current_design scp_top_wrap



#set reset
reset -name "trig_pcie*_button*"  -value 1
reset -name "pcie*_hot_resetn*" -value 0
reset -name PADS_RESETN -value 0
reset -name PADS_LSP_JTAG_RSTN -value 0

reset -name scp_top_inst.reset_ctrl_inst.noc_fr_ec_sys_rstn_reg -value 0
reset -name "scp_top_inst.reset_ctrl_inst.wd_rst_*" -value 1
reset -name scp_top_inst.reset_ctrl_inst.hw_rstn_from_pin -value 0
reset -name scp_top_inst.reset_ctrl_inst.scp_por_inst.por_rst_n -value 0
reset -name scp_top_inst.reset_ctrl_inst.rstn_mbist_pm_all -value 0
reset -name scp_top_wrap.scp_top_inst.scp_wdt_inst.wdt_sys_rst_n -value 0

#reset -name "scp_top_inst.reset_ctrl_inst.\crm_inst.noc_crm_*.md_rst_n" -value 0
#set case_analysis
set_case_analysis -name scp_top_inst.reset_ctrl_inst.sys_reset_master_enable[4:0] -value {h 1f}

set_case_analysis -name scp_top_inst.g2_io_inst.u_g2_pad.pads_mode_sel0_i -value 0
set_case_analysis -name scp_top_inst.g2_io_inst.u_g2_pad.pads_mode_sel1_i -value 0
set_case_analysis -name scp_top_inst.g2_io_inst.u_g2_pad.pads_mode_sel2_i -value 0
#set static signals

#INOUT
quasi_static -name "PADS_GPIO*"


#lowspeed
quasi_static -name low_speed_misc_wrap_inst.gpio_top_wrap_u.DW_apb_gpio_u.gpio_raw_intstatus
quasi_static -name low_speed_misc_wrap_inst.gpio_top_wrap_u.DW_apb_gpio_u.U_apb_gpio_apbif.gpio_int_polarity
quasi_static -name low_speed_misc_wrap_inst.pwm_wrap_u.apb_pwm_fan_u.pwm_fan_core_u.pwm_fan_apb_reg_u.pwm_start
quasi_static -name low_speed_misc_wrap_inst.pwm_wrap_u.apb_pwm_vid_u.pwm_vid_core_u.pwm_vid_apb_reg_u.pwm_start

#input
quasi_static -name "scp_top_inst.scp_int_ctrl_inst.sync_*.A*"


#scp_reg
quasi_static -name "scp_top_inst.scp_reg_top_inst.scp_*reg_*.inter_*"
quasi_static -name "scp_top_inst.scp_reg_top_inst.scp_reg_inst.cross_sync_trig*.Y*"
quasi_static -name "scp_top_inst.scp_reg_top_inst.scp_*_inst.sync_*_inst.A*"
