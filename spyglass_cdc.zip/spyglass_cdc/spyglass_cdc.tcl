#set env
set G2_RTL     $env(G2_RTL)
set DESIGN_NAME $env(DESIGN_NAME)

#new project
new_project -force sgcdc.prj

##################################################
#----------- Design and Project Setup -----------#
##################################################
set design_name $DESIGN_NAME
#set_option define {EU_MULTI_LIB_SEL}
#----------- read filellist
#read_file -type sourcelist $G3_NEO_RTL/xxxxxxxx/xxxxxxxx_top_wrap_dc.f
read_file -type sourcelist ../../${design_name}_for_dc.f
#read_file -type sourcelist ../../../../common/common_ip.lst
# set libs and ignore files to block box 
source set_lib_bb.tcl
#################################################################################################################################

#################################################################################################################################
# read memory and lib cell 
source set_gateslib.tcl
#################################################################################################################################

#set clock and reset
set_option sdc2sgdc yes
current_design    $DESIGN_NAME
sdc_data -file ./${design_name}.sdc
#sdc_data -file    ./syn_final_output.sdc

#################################################################################################################################
#################################################################################################################################
#read waive files
#if {[file exists ./waive/${design_name}.awl]} {
#  read_file -type awl ./waive/${design_name}.awl
#}

read_file -type awl ./scp_top_wrap_cdc.awl
read_file -type awl ./scp_bus.awl
#################################################################################################################################




#----------- Set Design Options
set_option top $design_name
#infer module with blackbox:   Causes SpyGlass to infer blackbox module interface based on the blackbox instances in the synthesized netlist and write to file named sgBlackbox.v in the current output directory
set_option inferblackbox yes
#hdl mode
set_option disablev2k no 
set_option enableV05 yes
set_option enableSV yes
set_option enableSV09 yes
#IEEE Std 1800-2012 Section 6.25 Parameterized data types: parameter type xxx = logic
set_option enableSV12 yes
set_option language_mode mixed
set_option mthresh 100000
#This option takes the threshold limit in terms of size of data bus  given as a power of 2. For e.g. if it's value is specified as 12, then data bus of size 4096 (2^12) would be completely evaluated.
set_option define_cell_sim_depth 12
#SpyGlass include the SYNTHESIS macro by default, so set it to false
set_option macro_synthesis_off yes
set_option dw yes
#################################################################################################################################
# Specify modules not to analyse
source set_no_analyse_modules.tcl
#################################################################################################################################
#waive -du {  {gpc2_clock_gate}  }  -rule {  {InferLatch}  } 

#add for lint_rtl_enhanced waive rule of low risk
#set_option ignorerules {SYNTH_1084}
waive -rule {  {SYNTH_1084}  }  -comment {parameter/localparam cannot be assigned a timeliteral value ( 1ps )} 


sync_cell -name *reset_n_sync* -reset
sync_cell -name *reset_sync* -reset
#----------- Read in the design; Equivalent to Design Read in Console
link_design

# set reset and static singals
#source set_quasi_static.tcl
read_file -type sgdc  set_quasi_static.tcl

#----------- Compiling the design; Equivalent to Design Read with Synthesis. Will also enable flattening
set_option designread_disable_flatten true
set_pref dq_design_view_type flat
compile_design

##################################################
#-----------        Goal Setup        -----------#
##################################################

#----------- Define the methodology to use
#current_methodology $SPYGLASS_HOME/GuideWare/latest/block/rtl_handoff

#----------- Define the goal to run
#current_goal Group_Run -goal {cdc/cdc_setup_check}
current_goal Group_Run -goal {cdc/cdc_setup_check cdc/clock_reset_integrity cdc/cdc_verify_struct cdc/cdc_verify cdc/cdc_abstract}




#Signal 'fifo_mem[rbinnext[(AWIDTH - 1):0] ]' size too big thus not processed, use 'set_parameter handle_large_bus yes' for enabling handling of these signals
#set_parameter handle_large_bus yes
#set_parameter nocheckoverflow yes
set_parameter use_inferred_resets yes
set_parameter fa_verif_cycles 65535
#----------- Run the goal
run_goal

save_project -force
gui_start
# exit -save
