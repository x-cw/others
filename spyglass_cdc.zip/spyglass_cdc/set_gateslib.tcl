##read memory db
#read_file -type gateslibdb $G3_NEO_RTL/xxxxxxxx/syn_lib/db/*.db
#

read_file -type gateslibdb  \
/Foundry/ARM/samsung_14lpu/Standard_Cell/samsung/ln14lpu_sc_s8p25t_flk_slvt_c84_V1.50_pkg/FE-Common/FE-Common_sec250430_0098/LIBERTY/ln14lpu_sc_s8p25t_flk_slvt_c84l16/ln14lpu_sc_s8p25t_flk_slvt_c84l16_sspg_nominal_max_0p7200v_m40c_lvf_dth.db_ccs_tn \
/Foundry/ARM/samsung_14lpu/Standard_Cell/samsung/ln14lpu_sc_s8p25t_flk_lvt_c84_V1.50_pkg/FE-Common/FE-Common_sec250430_0097/LIBERTY/ln14lpu_sc_s8p25t_flk_lvt_c84l16/ln14lpu_sc_s8p25t_flk_lvt_c84l16_sspg_nominal_max_0p7200v_m40c_lvf_dth.db_ccs_tn \
/Foundry/ARM/samsung_14lpu/Standard_IO/samsung/ln14lpu_gpio_lib_3p3v_a01_V1.13_pkg/FE-Common/FE-Common_sec260317_0034/LIBERTY/ln14lpu_gpio_lib_t33_sspg_sigcmax_0p7200v_2p9700v_m40c.db \
/Foundry/ARM/samsung_14lpu/Standard_IO/samsung/ln14lpu_gpio_lib_1p8v_a01_V1.21_pkg/FE-Common/FE-Common_sec260303_0070/LIBERTY/ln14lpu_gpio_lib_t18_sspg_sigcmax_0p7200v_1p6200v_m40c.db \
/Foundry/ARM/samsung_14lpu/Standard_IO/samsung/sf_efuse_x32_a100_ln14lpu_34000_V1.07_pkg/FE-Common/FE-Common_sec260420_0049/LIBERTY/sf_efuse4kb_a100_ln14lpu_34000_sspg_sigrcmin_0p7200v_m40c.db \
$G2_RTL/scp/syn_lib/db/INNO_FNPLL_TOP_ss_rcmax_m40.db \
$G2_RTL/scp/syn_lib/db/inno_por_ip_ss_rcmax_m40_func.db \
$G2_RTL/scp/syn_lib/db/ln14lpu_a01_mc_rf1rws_hdrw_rvt_512x128m2b1c0_SE_ACA_S14_RAM_SP_512X128_sspg_sigrcmax_0p7200v_0p7200v_m40c.db \
$G2_RTL/scp/syn_lib/db/ln14lpu_a01_mc_rf1rws_hdrw_rvt_528x32m4b1c0_SE_CXT_S14_RAM_SP_528X32_sspg_sigrcmax_0p7200v_0p7200v_m40c.db \
$G2_RTL/risc_v/syn_lib/db/ln14lpu_a01_mc_ra1rws_hdrw_rvt_4096x32m8b2c1_CPU_S14_RAM_SP_4096X32_sspg_sigrcmax_0p7200v_0p7200v_m40c.db \
$G2_RTL/risc_v/syn_lib/db/ln14lpu_a01_mc_vromp_hd_lvt_4096x32m16b2c1_CPU_S14_ROM_SP_4096X32_sspg_sigrcmax_0p7200v_m40c.db \
$G2_RTL/lowspeed/syn_lib/db/ln14lpu_a01_mc_rf1rs_hdrw_rvt_128x32m2b1c0_EC_S14_RAM_SP_128X32_sspg_sigrcmax_0p7200v_0p7200v_m40c.db \
$G2_RTL/lowspeed/syn_lib/db/inno_puf_64b_ip_setup_ss_cmax_T_m40.db \
