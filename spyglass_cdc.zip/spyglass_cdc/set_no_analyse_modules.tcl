
#set_option stop ${MODLUE_NAE}
#set_option stop { \
#   DW_div_pipe \
#   DW_div \
#}

#ip_block -name inno_tsensor_ip
