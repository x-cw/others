
#set_option ignorefile /Foundry/ARM/samsung_8lpu/Standard_IO/samsung/ln08lpp_gpio_1p8v_auto_V1.09_pkg/FE-Common_sec230405_0038/MODEL/ln08lpp_io_lib_t18.v 
#
#set_option ignorefile $G3_NEO_RTL/low_speed/rtl/efuse/sf_efuse2kb_a100_ln08lpp_304000.v 
#set_option ignorefile $G3_NEO_RTL/scp/sim_model/INNO_PLL_TOP_INT.v 
#set_option ignorefile $G3_NEO_RTL/scp/sim_model/INNO_PLL_TOP_FRAC.v 
#set_option ignorefile $G3_NEO_RTL/scp/sim_model/INNO_PLL_TOP_INT_4OUT.v 
#set_option ignorefile $G3_NEO_RTL/top/dig_top/sim_model/inno_por_ip.v 
#set_option ignorefile $G3_NEO_RTL/top/dig_top/sim_model/inno_puf_64b_ip.v 
#set_option ignorefile $G3_NEO_RTL/tsensor/sim_model/inno_tsensor_ip.v 
