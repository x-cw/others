// ----------------------------------------------------------------------------
//  The confidential and proprietary information contained in this file may
//  only be used by a person authorised under and to the extent permitted
//  by a subsisting licensing agreement from ARM Limited.
//
//                (C) COPYRIGHT 2004-2015 ARM Limited.
//                    ALL RIGHTS RESERVED
//
//  This entire notice must be reproduced on all copies of this file
//  and copies of this file may only be made by a person if such person is
//  permitted to do so under the terms of a subsisting license agreement
//  from ARM Limited.
//
//
//  Checked In          : $Date: 2014-01-15 12:32:16 +0000 (Wed, 15 Jan 2014) $
//  Revision            : $Revision: 38664 $
//  Release             : CoreSight-SoC-TM100-r3p2-00rel0
//
// ----------------------------------------------------------------------------
//  Purpose : DAP DP APB Interface Definitions.
// ----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// APB state machine
//-----------------------------------------------------------------------------
localparam DAP_APBIDLE   = 2'b00;
localparam DAP_APBSETUP  = 2'b01;
localparam DAP_APBENABLE = 2'b11;
localparam DAP_APBEND    = 2'b10;

//-----------------------------------------------------------------------------
// Transfer mode
//-----------------------------------------------------------------------------
localparam DAP_M_NORMAL = 2'b00;
localparam DAP_M_VERIFY = 2'b01;
localparam DAP_M_FIND   = 2'b10;
localparam DAP_M_RSVD   = 2'b11;
