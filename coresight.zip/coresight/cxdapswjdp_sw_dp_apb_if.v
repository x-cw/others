// --------------------------------------------------------------------------
//  The confidential and proprietary information contained in this file may
//  only be used by a person authorised under and to the extent permitted
//  by a subsisting licensing agreement from ARM Limited.
//
//                (C) COPYRIGHT 2004-2015 ARM Limited.
//                    ALL RIGHTS RESERVED
//
//  This entire notice must be reproduced on all copies of this file
//  and copies of this file may only be made by a person if such person is
//  permitted to do so under the terms of a subsisting license agreement
//  from ARM Limited.
//
//    Checked In : $Date: 2014-08-14 16:01:35 +0100 (Thu, 14 Aug 2014) $
//    Revision   : $Revision: 39945 $
//    Release    : CoreSight-SoC-TM100-r3p2-00rel0
// ----------------------------------------------------------------------------
//  Purpose : APB interface for DAP internal debug bus.
// ----------------------------------------------------------------------------


module cxdapswjdp_sw_dp_apb_if
  (
   //Inputs
   dapresetn, dapclk, dapclken, daprdata, dapready, dapslverr,
   busreq, buswrite, busaddr_31to24, busaddr_7to2, busabort,
   buswdata, busmode, busmask, bustrncnt,
   //Outputs
   dapsel, dapenable, dapwrite, dapabort, dapaddr_31to24,
   dapaddr_7to2, dapwdata,
   busack, busrdata, buscmp, buserr, busendcnt
  );

`include "cxdapswjdp_dp_apb_constants.v"

// --------------------------------------------------------------------------
// Port Definitions
// --------------------------------------------------------------------------
  input          dapresetn;      // Debug APB Reset
  input          dapclk;         // Debug APB Clock
  input          dapclken;       // Debug APB Clock Enable
  input  [31:0]  daprdata;       // DAP read bus
  input          dapready;       // Ready signal for DAP slaves
  input          dapslverr;      // Error signal for DAP slaves

  input          busreq;         // Bus Transaction Request
  input          buswrite;       // Bus write
  input  [31:24] busaddr_31to24; // Bus Address - AP Sel
  input  [7:2]   busaddr_7to2;   // Bus Address - Bank/Reg Sel
  input          busabort;       // Bus abort
  input  [31:0]  buswdata;       // Bus write Data Port
  input  [1:0]   busmode;        // Bus Mode
  input  [3:0]   busmask;        // Bus Compare Mask
  input  [11:0]  bustrncnt;      // Bus Transfer Cnt

  output         dapsel;         // DAP transaction select
  output         dapenable;      // DAP transaction enable
  output         dapwrite;       // APB transaction direction
  output         dapabort;       // DAP transaction abort
  output [31:24] dapaddr_31to24; // DAP address bits [31:24]
  output [7:2]   dapaddr_7to2;   // DAP address bits [7:2]
  output [31:0]  dapwdata;       // APB write bus

  output         busack;         // Bus Trasnaction Acknowledge
  output [31:0]  busrdata;       // Bus read Data Port
  output         buscmp;         // Bus Pushed Verify/Find
  output         buserr;         // Bus Error
  output [11:0]  busendcnt;      // Bus endCount

// ----------------------------------------------------------------------------
//  Signal Declarations
// ----------------------------------------------------------------------------
  // I/O pins
  wire          dapresetn;       // Debug APB Reset
  wire          dapclk;          // Debug APB Clock
  wire          dapclken;        // Debug APB Clock Enable
  wire   [31:0] daprdata;        // DAP read bus
  wire          dapready;        // Ready signal for DAP slaves
  wire          dapslverr;       // Error signal for DAP slaves
  wire          busreq;          // Bus Transaction Request
  wire          buswrite;        // Bus write
  wire [31:24]  busaddr_31to24;  // Bus Address - AP Sel
  wire [7:2]    busaddr_7to2;    // Bus Address - Bank/Reg Sel
  wire          busabort;        // Bus abort
  wire   [31:0] buswdata;        // Bus write Data Port
  wire    [1:0] busmode;         // Bus Mode
  wire    [3:0] busmask;         // Bus Compare Mask
  wire   [11:0] bustrncnt;       // Bus Transfer Cnt
  wire          dapsel;          // DAP transaction select
  wire          dapenable;       // DAP transaction enable
  wire          dapwrite;        // APB transaction direction
  wire          dap_write_int;   // APB transaction direction  - Internal version
  wire          dapabort;        // DAP transaction abort
  wire          dapabort_int;    // DAP transaction abort - internal version
  wire  [31:24] dapaddr_31to24;  // DAP address bits [31:24]
  wire  [7:2]   dapaddr_7to2;    // DAP address bits [7:2]
  wire   [31:0] dapwdata;        // APB write bus
  wire          busack;          // Bus Trasnaction Acknowledge
  wire   [31:0] busrdata;        // Bus read Data Port
  wire          buscmp;          // Bus Pushed Verify/Find
  wire          buserr;          // Bus Error
  wire   [11:0] busendcnt;       // Bus endCount

  // Internal signals
  reg     [1:0] apb_curr;          // APB state machine current
  reg     [1:0] apb_next;          // APB state machine next
  reg           apb_next_en;       // APB state machine next enable
  wire          busacki;           // bus acknowledge
  reg           busacki_cdc_check; // bus acknowledge
  reg           busack_di;         // bus acknowledge DFF input
  reg           busack_eni;        // bus acknowledge DFF enable
  wire          buscmpi;           // bus compare operation
  reg           buscmpi_cdc_check; // bus compare operation
  reg           buscmp_di;         // bus compare DFF input
  reg           buscmp_eni;        // bus compare DFF enable
  wire          buserri;           // bus error operation
  reg           buserri_cdc_check; // bus error operation
  wire          buserr_di;         // bus error DFF input
  wire          buserr_eni;        // bus error DFF enable
  wire   [31:0] rdbuff;            // APB read buffer
  reg    [31:0] rdbuff_cdc_check;  // APB read buffer
  wire          rdbuff_en;         // APB read buffer enable
  wire    [3:0] cmp_lane;          // compare byte lanes
  reg           dap_write_i;       // write control for normal operations
  wire   [11:0] buscnt;            // transaction counter
  reg    [11:0] buscnt_cdc_check;  // transaction counter
  reg    [11:0] buscnt_d;          // transaction counter DFF input
  reg           buscnt_en;         // transaction counter DFF enable
  wire          compare_st;        // compare status

// ----------------------------------------------------------------------------
// Beginning of main code
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
// next state combinatorial logic for APB state machine.
//  Do not let APBEND continue to APBIDLE until we've moved out of this state.
// ----------------------------------------------------------------------------
  always @ (dapclken or apb_curr or busreq or dapready or compare_st or
            buscnt or busmode or dapslverr or dapabort_int)
    case (apb_curr)
      DAP_APBIDLE   : begin
        apb_next   = DAP_APBSETUP;
        apb_next_en = dapclken & busreq;
      end
      DAP_APBSETUP  : begin
        apb_next   = DAP_APBENABLE;
        apb_next_en = dapclken;
      end
      DAP_APBENABLE : begin
        if (dapready)
          begin
            apb_next_en = dapclken;
            if (|buscnt)
              if ((busmode==DAP_M_FIND & compare_st) | (busmode==DAP_M_VERIFY &
                                                  !compare_st))
                apb_next = DAP_APBEND;
              else if (dapslverr | dapabort_int)
                apb_next = DAP_APBEND;
              else
                apb_next = DAP_APBSETUP;
            else
                apb_next = DAP_APBEND;
          end
        else
          begin
            apb_next   = 2'b00;
            apb_next_en = 1'b0;
          end
      end
      DAP_APBEND : begin
        apb_next   = DAP_APBIDLE;
        apb_next_en = dapclken & ~busreq;
      end
      default : begin
        apb_next   = 2'bxx;
        apb_next_en = 1'bx;
      end
    endcase

// ----------------------------------------------------------------------------
// registers for APB state machine
// ----------------------------------------------------------------------------
  always @ (negedge dapresetn or posedge dapclk)
    if (!dapresetn)
      apb_curr <= DAP_APBIDLE;
    else if (apb_next_en)
      apb_curr <= apb_next;

// ----------------------------------------------------------------------------
// Transfer PRDATA to the read buffer
// ----------------------------------------------------------------------------
  assign rdbuff_en = dapclken & apb_curr==DAP_APBENABLE & dapready & ~dap_write_int;

  always @ (negedge dapresetn or posedge dapclk)
    if (!dapresetn)
       rdbuff_cdc_check  <= {32{1'b0}};
    else if (rdbuff_en)
       rdbuff_cdc_check  <= daprdata;

// ----------------------------------------------------------------------------
// dapwrite - Force DAP read for Pushed operations
// ----------------------------------------------------------------------------
  always @ (busmode or buswrite)
    case (busmode)
      DAP_M_VERIFY,DAP_M_FIND : dap_write_i = 1'b0;
      DAP_M_NORMAL,DAP_M_RSVD : dap_write_i = buswrite;
      default           : dap_write_i = 1'bx;
    endcase

// ----------------------------------------------------------------------------
// Pushed operation compare
// ----------------------------------------------------------------------------
  assign cmp_lane[0] = (buswdata[7:0]  ==daprdata[7:0])   ? busmask[0] : 1'b0;
  assign cmp_lane[1] = (buswdata[15:8] ==daprdata[15:8])  ? busmask[1] : 1'b0;
  assign cmp_lane[2] = (buswdata[23:16]==daprdata[23:16]) ? busmask[2] : 1'b0;
  assign cmp_lane[3] = (buswdata[31:24]==daprdata[31:24]) ? busmask[3] : 1'b0;
  assign compare_st  = cmp_lane==busmask;

// ----------------------------------------------------------------------------
// Bus Transfer Counter
// ----------------------------------------------------------------------------
  always @ (dapclken or apb_curr or buscnt or dapready or busreq or bustrncnt or
            busabort or busmode or compare_st)
    begin
      buscnt_d  = {12{1'b0}};
      buscnt_en = 1'b0;
      if (apb_curr==DAP_APBIDLE & busreq)
        begin
          buscnt_d  = bustrncnt;
          buscnt_en = dapclken;
        end
      else if (apb_curr==DAP_APBENABLE & dapready)
        begin
          if (busabort)
            begin
              buscnt_d  = {12{1'b0}};
              buscnt_en = dapclken;
            end
          else if (|buscnt & ~((busmode==DAP_M_FIND & compare_st) |
                          (busmode==DAP_M_VERIFY & !compare_st)))
            begin
              buscnt_d  = (buscnt - 1);
              buscnt_en = dapclken;
            end
        end
    end

  always @ (negedge dapresetn or posedge dapclk)
    if (!dapresetn)
       buscnt_cdc_check  <= {12{1'b0}};
    else if (buscnt_en)
       buscnt_cdc_check  <= buscnt_d;

// ----------------------------------------------------------------------------
// Generate busack, referenced to clock edge, not combinatorially.
// ----------------------------------------------------------------------------
  always @ (dapclken or apb_curr or busreq)
    case (apb_curr)
      DAP_APBEND : begin
        // busreq assignment brings ACK forward a cycle
        busack_di  = busreq;
        busack_eni = dapclken;
      end
      DAP_APBIDLE,
      DAP_APBSETUP,
      DAP_APBENABLE : begin
        busack_di  = 1'b0;
        busack_eni = dapclken;
      end
      default: begin
        busack_di  = 1'bx;
        busack_eni = 1'bx;
      end
    endcase

  always @ (negedge dapresetn or posedge dapclk)
    if (!dapresetn)
       busacki_cdc_check  <= 1'b0;
    else if (busack_eni)
       busacki_cdc_check  <= busack_di;

// ----------------------------------------------------------------------------
// Generate buscmp
// ----------------------------------------------------------------------------
  always @ (dapclken or apb_curr or dapready or busmode or compare_st or buscmpi)
    case (busmode)
      DAP_M_VERIFY,DAP_M_FIND: begin
        buscmp_di  = compare_st;
        buscmp_eni = dapclken & apb_curr==DAP_APBENABLE & dapready &
                    (buscmpi ^ compare_st);
      end
      DAP_M_NORMAL,DAP_M_RSVD: begin
        buscmp_di  = 1'b0;
        buscmp_eni = dapclken & buscmpi;
      end
      default: begin
        buscmp_di  = 1'bx;
        buscmp_eni = 1'bx;
      end
    endcase


  always @ (negedge dapresetn or posedge dapclk)
    if (!dapresetn)
       buscmpi_cdc_check  <= 1'b0;
    else if (buscmp_eni)
       buscmpi_cdc_check  <= buscmp_di;

// ----------------------------------------------------------------------------
// Generate buserr
// ----------------------------------------------------------------------------
  assign buserr_di  = dapslverr;
  assign buserr_eni = dapclken & apb_curr==DAP_APBENABLE & dapready &
                       (buserri ^ dapslverr);

  always @ (negedge dapresetn or posedge dapclk)
    if (!dapresetn)
       buserri_cdc_check  <= 1'b0;
    else if (buserr_eni)
       buserri_cdc_check  <= buserr_di;

// ----------------------------------------------------------------------------
// DP bus outputs
// ----------------------------------------------------------------------------
  assign busrdata  = rdbuff;
  assign buscmp    = buscmpi;
  assign buserr    = buserri;
  assign busack    = busacki;
  assign busendcnt = buscnt;

// ----------------------------------------------------------------------------
// APB outputs
// ----------------------------------------------------------------------------
  assign dapsel         = apb_curr==DAP_APBENABLE | apb_curr==DAP_APBSETUP;
  assign dapenable      = apb_curr==DAP_APBENABLE;
  assign dap_write_int  = (apb_curr==DAP_APBENABLE | apb_curr==DAP_APBSETUP) &
                          dap_write_i;
  assign dapwrite       = dap_write_int;
  assign dapabort_int   = busabort & apb_curr==DAP_APBENABLE;
  assign dapabort       = dapabort_int;
  assign dapaddr_31to24 = (apb_curr==DAP_APBENABLE | apb_curr==DAP_APBSETUP) ?
                           busaddr_31to24 : {8{1'b0}};
  assign dapaddr_7to2   = (apb_curr==DAP_APBENABLE | apb_curr==DAP_APBSETUP) ?
                           busaddr_7to2 : {6{1'b0}};
  assign dapwdata       = (apb_curr==DAP_APBENABLE | apb_curr==DAP_APBSETUP) ?
                          buswdata  : {32{1'b0}};


`ifdef ARM_ASSERT_ON

  // simulation time generation of handshake start and end.
  wire hs_start;
  wire hs_end;

  assign hs_start = busreq & apb_curr==DAP_APBIDLE;
  assign hs_end   = busreq & apb_curr==DAP_APBEND & !busacki;

  // Do not include the following OVL when CDC checking is enabled
  `ifdef ARM_CDC_ON
  `else
  // busabort must only be asserted with busreq.
  assert_never #(`OVL_ERROR, `OVL_ASSERT, "busabort must only be asserted with busreq.")
    dapapb_busabort(.clk       (dapclk),
                    .reset_n   (dapresetn),
                    .test_expr (busabort & ~busreq));
  `endif

  // dapapb handshake.
  assert_handshake #(`OVL_ERROR, 0, 0, 0, 0, 0, `OVL_ASSERT, "dapapb handshake.")
    dapapb_handshake(.clk      (dapclk),
                    .reset_n   (dapresetn),
                     .req      (busreq),
                     .ack      (busacki));

  //  buswrite must remain static during handshake.
  assert_win_unchange #(`OVL_ERROR, 1, `OVL_ASSERT, "buswrite must remain static during handshake.")
    dapapb_hs_buswrite(
                       .clk         (dapclk),
                       .reset_n     (dapresetn),
                       .start_event (hs_start),
                       .test_expr   (buswrite),
                       .end_event  (hs_end));

  //  BUSADDR must remain static during handshake.
  assert_win_unchange #(`OVL_ERROR, 14, `OVL_ASSERT, "busaddr_* must remain static during handshake.")
  dapapb_hs_busaddr(
                    .clk         (dapclk),
                    .reset_n     (dapresetn),
                    .start_event (hs_start),
                    .test_expr   ({busaddr_31to24, busaddr_7to2}),
                    .end_event   (hs_end));

  //  buswdata must remain static during handshake.
  assert_win_unchange #(`OVL_ERROR, 32, `OVL_ASSERT, "buswdata must remain static during handshake.")
    dapapb_hs_buswdata(.clk      (dapclk),
                    .reset_n     (dapresetn),
                    .start_event (hs_start),
                    .test_expr   (buswdata),
                    .end_event   (hs_end));

  //  busmode must remain static during handshake.
  assert_win_unchange #(`OVL_ERROR, 2, `OVL_ASSERT, "busmode must remain static during handshake.")
    dapapb_hs_busmode(.clk         (dapclk),
                      .reset_n     (dapresetn),
                      .start_event ( hs_start),
                      .test_expr   (busmode),
                      .end_event   (hs_end));

  //  busmask must remain static during handshake.
  assert_win_unchange #(`OVL_ERROR, 4, `OVL_ASSERT, "busmask must remain static during handshake.")
  dapapb_hs_busmask(.clk           (dapclk),
                      .reset_n     (dapresetn),
                      .start_event (hs_start),
                      .test_expr   (busmask),
                      .end_event   (hs_end));

  //  bustrncnt must remain static during handshake.
  assert_win_unchange #(`OVL_ERROR, 12, `OVL_ASSERT, "bustrncnt must remain static during handshake.")
  dapapb_hs_bustrncnt(.clk         (dapclk),
                      .reset_n     (dapresetn),
                      .start_event (hs_start),
                      .test_expr   (bustrncnt),
                      .end_event   (hs_end));

  // Caught busreq x propogation
  assert_never_unknown #(`OVL_ERROR, 1, `OVL_ASSERT, "Caught busreq x propogation")
    dapapb_x_busreq(
                    .clk       (dapclk),
                    .reset_n   (dapresetn),
                    .qualifier (1'b1),
                    .test_expr (busreq));

  // Caught dapready x propogation
  assert_never_unknown #(`OVL_ERROR, 1, `OVL_ASSERT, "Caught dapready x propogation")
    dapapb_x_dapready(
                    .clk       (dapclk),
                    .reset_n   (dapresetn),
                    .qualifier (1'b1),
                    .test_expr (dapready));

  // Caught busabort x propogation
  assert_never_unknown #(`OVL_ERROR, 1, `OVL_ASSERT, "Caught busabort x propogation")
    dapapb_x_dapabort(
                      .clk       (dapclk),
                      .reset_n   (dapresetn),
                      .qualifier (1'b1),
                      .test_expr (busabort));

  // Caught compare x propogation
  assert_never_unknown #(`OVL_ERROR, 1, `OVL_ASSERT, "Caught compare x propogation")
  dapapb_x_compare(
                   .clk       (dapclk),
                   .reset_n   (dapresetn),
                   .qualifier (apb_curr==DAP_APBENABLE&
                               ((busmode==DAP_M_VERIFY)|
                                (busmode==DAP_M_FIND))),
                   .test_expr (compare_st));

  // Caught apb_curr x propogation
  assert_never_unknown #(`OVL_ERROR, 2, `OVL_ASSERT, "Caught apb_curr x propogation")
    dapapb_x_apbcurr(
                    .clk       (dapclk),
                    .reset_n   (dapresetn),
                    .qualifier (1'b1),
                    .test_expr (apb_curr));

  // Caught buscnt x propogation
  assert_never_unknown #(`OVL_ERROR, 12, `OVL_ASSERT, "Caught buscnt x propogation")
    dapapb_x_buscnt(
                    .clk       (dapclk),
                    .reset_n   (dapresetn),
                    .qualifier (apb_curr==DAP_APBENABLE),
                    .test_expr (buscnt));

  // Caught busmode x propogation
  //  * Note reset term.
  assert_never_unknown #(`OVL_ERROR, 2, `OVL_ASSERT, "Caught busmode x propogation")
    dapapb_x_busmode(
                    .clk       (dapclk),
                    .reset_n   (dapresetn),
                    .qualifier ( apb_curr==DAP_APBENABLE |
                                 apb_curr==DAP_APBSETUP),
                    .test_expr ( busmode));

`endif

`ifdef ARM_CDC_ON
  cdc_connect u_cdc_busacki(
                           .clk_launch(dapclk),
                           .clk_capture(cxdapswjdp.u_cxdapswjdp_swclktck.u_cxdapswjdp_sw_dp_sync.u_sync_bus_ack.clk),
                           .d_in(busacki_cdc_check),
                           .d_out_async(busacki)
                           );
`else
  assign busacki = busacki_cdc_check;
`endif
`ifdef ARM_CDC_ON
  cdc_connect #(11,0) u_cdc_buscnt(
                                  .clk_launch(dapclk),
                                  .clk_capture(cxdapswjdp.u_cxdapswjdp_swclktck.u_cxdapswjdp_jtag_dp_protocol.tck),
                                  .d_in(buscnt_cdc_check),
                                  .d_out_async(buscnt)
                                  );
`else
  assign buscnt = buscnt_cdc_check;
`endif
`ifdef ARM_CDC_ON
  cdc_connect #(31,0) u_cdc_rdbuff(
                                  .clk_launch(dapclk),
                                  .clk_capture(cxdapswjdp.u_cxdapswjdp_swclktck.u_cxdapswjdp_sw_dp_protocol.dbgclk),
                                  .d_in(rdbuff_cdc_check),
                                  .d_out_async(rdbuff)
                                  );
`else
  assign rdbuff = rdbuff_cdc_check;
`endif
`ifdef ARM_CDC_ON
  cdc_connect u_cdc_buscmpi(
                           .clk_launch(dapclk),
                           .clk_capture(cxdapswjdp.u_cxdapswjdp_swclktck.u_cxdapswjdp_jtag_dp_protocol.tck),
                           .d_in(buscmpi_cdc_check),
                           .d_out_async(buscmpi)
                           );
`else
  assign buscmpi = buscmpi_cdc_check;
`endif
`ifdef ARM_CDC_ON
  cdc_connect u_cdc_buserri(
                             .clk_launch(dapclk),
                             .clk_capture(cxdapswjdp.u_cxdapswjdp_swclktck.u_cxdapswjdp_jtag_dp_protocol.tck),
                             .d_in(buserri_cdc_check),
                             .d_out_async(buserri)
                             );
`else
  assign buserri = buserri_cdc_check;
`endif
endmodule
