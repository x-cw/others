// ----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//        (C) COPYRIGHT 2004-2015 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//      Checked In          : $Date: 2014-01-15 13:06:56 +0000 (Wed, 15 Jan 2014) $
//      Revision            : $Revision: 38665 $
//      Release             : CoreSight-SoC-TM100-r3p2-00rel0
//
// ----------------------------------------------------------------------------
//  Purpose : Top level for SWCLKTCK modules.
// ----------------------------------------------------------------------------

module cxdapswjdp_swclktck
  #(parameter IRLEN8 = 0)
  (
  // Outputs
  output wire         jtagsel,        // jtag select
  output wire         swdo,           // SW Data Out
  output wire         swdoen,         // SW Data Out Enable
  output wire         tdo,            // jtag TAP Data Out
  output wire         ntdoen,         // tdo enable
  output wire         jtagtop,        // jtag-DP TAP controller in one of four top states
                                      // (TLR, rti, Sel-DR, Sel-IR)
  output wire         busreq,         // Bus Transaction Request
  output wire         bus_write,      // Bus write
  output wire [31:24] busaddr_31to24, // Bus Address - AP Sel
  output wire [7:2]   busaddr_7to2,   // Bus Address - Bank/Reg Sel
  output wire         busabort,       // Bus abort
  output wire [31:0]  bus_wdata,      // Bus write Data Port
  output wire [1:0]   busmode,        // Bus Mode
  output wire [3:0]   busmask,        // Bus Compare Mask
  output wire [11:0]  bus_trn_cnt,    // Bus Transfer Cnt
  output wire         cdbgpwrupreq,   // Debug Power Domain up request
  output wire         csyspwrupreq,   // System Power Domain up request
  output wire         cdbgrstreq,     // Debug reset request to reset controller

    // Inputs
  input wire          ntrst,         // jtag TAP Reset
  input wire          swclktck,      // SW/jtag Clock
  input wire          swclktckn,     // Inverted SW/jtag Clock
  input wire          swditms,       // SW Debug Data In / jtag Test Mode Select
  input wire          npotrst,       // jtag/Serial Wire Power on reset
  input wire [31:0]   targetid,      // Target ID for SW multidrop selection
  input wire [3:0]    instanceid,    // Instance ID for SW multidrop selection
  input wire          buscmp_c,      // Bus Pushed Verify/Find
  input wire          buserr_c,      // Bus Error
  input wire [11:0]   busendcnt_c,   // Bus end count
  input wire          tdi,           // jtag TAP Data In / Alternative input function
  input wire [31:0]   busrdata_c,    // Bus read Data Port
  input wire          busack_c,      // Bus Transaction Acknowledge
  input wire          cdbgpwrupack,  // Debug Power Domain up acknowledge
  input wire          csyspwrupack,  // System Power Domain up acknowledge
  input wire          cdbgrstack     // Debug reset acknowledge to reset controller
  );

// --------------------------------------------------------------------------
// Signal Declarations
// --------------------------------------------------------------------------
  // Internal signals
  wire          j_busreq;
  wire          j_buswrite;
  wire          j_busabort;
  wire   [31:0] j_buswdata;
  wire    [1:0] j_busmode;
  wire    [3:0] j_busmask;
  wire   [11:0] j_bustrncnt;

  wire          s_busreq;
  wire          s_buswrite;
  wire  [31:24] sw_busaddr_31to24;
  wire  [7:2]   sw_busaddr_7to2;
  wire  [31:24] jtag_busaddr_31to24;
  wire  [7:2]   jtag_busaddr_7to2;
  wire          s_busabort;
  wire   [31:0] s_buswdata;
  wire    [1:0] s_busmode;
  wire    [3:0] s_busmask;
  wire   [11:0] s_bustrncnt;

  wire [3:0]    jtagstate;      // TAP in TLR
  wire          swdsel;         // SWD select
  wire          wirereset;      // SWD in wire reset
  wire          wireresetreq;   // SWD reset request
  wire          jtagtlrreq;     // jtag Reset request
  wire          safetms;

  wire          s_cdbgpwrupreq;
  wire          s_csyspwrupreq;
  wire          s_cdbgrstreq;
  wire          j_cdbgpwrupreq;
  wire          j_csyspwrupreq;
  wire          j_cdbgrstreq;

  wire          busack_t;        // sync  wire
  wire          cdbgpwrupack_s;  // sync  wire
  wire          csyspwrupack_s;  // sync  wire
  wire          cdbgrstack_s;    // sync  wire
  wire          jtag_sel_int;     // jtag select

//------------------------------------------------------------------------------
// Beginning of main code
//------------------------------------------------------------------------------
  // Serial Wire / jtag mode select watcher

  cxdapswjdp_swj_watcher u_cxdapswjdp_swj_watcher
   (
    // Outputs
    .jtagsel                            (jtag_sel_int),
    .swdsel                             (swdsel),
    .jtagtlrreq                         (jtagtlrreq),
    .wireresetreq                       (wireresetreq),
    .safetms                            (safetms),
    // Inputs
    .swclktck                           (swclktck),
    .swditms                            (swditms),
    .npotrst                            (npotrst),
    .wirereset                          (wirereset),
    .jtagstate                          (jtagstate[3:0]));

  assign jtagsel = jtag_sel_int;

  // SerialWire protocol engine
  cxdapswjdp_sw_dp_protocol  u_cxdapswjdp_sw_dp_protocol
   (
    // Outputs
    .dbgdo                              (swdo),
    .dbgdoen                            (swdoen),
    .busreq                             (s_busreq),
    .buswrite                           (s_buswrite),
    .busabort                           (s_busabort),
    .busaddr_31to24                     (sw_busaddr_31to24),
    .busaddr_7to2                       (sw_busaddr_7to2),
    .buswdata                           (s_buswdata[31:0]),
    .busmode                            (s_busmode[1:0]),
    .busmask                            (s_busmask[3:0]),
    .bustrncnt                          (s_bustrncnt[11:0]),
    .cdbgpwrupreq                       (s_cdbgpwrupreq),
    .csyspwrupreq                       (s_csyspwrupreq),
    .cdbgrstreq                         (s_cdbgrstreq),
    .wirereset                          (wirereset),
    // Inputs
    .targetid                           (targetid[31:0]),
    .instanceid                         (instanceid[3:0]),
    .dbgresetn                          (npotrst),
    .dbgclk                             (swclktck),
    .dbgdi                              (safetms),
    .swdsel                             (swdsel),
    .wireresetreq                       (wireresetreq),
    .busack                             (busack_t),
    .busrdata                           (busrdata_c[31:0]),
    .buscmp                             (buscmp_c),
    .buserr                             (buserr_c),
    .busendcnt                          (busendcnt_c[11:0]),
    .cdbgpwrupack                       (cdbgpwrupack_s),
    .csyspwrupack                       (csyspwrupack_s),
    .cdbgrstack                         (cdbgrstack_s));

  // jtag protocol engine
  cxdapswjdp_jtag_dp_protocol #(.IRLEN8(IRLEN8)) u_cxdapswjdp_jtag_dp_protocol
   (
    // Outputs
    .tdo                                (tdo),
    .ntdoen                             (ntdoen),
    .busreq                             (j_busreq),
    .buswrite                           (j_buswrite),
    .busabort                           (j_busabort),
    .busaddr_31to24                     (jtag_busaddr_31to24),
    .busaddr_7to2                       (jtag_busaddr_7to2),
    .buswdata                           (j_buswdata[31:0]),
    .busmode                            (j_busmode[1:0]),
    .busmask                            (j_busmask[3:0]),
    .bustrncnt                          (j_bustrncnt[11:0]),
    .cdbgpwrupreq                       (j_cdbgpwrupreq),
    .csyspwrupreq                       (j_csyspwrupreq),
    .cdbgrstreq                         (j_cdbgrstreq),
    .jtagstate                          (jtagstate),
    .jtagtop                            (jtagtop),
    // Inputs
    .npotrst                            (npotrst),
    .ntrst                              (ntrst),
    .tck                                (swclktck),
    .tckn                               (swclktckn),
    .tms                                (safetms),
    .tdi                                (tdi),
    .busack                             (busack_t),
    .busrdata                           (busrdata_c[31:0]),
    .buscmp                             (buscmp_c),
    .buserror                           (buserr_c),
    .busendcnt                          (busendcnt_c[11:0]),
    .cdbgpwrupack                       (cdbgpwrupack_s),
    .csyspwrupack                       (csyspwrupack_s),
    .cdbgrstack                         (cdbgrstack_s),
    .jtagsel                            (jtag_sel_int),
    .jtagtlrreq                         (jtagtlrreq));

  // Serial Interface Mux
  cxdapswjdp_dp_i_mux  u_cxdapswjdp_dp_i_mux
   (
    .dbgclk                             (swclktck),

    // Outputs
    .busreq                             (busreq),
    .bus_write                          (bus_write),
    .busaddr_31to24                     (busaddr_31to24),
    .busaddr_7to2                       (busaddr_7to2),
    .busabort                           (busabort),
    .bus_wdata                          (bus_wdata[31:0]),
    .busmode                            (busmode[1:0]),
    .busmask                            (busmask[3:0]),
    .bus_trn_cnt                        (bus_trn_cnt[11:0]),
    .cdbgpwrupreq                       (cdbgpwrupreq),
    .csyspwrupreq                       (csyspwrupreq),
    .cdbgrstreq                         (cdbgrstreq),
    // Inputs
    .npotrst                            (npotrst),
    .jtagsel                            (jtag_sel_int),
    .j_busreq                           (j_busreq),
    .j_buswrite                         (j_buswrite),
    .jtag_busaddr_31to24                (jtag_busaddr_31to24),
    .jtag_busaddr_7to2                  (jtag_busaddr_7to2),
    .j_busabort                         (j_busabort),
    .j_buswdata                         (j_buswdata[31:0]),
    .j_busmode                          (j_busmode[1:0]),
    .j_busmask                          (j_busmask[3:0]),
    .j_bustrncnt                        (j_bustrncnt[11:0]),
    .j_cdbgpwrupreq                     (j_cdbgpwrupreq),
    .j_csyspwrupreq                     (j_csyspwrupreq),
    .j_cdbgrstreq                       (j_cdbgrstreq),
    .s_busreq                           (s_busreq),
    .s_buswrite                         (s_buswrite),
    .sw_busaddr_31to24                  (sw_busaddr_31to24),
    .sw_busaddr_7to2                    (sw_busaddr_7to2),
    .s_busabort                         (s_busabort),
    .s_buswdata                         (s_buswdata[31:0]),
    .s_busmode                          (s_busmode[1:0]),
    .s_busmask                          (s_busmask[3:0]),
    .s_bustrncnt                        (s_bustrncnt[11:0]),
    .s_cdbgpwrupreq                     (s_cdbgpwrupreq),
    .s_csyspwrupreq                     (s_csyspwrupreq),
    .s_cdbgrstreq                       (s_cdbgrstreq));

  // SWCLKTCK domain synchronisers
  cxdapswjdp_sw_dp_sync  u_cxdapswjdp_sw_dp_sync
   (
    .dbgresetn      (npotrst),
    .dbgclk         (swclktck),
    .busack         (busack_c),
    .cdbgpwrupack   (cdbgpwrupack),
    .csyspwrupack   (csyspwrupack),
    .cdbgrstack     (cdbgrstack),

    .busack_t        (busack_t),
    .cdbgpwrupack_s  (cdbgpwrupack_s),
    .csyspwrupack_s  (csyspwrupack_s),
    .cdbgrstack_s    (cdbgrstack_s)
    );

endmodule
