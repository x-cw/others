+incdir+$GP3_RTL/coresight/rtl/coresight_component/debug_module/cxdapjtagap/verilog
$GP3_RTL/coresight/rtl/coresight_component/debug_module/cxdapjtagap/verilog/cxdapjtagap_apb_if.v
$GP3_RTL/coresight/rtl/coresight_component/debug_module/cxdapjtagap/verilog/cxdapjtagap_mux.v
$GP3_RTL/coresight/rtl/coresight_component/debug_module/cxdapjtagap/verilog/cxdapjtagap_constants.v
$GP3_RTL/coresight/rtl/coresight_component/debug_module/cxdapjtagap/verilog/cxdapjtagap_engine.v
$GP3_RTL/coresight/rtl/coresight_component/debug_module/cxdapjtagap/verilog/cxdapjtagap.v
$GP3_RTL/coresight/rtl/coresight_component/debug_module/cxdapjtagap/verilog/cxdapjtagap_sync.v
