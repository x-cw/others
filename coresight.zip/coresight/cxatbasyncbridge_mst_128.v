//-----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2010-2015 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//  Version and Release Control Information:
//
//  Checked In          : $Date: 2015-01-29 15:49:43 +0000 (Thu, 29 Jan 2015) $
//  Revision	        : $Revision: 41305 $
//  Date	        : $Date: 2015-01-29 15:49:43 +0000 (Thu, 29 Jan 2015) $
//
//  Release Information : CoreSight-SoC-TM100-r3p2-00rel0
//-----------------------------------------------------------------------------

//----------------------------------------------------------------------------
//
//                               CXATBASYNCBRIDGE.v
//                              ================
//
//----------------------------------------------------------------------------
//
//  Overview
// ==========
//
// This component instantiates an ATBASYNCBRIDGE of configurable ATB_DATA_WIDTH and optional CLOCK_STOP feature
//
//
//----------------------------------------------------------------------------



//------------------------------------------------------------------------------
// Module Declaration
//------------------------------------------------------------------------------
module cxatbasyncbridge_mst_128
  (
  //----------------------------------------------------------------------------
  // port definitions
  //----------------------------------------------------------------------------

  // Master Port
  clkm,        // ATB Bus clock for Masterport
  clkenm,      // ATB clock enable for masterport
  resetmn,     // ATB Bus reset on Master side
  atreadym,    // ATB Bus transfer ready master
  afvalidm,    // ATB Bus flush valid master
  syncreqm,    // Synchronization request
  atvalidm,    // ATB Bus transfer valid master
  atidm,       // ATB Bus id master
  atbytesm,    // ATB byte lane information
  atdatam,     // ATB Bus data master
  afreadym,     // ATB Bus flush ready master

  // Inter-domain ATB bus (Master side)
  atb_fwd_data_in,        // Fifo data which needs to be driven on master side
  atb_rev_data_out,       // Handshake signals and pointers from master side
  zero_pointer,           // Indication that the fifo is empty
  syncreqs_req_async_out, // syncreqs assertion request from ATBM
  syncreqs_ack_async_in   // ack from syncreqs domain for ATBM domain

);



  //----------------------------------------------------------------------------
  // parameters
  //----------------------------------------------------------------------------

  // calculated parameters (do not alter)

  localparam ATB_BYTES_WIDTH = 4;

  localparam ATB_DATA_WIDTH = 128;

  localparam DW = ATB_DATA_WIDTH - 1;
  localparam BW = ATB_BYTES_WIDTH - 1;

  localparam FIFO_DATA_WIDTH = BW+DW+9;




  // Master Port

  input wire             clkm;         // ATB Bus clock for Masterport
  input wire             clkenm;       // ATB clock enable for masterport
  input wire             resetmn;      // ATB Bus reset on Master side
  input wire             atreadym;     // ATB Bus transfer ready master
  input wire             afvalidm;     // ATB Bus flush valid master
  input wire             syncreqm;     // Synchronization request
  // Master Port
  output wire            atvalidm;     // ATB Bus transfer valid master
  output wire [6:0]      atidm;        // ATB Bus id master

  output wire [3:0]      atbytesm;     // ATB byte select master
  output wire [128-1:0]  atdatam;      // ATB Bus data master
  output wire            afreadym;     // ATB Bus flush ready master
  // Inter-domain ATB bus (Master side)
  output wire [4:0] atb_rev_data_out;     // Handshake signals and pointers from master side
//  input wire [6*FIFO_DATA_WIDTH + 10 : 0] atb_fwd_data_in;
  input wire [6*139 + 10 : 0] atb_fwd_data_in;
                                      // Fifo data which needs to be driven on master side
  output wire       zero_pointer;     // Indication that the fifo is empty
  output wire       syncreqs_req_async_out;
                                      // syncreqs assertion request from ATBM
  input wire        syncreqs_ack_async_in;
                                      // ack from syncreqs domain for ATBM domain

  //----------------------------------------------------------------------------
  // WIRES AND REGS
  //----------------------------------------------------------------------------

  // ---------------------------------------------------------------------------
  // ATB Master Interface
  // ---------------------------------------------------------------------------
  cxatbasyncbridge_mst_if_mst #(DW, BW, FIFO_DATA_WIDTH) u_cxatbasyncbridge_mst_if
    (
    // Inputs
    .atclkm                            (clkm),
    .atclkenm                          (clkenm),
    .atresetmn                         (resetmn),

    .atreadym                          (atreadym),
    .afvalidm                          (afvalidm),
    .atb_fwd_data                      (atb_fwd_data_in),
    .atb_rev_data                      (atb_rev_data_out),
    // Outputs
    .atvalidm                          (atvalidm),
    .atbytesm                          (atbytesm),
    .atidm                             (atidm),
    .atdatam                           (atdatam),
    .afreadym                          (afreadym),

    .zero_pointer                      (zero_pointer));

  // ---------------------------------------------------------------------------
  // syncreqm domain
  // ---------------------------------------------------------------------------
cxatbasyncbridge_syncreqm_domain_mst
  u_cxatbasyncbridge_syncreqm_domain (
                     .syncreqs_req_async       (syncreqs_req_async_out),
                     .syncreqs_ack_async       (syncreqs_ack_async_in),
                     
                     .syncreqm                 (syncreqm),
                     .clkm                     (clkm),
                     .clkenm                   (clkenm),
                     .resetmn                  (resetmn)
                                   );


`ifdef ARM_ASSERT_ON
  //----------------------------------------------------------------------------
  // OVL Assertions
  //----------------------------------------------------------------------------




`endif
endmodule // cxatbasyncbridge
