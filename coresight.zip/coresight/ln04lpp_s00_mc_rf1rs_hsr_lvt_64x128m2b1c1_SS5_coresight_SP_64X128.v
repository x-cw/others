/*====================================================================================================*/
/*  MemoryCompiler Version : FB-V2.23                                                                 */
/*  Date of Generation     : Thu Oct 16 16:30:03 2025                                                 */
/*  User Name              : fangxn                                                                   */
/*====================================================================================================*/
/*                                                                                     copyright 2024.*/
/*                                                                           SAMSUNG Electronics corp.*/
/*                                                                                all rights reserved.*/
/*  LIBRARY              : SF4X                                                                       */
/*  CONFIGURATION        : Depth=64, Bits=128, Ymux=2                                                 */
/*  INSTANCE NAME        : ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128          */
/*  VIEW VERSION         : 1.7                                                                        */
/*====================================================================================================*/
/* The confidential and proprietary information contained in this file may only be used by a person   */
/* authorised under and to the extent permitted by a subsisting licensing agreement from Samsung      */
/* Electronics.                                                                                       */

/* This entire notice must be reproduced on all copies of this file and copies of this file may only  */
/* be made by a person if such person is permitted to do so under the terms of a subsisting license   */
/* agreement from Samsung Electronics.                                                                */

/* Modification of this file is not permitted for any one and any case. Samsung Electronics has no    */
/* responsibility for any problem caused by unpermitted modification of this file.                    */
/*====================================================================================================*/


`timescale 1ns / 1ps
`ifndef REG_MEM
`define D_MEM_DELAY 0.0
`define D_MEM_SETUP 0.0
`define D_MEM_HOLD 0.0
`define D_MEM_WIDTH_H 0.0
`define D_MEM_WIDTH_L 0.0
`define D_MEM_WIDTH_THD 0.0
`define D_MEM_PERIOD 0.0

`define SEC_LPV_STARTTIME 0.0
`define DELAY_FOR_STOP 0.0

module datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 (CK, DOUT_update, SE, SI, DI, DFTRAM, mem_path, XDOUT, DOUT, BWEN);
	input CK, DOUT_update, SE, SI, DI, DFTRAM, mem_path, XDOUT, BWEN;
	output DOUT;
 
	reg DI_int;
	reg DOUT;

	always @(CK or SE or SI or DI or BWEN) begin
		if (CK === 1'b0) begin
			if (SE === 1'b1)
				DI_int=SI; // shift data
			else if (SE === 1'bx)
				DI_int=1'bx;
			else
				DI_int=(DI|BWEN); // capture data
		end
	end

	// model output side of RAM latch
	always @(posedge DOUT_update or posedge XDOUT or mem_path) begin
		if (XDOUT === 1'b0) begin
			if (DFTRAM === 1'b1)
				DOUT<=DI_int;  // scan mode
			else
				DOUT<=mem_path; // mission mode
		end
		else
			DOUT<=1'bx;
	end
endmodule

`celldefine

`ifdef POWER_PINS
module ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 (VDDE, VSSE, DOUT, CK, CSN, WEN, A, DI, MCS, MCSW
					,SO_D_L, SO_D_R, DFTRAM, SE, SI_D_L, SI_D_R
					,RET
					,CRE1, CRE2, FCA1, FCA2
					,ADME
					);
`else
module ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 (DOUT, CK, CSN, WEN, A, DI, MCS, MCSW
					,SO_D_L, SO_D_R, DFTRAM, SE, SI_D_L, SI_D_R
					,RET
					,CRE1, CRE2, FCA1, FCA2
					,ADME
					);
`endif

	// Parameter definition 
	parameter WORDS = 64;
	parameter BITS  = 128;
	parameter addr_width  = 6;
	parameter mux  = 2;
	parameter TRUE = 1'b1;
	parameter FALSE = 1'b0;
	parameter faddr1_width = 5;
	parameter faddr2_width = 5;
	parameter r_bit = 4;

	parameter word1 = {BITS{1'b1}};
	parameter word0 = {BITS{1'b0}};
	parameter wordx = {BITS{1'bx}};
	parameter wordz = {BITS{1'bz}};
	parameter row1 = {BITS*mux+r_bit*2{1'b1}};
	parameter row0 = {BITS*mux+r_bit*2{1'b0}};
	parameter rowx = {BITS*mux+r_bit*2{1'bx}};
	parameter addrx = {addr_width{1'bx}};

	// Primary port definition 
	output [BITS-1:0] DOUT;
	input CK;
	input CSN;
	input WEN;
	input [BITS-1:0] DI;
	input [addr_width-1:0] A;
	input [1:0] MCS;
	input MCSW;

	output SO_D_L;
	output SO_D_R;
	input SI_D_L;
	input SI_D_R;
	input DFTRAM;
	input SE;

	input RET;


	input CRE1;
	input CRE2;
	input [faddr1_width-1:0] FCA1;
	input [faddr2_width-1:0] FCA2;

	input [2:0] ADME;

`ifdef POWER_PINS
	inout VDDE;
	inout VSSE;
`endif

	integer i,j,h,k;

	// Memory definition
	reg  [(BITS*mux)-1+r_bit*2:0] mem [0:WORDS/mux-1];
	reg  [(BITS*mux)-1+r_bit*2:0] row;
	reg  [128-1+r_bit:0] rowL;
	reg  [128-1+r_bit:0] rowR;
	reg  [128-1:0] rowLL;
	reg  [128-1:0] rowRR;
	reg  [64-1:0] remained_data_L;
	reg  [64-1:0] remained_data_R;
	reg  [64-1:0] new_data_L;
	reg  [64-1:0] new_data_R;
	reg  [BITS-1:0] outreg_tmp,outreg;
	reg  [BITS-1:0] outreg_backdoor;

	// Internal register declaration
	reg  LAST_CK;

	wire [BITS-1:0] DI_;
	reg  [BITS-1:0] DI_int;
	wire [BITS-1:0] BWEN_;
	assign BWEN_ = word0;
	reg  [BITS-1:0] BWEN_int;
	wire [addr_width-1:0] A_;
	reg  [addr_width-1:0] A_int;
	wire CK_;
	wire DFTRAM_;
	reg  DFTRAM_int;
	wire SE_;
	reg  SE_int;
	wire SI_D_L_;
	wire SI_D_R_;
	wire [1:0] MCS_;
	reg  [1:0] MCS_int;
	wire MCSW_;
	reg  MCSW_int;
	wire RET_;
	reg  RET_int;
	wire CSN_;
	reg  CSN_int;
	wire WEN_;
	reg  WEN_int;
	wire CRE1_;
	reg  CRE1_int;
	wire CRE2_;
	reg  CRE2_int;
	wire [faddr1_width-1:0] FCA1_;
	reg  [faddr1_width-1:0] FCA1_int;
	reg  [faddr2_width-1:0] FCA2_int;
	wire [faddr2_width-1:0] FCA2_;
	wire [2:0] ADME_;
	wire [BITS-1:0] DOUT_;
	wire [BITS-1:0] DOUT_err_inj;
	wire [BITS-1:0] DOUT_data_path;
	wire [BITS-1:0] DOUT_int;
	wire SO_D_L_;
	wire SO_D_L_reg;
	wire SO_D_R_;
	wire SO_D_R_reg;

	reg XDOUT;
	reg DOUT_update;

	reg NOT_CK_A;
	reg NOT_CK_CRE;
	reg NOT_CK_FCA;
	reg NOT_CK_CSN;
	reg NOT_CK_DI_0;
	reg NOT_CK_DI_1;
	reg NOT_CK_DI_2;
	reg NOT_CK_DI_3;
	reg NOT_CK_DI_4;
	reg NOT_CK_DI_5;
	reg NOT_CK_DI_6;
	reg NOT_CK_DI_7;
	reg NOT_CK_DI_8;
	reg NOT_CK_DI_9;
	reg NOT_CK_DI_10;
	reg NOT_CK_DI_11;
	reg NOT_CK_DI_12;
	reg NOT_CK_DI_13;
	reg NOT_CK_DI_14;
	reg NOT_CK_DI_15;
	reg NOT_CK_DI_16;
	reg NOT_CK_DI_17;
	reg NOT_CK_DI_18;
	reg NOT_CK_DI_19;
	reg NOT_CK_DI_20;
	reg NOT_CK_DI_21;
	reg NOT_CK_DI_22;
	reg NOT_CK_DI_23;
	reg NOT_CK_DI_24;
	reg NOT_CK_DI_25;
	reg NOT_CK_DI_26;
	reg NOT_CK_DI_27;
	reg NOT_CK_DI_28;
	reg NOT_CK_DI_29;
	reg NOT_CK_DI_30;
	reg NOT_CK_DI_31;
	reg NOT_CK_DI_32;
	reg NOT_CK_DI_33;
	reg NOT_CK_DI_34;
	reg NOT_CK_DI_35;
	reg NOT_CK_DI_36;
	reg NOT_CK_DI_37;
	reg NOT_CK_DI_38;
	reg NOT_CK_DI_39;
	reg NOT_CK_DI_40;
	reg NOT_CK_DI_41;
	reg NOT_CK_DI_42;
	reg NOT_CK_DI_43;
	reg NOT_CK_DI_44;
	reg NOT_CK_DI_45;
	reg NOT_CK_DI_46;
	reg NOT_CK_DI_47;
	reg NOT_CK_DI_48;
	reg NOT_CK_DI_49;
	reg NOT_CK_DI_50;
	reg NOT_CK_DI_51;
	reg NOT_CK_DI_52;
	reg NOT_CK_DI_53;
	reg NOT_CK_DI_54;
	reg NOT_CK_DI_55;
	reg NOT_CK_DI_56;
	reg NOT_CK_DI_57;
	reg NOT_CK_DI_58;
	reg NOT_CK_DI_59;
	reg NOT_CK_DI_60;
	reg NOT_CK_DI_61;
	reg NOT_CK_DI_62;
	reg NOT_CK_DI_63;
	reg NOT_CK_DI_64;
	reg NOT_CK_DI_65;
	reg NOT_CK_DI_66;
	reg NOT_CK_DI_67;
	reg NOT_CK_DI_68;
	reg NOT_CK_DI_69;
	reg NOT_CK_DI_70;
	reg NOT_CK_DI_71;
	reg NOT_CK_DI_72;
	reg NOT_CK_DI_73;
	reg NOT_CK_DI_74;
	reg NOT_CK_DI_75;
	reg NOT_CK_DI_76;
	reg NOT_CK_DI_77;
	reg NOT_CK_DI_78;
	reg NOT_CK_DI_79;
	reg NOT_CK_DI_80;
	reg NOT_CK_DI_81;
	reg NOT_CK_DI_82;
	reg NOT_CK_DI_83;
	reg NOT_CK_DI_84;
	reg NOT_CK_DI_85;
	reg NOT_CK_DI_86;
	reg NOT_CK_DI_87;
	reg NOT_CK_DI_88;
	reg NOT_CK_DI_89;
	reg NOT_CK_DI_90;
	reg NOT_CK_DI_91;
	reg NOT_CK_DI_92;
	reg NOT_CK_DI_93;
	reg NOT_CK_DI_94;
	reg NOT_CK_DI_95;
	reg NOT_CK_DI_96;
	reg NOT_CK_DI_97;
	reg NOT_CK_DI_98;
	reg NOT_CK_DI_99;
	reg NOT_CK_DI_100;
	reg NOT_CK_DI_101;
	reg NOT_CK_DI_102;
	reg NOT_CK_DI_103;
	reg NOT_CK_DI_104;
	reg NOT_CK_DI_105;
	reg NOT_CK_DI_106;
	reg NOT_CK_DI_107;
	reg NOT_CK_DI_108;
	reg NOT_CK_DI_109;
	reg NOT_CK_DI_110;
	reg NOT_CK_DI_111;
	reg NOT_CK_DI_112;
	reg NOT_CK_DI_113;
	reg NOT_CK_DI_114;
	reg NOT_CK_DI_115;
	reg NOT_CK_DI_116;
	reg NOT_CK_DI_117;
	reg NOT_CK_DI_118;
	reg NOT_CK_DI_119;
	reg NOT_CK_DI_120;
	reg NOT_CK_DI_121;
	reg NOT_CK_DI_122;
	reg NOT_CK_DI_123;
	reg NOT_CK_DI_124;
	reg NOT_CK_DI_125;
	reg NOT_CK_DI_126;
	reg NOT_CK_DI_127;
	reg NOT_CK_MCS;
	reg NOT_CK_MCSW;
	reg NOT_CK_DFTRAM;
	reg NOT_CK_WEN;
	reg NOT_RET_CSN;
	reg NOT_RET_PDE;
	reg NOT_CSN_RET;
	reg NOT_DFTRAM_RET;
	reg NOT_RET_DFTRAM;
	reg NOT_CK_ADME;
	reg NOT_CK_SI_D_L;
	reg NOT_CK_SI_D_R;
	reg NOT_CK_SE;
	reg NOT_CK_MINH;
	reg NOT_CK_MINL;
	reg NOT_CK_PER;

`ifdef DISPLAY_CHECK_OFF
	parameter DISPLAY_CNTRL = 1;
`else
	parameter DISPLAY_CNTRL = 0;
`endif

`ifdef BACKDOOR_DISPLAY_CHECK_OFF
	parameter BACKDOOR_DISPLAY_CNTRL = 1;
`else
	parameter BACKDOOR_DISPLAY_CNTRL = 0;
`endif

// If INITIALIZE_MEMORY is defined at Simulator Command Line, it Initializes the Memory with all ZEROS.
`ifdef INITIALIZE_MEMORY_0
	initial for (i = 0; i < WORDS/mux; i = i + 1) mem[i] = row0;
`endif
`ifdef INITIALIZE_MEMORY_1
	initial for (i = 0; i < WORDS/mux; i = i + 1) mem[i] = row1;
`endif


// ------------------------------------------------------
// MIPD definition 
// ------------------------------------------------------
	wire vddpe_int;
	wire vddce_int;
	wire vsse_int;
`ifdef POWER_PINS
	assign vddce_int =  VDDE;
	assign vddpe_int =  VDDE;
	assign vsse_int =  VSSE;
`else
	assign vddce_int =  1'b1;
	assign vddpe_int =  1'b1;
	assign vsse_int =  1'b0;
`endif

	buf (RET_, RET);
	buf (CK_, CK);
	buf (CSN_, CSN);
	buf (WEN_, WEN);
	buf (MCS_[0], MCS[0]);
	buf (MCS_[1], MCS[1]);
	buf (MCSW_, MCSW);
	buf (ADME_[2], ADME[2]);
	buf (ADME_[1], ADME[1]);
	buf (ADME_[0], ADME[0]);

	buf (DFTRAM_, DFTRAM);
	buf (SE_, SE);
	buf (SI_D_L_, SI_D_L);
	buf (SI_D_R_, SI_D_R);

	buf (CRE1_, CRE1);
	buf (CRE2_, CRE2);
	buf (FCA1_[0], FCA1[0]);
	buf (FCA1_[1], FCA1[1]);
	buf (FCA1_[2], FCA1[2]);
	buf (FCA1_[3], FCA1[3]);
	buf (FCA1_[4], FCA1[4]);
	buf (FCA2_[0], FCA2[0]);
	buf (FCA2_[1], FCA2[1]);
	buf (FCA2_[2], FCA2[2]);
	buf (FCA2_[3], FCA2[3]);
	buf (FCA2_[4], FCA2[4]);
	buf (A_[0], A[0]);
	buf (A_[1], A[1]);
	buf (A_[2], A[2]);
	buf (A_[3], A[3]);
	buf (A_[4], A[4]);
	buf (A_[5], A[5]);
	buf (DI_[0], DI[0]);
	buf (DI_[1], DI[1]);
	buf (DI_[2], DI[2]);
	buf (DI_[3], DI[3]);
	buf (DI_[4], DI[4]);
	buf (DI_[5], DI[5]);
	buf (DI_[6], DI[6]);
	buf (DI_[7], DI[7]);
	buf (DI_[8], DI[8]);
	buf (DI_[9], DI[9]);
	buf (DI_[10], DI[10]);
	buf (DI_[11], DI[11]);
	buf (DI_[12], DI[12]);
	buf (DI_[13], DI[13]);
	buf (DI_[14], DI[14]);
	buf (DI_[15], DI[15]);
	buf (DI_[16], DI[16]);
	buf (DI_[17], DI[17]);
	buf (DI_[18], DI[18]);
	buf (DI_[19], DI[19]);
	buf (DI_[20], DI[20]);
	buf (DI_[21], DI[21]);
	buf (DI_[22], DI[22]);
	buf (DI_[23], DI[23]);
	buf (DI_[24], DI[24]);
	buf (DI_[25], DI[25]);
	buf (DI_[26], DI[26]);
	buf (DI_[27], DI[27]);
	buf (DI_[28], DI[28]);
	buf (DI_[29], DI[29]);
	buf (DI_[30], DI[30]);
	buf (DI_[31], DI[31]);
	buf (DI_[32], DI[32]);
	buf (DI_[33], DI[33]);
	buf (DI_[34], DI[34]);
	buf (DI_[35], DI[35]);
	buf (DI_[36], DI[36]);
	buf (DI_[37], DI[37]);
	buf (DI_[38], DI[38]);
	buf (DI_[39], DI[39]);
	buf (DI_[40], DI[40]);
	buf (DI_[41], DI[41]);
	buf (DI_[42], DI[42]);
	buf (DI_[43], DI[43]);
	buf (DI_[44], DI[44]);
	buf (DI_[45], DI[45]);
	buf (DI_[46], DI[46]);
	buf (DI_[47], DI[47]);
	buf (DI_[48], DI[48]);
	buf (DI_[49], DI[49]);
	buf (DI_[50], DI[50]);
	buf (DI_[51], DI[51]);
	buf (DI_[52], DI[52]);
	buf (DI_[53], DI[53]);
	buf (DI_[54], DI[54]);
	buf (DI_[55], DI[55]);
	buf (DI_[56], DI[56]);
	buf (DI_[57], DI[57]);
	buf (DI_[58], DI[58]);
	buf (DI_[59], DI[59]);
	buf (DI_[60], DI[60]);
	buf (DI_[61], DI[61]);
	buf (DI_[62], DI[62]);
	buf (DI_[63], DI[63]);
	buf (DI_[64], DI[64]);
	buf (DI_[65], DI[65]);
	buf (DI_[66], DI[66]);
	buf (DI_[67], DI[67]);
	buf (DI_[68], DI[68]);
	buf (DI_[69], DI[69]);
	buf (DI_[70], DI[70]);
	buf (DI_[71], DI[71]);
	buf (DI_[72], DI[72]);
	buf (DI_[73], DI[73]);
	buf (DI_[74], DI[74]);
	buf (DI_[75], DI[75]);
	buf (DI_[76], DI[76]);
	buf (DI_[77], DI[77]);
	buf (DI_[78], DI[78]);
	buf (DI_[79], DI[79]);
	buf (DI_[80], DI[80]);
	buf (DI_[81], DI[81]);
	buf (DI_[82], DI[82]);
	buf (DI_[83], DI[83]);
	buf (DI_[84], DI[84]);
	buf (DI_[85], DI[85]);
	buf (DI_[86], DI[86]);
	buf (DI_[87], DI[87]);
	buf (DI_[88], DI[88]);
	buf (DI_[89], DI[89]);
	buf (DI_[90], DI[90]);
	buf (DI_[91], DI[91]);
	buf (DI_[92], DI[92]);
	buf (DI_[93], DI[93]);
	buf (DI_[94], DI[94]);
	buf (DI_[95], DI[95]);
	buf (DI_[96], DI[96]);
	buf (DI_[97], DI[97]);
	buf (DI_[98], DI[98]);
	buf (DI_[99], DI[99]);
	buf (DI_[100], DI[100]);
	buf (DI_[101], DI[101]);
	buf (DI_[102], DI[102]);
	buf (DI_[103], DI[103]);
	buf (DI_[104], DI[104]);
	buf (DI_[105], DI[105]);
	buf (DI_[106], DI[106]);
	buf (DI_[107], DI[107]);
	buf (DI_[108], DI[108]);
	buf (DI_[109], DI[109]);
	buf (DI_[110], DI[110]);
	buf (DI_[111], DI[111]);
	buf (DI_[112], DI[112]);
	buf (DI_[113], DI[113]);
	buf (DI_[114], DI[114]);
	buf (DI_[115], DI[115]);
	buf (DI_[116], DI[116]);
	buf (DI_[117], DI[117]);
	buf (DI_[118], DI[118]);
	buf (DI_[119], DI[119]);
	buf (DI_[120], DI[120]);
	buf (DI_[121], DI[121]);
	buf (DI_[122], DI[122]);
	buf (DI_[123], DI[123]);
	buf (DI_[124], DI[124]);
	buf (DI_[125], DI[125]);
	buf (DI_[126], DI[126]);
	buf (DI_[127], DI[127]);
	buf (DOUT[0], DOUT_[0]);
	buf (DOUT[1], DOUT_[1]);
	buf (DOUT[2], DOUT_[2]);
	buf (DOUT[3], DOUT_[3]);
	buf (DOUT[4], DOUT_[4]);
	buf (DOUT[5], DOUT_[5]);
	buf (DOUT[6], DOUT_[6]);
	buf (DOUT[7], DOUT_[7]);
	buf (DOUT[8], DOUT_[8]);
	buf (DOUT[9], DOUT_[9]);
	buf (DOUT[10], DOUT_[10]);
	buf (DOUT[11], DOUT_[11]);
	buf (DOUT[12], DOUT_[12]);
	buf (DOUT[13], DOUT_[13]);
	buf (DOUT[14], DOUT_[14]);
	buf (DOUT[15], DOUT_[15]);
	buf (DOUT[16], DOUT_[16]);
	buf (DOUT[17], DOUT_[17]);
	buf (DOUT[18], DOUT_[18]);
	buf (DOUT[19], DOUT_[19]);
	buf (DOUT[20], DOUT_[20]);
	buf (DOUT[21], DOUT_[21]);
	buf (DOUT[22], DOUT_[22]);
	buf (DOUT[23], DOUT_[23]);
	buf (DOUT[24], DOUT_[24]);
	buf (DOUT[25], DOUT_[25]);
	buf (DOUT[26], DOUT_[26]);
	buf (DOUT[27], DOUT_[27]);
	buf (DOUT[28], DOUT_[28]);
	buf (DOUT[29], DOUT_[29]);
	buf (DOUT[30], DOUT_[30]);
	buf (DOUT[31], DOUT_[31]);
	buf (DOUT[32], DOUT_[32]);
	buf (DOUT[33], DOUT_[33]);
	buf (DOUT[34], DOUT_[34]);
	buf (DOUT[35], DOUT_[35]);
	buf (DOUT[36], DOUT_[36]);
	buf (DOUT[37], DOUT_[37]);
	buf (DOUT[38], DOUT_[38]);
	buf (DOUT[39], DOUT_[39]);
	buf (DOUT[40], DOUT_[40]);
	buf (DOUT[41], DOUT_[41]);
	buf (DOUT[42], DOUT_[42]);
	buf (DOUT[43], DOUT_[43]);
	buf (DOUT[44], DOUT_[44]);
	buf (DOUT[45], DOUT_[45]);
	buf (DOUT[46], DOUT_[46]);
	buf (DOUT[47], DOUT_[47]);
	buf (DOUT[48], DOUT_[48]);
	buf (DOUT[49], DOUT_[49]);
	buf (DOUT[50], DOUT_[50]);
	buf (DOUT[51], DOUT_[51]);
	buf (DOUT[52], DOUT_[52]);
	buf (DOUT[53], DOUT_[53]);
	buf (DOUT[54], DOUT_[54]);
	buf (DOUT[55], DOUT_[55]);
	buf (DOUT[56], DOUT_[56]);
	buf (DOUT[57], DOUT_[57]);
	buf (DOUT[58], DOUT_[58]);
	buf (DOUT[59], DOUT_[59]);
	buf (DOUT[60], DOUT_[60]);
	buf (DOUT[61], DOUT_[61]);
	buf (DOUT[62], DOUT_[62]);
	buf (DOUT[63], DOUT_[63]);
	buf (DOUT[64], DOUT_[64]);
	buf (DOUT[65], DOUT_[65]);
	buf (DOUT[66], DOUT_[66]);
	buf (DOUT[67], DOUT_[67]);
	buf (DOUT[68], DOUT_[68]);
	buf (DOUT[69], DOUT_[69]);
	buf (DOUT[70], DOUT_[70]);
	buf (DOUT[71], DOUT_[71]);
	buf (DOUT[72], DOUT_[72]);
	buf (DOUT[73], DOUT_[73]);
	buf (DOUT[74], DOUT_[74]);
	buf (DOUT[75], DOUT_[75]);
	buf (DOUT[76], DOUT_[76]);
	buf (DOUT[77], DOUT_[77]);
	buf (DOUT[78], DOUT_[78]);
	buf (DOUT[79], DOUT_[79]);
	buf (DOUT[80], DOUT_[80]);
	buf (DOUT[81], DOUT_[81]);
	buf (DOUT[82], DOUT_[82]);
	buf (DOUT[83], DOUT_[83]);
	buf (DOUT[84], DOUT_[84]);
	buf (DOUT[85], DOUT_[85]);
	buf (DOUT[86], DOUT_[86]);
	buf (DOUT[87], DOUT_[87]);
	buf (DOUT[88], DOUT_[88]);
	buf (DOUT[89], DOUT_[89]);
	buf (DOUT[90], DOUT_[90]);
	buf (DOUT[91], DOUT_[91]);
	buf (DOUT[92], DOUT_[92]);
	buf (DOUT[93], DOUT_[93]);
	buf (DOUT[94], DOUT_[94]);
	buf (DOUT[95], DOUT_[95]);
	buf (DOUT[96], DOUT_[96]);
	buf (DOUT[97], DOUT_[97]);
	buf (DOUT[98], DOUT_[98]);
	buf (DOUT[99], DOUT_[99]);
	buf (DOUT[100], DOUT_[100]);
	buf (DOUT[101], DOUT_[101]);
	buf (DOUT[102], DOUT_[102]);
	buf (DOUT[103], DOUT_[103]);
	buf (DOUT[104], DOUT_[104]);
	buf (DOUT[105], DOUT_[105]);
	buf (DOUT[106], DOUT_[106]);
	buf (DOUT[107], DOUT_[107]);
	buf (DOUT[108], DOUT_[108]);
	buf (DOUT[109], DOUT_[109]);
	buf (DOUT[110], DOUT_[110]);
	buf (DOUT[111], DOUT_[111]);
	buf (DOUT[112], DOUT_[112]);
	buf (DOUT[113], DOUT_[113]);
	buf (DOUT[114], DOUT_[114]);
	buf (DOUT[115], DOUT_[115]);
	buf (DOUT[116], DOUT_[116]);
	buf (DOUT[117], DOUT_[117]);
	buf (DOUT[118], DOUT_[118]);
	buf (DOUT[119], DOUT_[119]);
	buf (DOUT[120], DOUT_[120]);
	buf (DOUT[121], DOUT_[121]);
	buf (DOUT[122], DOUT_[122]);
	buf (DOUT[123], DOUT_[123]);
	buf (DOUT[124], DOUT_[124]);
	buf (DOUT[125], DOUT_[125]);
	buf (DOUT[126], DOUT_[126]);
	buf (DOUT[127], DOUT_[127]);

	and (scan_sh, DFTRAM_, SE_);
	and (SO_D_L_reg, DOUT_int[63], scan_sh);
	and (SO_D_R_reg, DOUT_int[64], scan_sh);
	buf (SO_D_L, SO_D_L_);
	buf (SO_D_R, SO_D_R_);

// ------------------------------------------------------
//      The Functional Description 
// ------------------------------------------------------


	function poweraware;
		input vddce, vddpe, vsse;
		reg result_pwr_on;
	begin
		case ({vddce,vddpe,vsse})
			3'b110: result_pwr_on = 1'b1;
			default: begin
				result_pwr_on = 1'b0;
				XDOUT =1 ;
			end
		endcase
		poweraware = result_pwr_on;
	end
	endfunction

	wire poweron;
	assign poweron = poweraware(vddce_int,vddpe_int,vsse_int);
	reg T_check_violation;

`ifdef SAMSUNG_FAULT_MODELING
	ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128_error_injection u1(.Q_out(DOUT_err_inj), .Q_in(outreg), .CK(CK_), .A(A_int), .CSN(CSN_int), .DFTRAM(DFTRAM_int), .SE(SE_int), .WEN(WEN_int), .CRE1(CRE1_int), .FCA1(FCA1_int), .CRE2(CRE2_int), .FCA2(FCA2_int));
	assign DOUT_data_path = DOUT_err_inj;
`else
	assign DOUT_data_path = outreg;
`endif

	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ0 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(SI_D_L_), .DI(DI_[0]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[0]), .XDOUT(XDOUT), .DOUT(DOUT_int[0]), .BWEN(BWEN_[0]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ1 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[0]), .DI(DI_[1]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[1]), .XDOUT(XDOUT), .DOUT(DOUT_int[1]), .BWEN(BWEN_[1]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ2 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[1]), .DI(DI_[2]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[2]), .XDOUT(XDOUT), .DOUT(DOUT_int[2]), .BWEN(BWEN_[2]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ3 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[2]), .DI(DI_[3]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[3]), .XDOUT(XDOUT), .DOUT(DOUT_int[3]), .BWEN(BWEN_[3]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ4 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[3]), .DI(DI_[4]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[4]), .XDOUT(XDOUT), .DOUT(DOUT_int[4]), .BWEN(BWEN_[4]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ5 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[4]), .DI(DI_[5]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[5]), .XDOUT(XDOUT), .DOUT(DOUT_int[5]), .BWEN(BWEN_[5]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ6 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[5]), .DI(DI_[6]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[6]), .XDOUT(XDOUT), .DOUT(DOUT_int[6]), .BWEN(BWEN_[6]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ7 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[6]), .DI(DI_[7]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[7]), .XDOUT(XDOUT), .DOUT(DOUT_int[7]), .BWEN(BWEN_[7]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ8 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[7]), .DI(DI_[8]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[8]), .XDOUT(XDOUT), .DOUT(DOUT_int[8]), .BWEN(BWEN_[8]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ9 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[8]), .DI(DI_[9]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[9]), .XDOUT(XDOUT), .DOUT(DOUT_int[9]), .BWEN(BWEN_[9]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ10 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[9]), .DI(DI_[10]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[10]), .XDOUT(XDOUT), .DOUT(DOUT_int[10]), .BWEN(BWEN_[10]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ11 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[10]), .DI(DI_[11]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[11]), .XDOUT(XDOUT), .DOUT(DOUT_int[11]), .BWEN(BWEN_[11]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ12 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[11]), .DI(DI_[12]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[12]), .XDOUT(XDOUT), .DOUT(DOUT_int[12]), .BWEN(BWEN_[12]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ13 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[12]), .DI(DI_[13]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[13]), .XDOUT(XDOUT), .DOUT(DOUT_int[13]), .BWEN(BWEN_[13]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ14 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[13]), .DI(DI_[14]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[14]), .XDOUT(XDOUT), .DOUT(DOUT_int[14]), .BWEN(BWEN_[14]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ15 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[14]), .DI(DI_[15]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[15]), .XDOUT(XDOUT), .DOUT(DOUT_int[15]), .BWEN(BWEN_[15]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ16 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[15]), .DI(DI_[16]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[16]), .XDOUT(XDOUT), .DOUT(DOUT_int[16]), .BWEN(BWEN_[16]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ17 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[16]), .DI(DI_[17]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[17]), .XDOUT(XDOUT), .DOUT(DOUT_int[17]), .BWEN(BWEN_[17]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ18 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[17]), .DI(DI_[18]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[18]), .XDOUT(XDOUT), .DOUT(DOUT_int[18]), .BWEN(BWEN_[18]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ19 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[18]), .DI(DI_[19]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[19]), .XDOUT(XDOUT), .DOUT(DOUT_int[19]), .BWEN(BWEN_[19]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ20 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[19]), .DI(DI_[20]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[20]), .XDOUT(XDOUT), .DOUT(DOUT_int[20]), .BWEN(BWEN_[20]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ21 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[20]), .DI(DI_[21]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[21]), .XDOUT(XDOUT), .DOUT(DOUT_int[21]), .BWEN(BWEN_[21]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ22 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[21]), .DI(DI_[22]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[22]), .XDOUT(XDOUT), .DOUT(DOUT_int[22]), .BWEN(BWEN_[22]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ23 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[22]), .DI(DI_[23]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[23]), .XDOUT(XDOUT), .DOUT(DOUT_int[23]), .BWEN(BWEN_[23]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ24 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[23]), .DI(DI_[24]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[24]), .XDOUT(XDOUT), .DOUT(DOUT_int[24]), .BWEN(BWEN_[24]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ25 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[24]), .DI(DI_[25]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[25]), .XDOUT(XDOUT), .DOUT(DOUT_int[25]), .BWEN(BWEN_[25]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ26 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[25]), .DI(DI_[26]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[26]), .XDOUT(XDOUT), .DOUT(DOUT_int[26]), .BWEN(BWEN_[26]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ27 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[26]), .DI(DI_[27]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[27]), .XDOUT(XDOUT), .DOUT(DOUT_int[27]), .BWEN(BWEN_[27]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ28 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[27]), .DI(DI_[28]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[28]), .XDOUT(XDOUT), .DOUT(DOUT_int[28]), .BWEN(BWEN_[28]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ29 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[28]), .DI(DI_[29]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[29]), .XDOUT(XDOUT), .DOUT(DOUT_int[29]), .BWEN(BWEN_[29]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ30 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[29]), .DI(DI_[30]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[30]), .XDOUT(XDOUT), .DOUT(DOUT_int[30]), .BWEN(BWEN_[30]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ31 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[30]), .DI(DI_[31]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[31]), .XDOUT(XDOUT), .DOUT(DOUT_int[31]), .BWEN(BWEN_[31]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ32 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[31]), .DI(DI_[32]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[32]), .XDOUT(XDOUT), .DOUT(DOUT_int[32]), .BWEN(BWEN_[32]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ33 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[32]), .DI(DI_[33]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[33]), .XDOUT(XDOUT), .DOUT(DOUT_int[33]), .BWEN(BWEN_[33]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ34 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[33]), .DI(DI_[34]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[34]), .XDOUT(XDOUT), .DOUT(DOUT_int[34]), .BWEN(BWEN_[34]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ35 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[34]), .DI(DI_[35]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[35]), .XDOUT(XDOUT), .DOUT(DOUT_int[35]), .BWEN(BWEN_[35]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ36 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[35]), .DI(DI_[36]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[36]), .XDOUT(XDOUT), .DOUT(DOUT_int[36]), .BWEN(BWEN_[36]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ37 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[36]), .DI(DI_[37]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[37]), .XDOUT(XDOUT), .DOUT(DOUT_int[37]), .BWEN(BWEN_[37]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ38 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[37]), .DI(DI_[38]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[38]), .XDOUT(XDOUT), .DOUT(DOUT_int[38]), .BWEN(BWEN_[38]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ39 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[38]), .DI(DI_[39]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[39]), .XDOUT(XDOUT), .DOUT(DOUT_int[39]), .BWEN(BWEN_[39]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ40 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[39]), .DI(DI_[40]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[40]), .XDOUT(XDOUT), .DOUT(DOUT_int[40]), .BWEN(BWEN_[40]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ41 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[40]), .DI(DI_[41]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[41]), .XDOUT(XDOUT), .DOUT(DOUT_int[41]), .BWEN(BWEN_[41]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ42 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[41]), .DI(DI_[42]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[42]), .XDOUT(XDOUT), .DOUT(DOUT_int[42]), .BWEN(BWEN_[42]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ43 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[42]), .DI(DI_[43]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[43]), .XDOUT(XDOUT), .DOUT(DOUT_int[43]), .BWEN(BWEN_[43]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ44 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[43]), .DI(DI_[44]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[44]), .XDOUT(XDOUT), .DOUT(DOUT_int[44]), .BWEN(BWEN_[44]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ45 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[44]), .DI(DI_[45]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[45]), .XDOUT(XDOUT), .DOUT(DOUT_int[45]), .BWEN(BWEN_[45]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ46 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[45]), .DI(DI_[46]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[46]), .XDOUT(XDOUT), .DOUT(DOUT_int[46]), .BWEN(BWEN_[46]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ47 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[46]), .DI(DI_[47]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[47]), .XDOUT(XDOUT), .DOUT(DOUT_int[47]), .BWEN(BWEN_[47]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ48 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[47]), .DI(DI_[48]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[48]), .XDOUT(XDOUT), .DOUT(DOUT_int[48]), .BWEN(BWEN_[48]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ49 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[48]), .DI(DI_[49]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[49]), .XDOUT(XDOUT), .DOUT(DOUT_int[49]), .BWEN(BWEN_[49]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ50 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[49]), .DI(DI_[50]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[50]), .XDOUT(XDOUT), .DOUT(DOUT_int[50]), .BWEN(BWEN_[50]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ51 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[50]), .DI(DI_[51]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[51]), .XDOUT(XDOUT), .DOUT(DOUT_int[51]), .BWEN(BWEN_[51]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ52 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[51]), .DI(DI_[52]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[52]), .XDOUT(XDOUT), .DOUT(DOUT_int[52]), .BWEN(BWEN_[52]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ53 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[52]), .DI(DI_[53]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[53]), .XDOUT(XDOUT), .DOUT(DOUT_int[53]), .BWEN(BWEN_[53]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ54 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[53]), .DI(DI_[54]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[54]), .XDOUT(XDOUT), .DOUT(DOUT_int[54]), .BWEN(BWEN_[54]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ55 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[54]), .DI(DI_[55]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[55]), .XDOUT(XDOUT), .DOUT(DOUT_int[55]), .BWEN(BWEN_[55]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ56 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[55]), .DI(DI_[56]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[56]), .XDOUT(XDOUT), .DOUT(DOUT_int[56]), .BWEN(BWEN_[56]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ57 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[56]), .DI(DI_[57]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[57]), .XDOUT(XDOUT), .DOUT(DOUT_int[57]), .BWEN(BWEN_[57]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ58 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[57]), .DI(DI_[58]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[58]), .XDOUT(XDOUT), .DOUT(DOUT_int[58]), .BWEN(BWEN_[58]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ59 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[58]), .DI(DI_[59]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[59]), .XDOUT(XDOUT), .DOUT(DOUT_int[59]), .BWEN(BWEN_[59]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ60 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[59]), .DI(DI_[60]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[60]), .XDOUT(XDOUT), .DOUT(DOUT_int[60]), .BWEN(BWEN_[60]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ61 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[60]), .DI(DI_[61]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[61]), .XDOUT(XDOUT), .DOUT(DOUT_int[61]), .BWEN(BWEN_[61]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ62 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[61]), .DI(DI_[62]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[62]), .XDOUT(XDOUT), .DOUT(DOUT_int[62]), .BWEN(BWEN_[62]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ63 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[62]), .DI(DI_[63]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[63]), .XDOUT(XDOUT), .DOUT(DOUT_int[63]), .BWEN(BWEN_[63]));

	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ64 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[65]), .DI(DI_[64]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[64]), .XDOUT(XDOUT), .DOUT(DOUT_int[64]), .BWEN(BWEN_[64]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ65 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[66]), .DI(DI_[65]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[65]), .XDOUT(XDOUT), .DOUT(DOUT_int[65]), .BWEN(BWEN_[65]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ66 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[67]), .DI(DI_[66]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[66]), .XDOUT(XDOUT), .DOUT(DOUT_int[66]), .BWEN(BWEN_[66]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ67 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[68]), .DI(DI_[67]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[67]), .XDOUT(XDOUT), .DOUT(DOUT_int[67]), .BWEN(BWEN_[67]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ68 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[69]), .DI(DI_[68]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[68]), .XDOUT(XDOUT), .DOUT(DOUT_int[68]), .BWEN(BWEN_[68]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ69 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[70]), .DI(DI_[69]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[69]), .XDOUT(XDOUT), .DOUT(DOUT_int[69]), .BWEN(BWEN_[69]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ70 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[71]), .DI(DI_[70]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[70]), .XDOUT(XDOUT), .DOUT(DOUT_int[70]), .BWEN(BWEN_[70]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ71 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[72]), .DI(DI_[71]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[71]), .XDOUT(XDOUT), .DOUT(DOUT_int[71]), .BWEN(BWEN_[71]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ72 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[73]), .DI(DI_[72]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[72]), .XDOUT(XDOUT), .DOUT(DOUT_int[72]), .BWEN(BWEN_[72]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ73 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[74]), .DI(DI_[73]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[73]), .XDOUT(XDOUT), .DOUT(DOUT_int[73]), .BWEN(BWEN_[73]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ74 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[75]), .DI(DI_[74]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[74]), .XDOUT(XDOUT), .DOUT(DOUT_int[74]), .BWEN(BWEN_[74]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ75 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[76]), .DI(DI_[75]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[75]), .XDOUT(XDOUT), .DOUT(DOUT_int[75]), .BWEN(BWEN_[75]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ76 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[77]), .DI(DI_[76]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[76]), .XDOUT(XDOUT), .DOUT(DOUT_int[76]), .BWEN(BWEN_[76]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ77 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[78]), .DI(DI_[77]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[77]), .XDOUT(XDOUT), .DOUT(DOUT_int[77]), .BWEN(BWEN_[77]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ78 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[79]), .DI(DI_[78]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[78]), .XDOUT(XDOUT), .DOUT(DOUT_int[78]), .BWEN(BWEN_[78]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ79 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[80]), .DI(DI_[79]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[79]), .XDOUT(XDOUT), .DOUT(DOUT_int[79]), .BWEN(BWEN_[79]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ80 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[81]), .DI(DI_[80]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[80]), .XDOUT(XDOUT), .DOUT(DOUT_int[80]), .BWEN(BWEN_[80]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ81 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[82]), .DI(DI_[81]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[81]), .XDOUT(XDOUT), .DOUT(DOUT_int[81]), .BWEN(BWEN_[81]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ82 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[83]), .DI(DI_[82]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[82]), .XDOUT(XDOUT), .DOUT(DOUT_int[82]), .BWEN(BWEN_[82]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ83 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[84]), .DI(DI_[83]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[83]), .XDOUT(XDOUT), .DOUT(DOUT_int[83]), .BWEN(BWEN_[83]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ84 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[85]), .DI(DI_[84]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[84]), .XDOUT(XDOUT), .DOUT(DOUT_int[84]), .BWEN(BWEN_[84]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ85 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[86]), .DI(DI_[85]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[85]), .XDOUT(XDOUT), .DOUT(DOUT_int[85]), .BWEN(BWEN_[85]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ86 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[87]), .DI(DI_[86]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[86]), .XDOUT(XDOUT), .DOUT(DOUT_int[86]), .BWEN(BWEN_[86]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ87 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[88]), .DI(DI_[87]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[87]), .XDOUT(XDOUT), .DOUT(DOUT_int[87]), .BWEN(BWEN_[87]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ88 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[89]), .DI(DI_[88]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[88]), .XDOUT(XDOUT), .DOUT(DOUT_int[88]), .BWEN(BWEN_[88]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ89 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[90]), .DI(DI_[89]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[89]), .XDOUT(XDOUT), .DOUT(DOUT_int[89]), .BWEN(BWEN_[89]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ90 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[91]), .DI(DI_[90]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[90]), .XDOUT(XDOUT), .DOUT(DOUT_int[90]), .BWEN(BWEN_[90]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ91 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[92]), .DI(DI_[91]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[91]), .XDOUT(XDOUT), .DOUT(DOUT_int[91]), .BWEN(BWEN_[91]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ92 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[93]), .DI(DI_[92]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[92]), .XDOUT(XDOUT), .DOUT(DOUT_int[92]), .BWEN(BWEN_[92]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ93 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[94]), .DI(DI_[93]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[93]), .XDOUT(XDOUT), .DOUT(DOUT_int[93]), .BWEN(BWEN_[93]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ94 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[95]), .DI(DI_[94]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[94]), .XDOUT(XDOUT), .DOUT(DOUT_int[94]), .BWEN(BWEN_[94]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ95 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[96]), .DI(DI_[95]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[95]), .XDOUT(XDOUT), .DOUT(DOUT_int[95]), .BWEN(BWEN_[95]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ96 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[97]), .DI(DI_[96]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[96]), .XDOUT(XDOUT), .DOUT(DOUT_int[96]), .BWEN(BWEN_[96]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ97 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[98]), .DI(DI_[97]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[97]), .XDOUT(XDOUT), .DOUT(DOUT_int[97]), .BWEN(BWEN_[97]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ98 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[99]), .DI(DI_[98]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[98]), .XDOUT(XDOUT), .DOUT(DOUT_int[98]), .BWEN(BWEN_[98]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ99 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[100]), .DI(DI_[99]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[99]), .XDOUT(XDOUT), .DOUT(DOUT_int[99]), .BWEN(BWEN_[99]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ100 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[101]), .DI(DI_[100]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[100]), .XDOUT(XDOUT), .DOUT(DOUT_int[100]), .BWEN(BWEN_[100]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ101 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[102]), .DI(DI_[101]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[101]), .XDOUT(XDOUT), .DOUT(DOUT_int[101]), .BWEN(BWEN_[101]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ102 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[103]), .DI(DI_[102]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[102]), .XDOUT(XDOUT), .DOUT(DOUT_int[102]), .BWEN(BWEN_[102]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ103 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[104]), .DI(DI_[103]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[103]), .XDOUT(XDOUT), .DOUT(DOUT_int[103]), .BWEN(BWEN_[103]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ104 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[105]), .DI(DI_[104]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[104]), .XDOUT(XDOUT), .DOUT(DOUT_int[104]), .BWEN(BWEN_[104]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ105 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[106]), .DI(DI_[105]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[105]), .XDOUT(XDOUT), .DOUT(DOUT_int[105]), .BWEN(BWEN_[105]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ106 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[107]), .DI(DI_[106]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[106]), .XDOUT(XDOUT), .DOUT(DOUT_int[106]), .BWEN(BWEN_[106]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ107 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[108]), .DI(DI_[107]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[107]), .XDOUT(XDOUT), .DOUT(DOUT_int[107]), .BWEN(BWEN_[107]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ108 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[109]), .DI(DI_[108]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[108]), .XDOUT(XDOUT), .DOUT(DOUT_int[108]), .BWEN(BWEN_[108]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ109 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[110]), .DI(DI_[109]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[109]), .XDOUT(XDOUT), .DOUT(DOUT_int[109]), .BWEN(BWEN_[109]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ110 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[111]), .DI(DI_[110]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[110]), .XDOUT(XDOUT), .DOUT(DOUT_int[110]), .BWEN(BWEN_[110]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ111 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[112]), .DI(DI_[111]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[111]), .XDOUT(XDOUT), .DOUT(DOUT_int[111]), .BWEN(BWEN_[111]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ112 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[113]), .DI(DI_[112]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[112]), .XDOUT(XDOUT), .DOUT(DOUT_int[112]), .BWEN(BWEN_[112]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ113 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[114]), .DI(DI_[113]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[113]), .XDOUT(XDOUT), .DOUT(DOUT_int[113]), .BWEN(BWEN_[113]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ114 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[115]), .DI(DI_[114]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[114]), .XDOUT(XDOUT), .DOUT(DOUT_int[114]), .BWEN(BWEN_[114]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ115 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[116]), .DI(DI_[115]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[115]), .XDOUT(XDOUT), .DOUT(DOUT_int[115]), .BWEN(BWEN_[115]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ116 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[117]), .DI(DI_[116]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[116]), .XDOUT(XDOUT), .DOUT(DOUT_int[116]), .BWEN(BWEN_[116]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ117 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[118]), .DI(DI_[117]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[117]), .XDOUT(XDOUT), .DOUT(DOUT_int[117]), .BWEN(BWEN_[117]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ118 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[119]), .DI(DI_[118]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[118]), .XDOUT(XDOUT), .DOUT(DOUT_int[118]), .BWEN(BWEN_[118]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ119 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[120]), .DI(DI_[119]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[119]), .XDOUT(XDOUT), .DOUT(DOUT_int[119]), .BWEN(BWEN_[119]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ120 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[121]), .DI(DI_[120]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[120]), .XDOUT(XDOUT), .DOUT(DOUT_int[120]), .BWEN(BWEN_[120]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ121 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[122]), .DI(DI_[121]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[121]), .XDOUT(XDOUT), .DOUT(DOUT_int[121]), .BWEN(BWEN_[121]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ122 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[123]), .DI(DI_[122]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[122]), .XDOUT(XDOUT), .DOUT(DOUT_int[122]), .BWEN(BWEN_[122]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ123 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[124]), .DI(DI_[123]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[123]), .XDOUT(XDOUT), .DOUT(DOUT_int[123]), .BWEN(BWEN_[123]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ124 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[125]), .DI(DI_[124]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[124]), .XDOUT(XDOUT), .DOUT(DOUT_int[124]), .BWEN(BWEN_[124]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ125 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[126]), .DI(DI_[125]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[125]), .XDOUT(XDOUT), .DOUT(DOUT_int[125]), .BWEN(BWEN_[125]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ126 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(DOUT_int[127]), .DI(DI_[126]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[126]), .XDOUT(XDOUT), .DOUT(DOUT_int[126]), .BWEN(BWEN_[126]));
	datapath_latch_ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 uDQ127 (.CK(CK), .DOUT_update(DOUT_update), .SE(SE_), .SI(SI_D_R_), .DI(DI_[127]), .DFTRAM(DFTRAM_), .mem_path(DOUT_data_path[127]), .XDOUT(XDOUT), .DOUT(DOUT_int[127]), .BWEN(BWEN_[127]));

`ifdef SEC_FUNCTIONAL_MODE
	assign #`D_MEM_DELAY DOUT_ = poweron === 1'b1 ? (RET_ === 1'bx ? {BITS{1'bx}} : DOUT_int) : {BITS{1'bx}};
	assign #`D_MEM_DELAY SO_D_L_ = poweron === 1'b1 ? (RET_ === 1'bx ? 1'bx : (T_check_violation === 1'b1 ? 1'bx : SO_D_L_reg)) : 1'bx;
	assign #`D_MEM_DELAY SO_D_R_ = poweron === 1'b1 ? (RET_ === 1'bx ? 1'bx : (T_check_violation === 1'b1 ? 1'bx : SO_D_R_reg)) : 1'bx;
`else
	assign DOUT_ = poweron === 1'b1 ? (RET_ === 1'bx ? {BITS{1'bx}} : DOUT_int) : {BITS{1'bx}};
	assign SO_D_L_ = poweron === 1'b1 ? (RET_ === 1'bx ? 1'bx : (T_check_violation === 1'b1 ? 1'bx : SO_D_L_reg)) : 1'bx;
	assign SO_D_R_ = poweron === 1'b1 ? (RET_ === 1'bx ? 1'bx : (T_check_violation === 1'b1 ? 1'bx : SO_D_R_reg)) : 1'bx;
`endif

	always @ (CRE1_ or DFTRAM_ or CK_) begin
		CRE1_int = CRE1_ & !DFTRAM_;
	end
	always @ (CRE2_ or DFTRAM_ or CK_) begin
		CRE2_int = CRE2_ & !DFTRAM_;
	end
	always @ (CRE1_int or FCA1_) begin
		if (CRE1_int === 1'b1) begin
			if (FCA1_ > 31) begin
				if (DISPLAY_CNTRL == 0) begin
					$display("Warning: Illegal value for FCA1 %b", FCA1_);
				end
			end
		`ifndef CR_CHECK_OFF
			write_out_x_R;
			write_out_x_L;
		`endif
		end
	end
	always @ (CRE2_int or FCA2_) begin
		if (CRE2_int === 1'b1) begin
			if (FCA2_ > 31) begin
				if (DISPLAY_CNTRL == 0) begin
					$display("Warning: Illegal value for FCA2 %b", FCA2_);
				end
			end
		`ifndef CR_CHECK_OFF
			write_out_x_R;
			write_out_x_L;
		`endif
		end
	end
`ifndef CR_CHECK_OFF
	always @ (CRE1_ or CRE2_) begin
		if (DFTRAM_int !== 1'b1 ) begin
			write_out_x_R;
			write_out_x_L;
		end
	end
	always @ (DFTRAM_) begin
		if (CRE1_=== 1'b1 || CRE2_ === 1'b1) begin
			write_out_x_R;
			write_out_x_L;
		end
	end
`endif


	always @ (RET_) begin
		if (RET_ === 1'bx) begin
			write_out_x;
			failedWrite;
		end else begin
			NONPG_RET_1: assert(RET_ === 1'b0) begin
			end else begin
				if ($time > `SEC_LPV_STARTTIME) begin
					if (DISPLAY_CNTRL == 0) begin
						$error("Error: Invalid mode, retention is not support(RET=%b) in %m at %0t", RET_, $time);
					end
					failedWrite;
					write_out_x;
				end
			end
		end
		T_check_violation = 0;
	end

	always @ (CK_) begin
`ifdef POWER_PINS
		CLOCK_TOGGLES_VDDE: assert(vddpe_int === 1'b1 || vddpe_int === 1'b0) else begin
			if (DISPLAY_CNTRL == 0) begin
				$error("Error: Unknown value for VDDE %b in %m at %0t", vddpe_int, $time);
			end
		end
		CLOCK_TOGGLES_VSSE: assert(vsse_int === 1'b1 || vsse_int === 1'b0) else begin
			if (DISPLAY_CNTRL == 0) begin
				$error("Error: Unknown value for VSSE %b in %m at %0t", vsse_int, $time);
			end
		end
`endif
		NONPG_RET_0: assert(RET_ === 1'b0 || RET_ === 1'bx) else begin
			if ($time > `SEC_LPV_STARTTIME) begin
				if (DISPLAY_CNTRL == 0) begin
					$error("Error: Invalid mode, retention is not support(RET=%b) in %m at %0t", RET_, $time);
				end
				failedWrite;
				write_out_x;
			end
		end
		if (RET_ === 1'bx) begin
			failedWrite;
			XDOUT = 1'b1; #0 DOUT_update = 1'b1;
		end else if (RET_ === 1'b0) begin //normal
			if (CK_ === 1'bx) begin
				failedWrite;
				XDOUT = 1'b1; #0 DOUT_update = 1'b1;
			end else if ((CK_ === 1'b1 || CK_ === 1'b0) && LAST_CK === 1'bx) begin
				XDOUT = 1'b0; #0 DOUT_update = 1'b0;
			end else if (CK_ === 1'b1 && LAST_CK === 1'b0) begin
				// assign
				DFTRAM_int = DFTRAM_; 
				SE_int = SE_;
				//MCS
				MCS_int = MCS_;
				MCSW_int = MCSW_;
				FCA1_int = FCA1_;
				FCA2_int = FCA2_;
				RET_int = RET_;
				CSN_int = CSN_;
				WEN_int = WEN_;
				A_int = A_;
				DI_int = DI_;
				BWEN_int = BWEN_;

				if (poweron === 1'b1) begin
					if (DFTRAM_=== 1'b1 && SE_ === 1'b1) begin //scan shift 
						XDOUT = 1'b0; #0 DOUT_update = 1'b1; 
					end else if (DFTRAM_=== 1'b1 && SE_ === 1'b0) begin // scan capture 
						XDOUT = 1'b0; #0 DOUT_update = 1'b1; 
					end else begin //normal
						READnWRITE;
					end
					T_check_violation = 0;
				end
				//
			end else if (CK_ === 1'b0 && LAST_CK === 1'b1) begin
				XDOUT = 1'b0; #0 DOUT_update = 1'b0; 
			end
		end
		LAST_CK = CK_;
	end

// ------------------------------------------------------
//            tasks and functions  
// ------------------------------------------------------

	task READnWRITE;
	begin
		if (RET_ === 1'b0) begin
			if (DFTRAM_int === 1'bx) begin
				failedWrite;
				write_out_x;
			end else if (DFTRAM_int === 1'b1) begin //scan
				if (isBitX(SE_int)) begin
					write_out_x;
				end
			end else begin // DFTRAM=0;
				if (CSN_int === 1'bx || CSN_int === 1'bz) begin
					failedWrite;
					write_out_x;
					x_war_message("CSN");
				end else if (CSN_int === 1'b1) begin
					//standby mode
				end else if (CSN_int == 1'b0) begin
					if ( isBitX(^MCS_int) || isBitX(MCSW_int) ) begin
						write_out_x;
						failedWrite;
					end else if ( isBitX(CRE1_int) ) begin
						write_out_x;
						failedWrite;
						x_war_message("CRE1");
					end else if ( isBitX(CRE2_int) ) begin
						write_out_x;
						failedWrite;
						x_war_message("CRE2");
					end else if ( isBitX(^FCA1_int) && CRE1_int === 1'b1 ) begin
						write_out_x;
						failedWrite;
					end else if ( isBitX(^FCA2_int) && CRE2_int === 1'b1 ) begin
						write_out_x;
						failedWrite;
					end else if ( isBitX(WEN_int) ) begin
						write_out_x;
						write_A_x;
					end else if (WEN_int === 1'b0) begin //write
						if ( isBitX(^ADME_) ) begin
							write_out_x;
							failedWrite;
						end else if ( (^A_int) === 1'bx && CSN_int === 1'b0 ) begin
							failedWrite;
						end else if ( A_int >= WORDS && CSN_int === 1'b0 ) begin
							XDOUT = 1'b0; #0 DOUT_update = 1'b0; 
						end else begin
							Write(DI_int,BWEN_int,A_int);
						end
					end else if (WEN_int === 1'b1) begin //read
						if ( isBitX(^ADME_) ) begin
							write_out_x;
							failedWrite;
						end else if ( (^A_int) === 1'bx && CSN_int === 1'b0 ) begin
							failedWrite;
							write_out_x;
						end else if ( A_int >= WORDS && CSN_int === 1'b0 ) begin
							XDOUT = 1'b1; #0 DOUT_update = 1'b1;
						end else begin
							Read(A_int,outreg);
							XDOUT = 1'b0; #0 DOUT_update = 1'b1; 
						end
					end
				end // CSN=0;
			end // DFTRAM=0;
		end // PDE or RET=0;
	end
	endtask

	function void Write;
		input [BITS-1:0] data;
		input [BITS-1:0] bwen;
		input [addr_width-1:0] address;
		integer mux_address;
		integer row_address;
		integer row_red_address;
	begin
		mux_address = get_mux_address(address);
		row_address = get_row_address(address);
		row_red_address = get_row_red_address(address);
		row = mem[row_address];
		rowL = row[(BITS*mux-1)+r_bit*2 : (128 + r_bit)];
		rowR = row[128-1 + r_bit:0];

		//left
		if (CRE1_int === 1'b1 && FCA1_int < 32) begin
			k=0;
			for(i=0;i<128; i=i+1) begin
				j=i>>2;
				if (j<FCA1_int) begin
					rowLL[i] = rowL[k];
					k=k+1;
				end
				else if (j===FCA1_int) begin
					rowLL[i] = rowL[k];
					k=k+1;
				end
				else if (j>FCA1_int) begin
					rowLL[i] = rowL[k+r_bit];
					k=k+1;
				end
			end
		end
		else if (CRE1_int === 1'b1 && FCA1_int >= 32) begin
			rowLL[128-1:0] = rowL[128-1+r_bit:r_bit];
		end
		else if (CRE1_int === 1'b0) begin
			rowLL[128-1:0] = rowL[128-1+r_bit:r_bit];
		end

		for(i=0; i<64; i=i+1) begin
			remained_data_L[64-1-i] = rowLL[i*mux + mux_address];
		end

		new_data_L = (((data[64-1:0] | bwen[64-1:0] ) & ~bwen[64-1:0]) | ((remained_data_L[64-1:0] | ~bwen[64-1:0]) & bwen[64-1:0]));

		for(i=0; i<64; i=i+1) begin
			rowLL[i*mux + mux_address] = new_data_L[64-1-i];
		end

		if (CRE1_int === 1'b1 && FCA1_int < 32) begin
			k=0;
			for(i=0;i<128; i=i+1) begin
				j=i>>2;
				if (j<FCA1_int) begin
					rowL[k] = rowLL[i];
					k=k+1;
				end
				else if (j===FCA1_int) begin
					rowL[k] = rowLL[i];
					k=k+1;
				end
				else if (j>FCA1_int) begin
					rowL[k+r_bit] = rowLL[i];
					k=k+1;
				end
			end
		end
		else if (CRE1_int === 1'b1 && FCA1_int >= 32) begin
			rowL[128-1+r_bit:r_bit] = rowLL[128-1:0];
		end
		else if (CRE1_int === 1'b0) begin
			rowL[128-1+r_bit:r_bit] = rowLL[128-1:0];
		end

		//right
		if (CRE2_int === 1'b1 && FCA2_int < 32) begin
			k=0;
			for(i=0; i<128; i=i+1) begin
				j = i >> 2;
				h = (128-1>>2)-j;
				if ( h > FCA2_int ) begin
					rowRR[i] = rowR[k];
					k=k+1;
				end
				else if (h === FCA2_int) begin
					rowRR[i] = rowR[k+r_bit];
					k=k+1;
				end
				else if (h < FCA2_int) begin
					rowRR[i] = rowR[k+r_bit];
					k=k+1;
				end
			end
		end
		else if (CRE2_int === 1'b1 && FCA2_int >= 32) begin
			rowRR[128-1:0] = rowR[128-1:0];
		end
		else if (CRE2_int === 1'b0) begin
			rowRR[128-1:0] = rowR[128-1:0];
		end

		for(i=64;i<BITS; i=i+1) begin
			remained_data_R[i-64] = rowRR[128-1 - (i-64)*mux - mux_address];
		end

		new_data_R = (((data[BITS-1:64] | bwen[BITS-1:64] ) & ~bwen[BITS-1:64]) | ((remained_data_R[64-1:0] | ~bwen[BITS-1:64]) & bwen[BITS-1:64]));

		for(i=64; i<BITS; i=i+1) begin
			rowRR[128-1 - (i-64)*mux - mux_address] = new_data_R[i-64];
		end

		if (CRE2_int === 1'b1 && FCA2_int < 32) begin
			k=0;
			for(i=0; i<128; i=i+1) begin
				j = i >> 2;
				h = (128-1>>2)-j;
				if ( h > FCA2_int ) begin
					rowR[k] = rowRR[i];
					k=k+1;
				end
				else if (h === FCA2_int) begin
					rowR[k+r_bit] = rowRR[i];
					k=k+1;
				end
				else if (h < FCA2_int) begin
					rowR[k+r_bit] = rowRR[i];
					k=k+1;
				end
			end
		end
		else if (CRE2_int === 1'b1 && FCA2_int >= 32) begin
			rowR[128-1:0] = rowRR[128-1:0];
		end
		else if (CRE2_int === 1'b0) begin
			rowR[128-1:0] = rowRR[128-1:0];
		end

		row[128-1+r_bit : 0] = rowR[128-1+r_bit : 0];
		row[(BITS*mux)-1+r_bit*2 : 128+r_bit] = rowL[128-1+r_bit : 0];
		mem[row_address] = row;
	end
	endfunction

	function void Read;
		input [addr_width-1:0] address;
		output [BITS-1:0] data_out;
		integer mux_address;
		integer row_address;
		integer row_red_address;
	begin
		mux_address = get_mux_address(address);
		row_address = get_row_address(address);
		row_red_address = get_row_red_address(address);
		row = mem[row_address];
		rowL = row[(BITS*mux-1)+r_bit*2 : (128 + r_bit)];
		rowR = row[128-1 + r_bit:0];

		//left
		if (CRE1_int === 1'b1 && FCA1_int < 32) begin
			k=0;
			for(i=0;i<128; i=i+1) begin
				j=i>>2;
				if (j<FCA1_int) begin
					rowLL[i] = rowL[k];
					k=k+1;
				end
				else if (j===FCA1_int) begin
					rowLL[i] = rowL[k];
					k=k+1;
				end
				else if (j>FCA1_int) begin
					rowLL[i] = rowL[k+r_bit];
					k=k+1;
				end
			end
		end
		else if (CRE1_int === 1'b1 && FCA1_int >= 32) begin
			rowLL[128-1:0] = rowL[128-1+r_bit:r_bit];
		end
		else if (CRE1_int === 1'b0) begin
			rowLL[128-1:0] = rowL[128-1+r_bit:r_bit];
		end

		//right
		if (CRE2_int === 1'b1 && FCA2_int < 32) begin
			k=0;
			for(i=0; i<128; i=i+1) begin
				j = i >> 2;
				h = (128-1>>2)-j;
				if ( h > FCA2_int ) begin
					rowRR[i] = rowR[k];
					k=k+1;
				end
				else if (h === FCA2_int) begin
					rowRR[i] = rowR[k+r_bit];
					k=k+1;
				end
				else if (h < FCA2_int) begin
					rowRR[i] = rowR[k+r_bit];
					k=k+1;
				end
			end
		end
		else if (CRE2_int === 1'b1 && FCA2_int >= 32) begin
			rowRR[128-1:0] = rowR[128-1:0];
		end
		else if (CRE2_int === 1'b0) begin
			rowRR[128-1:0] = rowR[128-1:0];
		end

		for(i=0; i<64; i=i+1) begin
			outreg_tmp[64-1-i] = rowLL[i*mux + mux_address];
		end
		for(i=64;i<BITS; i=i+1) begin
			outreg_tmp[i] = rowRR[128-1 - (i-64)*mux - mux_address];
		end
		data_out = outreg_tmp;
	end
	endfunction

	task write_out_low;
	begin
		outreg = word0;
	end
	endtask

	task write_out_high;
	begin
		outreg = word1;
	end
	endtask

	task write_out_x;
	begin
		XDOUT=1'b1; #0 DOUT_update=1'b1;
	end
	endtask

	task write_sout_x;
	begin
		T_check_violation = 1'b1;
	end
	endtask

	task write_out_x_R;
	begin
		uDQ64.DOUT<=1'bx;
		uDQ65.DOUT<=1'bx;
		uDQ66.DOUT<=1'bx;
		uDQ67.DOUT<=1'bx;
		uDQ68.DOUT<=1'bx;
		uDQ69.DOUT<=1'bx;
		uDQ70.DOUT<=1'bx;
		uDQ71.DOUT<=1'bx;
		uDQ72.DOUT<=1'bx;
		uDQ73.DOUT<=1'bx;
		uDQ74.DOUT<=1'bx;
		uDQ75.DOUT<=1'bx;
		uDQ76.DOUT<=1'bx;
		uDQ77.DOUT<=1'bx;
		uDQ78.DOUT<=1'bx;
		uDQ79.DOUT<=1'bx;
		uDQ80.DOUT<=1'bx;
		uDQ81.DOUT<=1'bx;
		uDQ82.DOUT<=1'bx;
		uDQ83.DOUT<=1'bx;
		uDQ84.DOUT<=1'bx;
		uDQ85.DOUT<=1'bx;
		uDQ86.DOUT<=1'bx;
		uDQ87.DOUT<=1'bx;
		uDQ88.DOUT<=1'bx;
		uDQ89.DOUT<=1'bx;
		uDQ90.DOUT<=1'bx;
		uDQ91.DOUT<=1'bx;
		uDQ92.DOUT<=1'bx;
		uDQ93.DOUT<=1'bx;
		uDQ94.DOUT<=1'bx;
		uDQ95.DOUT<=1'bx;
		uDQ96.DOUT<=1'bx;
		uDQ97.DOUT<=1'bx;
		uDQ98.DOUT<=1'bx;
		uDQ99.DOUT<=1'bx;
		uDQ100.DOUT<=1'bx;
		uDQ101.DOUT<=1'bx;
		uDQ102.DOUT<=1'bx;
		uDQ103.DOUT<=1'bx;
		uDQ104.DOUT<=1'bx;
		uDQ105.DOUT<=1'bx;
		uDQ106.DOUT<=1'bx;
		uDQ107.DOUT<=1'bx;
		uDQ108.DOUT<=1'bx;
		uDQ109.DOUT<=1'bx;
		uDQ110.DOUT<=1'bx;
		uDQ111.DOUT<=1'bx;
		uDQ112.DOUT<=1'bx;
		uDQ113.DOUT<=1'bx;
		uDQ114.DOUT<=1'bx;
		uDQ115.DOUT<=1'bx;
		uDQ116.DOUT<=1'bx;
		uDQ117.DOUT<=1'bx;
		uDQ118.DOUT<=1'bx;
		uDQ119.DOUT<=1'bx;
		uDQ120.DOUT<=1'bx;
		uDQ121.DOUT<=1'bx;
		uDQ122.DOUT<=1'bx;
		uDQ123.DOUT<=1'bx;
		uDQ124.DOUT<=1'bx;
		uDQ125.DOUT<=1'bx;
		uDQ126.DOUT<=1'bx;
		uDQ127.DOUT<=1'bx;
	end
	endtask

	task write_out_x_L;
	begin
		uDQ0.DOUT<=1'bx;
		uDQ1.DOUT<=1'bx;
		uDQ2.DOUT<=1'bx;
		uDQ3.DOUT<=1'bx;
		uDQ4.DOUT<=1'bx;
		uDQ5.DOUT<=1'bx;
		uDQ6.DOUT<=1'bx;
		uDQ7.DOUT<=1'bx;
		uDQ8.DOUT<=1'bx;
		uDQ9.DOUT<=1'bx;
		uDQ10.DOUT<=1'bx;
		uDQ11.DOUT<=1'bx;
		uDQ12.DOUT<=1'bx;
		uDQ13.DOUT<=1'bx;
		uDQ14.DOUT<=1'bx;
		uDQ15.DOUT<=1'bx;
		uDQ16.DOUT<=1'bx;
		uDQ17.DOUT<=1'bx;
		uDQ18.DOUT<=1'bx;
		uDQ19.DOUT<=1'bx;
		uDQ20.DOUT<=1'bx;
		uDQ21.DOUT<=1'bx;
		uDQ22.DOUT<=1'bx;
		uDQ23.DOUT<=1'bx;
		uDQ24.DOUT<=1'bx;
		uDQ25.DOUT<=1'bx;
		uDQ26.DOUT<=1'bx;
		uDQ27.DOUT<=1'bx;
		uDQ28.DOUT<=1'bx;
		uDQ29.DOUT<=1'bx;
		uDQ30.DOUT<=1'bx;
		uDQ31.DOUT<=1'bx;
		uDQ32.DOUT<=1'bx;
		uDQ33.DOUT<=1'bx;
		uDQ34.DOUT<=1'bx;
		uDQ35.DOUT<=1'bx;
		uDQ36.DOUT<=1'bx;
		uDQ37.DOUT<=1'bx;
		uDQ38.DOUT<=1'bx;
		uDQ39.DOUT<=1'bx;
		uDQ40.DOUT<=1'bx;
		uDQ41.DOUT<=1'bx;
		uDQ42.DOUT<=1'bx;
		uDQ43.DOUT<=1'bx;
		uDQ44.DOUT<=1'bx;
		uDQ45.DOUT<=1'bx;
		uDQ46.DOUT<=1'bx;
		uDQ47.DOUT<=1'bx;
		uDQ48.DOUT<=1'bx;
		uDQ49.DOUT<=1'bx;
		uDQ50.DOUT<=1'bx;
		uDQ51.DOUT<=1'bx;
		uDQ52.DOUT<=1'bx;
		uDQ53.DOUT<=1'bx;
		uDQ54.DOUT<=1'bx;
		uDQ55.DOUT<=1'bx;
		uDQ56.DOUT<=1'bx;
		uDQ57.DOUT<=1'bx;
		uDQ58.DOUT<=1'bx;
		uDQ59.DOUT<=1'bx;
		uDQ60.DOUT<=1'bx;
		uDQ61.DOUT<=1'bx;
		uDQ62.DOUT<=1'bx;
		uDQ63.DOUT<=1'bx;
	end
	endtask

	task write_A_x;
	begin
		if (^A_int === 1'bx) begin
			failedWrite;
		end
		else begin
			Write(wordx,BWEN_int,A_int);
		end
	end
	endtask

	task failedWrite;
		integer i;
	begin
		for (i=0; i<WORDS/mux; i=i+1)
			mem[i] = rowx;
	end
	endtask

	task write_BWEN_x;
		input integer fail_bit;
	begin
		if (^A_int === 1'bx) begin
			failedWrite;
		end else begin
			BWEN_int[fail_bit]=1'bx;
			Write(DI_int,BWEN_int,A_int);
		end
	end
	endtask

	function isBitX;
		input bitval;
	begin
		isBitX = (bitval===1'bx || bitval===1'bz) ? 1'b1 : 1'b0;
	end
	endfunction

	function isBit1;
		input bitval;
	begin
		isBit1 = (bitval===1'b1) ? 1'b1 : 1'b0;
	end
	endfunction

	function void write_mem;
		input [addr_width-1:0] addr_mem;
		input [BITS-1:0] mem_word;
	begin
		CRE1_int = CRE1_ & !DFTRAM_;
		CRE2_int = CRE2_ & !DFTRAM_;
		FCA1_int = FCA1_;
		FCA2_int = FCA2_;
		if (BACKDOOR_DISPLAY_CNTRL == 0) begin
			$display("data_loading addr: %0x Data : %0x",addr_mem,mem_word);
		end
		Write(mem_word,word0,addr_mem);
	end
	endfunction

	function void read_mem;
		input [addr_width-1:0] addr_mem;
		output [BITS-1:0] data_out;
	begin
		CRE1_int = CRE1_ & !DFTRAM_;
		CRE2_int = CRE2_ & !DFTRAM_;
		FCA1_int = FCA1_;
		FCA2_int = FCA2_;
		Read(addr_mem,outreg_backdoor);
		data_out = outreg_backdoor;
		if (BACKDOOR_DISPLAY_CNTRL == 0) begin
			$display("data_reading addr: %0x Data : %0x",addr_mem,outreg_backdoor);
		end
	end
	endfunction

	function void load_mem;
		input [1000*8-1:0] filename;
		reg[BITS-1:0] mem_array [0:WORDS-1];
		reg[BITS-1:0] mem_word;
		integer adr_cnt;
	begin
		$readmemh(filename, mem_array);
		CRE1_int = CRE1_ & !DFTRAM_;
		CRE2_int = CRE2_ & !DFTRAM_;
		FCA1_int = FCA1_;
		FCA2_int = FCA2_;

		for( adr_cnt = 0; adr_cnt < WORDS ; adr_cnt = adr_cnt + 1) begin
			mem_word = mem_array[adr_cnt];
			if (BACKDOOR_DISPLAY_CNTRL == 0) begin
				$display("data_loading addr: %0x Data : %0x",adr_cnt,mem_word);
			end
			Write(mem_word,word0,adr_cnt);
		end
	end
	endfunction

	function void dump_mem;
		input [1000*8-1:0] filename_dump;
		integer adr_cnt, tmp_dump_file;
	begin
		tmp_dump_file = $fopen(filename_dump);
		for( adr_cnt = 0; adr_cnt < WORDS ; adr_cnt = adr_cnt + 1) begin
			Read(adr_cnt,outreg_backdoor);
			$fdisplay(tmp_dump_file, "%h", outreg_backdoor);
		end
		$fclose(tmp_dump_file);
	end
	endfunction

	function void x_war_message;
		input [255:0] signal;
	begin
		IMPT_SIGNAL_X: assert (0) else begin
			if (DISPLAY_CNTRL == 0 && $time != 0) begin
				$error("%0t Error : Invalid value on memory instance %m:: %0s", $time, signal);
			end
		end
	end
	endfunction

	function integer get_mux_address;
		input [addr_width-1:0] Address;
	begin
		return Address[0:0];
	end
	endfunction

	function integer get_row_address;
		input [addr_width-1:0] Address;
	begin
		return Address[addr_width-1:1];
	end
	endfunction

	function integer get_row_red_address;
		input [addr_width-1:0] Address;
	begin
		return Address[2:1];
	end
	endfunction

`ifdef POWER_PINS
	always @ (vddce_int or vddpe_int or vsse_int) begin
		if ($time > `SEC_LPV_STARTTIME) begin
			PG_OFF_VSS: assert (vsse_int === 1'b0) else begin
				if (DISPLAY_CNTRL == 0) begin
					$error("Error: Forbidden state for VSSE %b in %m at %0t", vsse_int, $time);
				end
				failedWrite;
				write_out_x;
			end
			if (vddce_int !== 1'b1) begin
				failedWrite;
				write_out_x;
			end
		end
	end
`endif

//Timing violation reaction
	always @(NOT_CK_A) begin
		failedWrite;
		write_out_x;
	end
	always @(NOT_CK_CRE) begin
		failedWrite;
		write_out_x;
	end
	always @(NOT_CK_FCA) begin
		failedWrite;
		write_out_x;
	end
	always @(NOT_CK_CSN) begin
		failedWrite;
		write_out_x;
	end
	always @(NOT_CK_DI_0) begin
		if (DFTRAM_ && !SE_) begin
			uDQ0.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_1) begin
		if (DFTRAM_ && !SE_) begin
			uDQ1.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_2) begin
		if (DFTRAM_ && !SE_) begin
			uDQ2.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_3) begin
		if (DFTRAM_ && !SE_) begin
			uDQ3.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_4) begin
		if (DFTRAM_ && !SE_) begin
			uDQ4.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_5) begin
		if (DFTRAM_ && !SE_) begin
			uDQ5.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_6) begin
		if (DFTRAM_ && !SE_) begin
			uDQ6.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_7) begin
		if (DFTRAM_ && !SE_) begin
			uDQ7.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_8) begin
		if (DFTRAM_ && !SE_) begin
			uDQ8.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_9) begin
		if (DFTRAM_ && !SE_) begin
			uDQ9.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_10) begin
		if (DFTRAM_ && !SE_) begin
			uDQ10.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_11) begin
		if (DFTRAM_ && !SE_) begin
			uDQ11.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_12) begin
		if (DFTRAM_ && !SE_) begin
			uDQ12.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_13) begin
		if (DFTRAM_ && !SE_) begin
			uDQ13.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_14) begin
		if (DFTRAM_ && !SE_) begin
			uDQ14.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_15) begin
		if (DFTRAM_ && !SE_) begin
			uDQ15.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_16) begin
		if (DFTRAM_ && !SE_) begin
			uDQ16.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_17) begin
		if (DFTRAM_ && !SE_) begin
			uDQ17.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_18) begin
		if (DFTRAM_ && !SE_) begin
			uDQ18.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_19) begin
		if (DFTRAM_ && !SE_) begin
			uDQ19.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_20) begin
		if (DFTRAM_ && !SE_) begin
			uDQ20.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_21) begin
		if (DFTRAM_ && !SE_) begin
			uDQ21.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_22) begin
		if (DFTRAM_ && !SE_) begin
			uDQ22.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_23) begin
		if (DFTRAM_ && !SE_) begin
			uDQ23.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_24) begin
		if (DFTRAM_ && !SE_) begin
			uDQ24.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_25) begin
		if (DFTRAM_ && !SE_) begin
			uDQ25.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_26) begin
		if (DFTRAM_ && !SE_) begin
			uDQ26.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_27) begin
		if (DFTRAM_ && !SE_) begin
			uDQ27.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_28) begin
		if (DFTRAM_ && !SE_) begin
			uDQ28.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_29) begin
		if (DFTRAM_ && !SE_) begin
			uDQ29.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_30) begin
		if (DFTRAM_ && !SE_) begin
			uDQ30.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_31) begin
		if (DFTRAM_ && !SE_) begin
			uDQ31.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_32) begin
		if (DFTRAM_ && !SE_) begin
			uDQ32.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_33) begin
		if (DFTRAM_ && !SE_) begin
			uDQ33.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_34) begin
		if (DFTRAM_ && !SE_) begin
			uDQ34.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_35) begin
		if (DFTRAM_ && !SE_) begin
			uDQ35.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_36) begin
		if (DFTRAM_ && !SE_) begin
			uDQ36.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_37) begin
		if (DFTRAM_ && !SE_) begin
			uDQ37.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_38) begin
		if (DFTRAM_ && !SE_) begin
			uDQ38.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_39) begin
		if (DFTRAM_ && !SE_) begin
			uDQ39.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_40) begin
		if (DFTRAM_ && !SE_) begin
			uDQ40.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_41) begin
		if (DFTRAM_ && !SE_) begin
			uDQ41.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_42) begin
		if (DFTRAM_ && !SE_) begin
			uDQ42.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_43) begin
		if (DFTRAM_ && !SE_) begin
			uDQ43.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_44) begin
		if (DFTRAM_ && !SE_) begin
			uDQ44.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_45) begin
		if (DFTRAM_ && !SE_) begin
			uDQ45.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_46) begin
		if (DFTRAM_ && !SE_) begin
			uDQ46.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_47) begin
		if (DFTRAM_ && !SE_) begin
			uDQ47.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_48) begin
		if (DFTRAM_ && !SE_) begin
			uDQ48.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_49) begin
		if (DFTRAM_ && !SE_) begin
			uDQ49.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_50) begin
		if (DFTRAM_ && !SE_) begin
			uDQ50.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_51) begin
		if (DFTRAM_ && !SE_) begin
			uDQ51.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_52) begin
		if (DFTRAM_ && !SE_) begin
			uDQ52.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_53) begin
		if (DFTRAM_ && !SE_) begin
			uDQ53.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_54) begin
		if (DFTRAM_ && !SE_) begin
			uDQ54.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_55) begin
		if (DFTRAM_ && !SE_) begin
			uDQ55.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_56) begin
		if (DFTRAM_ && !SE_) begin
			uDQ56.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_57) begin
		if (DFTRAM_ && !SE_) begin
			uDQ57.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_58) begin
		if (DFTRAM_ && !SE_) begin
			uDQ58.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_59) begin
		if (DFTRAM_ && !SE_) begin
			uDQ59.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_60) begin
		if (DFTRAM_ && !SE_) begin
			uDQ60.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_61) begin
		if (DFTRAM_ && !SE_) begin
			uDQ61.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_62) begin
		if (DFTRAM_ && !SE_) begin
			uDQ62.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_63) begin
		if (DFTRAM_ && !SE_) begin
			uDQ63.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_64) begin
		if (DFTRAM_ && !SE_) begin
			uDQ64.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_65) begin
		if (DFTRAM_ && !SE_) begin
			uDQ65.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_66) begin
		if (DFTRAM_ && !SE_) begin
			uDQ66.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_67) begin
		if (DFTRAM_ && !SE_) begin
			uDQ67.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_68) begin
		if (DFTRAM_ && !SE_) begin
			uDQ68.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_69) begin
		if (DFTRAM_ && !SE_) begin
			uDQ69.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_70) begin
		if (DFTRAM_ && !SE_) begin
			uDQ70.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_71) begin
		if (DFTRAM_ && !SE_) begin
			uDQ71.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_72) begin
		if (DFTRAM_ && !SE_) begin
			uDQ72.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_73) begin
		if (DFTRAM_ && !SE_) begin
			uDQ73.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_74) begin
		if (DFTRAM_ && !SE_) begin
			uDQ74.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_75) begin
		if (DFTRAM_ && !SE_) begin
			uDQ75.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_76) begin
		if (DFTRAM_ && !SE_) begin
			uDQ76.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_77) begin
		if (DFTRAM_ && !SE_) begin
			uDQ77.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_78) begin
		if (DFTRAM_ && !SE_) begin
			uDQ78.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_79) begin
		if (DFTRAM_ && !SE_) begin
			uDQ79.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_80) begin
		if (DFTRAM_ && !SE_) begin
			uDQ80.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_81) begin
		if (DFTRAM_ && !SE_) begin
			uDQ81.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_82) begin
		if (DFTRAM_ && !SE_) begin
			uDQ82.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_83) begin
		if (DFTRAM_ && !SE_) begin
			uDQ83.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_84) begin
		if (DFTRAM_ && !SE_) begin
			uDQ84.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_85) begin
		if (DFTRAM_ && !SE_) begin
			uDQ85.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_86) begin
		if (DFTRAM_ && !SE_) begin
			uDQ86.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_87) begin
		if (DFTRAM_ && !SE_) begin
			uDQ87.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_88) begin
		if (DFTRAM_ && !SE_) begin
			uDQ88.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_89) begin
		if (DFTRAM_ && !SE_) begin
			uDQ89.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_90) begin
		if (DFTRAM_ && !SE_) begin
			uDQ90.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_91) begin
		if (DFTRAM_ && !SE_) begin
			uDQ91.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_92) begin
		if (DFTRAM_ && !SE_) begin
			uDQ92.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_93) begin
		if (DFTRAM_ && !SE_) begin
			uDQ93.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_94) begin
		if (DFTRAM_ && !SE_) begin
			uDQ94.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_95) begin
		if (DFTRAM_ && !SE_) begin
			uDQ95.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_96) begin
		if (DFTRAM_ && !SE_) begin
			uDQ96.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_97) begin
		if (DFTRAM_ && !SE_) begin
			uDQ97.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_98) begin
		if (DFTRAM_ && !SE_) begin
			uDQ98.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_99) begin
		if (DFTRAM_ && !SE_) begin
			uDQ99.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_100) begin
		if (DFTRAM_ && !SE_) begin
			uDQ100.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_101) begin
		if (DFTRAM_ && !SE_) begin
			uDQ101.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_102) begin
		if (DFTRAM_ && !SE_) begin
			uDQ102.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_103) begin
		if (DFTRAM_ && !SE_) begin
			uDQ103.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_104) begin
		if (DFTRAM_ && !SE_) begin
			uDQ104.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_105) begin
		if (DFTRAM_ && !SE_) begin
			uDQ105.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_106) begin
		if (DFTRAM_ && !SE_) begin
			uDQ106.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_107) begin
		if (DFTRAM_ && !SE_) begin
			uDQ107.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_108) begin
		if (DFTRAM_ && !SE_) begin
			uDQ108.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_109) begin
		if (DFTRAM_ && !SE_) begin
			uDQ109.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_110) begin
		if (DFTRAM_ && !SE_) begin
			uDQ110.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_111) begin
		if (DFTRAM_ && !SE_) begin
			uDQ111.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_112) begin
		if (DFTRAM_ && !SE_) begin
			uDQ112.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_113) begin
		if (DFTRAM_ && !SE_) begin
			uDQ113.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_114) begin
		if (DFTRAM_ && !SE_) begin
			uDQ114.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_115) begin
		if (DFTRAM_ && !SE_) begin
			uDQ115.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_116) begin
		if (DFTRAM_ && !SE_) begin
			uDQ116.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_117) begin
		if (DFTRAM_ && !SE_) begin
			uDQ117.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_118) begin
		if (DFTRAM_ && !SE_) begin
			uDQ118.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_119) begin
		if (DFTRAM_ && !SE_) begin
			uDQ119.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_120) begin
		if (DFTRAM_ && !SE_) begin
			uDQ120.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_121) begin
		if (DFTRAM_ && !SE_) begin
			uDQ121.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_122) begin
		if (DFTRAM_ && !SE_) begin
			uDQ122.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_123) begin
		if (DFTRAM_ && !SE_) begin
			uDQ123.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_124) begin
		if (DFTRAM_ && !SE_) begin
			uDQ124.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_125) begin
		if (DFTRAM_ && !SE_) begin
			uDQ125.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_126) begin
		if (DFTRAM_ && !SE_) begin
			uDQ126.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_DI_127) begin
		if (DFTRAM_ && !SE_) begin
			uDQ127.DOUT<=1'bx;
		end else begin
			if (WEN_int) begin
				//no opertion
			end else begin
				write_A_x;
			end
		end
	end
	always @(NOT_CK_MCS) begin
		if (!DFTRAM_) begin
			failedWrite;
		end
		write_out_x;
	end
	always @(NOT_CK_MCSW) begin
		if (!DFTRAM_) begin
			failedWrite;
		end
		write_out_x;
	end
	always @(NOT_CK_DFTRAM) begin
		failedWrite;
		write_out_x;
	end
	always @(NOT_CK_WEN) begin
		failedWrite;
		write_out_x;
	end
	always @(NOT_RET_CSN) begin
		failedWrite;
		write_out_x;
	end
	always @(NOT_CSN_RET) begin
		failedWrite;
		write_out_x;
	end
	always @(NOT_DFTRAM_RET) begin
		failedWrite;
		write_out_x;
	end
	always @(NOT_RET_DFTRAM) begin
		failedWrite;
		write_out_x;
	end
	always @(NOT_CK_ADME) begin
		failedWrite;
		write_out_x;
	end
	always @(NOT_CK_SI_D_L) begin
		write_out_x_L;
	end
	always @(NOT_CK_SI_D_R) begin
		write_out_x_R;
	end
	always @(NOT_CK_SE) begin
		write_out_x;
		write_sout_x;
	end
	always @(NOT_CK_MINH) begin
		failedWrite;
		write_out_x;
	end
	always @(NOT_CK_MINL) begin
		failedWrite;
		write_out_x;
	end
	always @(NOT_CK_PER) begin
		failedWrite;
		write_out_x;
	end

`ifdef SEC_FUNCTIONAL_MODE
`else
// C1_R_R0
//
// bussed mode
//

wire RETeq0 ;
wire RETeq0aDFTRAMeq0 ;
wire RETeq0aDFTRAMeq0aCSNeq0 ;
wire RETeq0aDFTRAMeq0aCSNeq0aCRE1eq1 ;
wire RETeq0aDFTRAMeq0aCSNeq0aCRE2eq1 ;
wire RETeq0aDFTRAMeq1 ;
wire RETeq0aDFTRAMeq1aSEeq1 ;
wire RETeq0aopDFTRAMeq0aCSNeq0cp ;
wire RETeq0aopDFTRAMeq1oopDFTRAMeq0aCSNeq0cpcp ;
wire RETeq0aopDFTRAMeq1oopDFTRAMeq0aCSNeq0cpcpaMCS1eq0aMCS0eq0aMCSWeq0aADME2eq1aADME1eq0aADME0eq0 ;
wire RETeq0aopDFTRAMeq1oopDFTRAMeq0aCSNeq0cpcpaMCS1eq0aMCS0eq0aMCSWeq1aADME2eq1aADME1eq0aADME0eq0 ;
wire RETeq0aopDFTRAMeq1oopDFTRAMeq0aCSNeq0cpcpaMCS1eq0aMCS0eq1aMCSWeq0aADME2eq1aADME1eq0aADME0eq0 ;
wire RETeq0aopDFTRAMeq1oopDFTRAMeq0aCSNeq0cpcpaMCS1eq0aMCS0eq1aMCSWeq1aADME2eq1aADME1eq0aADME0eq0 ;
wire RETeq0aopDFTRAMeq1oopDFTRAMeq0aCSNeq0cpcpaMCS1eq1aMCS0eq0aMCSWeq0aADME2eq1aADME1eq0aADME0eq0 ;
wire RETeq0aopDFTRAMeq1oopDFTRAMeq0aCSNeq0cpcpaMCS1eq1aMCS0eq0aMCSWeq1aADME2eq1aADME1eq0aADME0eq0 ;
wire RETeq0aopDFTRAMeq1oopDFTRAMeq0aCSNeq0cpcpaMCS1eq1aMCS0eq1aMCSWeq0aADME2eq1aADME1eq0aADME0eq0 ;
wire RETeq0aopDFTRAMeq1oopDFTRAMeq0aCSNeq0cpcpaMCS1eq1aMCS0eq1aMCSWeq1aADME2eq1aADME1eq0aADME0eq0 ;
wire RETeq0aopDFTRAMeq1oopDFTRAMeq0aCSNeq0cpcpaopopADME2eq0aADME1eq0aADME0eq0cpoopADME2eq0aADME1eq0aADME0eq1cpoopADME2eq0aADME1eq1aADME0eq0cpoopADME2eq0aADME1eq1aADME0eq1cpoopADME2eq1aADME1eq0aADME0eq1cpoopADME2eq1aADME1eq1aADME0eq0cpoopADME2eq1aADME1eq1aADME0eq1cpcp ;
wire RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp ;

assign RETeq0 = (!RET) ? 1'b1:1'b0;
assign RETeq0aDFTRAMeq0 = (!RET&!DFTRAM) ? 1'b1:1'b0;
assign RETeq0aDFTRAMeq0aCSNeq0 = (!RET&!DFTRAM&!CSN) ? 1'b1:1'b0;
assign RETeq0aDFTRAMeq0aCSNeq0aCRE1eq1 = (!RET&!DFTRAM&!CSN&CRE1) ? 1'b1:1'b0;
assign RETeq0aDFTRAMeq0aCSNeq0aCRE2eq1 = (!RET&!DFTRAM&!CSN&CRE2) ? 1'b1:1'b0;
assign RETeq0aDFTRAMeq1 = (!RET&DFTRAM) ? 1'b1:1'b0;
assign RETeq0aDFTRAMeq1aSEeq1 = (!RET&DFTRAM&SE) ? 1'b1:1'b0;
assign RETeq0aopDFTRAMeq0aCSNeq0cp = (!RET&(!DFTRAM&!CSN)) ? 1'b1:1'b0;
assign RETeq0aopDFTRAMeq1oopDFTRAMeq0aCSNeq0cpcp = (!RET&(DFTRAM|(!DFTRAM&!CSN))) ? 1'b1:1'b0;
assign RETeq0aopDFTRAMeq1oopDFTRAMeq0aCSNeq0cpcpaMCS1eq0aMCS0eq0aMCSWeq0aADME2eq1aADME1eq0aADME0eq0 = (!RET&(DFTRAM|(!DFTRAM&!CSN))&!MCS[1]&!MCS[0]&!MCSW&ADME[2]&!ADME[1]&!ADME[0]) ? 1'b1:1'b0;
assign RETeq0aopDFTRAMeq1oopDFTRAMeq0aCSNeq0cpcpaMCS1eq0aMCS0eq0aMCSWeq1aADME2eq1aADME1eq0aADME0eq0 = (!RET&(DFTRAM|(!DFTRAM&!CSN))&!MCS[1]&!MCS[0]&MCSW&ADME[2]&!ADME[1]&!ADME[0]) ? 1'b1:1'b0;
assign RETeq0aopDFTRAMeq1oopDFTRAMeq0aCSNeq0cpcpaMCS1eq0aMCS0eq1aMCSWeq0aADME2eq1aADME1eq0aADME0eq0 = (!RET&(DFTRAM|(!DFTRAM&!CSN))&!MCS[1]&MCS[0]&!MCSW&ADME[2]&!ADME[1]&!ADME[0]) ? 1'b1:1'b0;
assign RETeq0aopDFTRAMeq1oopDFTRAMeq0aCSNeq0cpcpaMCS1eq0aMCS0eq1aMCSWeq1aADME2eq1aADME1eq0aADME0eq0 = (!RET&(DFTRAM|(!DFTRAM&!CSN))&!MCS[1]&MCS[0]&MCSW&ADME[2]&!ADME[1]&!ADME[0]) ? 1'b1:1'b0;
assign RETeq0aopDFTRAMeq1oopDFTRAMeq0aCSNeq0cpcpaMCS1eq1aMCS0eq0aMCSWeq0aADME2eq1aADME1eq0aADME0eq0 = (!RET&(DFTRAM|(!DFTRAM&!CSN))&MCS[1]&!MCS[0]&!MCSW&ADME[2]&!ADME[1]&!ADME[0]) ? 1'b1:1'b0;
assign RETeq0aopDFTRAMeq1oopDFTRAMeq0aCSNeq0cpcpaMCS1eq1aMCS0eq0aMCSWeq1aADME2eq1aADME1eq0aADME0eq0 = (!RET&(DFTRAM|(!DFTRAM&!CSN))&MCS[1]&!MCS[0]&MCSW&ADME[2]&!ADME[1]&!ADME[0]) ? 1'b1:1'b0;
assign RETeq0aopDFTRAMeq1oopDFTRAMeq0aCSNeq0cpcpaMCS1eq1aMCS0eq1aMCSWeq0aADME2eq1aADME1eq0aADME0eq0 = (!RET&(DFTRAM|(!DFTRAM&!CSN))&MCS[1]&MCS[0]&!MCSW&ADME[2]&!ADME[1]&!ADME[0]) ? 1'b1:1'b0;
assign RETeq0aopDFTRAMeq1oopDFTRAMeq0aCSNeq0cpcpaMCS1eq1aMCS0eq1aMCSWeq1aADME2eq1aADME1eq0aADME0eq0 = (!RET&(DFTRAM|(!DFTRAM&!CSN))&MCS[1]&MCS[0]&MCSW&ADME[2]&!ADME[1]&!ADME[0]) ? 1'b1:1'b0;
assign RETeq0aopDFTRAMeq1oopDFTRAMeq0aCSNeq0cpcpaopopADME2eq0aADME1eq0aADME0eq0cpoopADME2eq0aADME1eq0aADME0eq1cpoopADME2eq0aADME1eq1aADME0eq0cpoopADME2eq0aADME1eq1aADME0eq1cpoopADME2eq1aADME1eq0aADME0eq1cpoopADME2eq1aADME1eq1aADME0eq0cpoopADME2eq1aADME1eq1aADME0eq1cpcp = (!RET&(DFTRAM|(!DFTRAM&!CSN))&((!ADME[2]&!ADME[1]&!ADME[0])|(!ADME[2]&!ADME[1]&ADME[0])|(!ADME[2]&ADME[1]&!ADME[0])|(!ADME[2]&ADME[1]&ADME[0])|(ADME[2]&!ADME[1]&ADME[0])|(ADME[2]&ADME[1]&!ADME[0])|(ADME[2]&ADME[1]&ADME[0]))) ? 1'b1:1'b0;
assign RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp = (!RET&((DFTRAM&!SE)|(!DFTRAM&!CSN&!WEN))) ? 1'b1:1'b0;

specify
$width(negedge CK &&& RETeq0aopDFTRAMeq1oopDFTRAMeq0aCSNeq0cpcp, `D_MEM_WIDTH_L, `D_MEM_WIDTH_THD, NOT_CK_MINL);
$width(posedge CK &&& RETeq0aopDFTRAMeq1oopDFTRAMeq0aCSNeq0cpcp, `D_MEM_WIDTH_H, `D_MEM_WIDTH_THD, NOT_CK_MINH);

$period(negedge CK &&& RETeq0aopDFTRAMeq1oopDFTRAMeq0aCSNeq0cpcpaMCS1eq0aMCS0eq0aMCSWeq0aADME2eq1aADME1eq0aADME0eq0, `D_MEM_PERIOD, NOT_CK_PER);
$period(negedge CK &&& RETeq0aopDFTRAMeq1oopDFTRAMeq0aCSNeq0cpcpaMCS1eq0aMCS0eq0aMCSWeq1aADME2eq1aADME1eq0aADME0eq0, `D_MEM_PERIOD, NOT_CK_PER);
$period(negedge CK &&& RETeq0aopDFTRAMeq1oopDFTRAMeq0aCSNeq0cpcpaMCS1eq0aMCS0eq1aMCSWeq0aADME2eq1aADME1eq0aADME0eq0, `D_MEM_PERIOD, NOT_CK_PER);
$period(negedge CK &&& RETeq0aopDFTRAMeq1oopDFTRAMeq0aCSNeq0cpcpaMCS1eq0aMCS0eq1aMCSWeq1aADME2eq1aADME1eq0aADME0eq0, `D_MEM_PERIOD, NOT_CK_PER);
$period(negedge CK &&& RETeq0aopDFTRAMeq1oopDFTRAMeq0aCSNeq0cpcpaMCS1eq1aMCS0eq0aMCSWeq0aADME2eq1aADME1eq0aADME0eq0, `D_MEM_PERIOD, NOT_CK_PER);
$period(negedge CK &&& RETeq0aopDFTRAMeq1oopDFTRAMeq0aCSNeq0cpcpaMCS1eq1aMCS0eq0aMCSWeq1aADME2eq1aADME1eq0aADME0eq0, `D_MEM_PERIOD, NOT_CK_PER);
$period(negedge CK &&& RETeq0aopDFTRAMeq1oopDFTRAMeq0aCSNeq0cpcpaMCS1eq1aMCS0eq1aMCSWeq0aADME2eq1aADME1eq0aADME0eq0, `D_MEM_PERIOD, NOT_CK_PER);
$period(negedge CK &&& RETeq0aopDFTRAMeq1oopDFTRAMeq0aCSNeq0cpcpaMCS1eq1aMCS0eq1aMCSWeq1aADME2eq1aADME1eq0aADME0eq0, `D_MEM_PERIOD, NOT_CK_PER);
$period(negedge CK &&& RETeq0aopDFTRAMeq1oopDFTRAMeq0aCSNeq0cpcpaopopADME2eq0aADME1eq0aADME0eq0cpoopADME2eq0aADME1eq0aADME0eq1cpoopADME2eq0aADME1eq1aADME0eq0cpoopADME2eq0aADME1eq1aADME0eq1cpoopADME2eq1aADME1eq0aADME0eq1cpoopADME2eq1aADME1eq1aADME0eq0cpoopADME2eq1aADME1eq1aADME0eq1cpcp, `D_MEM_PERIOD, NOT_CK_PER);
$period(posedge CK &&& RETeq0aopDFTRAMeq1oopDFTRAMeq0aCSNeq0cpcpaMCS1eq0aMCS0eq0aMCSWeq0aADME2eq1aADME1eq0aADME0eq0, `D_MEM_PERIOD, NOT_CK_PER);
$period(posedge CK &&& RETeq0aopDFTRAMeq1oopDFTRAMeq0aCSNeq0cpcpaMCS1eq0aMCS0eq0aMCSWeq1aADME2eq1aADME1eq0aADME0eq0, `D_MEM_PERIOD, NOT_CK_PER);
$period(posedge CK &&& RETeq0aopDFTRAMeq1oopDFTRAMeq0aCSNeq0cpcpaMCS1eq0aMCS0eq1aMCSWeq0aADME2eq1aADME1eq0aADME0eq0, `D_MEM_PERIOD, NOT_CK_PER);
$period(posedge CK &&& RETeq0aopDFTRAMeq1oopDFTRAMeq0aCSNeq0cpcpaMCS1eq0aMCS0eq1aMCSWeq1aADME2eq1aADME1eq0aADME0eq0, `D_MEM_PERIOD, NOT_CK_PER);
$period(posedge CK &&& RETeq0aopDFTRAMeq1oopDFTRAMeq0aCSNeq0cpcpaMCS1eq1aMCS0eq0aMCSWeq0aADME2eq1aADME1eq0aADME0eq0, `D_MEM_PERIOD, NOT_CK_PER);
$period(posedge CK &&& RETeq0aopDFTRAMeq1oopDFTRAMeq0aCSNeq0cpcpaMCS1eq1aMCS0eq0aMCSWeq1aADME2eq1aADME1eq0aADME0eq0, `D_MEM_PERIOD, NOT_CK_PER);
$period(posedge CK &&& RETeq0aopDFTRAMeq1oopDFTRAMeq0aCSNeq0cpcpaMCS1eq1aMCS0eq1aMCSWeq0aADME2eq1aADME1eq0aADME0eq0, `D_MEM_PERIOD, NOT_CK_PER);
$period(posedge CK &&& RETeq0aopDFTRAMeq1oopDFTRAMeq0aCSNeq0cpcpaMCS1eq1aMCS0eq1aMCSWeq1aADME2eq1aADME1eq0aADME0eq0, `D_MEM_PERIOD, NOT_CK_PER);
$period(posedge CK &&& RETeq0aopDFTRAMeq1oopDFTRAMeq0aCSNeq0cpcpaopopADME2eq0aADME1eq0aADME0eq0cpoopADME2eq0aADME1eq0aADME0eq1cpoopADME2eq0aADME1eq1aADME0eq0cpoopADME2eq0aADME1eq1aADME0eq1cpoopADME2eq1aADME1eq0aADME0eq1cpoopADME2eq1aADME1eq1aADME0eq0cpoopADME2eq1aADME1eq1aADME0eq1cpcp, `D_MEM_PERIOD, NOT_CK_PER);

$setuphold(posedge CK &&& (RETeq0aDFTRAMeq0aCSNeq0), negedge ADME[0], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_ADME);
$setuphold(posedge CK &&& (RETeq0aDFTRAMeq0aCSNeq0), negedge ADME[1], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_ADME);
$setuphold(posedge CK &&& (RETeq0aDFTRAMeq0aCSNeq0), negedge ADME[2], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_ADME);
$setuphold(posedge CK &&& (RETeq0aopDFTRAMeq0aCSNeq0cp), negedge A[0], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_A);
$setuphold(posedge CK &&& (RETeq0aopDFTRAMeq0aCSNeq0cp), negedge A[1], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_A);
$setuphold(posedge CK &&& (RETeq0aopDFTRAMeq0aCSNeq0cp), negedge A[2], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_A);
$setuphold(posedge CK &&& (RETeq0aopDFTRAMeq0aCSNeq0cp), negedge A[3], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_A);
$setuphold(posedge CK &&& (RETeq0aopDFTRAMeq0aCSNeq0cp), negedge A[4], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_A);
$setuphold(posedge CK &&& (RETeq0aopDFTRAMeq0aCSNeq0cp), negedge A[5], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_A);
$setuphold(posedge CK &&& (RETeq0aDFTRAMeq0aCSNeq0), negedge CRE1, `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_CRE);
$setuphold(posedge CK &&& (RETeq0aDFTRAMeq0aCSNeq0), negedge CRE2, `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_CRE);
$setuphold(negedge RET, negedge CSN, `D_MEM_SETUP, `D_MEM_HOLD, NOT_RET_CSN);
$setuphold(posedge CK &&& (RETeq0aDFTRAMeq0), negedge CSN, `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_CSN);
$setuphold(posedge RET, negedge CSN, `D_MEM_SETUP, `D_MEM_HOLD, NOT_RET_CSN);
$setuphold(negedge RET, negedge DFTRAM, `D_MEM_SETUP, `D_MEM_HOLD, NOT_RET_DFTRAM);
$setuphold(posedge CK &&& (RETeq0), negedge DFTRAM, `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DFTRAM);
$setuphold(posedge RET, negedge DFTRAM, `D_MEM_SETUP, `D_MEM_HOLD, NOT_RET_DFTRAM);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[0], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_0);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[1], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_1);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[2], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_2);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[3], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_3);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[4], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_4);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[5], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_5);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[6], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_6);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[7], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_7);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[8], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_8);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[9], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_9);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[10], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_10);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[11], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_11);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[12], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_12);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[13], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_13);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[14], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_14);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[15], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_15);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[16], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_16);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[17], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_17);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[18], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_18);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[19], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_19);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[20], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_20);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[21], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_21);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[22], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_22);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[23], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_23);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[24], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_24);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[25], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_25);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[26], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_26);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[27], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_27);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[28], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_28);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[29], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_29);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[30], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_30);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[31], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_31);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[32], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_32);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[33], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_33);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[34], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_34);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[35], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_35);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[36], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_36);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[37], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_37);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[38], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_38);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[39], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_39);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[40], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_40);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[41], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_41);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[42], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_42);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[43], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_43);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[44], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_44);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[45], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_45);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[46], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_46);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[47], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_47);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[48], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_48);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[49], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_49);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[50], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_50);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[51], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_51);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[52], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_52);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[53], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_53);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[54], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_54);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[55], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_55);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[56], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_56);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[57], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_57);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[58], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_58);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[59], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_59);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[60], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_60);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[61], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_61);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[62], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_62);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[63], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_63);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[64], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_64);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[65], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_65);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[66], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_66);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[67], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_67);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[68], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_68);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[69], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_69);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[70], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_70);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[71], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_71);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[72], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_72);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[73], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_73);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[74], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_74);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[75], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_75);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[76], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_76);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[77], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_77);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[78], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_78);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[79], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_79);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[80], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_80);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[81], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_81);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[82], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_82);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[83], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_83);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[84], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_84);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[85], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_85);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[86], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_86);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[87], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_87);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[88], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_88);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[89], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_89);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[90], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_90);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[91], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_91);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[92], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_92);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[93], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_93);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[94], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_94);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[95], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_95);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[96], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_96);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[97], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_97);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[98], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_98);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[99], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_99);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[100], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_100);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[101], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_101);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[102], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_102);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[103], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_103);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[104], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_104);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[105], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_105);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[106], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_106);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[107], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_107);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[108], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_108);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[109], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_109);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[110], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_110);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[111], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_111);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[112], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_112);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[113], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_113);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[114], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_114);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[115], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_115);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[116], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_116);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[117], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_117);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[118], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_118);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[119], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_119);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[120], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_120);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[121], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_121);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[122], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_122);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[123], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_123);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[124], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_124);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[125], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_125);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[126], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_126);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), negedge DI[127], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_127);
$setuphold(posedge CK &&& (RETeq0aDFTRAMeq0aCSNeq0aCRE1eq1), negedge FCA1[0], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_FCA);
$setuphold(posedge CK &&& (RETeq0aDFTRAMeq0aCSNeq0aCRE1eq1), negedge FCA1[1], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_FCA);
$setuphold(posedge CK &&& (RETeq0aDFTRAMeq0aCSNeq0aCRE1eq1), negedge FCA1[2], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_FCA);
$setuphold(posedge CK &&& (RETeq0aDFTRAMeq0aCSNeq0aCRE1eq1), negedge FCA1[3], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_FCA);
$setuphold(posedge CK &&& (RETeq0aDFTRAMeq0aCSNeq0aCRE1eq1), negedge FCA1[4], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_FCA);
$setuphold(posedge CK &&& (RETeq0aDFTRAMeq0aCSNeq0aCRE2eq1), negedge FCA2[0], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_FCA);
$setuphold(posedge CK &&& (RETeq0aDFTRAMeq0aCSNeq0aCRE2eq1), negedge FCA2[1], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_FCA);
$setuphold(posedge CK &&& (RETeq0aDFTRAMeq0aCSNeq0aCRE2eq1), negedge FCA2[2], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_FCA);
$setuphold(posedge CK &&& (RETeq0aDFTRAMeq0aCSNeq0aCRE2eq1), negedge FCA2[3], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_FCA);
$setuphold(posedge CK &&& (RETeq0aDFTRAMeq0aCSNeq0aCRE2eq1), negedge FCA2[4], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_FCA);
$setuphold(posedge CK &&& (RETeq0aDFTRAMeq0aCSNeq0), negedge MCSW, `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_MCSW);
$setuphold(posedge CK &&& (RETeq0aopDFTRAMeq1oopDFTRAMeq0aCSNeq0cpcp), negedge MCS[0], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_MCS);
$setuphold(posedge CK &&& (RETeq0aopDFTRAMeq1oopDFTRAMeq0aCSNeq0cpcp), negedge MCS[1], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_MCS);
$setuphold(posedge CK &&& (RETeq0aDFTRAMeq1), negedge SE, `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_SE);
$setuphold(posedge CK &&& (RETeq0aDFTRAMeq1aSEeq1), negedge SI_D_L, `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_SI_D_L);
$setuphold(posedge CK &&& (RETeq0aDFTRAMeq1aSEeq1), negedge SI_D_R, `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_SI_D_R);
$setuphold(posedge CK &&& (RETeq0aopDFTRAMeq0aCSNeq0cp), negedge WEN, `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_WEN);
$setuphold(posedge CK &&& (RETeq0aDFTRAMeq0aCSNeq0), posedge ADME[0], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_ADME);
$setuphold(posedge CK &&& (RETeq0aDFTRAMeq0aCSNeq0), posedge ADME[1], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_ADME);
$setuphold(posedge CK &&& (RETeq0aDFTRAMeq0aCSNeq0), posedge ADME[2], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_ADME);
$setuphold(posedge CK &&& (RETeq0aopDFTRAMeq0aCSNeq0cp), posedge A[0], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_A);
$setuphold(posedge CK &&& (RETeq0aopDFTRAMeq0aCSNeq0cp), posedge A[1], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_A);
$setuphold(posedge CK &&& (RETeq0aopDFTRAMeq0aCSNeq0cp), posedge A[2], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_A);
$setuphold(posedge CK &&& (RETeq0aopDFTRAMeq0aCSNeq0cp), posedge A[3], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_A);
$setuphold(posedge CK &&& (RETeq0aopDFTRAMeq0aCSNeq0cp), posedge A[4], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_A);
$setuphold(posedge CK &&& (RETeq0aopDFTRAMeq0aCSNeq0cp), posedge A[5], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_A);
$setuphold(posedge CK &&& (RETeq0aDFTRAMeq0aCSNeq0), posedge CRE1, `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_CRE);
$setuphold(posedge CK &&& (RETeq0aDFTRAMeq0aCSNeq0), posedge CRE2, `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_CRE);
$setuphold(negedge RET, posedge CSN, `D_MEM_SETUP, `D_MEM_HOLD, NOT_RET_CSN);
$setuphold(posedge CK &&& (RETeq0aDFTRAMeq0), posedge CSN, `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_CSN);
$setuphold(posedge RET, posedge CSN, `D_MEM_SETUP, `D_MEM_HOLD, NOT_RET_CSN);
$setuphold(negedge RET, posedge DFTRAM, `D_MEM_SETUP, `D_MEM_HOLD, NOT_RET_DFTRAM);
$setuphold(posedge CK &&& (RETeq0), posedge DFTRAM, `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DFTRAM);
$setuphold(posedge RET, posedge DFTRAM, `D_MEM_SETUP, `D_MEM_HOLD, NOT_RET_DFTRAM);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[0], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_0);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[1], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_1);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[2], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_2);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[3], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_3);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[4], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_4);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[5], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_5);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[6], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_6);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[7], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_7);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[8], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_8);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[9], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_9);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[10], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_10);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[11], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_11);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[12], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_12);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[13], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_13);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[14], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_14);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[15], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_15);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[16], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_16);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[17], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_17);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[18], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_18);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[19], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_19);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[20], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_20);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[21], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_21);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[22], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_22);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[23], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_23);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[24], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_24);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[25], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_25);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[26], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_26);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[27], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_27);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[28], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_28);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[29], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_29);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[30], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_30);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[31], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_31);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[32], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_32);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[33], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_33);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[34], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_34);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[35], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_35);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[36], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_36);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[37], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_37);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[38], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_38);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[39], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_39);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[40], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_40);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[41], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_41);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[42], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_42);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[43], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_43);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[44], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_44);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[45], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_45);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[46], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_46);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[47], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_47);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[48], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_48);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[49], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_49);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[50], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_50);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[51], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_51);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[52], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_52);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[53], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_53);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[54], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_54);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[55], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_55);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[56], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_56);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[57], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_57);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[58], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_58);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[59], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_59);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[60], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_60);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[61], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_61);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[62], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_62);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[63], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_63);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[64], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_64);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[65], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_65);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[66], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_66);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[67], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_67);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[68], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_68);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[69], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_69);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[70], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_70);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[71], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_71);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[72], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_72);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[73], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_73);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[74], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_74);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[75], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_75);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[76], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_76);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[77], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_77);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[78], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_78);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[79], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_79);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[80], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_80);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[81], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_81);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[82], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_82);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[83], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_83);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[84], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_84);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[85], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_85);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[86], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_86);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[87], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_87);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[88], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_88);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[89], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_89);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[90], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_90);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[91], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_91);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[92], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_92);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[93], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_93);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[94], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_94);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[95], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_95);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[96], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_96);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[97], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_97);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[98], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_98);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[99], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_99);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[100], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_100);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[101], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_101);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[102], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_102);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[103], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_103);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[104], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_104);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[105], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_105);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[106], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_106);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[107], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_107);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[108], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_108);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[109], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_109);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[110], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_110);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[111], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_111);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[112], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_112);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[113], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_113);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[114], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_114);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[115], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_115);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[116], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_116);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[117], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_117);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[118], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_118);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[119], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_119);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[120], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_120);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[121], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_121);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[122], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_122);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[123], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_123);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[124], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_124);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[125], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_125);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[126], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_126);
$setuphold(posedge CK &&& (RETeq0aopopDFTRAMeq1aSEeq0cpoopDFTRAMeq0aCSNeq0aWENeq0cpcp), posedge DI[127], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_DI_127);
$setuphold(posedge CK &&& (RETeq0aDFTRAMeq0aCSNeq0aCRE1eq1), posedge FCA1[0], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_FCA);
$setuphold(posedge CK &&& (RETeq0aDFTRAMeq0aCSNeq0aCRE1eq1), posedge FCA1[1], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_FCA);
$setuphold(posedge CK &&& (RETeq0aDFTRAMeq0aCSNeq0aCRE1eq1), posedge FCA1[2], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_FCA);
$setuphold(posedge CK &&& (RETeq0aDFTRAMeq0aCSNeq0aCRE1eq1), posedge FCA1[3], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_FCA);
$setuphold(posedge CK &&& (RETeq0aDFTRAMeq0aCSNeq0aCRE1eq1), posedge FCA1[4], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_FCA);
$setuphold(posedge CK &&& (RETeq0aDFTRAMeq0aCSNeq0aCRE2eq1), posedge FCA2[0], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_FCA);
$setuphold(posedge CK &&& (RETeq0aDFTRAMeq0aCSNeq0aCRE2eq1), posedge FCA2[1], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_FCA);
$setuphold(posedge CK &&& (RETeq0aDFTRAMeq0aCSNeq0aCRE2eq1), posedge FCA2[2], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_FCA);
$setuphold(posedge CK &&& (RETeq0aDFTRAMeq0aCSNeq0aCRE2eq1), posedge FCA2[3], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_FCA);
$setuphold(posedge CK &&& (RETeq0aDFTRAMeq0aCSNeq0aCRE2eq1), posedge FCA2[4], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_FCA);
$setuphold(posedge CK &&& (RETeq0aDFTRAMeq0aCSNeq0), posedge MCSW, `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_MCSW);
$setuphold(posedge CK &&& (RETeq0aopDFTRAMeq1oopDFTRAMeq0aCSNeq0cpcp), posedge MCS[0], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_MCS);
$setuphold(posedge CK &&& (RETeq0aopDFTRAMeq1oopDFTRAMeq0aCSNeq0cpcp), posedge MCS[1], `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_MCS);
$setuphold(posedge CK &&& (RETeq0aDFTRAMeq1), posedge SE, `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_SE);
$setuphold(posedge CK &&& (RETeq0aDFTRAMeq1aSEeq1), posedge SI_D_L, `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_SI_D_L);
$setuphold(posedge CK &&& (RETeq0aDFTRAMeq1aSEeq1), posedge SI_D_R, `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_SI_D_R);
$setuphold(posedge CK &&& (RETeq0aopDFTRAMeq0aCSNeq0cp), posedge WEN, `D_MEM_SETUP, `D_MEM_HOLD, NOT_CK_WEN);

(DFTRAM => SO_D_L) = (`D_MEM_DELAY, `D_MEM_DELAY);

(DFTRAM => SO_D_R) = (`D_MEM_DELAY, `D_MEM_DELAY);

(SE => SO_D_L) = (`D_MEM_DELAY, `D_MEM_DELAY);

(SE => SO_D_R) = (`D_MEM_DELAY, `D_MEM_DELAY);

if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[0]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[1]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[2]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[3]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[4]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[5]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[6]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[7]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[8]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[9]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[10]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[11]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[12]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[13]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[14]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[15]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[16]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[17]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[18]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[19]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[20]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[21]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[22]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[23]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[24]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[25]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[26]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[27]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[28]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[29]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[30]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[31]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[32]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[33]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[34]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[35]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[36]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[37]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[38]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[39]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[40]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[41]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[42]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[43]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[44]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[45]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[46]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[47]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[48]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[49]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[50]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[51]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[52]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[53]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[54]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[55]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[56]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[57]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[58]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[59]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[60]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[61]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[62]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[63]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[64]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[65]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[66]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[67]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[68]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[69]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[70]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[71]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[72]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[73]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[74]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[75]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[76]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[77]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[78]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[79]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[80]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[81]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[82]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[83]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[84]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[85]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[86]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[87]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[88]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[89]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[90]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[91]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[92]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[93]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[94]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[95]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[96]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[97]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[98]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[99]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[100]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[101]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[102]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[103]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[104]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[105]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[106]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[107]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[108]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[109]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[110]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[111]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[112]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[113]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[114]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[115]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[116]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[117]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[118]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[119]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[120]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[121]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[122]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[123]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[124]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[125]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[126]:1'b1)) = (`D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
(posedge CK => (DOUT[127]:1'b1)) = (`D_MEM_DELAY);

if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[0]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[1]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[2]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[3]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[4]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[5]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[6]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[7]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[8]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[9]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[10]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[11]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[12]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[13]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[14]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[15]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[16]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[17]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[18]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[19]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[20]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[21]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[22]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[23]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[24]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[25]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[26]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[27]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[28]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[29]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[30]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[31]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[32]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[33]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[34]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[35]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[36]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[37]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[38]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[39]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[40]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[41]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[42]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[43]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[44]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[45]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[46]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[47]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[48]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[49]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[50]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[51]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[52]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[53]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[54]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[55]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[56]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[57]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[58]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[59]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[60]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[61]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[62]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[63]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[64]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[65]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[66]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[67]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[68]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[69]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[70]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[71]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[72]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[73]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[74]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[75]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[76]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[77]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[78]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[79]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[80]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[81]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[82]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[83]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[84]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[85]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[86]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[87]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[88]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[89]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[90]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[91]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[92]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[93]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[94]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[95]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[96]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[97]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[98]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[99]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[100]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[101]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[102]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[103]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[104]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[105]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[106]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[107]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[108]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[109]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[110]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[111]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[112]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[113]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[114]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[115]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[116]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[117]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[118]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[119]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[120]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[121]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[122]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[123]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[124]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[125]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[126]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[127]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);

if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[0]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[1]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[2]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[3]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[4]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[5]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[6]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[7]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[8]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[9]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[10]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[11]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[12]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[13]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[14]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[15]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[16]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[17]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[18]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[19]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[20]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[21]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[22]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[23]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[24]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[25]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[26]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[27]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[28]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[29]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[30]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[31]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[32]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[33]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[34]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[35]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[36]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[37]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[38]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[39]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[40]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[41]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[42]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[43]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[44]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[45]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[46]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[47]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[48]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[49]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[50]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[51]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[52]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[53]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[54]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[55]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[56]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[57]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[58]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[59]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[60]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[61]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[62]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[63]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[64]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[65]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[66]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[67]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[68]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[69]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[70]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[71]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[72]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[73]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[74]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[75]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[76]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[77]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[78]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[79]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[80]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[81]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[82]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[83]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[84]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[85]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[86]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[87]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[88]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[89]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[90]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[91]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[92]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[93]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[94]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[95]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[96]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[97]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[98]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[99]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[100]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[101]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[102]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[103]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[104]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[105]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[106]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[107]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[108]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[109]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[110]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[111]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[112]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[113]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[114]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[115]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[116]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[117]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[118]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[119]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[120]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[121]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[122]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[123]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[124]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[125]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[126]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[127]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);

if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[0]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[1]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[2]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[3]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[4]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[5]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[6]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[7]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[8]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[9]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[10]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[11]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[12]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[13]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[14]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[15]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[16]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[17]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[18]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[19]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[20]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[21]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[22]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[23]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[24]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[25]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[26]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[27]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[28]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[29]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[30]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[31]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[32]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[33]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[34]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[35]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[36]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[37]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[38]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[39]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[40]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[41]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[42]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[43]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[44]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[45]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[46]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[47]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[48]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[49]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[50]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[51]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[52]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[53]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[54]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[55]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[56]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[57]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[58]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[59]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[60]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[61]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[62]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[63]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[64]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[65]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[66]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[67]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[68]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[69]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[70]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[71]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[72]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[73]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[74]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[75]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[76]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[77]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[78]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[79]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[80]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[81]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[82]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[83]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[84]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[85]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[86]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[87]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[88]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[89]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[90]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[91]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[92]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[93]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[94]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[95]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[96]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[97]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[98]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[99]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[100]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[101]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[102]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[103]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[104]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[105]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[106]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[107]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[108]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[109]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[110]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[111]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[112]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[113]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[114]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[115]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[116]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[117]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[118]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[119]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[120]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[121]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[122]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[123]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[124]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[125]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[126]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[127]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);

if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[0]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[1]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[2]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[3]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[4]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[5]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[6]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[7]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[8]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[9]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[10]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[11]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[12]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[13]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[14]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[15]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[16]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[17]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[18]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[19]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[20]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[21]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[22]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[23]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[24]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[25]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[26]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[27]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[28]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[29]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[30]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[31]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[32]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[33]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[34]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[35]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[36]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[37]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[38]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[39]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[40]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[41]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[42]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[43]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[44]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[45]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[46]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[47]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[48]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[49]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[50]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[51]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[52]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[53]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[54]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[55]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[56]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[57]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[58]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[59]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[60]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[61]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[62]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[63]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[64]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[65]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[66]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[67]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[68]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[69]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[70]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[71]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[72]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[73]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[74]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[75]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[76]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[77]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[78]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[79]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[80]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[81]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[82]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[83]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[84]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[85]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[86]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[87]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[88]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[89]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[90]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[91]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[92]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[93]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[94]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[95]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[96]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[97]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[98]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[99]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[100]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[101]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[102]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[103]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[104]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[105]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[106]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[107]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[108]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[109]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[110]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[111]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[112]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[113]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[114]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[115]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[116]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[117]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[118]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[119]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[120]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[121]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[122]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[123]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[124]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[125]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[126]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[127]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);

if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[0]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[1]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[2]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[3]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[4]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[5]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[6]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[7]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[8]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[9]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[10]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[11]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[12]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[13]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[14]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[15]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[16]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[17]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[18]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[19]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[20]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[21]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[22]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[23]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[24]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[25]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[26]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[27]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[28]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[29]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[30]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[31]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[32]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[33]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[34]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[35]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[36]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[37]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[38]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[39]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[40]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[41]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[42]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[43]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[44]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[45]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[46]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[47]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[48]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[49]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[50]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[51]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[52]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[53]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[54]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[55]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[56]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[57]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[58]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[59]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[60]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[61]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[62]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[63]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[64]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[65]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[66]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[67]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[68]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[69]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[70]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[71]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[72]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[73]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[74]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[75]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[76]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[77]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[78]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[79]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[80]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[81]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[82]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[83]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[84]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[85]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[86]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[87]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[88]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[89]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[90]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[91]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[92]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[93]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[94]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[95]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[96]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[97]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[98]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[99]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[100]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[101]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[102]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[103]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[104]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[105]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[106]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[107]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[108]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[109]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[110]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[111]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[112]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[113]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[114]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[115]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[116]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[117]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[118]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[119]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[120]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[121]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[122]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[123]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[124]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[125]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[126]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[127]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);

if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[0]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[1]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[2]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[3]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[4]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[5]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[6]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[7]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[8]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[9]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[10]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[11]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[12]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[13]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[14]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[15]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[16]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[17]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[18]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[19]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[20]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[21]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[22]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[23]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[24]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[25]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[26]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[27]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[28]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[29]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[30]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[31]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[32]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[33]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[34]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[35]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[36]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[37]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[38]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[39]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[40]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[41]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[42]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[43]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[44]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[45]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[46]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[47]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[48]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[49]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[50]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[51]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[52]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[53]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[54]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[55]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[56]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[57]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[58]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[59]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[60]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[61]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[62]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[63]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[64]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[65]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[66]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[67]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[68]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[69]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[70]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[71]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[72]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[73]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[74]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[75]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[76]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[77]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[78]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[79]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[80]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[81]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[82]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[83]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[84]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[85]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[86]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[87]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[88]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[89]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[90]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[91]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[92]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[93]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[94]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[95]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[96]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[97]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[98]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[99]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[100]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[101]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[102]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[103]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[104]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[105]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[106]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[107]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[108]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[109]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[110]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[111]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[112]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[113]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[114]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[115]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[116]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[117]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[118]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[119]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[120]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[121]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[122]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[123]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[124]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[125]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[126]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[127]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);

if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[0]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[1]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[2]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[3]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[4]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[5]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[6]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[7]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[8]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[9]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[10]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[11]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[12]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[13]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[14]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[15]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[16]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[17]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[18]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[19]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[20]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[21]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[22]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[23]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[24]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[25]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[26]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[27]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[28]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[29]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[30]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[31]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[32]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[33]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[34]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[35]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[36]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[37]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[38]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[39]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[40]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[41]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[42]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[43]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[44]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[45]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[46]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[47]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[48]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[49]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[50]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[51]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[52]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[53]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[54]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[55]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[56]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[57]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[58]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[59]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[60]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[61]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[62]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[63]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[64]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[65]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[66]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[67]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[68]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[69]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[70]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[71]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[72]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[73]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[74]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[75]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[76]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[77]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[78]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[79]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[80]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[81]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[82]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[83]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[84]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[85]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[86]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[87]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[88]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[89]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[90]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[91]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[92]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[93]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[94]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[95]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[96]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[97]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[98]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[99]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[100]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[101]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[102]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[103]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[104]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[105]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[106]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[107]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[108]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[109]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[110]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[111]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[112]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[113]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[114]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[115]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[116]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[117]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[118]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[119]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[120]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[121]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[122]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[123]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[124]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[125]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[126]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[127]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);

if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[0]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[1]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[2]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[3]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[4]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[5]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[6]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[7]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[8]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[9]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[10]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[11]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[12]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[13]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[14]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[15]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[16]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[17]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[18]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[19]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[20]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[21]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[22]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[23]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[24]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[25]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[26]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[27]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[28]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[29]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[30]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[31]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[32]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[33]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[34]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[35]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[36]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[37]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[38]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[39]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[40]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[41]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[42]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[43]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[44]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[45]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[46]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[47]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[48]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[49]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[50]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[51]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[52]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[53]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[54]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[55]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[56]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[57]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[58]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[59]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[60]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[61]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[62]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[63]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[64]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[65]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[66]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[67]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[68]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[69]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[70]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[71]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[72]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[73]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[74]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[75]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[76]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[77]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[78]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[79]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[80]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[81]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[82]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[83]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[84]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[85]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[86]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[87]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[88]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[89]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[90]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[91]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[92]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[93]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[94]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[95]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[96]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[97]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[98]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[99]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[100]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[101]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[102]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[103]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[104]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[105]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[106]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[107]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[108]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[109]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[110]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[111]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[112]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[113]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[114]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[115]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[116]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[117]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[118]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[119]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[120]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[121]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[122]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[123]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[124]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[125]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[126]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B0 && CSN==1'B0 && WEN==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
(posedge CK => (DOUT[127]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);

if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[0]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[1]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[2]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[3]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[4]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[5]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[6]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[7]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[8]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[9]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[10]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[11]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[12]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[13]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[14]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[15]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[16]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[17]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[18]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[19]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[20]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[21]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[22]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[23]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[24]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[25]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[26]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[27]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[28]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[29]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[30]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[31]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[32]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[33]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[34]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[35]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[36]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[37]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[38]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[39]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[40]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[41]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[42]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[43]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[44]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[45]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[46]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[47]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[48]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[49]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[50]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[51]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[52]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[53]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[54]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[55]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[56]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[57]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[58]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[59]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[60]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[61]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[62]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[63]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[64]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[65]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[66]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[67]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[68]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[69]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[70]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[71]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[72]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[73]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[74]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[75]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[76]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[77]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[78]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[79]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[80]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[81]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[82]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[83]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[84]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[85]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[86]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[87]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[88]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[89]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[90]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[91]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[92]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[93]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[94]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[95]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[96]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[97]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[98]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[99]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[100]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[101]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[102]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[103]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[104]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[105]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[106]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[107]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[108]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[109]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[110]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[111]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[112]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[113]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[114]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[115]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[116]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[117]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[118]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[119]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[120]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[121]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[122]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[123]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[124]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[125]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[126]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[127]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);

if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[0]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[1]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[2]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[3]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[4]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[5]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[6]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[7]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[8]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[9]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[10]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[11]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[12]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[13]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[14]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[15]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[16]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[17]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[18]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[19]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[20]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[21]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[22]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[23]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[24]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[25]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[26]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[27]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[28]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[29]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[30]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[31]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[32]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[33]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[34]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[35]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[36]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[37]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[38]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[39]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[40]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[41]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[42]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[43]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[44]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[45]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[46]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[47]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[48]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[49]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[50]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[51]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[52]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[53]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[54]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[55]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[56]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[57]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[58]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[59]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[60]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[61]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[62]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[63]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[64]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[65]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[66]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[67]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[68]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[69]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[70]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[71]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[72]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[73]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[74]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[75]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[76]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[77]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[78]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[79]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[80]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[81]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[82]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[83]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[84]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[85]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[86]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[87]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[88]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[89]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[90]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[91]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[92]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[93]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[94]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[95]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[96]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[97]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[98]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[99]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[100]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[101]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[102]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[103]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[104]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[105]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[106]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[107]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[108]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[109]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[110]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[111]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[112]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[113]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[114]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[115]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[116]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[117]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[118]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[119]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[120]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[121]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[122]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[123]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[124]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[125]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[126]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[127]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);

if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[0]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[1]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[2]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[3]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[4]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[5]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[6]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[7]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[8]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[9]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[10]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[11]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[12]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[13]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[14]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[15]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[16]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[17]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[18]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[19]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[20]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[21]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[22]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[23]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[24]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[25]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[26]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[27]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[28]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[29]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[30]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[31]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[32]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[33]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[34]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[35]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[36]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[37]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[38]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[39]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[40]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[41]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[42]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[43]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[44]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[45]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[46]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[47]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[48]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[49]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[50]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[51]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[52]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[53]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[54]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[55]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[56]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[57]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[58]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[59]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[60]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[61]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[62]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[63]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[64]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[65]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[66]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[67]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[68]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[69]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[70]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[71]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[72]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[73]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[74]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[75]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[76]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[77]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[78]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[79]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[80]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[81]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[82]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[83]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[84]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[85]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[86]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[87]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[88]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[89]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[90]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[91]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[92]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[93]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[94]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[95]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[96]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[97]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[98]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[99]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[100]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[101]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[102]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[103]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[104]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[105]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[106]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[107]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[108]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[109]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[110]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[111]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[112]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[113]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[114]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[115]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[116]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[117]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[118]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[119]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[120]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[121]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[122]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[123]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[124]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[125]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[126]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[127]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);

if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[0]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[1]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[2]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[3]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[4]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[5]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[6]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[7]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[8]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[9]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[10]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[11]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[12]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[13]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[14]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[15]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[16]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[17]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[18]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[19]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[20]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[21]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[22]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[23]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[24]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[25]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[26]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[27]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[28]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[29]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[30]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[31]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[32]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[33]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[34]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[35]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[36]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[37]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[38]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[39]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[40]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[41]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[42]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[43]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[44]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[45]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[46]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[47]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[48]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[49]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[50]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[51]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[52]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[53]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[54]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[55]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[56]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[57]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[58]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[59]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[60]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[61]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[62]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[63]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[64]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[65]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[66]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[67]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[68]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[69]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[70]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[71]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[72]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[73]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[74]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[75]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[76]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[77]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[78]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[79]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[80]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[81]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[82]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[83]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[84]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[85]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[86]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[87]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[88]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[89]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[90]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[91]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[92]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[93]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[94]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[95]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[96]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[97]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[98]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[99]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[100]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[101]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[102]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[103]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[104]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[105]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[106]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[107]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[108]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[109]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[110]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[111]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[112]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[113]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[114]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[115]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[116]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[117]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[118]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[119]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[120]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[121]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[122]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[123]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[124]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[125]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[126]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[127]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);

if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[0]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[1]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[2]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[3]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[4]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[5]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[6]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[7]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[8]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[9]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[10]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[11]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[12]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[13]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[14]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[15]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[16]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[17]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[18]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[19]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[20]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[21]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[22]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[23]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[24]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[25]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[26]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[27]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[28]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[29]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[30]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[31]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[32]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[33]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[34]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[35]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[36]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[37]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[38]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[39]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[40]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[41]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[42]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[43]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[44]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[45]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[46]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[47]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[48]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[49]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[50]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[51]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[52]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[53]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[54]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[55]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[56]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[57]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[58]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[59]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[60]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[61]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[62]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[63]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[64]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[65]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[66]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[67]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[68]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[69]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[70]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[71]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[72]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[73]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[74]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[75]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[76]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[77]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[78]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[79]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[80]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[81]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[82]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[83]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[84]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[85]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[86]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[87]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[88]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[89]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[90]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[91]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[92]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[93]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[94]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[95]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[96]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[97]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[98]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[99]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[100]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[101]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[102]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[103]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[104]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[105]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[106]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[107]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[108]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[109]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[110]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[111]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[112]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[113]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[114]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[115]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[116]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[117]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[118]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[119]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[120]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[121]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[122]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[123]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[124]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[125]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[126]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (DOUT[127]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);

if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[0]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[1]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[2]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[3]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[4]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[5]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[6]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[7]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[8]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[9]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[10]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[11]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[12]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[13]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[14]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[15]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[16]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[17]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[18]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[19]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[20]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[21]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[22]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[23]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[24]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[25]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[26]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[27]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[28]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[29]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[30]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[31]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[32]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[33]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[34]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[35]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[36]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[37]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[38]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[39]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[40]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[41]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[42]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[43]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[44]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[45]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[46]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[47]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[48]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[49]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[50]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[51]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[52]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[53]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[54]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[55]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[56]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[57]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[58]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[59]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[60]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[61]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[62]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[63]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[64]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[65]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[66]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[67]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[68]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[69]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[70]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[71]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[72]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[73]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[74]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[75]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[76]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[77]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[78]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[79]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[80]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[81]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[82]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[83]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[84]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[85]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[86]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[87]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[88]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[89]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[90]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[91]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[92]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[93]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[94]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[95]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[96]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[97]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[98]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[99]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[100]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[101]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[102]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[103]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[104]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[105]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[106]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[107]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[108]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[109]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[110]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[111]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[112]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[113]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[114]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[115]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[116]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[117]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[118]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[119]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[120]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[121]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[122]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[123]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[124]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[125]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[126]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (DOUT[127]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);

if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[0]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[1]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[2]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[3]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[4]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[5]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[6]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[7]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[8]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[9]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[10]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[11]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[12]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[13]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[14]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[15]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[16]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[17]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[18]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[19]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[20]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[21]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[22]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[23]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[24]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[25]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[26]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[27]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[28]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[29]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[30]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[31]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[32]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[33]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[34]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[35]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[36]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[37]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[38]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[39]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[40]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[41]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[42]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[43]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[44]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[45]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[46]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[47]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[48]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[49]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[50]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[51]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[52]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[53]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[54]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[55]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[56]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[57]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[58]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[59]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[60]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[61]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[62]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[63]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[64]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[65]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[66]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[67]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[68]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[69]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[70]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[71]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[72]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[73]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[74]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[75]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[76]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[77]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[78]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[79]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[80]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[81]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[82]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[83]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[84]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[85]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[86]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[87]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[88]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[89]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[90]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[91]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[92]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[93]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[94]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[95]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[96]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[97]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[98]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[99]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[100]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[101]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[102]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[103]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[104]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[105]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[106]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[107]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[108]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[109]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[110]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[111]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[112]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[113]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[114]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[115]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[116]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[117]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[118]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[119]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[120]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[121]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[122]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[123]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[124]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[125]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[126]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (DOUT[127]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);

if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[0]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[1]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[2]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[3]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[4]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[5]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[6]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[7]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[8]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[9]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[10]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[11]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[12]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[13]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[14]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[15]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[16]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[17]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[18]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[19]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[20]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[21]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[22]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[23]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[24]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[25]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[26]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[27]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[28]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[29]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[30]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[31]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[32]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[33]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[34]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[35]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[36]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[37]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[38]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[39]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[40]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[41]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[42]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[43]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[44]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[45]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[46]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[47]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[48]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[49]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[50]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[51]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[52]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[53]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[54]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[55]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[56]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[57]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[58]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[59]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[60]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[61]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[62]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[63]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[64]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[65]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[66]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[67]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[68]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[69]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[70]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[71]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[72]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[73]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[74]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[75]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[76]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[77]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[78]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[79]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[80]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[81]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[82]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[83]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[84]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[85]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[86]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[87]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[88]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[89]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[90]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[91]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[92]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[93]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[94]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[95]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[96]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[97]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[98]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[99]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[100]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[101]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[102]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[103]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[104]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[105]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[106]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[107]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[108]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[109]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[110]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[111]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[112]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[113]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[114]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[115]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[116]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[117]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[118]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[119]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[120]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[121]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[122]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[123]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[124]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[125]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[126]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
if ( RET==1'B0 && DFTRAM==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (DOUT[127]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);

if ( RET==1'B0 && DFTRAM==1'B1 && SE==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (SO_D_L:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);

if ( RET==1'B0 && DFTRAM==1'B1 && SE==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (SO_D_L:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);

if ( RET==1'B0 && DFTRAM==1'B1 && SE==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (SO_D_L:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);

if ( RET==1'B0 && DFTRAM==1'B1 && SE==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (SO_D_L:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);

if ( RET==1'B0 && DFTRAM==1'B1 && SE==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (SO_D_L:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);

if ( RET==1'B0 && DFTRAM==1'B1 && SE==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (SO_D_L:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);

if ( RET==1'B0 && DFTRAM==1'B1 && SE==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (SO_D_L:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);

if ( RET==1'B0 && DFTRAM==1'B1 && SE==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (SO_D_L:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);

if ( RET==1'B0 && DFTRAM==1'B1 && SE==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (SO_D_R:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);

if ( RET==1'B0 && DFTRAM==1'B1 && SE==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (SO_D_R:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);

if ( RET==1'B0 && DFTRAM==1'B1 && SE==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (SO_D_R:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);

if ( RET==1'B0 && DFTRAM==1'B1 && SE==1'B1 && MCS[1]==1'B0 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (SO_D_R:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);

if ( RET==1'B0 && DFTRAM==1'B1 && SE==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B0 )
(posedge CK => (SO_D_R:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);

if ( RET==1'B0 && DFTRAM==1'B1 && SE==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B0 && MCSW==1'B1 )
(posedge CK => (SO_D_R:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);

if ( RET==1'B0 && DFTRAM==1'B1 && SE==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B0 )
(posedge CK => (SO_D_R:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);

if ( RET==1'B0 && DFTRAM==1'B1 && SE==1'B1 && MCS[1]==1'B1 && MCS[0]==1'B1 && MCSW==1'B1 )
(posedge CK => (SO_D_R:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);

endspecify
`endif

endmodule 

`endcelldefine

module ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128_error_injection (Q_out, Q_in, CK, A, CSN, DFTRAM, SE, WEN, CRE1, FCA1, CRE2, FCA2);
	// Parameter definition
	parameter WORDS = 64;
	parameter BITS = 128;
	parameter mux  = 2;
	parameter addr_width  = 6;
	parameter faddr1_width = 5;
	parameter faddr2_width = 5;
	parameter center = 64;
	parameter row_addr_width = addr_width - 1;
	parameter BITS_bit = $clog2(BITS);

	output [(BITS-1):0] Q_out;
	input [(BITS-1):0] Q_in;
	input CK;
	input [(addr_width-1):0] A;						//Address_bit
	input CSN;
	input DFTRAM;
	input SE;
	input WEN;
	input CRE1;
	input CRE2;
	input [faddr1_width-1:0] FCA1;
	input [faddr2_width-1:0] FCA2;
	parameter LEFT_RED_COLUMN_FAULT = 2'd1;
	parameter RIGHT_RED_COLUMN_FAULT = 2'd2;
	parameter NO_RED_FAULT = 2'd0;
	reg [(BITS-1):0] Q_out;					//Num_DQ
	reg entry_found;
	reg list_complete;
	reg [(addr_width+BITS_bit+4):0] fault_table [(WORDS/mux-1):0];		//reg [fault_entry-1:0] fault_table [row_address-1:0];
	reg [(addr_width+BITS_bit+4):0] fault_entry;						//reg [fault_entry-1:0] fault_entry

	//This task injects fault in memory
	task add_fault;
		input [(addr_width-1):0] address;				//Address_bit
		input [(BITS_bit-1):0] bitPlace;			//log2(DQ)
		input [1:0] fault_type;
		input [1:0] red_fault;
		integer i;
		reg done;
	begin
		done = 1'b0;
		i = 0;
		while ((!done) && i < (WORDS/mux-1)) begin			//while ((!done) && i < (row_address-1))
			fault_entry = fault_table[i];
			if (fault_entry[0] === 1'b0 || fault_entry[0] === 1'bx)
			begin
				fault_entry[0] = 1'b1;
				fault_entry[2:1] = red_fault;
				fault_entry[4:3] = fault_type;
				fault_entry[(BITS_bit+4):5] = bitPlace;									//log2(DQ)
				fault_entry[(addr_width+BITS_bit+4):(BITS_bit+5)] = address;		//Num_Address
				fault_table[i] = fault_entry;
				done = 1'b1;
			end
			i = i+1;
		end
	end
	endtask

	//This task removes all fault entries injected by user
	task remove_all_faults;
		integer i;
	begin
		for (i = 0; i < (WORDS/mux) ; i=i+1)			//for (i = 0; i < row_address ; i=i+1)
		begin
			fault_entry = fault_table[i];
			fault_entry[0] = 1'b0;
			fault_table[i] = fault_entry;
		end
	end
	endtask

	// This task is used to inject error in memory and should be called
	// only from current module.
	//
	// This task injects error depending upon fault type to particular bit
	// of the output
	task bit_error;
		inout [(BITS-1):0] q_int;					//Num_DQ
		input [1:0] fault_type;
		input [(BITS_bit-1):0] bitLoc;				//log2(DQ)
	begin
		if (fault_type === 2'd0)
			q_int[bitLoc] = 1'b0;
		else if (fault_type === 2'd1)
			q_int[bitLoc] = 1'b1;
		else
			q_int[bitLoc] = ~q_int[bitLoc];
	end
	endtask

	// This function goes through error injection table for every
	// read cycle and corrupts Q output if fault for the particular
	// address is present in fault table
	//
	// If fault is redundant column is detected, this task corrupts
	// Q output in read cycle
	//
	// If fault is repaired using repair bus, this task does not
	// courrpt Q output in read cycle
	//
	task error_injection_on_output;
		output [(BITS-1):0] Q_output;				//Num_output
		reg list_complete;
		integer i;
		integer do_corrupt;
		reg [4:0] row_address;				//row_address
		reg [0:0] column_address;							//column_address
		reg [(BITS_bit-1):0] bitPlace;					//log2(DQ)
		reg [1:0] fault_type;
		reg [1:0] red_fault;
		reg valid;
		reg [BITS_bit:0] msb_bit_calc;				//log2(DQ)-1
	begin
		entry_found = 1'b0;
		list_complete = 1'b0;
		i = 0;
		Q_output = Q_in;
		while(!list_complete) begin
			fault_entry = fault_table[i];
			{row_address, column_address, bitPlace, fault_type, red_fault, valid} = fault_entry;
			i = i + 1;
			do_corrupt = 1;
			if (valid == 1'b1) begin
				if (red_fault === LEFT_RED_COLUMN_FAULT && CRE1 === 1'b1)
					bit_error(Q_output, fault_type,(center-1));						//left redundancy cell location(DQ)
				else if (red_fault === RIGHT_RED_COLUMN_FAULT && CRE2 === 1'b1)
					bit_error(Q_output, fault_type,center);							//right redundancy cell location(DQ)
				else if (red_fault === NO_RED_FAULT) begin
					if (row_address == A[addr_width-1:1] && column_address == A[0:0]) begin
							if (CRE1 === 1'b1 || CRE2 === 1'b1) begin
								if (CRE1 === 1'b1) begin
									if (FCA1 + (bitPlace[(BITS_bit-1):0]>>1) == ((center>>1)-1)) begin	//left repair
										do_corrupt = 0;
									end
									else begin
										do_corrupt = 1;
									end
								end
								if (CRE2 === 1'b1 && do_corrupt == 1) begin					//right repair
									msb_bit_calc = (bitPlace - center) >> 1;				//count from right-side center
									if (msb_bit_calc == FCA2) begin
										do_corrupt = 0;
									end
									else begin
										do_corrupt = 1;
									end
								end
								if (do_corrupt === 1'b1) begin
									bit_error(Q_output,fault_type, bitPlace);
								end
							end
							else begin
								bit_error(Q_output,fault_type, bitPlace);
							end
					end
				end
			end
			else
				list_complete = 1'b1;
		end
	end
	endtask

	always @ (Q_in or A) begin
		if (CSN === 1'b0 && WEN === 1'b1 && DFTRAM === 1'b0)
			error_injection_on_output(Q_out);
	end

endmodule

`else
module ln04lpp_s00_mc_rf1rs_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 (DOUT, CK, CSN, WEN, A, DI, MCS, MCSW
					,SO_D_L, SO_D_R, DFTRAM, SE, SI_D_L, SI_D_R
					,RET
					,CRE1, CRE2, FCA1, FCA2
					,ADME
					);

	// Parameter definition 
	parameter WORDS = 64;
	parameter BITS  = 128;
	parameter addr_width  = 6;
	parameter mux  = 2;
	parameter TRUE = 1'b1;
	parameter FALSE = 1'b0;
	parameter faddr1_width = 5;
	parameter faddr2_width = 5;
	parameter r_bit = 4;

	parameter word1 = {BITS{1'b1}};
	parameter word0 = {BITS{1'b0}};
	parameter wordx = {BITS{1'bx}};
	parameter wordz = {BITS{1'bz}};
	parameter row1 = {BITS*mux+r_bit*2{1'b1}};
	parameter row0 = {BITS*mux+r_bit*2{1'b0}};
	parameter rowx = {BITS*mux+r_bit*2{1'bx}};
	parameter addrx = {addr_width{1'bx}};

	// Primary port definition 
	output [BITS-1:0] DOUT;
	input CK;
	input CSN;
	input WEN;
	input [BITS-1:0] DI;
	input [addr_width-1:0] A;
	input [1:0] MCS;
	input MCSW;

	output SO_D_L;
	output SO_D_R;
	input SI_D_L;
	input SI_D_R;
	input DFTRAM;
	input SE;

	input RET;


	input CRE1;
	input CRE2;
	input [faddr1_width-1:0] FCA1;
	input [faddr2_width-1:0] FCA2;

	input [2:0] ADME;

    assign DOUT     ='0;
    assign SO_D_L   ='0;
    assign SO_D_R   ='0;

endmodule

`endif
   
