module coresight_wrapper(
        /*autoarg*/
   // Outputs
   vpu1_jpeg1_nts_tssync, vpu1_jpeg1_nts_tsbit, vpu1_jpeg0_nts_tssync,
   vpu1_jpeg0_nts_tsbit, vpu1_funnel_slice_atb_syncreq,
   vpu1_funnel_slice_atb_atready, vpu1_funnel_slice_atb_afvalid,
   vpu1_dec_nts_tssync, vpu1_dec_nts_tsbit, vpu1_cti_apb_pwrite,
   vpu1_cti_apb_pwdata, vpu1_cti_apb_psel, vpu1_cti_apb_penable,
   vpu1_cti_apb_paddr31, vpu1_cti_apb_paddr, vpu0_jpeg1_nts_tssync,
   vpu0_jpeg1_nts_tsbit, vpu0_jpeg0_nts_tssync, vpu0_jpeg0_nts_tsbit,
   vpu0_funnel_slice_atb_syncreq, vpu0_funnel_slice_atb_atready,
   vpu0_funnel_slice_atb_afvalid, vpu0_dec_nts_tssync,
   vpu0_dec_nts_tsbit, vpu0_cti_apb_pwrite, vpu0_cti_apb_pwdata,
   vpu0_cti_apb_psel, vpu0_cti_apb_penable, vpu0_cti_apb_paddr31,
   vpu0_cti_apb_paddr, swdbg_pslverr, swdbg_pready, swdbg_prdata,
   sec_mid_apbic_apb_pwrite, sec_mid_apbic_apb_pwdata,
   sec_mid_apbic_apb_psel, sec_mid_apbic_apb_penable,
   sec_mid_apbic_apb_paddr31, sec_mid_apbic_apb_paddr,
   reg_coresight_freqdiv, reg_coresight_clk_sel, pcie_nts_tssync_1,
   pcie_nts_tssync_0, pcie_nts_tsbit_1, pcie_nts_tsbit_0,
   pcie_cti_apb_pwrite, pcie_cti_apb_pwdata, pcie_cti_apb_psel,
   pcie_cti_apb_penable, pcie_cti_apb_paddr31, pcie_cti_apb_paddr,
   pcie1_slice_atb_syncreq, pcie1_slice_atb_atready,
   pcie1_slice_atb_afvalid, pcie0_slice_atb_syncreq,
   pcie0_slice_atb_atready, pcie0_slice_atb_afvalid,
   mid_ntsr_nts_tssync, mid_ntsr_nts_tsbit, mid_funnel_atb_syncreq,
   mid_funnel_atb_atready, mid_funnel_atb_afvalid, jtag_scr1_trst_n,
   jtag_scr1_tms, jtag_scr1_tdi, jtag_scr1_tck, etr_axi_wvalid,
   etr_axi_wstrb, etr_axi_wlast, etr_axi_wdata, etr_axi_rready,
   etr_axi_bready, etr_axi_awvalid, etr_axi_awuser, etr_axi_awsize,
   etr_axi_awqos, etr_axi_awprot, etr_axi_awlock, etr_axi_awlen,
   etr_axi_awid, etr_axi_awcache, etr_axi_awburst, etr_axi_awaddr,
   etr_axi_arvalid, etr_axi_aruser, etr_axi_arsize, etr_axi_arqos,
   etr_axi_arprot, etr_axi_arlock, etr_axi_arlen, etr_axi_arid,
   etr_axi_arcache, etr_axi_arburst, etr_axi_araddr,
   etf_etr_interrupt, dbus_btm_slice_atb_syncreq,
   dbus_btm_slice_atb_atready, dbus_btm_slice_atb_afvalid,
   dbus_btm_nts_tssync, dbus_btm_nts_tsbit, dbus_btm_cti_apb_pwrite,
   dbus_btm_cti_apb_pwdata, dbus_btm_cti_apb_psel,
   dbus_btm_cti_apb_penable, dbus_btm_cti_apb_paddr31,
   dbus_btm_cti_apb_paddr, cxctm0_ctmchout3, cxctm0_ctmchout2,
   cxctm0_ctmchinack3, cxctm0_ctmchinack2, cs_jtag_tdo,
   cs_jtag_ntdoen, cbus_btm_slice_atb_syncreq,
   cbus_btm_slice_atb_atready, cbus_btm_slice_atb_afvalid,
   cbus_btm_nts_tssync, cbus_btm_nts_tsbit, cbus_btm_cti_apb_pwrite,
   cbus_btm_cti_apb_pwdata, cbus_btm_cti_apb_psel,
   cbus_btm_cti_apb_penable, cbus_btm_cti_apb_paddr31,
   cbus_btm_cti_apb_paddr, axiap_wvalid, axiap_wstrb, axiap_wlast,
   axiap_wdata, axiap_rready, axiap_bready, axiap_awvalid,
   axiap_awuser, axiap_awsize, axiap_awprot, axiap_awlen,
   axiap_awcache, axiap_awburst, axiap_awaddr, axiap_arvalid,
   axiap_aruser, axiap_arsize, axiap_arprot, axiap_arlen,
   axiap_arcache, axiap_arburst, axiap_araddr,
   atb_formatter_vpu1_vdec_fr_reg, atb_formatter_vpu1_jpeg1_fr_reg,
   atb_formatter_vpu1_jpeg0_fr_reg, atb_formatter_vpu0_vdec_fr_reg,
   atb_formatter_vpu0_jpeg1_fr_reg, atb_formatter_vpu0_jpeg0_fr_reg,
   atb_formatter_up_ualink1_fr_reg, atb_formatter_up_ualink0_fr_reg,
   atb_formatter_ctrl_scp_fr_reg, atb_formatter_btm_pcie_r1_fr_reg,
   atb_formatter_btm_pcie_r0_fr_reg, apbap_dbgswen,
   // Inputs
   vpu1_jpeg1_nts_tssyncready, vpu1_jpeg0_nts_tssyncready,
   vpu1_funnel_slice_atb_atvalid, vpu1_funnel_slice_atb_atid,
   vpu1_funnel_slice_atb_atdata, vpu1_funnel_slice_atb_atbytes,
   vpu1_funnel_slice_atb_afready, vpu1_dec_nts_tssyncready,
   vpu1_cti_apb_pslverr, vpu1_cti_apb_pready, vpu1_cti_apb_prdata,
   vpu0_jpeg1_nts_tssyncready, vpu0_jpeg0_nts_tssyncready,
   vpu0_funnel_slice_atb_atvalid, vpu0_funnel_slice_atb_atid,
   vpu0_funnel_slice_atb_atdata, vpu0_funnel_slice_atb_atbytes,
   vpu0_funnel_slice_atb_afready, vpu0_dec_nts_tssyncready,
   vpu0_cti_apb_pslverr, vpu0_cti_apb_pready, vpu0_cti_apb_prdata,
   tscenter_hltdbg, trace_rstn, trace_clk, swjdp_npotrst,
   swdbg_pwrite, swdbg_pwdata, swdbg_psel, swdbg_penable, swdbg_paddr,
   sec_mid_apbic_apb_pslverr, sec_mid_apbic_apb_pready,
   sec_mid_apbic_apb_prdata, pcie_nts_tssyncready_1,
   pcie_nts_tssyncready_0, pcie_cti_apb_pslverr, pcie_cti_apb_pready,
   pcie_cti_apb_prdata, pcie1_slice_atb_atvalid, pcie1_slice_atb_atid,
   pcie1_slice_atb_atdata, pcie1_slice_atb_atbytes,
   pcie1_slice_atb_afready, pcie0_slice_atb_atvalid,
   pcie0_slice_atb_atid, pcie0_slice_atb_atdata,
   pcie0_slice_atb_atbytes, pcie0_slice_atb_afready,
   mid_ntsr_nts_tssyncready, mid_funnel_atb_atvalid,
   mid_funnel_atb_atid, mid_funnel_atb_atdata, mid_funnel_atb_atbytes,
   mid_funnel_atb_afready, jtag_scr1_tdo, etr_axi_wready,
   etr_axi_rvalid, etr_axi_ruser, etr_axi_rresp, etr_axi_rlast,
   etr_axi_rid, etr_axi_rdata, etr_axi_bvalid, etr_axi_buser,
   etr_axi_bresp, etr_axi_bid, etr_axi_awready, etr_axi_arready,
   dft_test_mode, dbus_btm_slice_atb_atvalid, dbus_btm_slice_atb_atid,
   dbus_btm_slice_atb_atdata, dbus_btm_slice_atb_atbytes,
   dbus_btm_slice_atb_afready, dbus_btm_nts_tssyncready,
   dbus_btm_cti_apb_pslverr, dbus_btm_cti_apb_pready,
   dbus_btm_cti_apb_prdata, dbg_rstn, dbg_clk, cxctm0_ctmchoutack3,
   cxctm0_ctmchoutack2, cxctm0_ctmchin3, cxctm0_ctmchin2, cs_jtag_tms,
   cs_jtag_tdi, cs_jtag_tck, cs_jtag_ntrst,
   cbus_btm_slice_atb_atvalid, cbus_btm_slice_atb_atid,
   cbus_btm_slice_atb_atdata, cbus_btm_slice_atb_atbytes,
   cbus_btm_slice_atb_afready, cbus_btm_nts_tssyncready,
   cbus_btm_cti_apb_pslverr, cbus_btm_cti_apb_pready,
   cbus_btm_cti_apb_prdata, axiap_wready, axiap_rvalid, axiap_rresp,
   axiap_rlast, axiap_rdata, axiap_bvalid, axiap_bresp, axiap_awready,
   axiap_arready
   );
/*autoinput*/
// Beginning of automatic inputs (from unused autoinst inputs)
input                   axiap_arready;          // To dap_wrapper_u0 of dap_wrapper.v
input                   axiap_awready;          // To dap_wrapper_u0 of dap_wrapper.v
input [1:0]             axiap_bresp;            // To dap_wrapper_u0 of dap_wrapper.v
input                   axiap_bvalid;           // To dap_wrapper_u0 of dap_wrapper.v
input [31:0]            axiap_rdata;            // To dap_wrapper_u0 of dap_wrapper.v
input                   axiap_rlast;            // To dap_wrapper_u0 of dap_wrapper.v
input [1:0]             axiap_rresp;            // To dap_wrapper_u0 of dap_wrapper.v
input                   axiap_rvalid;           // To dap_wrapper_u0 of dap_wrapper.v
input                   axiap_wready;           // To dap_wrapper_u0 of dap_wrapper.v
input [31:0]            cbus_btm_cti_apb_prdata;// To dap_wrapper_u0 of dap_wrapper.v
input                   cbus_btm_cti_apb_pready;// To dap_wrapper_u0 of dap_wrapper.v
input                   cbus_btm_cti_apb_pslverr;// To dap_wrapper_u0 of dap_wrapper.v
input                   cbus_btm_nts_tssyncready;// To ts_gen_wrapper_u0 of ts_gen_wrapper.v
input                   cbus_btm_slice_atb_afready;// To trace_wrapper_u0 of trace_wrapper.v
input [3:0]             cbus_btm_slice_atb_atbytes;// To trace_wrapper_u0 of trace_wrapper.v
input [127:0]           cbus_btm_slice_atb_atdata;// To trace_wrapper_u0 of trace_wrapper.v
input [6:0]             cbus_btm_slice_atb_atid;// To trace_wrapper_u0 of trace_wrapper.v
input                   cbus_btm_slice_atb_atvalid;// To trace_wrapper_u0 of trace_wrapper.v
input                   cs_jtag_ntrst;          // To jtag_reset_sync of reset_sync_dft.v, ...
input                   cs_jtag_tck;            // To jtag_reset_sync of reset_sync_dft.v, ...
input                   cs_jtag_tdi;            // To dap_wrapper_u0 of dap_wrapper.v
input                   cs_jtag_tms;            // To dap_wrapper_u0 of dap_wrapper.v
input [3:0]             cxctm0_ctmchin2;        // To trace_wrapper_u0 of trace_wrapper.v
input [3:0]             cxctm0_ctmchin3;        // To trace_wrapper_u0 of trace_wrapper.v
input [3:0]             cxctm0_ctmchoutack2;    // To trace_wrapper_u0 of trace_wrapper.v
input [3:0]             cxctm0_ctmchoutack3;    // To trace_wrapper_u0 of trace_wrapper.v
input                   dbg_clk;                // To dap_wrapper_u0 of dap_wrapper.v, ...
input                   dbg_rstn;               // To dap_wrapper_u0 of dap_wrapper.v, ...
input [31:0]            dbus_btm_cti_apb_prdata;// To dap_wrapper_u0 of dap_wrapper.v
input                   dbus_btm_cti_apb_pready;// To dap_wrapper_u0 of dap_wrapper.v
input                   dbus_btm_cti_apb_pslverr;// To dap_wrapper_u0 of dap_wrapper.v
input                   dbus_btm_nts_tssyncready;// To ts_gen_wrapper_u0 of ts_gen_wrapper.v
input                   dbus_btm_slice_atb_afready;// To trace_wrapper_u0 of trace_wrapper.v
input [3:0]             dbus_btm_slice_atb_atbytes;// To trace_wrapper_u0 of trace_wrapper.v
input [127:0]           dbus_btm_slice_atb_atdata;// To trace_wrapper_u0 of trace_wrapper.v
input [6:0]             dbus_btm_slice_atb_atid;// To trace_wrapper_u0 of trace_wrapper.v
input                   dbus_btm_slice_atb_atvalid;// To trace_wrapper_u0 of trace_wrapper.v
input                   dft_test_mode;          // To jtag_reset_sync of reset_sync_dft.v, ...
input                   etr_axi_arready;        // To trace_wrapper_u0 of trace_wrapper.v
input                   etr_axi_awready;        // To trace_wrapper_u0 of trace_wrapper.v
input [5:0]             etr_axi_bid;            // To trace_wrapper_u0 of trace_wrapper.v
input [1:0]             etr_axi_bresp;          // To trace_wrapper_u0 of trace_wrapper.v
input [15:0]            etr_axi_buser;          // To trace_wrapper_u0 of trace_wrapper.v
input                   etr_axi_bvalid;         // To trace_wrapper_u0 of trace_wrapper.v
input [127:0]           etr_axi_rdata;          // To trace_wrapper_u0 of trace_wrapper.v
input [5:0]             etr_axi_rid;            // To trace_wrapper_u0 of trace_wrapper.v
input                   etr_axi_rlast;          // To trace_wrapper_u0 of trace_wrapper.v
input [1:0]             etr_axi_rresp;          // To trace_wrapper_u0 of trace_wrapper.v
input [15:0]            etr_axi_ruser;          // To trace_wrapper_u0 of trace_wrapper.v
input                   etr_axi_rvalid;         // To trace_wrapper_u0 of trace_wrapper.v
input                   etr_axi_wready;         // To trace_wrapper_u0 of trace_wrapper.v
input                   jtag_scr1_tdo;          // To dap_wrapper_u0 of dap_wrapper.v
input                   mid_funnel_atb_afready; // To trace_wrapper_u0 of trace_wrapper.v
input [3:0]             mid_funnel_atb_atbytes; // To trace_wrapper_u0 of trace_wrapper.v
input [127:0]           mid_funnel_atb_atdata;  // To trace_wrapper_u0 of trace_wrapper.v
input [6:0]             mid_funnel_atb_atid;    // To trace_wrapper_u0 of trace_wrapper.v
input                   mid_funnel_atb_atvalid; // To trace_wrapper_u0 of trace_wrapper.v
input                   mid_ntsr_nts_tssyncready;// To ts_gen_wrapper_u0 of ts_gen_wrapper.v
input                   pcie0_slice_atb_afready;// To trace_wrapper_u0 of trace_wrapper.v
input [3:0]             pcie0_slice_atb_atbytes;// To trace_wrapper_u0 of trace_wrapper.v
input [127:0]           pcie0_slice_atb_atdata; // To trace_wrapper_u0 of trace_wrapper.v
input [6:0]             pcie0_slice_atb_atid;   // To trace_wrapper_u0 of trace_wrapper.v
input                   pcie0_slice_atb_atvalid;// To trace_wrapper_u0 of trace_wrapper.v
input                   pcie1_slice_atb_afready;// To trace_wrapper_u0 of trace_wrapper.v
input [3:0]             pcie1_slice_atb_atbytes;// To trace_wrapper_u0 of trace_wrapper.v
input [127:0]           pcie1_slice_atb_atdata; // To trace_wrapper_u0 of trace_wrapper.v
input [6:0]             pcie1_slice_atb_atid;   // To trace_wrapper_u0 of trace_wrapper.v
input                   pcie1_slice_atb_atvalid;// To trace_wrapper_u0 of trace_wrapper.v
input [31:0]            pcie_cti_apb_prdata;    // To dap_wrapper_u0 of dap_wrapper.v
input                   pcie_cti_apb_pready;    // To dap_wrapper_u0 of dap_wrapper.v
input                   pcie_cti_apb_pslverr;   // To dap_wrapper_u0 of dap_wrapper.v
input                   pcie_nts_tssyncready_0; // To ts_gen_wrapper_u0 of ts_gen_wrapper.v
input                   pcie_nts_tssyncready_1; // To ts_gen_wrapper_u0 of ts_gen_wrapper.v
input [31:0]            sec_mid_apbic_apb_prdata;// To dap_wrapper_u0 of dap_wrapper.v
input                   sec_mid_apbic_apb_pready;// To dap_wrapper_u0 of dap_wrapper.v
input                   sec_mid_apbic_apb_pslverr;// To dap_wrapper_u0 of dap_wrapper.v
input [16:2]            swdbg_paddr;            // To dap_wrapper_u0 of dap_wrapper.v
input                   swdbg_penable;          // To dap_wrapper_u0 of dap_wrapper.v
input                   swdbg_psel;             // To dap_wrapper_u0 of dap_wrapper.v
input [31:0]            swdbg_pwdata;           // To dap_wrapper_u0 of dap_wrapper.v
input                   swdbg_pwrite;           // To dap_wrapper_u0 of dap_wrapper.v
input                   swjdp_npotrst;          // To dap_wrapper_u0 of dap_wrapper.v
input                   trace_clk;              // To trace_wrapper_u0 of trace_wrapper.v
input                   trace_rstn;             // To trace_wrapper_u0 of trace_wrapper.v
input                   tscenter_hltdbg;        // To ts_gen_wrapper_u0 of ts_gen_wrapper.v
input [31:0]            vpu0_cti_apb_prdata;    // To dap_wrapper_u0 of dap_wrapper.v
input                   vpu0_cti_apb_pready;    // To dap_wrapper_u0 of dap_wrapper.v
input                   vpu0_cti_apb_pslverr;   // To dap_wrapper_u0 of dap_wrapper.v
input                   vpu0_dec_nts_tssyncready;// To ts_gen_wrapper_u0 of ts_gen_wrapper.v
input                   vpu0_funnel_slice_atb_afready;// To trace_wrapper_u0 of trace_wrapper.v
input [3:0]             vpu0_funnel_slice_atb_atbytes;// To trace_wrapper_u0 of trace_wrapper.v
input [127:0]           vpu0_funnel_slice_atb_atdata;// To trace_wrapper_u0 of trace_wrapper.v
input [6:0]             vpu0_funnel_slice_atb_atid;// To trace_wrapper_u0 of trace_wrapper.v
input                   vpu0_funnel_slice_atb_atvalid;// To trace_wrapper_u0 of trace_wrapper.v
input                   vpu0_jpeg0_nts_tssyncready;// To ts_gen_wrapper_u0 of ts_gen_wrapper.v
input                   vpu0_jpeg1_nts_tssyncready;// To ts_gen_wrapper_u0 of ts_gen_wrapper.v
input [31:0]            vpu1_cti_apb_prdata;    // To dap_wrapper_u0 of dap_wrapper.v
input                   vpu1_cti_apb_pready;    // To dap_wrapper_u0 of dap_wrapper.v
input                   vpu1_cti_apb_pslverr;   // To dap_wrapper_u0 of dap_wrapper.v
input                   vpu1_dec_nts_tssyncready;// To ts_gen_wrapper_u0 of ts_gen_wrapper.v
input                   vpu1_funnel_slice_atb_afready;// To trace_wrapper_u0 of trace_wrapper.v
input [3:0]             vpu1_funnel_slice_atb_atbytes;// To trace_wrapper_u0 of trace_wrapper.v
input [127:0]           vpu1_funnel_slice_atb_atdata;// To trace_wrapper_u0 of trace_wrapper.v
input [6:0]             vpu1_funnel_slice_atb_atid;// To trace_wrapper_u0 of trace_wrapper.v
input                   vpu1_funnel_slice_atb_atvalid;// To trace_wrapper_u0 of trace_wrapper.v
input                   vpu1_jpeg0_nts_tssyncready;// To ts_gen_wrapper_u0 of ts_gen_wrapper.v
input                   vpu1_jpeg1_nts_tssyncready;// To ts_gen_wrapper_u0 of ts_gen_wrapper.v
// End of automatics
/*autooutput*/
// Beginning of automatic outputs (from unused autoinst outputs)
output                  apbap_dbgswen;          // From dap_wrapper_u0 of dap_wrapper.v
output [31:0]           atb_formatter_btm_pcie_r0_fr_reg;// From dap_wrapper_u0 of dap_wrapper.v
output [31:0]           atb_formatter_btm_pcie_r1_fr_reg;// From dap_wrapper_u0 of dap_wrapper.v
output [31:0]           atb_formatter_ctrl_scp_fr_reg;// From dap_wrapper_u0 of dap_wrapper.v
output [31:0]           atb_formatter_up_ualink0_fr_reg;// From dap_wrapper_u0 of dap_wrapper.v
output [31:0]           atb_formatter_up_ualink1_fr_reg;// From dap_wrapper_u0 of dap_wrapper.v
output [31:0]           atb_formatter_vpu0_jpeg0_fr_reg;// From dap_wrapper_u0 of dap_wrapper.v
output [31:0]           atb_formatter_vpu0_jpeg1_fr_reg;// From dap_wrapper_u0 of dap_wrapper.v
output [31:0]           atb_formatter_vpu0_vdec_fr_reg;// From dap_wrapper_u0 of dap_wrapper.v
output [31:0]           atb_formatter_vpu1_jpeg0_fr_reg;// From dap_wrapper_u0 of dap_wrapper.v
output [31:0]           atb_formatter_vpu1_jpeg1_fr_reg;// From dap_wrapper_u0 of dap_wrapper.v
output [31:0]           atb_formatter_vpu1_vdec_fr_reg;// From dap_wrapper_u0 of dap_wrapper.v
output [63:0]           axiap_araddr;           // From dap_wrapper_u0 of dap_wrapper.v
output [1:0]            axiap_arburst;          // From dap_wrapper_u0 of dap_wrapper.v
output [3:0]            axiap_arcache;          // From dap_wrapper_u0 of dap_wrapper.v
output [7:0]            axiap_arlen;            // From dap_wrapper_u0 of dap_wrapper.v
output [2:0]            axiap_arprot;           // From dap_wrapper_u0 of dap_wrapper.v
output [2:0]            axiap_arsize;           // From dap_wrapper_u0 of dap_wrapper.v
output [31:0]           axiap_aruser;           // From dap_wrapper_u0 of dap_wrapper.v
output                  axiap_arvalid;          // From dap_wrapper_u0 of dap_wrapper.v
output [63:0]           axiap_awaddr;           // From dap_wrapper_u0 of dap_wrapper.v
output [1:0]            axiap_awburst;          // From dap_wrapper_u0 of dap_wrapper.v
output [3:0]            axiap_awcache;          // From dap_wrapper_u0 of dap_wrapper.v
output [7:0]            axiap_awlen;            // From dap_wrapper_u0 of dap_wrapper.v
output [2:0]            axiap_awprot;           // From dap_wrapper_u0 of dap_wrapper.v
output [2:0]            axiap_awsize;           // From dap_wrapper_u0 of dap_wrapper.v
output [31:0]           axiap_awuser;           // From dap_wrapper_u0 of dap_wrapper.v
output                  axiap_awvalid;          // From dap_wrapper_u0 of dap_wrapper.v
output                  axiap_bready;           // From dap_wrapper_u0 of dap_wrapper.v
output                  axiap_rready;           // From dap_wrapper_u0 of dap_wrapper.v
output [31:0]           axiap_wdata;            // From dap_wrapper_u0 of dap_wrapper.v
output                  axiap_wlast;            // From dap_wrapper_u0 of dap_wrapper.v
output [3:0]            axiap_wstrb;            // From dap_wrapper_u0 of dap_wrapper.v
output                  axiap_wvalid;           // From dap_wrapper_u0 of dap_wrapper.v
output [11:2]           cbus_btm_cti_apb_paddr; // From dap_wrapper_u0 of dap_wrapper.v
output                  cbus_btm_cti_apb_paddr31;// From dap_wrapper_u0 of dap_wrapper.v
output                  cbus_btm_cti_apb_penable;// From dap_wrapper_u0 of dap_wrapper.v
output                  cbus_btm_cti_apb_psel;  // From dap_wrapper_u0 of dap_wrapper.v
output [31:0]           cbus_btm_cti_apb_pwdata;// From dap_wrapper_u0 of dap_wrapper.v
output                  cbus_btm_cti_apb_pwrite;// From dap_wrapper_u0 of dap_wrapper.v
output [6:0]            cbus_btm_nts_tsbit;     // From ts_gen_wrapper_u0 of ts_gen_wrapper.v
output [1:0]            cbus_btm_nts_tssync;    // From ts_gen_wrapper_u0 of ts_gen_wrapper.v
output                  cbus_btm_slice_atb_afvalid;// From trace_wrapper_u0 of trace_wrapper.v
output                  cbus_btm_slice_atb_atready;// From trace_wrapper_u0 of trace_wrapper.v
output                  cbus_btm_slice_atb_syncreq;// From trace_wrapper_u0 of trace_wrapper.v
output                  cs_jtag_ntdoen;         // From dap_wrapper_u0 of dap_wrapper.v
output                  cs_jtag_tdo;            // From dap_wrapper_u0 of dap_wrapper.v
output [3:0]            cxctm0_ctmchinack2;     // From trace_wrapper_u0 of trace_wrapper.v
output [3:0]            cxctm0_ctmchinack3;     // From trace_wrapper_u0 of trace_wrapper.v
output [3:0]            cxctm0_ctmchout2;       // From trace_wrapper_u0 of trace_wrapper.v
output [3:0]            cxctm0_ctmchout3;       // From trace_wrapper_u0 of trace_wrapper.v
output [11:2]           dbus_btm_cti_apb_paddr; // From dap_wrapper_u0 of dap_wrapper.v
output                  dbus_btm_cti_apb_paddr31;// From dap_wrapper_u0 of dap_wrapper.v
output                  dbus_btm_cti_apb_penable;// From dap_wrapper_u0 of dap_wrapper.v
output                  dbus_btm_cti_apb_psel;  // From dap_wrapper_u0 of dap_wrapper.v
output [31:0]           dbus_btm_cti_apb_pwdata;// From dap_wrapper_u0 of dap_wrapper.v
output                  dbus_btm_cti_apb_pwrite;// From dap_wrapper_u0 of dap_wrapper.v
output [6:0]            dbus_btm_nts_tsbit;     // From ts_gen_wrapper_u0 of ts_gen_wrapper.v
output [1:0]            dbus_btm_nts_tssync;    // From ts_gen_wrapper_u0 of ts_gen_wrapper.v
output                  dbus_btm_slice_atb_afvalid;// From trace_wrapper_u0 of trace_wrapper.v
output                  dbus_btm_slice_atb_atready;// From trace_wrapper_u0 of trace_wrapper.v
output                  dbus_btm_slice_atb_syncreq;// From trace_wrapper_u0 of trace_wrapper.v
output                  etf_etr_interrupt;      // From trace_wrapper_u0 of trace_wrapper.v
output [51:0]           etr_axi_araddr;         // From trace_wrapper_u0 of trace_wrapper.v
output [1:0]            etr_axi_arburst;        // From trace_wrapper_u0 of trace_wrapper.v
output [3:0]            etr_axi_arcache;        // From trace_wrapper_u0 of trace_wrapper.v
output [5:0]            etr_axi_arid;           // From trace_wrapper_u0 of trace_wrapper.v
output [3:0]            etr_axi_arlen;          // From trace_wrapper_u0 of trace_wrapper.v
output                  etr_axi_arlock;         // From trace_wrapper_u0 of trace_wrapper.v
output [2:0]            etr_axi_arprot;         // From trace_wrapper_u0 of trace_wrapper.v
output [3:0]            etr_axi_arqos;          // From trace_wrapper_u0 of trace_wrapper.v
output [2:0]            etr_axi_arsize;         // From trace_wrapper_u0 of trace_wrapper.v
output [15:0]           etr_axi_aruser;         // From trace_wrapper_u0 of trace_wrapper.v
output                  etr_axi_arvalid;        // From trace_wrapper_u0 of trace_wrapper.v
output [51:0]           etr_axi_awaddr;         // From trace_wrapper_u0 of trace_wrapper.v
output [1:0]            etr_axi_awburst;        // From trace_wrapper_u0 of trace_wrapper.v
output [3:0]            etr_axi_awcache;        // From trace_wrapper_u0 of trace_wrapper.v
output [5:0]            etr_axi_awid;           // From trace_wrapper_u0 of trace_wrapper.v
output [3:0]            etr_axi_awlen;          // From trace_wrapper_u0 of trace_wrapper.v
output                  etr_axi_awlock;         // From trace_wrapper_u0 of trace_wrapper.v
output [2:0]            etr_axi_awprot;         // From trace_wrapper_u0 of trace_wrapper.v
output [3:0]            etr_axi_awqos;          // From trace_wrapper_u0 of trace_wrapper.v
output [2:0]            etr_axi_awsize;         // From trace_wrapper_u0 of trace_wrapper.v
output [15:0]           etr_axi_awuser;         // From trace_wrapper_u0 of trace_wrapper.v
output                  etr_axi_awvalid;        // From trace_wrapper_u0 of trace_wrapper.v
output                  etr_axi_bready;         // From trace_wrapper_u0 of trace_wrapper.v
output                  etr_axi_rready;         // From trace_wrapper_u0 of trace_wrapper.v
output [127:0]          etr_axi_wdata;          // From trace_wrapper_u0 of trace_wrapper.v
output                  etr_axi_wlast;          // From trace_wrapper_u0 of trace_wrapper.v
output [15:0]           etr_axi_wstrb;          // From trace_wrapper_u0 of trace_wrapper.v
output                  etr_axi_wvalid;         // From trace_wrapper_u0 of trace_wrapper.v
output                  jtag_scr1_tck;          // From dap_wrapper_u0 of dap_wrapper.v
output                  jtag_scr1_tdi;          // From dap_wrapper_u0 of dap_wrapper.v
output                  jtag_scr1_tms;          // From dap_wrapper_u0 of dap_wrapper.v
output                  jtag_scr1_trst_n;       // From dap_wrapper_u0 of dap_wrapper.v
output                  mid_funnel_atb_afvalid; // From trace_wrapper_u0 of trace_wrapper.v
output                  mid_funnel_atb_atready; // From trace_wrapper_u0 of trace_wrapper.v
output                  mid_funnel_atb_syncreq; // From trace_wrapper_u0 of trace_wrapper.v
output [6:0]            mid_ntsr_nts_tsbit;     // From ts_gen_wrapper_u0 of ts_gen_wrapper.v
output [1:0]            mid_ntsr_nts_tssync;    // From ts_gen_wrapper_u0 of ts_gen_wrapper.v
output                  pcie0_slice_atb_afvalid;// From trace_wrapper_u0 of trace_wrapper.v
output                  pcie0_slice_atb_atready;// From trace_wrapper_u0 of trace_wrapper.v
output                  pcie0_slice_atb_syncreq;// From trace_wrapper_u0 of trace_wrapper.v
output                  pcie1_slice_atb_afvalid;// From trace_wrapper_u0 of trace_wrapper.v
output                  pcie1_slice_atb_atready;// From trace_wrapper_u0 of trace_wrapper.v
output                  pcie1_slice_atb_syncreq;// From trace_wrapper_u0 of trace_wrapper.v
output [11:2]           pcie_cti_apb_paddr;     // From dap_wrapper_u0 of dap_wrapper.v
output                  pcie_cti_apb_paddr31;   // From dap_wrapper_u0 of dap_wrapper.v
output                  pcie_cti_apb_penable;   // From dap_wrapper_u0 of dap_wrapper.v
output                  pcie_cti_apb_psel;      // From dap_wrapper_u0 of dap_wrapper.v
output [31:0]           pcie_cti_apb_pwdata;    // From dap_wrapper_u0 of dap_wrapper.v
output                  pcie_cti_apb_pwrite;    // From dap_wrapper_u0 of dap_wrapper.v
output [6:0]            pcie_nts_tsbit_0;       // From ts_gen_wrapper_u0 of ts_gen_wrapper.v
output [6:0]            pcie_nts_tsbit_1;       // From ts_gen_wrapper_u0 of ts_gen_wrapper.v
output [1:0]            pcie_nts_tssync_0;      // From ts_gen_wrapper_u0 of ts_gen_wrapper.v
output [1:0]            pcie_nts_tssync_1;      // From ts_gen_wrapper_u0 of ts_gen_wrapper.v
output [1:0]            reg_coresight_clk_sel;  // From dap_wrapper_u0 of dap_wrapper.v
output [2:0]            reg_coresight_freqdiv;  // From dap_wrapper_u0 of dap_wrapper.v
output [15:2]           sec_mid_apbic_apb_paddr;// From dap_wrapper_u0 of dap_wrapper.v
output                  sec_mid_apbic_apb_paddr31;// From dap_wrapper_u0 of dap_wrapper.v
output                  sec_mid_apbic_apb_penable;// From dap_wrapper_u0 of dap_wrapper.v
output                  sec_mid_apbic_apb_psel; // From dap_wrapper_u0 of dap_wrapper.v
output [31:0]           sec_mid_apbic_apb_pwdata;// From dap_wrapper_u0 of dap_wrapper.v
output                  sec_mid_apbic_apb_pwrite;// From dap_wrapper_u0 of dap_wrapper.v
output [31:0]           swdbg_prdata;           // From dap_wrapper_u0 of dap_wrapper.v
output                  swdbg_pready;           // From dap_wrapper_u0 of dap_wrapper.v
output                  swdbg_pslverr;          // From dap_wrapper_u0 of dap_wrapper.v
output [11:2]           vpu0_cti_apb_paddr;     // From dap_wrapper_u0 of dap_wrapper.v
output                  vpu0_cti_apb_paddr31;   // From dap_wrapper_u0 of dap_wrapper.v
output                  vpu0_cti_apb_penable;   // From dap_wrapper_u0 of dap_wrapper.v
output                  vpu0_cti_apb_psel;      // From dap_wrapper_u0 of dap_wrapper.v
output [31:0]           vpu0_cti_apb_pwdata;    // From dap_wrapper_u0 of dap_wrapper.v
output                  vpu0_cti_apb_pwrite;    // From dap_wrapper_u0 of dap_wrapper.v
output [6:0]            vpu0_dec_nts_tsbit;     // From ts_gen_wrapper_u0 of ts_gen_wrapper.v
output [1:0]            vpu0_dec_nts_tssync;    // From ts_gen_wrapper_u0 of ts_gen_wrapper.v
output                  vpu0_funnel_slice_atb_afvalid;// From trace_wrapper_u0 of trace_wrapper.v
output                  vpu0_funnel_slice_atb_atready;// From trace_wrapper_u0 of trace_wrapper.v
output                  vpu0_funnel_slice_atb_syncreq;// From trace_wrapper_u0 of trace_wrapper.v
output [6:0]            vpu0_jpeg0_nts_tsbit;   // From ts_gen_wrapper_u0 of ts_gen_wrapper.v
output [1:0]            vpu0_jpeg0_nts_tssync;  // From ts_gen_wrapper_u0 of ts_gen_wrapper.v
output [6:0]            vpu0_jpeg1_nts_tsbit;   // From ts_gen_wrapper_u0 of ts_gen_wrapper.v
output [1:0]            vpu0_jpeg1_nts_tssync;  // From ts_gen_wrapper_u0 of ts_gen_wrapper.v
output [11:2]           vpu1_cti_apb_paddr;     // From dap_wrapper_u0 of dap_wrapper.v
output                  vpu1_cti_apb_paddr31;   // From dap_wrapper_u0 of dap_wrapper.v
output                  vpu1_cti_apb_penable;   // From dap_wrapper_u0 of dap_wrapper.v
output                  vpu1_cti_apb_psel;      // From dap_wrapper_u0 of dap_wrapper.v
output [31:0]           vpu1_cti_apb_pwdata;    // From dap_wrapper_u0 of dap_wrapper.v
output                  vpu1_cti_apb_pwrite;    // From dap_wrapper_u0 of dap_wrapper.v
output [6:0]            vpu1_dec_nts_tsbit;     // From ts_gen_wrapper_u0 of ts_gen_wrapper.v
output [1:0]            vpu1_dec_nts_tssync;    // From ts_gen_wrapper_u0 of ts_gen_wrapper.v
output                  vpu1_funnel_slice_atb_afvalid;// From trace_wrapper_u0 of trace_wrapper.v
output                  vpu1_funnel_slice_atb_atready;// From trace_wrapper_u0 of trace_wrapper.v
output                  vpu1_funnel_slice_atb_syncreq;// From trace_wrapper_u0 of trace_wrapper.v
output [6:0]            vpu1_jpeg0_nts_tsbit;   // From ts_gen_wrapper_u0 of ts_gen_wrapper.v
output [1:0]            vpu1_jpeg0_nts_tssync;  // From ts_gen_wrapper_u0 of ts_gen_wrapper.v
output [6:0]            vpu1_jpeg1_nts_tsbit;   // From ts_gen_wrapper_u0 of ts_gen_wrapper.v
output [1:0]            vpu1_jpeg1_nts_tssync;  // From ts_gen_wrapper_u0 of ts_gen_wrapper.v
// End of automatics
/*autoinout*/
/*autoreg*/
/*autowire*/
// Beginning of automatic wires (for undeclared instantiated-module outputs)
wire [11:0]             apb1to2_paddrm1;        // From dap_wrapper_u0 of dap_wrapper.v
wire                    apb1to2_penablem1;      // From dap_wrapper_u0 of dap_wrapper.v
wire [31:0]             apb1to2_prdatam1;       // From trace_wrapper_u0 of trace_wrapper.v
wire                    apb1to2_preadym1;       // From trace_wrapper_u0 of trace_wrapper.v
wire                    apb1to2_pselm1;         // From dap_wrapper_u0 of dap_wrapper.v
wire                    apb1to2_pslverrm1;      // From trace_wrapper_u0 of trace_wrapper.v
wire [31:0]             apb1to2_pwdatam1;       // From dap_wrapper_u0 of dap_wrapper.v
wire                    apb1to2_pwritem1;       // From dap_wrapper_u0 of dap_wrapper.v
wire                    apbic_paddr31_to_cti_etf;// From dap_wrapper_u0 of dap_wrapper.v
wire                    apbic_paddr31_to_cti_etr;// From dap_wrapper_u0 of dap_wrapper.v
wire                    apbic_paddr31_to_etf;   // From dap_wrapper_u0 of dap_wrapper.v
wire                    apbic_paddr31_to_etr;   // From dap_wrapper_u0 of dap_wrapper.v
wire                    apbic_paddr31_to_funnel;// From dap_wrapper_u0 of dap_wrapper.v
wire [11:2]             apbic_paddr_to_cti_etf; // From dap_wrapper_u0 of dap_wrapper.v
wire [11:2]             apbic_paddr_to_cti_etr; // From dap_wrapper_u0 of dap_wrapper.v
wire [11:2]             apbic_paddr_to_etf;     // From dap_wrapper_u0 of dap_wrapper.v
wire [11:2]             apbic_paddr_to_etr;     // From dap_wrapper_u0 of dap_wrapper.v
wire [11:2]             apbic_paddr_to_funnel;  // From dap_wrapper_u0 of dap_wrapper.v
wire                    apbic_penable_to_cti_etf;// From dap_wrapper_u0 of dap_wrapper.v
wire                    apbic_penable_to_cti_etr;// From dap_wrapper_u0 of dap_wrapper.v
wire                    apbic_penable_to_etf;   // From dap_wrapper_u0 of dap_wrapper.v
wire                    apbic_penable_to_etr;   // From dap_wrapper_u0 of dap_wrapper.v
wire                    apbic_penable_to_funnel;// From dap_wrapper_u0 of dap_wrapper.v
wire [31:0]             apbic_prdata_to_cti_etf;// From trace_wrapper_u0 of trace_wrapper.v
wire [31:0]             apbic_prdata_to_cti_etr;// From trace_wrapper_u0 of trace_wrapper.v
wire [31:0]             apbic_prdata_to_etf;    // From trace_wrapper_u0 of trace_wrapper.v
wire [31:0]             apbic_prdata_to_etr;    // From trace_wrapper_u0 of trace_wrapper.v
wire [31:0]             apbic_prdata_to_funnel; // From trace_wrapper_u0 of trace_wrapper.v
wire                    apbic_pready_to_cti_etf;// From trace_wrapper_u0 of trace_wrapper.v
wire                    apbic_pready_to_cti_etr;// From trace_wrapper_u0 of trace_wrapper.v
wire                    apbic_pready_to_etf;    // From trace_wrapper_u0 of trace_wrapper.v
wire                    apbic_pready_to_etr;    // From trace_wrapper_u0 of trace_wrapper.v
wire                    apbic_pready_to_funnel; // From trace_wrapper_u0 of trace_wrapper.v
wire                    apbic_psel_to_cti_etf;  // From dap_wrapper_u0 of dap_wrapper.v
wire                    apbic_psel_to_cti_etr;  // From dap_wrapper_u0 of dap_wrapper.v
wire                    apbic_psel_to_etf;      // From dap_wrapper_u0 of dap_wrapper.v
wire                    apbic_psel_to_etr;      // From dap_wrapper_u0 of dap_wrapper.v
wire                    apbic_psel_to_funnel;   // From dap_wrapper_u0 of dap_wrapper.v
wire                    apbic_pslverr_to_etf;   // From trace_wrapper_u0 of trace_wrapper.v
wire                    apbic_pslverr_to_etr;   // From trace_wrapper_u0 of trace_wrapper.v
wire                    apbic_pslverr_to_funnel;// From trace_wrapper_u0 of trace_wrapper.v
wire [31:0]             apbic_pwdata_to_cti_etf;// From dap_wrapper_u0 of dap_wrapper.v
wire [31:0]             apbic_pwdata_to_cti_etr;// From dap_wrapper_u0 of dap_wrapper.v
wire [31:0]             apbic_pwdata_to_etf;    // From dap_wrapper_u0 of dap_wrapper.v
wire [31:0]             apbic_pwdata_to_etr;    // From dap_wrapper_u0 of dap_wrapper.v
wire [31:0]             apbic_pwdata_to_funnel; // From dap_wrapper_u0 of dap_wrapper.v
wire                    apbic_pwrite_to_cti_etf;// From dap_wrapper_u0 of dap_wrapper.v
wire                    apbic_pwrite_to_cti_etr;// From dap_wrapper_u0 of dap_wrapper.v
wire                    apbic_pwrite_to_etf;    // From dap_wrapper_u0 of dap_wrapper.v
wire                    apbic_pwrite_to_etr;    // From dap_wrapper_u0 of dap_wrapper.v
wire                    apbic_pwrite_to_funnel; // From dap_wrapper_u0 of dap_wrapper.v
wire                    cs_jtag_ntrst_sync;     // From jtag_reset_sync of reset_sync_dft.v
wire [11:2]             cxtsgen_paddrctrl;      // From dap_wrapper_u0 of dap_wrapper.v
wire                    cxtsgen_penablectrl;    // From dap_wrapper_u0 of dap_wrapper.v
wire [31:0]             cxtsgen_prdatactrl;     // From ts_gen_wrapper_u0 of ts_gen_wrapper.v
wire                    cxtsgen_preadyctrl;     // From ts_gen_wrapper_u0 of ts_gen_wrapper.v
wire                    cxtsgen_pselctrl;       // From dap_wrapper_u0 of dap_wrapper.v
wire                    cxtsgen_pslverrctrl;    // From ts_gen_wrapper_u0 of ts_gen_wrapper.v
wire [31:0]             cxtsgen_pwdatactrl;     // From dap_wrapper_u0 of dap_wrapper.v
wire                    cxtsgen_pwritectrl;     // From dap_wrapper_u0 of dap_wrapper.v
wire [10:0]             etr_addr_h11_fr_reg;    // From dap_wrapper_u0 of dap_wrapper.v
wire [3:0]              etr_arqos_fr_reg;       // From dap_wrapper_u0 of dap_wrapper.v
wire [15:0]             etr_aruser_fr_reg;      // From dap_wrapper_u0 of dap_wrapper.v
wire [3:0]              etr_awqos_fr_reg;       // From dap_wrapper_u0 of dap_wrapper.v
wire [15:0]             etr_awuser_fr_reg;      // From dap_wrapper_u0 of dap_wrapper.v
// End of automatics

/*reset_sync_dft auto_template(
    
    .dft_test_mode              (dft_test_mode      ),
    .dft_test_rstn              (cs_jtag_ntrst      ),

    .rst_n                      (cs_jtag_ntrst      ),
    .clk                        (cs_jtag_tck        ),
    .rst_n_sync                 (cs_jtag_ntrst_sync ),
    );
*/

reset_sync_dft #(.ADD_BEATS(0)) jtag_reset_sync ( /*autoinst*/
                                                 // Outputs
                                                 .rst_n_sync            (cs_jtag_ntrst_sync ), // Templated
                                                 // Inputs
                                                 .dft_test_mode         (dft_test_mode      ), // Templated
                                                 .dft_test_rstn         (cs_jtag_ntrst      ), // Templated
                                                 .rst_n                 (cs_jtag_ntrst      ), // Templated
                                                 .clk                   (cs_jtag_tck        )); // Templated





/*
   dap_wrapper auto_template (

        .\(axiap_.*\)_fr_reg      (\1[]),
        .\(axiap_.*\)_to_reg      (\1[]),
        .cs_jtag_ntrst          (cs_jtag_ntrst_sync),

        .apbic_pslverrm5        (1'b0),
        .apbic_pslverrm6        (1'b0),
        .apbic_paddr31m4        (),

        .apbic_p\(.*\)m1    (apbic_p\1_to_funnel[]),
        .apbic_p\(.*\)m2    (apbic_p\1_to_etf[]),
        .apbic_p\(.*\)m3    (apbic_p\1_to_etr[]),
        .apbic_p\(.*\)m4    (cxtsgen_p\1ctrl[]),
        .apbic_p\(.*\)m5    (apbic_p\1_to_cti_etf[]),
        .apbic_p\(.*\)m6    (apbic_p\1_to_cti_etr[]),
        //.apbic_p\(.*\)m7      (pcie_funnel_apb_p\1[]),
        .apbic_p\(.*\)m7      (pcie_cti_apb_p\1[]),
        //.apbic_p\(.*\)m9      (scp_cti_apb_p\1[]),
        .apbic_p\(.*\)m8     (dbus_btm_cti_apb_p\1[]),
        .apbic_p\(.*\)m9     (cbus_btm_cti_apb_p\1[]),
        .apbic_p\(.*\)m10     (vpu0_cti_apb_p\1[]),
        .apbic_p\(.*\)m11     (vpu1_cti_apb_p\1[]),
        .apbic_p\(addr\)m12   (sec_mid_apbic_apb_p\1[15:2]),
        .apbic_p\(.*\)m12     (sec_mid_apbic_apb_p\1[]),
        .apbic_p\(.*ready.*\)m.*     (@"(if (equal vl-dir \\"output\\") \\" \\" (concat \\"{\\" vl-width \\"{1'b1}}\\"))"),
        .apbic_p\(.*\)m.*     (@"(if (equal vl-dir \\"output\\") \\" \\" (concat \\"{\\" vl-width \\"{1'b0}}\\"))"),
        
   );
*/
dap_wrapper
dap_wrapper_u0 (/*autoinst*/
                // Outputs
                .jtag_scr1_tck          (jtag_scr1_tck),
                .apbap_dbgswen          (apbap_dbgswen),
                .apb1to2_paddrm1        (apb1to2_paddrm1[11:0]),
                .apb1to2_penablem1      (apb1to2_penablem1),
                .apb1to2_pselm1         (apb1to2_pselm1),
                .apb1to2_pwdatam1       (apb1to2_pwdatam1[31:0]),
                .apb1to2_pwritem1       (apb1to2_pwritem1),
                .apbic_paddr31m1        (apbic_paddr31_to_funnel), // Templated
                .apbic_paddr31m10       (vpu0_cti_apb_paddr31),  // Templated
                .apbic_paddr31m11       (vpu1_cti_apb_paddr31),  // Templated
                .apbic_paddr31m12       (sec_mid_apbic_apb_paddr31), // Templated
                .apbic_paddr31m2        (apbic_paddr31_to_etf),  // Templated
                .apbic_paddr31m3        (apbic_paddr31_to_etr),  // Templated
                .apbic_paddr31m4        (),                      // Templated
                .apbic_paddr31m5        (apbic_paddr31_to_cti_etf), // Templated
                .apbic_paddr31m6        (apbic_paddr31_to_cti_etr), // Templated
                .apbic_paddr31m7        (pcie_cti_apb_paddr31),  // Templated
                .apbic_paddr31m8        (dbus_btm_cti_apb_paddr31), // Templated
                .apbic_paddr31m9        (cbus_btm_cti_apb_paddr31), // Templated
                .apbic_paddrm1          (apbic_paddr_to_funnel[11:2]), // Templated
                .apbic_paddrm10         (vpu0_cti_apb_paddr[11:2]), // Templated
                .apbic_paddrm11         (vpu1_cti_apb_paddr[11:2]), // Templated
                .apbic_paddrm12         (sec_mid_apbic_apb_paddr[15:2]), // Templated
                .apbic_paddrm2          (apbic_paddr_to_etf[11:2]), // Templated
                .apbic_paddrm3          (apbic_paddr_to_etr[11:2]), // Templated
                .apbic_paddrm4          (cxtsgen_paddrctrl[11:2]), // Templated
                .apbic_paddrm5          (apbic_paddr_to_cti_etf[11:2]), // Templated
                .apbic_paddrm6          (apbic_paddr_to_cti_etr[11:2]), // Templated
                .apbic_paddrm7          (pcie_cti_apb_paddr[11:2]), // Templated
                .apbic_paddrm8          (dbus_btm_cti_apb_paddr[11:2]), // Templated
                .apbic_paddrm9          (cbus_btm_cti_apb_paddr[11:2]), // Templated
                .apbic_penablem1        (apbic_penable_to_funnel), // Templated
                .apbic_penablem10       (vpu0_cti_apb_penable),  // Templated
                .apbic_penablem11       (vpu1_cti_apb_penable),  // Templated
                .apbic_penablem12       (sec_mid_apbic_apb_penable), // Templated
                .apbic_penablem2        (apbic_penable_to_etf),  // Templated
                .apbic_penablem3        (apbic_penable_to_etr),  // Templated
                .apbic_penablem4        (cxtsgen_penablectrl),   // Templated
                .apbic_penablem5        (apbic_penable_to_cti_etf), // Templated
                .apbic_penablem6        (apbic_penable_to_cti_etr), // Templated
                .apbic_penablem7        (pcie_cti_apb_penable),  // Templated
                .apbic_penablem8        (dbus_btm_cti_apb_penable), // Templated
                .apbic_penablem9        (cbus_btm_cti_apb_penable), // Templated
                .apbic_pselm1           (apbic_psel_to_funnel),  // Templated
                .apbic_pselm10          (vpu0_cti_apb_psel),     // Templated
                .apbic_pselm11          (vpu1_cti_apb_psel),     // Templated
                .apbic_pselm12          (sec_mid_apbic_apb_psel), // Templated
                .apbic_pselm2           (apbic_psel_to_etf),     // Templated
                .apbic_pselm3           (apbic_psel_to_etr),     // Templated
                .apbic_pselm4           (cxtsgen_pselctrl),      // Templated
                .apbic_pselm5           (apbic_psel_to_cti_etf), // Templated
                .apbic_pselm6           (apbic_psel_to_cti_etr), // Templated
                .apbic_pselm7           (pcie_cti_apb_psel),     // Templated
                .apbic_pselm8           (dbus_btm_cti_apb_psel), // Templated
                .apbic_pselm9           (cbus_btm_cti_apb_psel), // Templated
                .apbic_pwdatam1         (apbic_pwdata_to_funnel[31:0]), // Templated
                .apbic_pwdatam10        (vpu0_cti_apb_pwdata[31:0]), // Templated
                .apbic_pwdatam11        (vpu1_cti_apb_pwdata[31:0]), // Templated
                .apbic_pwdatam12        (sec_mid_apbic_apb_pwdata[31:0]), // Templated
                .apbic_pwdatam2         (apbic_pwdata_to_etf[31:0]), // Templated
                .apbic_pwdatam3         (apbic_pwdata_to_etr[31:0]), // Templated
                .apbic_pwdatam4         (cxtsgen_pwdatactrl[31:0]), // Templated
                .apbic_pwdatam5         (apbic_pwdata_to_cti_etf[31:0]), // Templated
                .apbic_pwdatam6         (apbic_pwdata_to_cti_etr[31:0]), // Templated
                .apbic_pwdatam7         (pcie_cti_apb_pwdata[31:0]), // Templated
                .apbic_pwdatam8         (dbus_btm_cti_apb_pwdata[31:0]), // Templated
                .apbic_pwdatam9         (cbus_btm_cti_apb_pwdata[31:0]), // Templated
                .apbic_pwritem1         (apbic_pwrite_to_funnel), // Templated
                .apbic_pwritem10        (vpu0_cti_apb_pwrite),   // Templated
                .apbic_pwritem11        (vpu1_cti_apb_pwrite),   // Templated
                .apbic_pwritem12        (sec_mid_apbic_apb_pwrite), // Templated
                .apbic_pwritem2         (apbic_pwrite_to_etf),   // Templated
                .apbic_pwritem3         (apbic_pwrite_to_etr),   // Templated
                .apbic_pwritem4         (cxtsgen_pwritectrl),    // Templated
                .apbic_pwritem5         (apbic_pwrite_to_cti_etf), // Templated
                .apbic_pwritem6         (apbic_pwrite_to_cti_etr), // Templated
                .apbic_pwritem7         (pcie_cti_apb_pwrite),   // Templated
                .apbic_pwritem8         (dbus_btm_cti_apb_pwrite), // Templated
                .apbic_pwritem9         (cbus_btm_cti_apb_pwrite), // Templated
                .atb_formatter_btm_pcie_r0_fr_reg(atb_formatter_btm_pcie_r0_fr_reg[31:0]),
                .atb_formatter_btm_pcie_r1_fr_reg(atb_formatter_btm_pcie_r1_fr_reg[31:0]),
                .atb_formatter_ctrl_scp_fr_reg(atb_formatter_ctrl_scp_fr_reg[31:0]),
                .atb_formatter_up_ualink0_fr_reg(atb_formatter_up_ualink0_fr_reg[31:0]),
                .atb_formatter_up_ualink1_fr_reg(atb_formatter_up_ualink1_fr_reg[31:0]),
                .atb_formatter_vpu0_jpeg0_fr_reg(atb_formatter_vpu0_jpeg0_fr_reg[31:0]),
                .atb_formatter_vpu0_jpeg1_fr_reg(atb_formatter_vpu0_jpeg1_fr_reg[31:0]),
                .atb_formatter_vpu0_vdec_fr_reg(atb_formatter_vpu0_vdec_fr_reg[31:0]),
                .atb_formatter_vpu1_jpeg0_fr_reg(atb_formatter_vpu1_jpeg0_fr_reg[31:0]),
                .atb_formatter_vpu1_jpeg1_fr_reg(atb_formatter_vpu1_jpeg1_fr_reg[31:0]),
                .atb_formatter_vpu1_vdec_fr_reg(atb_formatter_vpu1_vdec_fr_reg[31:0]),
                .axiap_araddr           (axiap_araddr[63:0]),
                .axiap_arburst          (axiap_arburst[1:0]),
                .axiap_arcache          (axiap_arcache[3:0]),
                .axiap_arlen            (axiap_arlen[7:0]),
                .axiap_arprot           (axiap_arprot[2:0]),
                .axiap_arsize           (axiap_arsize[2:0]),
                .axiap_aruser_fr_reg    (axiap_aruser[31:0]),    // Templated
                .axiap_arvalid          (axiap_arvalid),
                .axiap_awaddr           (axiap_awaddr[63:0]),
                .axiap_awburst          (axiap_awburst[1:0]),
                .axiap_awcache          (axiap_awcache[3:0]),
                .axiap_awlen            (axiap_awlen[7:0]),
                .axiap_awprot           (axiap_awprot[2:0]),
                .axiap_awsize           (axiap_awsize[2:0]),
                .axiap_awuser_fr_reg    (axiap_awuser[31:0]),    // Templated
                .axiap_awvalid          (axiap_awvalid),
                .axiap_bready           (axiap_bready),
                .axiap_rready           (axiap_rready),
                .axiap_wdata            (axiap_wdata[31:0]),
                .axiap_wlast            (axiap_wlast),
                .axiap_wstrb            (axiap_wstrb[3:0]),
                .axiap_wvalid           (axiap_wvalid),
                .cs_jtag_ntdoen         (cs_jtag_ntdoen),
                .cs_jtag_tdo            (cs_jtag_tdo),
                .etr_addr_h11_fr_reg    (etr_addr_h11_fr_reg[10:0]),
                .etr_arqos_fr_reg       (etr_arqos_fr_reg[3:0]),
                .etr_aruser_fr_reg      (etr_aruser_fr_reg[15:0]),
                .etr_awqos_fr_reg       (etr_awqos_fr_reg[3:0]),
                .etr_awuser_fr_reg      (etr_awuser_fr_reg[15:0]),
                .jtag_scr1_tdi          (jtag_scr1_tdi),
                .jtag_scr1_tms          (jtag_scr1_tms),
                .jtag_scr1_trst_n       (jtag_scr1_trst_n),
                .reg_coresight_clk_sel  (reg_coresight_clk_sel[1:0]),
                .reg_coresight_freqdiv  (reg_coresight_freqdiv[2:0]),
                .swdbg_prdata           (swdbg_prdata[31:0]),
                .swdbg_pready           (swdbg_pready),
                .swdbg_pslverr          (swdbg_pslverr),
                // Inputs
                .apb1to2_prdatam1       (apb1to2_prdatam1[31:0]),
                .apb1to2_preadym1       (apb1to2_preadym1),
                .apb1to2_pslverrm1      (apb1to2_pslverrm1),
                .apbic_prdatam1         (apbic_prdata_to_funnel[31:0]), // Templated
                .apbic_prdatam10        (vpu0_cti_apb_prdata[31:0]), // Templated
                .apbic_prdatam11        (vpu1_cti_apb_prdata[31:0]), // Templated
                .apbic_prdatam12        (sec_mid_apbic_apb_prdata[31:0]), // Templated
                .apbic_prdatam2         (apbic_prdata_to_etf[31:0]), // Templated
                .apbic_prdatam3         (apbic_prdata_to_etr[31:0]), // Templated
                .apbic_prdatam4         (cxtsgen_prdatactrl[31:0]), // Templated
                .apbic_prdatam5         (apbic_prdata_to_cti_etf[31:0]), // Templated
                .apbic_prdatam6         (apbic_prdata_to_cti_etr[31:0]), // Templated
                .apbic_prdatam7         (pcie_cti_apb_prdata[31:0]), // Templated
                .apbic_prdatam8         (dbus_btm_cti_apb_prdata[31:0]), // Templated
                .apbic_prdatam9         (cbus_btm_cti_apb_prdata[31:0]), // Templated
                .apbic_preadym1         (apbic_pready_to_funnel), // Templated
                .apbic_preadym10        (vpu0_cti_apb_pready),   // Templated
                .apbic_preadym11        (vpu1_cti_apb_pready),   // Templated
                .apbic_preadym12        (sec_mid_apbic_apb_pready), // Templated
                .apbic_preadym2         (apbic_pready_to_etf),   // Templated
                .apbic_preadym3         (apbic_pready_to_etr),   // Templated
                .apbic_preadym4         (cxtsgen_preadyctrl),    // Templated
                .apbic_preadym5         (apbic_pready_to_cti_etf), // Templated
                .apbic_preadym6         (apbic_pready_to_cti_etr), // Templated
                .apbic_preadym7         (pcie_cti_apb_pready),   // Templated
                .apbic_preadym8         (dbus_btm_cti_apb_pready), // Templated
                .apbic_preadym9         (cbus_btm_cti_apb_pready), // Templated
                .apbic_pslverrm1        (apbic_pslverr_to_funnel), // Templated
                .apbic_pslverrm10       (vpu0_cti_apb_pslverr),  // Templated
                .apbic_pslverrm11       (vpu1_cti_apb_pslverr),  // Templated
                .apbic_pslverrm12       (sec_mid_apbic_apb_pslverr), // Templated
                .apbic_pslverrm2        (apbic_pslverr_to_etf),  // Templated
                .apbic_pslverrm3        (apbic_pslverr_to_etr),  // Templated
                .apbic_pslverrm4        (cxtsgen_pslverrctrl),   // Templated
                .apbic_pslverrm5        (1'b0),                  // Templated
                .apbic_pslverrm6        (1'b0),                  // Templated
                .apbic_pslverrm7        (pcie_cti_apb_pslverr),  // Templated
                .apbic_pslverrm8        (dbus_btm_cti_apb_pslverr), // Templated
                .apbic_pslverrm9        (cbus_btm_cti_apb_pslverr), // Templated
                .axiap_arready          (axiap_arready),
                .axiap_awready          (axiap_awready),
                .axiap_bresp            (axiap_bresp[1:0]),
                .axiap_bvalid           (axiap_bvalid),
                .axiap_rdata            (axiap_rdata[31:0]),
                .axiap_rlast            (axiap_rlast),
                .axiap_rresp            (axiap_rresp[1:0]),
                .axiap_rvalid           (axiap_rvalid),
                .axiap_wready           (axiap_wready),
                .cs_jtag_ntrst          (cs_jtag_ntrst_sync),    // Templated
                .cs_jtag_tck            (cs_jtag_tck),
                .cs_jtag_tdi            (cs_jtag_tdi),
                .cs_jtag_tms            (cs_jtag_tms),
                .dbg_clk                (dbg_clk),
                .dbg_rstn               (dbg_rstn),
                .jtag_scr1_tdo          (jtag_scr1_tdo),
                .swdbg_paddr            (swdbg_paddr[16:2]),
                .swdbg_penable          (swdbg_penable),
                .swdbg_psel             (swdbg_psel),
                .swdbg_pwdata           (swdbg_pwdata[31:0]),
                .swdbg_pwrite           (swdbg_pwrite),
                .swjdp_npotrst          (swjdp_npotrst));
/*
   trace_wrapper auto_template (
       .funnel_\(.*\)s0     (cbus_btm_slice_atb_\1[]),
       .funnel_\(.*\)s1     (dbus_btm_slice_atb_\1[]),
       .funnel_\(.*\)s2     (pcie0_slice_atb_\1[]),
       .funnel_\(.*\)s3     (pcie1_slice_atb_\1[]),
       .funnel_\(.*\)s4     (mid_funnel_atb_\1[]),
       .funnel_\(.*\)s5     (vpu0_funnel_slice_atb_\1[]),
       .funnel_\(.*\)s6     (vpu1_funnel_slice_atb_\1[]),
       .funnel_\(.*ready.*\)s.*    (@"(if (equal vl-dir \\"output\\") \\" \\" (concat \\"{\\" vl-width \\"{1'b1}}\\"))"),
       .funnel_\(.*\)s.*         (@"(if (equal vl-dir \\"output\\") \\" \\" (concat \\"{\\" vl-width \\"{1'b0}}\\"))"),
       .etr_buser_to_reg     (),
       .etr_ruser_to_reg     (),
       .etr_id_ctrl_fr_reg   (32'h0),  
       .apb1to2_paddrm1     ({21'h0, apb1to2_paddrm1[10:2], 2'h0}),
   );
*/
trace_wrapper
trace_wrapper_u0 (/*autoinst*/
                  // Outputs
                  .etr_axi_bready       (etr_axi_bready),
                  .etr_buser_to_reg     (),                      // Templated
                  .etr_ruser_to_reg     (),                      // Templated
                  .etf_etr_interrupt    (etf_etr_interrupt),
                  .apb1to2_prdatam1     (apb1to2_prdatam1[31:0]),
                  .apb1to2_preadym1     (apb1to2_preadym1),
                  .apb1to2_pslverrm1    (apb1to2_pslverrm1),
                  .apbic_prdata_to_cti_etf(apbic_prdata_to_cti_etf[31:0]),
                  .apbic_prdata_to_cti_etr(apbic_prdata_to_cti_etr[31:0]),
                  .apbic_prdata_to_etf  (apbic_prdata_to_etf[31:0]),
                  .apbic_prdata_to_etr  (apbic_prdata_to_etr[31:0]),
                  .apbic_prdata_to_funnel(apbic_prdata_to_funnel[31:0]),
                  .apbic_pready_to_cti_etf(apbic_pready_to_cti_etf),
                  .apbic_pready_to_cti_etr(apbic_pready_to_cti_etr),
                  .apbic_pready_to_etf  (apbic_pready_to_etf),
                  .apbic_pready_to_etr  (apbic_pready_to_etr),
                  .apbic_pready_to_funnel(apbic_pready_to_funnel),
                  .apbic_pslverr_to_etf (apbic_pslverr_to_etf),
                  .apbic_pslverr_to_etr (apbic_pslverr_to_etr),
                  .apbic_pslverr_to_funnel(apbic_pslverr_to_funnel),
                  .cxctm0_ctmchinack2   (cxctm0_ctmchinack2[3:0]),
                  .cxctm0_ctmchinack3   (cxctm0_ctmchinack3[3:0]),
                  .cxctm0_ctmchout2     (cxctm0_ctmchout2[3:0]),
                  .cxctm0_ctmchout3     (cxctm0_ctmchout3[3:0]),
                  .etr_axi_araddr       (etr_axi_araddr[51:0]),
                  .etr_axi_arburst      (etr_axi_arburst[1:0]),
                  .etr_axi_arcache      (etr_axi_arcache[3:0]),
                  .etr_axi_arid         (etr_axi_arid[5:0]),
                  .etr_axi_arlen        (etr_axi_arlen[3:0]),
                  .etr_axi_arlock       (etr_axi_arlock),
                  .etr_axi_arprot       (etr_axi_arprot[2:0]),
                  .etr_axi_arqos        (etr_axi_arqos[3:0]),
                  .etr_axi_arsize       (etr_axi_arsize[2:0]),
                  .etr_axi_aruser       (etr_axi_aruser[15:0]),
                  .etr_axi_arvalid      (etr_axi_arvalid),
                  .etr_axi_awaddr       (etr_axi_awaddr[51:0]),
                  .etr_axi_awburst      (etr_axi_awburst[1:0]),
                  .etr_axi_awcache      (etr_axi_awcache[3:0]),
                  .etr_axi_awid         (etr_axi_awid[5:0]),
                  .etr_axi_awlen        (etr_axi_awlen[3:0]),
                  .etr_axi_awlock       (etr_axi_awlock),
                  .etr_axi_awprot       (etr_axi_awprot[2:0]),
                  .etr_axi_awqos        (etr_axi_awqos[3:0]),
                  .etr_axi_awsize       (etr_axi_awsize[2:0]),
                  .etr_axi_awuser       (etr_axi_awuser[15:0]),
                  .etr_axi_awvalid      (etr_axi_awvalid),
                  .etr_axi_rready       (etr_axi_rready),
                  .etr_axi_wdata        (etr_axi_wdata[127:0]),
                  .etr_axi_wlast        (etr_axi_wlast),
                  .etr_axi_wstrb        (etr_axi_wstrb[15:0]),
                  .etr_axi_wvalid       (etr_axi_wvalid),
                  .funnel_afvalids0     (cbus_btm_slice_atb_afvalid), // Templated
                  .funnel_afvalids1     (dbus_btm_slice_atb_afvalid), // Templated
                  .funnel_afvalids2     (pcie0_slice_atb_afvalid), // Templated
                  .funnel_afvalids3     (pcie1_slice_atb_afvalid), // Templated
                  .funnel_afvalids4     (mid_funnel_atb_afvalid), // Templated
                  .funnel_afvalids5     (vpu0_funnel_slice_atb_afvalid), // Templated
                  .funnel_afvalids6     (vpu1_funnel_slice_atb_afvalid), // Templated
                  .funnel_atreadys0     (cbus_btm_slice_atb_atready), // Templated
                  .funnel_atreadys1     (dbus_btm_slice_atb_atready), // Templated
                  .funnel_atreadys2     (pcie0_slice_atb_atready), // Templated
                  .funnel_atreadys3     (pcie1_slice_atb_atready), // Templated
                  .funnel_atreadys4     (mid_funnel_atb_atready), // Templated
                  .funnel_atreadys5     (vpu0_funnel_slice_atb_atready), // Templated
                  .funnel_atreadys6     (vpu1_funnel_slice_atb_atready), // Templated
                  .funnel_syncreqs0     (cbus_btm_slice_atb_syncreq), // Templated
                  .funnel_syncreqs1     (dbus_btm_slice_atb_syncreq), // Templated
                  .funnel_syncreqs2     (pcie0_slice_atb_syncreq), // Templated
                  .funnel_syncreqs3     (pcie1_slice_atb_syncreq), // Templated
                  .funnel_syncreqs4     (mid_funnel_atb_syncreq), // Templated
                  .funnel_syncreqs5     (vpu0_funnel_slice_atb_syncreq), // Templated
                  .funnel_syncreqs6     (vpu1_funnel_slice_atb_syncreq), // Templated
                  // Inputs
                  .etr_axi_bvalid       (etr_axi_bvalid),
                  .etr_awqos_fr_reg     (etr_awqos_fr_reg[3:0]),
                  .etr_arqos_fr_reg     (etr_arqos_fr_reg[3:0]),
                  .etr_awuser_fr_reg    (etr_awuser_fr_reg[15:0]),
                  .etr_aruser_fr_reg    (etr_aruser_fr_reg[15:0]),
                  .etr_addr_h11_fr_reg  (etr_addr_h11_fr_reg[10:0]),
                  .etr_axi_buser        (etr_axi_buser[15:0]),
                  .etr_axi_ruser        (etr_axi_ruser[15:0]),
                  .apb1to2_paddrm1      ({21'h0, apb1to2_paddrm1[10:2], 2'h0}), // Templated
                  .apb1to2_penablem1    (apb1to2_penablem1),
                  .apb1to2_pselm1       (apb1to2_pselm1),
                  .apb1to2_pwdatam1     (apb1to2_pwdatam1[31:0]),
                  .apb1to2_pwritem1     (apb1to2_pwritem1),
                  .apbic_paddr31_to_cti_etf(apbic_paddr31_to_cti_etf),
                  .apbic_paddr31_to_cti_etr(apbic_paddr31_to_cti_etr),
                  .apbic_paddr31_to_etf (apbic_paddr31_to_etf),
                  .apbic_paddr31_to_etr (apbic_paddr31_to_etr),
                  .apbic_paddr31_to_funnel(apbic_paddr31_to_funnel),
                  .apbic_paddr_to_cti_etf(apbic_paddr_to_cti_etf[11:2]),
                  .apbic_paddr_to_cti_etr(apbic_paddr_to_cti_etr[11:2]),
                  .apbic_paddr_to_etf   (apbic_paddr_to_etf[11:2]),
                  .apbic_paddr_to_etr   (apbic_paddr_to_etr[11:2]),
                  .apbic_paddr_to_funnel(apbic_paddr_to_funnel[11:2]),
                  .apbic_penable_to_cti_etf(apbic_penable_to_cti_etf),
                  .apbic_penable_to_cti_etr(apbic_penable_to_cti_etr),
                  .apbic_penable_to_etf (apbic_penable_to_etf),
                  .apbic_penable_to_etr (apbic_penable_to_etr),
                  .apbic_penable_to_funnel(apbic_penable_to_funnel),
                  .apbic_psel_to_cti_etf(apbic_psel_to_cti_etf),
                  .apbic_psel_to_cti_etr(apbic_psel_to_cti_etr),
                  .apbic_psel_to_etf    (apbic_psel_to_etf),
                  .apbic_psel_to_etr    (apbic_psel_to_etr),
                  .apbic_psel_to_funnel (apbic_psel_to_funnel),
                  .apbic_pwdata_to_cti_etf(apbic_pwdata_to_cti_etf[31:0]),
                  .apbic_pwdata_to_cti_etr(apbic_pwdata_to_cti_etr[31:0]),
                  .apbic_pwdata_to_etf  (apbic_pwdata_to_etf[31:0]),
                  .apbic_pwdata_to_etr  (apbic_pwdata_to_etr[31:0]),
                  .apbic_pwdata_to_funnel(apbic_pwdata_to_funnel[31:0]),
                  .apbic_pwrite_to_cti_etf(apbic_pwrite_to_cti_etf),
                  .apbic_pwrite_to_cti_etr(apbic_pwrite_to_cti_etr),
                  .apbic_pwrite_to_etf  (apbic_pwrite_to_etf),
                  .apbic_pwrite_to_etr  (apbic_pwrite_to_etr),
                  .apbic_pwrite_to_funnel(apbic_pwrite_to_funnel),
                  .cxctm0_ctmchin2      (cxctm0_ctmchin2[3:0]),
                  .cxctm0_ctmchin3      (cxctm0_ctmchin3[3:0]),
                  .cxctm0_ctmchoutack2  (cxctm0_ctmchoutack2[3:0]),
                  .cxctm0_ctmchoutack3  (cxctm0_ctmchoutack3[3:0]),
                  .dbg_clk              (dbg_clk),
                  .dbg_rstn             (dbg_rstn),
                  .dft_test_mode        (dft_test_mode),
                  .etr_axi_arready      (etr_axi_arready),
                  .etr_axi_awready      (etr_axi_awready),
                  .etr_axi_bid          (etr_axi_bid[5:0]),
                  .etr_axi_bresp        (etr_axi_bresp[1:0]),
                  .etr_axi_rdata        (etr_axi_rdata[127:0]),
                  .etr_axi_rid          (etr_axi_rid[5:0]),
                  .etr_axi_rlast        (etr_axi_rlast),
                  .etr_axi_rresp        (etr_axi_rresp[1:0]),
                  .etr_axi_rvalid       (etr_axi_rvalid),
                  .etr_axi_wready       (etr_axi_wready),
                  .etr_id_ctrl_fr_reg   (32'h0),                 // Templated
                  .funnel_afreadys0     (cbus_btm_slice_atb_afready), // Templated
                  .funnel_afreadys1     (dbus_btm_slice_atb_afready), // Templated
                  .funnel_afreadys2     (pcie0_slice_atb_afready), // Templated
                  .funnel_afreadys3     (pcie1_slice_atb_afready), // Templated
                  .funnel_afreadys4     (mid_funnel_atb_afready), // Templated
                  .funnel_afreadys5     (vpu0_funnel_slice_atb_afready), // Templated
                  .funnel_afreadys6     (vpu1_funnel_slice_atb_afready), // Templated
                  .funnel_atbytess0     (cbus_btm_slice_atb_atbytes[3:0]), // Templated
                  .funnel_atbytess1     (dbus_btm_slice_atb_atbytes[3:0]), // Templated
                  .funnel_atbytess2     (pcie0_slice_atb_atbytes[3:0]), // Templated
                  .funnel_atbytess3     (pcie1_slice_atb_atbytes[3:0]), // Templated
                  .funnel_atbytess4     (mid_funnel_atb_atbytes[3:0]), // Templated
                  .funnel_atbytess5     (vpu0_funnel_slice_atb_atbytes[3:0]), // Templated
                  .funnel_atbytess6     (vpu1_funnel_slice_atb_atbytes[3:0]), // Templated
                  .funnel_atdatas0      (cbus_btm_slice_atb_atdata[127:0]), // Templated
                  .funnel_atdatas1      (dbus_btm_slice_atb_atdata[127:0]), // Templated
                  .funnel_atdatas2      (pcie0_slice_atb_atdata[127:0]), // Templated
                  .funnel_atdatas3      (pcie1_slice_atb_atdata[127:0]), // Templated
                  .funnel_atdatas4      (mid_funnel_atb_atdata[127:0]), // Templated
                  .funnel_atdatas5      (vpu0_funnel_slice_atb_atdata[127:0]), // Templated
                  .funnel_atdatas6      (vpu1_funnel_slice_atb_atdata[127:0]), // Templated
                  .funnel_atids0        (cbus_btm_slice_atb_atid[6:0]), // Templated
                  .funnel_atids1        (dbus_btm_slice_atb_atid[6:0]), // Templated
                  .funnel_atids2        (pcie0_slice_atb_atid[6:0]), // Templated
                  .funnel_atids3        (pcie1_slice_atb_atid[6:0]), // Templated
                  .funnel_atids4        (mid_funnel_atb_atid[6:0]), // Templated
                  .funnel_atids5        (vpu0_funnel_slice_atb_atid[6:0]), // Templated
                  .funnel_atids6        (vpu1_funnel_slice_atb_atid[6:0]), // Templated
                  .funnel_atvalids0     (cbus_btm_slice_atb_atvalid), // Templated
                  .funnel_atvalids1     (dbus_btm_slice_atb_atvalid), // Templated
                  .funnel_atvalids2     (pcie0_slice_atb_atvalid), // Templated
                  .funnel_atvalids3     (pcie1_slice_atb_atvalid), // Templated
                  .funnel_atvalids4     (mid_funnel_atb_atvalid), // Templated
                  .funnel_atvalids5     (vpu0_funnel_slice_atb_atvalid), // Templated
                  .funnel_atvalids6     (vpu1_funnel_slice_atb_atvalid), // Templated
                  .trace_clk            (trace_clk),
                  .trace_rstn           (trace_rstn));
/*
   ts_gen_wrapper auto_template (
       .ntsreplicator_\(.*\)m0   (cbus_btm_nts_\1[]),
       .ntsreplicator_\(.*\)m1   (dbus_btm_nts_\1[]),
       .ntsreplicator_\(.*\)m2   (pcie_nts_\1_0[]),
       .ntsreplicator_\(.*\)m3   (pcie_nts_\1_1[]),
       .ntsreplicator_\(.*\)m4   (mid_ntsr_nts_\1[]),
       .ntsreplicator_\(.*\)m5   (vpu0_dec_nts_\1[]),
       .ntsreplicator_\(.*\)m6   (vpu0_jpeg0_nts_\1[]),
       .ntsreplicator_\(.*\)m7   (vpu0_jpeg1_nts_\1[]),
       .ntsreplicator_\(.*\)m8   (vpu1_dec_nts_\1[]),
       .ntsreplicator_\(.*\)m9   (vpu1_jpeg0_nts_\1[]),
       .ntsreplicator_\(.*\)m10  (vpu1_jpeg1_nts_\1[]),

       .ntsreplicator_\(.*ready.*\)m.*     (@"(if (equal vl-dir \\"output\\") \\" \\" (concat \\"{\\" vl-width \\"{1'b1}}\\"))"),
       .ntsreplicator_\(.*\)m.*     (@"(if (equal vl-dir \\"output\\") \\" \\" (concat \\"{\\" vl-width \\"{1'b0}}\\"))"),
   );
*/
ts_gen_wrapper
ts_gen_wrapper_u0 (/*autoinst*/
                   // Outputs
                   .cxtsgen_prdatactrl  (cxtsgen_prdatactrl[31:0]),
                   .cxtsgen_preadyctrl  (cxtsgen_preadyctrl),
                   .cxtsgen_pslverrctrl (cxtsgen_pslverrctrl),
                   .ntsreplicator_tsbitm0(cbus_btm_nts_tsbit[6:0]), // Templated
                   .ntsreplicator_tsbitm1(dbus_btm_nts_tsbit[6:0]), // Templated
                   .ntsreplicator_tsbitm10(vpu1_jpeg1_nts_tsbit[6:0]), // Templated
                   .ntsreplicator_tsbitm2(pcie_nts_tsbit_0[6:0]), // Templated
                   .ntsreplicator_tsbitm3(pcie_nts_tsbit_1[6:0]), // Templated
                   .ntsreplicator_tsbitm4(mid_ntsr_nts_tsbit[6:0]), // Templated
                   .ntsreplicator_tsbitm5(vpu0_dec_nts_tsbit[6:0]), // Templated
                   .ntsreplicator_tsbitm6(vpu0_jpeg0_nts_tsbit[6:0]), // Templated
                   .ntsreplicator_tsbitm7(vpu0_jpeg1_nts_tsbit[6:0]), // Templated
                   .ntsreplicator_tsbitm8(vpu1_dec_nts_tsbit[6:0]), // Templated
                   .ntsreplicator_tsbitm9(vpu1_jpeg0_nts_tsbit[6:0]), // Templated
                   .ntsreplicator_tssyncm0(cbus_btm_nts_tssync[1:0]), // Templated
                   .ntsreplicator_tssyncm1(dbus_btm_nts_tssync[1:0]), // Templated
                   .ntsreplicator_tssyncm10(vpu1_jpeg1_nts_tssync[1:0]), // Templated
                   .ntsreplicator_tssyncm2(pcie_nts_tssync_0[1:0]), // Templated
                   .ntsreplicator_tssyncm3(pcie_nts_tssync_1[1:0]), // Templated
                   .ntsreplicator_tssyncm4(mid_ntsr_nts_tssync[1:0]), // Templated
                   .ntsreplicator_tssyncm5(vpu0_dec_nts_tssync[1:0]), // Templated
                   .ntsreplicator_tssyncm6(vpu0_jpeg0_nts_tssync[1:0]), // Templated
                   .ntsreplicator_tssyncm7(vpu0_jpeg1_nts_tssync[1:0]), // Templated
                   .ntsreplicator_tssyncm8(vpu1_dec_nts_tssync[1:0]), // Templated
                   .ntsreplicator_tssyncm9(vpu1_jpeg0_nts_tssync[1:0]), // Templated
                   // Inputs
                   .cxtsgen_paddrctrl   (cxtsgen_paddrctrl[11:2]),
                   .cxtsgen_penablectrl (cxtsgen_penablectrl),
                   .cxtsgen_pselctrl    (cxtsgen_pselctrl),
                   .cxtsgen_pwdatactrl  (cxtsgen_pwdatactrl[31:0]),
                   .cxtsgen_pwritectrl  (cxtsgen_pwritectrl),
                   .dbg_clk             (dbg_clk),
                   .dbg_rstn            (dbg_rstn),
                   .ntsreplicator_tssyncreadym0(cbus_btm_nts_tssyncready), // Templated
                   .ntsreplicator_tssyncreadym1(dbus_btm_nts_tssyncready), // Templated
                   .ntsreplicator_tssyncreadym10(vpu1_jpeg1_nts_tssyncready), // Templated
                   .ntsreplicator_tssyncreadym2(pcie_nts_tssyncready_0), // Templated
                   .ntsreplicator_tssyncreadym3(pcie_nts_tssyncready_1), // Templated
                   .ntsreplicator_tssyncreadym4(mid_ntsr_nts_tssyncready), // Templated
                   .ntsreplicator_tssyncreadym5(vpu0_dec_nts_tssyncready), // Templated
                   .ntsreplicator_tssyncreadym6(vpu0_jpeg0_nts_tssyncready), // Templated
                   .ntsreplicator_tssyncreadym7(vpu0_jpeg1_nts_tssyncready), // Templated
                   .ntsreplicator_tssyncreadym8(vpu1_dec_nts_tssyncready), // Templated
                   .ntsreplicator_tssyncreadym9(vpu1_jpeg0_nts_tssyncready), // Templated
                   .tscenter_hltdbg     (tscenter_hltdbg));



endmodule
// Local Variables:
// verilog-library-directories:("./" "../../../common/") 
// verilog-auto-inst-param-value:t
// verilog-auto-wire-type:"wire"
// verilog-auto-output-ignore-regexp:"\\(.*noused\\|.*unused.*\\)"
// verilog-case-fold:t
// End:
