`ifdef EMU_SIM
    `define SIM
`endif

`timescale 1 ns / 1 ps
module cell_clk_gate (
    input  clk_in   ,
    input  en       , //clk enable,  high valid
    input  ten      , //test enable, high valid
    output clk_out   
);

`ifdef SIM
reg en_latch;
always @(/*AS*/clk_in or en or ten)
    if (!clk_in)
        en_latch <= en | ten;
    else
        en_latch <= en_latch;

assign clk_out = clk_in & en_latch;
`else

`ifdef IDEAL_CLK_GATE

wire  clk_in_ideal;
assign clk_in_ideal =  (en == 1'b0) ? ((clk_in === 1'b1) ? 1'b1 : 1'b0) : clk_in;
//HDBSVT22_CKGTPLT_V7_6 dont_touch_clk_gate_u (.SE(ten), .EN(en), .CK(clk_in_ideal), .Q(clk_out));
//HSBSVT22_CKGTPLT_V7_6 dont_touch_clk_gate_u (.SE(ten), .EN(en), .CK(clk_in_ideal), .Q(clk_out));
PREICG_D4_N_M7P5TL_C60L08 dont_touch_clk_gate_u (.SE(ten), .E(en), .CK(clk_in_ideal), .ECK(clk_out));


//From SMIC14 SCC14NSFP_90SDB_9TC16_RVT_v1p0a/Verilog/scc14nsfp_90sdb_9tc16_rvt.v
//CLKLANQV4_90S9T16R clk_gate_u(.Q(clk_out), .CK(clk_in), .E(en), .TE(ten));

//From /Foundry/ARM/tsmc12FFC/Standard_Cell/TSMCHOME/digital/Front_End/verilog/tcbn12ffcllbwp6t16p96cpd_120a/tcbn12ffcllbwp6t16p96cpd.v
//CKLNQOPTBBD4BWP6T16P96CPD dont_touch_clk_gate_u (.TE(ten), .E(en), .CP(clk_in), .Q(clk_out));

//From /Foundry/ARM/samsung_14lpp/Standard_Cell/arm/samsung/14lpp/sc9mcpp84_base_rvt_c16/r1p1/verilog/sc9mcpp84_14lpp_base_rvt_c16.v
//PREICG_X4N_A9PP84TR_C16 dont_touch_clk_gate_u (.SE(ten), .E(en), .CK(clk_in), .ECK(clk_out));


///Foundry/ARM/samsung_8lpp/Standard_Cell/SynopsysIP/samsung08nlv
///Foundry/ARM/samsung_8lpp/Standard_Cell/SynopsysIP/samsung08nlvh/22hs/hsl/rvt/3.00a/verilog/std_primitives.v
//`elsif USE_HSB_LIB
//HSBSVT22_CKGTPLT_V7_6 dont_touch_clk_gate_u (.SE(ten), .EN(en), .CK(clk_in), .Q(clk_out));
//
//`else
//HDBSVT22_CKGTPLT_V7_6 dont_touch_clk_gate_u (.SE(ten), .EN(en), .CK(clk_in), .Q(clk_out));
////HSBSVT22_CKGTPLT_V7_6 dont_touch_clk_gate_u (.SE(ten), .EN(en), .CK(clk_in), .Q(clk_out));
//`endif

///Foundry/ARM/samsung_5lpeAT/Standard_Cell/samsung/ln05lpe_sc_m7p5t_flk_lvt_c60_a00_V3.01_pkg/FE-Common_sec240318_0094/MODEL/ln05lpe_sc_m7p5t_flk_lvt_c60l08/ln05lpe_sc_m7p5t_flk_lvt_c60l08.v
`else
//PREICG_D4_N_M7P5TL_C60L08 dont_touch_clk_gate_u (.SE(ten), .E(en), .CK(clk_in), .ECK(clk_out));

///Foundry/ARM/samsung_4lpp/Standard_Cell/samsung/ln04lpp_sc_s7p94t_flk_lvt_c60_V1.11_pkg/FE-Common/FE-Common_sec250710_0002/MODEL/flk/ln04lpp_sc_s7p94t_flk_lvt_c60l06.v
PREICG_D4_N_S7P94TL_C60L06 dont_touch_clk_gate_u (.SE(ten), .E(en), .CK(clk_in), .ECK(clk_out));





`endif
`endif
endmodule
