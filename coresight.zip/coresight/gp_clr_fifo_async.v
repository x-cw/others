
`include "../general/general.vh"
//attention!!!
//the default define is for FPGA, please add global define ASIC for ASIC
//synthesis

module gp_clr_fifo_async #(
    //these two are design for backward compatibility with the old design (gp_fifo_async)
    parameter WIDTH=8,               //This must be configure when instant
    parameter LOG2WORDS=2,                //This must be configure when instant if FIFO_WORDS not be set
    parameter FIFO_WORDS=1 << LOG2WORDS,  //This must be configure when instant if LOG2WORDS not be set

    parameter MODULE_NAME="NONE",  
    //used for afull or aempty
    parameter AFULL_THRESH=FIFO_WORDS,
    parameter AEMPTY_THRESH=0,

    //used for valid entries, be care for clock domain
    parameter VALID_ENTRIES_SYNC_RD_CLK=0, // 0=valid_entries sync to wr_clk, 1=sync to rd_clk

    //below parameter can be default for normal use
    parameter FIFO_WIDTH=WIDTH,
    parameter L2_FIFO_WORDS=log2(FIFO_WORDS),

    parameter WR_SYNC = 1, // 1: write port is synchronous (free running clock), 0: asynchronous (strobe)
    parameter RD_SYNC = 1, // 1: read port is synchronous (free running clock), 0: asynchronous (strobe)
    parameter SAME_SYNC = 0,//(RD_SYNC && WR_SYNC),  
    // 1: if WR_SYNC and RD_SYNC, indicates wr_clk is same as rd_clk, 0: separate rd/wr clks

    parameter RD_REG=0, // 1: use registered fifo output directly (else emulate unregistered)
    parameter FULL_FLOP=0
) (
  /*autoinput*/
  // Beginning of automatic inputs (from unused autoinst inputs)
  input wire [FIFO_WIDTH-1:0] din,              // To fifo of gp_fifo_async_core.v
  input wire            rd_clk,                 // To fifo of gp_fifo_async_core.v
  input wire            rd_en,                  // To fifo of gp_fifo_async_core.v
  input wire            rd_reset_n,             // To fifo of gp_fifo_async_core.v
  input wire            rd_clear,
  input wire            wr_clk,                 // To fifo of gp_fifo_async_core.v
  input wire            wr_en,                  // To fifo of gp_fifo_async_core.v
  input wire            wr_reset_n,             // To fifo of gp_fifo_async_core.v
  input wire            wr_clear,
  // End of automatics
  /*autooutput*/
  // Beginning of automatic outputs (from unused autoinst outputs)
  output wire           aempty,                 // From fifo of gp_fifo_async_core.v
  output wire           afull,                  // From fifo of gp_fifo_async_core.v
  output wire [FIFO_WIDTH-1:0] dout,            // From fifo of gp_fifo_async_core.v
  output wire           empty,                  // From fifo of gp_fifo_async_core.v
  output wire           full,                   // From fifo of gp_fifo_async_core.v
  output wire           overflow,               // From fifo of gp_fifo_async_core.v
  output wire           underflow,              // From fifo of gp_fifo_async_core.v
  output wire [L2_FIFO_WORDS:0] valid_entries   // From fifo of gp_fifo_async_core.v
  // End of automatics
);
  `include "../general/misc.vh"

  generate 
    if(SAME_SYNC == 0) begin : gp_fifo_async
      /*gp_fifo_async_core auto_template (
        .WIDTH    (FIFO_WIDTH),
        .LOG2WORDS(L2_FIFO_WORDS),
      );*/
      gp_clr_fifo_async_core #(/*autoinstparam*/
                           // Parameters
                           .LOG2WORDS           (L2_FIFO_WORDS), // Templated
                           .WIDTH               (FIFO_WIDTH),    // Templated
                           .WR_SYNC             (WR_SYNC),
                           .AFULL_THRESH        (AFULL_THRESH),
                           .RD_SYNC             (RD_SYNC),
                           .AEMPTY_THRESH       (AEMPTY_THRESH),
                           .SAME_SYNC           (SAME_SYNC),
                           .RD_REG              (RD_REG),
                           .FULL_FLOP           (FULL_FLOP),
                           .MODULE_NAME         (MODULE_NAME),
                           .VALID_ENTRIES_SYNC_RD_CLK(VALID_ENTRIES_SYNC_RD_CLK))
      fifo (/*autoinst*/
            // Outputs
            .full                       (full),
            .afull                      (afull),
            .overflow                   (overflow),
            .valid_entries              (valid_entries[L2_FIFO_WORDS:0]),
            .dout                       (dout[FIFO_WIDTH-1:0]),
            .empty                      (empty),
            .aempty                     (aempty),
            .underflow                  (underflow),
            // Inputs
            .wr_reset_n                 (wr_reset_n),
            .wr_clear                   (wr_clear),
            .rd_reset_n                 (rd_reset_n),
            .rd_clear                   (rd_clear),
            .wr_clk                     (wr_clk),
            .wr_en                      (wr_en),
            .din                        (din[FIFO_WIDTH-1:0]),
            .rd_clk                     (rd_clk),
            .rd_en                      (rd_en));
    end// else begin : gp_fifo_async_fatal

//`ifdef SYNTHESIS
//      // force a compile issue
//      sync_not_supported_in_gp_fifo_async #(.FIFO_WIDTH(FIFO_WIDTH),.FIFO_WORDS(FIFO_WORDS)) unsupported_cell ();
//`else
//      initial assert(0) else $fatal("[%m] gp_fifo_async has been instantiated w/o SAME_SYNC==0");
//`endif
//    
//    end
  endgenerate
  
endmodule // gp_fifo_async
