
//--========================================================================
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2011-2015 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//  Version and Release Control Information:
//
//  File Name           : cxdapaxiapmstif_xmlcfg.v.xsl
//
//  Checked In          : $Date: 2015-02-16 14:55:41 +0000 (Mon, 16 Feb 2015) $
//
//  File Revision       : $Revision: 41661 $
//
//  Release Information : CoreSight-SoC-TM100-r3p2-00rel0
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// Abstract : CoreSight AXIAP Master Interface
//-----------------------------------------------------------------------------
//
// cxdapaxiap - CoreSight AXIAP Master Interface
// ---------------------------------------------
//
//-----------------------------------------------------------------------------

module cxdapaxiapmstif_1 (

  // Clock and Reset
  input wire            clk,
  input wire            resetn,

  // AW Channel
  output wire [63:0]     awaddr,
  output reg [7:0]      awlen,
  output wire [2:0]     awsize,
  output wire [1:0]     awburst,
  output reg            awlock,
  output reg [3:0]      awcache,
  output reg [2:0]      awprot,
  output wire           awvalid,
  input wire            awready,

  // W Channel
  output wire [31:0]    wdata,
  output reg [3:0]      wstrb,
  output reg            wlast,
  output wire           wvalid,
  input wire            wready,

  // W Resp Channel
  input wire [1:0]      bresp,
  input wire            bvalid,
  output wire           bready,

  // AR Channel
  output wire [63:0]     araddr,
  output reg [7:0]      arlen,
  output wire [2:0]     arsize,
  output wire [1:0]     arburst,
  output reg            arlock,
  output reg [3:0]      arcache,
  output reg [2:0]      arprot,
  output wire           arvalid,
  input wire            arready,

  // R Channel
  input wire [31:0]     rdata,
  input wire [1:0]      rresp,
  input wire            rlast,
  input wire            rvalid,
  output wire           rready,

  // ACE - Lite Interface

  // W Channel
  output reg [1:0]      awdomain,
  output reg [2:0]      awsnoop,
  output reg [1:0]      awbar,

  // R Channel
  output reg [1:0]      ardomain,
  output reg [3:0]      arsnoop,
  output reg [1:0]      arbar,

  // Register block interface
  input wire            drw_wr_req,
  input wire            drw_rd_req,
  input wire            bd0_req,
  input wire            bd1_req,
  input wire            bd2_req,
  input wire            bd3_req,
  input wire            drw_en,
  input wire            bd0_en,
  input wire            bd1_en,
  input wire            bd2_en,
  input wire            bd3_en,
  input wire            wr_en,

  input wire [31:0]     tar_l,
  input wire [31:0]     tar_u,
  input wire [1:0]      axi_size,
  input wire [3:0]      cache_enc,
  input wire [2:0]      prot_enc,
  input wire [1:0]      addr_inc,
  input wire [1:0]      bar_enc,
  input wire [1:0]      domain,
  input wire            abort_req,
  output wire [9:0]     inc_tar_l,
  output reg            inc_tar,
  output wire [31:0]     rdata_l,
  output wire           rdata_vld,

  // Top level FSM interface
  input wire [2:0]      fsm_state,
  output wire           bar_resp,
  output wire           bar_awready,
  output wire           mst_wready,
  output wire           wr_resp,
  output wire           bar_arready,
  output wire           rd_resp,
  output wire           axi_err_resp,
  output wire           pck_tr_done,

  // DAP interface
  input wire [31:0]     dap_wdata,

  //Authentication interface
  input wire            spiden_rg

  );

`include "cxdapaxiap_constants.v"

//------------------------------------------------------------------------------
// Constant definitions
//------------------------------------------------------------------------------
  localparam AXI_RESP_OKAY   = 2'b00;
  localparam AXI_RESP_EXOKAY = 2'b01;
  localparam AXI_RESP_SLVERR = 2'b10;
  localparam AXI_RESP_DECERR = 2'b11;



//----------------------------------------------------------------------------
// Wires
//----------------------------------------------------------------------------
  wire bar_resp_rd_next;
  wire bar_resp_wr_next;
  wire [31:0] rd_byte_addr0;
  wire [31:0] rd_byte_addr1;
  wire [31:0] rd_byte_addr2;
  wire [31:0] rd_byte_addr3;

  wire [31:0] rd_hw_addr0;
  wire [31:0] rd_hw_addr2;

  wire [31:0] wr_byte_addr0;
  wire [31:0] wr_byte_addr1;
  wire [31:0] wr_byte_addr2;
  wire [31:0] wr_byte_addr3;


  wire [31:0] wr_hw_addr0;
  wire [31:0] wr_hw_addr2;


  wire wstrb_next_en;
  wire [31:0] aligned_addr;
  wire bar_resp_rd_en;
  wire bar_resp_wr_en;
  wire dummy_carry_over;
  wire awvalid_en;
  wire arvalid_en;
  wire bd_req;
  wire axi_wr_data_en;
  wire rd_wr_addr_en;
  wire rd_wr_data_en;
  wire pck_tr_lst_done_next;
  wire pck_tr_lst_done_en;
  wire wvalid_sent_en;
  wire wvalid_en;
  wire bar_resp_int;

//----------------------------------------------------------------------------
// Registers
//----------------------------------------------------------------------------
  reg [1:0] pck_cntr_next;
  reg [1:0] pck_cntr;
  reg [31:0] align_addr;
  reg aw_bar_sent_next;
  reg aw_bar_sent;
  reg ar_bar_sent_next;
  reg ar_bar_sent;
  reg bar_resp_rd;
  reg bar_resp_wr;
  reg [3:0] addr_inc_size;
  reg tr_lst_done_next;
  reg tr_lst_done;
  reg [31:0] rd_wr_data_next;
  reg rdata_vld_next;
  reg [3:0] wstrb_next;
  reg tr_lst_done_en;
  reg aw_bar_sent_en;
  reg ar_bar_sent_en;
  reg pck_cntr_en;
  reg wvalid_sent_next;
  reg wvalid_sent;
  reg wvalid_next;
  reg [1:0] awsize_next;
  reg [3:0] awcache_next;
  reg       awprot_1_next;
  reg       awprot_1;
  reg       awvalid_next;
  reg       awvalid_q;
  reg [1:0] awbar_next;
  reg       aw_channel_en;
  reg [1:0] arsize_next;
  reg [3:0] arcache_next;
  reg       arprot_1_next;
  reg       arprot_1;
  reg       arvalid_next;
  reg       arvalid_q;
  reg [1:0] arbar_next;
  reg       ar_channel_en;
  reg [1:0] arsize_rg;
  reg [1:0] awsize_rg;
  reg [1:0] bd_addr;
  reg       rdata_vld_q;
  reg       wvalid_q;
  reg [31:0] rd_wr_data;
  reg [63:0] rd_wr_addr_next;
  reg [63:0] rd_wr_addr;
  reg [5:0] pck_tr_lst_done;

//============================================================================
//
// Main body of code
//
//============================================================================

//----------------------------------------------------------------------------
// Counter to keep track of packed transfers
//----------------------------------------------------------------------------
// Packing counter has to be decremented once a Write/Read request is sent
// It should be decremented only if following conditions are met
// addr_inc is set as '10'
// 32-bit AXI-data width
//   Size : '000' (8-bit access) or '001' (16-bit access)
// 64-bit AXI-data width
//   Packing operation is disabled when 64
// After the request is sent, the Packing counter will be decremented based on
//   Write response was okay and not an error
//   An abort was not requested
// If above condition is not met then Packing counter will be reset based on
//   DAPBUS sends an Abort request
//   Write response indicates an error condition
//----------------------------------------------------------------------------
  always @(*)
    begin : p_pck_cntr_decode
      pck_cntr_next = pck_cntr;
      pck_cntr_en = 1'b0;

      case (fsm_state)
        RD_CMD,
        WR_CMD : begin
          if (abort_req) begin
            pck_cntr_next = 2'b00;
            pck_cntr_en = 1'b1;
          end else if (((fsm_state == RD_CMD) && !(arready & arvalid_q)) ||
                   ((fsm_state == WR_CMD) && !(awready & awvalid_q))) begin
            pck_cntr_next = pck_cntr;
          end else if ((addr_inc == 2'b10) && (drw_wr_req || drw_rd_req)) begin
            if (axi_size < AXIAP_WORD) begin
              if (pck_cntr != 2'b00) begin
                pck_cntr_next = pck_cntr - 1'b1;
              end else if (axi_size == AXIAP_BYTE) begin
                pck_cntr_next = 2'b11;
              end else begin
                pck_cntr_next = 2'b01;
              end
              pck_cntr_en = 1'b1;
            end
          end
        end
        WRITE_RESP : begin
          if (abort_req || (bvalid &&
             ((bresp == AXI_RESP_SLVERR) ||
             (bresp == AXI_RESP_DECERR)))) begin
            pck_cntr_next = 2'b00;
            pck_cntr_en = 1'b1;
          end
        end
        READ_RESP : begin
          if (abort_req || (rvalid &&
             ((rresp == AXI_RESP_SLVERR) ||
             (rresp == AXI_RESP_DECERR)))) begin
            pck_cntr_next = 2'b00;
            pck_cntr_en = 1'b1;
          end
        end
        RDY,
        BRR,
        BRR_RESP,
        WR_DT : begin
          if (abort_req) begin
            pck_cntr_next = 2'b00;
            pck_cntr_en = 1'b1;
          end
        end
        default : pck_cntr_next = {2{1'bx}};
      endcase
    end

  always @(posedge clk or negedge resetn)
    begin : p_pck_cntr
      if (!resetn) begin
        pck_cntr <= {2{1'b0}};
      end else if (pck_cntr_en) begin
        pck_cntr <= pck_cntr_next;
      end
    end

  assign pck_tr_done = (pck_cntr == 2'b00);

  assign axi_err_resp = ((fsm_state == WRITE_RESP) & bvalid & (bresp == AXI_RESP_SLVERR)) |
                      ((fsm_state == WRITE_RESP) & bvalid & (bresp == AXI_RESP_DECERR)) |
                      ((fsm_state == READ_RESP) & rvalid & (rresp == AXI_RESP_SLVERR)) |
                      ((fsm_state == READ_RESP) & rvalid & (rresp == AXI_RESP_DECERR));

//----------------------------------------------------------------------------
// Banked Data Access
//----------------------------------------------------------------------------
  assign bd_req = ((bd0_req) |
                  (bd1_req) |
                  (bd2_req) |
                  (bd3_req));

//----------------------------------------------------------------------------
// Aligned Address field
// In case of 32-bit AXI data width
// If Size is Byte then tar_l will be retained
// If Size is Half-word then tar_l[0] will be zeroed out
// If Size is Word then tar_l[1:0] will be zeroed out
// In case of 64-bit AXI data width
// If Size is Byte then tar_l will be retained
// If Size is Half-word then tar_l[0] will be zeroed out
// If Size is Word then tar_l[1:0] will be zeroed out
// If Size is Double-word then tar_l[2:0] will be zeroed out
//----------------------------------------------------------------------------
  always @(*)
    begin
        bd_addr = (
                    ({2{(bd0_req)}} & 2'b00) |
                    ({2{(bd1_req)}} & 2'b01) |
                    ({2{(bd2_req)}} & 2'b10) |
                    ({2{(bd3_req)}} & 2'b11)
                  );
    end

  always @(*)
    begin
      case (axi_size)
        AXIAP_BYTE      : align_addr = tar_l;
        AXIAP_HALF_WORD : align_addr = {tar_l[31:1],1'b0};
        AXIAP_WORD      : align_addr = {tar_l[31:2],{2{1'b0}}};
        AXIAP_DWORD : begin

            align_addr = tar_l;

        end
        default         : align_addr = tar_l;
      endcase
    end

  assign aligned_addr[31:4] = align_addr[31:4];
  assign aligned_addr[3:0] = bd_req ?
                            {bd_addr,{2{1'b0}}} : align_addr[3:0];

//----------------------------------------------------------------------------
// AXI Read/Write address generation logic
//----------------------------------------------------------------------------
  always @(*)
    begin : p_rd_wr_addr_cmb
      rd_wr_addr_next = {tar_u,tar_l};

      if (fsm_state == BRR) begin
        if (!aw_bar_sent || !ar_bar_sent)
          begin
            rd_wr_addr_next = {64{1'b0}};
          end
      end else if ((fsm_state == WR_CMD) || (fsm_state == RD_CMD))
        begin
          rd_wr_addr_next = {tar_u,aligned_addr};
        end
    end

  assign rd_wr_addr_en = (fsm_state == BRR) |
                         (fsm_state == WR_CMD) |
                         (fsm_state == RD_CMD);

  always @(posedge clk or negedge resetn)
    begin : p_rd_wr_addr_seq
      if (!resetn) begin
        rd_wr_addr  <= {64{1'b0}};
      end else if (rd_wr_addr_en) begin
        rd_wr_addr  <= rd_wr_addr_next;
      end
    end

//----------------------------------------------------------------------------
// AW Channel - Including ACE-Lite interface
//----------------------------------------------------------------------------
  assign awsize  = {1'b0,awsize_rg};
  assign awburst = {2'b01};

  always @(*)
    begin : p_aw_ch
      awlen            = 8'b00000000;
      awlock           = 1'b0;
      awcache_next     = cache_enc;
      awprot[2]        = prot_enc[2];
      awprot[1]        = awprot_1;
      awprot[0]        = prot_enc[0];
      awvalid_next     = 1'b0;
      awdomain         = domain;
      awsnoop          = 3'b000;
      awbar_next       = 2'b00;
      awprot_1_next    = awvalid_q ? awprot_1 : (prot_enc[1] | ~spiden_rg);
      aw_bar_sent_next = aw_bar_sent;
      aw_bar_sent_en   = 1'b0;
      aw_channel_en    = 1'b0;
      awsize_next      = awsize_rg;

      if (fsm_state == BRR) begin
        if (!aw_bar_sent)
          begin
            awsize_next = 2'b10;
            awcache_next = 4'b0010;
            awbar_next   = bar_enc;
            awvalid_next = awvalid_q ? ~awready : 1'b1;
            aw_channel_en = 1'b1;
            if (awready & awvalid_q) begin
              aw_bar_sent_next = 1'b1;
              aw_bar_sent_en = 1'b1;
            end
          end
       end else if (fsm_state == BRR_RESP) begin
         aw_bar_sent_next = 1'b0;
         aw_bar_sent_en = 1'b1;
       end else if (fsm_state == WR_CMD)
         begin
           awvalid_next = awvalid_q ? ~awready : 1'b1;
           aw_channel_en = 1'b1;
           if (bd_req) begin
             awsize_next   = 2'b10;
           end else begin
             awsize_next   = axi_size;
           end
         end
    end

  assign awaddr = rd_wr_addr;

  always @(posedge clk or negedge resetn)
    begin
      if (!resetn) begin
        awsize_rg   <= 2'b00;
        awcache     <= 4'b0000;
        awprot_1    <= 1'b1;
      end else if (aw_channel_en) begin
        awsize_rg   <= awsize_next;
        awcache     <= awcache_next;
        awprot_1    <= awprot_1_next;
      end
    end

  always @(posedge clk or negedge resetn)
    begin
      if (!resetn) begin
        awbar       <= 2'b00;
      end else if (aw_channel_en | aw_bar_sent) begin
        awbar       <= awbar_next;
      end
    end

  assign awvalid_en = awvalid_next ^ awvalid_q;

  always @(posedge clk or negedge resetn)
    begin
      if (!resetn) begin
        awvalid_q     <= 1'b0;
      end else if (awvalid_en) begin
        awvalid_q     <= awvalid_next;
      end
    end

  assign awvalid = awvalid_q;

  always @(posedge clk or negedge resetn)
    begin : aw_bar_sent_reg
      if (!resetn) begin
        aw_bar_sent <= 1'b0;
      end else if (aw_bar_sent_en) begin
        aw_bar_sent <= aw_bar_sent_next;
      end
    end

  assign bar_awready = (aw_bar_sent | (awready & awvalid_q));

//----------------------------------------------------------------------------
// AR Channel - Including ACE-Lite Interface
//----------------------------------------------------------------------------
  assign arsize  = {1'b0,arsize_rg};
  assign arburst = {2'b01};

  always @(*)
    begin
      arlen            = 8'b00000000;
      arlock           = 1'b0;
      arcache_next     = cache_enc;
      arprot[2]        = prot_enc[2];
      arprot[1]        = arprot_1;
      arprot[0]        = prot_enc[0];
      arvalid_next     = 1'b0;
      ardomain         = domain;
      arsnoop          = 4'b0000;
      arbar_next       = 2'b00;
      arprot_1_next    = arvalid_q ? arprot_1 : (prot_enc[1] | ~spiden_rg);
      ar_bar_sent_next = ar_bar_sent;
      ar_bar_sent_en   = 1'b0;
      ar_channel_en    = 1'b0;
      arsize_next      = arsize_rg;

      if (fsm_state == BRR) begin
        if (!ar_bar_sent)
          begin
            arsize_next = 2'b10;
            arcache_next = 4'b0010;
            arbar_next = bar_enc;
            arvalid_next = arvalid_q ? ~arready : 1'b1;
            ar_channel_en = 1'b1;
            if (arready & arvalid_q) begin
              ar_bar_sent_next = 1'b1;
              ar_bar_sent_en   = 1'b1;
            end
          end
       end else if (fsm_state == BRR_RESP) begin
         ar_bar_sent_next = 1'b0;
         ar_bar_sent_en = 1'b1;
       end else if (fsm_state == RD_CMD)
         begin
           arvalid_next = arvalid_q ? ~arready : 1'b1;
           ar_channel_en = 1'b1;
           if (bd_req) begin
             arsize_next   = 2'b10;
           end else begin
             arsize_next   = axi_size;
           end
         end
    end

  assign araddr = rd_wr_addr;

  always @(posedge clk or negedge resetn)
    begin
      if (!resetn) begin
        arsize_rg   <= 2'b00;
        arcache     <= 4'b0000;
        arprot_1    <= 1'b1;
      end else if (ar_channel_en) begin
        arsize_rg   <= arsize_next;
        arcache     <= arcache_next;
        arprot_1    <= arprot_1_next;
      end
    end

  always @(posedge clk or negedge resetn)
    begin
      if (!resetn) begin
        arbar       <= 2'b00;
      end else if (ar_channel_en | ar_bar_sent) begin
        arbar       <= arbar_next;
      end
    end

  assign arvalid_en = arvalid_next ^ arvalid_q;

  always @(posedge clk or negedge resetn)
    begin
      if (!resetn) begin
        arvalid_q     <= 1'b0;
      end else if (arvalid_en) begin
        arvalid_q     <= arvalid_next;
      end
    end

  assign arvalid = arvalid_q;

  always @(posedge clk or negedge resetn)
    begin : p_ar_bar_sent_reg
      if (!resetn)
        ar_bar_sent <= 1'b0;
      else if (ar_bar_sent_en)
        ar_bar_sent <= ar_bar_sent_next;
    end

  assign bar_arready = (ar_bar_sent | (arready & arvalid_q));

//----------------------------------------------------------------------------
// W Resp Channel
//----------------------------------------------------------------------------
  assign bready = (fsm_state == WRITE_RESP) | (fsm_state == BRR_RESP);

//----------------------------------------------------------------------------
// R Resp Channel
//----------------------------------------------------------------------------
  assign rready = (fsm_state == READ_RESP) | (fsm_state == BRR_RESP);

//----------------------------------------------------------------------------
// Barrier response
// Wait for response on both the R and B Channel
//----------------------------------------------------------------------------
  assign bar_resp_rd_next = bar_resp_rd ?
                              ~bar_resp_int :
                              (fsm_state == BRR_RESP) & rvalid & ~bar_resp_int;

  assign bar_resp_wr_next = bar_resp_wr ?
                              ~bar_resp_int :
                              (fsm_state == BRR_RESP) & bvalid & ~bar_resp_int;

  assign bar_resp_rd_en = (bar_resp_rd != bar_resp_rd_next);

  always @(posedge clk or negedge resetn)
    begin : p_bar_resp_rd_reg
      if (!resetn)
        begin
          bar_resp_rd <= 1'b0;
        end
      else if (bar_resp_rd_en)
        begin
          bar_resp_rd <= bar_resp_rd_next;
        end
    end

  assign bar_resp_wr_en = (bar_resp_wr != bar_resp_wr_next);

  always @(posedge clk or negedge resetn)
    begin : p_bar_resp_wr_reg
      if (!resetn)
        begin
          bar_resp_wr <= 1'b0;
        end
      else if (bar_resp_wr_en)
        begin
          bar_resp_wr <= bar_resp_wr_next;
        end
    end

  assign bar_resp_int = (fsm_state == BRR_RESP) ?
                         (bar_resp_rd | rvalid) & (bar_resp_wr | bvalid) :
                           1'b0;

  assign bar_resp = bar_resp_int;

  assign mst_wready = wready | wvalid_sent;

  assign wr_resp = bvalid;

  assign rd_resp = rvalid;

//----------------------------------------------------------------------------
// addr_inc_size indicates the amount by which the value in the transfer address
// register should be incremented.
//----------------------------------------------------------------------------
  always @ (*)
    begin : p_addr_inc
      case (axi_size)
        AXIAP_BYTE      : addr_inc_size = 4'b0001;
        AXIAP_HALF_WORD : addr_inc_size = 4'b0010;
        AXIAP_WORD      : addr_inc_size = 4'b0100;
        AXIAP_DWORD     : begin

            addr_inc_size = 4'b0000;

        end
        default         : addr_inc_size = 4'b0000;
      endcase
    end

//----------------------------------------------------------------------------
// Tar register will wrap around at 1k-byte range
// It will be incremented only in WRITE_RESP or READ_RESP
// In Case of an abort, it will not be incremented.
//----------------------------------------------------------------------------

  assign {dummy_carry_over,inc_tar_l} = tar_l[9:0] + {{6{1'b0}},addr_inc_size};

  always @(*)
    begin : p_tar_l
      inc_tar = 1'b0;

      case (fsm_state)
        WRITE_RESP : begin
          if ((addr_inc != 2'b00) && (addr_inc != 2'b11) && ~bd_req) begin
            if (!abort_req) begin
              if (bvalid &&
                 ((bresp != AXI_RESP_SLVERR) &&
                  (bresp != AXI_RESP_DECERR)))
                begin
                  inc_tar = 1'b1;
                end
            end
          end
        end
        READ_RESP : begin
          if ((addr_inc != 2'b00) && (addr_inc != 2'b11) && ~bd_req) begin
            if (!abort_req) begin
              if (rvalid &&
                 ((rresp != AXI_RESP_SLVERR) &&
                  (rresp != AXI_RESP_DECERR)))
                begin
                  inc_tar = 1'b1;
                end
            end
          end
        end
        RDY,
        BRR,
        BRR_RESP,
        WR_CMD,
        WR_DT,
        RD_CMD : begin
          inc_tar = 1'b0;
        end
        default : begin
          inc_tar = 1'bx;
        end
      endcase
    end

//----------------------------------------------------------------------------
// rd_byte_addr0,rd_byte_addr1,rd_bye_addr2 and rd_byte_addr3 represent the nets when
// the AXI size is of 8 bits and the least two significant bits of the AXI
// address are zero,one,two and three respectively.
//----------------------------------------------------------------------------
  assign rd_byte_addr0 = (pck_tr_lst_done[0]) ? {rd_wr_data[31:8], rdata[7:0]} :
                         {rdata[7:0], rd_wr_data[31:8]};
  assign rd_byte_addr1 = (pck_tr_lst_done[1]) ? {rd_wr_data[31:16],rdata[15:8], rd_wr_data[7:0]} :
                         {rdata[15:8], rd_wr_data[31:8]};
  assign rd_byte_addr2 = (pck_tr_lst_done[2]) ? {rd_wr_data[31:24],rdata[23:16],rd_wr_data[15:0]} :
                         {rdata[23:16], rd_wr_data[31:8]};
  assign rd_byte_addr3 = (pck_tr_lst_done[3]) ? {rdata[31:24],rd_wr_data[23:0]} :
                         {rdata[31:24], rd_wr_data[31:8]};


//----------------------------------------------------------------------------
// rd_hw_addr0 and rd_hw_addr2 represent the nets when the AXI size is of 16
// bits and the least two significant bits of the AXI address are zero and
// two respectively.
//----------------------------------------------------------------------------
  assign rd_hw_addr0 = (pck_tr_lst_done[4]) ? {rd_wr_data[31:16],rdata[15:0]} :
                       {rdata[15:0], rd_wr_data[31:16]};
  assign rd_hw_addr2 = (pck_tr_lst_done[5]) ? {rdata[31:16],rd_wr_data[15:0]} :
                       {rdata[31:16], rd_wr_data[31:16]};

//----------------------------------------------------------------------------
// wr_byte_addr0,wr_byte_addr1,wr_bye_addr2 and wr_byte_addr3 represent the nets
// when the AXI size is of 8 bits and the least two significant bits of the AXI
// address are zero,one,two and three respectively.
//----------------------------------------------------------------------------
  assign wr_byte_addr0 = dap_wdata;
  assign wr_byte_addr1 = (addr_inc == 2'b10) ? {dap_wdata[23:0], dap_wdata[31:24]} : wr_byte_addr0;
  assign wr_byte_addr2 = (addr_inc == 2'b10) ? {dap_wdata[15:0], dap_wdata[31:16]} : wr_byte_addr0;
  assign wr_byte_addr3 = (addr_inc == 2'b10) ? {dap_wdata[7:0], dap_wdata[31:8]} : wr_byte_addr0;

//----------------------------------------------------------------------------
// wr_hw_addr0, wr_hw_addr2, wr_hw_addr4, wr_hw_addr6 represent the nets when
// the AXI size is of 16 bits and the least two significant bits of the AXI
// address are 0,2,4,6 respectively.
//----------------------------------------------------------------------------
  assign wr_hw_addr0 = dap_wdata;
  assign wr_hw_addr2 = (addr_inc == 2'b10) ? {dap_wdata[15:0], dap_wdata[31:16]} : wr_hw_addr0;


//----------------------------------------------------------------------------
// Logic to indicate if the last transfer of a packed access is complete
// Counter to keep track of packed transfer will be reset at the beginnning of
// either a read or write access. A signal is generated which will open a window
// from when pack-counter is zero until the actual transfer is complete.
// Pack-counter together with this signal will determine completion of last packet
//----------------------------------------------------------------------------
  always @(*)
    begin
      tr_lst_done_next = tr_lst_done;
      tr_lst_done_en = 1'b0;

      if ((pck_cntr == 2'b01) &&
           (pck_cntr_next == 2'b00)) begin
        if ((fsm_state == WR_CMD) ||
             (fsm_state == RD_CMD)) begin
          tr_lst_done_next = 1'b0;
          tr_lst_done_en = 1'b1;
        end
      end else if (((fsm_state == WRITE_RESP) && bvalid) ||
                ((fsm_state == READ_RESP) && rvalid)) begin
        if (!tr_lst_done) begin
          tr_lst_done_next = 1'b1;
          tr_lst_done_en = 1'b1;
        end
      end
    end

  always @(posedge clk or negedge resetn)
    begin : p_tr_lst_done_reg
      if (!resetn) begin
        tr_lst_done <= 1'b1;
      end else if (tr_lst_done_en) begin
        tr_lst_done <= tr_lst_done_next;
      end
    end

  assign pck_tr_lst_done_next = ((pck_cntr_en & (pck_cntr_next == 2'b00)) | (~pck_cntr_en & (pck_cntr == 2'b00))) &
                                ((tr_lst_done_en & tr_lst_done_next) | (~tr_lst_done_en & tr_lst_done));

  assign pck_tr_lst_done_en = (pck_tr_lst_done_next ^ pck_tr_lst_done[0]);

  always @(posedge clk or negedge resetn)
    begin : p_pck_tr_lst_done_reg
      if (!resetn) begin
        pck_tr_lst_done <= {6{1'b1}};
      end else if (pck_tr_lst_done_en) begin
        pck_tr_lst_done[0] <= pck_tr_lst_done_next;
        pck_tr_lst_done[1] <= pck_tr_lst_done_next;
        pck_tr_lst_done[2] <= pck_tr_lst_done_next;
        pck_tr_lst_done[3] <= pck_tr_lst_done_next;
        pck_tr_lst_done[4] <= pck_tr_lst_done_next;
        pck_tr_lst_done[5] <= pck_tr_lst_done_next;

      end
    end

//----------------------------------------------------------------------------
// Logic for storing the read data from AXI in the case of increment
// packed transactions and Write data for AXI write access.
// New 'Write data' is registered only when
// top-level FSM is in RDY state and DAP requests a write access.
//
// In case of 64-bit data width 2 conditions are possible.
//
// If axi_size is set as 64-bit then dword_fsm will be considered.
//
// However if axi_size is set as 32-bit then dword_fsm will not be considered.
//
// Inspite of this the write data will be stored properly in case of drw access
// that is, based on tar_l[2] bit it should be stored in either upper [63:32] bit
// locations or lower [31:0] bit locations
//
// Logic for storing the read data from AXI in the case of increment
// packed transactions.Word size transactions in case of increment and non-
// increment packed transactions are the same.For half word and byte
// transactions,the read data from AXI shall be stored over two and
// four AXI transactions respectively.
//----------------------------------------------------------------------------
  always @(*)
    begin : p_incr_data_l
      rd_wr_data_next = rd_wr_data;
      rdata_vld_next = 1'b0;

      if (fsm_state == RDY) begin
        if ((drw_en || bd0_en || bd1_en || bd2_en || bd3_en) && wr_en) begin

          case (axi_size)
            AXIAP_BYTE : begin
              if (drw_en) begin
                case (tar_l[1:0])
                  2'b00 : rd_wr_data_next = wr_byte_addr0;
                  2'b01 : rd_wr_data_next = wr_byte_addr1;
                  2'b10 : rd_wr_data_next = wr_byte_addr2;
                  2'b11 : rd_wr_data_next = wr_byte_addr3;
                  default : rd_wr_data_next = {32{1'bx}};
                endcase
              end else begin
                rd_wr_data_next = dap_wdata;
              end
            end
            AXIAP_HALF_WORD : begin
              if (drw_en) begin
                case (tar_l[1])
                  1'b0 : rd_wr_data_next = wr_hw_addr0;
                  1'b1 : rd_wr_data_next = wr_hw_addr2;
                  default : rd_wr_data_next = {32{1'bx}};
                endcase
              end else begin
                rd_wr_data_next = dap_wdata;
              end
            end
            AXIAP_WORD ,
            AXIAP_DWORD : rd_wr_data_next = dap_wdata;
            default : rd_wr_data_next = {32{1'bx}};
          endcase

        end
      end else if ((fsm_state == READ_RESP) && rvalid && rlast)
        begin
          rdata_vld_next = 1'b1;
          if (drw_rd_req)
              case (axi_size)
                AXIAP_BYTE : begin

                  case(tar_l[1:0])
                    2'b00   : rd_wr_data_next = rd_byte_addr0;
                    2'b01   : rd_wr_data_next = rd_byte_addr1;
                    2'b10   : rd_wr_data_next = rd_byte_addr2;
                    2'b11   : rd_wr_data_next = rd_byte_addr3;
                    default : rd_wr_data_next = {32{1'bx}};
                  endcase

                end
                AXIAP_HALF_WORD : begin

                  case(tar_l[1])
                    1'b0   : rd_wr_data_next = rd_hw_addr0;
                    1'b1   : rd_wr_data_next = rd_hw_addr2;
                    default : rd_wr_data_next = {32{1'bx}};
                  endcase

                end
                AXIAP_WORD  : begin

                  rd_wr_data_next = rdata;

                end
                AXIAP_DWORD : rd_wr_data_next = rdata;
                default     : rd_wr_data_next = {32{1'bx}};
              endcase
           else begin

                  rd_wr_data_next = rdata;

           end
        end
      else if (fsm_state == RD_CMD)
        begin
          if (!pck_tr_lst_done[0])
            rdata_vld_next = rdata_vld_q;
        end
    end

  assign axi_wr_data_en = (fsm_state == RDY) & ((drw_en | bd0_en | bd1_en | bd2_en | bd3_en) & wr_en);

  assign rd_wr_data_en = axi_wr_data_en | rdata_vld_next;

  always @(posedge clk or negedge resetn)
    begin : p_rd_wr_data_reg
      if (!resetn) begin
        rd_wr_data <= {32{1'b0}};
      end else if (rd_wr_data_en) begin
        rd_wr_data <= rd_wr_data_next;
      end
    end

  assign rdata_l = rd_wr_data;

  always @(posedge clk or negedge resetn)
    begin : p_rdata_vld_reg
      if (!resetn) begin
        rdata_vld_q <= 1'b0;
      end else begin
        rdata_vld_q <= rdata_vld_next;
      end
    end

  assign rdata_vld = rdata_vld_q;

//----------------------------------------------------------------------------
// W Channel
//----------------------------------------------------------------------------
// Combinational logic for the wstrb_next.It is derived from the three least
// significant bits of transfer address register and the size programmed in
// the control status word register.Unaligned transfers are not supported by
// the AXI-AP block.
//----------------------------------------------------------------------------
  always @(*)
    begin : p_wstrb_decode
    wstrb_next = {4{1'b0}};

      if (drw_wr_req) begin
        case(axi_size)
          AXIAP_BYTE :
            begin

              case(tar_l[1:0])
                2'b00   : wstrb_next[0] = 1'b1;
                2'b01   : wstrb_next[1] = 1'b1;
                2'b10   : wstrb_next[2] = 1'b1;
                2'b11   : wstrb_next[3] = 1'b1;

                default : wstrb_next = {4{1'b1}};
              endcase
            end
          AXIAP_HALF_WORD :
            begin

              case(tar_l[1])
                1'b0    : wstrb_next[1:0] = 2'b11;
                1'b1    : wstrb_next[3:2] = 2'b11;

                default : wstrb_next = {4{1'b1}};
              endcase
            end

          AXIAP_WORD : wstrb_next = {4{1'b1}};

          default : wstrb_next = {4{1'b1}};
        endcase
      end else begin

        wstrb_next = {4{1'b1}};
      end
    end

  assign wstrb_next_en = (fsm_state == WR_CMD) & ~awvalid_q;

  always @(posedge clk or negedge resetn)
    begin : p_wstrb
      if (!resetn)
        wstrb <= {4{1'b0}};
      else if (wstrb_next_en)
        wstrb <= wstrb_next;
    end

  assign wdata = rd_wr_data;

  always @(*)
    begin
      wvalid_sent_next = 1'b0;

      if (wvalid_sent) begin
        wvalid_sent_next = ((fsm_state == WR_CMD) | (fsm_state == WR_DT));
      end else begin
        wvalid_sent_next = wvalid_q & ((~wvalid_next));
      end
    end

  assign wvalid_sent_en = wvalid_sent_next ^ wvalid_sent;

  always @(posedge clk or negedge resetn)
    begin : p_wvalid_sent
      if (!resetn) begin
        wvalid_sent <= 1'b0;
      end else if (wvalid_sent_en) begin
        wvalid_sent <= wvalid_sent_next;
      end
    end

  always @(*)
    begin
      wvalid_next = 1'b0;

      if (!wvalid_sent)
        begin
          if (fsm_state == WR_CMD)
            begin
              wvalid_next = wvalid_q ? ~wready : 1'b1;
            end
          else if (fsm_state == WR_DT)
            begin
              wvalid_next = (~wready);
            end
        end
    end

  assign wvalid_en = wvalid_next ^ wvalid_q;

  always @(posedge clk or negedge resetn)
    begin : p_wvalid
      if (!resetn) begin
        wvalid_q    <= 1'b0;
        wlast       <= 1'b0;
      end else if (wvalid_en) begin
        wvalid_q    <= wvalid_next;
        wlast       <= wvalid_next;
      end
    end

  assign wvalid = wvalid_q;

endmodule
