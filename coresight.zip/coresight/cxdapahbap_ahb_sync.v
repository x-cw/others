//------------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2003-2013 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//    Checked In : $Date: 2013-09-12 19:02:23 +0100 (Thu, 12 Sep 2013) $
//    Revision   : $Revision: 37221 $
//    Release    : CoreSight-SoC-TM100-r3p1-00rel0
//------------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// Abstract : Debug Access Port AHB Access Port (DAPAHBAP)- hclk Synchronizers
//------------------------------------------------------------------------------
//
// DAPAHBAP - Debug Access Port AHB Access Port
// --------------------------------------------
//
// Debug Access Port AHB Access Port component provides an AHB-Lite interface to
// a System On Chip (SOC).
//
// cxdapahbap_ahb_sync.v
// -----------------
//
// cxdapahbap_ahb_sync.v provides the hclk domain synchronizers for the DAPAHBAP
// block.
//
// Instantiated blocks
// -------------------
// cx_en_sync.v      - 2 DFF synchronizer module, reset low
// cx_en_sync_high.v - 2 DFF synchronizer module, reset high
// Can be replaced with a 3 stage DFF synchronizer if required.
//------------------------------------------------------------------------------

module cxdapahbap_ahb_sync (
  // Inputs
  hclk, hclken, hresetn, dap_state_soc,
  // Outputs
  dap_state_sync
  );

  //----------------------------------------------------------------------------
  // Inputs
  //----------------------------------------------------------------------------
  input         hclk;           // AHB clock
  input         hclken;         // AHB clock enable
  input         hresetn;        // AHB asynchronous reset active low

  input [3:0]   dap_state_soc;  // DAP state from the DAP interface

  //----------------------------------------------------------------------------
  // Outputs
  //----------------------------------------------------------------------------
  output [3:0]  dap_state_sync; // DAP state (Synchronized)

  //---------------------------------------------------------------------------
  //
  // Main body of code
  // =================
  //
  //---------------------------------------------------------------------------

  //---------------------------------------------------------------------------
  // Double synchronizer instantiation for dap_state_sync[0] signal.
  //---------------------------------------------------------------------------
  cx_en_sync_high u_ahbap_ahb_sync_0
    (
     // Outputs
     .sync_do                   (dap_state_sync[0]),
     // Inputs
     .clk                       (hclk),
     .clken                     (hclken),
     .resetn                    (hresetn),
     .sync_di                   (dap_state_soc[0])
     );

  //---------------------------------------------------------------------------
  // Double synchronizer instantiation for dap_state_sync[1] signal.
  //---------------------------------------------------------------------------
  cx_en_sync u_ahbap_ahb_sync_1
    (
     // Outputs
     .sync_do                   (dap_state_sync[1]),
     // Inputs
     .clk                       (hclk),
     .clken                     (hclken),
     .resetn                    (hresetn),
     .sync_di                   (dap_state_soc[1])
     );

  //---------------------------------------------------------------------------
  // Double synchronizer instantiation for dap_state_sync[2] signal.
  //---------------------------------------------------------------------------
  cx_en_sync u_ahbap_ahb_sync_2
    (
     // Outputs
     .sync_do                   (dap_state_sync[2]),
     // Inputs
     .clk                       (hclk),
     .clken                     (hclken),
     .resetn                    (hresetn),
     .sync_di                   (dap_state_soc[2])
     );

  //---------------------------------------------------------------------------
  // Double synchronizer instantiation for dap_state_sync[3] signal.
  //---------------------------------------------------------------------------
  cx_en_sync u_ahbap_ahb_sync_3
    (
     // Outputs
     .sync_do                   (dap_state_sync[3]),
     // Inputs
     .clk                       (hclk),
     .clken                     (hclken),
     .resetn                    (hresetn),
     .sync_di                   (dap_state_soc[3])
     );

endmodule // cxdapahbap_ahb_sync
