+incdir+$GP3_RTL/coresight/rtl/coresight_component/models/cells/generic
$GP3_RTL/coresight/rtl/coresight_component/models/cells/generic/cx_en_sync_high.v
$GP3_RTL/coresight/rtl/coresight_component/models/cells/generic/cx_sync.v
$GP3_RTL/coresight/rtl/coresight_component/models/cells/generic/cx_cdc_corrupt_gry.v
$GP3_RTL/coresight/rtl/coresight_component/models/cells/generic/cxdapswjdp_dp_sync.v
$GP3_RTL/coresight/rtl/coresight_component/models/cells/generic/cx_en_sync.v
$GP3_RTL/coresight/rtl/coresight_component/models/cells/generic/cxdapswjdp_clk_inverter.v
$GP3_RTL/coresight/rtl/coresight_component/models/cells/generic/cx_comb_mux2.v
