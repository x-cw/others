//--========================================================================
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2003-2015 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//  Version and Release Control Information:
//
//  Checked In          : $Date: 2014-08-14 16:01:35 +0100 (Thu, 14 Aug 2014) $
//
//  File Revision       : $Revision: 39945 $
//
//  Release Information : CoreSight-SoC-TM100-r3p2-00rel0
// -----------------------------------------------------------------------------
// Purpose :
//           Embedded Cross Trigger parameters include file
//
// --=========================================================================--

//------------------------------------------------------------------------------
// NOT USER MODIFIABLE
//------------------------------------------------------------------------------
localparam ECTCHANNELWIDTH = 4;
