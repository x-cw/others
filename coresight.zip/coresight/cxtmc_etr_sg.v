//-----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//  
//            (C) COPYRIGHT 2009-2010 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//    Checked In :  2010-06-17 16:13:44 +0530 (Thu, 17 Jun 2010) 
//    Revision   :  8210 
//    Release    : TM961-BU-50000-r0p0-00rel0
//
//-----------------------------------------------------------------------------
// Purpose : CoreSight Trace Memory Controller (CXTMC) - Scatter Gather block
//            This block walks through the page table in scatter gather mode
//-----------------------------------------------------------------------------

module cxtmc_etr_sg
  //---------------------------------------------------------------------------
  // Port Declarations
  //---------------------------------------------------------------------------
  (
  // Inputs
  input wire         cxtmc_clk,          // Clock
  input wire         RESETn,             // Reset for the clock domain
  input wire         axictl_sg_mode,     // Scatter gather mode
  input wire         ctl_trace_capt_en,  // Indication that TMC is enabled
  input wire         ctl_trace_capt_en_0_1,
                                         // Indication of rising edge of
                                         // ctl_trace_capt_en
  input wire         tmc_ready,          // Status register bit
  input wire         mem_err,            // Indication that Error bit is set
  input wire [31:0]  dba_lo,             // DBALO register
  input wire [7:0]   dba_hi,             // DBAHI register
  input wire         dba_w_ready,
                                         // Request for new data buffer base
                                         // address for writing
  input wire         dba_r_ready,
                                         // Request for new data buffer base
                                         // address for reading
  input wire         pt_ready,           // Page table data is acknowledged
  input wire [27:0]  pt_data_hi,         // Page table data - higher order bits
  input wire [1:0]   pt_data_lo,         // Page table data - lower order bits

  // Outputs
  output reg         mem_err_pt,         // Memory error because of page table
                                         // access
  output reg         dba_w_valid,
                                         // Request for new data buffer base
                                         // address while writing is
                                         // acknowledged
  output reg         dba_r_valid,
                                         // Request for new data buffer base
                                         // address while reading is
                                         // acknowledged
  output wire [27:0] dba_w_addr,         // Current data buffer base address
                                         // for write
  output wire        dba_w_last,         // Current data buffer base address
                                         // Current data buffer base address
                                         // for write is last entry in page
                                         // table
  output wire [27:0] dba_r_addr,         // Current data buffer base address
                                         // for read
  output wire [39:0] pt_addr,            // Page table address
  output wire        sg_idle,            // Indication that SG block will no
                                         // more request for page table fetch
  output reg         pt_valid            // Page table address is valid
  );

  //---------------------------------------------------------------------------
  // Local Parameter declarations
  //---------------------------------------------------------------------------
  localparam CXTMC_PT_ENTRY_INVALID              = 2'b00;
  localparam CXTMC_LAST_PT_ENTRY                 = 2'b01;
  localparam CXTMC_PT_ENTRY_LLI                  = 2'b11;

  //---------------------------------------------------------------------------
  // Reg declarations
  //---------------------------------------------------------------------------

  reg        one_fetch_w_comp;    // Indication that an extra fetch (write) is
                                  // complete after ctl_trace_capt_en
                                  // is de-asserted
  reg        one_fetch_r_comp;    // Indication that an extra fetch (read) is
                                  // complete after ctl_trace_capt_en is
                                  // de-asserted
  reg [29:0] pt_data_w;           // One level storage for page table
                                  // descriptors in case of write
  reg [29:0] pt_data_r;           // One level storage for page table
                                  // descriptors in case of read
  reg [39:0] pt_w_addr;           // Next page table address for write
  reg [39:0] pt_r_addr;           // Next page table address for write
  reg        pt_valid_w_reg;      // Current page table fetch is for write
  reg        pt_valid_r;          // Current page table fetch is for read
  reg        pt_reload_link_w_reg;// Indication to reload the link in page table
  reg        pt_reload_link_r_reg;// Indication to reload the link in page table
  reg        first_pt_fetch;      // Indication that this was the first page
                                  // table fetch
  reg        sg_idle_reg;         // Registered version of nxt_sg_idle;

  //---------------------------------------------------------------------------
  // Wire declarations
  //---------------------------------------------------------------------------

  wire        pt_fetch_w;         // Indication to prefetch page table for
                                  // write
  wire        pt_fetch_r;         // Indication to prefetch page table for
                                  // read
  wire        pt_reload_link_w;   // Indication to reload the link list in
                                  // case of write
  wire        pt_reload_link_r;   // Indication to reload the link list in
                                  // case of read
  wire        pt_reload_base_w;   // Indication to reload the base address in
                                  // case of write
  wire        pt_reload_base_r;   // Indication to reload the base address in
                                  // case of read
  wire        nxt_pt_valid_w;     // Current page table fetch is for write
  wire        nxt_pt_valid_r;     // Current page table fetch is for read
  wire        nxt_one_fetch_w_comp;
                                  // D-Input of one_fetch_w_comp
  wire        nxt_one_fetch_r_comp;
                                  // D-Input of one_fetch_r_comp
  wire        nxt_pt_valid;       // D-Input of pt_valid
  wire        pt_data_w_en;       // Enable condition to load the link list item
                                  // in case of write
  wire        pt_data_r_en;       // Enable condition to load the link list item
                                  // in case of read
  wire [39:0] nxt_pt_w_addr;      // D-Input of pt_w_addr
  wire [39:0] nxt_pt_r_addr;      // D-Input of pt_r_addr
  wire        nxt_dba_w_valid;    // D-Input of nxt_dba_w_valid
  wire        nxt_dba_r_valid;    // D-Input of nxt_dba_r_valid
  wire        nxt_mem_err_pt;     // D-Input of mem_err_pt
  wire        mask_pt_req_mem_err;// Mask pt_request since there was an AXI
                                  // error
  wire        pt_valid_w;         // Current page table fetch is for write
  wire        nxt_sg_idle;        // D-Input of sg_idle
  wire        nxt_first_pt_fetch; // D-Input of first_pt_fetch

  // --------------------------------------------------------------------------
  //
  //  Main body of code
  //  =================
  //
  // --------------------------------------------------------------------------

  // --------------------------------------------------------------------------
  // pt_fetch_w/r :
  // ~~~~~~~~~~~~~~
  //   This signal indicates that we need to do a page table fetch in case of
  // write/read. Page table fetch is initiated when the one deep buffer does not
  // have latest prefetched data. Once the TMC is disabled the page table
  // fetch is requested to accomodate another 4KB chunk of data.
  // --------------------------------------------------------------------------
  assign pt_fetch_w = (ctl_trace_capt_en & (~dba_w_valid | dba_w_ready)) |
                      (~ctl_trace_capt_en & ~nxt_one_fetch_w_comp);
  
  assign pt_fetch_r = (ctl_trace_capt_en & (~dba_r_valid | dba_r_ready)) |
                      (~ctl_trace_capt_en & ~nxt_one_fetch_r_comp);
 
  // --------------------------------------------------------------------------
  // pt_reload_link_w/r :
  // ~~~~~~~~~~~~~~~~~~~~
  //    This signal indicates that page table address needs to be reloaded
  // with the link address. The indication is decoded in the last two bits of
  // the page table descriptors.
  // --------------------------------------------------------------------------
  assign pt_reload_link_w = (((pt_data_lo == CXTMC_PT_ENTRY_LLI) &&
                              pt_valid_w &&
                              pt_ready) ||
                             (pt_reload_link_w_reg && !pt_valid_w &&
                              !mem_err)) ? 1'b1 :
                              ((pt_reload_link_w_reg &&
                                 pt_valid_w) || mem_err) ?
                                            1'b0 : pt_reload_link_w_reg;


  assign pt_reload_link_r = (((pt_data_lo == CXTMC_PT_ENTRY_LLI) &&
                              pt_valid_r &&
                              pt_ready) ||
                             (pt_reload_link_r_reg && !pt_valid_r &&
                              !mem_err)) ? 1'b1 :
                              ((pt_reload_link_r_reg &&
                             pt_valid_r) || mem_err) ?
                                            1'b0 : pt_reload_link_r_reg;


  // --------------------------------------------------------------------------
  // Clock process to realize pt_reload_link_w_reg/pt_reload_link_r_reg register
  // --------------------------------------------------------------------------
  always @(posedge cxtmc_clk or negedge RESETn)
    begin : p_pt_reload_link_w_or_r_seq
      if (!RESETn)
        begin
          pt_reload_link_w_reg    <= 1'b0;
          pt_reload_link_r_reg    <= 1'b0;
        end
      else
        begin
          pt_reload_link_w_reg    <= pt_reload_link_w;
          pt_reload_link_r_reg    <= pt_reload_link_r;
        end
    end // p_pt_reload_link_w_or_r_seq

  // --------------------------------------------------------------------------
  // pt_reload_base_w/r :
  // ~~~~~~~~~~~~~~~~~~~~
  // This signal indicates that page table address needs to be reloaded with
  // the dba base address as programmed by the software. The lower two bits
  // decoding of the page table descriptor gives an indication that end of
  // page table is encountered and we need to wrap around to the beginning of
  // the page table as programmed by the dba.
  // --------------------------------------------------------------------------
  assign pt_reload_base_w = (pt_data_w[1:0] == CXTMC_LAST_PT_ENTRY) &
                            ~pt_valid_w;
  assign pt_reload_base_r = (pt_data_r[1:0] == CXTMC_LAST_PT_ENTRY) &
                            ~pt_valid_r;


  // --------------------------------------------------------------------------
  // pt_valid_w/r :
  // ~~~~~~~~~~~~~~
  // Indication that the current page table access is for write (pt_valid_w)
  // or for read (pt_valid_r). We have only one channel for page table access,
  // hence a flag indicating whether the current fetch is for read or write
  // will be useful in other places.
  // --------------------------------------------------------------------------
  assign nxt_pt_valid_w = (nxt_pt_valid && pt_fetch_w && !pt_valid_w) ?
                            1'b1 : ((pt_ready && !pt_reload_link_w) |
                                    mem_err) ? 1'b0 : pt_valid_w;

  assign nxt_pt_valid_r = ((nxt_pt_valid && !pt_valid_r &&
                             pt_fetch_r && !pt_fetch_w) |
                            (nxt_pt_valid && ctl_trace_capt_en_0_1)) ?
                            1'b1 : (pt_ready || mem_err) ? 1'b0 : pt_valid_r;

  // --------------------------------------------------------------------------
  // Clock process to realize pt_valid_w/pt_valid_r register
  // --------------------------------------------------------------------------
  always @(posedge cxtmc_clk or negedge RESETn)
    begin : p_pt_valid_w_or_r_seq
      if (!RESETn)
        begin
          pt_valid_w_reg <= 1'b0;
          pt_valid_r     <= 1'b0;
        end
      else
        begin
          pt_valid_w_reg <= nxt_pt_valid_w;
          pt_valid_r     <= nxt_pt_valid_r;
        end
    end // p_pt_valid_w_or_r_seq

  assign pt_valid_w = ~(pt_valid_r & ~first_pt_fetch) & pt_valid_w_reg;

  // --------------------------------------------------------------------------
  // mem_err_pt :
  // ~~~~~~~~~~~~
  // Memory error is asserted when we have a invalid page table descriptor,
  // this is possible when the page table set up has "00" in the last two
  // bits of the page table entry.
  // --------------------------------------------------------------------------
  assign nxt_mem_err_pt = (!mem_err_pt && pt_valid && pt_ready &&
                            (pt_data_lo == CXTMC_PT_ENTRY_INVALID))
                                                             ? 1'b1 : 1'b0; 

  // --------------------------------------------------------------------------
  // Clock process to realize one_fetch_w_comp register
  // --------------------------------------------------------------------------
  always @(posedge cxtmc_clk or negedge RESETn)
    begin : p_mem_err_pt_seq
      if (!RESETn)
        mem_err_pt    <= 1'b0;
      else
        mem_err_pt    <= nxt_mem_err_pt;
    end // p_mem_err_pt_seq
 
  // --------------------------------------------------------------------------
  // To mask further pagetable walk through when the mem_err is set.
  // --------------------------------------------------------------------------
  assign mask_pt_req_mem_err = mem_err_pt | mem_err;
 
  // --------------------------------------------------------------------------
  // one_fetch_w/r_comp :
  // ~~~~~~~~~~~~~~~~~~~~
  // When TraceCaptEn is pulled low we need to fetch one extra page table
  // entry which will point to 4KB of data buffer. These signals will be set
  // once that fetch has been completed.
  // --------------------------------------------------------------------------
  assign nxt_one_fetch_w_comp = (!ctl_trace_capt_en &&
                                  ((pt_valid_w &&
                                    pt_ready &&
                                    !pt_reload_link_w) ||
                                   dba_w_valid)) ||
                                 (mem_err && !ctl_trace_capt_en_0_1) ? 1'b1 :
                                 (ctl_trace_capt_en_0_1) ?
                                                     1'b0 : one_fetch_w_comp;
  
  assign nxt_one_fetch_r_comp = (!ctl_trace_capt_en &&
                                  ((pt_valid_r &&
                                    pt_ready &&
                                    !pt_reload_link_r) ||
                                   dba_r_valid)) ||
                                 (mem_err && !ctl_trace_capt_en_0_1) ? 1'b1 :
                                 (ctl_trace_capt_en_0_1) ?
                                                      1'b0 : one_fetch_r_comp;
  
  // --------------------------------------------------------------------------
  // Clock process to realize one_fetch_w_comp register
  // --------------------------------------------------------------------------
  always @(posedge cxtmc_clk or negedge RESETn)
    begin : p_one_fetch_w_comp_seq
      if (!RESETn)
        one_fetch_w_comp    <= 1'b0;
      else
        one_fetch_w_comp    <= nxt_one_fetch_w_comp;
    end // p_one_fetch_w_comp_seq
  
  // --------------------------------------------------------------------------
  // Clock process to realize one_fetch_r_comp register
  // --------------------------------------------------------------------------
  always @(posedge cxtmc_clk or negedge RESETn)
    begin : p_one_fetch_r_comp_seq
      if (!RESETn)
        one_fetch_r_comp    <= 1'b0;
      else
        one_fetch_r_comp    <= nxt_one_fetch_r_comp;
    end // p_one_fetch_r_comp_seq
  
  // --------------------------------------------------------------------------
  // Page table walk through either for read or write access.
  // --------------------------------------------------------------------------
  assign nxt_pt_valid = (axictl_sg_mode && !mask_pt_req_mem_err &&
                         (ctl_trace_capt_en_0_1 ||
                          (pt_fetch_w && (!pt_valid_w || pt_reload_link_w)) ||
                          (pt_fetch_r && !pt_valid_r && !pt_fetch_w))) ? 1'b1 :
                            (pt_ready || mem_err) ? 1'b0 : pt_valid;
  
  // --------------------------------------------------------------------------
  // Clock process to realize pt_valid register
  // --------------------------------------------------------------------------
  always @(posedge cxtmc_clk or negedge RESETn)
    begin : p_pt_valid_seq
      if (!RESETn)
        pt_valid    <= 1'b0;
      else
        pt_valid    <= nxt_pt_valid;
    end // p_pt_valid_seq
  
  // --------------------------------------------------------------------------
  // Flag to indicate that first page table fetch happened
  // --------------------------------------------------------------------------
  assign nxt_first_pt_fetch = (nxt_pt_valid && ctl_trace_capt_en_0_1) ? 1'b1 :
                               (pt_ready) ? 1'b0 : first_pt_fetch;

  // --------------------------------------------------------------------------
  // Clock process to realize first_pt_fetch register
  // --------------------------------------------------------------------------
  always @(posedge cxtmc_clk or negedge RESETn)
    begin : p_first_pt_fetch_seq
      if (!RESETn)
        begin
          first_pt_fetch <= 1'b0;
        end
      else
        begin
          first_pt_fetch <= nxt_first_pt_fetch;
        end
    end // p_first_pt_fetch_seq

  // --------------------------------------------------------------------------
  // Enable to clock in the data from AXI master interface.
  // --------------------------------------------------------------------------
  assign pt_data_w_en = pt_ready & pt_valid_w;
  
  // --------------------------------------------------------------------------
  // Clock process to realize pt_data_w register
  // --------------------------------------------------------------------------
  always @(posedge cxtmc_clk or negedge RESETn)
    begin
      if (!RESETn)
        pt_data_w <= 30'h0;
      else if (pt_data_w_en)
        pt_data_w <= {pt_data_hi, pt_data_lo};
    end
  
  // --------------------------------------------------------------------------
  // Enable to clock in the data from AXI master interface.
  // --------------------------------------------------------------------------
  assign pt_data_r_en = pt_ready & pt_valid_r;
  
  // --------------------------------------------------------------------------
  // Clock process to realize pt_data_r register
  // --------------------------------------------------------------------------
  always @(posedge cxtmc_clk or negedge RESETn)
    begin
      if (!RESETn)
        pt_data_r <= 30'h0;
      else if (pt_data_r_en)
        pt_data_r <= {pt_data_hi, pt_data_lo};
    end
  
  // --------------------------------------------------------------------------
  // pt_w/r_addr :
  // ~~~~~~~~~~~~~
  // While walking through the page table, the page table address has to be
  // generated. Each page table entry is offsetted by 0x4 bytes in system
  // memory, hence most of the times after the current fetch, the address is
  // incremented by 0x4, there are ocassions when we need to jump to the link
  // address based on the lower two bits decode and when we hit the last page
  // table buffer we need to jump to the start of the page table.
  // --------------------------------------------------------------------------
  assign nxt_pt_w_addr = (ctl_trace_capt_en_0_1 || pt_reload_base_w) ?
                           {dba_hi, dba_lo} :
                           (pt_valid_w && pt_ready &&
                            !pt_reload_link_w) ? pt_w_addr + 40'h4 :
                           (pt_valid_w && pt_ready &&
                            pt_reload_link_w) ? {pt_data_hi, 12'h0} :
                            (pt_reload_link_w) ? {pt_data_w[29:2], 12'h0} :
                              pt_w_addr; 
  
  assign nxt_pt_r_addr = (ctl_trace_capt_en_0_1 || pt_reload_base_r) ?
                           {dba_hi, dba_lo} :
                           (pt_valid_r && pt_ready &&
                            !pt_reload_link_r) ? pt_r_addr + 40'h4 :
                           (pt_valid_r && pt_ready &&
                            pt_reload_link_r) ? {pt_data_hi, 12'h0} :
                            (pt_reload_link_r) ? {pt_data_r[29:2], 12'h0} :
                              pt_r_addr; 
  
  // --------------------------------------------------------------------------
  // Clock process to realize pt_w_addr register
  // --------------------------------------------------------------------------
  always @(posedge cxtmc_clk or negedge RESETn)
    begin : p_pt_w_addr_seq
      if (!RESETn)
        pt_w_addr    <= 40'h0;
      else
        pt_w_addr    <= nxt_pt_w_addr;
    end // p_pt_w_addr_seq

  // --------------------------------------------------------------------------
  // Clock process to realize pt_r_addr register
  // --------------------------------------------------------------------------
  always @(posedge cxtmc_clk or negedge RESETn)
    begin : p_pt_r_addr_seq
      if (!RESETn)
        pt_r_addr    <= 40'h0;
      else
        pt_r_addr    <= nxt_pt_r_addr;
    end // p_pt_r_addr_seq
  
  // --------------------------------------------------------------------------
  // The current page table address depends on whether the fetch is for write
  // or read
  // --------------------------------------------------------------------------
  assign pt_addr = (pt_valid_w) ? pt_w_addr : pt_r_addr;
  
  // --------------------------------------------------------------------------
  // dba_w/r_valid :
  // ~~~~~~~~~~~~~~~
  // Once we have latest page table entry for read/write we need to present
  // the latest dba address to the AXI interface so that the next trace data
  // can be written into these 4K locations. These valid signals should be
  // sustained until tmc_ready goes high.
  // --------------------------------------------------------------------------
  assign nxt_dba_w_valid = (!dba_w_valid &&
                             pt_valid_w && pt_ready &&
                             !pt_reload_link_w &&
                             (!tmc_ready || ctl_trace_capt_en)) ? 1'b1 :
                               (dba_w_ready ||
                                (tmc_ready && !ctl_trace_capt_en)) ? 1'b0 :
                                                                   dba_w_valid;
  
  assign nxt_dba_r_valid = (!dba_r_valid &&
                             pt_valid_r && pt_ready &&
                             !pt_reload_link_r &&
                             (!tmc_ready || ctl_trace_capt_en)) ? 1'b1 :
                               (dba_r_ready ||
                                (tmc_ready && !ctl_trace_capt_en)) ? 1'b0 :
                                                                   dba_r_valid;
  
  // --------------------------------------------------------------------------
  // Clock process to realize dba_w_valid register
  // --------------------------------------------------------------------------
  always @(posedge cxtmc_clk or negedge RESETn)
    begin : p_dba_w_valid_seq
      if (!RESETn)
        dba_w_valid    <= 1'b0;
      else
        dba_w_valid    <= nxt_dba_w_valid;
    end // p_dba_w_valid_seq
  
  // --------------------------------------------------------------------------
  // Clock process to realize dba_r_valid register
  // --------------------------------------------------------------------------
  always @(posedge cxtmc_clk or negedge RESETn)
    begin : p_dba_r_valid_seq
      if (!RESETn)
        dba_r_valid    <= 1'b0;
      else
        dba_r_valid    <= nxt_dba_r_valid;
    end // p_dba_r_valid_seq
  
  // --------------------------------------------------------------------------
  // Address and last indications are derived from the 1 deep descriptor
  // storage for both read and write page tables.
  // --------------------------------------------------------------------------
  assign dba_r_addr = pt_data_r[29:2];
  assign dba_w_addr = pt_data_w[29:2];
  assign dba_w_last = (pt_data_w[1:0] == CXTMC_LAST_PT_ENTRY);

  assign nxt_sg_idle = (ctl_trace_capt_en_0_1 ||
                        (nxt_pt_valid && ctl_trace_capt_en)) ? 1'b0 :
                        ((one_fetch_r_comp && one_fetch_w_comp) ||
                         (!nxt_pt_valid && ctl_trace_capt_en)) ? 1'b1:
                         sg_idle;

  // --------------------------------------------------------------------------
  // Clock process to realize dba_r_valid register
  // --------------------------------------------------------------------------
  always @(posedge cxtmc_clk or negedge RESETn)
    begin : p_sg_idle_seq
      if (!RESETn)
        sg_idle_reg    <= 1'b1;
      else
        sg_idle_reg    <= nxt_sg_idle;
    end // p_sg_idle_seq
  assign sg_idle = sg_idle_reg & ~nxt_pt_valid; 

  //============================================================================
  // ASSERTIONS
  //============================================================================
`ifdef ARM_ASSERT_ON
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : pt_valid_w is sustained when pt_reload_link_w_reg is set hence this condition will not occur.")
      uzovl_cxtmc_etr_sg_000
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   ({pt_reload_link_w_reg, ((!pt_valid_w)), ((!mem_err))} == {1'b1,1'b1,1'b1})
        );
        
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message :pt_valid_w is sustained when pt_reload_link_w_reg is set hence this condition will not occur.")
      uzovl_cxtmc_etr_sg_001
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   ({((pt_data_lo==CXTMC_PT_ENTRY_LLI) && pt_valid_w && pt_ready), (pt_reload_link_w_reg && ((!pt_valid_w)) && ((!mem_err)))} == {1'b0,1'b1})
        );
        
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : Once mem_err_pt is asserted, no new page table fetches will be requested")
      uzovl_cxtmc_etr_sg_002
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   ({((!mem_err_pt)), pt_valid, pt_ready, (pt_data_lo==CXTMC_PT_ENTRY_INVALID)} == {1'b0,1'b1, 1'b1, 1'b1})
        );
        
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : pt_valid_w is sustained till non-link list item item is loaded.")
      uzovl_cxtmc_etr_sg_003
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   ({pt_valid_w, pt_ready, pt_reload_link_w} == {1'b0, 1'b1, 1'b1})
        );
        
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : New pt_valid are not asserted if the TMC is stopped.")
      uzovl_cxtmc_etr_sg_004
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   ({((!dba_w_valid)), pt_valid_w, pt_ready, ((!pt_reload_link_w)), (((!tmc_ready))||ctl_trace_capt_en)} == {1'b1, 1'b1, 1'b1, 1'b1, 1'b0})
        );
        
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : New pt_valid are not asserted if dba_r_valid is already asserted.")
      uzovl_cxtmc_etr_sg_005
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   ({((!dba_r_valid)), pt_valid_r, pt_ready, ((!pt_reload_link_r)), (((!tmc_ready))||ctl_trace_capt_en)} == {1'b1, 1'b1, 1'b1, 1'b1, 1'b0})
        );
        
`endif
    
endmodule
