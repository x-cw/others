module atb_formatter(
        /*autoarg*/
   // Outputs
   ts_mst_rd_ptr_gry_m, ts_mst_lp_ack_m,
   atb_slv_syncreqs_ack_async_out, atb_slv_atb_fwd_data_out,
   // Inputs
   ts_mst_wr_ptr_gry_m, ts_mst_lp_req_m, ts_mst_encd_data2_m,
   ts_mst_encd_data1_m, ts_mst_encd_data0_m, pkt_vld, pkt_tail,
   pkt_head, pkt_data, control_reg, clken, atid_static,
   atb_slv_zero_pointer_d, atb_slv_syncreqs_req_async_in,
   atb_slv_atb_rev_data_in, clk, por_rstn, dft_test_mode,
   dft_test_rstn
   );

input clk;
input por_rstn;
input dft_test_mode;
input dft_test_rstn;
/*autoinput*/
// Beginning of automatic inputs (from unused autoinst inputs)
input [4:0]             atb_slv_atb_rev_data_in;// To u_cxatbasyncbridge_slv of cxatbasyncbridge_slv_128.v
input                   atb_slv_syncreqs_req_async_in;// To u_cxatbasyncbridge_slv of cxatbasyncbridge_slv_128.v
input                   atb_slv_zero_pointer_d; // To u_cxatbasyncbridge_slv of cxatbasyncbridge_slv_128.v
input [6:0]             atid_static;            // To u_pkt2atb of pkt2atb.v
input                   clken;                  // To u_pkt2atb of pkt2atb.v, ...
input [31:0]            control_reg;            // To u_pkt2atb of pkt2atb.v
input [63:0]            pkt_data;               // To u_pkt2atb of pkt2atb.v
input                   pkt_head;               // To u_pkt2atb of pkt2atb.v
input                   pkt_tail;               // To u_pkt2atb of pkt2atb.v
input                   pkt_vld;                // To u_pkt2atb of pkt2atb.v
input [8:0]             ts_mst_encd_data0_m;    // To u_cxntsasyncbridge_mst of cxntsasyncbridge_mst.v
input [8:0]             ts_mst_encd_data1_m;    // To u_cxntsasyncbridge_mst of cxntsasyncbridge_mst.v
input [8:0]             ts_mst_encd_data2_m;    // To u_cxntsasyncbridge_mst of cxntsasyncbridge_mst.v
input                   ts_mst_lp_req_m;        // To u_cxntsasyncbridge_mst of cxntsasyncbridge_mst.v
input [3:0]             ts_mst_wr_ptr_gry_m;    // To u_cxntsasyncbridge_mst of cxntsasyncbridge_mst.v
// End of automatics
/*autooutput*/
// Beginning of automatic outputs (from unused autoinst outputs)
output [844:0]          atb_slv_atb_fwd_data_out;// From u_cxatbasyncbridge_slv of cxatbasyncbridge_slv_128.v
output                  atb_slv_syncreqs_ack_async_out;// From u_cxatbasyncbridge_slv of cxatbasyncbridge_slv_128.v
output                  ts_mst_lp_ack_m;        // From u_cxntsasyncbridge_mst of cxntsasyncbridge_mst.v
output [3:0]            ts_mst_rd_ptr_gry_m;    // From u_cxntsasyncbridge_mst of cxntsasyncbridge_mst.v
// End of automatics
/*autoinout*/
/*autowire*/
// Beginning of automatic wires (for undeclared instantiated-module outputs)
wire                    afreadym;               // From u_pkt2atb of pkt2atb.v
wire                    afvalidm;               // From u_cxatbasyncbridge_slv of cxatbasyncbridge_slv_128.v
wire [3:0]              atbytesm;               // From u_pkt2atb of pkt2atb.v
wire [127:0]            atdatam;                // From u_pkt2atb of pkt2atb.v
wire [6:0]              atidm;                  // From u_pkt2atb of pkt2atb.v
wire                    atreadym;               // From u_cxatbasyncbridge_slv of cxatbasyncbridge_slv_128.v
wire                    atvalidm;               // From u_pkt2atb of pkt2atb.v
wire                    syncreqm;               // From u_cxatbasyncbridge_slv of cxatbasyncbridge_slv_128.v
wire [6:0]              tsbitm;                 // From u_cxntsasyncbridge_mst of cxntsasyncbridge_mst.v
wire [1:0]              tssyncm;                // From u_cxntsasyncbridge_mst of cxntsasyncbridge_mst.v
wire                    tssyncreadym;           // From u_cxtsd of cxtsd.v
wire [63:0]             tsvalue;                // From u_cxtsd of cxtsd.v
// End of automatics
/*autoreg*/

wire resetn;
reset_sync_dft rst_sync_clk(.dft_test_mode(dft_test_mode)  ,
                            .dft_test_rstn(dft_test_rstn)  ,
                            .rst_n        (por_rstn)   ,
                            .clk          (clk)  ,
                            .rst_n_sync   (resetn));
/*
pkt2atb auto_template  (
                  .clkenm               (clken),
                  .reset_n              (resetn),
);
*/
pkt2atb u_pkt2atb(/*autoinst*/
                  // Outputs
                  .atvalidm             (atvalidm),
                  .atidm                (atidm[6:0]),
                  .atbytesm             (atbytesm[3:0]),
                  .atdatam              (atdatam[127:0]),
                  .afreadym             (afreadym),
                  // Inputs
                  .clk                  (clk),
                  .reset_n              (resetn),                // Templated
                  .control_reg          (control_reg[31:0]),
                  .atid_static          (atid_static[6:0]),
                  .pkt_vld              (pkt_vld),
                  .pkt_head             (pkt_head),
                  .pkt_tail             (pkt_tail),
                  .pkt_data             (pkt_data[63:0]),
                  .tsvalue              (tsvalue[63:0]),
                  .clkenm               (clken),                 // Templated
                  .atreadym             (atreadym),
                  .afvalidm             (afvalidm),
                  .syncreqm             (syncreqm));
/*
cxatbasyncbridge_slv_128 auto_template  (
                    .clks             (clk),
                    .resetsn          (resetn),
                    .clkens           (clken),
                    .\(.*\)s          (\1m[]),
                    .\(.*\)           (atb_slv_\1[]),
);
*/
cxatbasyncbridge_slv_128 u_cxatbasyncbridge_slv(/*autoinst*/
                                                // Outputs
                                                .atreadys       (atreadym),      // Templated
                                                .afvalids       (afvalidm),      // Templated
                                                .syncreqs       (syncreqm),      // Templated
                                                .atb_fwd_data_out(atb_slv_atb_fwd_data_out[6*139+10:0]), // Templated
                                                .syncreqs_ack_async_out(atb_slv_syncreqs_ack_async_out), // Templated
                                                // Inputs
                                                .clks           (clk),           // Templated
                                                .clkens         (clken),         // Templated
                                                .resetsn        (resetn),        // Templated
                                                .atvalids       (atvalidm),      // Templated
                                                .atids          (atidm[6:0]),    // Templated
                                                .atbytess       (atbytesm[3:0]), // Templated
                                                .atdatas        (atdatam[128-1:0]), // Templated
                                                .afreadys       (afreadym),      // Templated
                                                .atb_rev_data_in(atb_slv_atb_rev_data_in[4:0]), // Templated
                                                .zero_pointer_d (atb_slv_zero_pointer_d), // Templated
                                                .syncreqs_req_async_in(atb_slv_syncreqs_req_async_in)); // Templated


/*
cxntsasyncbridge_mst auto_template  (
                    .clkm             (clk),
                    .resetmn          (resetn),
                    .\(ts.*\)         (\1[]),
                    .\(.*\)           (ts_mst_\1[]),
);
*/
cxntsasyncbridge_mst u_cxntsasyncbridge_mst(/*autoinst*/
                                            // Outputs
                                            .rd_ptr_gry_m       (ts_mst_rd_ptr_gry_m[3:0]), // Templated
                                            .lp_ack_m           (ts_mst_lp_ack_m), // Templated
                                            .tsbitm             (tsbitm[6:0]),   // Templated
                                            .tssyncm            (tssyncm[1:0]),  // Templated
                                            // Inputs
                                            .clkm               (clk),           // Templated
                                            .resetmn            (resetn),        // Templated
                                            .wr_ptr_gry_m       (ts_mst_wr_ptr_gry_m[3:0]), // Templated
                                            .encd_data0_m       (ts_mst_encd_data0_m[8:0]), // Templated
                                            .encd_data1_m       (ts_mst_encd_data1_m[8:0]), // Templated
                                            .encd_data2_m       (ts_mst_encd_data2_m[8:0]), // Templated
                                            .lp_req_m           (ts_mst_lp_req_m), // Templated
                                            .tssyncreadym       (tssyncreadym));         // Templated
/*
cxtsd auto_template  (
                    .clk              (clk),
                    .resetn           (resetn),
                    .tsvalue          (tsvalue[]),
                    .\(.*\)           (\1m[]),
);
*/
cxtsd u_cxtsd(/*autoinst*/
              // Outputs
              .tssyncready              (tssyncreadym),          // Templated
              .tsvalue                  (tsvalue[63:0]),         // Templated
              // Inputs
              .clk                      (clk),                   // Templated
              .resetn                   (resetn),                // Templated
              .tsbit                    (tsbitm[6:0]),           // Templated
              .tssync                   (tssyncm[1:0]));                 // Templated

endmodule
// Local Variables:
// verilog-library-directories:("./" "../../coresight_component/trace_module/cxatbasyncbridge_slv/verilog" "../../coresight_component/timestamp_module/cxntsasyncbridge_mst/verilog" "../../coresight_component/timestamp_module/cxtsd/verilog") 
// verilog-auto-inst-param-value:t
// End:
