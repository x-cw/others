//-----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2012-2015 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//      Checked In          : $Date: 2013-09-06 13:56:23 +0100 (Fri, 06 Sep 2013) $
//      Revision            : $Revision: 37052 $
//      Release Information : CoreSight-SoC-TM100-r3p2-00rel0
//-----------------------------------------------------------------------------
//      Purpose:
//        Clock inverter cell model
//        To be replaced with cell from target library.
//-----------------------------------------------------------------------------

module cxdapswjdp_clk_inverter (
  // Inputs
  input  wire clk,          // Incoming clock

  // Outputs
  output wire clkn          // Inverted clock
  );

  //----------------------------------------------------------------------------
  // Clock inversion
  //----------------------------------------------------------------------------
  //assign clkn = ~clk;
  cell_inverter cell_inverter_u
  (
    .A(clk    ),
    .X(clkn   )  
  );

endmodule
