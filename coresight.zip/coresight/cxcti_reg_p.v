//-----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2003-2015 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//    Checked In : $Date: 2014-08-14 16:01:35 +0100 (Thu, 14 Aug 2014) $
//    Revision   : $Revision: 39945 $
//    Release    : CoreSight-SoC-TM100-r3p2-00rel0
//
//-----------------------------------------------------------------------------
//      Purpose             : ECT Register Module for the PCLK clock domain
// --=========================================================================--

module cxcti_reg_p
  (
  // Inputs
  presetdbgn, pclkdbg, pclkendbg, paddrdbg, pwritedbg, pwdatadbg, cp_req,
  paddrdbg31,
  // Outputs
  cp_rdata, device_un_locked
  );

`include "cxcti_constants.v"

  //----------------------------------------------------------------------------
  // INPUTS
  //----------------------------------------------------------------------------
  // System controls
  input                        presetdbgn;       // Reset
  input                        pclkdbg;          // pclkdbg
  input                        pclkendbg;        // pclkdbg Enable

  // Transfer control inputs PLCK domain
  input [11:2]                 paddrdbg;         // Transfer address
  input                        pwritedbg;        // Transfer write control
  input [31:0]                 pwdatadbg;        // Transfer write data
  input                        cp_req;           // Transfer request
  input                        paddrdbg31;       // APB marker to bypass lock access

  //----------------------------------------------------------------------------
  // OUTPUTS
  //----------------------------------------------------------------------------

  // Transfer control inputs PLCK domain
  output [19:0]                cp_rdata;         // Transfer read data
  output                       device_un_locked; // Lock Mode

  //----------------------------------------------------------------------------
  // WIRES AND REGS
  //----------------------------------------------------------------------------
  wire                         p_read_req;
  wire                         p_write_req;
  wire                         p_write_req_no_lock;
  wire [19:0]                  component_id_0_r_data;
  wire                         component_id_0_read;
  wire [19:0]                  component_id_1_r_data;
  wire                         component_id_1_read;
  wire [19:0]                  component_id_2_r_data;
  wire                         component_id_2_read;
  wire [19:0]                  component_id_3_r_data;
  wire                         component_id_3_read;
  wire [19:0]                  peripheral_id_0_r_data;
  wire                         peripheral_i_d_0_read;
  wire [19:0]                  peripheral_id_1_r_data;
  wire                         peripheral_id_1_read;
  wire [19:0]                  peripheral_id_2_r_data;
  wire                         peripheral_id_2_read;
  wire [19:0]                  peripheral_id_3_r_data;
  wire                         peripheral_id_3_read;
  wire                         lock_access_en;
  wire                         device_un_locked;
  wire                         device_un_locked_int;
  reg                          device_unlocked_cdc_check;
  wire                         next_locked;
  wire                         sw_lck_sts_rd_en;
  wire [19:0]                  sw_lck_sts_rd_data;
  wire [19:0]                  device_id_r_data;
  wire                         device_id_read;
  wire [19:0]                  device_type_id_r_data;
  wire                         device_type_id_read;
  wire [19:0]                  peripheral_id_4_r_data;
  wire                         peripheral_id_4_read;
  wire                         claim_tag_en;
  wire [3:0]                   new_claim_tag;
  reg [3:0]                    claim_tag;
  wire                         claim_tag_set_read;
  wire [19:0]                  claim_tag_set_r_data;
  wire                         claim_tag_clr_read;
  wire [19:0]                  claim_tag_clr_r_data;
  wire [19:0]                  cp_rdata;
  reg [3:0]                    periph_id_3_rev_and_reg; // Register for Rev-And data

  //----------------------------------------------------------------------------
  //
  // MAIN CODE
  //
  //----------------------------------------------------------------------------

  //----------------------------------------------------------------------------
  // p_read_req
  //----------------------------------------------------------------------------

  assign    p_read_req = cp_req & ~pwritedbg;

  assign    p_write_req = cp_req & pwritedbg & (device_un_locked_int | paddrdbg31);

  assign    p_write_req_no_lock = cp_req & pwritedbg;

  //----------------------------------------------------------------------------
  // ComponentID0 Register (R)
  //----------------------------------------------------------------------------

  assign      component_id_0_r_data = {{12{1'b0}},
                                      CXCTI_COMPONID0_VAL };

  assign      component_id_0_read = (
                                     (paddrdbg == CXCTI_COMPONID0_ADD) &
                                     p_read_req);


  //----------------------------------------------------------------------------
  // ComponentID1 Register (R)
  //----------------------------------------------------------------------------

  assign      component_id_1_r_data = {{12{1'b0}},
                                      CXCTI_COMPONID1_VAL };

  assign      component_id_1_read = (
                                     (paddrdbg == CXCTI_COMPONID1_ADD) &
                                     p_read_req);

  //----------------------------------------------------------------------------
  // ComponentID2 Register (R)
  //----------------------------------------------------------------------------

  assign      component_id_2_r_data = {{12{1'b0}},
                                      CXCTI_COMPONID2_VAL };

  assign      component_id_2_read = (
                                     (paddrdbg == CXCTI_COMPONID2_ADD) &
                                     p_read_req);

  //----------------------------------------------------------------------------
  // ComponentID3 Register (R)
  //----------------------------------------------------------------------------

  assign      component_id_3_r_data = {{12{1'b0}},
                                      CXCTI_COMPONID3_VAL };

  assign      component_id_3_read = (
                                     (paddrdbg == CXCTI_COMPONID3_ADD) &
                                     p_read_req);


  //----------------------------------------------------------------------------
  // PeripheralID0 Register (R)
  //----------------------------------------------------------------------------

  assign      peripheral_id_0_r_data = {{12{1'b0}},
                                       CXCTI_PERIPHID0_VAL};

  assign      peripheral_i_d_0_read = (
                                      (paddrdbg == CXCTI_PERIPHID0_ADD) &
                                      p_read_req);


  //----------------------------------------------------------------------------
  // PeripheralID1 Register (R)
  //----------------------------------------------------------------------------

  assign      peripheral_id_1_r_data = {{12{1'b0}},
                                       CXCTI_PERIPHID1_VAL};

  assign      peripheral_id_1_read = (
                                      (paddrdbg == CXCTI_PERIPHID1_ADD) &
                                      p_read_req);

  //----------------------------------------------------------------------------
  // PeripheralID2 Register (R)
  //----------------------------------------------------------------------------

  assign      peripheral_id_2_r_data = {{12{1'b0}},
                                       CXCTI_PERIPHID2_VAL};

  assign      peripheral_id_2_read = (
                                      (paddrdbg == CXCTI_PERIPHID2_ADD) &
                                      p_read_req);

  //----------------------------------------------------------------------------
  // PeripheralID3 Register (R)
  //----------------------------------------------------------------------------

  assign      peripheral_id_3_r_data = {{12{1'b0}}, periph_id_3_rev_and_reg[3:0],
                                       CXCTI_PERIPHID3_CUSTOM_VAL };


  assign      peripheral_id_3_read = (
                                      (paddrdbg == CXCTI_PERIPHID3_ADD) &
                                      p_read_req);

  // The Rev-And data (bits 7:4) should be driven from a register so that it
  // can be easily changed in the netlist.
  //
  // No Reset is required because this register cannot be read in the first
  // cycle after reset.
  always @(posedge pclkdbg)
    begin
      periph_id_3_rev_and_reg[3:0] <= CXCTI_PERIPHID3_REVAND_VAL;
    end

  // ---------------------------------------------------------------------------
  // Lock Access register    : Offset 0xFB0 ( W )
  // ---------------------------------------------------------------------------
  // Modifications are ignored for paddrdbg31==1

  // Device is locked from reset
  always @(posedge pclkdbg or negedge presetdbgn)
    if (!presetdbgn)
      device_unlocked_cdc_check  <= 1'b0;
    else
      if (lock_access_en)
        device_unlocked_cdc_check  <= next_locked;

  // only write if this is not external!
  assign lock_access_en = (pclkendbg & p_write_req_no_lock & ~paddrdbg31 &
                           (paddrdbg == CXCTI_LOCKACCESS_ADD));
  assign next_locked    = (pwdatadbg == 32'hC5ACCE55);

  // ---------------------------------------------------------------------------
  // Lock Status register    : Offset 0xFB4 ( R )
  // ---------------------------------------------------------------------------
  // This either reads as zero for paddrdbg31==1 or present for paddrdbg31==0

  assign sw_lck_sts_rd_en   = (p_read_req & (paddrdbg == CXCTI_LOCKSTATUS_ADD)
                              & ~paddrdbg31);
  assign sw_lck_sts_rd_data = { {17{1'b0}},
                              CXCTI_LOCKSTATUS_8BIT_VAL,
                              ~device_un_locked_int,
                              CXCTI_LOCKSTATUS_PRESENT_VAL};

  //----------------------------------------------------------------------------
  // Device ID Register (R)
  //----------------------------------------------------------------------------

  assign device_id_r_data[19:16] = CSSOC_ECTCHANNELWIDTH;
  assign device_id_r_data[15: 8] = CSSOC_ECTTRIGGERWIDTH;
  assign device_id_r_data[ 7: 0] = CSSOC_EXTMUXNUM;

  assign      device_id_read = (
                              (paddrdbg == CXCTI_DEVID_ADD) &
                               p_read_req);

  //----------------------------------------------------------------------------
  // DeviceTypeID Register (R)
  //----------------------------------------------------------------------------

  assign      device_type_id_r_data = {{12{1'b0}},
                                      CXCTI_DEVTYPE_VAL};

  assign      device_type_id_read = (
                                     (paddrdbg == CXCTI_DEVTYPE_ADD) &
                                     p_read_req);

  //----------------------------------------------------------------------------
  // PeripheralID4 Register (R)
  //----------------------------------------------------------------------------

  assign      peripheral_id_4_r_data = {{12{1'b0}},
                                       CXCTI_PERIPHID4_VAL};

  assign      peripheral_id_4_read = (
                                      (paddrdbg == CXCTI_PERIPHID4_ADD) &
                                      p_read_req);

  //----------------------------------------------------------------------------
  // PeripheralID5-7 are RAZ
  //----------------------------------------------------------------------------

  //----------------------------------------------------------------------------
  // Claim Tag Register (R/W)
  // Used by software tools when about to begin a session with devices. Setting
  // bits indicates to any other interrogating tools that this device is being
  // programmed or has been programmed.
  //
  // Accessed using two registers:
  // 0xFA0 - Claim Tag Set
  //       - read:  0 - claim bit not implemmentated, 1 - claim bit implemented
  //       - Write: 0 - no effect, 1 - set claim bit
  //
  // 0xFA4 - Claim Tag Clear
  //       - read:  Current value of claim bit
  //       - Write: 0 - no effect, 1 - clean claim bit
  //----------------------------------------------------------------------------

  assign claim_tag_en = (pclkendbg &
                         ((paddrdbg == CXCTI_CLAIMSET_ADD) |
                          (paddrdbg == CXCTI_CLAIMCLR_ADD)) &
                         p_write_req);

  assign new_claim_tag = (paddrdbg == CXCTI_CLAIMSET_ADD) ?
                         (claim_tag | pwdatadbg[3:0]) :
                           (claim_tag & ~pwdatadbg[3:0]);

  always @(posedge pclkdbg or negedge presetdbgn)
    begin
      if (!presetdbgn)
        claim_tag   <= 4'h0;
      else if (claim_tag_en)
        claim_tag   <= new_claim_tag;
    end

  assign claim_tag_set_read = (
                               (paddrdbg == CXCTI_CLAIMSET_ADD) &
                               p_read_req);

  assign claim_tag_set_r_data = {{16{1'b0}},CXCTI_CLAIMSET_VAL};

  assign claim_tag_clr_read = (
                                (paddrdbg == CXCTI_CLAIMCLR_ADD) &
                                p_read_req);

  assign claim_tag_clr_r_data = {{16{1'b0}},claim_tag};

  //----------------------------------------------------------------------------
  // read Interface
  // read Data is registered in the APB Interface Block
  //----------------------------------------------------------------------------

  assign      cp_rdata = (
                         ({20{component_id_3_read}} & component_id_3_r_data) |
                         ({20{component_id_2_read}} & component_id_2_r_data) |
                         ({20{component_id_1_read}} & component_id_1_r_data) |
                         ({20{component_id_0_read}} & component_id_0_r_data) |
                         ({20{peripheral_id_4_read}} & peripheral_id_4_r_data) |
                         ({20{peripheral_id_3_read}} & peripheral_id_3_r_data) |
                         ({20{peripheral_id_2_read}} & peripheral_id_2_r_data) |
                         ({20{peripheral_id_1_read}} & peripheral_id_1_r_data) |
                         ({20{peripheral_i_d_0_read}} & peripheral_id_0_r_data) |
                         ({20{sw_lck_sts_rd_en}} & sw_lck_sts_rd_data) |
                         ({20{device_id_read}} & device_id_r_data) |
                         ({20{device_type_id_read}} & device_type_id_r_data) |
                         ({20{claim_tag_set_read}} & claim_tag_set_r_data) |
                         ({20{claim_tag_clr_read}} & claim_tag_clr_r_data)
                         );

`ifdef ARM_ASSERT_ON
  //----------------------------------------------------------------------------
  // OVL Assertions
  //----------------------------------------------------------------------------

  //----------------------------------------------------------------------------
  // read enables should be mutually exclusive.
  //----------------------------------------------------------------------------

  assert_zero_one_hot #(`OVL_WARNING, 14, `OVL_ASSERT,
    "OVL message : cxcti_reg_p - read enables should be exclusive")
      cxcti_reg_p
        (
         .clk         (pclkdbg),
         .reset_n     (presetdbgn),
         .test_expr   ({component_id_3_read,component_id_2_read,component_id_1_read,
                        component_id_0_read,peripheral_id_4_read,peripheral_id_3_read,
                        peripheral_id_2_read,peripheral_id_1_read,peripheral_i_d_0_read,
                        sw_lck_sts_rd_en,device_id_read,
                        device_type_id_read,claim_tag_set_read,claim_tag_clr_read})
        );

`endif


`ifdef ARM_CDC_ON
    cdc_connect u_cdc_deviceunlocked(
      .clk_launch(pclkdbg),
      .clk_capture(cxcti.u_cxcti_ci.cticlk),
      .d_in(device_unlocked_cdc_check),
      .d_out_async(device_un_locked_int)
      );
`else
assign device_un_locked_int = device_unlocked_cdc_check;
`endif
assign device_un_locked = device_un_locked_int;
endmodule
