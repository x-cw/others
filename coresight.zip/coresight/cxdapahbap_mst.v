//------------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2003-2013 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//    Checked In : $Date: 2013-09-06 16:05:05 +0100 (Fri, 06 Sep 2013) $
//    Revision   : $Revision: 37058 $
//    Release    : CoreSight-SoC-TM100-r3p1-00rel0
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// Abstract : Debug Access Port AHB Access Port (DAPAHBAP)- AHB Master Interface
//------------------------------------------------------------------------------
//
// DAPAHBAP - Debug Access Port AHB Access Port
// --------------------------------------------
//
// Debug Access Port AHB Access Port component provides an AHB-Lite interface to
// a System On Chip (SOC).
//
// cxdapahbap_mst.v
// ---------------
//
// dapahbap_mst.v provides the AHB-Lite master interface for the DAPAHBAP block.
//
// Instantiated blocks
// -------------------
// None.
//------------------------------------------------------------------------------
`include "cxdapahbap_constants.v"

module cxdapahbap_mst (
  // Inputs
  hclk, hclken, hresetn, hreadym, hrespm, hrdatam, ahb_rd_wr,
  ahb_inc_pack, ahb_size, dap_state_sync, ahb_prot_bits4to0, ahb_prot_bit6, ahb_addr, ahb_wr_data,
  // Outputs
  hwritem, hlockm, htransm, hsizem, hburstm, hbstrbm, hprotm, haddrm,
  hwdatam, ahb_err_resp, ahb_state, ahb_rd_data
  );

  //----------------------------------------------------------------------------
  // Inputs
  //----------------------------------------------------------------------------
  input         hclk;              // AHB clock
  input         hclken;            // AHB clock enable
  input         hresetn;           // AHB asychronous reset active low

  input         hreadym;           // AHB slave ready
  input [1:0]   hrespm;            // AHB slave response
  input [31:0]  hrdatam;           // AHB read data bus

  input         ahb_rd_wr;         // AHB read or write transfer from DAP inteface
  input         ahb_inc_pack;      // AHB packed transfer from DAP inteface
  input [1:0]   ahb_size;          // AHB transfer size from DAP inteface
  input [3:0]   dap_state_sync;    // DAP interface state (Synchronized)
  input [4:0]   ahb_prot_bits4to0; // AHB protection control from DAP inteface
  input         ahb_prot_bit6;     // AHB protection control from DAP inteface
  input [31:0]  ahb_addr;          // AHB address bus from DAP inteface
  input [31:0]  ahb_wr_data;       // AHB write data bus from DAP inteface

  //----------------------------------------------------------------------------
  // Outputs
  //----------------------------------------------------------------------------
  output        hwritem;        // AHB write or read
  output        hlockm;         // AHB lock transfer
  output [1:0]  htransm;        // AHB transfer type
  output [2:0]  hsizem;         // AHB transfer size
  output [2:0]  hburstm;        // AHB burst type
  output [3:0]  hbstrbm;        // AHB byte lane strobe
  output [6:0]  hprotm;         // AHB protection type
  output [31:0] haddrm;         // AHB address bus
  output [31:0] hwdatam;        // AHB write data bus

  output        ahb_err_resp;   // AHB error response to DAP interface
  output [2:0]  ahb_state;      // AHB state to DAP ineterface
  output [31:0] ahb_rd_data;    // AHB read data to DAP interface

  //----------------------------------------------------------------------------
  // Wires
  //----------------------------------------------------------------------------
  wire          hbstrb_en;
  wire          ahb_pack_en;
  wire          ahb_tr_done_en;
  wire          next_ahb_err_resp;
  wire          next_htrans_bit1;
  wire [31:0]   ahb_rd_data;

  wire [31:0]   rd_sz_8_addr_0;
  wire [31:0]   rd_sz_8_addr_1;
  wire [31:0]   rd_sz_8_addr_2;
  wire [31:0]   rd_sz_8_addr_3;
  wire [31:0]   rd_sz_16_addr_0;
  wire [31:0]   rd_sz_16_addr_2;

  wire          haddr_en;
  wire          hwrite_en;
  wire          hsize_en;
  wire          hprot_en;
  wire          hwdata_en;

  //----------------------------------------------------------------------------
  // Registers
  //----------------------------------------------------------------------------
  wire          hlockm;
  wire [1:0]    htransm;
  reg           htransm_bit1;
  wire [2:0]    hburstm;
  reg  [3:0]    hbstrbm;

  wire          ahb_err_resp;
  reg           ahberrresp_cdc_check;
  reg  [2:0]    cur_state;
  reg  [2:0]    next_state;
  reg  [2:0]    next_ahb_state;
  wire [2:0]    ahb_state;
  reg  [2:0]    ahb_state_cdc_check;
  reg  [3:0]    next_hbstrb;

  wire [31:0]   haddrm;
  reg  [31:0]   haddrm_int;
  reg  [31:0]   hwdatam;
  wire [6:0]    hprotm;
  wire [2:0]    hsizem;
  reg  [1:0]    hsizem_int;
  reg           hwritem;

  reg  [31:0]   next_rd_data;
  wire [31:0]   rd_data;
  reg  [31:0]   rddata_cdc_check;
  reg  [4:0]    hprotm_bits4to0;
  reg           hprotm_bit6;

  //---------------------------------------------------------------------------
  //
  // Main body of code
  // =================
  //
  //---------------------------------------------------------------------------

  //----------------------------------------------------------------------------
  // NOTE :- All the bits of DAP state are double synchronized from the dapclk
  //         domain into the hclk domain.Gray coding is not used for DAP state
  //         before synchronization because the DAP state need not transit in a
  //         linear manner.This is to say,the DAP state need not transit from
  //         state 2'b00 to 2'b01.It can also transit from state 2'b00 to 2'b10.
  //         This rules out usage of Gray coding.Hence the AHB master interface
  //         state machine shall change its state only when the DAP state is one
  //         hot encoded.This takes care of the synchronization issues.
  //----------------------------------------------------------------------------

  //----------------------------------------------------------------------------
  // Logic for the AHB master interface state machine.
  //----------------------------------------------------------------------------
  // ST_AHB_RST  : Reset state for the state machine.Moves out of this state to
  //               ST_AHB_IDLE when the DAP interface is ready.Otherwise will
  //               remain in this state till the DAP interface is ready.
  // ST_AHB_IDLE : Idle state for the state machine.This state indicates that
  //               the AHB interface is ready to perform transactions.Moves out
  //               of this state to ST_AHB_ADDR when the DAP interface moves to
  //               busy state to initiate a transaction request on the AHB bus.
  // ST_AHB_ADDR : Address state for the state machine.The address and control
  //               signals are driven on the AHB bus from this state.Moves out
  //               of this state to ST_AHB_WAIT if the hreadym is high.
  // ST_AHB_WAIT : Wait state for the state machine.Remains in this state till
  //               an hreadym is received for the initiated AHB transaction.
  // ST_AHB_RDY  : Ready state for the state machine.Remains in this state till
  //               the DAP interface moves to either the HOLD state or the INIT
  //               state.
  //----------------------------------------------------------------------------
  always @ (cur_state or dap_state_sync or hreadym)
    begin : p_nextstate
      case (cur_state)
        `ST_AHB_RST  :
          case(dap_state_sync)
            4'b0000, 4'b0001,
            4'b0011, 4'b0100,
            4'b0101, 4'b0110,
            4'b0111, 4'b1000,
            4'b1001, 4'b1010,
            4'b1011, 4'b1100,
            4'b1101, 4'b1110,
            4'b1111 : next_state = `ST_AHB_RST;
            4'b0010 : next_state = `ST_AHB_IDLE;
            default : next_state = `ST_AHB_UNDEF;
          endcase
        `ST_AHB_IDLE :
          case(dap_state_sync)
            4'b0000, 4'b0001,
            4'b0010, 4'b0011,
            4'b0101, 4'b0110,
            4'b0111, 4'b1000,
            4'b1001, 4'b1010,
            4'b1011, 4'b1100,
            4'b1101, 4'b1110,
            4'b1111 : next_state = `ST_AHB_IDLE;
            4'b0100 : next_state = `ST_AHB_ADDR;
            default : next_state = `ST_AHB_UNDEF;
          endcase
        `ST_AHB_ADDR : next_state = hreadym ? `ST_AHB_WAIT : `ST_AHB_ADDR;
        `ST_AHB_WAIT : next_state = hreadym ? `ST_AHB_RDY  : `ST_AHB_WAIT;
        `ST_AHB_RDY  :
          case(dap_state_sync)
            4'b0000, 4'b0011,
            4'b0100, 4'b0101,
            4'b0110, 4'b0111,
            4'b1001, 4'b1010,
            4'b1011, 4'b1100,
            4'b1101, 4'b1110,
            4'b1111 : next_state = `ST_AHB_RDY;
            4'b0010, // unreachable but here for completeness
            4'b0001,
            4'b1000 : next_state = `ST_AHB_IDLE;
            default : next_state = `ST_AHB_UNDEF;
          endcase
        default : next_state = `ST_AHB_UNDEF;
      endcase // case(cur_state)
    end // block: p_nextstate

  //----------------------------------------------------------------------------
  // Sequential block for cur_state of the AHB master interface state machine.
  //----------------------------------------------------------------------------
  always @ (posedge hclk or negedge hresetn)
    begin : p_currentstate
      if (!hresetn)
        cur_state <= `ST_AHB_RST;
      else
        if(hclken)
          cur_state <= next_state;
    end

  //----------------------------------------------------------------------------
  // Block to generate the next ahb_state one hot encoded output.
  // Although the AHB interface
  // has four states,ST_AHB_ADDR and ST_AHB_WAIT states appear as busy state
  // to the DAP interface.
  //----------------------------------------------------------------------------
  always @ (cur_state or dap_state_sync)
    begin : p_nextahbstate
      case (cur_state)
        `ST_AHB_RST  :
          case(dap_state_sync)
            4'b0000, 4'b0001,
            4'b0011, 4'b0100,
            4'b0101, 4'b0110,
            4'b0111, 4'b1000,
            4'b1001, 4'b1010,
            4'b1011, 4'b1100,
            4'b1101, 4'b1110,
            4'b1111 : next_ahb_state = `ST_AHBIF_INIT;
            4'b0010 : next_ahb_state = `ST_AHBIF_RDY;
            default : next_ahb_state = `ST_AHBIF_UNDEF;
          endcase
        `ST_AHB_IDLE :
          case(dap_state_sync)
            4'b0000, 4'b0001,
            4'b0010, 4'b0011,
            4'b0101, 4'b0110,
            4'b0111, 4'b1000,
            4'b1001, 4'b1010,
            4'b1011, 4'b1100,
            4'b1101, 4'b1110,
            4'b1111 : next_ahb_state = `ST_AHBIF_RDY;
            4'b0100 : next_ahb_state = `ST_AHBIF_BSY;
            default : next_ahb_state = `ST_AHBIF_UNDEF;
          endcase
        `ST_AHB_ADDR : next_ahb_state = `ST_AHBIF_BSY;
        `ST_AHB_WAIT : next_ahb_state = `ST_AHBIF_BSY;
        `ST_AHB_RDY  :
          case(dap_state_sync)
            4'b0000, 4'b0011,
            4'b0100, 4'b0101,
            4'b0110, 4'b0111,
            4'b1001, 4'b1010,
            4'b1011, 4'b1100,
            4'b1101, 4'b1110,
            4'b1111 : next_ahb_state = `ST_AHBIF_BSY;
            4'b0010, // unreachable but here for completeness
            4'b0001,
            4'b1000 : next_ahb_state = `ST_AHBIF_RDY;
            default : next_ahb_state = `ST_AHB_UNDEF;
          endcase
        default : next_ahb_state = `ST_AHB_UNDEF;
      endcase // case(cur_state)
    end // block: p_nextahbstate

  //----------------------------------------------------------------------------
  // Sequential block for ahb_state of the AHB master interface state machine.
  //----------------------------------------------------------------------------
  always @ (posedge hclk or negedge hresetn)
    begin : p_ahbstate
      if (!hresetn)
         ahb_state_cdc_check  <= `ST_AHBIF_INIT;
      else if(hclken)
         ahb_state_cdc_check  <= next_ahb_state;
    end

  //----------------------------------------------------------------------------
  // Generation of haddrm of the AHB master interface.
  //----------------------------------------------------------------------------

  assign haddr_en = hclken & (next_state == `ST_AHB_ADDR);

  always @(posedge hclk or negedge hresetn)
    if (!hresetn)
      haddrm_int <= 32'h00000000;
    else
      if (haddr_en)
        haddrm_int <= ahb_addr;

  assign haddrm = haddrm_int;

  //----------------------------------------------------------------------------
  // Generation of hwritem of the AHB master interface.
  //----------------------------------------------------------------------------
  assign hwrite_en = hclken & (next_state == `ST_AHB_ADDR);

  always @(posedge hclk or negedge hresetn)
    if (!hresetn)
      hwritem <= 1'b0;
    else
      if (hwrite_en)
        hwritem <= ahb_rd_wr;

  //----------------------------------------------------------------------------
  // Generation of hsizem of the AHB master interface.
  //----------------------------------------------------------------------------
  assign hsize_en = hclken & (next_state == `ST_AHB_ADDR);

  always @(posedge hclk or negedge hresetn)
    if (!hresetn)
      hsizem_int <= 2'b00;
    else
      if (hsize_en)
        hsizem_int <= ahb_size;

  assign hsizem = {1'b0, hsizem_int};

  //----------------------------------------------------------------------------
  // Combinational block for hprotm of the AHB master interface.
  //----------------------------------------------------------------------------
  assign hprot_en = hclken & (next_state == `ST_AHB_ADDR);

  always @(posedge hclk or negedge hresetn)
    if (!hresetn)
      begin
        hprotm_bit6     <= 1'b0;
        hprotm_bits4to0 <= 5'b00000;
      end
    else
      if (hprot_en)
        begin
          hprotm_bit6     <= ahb_prot_bit6;
          hprotm_bits4to0 <= ahb_prot_bits4to0;
        end

  assign hprotm = {hprotm_bit6, 1'b0, hprotm_bits4to0};

  //----------------------------------------------------------------------------
  // Combinational block for hwdatam of the AHB master interface.
  //----------------------------------------------------------------------------
  assign hwdata_en = hclken & (next_state == `ST_AHB_ADDR);

  always @(posedge hclk or negedge hresetn)
    if (!hresetn)
      hwdatam <= 32'h00000000;
    else
      if (hwdata_en)
        hwdatam <= ahb_wr_data;

  //----------------------------------------------------------------------------
  // Logic for the ahb_tr_done_en signal.This signal indicates that the current
  // AHB transaction is complete.
  //----------------------------------------------------------------------------
  assign ahb_tr_done_en = (cur_state == `ST_AHB_WAIT) & hreadym & hclken;

  //----------------------------------------------------------------------------
  // Logic for the next_ahb_err_resp.This is set when the received response is
  // error and the AHB transaction completes on the bus.
  //----------------------------------------------------------------------------
  assign next_ahb_err_resp  = ahb_tr_done_en & (hrespm == `ERR_RESP);

  //----------------------------------------------------------------------------
  // Sequential block for ahb_err_resp of the AHB master interface.
  //----------------------------------------------------------------------------
  always @(posedge hclk or negedge hresetn)
    begin : p_ahberrresp
      if (!hresetn)
         ahberrresp_cdc_check  <= 1'b0;
      else
        if(ahb_tr_done_en)
           ahberrresp_cdc_check  <= next_ahb_err_resp;
    end

  //----------------------------------------------------------------------------
  // The next_hlock is driven zero for all types of transactions as the AHB-AP
  // never requires locked accesses to the bus.
  //----------------------------------------------------------------------------
  assign hlockm = `ZERO_LOCK;

  //----------------------------------------------------------------------------
  // The next_htrans is driven with non sequential transfer in the ST_AHB_ADDR
  // state of the AHB master interface state machine.In all other states the
  // next_htrans is driven with an idle transfer.
  //----------------------------------------------------------------------------
  assign next_htrans_bit1 = (next_state == `ST_AHB_ADDR) ? `NONSEQ_TRAN_BIT1 : `IDLE_TRAN_BIT1;

  //----------------------------------------------------------------------------
  // Sequential block for htransm of the AHB master interface.
  //----------------------------------------------------------------------------
  always @(posedge hclk or negedge hresetn)
    begin : p_httrans
      if (!hresetn)
        htransm_bit1 <= 1'b0;
      else
        if(hclken)
          htransm_bit1 <= next_htrans_bit1;
    end

  assign htransm = {htransm_bit1, 1'b0};

  //----------------------------------------------------------------------------
  // The next_hburst is driven with single type of burst for all the type of
  // transactions by the AHB master interface state machine.
  //----------------------------------------------------------------------------
  assign hburstm = `SINGLE_BURST;

  //----------------------------------------------------------------------------
  // Combinational logic for the next_hbstrb.It is derived from the two least
  // significant bits of transfer address register and the size programmed in
  // the control status word register.Unaligned transfers are not supported by
  // the AHB-AP block.
  //----------------------------------------------------------------------------
  always @(ahb_addr or ahb_size)
    begin : p_nexthbstrb
      case(ahb_size[1:0])
        2'b00 :
          begin
            case(ahb_addr[1:0])
              2'b00   : next_hbstrb = 4'b0001;
              2'b01   : next_hbstrb = 4'b0010;
              2'b10   : next_hbstrb = 4'b0100;
              2'b11   : next_hbstrb = 4'b1000;
              default : next_hbstrb = 4'bxxxx;
            endcase // case(ahb_addr[1:0])
          end
        2'b01 :
          begin
            case(ahb_addr[1])
              1'b0    : next_hbstrb = 4'b0011;
              1'b1    : next_hbstrb = 4'b1100;
              default : next_hbstrb = 4'bxxxx;
            endcase // case(ahb_addr[1:0])
          end
        2'b10   : next_hbstrb = 4'b1111;
        default : next_hbstrb = 4'bxxxx;
      endcase // case(ahb_size[1:0])
    end // block: p_nexthbstrb

  //----------------------------------------------------------------------------
  // Logic for hbstrb_en.Because hbstrbm is a control signal,the signal is only
  // driven during the address phase of the AHB-AP.
  //----------------------------------------------------------------------------
  assign hbstrb_en = (next_state == `ST_AHB_ADDR) & hclken;

  //----------------------------------------------------------------------------
  // Sequential block for HBSTRB of the AHB master interface.
  //----------------------------------------------------------------------------
  always @(posedge hclk or negedge hresetn)
    begin : p_hbstrb
      if (!hresetn)
        hbstrbm <= {4{1'b0}};
      else
        if(hbstrb_en)
          hbstrbm <= next_hbstrb;
    end

  //----------------------------------------------------------------------------
  // Sequential block for rd_data of the AHB master interface.
  //----------------------------------------------------------------------------
  always @(posedge hclk or negedge hresetn)
    begin : p_rddata
      if (!hresetn)
         rddata_cdc_check  <= {32{1'b0}};
      else
        if(ahb_tr_done_en)
           rddata_cdc_check  <= next_rd_data;
    end

  //----------------------------------------------------------------------------
  // rd_sz_8_addr_0,rd_sz_8_addr_0,rd_sz_8_addr_0 and rd_sz_8_addr_0 represent the nets when
  // the AHB size is of 8 bits and the least two significant bits of the AHB
  // address are zero,one,two and three respectively.
  //----------------------------------------------------------------------------
  assign rd_sz_8_addr_0 = {rd_data[31:8], hrdatam[7:0]};
  assign rd_sz_8_addr_1 = {rd_data[31:16],hrdatam[15:8], rd_data[7:0]};
  assign rd_sz_8_addr_2 = {rd_data[31:24],hrdatam[23:16],rd_data[15:0]};
  assign rd_sz_8_addr_3 = {              hrdatam[31:24],rd_data[23:0]};

  //----------------------------------------------------------------------------
  // rd_sz_16_addr_0 and rd_sz_16_addr_2 represent the nets when the AHB size is of 16
  // bits and the least two significant bits of the AHB address are zero and
  // two respectively.
  //----------------------------------------------------------------------------
  assign rd_sz_16_addr_0 = {rd_data[31:16],hrdatam[15:0]};
  assign rd_sz_16_addr_2 = {hrdatam[31:16],rd_data[15:0]};

  //----------------------------------------------------------------------------
  // The ahb_rd_data to the DAP inteface is driven from the ReadData.
  //----------------------------------------------------------------------------
  assign ahb_rd_data = rd_data;

  //----------------------------------------------------------------------------
  // The ahb_pack_en is the enable signal for performing the packed transfers.
  //----------------------------------------------------------------------------
  assign ahb_pack_en = ahb_tr_done_en & ahb_inc_pack;

  //----------------------------------------------------------------------------
  // Logic for storing the read data from the AHB bus in the case of increment
  // packed transactions.Word size transactions in case of increment and non-
  // increment packed transactions are one and the same.For half word and byte
  // transactions,the read data from the AHB bus shall be stored for two and
  // four AHB transactions respectively.
  //----------------------------------------------------------------------------
  // use the locally registered version which are stable

  always @(ahb_pack_en or haddrm_int or hrdatam or hsizem_int
           or rd_sz_16_addr_0 or rd_sz_16_addr_2 or rd_sz_8_addr_0 or rd_sz_8_addr_1
           or rd_sz_8_addr_2 or rd_sz_8_addr_3)
    begin : p_incrddata
      case(ahb_pack_en)
        1'b0 : next_rd_data = hrdatam;
        1'b1 :
          case({hsizem_int[0],haddrm_int[1:0]})
            3'b000  : next_rd_data = rd_sz_8_addr_0;
            3'b001  : next_rd_data = rd_sz_8_addr_1;
            3'b010  : next_rd_data = rd_sz_8_addr_2;
            3'b011  : next_rd_data = rd_sz_8_addr_3;
            3'b100  : next_rd_data = rd_sz_16_addr_0;
            3'b110  : next_rd_data = rd_sz_16_addr_2;
            default : next_rd_data = {32{1'bx}};
          endcase // case({ahb_size[0],ahb_addr[1:0]})
        default : next_rd_data = {32{1'bx}};
      endcase // case(ahb_pack_en)
    end // block: p_incrddata

        assign ahb_err_resp = ahberrresp_cdc_check;
        assign ahb_state = ahb_state_cdc_check;
        assign rd_data = rddata_cdc_check;

`ifdef ARM_ASSERT_ON
  //----------------------------------------------------------------------------
  // OVL Assertions
  //----------------------------------------------------------------------------

  //----------------------------------------------------------------------------
  // hsizem[2] should be always zero.Only byte,half word and word transfers are
  // supported by the AHB-AP.
  //----------------------------------------------------------------------------
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
    "OVL Message : dapahbap_ahbif - hsizem[2] is not driven zero")
      dapahbap_hsizem1
        (
         .clk         (hclk),
         .reset_n     (hresetn),
         .test_expr   (hsizem[2] == 1'b1)
        );

  //----------------------------------------------------------------------------
  // hsizem[1:0] should not be driven 2'b11 value.Only byte,half word and word
  // transfers are supported by the AHB-AP.
  //----------------------------------------------------------------------------
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
    "OVL Message : dapahbap_ahbif - Unsupported hsizem driven on the bus")
      dapahbap_hsizem2
        (
         .clk         (hclk),
         .reset_n     (hresetn),
         .test_expr   (hsizem_int[1:0] == 2'b11)
        );

  //----------------------------------------------------------------------------
  // hrespm[1] should be always zero.OKAY and ERROR responses should only be
  // driven on the AHB bus.
  //----------------------------------------------------------------------------
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
    "OVL Message : dapahbap_ahbif - Unsupported hrespm driven on the bus")
      dapahbap_hrespm
        (
         .clk         (hclk),
         .reset_n     (hresetn),
         .test_expr   (hrespm[1] == 1'b1)
        );

  //----------------------------------------------------------------------------
  // Unaligned half word transfers are not supported.Half word transfers should
  // always have the least significant bit of hsizem zero.
  //----------------------------------------------------------------------------
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
    "OVL Message : dapahbap_ahbif - Unsupported unaligned half word transfers")
      dapahbap_half_word
        (
         .clk         (hclk),
         .reset_n     (hresetn),
         .test_expr   ((ahb_addr[0] == 1'b1) & (ahb_size[1:0] == 2'b01) &
                        htransm == `NONSEQ_TRAN)
        );

  //----------------------------------------------------------------------------
  // Unaligned word transfers are not supported.Word transfers should always
  // have the least two significant bits of hsizem zero.
  //----------------------------------------------------------------------------
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
    "OVL Message : dapahbap_ahbif - Unsupported unaligned word transfers")
      dapahbap_word
        (
         .clk         (hclk),
         .reset_n     (hresetn),
         .test_expr   ((|ahb_addr[1:0]) & (ahb_size[1:0] == 2'b10) &
                        htransm == `NONSEQ_TRAN)
        );

  //----------------------------------------------------------------------------
  // Unpacked and packed word transfers are one and the same.ahb_pack_en should
  // be zero for both packed and non packed word transfers.
  //----------------------------------------------------------------------------
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
    "OVL Message : dapahbap_ahbif -  packed/non packed word transfers not same")
      dapahbap_inc_pack
        (
         .clk         (hclk),
         .reset_n     (hresetn),
         .test_expr   (ahb_pack_en & (ahb_size[1:0] == 2'b10))
        );

  //----------------------------------------------------------------------------
  // DAP state in RDY and AHB state in BSY not possible at the same time.
  //----------------------------------------------------------------------------
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
    "OVL Message : dapahbap_ahbif -  AHB and DAP invalid state combination")
      dapahbap_state
        (
         .clk         (hclk),
         .reset_n     (hresetn),
         .test_expr   ((dap_state_sync == `ST_DAPIF_RDY) &
                       (ahb_state == `ST_AHBIF_BSY))
        );

  //----------------------------------------------------------------------------
  // ahb_state is onehot (not zero)
  //----------------------------------------------------------------------------
  assert_one_hot #(`OVL_ERROR, 3, `OVL_ASSERT,
                   "OVL Message : ahb_state should be onehot")
    dapahbap_onehot_ahbstate
      (
       .clk         (hclk),
       .reset_n     (hresetn),
       .test_expr   (ahb_state)
      );

  //----------------------------------------------------------------------------
  // Guard: reachable X-assignments on lines 207 & 273 of dapahbap_mst.v
  //----------------------------------------------------------------------------
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
                 "dapahbap_mst: X-assignments on lines 207 & 273 should be deadcode")
    dapahbap_mst_guard_x_l207_l273
      (
       .clk       (hclk),
       .reset_n   (hresetn),
       .test_expr (  (dap_state_sync == `ST_DAPIF_RDY)
                   & (cur_state     == `ST_AHB_RDY)
                  )
      );

  //----------------------------------------------------------------------------
  // Guard: reachable X-assignments on lines 209 & 275 of dapahbap_mst.v
  //----------------------------------------------------------------------------
  assert_always #(`OVL_ERROR, `OVL_ASSERT,
                  "dapahbap_mst: X-assignments on lines 209 & 275 should be deadcode")
    dapahbap_mst_guard_x_l209_l275
      (
       .clk       (hclk),
       .reset_n   (hresetn),
       .test_expr (  (cur_state == `ST_AHB_RST)
                   | (cur_state == `ST_AHB_IDLE)
                   | (cur_state == `ST_AHB_ADDR)
                   | (cur_state == `ST_AHB_WAIT)
                   | (cur_state == `ST_AHB_RDY)
                  )
      );

  //----------------------------------------------------------------------------
  // Guard: reachable X-assignments on line 504 of dapahbap_mst.v
  //----------------------------------------------------------------------------
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
                 "dapahbap_mst: X-assignment on line 504 should be deadcode")
    dapahbapmst_guard_x_l504
      (
       .clk       (hclk),
       .reset_n   (hresetn),
       .test_expr (ahb_pack_en & ahb_size[0] & ahb_addr[0])
      );

`endif
endmodule // cxdapahbap_mst
