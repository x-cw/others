//-----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2003-2013 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//  Checked In          : $Date: 2013-09-06 16:05:05 +0100 (Fri, 06 Sep 2013) $
//  Revision            : $Revision: 37058 $
//  Release             : CoreSight-SoC-TM100-r3p1-00rel0
//-----------------------------------------------------------------------------


//
//  ----------------------------------------------------------------------------
//  Purpose             : JTAG-AP Port Multiplexer
//  ----------------------------------------------------------------------------

module cxdapjtagap_mux (
  // Inputs
  dapclk, dapclken, dapresetn, port_sel, s_rst_out, tck_int, tdi_int,
  tmsint, trst_out, psta_reg, cstdo, portconnected, portenabled,
  csrtck, srstconnected,
  // Outputs
  port_sel_con, port_status, rtck_int, s_rst_con, tdo_int, nsrstout,
  ncstrst, cstck, cstdi, cstms
  );

//------------------------------------------------------------------------------
// Port Definitions
//------------------------------------------------------------------------------
// Clock / Reset Pins
  input         dapclk;         // DAP internal APB clock
  input         dapclken;       // Enable term for dapclk domain
  input         dapresetn;      // DAP reset

// Internal signal connections

  input   [7:0] port_sel;       // Ports selected
  input         s_rst_out;      // Subsystem reset from Control/Status Word
  input         tck_int;        // tck from JTAG engine
  input         tdi_int;        // tdi from JTAG engine
  input         tmsint;         // tms from JTAG engine
  input         trst_out;       // NTRST from Control/Status Word register
  input   [7:0] psta_reg;       // Port Status Register (sticky)

  output        port_sel_con;   // Selected port is connected
  output  [7:0] port_status;    // state of selected port's portenabled
  output        rtck_int;       // Return tck to JTAG engine
  output        s_rst_con;      // SRST supported by selected port
  output        tdo_int;        // TDO to JTAG engine

// External JTAG port connections

  input   [7:0] cstdo;          // TDO from JTAG slaves
  input   [7:0] portconnected;  // JTAG ports are connected (static signals)
  input   [7:0] portenabled;    // JTAG ports are active
  input   [7:0] csrtck;         // Return tck from JTAG slaves
  input   [7:0] srstconnected;  // JTAG ports support Subsystem Reset


  output  [7:0] nsrstout;       // Subsystem reset to JTAG slaves
  output  [7:0] ncstrst;        // nTRST to JTAG slaves
  output  [7:0] cstck;          // tck to JTAG slaves
  output  [7:0] cstdi;          // tdi to JTAG slaves
  output  [7:0] cstms;          // tms to JTAG slaves

// Wire declarations

  wire    [7:0] nsrstout;       // Subsystem reset to JTAG slaves
  wire    [7:0] cstck;          // tck to JTAG slaves
  wire    [7:0] cstdi;          // tdi to JTAG slaves
  wire    [7:0] cstms;          // tms to JTAG slaves
  wire          tdo_int;        // TDO to JTAG engine
  wire    [7:0] port_status;    // state of selected port's portenabled
  wire          port_sel_con;   // Selected port is connected
  wire    [7:0] rtck_sync;      // dapclk synchronised version of rtck[7:0]
  wire          s_rst_con;      // SRST supported by selected port
  wire    [7:0] drive_ports;    // Drive JTAG ports only when selected
                                //  and enabled
  reg           rtck_int;       // Return tck to JTAG engine

// Evaluate status flags for Control/Status Word
// Set s_rst_con and port_sel_con to zero if no ports selected

  assign   s_rst_con     = (|port_sel) ? &((port_sel & srstconnected) | ~port_sel)
                                       : 1'b0;

  assign   port_sel_con  = (|port_sel) ? &((port_sel & portconnected) | ~port_sel)
                                       : 1'b0;

  assign   port_status  = (port_sel & portconnected & ~portenabled);

// Only drive JTAG port(s) when port is selected and port is connected
// and port has not been disabled in this session

  assign   drive_ports  = port_sel & portconnected & ~psta_reg;

// Multiplex JTAG ports

  assign   ncstrst     = ~(drive_ports & {8{trst_out}});
  assign   nsrstout    = ~(drive_ports & {8{s_rst_out}});
  assign   cstck       =   drive_ports & {8{tck_int}};
  assign   cstdi       =   drive_ports & {8{tdi_int}};
  assign   cstms       =   drive_ports & {8{tmsint}};

// Steer TDO from selected port to tdo_int, for capturing in the read FIFO
// If multiple ports are selected, tdo_int is the OR of all
// selected ports

  assign   tdo_int      = |(drive_ports & cstdo);

// Synchronise RTCKs into dapclk domain
// Note that it is safe to synchronise the RTCKs as a bus
// value, because even if a transient bus value is sampled,
// this won't affect correct operation of the logic
// that combines RTCKs

  cxdapjtagap_sync u_cxdapjtagap_sync

    (
     // Outputs
     .rtck_sync                         (rtck_sync[7:0]),
     // Inputs
     .dapclk                            (dapclk),
     .dapclken                          (dapclken),
     .dapresetn                         (dapresetn),
     .csrtck                            (csrtck[7:0]));


// Multiplexed port RTCKs are combinatorially joined, so that:
// -- If tck = '0', then select OR of active RTCKs
// -- If tck = '1', then select AND of active RTCKs
// If no ports are active, rtck is driven with tck

  always @ (drive_ports or rtck_sync or tck_int)
    case ({|drive_ports,tck_int})
      2'b00,
      2'b01   : rtck_int = tck_int;
      2'b10   : rtck_int = |(rtck_sync & drive_ports);
      2'b11   : rtck_int = ((rtck_sync & drive_ports) == drive_ports);
      default : rtck_int = 1'bX;
    endcase // case({|drive_ports,tck_int})

//------------------------------------------------------------------------------
// OVL Assertions
//------------------------------------------------------------------------------

`ifdef ARM_ASSERT_ON

  // Ensure no x or z in portconnected
  // Severity 1
  assert_never_unknown #(`OVL_ERROR, 8, `OVL_ASSERT, "x or z detected in portconnected")
    dapjtagap_portconnected_x
      (
       .clk       (dapclk),
       .reset_n   (dapresetn),
       .qualifier (1'b1),
       .test_expr (portconnected[7:0])
      );

  // Ensure no x or z in portenabled
  // Severity 1
  assert_never_unknown #(`OVL_ERROR, 8, `OVL_ASSERT, "x or z detected in portenabled")
    dapjtagap_portenabled_x
      (
       .clk       (dapclk),
       .reset_n   (dapresetn),
       .qualifier (1'b1),
       .test_expr (portenabled[7:0])
      );

  // Ensure no x or z in srstconnected
  // Severity 1
  assert_never_unknown #(`OVL_ERROR, 8, `OVL_ASSERT, "x or z detected in srstconnected")
    dapjtagap_srstconnected_x
      (
       .clk       (dapclk),
       .reset_n   (dapresetn),
       .qualifier (1'b1),
       .test_expr (srstconnected[7:0])
      );

 `endif

endmodule // cxdapjtagap_mux
