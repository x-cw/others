+incdir+$GP3_RTL/coresight/rtl/coresight_component/debug_module/cxdapaxiap_1/verilog
$GP3_RTL/coresight/rtl/coresight_component/debug_module/cxdapaxiap_1/verilog/cxdapaxiap_1.v
$GP3_RTL/coresight/rtl/coresight_component/debug_module/cxdapaxiap_1/verilog/cxdapaxiapdapslvif_1.v
$GP3_RTL/coresight/rtl/coresight_component/debug_module/cxdapaxiap_1/verilog/cxdapaxiapfsm_1.v
$GP3_RTL/coresight/rtl/coresight_component/debug_module/cxdapaxiap_1/verilog/cxdapaxiapmstif_1.v
$GP3_RTL/coresight/rtl/coresight_component/debug_module/cxdapaxiap_1/verilog/cxdapaxiapregblk_1.v
$GP3_RTL/coresight/rtl/coresight_component/debug_module/cxdapaxiap_1/verilog/cxdapaxiap_constants.v
