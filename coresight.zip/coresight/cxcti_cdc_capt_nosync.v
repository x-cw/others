//------------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2003-2015 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//------------------------------------------------------------------------------
// Version and Release Control Information:
//
// File Revision       : $Revision: 39945 $
// File Date           : $Date: 2014-08-14 16:01:35 +0100 (Thu, 14 Aug 2014) $
// Release Information : CoreSight-SoC-TM100-r3p2-00rel0
//------------------------------------------------------------------------------
//  Purpose : Register to capture cross domain signals
// -----------------------------------------------------------------------------

module cxcti_cdc_capt_nosync (clk, resetn, enable, q, d_async);

  parameter WIDTH = 4; // Width of the payload

  // ------------------------------------------------------
  // port declaration
  // ------------------------------------------------------
  output reg [WIDTH-1:0] q;
  input                  clk;
  input                  enable;
  input                  resetn;
  input  [WIDTH-1:0]     d_async;     // May be connected to an asynchronous input

  always @ (posedge clk or negedge resetn)
    if (~resetn)
      q <= {WIDTH{1'b0}};
    else if (enable)
      q <= d_async;

`ifdef ARM_CDC_CHECK

  integer   i;

  // Use an assertion if assertions are enabled.
  wire [WIDTH-1:0]  q_d;
  reg               z_detect;

  initial
    z_detect = 1'b0;

  // Create a delayed signal to ensure that any error fires at the correct
  // time
  assign #1 q_d = q;

  // Stop the simulation if any bits are Z when mux is enabled
  always @(q_d)
    if (enable)
      for (i = 0; i < WIDTH; i = i + 1)
        if (d_async[i] === 1'bz)
          begin
            z_detect <= 1'b1;
          end

  always @(posedge z_detect)
     begin
          $display("FATAL : Unsafe operation detected across CDC boundary");
          $stop;
     end

`endif

endmodule
