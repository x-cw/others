//-----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2012-2015 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//  Checked In          : $Date: 2014-06-25 08:59:36 +0100 (Wed, 25 Jun 2014) $
//  Revision            : $Revision: 39630 $
//  Release             : CoreSight-SoC-TM100-r3p2-00rel0
//
//  ----------------------------------------------------------------------------
//  Purpose             : DAPBUS Interconnect comprising :
//                           Address Decoder
//                           Response Mux
//  --========================================================================--

module cxdapbusic_3ap
  (
  // Inputs

  
  // I/O Declaration for DAPBUS Master interface 2
  output wire [7:2]  dapcaddrm2,
  output wire        dapselm2,
  output wire        dapenablem2,
  output wire        dapwritem2,
  output wire [31:0] dapwdatam2,
  output wire        dapabortm2,
  input  wire [31:0] daprdatam2,
  input  wire        dapreadym2,
  input  wire        dapslverrm2,
        
  // I/O Declaration for DAPBUS Master interface 1
  output wire [7:2]  dapcaddrm1,
  output wire        dapselm1,
  output wire        dapenablem1,
  output wire        dapwritem1,
  output wire [31:0] dapwdatam1,
  output wire        dapabortm1,
  input  wire [31:0] daprdatam1,
  input  wire        dapreadym1,
  input  wire        dapslverrm1,
        
  // I/O Declaration for DAPBUS Master interface 0
  output wire [7:2]  dapcaddrm0,
  output wire        dapselm0,
  output wire        dapenablem0,
  output wire        dapwritem0,
  output wire [31:0] dapwdatam0,
  output wire        dapabortm0,
  input  wire [31:0] daprdatam0,
  input  wire        dapreadym0,
  input  wire        dapslverrm0,
        
  // Slave interface
  input  wire [15:2] dapcaddrs,
  input  wire        dapsels,
  input  wire        dapenables,
  input  wire        dapwrites,
  input  wire [31:0] dapwdatas,
  input  wire        dapaborts,
  output wire [31:0] daprdatas,
  output wire        dapreadys,
  output wire        dapslverrs
);

//-----------------------------------------------------------------------------
// Wire declarations
//-----------------------------------------------------------------------------
wire          dapseldef; // Default slave

// Internal signals for dapselm*

wire int_dapselm2;
wire int_dapselm1;
wire int_dapselm0;

//-----------------------------------------------------------------------------
//
// Main body of code
// =================
//
//-----------------------------------------------------------------------------

// Address Decoder
  cxdapbusic_decoder_3ap u_cxdapbusic_decoder_3ap
    (
     // Outputs
  
     .dapselm2      (int_dapselm2),
     .dapselm1      (int_dapselm1),
     .dapselm0      (int_dapselm0),

      // Default select
     .dapseldef       (dapseldef),

     // Inputs
     .dapcaddrs_15to8 (dapcaddrs[15:8]),
     .dapsels         (dapsels));

  // Assign internal version of dapselm* to final outputs


  // AP Response mux
  cxdapbusic_mux_3ap u_cxdapbusic_mux_3ap
    (
     // Master interface select lines
     .dapselm2      (int_dapselm2),
     .dapselm1      (int_dapselm1),
     .dapselm0      (int_dapselm0),

      // Default select
     .dapseldef       (dapseldef),

      // Read Data
     .daprdatam2      (daprdatam2),
     .daprdatam1      (daprdatam1),
     .daprdatam0      (daprdatam0),

      // AP Response
     .dapreadym2      (dapreadym2),
     .dapreadym1      (dapreadym1),
     .dapreadym0      (dapreadym0),

      // Error indication
     .dapslverrm2      (dapslverrm2),
     .dapslverrm1      (dapslverrm1),
     .dapslverrm0      (dapslverrm0),

     // Outputs
     .daprdatas        (daprdatas[31:0]),
     .dapreadys        (dapreadys),
     .dapslverrs       (dapslverrs)
    );

//-----------------------------------------------------------------------------
// Generation of signals on the master interfaces
//-----------------------------------------------------------------------------
  
assign dapselm2    = int_dapselm2;
assign dapcaddrm2  = dapcaddrs[7:2];
assign dapenablem2 = dapenables;
assign dapwritem2  = dapwrites;
assign dapwdatam2  = dapwdatas;
assign dapabortm2  = dapaborts;
        
assign dapselm1    = int_dapselm1;
assign dapcaddrm1  = dapcaddrs[7:2];
assign dapenablem1 = dapenables;
assign dapwritem1  = dapwrites;
assign dapwdatam1  = dapwdatas;
assign dapabortm1  = dapaborts;
        
assign dapselm0    = int_dapselm0;
assign dapcaddrm0  = dapcaddrs[7:2];
assign dapenablem0 = dapenables;
assign dapwritem0  = dapwrites;
assign dapwdatam0  = dapwdatas;
assign dapabortm0  = dapaborts;
        

endmodule // cxdapbusic_3ap
