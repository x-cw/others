//----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2010-2015 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//
//      Checked In          : $Date: 2015-03-05 11:26:26 +0000 (Thu, 05 Mar 2015) $
//
//      Revision            : $Revision: 41888 $
//
//      Release Information : CoreSight-SoC-TM100-r3p2-00rel0
//-----------------------------------------------------------------------------
//  Purpose             : ATB Slave Clock domain side (input) FIFO
//                      : Contains FIFO storage registers
//-----------------------------------------------------------------------------

module cxatbasyncbridge_slv_fifo_slv
       #( parameter FIFO_DATA_WIDTH=41)
(
  // Inputs
  atclks,
  atclkens,
  atresetsn,
  atvalids,
  rdptr_grey_sync,
  write_data,
  afreadys,
  flush_req_sync,
  zero_pointer_sync,
  // Outputs
  atreadys,
  afvalids,
  wrptr_grey,
  fifo_data_0,
  fifo_data_1,
  fifo_data_2,
  fifo_data_3,
  fifo_data_4,
  fifo_data_5,
  flush_flag_0,
  flush_flag_1,
  flush_flag_2,
  flush_flag_3,
  flush_flag_4,
  flush_flag_5,
  flush_done
  );

  // Inputs
  input wire                        atclks;             // ATB Slave clock
  input wire                        atclkens;           // ATB Slave clock enable
  input wire                        atresetsn;          // ATB Slave asychronous reset active low
  input wire                        atvalids;           // Data valid signal from the input
  input wire [FIFO_DATA_WIDTH-1:0]  write_data;         // Write data to the FIFO
  input                             afreadys;           //
  input wire [3:0]                  rdptr_grey_sync;    // Read pointer from the synchronizer
  input wire                        flush_req_sync;     // Synchronized FlushReq from Master Clock domain
  input wire                        zero_pointer_sync;  // Synchronized ZeroPointer from Master Clock domain

  // Outputs
  output wire                       atreadys;           // Ready to accept data from input
  output wire                       afvalids;
  output wire [3:0]                 wrptr_grey;         // Write pointer to the read clock domain
  output wire [FIFO_DATA_WIDTH-1:0] fifo_data_0;        // Output all the data registers for use
  output wire [FIFO_DATA_WIDTH-1:0] fifo_data_1;        // in the ATB Master Clock domain
  output wire [FIFO_DATA_WIDTH-1:0] fifo_data_2;        // NB 6-deep used, optimal for 2 clk
  output wire [FIFO_DATA_WIDTH-1:0] fifo_data_3;        // delays synchronising between both domains
  output wire [FIFO_DATA_WIDTH-1:0] fifo_data_4;        //
  output wire [FIFO_DATA_WIDTH-1:0] fifo_data_5;        //
  output wire                       flush_flag_0;       // Flag bits used by the state machine in
  output wire                       flush_flag_1;       // the Master Clock Domain
  output wire                       flush_flag_2;       //
  output wire                       flush_flag_3;       //
  output wire                       flush_flag_4;       //
  output wire                       flush_flag_5;       //
  output wire                       flush_done;         // Flush complete from the input side


  // ------------------------------------------------------------------------
  //
  //                            ATB slave clock domain FIFO interface
  //                            =====================================
  //
  // ------------------------------------------------------------------------
  //
  //
  // Overview
  // ========
  // ATB Slave clock domain FIFO interface of the ATB Asynchronous Bridge.
  // ------------------------------------------------------------------------

  // ------------------------------------------------------------------------
  // Internal wire declartions
  // ------------------------------------------------------------------------
  wire                       wrptr_en;
  wire                       wrptr_adv;
  wire                       data_rdy;
  wire                       nxt_afvalids;
  wire                       nxt_flush_done;
  wire                       flush_flag_0_int;
  wire                       flush_flag_1_int;
  wire                       flush_flag_2_int;
  wire                       flush_flag_3_int;
  wire                       flush_flag_4_int;
  wire                       flush_flag_5_int;
  wire                       flush_done_int;
  wire [3:0]                 wrptr_grey_int;

  // ------------------------------------------------------------------------
  // Internal register declartions
  // ------------------------------------------------------------------------
  reg                        flush_done_cdc_check;
  reg                        slv_safe_state_cdc_check;
  reg [3:0]                  rdptr_grey_trans;
  reg [2:0]                  wrptr_bin; //MSB wrptr_bin[3] not needed and hence not used
  reg [3:0]                  wrptr_grey_cdc_check;
  reg [3:0]                  nxt_wrptr_grey;
  wire                       fifo_data_en_0;
  reg [FIFO_DATA_WIDTH-1:0]  fifo_data_0_cdc_check;
  wire                       fifo_data_en_1;
  reg [FIFO_DATA_WIDTH-1:0]  fifo_data_1_cdc_check;
  wire                       fifo_data_en_2;
  reg [FIFO_DATA_WIDTH-1:0]  fifo_data_2_cdc_check;
  wire                       fifo_data_en_3;
  reg [FIFO_DATA_WIDTH-1:0]  fifo_data_3_cdc_check;
  wire                       fifo_data_en_4;
  reg [FIFO_DATA_WIDTH-1:0]  fifo_data_4_cdc_check;
  wire                       fifo_data_en_5;
  reg [FIFO_DATA_WIDTH-1:0]  fifo_data_5_cdc_check;
  reg                        flush_flag_0_cdc_check;
  reg                        flush_flag_1_cdc_check;
  reg                        flush_flag_2_cdc_check;
  reg                        flush_flag_3_cdc_check;
  reg                        flush_flag_4_cdc_check;
  reg                        flush_flag_5_cdc_check;
  reg                        nxt_flush_flag_0;
  reg                        nxt_flush_flag_1;
  reg                        nxt_flush_flag_2;
  reg                        nxt_flush_flag_3;
  reg                        nxt_flush_flag_4;
  reg                        nxt_flush_flag_5;
  reg                        afvalids_q;

  // ------------------------------------------------------------------------
  //
  // Main body of code
  // =================
  //
  // ------------------------------------------------------------------------
  // ------------------------------------------------------------------------
  // Sequential block for the generation of the FifoData and FlushFlag.
  // ------------------------------------------------------------------------
  // Entry 0 of FIFO
  always @(posedge atclks or negedge atresetsn)
    begin : s_fifo_data_0
      if (!atresetsn)
         fifo_data_0_cdc_check  <= {FIFO_DATA_WIDTH{1'b0}};
      else
        if (fifo_data_en_0)
           fifo_data_0_cdc_check  <= write_data;
    end // block: s_fifo_data_0

  always @(posedge atclks or negedge atresetsn)
    begin : s_flush_flag_0
      if (!atresetsn)
         flush_flag_0_cdc_check  <= 1'b0;
      else
        if (atclkens)
           flush_flag_0_cdc_check  <= nxt_flush_flag_0;
    end // block: s_flush_flag_0

  // Entry 1 of FIFO
  always @(posedge atclks or negedge atresetsn)
    begin : s_fifo_data_1
      if (!atresetsn)
         fifo_data_1_cdc_check  <= {FIFO_DATA_WIDTH{1'b0}};
      else
        if (fifo_data_en_1)
           fifo_data_1_cdc_check  <= write_data;
    end // block: s_fifo_data_1

  always @(posedge atclks or negedge atresetsn)
    begin : s_flush_flag_1
      if (!atresetsn)
         flush_flag_1_cdc_check  <= 1'b0;
      else
        if (atclkens)
           flush_flag_1_cdc_check  <= nxt_flush_flag_1;
    end // block: s_flush_flag_1

  // Entry 2 of FIFO
  always @(posedge atclks or negedge atresetsn)
    begin : s_fifo_data_2
      if (!atresetsn)
         fifo_data_2_cdc_check  <= {FIFO_DATA_WIDTH{1'b0}};
      else
        if (fifo_data_en_2)
           fifo_data_2_cdc_check  <= write_data;
    end // block: s_fifo_data_2

  always @(posedge atclks or negedge atresetsn)
    begin : s_flush_flag_2
      if (!atresetsn)
         flush_flag_2_cdc_check  <= 1'b0;
      else
        if (atclkens)
           flush_flag_2_cdc_check  <= nxt_flush_flag_2;
    end // block: s_flush_flag_2

  // Entry 3 of FIFO
  always @(posedge atclks or negedge atresetsn)
    begin : s_fifo_data_3
      if (!atresetsn)
         fifo_data_3_cdc_check  <= {FIFO_DATA_WIDTH{1'b0}};
      else
        if (fifo_data_en_3)
           fifo_data_3_cdc_check  <= write_data;
    end // block: s_fifo_data_3

  always @(posedge atclks or negedge atresetsn)
    begin : s_flush_flag_3
      if (!atresetsn)
         flush_flag_3_cdc_check  <= 1'b0;
      else
        if (atclkens)
           flush_flag_3_cdc_check  <= nxt_flush_flag_3;
    end // block: s_flush_flag_3

  // Entry 4 of FIFO
  always @(posedge atclks or negedge atresetsn)
    begin : s_fifo_data_4
      if (!atresetsn)
         fifo_data_4_cdc_check  <= {FIFO_DATA_WIDTH{1'b0}};
      else
        if (fifo_data_en_4)
           fifo_data_4_cdc_check  <= write_data;
    end // block: s_fifo_data_4

  always @(posedge atclks or negedge atresetsn)
    begin : s_flush_flag_4
      if (!atresetsn)
         flush_flag_4_cdc_check  <= 1'b0;
      else
        if (atclkens)
           flush_flag_4_cdc_check  <= nxt_flush_flag_4;
    end // block: s_flush_flag_4

  // Entry 5 of FIFO
  always @(posedge atclks or negedge atresetsn)
    begin : s_fifo_data_5
      if (!atresetsn)
         fifo_data_5_cdc_check  <= {FIFO_DATA_WIDTH{1'b0}};
      else
        if (fifo_data_en_5)
           fifo_data_5_cdc_check  <= write_data;
    end // block: s_fifo_data_5

  always @(posedge atclks or negedge atresetsn)
    begin : s_flush_flag_5
      if (!atresetsn)
         flush_flag_5_cdc_check  <= 1'b0;
      else
        if (atclkens)
           flush_flag_5_cdc_check  <= nxt_flush_flag_5;
    end // block: s_flush_flag_5

  // ------------------------------------------------------------------------
  // Assigning the wrptr_adv signal.
  // ------------------------------------------------------------------------
  assign        wrptr_adv = atvalids & data_rdy;

  // ------------------------------------------------------------------------
  // Assigining the FIFO data enable signals.
  // ------------------------------------------------------------------------
  assign        fifo_data_en_0 = (wrptr_adv & (wrptr_bin[2:0] == 3'b000) & atclkens);
  assign        fifo_data_en_1 = (wrptr_adv & (wrptr_bin[2:0] == 3'b001) & atclkens);
  assign        fifo_data_en_2 = (wrptr_adv & (wrptr_bin[2:0] == 3'b010) & atclkens);
  assign        fifo_data_en_3 = (wrptr_adv & (wrptr_bin[2:0] == 3'b011) & atclkens);
  assign        fifo_data_en_4 = (wrptr_adv & (wrptr_bin[2:0] == 3'b100) & atclkens);
  assign        fifo_data_en_5 = (wrptr_adv & (wrptr_bin[2:0] == 3'b101) & atclkens);

  // ------------------------------------------------------------------------
  // Logic for the Flush Flags.
  // ------------------------------------------------------------------------
  always @(wrptr_adv or afreadys or afvalids_q or wrptr_bin
           or flush_flag_0_int or flush_flag_1_int or flush_flag_2_int
           or flush_flag_3_int or flush_flag_4_int or flush_flag_5_int)
    begin : c_nxt_flush_flag
      if (afreadys & afvalids_q)
        begin
          if (wrptr_adv)
            case (wrptr_bin[2:0])
              3'b000 :{nxt_flush_flag_0,nxt_flush_flag_1,nxt_flush_flag_2,nxt_flush_flag_3,nxt_flush_flag_4,nxt_flush_flag_5} =
                      {1'b0,{5{1'b1}}};
              3'b001 :{nxt_flush_flag_1,nxt_flush_flag_2,nxt_flush_flag_3,nxt_flush_flag_4,nxt_flush_flag_5,nxt_flush_flag_0} =
                      {1'b0,{5{1'b1}}};
              3'b010 :{nxt_flush_flag_2,nxt_flush_flag_3,nxt_flush_flag_4,nxt_flush_flag_5,nxt_flush_flag_0,nxt_flush_flag_1} =
                      {1'b0,{5{1'b1}}};
              3'b011 :{nxt_flush_flag_3,nxt_flush_flag_4,nxt_flush_flag_5,nxt_flush_flag_0,nxt_flush_flag_1,nxt_flush_flag_2} =
                      {1'b0,{5{1'b1}}};
              3'b100 :{nxt_flush_flag_4,nxt_flush_flag_5,nxt_flush_flag_0,nxt_flush_flag_1,nxt_flush_flag_2,nxt_flush_flag_3} =
                      {1'b0,{5{1'b1}}};
              3'b101 :{nxt_flush_flag_5,nxt_flush_flag_0,nxt_flush_flag_1,nxt_flush_flag_2,nxt_flush_flag_3,nxt_flush_flag_4} =
                      {1'b0,{5{1'b1}}};
              3'b110 ,
              3'b111 :{nxt_flush_flag_0,nxt_flush_flag_1,nxt_flush_flag_2,nxt_flush_flag_3,nxt_flush_flag_4,nxt_flush_flag_5} =
                      {6{1'b1}}; //not used
              default:{nxt_flush_flag_0,nxt_flush_flag_1,nxt_flush_flag_2,nxt_flush_flag_3,nxt_flush_flag_4,nxt_flush_flag_5} =
                      {6{1'bx}};
            endcase // case
          else
             {nxt_flush_flag_0,nxt_flush_flag_1,nxt_flush_flag_2,nxt_flush_flag_3,nxt_flush_flag_4,nxt_flush_flag_5} =
             {6{1'b1}};
        end
      else
        begin
          if (wrptr_adv)
            case (wrptr_bin[2:0])
              3'b000 :{nxt_flush_flag_0,nxt_flush_flag_1,nxt_flush_flag_2,nxt_flush_flag_3,nxt_flush_flag_4,nxt_flush_flag_5} =
                      {1'b0,flush_flag_1_int,flush_flag_2_int,flush_flag_3_int,flush_flag_4_int,flush_flag_5_int};
              3'b001 :{nxt_flush_flag_1,nxt_flush_flag_2,nxt_flush_flag_3,nxt_flush_flag_4,nxt_flush_flag_5,nxt_flush_flag_0} =
                      {1'b0,flush_flag_2_int,flush_flag_3_int,flush_flag_4_int,flush_flag_5_int,flush_flag_0_int};
              3'b010 :{nxt_flush_flag_2,nxt_flush_flag_3,nxt_flush_flag_4,nxt_flush_flag_5,nxt_flush_flag_0,nxt_flush_flag_1} =
                      {1'b0,flush_flag_3_int,flush_flag_4_int,flush_flag_5_int,flush_flag_0_int,flush_flag_1_int};
              3'b011 :{nxt_flush_flag_3,nxt_flush_flag_4,nxt_flush_flag_5,nxt_flush_flag_0,nxt_flush_flag_1,nxt_flush_flag_2} =
                      {1'b0,flush_flag_4_int,flush_flag_5_int,flush_flag_0_int,flush_flag_1_int,flush_flag_2_int};
              3'b100 :{nxt_flush_flag_4,nxt_flush_flag_5,nxt_flush_flag_0,nxt_flush_flag_1,nxt_flush_flag_2,nxt_flush_flag_3} =
                      {1'b0,flush_flag_5_int,flush_flag_0_int,flush_flag_1_int,flush_flag_2_int,flush_flag_3_int};
              3'b101 :{nxt_flush_flag_5,nxt_flush_flag_0,nxt_flush_flag_1,nxt_flush_flag_2,nxt_flush_flag_3,nxt_flush_flag_4} =
                      {1'b0,flush_flag_0_int,flush_flag_1_int,flush_flag_2_int,flush_flag_3_int,flush_flag_4_int};
              3'b110 ,
              3'b111 :{nxt_flush_flag_0,nxt_flush_flag_1,nxt_flush_flag_2,nxt_flush_flag_3,nxt_flush_flag_4,nxt_flush_flag_5} =
                      {flush_flag_0_int,flush_flag_1_int,flush_flag_2_int,flush_flag_3_int,flush_flag_4_int,flush_flag_5_int}; //not used
              default:{nxt_flush_flag_0,nxt_flush_flag_1,nxt_flush_flag_2,nxt_flush_flag_3,nxt_flush_flag_4,nxt_flush_flag_5} =
                      {6{1'bx}};
            endcase // case
          else
             {nxt_flush_flag_0,nxt_flush_flag_1,nxt_flush_flag_2,nxt_flush_flag_3,nxt_flush_flag_4,nxt_flush_flag_5} =
             {flush_flag_0_int,flush_flag_1_int,flush_flag_2_int,flush_flag_3_int,flush_flag_4_int,flush_flag_5_int};
        end
    end // block: c_nxt_flush_flag

  // ------------------------------------------------------------------------
  // Combination Block for nxt_flush_done
  // ------------------------------------------------------------------------
  // afreadys turns on flush_done and ~flush_req_sync turns it off
  assign nxt_flush_done = (afreadys & afvalids_q)? 1'b1 : ((!flush_req_sync)? 1'b0 : flush_done_int);

  // ------------------------------------------------------------------------
  // Sequential Block for flush_done
  // ------------------------------------------------------------------------
  always @(posedge atclks or negedge atresetsn)
    begin : s_flush_done
      if (!atresetsn)
         flush_done_cdc_check  <= 1'b0;
      else
        if (atclkens)
           flush_done_cdc_check  <= nxt_flush_done;
    end // block: s_flush_done

  // ------------------------------------------------------------------------
  // Sequential Block for slv_safe_state
  // ------------------------------------------------------------------------
  // Reset value is 1
  // slv_safe_state follows zero_pointer_sync
  always @(posedge atclks or negedge atresetsn)
    begin : s_slv_safe_state
      if (!atresetsn) begin
         slv_safe_state_cdc_check  <= 1'b1;
      end else begin
        if (atclkens)
           slv_safe_state_cdc_check  <= zero_pointer_sync;
      end
    end // block: s_slv_safe_state

  // ------------------------------------------------------------------------
  // Combination Block for nxt_afvalids
  // ------------------------------------------------------------------------
  // afvalids goes high when flush_req_sync is high and ~flush_done.
  // SAFE state (i.e. slv_safe_state_cdc_check) kills flush requests
  assign nxt_afvalids = (afreadys & afvalids_q)? 1'b0 : ((flush_req_sync & !flush_done_int & !slv_safe_state_cdc_check)? 1'b1 : afvalids_q);

  // ------------------------------------------------------------------------
  // Sequential Block for afvalids
  // ------------------------------------------------------------------------
  always @(posedge atclks or negedge atresetsn)
    begin : s_afvalids
      if (!atresetsn)
        afvalids_q <= 1'b0;
      else
        if (atclkens)
          afvalids_q <= nxt_afvalids;
    end // block: s_afvalids

  assign afvalids = afvalids_q;

  // ------------------------------------------------------------------------
  // Combinational block for the generation of the nxt_wrptr_grey.
  // ------------------------------------------------------------------------
  always @(wrptr_grey_int or slv_safe_state_cdc_check)
    begin
      if (slv_safe_state_cdc_check)
        nxt_wrptr_grey = {4{1'b0}};
      else
        case (wrptr_grey_int[3:0])
          4'b0000: nxt_wrptr_grey = 4'b0001;
          4'b0001: nxt_wrptr_grey = 4'b0011;
          4'b0011: nxt_wrptr_grey = 4'b0010;
          4'b0010: nxt_wrptr_grey = 4'b0110;
          4'b0110: nxt_wrptr_grey = 4'b0111;
          4'b0111: nxt_wrptr_grey = 4'b1111;
          4'b1111: nxt_wrptr_grey = 4'b1110;
          4'b1110: nxt_wrptr_grey = 4'b1010;
          4'b1010: nxt_wrptr_grey = 4'b1011;
          4'b1011: nxt_wrptr_grey = 4'b1001;
          4'b1001: nxt_wrptr_grey = 4'b1000;
          4'b1000: nxt_wrptr_grey = 4'b0000;
          4'b0100,
          4'b1100,
          4'b0101,
          4'b1101: nxt_wrptr_grey = 4'b0000; //not used
          default: nxt_wrptr_grey = {4{1'bx}};
        endcase
    end

  // ------------------------------------------------------------------------
  // Assigining the wrptr_en signal.
  // ------------------------------------------------------------------------
  assign wrptr_en = (wrptr_adv | slv_safe_state_cdc_check) & atclkens;

  // ------------------------------------------------------------------------
  // Sequential block for the generation of the wrptr_grey.
  // ------------------------------------------------------------------------
  always @(posedge atclks or negedge atresetsn)
    begin : s_wrptrctl
      if (!atresetsn)
           wrptr_grey_cdc_check    <= {4{1'b0}};
      else
        if(wrptr_en)
             wrptr_grey_cdc_check  <= nxt_wrptr_grey;
    end // block: s_wrptrctl

  // ------------------------------------------------------------------------
  // Translation of the write pointer from gray code to binary code.
  // ------------------------------------------------------------------------
  always @(wrptr_grey_int)
    begin
      case (wrptr_grey_int[3:0])
        4'b0000: wrptr_bin = 3'b000;
        4'b0001: wrptr_bin = 3'b001;
        4'b0011: wrptr_bin = 3'b010;
        4'b0010: wrptr_bin = 3'b011;
        4'b0110: wrptr_bin = 3'b100;
        4'b0111: wrptr_bin = 3'b101;
        4'b1111: wrptr_bin = 3'b000;
        4'b1110: wrptr_bin = 3'b001;
        4'b1010: wrptr_bin = 3'b010;
        4'b1011: wrptr_bin = 3'b011;
        4'b1001: wrptr_bin = 3'b100;
        4'b1000: wrptr_bin = 3'b101;
        4'b0100,
        4'b1100,
        4'b0101,
        4'b1101: wrptr_bin = 3'b000; //not used
        default: wrptr_bin = {3{1'bx}};
      endcase
    end

  // ------------------------------------------------------------------------
  // Translation of the synchronized read pointer for generating Full flag.
  // ------------------------------------------------------------------------
  always @(rdptr_grey_sync)
    begin
      case (rdptr_grey_sync[3:0])
        4'b0000: rdptr_grey_trans = 4'b0111;
        4'b0001: rdptr_grey_trans = 4'b0110;
        4'b0011: rdptr_grey_trans = 4'b0010;
        4'b0010: rdptr_grey_trans = 4'b0011;
        4'b0110: rdptr_grey_trans = 4'b0001;
        4'b0111: rdptr_grey_trans = 4'b0000;
        4'b1111: rdptr_grey_trans = 4'b1000;
        4'b1110: rdptr_grey_trans = 4'b1001;
        4'b1010: rdptr_grey_trans = 4'b1011;
        4'b1011: rdptr_grey_trans = 4'b1010;
        4'b1001: rdptr_grey_trans = 4'b1110;
        4'b1000: rdptr_grey_trans = 4'b1111;
        4'b0100,
        4'b0101,
        4'b1100,
        4'b1101: rdptr_grey_trans = 4'b0000; //not used
        default: rdptr_grey_trans = {4{1'bx}};
      endcase
  end

  // ------------------------------------------------------------------------
  // Combinational block for the generation of the data_rdy.
  // ------------------------------------------------------------------------
  // Fifo is full when the lower order bits are the same (same Fifo entry)
  // and the most significant bit is different (Read and write have caught up)
  assign data_rdy = (~((wrptr_grey_int[2:0] == rdptr_grey_trans[2:0]) & (wrptr_grey_int[3] != rdptr_grey_trans[3]))) | slv_safe_state_cdc_check;

  // ------------------------------------------------------------------------
  // Combinational block for the generation of the atreadys.
  // ------------------------------------------------------------------------
  assign atreadys = data_rdy;


  assign flush_done_int = flush_done_cdc_check;
  assign flush_done = flush_done_cdc_check;
  assign wrptr_grey = wrptr_grey_cdc_check;
  assign wrptr_grey_int = wrptr_grey_cdc_check;
  assign fifo_data_0 = fifo_data_0_cdc_check;
  assign fifo_data_1 = fifo_data_1_cdc_check;
  assign fifo_data_2 = fifo_data_2_cdc_check;
  assign fifo_data_3 = fifo_data_3_cdc_check;
  assign fifo_data_4 = fifo_data_4_cdc_check;
  assign fifo_data_5 = fifo_data_5_cdc_check;
  assign flush_flag_0 = flush_flag_0_cdc_check;
  assign flush_flag_1 = flush_flag_1_cdc_check;
  assign flush_flag_2 = flush_flag_2_cdc_check;
  assign flush_flag_3 = flush_flag_3_cdc_check;
  assign flush_flag_4 = flush_flag_4_cdc_check;
  assign flush_flag_5 = flush_flag_5_cdc_check;
  assign flush_flag_0_int = flush_flag_0_cdc_check;
  assign flush_flag_1_int = flush_flag_1_cdc_check;
  assign flush_flag_2_int = flush_flag_2_cdc_check;
  assign flush_flag_3_int = flush_flag_3_cdc_check;
  assign flush_flag_4_int = flush_flag_4_cdc_check;
  assign flush_flag_5_int = flush_flag_5_cdc_check;
//------------------------------------------------------------------------------
// OVL Assertions
//------------------------------------------------------------------------------

`ifdef ARM_ASSERT_ON
  `ifndef ARM_CDC_ON
  //----------------------------------------------------------------------------
  // OVL_ASSERT: Check if rdptr_grey_sync doesn't go to illegal values
  //----------------------------------------------------------------------------
  assert_never #(`OVL_FATAL, `OVL_ASSERT, "Illegal synchronized read pointer gray value")
    ovl_rdptr_grey_sync_illegal
      (
        .clk       (atclks),
        .reset_n   (atresetsn),
        .test_expr ((rdptr_grey_sync == 4'b0100)|(rdptr_grey_sync == 4'b0101)|(rdptr_grey_sync == 4'b1100)|(rdptr_grey_sync == 4'b1101))
      );

  //----------------------------------------------------------------------------
  // OVL_ASSERT: Check if wrptr_grey doesn't go to illegal values
  //----------------------------------------------------------------------------
  assert_never #(`OVL_FATAL, `OVL_ASSERT, "Illegal write pointer gray value")
    ovl_wrptr_grey_illegal
      (
        .clk       (atclks),
        .reset_n   (atresetsn),
        .test_expr ((wrptr_grey_int == 4'b0100)|(wrptr_grey_int == 4'b0101)|(wrptr_grey_int == 4'b1100)|(wrptr_grey_int == 4'b1101))
      );

  //----------------------------------------------------------------------------
  // OVL_ASSERT: Check if wrptr_bin doesn't go to illegal values
  //----------------------------------------------------------------------------
  assert_never #(`OVL_FATAL, `OVL_ASSERT, "Illegal write pointer binary value")
    ovl_wrptr_bin_illegal
      (
        .clk       (atclks),
        .reset_n   (atresetsn),
        .test_expr ((wrptr_bin == 3'b110)|(wrptr_bin == 3'b111))
      );

  //----------------------------------------------------------------------------
  // OVL_ASSERT: Check if wrptr_grey  follows grey encoding
  //----------------------------------------------------------------------------

  wire [3:0] wr_ptr_grey_check;
  assign wr_ptr_grey_check = wrptr_grey_int ^ nxt_wrptr_grey;

  assert_never #(`OVL_FATAL, `OVL_ASSERT, "More than one bit changed in write pointer gray value")
    ovl_wrptr_grey_code
      (
        .clk       (atclks),
        .reset_n   (atresetsn),
        .test_expr ((wr_ptr_grey_check != 4'b0001)&(wr_ptr_grey_check != 4'b0010)&(wr_ptr_grey_check != 4'b0100)&(wr_ptr_grey_check != 4'b1000)& ~slv_safe_state_cdc_check)
      );

  `endif
`endif // `ifdef ARM_ASSERT_ON

endmodule // cxatbasyncbridge_slv_fifo
