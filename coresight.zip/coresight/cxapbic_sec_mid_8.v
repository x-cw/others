//-----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2011-2015 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//  Checked In          : $Date: 2014-06-25 08:59:36 +0100 (Wed, 25 Jun 2014) $
//  Revision            : $Revision: 39630 $
//  Release             : CoreSight-SoC-TM100-r3p2-00rel0
//
//----------------------------------------------------------------------------
// Verilog-2001 (IEEE Std 1364-2001)
//  ----------------------------------------------------------------------------
//  Purpose             : APB Interconnect comprising :
//                           APB Slave interfaces
//                           Arbiter
//                           APB Slave mux for address, write-data
//                           ROM Table
//                           Response Mux (for responses from Master interfaces)
//                           Slave demux (for responses)
//   This block, when configured for multiple master interfaces and multiple
// slave interfaces, implements a single-layer interconnect that allows multiple
// APB slave interfaces to initiate transfers to one of several master
// interfaces. When an access from one slave interface is in progress, the other
// slave interfaces are waited (by pulling the respective pready low).
//   A static priority scheme is used to arbitrate between competing slave
// interfaces. Accesses from Slave interface 0 are given the highest priority.
// The priority scheme is : SlvIntf0 (highest priority) >
//           SlvIntf1 > SlvIntf2 > ... > SlvIntf(n-1)
//   Address and Write data from the selected Slave interface is muxed out to
// the master interfaces. For synthesis timing purposes, master address ranges
// are pre-decoded in Slave interfaces and are muxed along with the address.
//   Responses from the addressed master interface are routed to the
// selected Slave interface.
//   This block contains an internal ROM Table whose entries are configured
// by the user. The targetid[] port is used to optionally configure some
// of the values returned on reads of CoreSight management registers in the
// ROM Table.
//  --========================================================================--

module cxapbic_sec_mid_8
 #(
  // Parameters to specify manual ROM Entries
  // Non-zero default to avoid harmless lint warning
  
  parameter ROM_MANUAL_ENTRY0 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY1 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY2 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY3 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY4 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY5 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY6 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY7 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY8 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY9 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY10 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY11 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY12 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY13 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY14 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY15 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY16 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY17 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY18 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY19 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY20 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY21 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY22 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY23 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY24 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY25 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY26 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY27 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY28 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY29 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY30 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY31 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY32 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY33 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY34 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY35 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY36 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY37 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY38 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY39 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY40 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY41 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY42 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY43 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY44 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY45 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY46 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY47 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY48 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY49 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY50 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY51 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY52 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY53 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY54 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY55 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY56 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY57 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY58 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY59 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY60 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY61 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY62 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY63 = 32'h00000010,
  // Parameter to disable automatically created ROM Entries
  parameter ROM_AUTO_DISABLED = 1'b0)
  (
  // Clock and reset
  clk,
  resetn,
  
  // I/O Declaration for APB Slave interface 0
  paddrs0,
  psels0,
  penables0,
  pwrites0,
  pwdatas0,
  prdatas0,
  preadys0,
  pslverrs0,
    
  // I/O Declaration for APB Master interface 0
  paddrm0,
  paddr31m0,
  pselm0,
  penablem0,
  pwritem0,
  pwdatam0,
  prdatam0,
  preadym0,
  pslverrm0,
    
  // I/O Declaration for APB Master interface 1
  paddrm1,
  paddr31m1,
  pselm1,
  penablem1,
  pwritem1,
  pwdatam1,
  prdatam1,
  preadym1,
  pslverrm1,
    
  // I/O Declaration for APB Master interface 2
  paddrm2,
  paddr31m2,
  pselm2,
  penablem2,
  pwritem2,
  pwdatam2,
  prdatam2,
  preadym2,
  pslverrm2,
    
  // I/O Declaration for APB Master interface 3
  paddrm3,
  paddr31m3,
  pselm3,
  penablem3,
  pwritem3,
  pwdatam3,
  prdatam3,
  preadym3,
  pslverrm3,
    
  // I/O Declaration for APB Master interface 4
  paddrm4,
  paddr31m4,
  pselm4,
  penablem4,
  pwritem4,
  pwdatam4,
  prdatam4,
  preadym4,
  pslverrm4,
    
  // I/O Declaration for APB Master interface 5
  paddrm5,
  paddr31m5,
  pselm5,
  penablem5,
  pwritem5,
  pwdatam5,
  prdatam5,
  preadym5,
  pslverrm5,
    
  // I/O Declaration for APB Master interface 6
  paddrm6,
  paddr31m6,
  pselm6,
  penablem6,
  pwritem6,
  pwdatam6,
  prdatam6,
  preadym6,
  pslverrm6,
    
  // I/O Declaration for APB Master interface 7
  paddrm7,
  paddr31m7,
  pselm7,
  penablem7,
  pwritem7,
  pwdatam7,
  prdatam7,
  preadym7,
  pslverrm7,
    

  // paddr31 for Slave interface 0
  paddr31s0,

  // Authentication interface
  dbgswen
);

//-----------------------------------------------------------------------------
// Constants
//-----------------------------------------------------------------------------
`include "cxapbic_constants_sec_mid_8.v"

//-----------------------------------------------------------------------------
// Port declarations
//-----------------------------------------------------------------------------
  // Clock and reset
  input wire clk;
  input wire resetn;
  // I/O Declaration for APB Slave interface 0
  input  wire [15:2] paddrs0;
  input  wire        psels0;
  input  wire        penables0;
  input  wire        pwrites0;
  input  wire [31:0] pwdatas0;
  output wire [31:0] prdatas0;
  output wire        preadys0;
  output wire        pslverrs0;
    
  // I/O Declaration for APB Master interface 0
  output wire [(12+MASTER_INTF0_SIZE)-1:2] paddrm0;
  output wire        paddr31m0;
  output wire        pselm0;
  output wire        penablem0;
  output wire        pwritem0;
  output wire [31:0] pwdatam0;
  input  wire [31:0] prdatam0;
  input  wire        preadym0;
  input  wire        pslverrm0;
    
  // I/O Declaration for APB Master interface 1
  output wire [(12+MASTER_INTF1_SIZE)-1:2] paddrm1;
  output wire        paddr31m1;
  output wire        pselm1;
  output wire        penablem1;
  output wire        pwritem1;
  output wire [31:0] pwdatam1;
  input  wire [31:0] prdatam1;
  input  wire        preadym1;
  input  wire        pslverrm1;
    
  // I/O Declaration for APB Master interface 2
  output wire [(12+MASTER_INTF2_SIZE)-1:2] paddrm2;
  output wire        paddr31m2;
  output wire        pselm2;
  output wire        penablem2;
  output wire        pwritem2;
  output wire [31:0] pwdatam2;
  input  wire [31:0] prdatam2;
  input  wire        preadym2;
  input  wire        pslverrm2;
    
  // I/O Declaration for APB Master interface 3
  output wire [(12+MASTER_INTF3_SIZE)-1:2] paddrm3;
  output wire        paddr31m3;
  output wire        pselm3;
  output wire        penablem3;
  output wire        pwritem3;
  output wire [31:0] pwdatam3;
  input  wire [31:0] prdatam3;
  input  wire        preadym3;
  input  wire        pslverrm3;
    
  // I/O Declaration for APB Master interface 4
  output wire [(12+MASTER_INTF4_SIZE)-1:2] paddrm4;
  output wire        paddr31m4;
  output wire        pselm4;
  output wire        penablem4;
  output wire        pwritem4;
  output wire [31:0] pwdatam4;
  input  wire [31:0] prdatam4;
  input  wire        preadym4;
  input  wire        pslverrm4;
    
  // I/O Declaration for APB Master interface 5
  output wire [(12+MASTER_INTF5_SIZE)-1:2] paddrm5;
  output wire        paddr31m5;
  output wire        pselm5;
  output wire        penablem5;
  output wire        pwritem5;
  output wire [31:0] pwdatam5;
  input  wire [31:0] prdatam5;
  input  wire        preadym5;
  input  wire        pslverrm5;
    
  // I/O Declaration for APB Master interface 6
  output wire [(12+MASTER_INTF6_SIZE)-1:2] paddrm6;
  output wire        paddr31m6;
  output wire        pselm6;
  output wire        penablem6;
  output wire        pwritem6;
  output wire [31:0] pwdatam6;
  input  wire [31:0] prdatam6;
  input  wire        preadym6;
  input  wire        pslverrm6;
    
  // I/O Declaration for APB Master interface 7
  output wire [(12+MASTER_INTF7_SIZE)-1:2] paddrm7;
  output wire        paddr31m7;
  output wire        pselm7;
  output wire        penablem7;
  output wire        pwritem7;
  output wire [31:0] pwdatam7;
  input  wire [31:0] prdatam7;
  input  wire        preadym7;
  input  wire        pslverrm7;
    

  // paddr31 for Slave interface 0
  input  wire        paddr31s0;

  // Authentication interface
  input  wire        dbgswen;

//-----------------------------------------------------------------------------
// Wire declarations
//-----------------------------------------------------------------------------

// Registered versions of pselm* signals
wire pselm0_reg;
wire pselm1_reg;
wire pselm2_reg;
wire pselm3_reg;
wire pselm4_reg;
wire pselm5_reg;
wire pselm6_reg;
wire pselm7_reg;

wire psel_rom_table_reg;

wire [11:2]  paddr_rom_table;
wire psel_rom_table;

wire [31:0] rom_data;

// Muxed responses from master interfaces
wire [31:0] prdatam;  // Data from the addressed master interface
wire preadym;         // PREADY response from the addressed master interface
wire pslverrm;        // Error response from the addressed master interface

// Address pre-decode from Slave interface block 0
// One-hot vector to indicate the addressed Master interface.
wire [7:0] paddrs0_decode;

// Access from Slave interface 0 to the ROM table
wire rom_table_sel_0;

// Slice of address vector used for decode in Slave interface block 0
        
wire [3:0] paddrs0_msb_to_12;

// Data response from the addressed Master interface
wire [31:0] prdata_arbitrated_s0;

// Ready response from the addressed Master interface
wire pready_arbitrated_s0;

// Error response from the addressed Master interface
wire pslverr_arbitrated_s0;
  

//-----------------------------------------------------------------------------
//
//  Main body of code
//  =================
//
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// Extract address bits
//-----------------------------------------------------------------------------
assign paddrs0_msb_to_12 = paddrs0[15:12];
//-----------------------------------------------------------------------------
// APB Slave interface 0 instantiation
//-----------------------------------------------------------------------------
  cxapbic_slv_intf_sec_mid_8 u_cxapbic_slv_intf_sec_mid_8_0
  (
  .clk                     (clk),
  .resetn                  (resetn),

  .paddrs_msb_to_12        (paddrs0_msb_to_12),
  .paddr31s                (paddr31s0),
  .psels                   (psels0),
  .penables                (penables0),

  .pslverr_arbitrated      (pslverr_arbitrated_s0),
  .pready_arbitrated       (pready_arbitrated_s0),
  .dbgswen                 (dbgswen),

  .pslverrs                (pslverrs0),
  .preadys                 (preadys0),

  .paddrs_decode           (paddrs0_decode),
  
  .rom_table_sel           (rom_table_sel_0)
  );
        
//-----------------------------------------------------------------------------
// Route the de-muxed read data to the respective slave interfaces
//-----------------------------------------------------------------------------
assign prdatas0 = prdata_arbitrated_s0;


//-----------------------------------------------------------------------------
// Slave interface mux
//-----------------------------------------------------------------------------
  cxapbic_slv_mux_sec_mid_8 u_cxapbic_slv_mux_sec_mid_8
  (
  .clk                     (clk),
  .resetn                  (resetn),

  .rom_table_sel_0         (rom_table_sel_0),
  .paddrs0_decode          (paddrs0_decode),
  .paddrs0_14to2                 (paddrs0[14:2]),
  .pwrites0                (pwrites0),
  .pwdatas0                (pwdatas0),
  
  .paddr31s0               (paddr31s0),

  .penables0               (penables0),
  .pselm0_reg              (pselm0_reg),
  .penablem0               (penablem0),
  .pwritem0                (pwritem0),
  .paddrm0                 (paddrm0),
  .paddr31m0               (paddr31m0),
  .pwdatam0                (pwdatam0),
  
  .pselm1_reg              (pselm1_reg),
  .penablem1               (penablem1),
  .pwritem1                (pwritem1),
  .paddrm1                 (paddrm1),
  .paddr31m1               (paddr31m1),
  .pwdatam1                (pwdatam1),
  
  .pselm2_reg              (pselm2_reg),
  .penablem2               (penablem2),
  .pwritem2                (pwritem2),
  .paddrm2                 (paddrm2),
  .paddr31m2               (paddr31m2),
  .pwdatam2                (pwdatam2),
  
  .pselm3_reg              (pselm3_reg),
  .penablem3               (penablem3),
  .pwritem3                (pwritem3),
  .paddrm3                 (paddrm3),
  .paddr31m3               (paddr31m3),
  .pwdatam3                (pwdatam3),
  
  .pselm4_reg              (pselm4_reg),
  .penablem4               (penablem4),
  .pwritem4                (pwritem4),
  .paddrm4                 (paddrm4),
  .paddr31m4               (paddr31m4),
  .pwdatam4                (pwdatam4),
  
  .pselm5_reg              (pselm5_reg),
  .penablem5               (penablem5),
  .pwritem5                (pwritem5),
  .paddrm5                 (paddrm5),
  .paddr31m5               (paddr31m5),
  .pwdatam5                (pwdatam5),
  
  .pselm6_reg              (pselm6_reg),
  .penablem6               (penablem6),
  .pwritem6                (pwritem6),
  .paddrm6                 (paddrm6),
  .paddr31m6               (paddr31m6),
  .pwdatam6                (pwdatam6),
  
  .pselm7_reg              (pselm7_reg),
  .penablem7               (penablem7),
  .pwritem7                (pwritem7),
  .paddrm7                 (paddrm7),
  .paddr31m7               (paddr31m7),
  .pwdatam7                (pwdatam7),
  
  .paddr_rom_table         (paddr_rom_table),
  
  .psel_rom_table_reg      (psel_rom_table_reg)
  );

  assign pselm0 = paddrs0_decode[0];
  
  assign pselm1 = paddrs0_decode[1];
  
  assign pselm2 = paddrs0_decode[2];
  
  assign pselm3 = paddrs0_decode[3];
  
  assign pselm4 = paddrs0_decode[4];
  
  assign pselm5 = paddrs0_decode[5];
  
  assign pselm6 = paddrs0_decode[6];
  
  assign pselm7 = paddrs0_decode[7];
  
  assign psel_rom_table = rom_table_sel_0;

//-----------------------------------------------------------------------------
// ROM Table instantiation
//-----------------------------------------------------------------------------
  cxapbic_rom_table_sec_mid_8
 #(
  
  .ROM_MANUAL_ENTRY0  (ROM_MANUAL_ENTRY0),
  .ROM_MANUAL_ENTRY1  (ROM_MANUAL_ENTRY1),
  .ROM_MANUAL_ENTRY2  (ROM_MANUAL_ENTRY2),
  .ROM_MANUAL_ENTRY3  (ROM_MANUAL_ENTRY3),
  .ROM_MANUAL_ENTRY4  (ROM_MANUAL_ENTRY4),
  .ROM_MANUAL_ENTRY5  (ROM_MANUAL_ENTRY5),
  .ROM_MANUAL_ENTRY6  (ROM_MANUAL_ENTRY6),
  .ROM_MANUAL_ENTRY7  (ROM_MANUAL_ENTRY7),
  .ROM_MANUAL_ENTRY8  (ROM_MANUAL_ENTRY8),
  .ROM_MANUAL_ENTRY9  (ROM_MANUAL_ENTRY9),
  .ROM_MANUAL_ENTRY10  (ROM_MANUAL_ENTRY10),
  .ROM_MANUAL_ENTRY11  (ROM_MANUAL_ENTRY11),
  .ROM_MANUAL_ENTRY12  (ROM_MANUAL_ENTRY12),
  .ROM_MANUAL_ENTRY13  (ROM_MANUAL_ENTRY13),
  .ROM_MANUAL_ENTRY14  (ROM_MANUAL_ENTRY14),
  .ROM_MANUAL_ENTRY15  (ROM_MANUAL_ENTRY15),
  .ROM_MANUAL_ENTRY16  (ROM_MANUAL_ENTRY16),
  .ROM_MANUAL_ENTRY17  (ROM_MANUAL_ENTRY17),
  .ROM_MANUAL_ENTRY18  (ROM_MANUAL_ENTRY18),
  .ROM_MANUAL_ENTRY19  (ROM_MANUAL_ENTRY19),
  .ROM_MANUAL_ENTRY20  (ROM_MANUAL_ENTRY20),
  .ROM_MANUAL_ENTRY21  (ROM_MANUAL_ENTRY21),
  .ROM_MANUAL_ENTRY22  (ROM_MANUAL_ENTRY22),
  .ROM_MANUAL_ENTRY23  (ROM_MANUAL_ENTRY23),
  .ROM_MANUAL_ENTRY24  (ROM_MANUAL_ENTRY24),
  .ROM_MANUAL_ENTRY25  (ROM_MANUAL_ENTRY25),
  .ROM_MANUAL_ENTRY26  (ROM_MANUAL_ENTRY26),
  .ROM_MANUAL_ENTRY27  (ROM_MANUAL_ENTRY27),
  .ROM_MANUAL_ENTRY28  (ROM_MANUAL_ENTRY28),
  .ROM_MANUAL_ENTRY29  (ROM_MANUAL_ENTRY29),
  .ROM_MANUAL_ENTRY30  (ROM_MANUAL_ENTRY30),
  .ROM_MANUAL_ENTRY31  (ROM_MANUAL_ENTRY31),
  .ROM_MANUAL_ENTRY32  (ROM_MANUAL_ENTRY32),
  .ROM_MANUAL_ENTRY33  (ROM_MANUAL_ENTRY33),
  .ROM_MANUAL_ENTRY34  (ROM_MANUAL_ENTRY34),
  .ROM_MANUAL_ENTRY35  (ROM_MANUAL_ENTRY35),
  .ROM_MANUAL_ENTRY36  (ROM_MANUAL_ENTRY36),
  .ROM_MANUAL_ENTRY37  (ROM_MANUAL_ENTRY37),
  .ROM_MANUAL_ENTRY38  (ROM_MANUAL_ENTRY38),
  .ROM_MANUAL_ENTRY39  (ROM_MANUAL_ENTRY39),
  .ROM_MANUAL_ENTRY40  (ROM_MANUAL_ENTRY40),
  .ROM_MANUAL_ENTRY41  (ROM_MANUAL_ENTRY41),
  .ROM_MANUAL_ENTRY42  (ROM_MANUAL_ENTRY42),
  .ROM_MANUAL_ENTRY43  (ROM_MANUAL_ENTRY43),
  .ROM_MANUAL_ENTRY44  (ROM_MANUAL_ENTRY44),
  .ROM_MANUAL_ENTRY45  (ROM_MANUAL_ENTRY45),
  .ROM_MANUAL_ENTRY46  (ROM_MANUAL_ENTRY46),
  .ROM_MANUAL_ENTRY47  (ROM_MANUAL_ENTRY47),
  .ROM_MANUAL_ENTRY48  (ROM_MANUAL_ENTRY48),
  .ROM_MANUAL_ENTRY49  (ROM_MANUAL_ENTRY49),
  .ROM_MANUAL_ENTRY50  (ROM_MANUAL_ENTRY50),
  .ROM_MANUAL_ENTRY51  (ROM_MANUAL_ENTRY51),
  .ROM_MANUAL_ENTRY52  (ROM_MANUAL_ENTRY52),
  .ROM_MANUAL_ENTRY53  (ROM_MANUAL_ENTRY53),
  .ROM_MANUAL_ENTRY54  (ROM_MANUAL_ENTRY54),
  .ROM_MANUAL_ENTRY55  (ROM_MANUAL_ENTRY55),
  .ROM_MANUAL_ENTRY56  (ROM_MANUAL_ENTRY56),
  .ROM_MANUAL_ENTRY57  (ROM_MANUAL_ENTRY57),
  .ROM_MANUAL_ENTRY58  (ROM_MANUAL_ENTRY58),
  .ROM_MANUAL_ENTRY59  (ROM_MANUAL_ENTRY59),
  .ROM_MANUAL_ENTRY60  (ROM_MANUAL_ENTRY60),
  .ROM_MANUAL_ENTRY61  (ROM_MANUAL_ENTRY61),
  .ROM_MANUAL_ENTRY62  (ROM_MANUAL_ENTRY62),
  .ROM_MANUAL_ENTRY63  (ROM_MANUAL_ENTRY63),
  .ROM_AUTO_DISABLED   (ROM_AUTO_DISABLED)
  )
  u_cxapbic_rom_table_sec_mid_8
  (
  .clk                     (clk),
  .resetn                  (resetn),
  .psel_rom_table          (psel_rom_table),
  .paddr_rom_table         (paddr_rom_table),

  
  .rom_data                (rom_data)
  );

//-----------------------------------------------------------------------------
// Responses from the Master interfaces to the Slave interfaces
//-----------------------------------------------------------------------------
  cxapbic_resp_mux_sec_mid_8 u_cxapbic_resp_mux_sec_mid_8
  (
  .psel_rom_table_reg     (psel_rom_table_reg),

  .pselm0_reg             (pselm0_reg),
  .preadym0               (preadym0),
  .pslverrm0              (pslverrm0),
  .prdatam0               (prdatam0),
    
  .pselm1_reg             (pselm1_reg),
  .preadym1               (preadym1),
  .pslverrm1              (pslverrm1),
  .prdatam1               (prdatam1),
    
  .pselm2_reg             (pselm2_reg),
  .preadym2               (preadym2),
  .pslverrm2              (pslverrm2),
  .prdatam2               (prdatam2),
    
  .pselm3_reg             (pselm3_reg),
  .preadym3               (preadym3),
  .pslverrm3              (pslverrm3),
  .prdatam3               (prdatam3),
    
  .pselm4_reg             (pselm4_reg),
  .preadym4               (preadym4),
  .pslverrm4              (pslverrm4),
  .prdatam4               (prdatam4),
    
  .pselm5_reg             (pselm5_reg),
  .preadym5               (preadym5),
  .pslverrm5              (pslverrm5),
  .prdatam5               (prdatam5),
    
  .pselm6_reg             (pselm6_reg),
  .preadym6               (preadym6),
  .pslverrm6              (pslverrm6),
  .prdatam6               (prdatam6),
    
  .pselm7_reg             (pselm7_reg),
  .preadym7               (preadym7),
  .pslverrm7              (pslverrm7),
  .prdatam7               (prdatam7),
    
  .rom_data               (rom_data),

  .preadym                (preadym),
  .pslverrm               (pslverrm),
  .prdatam                (prdatam)
  );


assign pready_arbitrated_s0  = preadym;
assign pslverr_arbitrated_s0 = pslverrm;
assign prdata_arbitrated_s0  = prdatam;
  

`ifdef ARM_ASSERT_ON
//-----------------------------------------------------------------------------
// OVL Assertions
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
// Check for one-hot on select lines
//-----------------------------------------------------------------------------


  wire [8:0] pselm_one_hot_chk;
  assign pselm_one_hot_chk = {

    pselm0,
    pselm1,
    pselm2,
    pselm3,
    pselm4,
    pselm5,
    pselm6,
    pselm7,
    psel_rom_table};
  assert_zero_one_hot #(`OVL_ERROR, 9, `OVL_ASSERT,
    "OVL Message : cxapbic_sec_mid_8 - Multiple access targets selected at the same time.")
      uzovl_cxapbic_sec_mid_8_pselm_one_hot_chk
        (
         .clk         (clk),
         .reset_n     (resetn),
         .test_expr   (pselm_one_hot_chk)
        );

`endif

endmodule // cxapbic_sec_mid_8

//-- END OF FILE --------------------------------------------------------------
