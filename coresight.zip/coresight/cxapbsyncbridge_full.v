//-----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2010-2015 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//  Version and Release Control Information:
//
//  File Name           : cxapbsyncbridge_xmlcfg.v.xsl
//
//  Checked In          : $Date: 2015-02-16 14:55:41 +0000 (Mon, 16 Feb 2015) $
//
//  File Revision       : $Revision: 41661 $
//
//  Release Information : CoreSight-SoC-TM100-r3p2-00rel0
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// Abstract : CoreSight XDK APB Sync Bridge (cxapbsyncbridge) - Top Level Block
//-----------------------------------------------------------------------------
//
// cxapbsyncbridge - CoreSight APB Sync Bridge
// -------------------------------------------------
//
// CoreSight AMBA Peripheral Bus (APB) Synchronous bridge to improve
// synthesis timing.
//-----------------------------------------------------------------------------

module cxapbsyncbridge_full  (
  // Inputs
  input wire         pclk,
  input wire         presetn,

  input wire         pclkens,
  input wire [31:0]  paddrs,
  input wire [31:0]  pwdatas,
  input wire         pwrites,
  input wire         penables,
  input wire         psels,
  output wire [31:0] prdatas,
  output wire        pslverrs,
  output wire        preadys,


  input wire         pclkenm,
  output wire [31:0] paddrm,
  output wire [31:0] pwdatam,
  output wire        pwritem,
  output wire        penablem,
  output wire        pselm,
  input wire [31:0]  prdatam,
  input wire         pslverrm,
  input wire         preadym

  );



//------------------------------------------------------------------------------
// Constants definitions
//------------------------------------------------------------------------------


  //----------------------------------------------------------------------------
  // Wires and Register declarations
  //----------------------------------------------------------------------------

  //============================================================================
  //
  // Main body of code
  // =================
  //
  //============================================================================


  //----------------------------------------------------------------------------
  // Master block instantiation
  //----------------------------------------------------------------------------
cxapbsyncbridge_full_full
 u_apbsyncbridge_full (
    .pclk               (pclk),
    .presetn            (presetn),
    .pclkenm            (pclkenm),
    .paddrm             (paddrm),
    .pwdatam            (pwdatam),
    .pwritem            (pwritem),
    .penablem           (penablem),
    .pselm              (pselm),
    .prdatam            (prdatam),
    .pslverrm           (pslverrm),
    .preadym            (preadym),
    .pclkens            (pclkens),
    .paddrs             (paddrs),
    .pwdatas            (pwdatas),
    .pwrites            (pwrites),
    .penables           (penables),
    .psels              (psels),
    .prdatas            (prdatas),
    .pslverrs           (pslverrs),
    .preadys            (preadys)
    

                             );


`ifdef ARM_ASSERT_ON
  //----------------------------------------------------------------------------
  // OVL Assertions
  //----------------------------------------------------------------------------

  //----------------------------------------------------------------------------
  // LPI can be present only with a Full type bridge
  //----------------------------------------------------------------------------

  localparam full_bridge = 1'b1;
  localparam lpi_choice  = 1'b0;

  assert_never #(`OVL_ERROR, `OVL_ASSERT,
    "OVL Message : Configuration error: LPI can be present only with a Full type bridge")
      uzovl_cxapbsyncbridge_lpi_with_full_type_bridge
        (
         .clk         (pclk),
         .reset_n     (presetn),
         .test_expr   (lpi_choice & ~full_bridge)
        );

`endif
endmodule // cxapbsyncbridge
