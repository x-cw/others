//-----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2003-2015 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//  Version and Release Control Information:
//
//  Checked In          : $Date: 2015-03-09 14:04:25 +0000 (Mon, 09 Mar 2015) $
//
//  File Revision       : $Revision: 41969 $
//
//  Release Information : CoreSight-SoC-TM100-r3p2-00rel0
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// Abstract : Debug Access Port APB Access Port (cxdapapbap) - DAP Interface
//-----------------------------------------------------------------------------
//
// cxdapapbap - Debug Access Port APB Access Port
// ----------------------------------------------
//
// Debug Access Port APB Access Port component provides an APB interface to a
// System On Chip (SOC).
//
// cxdapapbap_dap_if.v
// -------------------
//
// cxdapapbap_apb_if.v provides the DAP slave interface for the dapapbap block.
//
// Instantiated blocks
// -------------------
// None.
//-----------------------------------------------------------------------------

module cxdapapbap_dap_if (
  // Inputs
  dapclk, dapclken, dapresetn, dapsel, dapenable, dapwrite, dapabort,
  dapaddr, dapwdata_31to2, deviceen, apb_tr_done, apb_tr_in_prog, pslverr,
  prdata, apb_rom_addr,
  // Outputs
  dapready, dapslverr, daprdata, apb_rd_wr, apb_tr_req, paddr_ap,
  pdbgswen
  );

`include "cxdapapbap_constants.v"

  //----------------------------------------------------------------------------
  // Inputs
  //----------------------------------------------------------------------------
  input         dapclk;         // DAP clock
  input         dapclken;       // DAP clock enable
  input         dapresetn;      // DAP asynchrnous reset active low

  input         dapsel;         // DAP select
  input         dapenable;      // DAP enable
  input         dapwrite;       // DAP write or read
  input         dapabort;       // DAP abort
  input   [7:2] dapaddr;        // DAP address bus
  input  [31:2] dapwdata_31to2; // DAP write data bus

  input         deviceen;       // Device enable

  input         apb_tr_done;    // APB interface transfer complete
  input         apb_tr_in_prog; // APB interface transfer in progress
  input         pslverr;        // APB interface error response
  input  [31:0] prdata;         // APB interface read data bus
  input  [31:0] apb_rom_addr;   // APB ROM base address tie-off

  //----------------------------------------------------------------------------
  // Outputs
  //----------------------------------------------------------------------------
  output        dapready;       // DAP slave ready
  output        dapslverr;      // DAP slave error
  output [31:0] daprdata;       // DAP read data bus

  output        apb_rd_wr;      // APB read or write transfer to APB interface
  output        apb_tr_req;     // APB transfer request to APB interface
  output [29:0] paddr_ap;       // APB address bus to the APB interface

  output        pdbgswen;       // Software enable to the debug APB

  //----------------------------------------------------------------------------
  // Wires
  //----------------------------------------------------------------------------
  wire          bd_sel;
  wire          csw_sel;
  wire          ta_sel;
  wire          id_sel;
  wire          bd_0_sel;
  wire          bd_1_sel;
  wire          bd_2_sel;
  wire          bd_3_sel;
  wire          drw_sel;
  wire          rom_sel;

  wire          ap_select;
  wire          reg_access;
  wire          apb_access;
  wire          trig_sm;
  wire          dap_tr_done;

  wire          bd_wr_en;
  wire          csw_sw_wr_en;
  wire          csw_sw_rd_en;
  wire          ta_sw_wr_en;
  wire          ta_sw_rd_en;
  wire          rom_sw_rd_en;
  wire          id_sw_rd_en;
  wire          apb_sw_rd_en;
  wire          auto_inc_en;
  wire          bd_access_en;
  wire          ta_wr_en;
  wire          pdbgswen_wr_en;
  wire          next_pdbg;
  wire          next_dap_slv_err;
  wire          apb_tr_req;
  wire          apb_tr_req_int;

  wire [29:0]   next_ta_reg;
  wire [31:0]   csw_rd_data;
  wire [31:0]   ta_rd_data;
  wire [31:0]   id_rd_data;
  wire [31:0]   rom_rd_data;
  wire [31:0]   next_dap_rd_data;

  wire          deviceen_corrupt;
  wire          device_en_sync;

  //----------------------------------------------------------------------------
  // Registers
  //----------------------------------------------------------------------------
  reg           dapready;
  reg           dapslverr;
  reg [31:0]    daprdata;

  reg           dap_rst;
  reg           next_dap_ready;
  reg           bd_access;
  reg           pdbg;
  reg           addr_inc;
  reg [1:0]     bd_reg;
  reg [1:0]     cur_state;
  reg [1:0]     next_state;
  reg [29:0]    ta_reg;

  //----------------------------------------------------------------------------
  //
  // Main body of code
  // =================
  //
  //----------------------------------------------------------------------------

  //----------------------------------------------------------------------------
  // The ap_select is set for one clock period of dapclk.This signal indicates
  // that the APB-AP block is selected for transactions.
  //----------------------------------------------------------------------------
  assign ap_select = dapsel & ~dapenable;

  //----------------------------------------------------------------------------
  // bd_sel indicates that the register accesses is to one of the banked data
  // registers.
  //----------------------------------------------------------------------------
  assign bd_sel = bd_0_sel | bd_1_sel | bd_2_sel | bd_3_sel;

  //----------------------------------------------------------------------------
  // The csw_sel,ta_sel,bd_0_sel,bd_1_sel,bd_2_sel,bd_3_sel,id_sel,drw_sel and rom_sel are
  // the select signals for selecting the control status word,transfer address,
  // banked data0,banked data1,banked data2,banked data3,identification,data
  // read write and ROM address registers respectively.
  //----------------------------------------------------------------------------
  assign csw_sel  = (dapaddr[7:2] == APB_CSWREG);
  assign ta_sel   = (dapaddr[7:2] == APB_TAREG);
  assign bd_0_sel = (dapaddr[7:2] == APB_BD0REG);
  assign bd_1_sel = (dapaddr[7:2] == APB_BD1REG);
  assign bd_2_sel = (dapaddr[7:2] == APB_BD2REG);
  assign bd_3_sel = (dapaddr[7:2] == APB_BD3REG);
  assign id_sel   = (dapaddr[7:2] == APB_IDREG);
  assign drw_sel  = (dapaddr[7:2] == APB_DRWREG);
  assign rom_sel  = (dapaddr[7:2] == APB_ROMREG);

  //----------------------------------------------------------------------------
  // The APB-AP register read and write transactions can either be to the
  // registers within the APB-AP block or can be in the registers residing
  // in the APB domain outside the APB-AP block.So the register read and
  // write transactions are classified into two sets of accesses.Firstly,
  // reg_access is the enable signal for the registers residing in the APB-AP
  // block and secondly the apb_access is the enable signal for the registers
  // residing outside the APB-AP block.The reg_access is for the control status
  // word,transfer address,identification and ROM address registers.The
  // apb_access is for the banked data and data read write registers.
  //----------------------------------------------------------------------------
  assign reg_access = csw_sel | ta_sel  | id_sel  | rom_sel;
  assign apb_access = drw_sel | bd_sel;

  //----------------------------------------------------------------------------
  // Sequential block for dap_rst.dap_rst is set after a reset is completed.
  //----------------------------------------------------------------------------
  always @ (posedge dapclk or negedge dapresetn)
    begin : p_daprst
      if (!dapresetn)
        dap_rst <= 1'b0;
      else
        if(dapclken)
          dap_rst <= 1'b1;
    end

  //----------------------------------------------------------------------------
  // Combinational logic for next_pdbg.The next_pdbg is set when the reset is
  // completed or when the software wants to write into it.
  //----------------------------------------------------------------------------
  assign pdbgswen_wr_en = ~dap_rst | csw_sw_wr_en | ~device_en_sync;
  assign next_pdbg      = ~dap_rst | dapwdata_31to2[31] | ~device_en_sync;

  //----------------------------------------------------------------------------
  // Sequential block for writing into the control status word register.
  // Control Status Word Register : Offset 0x00 ( R/W )
  // pdbgswen field of the CSW register.
  //----------------------------------------------------------------------------
  always @ (posedge dapclk or negedge dapresetn)
    begin : p_pdbg
      if (!dapresetn)
        pdbg <= 1'b0;
      else
        if(pdbgswen_wr_en)
          pdbg <= next_pdbg;
    end

  //----------------------------------------------------------------------------
  // The csw_sw_wr_en and csw_sw_rd_en signals are the enable signals for writing and
  // reading respectively from the control status word register.The writes to
  // the control status word are ignored if the apb_tr_in_prog is set.
  //----------------------------------------------------------------------------
  assign csw_sw_wr_en = csw_sel & ap_select & dapwrite & ~apb_tr_in_prog & dapclken;
  assign csw_sw_rd_en = csw_sel & ap_select & ~dapwrite;

  //----------------------------------------------------------------------------
  // Sequential block for writing into the control status word register.
  // Control Status Word Register : Offset 0x00 ( R/W )
  // addr_inc field of the CSW register.
  //----------------------------------------------------------------------------
  always @ (posedge dapclk or negedge dapresetn)
    begin : p_addrinc
      if (!dapresetn)
        addr_inc <= 1'b0;
      else
        if (csw_sw_wr_en)
          addr_inc <= dapwdata_31to2[4];
    end

  //----------------------------------------------------------------------------
  // Logic for driving the read data from the control status word register.Not
  // all the bits are writeable by the software.The bits which are read only
  // are driven along with the writeable fields onto the read data.
  //----------------------------------------------------------------------------
  assign csw_rd_data = {pdbg,{23{1'b0}},apb_tr_in_prog,
                      device_en_sync,1'b0,addr_inc,4'b0010};

  //----------------------------------------------------------------------------
  // The ta_sw_wr_en and ta_sw_rd_en signals are the enable signals for writing and
  // reading respectively from the transfer address register.
  //----------------------------------------------------------------------------
  assign ta_sw_wr_en = ta_sel & ap_select & dapwrite & ~apb_tr_in_prog;
  assign ta_sw_rd_en = ta_sel & ap_select & ~dapwrite;

  //----------------------------------------------------------------------------
  // Logic for the next_ta_reg.When the software selects the transfer address
  // register for performing a write transaction,the write data present on the
  // dapwdata is written into this register.Otherwise the value in this register
  // is incremented by one if the auto increment is enabled in the control
  // status register.
  //----------------------------------------------------------------------------
  assign next_ta_reg[29:8] = ta_sw_wr_en ? dapwdata_31to2[31:10] : ta_reg[29:8];
  assign next_ta_reg[7:0]  = ta_sw_wr_en ? dapwdata_31to2[9:2]   : ta_reg[7:0] + 8'h1;

  //----------------------------------------------------------------------------
  // The auto_inc_en signal is used for incrementing the address in the transfer
  // address register.The address is only incremented if the auto increment
  // option is set in the control status word register and if the current
  // transaction completes without an error response.The auto incrementing
  // is performed on the data read write register only.The address is not
  // if the current transaction is aborted.
  //----------------------------------------------------------------------------
  assign auto_inc_en = (addr_inc   == APB_ADDR_INC)  &
                       (next_state == ST_DAPAPB_RDY) &
                       (cur_state  == ST_DAPAPB_APB) &
                      ~(pslverr | dapabort)          &
                       drw_sel;

  //----------------------------------------------------------------------------
  // The ta_wr_en is the enable signal for writing into the transfer address
  // register.The register is updated by both software and hardware.The ta_sw_wr_en
  // and auto_inc_en are enable signals for software and hardware respectively.The
  // writes to the transfer address register are ignored if the apb_tr_in_prog bit
  // is set.
  //----------------------------------------------------------------------------
  assign ta_wr_en = (ta_sw_wr_en | auto_inc_en) & dapclken;

  //----------------------------------------------------------------------------
  // Sequential block for writing into the transfer address register.
  // Transfer Address Register : Offset 0x04 ( R/W )
  //----------------------------------------------------------------------------
  always @ (posedge dapclk or negedge dapresetn)
    begin : p_tareg
      if (!dapresetn)
        ta_reg <= {30{1'b0}};
      else
        if (ta_wr_en)
          ta_reg <= next_ta_reg;
    end

  //----------------------------------------------------------------------------
  // The ta_rd_data is driven from the ta_reg.
  //----------------------------------------------------------------------------
  assign ta_rd_data = {ta_reg,2'b00};

  //----------------------------------------------------------------------------
  // Debug APB ROM Address Register : Offset 0xF8 ( R )
  //----------------------------------------------------------------------------
  assign rom_rd_data = apb_rom_addr | 32'h00000002; // Bit 1 should always be set
  assign rom_sw_rd_en = rom_sel & ap_select & ~dapwrite;

  //----------------------------------------------------------------------------
  // Identification Register : Offset 0xFC ( R )
  //----------------------------------------------------------------------------
  assign id_rd_data = ID_REG_APBAP;
  assign id_sw_rd_en = id_sel & ap_select & ~dapwrite;

  //----------------------------------------------------------------------------
  // The apb_sw_rd_en is the enable signal for reading from the APB interface.
  //----------------------------------------------------------------------------
  assign apb_sw_rd_en = apb_access & apb_tr_done;

  //----------------------------------------------------------------------------
  // Logic for the trig_sm signal.This signal triggers the DAP slave state
  // machine.The state machine gets triggered for register accesses within
  // the APB-AP block and for the register accesses in the APB domain.For the
  // register accesses within the APB-AP block,the register reads are always
  // allowed.But the register writes in the APB-AP are only allowed if the
  // TrInProg is not set.All the register accesses in the APB domain are only
  // allowed if the TrInProg bit is not set.The APB-AP block will ignore all
  // the register writes within the APB-AP block and all the register accesses
  // in the APB domain if the TrInProg bit is set.If the device_en_sync is not,the
  // DAP slave state machine will not get triggered for transactions within
  // the APB domain.
  //----------------------------------------------------------------------------
  assign trig_sm = ((reg_access & ((dapwrite & ~apb_tr_in_prog) | ~dapwrite)) |
                   (apb_access & ~apb_tr_in_prog  & device_en_sync)) & ap_select;

  //----------------------------------------------------------------------------
  // The dap_tr_done signal indicates the DAP transaction is completed either
  // because of the apb_tr_done from the APB master interface or because of the
  // dapabort on the DAP slave inteface.
  //----------------------------------------------------------------------------
  assign dap_tr_done = apb_tr_done | dapabort;

  //----------------------------------------------------------------------------
  // Logic for the DAP slave inteface state machine.
  // ST_DAPAPB_IDLE : Idle state for the state machine.Remains in this state
  //                  till a trigger is received.
  // ST_DAPAPB_REG  : Enters this state from the ST_DAPAPB_IDLE state when a
  //                  trigger is received because of a register access in the
  //                  APB-AP block.Moves out of this state to ST_DAPAPB_IDLE
  //                  state because the register accesses of the APB-AP block
  //                  are serviced in zero wait cycles.
  // ST_DAPAPB_REG :  Enters this state from the ST_DAPAPB_IDLE state when a
  //                  trigger is received because of a register access in the
  //                  APB domain.Waits in this state till a ready is received
  //                  from APB side or a dapabort is received on the DAP side.
  //                  Moves out of this state to ST_DAPAPB_RDY for driving the
  //                  dapready.
  // ST_DAPAPB_RDY :  Enters this state from the ST_DAPAPB_APB state.The
  //                  dapready is driven in this state and the state then moves
  //                  to ST_DAPAPB_IDLE.
  //----------------------------------------------------------------------------
  always @(apb_access or cur_state or dap_tr_done
           or reg_access or trig_sm)
    begin : p_nextstate
      case(cur_state)
        ST_DAPAPB_IDLE :
          begin
            case({reg_access,apb_access})
              2'b00   : next_state = ST_DAPAPB_IDLE;
              2'b01   : next_state = trig_sm ? ST_DAPAPB_APB : ST_DAPAPB_IDLE;
              2'b10   : next_state = trig_sm ? ST_DAPAPB_REG : ST_DAPAPB_IDLE;
              default : next_state = ST_DAPAPB_UNDEF;
            endcase
          end
        ST_DAPAPB_REG  :
              next_state = ST_DAPAPB_IDLE;
        ST_DAPAPB_APB  :
              next_state = dap_tr_done ? ST_DAPAPB_RDY : ST_DAPAPB_APB;
        ST_DAPAPB_RDY  :
              next_state = ST_DAPAPB_IDLE;
        default         :
              next_state = ST_DAPAPB_UNDEF;
      endcase
    end

  //----------------------------------------------------------------------------
  // Sequential block for cur_state of the DAP slave interface state machine.
  //----------------------------------------------------------------------------
  always @(posedge dapclk or negedge dapresetn)
    begin : p_curstate
      if (!dapresetn)
        cur_state <= ST_DAPAPB_IDLE;
      else
        if(dapclken)
          cur_state <= next_state;
    end

  //----------------------------------------------------------------------------
  // Combinational block for driving the next_dap_ready.The next_dap_ready is
  // driven low when the state machine is in the ST_DAPAPB_APB state.For all the
  // other states of the state machine the next_dap_ready is driven high.
  //----------------------------------------------------------------------------
  always @(next_state)
    begin : p_nextdaprdy
      case(next_state)
        ST_DAPAPB_IDLE : next_dap_ready = 1'b1;
        ST_DAPAPB_REG  : next_dap_ready = 1'b1;
        ST_DAPAPB_APB  : next_dap_ready = 1'b0;
        ST_DAPAPB_RDY  : next_dap_ready = 1'b1;
        default         : next_dap_ready = 1'bx;
      endcase
    end

  //----------------------------------------------------------------------------
  // Combinational logic for driving the next_dap_slv_err.The next_dap_slv_err is
  // driven high when an error response occurs on the APB interface or when
  // the apb_tr_in_prog is high and the DAP interface requests for a write transfer
  // to any register or a read transfer to the data read write register or the
  // banked data registers.For all the other conditions the next_dap_slv_err is
  // driven low.
  //----------------------------------------------------------------------------
  assign next_dap_slv_err = (apb_access   & (~device_en_sync | pslverr))         |
                         (((reg_access & dapwrite)  | (apb_access & ~dapabort)) &
                         apb_tr_in_prog  & ~apb_tr_done);

  //----------------------------------------------------------------------------
  // Sequential block for driving dapready from the APB-AP block.
  //----------------------------------------------------------------------------
  always @(posedge dapclk or negedge dapresetn)
    begin : p_dapready
      if (!dapresetn)
        dapready <= 1'b1;
      else
        if(dapclken)
          dapready <= next_dap_ready;
    end

  //----------------------------------------------------------------------------
  // Sequential block for driving dapslverr from the APB-AP block.
  //----------------------------------------------------------------------------
  always @(posedge dapclk or negedge dapresetn)
    begin : p_dapslverr
      if (!dapresetn)
        dapslverr <= 1'b1;
      else
        if(dapclken)
          dapslverr <= next_dap_slv_err;
    end

  //----------------------------------------------------------------------------
  // The apb_rd_wr signal will indicate the APB master to drive a write and read
  // transactions for high and low values respectively.
  //----------------------------------------------------------------------------
  assign apb_rd_wr = apb_access & dapsel & dapwrite;

  //----------------------------------------------------------------------------
  // The apb_tr_req is driven for one clock cycle of dapclk.This signal will
  // indicate the APB master interface to initiate an APB transacation.
  //----------------------------------------------------------------------------
  assign apb_tr_req_int = (next_state == ST_DAPAPB_APB) & (next_state != cur_state);
  assign apb_tr_req    = apb_tr_req_int;

  //----------------------------------------------------------------------------
  // The bd_access_en is the enable signal for bd_access.
  //----------------------------------------------------------------------------
  assign bd_access_en = ((apb_tr_req_int & bd_sel) | apb_tr_done) & dapclken;

  //----------------------------------------------------------------------------
  // bd_access indicates that the current transaction is initiated by the banked
  // data register access.This signal is used to sustain the AhbAddr driven onto
  // the AHB interface.When a dapabort is received,the address on the DAP side
  // will change and hence the address driven onto the AHB interface should not
  // change.
  //----------------------------------------------------------------------------
  always @ (posedge dapclk or negedge dapresetn)
    begin : p_bdreg
      if (!dapresetn)
        bd_access <= 1'b0;
      else
        if (bd_access_en)
          bd_access <= apb_tr_req_int;
    end

  //----------------------------------------------------------------------------
  // The bd_wr_en is the enable signal for writing into the banked data address
  // register.
  //----------------------------------------------------------------------------
  assign bd_wr_en = bd_sel & dapclken;

  //----------------------------------------------------------------------------
  // Sequential block for writing into the banked data address register.Only
  // the 3:2 bits of the dapaddr bus are latched as the AHB address for the
  // banked data register accesses are formed by the 31:4 bits of ta_reg and
  // the 3:0 bits of dapaddr bus.[1:0] bits of dapaddr shall be 2'b00 as the
  // word accesses are only performed on the banked data registers.
  //----------------------------------------------------------------------------
  always @ (posedge dapclk or negedge dapresetn)
    begin : p_bdaccess
      if (!dapresetn)
        bd_reg <= {2{1'b0}};
      else
        if (bd_wr_en)
          bd_reg <= dapaddr[3:2];
    end

  //----------------------------------------------------------------------------
  // The paddr_ap is the APB address to be driven by the APB master interface.The
  // address is driven from transfer address register when transfer address or
  // data read write registers is selected.Only the 3:2 bits of address are
  // driven from BdAddr in the case of the banked data registers.
  //----------------------------------------------------------------------------
  assign paddr_ap[29:2] = ta_reg[29:2];
  assign paddr_ap[1:0]  = bd_access ? bd_reg[1:0] : ta_reg[1:0];

  //----------------------------------------------------------------------------
  // Combinational block for driving the daprdata.The read data from the
  // APB master interface is read when the APB master interface drives the
  // apb_tr_done signal.The registers within the APB-AP block are read from their
  // corresponding read data buses.
  //----------------------------------------------------------------------------
  assign next_dap_rd_data = (
                            ({32{csw_sw_rd_en}} & csw_rd_data) |
                            ({32{ta_sw_rd_en}}  & ta_rd_data)  |
                            ({32{apb_sw_rd_en}} & prdata)    |
                            ({32{rom_sw_rd_en}} & rom_rd_data) |
                            ({32{id_sw_rd_en}}  & id_rd_data)
                           );

  //----------------------------------------------------------------------------
  // Sequential block for daprdata of the DAP slave interface.
  //----------------------------------------------------------------------------
  always @(posedge dapclk or negedge dapresetn)
    begin : p_prdata
      if (!dapresetn)
        daprdata <= {32{1'b0}};
      else
        if(dapclken)
          daprdata <= next_dap_rd_data;
    end

  //----------------------------------------------------------------------------
  // The pdbgswen is driven from the control status register.
  //----------------------------------------------------------------------------
  assign pdbgswen = pdbg;

  //----------------------------------------------------------------------------
  // Synchronizer for the deviceen signal.
  //----------------------------------------------------------------------------
  cx_cdc_corrupt_gry #(1) u_corrupt_deviceen
  (
    .clk      (dapclk),
    .resetn   (dapresetn),
    .sync     (1'b0),
    .d_async  (deviceen),
    .q_async  (deviceen_corrupt)
  );

  cx_en_sync u_sync_deviceen
  (
    .clk      (dapclk),
    .resetn   (dapresetn),
    .clken    (dapclken),
    .sync_di  (deviceen_corrupt),
    .sync_do  (device_en_sync)
  );

`ifdef ARM_ASSERT_ON
  //----------------------------------------------------------------------------
  // OVL Assertions
  //----------------------------------------------------------------------------
  reg    apb_tr_done_del;        // Delayed APB transfer done

  //----------------------------------------------------------------------------
  // Register transfer request for edge detection
  //----------------------------------------------------------------------------
  always @ (posedge dapclk or negedge dapresetn)
    if (!dapresetn)
      apb_tr_done_del <= 1'b0;
    else
      if(dapclken)
        apb_tr_done_del <= apb_tr_done;

  //----------------------------------------------------------------------------
  // apb_access and reg_access should not be high at the same time.
  //----------------------------------------------------------------------------
  assert_zero_one_hot #(`OVL_ERROR, 2, `OVL_ASSERT,
    "OVL Message : dapapbap_dapif - apb_access and reg_access at the same time")
      dapapbap_access
        (
         .clk         (dapclk),
         .reset_n     (dapresetn),
         .test_expr   ({reg_access,apb_access})
        );

  //----------------------------------------------------------------------------
  // auto_inc_en and reg_access should not be high at the same time.
  //----------------------------------------------------------------------------
  assert_zero_one_hot #(`OVL_ERROR, 2, `OVL_ASSERT,
    "OVL Message : dapapbap_dapif - auto_inc_en and reg_access at the same time")
      dapapbap_incen
        (
         .clk         (dapclk),
         .reset_n     (dapresetn),
         .test_expr   ({reg_access,auto_inc_en})
        );

  //----------------------------------------------------------------------------
  // apb_tr_done should be a single cycle pulse.
  //----------------------------------------------------------------------------
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
    "OVL Message : dapapbap_dapif - apb_tr_done is not a single cycle pulse")
      dapapbap_apbtrdone
        (
         .clk         (dapclk),
         .reset_n     (dapresetn),
         .test_expr   (apb_tr_done & apb_tr_done_del)
        );


  //----------------------------------------------------------------------------
  // ID register value check
  //----------------------------------------------------------------------------
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
    "OVL Message : dapapbap_dapif - The revision value is not 4")
      dapahbap_rev_value
        (
         .clk         (dapclk),
         .reset_n     (dapresetn),
         .test_expr   (id_rd_data[31:28] != 4'b0100)
        );

`endif

endmodule // cxdapapbap_dap_if
