//-----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2004-2015 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//    Checked In : $Date: 2014-08-14 16:01:35 +0100 (Thu, 14 Aug 2014) $
//    Revision   : $Revision: 39945 $
//    Release    : CoreSight-SoC-TM100-r3p2-00rel0
//-----------------------------------------------------------------------------
//  Purpose             : Trace Out block, accepts 32-bit data words and
//                       serialises the data for output sizes between 1 and 32
//                       bits. This is also the final register stage before data
//                       is sent out off-chip.
//-----------------------------------------------------------------------------

module cxtpiu_trace_out (
  // Inputs
  traceclkin, tresetn, trace_d_valid, trace_d, trig_port_sync,
  curr_port_sel_reg, trace_pattern, ft_stopped_sync,
  // Outputs
  tracedata, tracectl, trace_d_accepted
  );

`include "cxtpiu_constants.v"

  // ---------------------------------------------------------------------------
  // Inputs and Outputs
  // ---------------------------------------------------------------------------

  // Clock and Reset
  input           traceclkin;       // Trace clock
  input           tresetn;          // Trace asychronous reset active low

  // TraceOut Port
  output [31:0]   tracedata;        // Exported Data
  output          tracectl;         // Exported Control

  // Internal Data Interface
  //  This takes data from selector within the Sync block which is either data
  //  from the FIFO or a synchronisation packet.
  input           trace_d_valid;    // Data present from Trace Bridge
  input [31:0]    trace_d;          // Actual Data
  output          trace_d_accepted; // Ack for current packet

  // Control signals
  input           trig_port_sync;   // Indicate a trigger condition via tracectl
  input [31:0]    curr_port_sel_reg;// Selected Trace port size. (One Hot)
  input           trace_pattern;    // Force pass through for use with the
                                    //  pattern generator
  input           ft_stopped_sync;  // Indicates the Formatter has stopped
                                    // (reset buffer)

  // ---------------------------------------------------------------------------
  // Internal Signals
  // ---------------------------------------------------------------------------

  // Control for Triggers and Stall conditions
  wire            trace_stall;      // Indicate holdup from trigger or disable cycle
                                    //  (no more data)
  reg             tracectl;
  wire            nxt_trace_ctl;
  reg             trig_port_sync_reg;
  wire            trace_trigger;    // One shot pulse from trig_port

  wire            t_pattern_reg_en;
  reg             t_pattern_reg;    // Delayed version of trace_pattern input

  // Control for Buffer reset on Formatter Stop
  wire            ft_reset;         // Synchronous reset signal
  wire            masked_ft_stopped;// Masked version of ft_stopped_sync
  wire            ft_stop_state_en; // FSM Register Enable
  reg [1:0]       nxt_ft_stop_state;// FSM Next state
  reg [1:0]       ft_stop_state;    // FSM Current state


  // Pipeline tracking
  wire            output_hold; //Stall final stage

  // PortWidth Calculations
  wire [5:0]      rotate;           // Amount to increase the rotation by (eq Port Size)
  wire            rotate_en;        // Enable term for New/Curr rotate
  wire [5:0]      nxt_curr_rotate;  // next Current rotation amount
  wire [5:0]      new_rotate;       // rotation value for the next cycle
  reg [5:0]       curr_rotate;      // Current rotation amount
  wire [31:0]     port_bit_mask;    // All the bits set for the selected port width

  // Data Holding Banks
  wire            nxt_bank_update;
  wire            bank_update_en;   // change to the next bank
  reg             bank_update;      // Indicates which bank is allowed to update
  reg [31:0]      holding_bank_a;   // The data reg banks
  reg [31:0]      holding_bank_b;
  wire            update_bank_a;    // refresh signals (ie bank will be empty)
  wire            update_bank_b;
  wire            nxt_bank_a_empty;
  wire            nxt_bank_b_empty;
  reg             bank_a_empty;     // Bank is empty
  reg             bank_b_empty;

  // Bank Selector Control
  reg [31:0]      bank_sel;         // If the bit is set then BankA is being used
  wire [63:0]     bank_sel_part_a;  // partA rotates 32 or 0,
  wire [63:0]     bank_sel_part_b;  // partB rotates 16 or 0,
  wire [63:0]     bank_sel_part_c;  // partC rotates 8 or 0,
  wire [63:0]     bank_sel_part_d;  // partD rotates 4 or 0,
  wire [63:0]     bank_sel_part_e;  // partE rotates 2 or 0,
  wire [63:0]     bank_sel_part_f;  // partF rotates 1 or 0,
  reg             bank_a_required;  // High if there are any bank_sel for BankA
  reg             bank_b_required;  // High if there are any bank_sel for BankB
  wire            nxt_bank_a_req;
  wire            nxt_bank_b_req;
  wire [31:0]     nxt_bank_sel;
  wire            bank_mask_en;

  // Serialiser / Data Output
  wire [31:0]     nxt_trace_data;
  reg [31:0]      tracedata;        // The output register bank
  wire [31:0]     merged_bank;
  wire [31:0]     rot_data_part_a;  // partA rotates 16 or 0,
  wire [31:0]     rot_data_part_b;  // partB rotates 8 or 0,
  wire [31:0]     rot_data_part_c;  // partC rotates 4 or 0,
  wire [31:0]     rot_data_part_d;  // partD rotates 2 or 0,
  wire [31:0]     rot_data_part_e;  // partE rotates 1 or 0,

  // ---------------------------------------------------------------------------
  // Control for Triggers and Stall conditions
  // ---------------------------------------------------------------------------
  assign trace_trigger = trig_port_sync & ~trig_port_sync_reg;

  assign trace_stall = (trace_trigger & ~trace_pattern)  | // Trigger event
                      (bank_a_empty & bank_a_required)   | //FIFO Empty
                      (bank_b_empty & bank_b_required)   ; //FIFO Empty

  assign nxt_trace_ctl = trace_stall | output_hold; // add in pipelined hold

  // Exported tracectl register and Trigger watch register
  always @(posedge traceclkin or negedge tresetn)
    if (!tresetn)
      begin
        tracectl        <= 1'b1;
        trig_port_sync_reg <= 1'b0;
      end
    else
      begin
        tracectl        <= nxt_trace_ctl;
        trig_port_sync_reg <= trig_port_sync;
      end

  // trace_pattern holder to ensure that trace_pattern mode is not disabled until
  // the Banks are empty of patterns (which is one cycle after trace_pattern
  // goes LOW)
  assign t_pattern_reg_en = ( trace_pattern & ~t_pattern_reg) |
                         (~trace_pattern &  t_pattern_reg) ;

  always @(posedge traceclkin or negedge tresetn)
    if (!tresetn)
        t_pattern_reg <= 1'b0;
    else
      if (t_pattern_reg_en)
        t_pattern_reg <= trace_pattern;

  // ---------------------------------------------------------------------------
  // Pipeline tracking
  // ---------------------------------------------------------------------------
  // This is used to ensure that the system is primed for the first packet after
  // reset and flushes

  // output_hold - Stall final register
  assign output_hold = ~((|curr_rotate[5:0]) | (|new_rotate[5:0]));

  // ---------------------------------------------------------------------------
  // Buffer Reset Control on Formatter Stop
  // The ft_reset signal controls the resetting of all the registers and
  // counters at the end of a trace session. ft_reset is triggered once
  // every time the Formatter is stopped, and always waits in case there
  // is a Trace valid awaiting to be output either on the TraceOut Interface
  // or inside the block itself.
  // The state machine that generated ft_reset has the following states:
  // - CSTPIU_FTSTOP_IDLE: Idle state
  // - CSTPIU_FTSTOP_RPEND: A block reset is pending, and should wait until
  //   the block has output all relevant data.
  // - CSTPIU_FTSTOP_RHOLD: A reset has been triggered for the current
  //   Formatter stop event, no further resets are necessary until the
  //   Formatter is re-stopped.
  // - CSTPIU_FTSTOP_UNUSED: Should never be reached. Checked by assertion
  //
  // Note that a pending Reset can be cancelled if the formatter is restarted
  // before all relevant data has been output. This implies that the FSM
  // can return from CSTPIU_FTSTOP_RPEND to CSTPIU_FTSTOP_IDLE.
  // Also note that an immediate reset can be forced from the idle state
  // if there is no data left to be output, saving one state transition and
  // improving the speed of the reset.
  // ---------------------------------------------------------------------------


  assign    masked_ft_stopped = ft_stopped_sync & ~trace_d_valid;
  assign    ft_stop_state_en = ft_stop_state != nxt_ft_stop_state;

  always @(ft_stop_state or ft_stopped_sync
           or masked_ft_stopped or trace_stall)
    begin
      case(ft_stop_state)
        CXTPIU_FTSTOP_IDLE:
          begin
            if (masked_ft_stopped)
              nxt_ft_stop_state = trace_stall ? CXTPIU_FTSTOP_RHOLD :
                                            CXTPIU_FTSTOP_RPEND;
            else
              nxt_ft_stop_state = CXTPIU_FTSTOP_IDLE;
          end
        CXTPIU_FTSTOP_RPEND:
          begin
            if (trace_stall)
              nxt_ft_stop_state = ft_stopped_sync ? CXTPIU_FTSTOP_RHOLD :
                                               CXTPIU_FTSTOP_IDLE;
            else
              nxt_ft_stop_state = CXTPIU_FTSTOP_RPEND;
          end
        CXTPIU_FTSTOP_RHOLD:
          nxt_ft_stop_state = ft_stopped_sync ? CXTPIU_FTSTOP_RHOLD :
                                           CXTPIU_FTSTOP_IDLE;
        CXTPIU_FTSTOP_UNUSED:
          nxt_ft_stop_state = CXTPIU_FTSTOP_IDLE;
        default:
          nxt_ft_stop_state = 2'bx;
      endcase
    end // always @ (...


  assign ft_reset = (((ft_stop_state == CXTPIU_FTSTOP_IDLE) &
                     (nxt_ft_stop_state == CXTPIU_FTSTOP_RHOLD)) |
                    ((ft_stop_state == CXTPIU_FTSTOP_RPEND) &
                     (nxt_ft_stop_state == CXTPIU_FTSTOP_RHOLD)));

  always @(posedge traceclkin or negedge tresetn)
    begin
    if (!tresetn)
      ft_stop_state <= CXTPIU_FTSTOP_IDLE;
    else if (ft_stop_state_en)
      ft_stop_state <= nxt_ft_stop_state;
    end

  // ---------------------------------------------------------------------------
  // PortWidth Calculations
  // ---------------------------------------------------------------------------

  assign rotate = ( ({6{curr_port_sel_reg[31]}} & 6'b100000 ) |
                    ({6{curr_port_sel_reg[30]}} & 6'b011111 ) |
                    ({6{curr_port_sel_reg[29]}} & 6'b011110 ) |
                    ({6{curr_port_sel_reg[28]}} & 6'b011101 ) |
                    ({6{curr_port_sel_reg[27]}} & 6'b011100 ) |
                    ({6{curr_port_sel_reg[26]}} & 6'b011011 ) |
                    ({6{curr_port_sel_reg[25]}} & 6'b011010 ) |
                    ({6{curr_port_sel_reg[24]}} & 6'b011001 ) |
                    ({6{curr_port_sel_reg[23]}} & 6'b011000 ) |
                    ({6{curr_port_sel_reg[22]}} & 6'b010111 ) |
                    ({6{curr_port_sel_reg[21]}} & 6'b010110 ) |
                    ({6{curr_port_sel_reg[20]}} & 6'b010101 ) |
                    ({6{curr_port_sel_reg[19]}} & 6'b010100 ) |
                    ({6{curr_port_sel_reg[18]}} & 6'b010011 ) |
                    ({6{curr_port_sel_reg[17]}} & 6'b010010 ) |
                    ({6{curr_port_sel_reg[16]}} & 6'b010001 ) |
                    ({6{curr_port_sel_reg[15]}} & 6'b010000 ) |
                    ({6{curr_port_sel_reg[14]}} & 6'b001111 ) |
                    ({6{curr_port_sel_reg[13]}} & 6'b001110 ) |
                    ({6{curr_port_sel_reg[12]}} & 6'b001101 ) |
                    ({6{curr_port_sel_reg[11]}} & 6'b001100 ) |
                    ({6{curr_port_sel_reg[10]}} & 6'b001011 ) |
                    ({6{curr_port_sel_reg[9]}}  & 6'b001010 ) |
                    ({6{curr_port_sel_reg[8]}}  & 6'b001001 ) |
                    ({6{curr_port_sel_reg[7]}}  & 6'b001000 ) |
                    ({6{curr_port_sel_reg[6]}}  & 6'b000111 ) |
                    ({6{curr_port_sel_reg[5]}}  & 6'b000110 ) |
                    ({6{curr_port_sel_reg[4]}}  & 6'b000101 ) |
                    ({6{curr_port_sel_reg[3]}}  & 6'b000100 ) |
                    ({6{curr_port_sel_reg[2]}}  & 6'b000011 ) |
                    ({6{curr_port_sel_reg[1]}}  & 6'b000010 ) |
                    ({6{curr_port_sel_reg[0]}}  & 6'b000001 ));

  assign rotate_en = ~trace_stall | ft_reset; // trace_stall can be high from
                                           // indicating triggers or idle cycles
  assign nxt_curr_rotate = ft_reset ? 6'b0 : new_rotate;

  // rotation for the serialiser
  always @ (posedge traceclkin or negedge tresetn)
    if (!tresetn)
      curr_rotate   <= 6'b000000;
    else
      if (rotate_en)
        curr_rotate <= nxt_curr_rotate;

  assign new_rotate = t_pattern_reg ? curr_rotate + 6'b100000 :
                                   {1'b1, {5{~trace_pattern}}} & (curr_rotate + rotate);

  // port_bit_mask Calculation
  assign port_bit_mask = { curr_port_sel_reg[31],        // 32 Bit Port
                         (| curr_port_sel_reg[31:30]), // 31 Bit Port
                         (| curr_port_sel_reg[31:29]), // 30 Bit Port
                         (| curr_port_sel_reg[31:28]), // 29 Bit Port
                         (| curr_port_sel_reg[31:27]), // 28 Bit Port
                         (| curr_port_sel_reg[31:26]), // 27 Bit Port
                         (| curr_port_sel_reg[31:25]), // 26 Bit Port
                         (| curr_port_sel_reg[31:24]), // 25 Bit Port
                         (| curr_port_sel_reg[31:23]), // 24 Bit Port
                         (| curr_port_sel_reg[31:22]), // 23 Bit Port
                         (| curr_port_sel_reg[31:21]), // 22 Bit Port
                         (| curr_port_sel_reg[31:20]), // 21 Bit Port
                         (| curr_port_sel_reg[31:19]), // 20 Bit Port
                         (| curr_port_sel_reg[31:18]), // 19 Bit Port
                         (| curr_port_sel_reg[31:17]), // 18 Bit Port
                         (| curr_port_sel_reg[31:16]), // 17 Bit Port
                         (| curr_port_sel_reg[31:15]), // 16 Bit Port
                         (| curr_port_sel_reg[31:14]), // 15 Bit Port
                         (| curr_port_sel_reg[31:13]), // 14 Bit Port
                         (| curr_port_sel_reg[31:12]), // 13 Bit Port
                         (| curr_port_sel_reg[31:11]), // 12 Bit Port
                         (| curr_port_sel_reg[31:10]), // 11 Bit Port
                         (| curr_port_sel_reg[31: 9]), // 10 Bit Port
                         (| curr_port_sel_reg[31: 8]), // 9  Bit Port
                         (| curr_port_sel_reg[31: 7]), // 8  Bit Port
                         (| curr_port_sel_reg[31: 6]), // 7  Bit Port
                         (| curr_port_sel_reg[31: 5]), // 6  Bit Port
                         (| curr_port_sel_reg[31: 4]), // 5  Bit Port
                         (| curr_port_sel_reg[31: 3]), // 4  Bit Port
                         (| curr_port_sel_reg[31: 2]), // 3  Bit Port
                         (| curr_port_sel_reg[31: 1]), // 2  Bit Port
                         (  1'b1                 )};// 1  Bit Port     - At least one bit in this
//                         (| curr_port_sel_reg[31: 0]) }; // 1  Bit Port - reg should be set by tools

  // ---------------------------------------------------------------------------
  // Data Holding Banks
  // ---------------------------------------------------------------------------
  // Two 32-bit banks hold the data for the rotate stage, as one bank is being
  // output the other can be refreshed
  // Bank#A is the lower bank and is used first; Bank#B is the secondary bank.

  // Update a bank when:
  // (a) in the next cycle the rotate will be operating within the other bank
  //      and that this cycle the last bit of information from this cycle is
  //      being taken and it hasn't stalled.
  // or (b) the bank is empty
  // or (c) the formatter has stopped working
  // or (d) the Pattern Generator is being used (assumes a 32-bit trace port)

  //Cycle between filling bank A then bank B, this is to stop A filling before B
  // when both are empty but data is going to be taken from B before A
  assign nxt_bank_update = ~bank_update & ~ft_reset; // 0 == Bank A, 1 == Bank B
  assign bank_update_en = (ft_reset |
                         ((update_bank_a | update_bank_b) & trace_d_valid));

  // Track which bank has been emptied
  always @(posedge traceclkin or negedge tresetn)
    if (!tresetn)
      bank_update <= 1'b0;
    else
      if (bank_update_en)
        bank_update <= nxt_bank_update;

  assign update_bank_a = ((ft_reset    | // c
                         bank_a_empty | // b
                         (~trace_stall & ~curr_rotate[5] &  new_rotate[5]) | // a
                         (~bank_update & trace_pattern) )); // d

  assign update_bank_b = ((ft_reset    | // c
                         bank_b_empty | // b
                         (~trace_stall &  curr_rotate[5] & ~new_rotate[5]) | // a
                         (bank_update & trace_pattern) )); // d

  wire [31:0] nxt_holding_bank_a;
  wire [31:0] nxt_holding_bank_b;

  assign nxt_holding_bank_a = ft_reset ? 32'b0 : trace_d;
  assign nxt_holding_bank_b = ft_reset ? 32'b0 : trace_d;

  // Data value held (Bank#A)
  always @(posedge traceclkin)
    if (update_bank_a)
      holding_bank_a <= nxt_holding_bank_a;

  // Data value held (Bank#B)
  always @(posedge traceclkin)
    if (update_bank_b)
      holding_bank_b <= nxt_holding_bank_b;

  // The bank becomes empty at Reset and when the Bank is updating (either
  // already empty or from rotation), this will not clear the emptyness unless
  // this bank is allowed to update and there is valid data for it.
  //  - UpdateBank<x> takes into account bank being empty and bank (potentially)
  //    becoming empty
  //  - Second term covers:
  //         Other bank updating OR
  //         This bank is updating and no new data

  assign nxt_bank_a_empty = update_bank_a & (bank_update |
                                        (~bank_update & ~trace_d_valid));
  assign nxt_bank_b_empty = update_bank_b & (~bank_update |
                                        (bank_update & ~trace_d_valid));

  // Control flags for the two data holding banks
  always @(posedge traceclkin or negedge tresetn)
    if (!tresetn)
      begin
        bank_a_empty <= 1'b1;
        bank_b_empty <= 1'b1;
      end
    else
      begin
        bank_a_empty <= nxt_bank_a_empty;
        bank_b_empty <= nxt_bank_b_empty;
      end

  // If either bank A or B updates, then return an accepted response.
  assign trace_d_accepted = (update_bank_a | update_bank_b) & ~ft_reset;

  // ---------------------------------------------------------------------------
  // Bank Selector Control
  // ---------------------------------------------------------------------------
  // This uses a 64-bit rotate to establish if Bank A or B is required.
  // The increasing rotation value is used to establish which bits are being
  // examined in the next cycle.

  assign bank_sel_part_a = (new_rotate[5] ?
                         {port_bit_mask, {32{1'b0}}}
                         : {{32{1'b0}}, port_bit_mask} );
  assign bank_sel_part_b = (new_rotate[4] ?
                         {bank_sel_part_a[47:0], bank_sel_part_a[63:48]}
                         : bank_sel_part_a[63:0]);
  assign bank_sel_part_c = (new_rotate[3] ?
                         {bank_sel_part_b[55:0], bank_sel_part_b[63:56]}
                         : bank_sel_part_b[63:0]);
  assign bank_sel_part_d = (new_rotate[2] ?
                         {bank_sel_part_c[59:0], bank_sel_part_c[63:60]}
                         : bank_sel_part_c[63:0]);
  assign bank_sel_part_e = (new_rotate[1] ?
                         {bank_sel_part_d[61:0], bank_sel_part_d[63:62]}
                         : bank_sel_part_d[63:0]);
  assign bank_sel_part_f = (new_rotate[0] ?
                         {bank_sel_part_e[62:0], bank_sel_part_e[63]}
                         : bank_sel_part_e[63:0]);

  assign nxt_bank_a_req = (|(bank_sel_part_f[31:0])) | ft_reset;
  assign nxt_bank_b_req = ft_reset ? 1'b0 : |(bank_sel_part_f[63:32]);
  assign bank_mask_en  = ~trace_stall | ft_reset;
  assign nxt_bank_sel  = ft_reset ? {32{1'b0}} : bank_sel_part_f[31:0];

  // Establish the required bank and bits
  always @(posedge traceclkin or negedge tresetn)
    if (!tresetn)
      begin
        bank_sel       <= {32{1'b0}};
        bank_a_required <= 1'b1;
        bank_b_required <= 1'b0;
      end
    else
      if (bank_mask_en)
      begin
        bank_sel       <= nxt_bank_sel;
        bank_a_required <= nxt_bank_a_req;
        bank_b_required <= nxt_bank_b_req;
      end

  // ---------------------------------------------------------------------------
  // Serialiser
  // ---------------------------------------------------------------------------
  // This is a 64-32 rotate that increases at a rate determined by the output
  // port width.
  // The system is broken down to 2 stages; Stage 1 performs a mux between the
  // two register banks (#A and #B), Stage 2 is a 32 bit rotate
  // NB This is all bypassed when using training patterns

  // Stage 1: Bank Mux
  // Select Bank#B bits when the curr_rotate value is greater than the equivalent
  // bank#A location
  assign merged_bank[31] = bank_sel[31] ? holding_bank_a[31]: holding_bank_b[31];
  assign merged_bank[30] = bank_sel[30] ? holding_bank_a[30]: holding_bank_b[30];
  assign merged_bank[29] = bank_sel[29] ? holding_bank_a[29]: holding_bank_b[29];
  assign merged_bank[28] = bank_sel[28] ? holding_bank_a[28]: holding_bank_b[28];
  assign merged_bank[27] = bank_sel[27] ? holding_bank_a[27]: holding_bank_b[27];
  assign merged_bank[26] = bank_sel[26] ? holding_bank_a[26]: holding_bank_b[26];
  assign merged_bank[25] = bank_sel[25] ? holding_bank_a[25]: holding_bank_b[25];
  assign merged_bank[24] = bank_sel[24] ? holding_bank_a[24]: holding_bank_b[24];
  assign merged_bank[23] = bank_sel[23] ? holding_bank_a[23]: holding_bank_b[23];
  assign merged_bank[22] = bank_sel[22] ? holding_bank_a[22]: holding_bank_b[22];
  assign merged_bank[21] = bank_sel[21] ? holding_bank_a[21]: holding_bank_b[21];
  assign merged_bank[20] = bank_sel[20] ? holding_bank_a[20]: holding_bank_b[20];
  assign merged_bank[19] = bank_sel[19] ? holding_bank_a[19]: holding_bank_b[19];
  assign merged_bank[18] = bank_sel[18] ? holding_bank_a[18]: holding_bank_b[18];
  assign merged_bank[17] = bank_sel[17] ? holding_bank_a[17]: holding_bank_b[17];
  assign merged_bank[16] = bank_sel[16] ? holding_bank_a[16]: holding_bank_b[16];
  assign merged_bank[15] = bank_sel[15] ? holding_bank_a[15]: holding_bank_b[15];
  assign merged_bank[14] = bank_sel[14] ? holding_bank_a[14]: holding_bank_b[14];
  assign merged_bank[13] = bank_sel[13] ? holding_bank_a[13]: holding_bank_b[13];
  assign merged_bank[12] = bank_sel[12] ? holding_bank_a[12]: holding_bank_b[12];
  assign merged_bank[11] = bank_sel[11] ? holding_bank_a[11]: holding_bank_b[11];
  assign merged_bank[10] = bank_sel[10] ? holding_bank_a[10]: holding_bank_b[10];
  assign merged_bank[9]  = bank_sel[9]  ? holding_bank_a[9] : holding_bank_b[9];
  assign merged_bank[8]  = bank_sel[8]  ? holding_bank_a[8] : holding_bank_b[8];
  assign merged_bank[7]  = bank_sel[7]  ? holding_bank_a[7] : holding_bank_b[7];
  assign merged_bank[6]  = bank_sel[6]  ? holding_bank_a[6] : holding_bank_b[6];
  assign merged_bank[5]  = bank_sel[5]  ? holding_bank_a[5] : holding_bank_b[5];
  assign merged_bank[4]  = bank_sel[4]  ? holding_bank_a[4] : holding_bank_b[4];
  assign merged_bank[3]  = bank_sel[3]  ? holding_bank_a[3] : holding_bank_b[3];
  assign merged_bank[2]  = bank_sel[2]  ? holding_bank_a[2] : holding_bank_b[2];
  assign merged_bank[1]  = bank_sel[1]  ? holding_bank_a[1] : holding_bank_b[1];
  assign merged_bank[0]  = bank_sel[0]  ? holding_bank_a[0] : holding_bank_b[0];

  // Stage 2: 32-bit rotate
  // partA rotates 16 or 0,
  assign rot_data_part_a = (curr_rotate[4] & ~t_pattern_reg ?
                         {merged_bank[15:0], merged_bank[31:16]}
                         : merged_bank[31:0]);
  // partB rotates 8 or 0,
  assign rot_data_part_b = (curr_rotate[3] & ~t_pattern_reg ?
                         {rot_data_part_a[7:0], rot_data_part_a[31:8]}
                         : rot_data_part_a[31:0]);
  // partC rotates 4 or 0,
  assign rot_data_part_c = (curr_rotate[2] & ~t_pattern_reg ?
                         {rot_data_part_b[3:0], rot_data_part_b[31:4]}
                         : rot_data_part_b[31:0]);
  // partD rotates 2 or 0,
  assign rot_data_part_d = (curr_rotate[1] & ~t_pattern_reg ?
                         {rot_data_part_c[1:0], rot_data_part_c[31:2]}
                         : rot_data_part_c[31:0]);
  // partE rotates 1 or 0,
  assign rot_data_part_e = (curr_rotate[0] & ~t_pattern_reg ?
                         {rot_data_part_d[0], rot_data_part_d[31:1]}
                         : rot_data_part_d[31:0]);

  // Mask off data if there is a stall this cycle
  assign nxt_trace_data = ({32{~nxt_trace_ctl}} & rot_data_part_e[31:0] & port_bit_mask)|
                        { {30{1'b0}},
                          (trace_trigger & ~t_pattern_reg),
                          ((trace_stall | output_hold) & ~trace_trigger) };

  // Final Register stage
  always @(posedge traceclkin or negedge tresetn)
    if (!tresetn)
      tracedata <= {{31{1'b0}}, 1'b1};
    else
      tracedata <= nxt_trace_data;

`ifdef ARM_ASSERT_ON
  assert_never #(`OVL_ERROR, `OVL_ASSUME, "CSTPIU_FTSTOP_UNUSED state reached by state machine")
     u_ft_stop_state_unused (traceclkin, tresetn,
                         (ft_stop_state == CXTPIU_FTSTOP_UNUSED));
`endif


endmodule // cxtpiu_trace_out
