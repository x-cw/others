module apb1to2(
        //m0:12'h000~12'h7ff
        //m1:12'h800~12'hfff
        input  [11:0] paddrs,
        input         psels,
        input         penables,
        input         pwrites,
        output [31:0] prdatas,
        input  [31:0] pwdatas,
        output        preadys,
        output        pslverrs,

        output  [11:0] paddrm0,
        output         pselm0,
        output         penablem0,
        output         pwritem0,
        input   [31:0] prdatam0,
        output  [31:0] pwdatam0,
        input          preadym0,
        input          pslverrm0,

        output  [11:0] paddrm1,
        output         pselm1,
        output         penablem1,
        output         pwritem1,
        input   [31:0] prdatam1,
        output  [31:0] pwdatam1,
        input          preadym1,
        input          pslverrm1
        );

        assign paddrm0   = (psels & !paddrs[11]) ? paddrs[11:0] : 12'h0;
        assign pselm0    = (psels & !paddrs[11]) ? psels : 1'h0;
        assign penablem0 = (psels & !paddrs[11]) ? penables : 1'h0;
        assign pwritem0  = (psels & !paddrs[11]) ? pwrites : 1'h0;
        assign pwdatam0  = (psels & !paddrs[11]) ? pwdatas : 32'h0;

        assign paddrm1   = (psels & paddrs[11]) ? paddrs[11:0] : 12'h0;
        assign pselm1    = (psels & paddrs[11]) ? psels : 1'h0;
        assign penablem1 = (psels & paddrs[11]) ? penables : 1'h0;
        assign pwritem1  = (psels & paddrs[11]) ? pwrites : 1'h0;
        assign pwdatam1  = (psels & paddrs[11]) ? pwdatas : 32'h0;

        //assign prdatas  = prdatam0  || prdatam1;
        //assign preadys  = preadym0  || preadym1;
        //assign pslverrs = pslverrm0 || pslverrm1;
        assign prdatas  = (psels & !paddrs[11]) ? prdatam0  : prdatam1;
        assign preadys  = (psels & !paddrs[11]) ? preadym0  : preadym1;
        assign pslverrs = (psels & !paddrs[11]) ? pslverrm0 : pslverrm1;

endmodule
