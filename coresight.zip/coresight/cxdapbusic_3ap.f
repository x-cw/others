+incdir+$GP3_RTL/coresight/rtl/coresight_component/debug_module/cxdapbusic_3ap
$GP3_RTL/coresight/rtl/coresight_component/debug_module/cxdapbusic_3ap/verilog/cxdapbusic_decoder_3ap.v
$GP3_RTL/coresight/rtl/coresight_component/debug_module/cxdapbusic_3ap/verilog/cxdapbusic_mux_3ap.v
$GP3_RTL/coresight/rtl/coresight_component/debug_module/cxdapbusic_3ap/verilog/cxdapbusic_3ap.v
