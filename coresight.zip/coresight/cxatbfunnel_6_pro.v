//-----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2003-2015 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//  Version and Release Control Information:
//
//  File Name           : cxatbfunnel_xmlcfg.v.xsl
//
//  Checked In          : $Date: 2015-02-16 14:55:41 +0000 (Mon, 16 Feb 2015) $
//
//  File Revision       : $Revision: 41661 $
//
//  Release Information : CoreSight-SoC-TM100-r3p2-00rel0
//-----------------------------------------------------------------------------


//-----------------------------------------------------------------------------
// Abstract : CoreSight  Trace Funnel (cxatbfunnel) - Top Level Block
//-----------------------------------------------------------------------------
//
// cxatbfunnel - CoreSight  Trace Funnel
// -------------------------------------
//
// CoreSight AMBA Trace Bus (ATB) trace link device used to combine multiple
// trace sources into a single bus.
//
// cxatbfunnel.v
// ----------
//
// cxatbfunnel.v provides the instantiations of all modules for the cxatbfunnel.
//
// Instantiated blocks
// -------------------
//
// cxatbfunnel_apb_if.v  - APB Interface Module
// cxatbfunnel_reg_blk.v - Register Module
// cxatbfunnel_arbiter.v - Arbiter Logic Module
//-----------------------------------------------------------------------------




module cxatbfunnel_6_pro  (
  // Inputs
  input wire         clk,
  input wire         resetn,

  input wire         pclkendbg,
  input wire         pseldbg,
  input wire         penabledbg,
  input wire         pwritedbg,
  input wire         paddrdbg31,
  input wire [11:2]  paddrdbg,
  input wire [31:0]  pwdatadbg,
  input wire         atvalids0,
  input wire         afreadys0,
  input wire [6:0]   atids0,
  input wire [128-1:0] atdatas0,
  
  input wire [3:0]   atbytess0,
  input wire         atvalids1,
  input wire         afreadys1,
  input wire [6:0]   atids1,
  input wire [128-1:0] atdatas1,
  
  input wire [3:0]   atbytess1,
  input wire         atvalids2,
  input wire         afreadys2,
  input wire [6:0]   atids2,
  input wire [128-1:0] atdatas2,
  
  input wire [3:0]   atbytess2,
  input wire         atvalids3,
  input wire         afreadys3,
  input wire [6:0]   atids3,
  input wire [128-1:0] atdatas3,
  
  input wire [3:0]   atbytess3,
  input wire         atvalids4,
  input wire         afreadys4,
  input wire [6:0]   atids4,
  input wire [128-1:0] atdatas4,
  
  input wire [3:0]   atbytess4,
  input wire         atvalids5,
  input wire         afreadys5,
  input wire [6:0]   atids5,
  input wire [128-1:0] atdatas5,
  
  input wire [3:0]   atbytess5,

  // ATB Master signals
  input wire         atreadym,
  input wire         afvalidm,
  input wire         syncreqm,
  // Outputs

  output wire        preadydbg,
  output wire        pslverrdbg,
  output wire [31:0] prdatadbg,
  output wire        atvalidm,
  output wire        afreadym,
  output wire [6:0]  atidm,
  output wire [128-1:0] atdatam,

  output [3:0]       atbytesm,
  output wire        atreadys2,
  output wire        afvalids2,
  output wire        syncreqs2,

  output wire        atreadys3,
  output wire        afvalids3,
  output wire        syncreqs3,

  output wire        atreadys4,
  output wire        afvalids4,
  output wire        syncreqs4,

  output wire        atreadys5,
  output wire        afvalids5,
  output wire        syncreqs5,

  output wire        atreadys0,
  output wire        afvalids0,
  output wire        syncreqs0,
  output wire        atreadys1,
  output wire        afvalids1,
  output wire        syncreqs1
  );

//------------------------------------------------------------------------------
// Local param definitions
//------------------------------------------------------------------------------

  localparam CXFUNNEL_ATB_DATA_WIDTH = 128; // Width of the ATB databus
                                          // Valid values: 32, 64 and 128
  localparam CXFUNNEL_ATBYTES_WIDTH =
  
             4;

  localparam CXFUNNEL_FIXED_CONFIGURATION =  0;
  localparam CXFUNNEL_NUMBER_OF_ATB_SLAVES =  6;
  localparam CXFUNNEL_FIXED_CONFIG_HOLD_TIME = 4'b0011;


//------------------------------------------------------------------------------
// Wires
//------------------------------------------------------------------------------

  wire                  en_port_0;
  wire [2:0]            pri_port_0;

  wire                  en_port_1;
  wire [2:0]            pri_port_1;

  wire                  en_port_2;
  wire [2:0]            pri_port_2;

  wire                  en_port_3;
  wire [2:0]            pri_port_3;

  wire                  en_port_4;
  wire [2:0]            pri_port_4;

  wire                  en_port_5;
  wire [2:0]            pri_port_5;

  wire [3:0]            min_hold_time;


  wire                  itc_reg;
  wire [31:0]           read_data;
  wire [9:0]            reg_addr;
  wire                  reg_read;
  wire                  reg_write;
  wire [31:0]           write_data;
  wire [16:0]      it_atb_data_0_wr_reg;
  wire [1:0]      it_atb_ctr_2_wr_reg;
  wire [6:0]      it_atb_ctr_1_wr_reg;
  wire [CXFUNNEL_ATBYTES_WIDTH+1:0]      it_atb_ctr_0_wr_reg;
  
  wire [16:0]      it_atb_data_0_rd_reg;
  wire [1:0]      it_atb_ctr_2_rd_reg;
  wire [6:0]      it_atb_ctr_1_rd_reg;
  wire [CXFUNNEL_ATBYTES_WIDTH+1:0]      it_atb_ctr_0_rd_reg;

  assign pslverrdbg =1'b0;
      //-----------------------------------------------------------------------
      // Debug APB Interface Module.
      // This module interfaces between the APB bus and the register module.
      //-----------------------------------------------------------------------
      cxatbfunnel_apb_if_6_pro u_cxatbfunnel_apb_if
        (
        // Inputs
        .clk                               (clk),
        .pclkendbg                         (pclkendbg),
        .resetn                            (resetn),
        .pseldbg                           (pseldbg),
        .penabledbg                        (penabledbg),
        .pwritedbg                         (pwritedbg),
        .paddrdbg                          (paddrdbg),
        .pwdatadbg                         (pwdatadbg),
        .read_data                         (read_data),

        // Outputs
        .preadydbg                         (preadydbg),
        .prdatadbg                         (prdatadbg),
        .reg_write                         (reg_write),
        .reg_read                          (reg_read),
        .reg_addr                          (reg_addr),
        .write_data                        (write_data));

      //-----------------------------------------------------------------------
      // Register Module.
      // This module contains the Funnel registers.
      //-----------------------------------------------------------------------
      cxatbfunnel_reg_blk_6_pro
        #(.CXFUNNEL_FIXED_CONFIG_HOLD_TIME   (CXFUNNEL_FIXED_CONFIG_HOLD_TIME),
          .CXFUNNEL_ATB_DATA_WIDTH           (CXFUNNEL_ATB_DATA_WIDTH),
          .CXFUNNEL_ATBYTES_WIDTH            (CXFUNNEL_ATBYTES_WIDTH))
      u_cxatbfunnel_reg_blk
        (
        // Inputs
        .clk                                (clk),
        .pclkendbg                          (pclkendbg),
        .resetn                             (resetn),
        .paddrdbg31                         (paddrdbg31),
        .reg_write                          (reg_write),
        .reg_read                           (reg_read),
        .reg_addr                           (reg_addr),
        .it_atb_data_0_wr_reg               (it_atb_data_0_wr_reg),
        .it_atb_ctr_2_wr_reg                (it_atb_ctr_2_wr_reg),
        .it_atb_ctr_1_wr_reg                (it_atb_ctr_1_wr_reg),
        .it_atb_ctr_0_wr_reg                (it_atb_ctr_0_wr_reg),
        .write_data                         (write_data),

        .atvalids0                          (atvalids0),
        .atreadys0                          (atreadys0),
        .afvalids0                          (afvalids0),

        .atvalids1                          (atvalids1),
        .atreadys1                          (atreadys1),
        .afvalids1                          (afvalids1),

        .atvalids2                          (atvalids2),
        .atreadys2                          (atreadys2),
        .afvalids2                          (afvalids2),

        .atvalids3                          (atvalids3),
        .atreadys3                          (atreadys3),
        .afvalids3                          (afvalids3),

        .atvalids4                          (atvalids4),
        .atreadys4                          (atreadys4),
        .afvalids4                          (afvalids4),

        .atvalids5                          (atvalids5),
        .atreadys5                          (atreadys5),
        .afvalids5                          (afvalids5),


        // Outputs
        .it_atb_data_0_rd_reg               (it_atb_data_0_rd_reg),
        .it_atb_ctr_2_rd_reg                (it_atb_ctr_2_rd_reg),
        .it_atb_ctr_1_rd_reg                (it_atb_ctr_1_rd_reg),
        .it_atb_ctr_0_rd_reg                (it_atb_ctr_0_rd_reg),
        .read_data                          (read_data),

        .en_port_0                          (en_port_0),
        .pri_port_0                         (pri_port_0),

        .en_port_1                          (en_port_1),
        .pri_port_1                         (pri_port_1),

        .en_port_2                          (en_port_2),
        .pri_port_2                         (pri_port_2),

        .en_port_3                          (en_port_3),
        .pri_port_3                         (pri_port_3),

        .en_port_4                          (en_port_4),
        .pri_port_4                         (pri_port_4),

        .en_port_5                          (en_port_5),
        .pri_port_5                         (pri_port_5),

        .itc_reg                            (itc_reg),
        .min_hold_time                      (min_hold_time));
  //---------------------------------------------------------------------------
  // Funnel Arbiter Module.
  // This module arbitarates among the different slave ports.
  //---------------------------------------------------------------------------
  cxatbfunnel_arbiter_6_pro
    #(
     .CXFUNNEL_ATB_DATA_WIDTH           (CXFUNNEL_ATB_DATA_WIDTH),
     .CXFUNNEL_ATBYTES_WIDTH            (CXFUNNEL_ATBYTES_WIDTH))
    u_cxatbfunnel_arbiter
     (
     // Inputs
     .clk                               (clk),
     .resetn                            (resetn),
     .atreadym                          (atreadym),
     .afvalidm                          (afvalidm),
     .syncreqm                          (syncreqm),
     .atvalids0                         (atvalids0),
     .afreadys0                         (afreadys0),
     .atids0                            (atids0),
     .atdatas0                          (atdatas0),
     .atbytess0                         (atbytess0),
     .atvalids1                         (atvalids1),
     .afreadys1                         (afreadys1),
     .atids1                            (atids1),
     .atdatas1                          (atdatas1),
     .atbytess1                         (atbytess1),
     
     .atvalids2                         (atvalids2),
     .afreadys2                         (afreadys2),
     .atids2                            (atids2),
     .atdatas2                          (atdatas2),
     .atbytess2                         (atbytess2),
     
     .atvalids3                         (atvalids3),
     .afreadys3                         (afreadys3),
     .atids3                            (atids3),
     .atdatas3                          (atdatas3),
     .atbytess3                         (atbytess3),
     
     .atvalids4                         (atvalids4),
     .afreadys4                         (afreadys4),
     .atids4                            (atids4),
     .atdatas4                          (atdatas4),
     .atbytess4                         (atbytess4),
     
     .atvalids5                         (atvalids5),
     .afreadys5                         (afreadys5),
     .atids5                            (atids5),
     .atdatas5                          (atdatas5),
     .atbytess5                         (atbytess5),
     
     .min_hold_time                     (min_hold_time),
      .en_port_0                        (en_port_0),
      .pri_port_0                       (pri_port_0),
      .en_port_1                        (en_port_1),
      .pri_port_1                       (pri_port_1),
     
      .en_port_2                        (en_port_2),
      .pri_port_2                       (pri_port_2),
      .en_port_3                        (en_port_3),
      .pri_port_3                       (pri_port_3),
      .en_port_4                        (en_port_4),
      .pri_port_4                       (pri_port_4),
      .en_port_5                        (en_port_5),
      .pri_port_5                       (pri_port_5),
     .itc_reg                           (itc_reg),
     .it_atb_data_0_wr_reg              (it_atb_data_0_wr_reg),
     .it_atb_ctr_2_wr_reg               (it_atb_ctr_2_wr_reg),
     .it_atb_ctr_1_wr_reg               (it_atb_ctr_1_wr_reg),
     .it_atb_ctr_0_wr_reg               (it_atb_ctr_0_wr_reg),

     // Outputs
     
     .it_atb_data_0_rd_reg              (it_atb_data_0_rd_reg),
     .it_atb_ctr_2_rd_reg               (it_atb_ctr_2_rd_reg),
     .it_atb_ctr_1_rd_reg               (it_atb_ctr_1_rd_reg),
     .it_atb_ctr_0_rd_reg               (it_atb_ctr_0_rd_reg),

     .afreadym                          (afreadym),
     .atvalidm                          (atvalidm),
     .atbytesm                          (atbytesm),
     .atidm                             (atidm),
     .atdatam                           (atdatam),
     
     .atreadys2                         (atreadys2),
     .afvalids2                         (afvalids2),
     .syncreqs2                         (syncreqs2),
     
     .atreadys3                         (atreadys3),
     .afvalids3                         (afvalids3),
     .syncreqs3                         (syncreqs3),
     
     .atreadys4                         (atreadys4),
     .afvalids4                         (afvalids4),
     .syncreqs4                         (syncreqs4),
     
     .atreadys5                         (atreadys5),
     .afvalids5                         (afvalids5),
     .syncreqs5                         (syncreqs5),
     
     .atreadys0                         (atreadys0),
     .afvalids0                         (afvalids0),
     .syncreqs0                         (syncreqs0),
     .atreadys1                         (atreadys1),
     .afvalids1                         (afvalids1),
     .syncreqs1                         (syncreqs1)
);

`ifdef ARM_ASSERT_ON
  //----------------------------------------------------------------------------
  // OVL Assertions
  //----------------------------------------------------------------------------

  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : Number of ATB slave ports cannot be less than 2 and greater than 8")
      uzovl_cxatbfunnel_num_atb_slave
        (
         .clk         (clk),
         .reset_n     (resetn),
         .test_expr   (CXFUNNEL_NUMBER_OF_ATB_SLAVES < 2 | CXFUNNEL_NUMBER_OF_ATB_SLAVES > 8 )
        );

  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : ATB Data width can be only in powers of 2 and within 128 bits")
      uzovl_cxatbfunnel_atb_data_width
        (
         .clk         (clk),
         .reset_n     (resetn),
         .test_expr   (~(CXFUNNEL_ATB_DATA_WIDTH == 8   |
                         CXFUNNEL_ATB_DATA_WIDTH == 16  |
                         CXFUNNEL_ATB_DATA_WIDTH == 32  |
                         CXFUNNEL_ATB_DATA_WIDTH == 64  |
                         CXFUNNEL_ATB_DATA_WIDTH == 128 ))
        );

`endif

endmodule // cxatbfunnel
