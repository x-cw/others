// 
//   Copyright (c) 2024 Innosilicon. Ltd.  All rights reserved. 
// 
//   THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF INNOSILICON
//   The copyright notice above does not evidence any actual or intended
//   publication of such source code.
// 
//************************************************************************
//    Module name: cxect.v
//    Create by  : chenqw
//    Email      : chenqw@innosilicon.com.cn
//    Create time: 2024-08-28
//************************************************************************
//    Description: 
//-FHDR*************************************************************************

module ts_gen_wrapper (
/*autoinput*/
// Beginning of automatic inputs (from unused autoinst inputs)
input [11:2]            cxtsgen_paddrctrl,      // To cxtsgen_u0 of cxtsgen.v
input                   cxtsgen_penablectrl,    // To cxtsgen_u0 of cxtsgen.v
input                   cxtsgen_pselctrl,       // To cxtsgen_u0 of cxtsgen.v
input [31:0]            cxtsgen_pwdatactrl,     // To cxtsgen_u0 of cxtsgen.v
input                   cxtsgen_pwritectrl,     // To cxtsgen_u0 of cxtsgen.v
input                   dbg_clk,                // To cxtsgen_u0 of cxtsgen.v, ...
input                   dbg_rstn,               // To cxtsgen_u0 of cxtsgen.v, ...
input                   ntsreplicator_tssyncreadym0,// To cxntsreplicator_11_u0 of cxntsreplicator_11.v
input                   ntsreplicator_tssyncreadym1,// To cxntsreplicator_11_u0 of cxntsreplicator_11.v
input                   ntsreplicator_tssyncreadym10,// To cxntsreplicator_11_u0 of cxntsreplicator_11.v
input                   ntsreplicator_tssyncreadym2,// To cxntsreplicator_11_u0 of cxntsreplicator_11.v
input                   ntsreplicator_tssyncreadym3,// To cxntsreplicator_11_u0 of cxntsreplicator_11.v
input                   ntsreplicator_tssyncreadym4,// To cxntsreplicator_11_u0 of cxntsreplicator_11.v
input                   ntsreplicator_tssyncreadym5,// To cxntsreplicator_11_u0 of cxntsreplicator_11.v
input                   ntsreplicator_tssyncreadym6,// To cxntsreplicator_11_u0 of cxntsreplicator_11.v
input                   ntsreplicator_tssyncreadym7,// To cxntsreplicator_11_u0 of cxntsreplicator_11.v
input                   ntsreplicator_tssyncreadym8,// To cxntsreplicator_11_u0 of cxntsreplicator_11.v
input                   ntsreplicator_tssyncreadym9,// To cxntsreplicator_11_u0 of cxntsreplicator_11.v
input                   tscenter_hltdbg,        // To cxtsgen_u0 of cxtsgen.v
// End of automatics
/*autooutput*/
// Beginning of automatic outputs (from unused autoinst outputs)
output [31:0]           cxtsgen_prdatactrl,     // From cxtsgen_u0 of cxtsgen.v
output                  cxtsgen_preadyctrl,     // From cxtsgen_u0 of cxtsgen.v
output                  cxtsgen_pslverrctrl,    // From cxtsgen_u0 of cxtsgen.v
output [6:0]            ntsreplicator_tsbitm0,  // From cxntsreplicator_11_u0 of cxntsreplicator_11.v
output [6:0]            ntsreplicator_tsbitm1,  // From cxntsreplicator_11_u0 of cxntsreplicator_11.v
output [6:0]            ntsreplicator_tsbitm10, // From cxntsreplicator_11_u0 of cxntsreplicator_11.v
output [6:0]            ntsreplicator_tsbitm2,  // From cxntsreplicator_11_u0 of cxntsreplicator_11.v
output [6:0]            ntsreplicator_tsbitm3,  // From cxntsreplicator_11_u0 of cxntsreplicator_11.v
output [6:0]            ntsreplicator_tsbitm4,  // From cxntsreplicator_11_u0 of cxntsreplicator_11.v
output [6:0]            ntsreplicator_tsbitm5,  // From cxntsreplicator_11_u0 of cxntsreplicator_11.v
output [6:0]            ntsreplicator_tsbitm6,  // From cxntsreplicator_11_u0 of cxntsreplicator_11.v
output [6:0]            ntsreplicator_tsbitm7,  // From cxntsreplicator_11_u0 of cxntsreplicator_11.v
output [6:0]            ntsreplicator_tsbitm8,  // From cxntsreplicator_11_u0 of cxntsreplicator_11.v
output [6:0]            ntsreplicator_tsbitm9,  // From cxntsreplicator_11_u0 of cxntsreplicator_11.v
output [1:0]            ntsreplicator_tssyncm0, // From cxntsreplicator_11_u0 of cxntsreplicator_11.v
output [1:0]            ntsreplicator_tssyncm1, // From cxntsreplicator_11_u0 of cxntsreplicator_11.v
output [1:0]            ntsreplicator_tssyncm10,// From cxntsreplicator_11_u0 of cxntsreplicator_11.v
output [1:0]            ntsreplicator_tssyncm2, // From cxntsreplicator_11_u0 of cxntsreplicator_11.v
output [1:0]            ntsreplicator_tssyncm3, // From cxntsreplicator_11_u0 of cxntsreplicator_11.v
output [1:0]            ntsreplicator_tssyncm4, // From cxntsreplicator_11_u0 of cxntsreplicator_11.v
output [1:0]            ntsreplicator_tssyncm5, // From cxntsreplicator_11_u0 of cxntsreplicator_11.v
output [1:0]            ntsreplicator_tssyncm6, // From cxntsreplicator_11_u0 of cxntsreplicator_11.v
output [1:0]            ntsreplicator_tssyncm7, // From cxntsreplicator_11_u0 of cxntsreplicator_11.v
output [1:0]            ntsreplicator_tssyncm8, // From cxntsreplicator_11_u0 of cxntsreplicator_11.v
output [1:0]            ntsreplicator_tssyncm9  // From cxntsreplicator_11_u0 of cxntsreplicator_11.v
// End of automatics
);

/*autowire*/
// Beginning of automatic wires (for undeclared instantiated-module outputs)
wire [6:0]              cxtse_tsbit;            // From cxtse_u0 of cxtse.v
wire [1:0]              cxtse_tssync;           // From cxtse_u0 of cxtse.v
wire                    cxtse_tssyncready;      // From cxntsreplicator_11_u0 of cxntsreplicator_11.v
wire                    cxtsgen_tsforcesync;    // From cxtsgen_u0 of cxtsgen.v
wire [63:0]             cxtsgen_tsvalueb;       // From cxtsgen_u0 of cxtsgen.v
// End of automatics

/* cxtsgen auto_template (
    .preadyread     (),
    .pslverrread    (),
    .prdataread     (),
    .pselread       (1'b0),
    .penableread    (1'b0),
    .pwriteread     (1'b0),
    .paddrread      (10'd0),
    .pwdataread     (32'd0),
    .clk            (dbg_clk),
    .resetn         (dbg_rstn),
    .hltdbg         (tscenter_hltdbg),
    .\(.*\)         (cxtsgen_\1[]),
);
*/

cxtsgen
cxtsgen_u0 (
/*autoinst*/
            // Outputs
            .preadyread                 (),                      // Templated
            .pslverrread                (),                      // Templated
            .prdataread                 (),                      // Templated
            .preadyctrl                 (cxtsgen_preadyctrl),    // Templated
            .pslverrctrl                (cxtsgen_pslverrctrl),   // Templated
            .prdatactrl                 (cxtsgen_prdatactrl[31:0]), // Templated
            .tsvalueb                   (cxtsgen_tsvalueb[63:0]), // Templated
            .tsforcesync                (cxtsgen_tsforcesync),   // Templated
            // Inputs
            .clk                        (dbg_clk),               // Templated
            .resetn                     (dbg_rstn),              // Templated
            .hltdbg                     (tscenter_hltdbg),       // Templated
            .pselread                   (1'b0),                  // Templated
            .penableread                (1'b0),                  // Templated
            .pwriteread                 (1'b0),                  // Templated
            .paddrread                  (10'd0),                 // Templated
            .pwdataread                 (32'd0),                 // Templated
            .pselctrl                   (cxtsgen_pselctrl),      // Templated
            .penablectrl                (cxtsgen_penablectrl),   // Templated
            .pwritectrl                 (cxtsgen_pwritectrl),    // Templated
            .paddrctrl                  (cxtsgen_paddrctrl[11:2]), // Templated
            .pwdatactrl                 (cxtsgen_pwdatactrl[31:0])); // Templated


/* cxtse auto_template (
    .tsclk          (dbg_clk),
    .tsresetn       (dbg_rstn),
    .tsvalue        (cxtsgen_tsvalueb),
    .tsforcesync    (cxtsgen_tsforcesync),
    .\(.*\)         (cxtse_\1[]),
);
*/

cxtse
cxtse_u0 (
/*autoinst*/
          // Outputs
          .tsbit                        (cxtse_tsbit[6:0]),      // Templated
          .tssync                       (cxtse_tssync[1:0]),     // Templated
          // Inputs
          .tsclk                        (dbg_clk),               // Templated
          .tsresetn                     (dbg_rstn),              // Templated
          .tsvalue                      (cxtsgen_tsvalueb),      // Templated
          .tsforcesync                  (cxtsgen_tsforcesync),   // Templated
          .tssyncready                  (cxtse_tssyncready));    // Templated

/* cxntsreplicator_11 auto_template (
    .clk            (dbg_clk),
    .resetn         (dbg_rstn),
    .\(ts.*\)s      (cxtse_\1[]),
    .\(.*\)         (ntsreplicator_\1[]),
);
*/

cxntsreplicator_11 
cxntsreplicator_11_u0 (
/*autoinst*/
                       // Outputs
                       .tsbitm0         (ntsreplicator_tsbitm0[6:0]), // Templated
                       .tssyncm0        (ntsreplicator_tssyncm0[1:0]), // Templated
                       .tsbitm1         (ntsreplicator_tsbitm1[6:0]), // Templated
                       .tssyncm1        (ntsreplicator_tssyncm1[1:0]), // Templated
                       .tsbitm2         (ntsreplicator_tsbitm2[6:0]), // Templated
                       .tssyncm2        (ntsreplicator_tssyncm2[1:0]), // Templated
                       .tsbitm3         (ntsreplicator_tsbitm3[6:0]), // Templated
                       .tssyncm3        (ntsreplicator_tssyncm3[1:0]), // Templated
                       .tsbitm4         (ntsreplicator_tsbitm4[6:0]), // Templated
                       .tssyncm4        (ntsreplicator_tssyncm4[1:0]), // Templated
                       .tsbitm5         (ntsreplicator_tsbitm5[6:0]), // Templated
                       .tssyncm5        (ntsreplicator_tssyncm5[1:0]), // Templated
                       .tsbitm6         (ntsreplicator_tsbitm6[6:0]), // Templated
                       .tssyncm6        (ntsreplicator_tssyncm6[1:0]), // Templated
                       .tsbitm7         (ntsreplicator_tsbitm7[6:0]), // Templated
                       .tssyncm7        (ntsreplicator_tssyncm7[1:0]), // Templated
                       .tsbitm8         (ntsreplicator_tsbitm8[6:0]), // Templated
                       .tssyncm8        (ntsreplicator_tssyncm8[1:0]), // Templated
                       .tsbitm9         (ntsreplicator_tsbitm9[6:0]), // Templated
                       .tssyncm9        (ntsreplicator_tssyncm9[1:0]), // Templated
                       .tsbitm10        (ntsreplicator_tsbitm10[6:0]), // Templated
                       .tssyncm10       (ntsreplicator_tssyncm10[1:0]), // Templated
                       .tssyncreadys    (cxtse_tssyncready),     // Templated
                       // Inputs
                       .clk             (dbg_clk),               // Templated
                       .resetn          (dbg_rstn),              // Templated
                       .tssyncreadym0   (ntsreplicator_tssyncreadym0), // Templated
                       .tssyncreadym1   (ntsreplicator_tssyncreadym1), // Templated
                       .tssyncreadym2   (ntsreplicator_tssyncreadym2), // Templated
                       .tssyncreadym3   (ntsreplicator_tssyncreadym3), // Templated
                       .tssyncreadym4   (ntsreplicator_tssyncreadym4), // Templated
                       .tssyncreadym5   (ntsreplicator_tssyncreadym5), // Templated
                       .tssyncreadym6   (ntsreplicator_tssyncreadym6), // Templated
                       .tssyncreadym7   (ntsreplicator_tssyncreadym7), // Templated
                       .tssyncreadym8   (ntsreplicator_tssyncreadym8), // Templated
                       .tssyncreadym9   (ntsreplicator_tssyncreadym9), // Templated
                       .tssyncreadym10  (ntsreplicator_tssyncreadym10), // Templated
                       .tsbits          (cxtse_tsbit[6:0]),      // Templated
                       .tssyncs         (cxtse_tssync[1:0]));    // Templated


// Local Variables:
// verilog-library-directories:("./"  "../coresight_component/timestamp_module/cxntsasyncbridge/" "../coresight_component/timestamp_module/cxntsreplicator_11/verilog/" "../coresight_component/timestamp_module/cxtsd/verilog/" "../coresight_component/timestamp_module/cxtse/verilog/" "../coresight_component/timestamp_module/cxtsgen/verilog/" "../coresight_component/timestamp_module/cxntsasyncbridge_mst/verilog/" "../coresight_component/timestamp_module/cxntsasyncbridge_slv/verilog/") 
// verilog-auto-inst-param-value:t
// verilog-auto-wire-type:"wire"
// End:

endmodule
