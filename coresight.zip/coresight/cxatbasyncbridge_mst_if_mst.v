//----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2010-2015 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//
//      Checked In          : $Date: 2015-01-12 13:23:39 +0000 (Mon, 12 Jan 2015) $
//
//      Revision            : $Revision: 41056 $
//
//      Release Information : CoreSight-SoC-TM100-r3p2-00rel0
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
// cxatbasyncbridge_mst_if.v
//-----------------------------------------------------------------------------
//
// cxatbasyncbridge_mst_if.v provides the instantiations of all modules on the Master
// side of the Asynchronous Bridge
//
// Instantiated blocks
// -------------------
//
// cxatbasyncbridge_mst_fifo.v   - ATB Master Clock Domain Side FIFO Module
// cxatbasyncbridge_mst_sync.v   - ATB Master Clock Domain Side Synchronizers
//-----------------------------------------------------------------------------

module cxatbasyncbridge_mst_if_mst
       #( parameter DW =31,
          parameter BW =1,
          parameter FIFO_DATA_WIDTH=41)
 (
  // Inputs
  atclkm,
  atclkenm,
  atresetmn,
  atreadym,
  afvalidm,

  atb_fwd_data,
  // Outputs
  atvalidm,
  atbytesm,
  atidm,
  atdatam,
  afreadym,

  atb_rev_data,
  zero_pointer
  );

   // Inputs
  input wire                              atclkm;           // ATB Master clock
  input wire                              atclkenm;         // ATB Master clock enable
  input wire                              atresetmn;        // ATB Master clock asychronous reset active low
  input wire                              atreadym;         // ATReady so data can be read from FIFO
  input wire                              afvalidm;         // Flush Request from the slave device

  input wire [6*FIFO_DATA_WIDTH + 10 : 0] atb_fwd_data;

  // Outputs
  output wire                             atvalidm;         // Valid for output
  output wire [BW:0]                      atbytesm;         // ATB Bus bytes master

  output wire [6:0]                       atidm;            //
  output wire [DW:0]                      atdatam;          // Output the read data values
  output wire                             afreadym;         // Flush Data complete to slave device
  output wire [4:0]                       atb_rev_data;     // ATB reverse data for slave
  output wire                             zero_pointer;      // Signal to zero the pointers


  // Wires
  wire [3:0]                  wrptr_grey_sync;
  wire                        flush_done_sync;

  wire [3:0]                 wrptr_grey_d;       // Write pointer from the Slave Clamp
  wire                       flush_done_d;       // FlushDone from the Slave Clamp
  wire [FIFO_DATA_WIDTH-1:0] fifo_data_0d;       // Fifo Entry 0 from Slave Clamp
  wire [FIFO_DATA_WIDTH-1:0] fifo_data_1d;       // Fifo Entry 1 from Slave Clamp
  wire [FIFO_DATA_WIDTH-1:0] fifo_data_2d;       // Fifo Entry 2 from Slave Clamp
  wire [FIFO_DATA_WIDTH-1:0] fifo_data_3d;       // Fifo Entry 3 from Slave Clamp
  wire [FIFO_DATA_WIDTH-1:0] fifo_data_4d;       // Fifo Entry 4 from Slave Clamp
  wire [FIFO_DATA_WIDTH-1:0] fifo_data_5d;       // Fifo Entry 5 from Slave Clamp
  wire                       flush_flag_0d;      // Flush Flag for Fifo Entry 0 from Slave Clamp
  wire                       flush_flag_1d;      // Flush Flag for Fifo Entry 1 from Slave Clamp
  wire                       flush_flag_2d;      // Flush Flag for Fifo Entry 2 from Slave Clamp
  wire                       flush_flag_3d;      // Flush Flag for Fifo Entry 3 from Slave Clamp
  wire                       flush_flag_4d;      // Flush Flag for Fifo Entry 4 from Slave Clamp
  wire                       flush_flag_5d;      // Flush Flag for Fifo Entry 5 from Slave Clamp
  wire [3:0]                rdptr_grey;        // Read pointer to the write clock domain
  wire                      flush_req;         // Flush Request

  // ---------------------------------------------------------------------------
  // Splitting the atb_fwd_data
  // ---------------------------------------------------------------------------
  assign fifo_data_0d = atb_fwd_data[FIFO_DATA_WIDTH - 1 : 0];
  assign flush_flag_0d = atb_fwd_data[FIFO_DATA_WIDTH];
  assign fifo_data_1d = atb_fwd_data[2*FIFO_DATA_WIDTH : FIFO_DATA_WIDTH + 1];
  assign flush_flag_1d = atb_fwd_data[2*FIFO_DATA_WIDTH + 1];
  assign fifo_data_2d = atb_fwd_data[3*FIFO_DATA_WIDTH + 1 : 2*FIFO_DATA_WIDTH + 2];
  assign flush_flag_2d = atb_fwd_data[3*FIFO_DATA_WIDTH + 2];
  assign fifo_data_3d = atb_fwd_data[4*FIFO_DATA_WIDTH + 2 : 3*FIFO_DATA_WIDTH + 3];
  assign flush_flag_3d = atb_fwd_data[4*FIFO_DATA_WIDTH + 3];
  assign fifo_data_4d = atb_fwd_data[5*FIFO_DATA_WIDTH + 3 : 4*FIFO_DATA_WIDTH + 4];
  assign flush_flag_4d = atb_fwd_data[5*FIFO_DATA_WIDTH + 4];
  assign fifo_data_5d = atb_fwd_data[6*FIFO_DATA_WIDTH + 4 : 5*FIFO_DATA_WIDTH + 5];
  assign flush_flag_5d = atb_fwd_data[6*FIFO_DATA_WIDTH + 5];
  assign flush_done_d = atb_fwd_data[6*FIFO_DATA_WIDTH + 6];
  assign wrptr_grey_d = atb_fwd_data[6*FIFO_DATA_WIDTH + 10 : 6*FIFO_DATA_WIDTH + 7];

  // ---------------------------------------------------------------------------
  // Creating atb_rev_data bus by concatenation
  // ---------------------------------------------------------------------------
  assign atb_rev_data ={rdptr_grey, flush_req};

  // ---------------------------------------------------------------------------
  // ATB Master Clock Domain FIFO Interface
  // ---------------------------------------------------------------------------
  cxatbasyncbridge_mst_fifo_mst
 #(DW, BW, FIFO_DATA_WIDTH) u_cxatbasyncbridge_mst_fifo
    (
    // Outputs
    .atvalidm                          (atvalidm),
    .atbytesm                          (atbytesm),
    .atidm                             (atidm),
    .atdatam                           (atdatam),
    .afreadym                          (afreadym),
    .rdptr_grey                         (rdptr_grey[3:0]),
    .flush_req                          (flush_req),
    .zero_pointer                       (zero_pointer),

    // Inputs
    .atclkm                            (atclkm),
    .atclkenm                          (atclkenm),
    .atresetmn                         (atresetmn),

    .atreadym                          (atreadym),
    .afvalidm                          (afvalidm),
    .fifo_data_0                         (fifo_data_0d),
    .fifo_data_1                         (fifo_data_1d),
    .fifo_data_2                         (fifo_data_2d),
    .fifo_data_3                         (fifo_data_3d),
    .fifo_data_4                         (fifo_data_4d),
    .fifo_data_5                         (fifo_data_5d),
    .flush_flag_0                        (flush_flag_0d),
    .flush_flag_1                        (flush_flag_1d),
    .flush_flag_2                        (flush_flag_2d),
    .flush_flag_3                        (flush_flag_3d),
    .flush_flag_4                        (flush_flag_4d),
    .flush_flag_5                        (flush_flag_5d),
    .wrptr_grey_sync                     (wrptr_grey_sync[3:0]),

    .flush_done_sync                     (flush_done_sync));

  // ---------------------------------------------------------------------------
  // ATB Master Clock Domain Synchronizers
  // ---------------------------------------------------------------------------
  // Signals going to the ATB Master Clock domain from ATB Slave Clock domain
  cxatbasyncbridge_mst_sync_mst u_cxatbasyncbridge_mst_sync
    (
    // Outputs
    .wrptr_grey_sync                       (wrptr_grey_sync[3:0]),
    .flush_done_sync                       (flush_done_sync),
    // Inputs
    .atclkm                                (atclkm),
    .atclkenm                              (atclkenm),
    .atresetmn                             (atresetmn),
    .wrptr_grey                            (wrptr_grey_d[3:0]),
    .flush_done                            (flush_done_d));

endmodule // cxatbasyncbridge_mst_if
