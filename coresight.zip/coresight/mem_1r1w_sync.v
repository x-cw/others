`include "../general/general.vh"

module mem_1r1w_sync
  #( parameter
     MEM_WORDS=0,
     MEM_WIDTH=0,
     MODULE_NAME="NONE",
     L2_MEM_WORDS=log2(MEM_WORDS)
     ) (
        input wire                    clk,

        input wire [MEM_WIDTH-1:0]    din,
        input wire [L2_MEM_WORDS-1:0] rd_addr,
        input wire                    rd_en,

        input wire [L2_MEM_WORDS-1:0] wr_addr,
        input wire                    wr_en,

        output wire [MEM_WIDTH-1:0]   dout
        );

  localparam MEM_BIT_EN=0;
  
`include "../general/misc.vh"
  //leda NTL_CON12 off
  wire [MEM_WIDTH-1:0] dout_internal;
  //leda NTL_CON12 on
  wire [MEM_WIDTH-1:0] bit_en_internal={MEM_WIDTH{1'b1}};

//`ifdef SYNTHESIS
  assign dout=dout_internal;

//`else
//  reg rd_en_last;
//  reg [L2_MEM_WORDS-1:0] rd_addr_last;
//  reg wr_en_last;
//  reg [L2_MEM_WORDS-1:0] wr_addr_last;
//  always @(posedge rd_clk) begin
//    rd_en_last<=rd_en;
//    rd_addr_last<=rd_addr;
//    wr_en_last<=wr_en;
//    wr_addr_last<=wr_addr;
//  end
//    
//  
//  assign dout=(wr_addr_last==rd_addr_last && 
//               wr_en_last && rd_en_last) ? {MEM_WIDTH{1'bx}} : 
//              (rd_en_last && rd_addr_last >= MEM_WORDS) ?  {MEM_WIDTH{1'bx}} :
//              dout_internal;
//
// `ifdef MEMORY_CHECK_ENABLES
//  
//  reg rd_en_at_reset;
//  initial begin
//    #10;
//    rd_en_at_reset=rd_en;
//    rd_en_assert_at_reset: assert (rd_en_at_reset==0) else
//      $warning("rd_en asserted at reset.");
//  end
//
//  wr_over_and_over: assert property (@(posedge wr_clk)
//                                     wr_en==1[*2] |-> wr_addr!=$past(wr_addr,1))
//    else $warning("writing to the same address in multiple clocks");
//
//  rd_over_and_over: assert property (@(posedge rd_clk)
//                                     disable iff(rd_en_at_reset==1)
//                                     rd_en==1[*2] |-> rd_addr!=$past(rd_addr,1))
//    else $warning("readed from the same address in multiple clocks");
// `endif

//  params_not_defined: assert property (@(posedge rd_clk) L2_MEM_WORDS!=0 && MEM_WIDTH!=0) else
//    $fatal(0,"addr_bits or ram_width = 0");
//
//  rd_clk_not_defined: assert property (@(posedge rd_en) rd_en==1 |-> rd_clk===1'b1 || rd_clk===1'b0) else
//    $fatal(0,"rd clock not defined");
//  wr_clk_not_defined: assert property (@(posedge wr_en) wr_en==1 |-> wr_clk===1'b1 || wr_clk===1'b0) else
//    $fatal(0,"wr clock not defined");
//
//  
//  // VCS coverage off
//  event              dv_bd_wr;
//  event              dv_bd_wr_ack;
//  reg [31:0]         dv_bd_wr_addr;
//  reg [31:0]         dv_bd_wr_bit_en;
//  reg [31:0]         dv_bd_din;
//  
//  event              dv_bd_rd;
//  event              dv_bd_rd_ack;
//  reg [31:0]         dv_bd_rd_addr;
//  reg [31:0]         dv_bd_dout;
//  // VCS coverage on
//  
//`endif
  
  
`ifdef ASIC
  mem_1r1w_flops
    #(/*autoinstparam*/
      // Parameters
      .MEM_WORDS                        (MEM_WORDS),
      .MEM_WIDTH                        (MEM_WIDTH),
      .MEM_BIT_EN                       (MEM_BIT_EN),
      .L2_MEM_WORDS                     (L2_MEM_WORDS))
  flops(/*autoinst*/
        // Outputs
        .dout_internal                  (dout_internal[MEM_WIDTH-1:0]),
        // Inputs
        .din                            (din[MEM_WIDTH-1:0]),
        .rd_addr                        (rd_addr[L2_MEM_WORDS-1:0]),
        .rd_clk                         (clk),
        .rd_en                          (rd_en),
        .wr_addr                        (wr_addr[L2_MEM_WORDS-1:0]),
        .wr_clk                         (clk),
        .wr_en                          (wr_en),
        .bit_en_internal                (bit_en_internal[MEM_WIDTH-1:0]));
`else

  
`ifdef FPGA
  mem_1r1w_flops
    #(/*autoinstparam*/
      // Parameters
      .MEM_WORDS                        (MEM_WORDS),
      .MEM_WIDTH                        (MEM_WIDTH),
      .MEM_BIT_EN                       (MEM_BIT_EN),
      .L2_MEM_WORDS                     (L2_MEM_WORDS))
  flops(/*autoinst*/
        // Outputs
        .dout_internal                  (dout_internal[MEM_WIDTH-1:0]),
        // Inputs
        .din                            (din[MEM_WIDTH-1:0]),
        .rd_addr                        (rd_addr[L2_MEM_WORDS-1:0]),
        .rd_clk                         (clk),
        .rd_en                          (rd_en),
        .wr_addr                        (wr_addr[L2_MEM_WORDS-1:0]),
        .wr_clk                         (clk),
        .wr_en                          (wr_en),
        .bit_en_internal                (bit_en_internal[MEM_WIDTH-1:0]));
`else

  wire WAEN=~wr_en;
  wire RBEN=~rd_en;
  wire WACLK=clk;
  wire RBCLK=clk;
  
  localparam OFFSET=1000;
  localparam MEMORY=MEM_WORDS * OFFSET + MEM_WIDTH;

      /* 
       //MEMORY_AUTO_LINES_BEGIN
        mem_2048x16_2rw_ben0_ra_8 auto_template
        mem_4096x8_2rw_ben0_ra_16 auto_template
        (.CLKA(rd_clk),
        .CENA(~rd_en),
        .QA(dout_internal[]),
        .AA(rd_addr[]),
        .DA({@"vl-width"{1'b0}}),
        .BWENA({@"vl-width"{1'b1}}),
        .WENA(1'b1),
        .CLKB(wr_clk),
        .CENB(~wr_en),
        .DB(din[]),
        .QB(),
        .AB(wr_addr[]),
        .BWENB(~bit_en_internal[]),
        .WENB(~wr_en),
        );

       //MEMORY_AUTO_LINES_END
     */

  
  generate
    //if (MEM_WORDS * MEM_WIDTH <= 65536) begin: flops
    //if (MEM_WORDS * MEM_WIDTH <= 4096) begin: flops
    if (MEM_WORDS * MEM_WIDTH <= 2048 * 2) begin: flops

//`ifndef SYNTHESIS
// // VCS coverage off
// // Backdoor Access Interface:
// always @(dv_bd_wr) begin
//   flops.dv_bd_wr_addr = dv_bd_wr_addr;
//   flops.dv_bd_wr_bit_en = dv_bd_wr_bit_en;
//   flops.dv_bd_din = dv_bd_din;
//   ->flops.dv_bd_wr;
//   @(flops.dv_bd_wr_ack);
//   ->dv_bd_wr_ack;
// end
// always @(dv_bd_rd) begin
//   flops.dv_bd_rd_addr = dv_bd_rd_addr;
//   ->flops.dv_bd_rd;
//   @(flops.dv_bd_rd_ack);
//   dv_bd_dout = flops.dv_bd_dout;
//   ->dv_bd_rd_ack;
// end
// // VCS coverage on
//`endif

      mem_1r1w_flops #(/*autoinstparam*/
                       // Parameters
                       .MEM_WORDS       (MEM_WORDS),
                       .MEM_WIDTH       (MEM_WIDTH),
                       .MEM_BIT_EN      (MEM_BIT_EN),
                       .L2_MEM_WORDS    (L2_MEM_WORDS)) 
      flops(/*autoinst*/
            // Outputs
            .dout_internal              (dout_internal[MEM_WIDTH-1:0]),
            // Inputs
            .din                        (din[MEM_WIDTH-1:0]),
            .rd_addr                    (rd_addr[L2_MEM_WORDS-1:0]),
            .rd_clk                     (clk),
            .rd_en                      (rd_en),
            .wr_addr                    (wr_addr[L2_MEM_WORDS-1:0]),
            .wr_clk                     (clk),
            .wr_en                      (wr_en),
            .bit_en_internal            (bit_en_internal[MEM_WIDTH-1:0]));
    end 
    //else if()
    //begin:ai_sr_rf_1024x269_2p_1clk
    //`include "ai_sr_memory.vh"
    //end
    else if(MEM_WORDS == 1024 && MEM_WIDTH == 269 && MODULE_NAME == "AI_SR")begin:ai_sr_rf_1024x269_2p_1clk
    ai_sr_rf_1024x269_wrapper ai_sr_rf_1024x269_wrap_u(
      .CLKW    (clk),
      .WEB     (~wr_en),
      .AA      (wr_addr[L2_MEM_WORDS-1:0]),
      .D       (din[MEM_WIDTH-1:0]),
  
      .CLKR    (clk),
      .REB     (~rd_en),
      .AB      (rd_addr[L2_MEM_WORDS-1:0]),
      .Q       (dout_internal[MEM_WIDTH-1 :0]) 
    );
    end
    else if(MEM_WORDS == 16 && MEM_WIDTH == 289) begin:pdp_rf_16x289_2p_1clk
      mem_1r1w_flops #(/*autoinstparam*/
                       // Parameters
                       .MEM_WORDS       (MEM_WORDS),
                       .MEM_WIDTH       (MEM_WIDTH),
                       .MEM_BIT_EN      (MEM_BIT_EN),
                       .L2_MEM_WORDS    (L2_MEM_WORDS)) 
      flops(/*autoinst*/
            // Outputs
            .dout_internal              (dout_internal[MEM_WIDTH-1:0]),
            // Inputs
            .din                        (din[MEM_WIDTH-1:0]),
            .rd_addr                    (rd_addr[L2_MEM_WORDS-1:0]),
            .rd_clk                     (clk),
            .rd_en                      (rd_en),
            .wr_addr                    (wr_addr[L2_MEM_WORDS-1:0]),
            .wr_clk                     (clk),
            .wr_en                      (wr_en),
            .bit_en_internal            (bit_en_internal[MEM_WIDTH-1:0]));
 
   ////foundry memory use more resource of register and logical
   // pdp_aw_lock_16x289_wrap  pdp_aw_lock_16x289_wrap_u(
   //   .CLKW    (clk),
   //   .WEB     (~wr_en),
   //   .AA      (wr_addr[L2_MEM_WORDS-1:0]),
   //   .D       (din[MEM_WIDTH-1:0]),
  
   //   .CLKR    (clk),
   //   .REB     (~rd_en),
   //   .AB      (rd_addr[L2_MEM_WORDS-1:0]),
   //   .Q       (dout_internal[MEM_WIDTH-1 :0]) 
   // );
    end
    else if(MEM_WORDS == 64 && MEM_WIDTH == 256) begin:pdp_rf_64x256_2p_1clk
     rf_64x256_2p_wrap pdp_rf_64x256_2p_wrap_inst(

            .CLKR    (clk),
            .CLKW    (clk),
            .WEB     (wr_en),
            .AA      (wr_addr[L2_MEM_WORDS-1:0]),
            .D       (din[MEM_WIDTH-1:0]),
  
            .REB     (rd_en),
            .AB      (rd_addr[L2_MEM_WORDS-1:0]),
            .Q       (dout_internal[MEM_WIDTH-1 :0]) 
     );
    end
    else if(MEM_WORDS == 64 && MEM_WIDTH == 101) begin:axi_mmu_aia_fifo
     mem_1r1w_flops
       #(/*autoinstparam*/
         // Parameters
         .MEM_WORDS                        (MEM_WORDS),
         .MEM_WIDTH                        (MEM_WIDTH),
         .MEM_BIT_EN                       (MEM_BIT_EN),
         .L2_MEM_WORDS                     (L2_MEM_WORDS))
     flops(/*autoinst*/
           // Outputs
           .dout_internal                  (dout_internal[MEM_WIDTH-1:0]),
           // Inputs
           .din                            (din[MEM_WIDTH-1:0]),
           .rd_addr                        (rd_addr[L2_MEM_WORDS-1:0]),
           .rd_clk                         (clk),
           .rd_en                          (rd_en),
           .wr_addr                        (wr_addr[L2_MEM_WORDS-1:0]),
           .wr_clk                         (clk),
           .wr_en                          (wr_en),
           .bit_en_internal                (bit_en_internal[MEM_WIDTH-1:0]));
    end
    else if(MEM_WORDS == 64 && MEM_WIDTH == 97) begin:axi_mmu_riscv_aia_fifo
     mem_1r1w_flops
       #(/*autoinstparam*/
         // Parameters
         .MEM_WORDS                        (MEM_WORDS),
         .MEM_WIDTH                        (MEM_WIDTH),
         .MEM_BIT_EN                       (MEM_BIT_EN),
         .L2_MEM_WORDS                     (L2_MEM_WORDS))
     flops(/*autoinst*/
           // Outputs
           .dout_internal                  (dout_internal[MEM_WIDTH-1:0]),
           // Inputs
           .din                            (din[MEM_WIDTH-1:0]),
           .rd_addr                        (rd_addr[L2_MEM_WORDS-1:0]),
           .rd_clk                         (clk),
           .rd_en                          (rd_en),
           .wr_addr                        (wr_addr[L2_MEM_WORDS-1:0]),
           .wr_clk                         (clk),
           .wr_en                          (wr_en),
           .bit_en_internal                (bit_en_internal[MEM_WIDTH-1:0]));
    end
    else begin: rams
      //leda off
      case(MEMORY)
        //MEMORY_CASE_LINES_BEGIN
   ('d1024 * OFFSET + 'd16): begin: mem_1024x16
     spram_1024x16_wrap u_spram_1024x16_wrap(
            .CLK     (clk),
            .WEB     (~wr_en),
            .AA      (wr_addr[L2_MEM_WORDS-1:0]),
            .D       (din[MEM_WIDTH-1:0]),
  
            .REB     (~rd_en),
            .AB      (rd_addr[L2_MEM_WORDS-1:0]),
            .Q       (dout_internal[MEM_WIDTH-1 :0]) 
     );
   end

   ('d1024 * OFFSET + 'd136): begin: mem_1024x136
     vcodec_r2f_d1024_w136_wrapper vcodec_r2f_d1024_w136_wrap_u(

            .CLK     (clk),
            .WEB     (~wr_en),
            .AA      (wr_addr[L2_MEM_WORDS-1:0]),
            .D       (din[MEM_WIDTH-1:0]),
  
            .REB     (~rd_en),
            .AB      (rd_addr[L2_MEM_WORDS-1:0]),
            .Q       (dout_internal[MEM_WIDTH-1 :0]) 
     );
   end

   ('d1024 * OFFSET + 'd140): begin: mem_1024x140
     vcodec_r2f_d1024_w140_wrapper vcodec_r2f_d1024_w140_wrap_u(

            .CLK     (clk),
            .WEB     (~wr_en),
            .AA      (wr_addr[L2_MEM_WORDS-1:0]),
            .D       (din[MEM_WIDTH-1:0]),
  
            .REB     (~rd_en),
            .AB      (rd_addr[L2_MEM_WORDS-1:0]),
            .Q       (dout_internal[MEM_WIDTH-1 :0]) 
     );
   end

   ('d1024 * OFFSET + 'd269): begin: mem_1024x269
     spram_1024x269_wrap spram_1024x269_wrap_u(
            .CLKW    (clk),
            .WEB     (~wr_en),
            .AA      (wr_addr[L2_MEM_WORDS-1:0]),
            .D       (din[MEM_WIDTH-1:0]),
  
            .CLKR    (clk),
            .REB     (~rd_en),
            .AB      (rd_addr[L2_MEM_WORDS-1:0]),
            .Q       (dout_internal[MEM_WIDTH-1 :0]) 
     );
   end

   ('d32 * OFFSET + 'd146): begin: mem_32x146
     rf_32x146_2p_wrap vcodec_rf_32x145_wrap_inst(

            .CLKR    (clk),
            .CLKW    (clk),
            .WEB     (~wr_en),
            .AA      (wr_addr[L2_MEM_WORDS-1:0]),
            .D       (din[MEM_WIDTH-1:0]),
  
            .REB     (~rd_en),
            .AB      (rd_addr[L2_MEM_WORDS-1:0]),
            .Q       (dout_internal[MEM_WIDTH-1 :0]) 
     );
   end

   ('d1024 * OFFSET + 'd36): begin: mem_1024x36
     PDP_R2F_HD_1024x36_wrapper PDP_R2F_HD_1024x36_wrapper_inst(

            .wclk    (clk),
            .rclk    (clk),
            .wen     (~wr_en),
            .waddr   (wr_addr[L2_MEM_WORDS-1:0]),
            .wdata   (din[MEM_WIDTH-1:0]),
  
            .ren     (~rd_en),
            .raddr   (rd_addr[L2_MEM_WORDS-1:0]),
            .rdata   (dout_internal[MEM_WIDTH-1 :0]) 
     );
   end

   ('d1024 * OFFSET + 'd39): begin: mem_1024x39
     PDP_R2F_HD_1024x39_wrapper PDP_R2F_HD_1024x39_wrapper_inst(

            .wclk    (clk),
            .rclk    (clk),
            .wen     (~wr_en),
            .waddr   (wr_addr[L2_MEM_WORDS-1:0]),
            .wdata   (din[MEM_WIDTH-1:0]),
  
            .ren     (~rd_en),
            .raddr   (rd_addr[L2_MEM_WORDS-1:0]),
            .rdata   (dout_internal[MEM_WIDTH-1 :0]) 
     );
   end

        //MEMORY_CASE_LINES_END
        
        default: begin: mem_UNDEFxUNDEF
`ifdef MEM_NOT_FATAL_IF_NOT_DEFINED
          initial assert (0) else
            $warning("MEMORY 1r1w %dx%d requested but not built",MEM_WORDS,MEM_WIDTH);
          
          mem_1r1w_flops
            #(/*autoinstparam*/
              // Parameters
              .MEM_WORDS                (MEM_WORDS),
              .MEM_WIDTH                (MEM_WIDTH),
              .MEM_BIT_EN               (MEM_BIT_EN),
              .L2_MEM_WORDS             (L2_MEM_WORDS))
          flops(/*autoinst*/
                // Outputs
                .dout_internal          (dout_internal[MEM_WIDTH-1:0]),
                // Inputs
                .din                    (din[MEM_WIDTH-1:0]),
                .rd_addr                (rd_addr[L2_MEM_WORDS-1:0]),
                .rd_clk                 (clk),
                .rd_en                  (rd_en),
                .wr_addr                (wr_addr[L2_MEM_WORDS-1:0]),
                .wr_clk                 (clk),
                .wr_en                  (wr_en),
                .bit_en_internal        (bit_en_internal[MEM_WIDTH-1:0]));
          
`else
          mem_model_not_defined #(
                                  .MEM_WORDS(MEM_WORDS),
                                  .MEM_WIDTH(MEM_WIDTH)
                                  ) mem();
`endif
        end
      endcase
      //leda on
    end
  endgenerate
`endif
`endif
  
endmodule 
//MEMORY_MEMDIR_BEGIN
// Local Variables:
// verilog-library-flags:("-y /asic/techlibs/smic55/memories/20140701")
// End:
//MEMORY_MEMDIR_END
