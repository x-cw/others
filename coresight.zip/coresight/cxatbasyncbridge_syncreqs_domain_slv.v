//-----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2010-2015 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//  Version and Release Control Information:
//
//  Checked In          : $Date: 2011-06-05 16:48:18 +0530 (Sun, 05 Jun 2011) $
//
//  Revision		: $Revision: 17078 $
//
//  Release Information : CoreSight-SoC-TM100-r3p2-00rel0
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// Abstract : CoreSight ATB syncreqs domain(cxatbasyncbridge_syncreqs_domain)
//-----------------------------------------------------------------------------
//
// cxatbasyncbridge_syncreqs_domain - CoreSight ATB syncreqs domain
// -------------------------------------------------------------------
//
// CoreSight AMBA Trace Bus (ATB) trace link device used to combine multiple
// trace sources into a single bus.
//-----------------------------------------------------------------------------

module cxatbasyncbridge_syncreqs_domain_slv (
  // Inputs
  clks,
  resetsn,
  clkens,
  syncreqs_req_async,
  // Outputs
  syncreqs_ack_async,
  syncreqs
  );

  // Inputs
  input wire         clks;
  input wire         resetsn;
  input wire         clkens;
  input wire         syncreqs_req_async;
  // Outputs
  output wire        syncreqs_ack_async;
  output reg         syncreqs;

//------------------------------------------------------------------------------
// Constants definitions
//------------------------------------------------------------------------------


  //----------------------------------------------------------------------------
  // Wires
  //----------------------------------------------------------------------------
  wire        syncreqs_req_corrupt_async;   // CDC intermediate signal
  wire        nxt_syncreqs;                 // D-input of syncreqs
  wire        syncreqs_req_sync;            // CDC block output
  reg         syncreqs_req_sync_del;        // CDC block output


  //----------------------------------------------------------------------------
  // Registers
  //----------------------------------------------------------------------------


  //============================================================================
  //
  // Main body of code
  // =================
  //
  //============================================================================



  // Add cdc blocks for incoming req

  //----------------------------------------------------------------------------
  // Incoming Req
  //----------------------------------------------------------------------------

  // Test component to corrupt req going into synchroniser
  cxatbasyncbridge_cdc_corrupt_gry #(1) u_cdc_corrupt_req
  (
      .clk       (clks),
      .resetn    (resetsn),
      .clken     (clkens),
      .sync      (1'b0),  // no flop
      .d_async   (syncreqs_req_async),
      .q_async   (syncreqs_req_corrupt_async)
  );

  // Synchroniser to bring the req into the clock domain
  cx_en_sync u_cdc_sync_req
  (
      .clk     (clks),
      .resetn  (resetsn),
      .clken   (clkens),   // double sync flops
      .sync_di (syncreqs_req_corrupt_async),
      .sync_do (syncreqs_req_sync)
  );

// Add CDC blocks for ack returned by the master to slave
  //----------------------------------------------------------------------------
  // Outgoing Ack
  //----------------------------------------------------------------------------
  assign syncreqs_ack_async = syncreqs_req_sync;

  assign nxt_syncreqs = ~syncreqs_req_sync_del & syncreqs_req_sync  ;


  always @(posedge clks or negedge resetsn)
    begin
      if (!resetsn)
        begin
          syncreqs              <= 1'b0;
          syncreqs_req_sync_del <= 1'b0;
        end
      else if (clkens)
        begin
          syncreqs              <= nxt_syncreqs;
          syncreqs_req_sync_del <= syncreqs_req_sync;
        end
    end


endmodule   //cxatbasyncbridge_syncreqs_domain_slv
