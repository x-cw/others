`include "../general/general.vh"


module gp_fifo
  #(parameter
    MODULE_NAME = "NONE",
    //these two are design for backward compatibility with the old design (gp_fifo_async)
    WIDTH=8,
    LOG2WORDS=2,

    FIFO_WIDTH=WIDTH,
    FIFO_WORDS=1 << LOG2WORDS,
    L2_FIFO_WORDS=log2(FIFO_WORDS),

    AFULL_THRESH=FIFO_WORDS,
    AEMPTY_THRESH=0,

    WR_SYNC = 1, // 1: write port is synchronous (free running clock), 0: asynchronous (strobe)
    RD_SYNC = 1, // 1: read port is synchronous (free running clock), 0: asynchronous (strobe)
    SAME_SYNC = (RD_SYNC && WR_SYNC),  
    // 1: if WR_SYNC and RD_SYNC, indicates wr_clk is same as rd_clk, 0: separate rd/wr clks

    RD_REG=0, // 1: use registered fifo output directly (else emulate unregistered)
    FULL_FLOP=0,
    VALID_ENTRIES_SYNC_RD_CLK=0 // 0=valid_entries sync to wr_clk, 1=sync to rd_clk
    
    ) (
       input wire                    clk,
       input wire                    reset_n,
       input wire                    init,
       
       //read
       input wire                    rd_en,
       output wire [FIFO_WIDTH-1:0]  dout,
       
       //write
       input wire                    wr_en,
       input wire [FIFO_WIDTH-1:0]   din,
       
       //status
       output wire                   aempty,
       output wire                   afull, 
       output wire                   empty,
       output wire                   full,
       output wire                   overflow,
       output wire                   underflow,
       output wire [L2_FIFO_WORDS:0] valid_entries
       );
`include "../general/misc.vh"

wire  wr_clk = clk;
wire  rd_clk = clk;
  /*autowire*/

`ifdef SS5_MEM
  generate
    if (WIDTH>80 && FIFO_WORDS>8) begin: gp_fifo_sync_no_divide  
      gp_clr_fifo_async_core #(/*autoinstparam*/
                           // Parameters
                           .MODULE_NAME         (MODULE_NAME),
                           .LOG2WORDS           (L2_FIFO_WORDS), // Templated
                           .WIDTH               (FIFO_WIDTH),    // Templated
                           .WR_SYNC             (1),
                           .AFULL_THRESH        (AFULL_THRESH),
                           .RD_SYNC             (1),
                           .AEMPTY_THRESH       (AEMPTY_THRESH),
                           .SAME_SYNC           (1),
                           .RD_REG              (0),
                           .FULL_FLOP           (0),
                           .VALID_ENTRIES_SYNC_RD_CLK(1))
      fifo (/*autoinst*/
            // Outputs
            .full                       (full),
            .afull                      (afull),
            .overflow                   (overflow),
            .valid_entries              (valid_entries[L2_FIFO_WORDS:0]),
            .dout                       (dout[FIFO_WIDTH-1:0]),
            .empty                      (empty),
            .aempty                     (aempty),
            .underflow                  (underflow),
            // Inputs
            .wr_reset_n                 (reset_n),
            .wr_clear                   (init),
            .rd_reset_n                 (reset_n),
            .rd_clear                   (init),
            .wr_clk                     (wr_clk),
            .wr_en                      (wr_en),
            .din                        (din[FIFO_WIDTH-1:0]),
            .rd_clk                     (rd_clk),
            .rd_en                      (rd_en));

    end else if (FIFO_WORDS>10 && SAME_SYNC==1) begin: gp_fifo_sync
      /*gp_fifo_sync auto_template (
        .ENABLE_INIT_INPUT(1),
        .clk  (rd_clk),
        .init (init),
      );*/
      
      gp_fifo_sync #(/*autoinstparam*/
                     // Parameters
                     .ENABLE_INIT_INPUT (1),                     // Templated
                     .FIFO_WIDTH        (FIFO_WIDTH),
                     .FIFO_WORDS        (FIFO_WORDS),
                     .AFULL_THRESH      (AFULL_THRESH),
                     .AEMPTY_THRESH     (AEMPTY_THRESH),
                     .L2_FIFO_WORDS     (L2_FIFO_WORDS))
      fifo(/*autoinst*/
           // Outputs
           .dout                        (dout[FIFO_WIDTH-1:0]),
           .aempty                      (aempty),
           .afull                       (afull),
           .empty                       (empty),
           .full                        (full),
           .overflow                    (overflow),
           .underflow                   (underflow),
           .valid_entries               (valid_entries[L2_FIFO_WORDS:0]),
           // Inputs
           .clk                         (rd_clk),                // Templated
           .reset_n                     (reset_n),
           .init                        (init),                  // Templated
           .rd_en                       (rd_en),
           .wr_en                       (wr_en),
           .din                         (din[FIFO_WIDTH-1:0]));

    end else if (SAME_SYNC==1) begin: gp_fifo_small

      /*gp_fifo_small2 auto_template (
        .ENABLE_INIT_INPUT(1),
        .clk(rd_clk),
        .init (init),       
      );*/
      gp_fifo_small2 #(/*autoinstparam*/
                       // Parameters
                       .ENABLE_INIT_INPUT(1),                    // Templated
                       .FIFO_WIDTH      (FIFO_WIDTH),
                       .FIFO_WORDS      (FIFO_WORDS),
                       .AFULL_THRESH    (AFULL_THRESH),
                       .AEMPTY_THRESH   (AEMPTY_THRESH),
                       .L2_FIFO_WORDS   (L2_FIFO_WORDS))
      fifo(/*autoinst*/
           // Outputs
           .dout                        (dout[FIFO_WIDTH-1:0]),
           .aempty                      (aempty),
           .afull                       (afull),
           .empty                       (empty),
           .full                        (full),
           .overflow                    (overflow),
           .underflow                   (underflow),
           .valid_entries               (valid_entries[L2_FIFO_WORDS:0]),
           // Inputs
           .clk                         (rd_clk),                // Templated
           .reset_n                     (reset_n),
           .init                        (init),                  // Templated
           .rd_en                       (rd_en),
           .wr_en                       (wr_en),
           .din                         (din[FIFO_WIDTH-1:0]));
    end
  endgenerate

`else

  generate
    if (FIFO_WORDS>10 && SAME_SYNC==1) begin: gp_fifo_sync
      /*gp_fifo_sync auto_template (
        .ENABLE_INIT_INPUT(1),
        .clk  (rd_clk),
        .init (init),
      );*/
      
      gp_fifo_sync #(/*autoinstparam*/
                           // Parameters
                     .ENABLE_INIT_INPUT (1),                     // Templated
                     .FIFO_WIDTH        (FIFO_WIDTH),
                     .FIFO_WORDS        (FIFO_WORDS),
                     .AFULL_THRESH      (AFULL_THRESH),
                     .AEMPTY_THRESH     (AEMPTY_THRESH),
                     .L2_FIFO_WORDS     (L2_FIFO_WORDS))
      fifo(/*autoinst*/
           // Outputs
           .dout                        (dout[FIFO_WIDTH-1:0]),
           .aempty                      (aempty),
           .afull                       (afull),
           .empty                       (empty),
           .full                        (full),
           .overflow                    (overflow),
           .underflow                   (underflow),
           .valid_entries               (valid_entries[L2_FIFO_WORDS:0]),
           // Inputs
           .clk                         (rd_clk),                // Templated
           .reset_n                     (reset_n),
           .init                        (init),                  // Templated
           .rd_en                       (rd_en),
           .wr_en                       (wr_en),
           .din                         (din[FIFO_WIDTH-1:0]));

    end else if (FIFO_WORDS*FIFO_WIDTH>1024 && SAME_SYNC==1) begin: gp_fifo_sync
      /*gp_fifo_sync auto_template (
        .ENABLE_INIT_INPUT(1),
        .clk  (rd_clk),
        .init (init),
      );*/
      
      gp_fifo_sync_width2 #(/*autoinstparam*/
                     // Parameters
                     .ENABLE_INIT_INPUT (1),                     // Templated
                     .FIFO_WIDTH        (FIFO_WIDTH),
                     .FIFO_WORDS        (FIFO_WORDS),
                     .AFULL_THRESH      (AFULL_THRESH),
                     .AEMPTY_THRESH     (AEMPTY_THRESH),
                     .L2_FIFO_WORDS     (L2_FIFO_WORDS))
      fifo(/*autoinst*/
           // Outputs
           .dout                        (dout[FIFO_WIDTH-1:0]),
           .aempty                      (aempty),
           .afull                       (afull),
           .empty                       (empty),
           .full                        (full),
           .overflow                    (overflow),
           .underflow                   (underflow),
           .valid_entries               (valid_entries[L2_FIFO_WORDS:0]),
           // Inputs
           .clk                         (rd_clk),                // Templated
           .reset_n                     (reset_n),
           .init                        (init),                  // Templated
           .rd_en                       (rd_en),
           .wr_en                       (wr_en),
           .din                         (din[FIFO_WIDTH-1:0]));

    end else if (SAME_SYNC==1) begin: gp_fifo_small

      /*gp_fifo_small2 auto_template (
        .ENABLE_INIT_INPUT(1),
        .clk(rd_clk),
        .init (init),       
      );*/
      gp_fifo_small2 #(/*autoinstparam*/
                       // Parameters
                       .ENABLE_INIT_INPUT(1),                    // Templated
                       .FIFO_WIDTH      (FIFO_WIDTH),
                       .FIFO_WORDS      (FIFO_WORDS),
                       .AFULL_THRESH    (AFULL_THRESH),
                       .AEMPTY_THRESH   (AEMPTY_THRESH),
                       .L2_FIFO_WORDS   (L2_FIFO_WORDS))
      fifo(/*autoinst*/
           // Outputs
           .dout                        (dout[FIFO_WIDTH-1:0]),
           .aempty                      (aempty),
           .afull                       (afull),
           .empty                       (empty),
           .full                        (full),
           .overflow                    (overflow),
           .underflow                   (underflow),
           .valid_entries               (valid_entries[L2_FIFO_WORDS:0]),
           // Inputs
           .clk                         (rd_clk),                // Templated
           .reset_n                     (reset_n),
           .init                        (init),                  // Templated
           .rd_en                       (rd_en),
           .wr_en                       (wr_en),
           .din                         (din[FIFO_WIDTH-1:0]));
    end
  endgenerate

`endif
  
endmodule
