// +FHDR----------------------------------------------------------------------------
// Project Name  : virtural_prj
// Author        : lidh
// Email         : lidh@innosilicon.com.cn
// Create On     : 2025/04/08 16:12
// Last Modified : 2025/04/08 16:12
// File Name     : atb_slice_sync.v
// Description   :
// 
// Copyright (c) 2025 Innosilicon.
// ALL RIGHTS RESERVED
// 
// ---------------------------------------------------------------------------------
// Modification History:
// Date         By              Version                 Change Description
// ---------------------------------------------------------------------------------
// 2025/04/08   lidh            1.0                     Original
// 
// -FHDR----------------------------------------------------------------------------

module atb_slice_sync
       #( parameter SLICE_NUM_ATB =0,
          parameter ATB_BYTES_WIDTH =4,
          parameter ATB_DATA_WIDTH =128)
(
/*autoarg*/
   // Outputs
   src_syncreq, src_atready, src_afvalid, dst_atvalid, dst_atid,
   dst_atdata, dst_atbytes, dst_afready,
   // Inputs
   src_atvalid, src_atid, src_atdata, src_atbytes, src_afready,
   resetn, dst_syncreq, dst_atready, dst_afvalid, clk
   );

input                   clk;                    // To atb_slice_u of cxatbsyncbridge_full.v
input                   resetn;                 // To atb_slice_u of cxatbsyncbridge_full.v

output                  dst_afready;            // From atb_slice_u of cxatbsyncbridge_full.v
output [ATB_BYTES_WIDTH-1:0] dst_atbytes;       // From atb_slice_u of cxatbsyncbridge_full.v
output [ATB_DATA_WIDTH-1:0] dst_atdata;         // From atb_slice_u of cxatbsyncbridge_full.v
output [6:0]            dst_atid;               // From atb_slice_u of cxatbsyncbridge_full.v
output                  dst_atvalid;            // From atb_slice_u of cxatbsyncbridge_full.v
output                  src_afvalid;            // From atb_slice_u of cxatbsyncbridge_full.v
output                  src_atready;            // From atb_slice_u of cxatbsyncbridge_full.v
output                  src_syncreq;            // From atb_slice_u of cxatbsyncbridge_full.v

input                   dst_afvalid;            // To atb_slice_u of cxatbsyncbridge_full.v
input                   dst_atready;            // To atb_slice_u of cxatbsyncbridge_full.v
input                   dst_syncreq;            // To atb_slice_u of cxatbsyncbridge_full.v
input                   src_afready;            // To atb_slice_u of cxatbsyncbridge_full.v
input [ATB_BYTES_WIDTH-1:0] src_atbytes;        // To atb_slice_u of cxatbsyncbridge_full.v
input [ATB_DATA_WIDTH-1:0] src_atdata;          // To atb_slice_u of cxatbsyncbridge_full.v
input [6:0]             src_atid;               // To atb_slice_u of cxatbsyncbridge_full.v
input                   src_atvalid;            // To atb_slice_u of cxatbsyncbridge_full.v
// End of automatics
genvar i;
generate if(SLICE_NUM_ATB ==0) begin:pass_through
 assign src_syncreq      =      dst_syncreq       ;             
 assign src_afvalid      =      dst_afvalid       ;             
 assign dst_afready      =      src_afready       ;             

 assign dst_atbytes      =      src_atbytes       ;        
 assign dst_atdata       =      src_atdata        ;         
 assign dst_atid         =      src_atid          ;             
 assign dst_atvalid      =      src_atvalid       ;             
 assign src_atready      =      dst_atready       ;             
            
end 
else begin:gen_slice
//internal signal
wire                      internal_afvalid 		 [SLICE_NUM_ATB:0] 		;
wire                      internal_atready 		 [SLICE_NUM_ATB:0] 		;
wire                      internal_syncreq 		 [SLICE_NUM_ATB:0] 		;
wire                      internal_afready 		 [SLICE_NUM_ATB:0] 		;
wire[ATB_BYTES_WIDTH-1:0] internal_atbytes 		 [SLICE_NUM_ATB:0] 		;
wire[ATB_DATA_WIDTH-1:0]  internal_atdata 		 [SLICE_NUM_ATB:0] 		;
wire[6:0]                 internal_atid 		 [SLICE_NUM_ATB:0] 		;
wire                      internal_atvalid 		 [SLICE_NUM_ATB:0] 		;

//src assign
assign src_afvalid           =  internal_afvalid[0];
assign internal_afready[0]   =  src_afready;
assign src_syncreq           =  internal_syncreq[0];

assign internal_atbytes[0]   =  src_atbytes;
assign internal_atdata[0]    =  src_atdata;
assign internal_atid[0]      =  src_atid;
assign internal_atvalid[0]   =  src_atvalid;

assign src_atready           =  internal_atready[0];



//dst assign
assign internal_afvalid[SLICE_NUM_ATB] = dst_afvalid;
assign dst_afready                     = internal_afready[SLICE_NUM_ATB];
assign internal_syncreq[SLICE_NUM_ATB] = dst_syncreq;

assign dst_atbytes                     = internal_atbytes[SLICE_NUM_ATB];
assign dst_atdata                      = internal_atdata[SLICE_NUM_ATB];
assign dst_atid                        = internal_atid[SLICE_NUM_ATB];
assign dst_atvalid                     = internal_atvalid[SLICE_NUM_ATB];
assign internal_atready[SLICE_NUM_ATB] = dst_atready;


  for(i=0; i<SLICE_NUM_ATB; i=i+1 ) begin:atb_slice
/*cxatbsyncbridge_full (
    .clkens   (1'b1),
    .clkenm   (1'b1),

    .csysreq   (1'b1),
    .cactive   (),
    .csysack   (),

    .\(.*\)s   (src_\1[]),
    .\(.*\)m   (dst_\1[]),
);
*/
    cxatbsyncbridge_full  
           #(   .ATB_BYTES_WIDTH (ATB_BYTES_WIDTH),
                .ATB_DATA_WIDTH  (ATB_DATA_WIDTH)     )  
    atb_slice_u (
                 // Outputs
                 .atreadys              (internal_atready[i]),           // Templated
                 .afvalids              (internal_afvalid[i]),           // Templated
                 .atvalidm              (internal_atvalid[i+1]),           // Templated
                 .atidm                 (internal_atid[i+1][6:0]),         // Templated
                 .atbytesm              (internal_atbytes[i+1][ATB_BYTES_WIDTH-1:0]), // Templated
                 .atdatam               (internal_atdata[i+1][ATB_DATA_WIDTH-1:0]), // Templated
                 .afreadym              (internal_afready[i+1]),           // Templated
                 .syncreqs              (internal_syncreq[i]),           // Templated
                 .csysack               (),                      // Templated
                 .cactive               (),                      // Templated
                 // Inputs
                 .clk                   (clk),
                 .clkens                (1'b1),                  // Templated
                 .resetn                (resetn),
                 .atvalids              (internal_atvalid[i]),           // Templated
                 .atids                 (internal_atid[i][6:0]),         // Templated
                 .atbytess              (internal_atbytes[i][ATB_BYTES_WIDTH-1:0]), // Templated
                 .atdatas               (internal_atdata[i][ATB_DATA_WIDTH-1:0]), // Templated
                 .afreadys              (internal_afready[i]),           // Templated
                 .clkenm                (1'b1),                  // Templated
                 .atreadym              (internal_atready[i+1]),           // Templated
                 .afvalidm              (internal_afvalid[i+1]),           // Templated
                 .syncreqm              (internal_syncreq[i+1]),           // Templated
                 .csysreq               (1'b1));                         // Templated



    end
end
endgenerate

endmodule
// Local Variables:
// verilog-library-directories:("./" "../coresight_component/*/*/verilog/" ) 
// verilog-auto-inst-param-value:t
// End:
