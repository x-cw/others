// --------------------------------------------------------------------------
//  The confidential and proprietary information contained in this file may
//  only be used by a person authorised under and to the extent permitted
//  by a subsisting licensing agreement from ARM Limited.
//
//                (C) COPYRIGHT 2004-2015 ARM Limited.
//                    ALL RIGHTS RESERVED
//
//  This entire notice must be reproduced on all copies of this file
//  and copies of this file may only be made by a person if such person is
//  permitted to do so under the terms of a subsisting license agreement
//  from ARM Limited.
// --------------------------------------------------------------------------
//
//    Checked In : $Date: 2014-08-14 16:01:35 +0100 (Thu, 14 Aug 2014) $
//    Revision   : $Revision: 39945 $
//    Release    : CoreSight-SoC-TM100-r3p2-00rel0
// ----------------------------------------------------------------------------
//  Purpose : Asynchronous JTAG TAP controller for JTAG-DP.
// ----------------------------------------------------------------------------


module cxdapswjdp_jtag_dp_protocol
  #(parameter IRLEN8 = 0)
  (
  // Inputs
  npotrst, ntrst, tck, tckn, tms, tdi, busack, busrdata, buscmp, buserror,
  busendcnt, cdbgpwrupack, csyspwrupack, cdbgrstack, jtagsel, jtagtlrreq,
  // Outputs
  tdo, ntdoen, busreq, buswrite, busabort, busaddr_31to24, busaddr_7to2,
  buswdata, busmode, busmask, bustrncnt, cdbgpwrupreq, csyspwrupreq,
  cdbgrstreq, jtagstate, jtagtop
  );

`include "cxdapswjdp_dp_apb_constants.v"
`include "cxdapswjdp_jtag_dp_constants.v"

// Determine Instruction Register Length, only 4 and 8 bits are supported
localparam JTAGDP_IRLEN = (IRLEN8 != 0) ? 8 : 4;

// Determing TAP IDCODE based on IR Length
localparam JTAGDP_DEVICEID = JTAGDP_IRLEN==8 ? JTAGDP_DEVICEID_IR8 :
                             JTAGDP_DEVICEID_IR4;
// State machine encodings
localparam JTAGDP_IDCODE = {{JTAGDP_IRLEN-3{1'b1}},JTAGDP_IDCODE_3B};
localparam JTAGDP_DPACC  = {{JTAGDP_IRLEN-3{1'b1}},JTAGDP_DPACC_3B};
localparam JTAGDP_APACC  = {{JTAGDP_IRLEN-3{1'b1}},JTAGDP_APACC_3B};
localparam JTAGDP_BYPASS = {{JTAGDP_IRLEN-3{1'b1}},JTAGDP_BYPASS_3B};
localparam JTAGDP_ABORT  = {{JTAGDP_IRLEN-3{1'b1}},JTAGDP_ABORT_3B};


// --------------------------------------------------------------------------
// Port Definitions
// --------------------------------------------------------------------------
  input          npotrst;        // JTAG Reset - (Pulsed once at PowerOn)

  input          ntrst;          // JTAG Reset - (External)
  input          tck;            // JTAG Test Clock
  input          tckn;           // Inverted JTAG Test Clock
  input          tms;            // JTAG Test Mode Select
  input          tdi;            // JTAG Test Data In

  input          busack;         // Bus Trasnaction Acknowledge
  input  [31:0]  busrdata;       // Bus read Data Port
  input          buscmp;         // Bus Pushed Verify/Find
  input          buserror;       // Bus Error
  input  [11:0]  busendcnt;      // Bus End Count

  input          cdbgpwrupack;   // Debug Power Domain up acknowledge
  input          csyspwrupack;   // System Power Domain up acknowledge
  input          cdbgrstack;     // Debug reset acknowledge to reset controller

  input          jtagsel;        // JTAG-DP selected
  input          jtagtlrreq;     // Tap state machine reset request

  output         tdo;            // JTAG Test Data Out
  output         ntdoen;         // JTAG Test Data Out Enable

  output         busreq;         // Bus Transaction Request
  output         buswrite;       // Bus write
  output         busabort;       // Bus abort
  output [31:24] busaddr_31to24; // Bus Address Port - AP Sel
  output [7:2]   busaddr_7to2;   // Bus Address Port - Bank/Reg Sel

  output [31:0]  buswdata;       // Bus write Data Port
  output [1:0]   busmode;        // Bus Mode
  output [3:0]   busmask;        // Bus Compare Mask
  output [11:0]  bustrncnt;      // Bus Transfer Cnt

  output         cdbgpwrupreq;   // Debug Power Domain up request
  output         csyspwrupreq;   // System Power Domain up request
  output         cdbgrstreq;     // Debug reset request to reset controller
  output [3:0]   jtagstate;      // JTAG TAP state machine
  output         jtagtop;        // JTAG-DP TAP controller in one of four top states
                                 // (TLR, rti, Sel-DR, Sel-IR)
// -------------------------------------------------------------------------
// Signal declarations
// -------------------------------------------------------------------------
  // I/O pins
  wire          npotrst;         // JTAG Reset - (Pulsed once at PowerOn)
  wire          ntrst;           // JTAG Reset - (External)
  wire          tck;             // JTAG Test Clock
  wire          tckn;            // invert tck clock for falling edge output
  wire          tms;             // JTAG Test Mode Select
  wire          tdi;             // JTAG Test Data In
  wire          busack;          // Bus Trasnaction Acknowledge
  wire   [31:0] busrdata;        // Bus read Data Port
  wire          buscmp;          // Bus Pushed Verify/Find
  wire          buserror;        // Bus Error
  wire   [11:0] busendcnt;       // Bus End Count
  wire          cdbgpwrupack;    // Debug Power Domain up acknowledge
  wire          csyspwrupack;    // System Power Domain up acknowledge
  wire          cdbgrstack;      // Debug reset acknowledge to reset controller
  wire          tdo;             // JTAG Test Data Out
  wire          busreq;          // Bus Transaction Request
  wire          buswrite;        // Bus write
  wire          busabort;        // Bus abort
  wire  [31:24] busaddr_31to24;  // Bus Address Port - AP Sel
  wire    [7:2] busaddr_7to2;    // Bus Address Port - Bank/Reg Sel
  wire   [31:0] buswdata;        // Bus write Data Port
  wire    [1:0] busmode;         // Bus Mode
  wire    [3:0] busmask;         // Bus Compare Mask
  wire   [11:0] bustrncnt;       // Bus Transfer Cnt
  wire          cdbgpwrupreq;    // Debug Power Domain up request
  reg           cdbgpwrupreq_int;// Debug Power Domain up request - internal version
  wire          csyspwrupreq;    // System Power Domain up request
  reg           csyspwrupreq_int;// System Power Domain up request - internal version
  wire          cdbgrstreq;      // Debug reset request to reset controller
  reg           cdbgrstreq_int;  // Debug reset request to reset controller - internal version
  wire    [3:0] jtagstate;              // JTAG TAP state machine

  // Internal signals
  reg     [3:0] jtag_curr;              // JTAG current state
  reg     [3:0] jtag_next_pre_rst;      // JTAG next state without external reset factored in
  wire    [3:0] jtag_next;              // JTAG next state
  reg     [JTAGDP_IRLEN-1:0] jtag_ir;   // JTAG Instruction register
  reg     [JTAGDP_IRLEN-1:0] jtag_ir_d; // JTAG IR DFF input
  reg           jtagir_en;              // JTAG IR DFF enable
  reg     [JTAGDP_IRLEN-1:0] jtag_sir;  // JTAG Scan instruction register
  reg     [JTAGDP_IRLEN-1:0] jtag_sir_d;// JTAG SIR DFF input
  reg           jtag_sir_en;            // JTAG SIR DFF enable
  reg    [34:0] jtag_sdr;               // JTAG Scan data register
  reg    [34:0] jtag_sdr_d;             // JTAG SDR DFF input
  reg           jtag_sdr_en;            // JTAG SDR DFF enable
  wire          tdo_instruction;        // Instruction tdo ouput
  reg           tdo_data;               // Data tdo output
  reg           tdo_di;                 // tdo DFF input
  reg           tdo_i;                  // tdo output
  wire          tdo_en_di;              // tdo Enable DFF input
  reg           tdo_eni;                // tdo output Enable
  reg           ap_abort;               // AP abort
  reg           ap_abort_d;             // AP abort DFF input
  reg           ap_abort_en;            // AP abort DFF enable
  wire    [1:0] trnmode;                // transfer mode
  reg     [1:0] trnmode_cdc_check;      // transfer mode
  wire    [3:0] mask_lane;              // mask lanes for compare operations
  reg     [3:0] mask_lane_cdc_check;    // mask lanes for compare operations
  wire          ctrl_en;                // control register enable
  wire   [11:0] trncnt;                 // transfer count
  reg    [11:0] trncnt_cdc_check;       // transfer count
  reg    [11:0] trncnt_d;               // transfer count DFF input
  reg           trncnt_en;              // transfer count DFF enable
  wire          stickystatus;           // Sticky status
  reg           stickycmp;              // Sticky compare register
  reg           stickycmp_d;            // Sticky compare DFF input
  reg           stickycmp_en;           // Sticky compare DFF enable
  reg           stickyerr;              // Sticky error register
  reg           stickyerr_d;            // Sticky error DFF input
  reg           stickyerr_en;           // Sticky error DFF enable
  wire          ap_dir;                 // AP access direction
  reg           ap_dir_cdc_check;       // AP access direction
  reg     [7:0] ap_sel;                 // AP access selection
  wire          ap_sel_en;              // AP selection enable
  reg     [3:0] ap_banksel;             // AP bank selection
  reg     [1:0] dp_addr;                // DP address
  reg     [1:0] rdmux;                  // read multiplexor
  reg     [1:0] rdmux_d;                // read multiplexor DFF input
  wire          rdmux_en;               // read multiplexor DFF enable
  reg           busreqi;                // bus request to APB interface
  wire          busreq_di;              // bus request DFF input
  reg           busreq_eni;             // bus request DFF enable
  wire   [31:0] bus_wdatai;             // bus request write holding register
  reg    [31:0] bus_wdatai_cdc_check;   // bus request write holding register
  wire          ap_acc_en;              // AP Access enable
  reg           face_rdycdri;           // interface ready @ CaptureDR
  wire          face_rdycdr_di;         // interface ready DFF input
  wire          face_rdycdr_eni;        // interface ready DFF enable
  reg           contdetect;             // continuation detection
  wire          ncont;                  // nCONT output bit
  wire    [2:0] ncont_vec;              // nCONT output bit vector
  reg           ncont_err;              // nCONT overrun detect
  reg           ncont_err_d;            // nCONT overrun DFF input
  reg           ncont_err_en;           // nCONT overrun DFF enable
  reg           transapdp;              // transaction to AP/DP
  wire          transapdp_d;            // transaction DFF input
  wire          transapdp_en;           // transaction DFF enable
  wire          dp_acc;                 // DP Access enable
  wire          ap_acc;                 // AP Access enable
  reg           iptr;                   // FIFO Pointer In
  wire          iptr_d;                 // FIFO Pointer In DFF input
  wire          iptr_en;                // FIFO Pointer In DFF enable
  reg           optr;                   // FIFO Pointer Out
  wire          optr_d;                 // FIFO Pointer Out DFF input
  wire          optr_en;                // FIFO Pointer Out DFF enable
  wire          e_ptr;                  // FIFO empty (write fifo)
  wire          fptr;                   // FIFO full


// -----------------------------------------------------------------------------
// Beginning of main code
// -----------------------------------------------------------------------------

// -----------------------------------------------------------------------------
// next state combinatorial logic for TAP state machine.
//  note that others/default case should never be reached.
// -----------------------------------------------------------------------------

  always @ (jtag_curr or tms)
    case (jtag_curr)
      JTAGDP_TLR  : jtag_next_pre_rst = tms ? JTAGDP_TLR : JTAGDP_RTI;
      JTAGDP_RTI  : jtag_next_pre_rst = tms ? JTAGDP_SDR : JTAGDP_RTI;
      JTAGDP_SDR  : jtag_next_pre_rst = tms ? JTAGDP_SIR : JTAGDP_CDR;
      JTAGDP_CDR  : jtag_next_pre_rst = tms ? JTAGDP_E1D : JTAGDP_SHD;
      JTAGDP_SHD  : jtag_next_pre_rst = tms ? JTAGDP_E1D : JTAGDP_SHD;
      JTAGDP_E1D  : jtag_next_pre_rst = tms ? JTAGDP_UDR : JTAGDP_PDR;
      JTAGDP_PDR  : jtag_next_pre_rst = tms ? JTAGDP_E2D : JTAGDP_PDR;
      JTAGDP_E2D  : jtag_next_pre_rst = tms ? JTAGDP_UDR : JTAGDP_SHD;
      JTAGDP_UDR  : jtag_next_pre_rst = tms ? JTAGDP_SDR : JTAGDP_RTI;
      JTAGDP_SIR  : jtag_next_pre_rst = tms ? JTAGDP_TLR : JTAGDP_CIR;
      JTAGDP_CIR  : jtag_next_pre_rst = tms ? JTAGDP_E1I : JTAGDP_SHIR;
      JTAGDP_SHIR : jtag_next_pre_rst = tms ? JTAGDP_E1I : JTAGDP_SHIR;
      JTAGDP_E1I  : jtag_next_pre_rst = tms ? JTAGDP_UIR : JTAGDP_PIR;
      JTAGDP_PIR  : jtag_next_pre_rst = tms ? JTAGDP_E2I : JTAGDP_PIR;
      JTAGDP_E2I  : jtag_next_pre_rst = tms ? JTAGDP_UIR : JTAGDP_SHIR;
      JTAGDP_UIR  : jtag_next_pre_rst = tms ? JTAGDP_SDR : JTAGDP_RTI;
       default : jtag_next_pre_rst = 4'bxxxx;
    endcase

  assign        jtag_next = jtagtlrreq ? JTAGDP_TLR : jtag_next_pre_rst;

// -----------------------------------------------------------------------------
// state machine register for TAP
// -----------------------------------------------------------------------------
  always @ (negedge ntrst or posedge tck)
    if (!ntrst)
      jtag_curr <= JTAGDP_TLR;
    else if (jtagsel)
      jtag_curr <= jtag_next;

// -----------------------------------------------------------------------------
// Output for SWJ-DP indicating TAP state machine
// -----------------------------------------------------------------------------

    assign jtagstate = jtag_curr;

// -----------------------------------------------------------------------------
// Output for SWJ-DP indicating TAP in TLR, rti, Sel-DR or Sel-IR states
// -----------------------------------------------------------------------------

    assign jtagtop = (jtag_curr==JTAGDP_TLR | jtag_curr==JTAGDP_RTI |
                      jtag_curr==JTAGDP_SDR | jtag_curr==JTAGDP_SIR);

// -----------------------------------------------------------------------------
// JTAG Shift Instruction Register
//  capture the instruction register contents
// -----------------------------------------------------------------------------
  always @ (jtag_curr or tdi or jtag_sir)
    case (jtag_curr)
      JTAGDP_TLR : begin
        jtag_sir_d  = {{(JTAGDP_IRLEN-1){1'b0}}, 1'b1};
        jtag_sir_en = 1'b1;
      end
      JTAGDP_CIR : begin
        jtag_sir_d  = {{(JTAGDP_IRLEN-1){1'b0}}, 1'b1};
        jtag_sir_en = 1'b1;
      end
      JTAGDP_SHIR : begin
        jtag_sir_d  = {tdi,jtag_sir[JTAGDP_IRLEN-1:1]};
        jtag_sir_en = 1'b1;
      end
      JTAGDP_E2D,
      JTAGDP_E1D,
      JTAGDP_SHD,
      JTAGDP_PDR,
      JTAGDP_SIR,
      JTAGDP_UDR,
      JTAGDP_CDR,
      JTAGDP_SDR,
      JTAGDP_E2I,
      JTAGDP_E1I,
      JTAGDP_PIR,
      JTAGDP_RTI,
      JTAGDP_UIR: begin
        jtag_sir_d  = {JTAGDP_IRLEN{1'b0}};
        jtag_sir_en = 1'b0;
      end
      default: begin
        jtag_sir_d  = {JTAGDP_IRLEN{1'bx}};
        jtag_sir_en = 1'bx;
      end
    endcase

  always @ (negedge ntrst or posedge tck)
    if (!ntrst)
      jtag_sir <= {JTAGDP_IRLEN{1'b0}};
    else if (jtag_sir_en)
      jtag_sir <= jtag_sir_d;

  always @ (jtag_curr or jtag_sir)
    case (jtag_curr)
      JTAGDP_TLR : begin
        jtag_ir_d  = JTAGDP_IDCODE;
        jtagir_en = 1'b1;
      end
      JTAGDP_UIR : begin
        jtag_ir_d  = jtag_sir;
        jtagir_en = 1'b1;
      end
      JTAGDP_E2D,
      JTAGDP_E1D,
      JTAGDP_SHD,
      JTAGDP_PDR,
      JTAGDP_SIR,
      JTAGDP_UDR,
      JTAGDP_CDR,
      JTAGDP_SDR,
      JTAGDP_E2I,
      JTAGDP_E1I,
      JTAGDP_SHIR,
      JTAGDP_PIR,
      JTAGDP_RTI,
      JTAGDP_CIR: begin
        jtag_ir_d  = {JTAGDP_IRLEN{1'b0}};
        jtagir_en = 1'b0;
      end
      default: begin
        jtag_ir_d  = {JTAGDP_IRLEN{1'bx}};
        jtagir_en = 1'bx;
      end
    endcase

  always @ (negedge ntrst or posedge tck)
    if (!ntrst)
      jtag_ir <= JTAGDP_IDCODE;
    else if (jtagir_en)
      jtag_ir <= jtag_ir_d;

  assign tdo_instruction = jtag_sir[0];

// -----------------------------------------------------------------------------
// JTAG Shift Data Register
//  Move input data Mux to out in tdo_data. This allows
//  the SHD state to collapse to a single entry.
// -----------------------------------------------------------------------------
  always @ (jtag_curr or jtag_ir or busrdata or ncont or rdmux or
            ap_sel or ap_banksel or trncnt or mask_lane or
            stickycmp or stickyerr or trnmode or ncont_err or contdetect or
            tdi or jtag_sdr or transapdp or csyspwrupack or csyspwrupreq_int or
            cdbgpwrupack or cdbgpwrupreq_int or cdbgrstack or cdbgrstreq_int)
    case (jtag_curr)
      JTAGDP_TLR : begin
        jtag_sdr_d  = {35{1'b0}};
        jtag_sdr_en = 1'b1;
      end
      JTAGDP_CDR : begin
        if (jtag_ir[JTAGDP_IRLEN-1:3] == {JTAGDP_IRLEN-3{1'b1}})
          case (jtag_ir[2:0])
            JTAGDP_IDCODE_3B : begin
              jtag_sdr_d  = {JTAGDP_DEVICEID,3'b000};
              jtag_sdr_en = 1'b1;
            end
            JTAGDP_APACC_3B,
            JTAGDP_DPACC_3B : begin
              if (transapdp==JTAGDP_AP)
                begin
                  jtag_sdr_d  = {busrdata,1'b0,~ncont,ncont};
                  jtag_sdr_en = 1'b1;
                end
              else
                begin
                  case (rdmux)
                    JTAGDP_MUXADDR : begin
                      jtag_sdr_d  = {ap_sel,8'h00,8'h00,ap_banksel,
                                   4'h0,1'b0,~ncont,ncont};
                      jtag_sdr_en = 1'b1;
                    end
                    JTAGDP_MUXSTAT : begin
                      jtag_sdr_d  = {csyspwrupack, csyspwrupreq_int,
                                   cdbgpwrupack, cdbgpwrupreq_int,
                                   cdbgrstack,   cdbgrstreq_int,
                                   2'b00,trncnt,mask_lane,2'b00,
                                   stickyerr,stickycmp,trnmode,
                                   ncont_err,contdetect,1'b0,~ncont,ncont};
                      jtag_sdr_en = 1'b1;
                    end
                    JTAGDP_MUXRBUF,2'b00 : begin
                      jtag_sdr_d  = {{32{1'b0}},1'b0,~ncont,ncont};
                      jtag_sdr_en = 1'b1;
                    end
                    default : begin
                      jtag_sdr_d  = {35{1'bx}};
                      jtag_sdr_en = 1'bx;
                    end
                  endcase
                end
            end
            JTAGDP_BYPASS_3B,
            JTAGDP_ABORT_3B,
            JTAGDP_UNK0_3B,
            JTAGDP_UNK1_3B,
            JTAGDP_UNK2_3B : begin
              jtag_sdr_d  = {35{1'b0}};
              jtag_sdr_en = 1'b1;
            end
            default: begin
              jtag_sdr_d  = {35{1'bx}};
              jtag_sdr_en = 1'bx;
            end
          endcase
        else
        begin
          jtag_sdr_d  = {35{1'b0}};
          jtag_sdr_en = 1'b1;
        end
      end
      JTAGDP_SHD : begin
        jtag_sdr_d  = {tdi,jtag_sdr[34:1]};
        jtag_sdr_en = (jtag_ir != JTAGDP_DPACC & jtag_ir != JTAGDP_APACC) |
                    (jtag_ir== JTAGDP_DPACC | jtag_ir== JTAGDP_APACC);
      end
      JTAGDP_E2D,
      JTAGDP_E1D,
      JTAGDP_PDR,
      JTAGDP_SIR,
      JTAGDP_UDR,
      JTAGDP_SDR,
      JTAGDP_E2I,
      JTAGDP_E1I,
      JTAGDP_SHIR,
      JTAGDP_PIR,
      JTAGDP_RTI,
      JTAGDP_UIR,
      JTAGDP_CIR: begin
        // JTAGDP_UDR performed in separate processes
        jtag_sdr_d  = {35{1'b0}};
        jtag_sdr_en = 1'b0;
      end
      default: begin
        // JTAGDP_UDR performed in separate processes
        jtag_sdr_d  = {35{1'bx}};
        jtag_sdr_en = 1'bx;
      end
    endcase

  always @ (negedge npotrst or posedge tck)
    if (!npotrst)
      jtag_sdr <= {35{1'b0}};
    else if (jtag_sdr_en)
      jtag_sdr <= jtag_sdr_d;

// -----------------------------------------------------------------------------
// tdo_data output mux
// -----------------------------------------------------------------------------
  always @ (jtag_ir or jtag_sdr)
  begin
    // 4'b1xxx or 8'b11111xxx
    if (jtag_ir[(JTAGDP_IRLEN-1):3] == {(JTAGDP_IRLEN-3){1'b1}})
    begin
      case (jtag_ir[2:0])
        JTAGDP_IDCODE_3B : tdo_data = jtag_sdr[3];   // 32-bit register
        JTAGDP_ABORT_3B,
        JTAGDP_DPACC_3B,
        JTAGDP_APACC_3B  : tdo_data = jtag_sdr[0];   // 35-bit registers
        JTAGDP_BYPASS_3B,
        JTAGDP_UNK0_3B,
        JTAGDP_UNK1_3B,
        JTAGDP_UNK2_3B   : tdo_data = jtag_sdr[34];  // 1-bit  register
        default : tdo_data = 1'bx;
      endcase
    end
    else
    begin
      tdo_data = jtag_sdr[34];
    end
  end

// -----------------------------------------------------------------------------
// tdo Output - Falling edge
// -----------------------------------------------------------------------------
  always @ (jtag_curr or tdo_instruction or tdo_data)
    case (jtag_curr)
      JTAGDP_SHIR,JTAGDP_E1I : tdo_di = tdo_instruction;
      JTAGDP_SHD,JTAGDP_E1D : tdo_di = tdo_data;
      JTAGDP_E2D,JTAGDP_PDR,
      JTAGDP_SIR,JTAGDP_UDR,
      JTAGDP_CDR,JTAGDP_SDR,
      JTAGDP_E2I,JTAGDP_PIR,
      JTAGDP_RTI,JTAGDP_UIR,
      JTAGDP_CIR,JTAGDP_TLR : tdo_di = 1'b1;
      default   : tdo_di = 1'bx;
    endcase

  // IEEE JTAG specification requires tdo changes on the falling edge of tck.
  always @ (negedge npotrst or posedge tckn)
    if (!npotrst)
      tdo_i <= 1'b0;
    else
      tdo_i <= tdo_di;

  assign tdo = tdo_i;

// -----------------------------------------------------------------------------
// tdo Output Enable - Falling edge
// -----------------------------------------------------------------------------
  assign tdo_en_di = (jtag_curr==JTAGDP_SHD | jtag_curr==JTAGDP_SHIR);

  // IEEE JTAG specification requires tdo changes on the falling edge of tck.
  always @ (negedge npotrst or posedge tckn)
    if (!npotrst)
      tdo_eni <= 1'b0;
    else
      tdo_eni <= tdo_en_di;

  assign ntdoen = ~tdo_eni;

// -----------------------------------------------------------------------------
// DP/AP access controls
// -----------------------------------------------------------------------------
  assign dp_acc = jtag_curr==JTAGDP_UDR & jtag_ir==JTAGDP_DPACC & face_rdycdri;
  assign ap_acc = jtag_curr==JTAGDP_UDR & jtag_ir==JTAGDP_APACC & face_rdycdri;

// -----------------------------------------------------------------------------
// Shift register read mux selector
// -----------------------------------------------------------------------------
  assign rdmux_en = dp_acc;

  always @ (jtag_sdr)
    case (jtag_sdr[2:1])
      JTAGDP_ADDR   : rdmux_d  = JTAGDP_MUXADDR;
      JTAGDP_STAT   : rdmux_d  = JTAGDP_MUXSTAT;
      2'b00,
      2'b11   : rdmux_d  = JTAGDP_MUXRBUF;
      default : rdmux_d  = 2'bxx;
    endcase

  always @ (negedge npotrst or posedge tck)
    if (!npotrst)
      rdmux <= JTAGDP_MUXRBUF;
    else if (rdmux_en)
      rdmux <= rdmux_d;

// --=========================================================================--
// JTAG DAP register interface
// --=========================================================================--

// -----------------------------------------------------------------------------
// CaptureDR ready status - as seen by external JTAG capture.
// -----------------------------------------------------------------------------
  assign face_rdycdr_di  = ~ncont;
  assign face_rdycdr_eni = jtag_curr==JTAGDP_CDR;

  always @ (negedge npotrst or posedge tck)
    if (!npotrst)
      face_rdycdri <= 1'b0;
    else if (face_rdycdr_eni)
      face_rdycdri <= face_rdycdr_di;

// -----------------------------------------------------------------------------
// nCONT Stickybit
// -----------------------------------------------------------------------------
  always @ (contdetect or dp_acc or jtag_curr or jtag_ir or jtag_sdr or
            ncont_err or ncont)
    if (dp_acc)
      begin
        ncont_err_d  = 1'b0;
        ncont_err_en = (jtag_sdr[4] | ~jtag_sdr[3]) & ncont_err &
                     jtag_sdr[2:1]==JTAGDP_CTRL & jtag_sdr[0]==JTAGDP_DAPW;
      end
    else
      begin
        ncont_err_d  = 1'b1;
        ncont_err_en = contdetect & ncont & ~ncont_err & jtag_curr==JTAGDP_CDR &
                     (jtag_ir==JTAGDP_APACC | jtag_ir==JTAGDP_DPACC);
      end

  always @ (negedge npotrst or posedge tck)
    if (!npotrst)
      ncont_err <= 1'b0;
    else if (ncont_err_en)
      ncont_err <= ncont_err_d;

// -----------------------------------------------------------------------------
// abort register
// -----------------------------------------------------------------------------
  always @ (jtag_curr or jtag_ir or ap_abort or busreqi or busack)
    if (jtag_ir==JTAGDP_ABORT & jtag_curr==JTAGDP_UDR)
      begin
        ap_abort_d  = 1'b1;
        ap_abort_en = busreqi & ~busack;
      end
    else
      begin
        ap_abort_d  = 1'b0;
        ap_abort_en = ap_abort & busack;
      end

  always @ (negedge npotrst or posedge tck)
    if (!npotrst)
      ap_abort <= 1'b0;
    else if (ap_abort_en)
      ap_abort <= ap_abort_d;

// -----------------------------------------------------------------------------
// Address register
// -----------------------------------------------------------------------------
  assign ap_sel_en = dp_acc & jtag_sdr[2:1]==JTAGDP_ADDR & jtag_sdr[0]==JTAGDP_DAPW;

  always @ (negedge npotrst or posedge tck)
    if (!npotrst)
      begin
        ap_sel     <= 8'b00000000;
        ap_banksel <= 4'b0000;
      end
    else if (ap_sel_en)
      begin
        ap_sel     <= jtag_sdr[34:27];
        ap_banksel <= jtag_sdr[10:7];
      end

// -----------------------------------------------------------------------------
// control register
// -----------------------------------------------------------------------------
  assign ctrl_en = dp_acc & jtag_sdr[2:1]==JTAGDP_CTRL & jtag_sdr[0]==JTAGDP_DAPW;

  always @ (negedge npotrst or posedge tck)
    if (!npotrst)
      begin
        contdetect   <= 1'b0;
         trnmode_cdc_check       <= 2'b00;
         mask_lane_cdc_check      <= 4'b0000;
        cdbgpwrupreq_int <= 1'b0;
        csyspwrupreq_int <= 1'b0;
        cdbgrstreq_int   <= 1'b0;
      end
    else if (ctrl_en)
      begin
        contdetect   <= jtag_sdr[3];
         trnmode_cdc_check       <= jtag_sdr[6:5];
         mask_lane_cdc_check      <= jtag_sdr[14:11];
        cdbgrstreq_int   <= jtag_sdr[29];
        csyspwrupreq_int <= jtag_sdr[33];
        cdbgpwrupreq_int <= jtag_sdr[31];
      end
  assign cdbgpwrupreq = cdbgpwrupreq_int;
  assign csyspwrupreq = csyspwrupreq_int;
  assign cdbgrstreq   = cdbgrstreq_int;

// -----------------------------------------------------------------------------
// Transaction count register
// -----------------------------------------------------------------------------
  always @ (jtag_curr or jtag_ir or face_rdycdri or jtag_sdr or busack or
            busendcnt or busreqi)
    if (jtag_curr==JTAGDP_UDR & jtag_ir==JTAGDP_DPACC & face_rdycdri)
      begin
        trncnt_d  = jtag_sdr[26:15];
        trncnt_en = jtag_sdr[2:1]==JTAGDP_CTRL & jtag_sdr[0]==JTAGDP_DAPW;
      end
    else
      begin
        trncnt_d  = busendcnt;
        trncnt_en = busack & busreqi;
      end

  always @ (negedge npotrst or posedge tck)
    if (!npotrst)
       trncnt_cdc_check  <= 12'b000000000000;
    else if (trncnt_en)
       trncnt_cdc_check  <= trncnt_d;

// -----------------------------------------------------------------------------
// APB Access register
// -----------------------------------------------------------------------------
  assign ap_acc_en = ap_acc & ~stickystatus;

  always @ (negedge npotrst or posedge tck)
    if (!npotrst)
      begin
         bus_wdatai_cdc_check  <= 32'h00000000;
        dp_addr    <= 2'b00;
         ap_dir_cdc_check      <= 1'b0;
      end
    else if (ap_acc_en)
      begin
         bus_wdatai_cdc_check  <= jtag_sdr[34:3];
        dp_addr    <= jtag_sdr[2:1];
         ap_dir_cdc_check      <= (~jtag_sdr[0]);
      end

// -----------------------------------------------------------------------------
// APB write buffer Access register
// -----------------------------------------------------------------------------
  // In Pointer
  assign iptr_en = ap_acc & ~stickystatus & cdbgpwrupack & cdbgpwrupreq_int;
  assign iptr_d  = ~iptr;

  always @ (negedge npotrst or posedge tck)
    if (!npotrst)
      iptr <= 1'b0;
    else if (iptr_en)
      iptr <= iptr_d;

  // Out Pointer
  assign optr_en = busreqi & busack;
  assign optr_d  = ~optr;

  always @ (negedge npotrst or posedge tck)
    if (!npotrst)
      optr <= 1'b0;
    else if (optr_en)
      optr <= optr_d;

  // Empty
  assign e_ptr = iptr==optr;

  // Full
  assign fptr = iptr!=optr;

// -----------------------------------------------------------------------------
// Interface not ready to continue.
//  if read outstanding then wait on FIFO not empty.
//  if write outstanding then wait if write-buffer is full.
//  if switching to DPACC, drain APACC write-buffer before continuing.
// -----------------------------------------------------------------------------
  assign ncont_vec = {// DP access must wait for transaction buffer to clear.
                     jtag_ir==JTAGDP_DPACC & ~e_ptr,
                     // stall write if transaction buffer is full.
                     jtag_ir==JTAGDP_APACC &  fptr &  ap_dir &
                       // exclusion to this rule is if fptr will be cleared.
                       ~(optr_en & ~iptr_en & optr_d==iptr),
                     // stall read when buffer not-empty.
                     jtag_ir==JTAGDP_APACC & ~e_ptr & ~ap_dir &
                       // exclusion to this rule is if e_ptr will be set.
                       ~(optr_en & ~iptr_en & optr_d==iptr)};

  assign ncont = |ncont_vec;

// -----------------------------------------------------------------------------
// Sticky Compare
// -----------------------------------------------------------------------------
  always @ (buscmp or busack or stickycmp or busreqi or jtag_curr or
            jtag_ir or face_rdycdri or jtag_sdr or trnmode)
    begin
      stickycmp_d  = 1'b0;
      stickycmp_en = 1'b0;
      if (busack & busreqi)
        begin
          stickycmp_d  = 1'b1;
          stickycmp_en = (buscmp & trnmode==DAP_M_FIND) |
                        (!buscmp & trnmode==DAP_M_VERIFY);
        end
      else if (jtag_curr==JTAGDP_UDR & jtag_ir==JTAGDP_DPACC & face_rdycdri)
        if (jtag_sdr[2:1]==JTAGDP_CTRL & jtag_sdr[0]==JTAGDP_DAPW)
          begin
            // Stickycmpclr
            stickycmp_d  = 1'b0;
            stickycmp_en = jtag_sdr[7] & stickycmp;
          end
    end

  always @ (negedge npotrst or posedge tck)
    if (!npotrst)
      stickycmp <= 1'b0;
    else if (stickycmp_en)
      stickycmp <= stickycmp_d;

// -----------------------------------------------------------------------------
// Sticky Error
// -----------------------------------------------------------------------------
  always @ (buserror or busack or stickyerr or busreqi or jtag_curr or
            jtag_ir or face_rdycdri or jtag_sdr or ap_acc or e_ptr or
            cdbgpwrupack or cdbgpwrupreq_int)
    begin
      stickyerr_d  = 1'b0;
      stickyerr_en = 1'b0;
      if (busack & busreqi)
        begin
          stickyerr_d  = 1'b1;
          stickyerr_en = buserror;
        end
      else if (ap_acc & e_ptr)
        begin
          stickyerr_d  = 1'b1;
          stickyerr_en = ~stickyerr & ~(cdbgpwrupack & cdbgpwrupreq_int);
        end
      else if (jtag_curr==JTAGDP_UDR & jtag_ir==JTAGDP_DPACC & face_rdycdri)
        if (jtag_sdr[2:1]==JTAGDP_CTRL & jtag_sdr[0]==JTAGDP_DAPW)
          begin
            // Stickyerrclr
            stickyerr_d  = 1'b0;
            stickyerr_en = jtag_sdr[8] & stickyerr;
          end
    end

  always @ (negedge npotrst or posedge tck)
    if (!npotrst)
      stickyerr <= 1'b0;
    else if (stickyerr_en)
      stickyerr <= stickyerr_d;

// -----------------------------------------------------------------------------
// sticky_status
// -----------------------------------------------------------------------------
  assign stickystatus = stickycmp | stickyerr | (contdetect & ncont_err);

// --=========================================================================--
// Bus Interface to APB port.
// --=========================================================================--

// -----------------------------------------------------------------------------
// Generate APB Request
// -----------------------------------------------------------------------------
  always @ (stickystatus or ap_acc or busack or busreqi or
            e_ptr or cdbgpwrupack or cdbgpwrupreq_int)
    if (busreqi)
      begin
        busreq_eni = busack;
      end
    else if ((ap_acc & e_ptr) | ~e_ptr)
      begin
        busreq_eni = ~stickystatus & ~busack &
                    cdbgpwrupack & cdbgpwrupreq_int;
      end
    else
      begin
        busreq_eni = 1'b0;
      end

  assign busreq_di = (busreqi & ~busack) |
                    ((ap_acc | ~e_ptr) & ~stickystatus & ~busack &
                     cdbgpwrupack & cdbgpwrupreq_int);

  always @ (negedge npotrst or posedge tck)
    if (!npotrst)
      busreqi <= 1'b0;
    else if (busreq_eni)
      busreqi <= busreq_di;

// -----------------------------------------------------------------------------
// JTAG_IR may have been changed between APACC and DPACC,
//  so cache the access type.
// -----------------------------------------------------------------------------
  assign transapdp_d  = jtag_ir==JTAGDP_APACC ? JTAGDP_AP : JTAGDP_DP;
  assign transapdp_en = jtag_curr==JTAGDP_UDR & face_rdycdri;

  always @ (negedge npotrst or posedge tck)
    if (!npotrst)
      transapdp <= 1'b0;
    else if (transapdp_en)
      transapdp <= transapdp_d;

// -----------------------------------------------------------------------------
// APB outputs
// -----------------------------------------------------------------------------
  assign busreq         = busreq_di;
  assign busaddr_31to24 = ap_sel;
  assign busaddr_7to2   = {ap_banksel, dp_addr};
  assign buswdata       = bus_wdatai;
  assign busabort       = busreq_di ? ap_abort : 1'b0;
  assign buswrite       = ap_dir;
  assign busmode        = trnmode;
  assign busmask        = mask_lane;
  assign bustrncnt      = trncnt;


`ifdef ARM_ASSERT_ON

  // ntrst must be pulsed for simulation to run correctly.
  assert_never_unknown #(`OVL_ERROR, 4, `OVL_ASSERT, "ntrst must be pulsed for simulation to run correctly.")
  jtagdp_ntrst(
               .clk       (tck),
               .reset_n   (ntrst),
               .qualifier (1'b1),
               .test_expr (jtag_curr));

  // Initialise transfer counter via software before using APACC interface.
  assert_never_unknown #(`OVL_ERROR, 12, `OVL_ASSERT, "Initialise transfer counterbefore using APACC interface.")
  jtagdp_trncnt(
                .clk       (tck),
                .reset_n   (npotrst),
                .qualifier (busreq),
                .test_expr ({trncnt}));

  // Initialise address register via software before using APACC interface.
  assert_never_unknown #(`OVL_ERROR, 12, `OVL_ASSERT, "Initialise address register before using APACC interface.")
  jtagdp_apsel(
               .clk       (tck),
               .reset_n   (npotrst),
               .qualifier (busreq),
               .test_expr ({ap_sel,ap_banksel}));

  // read_mux must not be x during transaction.
  assert_never_unknown #(`OVL_ERROR, 2, `OVL_ASSERT, "read_mux must not be x during transaction.")
  jtagdp_rdmux(
               .clk       (tck),
               .reset_n   (npotrst),
               .qualifier (jtag_curr==JTAGDP_CDR&jtag_ir==JTAGDP_DPACC),
               .test_expr (rdmux));

  // FIFO full has been pushed.
  assert_never #(`OVL_ERROR, `OVL_ASSERT, "FIFO full has been pushed.")
    fifofull_check(tck, npotrst, iptr_en & fptr);

  // FIFO empty has been popped.
  assert_never #(`OVL_ERROR, `OVL_ASSERT, "FIFO empty has been popped.")
    fifoempty_check(tck, npotrst, optr_en & e_ptr);

  // Incorrectly application of busreq controls.
  assert_never #(`OVL_ERROR, `OVL_ASSERT, "Incorrectly application of busreq controls.")
    busreq_check(tck, npotrst, busreq_eni & (busreq_di==busreqi));

  // ncont vector must be exclusive.
  assert_never_unknown #(`OVL_ERROR, 3, `OVL_ASSERT, "ncont vector must be exclusive.")
    ncont_exclusive(tck, npotrst, 1'b1, ncont_vec);

  // FIFO cannot not be incremented and decremented in same cycle.
  assert_never #(`OVL_ERROR, `OVL_ASSERT, "FIFO cannot not be incremented and decremented in same cycle.")
    fifoctrl_check(tck, npotrst, iptr_en & optr_en & ~stickystatus);

  reg  [8*20:0] mnemonic;

  always @ (jtag_curr)
    case (jtag_curr)
      JTAGDP_TLR : mnemonic = {"TLR"};
      JTAGDP_RTI : mnemonic = {"rti"};
      JTAGDP_SDR : mnemonic = {"SDR"};
      JTAGDP_CDR : mnemonic = {"cdr"};
      JTAGDP_SHD : mnemonic = {"SHD"};
      JTAGDP_E1D : mnemonic = {"E1D"};
      JTAGDP_PDR : mnemonic = {"PDR"};
      JTAGDP_E2D : mnemonic = {"E2D"};
      JTAGDP_UDR : mnemonic = {"udr"};
      JTAGDP_SIR : mnemonic = {"SIR"};
      JTAGDP_CIR : mnemonic = {"cir"};
      JTAGDP_SHIR : mnemonic = {"SHIR"};
      JTAGDP_E1I : mnemonic = {"E1I"};
      JTAGDP_PIR : mnemonic = {"PIR"};
      JTAGDP_E2I : mnemonic = {"E2I"};
      JTAGDP_UIR : mnemonic = {"uir"};
    endcase

`endif

`ifdef ARM_CDC_ON
  cdc_connect #(31,0) u_cdc_buswdatai(
                                     .clk_launch(tck),
                                     .clk_capture(cxdapswjdp.u_cxdapswjdp_dapclk.u_cxdapswjdp_sw_dp_apb_if.dapclk),
                                     .d_in(bus_wdatai_cdc_check),
                                     .d_out_async(bus_wdatai)
                                     );
`else
  assign        bus_wdatai = bus_wdatai_cdc_check;
`endif
`ifdef ARM_CDC_ON
  cdc_connect #(3,0) u_cdc_masklane(
                                   .clk_launch(tck),
                                   .clk_capture(cxdapswjdp.u_cxdapswjdp_dapclk.u_cxdapswjdp_sw_dp_apb_if.dapclk),
                                   .d_in(mask_lane_cdc_check),
                                   .d_out_async(mask_lane)
                                   );
`else
  assign        mask_lane = mask_lane_cdc_check;
`endif
`ifdef ARM_CDC_ON
  cdc_connect #(1,0) u_cdc_trnmode(
                                  .clk_launch(tck),
                                  .clk_capture(cxdapswjdp.u_cxdapswjdp_dapclk.u_cxdapswjdp_sw_dp_apb_if.dapclk),
                                  .d_in(trnmode_cdc_check),
                                  .d_out_async(trnmode)
                                  );
`else
  assign        trnmode = trnmode_cdc_check;
`endif
`ifdef ARM_CDC_ON
  cdc_connect u_cdc_apdir(
                         .clk_launch(tck),
                         .clk_capture(cxdapswjdp.u_cxdapswjdp_dapclk.u_cxdapswjdp_sw_dp_apb_if.dapclk),
                         .d_in(ap_dir_cdc_check),
                         .d_out_async(ap_dir)
                         );
`else
  assign        ap_dir = ap_dir_cdc_check;
`endif
`ifdef ARM_CDC_ON
  cdc_connect #(11,0) u_cdc_trncnt(
                                  .clk_launch(tck),
                                  .clk_capture(cxdapswjdp.u_cxdapswjdp_dapclk.u_cxdapswjdp_sw_dp_apb_if.dapclk),
                                  .d_in(trncnt_cdc_check),
                                  .d_out_async(trncnt)
                                  );
`else
  assign        trncnt = trncnt_cdc_check;
`endif
endmodule
