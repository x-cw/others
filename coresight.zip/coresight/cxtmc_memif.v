//----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2009-2010 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//    Checked In :  2010-06-11 09:11:07 +0530 (Fri, 11 Jun 2010) 
//    Revision   :  8038 
//    Release    : TM961-BU-50000-r0p0-00rel0
//
//----------------------------------------------------------------------------
// Purpose : This Memory Interface writes the data from Write
//         : Buffer into Memory and reads the data out to Unformatter OR
//         : APB Read FIFO
//----------------------------------------------------------------------------

module cxtmc_memif
  #(
    // TMC Configuration
    parameter CXTMC_ATBM_AXIM_CFG       = 0, 
    // Size of external SRAM in 32-bit words
    parameter CXTMC_MEM_SIZE            = 31'h00000100,
    // Width of ATB Bus - and is half of Memory width
    parameter CXTMC_ATB_DATA_WIDTH      = 32,
    // Width of the Memory address in words - this depends on Memory size
    // and Memory width
    parameter CXTMC_MEM_ADDR_WIDTH      = 27,
    // Width of the memory address in bytes
    parameter CXTMC_MEM_BYTE_ADDR_WIDTH = 29,
    // Defines the Writer Buffer data width
    parameter CXTMC_WB_DATA_WIDTH       = 64,
    // Width of fill-level signals
    parameter CXTMC_FILL_LEVEL_WIDTH = 27)
  (
  // Clock
  input wire                                      cxtmc_clk,

  // Reset
  input wire                                      RESETn,

  // read data from memory
  input wire        [2*CXTMC_ATB_DATA_WIDTH -1:0] MEMQ,

  // write data from write 
  // buffer
  input wire            [CXTMC_WB_DATA_WIDTH-1:0] wb_data,

  // Write Buffer request - Data would be valid next clock after request is 
  // accepted
  input wire                                      wb_req_valid,

  // read buffer request 
  input wire                                      rb_req_valid,

  // read pointer write request from APB
  input wire                                      rrp_wr_en,

  // write pointer write request from APB
  input wire                                      rwp_wr_en,

  // Data from APB
  input wire                               [31:0] apb_wdata,

  // Formatter is in Circular Buffer Mode
  input wire                                      circ_buf_mode,

  // Unformatter is enabled
  input wire                                      unformatter_en,

  // Unformatter pilelines empty
  input wire                                      unformatter_empty,

  // APB Read FIFO indicating that data read is all sent to APB and Read Pointer
  // Increment can happen
  input wire                                      apb_read_fifo_rrp_en,

  // All Read/Write pointers to be cleared. FULL flag wont get cleared in 
  // Circular buffer mode as its clearing is tied to Trace Enable 
  input wire                                      ptr_clr,
        
  // Pulse to clear fill level registers
  input wire                                      ctl_trace_capt_en_1_0,

  // If trace capture is enabled, pointers are maintained by the TMC
  input wire                                      ctl_trace_capt_en,

  // If TraceCaptEn=0 and TMCReady=1, direct control of pointers and the memory
  // by the APB is allowed, regardless of empty status
  input wire                                      tmc_disabled,

  // TraceCaptEn is cleared when TMCReady=0 and the TMC is in a FIFO mode 
  // or with Drain in progress
  input wire                                      tmc_abort,

  // indicates that buf level has been read and hence can be cleared
  input wire                                      lat_buf_level_rd_done,

  // Buffer water mark register
  input wire         [CXTMC_FILL_LEVEL_WIDTH-2:0] buf_wm, 

  // Write enable for ITMISCOP0 register
  input wire                                      it_misc_op_0_wr_en,

  // Integration Mode Control
  input wire                                      it_ctrl,

  // Memory flush request from Flush control block
  input wire                                      mem_flush_req,

  // Chip enable for memory
  output reg                                      MEMCEN,

  // Write enable for memory
  output reg                                      MEMWEN,

  // Memory Address
  output reg           [CXTMC_MEM_ADDR_WIDTH-1:0] MEMADDR,

  // Write data to Memory 
  output wire           [CXTMC_WB_DATA_WIDTH-1:0] MEMD,

  // Read data from Memory 
  output wire           [CXTMC_WB_DATA_WIDTH-1:0] rb_data,

  // Indicating to APB Read fifo/Unformatter that memory read data is valid
  output reg                                      rb_rdata_valid,

  // request from write buffer is accepted
  output reg                                      wb_req_ready,

  // request from apb read fifo/unformatter is accepted
  output reg                                      rb_req_ready,

  // memory read pointer in bytes
  output wire     [CXTMC_MEM_BYTE_ADDR_WIDTH-1:0] rrp,

  // memory write pointer in bytes
  output wire     [CXTMC_MEM_BYTE_ADDR_WIDTH-1:0] rwp,

  // maximum fifo fill depth in 32-bit words
  output wire        [CXTMC_FILL_LEVEL_WIDTH-1:0] lat_buf_level,
  
  // Current fill level of the trace memory in 32-bit words
  output wire        [CXTMC_FILL_LEVEL_WIDTH-1:0] c_buf_level,

  // memory is empty
  output reg                                      trace_mem_empty,

  // memory is FULL or has reached FULL at one point in circular buffer mode
  output reg                                      FULL,

  // Memory flush completion ack to Flush control block
  output wire                                     mem_flush_ack,

  // Memory write detect - used in ATB synchronisation block
  output wire                                     mem_wr

  );
  
  //----------------------------------------------------------------------------
  // Constants definitions
  //----------------------------------------------------------------------------
  `include "cxtmc_constants.v"

  // This parameter determines the number of 0's to be padded to the Memory 
  // Address Vector to arrive at Byte Address which needs to be driven on the 
  // Read/Write Pointers going to APB
  localparam CXTMC_PTR_PAD  = (CXTMC_MEM_BYTE_ADDR_WIDTH-CXTMC_MEM_ADDR_WIDTH);
  // This parameter determines the number of bits that need to masked to 0, to 
  // achieve
  // 1. Frame alignment for 32/64 bit ATB Width (64/128 Memory Width)
  // 2. Memory Width alignment for 128 ATb Width (256 Memory width)
  // for 128 ATB, Memory = 256 hence Lower 5 bits need to be ignored
  // For 64/32 ATB, pointer programming has to be frame aligned, hence lower
  // 4 bits need to be ignored
  localparam CXTMC_PTR_LSB  = (CXTMC_ATB_DATA_WIDTH == 128) ? 5 : 4;

  // This parameter indicates the number of 32-bit words in one memory dataword
  // This is the same as CXTMC_WB_DATA_WIDTH/32
  // It is used in generation of CXTMC_BUF_LEVEL_CMP_MASK
  localparam CXTMC_BUF_LEVEL_STEP = 
               (CXTMC_WB_DATA_WIDTH == 64) ?
                 {{CXTMC_FILL_LEVEL_WIDTH-2{1'b0}}, 2'b10}  : // 2
               (CXTMC_WB_DATA_WIDTH == 128) ?
                 {{CXTMC_FILL_LEVEL_WIDTH-3{1'b0}}, 3'b100} : // 4
                 {{CXTMC_FILL_LEVEL_WIDTH-4{1'b0}}, 4'b1000}; // 8

  // This parameter indicates the width for c_buf_level register
  // for 64 bit Write buffer, it will be one less than fill_level_width
  // 2 less for 128 and 3 for 256. 
  localparam CXTMC_BUF_LEVEL_WIDTH = 
               (CXTMC_WB_DATA_WIDTH == 64) ?
                 CXTMC_FILL_LEVEL_WIDTH-1  : // 32 bit ATB, 64 bit WB
               (CXTMC_WB_DATA_WIDTH == 128) ?
                 CXTMC_FILL_LEVEL_WIDTH-2 : // 64 bit ATB, 128 bit WB
                 CXTMC_FILL_LEVEL_WIDTH-3; // 128 bit AT, 256 bit WB 

  // This parameter indicates the number of 0's to be appended to 
  // c_buf_level_reg to assign it to c_buf_level
  localparam CXTMC_BUF_LEVEL_PAD = (CXTMC_WB_DATA_WIDTH == 64) ?  1 :         // 32 bit ATB, 
                                   (CXTMC_WB_DATA_WIDTH == 128) ? 2 : 3; // 64 bit ATB, 128 bit ATB 

  // This parameter indicates the number of bits to compare in the c_buf_level
  // value with the threshold space setting. This helps use an equality check
  // logic instead of a ">=" operator which carries an area penalty. 
  localparam CXTMC_BUF_LEVEL_CMP_MASK = 
               (CXTMC_BUF_LEVEL_STEP == 2) ? // Ignore LSBit during comparison
                 {{CXTMC_FILL_LEVEL_WIDTH-1{1'b1}}, 1'b0}  :
               (CXTMC_BUF_LEVEL_STEP == 4) ? // Ignore 2 LSBits
                 {{CXTMC_FILL_LEVEL_WIDTH-2{1'b1}}, 2'b00} :
                 {{CXTMC_FILL_LEVEL_WIDTH-3{1'b1}}, 3'b000};

  //----------------------------------------------------------------------------
  // Wire declarations
  //----------------------------------------------------------------------------
  // D-input for memory address
  wire      [CXTMC_MEM_ADDR_WIDTH-1:0]  nxt_memaddr;
  // D-input for rb_req_ready
  wire                                  nxt_rb_req_ready;
  // D-input for wb_req_ready
  wire                                  nxt_wb_req_ready;
  // D-input for rb_rdata_valid
  wire                                  nxt_rb_rdata_valid;
  // D-input for memcen
  wire                                  nxt_memcen;
  // D-input for memwen
  wire                                  nxt_memwen;
  // Clock enable for read pointer
  wire                                 rrp_en;
  // Clock enable for write pointer
  wire                                 rwp_en;
  // Write to Memory can be done
  wire                                 mem_wr_en;
  // This is used for updating read and write pointers. When a write happens 
  // from APB. This signal ensures that appropriate number of bits at the LSB 
  // are zeroed out, so that an incorrect write from software to those bits, 
  // which are illegal will be ignored.
  wire [CXTMC_MEM_BYTE_ADDR_WIDTH-1:0] masked_apb_wdata;

  // D-input of lat_buf_level_reg
  wire [CXTMC_BUF_LEVEL_WIDTH-1:0]     nxt_lat_buf_level_reg;

  // Trace memory space threshold
  wire [CXTMC_FILL_LEVEL_WIDTH-1:0] trace_mem_space_thrshold;

  // Signals to indicate pointer increment - used in CBUFLEVEL calculation
  wire                                 rrp_incr;
  wire                                 rwp_incr;

  // Memory Read request detected
  wire                                 mem_rd_en;

  // D-input of read skid buffer
  wire                                  nxt_mem_rd_skd;

  // Clock enable term for lat_buf_level
  wire                                 lat_buf_level_we;

  // Clock enable term for c_buf_level
  wire                                 c_buf_level_we;

  // Clock enable term for MEMADDR
  wire                                 memaddr_we;

  // Update lat_buf_level register since the current fill level has
  // incresed beyond the last latched value
  wire                                 lat_buf_level_upd;

  //----------------------------------------------------------------------------
  // Reg declarations
  //----------------------------------------------------------------------------
  // D-input for trace_mem_empty
  reg                                   nxt_trace_mem_empty;
  // Trace memory full status - different from FULL in that trace_mem_full is
  // not affected by BUFWM
  reg                                   trace_mem_full;
  // D-input for trace_mem_full
  reg                                   nxt_trace_mem_full;
  // D-input for FULL
  reg                                   nxt_full;
  // D-input for write pointer address in words
  reg       [CXTMC_MEM_ADDR_WIDTH-1:0] nxt_rwp_word_addr;
  // D-input for read pointer address in words
  reg       [CXTMC_MEM_ADDR_WIDTH-1:0]  nxt_rrp_word_addr;
  // Write pointr address in words
  reg       [CXTMC_MEM_ADDR_WIDTH-1:0] rrp_word_addr;
  // Read pointr address in words
  reg       [CXTMC_MEM_ADDR_WIDTH-1:0] rwp_word_addr;
  // D-input of c_buf_level
  reg      [CXTMC_BUF_LEVEL_WIDTH-1:0] nxt_c_buf_level_reg;
  // D-input of c_buf_level
  reg      [CXTMC_BUF_LEVEL_WIDTH-1:0] c_buf_level_reg;
  // D-input of lat_buf_level_reg
  reg  [CXTMC_BUF_LEVEL_WIDTH-1:0]     lat_buf_level_reg;

  // Skid buffer for Memory Read
  reg                                   mem_rd_skd;
  
  // Delayed version of lat_buf_level_upd
  reg                                   lat_buf_level_upd_reg;

//-----------------------------------------------------------------------------
//
//  Main body of code 
//  =================
//
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// If there is a request from the Write buffer, initiate a write to memory.
// (Writes take higher priority over reads, so even if there is a 
// simultaneous read request, the write goes through).
// However, if the trace memory is full, wait the write buffer request - this
// is not a consideration when the TMC is in Circular buffer mode (trace 
// data can be over-written) or the TMC is disabled (direct control of trace
// memory through APB regardless of mode or fill status).
// In FIFO modes, if the TMC is disabled with TMCReady=0 (tmc_abort=1), writes 
// are allowed even if the FIFO is full so as to allow draining the internal 
// pipelines in the formatter and the write buffer
//-----------------------------------------------------------------------------
assign mem_wr_en = wb_req_valid & wb_req_ready;

//-----------------------------------------------------------------------------
// Active low write enable output to memory
//-----------------------------------------------------------------------------
assign  nxt_memwen         = ~mem_wr_en;

//-----------------------------------------------------------------------------
// wb_req_ready will be asserted whenever a write can be accepted - always in 
// circular buffer mode, or when it is not full in other modes
// If the TMC is disabled, writes are allowed regardless of the full status
// of the memory. This can only occur with the TMC in legacy circular buffer
// mode or is disabled in one of the FIFO modes (draining of data remaining
// in internal pipelines) or is completely disabled (direct control of 
// memory through APB writes).
// The  nxt_ version of only the full status is used because this is the only
// term in the expression that changes dynamically during device operation.
//-----------------------------------------------------------------------------
assign  nxt_wb_req_ready   = circ_buf_mode | tmc_abort | tmc_disabled |
                             ~nxt_trace_mem_full ;

//-----------------------------------------------------------------------------
// MEMD is a pass through. Data for a given transfer is driven valid by
// the write buffer on the rising edge of clock at which wb_req_valid and
// wb_req_ready are sampled HIGH.
//-----------------------------------------------------------------------------
assign MEMD                = wb_data;

//-----------------------------------------------------------------------------
// rb_data is a pass through
// MEMQ can be sampled on the rising edge of clock after the read is sampled
// by the memory
//-----------------------------------------------------------------------------
assign rb_data             = MEMQ;

//-----------------------------------------------------------------------------
// This will be asserted, when either a write request is present, or when a 
// read request present.
//-----------------------------------------------------------------------------
assign  nxt_memcen = ~(mem_rd_en | mem_wr_en);

//-----------------------------------------------------------------------------
// This will be asserted, when Memory is not empty, and when there is no write
// in the same clock. Checks for rb_req_ready to be low, so that it doesnt get 
// asserted twice.
// Higher priority to writes than to reads
//-----------------------------------------------------------------------------
assign mem_rd_en = ((rb_req_valid & rb_req_ready) | mem_rd_skd) & ~mem_wr_en;

//-----------------------------------------------------------------------------
// Accept a new read request only if the memory has atleast one valid entry
// and there is no buffered read request in the skid buffer. If the TMC is
// disabled, then reads are allowed even if the memory is empty.
//-----------------------------------------------------------------------------
assign  nxt_rb_req_ready = (tmc_disabled | ~nxt_trace_mem_empty) &
                           ~nxt_mem_rd_skd;

//-----------------------------------------------------------------------------
// Skid buffer for read requests.
// If there is a conflict due to simultaneous read and write requests, write
// requests are given a higher priority and the read request is stored in the
// skid buffer.
// The request stored in the read skid buffer is issued when there is no
// conflicting write request on a subsequent clock cycle. If there is a fresh
// read request before the skid buffer is emptied, that request is waited
// by deasserting rb_req_ready.
//-----------------------------------------------------------------------------
assign  nxt_mem_rd_skd = (rb_req_valid & rb_req_ready & mem_wr_en) |
                         (mem_rd_skd & mem_wr_en); 

//-----------------------------------------------------------------------------
// Clocked process for skid buffer for read requests.
//-----------------------------------------------------------------------------
  always @(posedge cxtmc_clk or negedge RESETn)
  begin : p_mem_rd_skd
    if (!RESETn)
      mem_rd_skd <= 1'b0;
    else
      mem_rd_skd <=  nxt_mem_rd_skd;
  end // block: p_mem_rd_skd

//-----------------------------------------------------------------------------
// when write is present, write pointer is driven on to memory address, else 
// read
//-----------------------------------------------------------------------------
assign  nxt_memaddr        = mem_wr_en ? rwp_word_addr : rrp_word_addr;

//-----------------------------------------------------------------------------
// Read data valid is asserted, when a read command is issued to memory
//-----------------------------------------------------------------------------
assign  nxt_rb_rdata_valid = ~MEMCEN & MEMWEN;

//-----------------------------------------------------------------------------
// rrp_en is clock enable for rrp
// rrp_en is set either when read command is issued from unformatter - where 
// the data is consumed immediately, or when apb_read_fifo_rrp_en is set, which
// denotes that the last data has been emptied from APB Read fifo
// or when a write to the read pointer happens from APB, or when a clear happens
//-----------------------------------------------------------------------------
assign rrp_en              = ptr_clr | rrp_wr_en | rrp_incr;

//-----------------------------------------------------------------------------
// rwp_en is clock enable for rwp
// It is set when a write happens or when a write to the pointer happens from 
// APB or when a clear happens
//-----------------------------------------------------------------------------
assign rwp_en              = rwp_incr | rwp_wr_en | ptr_clr;

//-----------------------------------------------------------------------------
// masked_apb_wdata is generated from apb_wdata by making appropriate bits in 
// LSB as 0. Refer description for CXTMC_PTR_LSB for more details
//-----------------------------------------------------------------------------
assign masked_apb_wdata = apb_wdata[CXTMC_MEM_BYTE_ADDR_WIDTH-1:0] 
                          & {{CXTMC_MEM_BYTE_ADDR_WIDTH-CXTMC_PTR_LSB{1'b1}},
                            {CXTMC_PTR_LSB{1'b0}}};

//-----------------------------------------------------------------------------
// Write pointer increment control logic
// When a write is issued to memory, increment the write pointer
//-----------------------------------------------------------------------------
assign rwp_incr = ~nxt_memcen & ~nxt_memwen;

//-----------------------------------------------------------------------------
// Read pointer increment control logic
// If memory reads are initiated by the unformatter (TMC in HW-FIFO mode or 
// DrainBuffer bit set in Circular-Buffer mode), then the read pointer is 
// incremented when the memory read is issued on the memory interface. This is
// because the unformatter consumes the entire data read out from the memory 
// in a single cycle. 
// If the TMC is abruptly disabled when the unformatter is active, the memory
// interface continues to honour further read requests from the unformatter
// till the unformatter is empty.
// If memory reads are initiated through APB register reads, the read pointer
// is incremented only after the complete memory dataword is read out through
// the APB (apb_read_fifo_rrp_en asserted)
// In the Circular buffer mode, memory writes result in an impact on the read
// pointer after the trace memory is filled completely. This is to ensure that
// the first data read out from the trace memory is the oldest.
// In Circular buffer mode, memory reads from the APB/unformatter cannot
// occur at the same time as a memory write
// The read pointer must be maintained when the TMC is enabled in 
// circular buffer mode.
// The read pointer is written with the write pointer value when trace 
// capture is enabled in circular buffer mode. Subsequently, when the 
// trace memory is written and the write pointer advances to again match
// the read pointer, the read pointer must progress along with the
// write pointer with every memory write to ensure that the oldest data 
// is read out first after trace capture stops.
//-----------------------------------------------------------------------------
generate
  if (CXTMC_ATBM_AXIM_CFG == CXTMC_CFG_ETB) // ETB configuration
    assign rrp_incr = (apb_read_fifo_rrp_en)      |
                      (circ_buf_mode & (rwp_word_addr == rrp_word_addr) & 
                        FULL & rwp_incr); 
  else // ETF configuration
    begin
      wire unf_empty_in_prog;    // Unformatter disabled and emptying of 
                                 // internal pipelines in progress
      reg unformatter_en_reg;    // Delayed version of unformatter_en - used to 
                                 // detect a falling edge on unformatter_en
      reg unf_empty_in_prog_reg; // Delayed version of unf_empty_in_prog


      assign rrp_incr = ((unformatter_en | unf_empty_in_prog) &
                          ~nxt_memcen &  nxt_memwen) |
                        (apb_read_fifo_rrp_en)      |
                        (circ_buf_mode & (rwp_word_addr == rrp_word_addr) &
                          FULL & rwp_incr);

      //-----------------------------------------------------------------------
      // If the TMC is abruptly disabled when the unformatter is active, the 
      // memory interface continues to honour further read requests from the 
      // unformatter till the unformatter is idle.
      //-----------------------------------------------------------------------
      assign unf_empty_in_prog = (~unformatter_en & unformatter_en_reg) |
                                 (unf_empty_in_prog_reg & ~unformatter_empty);


      always @(posedge cxtmc_clk or negedge RESETn)
      begin                     
        if (!RESETn)
          begin
            unformatter_en_reg    <= 1'b0;
            unf_empty_in_prog_reg <= 1'b0;
          end
        else
          begin
            unformatter_en_reg    <= unformatter_en;
            unf_empty_in_prog_reg <= unf_empty_in_prog;
          end
      end
    end
endgenerate

//-----------------------------------------------------------------------------
// Read pointer update logic
// When APB issues a pointer clear (when ctl_trace_capt_en goes from 0 to 1), 
// read pointer is zeroed out, but in circular buffer mode, the read
// pointer is made same as the programmed write pointer.
// When a read pointer write happens (rrp_wr_en asserted), the read pointer is 
// updated. Note that rrp_wr_en input cannot be asserted when any memory 
// reads/writes occur because:
//   - RRP writes are allowed only when TraceCaptEn=0 and TMCReady=1, which 
//     implies that there is no trace capture in progress.
//   - When there is no trace capture in progress, reads/writes to memory can 
//     occur only from the APB.
//   - There can only be one access from the APB at a time - the assertion of 
//     rrp_wr_en implies an APB access to the RRP register (and not to RRD)
// Note that ptr_clr input cannot be asserted when any memory reads/writes can
// occur because:
//   - ptr_clr is the result of a 0 -> 1 transition on TraceCaptEn.
//   - Setting of TraceCaptEn bit is allowed only when TraceCaptEn=0 and 
//     TMCReady=1, which implies that there is no trace capture in progress.
// When rrp_incr is set, indicating the last data in apb read fifo is drained 
// out, the read pointer is incremented.
//-----------------------------------------------------------------------------
always @*
begin
    case ({ptr_clr, rrp_wr_en, rrp_incr})
      3'b100,
      3'b101,
      3'b110,
      3'b111 : 
         nxt_rrp_word_addr = circ_buf_mode ? rwp_word_addr :
                                      {CXTMC_MEM_ADDR_WIDTH{1'b0}};
      3'b010,
      3'b011 : 
         nxt_rrp_word_addr = masked_apb_wdata[CXTMC_MEM_BYTE_ADDR_WIDTH-1:
                                              CXTMC_PTR_PAD];
      3'b001 :
         nxt_rrp_word_addr = rrp_word_addr + 
                             {{CXTMC_MEM_ADDR_WIDTH-1{1'b0}}, 1'b1};
      3'b000 :
         nxt_rrp_word_addr = rrp_word_addr;
      default :
         nxt_rrp_word_addr = {CXTMC_MEM_ADDR_WIDTH{1'bx}}; 
    endcase
         
end

//-----------------------------------------------------------------------------
// Write pointer update logic
// When a write pointer write happens, the write pointer is updated.
// When TraceCaptEn is set (pulse on ptr_clr), the write pointer is cleared
// if in FIFO modes. If in Circular buffer mode, the pointer retains its
// value (previously initialised through APB)
// When there is an APB access to write to the pointers, it is updated with 
// the APB write data masked to ensure alignment of value to memory datawidth
// and frame size.
// When a write access has been issued to memory (rwp_incr asserted), the
// write pointer is incremented. 
//-----------------------------------------------------------------------------
always @*
  begin
    case ({ptr_clr, rwp_wr_en, rwp_incr})
      3'b100,
      3'b101,
      3'b110,
      3'b111 : 
         nxt_rwp_word_addr = circ_buf_mode ? rwp_word_addr :
                               {CXTMC_MEM_ADDR_WIDTH{1'b0}};
      3'b010,
      3'b011 : 
         nxt_rwp_word_addr = masked_apb_wdata[CXTMC_MEM_BYTE_ADDR_WIDTH-1:
                                              CXTMC_PTR_PAD];
      3'b001 :
         nxt_rwp_word_addr = rwp_word_addr + 
                             {{CXTMC_MEM_ADDR_WIDTH-1{1'b0}}, 1'b1};
      3'b000 :
         nxt_rwp_word_addr = rwp_word_addr;
      default :
         nxt_rwp_word_addr = {CXTMC_MEM_ADDR_WIDTH{1'bx}}; 
    endcase
  end

//-----------------------------------------------------------------------------
// The threshold space for signaling FULL is calculated from the
// programmed water mark fill level and the max fill level 
// Based on the width of the memory databus, the c_buf_level increments
// in steps of 2, 4 or 8. The value programmed into the BFWM register
// is masked to ignore the corresponding number of LSBits. This allows an
// equality operator to be used (instead of a >= operator) when generating
// FULL.
//-----------------------------------------------------------------------------
assign trace_mem_space_thrshold = CXTMC_MEM_SIZE[CXTMC_FILL_LEVEL_WIDTH-1:0] - 
                                  ({1'b0, buf_wm} & CXTMC_BUF_LEVEL_CMP_MASK);

//-----------------------------------------------------------------------------
// FULL generation
// When TraceCaptureEn is set (ptr_clr asserted), FULL is cleared.
// When in Circular Buffer mode, the FULL flag is set when the write pointer
// wraps around to 0. Once the FULL flag is set, it remains set
// till cleared by the assertion of ptr_clr (regardless of reads from the
// trace memory making it non full).
// When TraceCaptEn is cleared, FULL retains its value till cleared by ptr_clr
// By design, ptr_clr cannot occur at the same time as a read or write being
// issued to memory.  
// In FIFO modes, the FULL output reflects the fill status of the trace
// memory dynamically.
// On reads, if the fill level is about to fall below the set threshold, FULL 
// is cleared.
// On writes, if the fill level is about to reach the threshold, FULL is set. 
// Use of the '==' operator results in lesser logic gates over use of '<=' 
// operator.
// In the Integration test mode, FULL output is controlled by writes to the
// ITMISCOP0 register.
//-----------------------------------------------------------------------------
always @*
begin
  if (it_ctrl)
     nxt_full = it_misc_op_0_wr_en ? apb_wdata[1] : FULL;
  else
    case ({rwp_incr, rrp_incr})
      2'b00,  // Neither pointers change
      2'b11 : // Both pointers increment, so fill level remains same
         nxt_full = (ptr_clr) ? 1'b0 : FULL;
      2'b01 : // Read pointer increment
         nxt_full = (circ_buf_mode | ~ctl_trace_capt_en) ? FULL :
                    (c_buf_level == trace_mem_space_thrshold) ? 1'b0 : FULL;
      2'b10 : // Write pointer increment 
         nxt_full = circ_buf_mode ?
                     (FULL | (rwp_word_addr == {CXTMC_MEM_ADDR_WIDTH{1'b1}})) :
                    ~ctl_trace_capt_en ? FULL :
                     (FULL | ({nxt_c_buf_level_reg,{CXTMC_BUF_LEVEL_PAD{1'b0}}} == trace_mem_space_thrshold));
      default :
         nxt_full           = 1'bx;
    endcase
end

//-----------------------------------------------------------------------------
// Trace memory full condition detection
//-----------------------------------------------------------------------------
always @*
begin
  if (ctl_trace_capt_en & ~ptr_clr)
    case ({rwp_incr, rrp_incr})
      2'b00,  // No change in pointers
      2'b11 : // Both pointers increment, so fill level remains same
               nxt_trace_mem_full = trace_mem_full;
      2'b01 : // Increment Read pointer only
               nxt_trace_mem_full = 1'b0;
      2'b10 : // Increment Write pointer only
               nxt_trace_mem_full = ( nxt_rwp_word_addr == rrp_word_addr);
      default :
               nxt_trace_mem_full = 1'bx;
    endcase
  else
     nxt_trace_mem_full = 1'b0;
end

//-----------------------------------------------------------------------------
// Trace memory empty condition detection
// Trace_mem_empty flag will be set if the new read pointer matches the 
// write pointer
//-----------------------------------------------------------------------------
always @*
begin
  case ({ctl_trace_capt_en, ptr_clr, rwp_incr, rrp_incr})
    4'b0000,
    4'b0001,
    4'b0010,
    4'b0011,
    4'b0100,
    4'b0101,
    4'b0110,
    4'b0111 : // ctl_trace_capt_en low
       nxt_trace_mem_empty = 1'b0;
    4'b1100,
    4'b1101,
    4'b1110,
    4'b1111 : // ptr_clr asserted
       nxt_trace_mem_empty = 1'b1;
    4'b1000,  // No change in pointers
    4'b1011 : // Both pointers increment, so fill level remains same
       nxt_trace_mem_empty = trace_mem_empty;
    4'b1001 : // Increment Read pointer only
       nxt_trace_mem_empty = ( nxt_rrp_word_addr == rwp_word_addr);
    4'b1010 : // Increment Write pointer only
              // trace_mem_empty is reset because the write would make the 
              // memory non-empty
       nxt_trace_mem_empty = 1'b0;
    default :
       nxt_trace_mem_empty = 1'bx;
  endcase
end

//-----------------------------------------------------------------------------
// Clock processes for above comb singals
//-----------------------------------------------------------------------------
always @(posedge cxtmc_clk or negedge RESETn)
begin
  if (!RESETn) begin
    FULL                  <= 1'b0;
    trace_mem_full        <= 1'b0;
    wb_req_ready          <= 1'b0;
    rb_req_ready          <= 1'b0;
    MEMCEN                <= 1'b1;
    MEMWEN                <= 1'b1;
    rb_rdata_valid        <= 1'b0;
    trace_mem_empty       <= 1'b0;
  end else begin
    FULL                  <=  nxt_full;
    trace_mem_full        <=  nxt_trace_mem_full;
    wb_req_ready          <=  nxt_wb_req_ready;
    rb_req_ready          <=  nxt_rb_req_ready;
    MEMCEN                <=  nxt_memcen;
    MEMWEN                <=  nxt_memwen;
    rb_rdata_valid        <=  nxt_rb_rdata_valid;
    trace_mem_empty       <=  nxt_trace_mem_empty;
  end
end

//-----------------------------------------------------------------------------
// Update memory address only when memory access happens
//-----------------------------------------------------------------------------
assign memaddr_we = ~nxt_memcen;

always @(posedge cxtmc_clk or negedge RESETn)
begin
  if (!RESETn) begin
    MEMADDR      <= {CXTMC_MEM_ADDR_WIDTH{1'b0}}; 
  end else if (memaddr_we) begin
    MEMADDR      <=  nxt_memaddr;
  end
end

//-----------------------------------------------------------------------------
// Update write pointer address only when rwp_en is set
//-----------------------------------------------------------------------------
always @(posedge cxtmc_clk or negedge RESETn)
begin
  if (!RESETn) begin
    rwp_word_addr  <= {CXTMC_MEM_ADDR_WIDTH{1'b0}};
  end else if (rwp_en) begin
    rwp_word_addr  <=  nxt_rwp_word_addr;
  end
end

//-----------------------------------------------------------------------------
// Update read pointer address only when rrp_en is set
//-----------------------------------------------------------------------------
always @(posedge cxtmc_clk or negedge RESETn)
begin
  if (!RESETn) begin
    rrp_word_addr  <= {CXTMC_MEM_ADDR_WIDTH{1'b0}};
  end else if (rrp_en) begin
    rrp_word_addr  <=  nxt_rrp_word_addr;
  end
end

//-----------------------------------------------------------------------------
// rrp_word_addr stores the Read Pointer as a word address. rrp is a byte 
// pointer.
// CXTMC_PTR_PAD provides the number of bits to be padded to arrive at the byte
// pointer from word address
//-----------------------------------------------------------------------------
assign rrp                 = {rrp_word_addr,{CXTMC_PTR_PAD{1'b0}}};

//-----------------------------------------------------------------------------
// rwp_word_addr stores the Write Pointer as a word address. rwp is a byte 
// pointer.
// CXTMC_PTR_PAD provides the number of bits to be padded to arrive at the byte
// pointer from word address
//-----------------------------------------------------------------------------
assign rwp                 = {rwp_word_addr,{CXTMC_PTR_PAD{1'b0}}};

//-----------------------------------------------------------------------------
// Current fill level
// If ctl_trace_capt_en is LOW or if trace capture has just been enabled 
// (ptr_clr asserted), then clear the fill level.
// On reads, decrement the fill level. On writes, increment the fill level.
//-----------------------------------------------------------------------------
always @*
  begin
    if (ctl_trace_capt_en & ~ptr_clr)
      case ({rwp_incr, rrp_incr})
        2'b00,  // No change in pointers
        2'b11 : // Both pointers increment, so fill level remains same
                 nxt_c_buf_level_reg = c_buf_level_reg;
        2'b01 : // Read pointer increment
                 nxt_c_buf_level_reg = trace_mem_empty ? c_buf_level_reg :
                                       c_buf_level_reg - {{CXTMC_BUF_LEVEL_WIDTH-1{1'b0}}, 1'b1};
        2'b10 : // Write pointer increment
                 nxt_c_buf_level_reg = trace_mem_full ? c_buf_level_reg :
                                       c_buf_level_reg + {{CXTMC_BUF_LEVEL_WIDTH-1{1'b0}}, 1'b1};
        default :
                 nxt_c_buf_level_reg = {CXTMC_BUF_LEVEL_WIDTH{1'bx}};
      endcase 
    else
       nxt_c_buf_level_reg = {CXTMC_BUF_LEVEL_WIDTH{1'b0}};
  end

assign c_buf_level_we = ctl_trace_capt_en_1_0 | rwp_incr | rrp_incr | ptr_clr;

//-----------------------------------------------------------------------------
// Clocked process for c_buf_level
//-----------------------------------------------------------------------------
  always @(posedge cxtmc_clk or negedge RESETn)
  begin
    if (!RESETn)
      c_buf_level_reg   <= {CXTMC_BUF_LEVEL_WIDTH{1'b0}};
    else if (c_buf_level_we)
      c_buf_level_reg   <=  nxt_c_buf_level_reg;
  end

  assign c_buf_level = {c_buf_level_reg,{CXTMC_BUF_LEVEL_PAD{1'b0}}};

  always @(posedge cxtmc_clk or negedge RESETn)
  begin
    if (!RESETn)
      begin
        lat_buf_level_upd_reg <= 1'b0;
      end
    else
      begin
        lat_buf_level_upd_reg <= lat_buf_level_upd;
      end
  end

//-----------------------------------------------------------------------------
// Max buf level storage
// If ptr_clr is asserted, lat_buf_level is cleared because the pointers
// are cleared anyway. If the LBUFLEVEL register is read, then it is updated to 
// the current fill level. If there is a write to trace memory and the
// computed fill level is greater than the latched fill level, then 
// the latched fill level is updated to the computed fill level. 
//-----------------------------------------------------------------------------
  assign  nxt_lat_buf_level_reg = (ptr_clr) ? {CXTMC_BUF_LEVEL_WIDTH{1'b0}} : 
                              (ctl_trace_capt_en &&
                                 ((lat_buf_level_rd_done && 
                                  !lat_buf_level_upd_reg) ||  
                                 lat_buf_level_upd)) ?
                                 nxt_c_buf_level_reg :
                              lat_buf_level_reg;

assign lat_buf_level_upd = (rwp_incr & (nxt_c_buf_level_reg > lat_buf_level_reg));

assign lat_buf_level_we = ptr_clr | lat_buf_level_rd_done | rwp_incr;

//-----------------------------------------------------------------------------
// Clocked processes for lat_buf_level
//-----------------------------------------------------------------------------
  always @(posedge cxtmc_clk or negedge RESETn) 
  begin
    if (!RESETn)
      lat_buf_level_reg <= {CXTMC_BUF_LEVEL_WIDTH{1'b0}};
    else if (lat_buf_level_we)
      lat_buf_level_reg <=  nxt_lat_buf_level_reg;
  end

  assign lat_buf_level = {lat_buf_level_reg,{CXTMC_BUF_LEVEL_PAD{1'b0}}};

//----------------------------------------------------------------------------
// Memory flush logic.
// In the ETB configuration, mem_flush_req is not used, so mem_flush_ack
// is pulled high.
// In the ETF configuration, if a Memory Flush request is asserted, store the 
// write pointer.
// When the read pointer subsequently equals this stored value, assert the
// flush acknowledge signal for one clock period.
// Once the Memory flush request input is asserted, it is expected to stay 
// asserted till mem_flush_ack is asserted - either on the same clock or on
// a subsequent clock. 
// If trace capture is disabled, then clear history.
//----------------------------------------------------------------------------
generate
  if (CXTMC_ATBM_AXIM_CFG == CXTMC_CFG_ETF) // ETF configuration
    begin
      // D-input of mem_flush_req_det
      wire                             nxt_mem_flush_req_det;

      // Remember that a flush request has been detected and the
      // Write pointer has been stored
      reg                              mem_flush_req_det;

      // Clock enable for rwp_waddr_flush_marker
      wire                             rwp_waddr_flush_marker_we;

      // D-input of rwp_waddr_flush_marker
      wire [CXTMC_MEM_ADDR_WIDTH-1:0]  nxt_rwp_waddr_flush_marker;

      // Stored value of Write pointer when a flush request is detected
      reg   [CXTMC_MEM_ADDR_WIDTH-1:0] rwp_waddr_flush_marker;

      // D-input of mem_fl_ack_non_empty
      wire                             nxt_mem_fl_ack_non_empty;

      // Memory flush acknowledge corresponding to non-empty memory
      reg                              mem_fl_ack_non_empty;

      assign  nxt_mem_flush_req_det = ctl_trace_capt_en &
                                ((mem_flush_req & ~mem_flush_ack) |
                                (mem_flush_req_det & ~mem_flush_ack));

      always @(posedge cxtmc_clk or negedge RESETn)
      begin
        if (!RESETn)
            mem_flush_req_det <= 1'b0;
        else
            mem_flush_req_det <=  nxt_mem_flush_req_det;
      end

//----------------------------------------------------------------------------
// Store the Write pointer when a flush request is raised.
// If the trace memory is empty, there is no need to store the pointer.
// The write pointer could increment after mem_flush_req is asserted,
// but do not change the stored write pointer value till a subsequent
// mem_flush_ack is received - this is implemented by checking for
// mem_flush_req_det. 
//----------------------------------------------------------------------------
      assign rwp_waddr_flush_marker_we = mem_flush_req & ~trace_mem_empty & 
                                         ~mem_flush_req_det;
                                      
      assign  nxt_rwp_waddr_flush_marker = rwp_waddr_flush_marker_we ?
                                       rwp_word_addr : rwp_waddr_flush_marker;

      always @(posedge cxtmc_clk or negedge RESETn)
      begin
        if (!RESETn)
            rwp_waddr_flush_marker <= {CXTMC_MEM_ADDR_WIDTH{1'b0}};
        else if (rwp_waddr_flush_marker_we)
            rwp_waddr_flush_marker <=  nxt_rwp_waddr_flush_marker;
      end

//----------------------------------------------------------------------------
// Memory flush acknowledge.
// If the memory is empty, a flush request is acknowledged immediately.
// If the read pointer becomes equal to the stored write pointer, the
// flush request is acknowledged with a one-clock-wide pulse on mem_flush_ack.
// If trace capture is disabled, assert acknowledge as a default response.
//----------------------------------------------------------------------------
      assign  nxt_mem_fl_ack_non_empty = mem_flush_req & 
                            (nxt_rrp_word_addr == nxt_rwp_waddr_flush_marker) & 
                            (rrp_word_addr !=  nxt_rwp_waddr_flush_marker);

      always @(posedge cxtmc_clk or negedge RESETn)
      begin
        if (!RESETn)
            mem_fl_ack_non_empty <= 1'b0;
        else 
            mem_fl_ack_non_empty <=  nxt_mem_fl_ack_non_empty;
      end

      assign mem_flush_ack = ~ctl_trace_capt_en | trace_mem_empty | 
                             mem_fl_ack_non_empty;
    end
  else // ETB configuration
    assign mem_flush_ack = 1'b1;
endgenerate

//----------------------------------------------------------------------------
// Memory write detect. Used to decrement PSCR counter in the ATB 
// Synchronisation request generator block.
//----------------------------------------------------------------------------
assign mem_wr = ~MEMWEN & ~MEMCEN;

//----------------------------------------------------------------------------
// ASSERTIONS
//----------------------------------------------------------------------------
`ifdef ARM_ASSERT_ON
  
// If trace capture is enabled, APB write accesses to RRP are not expected 
   assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxtmc_memif - APB write accesses to RRP are not allowed when trace capture is enabled")
      uzovl_cxtmc_memif_rrp
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   (ctl_trace_capt_en & rrp_wr_en)
        );

// If trace capture is enabled, APB write accesses to RWP are not expected 
   assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxtmc_memif - APB write accesses to RWP are not allowed when trace capture is enabled")
      uzovl_cxtmc_memif_rwp
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   (ctl_trace_capt_en & rwp_wr_en)
        );

// ptr_clr input cannot be asserted when any memory reads can occur
   assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxtmc_memif - ptr_clr cannot occur when a memory read is issued")
      uzovl_cxtmc_memif_ptr_clr_rrp_incr
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   (ptr_clr & rrp_incr)
        );

// ptr_clr input cannot be asserted when any memory writes can occur
   assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxtmc_memif - ptr_clr cannot occur when a memory write is issued")
      uzovl_cxtmc_memif_ptr_clr_rwp_incr
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   (ptr_clr & rwp_incr)
        );


// Once Flush request is asserted, it must not be de-asserted before flush ack is asserted
  reg mem_flush_req_reg;
  reg mem_flush_ack_reg;

  always @(posedge cxtmc_clk or negedge RESETn)
  begin
    if (!RESETn)
      begin
        mem_flush_req_reg <= 1'b0;
        mem_flush_ack_reg <= 1'b0;
      end
    else
      begin
        mem_flush_req_reg <= mem_flush_req;
        mem_flush_ack_reg <= mem_flush_ack;
      end
  end
  
   assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxtmc_memif - Once Flush request is asserted, it must not be de-asserted before flush ack is asserted")
      uzovl_cxtmc_memif_flush_req_ack
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   (~mem_flush_req & mem_flush_req_reg & ~mem_flush_ack_reg)
        );

  assert_always #(`OVL_ERROR,`OVL_ASSERT,"MEMWEN is asserted, but MEMCEN is not asserted")
    uzovl_cxtmc_memif_cen (
      .clk       (cxtmc_clk),
      .reset_n   (RESETn),
      .test_expr (MEMWEN || (!MEMCEN))
    );

  assert_always #(`OVL_ERROR,`OVL_ASSERT,"nxt_memwen is asserted, but nxt_memcen is not asserted")
    uzovl_cxtmc_memif_nxt_cen (
      .clk       (cxtmc_clk),
      .reset_n   (RESETn),
      .test_expr (nxt_memwen || (!nxt_memcen))
    );

   assert_never_unknown #(`OVL_ERROR, 1, `OVL_ASSERT,
    "OVL Message : cxtmc_memif - X or Z detected in nxt_trace_mem_full")
      uzovl_cxtmc_memif_x_chk_01
      (
       .clk       (cxtmc_clk),
       .reset_n   (RESETn),
       .qualifier (1'b1),
       .test_expr (nxt_trace_mem_full)
      );

   assert_never_unknown #(`OVL_ERROR, CXTMC_BUF_LEVEL_WIDTH, `OVL_ASSERT,
    "OVL Message : cxtmc_memif - X or Z detected in nxt_c_buf_level_reg")
      uzovl_cxtmc_memif_x_chk_02
      (
       .clk       (cxtmc_clk),
       .reset_n   (RESETn),
       .qualifier (1'b1),
       .test_expr (nxt_c_buf_level_reg)
      );

   assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxtmc_memif - If unformatter_en is low, apb_read_fifo_rrp_en must not be asserted")
      uzovl_cxtmc_memif_unf_en
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   (unformatter_en & apb_read_fifo_rrp_en)
        );

  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxtmc_memif - Memory Buffer flush happened with non -zero data")
      uzovl_cxtmc_memif_flush_non_zero_data
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   (ctl_trace_capt_en && mem_flush_ack_reg && 
                       mem_flush_req_reg && rb_rdata_valid && 
                       (rb_data[(CXTMC_WB_DATA_WIDTH - 9) : 8] != 'h0))
        );

reg wb_req_valid_hold_chk; // wb_req_valid once asserted should be sustained
                           // until wb_req_ready is sampled
reg rb_req_valid_hold_chk; // rb_req_valid once asserted should be sustained
                           // until rb_req_ready is sampled
wire nxt_wb_req_valid_hold_chk; // D-input of wb_req_valid_hold_chk
wire nxt_rb_req_valid_hold_chk; // D-input of rb_req_valid_hold_chk

assign nxt_wb_req_valid_hold_chk = (wb_req_valid & ~wb_req_ready) |
                                   (wb_req_valid_hold_chk & ~wb_req_ready);

assign nxt_rb_req_valid_hold_chk = (rb_req_valid & ~rb_req_ready) |
                                   (rb_req_valid_hold_chk & ~rb_req_ready);

  always @(posedge cxtmc_clk or negedge RESETn)
  begin
    if (!RESETn)
      begin
        wb_req_valid_hold_chk  <= 1'b0;
        rb_req_valid_hold_chk  <= 1'b0;
      end
    else
      begin
        wb_req_valid_hold_chk  <= nxt_wb_req_valid_hold_chk;
        rb_req_valid_hold_chk  <= nxt_rb_req_valid_hold_chk;
      end
  end

// wb_req_valid once asserted must not change until acknowledged by wb_req_ready
   assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxtmc_mem_if - wb_req_valid once asserted must not change until   acknowledged by wb_req_ready")
      uzovl_cxtmc_mem_if_wb_req_valid
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   (wb_req_valid_hold_chk & ~wb_req_valid)
        );

// rb_req_valid once asserted must not change until acknowledged by rb_req_ready
   assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxtmc_mem_if - rb_req_valid once asserted must not change until   acknowledged by rb_req_ready")
      uzovl_cxtmc_mem_if_rb_req_valid
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   (rb_req_valid_hold_chk & ~rb_req_valid & unformatter_en)
        );

generate
  if (CXTMC_ATBM_AXIM_CFG == CXTMC_CFG_ETB) // ETB configuration
// mem_flush_req must not be asserted in ETB configuration
   assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxtmc_mem_if - mem_flush_req must not be asserted in ETB configuration")
      uzovl_cxtmc_mem_flush_req
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   (mem_flush_req)
        );
endgenerate

`endif

endmodule
