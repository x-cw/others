//-----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2007-2015 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//  Version and Release Control Information:
//
//  File Revision       : $Revision: 41969 $
//  File Date           : $Date: 2015-03-09 14:04:25 +0000 (Mon, 09 Mar 2015) $
//
//  Release Information : CoreSight-SoC-TM100-r3p2-00rel0
//-----------------------------------------------------------------------------


//-----------------------------------------------------------------------------
// Forward register slice for  APB/DAP synchronous bridge
//-----------------------------------------------------------------------------

module cxapbsyncbridge_full_full
(
  //----------------------------------------------------------------------------
  // Port Declarations
  //----------------------------------------------------------------------------

  //apb Master side Bus
  output wire  [31:0]     paddrm,      //address of apb bus
  output wire  [31:0]     pwdatam,     //write data of apb bus
  output wire             pwritem,     //read/write control of apb bus
  output wire             penablem,    //enable of apb bus
  output wire             pselm,       //peripheral select of apb bus

  input  wire   [31:0]    prdatam,     //read data of apb bus
  input  wire             pslverrm,    //error response of apb bus
  input  wire             preadym,     //ready of apb bus

  //apb Slave side Bus
  input wire  [31:0]      paddrs,       //address of apb bus
  input wire  [31:0]      pwdatas,      //write data of apb bus
  input wire              pwrites,      //read/write control of apb bus
  input wire              penables,     //enable of apb bus
  input wire              psels,        //peripheral select of apb bus
  

  output reg    [31:0]    prdatas,      //read data of apb bus
  output reg              pslverrs,     //error response of apb bus
  output wire             preadys,        // transfer completion indication 


  //Clock and reset signals
  input  wire             pclk,         //apb clock
  input  wire             pclkens,      //apb clock
  input  wire             pclkenm,      //apb clock
  input  wire             presetn       //apb reset

);


  //----------------------------------------------------------------------------
  // parameters
  //----------------------------------------------------------------------------


  localparam ST_IDLE      = 2'b00;
  localparam ST_SETUP     = 2'b01;
  localparam ST_ACCESS    = 2'b10;
  localparam ST_ACK       = 2'b11;


  //----------------------------------------------------------------------------
  // internal signals declarations
  //----------------------------------------------------------------------------

  wire [64:0]           nxt_fwd_data;       // D-Input of fwd_data
  reg  [64:0]           fwd_data;           // transfer payload from source

  reg  [32:0]           rev_data;           // Read data and response on master side
  wire [32:0]           nxt_rev_data;       // D-input of rev_data
  

  // ---------------------------------------------------------------------------
  //  Internal signals
  // ---------------------------------------------------------------------------
  wire                  hs_master_ack;         // Handshake ack from master side
  wire                  pending_sel_req;    // Pending select request
  wire                  hs_sel_req_en;      // Enable for hs_sel_req
  wire                  nxt_hs_sel_req;     // D-input of hs_sel_req
  wire                  nxt_readys;         // D-input of readys
  wire                  clk_fwd_en;         // clock enable to capture slave data and control
  wire                  clk_rev_en;         // clock enable to capture master read data and response
  wire                  master_fsm_clk_en;  // clock enable for master FSM
  wire                  clk_ready_en;       // clock enable for readys
  reg   [1:0]           nxt_master_state;   // D-Input of master_state FSM
  wire                  nxt_pselm;         // D-input of pselm
  reg                   pselm_int;  // Internal pselm

  reg                   hs_sel_req;         // Request to drive select line on master side
  reg                   readys;             // Transfer completion indication on slave side
  reg   [1:0]           master_state;       // state vector for master FSM
  

  // ---------------------------------------------------------------------------
  //  start of code
  // ---------------------------------------------------------------------------


  //----------------------------------------------------------------------------
  //                Slave interface req -> Master interface
  //----------------------------------------------------------------------------

  // Handshake signals (one for psel and other for penable) are initiated when
  // there's a pending request (pending_sel_req or pending_enb_req sampled high) and when previous
  // transfer is completed (synchronized acknowledge from core domain is low)

  assign pending_sel_req = psels;

  assign hs_sel_req_en  = pclkens &
                          ((~hs_sel_req & ~readys & pending_sel_req ) |
                           (hs_sel_req & hs_master_ack ));


  assign nxt_hs_sel_req = ~hs_sel_req & ~hs_master_ack & pending_sel_req;

  always @ (posedge pclk or negedge presetn)
    begin : p_hs_sel_seq
      if (!presetn)
        begin
          hs_sel_req <= 1'b0;
        end
      else if (hs_sel_req_en)
        begin
          hs_sel_req <= nxt_hs_sel_req;
        end
    end // p_hs_sel_seq


  //----------------------------------------------------------------------------
  //                Master interface ack -> Slave interface
  //----------------------------------------------------------------------------

  // readys will be asserted when the handshake completes (req=1 and ack =1)

  assign clk_ready_en = pclkens & (hs_master_ack & hs_sel_req  | readys);

  assign nxt_readys = hs_master_ack & hs_sel_req ;

  always @ (posedge pclk or negedge presetn)
    begin : p_pready_seq
      if (!presetn)
        readys <= 1'b1;
    else if (clk_ready_en)
        readys <= nxt_readys;
    end // p_pready_seq

  

  assign preadys = readys;
  

  //----------------------------------------------------------------------------
  // Incoming Data
  //----------------------------------------------------------------------------
  always @ (posedge pclk or negedge presetn)
    begin : p_rev_data_seq
      if (!presetn)
        begin
          {prdatas, pslverrs} <= {32'b0, 1'b1};
        end
      else if (nxt_readys && clk_ready_en)
        begin
          // Expand Reverse Payload
          {prdatas, pslverrs} <= rev_data;
        end
    end // p_rev_data_seq


  //----------------------------------------------------------------------------
  // Outgoing Data
  //----------------------------------------------------------------------------

  // Generate Clock Enable
  assign clk_fwd_en = ~hs_sel_req & ~readys & pending_sel_req & pclkens;

  // Concatenate Forward Payload
  assign nxt_fwd_data = {paddrs, pwdatas, pwrites};

  always @ (posedge pclk or negedge presetn)
    begin : p_fwd_data
      if (!presetn)
        begin
          fwd_data <= 65'b0;
        end
      else if(clk_fwd_en)
        begin
          fwd_data <= nxt_fwd_data;
        end
     end // p_fwd_data


  


  //----------------------------------------------------------------------------
  //                Slave interface req -> Master interface
  //----------------------------------------------------------------------------

  assign master_fsm_clk_en = pclkenm & (hs_sel_req | (master_state == ST_ACK));

  always @ (posedge pclk or negedge presetn)
    begin : p_master_state_seq
      if (!presetn)
        master_state <= ST_IDLE;
      else if (master_fsm_clk_en)
        master_state <= nxt_master_state;
    end // p_master_state_seq

  //----------------------------------------------------------------------------
  //  Master FSM
  //----------------------------------------------------------------------------
  // ST_IDLE  : Idle state of FSM. This is reset state. Moves to Setup phase
  //            when a request is received from the slave domain
  // ST_SETUP : Setup phase.pselm_int is driven high in this state.Moves to ST_ACCESS state next cycle
  // ST_ACCESS: Access phase. Moves to ST_ACK state when the ready is received
  //            from the target
  // ST_ACK   : In this state, the fsm waits for the handshake from slave interface
  //            before moving to IDLE state
  //----------------------------------------------------------------------------

  always @ *
  begin
    case (master_state)
      ST_IDLE:
        nxt_master_state = hs_sel_req ? ST_SETUP : ST_IDLE;
      ST_SETUP:
        nxt_master_state = ST_ACCESS;
      ST_ACCESS:
        nxt_master_state = preadym ? ST_ACK : ST_ACCESS;
      ST_ACK:
        nxt_master_state = ~hs_sel_req ? ST_IDLE : ST_ACK;
      default:
        nxt_master_state = 2'bxx;
    endcase
  end

  assign penablem = (master_state == ST_ACCESS);

  assign nxt_pselm = hs_sel_req & (master_state == ST_IDLE) |
                     (master_state == ST_SETUP) |
                     ~preadym & (master_state == ST_ACCESS);


  always @ (posedge pclk or negedge presetn)
    if (!presetn)
      pselm_int <= 1'b0;
    else if (master_fsm_clk_en)
      pselm_int <= nxt_pselm;

  assign pselm = pselm_int;

  // Expand Forward Payload
  assign {paddrm, pwdatam, pwritem} = fwd_data;

  //----------------------------------------------------------------------------
  // Outgoing Ack
  //----------------------------------------------------------------------------


  assign hs_master_ack = (master_state == ST_ACK);

  //----------------------------------------------------------------------------
  // Outgoing Data
  //----------------------------------------------------------------------------

  // Generate Clock Enable
  assign clk_rev_en = pclkenm & (master_state == ST_ACCESS) & preadym;

  // Concatenate Reverse Payload
  assign nxt_rev_data = {prdatam, pslverrm};

  always @ (posedge pclk or negedge presetn)
    if (!presetn)
      rev_data <= 33'b0;
    else if (clk_rev_en)
      rev_data <= nxt_rev_data;




`ifdef ARM_ASSERT_ON

  //----------------------------------------------------------------------------
  // OVL Assertions
  //----------------------------------------------------------------------------

  

  //----------------------------------------------------------------------------
  // data checks
  // data and control should match on slave and master ports when there is no
  // abort
  //----------------------------------------------------------------------------



  assert_never #(`OVL_ERROR, `OVL_ASSERT,
    "OVL Message : pwdata signals should match on slave and master interfaces")
      uzovl_cxapbsyncbridge_data_match
        (
         .clk         (pclk),
         .reset_n     (presetn),
         .test_expr   (pselm_int & psels & pwrites & pclkens &( pwdatas !=pwdatam ) )
        );


  assert_never #(`OVL_ERROR, `OVL_ASSERT,
    "OVL Message : pwrite signals should match on slave and master interfaces")
      uzovl_cxapbsyncbridge_control_match
        (
         .clk         (pclk),
         .reset_n     (presetn),
         .test_expr   (pselm_int & psels & pclkens &( pwrites !=pwritem ) )
        );


  assert_never #(`OVL_ERROR, `OVL_ASSERT,
    "OVL Message : paddr signals should match on slave and master interfaces")
      uzovl_cxapbsyncbridge_addr_match
        (
         .clk         (pclk),
         .reset_n     (presetn),
         .test_expr   (pselm_int & psels & pclkens &( paddrs !=paddrm) )
        );



  //----------------------------------------------------------------------------
  // Slave interface cannot accept a new data when master interface is busy
  //----------------------------------------------------------------------------


  assert_never #(`OVL_ERROR, `OVL_ASSERT,
    "OVL Message : Slave interface responds with ready while master is still busy")
      uzovl_cxapbsyncbridge_slv_stall
        (
         .clk         (pclk),
         .reset_n     (presetn),
         .test_expr   (pselm_int & preadys )
        );


`endif


endmodule //cxapbsyncbridge_full_full
