//-----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2010-2015 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//  Version and Release Control Information:
//
//
//  Checked In          : $Date: 2014-10-23 10:07:08 +0100 (Thu, 23 Oct 2014) $
//
//  File Revision       : $Revision: 40320 $
//
//  Release Information : CoreSight-SoC-TM100-r3p2-00rel0
//-----------------------------------------------------------------------------
// Verilog-2001 (IEEE Std 1364-2001)
//----------------------------------------------------------------------------


//-----------------------------------------------------------------------------
// Abstract : CoreSight Trace Atbupsizer (cxatbupsizer) - Top Level Block
//-----------------------------------------------------------------------------
//
// cxatbupsizer - CoreSight Trace Atbupsizer
// -------------------------------------
//
// CoreSight AMBA Trace Bus (ATB) trace link device used to combine multiple
// trace sources into a single bus.
//-----------------------------------------------------------------------------

module cxatbupsizer_64_128  (
  // Inputs
  input wire         clk,             // ATB clock
  input wire         resetn,          // ATB reset
  input wire         atvalids,        // Indication of valid ATB transfer
  input wire         afreadys,        // Indication to flush the internal buffer
  input wire [6:0]   atids,           // ID's for ATB transfers
  input wire [63:0] atdatas,
                                      // ATB data

  input wire [2:0]   atbytess,        // Indication of number of valid bytes
  input wire         atreadym,        // Indication of acceptance of ATB transfer
  input wire         afvalidm,        // Indication to flush the internal buffer
  input wire         syncreqm,        // Indication to send sync packets
  // Outputs
  output wire        atvalidm,        // Indication of valid ATB transfer
  output wire        afreadym,        // Indication of completion of flush transfer
  output wire [6:0]  atidm,           // ID's for ATB transfers
  output wire [127:0] atdatam,
                                      // ATB data

  output wire [3:0]  atbytesm,        // Indication of number of valid bytes
  output wire        atreadys,        // Indication of acceptance of ATB transfer
  output wire        afvalids,        // Indication to flush the internal buffer
  output reg         syncreqs         // Indication to send sync packets
  );

//------------------------------------------------------------------------------
// Local parameters definitions
//------------------------------------------------------------------------------

  // Converting XSL parameter to local parameter
  localparam ATB_SLAVE_DATA_WIDTH = 64;
  localparam ATB_MASTER_DATA_WIDTH = 128;


  // Slave side ATBYTES width calculation
  localparam ATBYTESS_WIDTH = 3;


  // Maximum number of valid Bytes possible on ATB slave side
  localparam ATBYTESS_MAX = 7;

  // Maximum number of valid Bytes possible on ATB slave side (atbytess + 1)
  localparam ATBYTESS_MAX_PLUS_ONE = 8;

  // Master side ATBYTES width calculation
  localparam ATBYTESM_WIDTH = 4;

  // Maximum number of valid Bytes possible on ATB master side
  localparam ATBYTESM_MAX = 15;

  // Maximum number of valid Bytes possible on ATB master side (atbytesm + 1)
  localparam ATBYTESM_MAX_PLUS_ONE = 16;

  // State machine states
  localparam ST_UPSIZER_IDLE = 2'h0;
  localparam ST_UPSIZER_FLUSH_WIDE_BUF = 2'h1;
  localparam ST_UPSIZER_1x = 2'h2;


  localparam ST_UPSIZER_FLUSH_IDLE = 2'b00;
  localparam ST_UPSIZER_FLUSH_SLAVE = 2'b01;
  localparam ST_UPSIZER_FLUSH_ONE_TIME = 2'b10;
  localparam ST_UPSIZER_FLUSH_TWO_TIMES = 2'b11;

  //----------------------------------------------------------------------------
  // Wires
  //----------------------------------------------------------------------------

  wire      slave_atb_hand_shake;    // Indication of completion of current
                                     // data transfer on ATB slave
  wire      master_atb_hand_shake;   // Indication of completion of current
                                     // data transfer on ATB master
  wire      write_narrow;            // Indication to write to narrow register
  wire      nxt_atreadys;            // D-Input of atreadys
  reg       atreadys_int;            // Internal usage of atreadys
  wire      stop_merge;                // Indication to stop merging
  wire      stop_merge_cond;           // OR of merge stop sources
  wire      nxt_stop_merge_cond_reg;   // D-input of stop_merge_cond_reg
  wire      nxt_flush_narrow;          // D-input of flush_narrow
  wire      nxt_narrow_buf_data_valid; // D input of narrow_buf_data_valid
  wire      stop_merge_atbytess_less;  // Merging stopped because of atbytess
  wire      stop_merge_atids;          // Merging stopped because of diff atids
  wire      stop_merge_flush;          // Merging stopped because of flush
  wire      nxt_narrow_buf_has_data;   // D-input of narrow_buf_has_data
  wire      upsizer_sm_flush_wide_buf; // flush_wide_buf state
  wire      upsizer_sm_idle;           // ST_UPSIZER_IDLE
  wire      reset_stop_merge_cond_reg; // reset the stop_merge_condition_reg
  wire      set_flush_narrow;          // set signal for flush_narrow register

  //----------------------------------------------------------------------------
  // Registers
  //----------------------------------------------------------------------------
  reg  [ATB_MASTER_DATA_WIDTH-1 : 0]  nxt_wide_fifo;              // D-Input of wide_fifo register
  reg  [ATB_MASTER_DATA_WIDTH-1 : 0]  wide_fifo;                  // wide fifo to drive atdatam
  reg  [ATBYTESS_WIDTH-1 : 0]         atbytes_narrow;             // Store the atbytess info when wide
                                                                  // buffer is full
  reg  [6:0]                          atid_narrow;                // Store the atids info when wide
                                                                  // buffer is full
  reg  [ATB_SLAVE_DATA_WIDTH-1 : 0]  atdatas_narrow;              // Store the atdatas info when wide
                                                                  // buffer is full
  reg  [1:0] nxt_upsizer_sm;           // D-input of upsizer_sm
  reg  [1:0] upsizer_sm;               // Upsizer fsm to count the
                                       // received packets and to drive
                                       // ATB stimulus on master side

  reg                                   stop_merge_cond_reg;      // Merge condition is registered
                                                                  // until acted by fsm
  reg [ATBYTESM_WIDTH-1 : 0]            nxt_atbytesm;             // D-Input of ATBYTESM
  reg [ATBYTESM_WIDTH-1 : 0]            atbytesm_int;             // Internal usage of ATBYTESM
  reg                                   nxt_atvalidm;             // D-Input of atvalidm register
  reg                                   atvalidm_int;             // Internal signal
  reg [6:0]                             nxt_atidm;                // D-Input of atidm register
  reg [6:0]                             atidm_int;                // Internal usage of atidm
  reg                                   nxt_afvalids;             // D-Input of afvalids register
  reg                                   afvalids_int;             // Internal version of afvalids
  reg                                   nxt_afreadym;             // D-Input of afreadym register
  reg                                   afreadym_int;             // Signal used internally
  reg                                   flush_narrow;             // flush narrow buffer
  reg                                   narrow_buf_data_valid;    // Data in narrow buffer is valid
  reg                                   narrow_buf_data_driven;   // Narrow bufferdata is accounted
  reg                                   narrow_buf_has_data;      // Narrow buffer has data
  reg  [1:0]                            nxt_upsizer_flush_sm;     // D-input of upsizer_flush_fsm
  reg  [1:0]                            upsizer_flush_sm;         // Flush fsm

  //============================================================================
  //
  // Main body of code
  // =================
  //

  // Output assignment

  assign atreadys = atreadys_int;
  assign afreadym = afreadym_int;
  assign atvalidm = atvalidm_int;
  assign atbytesm = atbytesm_int;
  assign atidm    = atidm_int;
  assign afvalids = afvalids_int;

  //============================================================================


  // Indication that slave and master side ATB data transfer handshake is
  // completed
  assign slave_atb_hand_shake = atvalids & atreadys_int;
  assign master_atb_hand_shake = atvalidm_int & atreadym;

 always @ *
   begin : p_upsizer_flush_sm_comb
     nxt_upsizer_flush_sm = upsizer_flush_sm;
     nxt_afreadym = 1'b0;
     nxt_afvalids = afvalids_int;

     case (upsizer_flush_sm)
       ST_UPSIZER_FLUSH_IDLE :
         begin
           if (afvalidm & !afreadym_int)
             begin
               nxt_upsizer_flush_sm = ST_UPSIZER_FLUSH_SLAVE;
               nxt_afvalids = 1'b1;
             end
         end

       ST_UPSIZER_FLUSH_SLAVE :
         begin
           if (afreadys)
             begin
               nxt_afvalids = 1'b0;
               if ((upsizer_sm == ST_UPSIZER_IDLE) ||
                   (!narrow_buf_has_data && master_atb_hand_shake))
                 begin
                   nxt_afreadym = 1'b1;
                   nxt_upsizer_flush_sm = ST_UPSIZER_FLUSH_IDLE;
                 end
               else if (narrow_buf_has_data && !master_atb_hand_shake)
                 begin
                   nxt_upsizer_flush_sm = ST_UPSIZER_FLUSH_TWO_TIMES;
                 end
               else if (narrow_buf_has_data && master_atb_hand_shake)
                 begin
                   nxt_upsizer_flush_sm = ST_UPSIZER_FLUSH_ONE_TIME;
                 end
               else
                 begin
                   nxt_upsizer_flush_sm = ST_UPSIZER_FLUSH_ONE_TIME;
                 end

             end
         end

       ST_UPSIZER_FLUSH_TWO_TIMES :
         begin
           if (master_atb_hand_shake)
             begin
               nxt_upsizer_flush_sm = ST_UPSIZER_FLUSH_ONE_TIME;
             end
         end

       ST_UPSIZER_FLUSH_ONE_TIME :
         begin
           if (master_atb_hand_shake)
             begin
               nxt_upsizer_flush_sm = ST_UPSIZER_FLUSH_IDLE;
               nxt_afreadym = 1'b1;
             end
         end
       default :
         begin
           nxt_upsizer_flush_sm = 2'bx;
           nxt_afreadym = 1'bx;
           nxt_afvalids = 1'bx;
         end

     endcase
   end // p_upsizer_flush_sm_comb


  always @ *
    begin : p_upsizer_sm_comb
      nxt_upsizer_sm = upsizer_sm;
      nxt_atvalidm   = atvalidm_int;
      nxt_atbytesm   = atbytesm_int;
      nxt_atidm      = atidm_int;
      nxt_wide_fifo  = wide_fifo;

      narrow_buf_data_driven = 1'b0;

      case (upsizer_sm)
        ST_UPSIZER_IDLE :
          begin
          if (stop_merge_atbytess_less)
              begin
                nxt_upsizer_sm = ST_UPSIZER_FLUSH_WIDE_BUF;
                nxt_atvalidm = 1'b1;
                nxt_atbytesm = atbytess;
                nxt_atidm    = atids;
                nxt_wide_fifo[ATB_SLAVE_DATA_WIDTH - 1: 0] = atdatas;
              end
            else if (atvalids)
              begin
                nxt_upsizer_sm = ST_UPSIZER_1x;
                nxt_atbytesm = atbytess;
                nxt_atidm    = atids;
                nxt_wide_fifo[ATB_SLAVE_DATA_WIDTH - 1: 0] = atdatas;
              end
          end

        ST_UPSIZER_1x :
          begin
            if (stop_merge)
              begin
                nxt_upsizer_sm = ST_UPSIZER_FLUSH_WIDE_BUF;
                nxt_atvalidm = 1'b1;
                if (stop_merge_atbytess_less && !stop_merge_atids && !stop_merge_flush)
                  begin
                    nxt_atbytesm = atbytesm_int + atbytess + 1;
                    nxt_wide_fifo[2*ATB_SLAVE_DATA_WIDTH - 1: ATB_SLAVE_DATA_WIDTH] = atdatas;
                  end
              end
            else if (atvalids)
              begin
                nxt_atbytesm = atbytesm_int + atbytess + 1;
                nxt_wide_fifo[2*ATB_SLAVE_DATA_WIDTH - 1: ATB_SLAVE_DATA_WIDTH] = atdatas;

                nxt_upsizer_sm = ST_UPSIZER_FLUSH_WIDE_BUF;
                nxt_atvalidm = 1'b1;

              end
          end



        ST_UPSIZER_FLUSH_WIDE_BUF :
          begin
            if (master_atb_hand_shake)
              begin
                nxt_atvalidm = 1'b0;
                if (flush_narrow)
                  begin
                    nxt_upsizer_sm = ST_UPSIZER_FLUSH_WIDE_BUF;
                    nxt_atvalidm = 1'b1;
                    nxt_atbytesm = atbytes_narrow;
                    nxt_atidm    = atid_narrow;
                    nxt_wide_fifo[ATB_SLAVE_DATA_WIDTH - 1: 0] = atdatas_narrow;
                    narrow_buf_data_driven = 1'b1;
                  end
                else if (narrow_buf_data_valid )
                  begin
                    if (stop_merge_flush)
                      begin
                        nxt_atvalidm = 1'b1;
                        nxt_upsizer_sm = ST_UPSIZER_FLUSH_WIDE_BUF;
                      end
                    else
                      begin
                        nxt_upsizer_sm = ST_UPSIZER_1x;
                       end
                    nxt_atbytesm = atbytes_narrow;
                    nxt_atidm    = atid_narrow;
                    nxt_wide_fifo[ATB_SLAVE_DATA_WIDTH - 1: 0] = atdatas_narrow;
                    narrow_buf_data_driven = 1'b1;
                  end
                  
                else if (narrow_buf_has_data)
                  begin
                    nxt_upsizer_sm = ST_UPSIZER_FLUSH_WIDE_BUF;
                    nxt_atvalidm = 1'b1;
                    nxt_atbytesm = atbytes_narrow;
                    nxt_atidm    = atid_narrow;
                    nxt_wide_fifo[ATB_SLAVE_DATA_WIDTH - 1: 0] = atdatas_narrow;
                    narrow_buf_data_driven = 1'b1;
                  end
                else if (atvalids)
                  begin
                    if (stop_merge_atbytess_less)
                      begin
                        nxt_upsizer_sm = ST_UPSIZER_FLUSH_WIDE_BUF;
                        nxt_atvalidm = 1'b1;
                        nxt_atbytesm = atbytess;
                        nxt_atidm    = atids;
                        nxt_wide_fifo[ATB_SLAVE_DATA_WIDTH - 1: 0] = atdatas;
                      end
                    else
                      begin
                        nxt_upsizer_sm = ST_UPSIZER_1x;
                        nxt_atbytesm = atbytess;
                        nxt_atidm    = atids;
                        nxt_wide_fifo[ATB_SLAVE_DATA_WIDTH - 1: 0] = atdatas;
                      end
                  end
                else
                  begin
                    nxt_upsizer_sm = ST_UPSIZER_IDLE;
                  end
              end
          end
        default  :
          begin
            nxt_upsizer_sm = 2'bx;
            nxt_atvalidm   = 1'bx;
            nxt_atbytesm   = {ATBYTESM_WIDTH{1'bx}};
            nxt_atidm      = 7'bx;
            nxt_wide_fifo  = {ATB_MASTER_DATA_WIDTH{1'bx}};
          end

      endcase
    end // p_upsizer_sm_comb

  // merge stop conditions are triggered on following conditions,
  // a) when the atids changes
  // b) when the slave side transfer is less than its maximum width.
  // c) when there is a flush condition.
     assign stop_merge_atbytess_less = (slave_atb_hand_shake & (atbytess != ATBYTESS_MAX));
    assign stop_merge_atids = (slave_atb_hand_shake & (upsizer_sm != ST_UPSIZER_IDLE) & (atids != atidm_int));
    assign stop_merge_flush = afvalids_int & afreadys & (upsizer_sm != ST_UPSIZER_IDLE);

    assign stop_merge_cond = stop_merge_atbytess_less | stop_merge_atids & (upsizer_sm != ST_UPSIZER_FLUSH_WIDE_BUF) | stop_merge_flush & (upsizer_sm != ST_UPSIZER_FLUSH_WIDE_BUF);

    assign upsizer_sm_flush_wide_buf = (upsizer_sm == ST_UPSIZER_FLUSH_WIDE_BUF);
    assign upsizer_sm_idle = (upsizer_sm == ST_UPSIZER_IDLE);
    assign reset_stop_merge_cond_reg = ((upsizer_sm_flush_wide_buf & master_atb_hand_shake) | (upsizer_sm_idle));

    assign nxt_stop_merge_cond_reg =  stop_merge_cond | (~reset_stop_merge_cond_reg & stop_merge_cond_reg) ;

    assign stop_merge = stop_merge_cond | stop_merge_cond_reg;

    assign set_flush_narrow = ~flush_narrow & (upsizer_sm == ST_UPSIZER_FLUSH_WIDE_BUF) &
                                (~master_atb_hand_shake & stop_merge_atbytess_less |
                                 stop_merge_flush & narrow_buf_data_valid & ~narrow_buf_data_driven);

    assign nxt_flush_narrow = set_flush_narrow | (~narrow_buf_data_driven & flush_narrow);


    assign nxt_narrow_buf_data_valid = (~narrow_buf_data_valid & ~stop_merge_atbytess_less & write_narrow) | (~narrow_buf_data_driven & narrow_buf_data_valid);

    assign nxt_narrow_buf_has_data = (~narrow_buf_has_data & write_narrow) | (~narrow_buf_data_driven & narrow_buf_has_data);

    assign write_narrow = (upsizer_sm == ST_UPSIZER_FLUSH_WIDE_BUF) & slave_atb_hand_shake & ~master_atb_hand_shake |
                          ((upsizer_sm != ST_UPSIZER_IDLE) & (upsizer_sm != ST_UPSIZER_FLUSH_WIDE_BUF) & (stop_merge_atids | slave_atb_hand_shake & stop_merge_flush));

    assign nxt_atreadys = ((upsizer_sm != ST_UPSIZER_FLUSH_WIDE_BUF) & ~nxt_narrow_buf_has_data) |
                          ((upsizer_sm == ST_UPSIZER_FLUSH_WIDE_BUF) & ~nxt_flush_narrow & ~nxt_narrow_buf_has_data);


  // Registering statemachine states and control
  always @(posedge clk or negedge resetn)
    begin : p_upsizer_sm_seq
      if (!resetn)
        begin
          upsizer_sm     <= ST_UPSIZER_IDLE;
          atvalidm_int   <= 1'b0;
          atidm_int      <= 7'b0;
          atbytesm_int   <= {(ATBYTESM_WIDTH){1'b0}};
          wide_fifo      <= {(ATB_MASTER_DATA_WIDTH){1'b0}};
          narrow_buf_has_data   <= 1'b0;
        end
      else
        begin
          upsizer_sm     <= nxt_upsizer_sm;
          atvalidm_int   <= nxt_atvalidm;
          atbytesm_int   <= nxt_atbytesm;
          atidm_int      <= nxt_atidm;
          wide_fifo      <= nxt_wide_fifo;
          narrow_buf_has_data   <= nxt_narrow_buf_has_data;
        end
    end // p_upsizer_ctl_seq
  assign atdatam = wide_fifo;

  // Registering control signals
  always @(posedge clk or negedge resetn)
    begin : p_upsizer_ctl_seq
      if (!resetn)
        begin
          stop_merge_cond_reg     <= 1'b0;
          flush_narrow            <= 1'b0;
          narrow_buf_data_valid   <= 1'b0;
          atreadys_int            <= 1'b1;
        end
      else
        begin
          stop_merge_cond_reg     <= nxt_stop_merge_cond_reg;
          flush_narrow            <= nxt_flush_narrow;
          narrow_buf_data_valid   <= nxt_narrow_buf_data_valid;
          atreadys_int            <= nxt_atreadys;
        end
    end // p_upsizer_ctl_seq

  // Registering flush logic
  always @(posedge clk or negedge resetn)
    begin : p_atbs_flush_seq
      if (!resetn)
        begin
          upsizer_flush_sm <= ST_UPSIZER_FLUSH_IDLE;
          afvalids_int <= 1'b0;
          afreadym_int <= 1'b1;
        end
      else
        begin
          upsizer_flush_sm <= nxt_upsizer_flush_sm;
          afvalids_int <= nxt_afvalids;
          afreadym_int <= nxt_afreadym;
        end
    end // p_atbs_flush_seq

  // Registering narrow buffers
  always @(posedge clk or negedge resetn)
    begin : p_narrow_buffer_seq
      if (!resetn)
        begin
          atbytes_narrow <= {ATBYTESS_WIDTH{1'b0}};
          atid_narrow    <= 7'b0;
          atdatas_narrow <= {ATB_SLAVE_DATA_WIDTH{1'b0}};
        end
      else if (write_narrow)
        begin
          atbytes_narrow <= atbytess;
          atid_narrow    <= atids;
          atdatas_narrow <= atdatas;
        end
    end // p_narrow_buffer_seq

  // Registering syncreqm
  always @(posedge clk or negedge resetn)
    begin : p_syncreqs_seq
      if (!resetn)
        begin
          syncreqs <= 1'b0;
        end
      else
        begin
          syncreqs <= syncreqm;
        end
    end // p_syncreqs_seq

`ifdef ARM_ASSERT_ON
  //----------------------------------------------------------------------------
  // OVL Assertions
  //----------------------------------------------------------------------------

localparam atdatas_width = 64;
localparam atdatam_width = 128;
  //----------------------------------------------------------------------------
  // Configuration check
  // Master ATDATA width cannot be lower than slave ATDATA width
  //----------------------------------------------------------------------------
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
    "OVL Message : Illegal configuration- ATDATAM width is lower then ATDATAS width")
      uzovl_cxatbupsizer_illegal_config
        (
         .clk         (clk),
         .reset_n     (resetn),
         .test_expr   (atdatas_width > atdatam_width)
        );


  //----------------------------------------------------------------------------
  // Narrow buffer will be loaded only when the data being put out by wide buffer
  // does not get accepted by slave or when a stop_merge condition is reached
  //----------------------------------------------------------------------------
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
    "OVL Message : Narrow buffer written while wide buffer is free or without stop_merge condition")
      uzovl_cxatbupsizer_narrow_buf_used
        (
         .clk         (clk),
         .reset_n     (resetn),
         .test_expr   (write_narrow & ~((atvalidm & ~atreadym)| stop_merge))
        );

  //----------------------------------------------------------------------------
  // Transactions will always be accepted at slave port while narrow buffer is empty
  //----------------------------------------------------------------------------
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
    "OVL Message : Slave transaction not accepted while narrow buffer is empty")
      uzovl_cxatbupsizer_atreadys_narrow_buf_empty
        (
         .clk         (clk),
         .reset_n     (resetn),
         .test_expr   (~narrow_buf_has_data & ~atreadys & atvalids)
        );

  //----------------------------------------------------------------------------
  // When wide buffer becomes full, atvalidm should be asserted
  //----------------------------------------------------------------------------
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
    "OVL Message : atvalidm not asserted when wide buffer is full")
      uzovl_cxatbupsizer_assert_atvalidm_wide_buf_full
        (
         .clk         (clk),
         .reset_n     (resetn),
         .test_expr   (nxt_upsizer_sm == ST_UPSIZER_FLUSH_WIDE_BUF & ~stop_merge & ~nxt_atvalidm)
        );


  //----------------------------------------------------------------------------
  // When a stop merge condition is reached, atvalidm should be asserted
  // if a valid data present in upsizer
  //----------------------------------------------------------------------------
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
    "OVL Message : atvalidm not asserted when  a stop merge condition is reached and  valid data present in upsizer")
      uzovl_cxatbupsizer_assert_atvalidm_stop_merge
        (
         .clk         (clk),
         .reset_n     (resetn),
         .test_expr   (stop_merge_cond_reg & ~atvalidm & (upsizer_sm != ST_UPSIZER_IDLE | atvalids))
        );

    assert_never_unknown #(`OVL_FATAL, 1, `OVL_ASSERT, " Signal slave_atb_hand_shake is X")
    uzovl_cxatbupsizer_xcheck_slave_atb_hand_shake (.clk       (clk),
                                  .reset_n   (resetn),
                                  .qualifier (1'b1),
                                  .test_expr (slave_atb_hand_shake));

    assert_never_unknown #(`OVL_FATAL, 1, `OVL_ASSERT, " Signal master_atb_hand_shake is X")
    uzovl_cxatbupsizer_xcheck_master_atb_hand_shake (.clk       (clk),
                                  .reset_n   (resetn),
                                  .qualifier (1'b1),
                                  .test_expr (master_atb_hand_shake));









`endif


endmodule // cxatbupsizer
