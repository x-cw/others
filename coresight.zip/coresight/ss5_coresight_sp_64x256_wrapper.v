//-----------------------------------------------------------------------------
// Purpose : 64x256 RAM memory 
//           ------------------------------------------------------------------
//           RAM height: 64
//           RAM width:  256
//           RAM lanes:  1
//           RAM ports:  1
//-----------------------------------------------------------------------------

module ss5_coresight_sp_64x256_wrapper (
  // clocks and resets:
  clk,
  // DFT signals:
  mem_cen,
  mem_wen,
  mem_addr,
  memd,
  memq
  );

  //===========================================================================
  // parameters
  //===========================================================================
  localparam WIDTH                          = 256;
  localparam DEPTH                          = 6;
  localparam HEIGHT                         = 64;
  //===========================================================================
  // port declarations
  //===========================================================================

  //---------------------------------------------------------------------------
  // clocks and resets
  //---------------------------------------------------------------------------
  input wire                                clk;                       // clock

  //---------------------------------------------------------------------------
  // write/read interface
  //---------------------------------------------------------------------------
  input wire                                mem_cen;                      // chip enable
  input wire                                mem_wen;                      // write enable
  input wire                    [DEPTH-1:0] mem_addr;                     // address
  input wire                    [WIDTH-1:0] memd;                        // write data
  output wire                   [WIDTH-1:0] memq;                        // read data


`ifndef REG_MEM
ln05lpe_a00_mc_rf1r_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 etf_mem_u0(/*autoinst*/
                                   // Outputs
                                   .DOUT                (memq[127:0]), // Templated
                                   .SO_D_L              ( ),             // Templated
                                   .SO_D_R              ( ),             // Templated
                                   // Inputs
                                   .CK                  (clk),     // Templated
                                   .CSN                 (mem_cen),    // Templated
                                   .WEN                 (mem_wen),    // Templated
                                   .A                   (mem_addr[5:0]), // Templated
                                   .DI                  (memd[127:0]), // Templated

                                   .MCS                 (2'b01    ),
                                   .MCSW                (1'b0     ),
                                   .SI_D_L              ('0       ),
                                   .SI_D_R              ('0       ),
                                   .DFTRAM              ('0       ),
                                   .SE                  ('0       ),
                                   .RET                 ('0       ),
                                   .CRE1                ('0       ),
                                   .CRE2                ('0       ),
                                   .FCA1                ('0       ),
                                   .FCA2                ('0       ),
                                   .ADME                (3'b100       ));

ln05lpe_a00_mc_rf1r_hsr_lvt_64x128m2b1c1_SS5_coresight_SP_64X128 etf_mem_u1(/*autoinst*/
                                   // Outputs
                                   .DOUT                (memq[255:128]), // Templated
                                   .SO_D_L              ( ),             // Templated
                                   .SO_D_R              ( ),             // Templated

                                   // Inputs
                                   .CK                  (clk),     // Templated
                                   .CSN                 (mem_cen),    // Templated
                                   .WEN                 (mem_wen),    // Templated
                                   .A                   (mem_addr[5:0]), // Templated
                                   .DI                  (memd[255:128]), // Templated

                                   .MCS                 (2'b01    ),
                                   .MCSW                (1'b0     ),
                                   .SI_D_L              ('0       ),
                                   .SI_D_R              ('0       ),
                                   .DFTRAM              ('0       ),
                                   .SE                  ('0       ),
                                   .RET                 ('0       ),
                                   .CRE1                ('0       ),
                                   .CRE2                ('0       ),
                                   .FCA1                ('0       ),
                                   .FCA2                ('0       ),
                                   .ADME                (3'b100   ));

`else
                           mem_sp_for_fpga 
                             #(
                               .DEPTH                           (DEPTH),
                               .HEIGHT                          (HEIGHT),
                               .WIDTH                           (WIDTH)
                             )
                             u_mem_sp
                               (
                                 .clk                           (clk),
                                 .ce0                           (~mem_cen),
                                 .we0                           (~mem_wen),
                                 .a0                            (mem_addr),
                                 .di0                           (memd),
                                 .do0                           (memq)
                               );
`endif                               
endmodule
