`include "../general/general.vh"

module mem_1r1w
  #( parameter
     MEM_WORDS=0,
     MEM_WIDTH=0,

     L2_MEM_WORDS=log2(MEM_WORDS)
     ) (
        input wire [MEM_WIDTH-1:0]    din,
        input wire [L2_MEM_WORDS-1:0] rd_addr,
        input wire                    rd_clk,
        input wire                    rd_en,

        input wire [L2_MEM_WORDS-1:0] wr_addr,
        input wire                    wr_clk,
        input wire                    wr_en,

        output wire [MEM_WIDTH-1:0]   dout
        );

  localparam MEM_BIT_EN=0;
  parameter MODULE_NAME = "NONE"; 
  
`include "../general/misc.vh"
  //leda NTL_CON12 off
  wire [MEM_WIDTH-1:0] dout_internal;
  //leda NTL_CON12 on
  wire [MEM_WIDTH-1:0] bit_en_internal={MEM_WIDTH{1'b1}};

//`ifdef SYNTHESIS
  assign dout=dout_internal;

//`else
//  reg rd_en_last;
//  reg [L2_MEM_WORDS-1:0] rd_addr_last;
//  reg wr_en_last;
//  reg [L2_MEM_WORDS-1:0] wr_addr_last;
//  always @(posedge rd_clk) begin
//    rd_en_last<=rd_en;
//    rd_addr_last<=rd_addr;
//    wr_en_last<=wr_en;
//    wr_addr_last<=wr_addr;
//  end
//    
//  
//  assign dout=(wr_addr_last==rd_addr_last && 
//               wr_en_last && rd_en_last) ? {MEM_WIDTH{1'bx}} : 
//              (rd_en_last && rd_addr_last >= MEM_WORDS) ?  {MEM_WIDTH{1'bx}} :
//              dout_internal;
//
// `ifdef MEMORY_CHECK_ENABLES
//  
//  reg rd_en_at_reset;
//  initial begin
//    #10;
//    rd_en_at_reset=rd_en;
//    rd_en_assert_at_reset: assert (rd_en_at_reset==0) else
//      $warning("rd_en asserted at reset.");
//  end
//
//  wr_over_and_over: assert property (@(posedge wr_clk)
//                                     wr_en==1[*2] |-> wr_addr!=$past(wr_addr,1))
//    else $warning("writing to the same address in multiple clocks");
//
//  rd_over_and_over: assert property (@(posedge rd_clk)
//                                     disable iff(rd_en_at_reset==1)
//                                     rd_en==1[*2] |-> rd_addr!=$past(rd_addr,1))
//    else $warning("readed from the same address in multiple clocks");
// `endif

//  params_not_defined: assert property (@(posedge rd_clk) L2_MEM_WORDS!=0 && MEM_WIDTH!=0) else
//    $fatal(0,"addr_bits or ram_width = 0");
//
//  rd_clk_not_defined: assert property (@(posedge rd_en) rd_en==1 |-> rd_clk===1'b1 || rd_clk===1'b0) else
//    $fatal(0,"rd clock not defined");
//  wr_clk_not_defined: assert property (@(posedge wr_en) wr_en==1 |-> wr_clk===1'b1 || wr_clk===1'b0) else
//    $fatal(0,"wr clock not defined");
//
//  
//  // VCS coverage off
//  event              dv_bd_wr;
//  event              dv_bd_wr_ack;
//  reg [31:0]         dv_bd_wr_addr;
//  reg [31:0]         dv_bd_wr_bit_en;
//  reg [31:0]         dv_bd_din;
//  
//  event              dv_bd_rd;
//  event              dv_bd_rd_ack;
//  reg [31:0]         dv_bd_rd_addr;
//  reg [31:0]         dv_bd_dout;
//  // VCS coverage on
//  
//`endif
  
`ifdef ASIC  
   mem_1r1w_flops
     #(/*autoinstparam*/
       // Parameters
       .MEM_WORDS                        (MEM_WORDS),
       .MEM_WIDTH                        (MEM_WIDTH),
       .MEM_BIT_EN                       (MEM_BIT_EN),
       .L2_MEM_WORDS                     (L2_MEM_WORDS))
   flops(/*autoinst*/
            // Outputs
            .dout_internal                  (dout_internal[MEM_WIDTH-1:0]),
            // Inputs
            .din                            (din[MEM_WIDTH-1:0]),
            .rd_addr                        (rd_addr[L2_MEM_WORDS-1:0]),
            .rd_clk                         (rd_clk),
            .rd_en                          (rd_en),
            .wr_addr                        (wr_addr[L2_MEM_WORDS-1:0]),
            .wr_clk                         (wr_clk),
            .wr_en                          (wr_en),
            .bit_en_internal                (bit_en_internal[MEM_WIDTH-1:0]));
`else

    `ifdef FPGA
      mem_1r1w_flops
        #(/*autoinstparam*/
          // Parameters
          .MEM_WORDS                        (MEM_WORDS),
          .MEM_WIDTH                        (MEM_WIDTH),
          .MEM_BIT_EN                       (MEM_BIT_EN),
          .L2_MEM_WORDS                     (L2_MEM_WORDS))
      flops(/*autoinst*/
            // Outputs
            .dout_internal                  (dout_internal[MEM_WIDTH-1:0]),
            // Inputs
            .din                            (din[MEM_WIDTH-1:0]),
            .rd_addr                        (rd_addr[L2_MEM_WORDS-1:0]),
            .rd_clk                         (rd_clk),
            .rd_en                          (rd_en),
            .wr_addr                        (wr_addr[L2_MEM_WORDS-1:0]),
            .wr_clk                         (wr_clk),
            .wr_en                          (wr_en),
            .bit_en_internal                (bit_en_internal[MEM_WIDTH-1:0]));
    `else
    generate
       if (MODULE_NAME == "CODEC_SLC_AFIFO")
       begin : afifo_code_slc_lvt
           slc_fifo_abstraction #(
           .FIFO_WORD (MEM_WORDS),
           .FIFO_WIDTH (MEM_WIDTH),
           .FIFO_LOG2WORD (L2_MEM_WORDS),
           .MEM_BIT_EN (1'b1),
           .PORT_TYPE ("DUALC")
           
           ) slc_fifo_abstraction_async(
          // Outputs
               .rd_data (dout),
          // Inputs
               .wr_clk(wr_clk), 
               .wr_en(wr_en), 
               .wr_addr(wr_addr), 
               .wr_data(din), 
               .wr_strb({(MEM_WIDTH){1'b1}}), 
               .rd_clk(rd_clk), 
               .rd_en(rd_en), 
               .rd_addr(rd_addr)       
           );
       end
       else begin :mem_UNDEFxUNDEF
         //MEMORY_CASE_LINES_END
       
       `ifdef MEM_NOT_FATAL_IF_NOT_DEFINED
                 initial assert (0) else
                   $warning("MEMORY 1r1w %dx%d requested but not built",MEM_WORDS,MEM_WIDTH);
       //               mem_1r1w
       //     #(.MEM_WORDS(MEM_WORDS), .MEM_WIDTH(MEM_WIDTH)) 
       //     ram (
       //    	.wr_clk(actual_wr_clk),
       //    	.wr_en(actual_wr_en),
       //    	.wr_addr(wr_addr),
       //    	.din(din),
       //    	.rd_clk(actual_rd_clk),
       //    	.rd_en(actual_rd_en),
       //    	.rd_addr(rd_addr),
       //    	.dout(dout_tmp)
       //        );
         mem_1r1w_flops
           #(/*autoinstparam*/
             // Parameters
             .MEM_WORDS                        (MEM_WORDS),
             .MEM_WIDTH                        (MEM_WIDTH),
             .MEM_BIT_EN                       (MEM_BIT_EN),
             .L2_MEM_WORDS                     (L2_MEM_WORDS))
         flops(/*autoinst*/
               // Outputs
               .dout_internal                  (dout_internal[MEM_WIDTH-1:0]),
               // Inputs
               .din                            (din[MEM_WIDTH-1:0]),
               .rd_addr                        (rd_addr[L2_MEM_WORDS-1:0]),
               .rd_clk                         (rd_clk),
               .rd_en                          (rd_en),
               .wr_addr                        (wr_addr[L2_MEM_WORDS-1:0]),
               .wr_clk                         (wr_clk),
               .wr_en                          (wr_en),
               .bit_en_internal                (bit_en_internal[MEM_WIDTH-1:0]));
       
       `else
       initial assert (0) else
                   $fatal("MEMORY %dx%d requested but not built",MEM_WORDS,MEM_WIDTH);
                 mem_model_not_defined #(
                                         .MEM_WORDS(MEM_WORDS),
                                         .MEM_WIDTH(MEM_WIDTH)
                                         ) mem();
       
       `endif
      end
      endgenerate
    
    `endif
`endif
//  wire WAEN=~wr_en;
//  wire RBEN=~rd_en;
//  wire WACLK=wr_clk;
//  wire RBCLK=rd_clk;
//  
//  localparam OFFSET=1000;
//  localparam MEMORY=MEM_WORDS * OFFSET + MEM_WIDTH;
//
//      /* 
//       //MEMORY_AUTO_LINES_BEGIN
//        mem_2048x16_2rw_ben0_ra_8 auto_template
//        mem_4096x8_2rw_ben0_ra_16 auto_template
//        (.CLKA(rd_clk),
//        .CENA(~rd_en),
//        .QA(dout_internal[]),
//        .AA(rd_addr[]),
//        .DA({@"vl-width"{1'b0}}),
//        .BWENA({@"vl-width"{1'b1}}),
//        .WENA(1'b1),
//        .CLKB(wr_clk),
//        .CENB(~wr_en),
//        .DB(din[]),
//        .QB(),
//        .AB(wr_addr[]),
//        .BWENB(~bit_en_internal[]),
//        .WENB(~wr_en),
//        );
//
//       //MEMORY_AUTO_LINES_END
//     */
//
//  
//  generate
//    //if (MEM_WORDS * MEM_WIDTH <= 65536) begin: flops
//    //if (MEM_WORDS * MEM_WIDTH <= 4096) begin: flops
//    if (MEM_WORDS * MEM_WIDTH <= 2048 * 2) begin: flops
//
////`ifndef SYNTHESIS
//// // VCS coverage off
//// // Backdoor Access Interface:
//// always @(dv_bd_wr) begin
////   flops.dv_bd_wr_addr = dv_bd_wr_addr;
////   flops.dv_bd_wr_bit_en = dv_bd_wr_bit_en;
////   flops.dv_bd_din = dv_bd_din;
////   ->flops.dv_bd_wr;
////   @(flops.dv_bd_wr_ack);
////   ->dv_bd_wr_ack;
//// end
//// always @(dv_bd_rd) begin
////   flops.dv_bd_rd_addr = dv_bd_rd_addr;
////   ->flops.dv_bd_rd;
////   @(flops.dv_bd_rd_ack);
////   dv_bd_dout = flops.dv_bd_dout;
////   ->dv_bd_rd_ack;
//// end
//// // VCS coverage on
////`endif
//
//      mem_1r1w_flops #(/*autoinstparam*/
//                       // Parameters
//                       .MEM_WORDS       (MEM_WORDS),
//                       .MEM_WIDTH       (MEM_WIDTH),
//                       .MEM_BIT_EN      (MEM_BIT_EN),
//                       .L2_MEM_WORDS    (L2_MEM_WORDS)) 
//      flops(/*autoinst*/
//            // Outputs
//            .dout_internal              (dout_internal[MEM_WIDTH-1:0]),
//            // Inputs
//            .din                        (din[MEM_WIDTH-1:0]),
//            .rd_addr                    (rd_addr[L2_MEM_WORDS-1:0]),
//            .rd_clk                     (rd_clk),
//            .rd_en                      (rd_en),
//            .wr_addr                    (wr_addr[L2_MEM_WORDS-1:0]),
//            .wr_clk                     (wr_clk),
//            .wr_en                      (wr_en),
//            .bit_en_internal            (bit_en_internal[MEM_WIDTH-1:0]));
//    end else begin: rams
//      //leda off
//      case(MEMORY)
//        //MEMORY_CASE_LINES_BEGIN
//`ifndef MEMORY_SCAN
//   ('d1024 * OFFSET + 'd16): begin: mem_1024x16
//     spram_1024x16_wrap u_spram_1024x16_wrap(
//            .CLKW    (wr_clk),
//            .WEB     (~wr_en),
//            .AA      (wr_addr[L2_MEM_WORDS-1:0]),
//            .D       (din[MEM_WIDTH-1:0]),
//  
//            .CLKR    (rd_clk),
//            .REB     (~rd_en),
//            .AB      (rd_addr[L2_MEM_WORDS-1:0]),
//            .Q       (dout_internal[MEM_WIDTH-1 :0]) 
//     );
//   end
//
//   ('d1024 * OFFSET + 'd269): begin: mem_1024x269
//     spram_1024x269_wrap u_spram_1024x269_wrap(
//            .CLKW    (wr_clk),
//            .WEB     (~wr_en),
//            .AA      (wr_addr[L2_MEM_WORDS-1:0]),
//            .D       (din[MEM_WIDTH-1:0]),
//  
//            .CLKR    (rd_clk),
//            .REB     (~rd_en),
//            .AB      (rd_addr[L2_MEM_WORDS-1:0]),
//            .Q       (dout_internal[MEM_WIDTH-1 :0]) 
//     );
//   end
//
//   ('d1024 * OFFSET + 'd257): begin: mem_1024x257
//     spram_1024x257_wrap u_spram_1024x257_wrap(
//            .CLKW    (wr_clk),
//            .WEB     (~wr_en),
//            .AA      (wr_addr[L2_MEM_WORDS-1:0]),
//            .D       (din[MEM_WIDTH-1:0]),
//  
//            .CLKR    (rd_clk),
//            .REB     (~rd_en),
//            .AB      (rd_addr[L2_MEM_WORDS-1:0]),
//            .Q       (dout_internal[MEM_WIDTH-1 :0]) 
//     );
//   end
//
//   ('d2048 * OFFSET + 'd16): begin: mem_2048x16
//     spram_2048x16_wrap u_spram_2048x16_wrap(
//            .CLKW    (wr_clk),
//            .CLKR    (rd_clk),
//            .WEB     (~wr_en),
//            .AA      (wr_addr[L2_MEM_WORDS-1:0]),
//            .D       (din[MEM_WIDTH-1:0]),
//  
//            .REB     (~rd_en),
//            .AB      (rd_addr[L2_MEM_WORDS-1:0]),
//            .Q       (dout_internal[MEM_WIDTH-1 :0]) 
//     );
//   end
//
//   ('d4096 * OFFSET + 'd16): begin: mem_4096x16
//     spram_4096x16_wrap u_spram_4096x16_wrap(
//            .CLKW    (wr_clk),
//            .CLKR    (rd_clk),
//            .WEB     (~wr_en),
//            .AA      (wr_addr[L2_MEM_WORDS-1:0]),
//            .D       (din[MEM_WIDTH-1:0]),
//  
//            .REB     (~rd_en),
//            .AB      (rd_addr[L2_MEM_WORDS-1:0]),
//            .Q       (dout_internal[MEM_WIDTH-1 :0]) 
//     );
//   end
//
//   ('d8192 * OFFSET + 'd16): begin: mem_8192x16
//     spram_8192x16_wrap u_spram_8192x16_wrap(
//            .CLKW    (wr_clk),
//            .CLKR    (rd_clk),
//            .WEB     (~wr_en),
//            .AA      (wr_addr[L2_MEM_WORDS-1:0]),
//            .D       (din[MEM_WIDTH-1:0]),
//  
//            .REB     (~rd_en),
//            .AB      (rd_addr[L2_MEM_WORDS-1:0]),
//            .Q       (dout_internal[MEM_WIDTH-1 :0]) 
//     );
//   end
//
//   ('d1024 * OFFSET + 'd24): begin: mem_1024x24
//     spram_1024x24_wrap u_spram_1024x24_wrap(
//            .CLKW    (wr_clk),
//            .CLKR    (rd_clk),
//            .WEB     (~wr_en),
//            .AA      (wr_addr[L2_MEM_WORDS-1:0]),
//            .D       (din[MEM_WIDTH-1:0]),
//  
//            .REB     (~rd_en),
//            .AB      (rd_addr[L2_MEM_WORDS-1:0]),
//            .Q       (dout_internal[MEM_WIDTH-1 :0]) 
//     );
//   end
//
//   ('d2048 * OFFSET + 'd24): begin: mem_2048x24
//     spram_2048x24_wrap u_spram_2048x24_wrap(
//            .CLKW    (wr_clk),
//            .CLKR    (rd_clk),
//            .WEB     (~wr_en),
//            .AA      (wr_addr[L2_MEM_WORDS-1:0]),
//            .D       (din[MEM_WIDTH-1:0]),
//  
//            .REB     (~rd_en),
//            .AB      (rd_addr[L2_MEM_WORDS-1:0]),
//            .Q       (dout_internal[MEM_WIDTH-1 :0]) 
//     );
//   end
//
//   ('d2048 * OFFSET + 'd36): begin: mem_2048x36
//     rf_2048x36_2p_2clk_wrap u_rf_2048x36_2p_2clk_wrap(
//            .CLKW    (wr_clk),
//            .CLKR    (rd_clk),
//            .WEB     (~wr_en),
//            .AA      (wr_addr[L2_MEM_WORDS-1:0]),
//            .D       (din[MEM_WIDTH-1:0]),
//  
//            .REB     (~rd_en),
//            .AB      (rd_addr[L2_MEM_WORDS-1:0]),
//            .Q       (dout_internal[MEM_WIDTH-1 :0]) 
//     );
//   end
//
//   ('d4096 * OFFSET + 'd36): begin: mem_4096x36
//     rf_4096x36_2p_2clk_wrap u_rf_4096x36_2p_2clk_wrap(
//            .CLKW    (wr_clk),
//            .CLKR    (rd_clk),
//            .WEB     (~wr_en),
//            .AA      (wr_addr[L2_MEM_WORDS-1:0]),
//            .D       (din[MEM_WIDTH-1:0]),
//  
//            .REB     (~rd_en),
//            .AB      (rd_addr[L2_MEM_WORDS-1:0]),
//            .Q       (dout_internal[MEM_WIDTH-1 :0]) 
//     );
//   end
//
//        ('d64 * OFFSET + 'd130): begin: mem_64x130
//         rf_64x130_2p_2clk_wrap u_rf_64x130_2p_wrap(
//                .CLKW    (wr_clk),
//                .WEB     (~wr_en),
//                .AA      (wr_addr[L2_MEM_WORDS-1:0]),
//                .D       (din[MEM_WIDTH-1:0]),
//          
//                .CLKR    (rd_clk),
//                .REB     (~rd_en),
//                .AB      (rd_addr[L2_MEM_WORDS-1:0]),
//                .Q       (dout_internal[MEM_WIDTH-1 :0]) 
//          );
//        end
//
//        ('d64 * OFFSET + 'd128): begin: mem_64x128
//         rf_64x128_2p_2clk_wrap u_rf_64x128_2p_wrap(
//                .CLKW    (wr_clk),
//                .WEB     (~wr_en),
//                .AA      (wr_addr[L2_MEM_WORDS-1:0]),
//                .D       (din[MEM_WIDTH-1:0]),
//          
//                .CLKR    (rd_clk),
//                .REB     (~rd_en),
//                .AB      (rd_addr[L2_MEM_WORDS-1:0]),
//                .Q       (dout_internal[MEM_WIDTH-1 :0]) 
//          );
//        end
//
//
//        ('d64 * OFFSET + 'd258): begin: mem_64x258
//         rf_64x258_2p_2clk_wrap u_rf_64x258_2p_wrap(
//                .CLKW    (wr_clk),
//                .WEB     (~wr_en),
//                .AA      (wr_addr[L2_MEM_WORDS-1:0]),
//                .D       (din[MEM_WIDTH-1:0]),
//          
//                .CLKR    (rd_clk),
//                .REB     (~rd_en),
//                .AB      (rd_addr[L2_MEM_WORDS-1:0]),
//                .Q       (dout_internal[MEM_WIDTH-1 :0]) 
//          );
//        end
//
//        ('d32 * OFFSET + 'd256): begin: mem_32x256
//         rf_32x256_2p_2clk_wrap u_rf_32x256_2p_wrap(
//                .CLKW    (wr_clk),
//                .WEB     (~wr_en),
//                .AA      (wr_addr[L2_MEM_WORDS-1:0]),
//                .D       (din[MEM_WIDTH-1:0]),
//          
//                .CLKR    (rd_clk),
//                .REB     (~rd_en),
//                .AB      (rd_addr[L2_MEM_WORDS-1:0]),
//                .Q       (dout_internal[MEM_WIDTH-1 :0]) 
//          );
//        end
//
//        ('d64 * OFFSET + 'd256): begin: mem_64x256
//         rf_64x256_2p_2clk_wrap u_rf_64x256_2p_wrap(
//                .CLKW    (wr_clk),
//                .WEB     (~wr_en),
//                .AA      (wr_addr[L2_MEM_WORDS-1:0]),
//                .D       (din[MEM_WIDTH-1:0]),
//          
//                .CLKR    (rd_clk),
//                .REB     (~rd_en),
//                .AB      (rd_addr[L2_MEM_WORDS-1:0]),
//                .Q       (dout_internal[MEM_WIDTH-1 :0]) 
//          );
//        end
//
//        ('d128 * OFFSET + 'd128): begin: mem_128x128
//         spram_128x128_wrap u_spram_128x128_wrap(
//                .CLKW    (wr_clk),
//                .WEB     (~wr_en),
//                .AA      (wr_addr[L2_MEM_WORDS-1:0]),
//                .D       (din[MEM_WIDTH-1:0]),
//          
//                .CLKR    (rd_clk),
//                .REB     (~rd_en),
//                .AB      (rd_addr[L2_MEM_WORDS-1:0]),
//                .Q       (dout_internal[MEM_WIDTH-1 :0]) 
//          );
//        end
//
//        ('d128 * OFFSET + 'd130): begin: mem_128x130
//         spram_128x130_wrap u_spram_128x130_wrap(
//                .CLKW    (wr_clk),
//                .WEB     (~wr_en),
//                .AA      (wr_addr[L2_MEM_WORDS-1:0]),
//                .D       (din[MEM_WIDTH-1:0]),
//          
//                .CLKR    (rd_clk),
//                .REB     (~rd_en),
//                .AB      (rd_addr[L2_MEM_WORDS-1:0]),
//                .Q       (dout_internal[MEM_WIDTH-1 :0]) 
//          );
//        end
//
//        ('d128 * OFFSET + 'd256): begin: mem_128x256
//         spram_128x256_wrap u_spram_128x256_wrap(
//                .CLKW    (wr_clk),
//                .WEB     (~wr_en),
//                .AA      (wr_addr[L2_MEM_WORDS-1:0]),
//                .D       (din[MEM_WIDTH-1:0]),
//          
//                .CLKR    (rd_clk),
//                .REB     (~rd_en),
//                .AB      (rd_addr[L2_MEM_WORDS-1:0]),
//                .Q       (dout_internal[MEM_WIDTH-1 :0]) 
//          );
//        end
//
//        ('d256 * OFFSET + 'd256): begin: mem_256x256
//         spram_256x256_wrap u_spram_256x256_wrap(
//                .CLKW    (wr_clk),
//                .WEB     (~wr_en),
//                .AA      (wr_addr[L2_MEM_WORDS-1:0]),
//                .D       (din[MEM_WIDTH-1:0]),
//          
//                .CLKR    (rd_clk),
//                .REB     (~rd_en),
//                .AB      (rd_addr[L2_MEM_WORDS-1:0]),
//                .Q       (dout_internal[MEM_WIDTH-1 :0]) 
//          );
//        end
//
//        ('d128 * OFFSET + 'd258): begin: mem_128x258
//         spram_128x258_wrap u_spram_128x258_wrap(
//                .CLKW    (wr_clk),
//                .WEB     (~wr_en),
//                .AA      (wr_addr[L2_MEM_WORDS-1:0]),
//                .D       (din[MEM_WIDTH-1:0]),
//          
//                .CLKR    (rd_clk),
//                .REB     (~rd_en),
//                .AB      (rd_addr[L2_MEM_WORDS-1:0]),
//                .Q       (dout_internal[MEM_WIDTH-1 :0]) 
//          );
//        end
//
//        ('d128 * OFFSET + 'd280): begin: mem_128x280
//         spram_128x280_2p_2clk_wrap u_spram_128x280_wrap(
//                .CLKW    (wr_clk),
//                .WEB     (~wr_en),
//                .AA      (wr_addr[L2_MEM_WORDS-1:0]),
//                .D       (din[MEM_WIDTH-1:0]),
//          
//                .CLKR    (rd_clk),
//                .REB     (~rd_en),
//                .AB      (rd_addr[L2_MEM_WORDS-1:0]),
//                .Q       (dout_internal[MEM_WIDTH-1 :0]) 
//          );
//        end
//
//        ('d32 * OFFSET + 'd290): begin: rf_32x290
//         rf_32x290_2p_2clk_wrap u_rf_32x290_2p_wrap(
//                .CLKW    (wr_clk),
//                .WEB     (~wr_en),
//                .AA      (wr_addr[L2_MEM_WORDS-1:0]),
//                .D       (din[MEM_WIDTH-1:0]),
//          
//                .CLKR    (rd_clk),
//                .REB     (~rd_en),
//                .AB      (rd_addr[L2_MEM_WORDS-1:0]),
//                .Q       (dout_internal[MEM_WIDTH-1 :0]) 
//          );
//        end
//
//        ('d32 * OFFSET + 'd146): begin: rf_32x146
//         rf_32x146_2p_wrap u_rf_32x146_2p_wrap(
//                .CLKW    (wr_clk),
//                .WEB     (~wr_en),
//                .AA      (wr_addr[L2_MEM_WORDS-1:0]),
//                .D       (din[MEM_WIDTH-1:0]),
//          
//                .CLKR    (rd_clk),
//                .REB     (~rd_en),
//                .AB      (rd_addr[L2_MEM_WORDS-1:0]),
//                .Q       (dout_internal[MEM_WIDTH-1 :0]) 
//          );
//        end
//
//        ('d512 * OFFSET + 'd256): begin: mem_512x256
//          //`include "../memories/isi_mem_wrapper_include.vh"
//          localparam Bits=256,Add_Width=9,Wen_Width=256;
//localparam Word_Width=Bits;
//localparam Addr_Depth=Add_Width;
//     ram_512x256_sp_wrap ififo(
//       //for write
//       .CLKW       (wr_clk) ,
//       .WEB        (~wr_en) ,
//       .AA         (wr_addr[Add_Width-1:0]) ,
//       .D          (din[Bits-1:0]) ,
//       //for read
//       .CLKR       (rd_clk) ,
//       .REB        (~rd_en) ,
//       .AB         (rd_addr[Add_Width-1:0]) ,
//       .Q          (dout_internal[Bits-1:0]) 
//     );
//     end
//
//`endif
//        //MEMORY_CASE_LINES_END
//        
//        default: begin: mem_UNDEFxUNDEF
//`ifdef MEM_NOT_FATAL_IF_NOT_DEFINED
//          initial assert (0) else
//            $warning("MEMORY 1r1w %dx%d requested but not built",MEM_WORDS,MEM_WIDTH);
//          
//          mem_1r1w_flops
//            #(/*autoinstparam*/
//              // Parameters
//              .MEM_WORDS                (MEM_WORDS),
//              .MEM_WIDTH                (MEM_WIDTH),
//              .MEM_BIT_EN               (MEM_BIT_EN),
//              .L2_MEM_WORDS             (L2_MEM_WORDS))
//          flops(/*autoinst*/
//                // Outputs
//                .dout_internal          (dout_internal[MEM_WIDTH-1:0]),
//                // Inputs
//                .din                    (din[MEM_WIDTH-1:0]),
//                .rd_addr                (rd_addr[L2_MEM_WORDS-1:0]),
//                .rd_clk                 (rd_clk),
//                .rd_en                  (rd_en),
//                .wr_addr                (wr_addr[L2_MEM_WORDS-1:0]),
//                .wr_clk                 (wr_clk),
//                .wr_en                  (wr_en),
//                .bit_en_internal        (bit_en_internal[MEM_WIDTH-1:0]));
//          
//`else
//          mem_model_not_defined #(
//                                  .MEM_WORDS(MEM_WORDS),
//                                  .MEM_WIDTH(MEM_WIDTH)
//                                  ) mem();
//`endif
//        end
//      endcase
//      //leda on
//    end
//  endgenerate
//`endif
  
endmodule 
//MEMORY_MEMDIR_BEGIN
// Local Variables:
// verilog-library-flags:("-y /asic/techlibs/smic55/memories/20140701")
// End:
//MEMORY_MEMDIR_END
