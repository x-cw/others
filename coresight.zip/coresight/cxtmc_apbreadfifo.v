//----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2009-2010 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//    Checked In :  2010-06-02 11:27:54 +0530 (Wed, 02 Jun 2010) 
//    Revision   :  7891 
//    Release    : TM961-BU-50000-r0p0-00rel0
//
//----------------------------------------------------------------------------
// Purpose             : This APB READ FIFO Block fetches data from Read
//                     : Buffer and drives to the APB Interface block
//----------------------------------------------------------------------------


module cxtmc_apbreadfifo
  #(parameter CXTMC_ATBM_AXIM_CFG  = 0, // Valid Values: 0 (ETB), 1 (ETR) and 
                                        // 2 (ETF)
    parameter CXTMC_ATB_DATA_WIDTH = 128,
    parameter CXTMC_WB_DATA_WIDTH  = 256)
  (

                                          // Clock
  input wire                              cxtmc_clk,
                                          // Reset
  input wire                              RESETn,
                                          // request for read has been accepted
  input wire                              rb_req_ready,
                                          // read data is valid
  input wire                              rb_rdata_valid,
                                          // read data
  input wire    [CXTMC_WB_DATA_WIDTH-1:0] rb_data,
                                          // APB read request for data
  input wire                              rrd_rd_req,
                                          // Clear Read pointer
  input wire                              apbreadfifo_clr,

                                          // This signal is set when all the data read through a single read is
                                          // read through APB
  output reg                              apb_read_fifo_rrp_en,
                                          // APB read request for data
  output reg                              rb_req_valid,
                                          // APB read data is valid
  output reg                              rrd_rd_ack,
                                          // APB read data
  output wire                      [31:0] rrd

  );
  
`include "cxtmc_constants.v"
  //----------------------------------------------------------------------------
  // Constants definitions
  //----------------------------------------------------------------------------
  // The FIFO size depends on the ratio between ATB Data width and APB Width.
  localparam FIFO_DEPTH               = (CXTMC_ATBM_AXIM_CFG == CXTMC_CFG_ETR) ? 
                                        ((CXTMC_ATB_DATA_WIDTH == 128) ? 4 : 
                                        (CXTMC_ATB_DATA_WIDTH == 64)  ? 2 : 1):
                                        ((CXTMC_ATB_DATA_WIDTH == 128) ? 8 : 
                                        (CXTMC_ATB_DATA_WIDTH == 64)  ? 4 : 2);
  // This indicates FIFO DEPTH -2 in cases where it is greater than or equal to 0. Used in FIFO_NOT_EMPTY
  // State, which wont be reached if FIFO_DEPTH==1
  localparam FIFO_DEPTH_MINUS_2       = (CXTMC_ATBM_AXIM_CFG == CXTMC_CFG_ETR) ? 
                                        ((CXTMC_ATB_DATA_WIDTH == 128) ? 3'b010 : 3'b000) :
                                        ((CXTMC_ATB_DATA_WIDTH == 128) ? 3'b110 : 
                                        (CXTMC_ATB_DATA_WIDTH == 64)  ? 2'b10 : 1'b0);
  // PTR_WIDTH will determine the correct size for the fifo pointer
  localparam PTR_WIDTH                = (CXTMC_ATBM_AXIM_CFG == CXTMC_CFG_ETR) ? 
                                        ((CXTMC_ATB_DATA_WIDTH == 128) ? 2 : 1) :
                                        ((CXTMC_ATB_DATA_WIDTH == 128) ? 3 : 
                                         (CXTMC_ATB_DATA_WIDTH == 64) ? 2 : 1);
  // PADDED_1 is used to assign the LSB as 1 and other bits as 0 for the pointers
  localparam PADDED_1                 = (CXTMC_ATB_DATA_WIDTH == 128) ? 3'b001 : 
                                        (CXTMC_ATB_DATA_WIDTH == 64)  ? 2'b01 : 1'b1;

  // These localparams are Macros for State machine.
  // FIFO has no data in it
  localparam FIFO_EMPTY               = 2'b00;
  // Request for data has been raised to the memory interface, and data is not received yet
  localparam FIFO_REQ_RAISED          = 2'b01;
  // Data exists in FIFO. Next APB request will result in returning of data from the FIFO
  localparam FIFO_NOT_EMPTY           = 2'b10;

  localparam FIFO_STATE_WIDTH = ((CXTMC_ATBM_AXIM_CFG == CXTMC_CFG_ETR) && 
                                    (CXTMC_ATB_DATA_WIDTH == 32)) ? 1 : 2;

  //----------------------------------------------------------------------------
  // WIRES AND REGS
  //----------------------------------------------------------------------------
  // D-input of rb_req_valid
  wire                              nxt_rb_req_valid;
  // D-input of apb_read_fifo_rrp_en
  reg                               nxt_apb_read_fifo_rrp_en;
  // FIFO Registers
  reg                        [31:0] apb_read_fifo[FIFO_DEPTH-1:0];

  // Read point for the FIFO
  reg               [PTR_WIDTH-1:0] rptr;
  // D-input of rptr
  reg               [PTR_WIDTH-1:0] nxt_rptr;
  // Request to memory interface will be set high on assertion of this signal
  reg                               rb_req_set;
  // D-input of rrd_rd_ack
  reg                               nxt_rrd_rd_ack;
  // Incoming Read data is clocked into this register
  reg     [CXTMC_WB_DATA_WIDTH-1:0] rb_data_reg;
  // Registers for FIFO State machine
  reg        [FIFO_STATE_WIDTH-1:0] fifo_state;
  // D-input of fifo_state
  reg        [FIFO_STATE_WIDTH-1:0] nxt_fifo_state;
  // loop variable
  integer                           loopvar_i;


//----------------------------------------------------------------------------
//
// MAIN CODE
//
//----------------------------------------------------------------------------
// APB Read FIFO
// Read Data from Read Buffer when APB Read ack is asserted.
// Return data to APB after that.
//----------------------------------------------------------------------------

// When rb_req_set is set, assert rb_req_valid next clock. When rb_req_ready is set,
// deassert rb_req_valid next clock
assign nxt_rb_req_valid = rb_req_set | (rb_req_valid & ~rb_req_ready); 

generate 
if ((CXTMC_ATBM_AXIM_CFG == CXTMC_CFG_ETR) && (CXTMC_WB_DATA_WIDTH ==32)) 
begin
  always @*
  begin
    // Default value of rb_req_set is always low
    rb_req_set                    = 1'b0;
    // Retain old fifo state
    nxt_fifo_state                = fifo_state;
    // Read data acknowledge to APB is set low
    nxt_rrd_rd_ack                = 1'b0;
    // No MEMIF for ETR and hence this signal not required
    apb_read_fifo_rrp_en          = 1'b0;
    case (fifo_state) 
      // No data in FIFO
      FIFO_EMPTY : begin
        // IF a read request from APB is set, assert rb_req_valid
        rb_req_set                = rrd_rd_req;
        // If a read request from APB is set, transition to REQ_RAISED
        nxt_fifo_state            = rrd_rd_req ? FIFO_REQ_RAISED : FIFO_EMPTY;
      end 
      FIFO_REQ_RAISED : begin
        // If data received, transition to NOT_EMPTY state, else stay
        nxt_fifo_state            = rb_rdata_valid ? FIFO_EMPTY : FIFO_REQ_RAISED;
        // Provide first acknowledgement to APB next clock when data received this clock
        nxt_rrd_rd_ack            = rb_rdata_valid;
      end
      default : begin
        nxt_rrd_rd_ack            = 1'bx;
        nxt_fifo_state            = 2'bxx;
        rb_req_set                = 1'bx;
      end
    endcase
  end
  // APB Data is combinationally read out of the APB Read FIFO
  assign rrd = apb_read_fifo[1'b0]; 
end else
begin
  always @*
  begin
    // Default value of rb_req_set is always low
    rb_req_set                    = 1'b0;
    // Retain old fifo state
    nxt_fifo_state                = fifo_state;
    // Read data acknowledge to APB is set low
    nxt_rrd_rd_ack                = 1'b0;
    // Retain old value of rtpr
    nxt_rptr                      = rptr;
    // default value of apb_read_fifo_rrp_en is 0
    nxt_apb_read_fifo_rrp_en      = 1'b0;
    case (fifo_state) 
      // No data in FIFO
      FIFO_EMPTY : begin
        // Retain rptr, since rrd must be kept stable if rrd_rd_ack is low
        nxt_rptr                  = rptr;
        // IF a read request from APB is set, assert rb_req_valid
        rb_req_set                 = rrd_rd_req;
        // If a read request from APB is set, transition to REQ_RAISED
        nxt_fifo_state            = rrd_rd_req ? FIFO_REQ_RAISED : FIFO_EMPTY;
      end 
      FIFO_REQ_RAISED : begin
        // If data received, transition to NOT_EMPTY state, else stay
        nxt_fifo_state            = rb_rdata_valid ? FIFO_NOT_EMPTY : FIFO_REQ_RAISED;
        // Provide first acknowledgement to APB next clock when data received this clock
        nxt_rrd_rd_ack            = rb_rdata_valid;
        // When data is received, initialise the pointer to point to the least
        // significant 32-bit word of data.
        nxt_rptr                  = rb_rdata_valid ? {PTR_WIDTH{1'b0}} : rptr;
      end
      FIFO_NOT_EMPTY : begin
        // In this state, FIFO has data existing, so read data can be returned next clock
        nxt_rrd_rd_ack            = rrd_rd_req;
        // Increment read pointer when a request is received. Data will be read out
        // of the incremented rptr
        nxt_rptr                  = rrd_rd_req ? rptr + PADDED_1 : rptr;
        // When a read request is asserted, and if the rptr is FIFO_DEPTH_GT_1-2, then 
        // in the next clock all data in the FIFO would be read out. So apb_read_fifo_rrp_en
        // will be set to memory interface to increment the read pointer
        nxt_apb_read_fifo_rrp_en  = (rrd_rd_req && (rptr == FIFO_DEPTH_MINUS_2)) ? 1'b1 : 1'b0;
        // When a read request is asserted and if rtpr is FIFO_DEPTH_GT_1-2, then all data in FIFO
        // would be read out next clock. transition to empty. Transition to empty even when
        // apbreadfifo_clr is set
        nxt_fifo_state            = (apbreadfifo_clr || (rrd_rd_req && (rptr == FIFO_DEPTH_MINUS_2))) ? FIFO_EMPTY :
                                     FIFO_NOT_EMPTY;
      end
      default : begin
        nxt_rrd_rd_ack            = 1'bx;
        nxt_rptr                  = {PTR_WIDTH{1'bx}};
        nxt_fifo_state            = 2'bxx;
        rb_req_set                = 1'bx;
        nxt_apb_read_fifo_rrp_en  = 1'bx;
      end
    endcase
  end
  // APB Data is combinationally read out of the APB Read FIFO
  assign rrd = apb_read_fifo[rptr]; 
  // FLops for logic not required for ETR 32 configs
  always @(posedge cxtmc_clk or negedge RESETn)
  begin
    if (!RESETn) begin
      rptr                  <= {PTR_WIDTH{1'b0}};
      apb_read_fifo_rrp_en  <= 1'b0;
    end else begin
      apb_read_fifo_rrp_en  <= nxt_apb_read_fifo_rrp_en;
      rptr                  <= nxt_rptr;
    end
  end
end
endgenerate

// Representing rb_data_reg as a memory, to enable easy muxing using rptr
always @*
begin
  for (loopvar_i=0; loopvar_i < FIFO_DEPTH; loopvar_i=loopvar_i+1) begin
    apb_read_fifo[loopvar_i] = rb_data_reg[loopvar_i*32 +: 32];
  end
end

// Clock in read data whenever rb_rdata_valid is set.
always @(posedge cxtmc_clk)
begin
  if (rb_rdata_valid) begin
    rb_data_reg <= rb_data;
  end
end

// FLops for above logic
always @(posedge cxtmc_clk or negedge RESETn)
begin
  if (!RESETn) begin
    rrd_rd_ack            <= 1'b0;
    rb_req_valid          <= 1'b0;
    fifo_state            <= FIFO_EMPTY;
  end else begin
    rrd_rd_ack            <= nxt_rrd_rd_ack;
    rb_req_valid          <= nxt_rb_req_valid;
    fifo_state            <= nxt_fifo_state;
  end
end

  //----------------------------------------------------------------------------
  // ASSERTIONS
  //----------------------------------------------------------------------------
`ifdef ARM_ASSERT_ON
  // No apbreadfifo_clr in FIFO_REQ_RAISED state
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxtmc_apbreadfifo - apbreadfifo_clr must not be asserted in FIFO_REQ_RAISED state")
      uzovl_cxtmc_apbreadfifo_ptr_clr
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   ((fifo_state == FIFO_REQ_RAISED) & apbreadfifo_clr)
        );

// rb_rdata_valid can be set only when fifo_state is FIFO_REQ_RAISED
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxtmc_apbreadfifo - rb_rdata_valid can be set only when fifo_state is FIFO_REQ_RAISED")
      uzovl_cxtmc_apbreadfifo_rb_rdata_valid
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   ((fifo_state != FIFO_REQ_RAISED) & rb_rdata_valid)
        );

generate if (CXTMC_ATB_DATA_WIDTH == 32)
begin
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxtmc_apbreadfifo - FIFO_DEPTH is always 0 in 32 bit mode in FIFO_NOT_EMPTY state")
      uzovl_cxtmc_apb_rptr
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   ((fifo_state == FIFO_NOT_EMPTY) && (rptr != 2'b00))
        );
end
endgenerate

generate
if (CXTMC_ATBM_AXIM_CFG != CXTMC_CFG_ETR) 
begin
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxtmc_apbreadfifo - When request is raised for APB, no flow control from memory, as accesses from APB are sequential")
      uzovl_cxtmc_apbreadfifo_req_valid_apb
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   (rb_req_valid & ~rb_req_ready)
        );
end
endgenerate

`endif
     
 endmodule
