//-----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2011-2015 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//    Checked In : $Date: 2014-06-25 08:59:36 +0100 (Wed, 25 Jun 2014) $
//    Revision   : $Revision: 39630 $
//    Release    : CoreSight-SoC-TM100-r3p2-00rel0
//
//----------------------------------------------------------------------------
// Verilog-2001 (IEEE Std 1364-2001)
//----------------------------------------------------------------------------
// Purpose : APB Slave interface mux
//   This block muxes between address/control information from multiple Slave
// interfaces using the pselm* signals and the psel_rom_table signal as the
// select inputs. This block also generates the pselm*_reg and the
// psel_rom_table_reg signals which are registered versions of the select
// signals. The registered versions help synthesis timing in the Demux
// block for generating responses for Slave interfaces.
//----------------------------------------------------------------------------
module cxapbic_slv_mux_top_13
  (
  clk,
  resetn,

  // Port declaration for APB Slave interface 0
  rom_table_sel_0,
  paddrs0_decode,
  paddrs0_15to2,
  pwrites0,
  pwdatas0,
    
  // Port declaration for APB Slave interface 1
  rom_table_sel_1,
  paddrs1_decode,
  paddrs1_15to2,
  pwrites1,
  pwdatas1,
    
  paddr31s0,

  apbic_state, // Used to generate penablem* to master interfaces
  apb_slv_intf_sel,
  // Port declaration for APB Master interface 0
  pselm0,
  pselm0_reg,
  penablem0,
  pwritem0,
  paddrm0,
  paddr31m0,
  pwdatam0,
    
  // Port declaration for APB Master interface 1
  pselm1,
  pselm1_reg,
  penablem1,
  pwritem1,
  paddrm1,
  paddr31m1,
  pwdatam1,
    
  // Port declaration for APB Master interface 2
  pselm2,
  pselm2_reg,
  penablem2,
  pwritem2,
  paddrm2,
  paddr31m2,
  pwdatam2,
    
  // Port declaration for APB Master interface 3
  pselm3,
  pselm3_reg,
  penablem3,
  pwritem3,
  paddrm3,
  paddr31m3,
  pwdatam3,
    
  // Port declaration for APB Master interface 4
  pselm4,
  pselm4_reg,
  penablem4,
  pwritem4,
  paddrm4,
  paddr31m4,
  pwdatam4,
    
  // Port declaration for APB Master interface 5
  pselm5,
  pselm5_reg,
  penablem5,
  pwritem5,
  paddrm5,
  paddr31m5,
  pwdatam5,
    
  // Port declaration for APB Master interface 6
  pselm6,
  pselm6_reg,
  penablem6,
  pwritem6,
  paddrm6,
  paddr31m6,
  pwdatam6,
    
  // Port declaration for APB Master interface 7
  pselm7,
  pselm7_reg,
  penablem7,
  pwritem7,
  paddrm7,
  paddr31m7,
  pwdatam7,
    
  // Port declaration for APB Master interface 8
  pselm8,
  pselm8_reg,
  penablem8,
  pwritem8,
  paddrm8,
  paddr31m8,
  pwdatam8,
    
  // Port declaration for APB Master interface 9
  pselm9,
  pselm9_reg,
  penablem9,
  pwritem9,
  paddrm9,
  paddr31m9,
  pwdatam9,
    
  // Port declaration for APB Master interface 10
  pselm10,
  pselm10_reg,
  penablem10,
  pwritem10,
  paddrm10,
  paddr31m10,
  pwdatam10,
    
  // Port declaration for APB Master interface 11
  pselm11,
  pselm11_reg,
  penablem11,
  pwritem11,
  paddrm11,
  paddr31m11,
  pwdatam11,
    
  // Port declaration for APB Master interface 12
  pselm12,
  pselm12_reg,
  penablem12,
  pwritem12,
  paddrm12,
  paddr31m12,
  pwdatam12,
    

  paddr_rom_table,
  psel_rom_table,
  psel_rom_table_reg
  );

//-----------------------------------------------------------------------------
// Constants
//-----------------------------------------------------------------------------
`include "cxapbic_constants_top_13.v"

//-----------------------------------------------------------------------------
// Port declarations
//-----------------------------------------------------------------------------
  input wire clk;
  input wire resetn;

  // Port declaration for APB Slave interface 0
  input wire        rom_table_sel_0;
  input wire [12:0] paddrs0_decode;
  input wire [15:2] paddrs0_15to2;
  input wire        pwrites0;
  input wire [31:0] pwdatas0;
    
  // Port declaration for APB Slave interface 1
  input wire        rom_table_sel_1;
  input wire [12:0] paddrs1_decode;
  input wire [15:2] paddrs1_15to2;
  input wire        pwrites1;
  input wire [31:0] pwdatas1;
    
  input wire        paddr31s0;

  input wire        apbic_state; // Used to generate penablem* to master interfaces
  input wire [1:0] apb_slv_intf_sel;
  // Port declaration for APB Master interface 0
  output wire        pselm0;
  output reg         pselm0_reg;
  output wire        penablem0;
  output wire        pwritem0;
  output wire [(12+MASTER_INTF0_SIZE)-1:2] paddrm0;
  output wire        paddr31m0;
  output wire [31:0] pwdatam0;
    
  // Port declaration for APB Master interface 1
  output wire        pselm1;
  output reg         pselm1_reg;
  output wire        penablem1;
  output wire        pwritem1;
  output wire [(12+MASTER_INTF1_SIZE)-1:2] paddrm1;
  output wire        paddr31m1;
  output wire [31:0] pwdatam1;
    
  // Port declaration for APB Master interface 2
  output wire        pselm2;
  output reg         pselm2_reg;
  output wire        penablem2;
  output wire        pwritem2;
  output wire [(12+MASTER_INTF2_SIZE)-1:2] paddrm2;
  output wire        paddr31m2;
  output wire [31:0] pwdatam2;
    
  // Port declaration for APB Master interface 3
  output wire        pselm3;
  output reg         pselm3_reg;
  output wire        penablem3;
  output wire        pwritem3;
  output wire [(12+MASTER_INTF3_SIZE)-1:2] paddrm3;
  output wire        paddr31m3;
  output wire [31:0] pwdatam3;
    
  // Port declaration for APB Master interface 4
  output wire        pselm4;
  output reg         pselm4_reg;
  output wire        penablem4;
  output wire        pwritem4;
  output wire [(12+MASTER_INTF4_SIZE)-1:2] paddrm4;
  output wire        paddr31m4;
  output wire [31:0] pwdatam4;
    
  // Port declaration for APB Master interface 5
  output wire        pselm5;
  output reg         pselm5_reg;
  output wire        penablem5;
  output wire        pwritem5;
  output wire [(12+MASTER_INTF5_SIZE)-1:2] paddrm5;
  output wire        paddr31m5;
  output wire [31:0] pwdatam5;
    
  // Port declaration for APB Master interface 6
  output wire        pselm6;
  output reg         pselm6_reg;
  output wire        penablem6;
  output wire        pwritem6;
  output wire [(12+MASTER_INTF6_SIZE)-1:2] paddrm6;
  output wire        paddr31m6;
  output wire [31:0] pwdatam6;
    
  // Port declaration for APB Master interface 7
  output wire        pselm7;
  output reg         pselm7_reg;
  output wire        penablem7;
  output wire        pwritem7;
  output wire [(12+MASTER_INTF7_SIZE)-1:2] paddrm7;
  output wire        paddr31m7;
  output wire [31:0] pwdatam7;
    
  // Port declaration for APB Master interface 8
  output wire        pselm8;
  output reg         pselm8_reg;
  output wire        penablem8;
  output wire        pwritem8;
  output wire [(12+MASTER_INTF8_SIZE)-1:2] paddrm8;
  output wire        paddr31m8;
  output wire [31:0] pwdatam8;
    
  // Port declaration for APB Master interface 9
  output wire        pselm9;
  output reg         pselm9_reg;
  output wire        penablem9;
  output wire        pwritem9;
  output wire [(12+MASTER_INTF9_SIZE)-1:2] paddrm9;
  output wire        paddr31m9;
  output wire [31:0] pwdatam9;
    
  // Port declaration for APB Master interface 10
  output wire        pselm10;
  output reg         pselm10_reg;
  output wire        penablem10;
  output wire        pwritem10;
  output wire [(12+MASTER_INTF10_SIZE)-1:2] paddrm10;
  output wire        paddr31m10;
  output wire [31:0] pwdatam10;
    
  // Port declaration for APB Master interface 11
  output wire        pselm11;
  output reg         pselm11_reg;
  output wire        penablem11;
  output wire        pwritem11;
  output wire [(12+MASTER_INTF11_SIZE)-1:2] paddrm11;
  output wire        paddr31m11;
  output wire [31:0] pwdatam11;
    
  // Port declaration for APB Master interface 12
  output wire        pselm12;
  output reg         pselm12_reg;
  output wire        penablem12;
  output wire        pwritem12;
  output wire [(12+MASTER_INTF12_SIZE)-1:2] paddrm12;
  output wire        paddr31m12;
  output wire [31:0] pwdatam12;
    

  output wire [11:2] paddr_rom_table;
  output wire        psel_rom_table;
  output reg         psel_rom_table_reg;

//-----------------------------------------------------------------------------
// Wire declarations
//-----------------------------------------------------------------------------

// Concatenated psel vector from Slave interface 0 - including
// ROM table address decode
wire [13:0] pselm_from_slv0;
// Concatenated psel vector from Slave interface 1 - including
// ROM table address decode
wire [13:0] pselm_from_slv1;

wire [13:0] pselm_arbitrated;
wire        pwritem_arbitrated;
wire [31:0] pwdatam_arbitrated;
wire [15:2] paddrm_arbitrated;
wire        paddrm_bit31;
  
wire        pselm0_int;
    
wire        pselm1_int;
    
wire        pselm2_int;
    
wire        pselm3_int;
    
wire        pselm4_int;
    
wire        pselm5_int;
    
wire        pselm6_int;
    
wire        pselm7_int;
    
wire        pselm8_int;
    
wire        pselm9_int;
    
wire        pselm10_int;
    
wire        pselm11_int;
    
wire        pselm12_int;
    
wire        psel_rom_table_int;

//-----------------------------------------------------------------------------
//
//  Main body of code
//  =================
//
//-----------------------------------------------------------------------------

assign pselm_from_slv0 = {rom_table_sel_0, paddrs0_decode};
assign pselm_from_slv1 = {rom_table_sel_1, paddrs1_decode};

// Mux

assign pselm_arbitrated = 
         ({14{apb_slv_intf_sel[1] }} & pselm_from_slv1) | 
         ({14{apb_slv_intf_sel[0] }} & pselm_from_slv0);


// Extract pselm* signals from the pselm_arbitrated[] vector
assign pselm0_int = pselm_arbitrated[0];
assign pselm0     = pselm0_int;
assign pselm1_int = pselm_arbitrated[1];
assign pselm1     = pselm1_int;
assign pselm2_int = pselm_arbitrated[2];
assign pselm2     = pselm2_int;
assign pselm3_int = pselm_arbitrated[3];
assign pselm3     = pselm3_int;
assign pselm4_int = pselm_arbitrated[4];
assign pselm4     = pselm4_int;
assign pselm5_int = pselm_arbitrated[5];
assign pselm5     = pselm5_int;
assign pselm6_int = pselm_arbitrated[6];
assign pselm6     = pselm6_int;
assign pselm7_int = pselm_arbitrated[7];
assign pselm7     = pselm7_int;
assign pselm8_int = pselm_arbitrated[8];
assign pselm8     = pselm8_int;
assign pselm9_int = pselm_arbitrated[9];
assign pselm9     = pselm9_int;
assign pselm10_int = pselm_arbitrated[10];
assign pselm10     = pselm10_int;
assign pselm11_int = pselm_arbitrated[11];
assign pselm11     = pselm11_int;
assign pselm12_int = pselm_arbitrated[12];
assign pselm12     = pselm12_int;
assign psel_rom_table_int = pselm_arbitrated[13];
assign psel_rom_table     = psel_rom_table_int;
assign paddrm_arbitrated = 
         ({14{apb_slv_intf_sel[1] }} & paddrs1_15to2) | 
         ({14{apb_slv_intf_sel[0] }} & paddrs0_15to2);

// Tie bit 31 of address to 0 for system accesses to the APB
assign paddrm_bit31 = (apb_slv_intf_sel[0] == 1'b1) ? paddr31s0 : 1'b0;

// Generate an arbitrated version of pwrite and pwdata based on the
// slave interface selected

assign pwritem_arbitrated = 
         (apb_slv_intf_sel[1]  & pwrites1) | 
         (apb_slv_intf_sel[0]  & pwrites0);
assign pwdatam_arbitrated = 
         ({32{apb_slv_intf_sel[1] }} & pwdatas1) | 
         ({32{apb_slv_intf_sel[0] }} & pwdatas0);

//-----------------------------------------------------------------------------
// Demux to distribute the bus information from the arbitrated slave interface
// to the addressed master interface. To minimize toggle and save power, gate
// the outputs with the corresponding select line.
//-----------------------------------------------------------------------------

assign pwritem0 = pselm0_int & pwritem_arbitrated;
assign penablem0 = pselm0_int & apbic_state;
assign pwdatam0 = pselm0_int ? pwdatam_arbitrated : {32{1'b0}};
assign paddr31m0 = pselm0_int & paddrm_bit31;
assign paddrm0 = pselm0_int ? paddrm_arbitrated[(12+MASTER_INTF0_SIZE)-1:2] : {12+MASTER_INTF0_SIZE-2{1'b0}};
  
assign pwritem1 = pselm1_int & pwritem_arbitrated;
assign penablem1 = pselm1_int & apbic_state;
assign pwdatam1 = pselm1_int ? pwdatam_arbitrated : {32{1'b0}};
assign paddr31m1 = pselm1_int & paddrm_bit31;
assign paddrm1 = pselm1_int ? paddrm_arbitrated[(12+MASTER_INTF1_SIZE)-1:2] : {12+MASTER_INTF1_SIZE-2{1'b0}};
  
assign pwritem2 = pselm2_int & pwritem_arbitrated;
assign penablem2 = pselm2_int & apbic_state;
assign pwdatam2 = pselm2_int ? pwdatam_arbitrated : {32{1'b0}};
assign paddr31m2 = pselm2_int & paddrm_bit31;
assign paddrm2 = pselm2_int ? paddrm_arbitrated[(12+MASTER_INTF2_SIZE)-1:2] : {12+MASTER_INTF2_SIZE-2{1'b0}};
  
assign pwritem3 = pselm3_int & pwritem_arbitrated;
assign penablem3 = pselm3_int & apbic_state;
assign pwdatam3 = pselm3_int ? pwdatam_arbitrated : {32{1'b0}};
assign paddr31m3 = pselm3_int & paddrm_bit31;
assign paddrm3 = pselm3_int ? paddrm_arbitrated[(12+MASTER_INTF3_SIZE)-1:2] : {12+MASTER_INTF3_SIZE-2{1'b0}};
  
assign pwritem4 = pselm4_int & pwritem_arbitrated;
assign penablem4 = pselm4_int & apbic_state;
assign pwdatam4 = pselm4_int ? pwdatam_arbitrated : {32{1'b0}};
assign paddr31m4 = pselm4_int & paddrm_bit31;
assign paddrm4 = pselm4_int ? paddrm_arbitrated[(12+MASTER_INTF4_SIZE)-1:2] : {12+MASTER_INTF4_SIZE-2{1'b0}};
  
assign pwritem5 = pselm5_int & pwritem_arbitrated;
assign penablem5 = pselm5_int & apbic_state;
assign pwdatam5 = pselm5_int ? pwdatam_arbitrated : {32{1'b0}};
assign paddr31m5 = pselm5_int & paddrm_bit31;
assign paddrm5 = pselm5_int ? paddrm_arbitrated[(12+MASTER_INTF5_SIZE)-1:2] : {12+MASTER_INTF5_SIZE-2{1'b0}};
  
assign pwritem6 = pselm6_int & pwritem_arbitrated;
assign penablem6 = pselm6_int & apbic_state;
assign pwdatam6 = pselm6_int ? pwdatam_arbitrated : {32{1'b0}};
assign paddr31m6 = pselm6_int & paddrm_bit31;
assign paddrm6 = pselm6_int ? paddrm_arbitrated[(12+MASTER_INTF6_SIZE)-1:2] : {12+MASTER_INTF6_SIZE-2{1'b0}};
  
assign pwritem7 = pselm7_int & pwritem_arbitrated;
assign penablem7 = pselm7_int & apbic_state;
assign pwdatam7 = pselm7_int ? pwdatam_arbitrated : {32{1'b0}};
assign paddr31m7 = pselm7_int & paddrm_bit31;
assign paddrm7 = pselm7_int ? paddrm_arbitrated[(12+MASTER_INTF7_SIZE)-1:2] : {12+MASTER_INTF7_SIZE-2{1'b0}};
  
assign pwritem8 = pselm8_int & pwritem_arbitrated;
assign penablem8 = pselm8_int & apbic_state;
assign pwdatam8 = pselm8_int ? pwdatam_arbitrated : {32{1'b0}};
assign paddr31m8 = pselm8_int & paddrm_bit31;
assign paddrm8 = pselm8_int ? paddrm_arbitrated[(12+MASTER_INTF8_SIZE)-1:2] : {12+MASTER_INTF8_SIZE-2{1'b0}};
  
assign pwritem9 = pselm9_int & pwritem_arbitrated;
assign penablem9 = pselm9_int & apbic_state;
assign pwdatam9 = pselm9_int ? pwdatam_arbitrated : {32{1'b0}};
assign paddr31m9 = pselm9_int & paddrm_bit31;
assign paddrm9 = pselm9_int ? paddrm_arbitrated[(12+MASTER_INTF9_SIZE)-1:2] : {12+MASTER_INTF9_SIZE-2{1'b0}};
  
assign pwritem10 = pselm10_int & pwritem_arbitrated;
assign penablem10 = pselm10_int & apbic_state;
assign pwdatam10 = pselm10_int ? pwdatam_arbitrated : {32{1'b0}};
assign paddr31m10 = pselm10_int & paddrm_bit31;
assign paddrm10 = pselm10_int ? paddrm_arbitrated[(12+MASTER_INTF10_SIZE)-1:2] : {12+MASTER_INTF10_SIZE-2{1'b0}};
  
assign pwritem11 = pselm11_int & pwritem_arbitrated;
assign penablem11 = pselm11_int & apbic_state;
assign pwdatam11 = pselm11_int ? pwdatam_arbitrated : {32{1'b0}};
assign paddr31m11 = pselm11_int & paddrm_bit31;
assign paddrm11 = pselm11_int ? paddrm_arbitrated[(12+MASTER_INTF11_SIZE)-1:2] : {12+MASTER_INTF11_SIZE-2{1'b0}};
  
assign pwritem12 = pselm12_int & pwritem_arbitrated;
assign penablem12 = pselm12_int & apbic_state;
assign pwdatam12 = pselm12_int ? pwdatam_arbitrated : {32{1'b0}};
assign paddr31m12 = pselm12_int & paddrm_bit31;
assign paddrm12 = pselm12_int ? paddrm_arbitrated[(12+MASTER_INTF12_SIZE)-1:2] : {12+MASTER_INTF12_SIZE-2{1'b0}};
  
assign paddr_rom_table = psel_rom_table_int ? paddrm_arbitrated[11:2] : {10{1'b0}};

//-----------------------------------------------------------------------------
// Registered versions of psel lines of master interfaces - helps
// synthesis timing in muxing responses from master interface.
//-----------------------------------------------------------------------------
always @(posedge clk or negedge resetn)
begin : p_sel_reg
  if (!resetn)
    begin
      pselm0_reg <= 1'b0;
      pselm1_reg <= 1'b0;
      pselm2_reg <= 1'b0;
      pselm3_reg <= 1'b0;
      pselm4_reg <= 1'b0;
      pselm5_reg <= 1'b0;
      pselm6_reg <= 1'b0;
      pselm7_reg <= 1'b0;
      pselm8_reg <= 1'b0;
      pselm9_reg <= 1'b0;
      pselm10_reg <= 1'b0;
      pselm11_reg <= 1'b0;
      pselm12_reg <= 1'b0;
      psel_rom_table_reg <= 1'b0;
    end
  else
    begin
      pselm0_reg <= pselm0_int;
      pselm1_reg <= pselm1_int;
      pselm2_reg <= pselm2_int;
      pselm3_reg <= pselm3_int;
      pselm4_reg <= pselm4_int;
      pselm5_reg <= pselm5_int;
      pselm6_reg <= pselm6_int;
      pselm7_reg <= pselm7_int;
      pselm8_reg <= pselm8_int;
      pselm9_reg <= pselm9_int;
      pselm10_reg <= pselm10_int;
      pselm11_reg <= pselm11_int;
      pselm12_reg <= pselm12_int;
      psel_rom_table_reg <= psel_rom_table_int;
    end
end // p_sel_reg

endmodule // cxapbic_slv_mux_top_13

//-- END OF FILE --------------------------------------------------------------
