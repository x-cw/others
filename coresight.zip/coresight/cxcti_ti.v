//-----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2003-2015 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//    Checked In : $Date: 2014-08-14 16:01:35 +0100 (Thu, 14 Aug 2014) $
//    Revision   : $Revision: 39945 $
//    Release    : CoreSight-SoC-TM100-r3p2-00rel0
//
//----------------------------------------------------------------------------
//      Purpose             : ECT Trigger Interface Module
// --=========================================================================--

module cxcti_ti
  (
  // Inputs
  cticlk, cticlken, ctiresetn, tisbypassin, tisbypassack, tihsbypass,
  ctitrigin, map_trig_out, ctitrigoutack, cti_int_ack, iten, dbgen,
  niden, tinidensel, todbgensel, pwdatadbg, it_triginack_en, it_trigout_en,
  // Outputs
  ctitrigout, map_trig_in, ctitriginack, reg_trig_in_status,
  reg_trig_out_status, it_trigout_ack_r_data, it_trigin_r_data, internal_niden,
  dbgen_sync_2
  );

`include "cxcti_constants.v"

  //----------------------------------------------------------------------------
  // INPUTS
  //----------------------------------------------------------------------------

  input                               cticlk;            // Clock
  input                               cticlken;          // Clock Enable
  input                               ctiresetn;         // Reset

  input [CSSOC_ECTTRIGGERWIDTH-1:0]   tisbypassin;       // Trig intface Sync Bypass
  input [CSSOC_ECTTRIGGERWIDTH-1:0]   tisbypassack;      // Trig intface Sync Bypass
  input [CSSOC_ECTTRIGGERWIDTH-1:0]   tihsbypass;        // Trig intface H/S Bypass

  input [CSSOC_ECTTRIGGERWIDTH-1:0]   ctitrigin;         // Trigger inputs
  input [CSSOC_ECTTRIGGERWIDTH-1:0]   map_trig_out;      // Trigger from Mapper
  input [CSSOC_ECTTRIGGERWIDTH-1:0]   ctitrigoutack;     // Trigger out ACK

  input [CSSOC_ECTTRIGGERWIDTH-1:0]   cti_int_ack;       // SW clear from reg block

  input                               iten;              // Test mode control

  // General control
  input                               dbgen;             // Invasive Debug enable
  input                               niden;             // Non-invasive debug enable

  // Masking Debug Enable Signals
  input [CSSOC_ECTTRIGGERWIDTH-1:0]  tinidensel;        // Mask when niden is LOW
  input [CSSOC_ECTTRIGGERWIDTH-1:0]  todbgensel;        // Mask when dbgen is LOW

  // Integration registers inputs
  input [CSSOC_ECTTRIGGERWIDTH-1:0]   pwdatadbg;         // Write Data
  input                               it_triginack_en;   // Int.Reg. TrigInAck enable
  input                               it_trigout_en;     // Int.Reg. TrigOut enable


  //----------------------------------------------------------------------------
  // OUTPUTS
  //----------------------------------------------------------------------------

  output [CSSOC_ECTTRIGGERWIDTH-1:0] ctitrigout;        // Trigger outputs
  output [CSSOC_ECTTRIGGERWIDTH-1:0] map_trig_in;       // Trigger to Mapper
  output [CSSOC_ECTTRIGGERWIDTH-1:0] ctitriginack;      // Trigger In ACK
  output [CSSOC_ECTTRIGGERWIDTH-1:0] reg_trig_in_status;    // From Trigger In Register
  output [CSSOC_ECTTRIGGERWIDTH-1:0] reg_trig_out_status;   // From Trigger Out Register
  // Integration registers outputs
  output [CSSOC_ECTTRIGGERWIDTH-1:0] it_trigout_ack_r_data; // Int.Reg.TrigOutAck data
  output [CSSOC_ECTTRIGGERWIDTH-1:0] it_trigin_r_data;      // Int.Reg.TrigIn data

  // Authentication signals
  output                              internal_niden;        // OR'ed dbgen/niden
  output                              dbgen_sync_2;          // DEBGEN

  //----------------------------------------------------------------------------
  // WIRES AND REGS
  //----------------------------------------------------------------------------

  wire [CSSOC_ECTTRIGGERWIDTH-1:0]   ti_in_tmux;
  wire [CSSOC_ECTTRIGGERWIDTH-1:0]   ti_out_acktmux;
  wire [CSSOC_ECTTRIGGERWIDTH-1:0]   ctitrigin_corrupt;
  wire [CSSOC_ECTTRIGGERWIDTH-1:0]   ti_in_sync;
  wire [CSSOC_ECTTRIGGERWIDTH-1:0]   ctitrigoutack_corrupt;
  wire [CSSOC_ECTTRIGGERWIDTH-1:0]   ti_out_ack_sync;
  wire [CSSOC_ECTTRIGGERWIDTH-1:0]   ti_in_synced;
  wire [CSSOC_ECTTRIGGERWIDTH-1:0]   ti_out_ack_synced;
  wire [CSSOC_ECTTRIGGERWIDTH-1:0]   nxt_trig_in_ack;
  reg  [CSSOC_ECTTRIGGERWIDTH-1:0]   reg_trig_in_ack;
  wire [CSSOC_ECTTRIGGERWIDTH-1:0]   sw_clr_trig_out;
  wire [CSSOC_ECTTRIGGERWIDTH-1:0]   nxt_clr_holder;
  reg  [CSSOC_ECTTRIGGERWIDTH-1:0]   reg_clr_holder;
  wire [CSSOC_ECTTRIGGERWIDTH-1:0]   nxt_ti_out_holder;
  reg  [CSSOC_ECTTRIGGERWIDTH-1:0]   reg_ti_out_holder;
  wire [CSSOC_ECTTRIGGERWIDTH-1:0]   ti_out_internal;
  wire [CSSOC_ECTTRIGGERWIDTH-1:0]   ti_out_int;
  wire [CSSOC_ECTTRIGGERWIDTH-1:0]   ti_in_ack_int;
  wire                               reg_ti_out_holder_en;
  wire [CSSOC_ECTTRIGGERWIDTH-1:0]   ti_in_mask;
  wire                               reg_trig_in_ack_en;
  wire [CSSOC_ECTTRIGGERWIDTH-1:0]   map_trig_out_gated;
  wire [CSSOC_ECTTRIGGERWIDTH-1:0]   trig_out_mask;
  wire [CSSOC_ECTTRIGGERWIDTH-1:0]   ct_w_data_mask;
  wire                               internal_niden;
  wire                               internal_niden_loc;
  wire                               dbgen_corrupt;
  wire                               dbgen_sync_2;
  wire                               dbgen_sync_2_int;
  wire                               niden_corrupt;
  wire                               niden_sync_2;
  reg [CSSOC_ECTTRIGGERWIDTH-1:0]    ti_out_int_reg;
  wire [CSSOC_ECTTRIGGERWIDTH-1:0]   map_trig_in_int;

  //----------------------------------------------------------------------------
  //
  // MAIN CODE
  //
  //----------------------------------------------------------------------------

  //----------------------------------------------------------------------------
  // Synchronize authentication signals
  //----------------------------------------------------------------------------

`ifdef ARM_CDC_CHECK
  // Test component to corrupt dbgen going into synchroniser
  cx_cdc_corrupt_gry #(.WIDTH(1)) u_cdc_corrupt_dbgen (
      .clk    (cticlk),
      .resetn (ctiresetn),
      .sync   (1'b0),
      .d_async(dbgen),
      .q_async(dbgen_corrupt)
    );
  // Test component to corrupt niden going into synchroniser
  cx_cdc_corrupt_gry #(.WIDTH(1)) u_cdc_corrupt_niden (
      .clk    (cticlk),
      .resetn (ctiresetn),
      .sync   (1'b0),
      .d_async(niden),
      .q_async(niden_corrupt)
    );

`else

  assign dbgen_corrupt   = dbgen;
  assign niden_corrupt   = niden;

`endif

  cx_en_sync u_dbgen_sync
    (
     .clk      (cticlk),
     .resetn   (ctiresetn),
     .clken    (cticlken),
     .sync_di  (dbgen_corrupt),
     .sync_do  (dbgen_sync_2_int)
     );
  assign dbgen_sync_2 = dbgen_sync_2_int;

  cx_en_sync u_niden_sync
    (
     .clk      (cticlk),
     .resetn   (ctiresetn),
     .clken    (cticlken),
     .sync_di  (niden_corrupt),
     .sync_do  (niden_sync_2)
     );


  //----------------------------------------------------------------------------
  // dbgen also enables niden
  // Invasive debug, also enables non invasive debug.
  //----------------------------------------------------------------------------
  assign internal_niden_loc = niden_sync_2 | dbgen_sync_2_int;
  assign internal_niden     = internal_niden_loc;


  //----------------------------------------------------------------------------
  // Trigger In -> Map Trigger In
  //----------------------------------------------------------------------------
`ifdef ARM_CDC_CHECK
  // Test component to corrupt ctitrigin going into synchroniser
  cx_cdc_corrupt_gry #(.WIDTH(CSSOC_ECTTRIGGERWIDTH)) u_cdc_corrupt_ctitrigin (
      .clk    (cticlk),
      .resetn (ctiresetn),
      .sync   (1'b0),
      .d_async(ctitrigin),
      .q_async(ctitrigin_corrupt)
    );
`else
  assign ctitrigin_corrupt   = ctitrigin;
`endif

  generate
    genvar g;
    for (g = 0; g < CSSOC_ECTTRIGGERWIDTH; g=g+1)
    begin : g_tinsync
      cx_en_sync u_tinsync
      (
        .clk      (cticlk),
        .resetn   (ctiresetn),
        .clken    (cticlken),
        .sync_di  (ctitrigin_corrupt[g]),
        .sync_do  (ti_in_sync[g])
     );

      // Sync Mux
      cx_comb_mux2 #(.WIDTH(1)) u_ti_in_sync_mux
      (
        .din1_async (ti_in_sync[g]),
        .din2_async (ctitrigin[g]),
        .sel        (tisbypassin[g]),
        .dout_async (ti_in_synced[g])
      );
    end
  endgenerate

  // Input test mux
  assign ti_in_tmux     = ti_in_synced;

  // Mask Trigger in inputs with internal_niden according to tinidensel
  // tinidensel enable individual trigger inputs to be masked when
  // internal_niden is LOW.
  // Each bit of tinidensel must be set HIGH to bypass internal_niden,
  // or LOW to be masked by internal_niden.
  assign ti_in_mask = (tinidensel |
                       (~tinidensel & {CSSOC_ECTTRIGGERWIDTH{internal_niden_loc}}));


  // Connect trigger in to mapper
  assign map_trig_in_int = ti_in_tmux & ti_in_mask;
  assign map_trig_in     = map_trig_in_int;

  // Trigger in status register, this TrigInStatus output is taken
  // to the programming interface.
  assign reg_trig_in_status = map_trig_in_int;

  // Integration Register
  assign it_trigin_r_data = map_trig_in_int;

  //----------------------------------------------------------------------------
  // Trigger In Ack
  //----------------------------------------------------------------------------

  // Generate Trigger In ACK
  // Integration Register ITTRIGINACK
  assign nxt_trig_in_ack = it_triginack_en ? pwdatadbg : ti_in_tmux;


  // When in integration mode, the register is updated only when written
  // In normal operation the register is always updated.
  assign reg_trig_in_ack_en = cticlken & (~iten | (iten & it_triginack_en));

  // Register TriggerInAck output
  always @(posedge cticlk or negedge ctiresetn)
    begin
      if (!ctiresetn)
        reg_trig_in_ack <= {CSSOC_ECTTRIGGERWIDTH{1'b1}};
      else if (reg_trig_in_ack_en)
        reg_trig_in_ack <= nxt_trig_in_ack;
    end

  // Trigger In ACK test MUX
  assign ti_in_ack_int = reg_trig_in_ack;


  //----------------------------------------------------------------------------
  // Trigger Out Ack
  //----------------------------------------------------------------------------

  // TriggerOut Ack
`ifdef ARM_CDC_CHECK
  // Test component to corrupt ctitrigoutack going into synchroniser
  cx_cdc_corrupt_gry #(.WIDTH(CSSOC_ECTTRIGGERWIDTH)) u_cdc_corrupt_ctitrigoutack (
      .clk    (cticlk),
      .resetn (ctiresetn),
      .sync   (1'b0),
      .d_async(ctitrigoutack),
      .q_async(ctitrigoutack_corrupt)
    );
`else
  assign ctitrigoutack_corrupt   = ctitrigoutack;
`endif

  // Input synchronisation
  generate
    for (g = 0; g < CSSOC_ECTTRIGGERWIDTH; g=g+1)
    begin : g_tioutsync
      cx_en_sync u_tioutsync
      (
        .clk      (cticlk),
        .resetn   (ctiresetn),
        .clken    (cticlken),
        .sync_di  (ctitrigoutack_corrupt[g]),
        .sync_do  (ti_out_ack_sync[g])
      );

      // Sync Mux
      cx_comb_mux2 #(.WIDTH(1)) u_ctitrigoutack_mux
      (
        .din1_async (ti_out_ack_sync[g]),
        .din2_async (ctitrigoutack[g]),
        .sel        (tisbypassack[g]),
        .dout_async (ti_out_ack_synced[g])
      );
    end
  endgenerate

  // Input test mux
  assign ti_out_acktmux = ti_out_ack_synced;

  // Integration test register
  assign it_trigout_ack_r_data = ti_out_acktmux;

  //----------------------------------------------------------------------------
  // Map Trigger Out -> Trigger Out
  //----------------------------------------------------------------------------

  // map_trig_out must be gated when the device is in integration mode, to bypass
  // the or gate after the holding register
  assign map_trig_out_gated = iten ? {CSSOC_ECTTRIGGERWIDTH{1'b0}} : map_trig_out;

  // TriggerOut Mask
  // todbgensel individual trigger outputs to be masked when dbgen is LOW.
  // Each bit of todbgensel must be set HIGH to bypass dbgen,
  // or LOW to be masked by dbgen.
  assign trig_out_mask = (todbgensel |
                          (~todbgensel & {CSSOC_ECTTRIGGERWIDTH{dbgen_sync_2_int}}));

  // Trigger Out
  assign ti_out_internal = (trig_out_mask & map_trig_out_gated) | reg_ti_out_holder;

  // Masked version of pwdatadbg
  assign ct_w_data_mask = pwdatadbg & trig_out_mask;

  // Holder for trigger out - Trigger out remain high until an ACK is received
  // or cleared by software, or if the handshaking is disabled
  // Integration Register
  assign nxt_ti_out_holder = it_trigout_en ? ct_w_data_mask :
                              (ti_out_internal & (~sw_clr_trig_out) &
                               (~tihsbypass) & (~ti_out_acktmux));

  // When in integration mode, the register is updated only when written
  // In normal operation the register is always updated.
  assign reg_ti_out_holder_en = cticlken & (~iten | (iten & it_trigout_en));

  // Register trigger out holder
  always @(posedge cticlk or negedge ctiresetn)
    begin
      if (!ctiresetn)
        reg_ti_out_holder <= {CSSOC_ECTTRIGGERWIDTH{1'b0}};
      else if (reg_ti_out_holder_en)
        reg_ti_out_holder <= nxt_ti_out_holder;
    end

  // Generate sw_clr_trig_out (software clear)
  assign sw_clr_trig_out = cti_int_ack | reg_clr_holder;

  // Next state for clear request holder
  // The clear request is hold until the mapped trigger event
  // is dropped
  assign nxt_clr_holder = sw_clr_trig_out & map_trig_out_gated;

  // Register the clear request holder
  always @(posedge cticlk or negedge ctiresetn)
    begin
      if (!ctiresetn)
        reg_clr_holder <= {CSSOC_ECTTRIGGERWIDTH{1'b0}};
      else if (cticlken)
        reg_clr_holder <= nxt_clr_holder;
    end

  // Trigger Out Test mux
  assign ti_out_int = ti_out_internal;

  // Connect internal net to higher level
  assign ctitrigout   = ti_out_int_reg;
  assign ctitriginack = ti_in_ack_int;

  // Trigger in status register, this TrigInStatus output is taken
  // to the programming interface.
  assign reg_trig_out_status = ti_out_int_reg;

  // Flops to register the actual Trigout signals before they are
  // output
  always @(posedge cticlk or negedge ctiresetn)
    begin
      if (!ctiresetn)
        ti_out_int_reg <= {CSSOC_ECTTRIGGERWIDTH{1'b0}};
      else if (cticlken)
        ti_out_int_reg <= ti_out_int;
    end

endmodule
