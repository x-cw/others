//-----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2012-2013 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//    Checked In : $Date: 2013-09-06 16:05:05 +0100 (Fri, 06 Sep 2013) $
//    Revision   : $Revision: 37058 $
//    Release    : CoreSight-SoC-TM100-r3p1-00rel0
//
//----------------------------------------------------------------------------
// Verilog-2001 (IEEE Std 1364-2001)
//----------------------------------------------------------------------------
// Purpose : APB Response de-mux to route the response from the addressed
//           master interface to the selected slave interface.
//   The de-muxing is implemented through ANDing of the master responses
// with the select signals to generate the response signals for each
// slave interface.
//   To help synthesis timing, the registered versions of the apb_slv_intf_sel
// signals (apb_slv_intf_sel_reg*) are used for the de-muxing.
//----------------------------------------------------------------------------
module cxapbic_slv_demux_1
  (
  input wire preadym,
  input wire pslverrm,
  input wire [31:0] prdatam,

  // Port declaration for APB Slave interface 0
  output wire pready_arbitrated_s0,
  output wire pslverr_arbitrated_s0,
  output wire [31:0] prdata_arbitrated_s0,
    
  // Port declaration for APB Slave interface 1
  output wire pready_arbitrated_s1,
  output wire pslverr_arbitrated_s1,
  output wire [31:0] prdata_arbitrated_s1,
    

  input wire [1:0] apb_slv_intf_sel_reg
  );

//-----------------------------------------------------------------------------
//
//  Main body of code
//  =================
//
//-----------------------------------------------------------------------------
// Slave interface demuxes
assign prdata_arbitrated_s0 = {32{apb_slv_intf_sel_reg[0]}} & prdatam;
assign pready_arbitrated_s0 = apb_slv_intf_sel_reg[0] & preadym;
assign pslverr_arbitrated_s0 = apb_slv_intf_sel_reg[0] & pslverrm;
    
assign prdata_arbitrated_s1 = {32{apb_slv_intf_sel_reg[1]}} & prdatam;
assign pready_arbitrated_s1 = apb_slv_intf_sel_reg[1] & preadym;
assign pslverr_arbitrated_s1 = apb_slv_intf_sel_reg[1] & pslverrm;
    
endmodule // cxapbic_slv_demux_1

//-- END OF FILE --------------------------------------------------------------
