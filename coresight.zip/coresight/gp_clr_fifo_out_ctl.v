`include "../general/general.vh"

module gp_clr_fifo_out_ctl (
  input wire rd_reset_n,         // clear state
  
  input wire rd_clk,             // fifo read port clock
  input wire rd_en,              // '1' if receiver is ready to receive data
  input wire fifo_array_empty,   // fifo has no valid entries (not including fifo reg)
  input rd_clear,
  
  output wire actual_fifo_empty, /* replaces 'fifo_array_empty' for instantiator, indicates if 
                                    combination of fifo and fifo reg has data
                                    (e.g. fifo/register combination is ready to transmit) */
  output wire fifo_rd_en         // drive gp_fifo_ctl and associated RAM 'rd_en' with this
  );
  /* Attach to output of a registered output fifo to make it behave like an unregistered output fifo
    (i.e. output will reflect next data to read, thereby removing pipeline delay on reads).  Xilinx
    synthesizer will only use block RAMs if outputs are registered (reason for registering output).
    This can only be used if attaced fifo read port has a continuously running clock (i.e. is 
    synchronous to 'rd_clk').  Fifo output register is referred to as 'fifo reg'.
  */
  wire do_xfr;                   // reading fifo reg at next clock
  wire ld_fiforeg;               // transfer data to fifo reg
  reg fiforeg_valid;             // fifo reg output is valid (matches next read address data)

  assign do_xfr = fiforeg_valid && rd_en;  // read fifo reg whenever xmt/rcv both ready
  // update fifo reg when have fifo data, and register is either empty, or about to empty (be read)
  assign ld_fiforeg = !fifo_array_empty && (!fiforeg_valid || do_xfr);

  always @(posedge rd_clk, negedge rd_reset_n) begin
    // asynchronous clear JK flop
    if (!rd_reset_n)   fiforeg_valid <= 1'b0;
    else begin
      if(rd_clear)
       fiforeg_valid <= 1'b0;
      else if (ld_fiforeg)  fiforeg_valid <= 1'b1; // loading fifo reg, so will be valid
      else if (do_xfr) fiforeg_valid <= 1'b0; // reading, but not refilling
    end
  end  
  
  assign actual_fifo_empty = ~fiforeg_valid;
  assign fifo_rd_en = ld_fiforeg;  // read fifo toput read pointer data into fifo reg
endmodule // gp_fifo_out_ctl
