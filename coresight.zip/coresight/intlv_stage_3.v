//+FHDR*************************************************************************
// 
//   Copyright (c) 2025 Innosilicon. Ltd.  All rights reserved. 
// 
//   THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF INNOSILICON
//   The copyright notice above does not evidence any actual or intended
//   publication of such source code.
// 
//************************************************************************
//    Module name: intlv_stage_3.v
//    Create by  : fangxn
//    Email      : fangxn@innosilicon.com.cn
//    Create time: 2025-10-10
//************************************************************************
//    Description: 
//-FHDR*************************************************************************


module intlv_stage_3  #(
    parameter    IDW        =   8,                      // the width of awid/arid
    parameter    ADDRW      =   51,                     // the width of awaddr/araddr
    parameter    WXP0       =   100,
    parameter    WXP        =   100
)(
    // clock and reset, used for debug logic 
    input   wire                            clk,
    input   wire                            rst_n,

    // scenario static config signal
    input   wire        [35:0]          scenario_ddr_lnhash,    // one-hot code to indicate which scenario is valid, verify assert
                                                                // [35:0]: ddr_intlv linear hash, only one of them can be valid

    input   wire        [35:0]          scenario_ddr_cfghash,   // one-hot code to indicate which scenario is valid, verify assert
                                                                // [35:0]: ddr_intlv config hash, only one of them can be valid

    input   wire        [3:0]           scenario_l2c_lnhash,    // one-hot code to indicate which scenario is valid, verify assert
                                                                // [3:0]: buffer linear hash, only one of them can be valid

    input   wire    [6:0]   ddr_intlv_bankid_0,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_1,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_2,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_3,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_4,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_5,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_6,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_7,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_8,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_9,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_10,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_11,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_12,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_13,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_14,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_15,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_16,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_17,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_18,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_19,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_20,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_21,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_22,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_23,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_24,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_25,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_26,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_27,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_28,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_29,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_30,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_31,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_32,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_33,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_34,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_35,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_36,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_37,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_38,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_39,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_40,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_41,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_42,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_43,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_44,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_45,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_46,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_47,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_48,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_49,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_50,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_51,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_52,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_53,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_54,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_55,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_56,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_57,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_58,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_59,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_60,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_61,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_62,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_63,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_64,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_65,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_66,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_67,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_68,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_69,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_70,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_71,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_72,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_73,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_74,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_75,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_76,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_77,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_78,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_79,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    
    input   wire    [6:0]   buf_intlv_bankid_0,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_1,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_2,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_3,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_4,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_5,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_6,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_7,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_8,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_9,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_10,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_11,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_12,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_13,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_14,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_15,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_16,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_17,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_18,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_19,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_20,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_21,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_22,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_23,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_24,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_25,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_26,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_27,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_28,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_29,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_30,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_31,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_32,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_33,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_34,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_35,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_36,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_37,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_38,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_39,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_40,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_41,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_42,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_43,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_44,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_45,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_46,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_47,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_48,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_49,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_50,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_51,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_52,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_53,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_54,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_55,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_56,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_57,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_58,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_59,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_60,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_61,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_62,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_63,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_64,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_65,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_66,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_67,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_68,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_69,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_70,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_71,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_72,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_73,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_74,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_75,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_76,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_77,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_78,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_79,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    // slice payload in
    input   wire        [WXP-1:0]  slice_payload_i,
    // slice payload out
    output  wire        [WXP0-1:0] slice_payload_o,
    input   wire        [79:0]         bank_damage            // one-hot code for bank damage infomation 1'b0:bank not damage  (default)   1'b1: bank damage
);

// axi_payload extracted
wire    [ADDRW-1:0]         opa_axi_addr;
wire    [35:0]              scenario_ddr_lnhash_flag;
wire    [35:0]              scenario_ddr_cfghash_flag;
wire    [3:0]               scenario_l2c_lnhash_flag;


wire    [2:0]               ecc_div7_rem;
wire    [2:0]               ecc_div7_quo;

wire    [6:0]               tmpbankid;
wire    [6:0]               tmpsetid;

wire    [39:0]              ecc_epa_addr;

wire    [6:0]               st2_divisor_rem;
wire    [15:0]              st2_divisor_quo;

reg     [6:0]               ddr_bankid_offset;
reg     [6:0]               l2c_bankid_offset;
reg     [40:0]              ddr_lnhash_addr;
reg     [40:0]              ddr_cfghash_addr;
reg     [23:0]              l2c_lnhash_addr;
wire    [ADDRW-1:0]         addr_ddr;
wire    [ADDRW-1:0]         l2c_ddr;
wire                        addr_ddr_34bit;
wire    [ADDRW-1:0]         axi_addr_last;

wire    [6:0]               ddr_rebuild_bankid;
wire    [6:0]               l2c_rebuild_bankid;

wire    [6:0]               ddr_rebuild_setid;
wire    [6:0]               l2c_rebuild_setid;

wire                        gp3_req_hit_local_ddr;              // the flag assert when request's address hits local ddr space
wire                        gp3_req_hit_local_l2b;              // the flag assert when request's address hits local l2 buffer space

wire    [11:10]             new_ddr_lnhash_addr  ;
wire    [11:10]             new_ddr_cfghash_addr ;

/////////////analyze slice_payload_i result///////////////////////////
assign  opa_axi_addr               = slice_payload_i[ADDRW-1:0];
assign  tmpsetid                   = slice_payload_i[WXP0+7-1:WXP0];
assign  tmpbankid                  = slice_payload_i[WXP0+7+7-1:WXP0+7];
assign  ecc_div7_rem               = slice_payload_i[WXP0+7+7+3-1:WXP0+7+7];
assign  ecc_div7_quo               = slice_payload_i[WXP0+7+7+3+3-1:WXP0+7+7+3];
assign  gp3_req_hit_local_l2b      = slice_payload_i[WXP0+7+7+3+3+1-1:WXP0+7+7+3+3];
assign  gp3_req_hit_local_ddr      = slice_payload_i[WXP0+7+7+3+3+1+1-1:WXP0+7+7+3+3+1];
assign  st2_divisor_rem            = slice_payload_i[WXP0+7+7+3+3+1+1+7-1:WXP0+7+7+3+3+1+1];
assign  st2_divisor_quo            = slice_payload_i[WXP0+7+7+3+3+1+1+7+16-1:WXP0+7+7+3+3+1+1+7];

//////////////////////////////////rebuild scenario////////////////////////////////////////////
assign  scenario_ddr_lnhash_flag  =   scenario_ddr_lnhash  & {36{gp3_req_hit_local_ddr}};           // scenario of ddr interleaving
assign  scenario_ddr_cfghash_flag =   scenario_ddr_cfghash & {36{gp3_req_hit_local_ddr}};           // scenario of ddr interleaving
assign  scenario_l2c_lnhash_flag  =   scenario_l2c_lnhash  & {4{gp3_req_hit_local_l2b}};            // scenario of l2 buffer interleaving


//////////////////////EPA DATA/////////////////////////////////////////////////////////////////////////////
assign  ecc_epa_addr     =   scenario_ddr_lnhash_flag[9]  || scenario_ddr_cfghash_flag[9]    ? {     ecc_div7_quo,ecc_div7_rem,opa_axi_addr[33:0]} : 
                             scenario_ddr_lnhash_flag[11] || scenario_ddr_cfghash_flag[11]   ? {1'd0,ecc_div7_quo,ecc_div7_rem,opa_axi_addr[32:0]} :          
                             scenario_ddr_lnhash_flag[13] || scenario_ddr_cfghash_flag[13]   ? {2'd0,ecc_div7_quo,ecc_div7_rem,opa_axi_addr[31:0]} :
                             scenario_ddr_lnhash_flag[15] || scenario_ddr_cfghash_flag[15]   ? {3'd0,ecc_div7_quo,ecc_div7_rem,opa_axi_addr[30:0]} :
                             scenario_ddr_lnhash_flag[17] || scenario_ddr_cfghash_flag[17]   ? {4'd0,ecc_div7_quo,ecc_div7_rem,opa_axi_addr[29:0]} :40'd0;

////////////////////////get offset bankid////////////////////////////////////////////
///rebuild algorium bankid
assign ddr_rebuild_bankid =  |{scenario_ddr_lnhash_flag[0],scenario_ddr_lnhash_flag[2],scenario_ddr_lnhash_flag[4],scenario_ddr_lnhash_flag[6],scenario_ddr_lnhash_flag[8],
                           scenario_ddr_lnhash_flag[9],scenario_ddr_lnhash_flag[11],scenario_ddr_lnhash_flag[13],scenario_ddr_lnhash_flag[15],
                           scenario_ddr_lnhash_flag[17]}  ? {st2_divisor_rem[2:0],opa_axi_addr[11:8]} :
                         |{scenario_ddr_cfghash_flag[0],scenario_ddr_cfghash_flag[2],scenario_ddr_cfghash_flag[4],scenario_ddr_cfghash_flag[6],scenario_ddr_cfghash_flag[8],
                           scenario_ddr_cfghash_flag[9],scenario_ddr_cfghash_flag[11],scenario_ddr_cfghash_flag[13],scenario_ddr_cfghash_flag[15],
                           scenario_ddr_cfghash_flag[17]} ? {st2_divisor_rem[2:0],tmpbankid[3:0]} :
                         |{scenario_ddr_lnhash_flag[1],scenario_ddr_lnhash_flag[3],scenario_ddr_lnhash_flag[5],scenario_ddr_lnhash_flag[7],scenario_ddr_lnhash_flag[10],
                           scenario_ddr_lnhash_flag[12],scenario_ddr_lnhash_flag[14],scenario_ddr_lnhash_flag[16],
                           scenario_ddr_cfghash_flag[1],scenario_ddr_cfghash_flag[3],scenario_ddr_cfghash_flag[5],scenario_ddr_cfghash_flag[7],scenario_ddr_cfghash_flag[10],
                           scenario_ddr_cfghash_flag[12],scenario_ddr_cfghash_flag[14],scenario_ddr_cfghash_flag[16]} ? st2_divisor_rem[6:0] : st2_divisor_rem[6:0];

assign l2c_rebuild_bankid = {scenario_l2c_lnhash_flag[0]|scenario_l2c_lnhash_flag[1]} ? {st2_divisor_rem[2:0],opa_axi_addr[11:8]}:st2_divisor_rem[6:0];
                            

///////////////////rebuild setid//////////////////////////////
assign ddr_rebuild_setid = |{scenario_ddr_lnhash_flag[0],scenario_ddr_lnhash_flag[2],scenario_ddr_lnhash_flag[4],scenario_ddr_lnhash_flag[6],scenario_ddr_lnhash_flag[8],
                           scenario_ddr_lnhash_flag[9],scenario_ddr_lnhash_flag[11],scenario_ddr_lnhash_flag[13],scenario_ddr_lnhash_flag[15],
                           scenario_ddr_lnhash_flag[17]}  ? {opa_axi_addr[21:19],st2_divisor_quo[3:0]} :
                           |{scenario_ddr_cfghash_flag[0],scenario_ddr_cfghash_flag[2],scenario_ddr_cfghash_flag[4],scenario_ddr_cfghash_flag[6],scenario_ddr_cfghash_flag[8],
                           scenario_ddr_cfghash_flag[9],scenario_ddr_cfghash_flag[11],scenario_ddr_cfghash_flag[13],scenario_ddr_cfghash_flag[15],
                           scenario_ddr_cfghash_flag[17]} ? {tmpsetid[6:4],st2_divisor_quo[3:0]} :
                           |{scenario_ddr_lnhash_flag[1],scenario_ddr_lnhash_flag[3],scenario_ddr_lnhash_flag[5],scenario_ddr_lnhash_flag[7],scenario_ddr_lnhash_flag[10],
                           scenario_ddr_lnhash_flag[12],scenario_ddr_lnhash_flag[14],scenario_ddr_lnhash_flag[16]} ?  {opa_axi_addr[21:19],st2_divisor_quo[3:0]} :
                           |{scenario_ddr_cfghash_flag[1],scenario_ddr_cfghash_flag[3],scenario_ddr_cfghash_flag[5],scenario_ddr_cfghash_flag[7],scenario_ddr_cfghash_flag[10],
                           scenario_ddr_cfghash_flag[12],scenario_ddr_cfghash_flag[14],scenario_ddr_cfghash_flag[16]} ? {tmpsetid[6:4],st2_divisor_quo[3:0]} :
                           |scenario_ddr_lnhash_flag[35:18] ? {opa_axi_addr[21:19],st2_divisor_quo[3:0]} :  {tmpsetid[6:4],st2_divisor_quo[3:0]};

assign l2c_rebuild_setid = {scenario_l2c_lnhash_flag[0]|scenario_l2c_lnhash_flag[1]} ? {st2_divisor_quo[2:0],opa_axi_addr[18:15]}:st2_divisor_quo[6:0];

//// get ddr bankid_offset
always @ (*) begin
    case(ddr_rebuild_bankid)
        7'd0 :  ddr_bankid_offset  =  ddr_intlv_bankid_0;
        7'd1 :  ddr_bankid_offset  =  ddr_intlv_bankid_1;
        7'd2 :  ddr_bankid_offset  =  ddr_intlv_bankid_2;
        7'd3 :  ddr_bankid_offset  =  ddr_intlv_bankid_3;
        7'd4 :  ddr_bankid_offset  =  ddr_intlv_bankid_4;
        7'd5 :  ddr_bankid_offset  =  ddr_intlv_bankid_5;
        7'd6 :  ddr_bankid_offset  =  ddr_intlv_bankid_6;
        7'd7 :  ddr_bankid_offset  =  ddr_intlv_bankid_7;
        7'd8 :  ddr_bankid_offset  =  ddr_intlv_bankid_8;
        7'd9 :  ddr_bankid_offset  =  ddr_intlv_bankid_9;
        7'd10:  ddr_bankid_offset  =  ddr_intlv_bankid_10;
        7'd11:  ddr_bankid_offset  =  ddr_intlv_bankid_11;
        7'd12:  ddr_bankid_offset  =  ddr_intlv_bankid_12;
        7'd13:  ddr_bankid_offset  =  ddr_intlv_bankid_13;
        7'd14:  ddr_bankid_offset  =  ddr_intlv_bankid_14;
        7'd15:  ddr_bankid_offset  =  ddr_intlv_bankid_15;
        7'd16:  ddr_bankid_offset  =  ddr_intlv_bankid_16;
        7'd17:  ddr_bankid_offset  =  ddr_intlv_bankid_17;
        7'd18:  ddr_bankid_offset  =  ddr_intlv_bankid_18;
        7'd19:  ddr_bankid_offset  =  ddr_intlv_bankid_19;
        7'd20:  ddr_bankid_offset  =  ddr_intlv_bankid_20;
        7'd21:  ddr_bankid_offset  =  ddr_intlv_bankid_21;
        7'd22:  ddr_bankid_offset  =  ddr_intlv_bankid_22;
        7'd23:  ddr_bankid_offset  =  ddr_intlv_bankid_23;
        7'd24:  ddr_bankid_offset  =  ddr_intlv_bankid_24;
        7'd25:  ddr_bankid_offset  =  ddr_intlv_bankid_25;
        7'd26:  ddr_bankid_offset  =  ddr_intlv_bankid_26;
        7'd27:  ddr_bankid_offset  =  ddr_intlv_bankid_27;
        7'd28:  ddr_bankid_offset  =  ddr_intlv_bankid_28;
        7'd29:  ddr_bankid_offset  =  ddr_intlv_bankid_29;        
        7'd30:  ddr_bankid_offset  =  ddr_intlv_bankid_30;
        7'd31:  ddr_bankid_offset  =  ddr_intlv_bankid_31;
        7'd32:  ddr_bankid_offset  =  ddr_intlv_bankid_32;
        7'd33:  ddr_bankid_offset  =  ddr_intlv_bankid_33;
        7'd34:  ddr_bankid_offset  =  ddr_intlv_bankid_34;
        7'd35:  ddr_bankid_offset  =  ddr_intlv_bankid_35;
        7'd36:  ddr_bankid_offset  =  ddr_intlv_bankid_36;
        7'd37:  ddr_bankid_offset  =  ddr_intlv_bankid_37;
        7'd38:  ddr_bankid_offset  =  ddr_intlv_bankid_38;
        7'd39:  ddr_bankid_offset  =  ddr_intlv_bankid_39;
        7'd40:  ddr_bankid_offset  =  ddr_intlv_bankid_40;
        7'd41:  ddr_bankid_offset  =  ddr_intlv_bankid_41;
        7'd42:  ddr_bankid_offset  =  ddr_intlv_bankid_42;
        7'd43:  ddr_bankid_offset  =  ddr_intlv_bankid_43;
        7'd44:  ddr_bankid_offset  =  ddr_intlv_bankid_44;
        7'd45:  ddr_bankid_offset  =  ddr_intlv_bankid_45;
        7'd46:  ddr_bankid_offset  =  ddr_intlv_bankid_46;
        7'd47:  ddr_bankid_offset  =  ddr_intlv_bankid_47;
        7'd48:  ddr_bankid_offset  =  ddr_intlv_bankid_48;
        7'd49:  ddr_bankid_offset  =  ddr_intlv_bankid_49;
        7'd50:  ddr_bankid_offset  =  ddr_intlv_bankid_50;
        7'd51:  ddr_bankid_offset  =  ddr_intlv_bankid_51;
        7'd52:  ddr_bankid_offset  =  ddr_intlv_bankid_52;
        7'd53:  ddr_bankid_offset  =  ddr_intlv_bankid_53;
        7'd54:  ddr_bankid_offset  =  ddr_intlv_bankid_54;
        7'd55:  ddr_bankid_offset  =  ddr_intlv_bankid_55;
        7'd56:  ddr_bankid_offset  =  ddr_intlv_bankid_56;
        7'd57:  ddr_bankid_offset  =  ddr_intlv_bankid_57;
        7'd58:  ddr_bankid_offset  =  ddr_intlv_bankid_58;
        7'd59:  ddr_bankid_offset  =  ddr_intlv_bankid_59;
        7'd60:  ddr_bankid_offset  =  ddr_intlv_bankid_60;
        7'd61:  ddr_bankid_offset  =  ddr_intlv_bankid_61;
        7'd62:  ddr_bankid_offset  =  ddr_intlv_bankid_62;
        7'd63:  ddr_bankid_offset  =  ddr_intlv_bankid_63;
        7'd64:  ddr_bankid_offset  =  ddr_intlv_bankid_64;
        7'd65:  ddr_bankid_offset  =  ddr_intlv_bankid_65;
        7'd66:  ddr_bankid_offset  =  ddr_intlv_bankid_66;
        7'd67:  ddr_bankid_offset  =  ddr_intlv_bankid_67;
        7'd68:  ddr_bankid_offset  =  ddr_intlv_bankid_68;
        7'd69:  ddr_bankid_offset  =  ddr_intlv_bankid_69;
        7'd70:  ddr_bankid_offset  =  ddr_intlv_bankid_70;
        7'd71:  ddr_bankid_offset  =  ddr_intlv_bankid_71;
        7'd72:  ddr_bankid_offset  =  ddr_intlv_bankid_72;
        7'd73:  ddr_bankid_offset  =  ddr_intlv_bankid_73;
        7'd74:  ddr_bankid_offset  =  ddr_intlv_bankid_74;
        7'd75:  ddr_bankid_offset  =  ddr_intlv_bankid_75;
        7'd76:  ddr_bankid_offset  =  ddr_intlv_bankid_76;
        7'd77:  ddr_bankid_offset  =  ddr_intlv_bankid_77;
        7'd78:  ddr_bankid_offset  =  ddr_intlv_bankid_78;
        7'd79:  ddr_bankid_offset  =  ddr_intlv_bankid_79;
        default: ddr_bankid_offset =  7'h0;
    endcase
end

//// buf bankid_offset
always @ (*) begin
    case(l2c_rebuild_bankid)
        7'd0:   l2c_bankid_offset  =  buf_intlv_bankid_0;
        7'd1:   l2c_bankid_offset  =  buf_intlv_bankid_1;
        7'd2:   l2c_bankid_offset  =  buf_intlv_bankid_2;
        7'd3:   l2c_bankid_offset  =  buf_intlv_bankid_3;
        7'd4:   l2c_bankid_offset  =  buf_intlv_bankid_4;
        7'd5:   l2c_bankid_offset  =  buf_intlv_bankid_5;
        7'd6:   l2c_bankid_offset  =  buf_intlv_bankid_6;
        7'd7:   l2c_bankid_offset  =  buf_intlv_bankid_7;
        7'd8:   l2c_bankid_offset  =  buf_intlv_bankid_8;
        7'd9:   l2c_bankid_offset  =  buf_intlv_bankid_9;
        7'd10:  l2c_bankid_offset  =  buf_intlv_bankid_10;
        7'd11:  l2c_bankid_offset  =  buf_intlv_bankid_11;
        7'd12:  l2c_bankid_offset  =  buf_intlv_bankid_12;
        7'd13:  l2c_bankid_offset  =  buf_intlv_bankid_13;
        7'd14:  l2c_bankid_offset  =  buf_intlv_bankid_14;
        7'd15:  l2c_bankid_offset  =  buf_intlv_bankid_15;
        7'd16:  l2c_bankid_offset  =  buf_intlv_bankid_16;
        7'd17:  l2c_bankid_offset  =  buf_intlv_bankid_17;
        7'd18:  l2c_bankid_offset  =  buf_intlv_bankid_18;
        7'd19:  l2c_bankid_offset  =  buf_intlv_bankid_19;
        7'd20:  l2c_bankid_offset  =  buf_intlv_bankid_20;
        7'd21:  l2c_bankid_offset  =  buf_intlv_bankid_21;
        7'd22:  l2c_bankid_offset  =  buf_intlv_bankid_22;
        7'd23:  l2c_bankid_offset  =  buf_intlv_bankid_23;
        7'd24:  l2c_bankid_offset  =  buf_intlv_bankid_24;
        7'd25:  l2c_bankid_offset  =  buf_intlv_bankid_25;
        7'd26:  l2c_bankid_offset  =  buf_intlv_bankid_26;
        7'd27:  l2c_bankid_offset  =  buf_intlv_bankid_27;
        7'd28:  l2c_bankid_offset  =  buf_intlv_bankid_28;
        7'd29:  l2c_bankid_offset  =  buf_intlv_bankid_29;        
        7'd30:  l2c_bankid_offset  =  buf_intlv_bankid_30;
        7'd31:  l2c_bankid_offset  =  buf_intlv_bankid_31;
        7'd32:  l2c_bankid_offset  =  buf_intlv_bankid_32;
        7'd33:  l2c_bankid_offset  =  buf_intlv_bankid_33;
        7'd34:  l2c_bankid_offset  =  buf_intlv_bankid_34;
        7'd35:  l2c_bankid_offset  =  buf_intlv_bankid_35;
        7'd36:  l2c_bankid_offset  =  buf_intlv_bankid_36;
        7'd37:  l2c_bankid_offset  =  buf_intlv_bankid_37;
        7'd38:  l2c_bankid_offset  =  buf_intlv_bankid_38;
        7'd39:  l2c_bankid_offset  =  buf_intlv_bankid_39;
        7'd40:  l2c_bankid_offset  =  buf_intlv_bankid_40;
        7'd41:  l2c_bankid_offset  =  buf_intlv_bankid_41;
        7'd42:  l2c_bankid_offset  =  buf_intlv_bankid_42;
        7'd43:  l2c_bankid_offset  =  buf_intlv_bankid_43;
        7'd44:  l2c_bankid_offset  =  buf_intlv_bankid_44;
        7'd45:  l2c_bankid_offset  =  buf_intlv_bankid_45;
        7'd46:  l2c_bankid_offset  =  buf_intlv_bankid_46;
        7'd47:  l2c_bankid_offset  =  buf_intlv_bankid_47;
        7'd48:  l2c_bankid_offset  =  buf_intlv_bankid_48;
        7'd49:  l2c_bankid_offset  =  buf_intlv_bankid_49;
        7'd50:  l2c_bankid_offset  =  buf_intlv_bankid_50;
        7'd51:  l2c_bankid_offset  =  buf_intlv_bankid_51;
        7'd52:  l2c_bankid_offset  =  buf_intlv_bankid_52;
        7'd53:  l2c_bankid_offset  =  buf_intlv_bankid_53;
        7'd54:  l2c_bankid_offset  =  buf_intlv_bankid_54;
        7'd55:  l2c_bankid_offset  =  buf_intlv_bankid_55;
        7'd56:  l2c_bankid_offset  =  buf_intlv_bankid_56;
        7'd57:  l2c_bankid_offset  =  buf_intlv_bankid_57;
        7'd58:  l2c_bankid_offset  =  buf_intlv_bankid_58;
        7'd59:  l2c_bankid_offset  =  buf_intlv_bankid_59;
        7'd60:  l2c_bankid_offset  =  buf_intlv_bankid_60;
        7'd61:  l2c_bankid_offset  =  buf_intlv_bankid_61;
        7'd62:  l2c_bankid_offset  =  buf_intlv_bankid_62;
        7'd63:  l2c_bankid_offset  =  buf_intlv_bankid_63;
        7'd64:  l2c_bankid_offset  =  buf_intlv_bankid_64;
        7'd65:  l2c_bankid_offset  =  buf_intlv_bankid_65;
        7'd66:  l2c_bankid_offset  =  buf_intlv_bankid_66;
        7'd67:  l2c_bankid_offset  =  buf_intlv_bankid_67;
        7'd68:  l2c_bankid_offset  =  buf_intlv_bankid_68;
        7'd69:  l2c_bankid_offset  =  buf_intlv_bankid_69;
        7'd70:  l2c_bankid_offset  =  buf_intlv_bankid_70;
        7'd71:  l2c_bankid_offset  =  buf_intlv_bankid_71;
        7'd72:  l2c_bankid_offset  =  buf_intlv_bankid_72;
        7'd73:  l2c_bankid_offset  =  buf_intlv_bankid_73;
        7'd74:  l2c_bankid_offset  =  buf_intlv_bankid_74;
        7'd75:  l2c_bankid_offset  =  buf_intlv_bankid_75;
        7'd76:  l2c_bankid_offset  =  buf_intlv_bankid_76;
        7'd77:  l2c_bankid_offset  =  buf_intlv_bankid_77;
        7'd78:  l2c_bankid_offset  =  buf_intlv_bankid_78;
        7'd79:  l2c_bankid_offset  =  buf_intlv_bankid_79;
        default: l2c_bankid_offset = 7'h0;
    endcase
end

// concat
//// ddr expand addr and bank shift
always @ (*) begin
    case(scenario_ddr_lnhash_flag)
      36'h0000_0000_1: ddr_lnhash_addr = {ddr_bankid_offset[6:0],ddr_bankid_offset[0],opa_axi_addr[36:34],st2_divisor_quo[6:4],opa_axi_addr[33:22],ddr_rebuild_setid[6:0],opa_axi_addr[7:0]};
      36'h0000_0000_2: ddr_lnhash_addr = {ddr_bankid_offset[6:0],ddr_bankid_offset[0],st2_divisor_quo[8:4],opa_axi_addr[34:22],ddr_rebuild_setid[6:0],opa_axi_addr[7:0]};
      36'h0000_0000_4: ddr_lnhash_addr = {ddr_bankid_offset[6:0],ddr_bankid_offset[0],1'd0,opa_axi_addr[35:33],st2_divisor_quo[6:4],opa_axi_addr[32:22],ddr_rebuild_setid[6:0],opa_axi_addr[7:0]};
      36'h0000_0000_8: ddr_lnhash_addr = {ddr_bankid_offset[6:0],ddr_bankid_offset[0],1'd0,st2_divisor_quo[8:4],opa_axi_addr[33:22],ddr_rebuild_setid[6:0],opa_axi_addr[7:0]};

      36'h0000_0001_0: ddr_lnhash_addr = {ddr_bankid_offset[6:0],ddr_bankid_offset[0],2'd0,opa_axi_addr[34:32],st2_divisor_quo[6:4],opa_axi_addr[31:22],ddr_rebuild_setid[6:0],opa_axi_addr[7:0]};
      36'h0000_0002_0: ddr_lnhash_addr = {ddr_bankid_offset[6:0],ddr_bankid_offset[0],2'd0,st2_divisor_quo[8:4],opa_axi_addr[32:22],ddr_rebuild_setid[6:0],opa_axi_addr[7:0]};
      36'h0000_0004_0: ddr_lnhash_addr = {ddr_bankid_offset[6:0],ddr_bankid_offset[0],3'd0,opa_axi_addr[33:31],st2_divisor_quo[6:4],opa_axi_addr[30:22],ddr_rebuild_setid[6:0],opa_axi_addr[7:0]};
      36'h0000_0008_0: ddr_lnhash_addr = {ddr_bankid_offset[6:0],ddr_bankid_offset[0],3'd0,st2_divisor_quo[8:4],opa_axi_addr[31:22],ddr_rebuild_setid[6:0],opa_axi_addr[7:0]};

      36'h0000_0010_0: ddr_lnhash_addr = {ddr_bankid_offset[6:0],ddr_bankid_offset[0],4'd0,opa_axi_addr[32:30],st2_divisor_quo[6:4],opa_axi_addr[29:22],ddr_rebuild_setid[6:0],opa_axi_addr[7:0]};
      36'h0000_0020_0: ddr_lnhash_addr = {ddr_bankid_offset[6:0],ddr_bankid_offset[0],ecc_epa_addr[36:34],st2_divisor_quo[6:4],ecc_epa_addr[33:22],ddr_rebuild_setid[6:0],ecc_epa_addr[7:0]};
      36'h0000_0040_0: ddr_lnhash_addr = {ddr_bankid_offset[6:0],ddr_bankid_offset[0],st2_divisor_quo[11:4],opa_axi_addr[31:22],ddr_rebuild_setid[6:0],opa_axi_addr[7:0]};
      36'h0000_0080_0: ddr_lnhash_addr = {ddr_bankid_offset[6:0],ddr_bankid_offset[0],1'd0,ecc_epa_addr[35:33],st2_divisor_quo[6:4],ecc_epa_addr[32:22],ddr_rebuild_setid[6:0],ecc_epa_addr[7:0]};

      36'h0000_0100_0: ddr_lnhash_addr = {ddr_bankid_offset[6:0],ddr_bankid_offset[0],1'd0,st2_divisor_quo[11:4],opa_axi_addr[30:22],ddr_rebuild_setid[6:0],opa_axi_addr[7:0]};
      36'h0000_0200_0: ddr_lnhash_addr = {ddr_bankid_offset[6:0],ddr_bankid_offset[0],2'd0,ecc_epa_addr[34:32],st2_divisor_quo[6:4],ecc_epa_addr[31:22],ddr_rebuild_setid[6:0],ecc_epa_addr[7:0]};
      36'h0000_0400_0: ddr_lnhash_addr = {ddr_bankid_offset[6:0],ddr_bankid_offset[0],2'd0,st2_divisor_quo[11:4],opa_axi_addr[29:22],ddr_rebuild_setid[6:0],opa_axi_addr[7:0]};
      36'h0000_0800_0: ddr_lnhash_addr = {ddr_bankid_offset[6:0],ddr_bankid_offset[0],3'd0,ecc_epa_addr[33:31],st2_divisor_quo[6:4],ecc_epa_addr[30:22],ddr_rebuild_setid[6:0],ecc_epa_addr[7:0]};

      36'h0000_1000_0: ddr_lnhash_addr = {ddr_bankid_offset[6:0],ddr_bankid_offset[0],3'd0,st2_divisor_quo[11:4],opa_axi_addr[28:22],ddr_rebuild_setid[6:0],opa_axi_addr[7:0]};
      36'h0000_2000_0: ddr_lnhash_addr = {ddr_bankid_offset[6:0],ddr_bankid_offset[0],4'd0,ecc_epa_addr[32:30],st2_divisor_quo[6:4],ecc_epa_addr[29:22],ddr_rebuild_setid[6:0],ecc_epa_addr[7:0]};
      36'h0000_4000_0: ddr_lnhash_addr = {ddr_bankid_offset[6:0],ddr_bankid_offset[0],st2_divisor_quo[10:4],opa_axi_addr[32:22],ddr_rebuild_setid[6:0],opa_axi_addr[7:0]};
      36'h0000_8000_0: ddr_lnhash_addr = {ddr_bankid_offset[6:0],ddr_bankid_offset[0],st2_divisor_quo[12:4],opa_axi_addr[30:22],ddr_rebuild_setid[6:0],opa_axi_addr[7:0]};

      36'h0001_0000_0: ddr_lnhash_addr = {ddr_bankid_offset[6:0],ddr_bankid_offset[0],1'd0,st2_divisor_quo[10:4],opa_axi_addr[31:22],ddr_rebuild_setid[6:0],opa_axi_addr[7:0]};
      36'h0002_0000_0: ddr_lnhash_addr = {ddr_bankid_offset[6:0],ddr_bankid_offset[0],1'd0,st2_divisor_quo[12:4],opa_axi_addr[29:22],ddr_rebuild_setid[6:0],opa_axi_addr[7:0]};
      36'h0004_0000_0: ddr_lnhash_addr = {ddr_bankid_offset[6:0],ddr_bankid_offset[0],2'd0,st2_divisor_quo[10:4],opa_axi_addr[30:22],ddr_rebuild_setid[6:0],opa_axi_addr[7:0]};
      36'h0008_0000_0: ddr_lnhash_addr = {ddr_bankid_offset[6:0],ddr_bankid_offset[0],2'd0,st2_divisor_quo[12:4],opa_axi_addr[28:22],ddr_rebuild_setid[6:0],opa_axi_addr[7:0]};

      36'h0010_0000_0: ddr_lnhash_addr = {ddr_bankid_offset[6:0],ddr_bankid_offset[0],3'd0,st2_divisor_quo[10:4],opa_axi_addr[29:22],ddr_rebuild_setid[6:0],opa_axi_addr[7:0]};
      36'h0020_0000_0: ddr_lnhash_addr = {ddr_bankid_offset[6:0],ddr_bankid_offset[0],3'd0,st2_divisor_quo[12:4],opa_axi_addr[27:22],ddr_rebuild_setid[6:0],opa_axi_addr[7:0]};
      36'h0040_0000_0: ddr_lnhash_addr = {ddr_bankid_offset[6:0],ddr_bankid_offset[0],4'd0,st2_divisor_quo[10:4],opa_axi_addr[28:22],ddr_rebuild_setid[6:0],opa_axi_addr[7:0]};
      36'h0080_0000_0: ddr_lnhash_addr = {ddr_bankid_offset[6:0],ddr_bankid_offset[0],st2_divisor_quo[13:4],opa_axi_addr[29:22],ddr_rebuild_setid[6:0],opa_axi_addr[7:0]};

      36'h0100_0000_0: ddr_lnhash_addr = {ddr_bankid_offset[6:0],ddr_bankid_offset[0],st2_divisor_quo[15:4],opa_axi_addr[27:22],ddr_rebuild_setid[6:0],opa_axi_addr[7:0]};
      36'h0200_0000_0: ddr_lnhash_addr = {ddr_bankid_offset[6:0],ddr_bankid_offset[0],1'd0,st2_divisor_quo[13:4],opa_axi_addr[28:22],ddr_rebuild_setid[6:0],opa_axi_addr[7:0]};
      36'h0400_0000_0: ddr_lnhash_addr = {ddr_bankid_offset[6:0],ddr_bankid_offset[0],1'd0,st2_divisor_quo[15:4],opa_axi_addr[26:22],ddr_rebuild_setid[6:0],opa_axi_addr[7:0]};
      36'h0800_0000_0: ddr_lnhash_addr = {ddr_bankid_offset[6:0],ddr_bankid_offset[0],2'd0,st2_divisor_quo[13:4],opa_axi_addr[27:22],ddr_rebuild_setid[6:0],opa_axi_addr[7:0]};

      36'h1000_0000_0: ddr_lnhash_addr = {ddr_bankid_offset[6:0],ddr_bankid_offset[0],2'd0,st2_divisor_quo[15:4],opa_axi_addr[25:22],ddr_rebuild_setid[6:0],opa_axi_addr[7:0]};
      36'h2000_0000_0: ddr_lnhash_addr = {ddr_bankid_offset[6:0],ddr_bankid_offset[0],3'd0,st2_divisor_quo[13:4],opa_axi_addr[26:22],ddr_rebuild_setid[6:0],opa_axi_addr[7:0]};
      36'h4000_0000_0: ddr_lnhash_addr = {ddr_bankid_offset[6:0],ddr_bankid_offset[0],3'd0,st2_divisor_quo[15:4],opa_axi_addr[24:22],ddr_rebuild_setid[6:0],opa_axi_addr[7:0]};
      36'h8000_0000_0: ddr_lnhash_addr = {ddr_bankid_offset[6:0],ddr_bankid_offset[0],4'd0,st2_divisor_quo[13:4],opa_axi_addr[25:22],ddr_rebuild_setid[6:0],opa_axi_addr[7:0]};
      default: ddr_lnhash_addr = 41'h0;
    endcase
end


always @ (*) begin
    case(scenario_ddr_cfghash_flag)
      36'h0000_0000_1: ddr_cfghash_addr = {ddr_bankid_offset[6:0],ddr_bankid_offset[0],opa_axi_addr[36:34],st2_divisor_quo[6:4],opa_axi_addr[33:22],ddr_rebuild_setid[6:0],opa_axi_addr[7:0]};
      36'h0000_0000_2: ddr_cfghash_addr = {ddr_bankid_offset[6:0],ddr_bankid_offset[0],st2_divisor_quo[8:4],opa_axi_addr[34:22],ddr_rebuild_setid[6:0],opa_axi_addr[7:0]};
      36'h0000_0000_4: ddr_cfghash_addr = {ddr_bankid_offset[6:0],ddr_bankid_offset[0],1'd0,opa_axi_addr[35:33],st2_divisor_quo[6:4],opa_axi_addr[32:22],ddr_rebuild_setid[6:0],opa_axi_addr[7:0]};
      36'h0000_0000_8: ddr_cfghash_addr = {ddr_bankid_offset[6:0],ddr_bankid_offset[0],1'd0,st2_divisor_quo[8:4],opa_axi_addr[33:22],ddr_rebuild_setid[6:0],opa_axi_addr[7:0]};

      36'h0000_0001_0: ddr_cfghash_addr = {ddr_bankid_offset[6:0],ddr_bankid_offset[0],2'd0,opa_axi_addr[34:32],st2_divisor_quo[6:4],opa_axi_addr[31:22],ddr_rebuild_setid[6:0],opa_axi_addr[7:0]};
      36'h0000_0002_0: ddr_cfghash_addr = {ddr_bankid_offset[6:0],ddr_bankid_offset[0],2'd0,st2_divisor_quo[8:4],opa_axi_addr[32:22],ddr_rebuild_setid[6:0],opa_axi_addr[7:0]};
      36'h0000_0004_0: ddr_cfghash_addr = {ddr_bankid_offset[6:0],ddr_bankid_offset[0],3'd0,opa_axi_addr[33:31],st2_divisor_quo[6:4],opa_axi_addr[30:22],ddr_rebuild_setid[6:0],opa_axi_addr[7:0]};
      36'h0000_0008_0: ddr_cfghash_addr = {ddr_bankid_offset[6:0],ddr_bankid_offset[0],3'd0,st2_divisor_quo[8:4],opa_axi_addr[31:22],ddr_rebuild_setid[6:0],opa_axi_addr[7:0]};

      36'h0000_0010_0: ddr_cfghash_addr = {ddr_bankid_offset[6:0],ddr_bankid_offset[0],4'd0,opa_axi_addr[32:30],st2_divisor_quo[6:4],opa_axi_addr[29:22],ddr_rebuild_setid[6:0],opa_axi_addr[7:0]};
      36'h0000_0020_0: ddr_cfghash_addr = {ddr_bankid_offset[6:0],ddr_bankid_offset[0],ecc_epa_addr[36:34],st2_divisor_quo[6:4],ecc_epa_addr[33:22],ddr_rebuild_setid[6:0],ecc_epa_addr[7:0]};
      36'h0000_0040_0: ddr_cfghash_addr = {ddr_bankid_offset[6:0],ddr_bankid_offset[0],st2_divisor_quo[11:4],opa_axi_addr[31:22],ddr_rebuild_setid[6:0],opa_axi_addr[7:0]};
      36'h0000_0080_0: ddr_cfghash_addr = {ddr_bankid_offset[6:0],ddr_bankid_offset[0],1'd0,ecc_epa_addr[35:33],st2_divisor_quo[6:4],ecc_epa_addr[32:22],ddr_rebuild_setid[6:0],ecc_epa_addr[7:0]};

      36'h0000_0100_0: ddr_cfghash_addr = {ddr_bankid_offset[6:0],ddr_bankid_offset[0],1'd0,st2_divisor_quo[11:4],opa_axi_addr[30:22],ddr_rebuild_setid[6:0],opa_axi_addr[7:0]};
      36'h0000_0200_0: ddr_cfghash_addr = {ddr_bankid_offset[6:0],ddr_bankid_offset[0],2'd0,ecc_epa_addr[34:32],st2_divisor_quo[6:4],ecc_epa_addr[31:22],ddr_rebuild_setid[6:0],ecc_epa_addr[7:0]};
      36'h0000_0400_0: ddr_cfghash_addr = {ddr_bankid_offset[6:0],ddr_bankid_offset[0],2'd0,st2_divisor_quo[11:4],opa_axi_addr[29:22],ddr_rebuild_setid[6:0],opa_axi_addr[7:0]};
      36'h0000_0800_0: ddr_cfghash_addr = {ddr_bankid_offset[6:0],ddr_bankid_offset[0],3'd0,ecc_epa_addr[33:31],st2_divisor_quo[6:4],ecc_epa_addr[30:22],ddr_rebuild_setid[6:0],ecc_epa_addr[7:0]};

      36'h0000_1000_0: ddr_cfghash_addr = {ddr_bankid_offset[6:0],ddr_bankid_offset[0],3'd0,st2_divisor_quo[11:4],opa_axi_addr[28:22],ddr_rebuild_setid[6:0],opa_axi_addr[7:0]};
      36'h0000_2000_0: ddr_cfghash_addr = {ddr_bankid_offset[6:0],ddr_bankid_offset[0],4'd0,ecc_epa_addr[32:30],st2_divisor_quo[6:4],ecc_epa_addr[29:22],ddr_rebuild_setid[6:0],ecc_epa_addr[7:0]};
      36'h0000_4000_0: ddr_cfghash_addr = {ddr_bankid_offset[6:0],ddr_bankid_offset[0],st2_divisor_quo[10:4],opa_axi_addr[32:22],ddr_rebuild_setid[6:0],opa_axi_addr[7:0]};
      36'h0000_8000_0: ddr_cfghash_addr = {ddr_bankid_offset[6:0],ddr_bankid_offset[0],st2_divisor_quo[12:4],opa_axi_addr[30:22],ddr_rebuild_setid[6:0],opa_axi_addr[7:0]};

      36'h0001_0000_0: ddr_cfghash_addr = {ddr_bankid_offset[6:0],ddr_bankid_offset[0],1'd0,st2_divisor_quo[10:4],opa_axi_addr[31:22],ddr_rebuild_setid[6:0],opa_axi_addr[7:0]};
      36'h0002_0000_0: ddr_cfghash_addr = {ddr_bankid_offset[6:0],ddr_bankid_offset[0],1'd0,st2_divisor_quo[12:4],opa_axi_addr[29:22],ddr_rebuild_setid[6:0],opa_axi_addr[7:0]};
      36'h0004_0000_0: ddr_cfghash_addr = {ddr_bankid_offset[6:0],ddr_bankid_offset[0],2'd0,st2_divisor_quo[10:4],opa_axi_addr[30:22],ddr_rebuild_setid[6:0],opa_axi_addr[7:0]};
      36'h0008_0000_0: ddr_cfghash_addr = {ddr_bankid_offset[6:0],ddr_bankid_offset[0],2'd0,st2_divisor_quo[12:4],opa_axi_addr[28:22],ddr_rebuild_setid[6:0],opa_axi_addr[7:0]};

      36'h0010_0000_0: ddr_cfghash_addr = {ddr_bankid_offset[6:0],ddr_bankid_offset[0],3'd0,st2_divisor_quo[10:4],opa_axi_addr[29:22],ddr_rebuild_setid[6:0],opa_axi_addr[7:0]};
      36'h0020_0000_0: ddr_cfghash_addr = {ddr_bankid_offset[6:0],ddr_bankid_offset[0],3'd0,st2_divisor_quo[12:4],opa_axi_addr[27:22],ddr_rebuild_setid[6:0],opa_axi_addr[7:0]};
      36'h0040_0000_0: ddr_cfghash_addr = {ddr_bankid_offset[6:0],ddr_bankid_offset[0],4'd0,st2_divisor_quo[10:4],opa_axi_addr[28:22],ddr_rebuild_setid[6:0],opa_axi_addr[7:0]};
      36'h0080_0000_0: ddr_cfghash_addr = {ddr_bankid_offset[6:0],ddr_bankid_offset[0],st2_divisor_quo[13:4],opa_axi_addr[29:22],ddr_rebuild_setid[6:0],opa_axi_addr[7:0]};

      36'h0100_0000_0: ddr_cfghash_addr = {ddr_bankid_offset[6:0],ddr_bankid_offset[0],st2_divisor_quo[15:4],opa_axi_addr[27:22],ddr_rebuild_setid[6:0],opa_axi_addr[7:0]};
      36'h0200_0000_0: ddr_cfghash_addr = {ddr_bankid_offset[6:0],ddr_bankid_offset[0],1'd0,st2_divisor_quo[13:4],opa_axi_addr[28:22],ddr_rebuild_setid[6:0],opa_axi_addr[7:0]};
      36'h0400_0000_0: ddr_cfghash_addr = {ddr_bankid_offset[6:0],ddr_bankid_offset[0],1'd0,st2_divisor_quo[15:4],opa_axi_addr[26:22],ddr_rebuild_setid[6:0],opa_axi_addr[7:0]};
      36'h0800_0000_0: ddr_cfghash_addr = {ddr_bankid_offset[6:0],ddr_bankid_offset[0],2'd0,st2_divisor_quo[13:4],opa_axi_addr[27:22],ddr_rebuild_setid[6:0],opa_axi_addr[7:0]};

      36'h1000_0000_0: ddr_cfghash_addr = {ddr_bankid_offset[6:0],ddr_bankid_offset[0],2'd0,st2_divisor_quo[15:4],opa_axi_addr[25:22],ddr_rebuild_setid[6:0],opa_axi_addr[7:0]};
      36'h2000_0000_0: ddr_cfghash_addr = {ddr_bankid_offset[6:0],ddr_bankid_offset[0],3'd0,st2_divisor_quo[13:4],opa_axi_addr[26:22],ddr_rebuild_setid[6:0],opa_axi_addr[7:0]};
      36'h4000_0000_0: ddr_cfghash_addr = {ddr_bankid_offset[6:0],ddr_bankid_offset[0],3'd0,st2_divisor_quo[15:4],opa_axi_addr[24:22],ddr_rebuild_setid[6:0],opa_axi_addr[7:0]};
      36'h8000_0000_0: ddr_cfghash_addr = {ddr_bankid_offset[6:0],ddr_bankid_offset[0],4'd0,st2_divisor_quo[13:4],opa_axi_addr[25:22],ddr_rebuild_setid[6:0],opa_axi_addr[7:0]};
      default: ddr_cfghash_addr = 41'h0;
    endcase
end


always @ (*) begin
    case(scenario_l2c_lnhash_flag)
      4'h1: l2c_lnhash_addr = {l2c_bankid_offset[6:0],opa_axi_addr[20:19],l2c_rebuild_setid[6:0],opa_axi_addr[7:0]};
      4'h2: l2c_lnhash_addr = {l2c_bankid_offset[6:0],opa_axi_addr[23],opa_axi_addr[19],l2c_rebuild_setid[6:0],opa_axi_addr[7:0]};
      4'h4: l2c_lnhash_addr = {l2c_bankid_offset[6:0],opa_axi_addr[16:15],l2c_rebuild_setid[6:0],opa_axi_addr[7:0]};
      4'h8: l2c_lnhash_addr = {l2c_bankid_offset[6:0],opa_axi_addr[23],opa_axi_addr[15],l2c_rebuild_setid[6:0],opa_axi_addr[7:0]};
      default: l2c_lnhash_addr = 24'h0;
    endcase
end


///////////////////////////////////////////////////////////////////////////////////////////
///////////////////////improve ddr access performance
///////////////////////////////////////////////////////////////////////////////////////////
assign new_ddr_lnhash_addr[10]  = ddr_lnhash_addr[10]^ddr_lnhash_addr[16]^ddr_lnhash_addr[18];
assign new_ddr_lnhash_addr[11]  = ddr_lnhash_addr[11]^ddr_lnhash_addr[15]^ddr_lnhash_addr[17];
assign new_ddr_cfghash_addr[10] = ddr_cfghash_addr[10]^ddr_cfghash_addr[16]^ddr_cfghash_addr[18];
assign new_ddr_cfghash_addr[11] = ddr_cfghash_addr[11]^ddr_cfghash_addr[15]^ddr_cfghash_addr[17];

assign addr_ddr = |scenario_ddr_lnhash_flag[35:0]  ? {opa_axi_addr[ADDRW-1:41],ddr_lnhash_addr[40:12],new_ddr_lnhash_addr[11:10],ddr_lnhash_addr[9:0]}:
                  |scenario_ddr_cfghash_flag[35:0] ? {opa_axi_addr[ADDRW-1:41],ddr_cfghash_addr[40:12],new_ddr_cfghash_addr[11:10],ddr_cfghash_addr[9:0]}:opa_axi_addr[ADDRW-1:0];

assign l2c_ddr  = |scenario_l2c_lnhash_flag[3:0]   ? {opa_axi_addr[ADDRW-1:24],l2c_lnhash_addr[23:0]}:opa_axi_addr[ADDRW-1:0];


// ddr bank shift
assign addr_ddr_34bit  = bank_damage[addr_ddr[40:34]] ? ~addr_ddr[34] : addr_ddr[34];

assign axi_addr_last   = |{scenario_ddr_lnhash_flag,scenario_ddr_cfghash_flag} ? {addr_ddr[ADDRW-1:35], addr_ddr_34bit, addr_ddr[33:0]} :
                         |{scenario_l2c_lnhash_flag} ? l2c_ddr : opa_axi_addr;

assign slice_payload_o = {slice_payload_i[WXP0-1:ADDRW],axi_addr_last};

endmodule
