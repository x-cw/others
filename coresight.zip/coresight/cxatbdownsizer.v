// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2010-2015 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//  Version and Release Control Information:
//
//  Checked In          : $Date: 2014-06-25 08:59:36 +0100 (Wed, 25 Jun 2014) $
//
//  File Revision       : $Revision: 39630 $
//
//  Release Information : CoreSight-SoC-TM100-r3p2-00rel0
//-----------------------------------------------------------------------------
// Verilog-2001 (IEEE Std 1364-2001)
//----------------------------------------------------------------------------


//-----------------------------------------------------------------------------
// Abstract : CoreSight Trace Atbdownsizer (cxatbdownsizer) - Top Level Block
//-----------------------------------------------------------------------------
//
// cxatbdownsizer - CoreSight Trace Atbdownsizer
// -------------------------------------------------
//
// CoreSight AMBA Trace Bus (ATB) Downsizer for downsizing wider ATB to
// narrower ATB
//-----------------------------------------------------------------------------

module cxatbdownsizer  (
  // Inputs
  input wire         clk,             // ATB clock
  input wire         resetn,          // ATB reset
  input wire         atvalids,        // Indication of valid ATB transfer
  input wire         afreadys,        // Indication to flush the internal buffer
  input wire [6:0]   atids,           // ID's for ATB transfers
  input wire [128-1:0] atdatas,       // ATB data
  input wire [3:0]   atbytess,        // Indication of number of valid bytes
  input wire         atreadym,        // Indication of acceptance of ATB transfer
  input wire         afvalidm,        // Indication to flush the internal buffer
  input wire         syncreqm,        // Indication to send sync packets
  // Outputs
  output wire        atvalidm,        // Indication of valid ATB transfer
  output wire        afreadym,        // Indication of completion of flush transfer
  output wire [6:0]  atidm,           // ID's for ATB transfers
  output reg  [32-1:0] atdatam,       // ATB data
  output wire [1:0]  atbytesm,        // Indication of number of valid bytes
  output wire        atreadys,        // Indication of acceptance of ATB transfer
  output wire        afvalids,        // Indication to flush the internal buffer
  output wire        syncreqs         // Indication to send sync pack
  );



//------------------------------------------------------------------------------
// Local parameters definitions
//------------------------------------------------------------------------------

  // Converting XSL parameter to local parameter
  localparam ATB_SLAVE_DATA_WIDTH = 128;
  localparam ATB_MASTER_DATA_WIDTH = 32;

  // Maximum number of valid Bytes possible on ATB slave side
  localparam ATBYTESS_MAX = 4'd15;

  // Maximum number of valid Bytes possible on ATB slave side (atbytess + 1)
  localparam ATBYTESS_MAX_PLUS_ONE = 16;

  // Width of ATBYTES counter
  localparam ATBYTESS_CNT_WIDTH = 4;

  // Maximum number of valid Bytes possible on ATB master side
  localparam ATBYTESM_MAX = 2'd3;

  // Maximum number of valid Bytes possible on ATB master side (atbytesm + 1)
  localparam ATBYTESM_MAX_PLUS_ONE = 4;

       localparam ATBYTESM_MAX_PLUS_ONE_ADJUSTED = 3'd4;

  //----------------------------------------------------------------------------
  // Wires and Register declarations
  //----------------------------------------------------------------------------

  wire        slave_atb_hand_shake;    // Indication of completion of current
                                       // data transfer on ATB slave
  wire        master_atb_hand_shake;   // Indication of completion of current
                                       // data transfer on ATB master
  reg         nxt_rem_txr;             // D-input of rem_txr
  reg         rem_txr;                 // Flag used to drive atreadys
  reg  [3:0]  nxt_atbytes_cnt;         // nxt_atbytes_cnt
  wire [3:0]  nxt_atbytes_up_cnt;      // D-Input of atbytes_up_cnt register
  reg  [3:0]  atbytes_up_cnt;          // Counter to mux the data
  reg  [3:0]  atbytes_cnt;             // Total number of ATBYTES received on
                                       // ATB slave

  reg [1:0] atbytesm_wide;             // atbytesm padded with extra bit to take care of lint


  //============================================================================
  //
  // Main body of code
  // =================
  //
  //============================================================================

  // Indication that slave and master side ATB data transfer handshake is
  // completed.
  assign slave_atb_hand_shake = atvalids & atreadys;
  assign master_atb_hand_shake = atvalidm & atreadym;


  //============================================================================
  // Continous assignments as this block's outputs are not registered.
  //============================================================================
  assign atvalidm = atvalids;
  assign afvalids = afvalidm;
  assign afreadym = afreadys;
  assign atidm    = atids;
  assign syncreqs = syncreqm;

  // atreadys is driven once all the sub transfers on ATB master side
  // is completed.
  assign atreadys = atvalids &
                    (((atbytes_cnt <= ATBYTESM_MAX) & rem_txr) |
                     (atbytess <= ATBYTESM_MAX)) & atreadym;

  // Counter to count the number of bytes received from ATB slave side.
  // This counter is decremented on every write on ATB master side.

  always @(*)
  begin
    if (slave_atb_hand_shake) begin
      nxt_atbytes_cnt = {(ATBYTESS_CNT_WIDTH){1'b0}};
    end else if (atvalids && !atreadym && !(|atbytes_cnt) && !rem_txr) begin
      nxt_atbytes_cnt = atbytess;
    end else if (atvalids && atreadym && !(|atbytes_cnt) && !rem_txr) begin
      nxt_atbytes_cnt = atbytess - ATBYTESM_MAX_PLUS_ONE_ADJUSTED;
    end else if ((|atbytes_cnt) && master_atb_hand_shake) begin
      nxt_atbytes_cnt = atbytes_cnt - ATBYTESM_MAX_PLUS_ONE_ADJUSTED;
    end else begin
      nxt_atbytes_cnt = atbytes_cnt;
    end
  end

  assign nxt_atbytes_up_cnt = atbytess - nxt_atbytes_cnt;

  // Realizing atbytes_cnt counter
  always @(posedge clk or negedge resetn)
    begin :  p_atbytes_cnt_seq
      if (!resetn)
        begin
          atbytes_cnt <= {ATBYTESS_CNT_WIDTH{1'b0}};
          atbytes_up_cnt <= {ATBYTESS_CNT_WIDTH{1'b0}};
        end
      else
        begin
          atbytes_cnt <= nxt_atbytes_cnt;
          atbytes_up_cnt <= nxt_atbytes_up_cnt;
        end
    end // p_atbytes_cnt_seq

  // atbytesm is always driven with max value, only in scenarios where the ATBYTES
  // is less than the max possible transfer on atbytess, atbytesm will be less than
  // max possible values on atbytesm.

  always @(*)
    begin
      if (!(|atbytes_cnt) && (atbytess > ATBYTESM_MAX) && !rem_txr) begin
        atbytesm_wide = 2'b11;
      end else if (!(|atbytes_cnt)) begin
        atbytesm_wide = atbytess[1:0];
      end else if (atbytes_cnt >= ATBYTESM_MAX_PLUS_ONE) begin
        atbytesm_wide = 2'b11;
      end else begin
        atbytesm_wide = atbytes_cnt[1:0];
      end
    end

  assign atbytesm = atbytesm_wide;

  // Flag used to drive the atreadys
  always @(*)
  begin
    if (master_atb_hand_shake && !rem_txr && !(atbytess <= ATBYTESM_MAX)) begin
      nxt_rem_txr = 1'b1;
    end else if (slave_atb_hand_shake) begin
      nxt_rem_txr = 1'b0;
    end else begin
      nxt_rem_txr = rem_txr;
    end
  end

  // Registering nxt_rem_txr logic
  always @(posedge clk or negedge resetn)
    begin : p_rem_txr_seq
      if (!resetn)
        begin
          rem_txr <= 1'b0;
        end
      else
        begin
          rem_txr <= nxt_rem_txr;
        end
    end // p_rem_txr_seq

  // SLAVE 128 bit and Master 32 bit
  always @ *
    begin : p_atdatam_comb
      if (rem_txr)
      case (atbytes_up_cnt)
        4'd15, 4'd14, 4'd13, 4'd12 : atdatam = atdatas[127:96];
        4'd11, 4'd10, 4'd9, 4'd8   : atdatam = atdatas[95:64];
        4'd7, 4'd6, 4'd5, 4'd4     : atdatam = atdatas[63:32];
        4'd3, 4'd2, 4'd1, 4'd0     : atdatam = atdatas[31:0];
        default                    : atdatam = 32'bx;
      endcase
      else
      atdatam = atdatas[31:0];
    end // p_atdatam_comb

`ifdef ARM_ASSERT_ON
  //----------------------------------------------------------------------------
  // OVL Assertions
  //----------------------------------------------------------------------------

localparam atdatas_width = 128;
localparam atdatam_width = 32;
  //----------------------------------------------------------------------------
  // Configuration check
  // Master ATDATA width cannot be hugher than slave ATDATA width
  //----------------------------------------------------------------------------
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
    "OVL Message : Illegal configuration- ATDATAM width is lower then ATDATAS width")
      uzovl_cxatbdownsizer_illegal_config
        (
         .clk         (clk),
         .reset_n     (resetn),
         .test_expr   (atdatas_width < atdatam_width)
        );


    //-----------------------------------------------------------------------------
    // x-check OVLs
    //-----------------------------------------------------------------------------
    assert_never_unknown #(`OVL_FATAL, 1, `OVL_ASSERT, " Signal slave_atb_hand_shake is X")
    uzovl_x_slave_atb_hand_shake (.clk       (clk),
                                  .reset_n   (resetn),
                                  .qualifier (1'b1),
                                  .test_expr (slave_atb_hand_shake));

    assert_never_unknown #(`OVL_FATAL, 1, `OVL_ASSERT, " Signal master_atb_hand_shake is X")
    uzovl_x_master_atb_hand_shake (.clk       (clk),
                                  .reset_n   (resetn),
                                  .qualifier (1'b1),
                                  .test_expr (master_atb_hand_shake));

    assert_never_unknown #(`OVL_FATAL, 1, `OVL_ASSERT, " Select signal for nxt_atbytes_cnt is X")
    uzovl_x_nxt_atbytes_cnt_select1 (.clk       (clk),
                                  .reset_n   (resetn),
                                  .qualifier (1'b1),
                                  .test_expr ((atvalids && !atreadym && !(|atbytes_cnt) && !rem_txr)));

    assert_never_unknown #(`OVL_FATAL, 1, `OVL_ASSERT, " Select signal for nxt_atbytes_cnt is X")
    uzovl_x_nxt_atbytes_cnt_select2 (.clk       (clk),
                                  .reset_n   (resetn),
                                  .qualifier (1'b1),
                                  .test_expr ((atvalids && atreadym && !(|atbytes_cnt) && !rem_txr)));

    assert_never_unknown #(`OVL_FATAL, 1, `OVL_ASSERT, " Select signal for nxt_rem_txr is X")
    uzovl_x_nxt_rem_txr_select (.clk       (clk),
                                  .reset_n   (resetn),
                                  .qualifier (1'b1),
                                  .test_expr ((master_atb_hand_shake && !rem_txr && !(atbytess <= ATBYTESM_MAX))));



`endif

endmodule // cxatbdownsizer
