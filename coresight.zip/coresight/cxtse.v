//-----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2010-2013 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//  Version and Release Control Information:
//
//  Checked In          : $Date: 2013-09-10 13:45:39 +0100 (Tue, 10 Sep 2013) $
//
//  File Revision       : $Revision: 37124 $
//
//  Release Information : CoreSight-SoC-TM100-r3p1-00rel0
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// Abstract : CoreSight Time Stamp Encoder - Top Level Block
//-----------------------------------------------------------------------------
//
// cxtse - CoreSight Time Stamp Encoder
//-----------------------------------------------------------------------------

module cxtse (

  // Clock and Reset
  input wire        tsclk,
  input wire        tsresetn,

  // Master TimeStamp interface
  input wire [63:0] tsvalue,
  input wire        tsforcesync,

  // Time Stamp Encoder
  output reg [6:0]  tsbit,
  output reg [1:0]  tssync,
  input wire        tssyncready

  );

//-----------------------------------------------------------------------------
// Local Parameters
//-----------------------------------------------------------------------------
  localparam CNTZERO   = {64{1'b0}};
  localparam SYNC_MARK = 1'b0;
  localparam SYNC_BIT  = 1'b1;
  localparam RESYNC    = {7{1'b1}};
  localparam TSBITINV  = {7{1'b0}};

  localparam BIT0_MASK = 64'hAAAA_AAAA_AAAA_AAAA;
  localparam BIT1_MASK = 64'hCCCC_CCCC_CCCC_CCCC;
  localparam BIT2_MASK = 64'hF0F0_F0F0_F0F0_F0F0;
  localparam BIT3_MASK = 64'hFF00_FF00_FF00_FF00;
  localparam BIT4_MASK = 64'hFFFF_0000_FFFF_0000;
  localparam BIT5_MASK = 64'hFFFF_FFFF_0000_0000;

//----------------------------------------------------------------------------
// Wires
//----------------------------------------------------------------------------
  wire        ts_cnt_rg_en;
  wire        ts_cnt_en;
  wire [6:0]  ts_bit_nxt;
  wire        ts_bit_en;
  wire [6:0]  ts_int_sync_indx;
  wire [6:0]  ts_cnt_prev_indx;
  wire        tssync_en;
  wire        ts_aligned_indx_en;
  wire [1:0]  ts_sync_bit_info;
  wire [6:0]  ts_index;
  wire [63:0] indx;
  wire [62:0] indx_or;
  wire [63:0] indx_chg;
  wire [5:0]  ts_index_int;
  wire [6:0]  incr_val;
  wire        dummy_co;
  wire        sync_mark_req;

//------------------------------------------------------------------------------
// Reg declarationsts_cnt
//------------------------------------------------------------------------------
  reg [6:0]  ts_aligned_indx;
  reg [63:0] ts_cnt_rg;
  wire[64:0] ts_cnt_rg_pad;
  reg [63:0] ts_cnt_prev;
  reg        sync_state_nxt;
  reg        sync_state;
  reg        sync_state_en;
  reg [1:0]  ts_sync_nxt;
  reg        ts_syncreq_rg;
  reg        ts_sync_en;
  reg        sync_mark_req_rg;

//============================================================================
//
// Main body of code
//
//============================================================================

//----------------------------------------------------------------------------
// Register TimeStamp value from the Master TimeStamp generator
//----------------------------------------------------------------------------
  assign ts_cnt_rg_en = (tsvalue != ts_cnt_rg);

  always @(posedge tsclk or negedge tsresetn)
    begin
      if (!tsresetn)
        ts_cnt_rg <= CNTZERO;
      else if (ts_cnt_rg_en)
        ts_cnt_rg <= tsvalue;
    end

//----------------------------------------------------------------------------
// Register tsforcesync value from the Master TimeStamp generator
//----------------------------------------------------------------------------
  always @(posedge tsclk or negedge tsresetn)
    begin
      if (!tsresetn)
        ts_syncreq_rg <= 1'b0;
      else
        ts_syncreq_rg <= tsforcesync;
    end

//----------------------------------------------------------------------------
// Store the previous TimeStamp value from Master TimeStamp generator
//----------------------------------------------------------------------------
  assign ts_cnt_en = (ts_cnt_rg != ts_cnt_prev);

  always @(posedge tsclk or negedge tsresetn)
    begin
      if (!tsresetn)
        ts_cnt_prev <= CNTZERO;
      else if (ts_cnt_en)
        ts_cnt_prev <= ts_cnt_rg;
    end

//-----------------------------------------------------------------------------
// Algorithm
//-----------------------------------------------------------------------------
// Store the previous value of the counter
// Compare with the current value of the counter
// Generate a signal which indicates if there is a change
// If there is a change only then proceed to generate a new index
// When there is a change, following procedure is followed to generate
// the index. This index indicates that current bit position has to be
// set and all the lower bits from the current index needs to be reset.
// The bit[0] will be selected only if none of the other upper bits
// i.e bit[N-1:1] do not change.
// Similarly for bit[1] index will be selected only if none of the higher
// bits change i.e bit[N-1:1] remain unchanged. This logic is extended
// for all the higher bits

  assign indx_chg[63]    = (ts_cnt_rg[63] ^ ts_cnt_prev[63]);
  assign indx_chg[62]    = (ts_cnt_rg[62] ^ ts_cnt_prev[62]);

  assign indx_or[62] = indx_chg[63];
  assign indx_or[61] = indx_or[62] | indx_chg[62];

  genvar i;
  generate
   for (i = 0; i < 62; i = i+1)
     begin : gen_indx_chg
       assign indx_chg[i] = (ts_cnt_rg[i] ^ ts_cnt_prev[i]);
     end
   for (i = 0; i < 61; i = i+1)
     begin : gen_indx_or
       assign indx_or[i]  = indx_or[i+1] | indx_chg[i+1];
     end
  endgenerate

  assign indx = {indx_chg[63], (indx_chg[62:0] & ~indx_or[62:0])};

  assign ts_index_int[0] = |(indx & BIT0_MASK);
  assign ts_index_int[1] = |(indx & BIT1_MASK);
  assign ts_index_int[2] = |(indx & BIT2_MASK);
  assign ts_index_int[3] = |(indx & BIT3_MASK);
  assign ts_index_int[4] = |(indx & BIT4_MASK);
  assign ts_index_int[5] = |(indx & BIT5_MASK);

  assign incr_val = (ts_index_int[5:0] == {6{1'b0}}) ?
                      {{6{1'b0}},indx[0]} :
                        {{6{1'b0}},1'b1};

  assign {dummy_co, ts_index} = {1'b0,ts_index_int} + incr_val;

//------------------------------------------------------------------------------
// Encoder interface. A function to encode the bit which has changed is used.
// This will be sent on the encoded channel. The encoded value is valid only
// when the current count value is different from the previous count value and
// count value is not zero.
//------------------------------------------------------------------------------
  assign ts_bit_nxt = ts_syncreq_rg ? RESYNC : ts_index;

  assign ts_bit_en = ts_cnt_en |
                     ts_syncreq_rg |
                     ((tsbit != TSBITINV) && (ts_bit_nxt == TSBITINV));

//----------------------------------------------------------------------------
// Time Stamp Encoded values
//----------------------------------------------------------------------------

  always @(posedge tsclk or negedge tsresetn)
    if (!tsresetn) begin
      tsbit <= {7{1'b0}};
    end else if (ts_bit_en) begin
      tsbit <= ts_bit_nxt;
    end

//----------------------------------------------------------------------------
// Synchronization channel. Synchronization values are sent over this channel.
// There are 4 different options
// 2'b00 : Invalid sync value, needs to be ignored
// 2'b01 : sync-mark indicates the begining of a new sync-cycle
// 2'b10 : Sync-bit being sent is 0
// 2'b11 : Sync-bit being sent is 1
// This state machine sends a sequence of Sync-mark followed by sync-bits and
// then repeats this cycle. If the sync-channel is not ready and then it holds
// the value and resends it the next cycle
//
// This has 2 states SYNC_MARK and SYNC_BIT
//
// Initially it will send the sync-mark when the FSM is in SYNC_MARK state
// Then it transitions to SYNC_BIT state to send the sync-bit
//
// When the Index bit being sent on the encoded channel is equal to or greater
// than the bit being sent serially then sync-bit sequence is terminated.
//
// Sync-mark will be sent to start a fresh sequence. If the sync-channel is not
// ready then the FSM transitions to SYNC_MARK state and stays there till it
// sends the sync-mark and then transitions to SYNC_BIT. Other wise it sends
// the sync-mark and stays in SYNC_BIT state.
//----------------------------------------------------------------------------
  assign ts_int_sync_indx = ((tssync == 2'b01) ||
                             (tssyncready & (ts_bit_nxt >= ts_aligned_indx))) ?
                               7'd64 :
                                 (ts_aligned_indx - 7'd1);

  assign ts_aligned_indx_en = tssyncready | (tssync == 2'b01);

  always @(posedge tsclk or negedge tsresetn)
    if (!tsresetn) begin
      ts_aligned_indx <= 7'd64;
    end else if (ts_aligned_indx_en) begin
      ts_aligned_indx <= ts_int_sync_indx;
    end

  // When bit below current sync position is set, SYNC_MARK is required once sync is accepted
  // Detect last valid bit being sent if value is static
  // Repeat SYNC_MARK if resync request generates RESYNC when TSSYNC is stalled
  assign sync_mark_req = (~tssyncready &(sync_mark_req_rg | (ts_bit_nxt == ts_aligned_indx) | (ts_aligned_indx == 7'h02) | ts_syncreq_rg));

  always @(posedge tsclk or negedge tsresetn)
    if (!tsresetn) begin
      sync_mark_req_rg <= 1'b0;
    end else begin
      sync_mark_req_rg <= sync_mark_req;
    end

  assign ts_cnt_prev_indx =  ts_int_sync_indx & {7{(|ts_int_sync_indx)}};
  assign ts_cnt_rg_pad    = {ts_cnt_rg,1'b0};

  assign ts_sync_bit_info = {1'b1, ts_cnt_rg_pad[ts_cnt_prev_indx]};

  always @(*)
    begin
      sync_state_en = 1'b1;
      sync_state_nxt = sync_state;
      ts_sync_en = 1'b0;

      case (sync_state)
        SYNC_MARK : begin
          if (tssyncready & ~ts_syncreq_rg & ~sync_mark_req_rg) begin
            ts_sync_nxt = (tssync == 2'b01) ? ts_sync_bit_info : 2'b01;
            sync_state_nxt = SYNC_BIT;
          end else begin
            ts_sync_nxt = tssync;
            sync_state_en = 1'b0;
          end
        end
        SYNC_BIT : begin
          if (ts_bit_nxt > ts_aligned_indx) begin
            if (tssyncready) begin
              sync_state_nxt = SYNC_BIT;
              ts_sync_nxt = 2'b01;
            end else begin
              sync_state_nxt = SYNC_MARK;
              ts_sync_nxt = 2'b01;
              ts_sync_en = 1'b1;
            end
          end else begin
            if (((ts_bit_nxt == ts_aligned_indx) | sync_mark_req_rg) & tssyncready) begin
                sync_state_nxt = SYNC_BIT;
                ts_sync_nxt = 2'b01;
              end else begin
                ts_sync_nxt = ts_sync_bit_info;
                sync_state_en = 1'b0;
              end
          end
        end
        default : ts_sync_nxt = {2{1'bx}};
      endcase
    end

  always @(posedge tsclk or negedge tsresetn)
    if (!tsresetn) begin
      sync_state <= SYNC_MARK;
    end else if (sync_state_en) begin
      sync_state <= sync_state_nxt;
    end

  assign tssync_en = tssyncready | ts_sync_en;

  always @(posedge tsclk or negedge tsresetn)
    if (!tsresetn) begin
      tssync <= {2{1'b0}};
    end else if (tssync_en) begin
      tssync <= ts_sync_nxt;
    end

//----------------------------------------------------------------------------
// ASSERTIONS
//----------------------------------------------------------------------------

`ifdef ARM_ASSERT_ON

//-----------------------------------------------------------------------------
// Check if the fsm enters illegal state
// If it enters default, generate an error message
//-----------------------------------------------------------------------------
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxtse - FSM has entered an illegal state")
      uzovl_cxtse_illegal_state_chk
        (
         .clk         (tsclk),
         .reset_n     (tsresetn),
         .test_expr   ((sync_state != SYNC_MARK) &&
                       (sync_state != SYNC_BIT))
        );

//-----------------------------------------------------------------------------
// Check if the encoder stops sending sync-packets when the input count value
// does not increment
//-----------------------------------------------------------------------------
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxtse - Encoder missed a sync-mark")
      uzovl_cxtse_sync_pck_state_chk
        (
         .clk         (tsclk),
         .reset_n     (tsresetn),
         .test_expr   ((ts_aligned_indx > 7'd64) && (ts_aligned_indx < 7'd127))
        );



`endif // ARM_ASSERT_ON

endmodule
