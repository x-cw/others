//+FHDR*************************************************************************
// 
//   Copyright (c) 2025 Innosilicon. Ltd.  All rights reserved. 
// 
//   THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF INNOSILICON
//   The copyright notice above does not evidence any actual or intended
//   publication of such source code.
// 
//************************************************************************
//    Module name: intlv_stage_2.v
//    Create by  : fangxn
//    Email      : fangxn@innosilicon.com.cn
//    Create time: 2025-08-06
//************************************************************************
//    Description: 
//-FHDR*************************************************************************
module intlv_stage_2  #(
    parameter    IDW        =   8,                      // the width of awid/arid
    parameter    ADDRW      =   51,                     // the width of awaddr/araddr
    parameter    WXP0       =   29,    
    parameter    WXP        =   100,
    parameter    ST2_SW     =   23
)(
    // clock and reset, used for debug logic 
    input   wire                            clk,
    input   wire                            rst_n,

    input  wire                             i_up_valid,
    output wire                             o_up_ready,

    // slice payload in
    input   wire        [WXP-1:0]          slice_payload_i,


    output  wire                            o_down_valid,
    input   wire                            i_down_ready,

    // slice payload out
    output  wire        [ST2_SW+WXP0-1:0]   slice_payload_o
);

// axi_payload extracted
wire    [21:0]              dividend_all       ;
wire    [6:0]               divisor_all        ;

wire    [6:0]               divisor_rem        ;
wire    [15:0]              divisor_quo        ;
wire    [5:0]               divisor_quo_noused ;

reg                         intlv_valid_s0     ;
reg     [WXP0-1:0]          intlv_data_s0      ;
wire                        in_data_valid_en   ;


reg     [21:0]              divisor_quo_temp   ;
reg     [6:0]               divisor_rem_temp   ;

/////////////analyze slice_payload_i result///////////////////////////
assign  divisor_all               = slice_payload_i[WXP0+7-1:WXP0];
assign  dividend_all              = slice_payload_i[WXP0+7+22-1:WXP0+7];

//////////////////////////////solve div delay problem/////////////////////////////////////////////////////////////////////////////
always@(posedge clk or negedge rst_n) begin
    if(rst_n == 1'b0) begin
        intlv_valid_s0  <= 1'b0;
    end else if (!intlv_valid_s0 || i_down_ready) begin
        intlv_valid_s0  <= i_up_valid;
    end
end

always@(posedge clk or negedge rst_n) begin
    if(rst_n == 1'b0) begin
        intlv_data_s0  <= '0;
    end else if (i_up_valid && (!intlv_valid_s0 || i_down_ready)) begin
        intlv_data_s0  <= slice_payload_i[WXP0-1:0];
    end
end

assign o_up_ready = !intlv_valid_s0 | i_down_ready;


assign in_data_valid_en = i_up_valid && o_up_ready;

////////////////////////////////////DW_div/////////////////////////////////////////////////////////////////////////////////////////
`ifdef PAL_INTLV_DIV
    always@(posedge clk or negedge rst_n) begin
        if(rst_n == 1'b0) begin
           divisor_quo_temp           <= '0;
           divisor_rem_temp           <= '0;
        end else if (i_up_valid && (!intlv_valid_s0 || i_down_ready)) begin
           divisor_quo_temp           <= dividend_all / divisor_all;
           divisor_rem_temp           <= dividend_all % divisor_all;
        end
    end

    assign  {divisor_quo_noused,divisor_quo} =   divisor_quo_temp;
    assign  divisor_rem                      =   divisor_rem_temp;


`else 
  DW_div_pipe #(
        .a_width     ( 22 ), 
        .b_width     ( 7 ),
        .tc_mode     ( 0 ),
        .rem_mode    ( 1 ),
        .num_stages  ( 2 ),
        .stall_mode  ( 1 ),
        .rst_mode    ( 2 ),
        .op_iso_mode ( 1 )
    )u_DW_banknum(
// ports 
        .clk          (clk                                    ), 
        .rst_n        (rst_n                                  ),
        .en           (in_data_valid_en                       ), 
        .a            (dividend_all                           ),
        .b            (divisor_all                            ),

        .quotient     ({divisor_quo_noused,divisor_quo}       ),
        .remainder    (divisor_rem                            ),
        .divide_by_0  (                                       )
    );
`endif

//////////////////////rebuild handshank signal////////////////
assign o_down_valid      = intlv_valid_s0;
assign slice_payload_o   = {divisor_quo,divisor_rem,intlv_data_s0};


endmodule
