+incdir+$GP3_RTL/coresight/rtl/coresight_component/timestamp_module/cxtsgen/verilog

$GP3_RTL/coresight/rtl/coresight_component/timestamp_module/cxtsgen/verilog/cxtsgencntr.v
$GP3_RTL/coresight/rtl/coresight_component/timestamp_module/cxtsgen/verilog/cxtsgenregblk.v
$GP3_RTL/coresight/rtl/coresight_component/timestamp_module/cxtsgen/verilog/cxtsgen.v
