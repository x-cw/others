// ----------------------------------------------------------------------------
//  The confidential and proprietary information contained in this file may
//  only be used by a person authorised under and to the extent permitted
//  by a subsisting licensing agreement from ARM Limited.
//
//                (C) COPYRIGHT 2004-2015 ARM Limited.
//                    ALL RIGHTS RESERVED
//
//  This entire notice must be reproduced on all copies of this file
//  and copies of this file may only be made by a person if such person is
//  permitted to do so under the terms of a subsisting license agreement
//  from ARM Limited.
//
//    Checked In : $Date: 2014-01-15 12:32:16 +0000 (Wed, 15 Jan 2014) $
//    Revision   : $Revision: 38664 $
//    Release    : CoreSight-SoC-TM100-r3p2-00rel0
// ----------------------------------------------------------------------------
//  Purpose : DAP JTAG-DP Definitions.
// ----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// JTAG states
//-----------------------------------------------------------------------------
localparam JTAGDP_E2D  = 4'b0000;
localparam JTAGDP_E1D  = 4'b0001;
localparam JTAGDP_SHD  = 4'b0010;
localparam JTAGDP_PDR  = 4'b0011;
localparam JTAGDP_SIR  = 4'b0100;
localparam JTAGDP_UDR  = 4'b0101;
localparam JTAGDP_CDR  = 4'b0110;
localparam JTAGDP_SDR  = 4'b0111;
localparam JTAGDP_E2I  = 4'b1000;
localparam JTAGDP_E1I  = 4'b1001;
localparam JTAGDP_SHIR = 4'b1010;
localparam JTAGDP_PIR  = 4'b1011;
localparam JTAGDP_RTI  = 4'b1100;
localparam JTAGDP_UIR  = 4'b1101;
localparam JTAGDP_CIR  = 4'b1110;
localparam JTAGDP_TLR  = 4'b1111;

//-----------------------------------------------------------------------------
// Control
//-----------------------------------------------------------------------------
localparam JTAGDP_CTRL      = 2'b01;
localparam JTAGDP_STAT      = 2'b01;
localparam JTAGDP_ADDR      = 2'b10;
localparam JTAGDP_DAPW      = 1'b0;
localparam JTAGDP_DAPR      = 1'b1;
localparam JTAGDP_APBR      = 1'b0;
localparam JTAGDP_APBW      = 1'b1;
localparam JTAGDP_MUXSTAT   = 2'b01;
localparam JTAGDP_MUXADDR   = 2'b10;
localparam JTAGDP_MUXRBUF   = 2'b11;
localparam JTAGDP_AP        = 1'b0;
localparam JTAGDP_DP        = 1'b1;

//-----------------------------------------------------------------------------
// JTAG IR values
//-----------------------------------------------------------------------------
localparam JTAGDP_ABORT_3B  = 3'b000;
localparam JTAGDP_UNK0_3B   = 3'b001;
localparam JTAGDP_DPACC_3B  = 3'b010;
localparam JTAGDP_APACC_3B  = 3'b011;
localparam JTAGDP_UNK1_3B   = 3'b100;
localparam JTAGDP_UNK2_3B   = 3'b101;
localparam JTAGDP_IDCODE_3B = 3'b110;
localparam JTAGDP_BYPASS_3B = 3'b111;


//-----------------------------------------------------------------------------
// TAP ID code
//-----------------------------------------------------------------------------
localparam JTAGDP_DEVICEID_IR4 = 32'h6BA00477;
localparam JTAGDP_DEVICEID_IR8 = 32'h0BA03477;
