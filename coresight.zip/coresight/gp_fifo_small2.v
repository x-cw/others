`include "../general/general.vh"


module gp_fifo_small2 #(
  parameter ENABLE_INIT_INPUT = 0,  
  parameter FIFO_WIDTH        = 0,
  parameter FIFO_WORDS        = 0,
  parameter AFULL_THRESH      = 0,
  parameter AEMPTY_THRESH     = 0,
  parameter L2_FIFO_WORDS     = log2(FIFO_WORDS)
) (
  input wire                   clk,
  input wire                   reset_n,

  input wire                   init,
  
  //read
  input wire                   rd_en,
  output wire [FIFO_WIDTH-1:0] dout,
  
  //write
  input wire                   wr_en,
  input wire [FIFO_WIDTH-1:0]  din,
  
  //status
  output reg                   aempty,
  output reg                   afull, 
  output reg                   empty,
  output reg                   full,
  output reg                   overflow,
  output reg                   underflow,
  output reg [L2_FIFO_WORDS:0] valid_entries
);

`include "../general/misc.vh"
  
  reg [FIFO_WIDTH-1:0]  fifo     [FIFO_WORDS-1:0];
  reg [FIFO_WORDS-1:0]  fifo_wen;
  reg [L2_FIFO_WORDS:0] valid_entries_next;
  
  always @* begin
    fifo_wen = 'd0;
    if(wr_en) begin
      if(rd_en) begin
        fifo_wen[valid_entries-1] = 1'b1;
      end else begin
        fifo_wen[valid_entries] = 1'b1;
      end
    end
  end
  
  always @* begin
    if((ENABLE_INIT_INPUT==1) & init) begin
      valid_entries_next  = 'd0;
    end else begin
      case ({wr_en,rd_en})
      2'b10   : valid_entries_next  = valid_entries + 1;
      2'b01   : valid_entries_next  = valid_entries - 1;
      default : valid_entries_next  = valid_entries;      //hold on +1-1 or nothing...
      endcase
    end
  end
  
  genvar i;
  generate
    for(i=0;i<FIFO_WORDS;i=i+1) begin: fifo_loop
      if(i == (FIFO_WORDS-1)) begin : fifo_end

        always @(posedge clk) begin
          if(fifo_wen[i]) fifo[i] <= din;
          else if(rd_en)  fifo[i] <= 'dX;   // force error
        end
        
      end else begin : fifo_intermediate
      
        always @(posedge clk) begin
          if(fifo_wen[i]) fifo[i] <= din;
          else if(rd_en)  fifo[i] <= fifo[i+1];
        end
        
      end
    end
  endgenerate

  always @(posedge clk or negedge reset_n) begin
    if (~reset_n) begin
      aempty <= 1'h1;
      empty <= 1'h1;
      /*autoreset*/
      // Beginning of autoreset for uninitialized flops
      afull <= 1'h0;
      full <= 1'h0;
      overflow <= 1'h0;
      underflow <= 1'h0;
      valid_entries <= {(1+(L2_FIFO_WORDS)){1'b0}};
      // End of automatics
    end else if((ENABLE_INIT_INPUT==1) & init) begin
      aempty <= 1'h1;
      empty <= 1'h1;    
      /*autoreset*/
      // Beginning of autoreset for uninitialized flops
      afull <= 1'h0;
      full <= 1'h0;
      overflow <= 1'h0;
      underflow <= 1'h0;
      valid_entries <= {(1+(L2_FIFO_WORDS)){1'b0}};
      // End of automatics
    end else begin
      
      valid_entries <= valid_entries_next;
      
      if (wr_en && full)  overflow<=1;
      
      if (rd_en && empty) underflow<=1;
    
      if (valid_entries_next == FIFO_WORDS) 
        full<=1;
      else
        full<=0;

      if (valid_entries_next >= AFULL_THRESH) 
        afull<=1;
      else
        afull<=0;

      if (valid_entries_next == 0) 
        empty<=1;
      else
        empty<=0;        

      if (valid_entries_next < AEMPTY_THRESH) 
        aempty<=1;
      else
        aempty<=0;           
        
    end
  end
  
  assign dout = fifo[0];

  //`ifdef VCS
  //`ifdef DO_WAVE
  //initial $vcdplusmemon(fifo);
  //`endif
  //`endif
  
endmodule
