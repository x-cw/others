//-----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2003-2015 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//    Checked In : $Date: 2014-08-14 16:01:35 +0100 (Thu, 14 Aug 2014) $
//    Revision   : $Revision: 39945 $
//    Release    : CoreSight-SoC-TM100-r3p2-00rel0
//
// -----------------------------------------------------------------------------
//      Purpose             : ECT Channel Interface Module
// --=========================================================================--

module cxcti_ci
  (
  // Inputs
  cticlk, cticlken, ctiresetn, cti_control, cisbypass, cihsbypass,
  ctichin, ctichoutack, map_ch_out, ch_out_enable, iten, itchin_ack_en,
  itch_out_en, pwdatadbg,
  // Outputs
  ctichout, map_ch_in, ctichinack, reg_ch_in_status, reg_ch_out_status,
  itchout_ack_r_data, itchin_r_data
  );

`include "cxcti_constants.v"

  //----------------------------------------------------------------------------
  // INPUTS
  //----------------------------------------------------------------------------

  input                              cticlk;        // Clock
  input                              cticlken;      // Clock Enable
  input                              ctiresetn;     // Reset

  input                              cti_control;   // SW Global enable

  input                              cisbypass;     // Channel interface Sync Bypass
  input [CSSOC_ECTCHANNELWIDTH-1:0]  cihsbypass;    // Channel interface H/S Bypass

  input [CSSOC_ECTCHANNELWIDTH-1:0]  ctichin;       // Channel inputs
  input [CSSOC_ECTCHANNELWIDTH-1:0]  ctichoutack;   // Channel out ACK
  input [CSSOC_ECTCHANNELWIDTH-1:0]  map_ch_out;    // Channel from Mapper
  input [CSSOC_ECTCHANNELWIDTH-1:0]  ch_out_enable; // Channel Out Enable


  input                              iten;          // Test mode control
  input                              itchin_ack_en; // Int.Reg ChInAck enable
  input                              itch_out_en;   // Int.Reg ChOut enable
  input [CSSOC_ECTCHANNELWIDTH-1:0]  pwdatadbg;     // Write data

  //----------------------------------------------------------------------------
  // OUTPUTS
  //----------------------------------------------------------------------------
  output [CSSOC_ECTCHANNELWIDTH-1:0] ctichout;       // Channel outputs
  output [CSSOC_ECTCHANNELWIDTH-1:0] map_ch_in;      // Channel to Mapper
  output [CSSOC_ECTCHANNELWIDTH-1:0] ctichinack;     // Channel In ACK

  output [CSSOC_ECTCHANNELWIDTH-1:0] reg_ch_in_status;  // From Channel In Register
  output [CSSOC_ECTCHANNELWIDTH-1:0] reg_ch_out_status; // From Channel Out Register

  output [CSSOC_ECTCHANNELWIDTH-1:0] itchout_ack_r_data;// Int.Reg ChOutAck data
  output [CSSOC_ECTCHANNELWIDTH-1:0] itchin_r_data;     // Int.Reg ChIn data


  //----------------------------------------------------------------------------
  // WIRES AND REGS
  //----------------------------------------------------------------------------

  wire                               cti_enable_int;
  wire [CSSOC_ECTCHANNELWIDTH-1:0]   ci_in_tmux;
  wire [CSSOC_ECTCHANNELWIDTH-1:0]   ci_out_acktmux;
  wire [CSSOC_ECTCHANNELWIDTH-1:0]   ci_in_sync_2;
  wire [CSSOC_ECTCHANNELWIDTH-1:0]   ctichin_corrupt;
  wire [CSSOC_ECTCHANNELWIDTH-1:0]   ci_out_ack_sync_2;
  wire [CSSOC_ECTCHANNELWIDTH-1:0]   ctichoutack_corrupt;
  wire [CSSOC_ECTCHANNELWIDTH-1:0]   ci_in_synced;
  wire [CSSOC_ECTCHANNELWIDTH-1:0]   ci_out_ack_synced;
  wire [CSSOC_ECTCHANNELWIDTH-1:0]   nxt_ch_in_ack;
  reg  [CSSOC_ECTCHANNELWIDTH-1:0]   reg_ch_in_ack;
  wire [CSSOC_ECTCHANNELWIDTH-1:0]   nxt_ci_out_holder;
  reg  [CSSOC_ECTCHANNELWIDTH-1:0]   reg_ci_out_holder;
  wire [CSSOC_ECTCHANNELWIDTH-1:0]   ci_out_internal;
  wire [CSSOC_ECTCHANNELWIDTH-1:0]   ci_out_int;
  reg  [CSSOC_ECTCHANNELWIDTH-1:0]   ci_out_int_reg;
  wire [CSSOC_ECTCHANNELWIDTH-1:0]   ci_in_ack_int;
  wire                               reg_ch_in_ack_en;
  wire [CSSOC_ECTCHANNELWIDTH-1:0]   map_ch_out_gated;
  wire                               reg_ci_out_holder_en;

  //----------------------------------------------------------------------------
  //
  // MAIN CODE
  //
  //----------------------------------------------------------------------------


  //----------------------------------------------------------------------------
  // Channel In
  //----------------------------------------------------------------------------
`ifdef ARM_CDC_CHECK
  // Test component to corrupt ctichin going into synchroniser
  cx_cdc_corrupt_gry #(.WIDTH(4)) u_cdc_corrupt_ctichin (
      .clk    (cticlk),
      .resetn (ctiresetn),
      .sync   (1'b0),
      .d_async(ctichin),
      .q_async(ctichin_corrupt)
    );
`else
  assign ctichin_corrupt   = ctichin;
`endif

  // Input synchronisation - must be adjusted if CSSOC_ECTCHANNELWIDTH is changed
  cx_en_sync u_cxcti_ciin_sync_0
    (
    .clk      (cticlk),
    .resetn   (ctiresetn),
    .clken    (cticlken),
    .sync_di  (ctichin_corrupt[0]),
    .sync_do  (ci_in_sync_2[0])
    );
  cx_en_sync u_cxcti_ciin_sync_1
    (
    .clk      (cticlk),
    .resetn   (ctiresetn),
    .clken    (cticlken),
    .sync_di  (ctichin_corrupt[1]),
    .sync_do  (ci_in_sync_2[1])
    );
  cx_en_sync u_cxcti_ciin_sync_2
    (
    .clk      (cticlk),
    .resetn   (ctiresetn),
    .clken    (cticlken),
    .sync_di  (ctichin_corrupt[2]),
    .sync_do  (ci_in_sync_2[2])
    );
  cx_en_sync u_cxcti_ciin_sync_3
    (
    .clk      (cticlk),
    .resetn   (ctiresetn),
    .clken    (cticlken),
    .sync_di  (ctichin_corrupt[3]),
    .sync_do  (ci_in_sync_2[3])
    );

  // Sync MUX
  cx_comb_mux2 #(.WIDTH(CSSOC_ECTCHANNELWIDTH)) u_ctichin_sync_mux
    (
    .din1_async (ci_in_sync_2),
    .din2_async (ctichin),
    .sel        (cisbypass),
    .dout_async (ci_in_synced)
    );

  // Input test mux
  assign ci_in_tmux     = ci_in_synced;

  // Integration Register
  assign itchin_r_data = ci_in_synced;

  // Generate Channel In ACK and allow integration register write
  assign nxt_ch_in_ack = itchin_ack_en ? pwdatadbg : ci_in_tmux;

  // When in integration mode, the register is updated only when written
  // In normal operation the register is always updated.
  assign reg_ch_in_ack_en = cticlken & (~iten | (iten & itchin_ack_en));

  // Register ChannelInAck output
  always @(posedge cticlk or negedge ctiresetn)
    begin
      if (!ctiresetn)
        reg_ch_in_ack <= {CSSOC_ECTCHANNELWIDTH{1'b1}};
      else if (reg_ch_in_ack_en)
        reg_ch_in_ack <= nxt_ch_in_ack;
    end

  // Channel In ACK test MUX
  assign ci_in_ack_int = reg_ch_in_ack;

  // Connect channel in to mapper
  assign map_ch_in = (cti_enable_int ==1'b1) ? ci_in_tmux : {CSSOC_ECTCHANNELWIDTH{1'b0}};

  // Channel In Status Register
  assign reg_ch_in_status = ci_in_tmux;

  //----------------------------------------------------------------------------
  // Channel Out
  //----------------------------------------------------------------------------

  // map_ch_out must be gated when the device is in integration mode, to bypass
  // the or gate after the holding register
  assign map_ch_out_gated = iten ? {CSSOC_ECTCHANNELWIDTH{1'b0}} : map_ch_out;

`ifdef ARM_CDC_CHECK
  // Test component to corrupt ctichoutack going into synchroniser
  cx_cdc_corrupt_gry #(.WIDTH(4)) u_cdc_corrupt_ctichoutack (
      .clk    (cticlk),
      .resetn (ctiresetn),
      .sync   (1'b0),
      .d_async(ctichoutack),
      .q_async(ctichoutack_corrupt)
    );
`else
  assign ctichoutack_corrupt   = ctichoutack;
`endif

  // Input synchronisation
  cx_en_sync u_cxcti_choutack_sync_0
    (
    .clk      (cticlk),
    .resetn   (ctiresetn),
    .clken    (cticlken),
    .sync_di  (ctichoutack_corrupt[0]),
    .sync_do  (ci_out_ack_sync_2[0])
    );
  cx_en_sync u_cxcti_choutack_sync_1
    (
    .clk      (cticlk),
    .resetn   (ctiresetn),
    .clken    (cticlken),
    .sync_di  (ctichoutack_corrupt[1]),
    .sync_do  (ci_out_ack_sync_2[1])
    );
  cx_en_sync u_cxcti_choutack_sync_2
    (
    .clk      (cticlk),
    .resetn   (ctiresetn),
    .clken    (cticlken),
    .sync_di  (ctichoutack_corrupt[2]),
    .sync_do  (ci_out_ack_sync_2[2])
    );
  cx_en_sync u_cxcti_choutack_sync_3
    (
    .clk      (cticlk),
    .resetn   (ctiresetn),
    .clken    (cticlken),
    .sync_di  (ctichoutack_corrupt[3]),
    .sync_do  (ci_out_ack_sync_2[3])
    );


  // Sync MUX
  cx_comb_mux2 #(.WIDTH(CSSOC_ECTCHANNELWIDTH)) u_ctichoutack_sync_mux
    (
    .din1_async (ci_out_ack_sync_2),
    .din2_async (ctichoutack),
    .sel        (cisbypass),
    .dout_async (ci_out_ack_synced)
    );

  // Input test mux
  assign ci_out_acktmux = ci_out_ack_synced;

  // Integration register
  assign itchout_ack_r_data = ci_out_ack_synced;

  // Channel Out
  assign ci_out_internal = (cti_enable_int ==1'b1) ?
                           (( {CSSOC_ECTCHANNELWIDTH{ iten}}  & reg_ci_out_holder) |
                            (({CSSOC_ECTCHANNELWIDTH{~iten}}) & (ch_out_enable & (map_ch_out_gated | reg_ci_out_holder)))):
                              {CSSOC_ECTCHANNELWIDTH{1'b0}};

  // Holder for Channel out - Channel out remain high until an ACK is received
  // or if the handshaking is disabled
  assign nxt_ci_out_holder = itch_out_en ? pwdatadbg :
                                           (ci_out_internal & (~cihsbypass) & (~ci_out_acktmux));

  // When in integration mode, the register is updated only when written
  // In normal operation the register is always updated.
  assign reg_ci_out_holder_en = cticlken & (~iten | (iten & itch_out_en));

  // Register Channel Output holder
  always @(posedge cticlk or negedge ctiresetn)
    begin
      if (!ctiresetn)
        reg_ci_out_holder <= {CSSOC_ECTCHANNELWIDTH{1'b0}};
      else if (reg_ci_out_holder_en)
        reg_ci_out_holder <= nxt_ci_out_holder;
    end

  // Trigger Out Test mux
  assign ci_out_int = ci_out_internal;

  // Internal CTI Enable
  assign cti_enable_int  = cti_control;

  // Connect internal net to higher level
  assign ctichout   = ci_out_int_reg;
  assign ctichinack = ci_in_ack_int;

  // Channel Out Status register
  assign reg_ch_out_status = ci_out_int_reg;

  // Flops to register the actual Chout signals before they are
  // output
  always @(posedge cticlk or negedge ctiresetn)
    begin
      if (!ctiresetn)
        ci_out_int_reg <= {CSSOC_ECTCHANNELWIDTH{1'b0}};
      else if (cticlken)
        ci_out_int_reg <= ci_out_int;
    end

endmodule
