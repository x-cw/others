+incdir+$GP3_RTL/coresight/rtl/coresight_component/trigger_module/cxctm/verilog 
$GP3_RTL/coresight/rtl/coresight_component/trigger_module/cxctm/verilog/cxctm_bridge.v  
$GP3_RTL/coresight/rtl/coresight_component/trigger_module/cxctm/verilog/cxctm_constants.v
$GP3_RTL/coresight/rtl/coresight_component/trigger_module/cxctm/verilog/cxctm_sync_channel.v
$GP3_RTL/coresight/rtl/coresight_component/trigger_module/cxctm/verilog/cxctm.v
