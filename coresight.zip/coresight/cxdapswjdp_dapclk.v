// ----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//        (C) COPYRIGHT 2004-2015 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//      Checked In          : $Date: 2014-01-15 12:32:16 +0000 (Wed, 15 Jan 2014) $
//      Revision            : $Revision: 38664 $
//      Release             : CoreSight-SoC-TM100-r3p2-00rel0
//
// ----------------------------------------------------------------------------
//  Purpose : Top level for dapclk domain
// ----------------------------------------------------------------------------

module cxdapswjdp_dapclk
  (
    // Outputs
  output wire         dapsel,         // DAP transaction select
  output wire         dapenable,      // DAP Enable Transaction
  output wire         dapwrite,       // DAP Bus write
  output wire         dapabort,       // DAP abort
  output wire [31:24] dapaddr_31to24, // DAP address bits [31:24]
  output wire [7:2]   dapaddr_7to2,   // DAP address bits [7:2]

  output wire [31:0]  dapwdata,       // DAP write Data
  output wire         busack,         // Bus Transaction Acknowledge
  output wire [31:0]  busrdata,       // Bus read Data Port
  output wire         buscmp,         // Bus Pushed Verify/Find
  output wire         buserr,         // Bus Error
  output wire [11:0]  busendcnt,      // Bus endCount

    // Inputs
  input wire          dapresetn,      // Debug APB Reset
  input wire          dapclk,         // Debug APB Clock
  input wire          dapclken,       // Debug APB Clock Enable
  input wire [31:0]   daprdata,       // DAP read bus
  input wire          dapready,       // Ready signal for DAP slaves
  input wire          dapslverr,      // Error signal for DAP slaves
  input wire          bus_write_c,    // Bus write
  input wire [31:24]  busaddr_31to24, // Bus Address - AP Sel
  input wire [7:2]    busaddr_7to2,   // Bus Address - Bank/Reg Sel
  input wire [31:0]   bus_wdata_c,    // Bus write Data Port
  input wire [1:0]    busmode_c,      // Bus Mode
  input wire [3:0]    busmask_c,      // Bus Compare Mask
  input wire [11:0]   bus_trn_cnt_c,  // Bus Transfer Cnt
  input wire          busreq_c,       // Bus Transaction Request
  input wire          busabort_c      // Bus abort
  );

// --------------------------------------------------------------------------
// Wire Declarations
// --------------------------------------------------------------------------
  wire          busreq_d;        // sync wire
  wire          busabort_d;      // sync wire

//------------------------------------------------------------------------------
// Beginning of main code
//------------------------------------------------------------------------------
  // DAP APB interface
  cxdapswjdp_sw_dp_apb_if  u_cxdapswjdp_sw_dp_apb_if
   (
    // Outputs
    .dapsel         (dapsel),
    .dapenable      (dapenable),
    .dapwrite       (dapwrite),
    .dapabort       (dapabort),
    .dapaddr_31to24 (dapaddr_31to24),
    .dapaddr_7to2   (dapaddr_7to2),
    .dapwdata       (dapwdata[31:0]),
    .busack         (busack),
    .busrdata       (busrdata[31:0]),
    .buscmp         (buscmp),
    .buserr         (buserr),
    .busendcnt      (busendcnt[11:0]),
    // Inputs
    .dapresetn      (dapresetn),
    .dapclk         (dapclk),
    .dapclken       (dapclken),
    .daprdata       (daprdata[31:0]),
    .dapready       (dapready),
    .dapslverr      (dapslverr),
    .busreq         (busreq_d),
    .buswrite       (bus_write_c),
    .busaddr_31to24 (busaddr_31to24),
    .busaddr_7to2   (busaddr_7to2),
    .busabort       (busabort_d),
    .buswdata       (bus_wdata_c[31:0]),
    .busmode        (busmode_c[1:0]),
    .busmask        (busmask_c[3:0]),
    .bustrncnt      (bus_trn_cnt_c[11:0]));

  // dapclk domain synchronisers
  cxdapswjdp_dp_apb_sync  u_cxdapswjdp_dp_apb_sync
   (
    .dapresetn      (dapresetn),
    .dapclk         (dapclk),
    .dapclken       (dapclken),
    .busreq         (busreq_c),
    .busabort       (busabort_c),

    .busreq_d       (busreq_d),
    .busabort_d     (busabort_d)
    );

endmodule
