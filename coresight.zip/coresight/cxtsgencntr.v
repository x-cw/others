//-----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2010-2013 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//  Version and Release Control Information:
//
//  Checked In          : $Date: 2011-07-12 17:44:35 +0530 (Tue, 12 Jul 2011) $
//
//  File Revision       : $Revision: 18204 $
//
//  Release Information : CoreSight-SoC-TM100-r3p1-00rel0
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// Abstract : CoreSight Time Stamp Generator - Counter Block
//-----------------------------------------------------------------------------
//
// cxtsgencntr - Time Stamp Counter (Up-counter only)
//-----------------------------------------------------------------------------

module cxtsgencntr (

  // Clock and Reset
  input wire         clk,
  input wire         resetn,

  // Enable normal count operation
  input wire         enablecnt,

  // Write new count value
  input wire [63:0]  newcnt,
  input wire         newcntwren,

  // Time Stamp Encoder
  output wire [63:0] tsvalueb,
  output wire        tsforcesync

  );

//----------------------------------------------------------------------------
// Wires
//----------------------------------------------------------------------------
  wire       tsvaluel_en;
  wire       tsvaluel_cy_nxt;
  wire       tsvaluel_cy_en;
  wire [1:0] tsvalueusel;
  wire       tsvalueu_en;
  wire       tsforcesync_en;
  wire       tsforcesync_nxt;

//------------------------------------------------------------------------------
// Reg declarations
//------------------------------------------------------------------------------
  reg [31:0] tsvaluel_nxt;
  reg [31:0] tsvaluel;
  reg        tsvaluel_cy;
  reg [31:0] tsvalueu_nxt;
  reg [31:0] tsvalueu;
  reg        tsforcesync_q;

//============================================================================
//
// Main body of code
//
//============================================================================

//----------------------------------------------------------------------------
// TSVALUEB-lower 32 bits. When enablecnt is asserted then the counter will
// perform a normal up-count. If a new cnt value has to be written then
// enablecnt has to be de-asserted. If both these signals are de-asserted then
// the counter will retain its value.
//----------------------------------------------------------------------------
  always @(*)
    begin
      case ({enablecnt,newcntwren})
        2'b00 : tsvaluel_nxt[31:0] = tsvaluel[31:0];
        2'b01 : tsvaluel_nxt[31:0] = newcnt[31:0];
        2'b10,
        2'b11 : tsvaluel_nxt[31:0] = tsvaluel + {{31{1'b0}},1'b1};
        default : tsvaluel_nxt[31:0] = {32{1'bx}};
      endcase
    end

//----------------------------------------------------------------------------
// enable the counter to be update only when enabled or when a new value is
// being written.
//----------------------------------------------------------------------------
  assign tsvaluel_en = (enablecnt | newcntwren);

  always @(posedge clk or negedge resetn)
    if (!resetn) begin
      tsvaluel <= {32{1'b0}};
    end else if (tsvaluel_en) begin
      tsvaluel <= tsvaluel_nxt;
    end

//----------------------------------------------------------------------------
// Store an event when the lower 32-bits of TSVALUE will generate a carry
// the next time it is incremented.
//----------------------------------------------------------------------------
  assign tsvaluel_cy_nxt = (tsvaluel_nxt[31:0] == {32{1'b1}}) & tsvaluel_en;

  assign tsvaluel_cy_en = tsvaluel_cy ? tsvaluel_en : tsvaluel_cy_nxt;

  always @(posedge clk or negedge resetn)
    if (!resetn) begin
      tsvaluel_cy <= 1'b0;
    end else if (tsvaluel_cy_en) begin
      tsvaluel_cy <= tsvaluel_cy_nxt;
    end

//----------------------------------------------------------------------------
// enable new value to be written only when the counter is disabled, as in,
// enablecnt is deasserted. If counter is enabled then the new count value
// is ignored and if a carry event is asserted then the upper 32-bits of
// TSVALUEB will be incremented.
//----------------------------------------------------------------------------
  assign tsvalueusel = {(enablecnt & tsvaluel_cy),(~enablecnt & newcntwren)};

  always @(*)
    begin
      case (tsvalueusel)
        2'b00 : tsvalueu_nxt[31:0] = tsvalueu[31:0];
        2'b01 : tsvalueu_nxt[31:0] = newcnt[63:32];
        2'b10,
        2'b11 : tsvalueu_nxt[31:0] = tsvalueu + {{31{1'b0}},1'b1};
        default : tsvalueu_nxt[31:0] = {32{1'bx}};
      endcase
    end

  assign tsvalueu_en = |tsvalueusel;

  always @(posedge clk or negedge resetn)
    if (!resetn) begin
      tsvalueu <= {32{1'b0}};
    end else if (tsvalueu_en) begin
      tsvalueu <= tsvalueu_nxt;
    end

  assign tsvalueb = {tsvalueu, tsvaluel};

//----------------------------------------------------------------------------
// TSFORCESYNC is asserted whenever the counter rolls over to zero or on a
// successfull update of the counter value.
//----------------------------------------------------------------------------
  assign tsforcesync_nxt = ((tsvalueu == {32{1'b1}}) &
                             (enablecnt & tsvaluel_cy)) |
                               (~enablecnt & newcntwren);

  assign tsforcesync_en = (tsforcesync_q ^ tsforcesync_nxt);

  always @(posedge clk or negedge resetn)
    if (!resetn) begin
      tsforcesync_q <= 1'b0;
    end else if (tsforcesync_en) begin
      tsforcesync_q <= tsforcesync_nxt;
    end

  assign tsforcesync = tsforcesync_q;

//----------------------------------------------------------------------------
// ASSERTIONS
//----------------------------------------------------------------------------

`ifdef ARM_ASSERT_ON

//-----------------------------------------------------------------------------
// Check if counter value is being modified when it is enabled
//-----------------------------------------------------------------------------
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxtsgencntr - A Write is modifying counter when it is not disabled")
      uzovl_cxtsgencntr_illegal_cntr_update_chk
        (
         .clk         (clk),
         .reset_n     (resetn),
         .test_expr   (enablecnt &&
                       (tsvalueusel == 2'b01))
        );

//-----------------------------------------------------------------------------
// Check if counter value is incremented even when there is no carry over from
// the lower 32-bits.
//-----------------------------------------------------------------------------
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxtsgencntr - Upper 32-bits of counter is incrementing even when there is no carry")
      uzovl_cxtsgencntr_illegal_cntr_incr_chk
        (
         .clk         (clk),
         .reset_n     (resetn),
         .test_expr   (enablecnt &&
                       !tsvaluel_cy &&
                       ((tsvalueusel == 2'b10) ||
                        (tsvalueusel == 2'b11)))
        );

`endif // ARM_ASSERT_ON

endmodule
