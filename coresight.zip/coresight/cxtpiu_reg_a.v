//-----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2004-2015 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//    Checked In : $Date: 2014-08-14 16:01:35 +0100 (Thu, 14 Aug 2014) $
//    Revision   : $Revision: 39945 $
//    Release    : CoreSight-SoC-TM100-r3p2-00rel0
//-----------------------------------------------------------------------------
//  Purpose             : atclk domain register module for the TPIU block.
//                        Holds EXCTL registers, Trigger Control Registers and
//                        Flush Status.
//-----------------------------------------------------------------------------

module cxtpiu_reg_a  (
  // Inputs
  atclk, atclken, atresetn, afvalids, pwritedbg, rd_wr_req, ft_stopped,
  paddrdbg, paddrdbg31, pwdatadbg, device_un_locked, extctlin,
  trig_in_detect, ft_data_valid, f_on_man_active, f_on_man_clr, it_atb_ctr_1_reg,
  it_atb_dat_0_reg, it_ctr_0_byt_reg, it_ctr_0_atv_reg, trigin_sync, flushin_sync,
  afready_reg, tpctl,
  // Outputs
  read_data_a, trg_one, trg_count_off, ffcr_f_on_man_reg, trg_running,
  triggered, extctlout, it_atb_ctr_2_atr_reg, it_tr_fl_in_ack_reg,
  it_atb_ctr_2_afv_reg
  );

`include "cxtpiu_constants.v"

  // Inputs
  input         atclk;            // ATB clock
  input         atclken;          // ATB clock enable
  input         atresetn;         // ATB asychronous reset active low
  input         afvalids;         // ATB flush signal
  input         pwritedbg;        // APB Write/!Read signal
  input         rd_wr_req;        // Read or write request from the APB interface
  input         ft_stopped;       // Formatter stopped signal from the Formatter
  input [11:2]  paddrdbg;         // APB Address bus
  input         paddrdbg31;       // APB address marker to bypass lock access
  input [7:0]   pwdatadbg;        // APB Write data bus
  input         device_un_locked; // Allow Writes on paddrdbg==0
  input [7:0]   extctlin;         // EXTernal ConTroL INput
  input         trig_in_detect;   // Trigger detected on trigin
  input         ft_data_valid;    // Indicates when a word is pushed into the FIFO
  input         f_on_man_active;  // Manual flush in progress
  input         f_on_man_clr;     // Clear FOnMan bit in FFCR
  input [6:0]   it_atb_ctr_1_reg; // Integration ItAtbCtr1 atids register
  input [4:0]   it_atb_dat_0_reg; // Integration ItAtbData0 atdatas register
  input [1:0]   it_ctr_0_byt_reg; // Integration ItAtbCtr0 atbytess register
  input         it_ctr_0_atv_reg; // Integration ItAtbCtr0 atvalids register
  input         trigin_sync;      // Integration trigin
  input         flushin_sync;     // Integration flushin
  input         afready_reg;      // Integration afreadys
  input         tpctl;            // External tie-off indicating the presence of
                                  //  the tracectl pin

  // Outputs
  output [31:0] read_data_a;         // Read data bus to the APB interface
  output        trg_one;             // Single pulse to indicate a TrigEvent
  output        trg_count_off;       // trig_count Reg is set to zero i.e. disabled
  output        ffcr_f_on_man_reg;   // FFCR FOnMan register
  output        trg_running;         // exported to the Trigger Mode in RegP
  output        triggered;           // exported to the Trigger Mode in RegP
  output [7:0]  extctlout;           // EXTernal ConTroL OUTput
  output        it_atb_ctr_2_atr_reg;// Integration ItAtbCtr2 atreadys
  output [1:0]  it_tr_fl_in_ack_reg; // Integration triginack=0 flushinack=1 reg
  output        it_atb_ctr_2_afv_reg;// Integration afvalids

  // ---------------------------------------------------------------------------
  //                            Register Module
  //                            ===============
  // ---------------------------------------------------------------------------
  //
  // Overview
  // ========
  // atclk domain register block for the TPIU module.
  // Contains:
  //  Manual Flush control
  //  EXTernal ConTroL OUTput Registers
  //  EXTernal ConTroL INput Registers
  //  Formatter & Flush Status Register
  //  Trigger count Multiplier
  //  Trigger Counter
  // + Associated Trigger Logic
  // ---------------------------------------------------------------------------

  // ---------------------------------------------------------------------------
  // Wire declarations
  // ---------------------------------------------------------------------------
  wire          trg_one;
  wire          trg_one_int;       // Internal version of trg_one
  wire          trg_count_off;     // trig_count Reg is set to zero i.e. disabled
  wire          trg_count_off_int; // Internal version of trg_count_off

  // ---------------------------------------------------------------------------
  // Internal wire declarations
  // ---------------------------------------------------------------------------

  // Global Read/Write Enables
  wire          reg_write;
  wire          reg_read;
  reg           rd_wr_req_a_reg;

  // Formatter & Flush control
  wire          ffcr_f_on_man_reg;    // FFCR flush control FOnMan register
  reg           ffcr_f_on_man_reg_int;// Internal version of ffcr_f_on_man_reg
  wire          nxt_ffcr_f_on_man_reg;// Next state of FFCR FOnMan register
  wire          ffcr_f_on_man_en;     // Enable FFCR flush register write
  wire          new_ffcr_f_on_man;    // New value of FFCR reg

  // Trigger Counter
  wire          trig_count_wr_en;
  wire          trig_count_rd_en;
  wire [31:0]   trig_count_rd_data;
  reg [7:0]     trig_count_reg;       // This holds the preset value
  reg [7:0]     trig_count;           // This is the actual counter
  wire          trig_count_upd;
  wire [7:0]    next_trig_count;
  wire          trg_running;          // Set when the counter is running
  reg           trg_running_int;      // Internal version of trg_running
  wire          next_trg_running;
  wire          trg_running_en;
  wire          triggered;
  reg           triggered_int;        // Internal version of triggered
  wire          next_triggered;
  wire          triggered_en;

  // Trigger count Multiplier
  wire          trig_mult_wr_en;
  wire          trig_mult_wr;         //as above but without atclken
  wire          trig_mult_rd_en;
  wire [31:0]   trig_mult_rd_data;
  reg [4:0]     trig_mult_reg;
  wire          trig_mult_dec_0;      //original decrement pulse
  wire          trig_mult_dec_1;      //div2     or bypass
  wire          trig_mult_dec_2;      //div4     or bypass
  wire          trig_mult_dec_4;      //div16    or bypass
  wire          trig_mult_dec_8;      //div256   or bypass
  wire          trig_mult_dec_16;     //div65536 or bypass
  wire          trig_mult_dec;        //generic decrement pulse for counter
  reg           div_2_count;          // Divide by 2 counter
  wire          div_2_count_en;
  wire          next_div_2_count;
  wire          trig_div_2;           // Divided by 2 pulse
  reg [1:0]     div_4_count;          // Divide by 4 counter
  wire          div_4_count_en;
  wire [1:0]    next_div_4_count;
  wire          trig_div_4;           // Divided by 4 pulse
  reg [3:0]     div_16_count;         // Divide by 16 counter
  wire          div_16_count_en;
  wire [3:0]    next_div_16_count;
  wire          trig_div_16;          // Divided by 16 pulse
  reg [7:0]     div_256_count;        // Divide by 256 counter
  wire          div_256_count_en;
  wire [7:0]    next_div_256_count;
  wire          trig_div_256;         // Divided by 256 pulse
  reg [15:0]    div_6k_count;         // Divide by 65536 counter
  wire          div_6k_count_en;
  wire [15:0]   next_div_6k_count;
  wire          trig_div_6k;

  // EXTCTL OUT
  wire          ext_ctl_op_wr_en;
  wire          ext_ctl_op_rd_en;
  wire [7:0]    extctlout;
  reg [7:0]     extctlout_int;
  wire [31:0]   ext_ctl_op_rd_data;

  // EXTCTL IN
  wire          ext_ctl_in_rd_en;
  wire [31:0]   ext_ctl_in_rd_data;

  // Formatter & Flush Status
  wire          form_status_rd_en;
  wire [31:0]   form_status_rd_data;

  // Integration registers
  reg [1:0]     it_tr_fl_in_ack_reg;
  wire          it_tr_fl_in_ack_wr_en;
  wire          it_tr_fl_in_rd_en;
  wire [31:0]   it_tr_fl_in_rd_data;
  wire          it_atb_data_0_rd_en;
  wire [31:0]   it_atb_data_0_rd_data;
  reg           it_atb_ctr_2_afv_reg;
  reg           it_atb_ctr_2_atr_reg;
  wire          it_atb_ctr_2_wr_en;
  wire          it_atb_ctr_1_rd_en;
  wire [31:0]   it_atb_ctr_1_rd_data;
  wire          it_atb_ctr_0_rd_en;
  wire [31:0]   it_atb_ctr_0_rd_data;

  // ---------------------------------------------------------------------------
  // Main body of code
  // =================
  // ---------------------------------------------------------------------------

  // ---------------------------------------------------------------------------
  // Assigning the reg_write and reg_read signals.
  // ---------------------------------------------------------------------------

  // Create a Write Strobe and a read enable
  assign reg_write  = ~rd_wr_req & rd_wr_req_a_reg & pwritedbg & (device_un_locked | paddrdbg31);
  assign reg_read   = rd_wr_req & ~pwritedbg;

  // Read/Write request register
  always @(posedge atclk or negedge atresetn)
    begin : p_rega_writestrobe
      if (!atresetn)
        rd_wr_req_a_reg <= 1'b0;
      else
        if (atclken)
          rd_wr_req_a_reg <= rd_wr_req;
    end

  // ---------------------------------------------------------------------------
  // Formatter and Flush control register: Offset 0x304 ( R/W )
  // ---------------------------------------------------------------------------
  // Controls the formatting and flushing within the ATB formatter.
  // FOnMan bit resides in the atclk domain, as it needs to be updated
  // when a flush has been completed.

  // Update on new value being written or clearing the old value
  assign ffcr_f_on_man_en = atclken & ((reg_write & (paddrdbg == CXTPIU_FFCR_ADD))|
                                   (f_on_man_clr)                                );

  // If a flush is in progress ignore writes to this register
  assign new_ffcr_f_on_man = f_on_man_active ? ffcr_f_on_man_reg_int : pwdatadbg[6];
  // Clear on completion
  assign nxt_ffcr_f_on_man_reg = new_ffcr_f_on_man & ~f_on_man_clr;

  // Flush on Manual request register
  always @(posedge atclk or negedge atresetn)
    begin : p_regaseq_fonman
      if (!atresetn)
        ffcr_f_on_man_reg_int <= 1'b0;
      else if (ffcr_f_on_man_en)
        ffcr_f_on_man_reg_int <= nxt_ffcr_f_on_man_reg;
  end // p_regaseq_fonman
  assign ffcr_f_on_man_reg = ffcr_f_on_man_reg_int;

  // ---------------------------------------------------------------------------
  // Trigger Counter Value Register : Offset 0x104 ( RW )
  // ---------------------------------------------------------------------------
  // trig_count_reg is the value that the Trigger counter is reset to on reaching
  // zero.
  always @(posedge atclk or negedge atresetn)
    if (!atresetn)
      trig_count_reg <= 8'h00;
    else
      if (trig_count_wr_en)
        trig_count_reg <= pwdatadbg[7:0];

  assign trig_count_wr_en   = atclken & reg_write &
                                     (paddrdbg == CXTPIU_TRIGCNT_ADD);
  assign trig_count_rd_en   = reg_read & (paddrdbg == CXTPIU_TRIGCNT_ADD);
  assign trig_count_rd_data = {{24{1'b0}}, trig_count_reg};

  // Actual Trigger Counter
  always @(posedge atclk or negedge atresetn)
    if (!atresetn)
      trig_count <= 8'h00;
    else
      if (trig_count_upd)
        trig_count <= next_trig_count;

  // Trigger Counter changes on:
  //  multipler divided pulse (decrement)
  //  new value written to trig_count Reg (reset to new value)
  //  new value written to TrigMult Reg (reset to stored value)
  //  on reaching zero (reset to stored value if not zero)
  assign trig_count_upd = (atclken &
                         ( trig_mult_dec | trig_count_wr_en | trig_mult_wr ));
  assign next_trig_count =
                trig_count_wr_en                         ? pwdatadbg[7:0] :
                ({8{ ((trig_count == 8'h00) | trig_mult_wr)}} & trig_count_reg  |
                 {8{~((trig_count == 8'h00) | trig_mult_wr)}} & (trig_count - 8'h01));

  // Indicate the Trigger Event
  //  When at one (transition to zero next cycle)
  //  & Transitioning to zero
  //NB this needs to be at zero but ETB uses when one.
  assign trg_count_off_int = (trig_count_reg == 8'h00);
  assign trg_count_off = trg_count_off_int;
  assign trg_one_int = (trig_count == 8'h00) & trig_mult_dec & ~trg_count_off_int;
  assign trg_one = trg_one_int;

  // Trigger Counter Run/Stop control
  //  Allows for the one-shot run of the Trigger Counter system
  always @(posedge atclk or negedge atresetn)
    if (!atresetn)
      trg_running_int <= 1'b0;
    else
      if (trg_running_en)
        trg_running_int <= next_trg_running;
  assign trg_running = trg_running_int;

  // Stop when the trigger counter hits zero,
  // Start when a trigger is seen and the reset counter is not zero
  assign next_trg_running = ((trg_running_int & ~trg_one_int)                   |
                           (trig_in_detect & (trig_count_reg != 8'h00) ));
  assign trg_running_en = atclken & (trg_one_int | trig_in_detect);

  // triggered Flag
  always @(posedge atclk or negedge atresetn)
    if (!atresetn)
      triggered_int <= 1'b0;
    else
      if (triggered_en)
        triggered_int <= next_triggered;
  assign triggered = triggered_int;

  // Set on : trigin when the counter is zero
  //   -or- : Counter reaching zero when preset to non-zero
  // Clear  : Writing to the Counter register
  assign next_triggered = ( (trig_in_detect & (trig_count_reg == 8'h00)) |
                           (trg_one_int       & (trig_count_reg != 8'h00)) ) &
                           ~trig_count_wr_en & atclken;
  // update on External Triggers or Counter hitting zero when not set
  // or (reset) on Writing to the Trigger count Reg
  assign triggered_en = (((trig_in_detect | trg_one_int) & ~triggered_int) |
                        (trig_count_wr_en                       ) );

  // ---------------------------------------------------------------------------
  // Trigger Counter Multiplier Register : Offset 0x108 ( RW )
  // ---------------------------------------------------------------------------
  always @(posedge atclk or negedge atresetn)
    if (!atresetn)
      trig_mult_reg <= 5'b00000;
    else
      if (trig_mult_wr_en)
        trig_mult_reg <= pwdatadbg[4:0];

  // seperate out WrEn as other registers watch for the access
  assign trig_mult_wr     = reg_write & (paddrdbg == CXTPIU_TRIGMUL_ADD);

  assign trig_mult_wr_en   = atclken & trig_mult_wr;
  assign trig_mult_rd_en   = reg_read & (paddrdbg == CXTPIU_TRIGMUL_ADD);
  assign trig_mult_rd_data = {{27{1'b0}}, trig_mult_reg};

  // Divide the count pulse down according to the enabled bits
  //  This is a series of Muxes that switch in the different divide stages to
  //  achieve a divide count of 1 to 2x10^9
  // count down on each word written to the FIFO when the counter is running
  // (added in a start decrement else the counter needs to count one extra pulse
  //  to roll the counter over)
  assign trig_mult_dec_0  = ((ft_data_valid & trg_running_int)  |
                          (trig_in_detect & ~trg_running_int & ~trg_count_off_int));
  assign trig_mult_dec_1  = trig_mult_reg[0] ? trig_div_2   : trig_mult_dec_0; //div2
  assign trig_mult_dec_2  = trig_mult_reg[1] ? trig_div_4   : trig_mult_dec_1; //div4
  assign trig_mult_dec_4  = trig_mult_reg[2] ? trig_div_16  : trig_mult_dec_2; //div16
  assign trig_mult_dec_8  = trig_mult_reg[3] ? trig_div_256 : trig_mult_dec_4; //div256
  assign trig_mult_dec_16 = trig_mult_reg[4] ? trig_div_6k  : trig_mult_dec_8; //div65536
  // connect to the trigmultdec to allow for any additional stages
  assign trig_mult_dec   = trig_mult_dec_16;

  // Each divide counter operates in the same way
  // The enable is active when the divider is enabled and the previous stage
  //  muxed value pulses.
  // The counter ideally should just be a cascaded div2 generated by DFFs to
  //  the appropriate length.
  // On each stage the pulse is optained when the count is zero and is about
  //  to roll over.
  // trig_mult_wr(En) has been included to ensure that the counters are reset
  //  each time the control register is reset.

  //Divide by 2
  always @(posedge atclk or negedge atresetn)
    if (!atresetn)
      div_2_count <= 1'b0;
    else
      if (div_2_count_en)
        div_2_count <= next_div_2_count;

  assign div_2_count_en   = atclken & ((trig_mult_dec_0 & trig_mult_reg[0]) |
                                    (trig_mult_wr)                    );
  assign next_div_2_count = ~div_2_count & ~trig_mult_wr;
  assign trig_div_2      = ~div_2_count & trig_mult_dec_0;

  //Divide by 4
  always @(posedge atclk or negedge atresetn)
    if (!atresetn)
      div_4_count <= 2'b00;
    else
      if (div_4_count_en)
        div_4_count <= next_div_4_count;

  assign div_4_count_en   = atclken & ((trig_mult_dec_1 & trig_mult_reg[1]) |
                                    (trig_mult_wr)                    );
  assign next_div_4_count = (div_4_count - 2'b01) & {2{~trig_mult_wr}};
  assign trig_div_4      = (div_4_count == 2'b00) & trig_mult_dec_1;

  //Divide by 16
  always @(posedge atclk or negedge atresetn)
    if (!atresetn)
      div_16_count <= 4'h0;
    else
      if (div_16_count_en)
        div_16_count <= next_div_16_count;

  assign div_16_count_en   = atclken & ((trig_mult_dec_2 & trig_mult_reg[2]) |
                                     (trig_mult_wr)                    );
  assign next_div_16_count = (div_16_count - 4'h1) & {4{~trig_mult_wr}};
  assign trig_div_16      = (div_16_count == 4'h0) & trig_mult_dec_2;

  //Divide by 256
  always @(posedge atclk or negedge atresetn)
    if (!atresetn)
      div_256_count <= 8'h00;
    else
      if (div_256_count_en)
        div_256_count <= next_div_256_count;

  assign div_256_count_en   = atclken & ((trig_mult_dec_4 & trig_mult_reg[3]) |
                                      (trig_mult_wr)                    );
  assign next_div_256_count = (div_256_count - 8'h01) & {8{~trig_mult_wr}};
  assign trig_div_256      = (div_256_count == 8'h00) & trig_mult_dec_4;

  //Divide by 65536
  always @(posedge atclk or negedge atresetn)
    if (!atresetn)
      div_6k_count <= 16'h0000;
    else
      if (div_6k_count_en)
        div_6k_count <= next_div_6k_count;

  assign div_6k_count_en   = atclken & ((trig_mult_dec_8 & trig_mult_reg[4]) |
                                     (trig_mult_wr)                    );
  assign next_div_6k_count = (div_6k_count - 16'h0001) & {16{~trig_mult_wr}};
  assign trig_div_6k      = (div_6k_count == 16'h0000) & trig_mult_dec_8;

  // ---------------------------------------------------------------------------
  // External control input register   : Offset 0x400 ( R )
  // ---------------------------------------------------------------------------

  assign ext_ctl_in_rd_en   = reg_read & (paddrdbg == CXTPIU_EXTCTLIN_ADD);
  assign ext_ctl_in_rd_data = {{24{1'b0}}, extctlin};

  // ---------------------------------------------------------------------------
  // External control output register   : Offset 0x404 ( R/W )
  // ---------------------------------------------------------------------------
  always @(posedge atclk or negedge atresetn)
    begin : s_extctlop
      if (!atresetn)
         extctlout_int <= {8{1'b0}};
      else
        if(ext_ctl_op_wr_en)
          extctlout_int <= pwdatadbg[7:0];
    end // block: s_extctlop
  assign extctlout = extctlout_int;

  assign ext_ctl_op_wr_en   = atclken & reg_write &
                                     (paddrdbg == CXTPIU_EXTCTLOUT_ADD);
  assign ext_ctl_op_rd_en   = reg_read  & (paddrdbg == CXTPIU_EXTCTLOUT_ADD);
  assign ext_ctl_op_rd_data = {{24{1'b0}}, extctlout_int};

  // ---------------------------------------------------------------------------
  // Formatter and flush status register   : Offset 0x300 ( R/W )
  // ---------------------------------------------------------------------------
  assign form_status_rd_en   = reg_read & (paddrdbg == CXTPIU_FORMSTAT_ADD);
  assign form_status_rd_data = {{29{1'b0}},(CXTPIU_TRACECTL_VAL & tpctl),
                             ft_stopped,afvalids};

  // ---------------------------------------------------------------------------
  // Integration Registers
  //

  // ---------------------------------------------------------------------------
  // Integration flushinack/triginack register : Offset 0xEE4 ( W )
  // ---------------------------------------------------------------------------
  always @(posedge atclk or negedge atresetn)
    if (!atresetn)
      it_tr_fl_in_ack_reg <= 2'b00;
    else
      if (it_tr_fl_in_ack_wr_en)
        it_tr_fl_in_ack_reg <= pwdatadbg[1:0];

  assign it_tr_fl_in_ack_wr_en = atclken & reg_write &
                                        (paddrdbg == CXTPIU_ITTRFLINACK_ADD);

  // ---------------------------------------------------------------------------
  // Integration flushin/trigin register : Offset 0xEE8 ( R )
  // ---------------------------------------------------------------------------
  assign it_tr_fl_in_rd_en   = reg_read & (paddrdbg == CXTPIU_ITTRFLIN_ADD);
  assign it_tr_fl_in_rd_data = { {30{1'b0}}, flushin_sync, trigin_sync};

  // ---------------------------------------------------------------------------
  // Integration atdatas register : Offset 0xEEC ( R )
  // ---------------------------------------------------------------------------
  assign it_atb_data_0_rd_en   = reg_read & (paddrdbg == CXTPIU_ITATBDATA0_ADD);
  assign it_atb_data_0_rd_data = { {27{1'b0}}, it_atb_dat_0_reg };

  // ---------------------------------------------------------------------------
  // Integration afvalids/atreadys register : Offset 0xEF0 ( W )
  // ---------------------------------------------------------------------------
  always @(posedge atclk or negedge atresetn)
    if (!atresetn)
      begin
        it_atb_ctr_2_afv_reg <= 1'b0;
        it_atb_ctr_2_atr_reg <= 1'b0;
      end
    else
      if (it_atb_ctr_2_wr_en)
        begin
          it_atb_ctr_2_afv_reg <= pwdatadbg[1];
          it_atb_ctr_2_atr_reg <= pwdatadbg[0];
        end

  assign it_atb_ctr_2_wr_en   = atclken & reg_write &
                                      (paddrdbg == CXTPIU_ITATBCTR2_ADD);

  // ---------------------------------------------------------------------------
  //  Integration atids register : Offset 0xEF4 ( R )
  // ---------------------------------------------------------------------------
  assign it_atb_ctr_1_rd_en   = reg_read & (paddrdbg == CXTPIU_ITATBCTR1_ADD);
  assign it_atb_ctr_1_rd_data = { {25{1'b0}}, it_atb_ctr_1_reg };

  // ---------------------------------------------------------------------------
  //  Integration ATBYTES/atvalids/afreadys register : Offset 0xEF8 ( R )
  // ---------------------------------------------------------------------------
  assign it_atb_ctr_0_rd_en   = reg_read & (paddrdbg == CXTPIU_ITATBCTR0_ADD);
  assign it_atb_ctr_0_rd_data = { {22{1'b0}}, it_ctr_0_byt_reg, {6{1'b0}},
                             afready_reg, it_ctr_0_atv_reg };

  // ---------------------------------------------------------------------------
  // The read data is driven out from the register module.
  // ---------------------------------------------------------------------------
  assign read_data_a = (
                      ({32{trig_mult_rd_en}}    & trig_mult_rd_data)  |
                      ({32{trig_count_rd_en}}   & trig_count_rd_data) |
                      ({32{ext_ctl_op_rd_en}}    & ext_ctl_op_rd_data)  |
                      ({32{ext_ctl_in_rd_en}}    & ext_ctl_in_rd_data)  |
                      ({32{form_status_rd_en}}  & form_status_rd_data)|
                      ({32{it_tr_fl_in_rd_en}}    & it_tr_fl_in_rd_data)  |
                      ({32{it_atb_data_0_rd_en}}  & it_atb_data_0_rd_data)|
                      ({32{it_atb_ctr_1_rd_en}}   & it_atb_ctr_1_rd_data) |
                      ({32{it_atb_ctr_0_rd_en}}   & it_atb_ctr_0_rd_data)
                     );

endmodule // cxtpiu_reg_a
