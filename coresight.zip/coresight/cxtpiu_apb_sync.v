//-----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2004-2015 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//    Checked In : $Date: 2014-06-25 08:42:22 +0100 (Wed, 25 Jun 2014) $
//    Revision   : $Revision: 39629 $
//    Release    : CoreSight-SoC-TM100-r3p2-00rel0
//-----------------------------------------------------------------------------
//  Purpose             : Double Synchronizer for FIFO module in TPIU block.
//-----------------------------------------------------------------------------

module cxtpiu_apb_sync  (
  // Inputs
  pclkdbg, pclkendbg, presetdbgn, rd_wr_ack_t,
  // Outputs
  rd_wr_ack_t_sync
  );

  // Inputs
  input         pclkdbg;         // APB clock
  input         pclkendbg;       // APB Clock enable
  input         presetdbgn;      // APB asychronous reset active low
  input         rd_wr_ack_t;     // Read write ack from the traceclkin domain

  // Outputs
  output        rd_wr_ack_t_sync;// Read write ack to the pclkdbg domain

  // ---------------------------------------------------------------------------
  //                     Synchronizers For pclkdbg Domain
  //                     ================================
  // ---------------------------------------------------------------------------
  // Overview
  // ========
  // Synchronizers for the signals of the TPIU block in the pclkdbg domain.
  // Converts rd_wr_ack_t from the traceclkin region (from RegT) to pclkdbg.
  //
  // ---------------------------------------------------------------------------

  // ---------------------------------------------------------------------------
  // Main body of code
  // =================
  // ---------------------------------------------------------------------------

  // ---------------------------------------------------------------------------
  // Instantiating the doubleSync module for synchronizing rd_wr_ack_t bit.
  // ---------------------------------------------------------------------------
  cx_en_sync u_rd_wr_ack_t  (
                         // Outputs
                         .sync_do          (rd_wr_ack_t_sync),
                         // Inputs
                         .clk              (pclkdbg),
                         .clken            (pclkendbg),
                         .resetn           (presetdbgn),
                         .sync_di          (rd_wr_ack_t));

endmodule
