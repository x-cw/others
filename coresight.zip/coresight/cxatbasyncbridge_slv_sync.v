//-----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2010-2015 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//
//      Checked In          : $Date: 2014-08-14 16:01:35 +0100 (Thu, 14 Aug 2014) $
//
//      Revision            : $Revision: 39945 $
//
//      Release Information : CoreSight-SoC-TM100-r3p2-00rel0
//-----------------------------------------------------------------------------
//  Purpose             : Double Synchronizer for signals from ATCLKM to atclks
//-----------------------------------------------------------------------------

module cxatbasyncbridge_slv_sync (
  // Inputs
  atclks,
  atclkens,
  atresetsn,
  rdptr_grey,
  flush_req,
  // Outputs
  rdptr_grey_sync,
  flush_req_sync
  );

  // Inputs
  input wire         atclks;           // ATB Slave clock
  input wire         atclkens;         // ATB Slave enable
  input wire         atresetsn;        // ATB asychronous reset active low
  input wire [3:0]   rdptr_grey;       // Read pointer from the master clock domain
  input wire         flush_req;        // flush_req from the master clock domain
  // Outputs
  output wire [3:0]  rdptr_grey_sync;   // Read pointer to the slave clock domain
  output wire        flush_req_sync;    // Synchronized flush_req in slave clock domain

  // ---------------------------------------------------------------------------
  //                      Synchronizers For ATB Slave CLK Domain
  //                      ======================================
  // ---------------------------------------------------------------------------
  // Overview
  // ========
  // Synchronizers for the signals of the CSBRIDGE block in the ATB Slave CLK
  // domain.
  // Converts: rdptr_grey (AtbmFIFO) from ATCLKM
  //           flush_req (AtbmFIFO) from ATCLKM
  // ---------------------------------------------------------------------------

  wire [3:0]   rdptr_grey_corrupt;       // Read pointer from the master clock domain
  wire         flush_req_corrupt;        // flush_req from the master clock domain

  // ---------------------------------------------------------------------------
  // Corrupt rdptr
  // ---------------------------------------------------------------------------
  cxatbasyncbridge_cdc_corrupt_gry #(4) u_cdc_corrupt_rdptr
  (
      .clk       (atclks),
      .resetn    (atresetsn),
      .clken     (atclkens),
      .sync      (1'b0),
      .d_async   (rdptr_grey),
      .q_async   (rdptr_grey_corrupt)
  );

  // ---------------------------------------------------------------------------
  // Instantiating the doubleSync module for synchronizing rdptr_grey[0] bit.
  // ---------------------------------------------------------------------------
  cx_en_sync u_rdptr_grey0
    (
    // Outputs
    .sync_do          (rdptr_grey_sync[0]),
    // Inputs
    .clk              (atclks),
    .clken            (atclkens),
    .resetn           (atresetsn),
    .sync_di          (rdptr_grey_corrupt[0]));

  // ---------------------------------------------------------------------------
  // Instantiating the doubleSync module for synchronizing rdptr_grey[1] bit.
  // ---------------------------------------------------------------------------
  cx_en_sync u_rdptr_grey1
    (
    // Outputs
    .sync_do          (rdptr_grey_sync[1]),
    // Inputs
    .clk              (atclks),
    .clken            (atclkens),
    .resetn           (atresetsn),
    .sync_di          (rdptr_grey_corrupt[1]));

  // ---------------------------------------------------------------------------
  // Instantiating the doubleSync module for synchronizing rdptr_grey[2] bit.
  // ---------------------------------------------------------------------------
  cx_en_sync u_rdptr_grey2
    (
    // Outputs
    .sync_do          (rdptr_grey_sync[2]),
    // Inputs
    .clk              (atclks),
    .clken            (atclkens),
    .resetn           (atresetsn),
    .sync_di          (rdptr_grey_corrupt[2]));

  // ---------------------------------------------------------------------------
  // Instantiating the doubleSync module for synchronizing rdptr_grey[3] bit.
  // ---------------------------------------------------------------------------
  cx_en_sync u_rdptr_grey3
    (
    // Outputs
    .sync_do           (rdptr_grey_sync[3]),
    // Inputs
    .clk              (atclks),
    .clken            (atclkens),
    .resetn           (atresetsn),
    .sync_di          (rdptr_grey_corrupt[3]));

  // ---------------------------------------------------------------------------
  // Instantiating the doubleSync module for synchronizing flush_req.
  // ---------------------------------------------------------------------------
  cxatbasyncbridge_cdc_corrupt_gry #(1) u_cdc_corrupt_flush_req
  (
      .clk       (atclks),
      .resetn    (atresetsn),
      .clken     (atclkens),
      .sync      (1'b0),
      .d_async   (flush_req),
      .q_async   (flush_req_corrupt)
  );

  cx_en_sync u_flush_req
    (
    // Outputs
    .sync_do          (flush_req_sync),
    // Inputs
    .clk              (atclks),
    .clken            (atclkens),
    .resetn           (atresetsn),
    .sync_di          (flush_req_corrupt));

endmodule // cxatbasyncbridge_slv_sync
