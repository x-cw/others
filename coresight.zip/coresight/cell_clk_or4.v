`timescale 1 ns / 1 ps
module cell_clk_or4 (
    input  clk0   ,
    input  clk1   , 
    input  clk2   , 
    input  clk3   , 
    output clko   
);

`ifdef SIM
assign clko = clk0 | clk1 | clk2 | clk3;
`else
//From SMIC14 SCC14NSFP_90SDB_9TC16_RVT_v1p0a/Verilog/scc14nsfp_90sdb_9tc16_rvt.v
//CLKOR2V4_90S9T16R clk_or_u(.Z(clko), .A1(clk0), .A2(clk1));

//From /Foundry/ARM/tsmc12FFC/Standard_Cell/TSMCHOME/digital/Front_End/verilog/tcbn12ffcllbwp6t16p96cpd_120a/tcbn12ffcllbwp6t16p96cpd.v
//CKOR2D4BWP6T16P96CPD dont_touch_clk_or_u (.A1(clk0), .A2(clk1), .Z(clko));


//From /Foundry/ARM/samsung_14lpp/Standard_Cell/arm/samsung/14lpp/sc9mcpp84_base_rvt_c16/r1p1/verilog/sc9mcpp84_14lpp_base_rvt_c16.v
//OR4_X2N_A9PP84TR_C16 dont_touch_clk_or_u (.A(clk0), .B(clk1), .C(clk2), .D(clk3), .Y(clko));

///Foundry/ARM/samsung_8lpp/Standard_Cell/SynopsysIP/samsung08nlvh/22hs/hsl/rvt/3.00a/verilog/3.0/sa08nlhslogl22hsl068f.v
///Foundry/ARM/samsung_8lpp/Standard_Cell/SynopsysIP/samsung08nlvh/22hs/hsl/rvt/3.00a/verilog/std_primitives.v
//`ifdef USE_HSB_LIB
//HSBSVT22_OR4_4   dont_touch_clk_or_u (.A1(clk0), .A2(clk1), .A3(clk2), .A4(clk3), .X(clko));
//`else
//HDBSVT22_OR4_4   dont_touch_clk_or_u (.A1(clk0), .A2(clk1), .A3(clk2), .A4(clk3), .X(clko));
//`endif



///Foundry/ARM/samsung_5lpeAT/Standard_Cell/samsung/ln05lpe_sc_m7p5t_flk_lvt_c60_a00_V3.01_pkg/FE-Common_sec240318_0094/MODEL/ln05lpe_sc_m7p5t_flk_lvt_c60l08/ln05lpe_sc_m7p5t_flk_lvt_c60l08.v
//OR4_D2_N_M7P5TL_C60L08   dont_touch_clk_or_u (.A(clk0), .B(clk1), .C(clk2), .D(clk3), .Y(clko));

///Foundry/ARM/samsung_4lpp/Standard_Cell/samsung/ln04lpp_sc_s7p94t_flk_lvt_c60_V1.11_pkg/FE-Common/FE-Common_sec250710_0002/MODEL/flk/ln04lpp_sc_s7p94t_flk_lvt_c60l06.v

OR4_D2_N_S7P94TL_C60L06 dont_touch_clk_or_u (.A(clk0), .B(clk1), .C(clk2), .D(clk3), .Y(clko));


`endif
endmodule
