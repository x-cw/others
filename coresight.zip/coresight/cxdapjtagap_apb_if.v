//-----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2003-2013 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//  Checked In          : $Date: 2013-09-06 16:05:05 +0100 (Fri, 06 Sep 2013) $
//  Revision            : $Revision: 37058 $
//  Release             : CoreSight-SoC-TM100-r3p1-00rel0
//-----------------------------------------------------------------------------

//
//  ----------------------------------------------------------------------------
//  Purpose             : JTAG-AP APB interface (including read and Write FIFOs)
//  ----------------------------------------------------------------------------

`include "cxdapjtagap_constants.v"

module cxdapjtagap_apb_if (
  // Inputs
  dapclk, dapclken, dapresetn, dapsel, dapenable, dapwrite, dapabort,
  dapaddr, dapwdata, port_status, port_sel_con, s_rst_con, ser_actv,
  jtag_cmd_ack, r_fifo_req, tdo_byte,
  // Outputs
  dapready, daprdata, jtag_cmd, jtag_cmd_req, r_fifo_ack, port_sel,
  s_rst_out, trst_out, psta_reg, dapabort_q
  );

//------------------------------------------------------------------------------
// Port Definitions
//------------------------------------------------------------------------------
  // Clock / Reset Pins
  input         dapclk;         // DAP internal APB clock
  input         dapclken;       // Enable term for dapclk domain
  input         dapresetn;      // DAP reset

  input         dapsel;         // DAP slave select signal
  input         dapenable;      // Data valid strobe
  input         dapwrite;       // DAP Write signal
  input         dapabort;       // DAP access abort signal
  input   [7:2] dapaddr;        // Address (used bits only)
  input  [31:0] dapwdata;       // DAP Write data

  input   [7:0] port_status;    // Port active flags
  input         port_sel_con;   // Port connected status of selected port
  input         s_rst_con;      // SRST connected status of selected port
  input         ser_actv;       // JTAG engine serialiser active
  input         jtag_cmd_ack;   // Acknowledge from JTAG engine
  input         r_fifo_req;     // read FIFO transfer request
  input   [7:0] tdo_byte;       // Packed TDO values exported from
                                // JTAG serialiser

  output        dapready;       // DAP ready signal
  output [31:0] daprdata;       // read data

  output  [7:0] jtag_cmd;       // JTAG command byte to JTAG Serialiser engine
  output        jtag_cmd_req;   // Request to send JTAG command byte to
                                // JTAG Engine
  output        r_fifo_ack;     // read FIFO has accepted byte
  output  [7:0] port_sel;       // Ports selected
  output        s_rst_out;      // Subsystem reset to port multiplexer
  output        trst_out;       // Test reset to port multiplexer
  output  [7:0] psta_reg;       // Port Status Register (sticky)
  output        dapabort_q;     // dapabort qualified by dapready


//------------------------------------------------------------------------------
// Constant declarations
//------------------------------------------------------------------------------

// JTAG-AP Register Address Map:
//
// Address  Register  Type       Width  Reset value Description
// 0x00     CSW       R/W        32     0x00000000  Control/Status Word (CSW)
// 0x04     PSEL      R/W         8     0x00        Multiplexor Port Select
// 0x08     PSTA      R/W         8     0x00        Port Status Register
// 0x0C     -         -          -      -           Reserved
// 0x10     BFifo1    R/W         8     Undefined   Byte FIFO 1 Entry
// 0x14     BFifo2    R/W        16     Undefined   Byte FIFO 2 Entry
// 0x18     BFifo3    R/W        24     Undefined   Byte FIFO 3 Entry
// 0x1C     BFifo4    R/W        32     Undefined   Byte FIFO 4 Entry
// 0x20-F8  -         -          -      -           Reserved
// 0xFC     IdrReg    R          32     0x14760010  Identification Register


// -----------------------------------------------------------------------------
// Signal declarations
// -----------------------------------------------------------------------------

  // I/O Pins of type wire
  wire          dapclk;           // APB system clock
  wire          dapclken;         // Enable for dapclk domain
  wire          dapresetn;        // APB system reset

  wire          dapsel;           // Module select signal
  wire          dapenable;        // Data valid strobe
  wire          dapwrite;         // Write/nRead signal
  wire    [7:2] dapaddr;          // Address (used bits only)
  wire   [31:0] dapwdata;         // Write data

  wire          dapready;         // read data ready signal
  reg           dapready_int;     // read data ready signal
  reg    [31:0] daprdata;         // read data

  // Internal Signals
  wire          valid;            // Detect valid transfers
  wire          idr_sel;          // ID register select
  wire          csw_wr_en;        // Control/Status Word update enable
  wire          psel_wr_en;       // Port select register write enable
  wire          psel_sel;         // Port select register read select
  wire          psta_wr_en;       // Port status register write enable
  wire          reg_access;       // Internal register access

  wire          start_state;      // Start the next transfer
  reg     [1:0] state;            // state Machine - current state
  reg     [1:0] next_state;       // state Machine - next state
  wire    [1:0] next_state_abt;   // Next state qualified with dapabort

  reg     [1:0] csw_reg;          // Control/Status Word (CSW) register
  wire    [1:0] nxt_csw_reg;      // Next value of CSW register
  wire          csw_sel;          // Control/Status Word (CSW) read select
  reg     [7:0] psel_reg;         // Port Select Register
  wire    [7:0] nxt_psel_reg;     // Next value of Port Select Register
  wire    [7:0] psta_reg;         // Port Status Register
  reg     [7:0] psta_reg_int;     // Port Status Register
  wire          psta_sel;         // Port Status Register select
  wire    [7:0] clr_psta_reg;     // Evaluate cleared sticky value of PSTA
  wire    [7:0] next_psta_reg;    // Set sticky value of PSTA
  reg    [31:0] bfifo_reg;        // BFIFO Register
  reg    [31:0] next_b_fifo_reg;  // Assembly of TDO bytes from read FIFO
  wire   [31:0] new_b_fifo_reg;   // New value to write to BFIFO register
  wire          bfifo_sel;        // BFIFOReg select for daprdata mux
  wire   [31:0] csw_read_data;    // Register read value
                                  // (not all CSW register bits can be written)

  wire          dapready_next;    // Logic for dapready

  reg     [2:0] byte_count_next;  // Next value of BFIFO byte counter
  reg     [2:0] w_byte_count;     // Count of bytes to write derived
                                  // from dapaddr
  wire    [2:0] dec_w_byte_count; // Decremented value of write bytes counter
  wire    [2:0] next_w_byte_count;// Next value of BFIFO write bytes counter

  reg     [2:0] r_byte_count;     // Count of bytes to read derived
                                  // from dapaddr
  wire    [2:0] dec_r_byte_count; // Decremented value of BFIFO
                                  // read bytes counter
  wire    [2:0] next_r_byte_count;// Next value of BFIFO read bytes counter

  reg [`RFIFOWIDTH-1:0]  r_fifo[`RFIFODEPTH-1:0];  // read FIFO
  reg [`WFIFOWIDTH-1:0]  w_fifo[`WFIFODEPTH-1:0];  // Write FIFO

  wire [`RFIFOWIDTH-1:0] r_fifo_entry; // read FIFO entry pointed to by
                                     // read FIFO read pointer

  reg     [2:0] r_fifo_rd_ptr;    // read FIFO read pointer
  reg     [2:0] r_fifo_wr_ptr;    // read FIFO write pointer
  wire    [2:0] nxt_r_fifo_rd_ptr;// Incremented read FIFO read pointer
  wire    [2:0] nxt_r_fifo_wr_ptr;// Incremented read FIFO write pointer
  reg     [1:0] w_fifo_rd_ptr;    // Write FIFO read pointer
  reg     [1:0] w_fifo_wr_ptr;    // Write FIFO write pointer
  wire    [1:0] nxt_w_fifo_rd_ptr;// Incremented Write FIFO read pointer
  wire    [1:0] nxt_w_fifo_wr_ptr;// Incremented Write FIFO write pointer
  reg     [2:0] w_fifo_cnt;       // Outstanding Write FIFO Count
  reg     [2:0] r_fifo_cnt;       // Outstanding read FIFO Count
  wire    [2:0] inc_w_fifo_cnt;   // Incremented value of Write FIFO counter
  wire    [2:0] dec_w_fifo_cnt;   // Decremented value of Write FIFO counter
  wire    [2:0] next_w_fifo_cnt;  // Next value of Write FIFO counter
  wire    [2:0] inc_r_fifo_cnt;   // Incremented value of read FIFO counter
  wire    [2:0] dec_r_fifo_cnt;   // Decremented value of read FIFO counter
  wire    [2:0] next_r_fifo_cnt;  // Next value of read FIFO counter
  wire          r_fifo_rd_en;     // read FIFO read enable
  wire          w_fifo_rd_en;     // Write FIFO read enable
  wire          r_fifo_wr_en;     // read FIFO write enable
  wire          w_fifo_wr_en;     // Write FIFO write enable
  wire          r_fifo_cnt_en;    // Enable increment/decrement of
                                  // read FIFO entry counter
  wire          w_fifo_cnt_en;    // Enable increment/decrement of
                                  // Write FIFO entry counter
  wire          w_fifo_full;      // Write FIFO full flag
  wire          w_fifo_empty;     // Write FIFO empty flag
  wire          r_fifo_full;      // read FIFO full flag
  wire          r_fifo_empty;     // read FIFO empty flag
  reg     [7:0] bfifo_reg_byte;   // Next byte to extract from BFIFO register
  wire          jtag_cmd_req;     // JTAG command request to JTAG engine
  reg           jtag_cmd_req_int; // JTAG command request to JTAG engine
  wire          next_jtag_cmd_req;// Next value of JTAG command request
  wire          jtag_cmd_req_en;  // Enable for JTAG command request register
  reg     [7:0] jtag_cmd;         // JTAG command to pass to JTAG serialiser
  wire    [7:0] next_jtag_cmd;    // Next value of JTAG command
  wire          jtag_cmd_en;      // Enable for JTAG command register
  wire          r_fifo_ack;       // read FIFO acknowledge
  reg           r_fifo_ack_int;   // read FIFO acknowledge
  wire          next_r_fifo_ack;  // Next read FIFO acknowledge
  wire          bfifo_access;     // BFIFO register select
  wire          bfifo_wr_en;      // BFIFO register write enable
  wire          bfifo_rd_en;      // BFIFO register read enable
  wire          bfifo_reg_en;     // BFIFO register enable
  wire          load_r_byte_cnt;  // Load initial value of BFIFO
                                  // read byte counter
  wire          r_byte_cnt_en;    // Enable for BFIFO read byte counter
  wire          w_byte_cnt_en;    // Enable for BFIFO write byte counter
  wire          trst_out;         // Test reset output to port multiplexer
  wire          trst_out_int;     // Test reset output to port multiplexer
  wire          s_rst_out;        // Subsystem reset output to port multiplexer
  wire          s_rst_out_int;    // Subsystem reset output to port multiplexer
  wire    [7:0] port_sel;         // Port select to output to port multiplexer
  wire          dapabort_q;       // Qualified dapabort
  wire          dapabort_q_int;   // Qualified dapabort
  wire          rd_data_reg_en;   // daprdata output register enable
  wire [31:0]   next_dap_rd_data; // Next value of daprdata output register
  wire [1:0]    inc_w_fifo_wr_ptr; // Incremented write pointer value for WFIFO
  wire [1:0]    inc_w_fifo_rd_ptr; // Next value of daprdata output register

  localparam [2:0] num_entries_wfifo = `WFIFODEPTH_MAXVAL - 3'b001;  // Number of entries in the WFIFO

//------------------------------------------------------------------------------
// Function to increment read and write pointers for read FIFO
//------------------------------------------------------------------------------

   function  [2:0]  inc_r_fifo_ptr;
      input  [2:0]  r_f_pointer;
        inc_r_fifo_ptr = (r_f_pointer == `RFIFODEPTH_MAXVAL - 3'b001) ? 3'b000 :
                         r_f_pointer + 3'b001;
   endfunction //  inc_r_fifo_ptr

//------------------------------------------------------------------------------
// Beginning of main code
//------------------------------------------------------------------------------

// Only respond to valid APB transfers
  assign valid = dapsel & ~dapenable;

// Qualify abort with dapready to prevent abort being accepted on cycle
// in which dapready is returned high

  assign dapabort_q_int = dapabort & ~dapready_int;
  assign dapabort_q    = dapabort_q_int;

//------------------------------------------------------------------------------
// Internal register address decoding
//------------------------------------------------------------------------------
// Write enables are asserted when register is addressed and dapwrite is
// asserted. read enables are asserted when the register is addressed and
// dapwrite is deasserted.
//  By default, the register enables are all deselected.

// Define two address regions for DAP bus registers and BFIFO accesses
  assign reg_access    = ((dapaddr[7:2] == `CSWADDR) |
                         (dapaddr[7:2] == `PSELADDR) |
                         (dapaddr[7:2] == `PSTAADDR) |
                         (dapaddr[7:2] == `IDRADDR) );

  assign bfifo_access  = ((dapaddr[7:2] == `BF1ADDR) |
                         (dapaddr[7:2] == `BF2ADDR) |
                         (dapaddr[7:2] == `BF3ADDR) |
                         (dapaddr[7:2] == `BF4ADDR));


  assign csw_wr_en = (((dapaddr[7:2] == `CSWADDR) & valid & dapwrite)
                      | dapabort_q_int) & dapclken;

  assign psel_wr_en = (((dapaddr[7:2] == `PSELADDR) & valid & dapwrite)
                      | dapabort_q_int) & dapclken;

  assign psta_wr_en = ((dapaddr[7:2] == `PSTAADDR) & valid & dapwrite)
                      | dapabort_q_int;

  assign bfifo_wr_en = bfifo_access & valid & dapwrite;

  assign bfifo_rd_en = bfifo_access & dapsel & ~dapwrite;


//------------------------------------------------------------------------------
// DAP state Machine
//------------------------------------------------------------------------------
// Initiates and tracks the transfer on the DAP APB interface.

  assign start_state = (dapsel & ~dapenable & (reg_access | bfifo_access));

  always @ (r_byte_count or reg_access or start_state
            or state or w_byte_count)
    begin : p_nextstatecomb
      case (state)

        `JT_DAPIDLE : begin
          // waiting for an active transfer to start
          case ({start_state, reg_access})
            2'b00, 2'b01 : next_state = `JT_DAPIDLE;  // Unchanged
            2'b10        : next_state = `JT_DAPBFIFO1;// BFIFO access
            2'b11        : next_state = `JT_DAPREG;   // Internal register access
            default      : next_state = `JT_UNDEF;
          endcase
        end

        `JT_DAPREG : begin
          // DAP register access.
          // Zero wait states. Completes immediately
          next_state = `JT_DAPIDLE;
        end

        `JT_DAPBFIFO1 : begin
          // Wait for BFIFO Counter to be written
          next_state = `JT_DAPBFIFO2;
        end

        `JT_DAPBFIFO2 : begin
          // Wait until bfifo_reg is emptied (for Writes) or filled (for Reads)
          // Hold APB interface with dapready low
          next_state = ((~|w_byte_count) & (~|r_byte_count)) ?
                      `JT_DAPIDLE :
                      `JT_DAPBFIFO2;
        end

        default: begin
          // illegal state transition
          next_state = `JT_UNDEF;
        end

      endcase // case(state)
    end // block: p_nextstatecomb

 // Clear state machine to idle on dapabort
  assign next_state_abt = next_state & {2{~dapabort_q_int}};

  // Registers for state machine
  always @ (posedge dapclk or negedge dapresetn)
    begin : p_stateseq
      if (!dapresetn)
        state <= `JT_DAPIDLE;
      else if (dapclken)
        state <= next_state_abt;
    end

//------------------------------------------------------------------------------
// read/write registers
//------------------------------------------------------------------------------
//

// Clear CSW on dapabort

  assign nxt_csw_reg = dapwdata[1:0] & {2{~dapabort_q_int}};

// Control/Status Word Register; only bits[1:0] are writable;
//  other bits are reset elsewhere
  always @ (posedge dapclk or negedge dapresetn)
    begin : p_cswreg
      if (!dapresetn)
          csw_reg[1:0]  <= `CSWRSTVAL;
      else if (csw_wr_en)
          csw_reg[1:0]  <= nxt_csw_reg;   // TRST_OUT, SRST_OUT
    end

  assign trst_out_int = csw_reg[1];
  assign trst_out    = trst_out_int;
  assign s_rst_out_int = csw_reg[0];
  assign s_rst_out    = s_rst_out_int;

  // Assemble CSW Register for read
  assign csw_read_data = {ser_actv,           // JTAG Serialiser active
                        w_fifo_cnt,          // Outstanding Write FIFO Count
                        1'b0,              // Reserved
                        r_fifo_cnt,          // Outstanding read FIFO Count
                        {20{1'b0}},        // Reserved
                        port_sel_con,        // Port connected of selected port
                        s_rst_con,           // SRST connected of selected port
                        trst_out_int,        // TRST Assert
                        s_rst_out_int};       // SRST Assert

// Clear PSEL on dapabort
  assign nxt_psel_reg = dapwdata[7:0] & {8{~dapabort_q_int}};

// Port Select Register
  always @ (posedge dapclk or negedge dapresetn)
    begin : p_pselreg
      if (!dapresetn)
          psel_reg  <= `PSELRESET;
      else if (psel_wr_en)
          psel_reg  <= nxt_psel_reg;
    end

  assign port_sel = psel_reg;

// Port Status Register (sticky - cleared by writing a '1')
// A '1' indicates that a selected and enabled port has gone
// inactive - this may be transient, so the register is sticky
// Clear PSTA register on dapabort

  assign clr_psta_reg   = psta_reg_int & ~(dapwdata[7:0] & psta_reg_int) & {8{~dapabort_q_int}};

  assign next_psta_reg  = (psta_wr_en) ? clr_psta_reg : (psta_reg_int | port_status);

  // PSTA Register
  always @ (posedge dapclk or negedge dapresetn)
    begin : p_pstareg
      if (!dapresetn)
          psta_reg_int  <= `PSTARESET;
      else if (dapclken)
          psta_reg_int  <= next_psta_reg;  // Need to capture port status
    end                                // on every dapclk
  assign psta_reg = psta_reg_int;

//------------------------------------------------------------------------------
// Debug Access Port Data and Ready signal generation
//------------------------------------------------------------------------------

// Generate the ready signal from the state machine.
  // The ready signal is active immediately for a zero wait state response to a
  // register.
  // Ready in IDLE state and for zero-wait state register accesses
  // Other states insert wait states
  // dapabort will force state machine to JT_DAPIDLE, so no need to
  // clear dapready on dapabort

  assign dapready_next = (next_state == `JT_DAPIDLE) | (next_state == `JT_DAPREG);

  // Register the ready signal
  always @ (posedge dapclk or negedge dapresetn)
    begin : p_dapreadynextseq
      if (!dapresetn)
        dapready_int <= 1'b1;
      else if (dapclken)
        dapready_int <= dapready_next;
    end
  assign dapready = dapready_int;

//------------------------------------------------------------------------------
// Generate selects for daprdata register input multiplexer
//------------------------------------------------------------------------------

  assign csw_sel   = (dapaddr[7:2] == `CSWADDR ) & ~dapabort_q_int;
  assign psel_sel  = (dapaddr[7:2] == `PSELADDR) & ~dapabort_q_int;
  assign psta_sel  = (dapaddr[7:2] == `PSTAADDR) & ~dapabort_q_int;
  assign idr_sel   = (dapaddr[7:2] == `IDRADDR)  & ~dapabort_q_int;
  assign bfifo_sel = bfifo_access                 & ~dapabort_q_int;

// daprdata input multiplexer

  assign next_dap_rd_data = (({32{csw_sel}} & csw_read_data)             |
                          ({{24{1'b0}},{8{psel_sel}} & psel_reg})    |
                          ({{24{1'b0}},{8{psta_sel}} & psta_reg_int}) |
                          ({32{bfifo_sel}} & bfifo_reg)              |
                          ({32{idr_sel}} & `IDREGVAL));

// daprdata register enable

  assign rd_data_reg_en = (dapready_next | dapabort_q_int) & ~dapwrite & dapsel & dapclken;

  //----------------------------------------------------------------------------
  // daprdata output register
  //----------------------------------------------------------------------------
  always @(posedge dapclk or negedge dapresetn)
    begin : p_prdata
      if (!dapresetn)
        daprdata <= {32{1'b0}};
      else
        if(rd_data_reg_en)
          daprdata <= next_dap_rd_data;
    end

//------------------------------------------------------------------------------
// BFIFO Register interface to read and Write FIFOs
//------------------------------------------------------------------------------

// Generate count of bytes to write to Write FIFO

  always @ (dapaddr)
    begin : p_bytecountcomb
      case (dapaddr[3:2])
        `BF1BYTE : byte_count_next = 3'b001;
        `BF2BYTE : byte_count_next = 3'b010;
        `BF3BYTE : byte_count_next = 3'b011;
        `BF4BYTE : byte_count_next = 3'b100;
        default  : byte_count_next = 3'bxxx;
      endcase
    end

  assign dec_w_byte_count = w_byte_count - 3'b001;

  // Load count of bytes in BFIFO register on dapwrite;
  // decrement count when Write FIFO is written
  // Clear counter on dapabort


  assign w_byte_cnt_en = (bfifo_wr_en | w_fifo_wr_en | dapabort_q_int) & dapclken;

  assign next_w_byte_count = ((bfifo_wr_en) ? byte_count_next : dec_w_byte_count)
                            & {3{~dapabort_q_int}};

  // Write FIFO Byte Count Register
  always @ (posedge dapclk or negedge dapresetn)
    begin : p_wbytecounter
      if (!dapresetn)
          w_byte_count <= 3'b000;
      else if (w_byte_cnt_en)
          w_byte_count <= next_w_byte_count; // Load count of bytes in BFIFO register
    end

//------------------------------------------------------------------------------
// Counter for number of bytes to transfer from read FIFO
//------------------------------------------------------------------------------

  // Load count of bytes to read from BFIFO; decrement counter
  // on read of read FIFO
  assign dec_r_byte_count = r_byte_count - 3'b001;
  assign load_r_byte_cnt  = bfifo_rd_en & (state == `JT_DAPBFIFO1);

  assign r_byte_cnt_en    = (load_r_byte_cnt | r_fifo_rd_en | dapabort_q_int) & dapclken;

  assign next_r_byte_count = ((load_r_byte_cnt) ? byte_count_next : dec_r_byte_count)
                            & {3{~dapabort_q_int}};

  // read FIFO Byte Count Register
  always @ (posedge dapclk or negedge dapresetn)
    begin : p_rbytecounter
      if (!dapresetn)
          r_byte_count <= 3'b000;
      else if (r_byte_cnt_en)
          r_byte_count <= next_r_byte_count;
    end

//------------------------------------------------------------------------------
// BFIFO Register
//------------------------------------------------------------------------------

  // Assemble next TDO byte into bfifo_reg; zero most significant byte(s) if
  // necessary on load of last byte
  // When count is zero, select usual case for 1st byte of next load,
  // to minimise toggling

  assign r_fifo_entry = r_fifo[r_fifo_rd_ptr];

  always @ (bfifo_reg or dapaddr or r_byte_count
            or r_fifo_entry)
    begin : p_byterfifomux

      case ({dapaddr[3:2],r_byte_count})

         `BFIFO4_2NDBYTE,
         `BFIFO3_2NDBYTE  : next_b_fifo_reg = {bfifo_reg[31:16],r_fifo_entry,
                                                            bfifo_reg[7:0]};

         `BFIFO2_LASTBYTE : next_b_fifo_reg = {{16{1'b0}},r_fifo_entry,
                                                       bfifo_reg[7:0]};

         `BFIFO4_3RDBYTE  : next_b_fifo_reg = {bfifo_reg[31:24],r_fifo_entry,
                                                            bfifo_reg[15:0]};
         `BFIFO3_LASTBYTE : next_b_fifo_reg = {{8{1'b0}},r_fifo_entry,
                                                      bfifo_reg[15:0]};

         `BFIFO4_LASTBYTE : next_b_fifo_reg = {r_fifo_entry,bfifo_reg[23:0]};

         `BFIFO1_LASTBYTE : next_b_fifo_reg = {{24{1'b0}},r_fifo_entry};

         `BFIFO4_1STBYTE,
         `BFIFO3_1STBYTE,
         `BFIFO2_1STBYTE,
         `BFIFO_ZCOUNT    : next_b_fifo_reg = {bfifo_reg[31:8],r_fifo_entry};

         default          : next_b_fifo_reg = `BFIFO_UNDEF;
      endcase
    end


  assign bfifo_reg_en = (bfifo_wr_en | r_fifo_rd_en) & dapclken;

  assign new_b_fifo_reg = (bfifo_wr_en) ? dapwdata : next_b_fifo_reg;

  // Write the BFIFO register (not required to be reset, or cleared on dapabort)
  always @ (posedge dapclk)
    begin : p_bfiforeg
      if (bfifo_reg_en)
        bfifo_reg <= new_b_fifo_reg;
    end

//------------------------------------------------------------------------------
// read FIFO
// Implemented as a circular buffer with separate read and write pointers
//------------------------------------------------------------------------------

// Generate incremented value of read FIFO read pointer
// Clear pointer on dapabort
  assign nxt_r_fifo_rd_ptr = (inc_r_fifo_ptr(r_fifo_rd_ptr)) & {3{~dapabort_q_int}};

  // read FIFO write and read enables
  assign r_fifo_wr_en= ((r_fifo_req & ~r_fifo_full & r_fifo_ack_int) | dapabort_q_int) & dapclken;
  assign r_fifo_rd_en = (((|r_byte_count) & (state == `JT_DAPBFIFO2) &
                        bfifo_rd_en & ~r_fifo_empty) | dapabort_q_int) & dapclken;

// Register read FIFO read Pointer
  always @ (posedge dapclk or negedge dapresetn)
    begin : p_rfifordptr
      if (!dapresetn)
          r_fifo_rd_ptr <= 3'b000;
      else if (r_fifo_rd_en)
          r_fifo_rd_ptr <= nxt_r_fifo_rd_ptr;   // Increment pointer on read
    end

  // Generate incremented value of read FIFO write pointer
  // Clear pointer on dapabort
  assign nxt_r_fifo_wr_ptr = (inc_r_fifo_ptr(r_fifo_wr_ptr)) & {3{~dapabort_q_int}};

// Register read FIFO Write Pointer
  always @ (posedge dapclk or negedge dapresetn)
    begin : p_rfifowtptr
      if (!dapresetn)
          r_fifo_wr_ptr <= 3'b000;
      else if (r_fifo_wr_en)
          r_fifo_wr_ptr <= nxt_r_fifo_wr_ptr;   // Increment pointer on write
    end

// Generate incremented and decremented values of read FIFO entry counter
  assign inc_r_fifo_cnt = r_fifo_cnt + 3'b001;
  assign dec_r_fifo_cnt = r_fifo_cnt - 3'b001;

// Increment counter on write, decrement on read, do nothing if
// read and write on same cycle
// Clear counter on dapabort
  assign r_fifo_cnt_en   = ((r_fifo_wr_en ^ r_fifo_rd_en) | dapabort_q_int) & dapclken;
  assign next_r_fifo_cnt = ((r_fifo_wr_en) ? inc_r_fifo_cnt : dec_r_fifo_cnt)
                        & {3{~dapabort_q_int}};

// read FIFO entry counter
  always @ (posedge dapclk or negedge dapresetn)
    begin : p_rfifocounter
      if (!dapresetn)
          r_fifo_cnt <= 3'b000;
      else if (r_fifo_cnt_en)
          r_fifo_cnt <= next_r_fifo_cnt;
    end

// Evaluate full and empty status of read-FIFO
  assign r_fifo_full  = (r_fifo_cnt == `RFIFODEPTH);
  assign r_fifo_empty = (~|r_fifo_cnt);

// Write the read FIFO at entry pointed to by Write Pointer
  always @ (posedge dapclk)
    begin : p_rfifowr
      if (r_fifo_wr_en)
        r_fifo[r_fifo_wr_ptr] <= tdo_byte;
    end

//------------------------------------------------------------------------------
// Write FIFO
// Implemented as a circular buffer with separate read and write pointers
//------------------------------------------------------------------------------

  // Write FIFO Write Enable
  assign w_fifo_wr_en = (((|w_byte_count) & (~w_fifo_full)) | dapabort_q_int) & dapclken;

  // Evaluate Write FIFO read enable
  assign w_fifo_rd_en = ((jtag_cmd_req_int & jtag_cmd_ack) | dapabort_q_int) & dapclken;

  // Generate incremented value of Write FIFO read pointer
  // Clear on dapabort
  assign inc_w_fifo_rd_ptr = (w_fifo_rd_ptr == num_entries_wfifo[1:0] ) ? 2'b00 :
                         w_fifo_rd_ptr + 2'b01;
  assign nxt_w_fifo_rd_ptr = (inc_w_fifo_rd_ptr) & {2{~dapabort_q_int}};

// Register Write FIFO read Pointer
  always @ (posedge dapclk or negedge dapresetn)
    begin : p_wfifordptr
      if (!dapresetn)
          w_fifo_rd_ptr <= 2'b00;
      else if (w_fifo_rd_en)
          w_fifo_rd_ptr <= nxt_w_fifo_rd_ptr;   // Increment pointer on read
    end

  // Generate incremented value of Write FIFO write pointer
  // Clear on dapabort
  assign inc_w_fifo_wr_ptr = (w_fifo_wr_ptr == num_entries_wfifo[1:0] ) ? 2'b00 :
                         w_fifo_wr_ptr + 2'b01;
  assign nxt_w_fifo_wr_ptr = (inc_w_fifo_wr_ptr) & {2{~dapabort_q_int}};

// Register Write FIFO Write Pointer
  always @ (posedge dapclk or negedge dapresetn)
    begin : p_wfifowrptr
      if (!dapresetn)
          w_fifo_wr_ptr <= 2'b00;
      else if (w_fifo_wr_en)
          w_fifo_wr_ptr <= nxt_w_fifo_wr_ptr;   // Increment pointer on write
    end

// Evaluate pointer to next byte to extract from BFIFO register
// Depends on byte counter and whether BFIFO 1,2,3 or 4 addressed
// When count is zero, select usual case for 1st byte of next load,
// to minimise toggling
  always @ (bfifo_reg or dapaddr or w_byte_count)
    begin : p_bytefifomux
      case ({dapaddr[3:2], w_byte_count})

         `BFIFO4_LASTBYTE : bfifo_reg_byte = bfifo_reg[31:24];

         `BFIFO4_3RDBYTE,
         `BFIFO3_LASTBYTE : bfifo_reg_byte = bfifo_reg[23:16];

         `BFIFO4_2NDBYTE,
         `BFIFO3_2NDBYTE,
         `BFIFO2_LASTBYTE : bfifo_reg_byte = bfifo_reg[15:8];

         `BFIFO4_1STBYTE,
         `BFIFO3_1STBYTE,
         `BFIFO2_1STBYTE,
         `BFIFO1_LASTBYTE,
         `BFIFO_ZCOUNT    : bfifo_reg_byte = bfifo_reg[7:0];

          default         : bfifo_reg_byte = `BYTE_UNDEF;
      endcase
    end


// Write the Write FIFO at entry pointed to by Write Pointer
  always @ (posedge dapclk)
    begin : p_wfifowr
      if (w_fifo_wr_en)
        w_fifo[w_fifo_wr_ptr] <= bfifo_reg_byte;
    end

// Generate incremented and decremented values of Write FIFO entry counter
 assign  inc_w_fifo_cnt = w_fifo_cnt + 3'b001;
 assign  dec_w_fifo_cnt = w_fifo_cnt - 3'b001;

// Increment on writes, decrement on reads, do nothing if both read and
// write in the same cycle
 assign  w_fifo_cnt_en   = ((w_fifo_wr_en ^ w_fifo_rd_en) | dapabort_q_int) & dapclken;
 assign  next_w_fifo_cnt = ((w_fifo_wr_en) ? inc_w_fifo_cnt : dec_w_fifo_cnt)
                          & {3{~dapabort_q_int}};

// Write FIFO entry counter
  always @ (posedge dapclk or negedge dapresetn)
    begin : p_wfifocounter
      if (!dapresetn)
          w_fifo_cnt <= 3'b000;
      else if (w_fifo_cnt_en)
          w_fifo_cnt <= next_w_fifo_cnt;
    end

// Evaluate full and empty status of Write-FIFO
  assign w_fifo_full  = (w_fifo_cnt == `WFIFODEPTH_MAXVAL);
  assign w_fifo_empty = (~|w_fifo_cnt);

//------------------------------------------------------------------------------
// Interface to JTAG Serialiser Engine
//------------------------------------------------------------------------------

// JTAG Command to send if Write FIFO not empty and JTAG Serialiser
// not busy
  assign next_jtag_cmd_req = ~jtag_cmd_ack & ~dapabort_q_int;
  assign jtag_cmd_req_en = ((~w_fifo_empty) | dapabort_q_int) & dapclken;

  // Register JTAG Command Request
  always @ (posedge dapclk or negedge dapresetn)
    begin : p_jtagcmdreq
      if (!dapresetn)
          jtag_cmd_req_int <= 1'b0;
      else if (jtag_cmd_req_en)
          jtag_cmd_req_int <= next_jtag_cmd_req;   // Request to send JTAG Command
    end

  assign jtag_cmd_req  = jtag_cmd_req_int;
  assign jtag_cmd_en   = (~w_fifo_empty & ~jtag_cmd_ack) & dapclken;
  assign next_jtag_cmd = w_fifo[w_fifo_rd_ptr];

  // JTAG Command Register
  // No need to clear on dapabort because WFIFO will be reloaded
  // after an abort
  always @ (posedge dapclk or negedge dapresetn)
    begin : p_jtagcmd
      if (!dapresetn)
        jtag_cmd <= 8'b00000000;
      else if (jtag_cmd_en)
        jtag_cmd <= next_jtag_cmd;
    end

// Interface between JTAG serialiser and read FIFO
// Accept TDO byte if Request from serialiser and read FIFO not full
  assign next_r_fifo_ack = ~r_fifo_full & r_fifo_req & ~dapabort_q_int;

  // Register read FIFO Acknowledge
  always @ (posedge dapclk or negedge dapresetn)
    begin : p_rfifoack
      if (!dapresetn)
          r_fifo_ack_int <= 1'b0;
      else if (dapclken)
          r_fifo_ack_int <= next_r_fifo_ack;   // Acknowledge transfer of TDO byte
    end
  assign r_fifo_ack = r_fifo_ack_int;

//------------------------------------------------------------------------------
// OVL Assertions
//------------------------------------------------------------------------------
`ifdef ARM_ASSERT_ON


  //----------------------------------------------------------------------------
  // OVL_ASSERT: Check for legal use of FIFO read and write pointers
  //----------------------------------------------------------------------------
  // Check that RFIFO read and write pointers are (RFIFODEPTH-1) or less.
  //----------------------------------------------------------------------------

 assert_range #(`OVL_ERROR, 3, 0, `RFIFODEPTH-1, `OVL_ASSERT, "r_fifo_rd_ptr is not RFIFODEPTH-1 or less")
    rfifordptr_range (
      .clk              (dapclk),
      .reset_n          (dapresetn),
      .test_expr        (r_fifo_rd_ptr)
      );

 assert_range #(`OVL_ERROR, 3, 0, `RFIFODEPTH-1, `OVL_ASSERT, "r_fifo_wr_ptr is not RFIFODEPTH-1 or less")
    rfifowrptr_range (
      .clk              (dapclk),
      .reset_n          (dapresetn),
      .test_expr        (r_fifo_wr_ptr)
      );

  //----------------------------------------------------------------------------
  // Check that WFIFO read and write pointers are (WFIFODEPTH-1) or less.
  //----------------------------------------------------------------------------

 assert_range #(`OVL_ERROR, 2, 0, `WFIFODEPTH-1, `OVL_ASSERT, "w_fifo_rd_ptr is not WFIFODEPTH-1 or less")
    wfifordptr_range (
      .clk              (dapclk),
      .reset_n          (dapresetn),
      .test_expr        (w_fifo_rd_ptr)
      );

  assert_range #(`OVL_ERROR, 2, 0, `WFIFODEPTH-1, `OVL_ASSERT, "w_fifo_wr_ptr is not WFIFODEPTH-1 or less")
    wfifowrptr_range (
      .clk              (dapclk),
      .reset_n          (dapresetn),
      .test_expr        (w_fifo_wr_ptr)
      );

  //----------------------------------------------------------------------------
  // OVL_ASSERT: Check for legal values of read and write FIFO entry counts
  //----------------------------------------------------------------------------

  assert_range #(`OVL_ERROR, 3, 0, `RFIFODEPTH, `OVL_ASSERT, "r_fifo_cnt should be RFIFODEPTH or less")
    rfifocnt_range (
      .clk              (dapclk),
      .reset_n          (dapresetn),
      .test_expr        (r_fifo_cnt)
      );

  assert_range #(`OVL_ERROR, 3, 0, `WFIFODEPTH, `OVL_ASSERT, "w_fifo_cnt should be WFIFODEPTH or less")
    wfifocnt_range (
      .clk              (dapclk),
      .reset_n          (dapresetn),
      .test_expr        (w_fifo_cnt)
      );

  //----------------------------------------------------------------------------
  // OVL_ASSERT: Check that bfifo_wr_en and w_fifo_wr_en can't occur simultaneously
  //----------------------------------------------------------------------------

  assert_never #(`OVL_ERROR, `OVL_ASSERT, "bfifo_wr_en and w_fifo_wr_en are both HIGH")
    ovl_bfifo_wr_en (
      .clk          (dapclk),
      .reset_n      (dapresetn),
      .test_expr    (bfifo_wr_en & w_fifo_wr_en)
      );

  //----------------------------------------------------------------------------
  // OVL_ASSERT: Check for legal values of r_byte_count and w_byte_count
  //----------------------------------------------------------------------------

  assert_range #(`OVL_ERROR, 3, 0, 4, `OVL_ASSERT, "r_byte_count should be 4 or less")
    rbytecount_range (
      .clk              (dapclk),
      .reset_n          (dapresetn),
      .test_expr        (r_byte_count)
      );

  assert_range #(`OVL_ERROR, 3, 0, 4, `OVL_ASSERT, "w_byte_count should be 4 or less")
    wbytecount_range (
      .clk              (dapclk),
      .reset_n          (dapresetn),
      .test_expr        (w_byte_count)
      );

  //----------------------------------------------------------------------------
  // OVL_ASSERT: Check for illegal combinations of dapaddr and r_byte_count
  //----------------------------------------------------------------------------

  assert_always #(`OVL_ERROR, `OVL_ASSERT, "Illegal combination of dapaddr[3:2] and r_byte_count")
    dapaddr_rbytecount_comb (
      .clk              (dapclk),
      .reset_n          (dapresetn),
      .test_expr        (   ({dapaddr[3:2],r_byte_count} !=5'b10100)
                          & ({dapaddr[3:2],r_byte_count} !=5'b01100)
                          & ({dapaddr[3:2],r_byte_count} !=5'b00100)
                          & ({dapaddr[3:2],r_byte_count} !=5'b01011)
                          & ({dapaddr[3:2],r_byte_count} !=5'b00011)
                          & ({dapaddr[3:2],r_byte_count} !=5'b00010)
                        )
      );

  //----------------------------------------------------------------------------
  // OVL_ASSERT: Check for illegal combinations of dapaddr and w_byte_count
  //----------------------------------------------------------------------------

  assert_always #(`OVL_ERROR, `OVL_ASSERT, "Illegal combination of dapaddr[3:2] and w_byte_count")
    dapaddr_wbytecount_comb (
      .clk              (dapclk),
      .reset_n          (dapresetn),
      .test_expr        (   ({dapaddr[3:2],w_byte_count} !=5'b10100)
                          & ({dapaddr[3:2],w_byte_count} !=5'b01100)
                          & ({dapaddr[3:2],w_byte_count} !=5'b00100)
                          & ({dapaddr[3:2],w_byte_count} !=5'b01011)
                          & ({dapaddr[3:2],w_byte_count} !=5'b00011)
                          & ({dapaddr[3:2],w_byte_count} !=5'b00010)
                        )
      );

  //----------------------------------------------------------------------------
  // OVL_ASSERT: Check for tdo_byte not x when being loaded into the read FIFO
  // Needs to be qualified with dapabort because write enable is forced on
  // (to clear counters) and x's may be written into the read FIFO in that
  // case (this register value would not be read)
  //----------------------------------------------------------------------------
  // Severity 1
  assert_never_unknown #(`OVL_ERROR, 8, `OVL_ASSERT, "x or z detected in tdobyte when captured in read FIFO")
    dapjtagap_tdobyte_x_on_rfifo_load
      (
       .clk       (dapclk),
       .reset_n   (dapresetn),
       .qualifier (r_fifo_wr_en & ~dapabort),
       .test_expr (tdo_byte[7:0])
      );

  //----------------------------------------------------------------------------
  // OVL_ASSERT: Check for new_b_fifo_reg[31:0] being assigned x - added due to
  // Solidify bad reachable x-assignment warnings (can't happen in practice)
  // Needs to be qualified with dapabort because write enable is forced on
  // (to clear counters) and x's may be written into the bfifo_reg in that
  // case (this register value would not be read)
  //----------------------------------------------------------------------------
  // Severity 1
  assert_never_unknown #(`OVL_ERROR, 32, `OVL_ASSERT, "bfifo_reg loaded with x or z")
    dapjtagap_bfiforeg_x
      (
       .clk       (dapclk),
       .reset_n   (dapresetn),
       .qualifier (bfifo_reg_en & ~dapabort),
       .test_expr (new_b_fifo_reg[31:0])
      );

  //----------------------------------------------------------------------------
  // OVL_ASSERT: Check for bfifo_reg_byte[7:0] being assigned x - added due to
  // Solidify bad reachable x-assignment warnings (can't happen in practice)
  // Needs to be qualified with dapabort because write enable is forced on
  // (to clear counters) and x's may be written into the w_fifo in that
  // case (this FIFO value would not be used)
  //----------------------------------------------------------------------------
  // Severity 1
  assert_never_unknown #(`OVL_ERROR, 8, `OVL_ASSERT, "w_fifo loaded with x or z in bfifo_reg_byte")
    dapjtagap_bfiforegbyte_x
      (
       .clk       (dapclk),
       .reset_n   (dapresetn),
       .qualifier (w_fifo_wr_en & ~dapabort),
       .test_expr (bfifo_reg_byte[7:0])
      );

`endif //  `ifdef ARM_ASSERT_ON


endmodule // cxdapjtagap_apb_if
