//-----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2011-2015 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//  Checked In          : $Date: 2014-06-25 08:59:36 +0100 (Wed, 25 Jun 2014) $
//  Revision            : $Revision: 39630 $
//  Release             : CoreSight-SoC-TM100-r3p2-00rel0
//
//----------------------------------------------------------------------------
// Verilog-2001 (IEEE Std 1364-2001)
//  ----------------------------------------------------------------------------
//  Purpose             : APB Interconnect comprising :
//                           APB Slave interfaces
//                           Arbiter
//                           APB Slave mux for address, write-data
//                           ROM Table
//                           Response Mux (for responses from Master interfaces)
//                           Slave demux (for responses)
//   This block, when configured for multiple master interfaces and multiple
// slave interfaces, implements a single-layer interconnect that allows multiple
// APB slave interfaces to initiate transfers to one of several master
// interfaces. When an access from one slave interface is in progress, the other
// slave interfaces are waited (by pulling the respective pready low).
//   A static priority scheme is used to arbitrate between competing slave
// interfaces. Accesses from Slave interface 0 are given the highest priority.
// The priority scheme is : SlvIntf0 (highest priority) >
//           SlvIntf1 > SlvIntf2 > ... > SlvIntf(n-1)
//   Address and Write data from the selected Slave interface is muxed out to
// the master interfaces. For synthesis timing purposes, master address ranges
// are pre-decoded in Slave interfaces and are muxed along with the address.
//   Responses from the addressed master interface are routed to the
// selected Slave interface.
//   This block contains an internal ROM Table whose entries are configured
// by the user. The targetid[] port is used to optionally configure some
// of the values returned on reads of CoreSight management registers in the
// ROM Table.
//  --========================================================================--

module cxapbic_1
 #(
  // Parameters to specify manual ROM Entries
  // Non-zero default to avoid harmless lint warning
  
  parameter ROM_MANUAL_ENTRY0 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY1 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY2 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY3 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY4 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY5 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY6 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY7 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY8 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY9 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY10 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY11 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY12 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY13 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY14 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY15 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY16 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY17 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY18 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY19 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY20 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY21 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY22 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY23 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY24 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY25 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY26 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY27 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY28 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY29 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY30 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY31 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY32 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY33 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY34 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY35 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY36 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY37 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY38 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY39 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY40 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY41 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY42 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY43 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY44 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY45 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY46 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY47 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY48 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY49 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY50 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY51 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY52 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY53 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY54 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY55 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY56 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY57 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY58 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY59 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY60 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY61 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY62 = 32'h00000010,
  parameter ROM_MANUAL_ENTRY63 = 32'h00000010,
  // Parameter to disable automatically created ROM Entries
  parameter ROM_AUTO_DISABLED = 1'b0)
  (
  // Clock and reset
  clk,
  resetn,
  
  // I/O Declaration for APB Slave interface 0
  paddrs0,
  psels0,
  penables0,
  pwrites0,
  pwdatas0,
  prdatas0,
  preadys0,
  pslverrs0,
    
  // I/O Declaration for APB Slave interface 1
  paddrs1,
  psels1,
  penables1,
  pwrites1,
  pwdatas1,
  prdatas1,
  preadys1,
  pslverrs1,
    
  // I/O Declaration for APB Master interface 0
  paddrm0,
  paddr31m0,
  pselm0,
  penablem0,
  pwritem0,
  pwdatam0,
  prdatam0,
  preadym0,
  pslverrm0,
    
  // I/O Declaration for APB Master interface 1
  paddrm1,
  paddr31m1,
  pselm1,
  penablem1,
  pwritem1,
  pwdatam1,
  prdatam1,
  preadym1,
  pslverrm1,
    
  // I/O Declaration for APB Master interface 2
  paddrm2,
  paddr31m2,
  pselm2,
  penablem2,
  pwritem2,
  pwdatam2,
  prdatam2,
  preadym2,
  pslverrm2,
    
  // I/O Declaration for APB Master interface 3
  paddrm3,
  paddr31m3,
  pselm3,
  penablem3,
  pwritem3,
  pwdatam3,
  prdatam3,
  preadym3,
  pslverrm3,
    
  // I/O Declaration for APB Master interface 4
  paddrm4,
  paddr31m4,
  pselm4,
  penablem4,
  pwritem4,
  pwdatam4,
  prdatam4,
  preadym4,
  pslverrm4,
    
  // I/O Declaration for APB Master interface 5
  paddrm5,
  paddr31m5,
  pselm5,
  penablem5,
  pwritem5,
  pwdatam5,
  prdatam5,
  preadym5,
  pslverrm5,
    
  // I/O Declaration for APB Master interface 6
  paddrm6,
  paddr31m6,
  pselm6,
  penablem6,
  pwritem6,
  pwdatam6,
  prdatam6,
  preadym6,
  pslverrm6,
    
  // I/O Declaration for APB Master interface 7
  paddrm7,
  paddr31m7,
  pselm7,
  penablem7,
  pwritem7,
  pwdatam7,
  prdatam7,
  preadym7,
  pslverrm7,
    
  // I/O Declaration for APB Master interface 8
  paddrm8,
  paddr31m8,
  pselm8,
  penablem8,
  pwritem8,
  pwdatam8,
  prdatam8,
  preadym8,
  pslverrm8,
    
  // I/O Declaration for APB Master interface 9
  paddrm9,
  paddr31m9,
  pselm9,
  penablem9,
  pwritem9,
  pwdatam9,
  prdatam9,
  preadym9,
  pslverrm9,
    
  // I/O Declaration for APB Master interface 10
  paddrm10,
  paddr31m10,
  pselm10,
  penablem10,
  pwritem10,
  pwdatam10,
  prdatam10,
  preadym10,
  pslverrm10,
    
  // I/O Declaration for APB Master interface 11
  paddrm11,
  paddr31m11,
  pselm11,
  penablem11,
  pwritem11,
  pwdatam11,
  prdatam11,
  preadym11,
  pslverrm11,
    
  // I/O Declaration for APB Master interface 12
  paddrm12,
  paddr31m12,
  pselm12,
  penablem12,
  pwritem12,
  pwdatam12,
  prdatam12,
  preadym12,
  pslverrm12,
    
  // I/O Declaration for APB Master interface 13
  paddrm13,
  paddr31m13,
  pselm13,
  penablem13,
  pwritem13,
  pwdatam13,
  prdatam13,
  preadym13,
  pslverrm13,
    
  // I/O Declaration for APB Master interface 14
  paddrm14,
  paddr31m14,
  pselm14,
  penablem14,
  pwritem14,
  pwdatam14,
  prdatam14,
  preadym14,
  pslverrm14,
    
  // I/O Declaration for APB Master interface 15
  paddrm15,
  paddr31m15,
  pselm15,
  penablem15,
  pwritem15,
  pwdatam15,
  prdatam15,
  preadym15,
  pslverrm15,
    
  // I/O Declaration for APB Master interface 16
  paddrm16,
  paddr31m16,
  pselm16,
  penablem16,
  pwritem16,
  pwdatam16,
  prdatam16,
  preadym16,
  pslverrm16,
    
  // I/O Declaration for APB Master interface 17
  paddrm17,
  paddr31m17,
  pselm17,
  penablem17,
  pwritem17,
  pwdatam17,
  prdatam17,
  preadym17,
  pslverrm17,
    
  // I/O Declaration for APB Master interface 18
  paddrm18,
  paddr31m18,
  pselm18,
  penablem18,
  pwritem18,
  pwdatam18,
  prdatam18,
  preadym18,
  pslverrm18,
    
  // I/O Declaration for APB Master interface 19
  paddrm19,
  paddr31m19,
  pselm19,
  penablem19,
  pwritem19,
  pwdatam19,
  prdatam19,
  preadym19,
  pslverrm19,
    
  // I/O Declaration for APB Master interface 20
  paddrm20,
  paddr31m20,
  pselm20,
  penablem20,
  pwritem20,
  pwdatam20,
  prdatam20,
  preadym20,
  pslverrm20,
    // targetid setting for top-level APBIC
  targetid,

  // paddr31 for Slave interface 0
  paddr31s0,

  // Authentication interface
  dbgswen
);

//-----------------------------------------------------------------------------
// Constants
//-----------------------------------------------------------------------------
`include "cxapbic_constants_1.v"

//-----------------------------------------------------------------------------
// Port declarations
//-----------------------------------------------------------------------------
  // Clock and reset
  input wire clk;
  input wire resetn;
  // I/O Declaration for APB Slave interface 0
  input  wire [16:2] paddrs0;
  input  wire        psels0;
  input  wire        penables0;
  input  wire        pwrites0;
  input  wire [31:0] pwdatas0;
  output wire [31:0] prdatas0;
  output wire        preadys0;
  output wire        pslverrs0;
    
  // I/O Declaration for APB Slave interface 1
  input  wire [16:2] paddrs1;
  input  wire        psels1;
  input  wire        penables1;
  input  wire        pwrites1;
  input  wire [31:0] pwdatas1;
  output wire [31:0] prdatas1;
  output wire        preadys1;
  output wire        pslverrs1;
    
  // I/O Declaration for APB Master interface 0
  output wire [(12+0)-1:2] paddrm0;
  output wire        paddr31m0;
  output wire        pselm0;
  output wire        penablem0;
  output wire        pwritem0;
  output wire [31:0] pwdatam0;
  input  wire [31:0] prdatam0;
  input  wire        preadym0;
  input  wire        pslverrm0;
    
  // I/O Declaration for APB Master interface 1
  output wire [(12+0)-1:2] paddrm1;
  output wire        paddr31m1;
  output wire        pselm1;
  output wire        penablem1;
  output wire        pwritem1;
  output wire [31:0] pwdatam1;
  input  wire [31:0] prdatam1;
  input  wire        preadym1;
  input  wire        pslverrm1;
    
  // I/O Declaration for APB Master interface 2
  output wire [(12+0)-1:2] paddrm2;
  output wire        paddr31m2;
  output wire        pselm2;
  output wire        penablem2;
  output wire        pwritem2;
  output wire [31:0] pwdatam2;
  input  wire [31:0] prdatam2;
  input  wire        preadym2;
  input  wire        pslverrm2;
    
  // I/O Declaration for APB Master interface 3
  output wire [(12+0)-1:2] paddrm3;
  output wire        paddr31m3;
  output wire        pselm3;
  output wire        penablem3;
  output wire        pwritem3;
  output wire [31:0] pwdatam3;
  input  wire [31:0] prdatam3;
  input  wire        preadym3;
  input  wire        pslverrm3;
    
  // I/O Declaration for APB Master interface 4
  output wire [(12+0)-1:2] paddrm4;
  output wire        paddr31m4;
  output wire        pselm4;
  output wire        penablem4;
  output wire        pwritem4;
  output wire [31:0] pwdatam4;
  input  wire [31:0] prdatam4;
  input  wire        preadym4;
  input  wire        pslverrm4;
    
  // I/O Declaration for APB Master interface 5
  output wire [(12+0)-1:2] paddrm5;
  output wire        paddr31m5;
  output wire        pselm5;
  output wire        penablem5;
  output wire        pwritem5;
  output wire [31:0] pwdatam5;
  input  wire [31:0] prdatam5;
  input  wire        preadym5;
  input  wire        pslverrm5;
    
  // I/O Declaration for APB Master interface 6
  output wire [(12+0)-1:2] paddrm6;
  output wire        paddr31m6;
  output wire        pselm6;
  output wire        penablem6;
  output wire        pwritem6;
  output wire [31:0] pwdatam6;
  input  wire [31:0] prdatam6;
  input  wire        preadym6;
  input  wire        pslverrm6;
    
  // I/O Declaration for APB Master interface 7
  output wire [(12+0)-1:2] paddrm7;
  output wire        paddr31m7;
  output wire        pselm7;
  output wire        penablem7;
  output wire        pwritem7;
  output wire [31:0] pwdatam7;
  input  wire [31:0] prdatam7;
  input  wire        preadym7;
  input  wire        pslverrm7;
    
  // I/O Declaration for APB Master interface 8
  output wire [(12+0)-1:2] paddrm8;
  output wire        paddr31m8;
  output wire        pselm8;
  output wire        penablem8;
  output wire        pwritem8;
  output wire [31:0] pwdatam8;
  input  wire [31:0] prdatam8;
  input  wire        preadym8;
  input  wire        pslverrm8;
    
  // I/O Declaration for APB Master interface 9
  output wire [(12+0)-1:2] paddrm9;
  output wire        paddr31m9;
  output wire        pselm9;
  output wire        penablem9;
  output wire        pwritem9;
  output wire [31:0] pwdatam9;
  input  wire [31:0] prdatam9;
  input  wire        preadym9;
  input  wire        pslverrm9;
    
  // I/O Declaration for APB Master interface 10
  output wire [(12+0)-1:2] paddrm10;
  output wire        paddr31m10;
  output wire        pselm10;
  output wire        penablem10;
  output wire        pwritem10;
  output wire [31:0] pwdatam10;
  input  wire [31:0] prdatam10;
  input  wire        preadym10;
  input  wire        pslverrm10;
    
  // I/O Declaration for APB Master interface 11
  output wire [(12+0)-1:2] paddrm11;
  output wire        paddr31m11;
  output wire        pselm11;
  output wire        penablem11;
  output wire        pwritem11;
  output wire [31:0] pwdatam11;
  input  wire [31:0] prdatam11;
  input  wire        preadym11;
  input  wire        pslverrm11;
    
  // I/O Declaration for APB Master interface 12
  output wire [(12+0)-1:2] paddrm12;
  output wire        paddr31m12;
  output wire        pselm12;
  output wire        penablem12;
  output wire        pwritem12;
  output wire [31:0] pwdatam12;
  input  wire [31:0] prdatam12;
  input  wire        preadym12;
  input  wire        pslverrm12;
    
  // I/O Declaration for APB Master interface 13
  output wire [(12+0)-1:2] paddrm13;
  output wire        paddr31m13;
  output wire        pselm13;
  output wire        penablem13;
  output wire        pwritem13;
  output wire [31:0] pwdatam13;
  input  wire [31:0] prdatam13;
  input  wire        preadym13;
  input  wire        pslverrm13;
    
  // I/O Declaration for APB Master interface 14
  output wire [(12+0)-1:2] paddrm14;
  output wire        paddr31m14;
  output wire        pselm14;
  output wire        penablem14;
  output wire        pwritem14;
  output wire [31:0] pwdatam14;
  input  wire [31:0] prdatam14;
  input  wire        preadym14;
  input  wire        pslverrm14;
    
  // I/O Declaration for APB Master interface 15
  output wire [(12+0)-1:2] paddrm15;
  output wire        paddr31m15;
  output wire        pselm15;
  output wire        penablem15;
  output wire        pwritem15;
  output wire [31:0] pwdatam15;
  input  wire [31:0] prdatam15;
  input  wire        preadym15;
  input  wire        pslverrm15;
    
  // I/O Declaration for APB Master interface 16
  output wire [(12+0)-1:2] paddrm16;
  output wire        paddr31m16;
  output wire        pselm16;
  output wire        penablem16;
  output wire        pwritem16;
  output wire [31:0] pwdatam16;
  input  wire [31:0] prdatam16;
  input  wire        preadym16;
  input  wire        pslverrm16;
    
  // I/O Declaration for APB Master interface 17
  output wire [(12+0)-1:2] paddrm17;
  output wire        paddr31m17;
  output wire        pselm17;
  output wire        penablem17;
  output wire        pwritem17;
  output wire [31:0] pwdatam17;
  input  wire [31:0] prdatam17;
  input  wire        preadym17;
  input  wire        pslverrm17;
    
  // I/O Declaration for APB Master interface 18
  output wire [(12+0)-1:2] paddrm18;
  output wire        paddr31m18;
  output wire        pselm18;
  output wire        penablem18;
  output wire        pwritem18;
  output wire [31:0] pwdatam18;
  input  wire [31:0] prdatam18;
  input  wire        preadym18;
  input  wire        pslverrm18;
    
  // I/O Declaration for APB Master interface 19
  output wire [(12+0)-1:2] paddrm19;
  output wire        paddr31m19;
  output wire        pselm19;
  output wire        penablem19;
  output wire        pwritem19;
  output wire [31:0] pwdatam19;
  input  wire [31:0] prdatam19;
  input  wire        preadym19;
  input  wire        pslverrm19;
    
  // I/O Declaration for APB Master interface 20
  output wire [(12+0)-1:2] paddrm20;
  output wire        paddr31m20;
  output wire        pselm20;
  output wire        penablem20;
  output wire        pwritem20;
  output wire [31:0] pwdatam20;
  input  wire [31:0] prdatam20;
  input  wire        preadym20;
  input  wire        pslverrm20;
    
  // targetid setting for top-level APBIC
  input  wire [31:0] targetid;

  // paddr31 for Slave interface 0
  input  wire        paddr31s0;

  // Authentication interface
  input  wire        dbgswen;

//-----------------------------------------------------------------------------
// Wire declarations
//-----------------------------------------------------------------------------
wire [1:0] apb_slv_intf_sel;
wire [1:0] apb_slv_intf_sel_reg;
wire apbic_state;

// Registered versions of pselm* signals
wire pselm0_reg;
wire pselm1_reg;
wire pselm2_reg;
wire pselm3_reg;
wire pselm4_reg;
wire pselm5_reg;
wire pselm6_reg;
wire pselm7_reg;
wire pselm8_reg;
wire pselm9_reg;
wire pselm10_reg;
wire pselm11_reg;
wire pselm12_reg;
wire pselm13_reg;
wire pselm14_reg;
wire pselm15_reg;
wire pselm16_reg;
wire pselm17_reg;
wire pselm18_reg;
wire pselm19_reg;
wire pselm20_reg;

wire psel_rom_table_reg;

wire [11:2]  paddr_rom_table;
wire psel_rom_table;

wire [31:0] rom_data;

// Muxed responses from master interfaces
wire [31:0] prdatam;  // Data from the addressed master interface
wire preadym;         // PREADY response from the addressed master interface
wire pslverrm;        // Error response from the addressed master interface

// Address pre-decode from Slave interface block 0
// One-hot vector to indicate the addressed Master interface.
wire [20:0] paddrs0_decode;

// Access from Slave interface 0 to the ROM table
wire       rom_table_sel_0;

// Slice of address vector used for decode in Slave interface block 0
        
wire [4:0] paddrs0_msb_to_12;
// Access request raised by Slave interface 0
// Validated for accesses to default slave.
wire psel_valid_s0;

// Data response from the addressed Master interface when the Slave interface
// selected by the arbitration block is Slave interface 0
wire [31:0] prdata_arbitrated_s0;

// Ready response from the addressed Master interface when the Slave interface
// selected by the arbitration block is Slave interface 0
wire pready_arbitrated_s0;

// Error response from the addressed Master interface when the Slave interface
// selected by the arbitration block is Slave interface 0
wire pslverr_arbitrated_s0;
// Address pre-decode from Slave interface block 1
// One-hot vector to indicate the addressed Master interface.
wire [20:0] paddrs1_decode;

// Access from Slave interface 1 to the ROM table
wire       rom_table_sel_1;

// Slice of address vector used for decode in Slave interface block 1
        
wire [4:0] paddrs1_msb_to_12;
// Access request raised by Slave interface 1
// Validated for accesses to default slave.
wire psel_valid_s1;

// Data response from the addressed Master interface when the Slave interface
// selected by the arbitration block is Slave interface 1
wire [31:0] prdata_arbitrated_s1;

// Ready response from the addressed Master interface when the Slave interface
// selected by the arbitration block is Slave interface 1
wire pready_arbitrated_s1;

// Error response from the addressed Master interface when the Slave interface
// selected by the arbitration block is Slave interface 1
wire pslverr_arbitrated_s1;// paddr31 corresponding to slave interface 1
wire paddr31s1;


//-----------------------------------------------------------------------------
//
//  Main body of code
//  =================
//
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// Extract address bits
//-----------------------------------------------------------------------------
assign paddrs0_msb_to_12 = paddrs0[16:12];
assign paddrs1_msb_to_12 = paddrs1[16:12];
//-----------------------------------------------------------------------------
// For slave interfaces 1 to NUM_SLAVE_INTF-1, wire paddr31s to 0 so that
// System accesses can be blocked within Slave interfaces if dbgswen is low.
// For Slave interface 0 too (which is wired to an external debugger), system
// accesses (ie accesses with paddr31s=0) are gated by dbgswen.
// Slave interface 0 can initiate accesses with paddr31s=1 or 0, whereas
// paddr31 inputs from Slave interfaces 1 to NUM_SLAVE_INTF-1 are ignored and
// are assumed to be 0.
//-----------------------------------------------------------------------------
assign paddr31s1 = 1'b0;

//-----------------------------------------------------------------------------
// APB Slave interface 1 instantiation
//-----------------------------------------------------------------------------
  cxapbic_slv_intf_1 u_cxapbic_slv_intf_1_1
  (
  .clk                     (clk),
  .resetn                  (resetn),

  .paddrs_msb_to_12        (paddrs1_msb_to_12),
  .paddr31s                (paddr31s1),
  .psels                   (psels1),
  .penables                (penables1),

  .pslverr_arbitrated      (pslverr_arbitrated_s1),
  .pready_arbitrated       (pready_arbitrated_s1),
  .dbgswen                 (dbgswen),

  .pslverrs                (pslverrs1),
  .preadys                 (preadys1),

  .paddrs_decode           (paddrs1_decode),
  .psel_valid              (psel_valid_s1),
  .rom_table_sel           (rom_table_sel_1)
  );
        
//-----------------------------------------------------------------------------
// APB Slave interface 0 instantiation
//-----------------------------------------------------------------------------
  cxapbic_slv_intf_1 u_cxapbic_slv_intf_1_0
  (
  .clk                     (clk),
  .resetn                  (resetn),

  .paddrs_msb_to_12        (paddrs0_msb_to_12),
  .paddr31s                (paddr31s0),
  .psels                   (psels0),
  .penables                (penables0),

  .pslverr_arbitrated      (pslverr_arbitrated_s0),
  .pready_arbitrated       (pready_arbitrated_s0),
  .dbgswen                 (dbgswen),

  .pslverrs                (pslverrs0),
  .preadys                 (preadys0),

  .paddrs_decode           (paddrs0_decode),
  .psel_valid              (psel_valid_s0),
  .rom_table_sel           (rom_table_sel_0)
  );
        
//-----------------------------------------------------------------------------
// Route the de-muxed read data to the respective slave interfaces
//-----------------------------------------------------------------------------
assign prdatas0 = prdata_arbitrated_s0;
assign prdatas1 = prdata_arbitrated_s1;

//-----------------------------------------------------------------------------
// Arbiter
//-----------------------------------------------------------------------------
  cxapbic_arb_1 u_cxapbic_arb_1
  (
  .clk                     (clk),
  .resetn                  (resetn),
  
  .psel_valid_s0       (psel_valid_s0),
  
  .psel_valid_s1       (psel_valid_s1),
  
  .preadym                 (preadym),

  .apb_slv_intf_sel        (apb_slv_intf_sel),
  .apb_slv_intf_sel_reg    (apb_slv_intf_sel_reg),
  .apbic_state             (apbic_state)
  );

//-----------------------------------------------------------------------------
// Slave interface mux
//-----------------------------------------------------------------------------
  cxapbic_slv_mux_1 u_cxapbic_slv_mux_1
  (
  .clk                     (clk),
  .resetn                  (resetn),

  .rom_table_sel_0         (rom_table_sel_0),
  .paddrs0_decode          (paddrs0_decode),
  .paddrs0_11to2                 (paddrs0[11:2]),
  .pwrites0                (pwrites0),
  .pwdatas0                (pwdatas0),
    .rom_table_sel_1         (rom_table_sel_1),
  .paddrs1_decode          (paddrs1_decode),
  .paddrs1_11to2                 (paddrs1[11:2]),
  .pwrites1                (pwrites1),
  .pwdatas1                (pwdatas1),
  
  .paddr31s0               (paddr31s0),

  .apbic_state             (apbic_state),
  .apb_slv_intf_sel        (apb_slv_intf_sel),
  .pselm0                  (pselm0),
  .pselm0_reg              (pselm0_reg),
  .penablem0               (penablem0),
  .pwritem0                (pwritem0),
  .paddrm0                 (paddrm0),
  .paddr31m0               (paddr31m0),
  .pwdatam0                (pwdatam0),
  
  .pselm1                  (pselm1),
  .pselm1_reg              (pselm1_reg),
  .penablem1               (penablem1),
  .pwritem1                (pwritem1),
  .paddrm1                 (paddrm1),
  .paddr31m1               (paddr31m1),
  .pwdatam1                (pwdatam1),
  
  .pselm2                  (pselm2),
  .pselm2_reg              (pselm2_reg),
  .penablem2               (penablem2),
  .pwritem2                (pwritem2),
  .paddrm2                 (paddrm2),
  .paddr31m2               (paddr31m2),
  .pwdatam2                (pwdatam2),
  
  .pselm3                  (pselm3),
  .pselm3_reg              (pselm3_reg),
  .penablem3               (penablem3),
  .pwritem3                (pwritem3),
  .paddrm3                 (paddrm3),
  .paddr31m3               (paddr31m3),
  .pwdatam3                (pwdatam3),
  
  .pselm4                  (pselm4),
  .pselm4_reg              (pselm4_reg),
  .penablem4               (penablem4),
  .pwritem4                (pwritem4),
  .paddrm4                 (paddrm4),
  .paddr31m4               (paddr31m4),
  .pwdatam4                (pwdatam4),
  
  .pselm5                  (pselm5),
  .pselm5_reg              (pselm5_reg),
  .penablem5               (penablem5),
  .pwritem5                (pwritem5),
  .paddrm5                 (paddrm5),
  .paddr31m5               (paddr31m5),
  .pwdatam5                (pwdatam5),
  
  .pselm6                  (pselm6),
  .pselm6_reg              (pselm6_reg),
  .penablem6               (penablem6),
  .pwritem6                (pwritem6),
  .paddrm6                 (paddrm6),
  .paddr31m6               (paddr31m6),
  .pwdatam6                (pwdatam6),
  
  .pselm7                  (pselm7),
  .pselm7_reg              (pselm7_reg),
  .penablem7               (penablem7),
  .pwritem7                (pwritem7),
  .paddrm7                 (paddrm7),
  .paddr31m7               (paddr31m7),
  .pwdatam7                (pwdatam7),
  
  .pselm8                  (pselm8),
  .pselm8_reg              (pselm8_reg),
  .penablem8               (penablem8),
  .pwritem8                (pwritem8),
  .paddrm8                 (paddrm8),
  .paddr31m8               (paddr31m8),
  .pwdatam8                (pwdatam8),
  
  .pselm9                  (pselm9),
  .pselm9_reg              (pselm9_reg),
  .penablem9               (penablem9),
  .pwritem9                (pwritem9),
  .paddrm9                 (paddrm9),
  .paddr31m9               (paddr31m9),
  .pwdatam9                (pwdatam9),
  
  .pselm10                  (pselm10),
  .pselm10_reg              (pselm10_reg),
  .penablem10               (penablem10),
  .pwritem10                (pwritem10),
  .paddrm10                 (paddrm10),
  .paddr31m10               (paddr31m10),
  .pwdatam10                (pwdatam10),
  
  .pselm11                  (pselm11),
  .pselm11_reg              (pselm11_reg),
  .penablem11               (penablem11),
  .pwritem11                (pwritem11),
  .paddrm11                 (paddrm11),
  .paddr31m11               (paddr31m11),
  .pwdatam11                (pwdatam11),
  
  .pselm12                  (pselm12),
  .pselm12_reg              (pselm12_reg),
  .penablem12               (penablem12),
  .pwritem12                (pwritem12),
  .paddrm12                 (paddrm12),
  .paddr31m12               (paddr31m12),
  .pwdatam12                (pwdatam12),
  
  .pselm13                  (pselm13),
  .pselm13_reg              (pselm13_reg),
  .penablem13               (penablem13),
  .pwritem13                (pwritem13),
  .paddrm13                 (paddrm13),
  .paddr31m13               (paddr31m13),
  .pwdatam13                (pwdatam13),
  
  .pselm14                  (pselm14),
  .pselm14_reg              (pselm14_reg),
  .penablem14               (penablem14),
  .pwritem14                (pwritem14),
  .paddrm14                 (paddrm14),
  .paddr31m14               (paddr31m14),
  .pwdatam14                (pwdatam14),
  
  .pselm15                  (pselm15),
  .pselm15_reg              (pselm15_reg),
  .penablem15               (penablem15),
  .pwritem15                (pwritem15),
  .paddrm15                 (paddrm15),
  .paddr31m15               (paddr31m15),
  .pwdatam15                (pwdatam15),
  
  .pselm16                  (pselm16),
  .pselm16_reg              (pselm16_reg),
  .penablem16               (penablem16),
  .pwritem16                (pwritem16),
  .paddrm16                 (paddrm16),
  .paddr31m16               (paddr31m16),
  .pwdatam16                (pwdatam16),
  
  .pselm17                  (pselm17),
  .pselm17_reg              (pselm17_reg),
  .penablem17               (penablem17),
  .pwritem17                (pwritem17),
  .paddrm17                 (paddrm17),
  .paddr31m17               (paddr31m17),
  .pwdatam17                (pwdatam17),
  
  .pselm18                  (pselm18),
  .pselm18_reg              (pselm18_reg),
  .penablem18               (penablem18),
  .pwritem18                (pwritem18),
  .paddrm18                 (paddrm18),
  .paddr31m18               (paddr31m18),
  .pwdatam18                (pwdatam18),
  
  .pselm19                  (pselm19),
  .pselm19_reg              (pselm19_reg),
  .penablem19               (penablem19),
  .pwritem19                (pwritem19),
  .paddrm19                 (paddrm19),
  .paddr31m19               (paddr31m19),
  .pwdatam19                (pwdatam19),
  
  .pselm20                  (pselm20),
  .pselm20_reg              (pselm20_reg),
  .penablem20               (penablem20),
  .pwritem20                (pwritem20),
  .paddrm20                 (paddrm20),
  .paddr31m20               (paddr31m20),
  .pwdatam20                (pwdatam20),
  
  .paddr_rom_table         (paddr_rom_table),
  .psel_rom_table          (psel_rom_table),
  .psel_rom_table_reg      (psel_rom_table_reg)
  );


//-----------------------------------------------------------------------------
// ROM Table instantiation
//-----------------------------------------------------------------------------
  cxapbic_rom_table_1
 #(
  
  .ROM_MANUAL_ENTRY0  (ROM_MANUAL_ENTRY0),
  .ROM_MANUAL_ENTRY1  (ROM_MANUAL_ENTRY1),
  .ROM_MANUAL_ENTRY2  (ROM_MANUAL_ENTRY2),
  .ROM_MANUAL_ENTRY3  (ROM_MANUAL_ENTRY3),
  .ROM_MANUAL_ENTRY4  (ROM_MANUAL_ENTRY4),
  .ROM_MANUAL_ENTRY5  (ROM_MANUAL_ENTRY5),
  .ROM_MANUAL_ENTRY6  (ROM_MANUAL_ENTRY6),
  .ROM_MANUAL_ENTRY7  (ROM_MANUAL_ENTRY7),
  .ROM_MANUAL_ENTRY8  (ROM_MANUAL_ENTRY8),
  .ROM_MANUAL_ENTRY9  (ROM_MANUAL_ENTRY9),
  .ROM_MANUAL_ENTRY10  (ROM_MANUAL_ENTRY10),
  .ROM_MANUAL_ENTRY11  (ROM_MANUAL_ENTRY11),
  .ROM_MANUAL_ENTRY12  (ROM_MANUAL_ENTRY12),
  .ROM_MANUAL_ENTRY13  (ROM_MANUAL_ENTRY13),
  .ROM_MANUAL_ENTRY14  (ROM_MANUAL_ENTRY14),
  .ROM_MANUAL_ENTRY15  (ROM_MANUAL_ENTRY15),
  .ROM_MANUAL_ENTRY16  (ROM_MANUAL_ENTRY16),
  .ROM_MANUAL_ENTRY17  (ROM_MANUAL_ENTRY17),
  .ROM_MANUAL_ENTRY18  (ROM_MANUAL_ENTRY18),
  .ROM_MANUAL_ENTRY19  (ROM_MANUAL_ENTRY19),
  .ROM_MANUAL_ENTRY20  (ROM_MANUAL_ENTRY20),
  .ROM_MANUAL_ENTRY21  (ROM_MANUAL_ENTRY21),
  .ROM_MANUAL_ENTRY22  (ROM_MANUAL_ENTRY22),
  .ROM_MANUAL_ENTRY23  (ROM_MANUAL_ENTRY23),
  .ROM_MANUAL_ENTRY24  (ROM_MANUAL_ENTRY24),
  .ROM_MANUAL_ENTRY25  (ROM_MANUAL_ENTRY25),
  .ROM_MANUAL_ENTRY26  (ROM_MANUAL_ENTRY26),
  .ROM_MANUAL_ENTRY27  (ROM_MANUAL_ENTRY27),
  .ROM_MANUAL_ENTRY28  (ROM_MANUAL_ENTRY28),
  .ROM_MANUAL_ENTRY29  (ROM_MANUAL_ENTRY29),
  .ROM_MANUAL_ENTRY30  (ROM_MANUAL_ENTRY30),
  .ROM_MANUAL_ENTRY31  (ROM_MANUAL_ENTRY31),
  .ROM_MANUAL_ENTRY32  (ROM_MANUAL_ENTRY32),
  .ROM_MANUAL_ENTRY33  (ROM_MANUAL_ENTRY33),
  .ROM_MANUAL_ENTRY34  (ROM_MANUAL_ENTRY34),
  .ROM_MANUAL_ENTRY35  (ROM_MANUAL_ENTRY35),
  .ROM_MANUAL_ENTRY36  (ROM_MANUAL_ENTRY36),
  .ROM_MANUAL_ENTRY37  (ROM_MANUAL_ENTRY37),
  .ROM_MANUAL_ENTRY38  (ROM_MANUAL_ENTRY38),
  .ROM_MANUAL_ENTRY39  (ROM_MANUAL_ENTRY39),
  .ROM_MANUAL_ENTRY40  (ROM_MANUAL_ENTRY40),
  .ROM_MANUAL_ENTRY41  (ROM_MANUAL_ENTRY41),
  .ROM_MANUAL_ENTRY42  (ROM_MANUAL_ENTRY42),
  .ROM_MANUAL_ENTRY43  (ROM_MANUAL_ENTRY43),
  .ROM_MANUAL_ENTRY44  (ROM_MANUAL_ENTRY44),
  .ROM_MANUAL_ENTRY45  (ROM_MANUAL_ENTRY45),
  .ROM_MANUAL_ENTRY46  (ROM_MANUAL_ENTRY46),
  .ROM_MANUAL_ENTRY47  (ROM_MANUAL_ENTRY47),
  .ROM_MANUAL_ENTRY48  (ROM_MANUAL_ENTRY48),
  .ROM_MANUAL_ENTRY49  (ROM_MANUAL_ENTRY49),
  .ROM_MANUAL_ENTRY50  (ROM_MANUAL_ENTRY50),
  .ROM_MANUAL_ENTRY51  (ROM_MANUAL_ENTRY51),
  .ROM_MANUAL_ENTRY52  (ROM_MANUAL_ENTRY52),
  .ROM_MANUAL_ENTRY53  (ROM_MANUAL_ENTRY53),
  .ROM_MANUAL_ENTRY54  (ROM_MANUAL_ENTRY54),
  .ROM_MANUAL_ENTRY55  (ROM_MANUAL_ENTRY55),
  .ROM_MANUAL_ENTRY56  (ROM_MANUAL_ENTRY56),
  .ROM_MANUAL_ENTRY57  (ROM_MANUAL_ENTRY57),
  .ROM_MANUAL_ENTRY58  (ROM_MANUAL_ENTRY58),
  .ROM_MANUAL_ENTRY59  (ROM_MANUAL_ENTRY59),
  .ROM_MANUAL_ENTRY60  (ROM_MANUAL_ENTRY60),
  .ROM_MANUAL_ENTRY61  (ROM_MANUAL_ENTRY61),
  .ROM_MANUAL_ENTRY62  (ROM_MANUAL_ENTRY62),
  .ROM_MANUAL_ENTRY63  (ROM_MANUAL_ENTRY63),
  .ROM_AUTO_DISABLED   (ROM_AUTO_DISABLED)
  )
  u_cxapbic_rom_table_1
  (
  .clk                     (clk),
  .resetn                  (resetn),
  .psel_rom_table          (psel_rom_table),
  .paddr_rom_table         (paddr_rom_table),

  // targetid setting for top-level APBIC
  .targetid                (targetid),
  .rom_data                (rom_data)
  );

//-----------------------------------------------------------------------------
// Responses from the Master interfaces to the Slave interfaces
//-----------------------------------------------------------------------------
  cxapbic_resp_mux_1 u_cxapbic_resp_mux_1
  (
  .psel_rom_table_reg     (psel_rom_table_reg),

  .pselm0_reg             (pselm0_reg),
  .preadym0               (preadym0),
  .pslverrm0              (pslverrm0),
  .prdatam0               (prdatam0),
    
  .pselm1_reg             (pselm1_reg),
  .preadym1               (preadym1),
  .pslverrm1              (pslverrm1),
  .prdatam1               (prdatam1),
    
  .pselm2_reg             (pselm2_reg),
  .preadym2               (preadym2),
  .pslverrm2              (pslverrm2),
  .prdatam2               (prdatam2),
    
  .pselm3_reg             (pselm3_reg),
  .preadym3               (preadym3),
  .pslverrm3              (pslverrm3),
  .prdatam3               (prdatam3),
    
  .pselm4_reg             (pselm4_reg),
  .preadym4               (preadym4),
  .pslverrm4              (pslverrm4),
  .prdatam4               (prdatam4),
    
  .pselm5_reg             (pselm5_reg),
  .preadym5               (preadym5),
  .pslverrm5              (pslverrm5),
  .prdatam5               (prdatam5),
    
  .pselm6_reg             (pselm6_reg),
  .preadym6               (preadym6),
  .pslverrm6              (pslverrm6),
  .prdatam6               (prdatam6),
    
  .pselm7_reg             (pselm7_reg),
  .preadym7               (preadym7),
  .pslverrm7              (pslverrm7),
  .prdatam7               (prdatam7),
    
  .pselm8_reg             (pselm8_reg),
  .preadym8               (preadym8),
  .pslverrm8              (pslverrm8),
  .prdatam8               (prdatam8),
    
  .pselm9_reg             (pselm9_reg),
  .preadym9               (preadym9),
  .pslverrm9              (pslverrm9),
  .prdatam9               (prdatam9),
    
  .pselm10_reg             (pselm10_reg),
  .preadym10               (preadym10),
  .pslverrm10              (pslverrm10),
  .prdatam10               (prdatam10),
    
  .pselm11_reg             (pselm11_reg),
  .preadym11               (preadym11),
  .pslverrm11              (pslverrm11),
  .prdatam11               (prdatam11),
    
  .pselm12_reg             (pselm12_reg),
  .preadym12               (preadym12),
  .pslverrm12              (pslverrm12),
  .prdatam12               (prdatam12),
    
  .pselm13_reg             (pselm13_reg),
  .preadym13               (preadym13),
  .pslverrm13              (pslverrm13),
  .prdatam13               (prdatam13),
    
  .pselm14_reg             (pselm14_reg),
  .preadym14               (preadym14),
  .pslverrm14              (pslverrm14),
  .prdatam14               (prdatam14),
    
  .pselm15_reg             (pselm15_reg),
  .preadym15               (preadym15),
  .pslverrm15              (pslverrm15),
  .prdatam15               (prdatam15),
    
  .pselm16_reg             (pselm16_reg),
  .preadym16               (preadym16),
  .pslverrm16              (pslverrm16),
  .prdatam16               (prdatam16),
    
  .pselm17_reg             (pselm17_reg),
  .preadym17               (preadym17),
  .pslverrm17              (pslverrm17),
  .prdatam17               (prdatam17),
    
  .pselm18_reg             (pselm18_reg),
  .preadym18               (preadym18),
  .pslverrm18              (pslverrm18),
  .prdatam18               (prdatam18),
    
  .pselm19_reg             (pselm19_reg),
  .preadym19               (preadym19),
  .pslverrm19              (pslverrm19),
  .prdatam19               (prdatam19),
    
  .pselm20_reg             (pselm20_reg),
  .preadym20               (preadym20),
  .pslverrm20              (pslverrm20),
  .prdatam20               (prdatam20),
    
  .rom_data               (rom_data),

  .preadym                (preadym),
  .pslverrm               (pslverrm),
  .prdatam                (prdatam)
  );


//-----------------------------------------------------------------------------
// Demux instantiation to route responses to the selected APB Slave interface
//-----------------------------------------------------------------------------
  cxapbic_slv_demux_1 u_cxapbic_slv_demux_1
  (
  .preadym                 (preadym),
  .pslverrm                (pslverrm),
  .prdatam                 (prdatam),
  
  .pready_arbitrated_s0                 (pready_arbitrated_s0),
  .pslverr_arbitrated_s0                (pslverr_arbitrated_s0),
  .prdata_arbitrated_s0                 (prdata_arbitrated_s0),
    
  .pready_arbitrated_s1                 (pready_arbitrated_s1),
  .pslverr_arbitrated_s1                (pslverr_arbitrated_s1),
  .prdata_arbitrated_s1                 (prdata_arbitrated_s1),
    

  .apb_slv_intf_sel_reg                (apb_slv_intf_sel_reg)
  );

`ifdef ARM_ASSERT_ON
//-----------------------------------------------------------------------------
// OVL Assertions
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
// Check for one-hot on select lines
//-----------------------------------------------------------------------------

  assert_zero_one_hot #(`OVL_ERROR, 2, `OVL_ASSERT,
    "OVL Message : cxapbic_1 - Multiple Slave interfaces selected at the same time.")
      uzovl_cxapbic_1_sel_one_hot_chk
        (
         .clk         (clk),
         .reset_n     (resetn),
         .test_expr   (apb_slv_intf_sel)
        );

  assert_zero_one_hot #(`OVL_ERROR, 2, `OVL_ASSERT,
    "OVL Message : cxapbic_1 - Multiple bits in apb_slv_intf_sel_reg[] asserted at the same time.")
      uzovl_cxapbic_1_sel_reg_one_hot_chk
        (
         .clk         (clk),
         .reset_n     (resetn),
         .test_expr   (apb_slv_intf_sel_reg)
        );


  wire [21:0] pselm_one_hot_chk;
  assign pselm_one_hot_chk = {

    pselm0,
    pselm1,
    pselm2,
    pselm3,
    pselm4,
    pselm5,
    pselm6,
    pselm7,
    pselm8,
    pselm9,
    pselm10,
    pselm11,
    pselm12,
    pselm13,
    pselm14,
    pselm15,
    pselm16,
    pselm17,
    pselm18,
    pselm19,
    pselm20,
    psel_rom_table};
  assert_zero_one_hot #(`OVL_ERROR, 22, `OVL_ASSERT,
    "OVL Message : cxapbic_1 - Multiple access targets selected at the same time.")
      uzovl_cxapbic_1_pselm_one_hot_chk
        (
         .clk         (clk),
         .reset_n     (resetn),
         .test_expr   (pselm_one_hot_chk)
        );

`endif

endmodule // cxapbic_1

//-- END OF FILE --------------------------------------------------------------
