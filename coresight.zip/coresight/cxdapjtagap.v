// ----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//        (C) COPYRIGHT 2003-2013 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//  Checked In          : $Date: 2013-09-06 16:05:05 +0100 (Fri, 06 Sep 2013) $
//  Revision            : $Revision: 37058 $
//  Release             : CoreSight-SoC-TM100-r3p1-00rel0
//
// ----------------------------------------------------------------------------
//  Purpose             : JTAG-AP Top-level
//
//  JTAG-AP consists of three blocks:
//
//  cxdapjtagap_apb_if -  This block implements the interface to the DAP bus,
//                    the programmable registers and the Write and read FIFOs
//
//  cxdapjtagap_engine - This block implements the JTAG serialiser. It takes
//                    byte commands from the Write FIFO and converts these to
//                    a JTAG sequence. It optionally captures data from TDO
//                    and packs this into bytes for transfer to the read FIFO.
//
//  cxdapjtagap_mux -    This block implements the JTAG port multiplexer. Up
//                    to 8 JTAG ports can be driven at the same time through
//                    this block. Also implements the combining of rtck from
//                    multiple ports and the rtck synchronisers.
//
// ----------------------------------------------------------------------------

module cxdapjtagap (
  // Clock / Reset Pins
  input wire         dapclk,         // DAP internal APB clock
  input wire         dapclken,       // Enable term for dapclk domain
  input wire         dapresetn,      // DAP reset

  // Debug Access Port interface inputs
  input wire         dapsel,         // DAP slave select signal
  input wire         dapenable,      // Data valid strobe
  input wire         dapwrite,       // DAP Write signal
  input wire         dapabort,       // DAP access abort signal
  input wire  [7:2]  dapcaddr,       // DAP Address
  input wire [31:0]  dapwdata,       // Write data

  // Inputs from JTAG slaves
  input wire  [7:0]  csrtck,         // Return tck from JTAG slaves
  input wire  [7:0]  srstconnected,  // JTAG slaves support of SRST
  input wire  [7:0]  portconnected,  // JTAG slaves support of SRST
  input wire  [7:0]  portenabled,    // JTAG slaves support of SRST
  input wire  [7:0]  cstdo,          // TDO from JTAG slaves

  // Debug Access Port interface outputs
  output wire        dapready,       // read data ready signal
  output wire [31:0] daprdata,       // read data

  // Outputs to JTAG slaves
  output wire [7:0]  nsrstout,       // Subsystem reset to JTAG slaves
  output wire [7:0]  ncstrst,        // Test Reset to JTAG slaves
  output wire [7:0]  cstck,          // Test Clock to JTAG slaves
  output wire [7:0]  cstdi,          // Test Data Input to JTAG slaves
  output wire [7:0]  cstms           // Test Mode Select to JTAG slaves
  );

wire [7:2]              dapaddr;                // Address bus with filter to avoid
                                                //  x-propagation


// Beginning of automatic wires (for undeclared instantiated-module outputs)
wire                    dapabort_q;             // From u_cxdapjtagap_apb_if of cxdapjtagap_apb_if.v
wire [7:0]              jtag_cmd;               // From u_cxdapjtagap_apb_if of cxdapjtagap_apb_if.v
wire                    jtag_cmd_ack;           // From u_cxdapjtagap_engine of cxdapjtagap_engine.v
wire                    jtag_cmd_req;           // From u_cxdapjtagap_apb_if of cxdapjtagap_apb_if.v
wire [7:0]              psta_reg;               // From u_cxdapjtagap_apb_if of cxdapjtagap_apb_if.v
wire [7:0]              port_sel;               // From u_cxdapjtagap_apb_if of cxdapjtagap_apb_if.v
wire                    port_sel_con;           // From u_cxdapjtagap_mux of cxdapjtagap_mux.v
wire [7:0]              port_status;            // From u_cxdapjtagap_mux of cxdapjtagap_mux.v
wire                    r_fifo_ack;             // From u_cxdapjtagap_apb_if of cxdapjtagap_apb_if.v
wire                    r_fifo_req;             // From u_cxdapjtagap_engine of cxdapjtagap_engine.v
wire                    rtck_int;               // From u_cxdapjtagap_mux of cxdapjtagap_mux.v
wire                    s_rst_con;              // From u_cxdapjtagap_mux of cxdapjtagap_mux.v
wire                    s_rst_out;              // From u_cxdapjtagap_apb_if of cxdapjtagap_apb_if.v
wire                    ser_actv;               // From u_cxdapjtagap_engine of cxdapjtagap_engine.v
wire                    tck_int;                // From u_cxdapjtagap_engine of cxdapjtagap_engine.v
wire                    tdi_int;                // From u_cxdapjtagap_engine of cxdapjtagap_engine.v
wire [7:0]              tdo_byte;               // From u_cxdapjtagap_engine of cxdapjtagap_engine.v
wire                    tdo_int;                // From u_cxdapjtagap_mux of cxdapjtagap_mux.v
wire                    tmsint;                 // From u_cxdapjtagap_engine of cxdapjtagap_engine.v
wire                    trst_out;               // From u_cxdapjtagap_apb_if of cxdapjtagap_apb_if.v
// End of automatics

  cxdapjtagap_apb_if u_cxdapjtagap_apb_if

    (
     // Outputs
     .dapready                          (dapready),
     .daprdata                          (daprdata[31:0]),
     .jtag_cmd                          (jtag_cmd[7:0]),
     .jtag_cmd_req                      (jtag_cmd_req),
     .r_fifo_ack                        (r_fifo_ack),
     .port_sel                          (port_sel[7:0]),
     .s_rst_out                         (s_rst_out),
     .trst_out                          (trst_out),
     .psta_reg                          (psta_reg[7:0]),
     .dapabort_q                        (dapabort_q),
     // Inputs
     .dapclk                            (dapclk),
     .dapclken                          (dapclken),
     .dapresetn                         (dapresetn),
     .dapsel                            (dapsel),
     .dapenable                         (dapenable),
     .dapwrite                          (dapwrite),
     .dapabort                          (dapabort),
     .dapaddr                           (dapaddr[7:2]),
     .dapwdata                          (dapwdata[31:0]),
     .port_status                       (port_status[7:0]),
     .port_sel_con                      (port_sel_con),
     .s_rst_con                         (s_rst_con),
     .ser_actv                          (ser_actv),
     .jtag_cmd_ack                      (jtag_cmd_ack),
     .r_fifo_req                        (r_fifo_req),
     .tdo_byte                          (tdo_byte[7:0]));

  cxdapjtagap_engine u_cxdapjtagap_engine

    (
     // Outputs
     .tck_int                           (tck_int),
     .tmsint                            (tmsint),
     .tdi_int                           (tdi_int),
     .jtag_cmd_ack                      (jtag_cmd_ack),
     .r_fifo_req                        (r_fifo_req),
     .tdo_byte                          (tdo_byte[7:0]),
     .ser_actv                          (ser_actv),
     // Inputs
     .dapclk                            (dapclk),
     .dapclken                          (dapclken),
     .dapresetn                         (dapresetn),
     .dapabort_q                        (dapabort_q),
     .tdo_int                           (tdo_int),
     .rtck_int                          (rtck_int),
     .jtag_cmd                          (jtag_cmd[7:0]),
     .jtag_cmd_req                      (jtag_cmd_req),
     .r_fifo_ack                        (r_fifo_ack));

  cxdapjtagap_mux u_cxdapjtagap_mux

    (
     // Outputs
     .port_sel_con                      (port_sel_con),
     .port_status                       (port_status[7:0]),
     .rtck_int                          (rtck_int),
     .s_rst_con                         (s_rst_con),
     .tdo_int                           (tdo_int),
     .nsrstout                          (nsrstout[7:0]),
     .ncstrst                           (ncstrst[7:0]),
     .cstck                             (cstck[7:0]),
     .cstdi                             (cstdi[7:0]),
     .cstms                             (cstms[7:0]),
     // Inputs
     .dapclk                            (dapclk),
     .dapclken                          (dapclken),
     .dapresetn                         (dapresetn),
     .port_sel                          (port_sel[7:0]),
     .s_rst_out                         (s_rst_out),
     .tck_int                           (tck_int),
     .tdi_int                           (tdi_int),
     .tmsint                            (tmsint),
     .trst_out                          (trst_out),
     .psta_reg                          (psta_reg[7:0]),
     .cstdo                             (cstdo[7:0]),
     .portconnected                     (portconnected[7:0]),
     .portenabled                       (portenabled[7:0]),
     .csrtck                            (csrtck[7:0]),
     .srstconnected                     (srstconnected[7:0]));

//-----------------------------------------------------------------------------
// Map DAPCADDR to dapaddr
//-----------------------------------------------------------------------------
  assign dapaddr = dapcaddr;

endmodule
