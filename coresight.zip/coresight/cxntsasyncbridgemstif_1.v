

//-----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2011-2015 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//  Version and Release Control Information:
//
//  File Name           : cxntsasyncbridgemstif_xmlcfg.v.xsl
//
//  Checked In          : $Date: 2015-02-16 14:55:41 +0000 (Mon, 16 Feb 2015) $
//
//  File Revision       : $Revision: 41661 $
//
//  Release Information : CoreSight-SoC-TM100-r3p2-00rel0
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// Abstract : CoreSight NTAB - Master Interface
//-----------------------------------------------------------------------------
//
// cxntsasyncbridge - CoreSight NTAB (Narrow Timestamp Asynchronous Bridge)
// Master interface
//-----------------------------------------------------------------------------

module cxntsasyncbridgemstif_1 (

  // Clock and Reset
  input wire        clkm,
  input wire        resetmn,

  // Slave Interface
  output reg [6:0]  tsbitm,
  output reg [1:0]  tssyncm,
  input wire        tssyncreadym,

  // Slave Interface
  output wire [3:0] rd_ptr_gry_m,
  input wire [3:0]  wr_ptr_gry_m,
  
  input wire [8:0] encd_data0_m, // Encoded Data0
  input wire [8:0] encd_data1_m, // Encoded Data1
  input wire [8:0] encd_data2_m, // Encoded Data2


  input wire        lp_req_m,
  output wire       lp_ack_m

  );

//------------------------------------------------------------------------------
// Constant definitions
//------------------------------------------------------------------------------
  localparam PWRUP    = 3'b001;
  localparam PWRWAIT  = 3'b010;
  localparam PWRDN    = 3'b100;
  localparam PWRUNUS0 = 3'b000;
  localparam PWRUNUS1 = 3'b011;
  localparam PWRUNUS2 = 3'b101;
  localparam PWRUNUS3 = 3'b110;
  localparam PWRUNUS4 = 3'b111;

//----------------------------------------------------------------------------
// Wires
//----------------------------------------------------------------------------
  wire async_fifo_empty;
  wire rd_req;
  wire lp_req_m_corrupt_async;
  wire lp_req_m_sync;
  wire lp_ack_m_int_next;
  wire lp_ack_m_int_en;
  wire lp_ack_m_en;
  wire [3:0] wr_ptr_gry_m_corrupt_async;
  wire [3:0] wr_ptr_gry_m_sync;
  wire [1:0] ts_sync_m_next;
  wire roll_over;
  wire [6:0] tsbitm_next;
  wire [2:0] rd_ptr_bin;
  wire [8:0] encd_data;


//----------------------------------------------------------------------------
// Registers
//----------------------------------------------------------------------------
  reg lp_ack_m_int;
  reg lp_ack_m_q;
  reg [3:0] incr_ptr_gry;
  reg [2:0] gry_to_bin;
  reg [2:0] wr_ptr_gry_m_to_bin;
  reg [3:0] rd_ptr_gry_m_next;
  reg [3:0] rd_ptr_gry_m_q;

//============================================================================
//
// Main body of code
//
//============================================================================

//----------------------------------------------------------------------------
// Low Power Ack synchronization
//----------------------------------------------------------------------------

  // Test component to corrupt Low Power Ack going into synchroniser
  cx_cdc_corrupt_gry #(1) u_cdc_corrupt_lp_req_m
  (
      .clk       (clkm),
      .resetn    (resetmn),
      .sync      (1'b0),
      .d_async   (lp_req_m),
      .q_async   (lp_req_m_corrupt_async)
  );

  // Synchroniser to bring the Low Power Ack into the clkm domain
  cx_sync u_cdc_sync_lp_req_m
  (
      .clk       (clkm),
      .resetn    (resetmn),
      .sync_di   (lp_req_m_corrupt_async),
      .sync_do   (lp_req_m_sync)
  );

  assign lp_ack_m_int_next = (~lp_ack_m_int) ? lp_req_m_sync :
                         ~((~lp_req_m_sync) & async_fifo_empty);

  assign lp_ack_m_int_en = lp_ack_m_int_next ^ lp_ack_m_int;

  always @(posedge clkm or negedge resetmn)
    begin
      if (!resetmn) begin
          lp_ack_m_int <= 1'b1;
      end else if (lp_ack_m_int_en) begin
          lp_ack_m_int <= lp_ack_m_int_next;
      end
    end

//----------------------------------------------------------------------------
// Send the low-power acknowledge only after the slave has accepted the last
// word from the registered interface.
//----------------------------------------------------------------------------
  assign lp_ack_m_en = (lp_ack_m_int ^ lp_ack_m_q) & tssyncreadym;

  always @(posedge clkm or negedge resetmn)
    begin
      if (!resetmn) begin
          lp_ack_m_q <= 1'b1;
      end else if (lp_ack_m_en) begin
          lp_ack_m_q <= lp_ack_m_int;
      end
    end

  assign lp_ack_m = lp_ack_m_q;

//----------------------------------------------------------------------------
// Control logic generates write pointer and determines if the FIFO is empty
//----------------------------------------------------------------------------


  assign roll_over = rd_ptr_gry_m_q[2] ^ wr_ptr_gry_m_sync[2];


  assign async_fifo_empty = (~lp_ack_m_int) ? 1'b1 :
                            ((gry_to_bin == wr_ptr_gry_m_to_bin) & ~roll_over);

//----------------------------------------------------------------------------
// Read pointer generation including binary to grey conversion
//----------------------------------------------------------------------------

//------------------------------------------------------------------------------
// increments in grey sequence
//------------------------------------------------------------------------------
  always @(*)
    begin
    incr_ptr_gry = rd_ptr_gry_m_q;

    case (rd_ptr_gry_m_q)
      4'd0 : incr_ptr_gry = 4'd1;
      4'd1 : incr_ptr_gry = 4'd3;

      4'd3 : incr_ptr_gry = 4'd7;
      4'd7 : incr_ptr_gry = 4'd6;
      4'd6 : incr_ptr_gry = 4'd4;
      4'd4 : incr_ptr_gry = 4'd0;

      4'd2,
      4'd5,
      4'd8,
      4'd9,
      4'd10,
      4'd11,
      4'd12,
      4'd13,
      4'd14,
      4'd15 : incr_ptr_gry = {4{1'b0}};

      default : incr_ptr_gry = {4{1'bx}};
    endcase
    end

  assign rd_req = ~async_fifo_empty & lp_ack_m_int & tssyncreadym;

  always @(*)
  begin
    rd_ptr_gry_m_next = rd_ptr_gry_m_q;

    if (~lp_ack_m_q) begin
      rd_ptr_gry_m_next = 4'd0;
    end else if (~async_fifo_empty & rd_req) begin
      rd_ptr_gry_m_next = incr_ptr_gry;
    end
  end

  always @(posedge clkm or negedge resetmn)
    begin
      if (!resetmn)
        rd_ptr_gry_m_q <= {4{1'b0}};
      else
        rd_ptr_gry_m_q <= rd_ptr_gry_m_next;
    end

  assign rd_ptr_gry_m = rd_ptr_gry_m_q;

//----------------------------------------------------------------------------
// Write pointer generation
//----------------------------------------------------------------------------

  // Test component to corrupt Read Pointer going into synchroniser
  cx_cdc_corrupt_gry #(4) u_cdc_corrupt_wr_ptr_gry_m
  (
      .clk       (clkm),
      .resetn    (resetmn),
      .sync      (1'b0),
      .d_async   (wr_ptr_gry_m),
      .q_async   (wr_ptr_gry_m_corrupt_async)
  );

  // Synchronisers to bring the Read Pointer into the clock domain
  cx_sync u_cdc_sync_wr_ptr_gry_m0
  (
      .clk       (clkm),
      .resetn    (resetmn),
      .sync_di   (wr_ptr_gry_m_corrupt_async[0]),
      .sync_do   (wr_ptr_gry_m_sync[0])
  );
  cx_sync u_cdc_sync_wr_ptr_gry_m1
  (
      .clk       (clkm),
      .resetn    (resetmn),
      .sync_di   (wr_ptr_gry_m_corrupt_async[1]),
      .sync_do   (wr_ptr_gry_m_sync[1])
  );
  cx_sync u_cdc_sync_wr_ptr_gry_m2
  (
      .clk       (clkm),
      .resetn    (resetmn),
      .sync_di   (wr_ptr_gry_m_corrupt_async[2]),
      .sync_do   (wr_ptr_gry_m_sync[2])
  );
  cx_sync u_cdc_sync_wr_ptr_gry_m3
  (
      .clk       (clkm),
      .resetn    (resetmn),
      .sync_di   (wr_ptr_gry_m_corrupt_async[3]),
      .sync_do   (wr_ptr_gry_m_sync[3])
  );

//------------------------------------------------------------------------------
// generate binary sequence given a grey sequence of write pointer
//------------------------------------------------------------------------------
  always @(*)
    begin

    wr_ptr_gry_m_to_bin = 3'd0;

    case (wr_ptr_gry_m_sync)
    4'd0 : wr_ptr_gry_m_to_bin = 3'd0;
    4'd1 : wr_ptr_gry_m_to_bin = 3'd1;

    4'd3 : wr_ptr_gry_m_to_bin = 3'd2;
    4'd7 : wr_ptr_gry_m_to_bin = 3'd0;
    4'd6 : wr_ptr_gry_m_to_bin = 3'd1;
    4'd4 : wr_ptr_gry_m_to_bin = 3'd2;

    4'd2,
    4'd5,
    4'd8,
    4'd9,
    4'd10,
    4'd11,
    4'd12,
    4'd13,
    4'd14,
    4'd15 : wr_ptr_gry_m_to_bin = {3{1'b0}};

    default : wr_ptr_gry_m_to_bin = {3{1'bx}};
    endcase
  end

//----------------------------------------------------------------------------
// Read Data muxing and Read data extraction
//----------------------------------------------------------------------------
  
  // Bit 0
  cxntsasyncbridge_cdc_comb_mux4 u_bit_0_lvl_0_mux_0 (
  .din1_async (encd_data0_m[0]),
  .din2_async (encd_data1_m[0]),
  .din3_async (encd_data2_m[0]),
 .din4_async (1'b0),

  .sel        (rd_ptr_bin[1:0]),
  .dout_async (encd_data[0]));
    
  // Bit 1
  cxntsasyncbridge_cdc_comb_mux4 u_bit_1_lvl_0_mux_0 (
  .din1_async (encd_data0_m[1]),
  .din2_async (encd_data1_m[1]),
  .din3_async (encd_data2_m[1]),
 .din4_async (1'b0),

  .sel        (rd_ptr_bin[1:0]),
  .dout_async (encd_data[1]));
    
  // Bit 2
  cxntsasyncbridge_cdc_comb_mux4 u_bit_2_lvl_0_mux_0 (
  .din1_async (encd_data0_m[2]),
  .din2_async (encd_data1_m[2]),
  .din3_async (encd_data2_m[2]),
 .din4_async (1'b0),

  .sel        (rd_ptr_bin[1:0]),
  .dout_async (encd_data[2]));
    
  // Bit 3
  cxntsasyncbridge_cdc_comb_mux4 u_bit_3_lvl_0_mux_0 (
  .din1_async (encd_data0_m[3]),
  .din2_async (encd_data1_m[3]),
  .din3_async (encd_data2_m[3]),
 .din4_async (1'b0),

  .sel        (rd_ptr_bin[1:0]),
  .dout_async (encd_data[3]));
    
  // Bit 4
  cxntsasyncbridge_cdc_comb_mux4 u_bit_4_lvl_0_mux_0 (
  .din1_async (encd_data0_m[4]),
  .din2_async (encd_data1_m[4]),
  .din3_async (encd_data2_m[4]),
 .din4_async (1'b0),

  .sel        (rd_ptr_bin[1:0]),
  .dout_async (encd_data[4]));
    
  // Bit 5
  cxntsasyncbridge_cdc_comb_mux4 u_bit_5_lvl_0_mux_0 (
  .din1_async (encd_data0_m[5]),
  .din2_async (encd_data1_m[5]),
  .din3_async (encd_data2_m[5]),
 .din4_async (1'b0),

  .sel        (rd_ptr_bin[1:0]),
  .dout_async (encd_data[5]));
    
  // Bit 6
  cxntsasyncbridge_cdc_comb_mux4 u_bit_6_lvl_0_mux_0 (
  .din1_async (encd_data0_m[6]),
  .din2_async (encd_data1_m[6]),
  .din3_async (encd_data2_m[6]),
 .din4_async (1'b0),

  .sel        (rd_ptr_bin[1:0]),
  .dout_async (encd_data[6]));
    
  // Bit 7
  cxntsasyncbridge_cdc_comb_mux4 u_bit_7_lvl_0_mux_0 (
  .din1_async (encd_data0_m[7]),
  .din2_async (encd_data1_m[7]),
  .din3_async (encd_data2_m[7]),
 .din4_async (1'b0),

  .sel        (rd_ptr_bin[1:0]),
  .dout_async (encd_data[7]));
    
  // Bit 8
  cxntsasyncbridge_cdc_comb_mux4 u_bit_8_lvl_0_mux_0 (
  .din1_async (encd_data0_m[8]),
  .din2_async (encd_data1_m[8]),
  .din3_async (encd_data2_m[8]),
 .din4_async (1'b0),

  .sel        (rd_ptr_bin[1:0]),
  .dout_async (encd_data[8]));
    

//------------------------------------------------------------------------------
// generate binary sequence given a grey sequence of read pointer
//------------------------------------------------------------------------------
  always @(*)
    begin

    gry_to_bin = 3'd0;

    case (rd_ptr_gry_m_q)
    4'd0 : gry_to_bin = 3'd0;
    4'd1 : gry_to_bin = 3'd1;

    4'd3 : gry_to_bin = 3'd2;
    4'd7 : gry_to_bin = 3'd0;
    4'd6 : gry_to_bin = 3'd1;
    4'd4 : gry_to_bin = 3'd2;

    4'd2,
    4'd5,
    4'd8,
    4'd9,
    4'd10,
    4'd11,
    4'd12,
    4'd13,
    4'd14,
    4'd15 : gry_to_bin = {3{1'b0}};

    default : gry_to_bin = {3{1'bx}};
    endcase
  end

  assign rd_ptr_bin = gry_to_bin;

  assign tsbitm_next = {7{~async_fifo_empty}} & encd_data[6:0];

  always @(posedge clkm or negedge resetmn)
    begin
      if (!resetmn)
        tsbitm <= {7{1'b0}};
      else if (tssyncreadym)
        tsbitm <= tsbitm_next;
    end

  assign ts_sync_m_next = ({2{~async_fifo_empty}} & encd_data[8:7]);

  always @(posedge clkm or negedge resetmn)
    begin
      if (!resetmn)
        tssyncm <= {2{1'b0}};
      else if (tssyncreadym)
        tssyncm <= ts_sync_m_next;
    end

//----------------------------------------------------------------------------
// ASSERTIONS
//----------------------------------------------------------------------------

`ifdef ARM_ASSERT_ON

//-----------------------------------------------------------------------------
// Ensure that read-pointer is reset only when it has read all the words in fifo
//-----------------------------------------------------------------------------
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxntsasyncbridge - After low-power request is asserted - Read pointer reset before all words have been read")
      uzovl_cxntsasyncbridge_fifo_sysreq_mst
        (
         .clk         (clkm),
         .reset_n     (resetmn),
         .test_expr   (~lp_ack_m_int &
                       ~async_fifo_empty &
                       (rd_ptr_gry_m_q == 4'd0))
        );

`endif // ARM_ASSERT_ON

endmodule
