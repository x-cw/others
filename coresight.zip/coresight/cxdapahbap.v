// ----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//        (C) COPYRIGHT 2003-2013 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//  Checked In          : $Date: 2013-09-06 16:05:05 +0100 (Fri, 06 Sep 2013) $
//  Revision            : $Revision: 37058 $
//  Release             : CoreSight-SoC-TM100-r3p1-00rel0
//
//-----------------------------------------------------------------------------
// Purpose : Debug Access Port AHB Access Port (DAPAHBAP) - Top Level Block
//-----------------------------------------------------------------------------
//
// DAPAHBAP - Debug Access Port AHB Access Port
// --------------------------------------------
//
// Debug Access Port AHB Access Port component provides an AHB-Lite interface to
// a System On Chip (SOC).
//
// DAPAHBAP.v
// -----------
//
// DAPAHBAP.v provides the instantiations of all modules for the DAPAHBAP.
//
// Instantiated blocks
// -------------------
//
// cxdapahbap_slv.v     - DAP Slave  Interface Module
// cxdapahbap_mst.v     - AHB Master Interface Module
// cxdapahbap_ahb_sync.v - AHB Domain Synchronizer Module
// cxdapahbap_dap_sync.v - DAP Domain Synchronizer Module
//
// Note :     hclk, hclken and hresetn are tied off to dapclk, dapclken and
//            dapresetn.
//-----------------------------------------------------------------------------

module cxdapahbap
  (
  //----------------------------------------------------------------------------
  // Inputs
  //----------------------------------------------------------------------------
  input wire         dapclk,         // DAP clock
  input wire         dapclken,       // DAP clock enable
  input wire         dapresetn,      // DAP asynchronous reset active low

  input wire         dbgen,          // Debug enable for AHB transfers
  input wire         spiden,         // TrustZone enable for secure transfers

  input wire         dapsel,         // DAP select
  input wire         dapenable,      // DAP Enable
  input wire         dapwrite,       // DAP write or read
  input wire         dapabort,       // DAP abort
  input wire [7:2]   dapcaddr,       // DAP address bus
  input wire [31:0]  dapwdata,       // DAP write data bus

  input wire         hreadym,        // AHB slave ready
  input wire [1:0]   hrespm,         // AHB slave response
  input wire [31:0]  hrdatam,        // AHB read data bus
  input wire [31:0]  rombaseaddr,    // AHB ROM Base address, tie-off

  //----------------------------------------------------------------------------
  // Outputs
  //----------------------------------------------------------------------------
  output wire        dapready,       // DAP slave ready
  output wire        dapslverr,      // DAP slave error
  output wire [31:0] daprdata,       // DAP read data bus

  output wire        hwritem,        // AHB write or read
  output wire        hlockm,         // AHB lock transfer
  output wire [1:0]  htransm,        // AHB transfer type
  output wire [2:0]  hsizem,         // AHB transfer size
  output wire [2:0]  hburstm,        // AHB burst type
  output wire [3:0]  hbstrbm,        // AHB byte lane strobe
  output wire [6:0]  hprotm,         // AHB protection type
  output wire [31:0] haddrm,         // AHB address bus
  output wire [31:0] hwdatam         // AHB write data bus
  );

  //----------------------------------------------------------------------------
  // Wire declarations
  //----------------------------------------------------------------------------
  wire                  dbgen_sync;
  wire                  spid_en_sync;
  wire                  ahb_rd_wr_soc;
  wire                  ahb_err_resp_dbg;
  wire                  ahb_inc_pack_soc;
  wire [1:0]            ahb_size_soc;
  wire [2:0]            ahb_state_dbg;
  wire [3:0]            dap_state_soc;
  wire [4:0]            ahb_prot_soc_bits4to0;
  wire                  ahb_prot_soc_bit6;
  wire [31:0]           ahb_addr_soc;
  wire [31:0]           ahb_wr_data_soc;
  wire [31:0]           ahb_rd_data_dbg;

wire [7:2] dapaddr; // DAPBUS Address bus

  // Beginning of automatic wires (for undeclared instantiated-module outputs)
  wire [31:0]           ahb_addr;                // From u_dapahbap_slv of cxdapahbap_slv.v
  wire                  ahb_err_resp;             // From u_dapahbap_mst of cxdapahbap_mst.v
  wire                  ahb_inc_pack;             // From u_dapahbap_slv of cxdapahbap_slv.v
  wire [4:0]            ahb_prot_bits4to0;                // From u_dapahbap_slv of cxdapahbap_slv.v
  wire                  ahb_prot_bit6;                // From u_dapahbap_slv of cxdapahbap_slv.v
  wire [31:0]           ahb_rd_data;              // From u_dapahbap_mst of cxdapahbap_mst.v
  wire                  ahb_rd_wr;                // From u_dapahbap_slv of cxdapahbap_slv.v
  wire [1:0]            ahb_size;                // From u_dapahbap_slv of cxdapahbap_slv.v
  wire [2:0]            ahb_state;               // From u_dapahbap_mst of cxdapahbap_mst.v
  wire [2:0]            ahb_state_sync;           // From u_dapahbap_dap_sync of cxdapahbap_dap_sync.v
  wire [31:0]           ahb_wr_data;              // From u_dapahbap_slv of cxdapahbap_slv.v
  wire [3:0]            dap_state;               // From u_dapahbap_slv of cxdapahbap_slv.v
  wire [3:0]            dap_state_sync;           // From u_dapahbap_ahb_sync of cxdapahbap_ahb_sync.v
  // End of automatics

//-----------------------------------------------------------------------------
//
// Main body of code
// =================
//
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// hclk, hclken and hresetn are tied off to dapclk, dapclken and dapresetn.
// This is to ensure that all clock and power domain crossing are done using
// appropriate bus Sync and Async bridges.
// hclk    = dapclk;
// hclken  = dapclken;
// hresetn = dapresetn;
//-----------------------------------------------------------------------------

  //----------------------------------------------------------------------------
  // AHB-AP DAP Slave Interface Module
  //----------------------------------------------------------------------------
  cxdapahbap_slv u_cxdapahbap_slv
    (
     // Inputs
     .ahb_err_resp                      (ahb_err_resp_dbg),
     .ahb_rd_data                       (ahb_rd_data_dbg[31:0]),

     // Outputs
     .dapready                          (dapready),
     .dapslverr                         (dapslverr),
     .daprdata                          (daprdata[31:0]),
     .ahb_rd_wr                         (ahb_rd_wr),
     .ahb_inc_pack                      (ahb_inc_pack),
     .ahb_size                          (ahb_size[1:0]),
     .dap_state                         (dap_state[3:0]),
     .ahb_prot_bit6                     (ahb_prot_bit6),
     .ahb_prot_bits4to0                 (ahb_prot_bits4to0[4:0]),
     .ahb_addr                          (ahb_addr[31:0]),
     .ahb_wr_data                       (ahb_wr_data[31:0]),
     // Inputs
     .dapclk                            (dapclk),
     .dapclken                          (dapclken),
     .dapresetn                         (dapresetn),
     .dapsel                            (dapsel),
     .dapenable                         (dapenable),
     .dapwrite                          (dapwrite),
     .dapabort                          (dapabort),
     .dapaddr                           (dapaddr[7:2]),
     .dapwdata                          (dapwdata[31:0]),
     .ahb_state_sync                    (ahb_state_sync[2:0]),
     .ahb_rom_addr                      (rombaseaddr),
     .dbgen_sync                        (dbgen_sync),
     .spid_en_sync                      (spid_en_sync));

  //----------------------------------------------------------------------------
  // AHB-AP AHB Master Interface Module
  //----------------------------------------------------------------------------
  cxdapahbap_mst u_cxdapahbap_mst
    (
     // Inputs
     .ahb_rd_wr                         (ahb_rd_wr_soc),
     .ahb_inc_pack                      (ahb_inc_pack_soc),
     .ahb_size                          (ahb_size_soc[1:0]),
     .ahb_prot_bit6                     (ahb_prot_soc_bit6),
     .ahb_prot_bits4to0                 (ahb_prot_soc_bits4to0),
     .ahb_addr                          (ahb_addr_soc[31:0]),
     .ahb_wr_data                       (ahb_wr_data_soc[31:0]),

     // Outputs
     .hwritem                           (hwritem),
     .hlockm                            (hlockm),
     .htransm                           (htransm[1:0]),
     .hsizem                            (hsizem[2:0]),
     .hburstm                           (hburstm[2:0]),
     .hbstrbm                           (hbstrbm[3:0]),
     .hprotm                            (hprotm[6:0]),
     .haddrm                            (haddrm[31:0]),
     .hwdatam                           (hwdatam[31:0]),
     .ahb_err_resp                      (ahb_err_resp),
     .ahb_state                         (ahb_state[2:0]),
     .ahb_rd_data                       (ahb_rd_data[31:0]),
     // Inputs
     .hclk                              (dapclk),
     .hclken                            (dapclken),
     .hresetn                           (dapresetn),
     .hreadym                           (hreadym),
     .hrespm                            (hrespm[1:0]),
     .hrdatam                           (hrdatam[31:0]),
     .dap_state_sync                    (dap_state_sync[3:0]));

  //----------------------------------------------------------------------------
  // AHB-AP without clamping
  //----------------------------------------------------------------------------
  assign ahb_rd_wr_soc         = ahb_rd_wr;
  assign ahb_inc_pack_soc      = ahb_inc_pack;
  assign ahb_size_soc          = ahb_size;
  assign dap_state_soc         = dap_state;
  assign ahb_prot_soc_bit6     = ahb_prot_bit6;
  assign ahb_prot_soc_bits4to0 = ahb_prot_bits4to0;
  assign ahb_wr_data_soc       = ahb_wr_data;
  assign ahb_addr_soc          = ahb_addr;
  assign ahb_err_resp_dbg      = ahb_err_resp;
  assign ahb_state_dbg         = ahb_state;
  assign ahb_rd_data_dbg       = ahb_rd_data;

  //----------------------------------------------------------------------------
  // AHB-AP dapclk Synchronizer module
  //----------------------------------------------------------------------------
  cxdapahbap_dap_sync u_cxdapahbap_dap_sync
    (

     // Outputs
     .dbgen_sync                        (dbgen_sync),
     .spid_en_sync                      (spid_en_sync),
     .ahb_state_sync                    (ahb_state_sync[2:0]),
     // Inputs
     .dapclk                            (dapclk),
     .dapclken                          (dapclken),
     .dapresetn                         (dapresetn),
     .dbgen                             (dbgen),
     .spiden                            (spiden),
     .ahb_state_dbg                     (ahb_state_dbg[2:0]));

  //----------------------------------------------------------------------------
  // AHB-AP hclk Synchronizer module
  //----------------------------------------------------------------------------
  cxdapahbap_ahb_sync u_cxdapahbap_ahb_sync
    (

     // Outputs
     .dap_state_sync                    (dap_state_sync[3:0]),
     // Inputs
     .hclk                              (dapclk),
     .hclken                            (dapclken),
     .hresetn                           (dapresetn),
     .dap_state_soc                     (dap_state_soc[3:0]));

//-----------------------------------------------------------------------------
// Map dapcaddr to dapaddr
//-----------------------------------------------------------------------------
  assign dapaddr = dapcaddr;

`ifdef ARM_ASSERT_ON

  //----------------------------------------------------------------------------
  // OVL Assertions
  //----------------------------------------------------------------------------
  assert_one_hot #(`OVL_ERROR, 4, `OVL_ASSERT,
    "cxdapahbap_mst: dap_state_sync should be onehot")
      dapahbap_mst_dapstatesync_onehot
        (
         .clk       (dapclk),
         .reset_n   (dapresetn),
         .test_expr (dap_state_sync)
        );

`endif //`ifdef ARM_ASSERT_ON

endmodule // cxdapahbap
