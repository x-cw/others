
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//  
//            (C) COPYRIGHT 2009-2010 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//    Checked In :  2010-06-14 15:57:42 +0530 (Mon, 14 Jun 2010) 
//    Revision   :  8088 
//    Release    : TM961-BU-50000-r0p0-00rel0
//
//-----------------------------------------------------------------------------
// Purpose : CoreSight Trace Memory Controller (CXTMC) - ATB Synchronisation
//            request generator. This block generates the SYNCREQS output for 
//            the TMC
//-----------------------------------------------------------------------------

module cxtmc_sync_req
  #(parameter CXTMC_ATB_DATA_WIDTH  = 32,
    parameter CXTMC_ATBM_AXIM_CFG  = 1)
  //---------------------------------------------------------------------------
  // Port Declarations
  //---------------------------------------------------------------------------
  (
  // Inputs
  input wire       cxtmc_clk,          // Clock
  input wire       RESETn,             // Reset for the clock domain
  input wire       it_ctrl,            // Integration Mode Control
  input wire       it_atb_ctr_2_wr_en, // Write enable for ITATBCTR2 register
  input wire       apb_wdata_bit2,     // APB Write data for integ reg
  input wire [4:0] pscr,               // PSCR register
  input wire       SYNCREQM,           // Sync Request from ATB Master port
  input wire       pscr_ctr_decr_pulse,// Indication to dcrement sync counter
  input wire       ctl_trace_capt_en,  // Indication that TMC is enabled
  input wire       ctl_trace_capt_en_0_1,
                                       // Indication of rising edge of
                                       // ctl_trace_capt_en
  input wire       ft_running_p0,      // Indication that formatter is active
  // Outputs
  output reg       SYNCREQS            // SYNCREQ driven on ATB Slave
  );

  //----------------------------------------------------------------------------
  // Constants definitions
  //----------------------------------------------------------------------------
  `include "cxtmc_constants.v"

  //----------------------------------------------------------------------------
  // This PSCR_PAD parameter defines the number of zero's to be padded for the
  // pscr counter. Since pscr counter is incremented based on the memory/axi
  // transactions, whose width is configurable, hence the number of bits of
  // zero's to be padded also varies.
  //----------------------------------------------------------------------------
  localparam PSCR_PAD =
         (CXTMC_ATB_DATA_WIDTH == 32) ?
           ((CXTMC_ATBM_AXIM_CFG == CXTMC_CFG_ETR) ? 2 : 3) :
             ((CXTMC_ATB_DATA_WIDTH == 64) ?
               ((CXTMC_ATBM_AXIM_CFG == CXTMC_CFG_ETR) ? 3 : 4) :
                 ((CXTMC_ATBM_AXIM_CFG == CXTMC_CFG_ETR) ? 4 : 5));

  //----------------------------------------------------------------------------
  // PSCR_WIDTH defines the width of the internal pscr counter. Since the
  // decrementing logic is on AXI width/memory width boundary which are
  // configurable, hence there will be redundant flops if we take
  // complete [27:0] as the counter width. This parameter helps is removing
  // those redundant flops.
  //----------------------------------------------------------------------------
  localparam PSCR_WIDTH =
    (CXTMC_ATB_DATA_WIDTH == 32) ?
       ((CXTMC_ATBM_AXIM_CFG == CXTMC_CFG_ETR) ? 26 : 25) :
         ((CXTMC_ATB_DATA_WIDTH == 64) ?
           ((CXTMC_ATBM_AXIM_CFG == CXTMC_CFG_ETR) ? 25 : 24) :
             ((CXTMC_ATBM_AXIM_CFG == CXTMC_CFG_ETR) ? 24 : 23));

  //---------------------------------------------------------------------------
  // Reg declarations
  //---------------------------------------------------------------------------

  wire [27:0] pscr_ctr;           // Running sync counter
  reg [PSCR_WIDTH-1:0] pscr_ctr_int;
                                  // Internal pscr counter which has redundant
                                  // flops removed
  wire [PSCR_WIDTH-1:0] nxt_pscr_ctr_int;
                                  // D-Input of pscr_ctr_int
  reg        sync_flag_int_reg;   // Internal sync flag
  reg        sync_flag_ext_reg;   // External sync flag
  reg        syncreqm_reg_etf;    // Registered version of SYNCREQM generated
                                  // in ETF configuration 

  //---------------------------------------------------------------------------
  // Wire declarations
  //---------------------------------------------------------------------------

  wire        nxt_syncreqs;       // D-input of SYNCREQS
  wire        syncreqs_wr_en;     // Clock enable for SYNCREQS flop
  wire [27:0] pscr_reload_value;  // Synch counter reload value
  wire [27:0] nxt_pscr_ctr;       // D-Input of pscr_ctr
  wire        pscr_ctr_reload;    // Indication to reload the counter
  wire        int_sync_req;       // Internal sync req generated on counter
                                  // expiry
  wire        ext_sync_req;       // External sync req generated when ATB master
                                  // interface requests for synchronization
  wire        nxt_sync_flag_int;  // D-Input of sync_flag_int_reg
  wire        sync_flag_int_we;   // Clock enable for sync_flag_int_reg
  wire        nxt_sync_flag_ext;  // D-Input of sync_flag_ext_reg
  wire        sync_flag_ext_we;   // Clock enable for sync_flag_ext_reg
  wire        sync_combined;      // Combining two sync sources
  wire [27:0] pscr_decr_value;    // Decrement count for sync counter
  wire        pscr_ctr_decr_reload;
                                  // Indication that while reloading the
                                  // counter it has to decremented and then
                                  // reloaded

  wire        pscr_en;            // Indication that sync counter logic is
                                  // enabled
  wire        pscr_ctr_decr;      // Indication to decrement sync counter
  wire        syncreqm_gated;     // Gated with ft_running_p0
  wire        syncreqm_reg;       // Registered version of SYNCREQM

  // --------------------------------------------------------------------------
  //
  //  Main body of code
  //  =================
  //
  // --------------------------------------------------------------------------

  // ---------------------------------------------------------------------------
  // Enable periodic synchronisation counter if the PSCR register is programmed
  // within a valid range and Trace Capture is enabled.
  // ---------------------------------------------------------------------------
  assign pscr_en = ((pscr > 5'h06) & (pscr < 5'h1C) &
                    ctl_trace_capt_en);

  // ---------------------------------------------------------------------------
  // Sync counter reload value.
  // Depending on the valid range programmed into 5 bit register, the counter
  // is loaded with a value after shifting '1' left by the count programmed.
  // ---------------------------------------------------------------------------
  assign pscr_reload_value = {28{pscr == 5'h07}} & 28'h0000080 |
                             {28{pscr == 5'h08}} & 28'h0000100 |
                             {28{pscr == 5'h09}} & 28'h0000200 |
                             {28{pscr == 5'h0A}} & 28'h0000400 |
                             {28{pscr == 5'h0B}} & 28'h0000800 |
                             {28{pscr == 5'h0C}} & 28'h0001000 |
                             {28{pscr == 5'h0D}} & 28'h0002000 |
                             {28{pscr == 5'h0E}} & 28'h0004000 |
                             {28{pscr == 5'h0F}} & 28'h0008000 |
                             {28{pscr == 5'h10}} & 28'h0010000 |
                             {28{pscr == 5'h11}} & 28'h0020000 |
                             {28{pscr == 5'h12}} & 28'h0040000 |
                             {28{pscr == 5'h13}} & 28'h0080000 |
                             {28{pscr == 5'h14}} & 28'h0100000 |
                             {28{pscr == 5'h15}} & 28'h0200000 |
                             {28{pscr == 5'h16}} & 28'h0400000 |
                             {28{pscr == 5'h17}} & 28'h0800000 |
                             {28{pscr == 5'h18}} & 28'h1000000 |
                             {28{pscr == 5'h19}} & 28'h2000000 |
                             {28{pscr == 5'h1A}} & 28'h4000000 |
                             {28{pscr == 5'h1B}} & 28'h8000000;

  // --------------------------------------------------------------------------
  // PSCR decrement value. The counter is decremented in terms of byte and is
  // dependent on the AXI/memory width.
  // --------------------------------------------------------------------------
generate
  if (CXTMC_ATB_DATA_WIDTH == 32)
    begin
      if (CXTMC_ATBM_AXIM_CFG == CXTMC_CFG_ETR)
        assign pscr_decr_value = {{25{1'b0}}, 3'b100};
      else
        assign pscr_decr_value = {{24{1'b0}}, 4'b1000};
    end
  else if (CXTMC_ATB_DATA_WIDTH == 64)
    begin
      if (CXTMC_ATBM_AXIM_CFG == CXTMC_CFG_ETR)
        assign pscr_decr_value = {{24{1'b0}}, 4'b1000};
      else
        assign pscr_decr_value = {{23{1'b0}}, 5'b10000};
    end
  else
    begin
      if (CXTMC_ATBM_AXIM_CFG == CXTMC_CFG_ETR)
        assign pscr_decr_value = {{23{1'b0}}, 5'b10000};
      else
        assign pscr_decr_value = {{22{1'b0}}, 6'b100000};
    end
endgenerate

  // --------------------------------------------------------------------------
  // Sync counter realization:
  // Counter reloaded when the counter downcounts to zero or when the device is
  // enabled (provided the value programmed into this counter is within the
  // valid range).
  // --------------------------------------------------------------------------
  assign pscr_ctr_reload = pscr_en & (ctl_trace_capt_en_0_1 | int_sync_req);
  assign pscr_ctr_decr = pscr_ctr_decr_pulse & (|pscr_ctr);
  assign pscr_ctr_decr_reload = pscr_ctr_decr_pulse & int_sync_req  & pscr_en;
  assign nxt_pscr_ctr = (pscr_ctr_reload && !pscr_ctr_decr_reload) ?
                           pscr_reload_value :
                           (pscr_ctr_reload && pscr_ctr_decr_reload) ?
                             pscr_reload_value - pscr_decr_value :
                         (pscr_ctr_decr) ? pscr_ctr - pscr_decr_value :
                           pscr_ctr;

  // --------------------------------------------------------------------------
  // Internal counter to ensure that the required number of memory elements is
  // present.
  // --------------------------------------------------------------------------
  assign nxt_pscr_ctr_int = nxt_pscr_ctr[27:PSCR_PAD];
  always @(posedge cxtmc_clk)
    begin
      pscr_ctr_int <= nxt_pscr_ctr_int;
    end

  // --------------------------------------------------------------------------
  // pscr_ctr is full 28 bit counter
  // --------------------------------------------------------------------------
  assign pscr_ctr = {pscr_ctr_int, {PSCR_PAD{1'b0}}};

  // --------------------------------------------------------------------------
  // Internal sync request generation
  // --------------------------------------------------------------------------
  assign int_sync_req = ~(|pscr_ctr[27:0]) & pscr_en & ~ctl_trace_capt_en_0_1;

generate 
  if (CXTMC_ATBM_AXIM_CFG == CXTMC_CFG_ETF)
    begin
      // External sync request (only when TMC is enabled)
      assign syncreqm_gated = SYNCREQM & ft_running_p0;
    
      // Register external sync request (SYNCREQM input) for timing purpose
      always @(posedge cxtmc_clk or negedge RESETn)
        begin
          if (!RESETn)
            syncreqm_reg_etf <= 1'b0;
          else
            syncreqm_reg_etf <= syncreqm_gated;
        end
      assign syncreqm_reg = syncreqm_reg_etf;
    end
  else // ETB/ETR configurations
    begin
      assign syncreqm_reg = 1'b0;
    end
endgenerate

  assign ext_sync_req = syncreqm_reg;

  // Internal and external sync request combining logic
  // Flags:
  //   flag is set upon request active
  //   flag is cleared when combined sync is generated after request from
  //   another source
  assign nxt_sync_flag_int = int_sync_req | ctl_trace_capt_en_0_1;
  assign sync_flag_int_we  = int_sync_req |
                             (ext_sync_req & sync_flag_ext_reg) |
                             ctl_trace_capt_en_0_1;

  always @(posedge cxtmc_clk or negedge RESETn)
    begin
      if (!RESETn)
        sync_flag_int_reg <= 1'b0;
      else if (sync_flag_int_we)
        sync_flag_int_reg <= nxt_sync_flag_int;
    end

  // --------------------------------------------------------------------------
  // External sync request generation
  // --------------------------------------------------------------------------
  assign nxt_sync_flag_ext = ext_sync_req | ctl_trace_capt_en_0_1;
  assign sync_flag_ext_we  = ext_sync_req |
                             (int_sync_req & sync_flag_int_reg) |
                             ctl_trace_capt_en_0_1;

  always @(posedge cxtmc_clk or negedge RESETn)
    begin
      if (!RESETn)
        sync_flag_ext_reg <= 1'b0;
      else if (sync_flag_ext_we)
        sync_flag_ext_reg <= nxt_sync_flag_ext;
    end

  // Combined sync is generated when input request and associated flag are set
  assign sync_combined = ((ext_sync_req & sync_flag_ext_reg) |
                          (int_sync_req & sync_flag_int_reg));

  // --------------------------------------------------------------------------
  // SYNCREQS generation
  // When in Integration test mode, SYNCREQS output is controlled by writes to
  // the ITATBCTR2 register
  // --------------------------------------------------------------------------
  assign nxt_syncreqs = it_ctrl ? 
                          (it_atb_ctr_2_wr_en ? apb_wdata_bit2 : SYNCREQS):
                          sync_combined;

  // ---------------------------------------------------------------------------
  // SYNCREQS generation
  // When in Integration test mode, SYNCREQS is clocked only when the ITATBCTR2
  // register is accessed.
  // ---------------------------------------------------------------------------
  assign syncreqs_wr_en = ~it_ctrl | it_atb_ctr_2_wr_en;

  // ---------------------------------------------------------------------------
  // Sequential block for SYNCREQS
  // ---------------------------------------------------------------------------
  always @(posedge cxtmc_clk or negedge RESETn)
    begin : p_syncreqs
      if (!RESETn)
        SYNCREQS <= 1'b0;
      else if(syncreqs_wr_en)
        SYNCREQS <= nxt_syncreqs;
    end // block: p_syncreqs


  //============================================================================
  // ASSERTIONS
  //============================================================================
`ifdef ARM_ASSERT_ON
  generate
    if (CXTMC_ATBM_AXIM_CFG != CXTMC_CFG_ETF)
    begin
        assert_never #(`OVL_ERROR, `OVL_ASSERT,
         "OVL Message : In ETF configuration sync_flag_int_reg will toggle because of one more sync source. In ETRETB this condition will not be covered.")
            uzovl_cxtmc_sync_req_auto_6
              (
               .clk         (cxtmc_clk),
               .reset_n     (RESETn),
               .test_expr   ({int_sync_req,sync_flag_int_reg} == {1'b1,1'b0})
              );
    end
  endgenerate
`endif
endmodule
