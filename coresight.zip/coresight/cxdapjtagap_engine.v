//-----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2003-2013 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//  Checked In          : $Date: 2013-09-06 16:05:05 +0100 (Fri, 06 Sep 2013) $
//  Revision            : $Revision: 37058 $
//  Release             : CoreSight-SoC-TM100-r3p1-00rel0
//-----------------------------------------------------------------------------
//
// ----------------------------------------------------------------------------
//  Purpose : DAP JTAG-AP JTAG Serialiser Engine
//  Receives JTAG commands and data from Write FIFO in APB Interface
//  Optionally returns TDO data to read FIFO in APB Interface
// ----------------------------------------------------------------------------

`include "cxdapjtagap_constants.v"

module cxdapjtagap_engine
  (
  // Inputs
  dapclk, dapclken, dapresetn, dapabort_q, tdo_int, rtck_int, jtag_cmd,
  jtag_cmd_req, r_fifo_ack,
  // Outputs
  tck_int, tmsint, tdi_int, jtag_cmd_ack, r_fifo_req, tdo_byte, ser_actv
  );

  // Debug access port clock, reset and abort
  input         dapclk;         // Clock in debug access port domain
  input         dapclken;       // Enable term for dapclk domain
  input         dapresetn;      // Reset in debug access port domain
  input         dapabort_q;     // DAP access abort signal qualified
                                // by dapready

  // Inputs from Port Multiplexer
  input         tdo_int;        // JTAG Data Out
  input         rtck_int;       // Target tck pacing signal

  // Inputs from APB interface
  input  [7:0]  jtag_cmd;       // JTAG Engine Command Byte
  input         jtag_cmd_req;   // JTAG Command Request
  input         r_fifo_ack;     // read FIFO has accepted byte

  // Outputs to Port Multiplexer
  output        tck_int;        // JTAG clock
  output        tmsint;         // JTAG Test Mode Select
  output        tdi_int;        // JTAG Data In

  // Outputs to APB interface
  output        jtag_cmd_ack;   // JTAG Command Acknowledge
  output        r_fifo_req;     // read FIFO transfer request
  output  [7:0] tdo_byte;       // Packed TDO values to export to read FIFO
  output        ser_actv;       // JTAG serialiser is active

// -----------------------------------------------------------------------------
// Signal declarations
// -----------------------------------------------------------------------------

  reg  [3:0]    next_state;       // Next state of JTAG engine state machine
  wire [3:0]    next_state_abt;   // Next state conditioned by dapabort
  reg  [3:0]    state;            // JTAG engine state machine state
  reg  [2:0]    tms_count;        // Counter for tms ticks
  reg  [3:0]    tdi_count;        // Counter for tdi ticks
  wire [3:0]    tdi_count_reload; // tdi counter reload value
  wire [2:0]    tdo_byte_ptr;     // Pointer to bit position to write
                                  //  next TDO value
  wire [3:0]    tdi_count_dif;    // Pointer to bit position of next tdi value
  wire [2:0]    tms_count_dec;    // Decremented tms count
  wire          tms_count_dec_en; // Enable to decrement tms count
  wire          tms_init_en;      // Enable to initialise tms counter
  wire          tms_count_en;     // Enable for tms tick counter
  reg  [2:0]    tms_init;         // Initial value of tms counter
  wire [2:0]    next_tms_count;   // Next value of tms counter
  wire [3:0]    tdi_count_dec;    // Decremented tdi count
  wire          tdi_count_dec_en; // Enable to decrement tdi count
  wire          tdi_init_en;      // Enable to initialise tdi counter
  wire          tdi_init_cnt_en;  // Enable to register for initial value of
                                  //  tdi counter
  wire          tdi_count_en;     // Enable for tdi counter
  reg  [3:0]    tdi_init;         // Initial value of tdi counter
  wire [3:0]    new_tdi_init;     // New value of tdi initial count
  reg  [3:0]    tdi_init_p;       // Initial tdi count for packed case
  wire [3:0]    tdi_init_n;       // Initial tdi count for normal case
  wire [3:0]    tdi_init_mux;     // Select initial tdi count for packed or normal
  wire [3:0]    new_tdi_count;    // New tdi counter value
  wire [7:0]    tdi_len_init;     // Initial value of tdi length counter
  reg  [7:0]    tdi_length;       // tdi length counter
  wire [7:0]    new_tdi_length;   // New value of tdi length counter
  wire          tdi_len_init_en;  // Enable for initial load of tdi length counter
  wire          tdi_length_en;    // Enable for tdi length counter
  wire [7:0]    next_tdi_length;  // Calculate new value of tdi length counter
                                  // after each byte has been serialised
  wire          tdi_len_next_en;  // Enable for tdi length counter update
  wire          tdi_reload_en;    // Enable for tdi length counter reload
  wire          tdi_tdo_reg_en;   // Enable for load of TDI_TDO flag register
  reg           utdi;             // Register utdi flag of TDI_TDO command
  reg           tdi_val;          // Register tdi flag of TDI_TDO command
  reg           tdo_read;         // Register TDO flag of TDI_TDO command
  reg           tms_val;          // Register tms flag of TDI_TDO command
  reg           tdi_packed;       // Register Packed flag from 2nd byte of TDI_TDO
  reg           tdi_int;          // Register tdi output
  reg           tck_int;          // Register tck output
  wire          tmsint;           // Register tms output
  reg           tmsint_loc;       // Register tms output - Local copy
  wire [7:0]    tdo_byte;         // Storage for captured TDO values
  reg  [7:0]    tdo_byte_int;     // Storage for captured TDO values
  wire [7:0]    tdo_byte_next;    // Next value to write to tdo_byte; zero filled
  reg  [7:0]    tdo_mask;         // Determine mask for zero filling of tdo_byte
  wire          tdi_tdi_tdo;      // tdi value to output for TDI_TDO command
  wire          tdi_tms;          // tdi value to output for tms command
  wire          next_tdiint;      // Next value of tdi output register
  wire          tdi_tdo_en;       // Enable for tdi_int register
  wire          tdi_reg_en;       // Enable for tdi output register
  wire          tms_en;           // Enable for tms update
  wire          tms_reg_en;       // Enable for tms output register
  wire          tms_tms;          // tms value to output for tms command
  wire          tms_tdi_tdo;      // tms value to output for TDI_TDO command
  wire          next_tmsint;      // Next value of tms output register
  wire          tdo_cap_en;       // Enable for capture of TDO
  wire          ser_actv;         // JTAG serialiser engine is active
  wire          next_tck_int;     // Next value of tck to register

//------------------------------------------------------------------------------
// Beginning of main code
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// JTAG serialiser engine state machine
//------------------------------------------------------------------------------

// Next state logic for JTAG engine state machine
   always @(jtag_cmd or jtag_cmd_req or r_fifo_ack or rtck_int
            or state or tdi_count or tdi_length or tdi_packed or tdo_read
            or tms_count or utdi)
    begin : p_jtagengine_state
      case (state)
        `JE_IDLE : // TDITDO or tms branch depends on MSB of JTAG command
          case ({jtag_cmd_req, jtag_cmd[7]})
            2'b00, 2'b01 : next_state = `JE_IDLE;
            2'b10        : next_state = `JE_TMS;
            2'b11        : next_state = `JE_TDITDO;
            default      : next_state = `JE_UNDEF;
          endcase

        `JE_TMS :  // tms state enables tms counter to be loaded
          next_state = `JE_TMSLOW;

        `JE_TMSLOW : // state to emit first value of tms before tck rises
          next_state = (~rtck_int) ? `JE_TMSRISE : `JE_TMSLOW;

        `JE_TMSRISE : // tck rises with tms held
          next_state = (rtck_int)  ? `JE_TMSFALL : `JE_TMSRISE;

        `JE_TMSFALL : // tck falls - change value of tms.
                      // Continue until count exhausted
                      // But always wait until rtck returned low
                      // before exiting state
          case ({(|tms_count),rtck_int})
            2'b00       : next_state = `JE_IDLE;
            2'b01,2'b11 : next_state = `JE_TMSFALL;
            2'b10       : next_state = `JE_TMSRISE;
            default     : next_state = `JE_UNDEF;
          endcase

        `JE_TDITDO :  // TDITDO command branch. Load tms, TDO, tdi & utdi flags
          next_state = `JE_TDITDO2;

        `JE_TDITDO2 : // Wait for 2nd command byte
          next_state = (jtag_cmd_req) ? `JE_TDINP : `JE_TDITDO2;

        `JE_TDINP :   // Extract normal vs packed and length from 2nd byte
          case ({utdi,jtag_cmd[7]})
            2'b00 :        next_state = `JE_NORMAL;
            2'b10 :        next_state = `JE_UTDIMORE;
            2'b01, 2'b11 : next_state = `JE_TDILOW;
            default  :     next_state = `JE_UNDEF;
          endcase

        `JE_NORMAL :  // Normal case. Wait for 3rd byte with tdi data
          next_state = (jtag_cmd_req) ? `JE_TDILOW : `JE_NORMAL;

        `JE_TDILOW :  // Packed case jumps here.
                      // Normal case after loading 3rd byte
                      // Emit tdi with tck low
          next_state = (~rtck_int) ? `JE_TDIRISE : `JE_TDILOW;

        `JE_TDIRISE : // tck rising with tdi held
          next_state = (rtck_int)  ? `JE_TDIFALL : `JE_TDIRISE;

        `JE_TDIFALL : // tck falling. Emit next value of tdi.
                      // Continue until count exhausted
                      // Separate tests for Packed, utdi and Normal cases
          case ({|tdi_count,tdo_read})
            2'b00    : case ({tdi_packed,|tdi_length})
                         2'b00, 2'b10, 2'b11 : next_state = `JE_IDLE;
                         2'b01               : next_state = (utdi) ? `JE_UTDIMORE
                                                                  : `JE_NORMAL;
                         default             : next_state = `JE_UNDEF;
                       endcase
            2'b01    : next_state = `JE_TDOXFER;
            2'b10,
            2'b11    : next_state = (rtck_int) ? `JE_TDIFALL : `JE_TDIRISE;
            default  : next_state = `JE_UNDEF;
          endcase // case{|tdi_count,tdo_read}

        `JE_TDOXFER : // IF TDO flag set, then export TDO data to
                      // read FIFO before continuing
          next_state = `JE_TDOWAIT;

        `JE_TDOWAIT : // Wait for acknowledge from read FIFO
                      // Next state depends on whether Packed, utdi or Normal
          case ({r_fifo_ack,tdi_packed,|tdi_length})
            3'b000,
            3'b001,
            3'b010,
            3'b011   : next_state = `JE_TDOWAIT;

            3'b100,
            3'b110,
            3'b111   : next_state = `JE_IDLE;

            3'b101   : case (utdi)
                         1'b0 :    next_state = `JE_NORMAL;
                         1'b1 :    next_state = `JE_UTDIMORE;
                         default : next_state = `JE_UNDEF;
                       endcase // case(utdi)

            default : next_state = `JE_UNDEF;
          endcase

        `JE_UTDIMORE : // If utdi case, no data to get from Write FIFO,
                       // just continue. Need this state to reload tdi counter
          next_state = `JE_TDILOW;

        default     : next_state = `JE_UNDEF;

      endcase
    end // block: p_jtagengine_state

  assign next_state_abt = next_state & {4{~dapabort_q}};

  // Registers for state machine
  always @ (posedge dapclk or negedge dapresetn)
    begin : p_stateseq
      if (!dapresetn)
        state <= `JE_IDLE;
      else if (dapclken)
        state <= next_state_abt;
    end

   // Serialiser active status to export to Control/Status Word
   assign ser_actv = (state != `JE_IDLE);

//------------------------------------------------------------------------------
// JTAG command interface handshake
//------------------------------------------------------------------------------

   // Acknowledge request from Write FIFO interface. Ready to receive
   // new command only in JE_IDLE, TDITDO2 and NORMAL states
   assign jtag_cmd_ack = (state != `JE_IDLE) & (state != `JE_TDITDO2)
                       & (state != `JE_NORMAL);

//------------------------------------------------------------------------------
// Mode flags
//------------------------------------------------------------------------------

  // Register new values of utdi,tdi,TDO & tms from JTAG
  // command each time in state TDITDO
  // Not cleared by dapabort because will re-enter
  // JE_TDITDO state before values are used again
  assign tdi_tdo_reg_en = (state == `JE_TDITDO) & dapclken;

  // utdi,tdi,TDO and tms flags extracted from TDITDO command
  always @ (posedge dapclk or negedge dapresetn)
    begin : p_tditdoreg
      if (!dapresetn)
        begin
          utdi    <= 1'b0;
          tdi_val  <= 1'b0;
          tdo_read <= 1'b0;
          tms_val  <= 1'b0;
        end
      else if (tdi_tdo_reg_en)
        begin
          utdi    <= jtag_cmd[0];
          tdi_val  <= jtag_cmd[1];
          tdo_read <= jtag_cmd[2];
          tms_val  <= jtag_cmd[3];
        end
    end // block: p_tditdoreg

  // Register Packed vs Normal flag
  // Not cleared on dapabort because will be reloaded before
  // being used
  always @ (posedge dapclk or negedge dapresetn)
    begin : p_packedreg
      if (!dapresetn)
        tdi_packed <= 1'b0;
      else if (tdi_init_en)
        tdi_packed <= jtag_cmd[7];
    end

//------------------------------------------------------------------------------
// tck generation
//------------------------------------------------------------------------------

   // Determine tck to drive to JTAG Port Multiplexer
   assign next_tck_int = (next_state == `JE_TMSRISE) | (next_state == `JE_TDIRISE);

    // Register tck output
  always @ (posedge dapclk or negedge dapresetn)
    begin : p_tckregister
      if (!dapresetn)
        tck_int <= 1'b0;
      else if (dapclken)
        tck_int <= next_tck_int;
    end

//------------------------------------------------------------------------------
// tms counter
//------------------------------------------------------------------------------

   // tms counter combinatorial logic
   assign tms_init_en = (next_state == `JE_TMS);

  // Decrement counter each time enter JE_TMSRISE state from another state
   assign tms_count_dec_en = (next_state == `JE_TMSRISE) & (state != `JE_TMSRISE);

   assign tms_count_en = (tms_init_en | tms_count_dec_en | dapabort_q) & dapclken;

   assign tms_count_dec = tms_count - 3'b001;

   // Initialise tms counter value from JTAG command byte
  always @ (jtag_cmd)
    case (jtag_cmd[5:1])
      `def_1xxxx: tms_init[2:0] = 3'b101; // bit [5] set
      `def_01xxx: tms_init[2:0] = 3'b100; // bit [4] set
      `def_001xx: tms_init[2:0] = 3'b011; // bit [3] set
      `def_0001x: tms_init[2:0] = 3'b010; // bit [2] set
       5'b00001 : tms_init[2:0] = 3'b001; // bit [1] set
       5'b00000 : tms_init[2:0] = 3'b001; // Illegal instruction -
                                         // do same as if bit [1] set
       default:   tms_init[2:0] = 3'bXXX; // x-propagation
    endcase

  assign  next_tms_count = ((tms_init_en) ? tms_init : tms_count_dec)
                           & {3{~dapabort_q}};

  // tms tick counter
  always @ (posedge dapclk or negedge dapresetn)
    begin : p_tmscounter
      if (!dapresetn)
        tms_count <= 3'b000;
      else if (tms_count_en)
        tms_count <= next_tms_count;
    end

//------------------------------------------------------------------------------
// tdi length counter
//------------------------------------------------------------------------------

  // tdi stream length counter combinatorial logic
  // Length is 1 more than number contained in lower 7 bits
  // of JTAG command
  assign tdi_len_init  = {1'b0,jtag_cmd[6:0]} + 8'h01;

  // Initialise length counter if MSB is '0' - i.e. normal, not packed case
  assign tdi_len_init_en = (~jtag_cmd[7]) & (state == `JE_TDINP);

  // Reload tdi length counter as exit from NORMAL  state - i.e once new
  // JTAG command byte received - or as exit from UTDIMORE state

  assign tdi_len_next_en = ((state == `JE_NORMAL) | (state == `JE_UTDIMORE))
                         & (next_state == `JE_TDILOW) ;


  // Calculate next value of tdi length counter, decrement by 8 until value
  // is less than 8, then set to zero and rely on TDIcount to count down
  // final N bytes
  assign next_tdi_length = (tdi_length > 8'h08) ? (tdi_length - 8'h08) : 8'h00;

  assign new_tdi_length = (({8{tdi_len_init_en}} & tdi_len_init) |
                         ({8{tdi_len_next_en}} & next_tdi_length))
                         & {8{~dapabort_q}};

  assign tdi_length_en = (tdi_len_init_en | tdi_len_next_en | dapabort_q)
                         & dapclken;

  // Initialise tdi length counter
  always @ (posedge dapclk or negedge dapresetn)
    begin : p_tdilencounter
      if (!dapresetn)
        tdi_length <= 8'h00;
      else if (tdi_length_en)
        tdi_length <= new_tdi_length;
    end

//------------------------------------------------------------------------------
// tdi bit counter
//------------------------------------------------------------------------------

   // tdi counter combinatorial logic

   // Initialise tdi counter in TDINP state
   assign tdi_init_en = (next_state == `JE_TDINP) & dapclken;

   // Reload tdi counter as enter NORMAL, UTDIMORE or TDOXFER states
   assign tdi_reload_en = (state == `JE_TDIFALL) &
                          ((next_state == `JE_NORMAL) |
                           (next_state == `JE_UTDIMORE) |
                           (next_state == `JE_TDOXFER)
                          );

   assign tdi_count_reload = (tdi_length >= 8'h08) ? 4'h8 : tdi_length[3:0];

   // Decrement counter each time enter TDIRISE state from another state
   assign tdi_count_dec_en = (next_state == `JE_TDIRISE) & (state != `JE_TDIRISE);

   assign tdi_count_dec = tdi_count - 4'h1;

  // Determine tdi count for packed case from JTAG command byte

  always @ (jtag_cmd)
    case (jtag_cmd[6:1])
      `def_1xxxxx : tdi_init_p[3:0] = 4'h6; // bit [6] set
      `def_01xxxx : tdi_init_p[3:0] = 4'h5; // bit [5] set
      `def_001xxx : tdi_init_p[3:0] = 4'h4; // bit [4] set
      `def_0001xx : tdi_init_p[3:0] = 4'h3; // bit [3] set
      `def_00001x : tdi_init_p[3:0] = 4'h2; // bit [2] set
       6'b000001  : tdi_init_p[3:0] = 4'h1; // bit [1] set
       6'b000000  : tdi_init_p[3:0] = 4'h1; // Illegal instruction -
                                          // do same as if bit [1] set
       default:     tdi_init_p[3:0] = 4'bXXXX; // x-propagation
    endcase

   // and for Normal case
   assign tdi_init_n = (jtag_cmd[6:3] != 4'b0000) ? 4'h8 :
                        ({1'b0,jtag_cmd[2:0]} + 4'h1);

   // Select initial value for Normal or Packed case
   assign tdi_init_mux = (jtag_cmd[7]) ? tdi_init_p : tdi_init_n;

  // Select source for new value of tdi counter
  // Clear counter on dapabort

  assign new_tdi_count = (({4{tdi_init_en}}     & tdi_init_mux)     |
                          ({4{tdi_reload_en}}   & tdi_count_reload) |
                          ({4{tdi_count_dec_en}} & tdi_count_dec))
                          & {4{~dapabort_q}};

  assign tdi_count_en = (tdi_init_en | tdi_reload_en | tdi_count_dec_en | dapabort_q)
                        & dapclken;

  // tdi tick counter
  always @ (posedge dapclk or negedge dapresetn)
    begin : p_tdicounter
      if (!dapresetn)
        tdi_count <= 4'h0;
      else if (tdi_count_en)
        tdi_count <= new_tdi_count;
    end

  // Determine initial count of tdi cycles; reload each time
  // tdi counter is reloaded
  assign tdi_init_cnt_en = (tdi_init_en | tdi_reload_en) & dapclken;

  assign new_tdi_init = tdi_init_en ? tdi_init_mux : tdi_count_reload;

  // Register initial count of tdi ticks
  // Not cleared on dapabort because will be reloaded before
  // being used
  always @ (posedge dapclk or negedge dapresetn)
    begin : p_tdicount
      if (!dapresetn)
        tdi_init <= 4'h0;
      else if (tdi_init_cnt_en)
        tdi_init <= new_tdi_init;
    end

//------------------------------------------------------------------------------
// tdi generation
//------------------------------------------------------------------------------

  // Get value of tdi to emit. There are three cases for TDI_TDO:
  // 1. If utdi=1, use tdi value contained in first TDI_TDO byte
  // 2. Else if packed, get tdi value from 2nd byte
  // 3. Else if normal, get tdi value from 3rd and subsequent bytes
  // and one case for tms commands
  assign tdi_tdi_tdo = (utdi) ? tdi_val : jtag_cmd[tdi_count_dif[2:0]];

  assign tdi_tms   = jtag_cmd[6]; // tdi value embedded in tms command

  // Enable tdi register update when tck low or on tck falling edge
  // while tdi counter non-zero
  assign tdi_tdo_en = ((next_state == `JE_TDILOW) | (next_state == `JE_TDIFALL))
                      & (|tdi_count);

  // Enable tms register update when tck low or on tck falling edge
  // while tms counter non-zero
  assign tms_en    = ((next_state == `JE_TMSLOW) | (next_state == `JE_TMSFALL))
                       & (|tms_count);

  assign tdi_reg_en = (tdi_tdo_en | tms_en) & dapclken;

  assign next_tdiint = (tdi_tdo_en) ? tdi_tdi_tdo : tdi_tms;

  // tdi output register
  // Not cleared on dapabort because will be initialised before
  // first rising edge of tck
  always @ (posedge dapclk or negedge dapresetn)
    begin : p_tdireg
      if (!dapresetn)
        tdi_int <= 1'b0;
      else if (tdi_reg_en)
        tdi_int <= next_tdiint;
    end

//------------------------------------------------------------------------------
// tms generation
//------------------------------------------------------------------------------

  // Get value of tms to emit.
  // For tms command, select value from command byte

  assign tms_tms    = jtag_cmd[tms_init - tms_count];

  // For TDI_TDO command, hold tms until last cycle when last tdi is emitted,
  //  then emit tms value from first TDI_TDO command byte
  // Last cycle is indicated by tdi counter about to become zero AND
  // tdi length counter either already zero or about to become zero

  assign tms_tdi_tdo = ((~|tdi_count_dec) &
                       ((~|tdi_length) | (tdi_len_next_en & (~|next_tdi_length))))
                       ? tms_val : tmsint_loc;

  assign tms_reg_en = (tms_en | tdi_tdo_en) & dapclken;

  assign next_tmsint = (tdi_tdo_en) ? tms_tdi_tdo : tms_tms;

  // tms output register
  // Not cleared on dapabort because will be initialised before
  // first rising edge of tck
  always @ (posedge dapclk or negedge dapresetn)
    begin : p_tmsreg
      if (!dapresetn)
        tmsint_loc <= 1'b0;
      else if (tms_reg_en)
        tmsint_loc <= next_tmsint;
    end
  assign tmsint = tmsint_loc;

//------------------------------------------------------------------------------
// TDO capture
//------------------------------------------------------------------------------

  // Capture TDO values on each tck if in TDI_TDO mode and TDO flag set

  // Define bit mask to zero out upper bits of tdo_byte if less
  // than 8 bits captured
  always @ (tdi_init)
    case (tdi_init)
      4'h8   : tdo_mask = 8'b11111111;
      4'h7   : tdo_mask = 8'b01111111;
      4'h6   : tdo_mask = 8'b00111111;
      4'h5   : tdo_mask = 8'b00011111;
      4'h4   : tdo_mask = 8'b00001111;
      4'h3   : tdo_mask = 8'b00000111;
      4'h2   : tdo_mask = 8'b00000011;
      4'h1   : tdo_mask = 8'b00000001;
      4'h0   : tdo_mask = 8'b00000000;
      default: tdo_mask = 8'bXXXXXXXX; // x-propagation
    endcase

  // Determine bit position to write next value of TDO
  // tdi counter is incremented as enter TDIRISE state
  // so need to subtract 1 as value is used as exit TDIRISE state
  assign tdi_count_dif = tdi_init - tdi_count;      // 4-bit subtraction

  assign tdo_byte_ptr  = tdi_count_dif[2:0] - 3'b001; // But only need bottom 3 bits

  // Enable on each bit of tdo_byte register
  assign tdo_byte_next[7] = (tdo_byte_ptr == 3'b111) ? tdo_int :
                               (tdo_byte_int[7] & tdo_mask[7]);

  assign tdo_byte_next[6] = (tdo_byte_ptr == 3'b110) ? tdo_int :
                               (tdo_byte_int[6] & tdo_mask[6]);

  assign tdo_byte_next[5] = (tdo_byte_ptr == 3'b101) ? tdo_int :
                               (tdo_byte_int[5] & tdo_mask[5]);

  assign tdo_byte_next[4] = (tdo_byte_ptr == 3'b100) ? tdo_int :
                               (tdo_byte_int[4] & tdo_mask[4]);

  assign tdo_byte_next[3] = (tdo_byte_ptr == 3'b011) ? tdo_int :
                               (tdo_byte_int[3] & tdo_mask[3]);

  assign tdo_byte_next[2] = (tdo_byte_ptr == 3'b010) ? tdo_int :
                               (tdo_byte_int[2] & tdo_mask[2]);

  assign tdo_byte_next[1] = (tdo_byte_ptr == 3'b001) ? tdo_int :
                               (tdo_byte_int[1] & tdo_mask[1]);

  assign tdo_byte_next[0] = (tdo_byte_ptr == 3'b000) ? tdo_int :
                               (tdo_byte_int[0] & tdo_mask[0]);


  // Capture TDO on falling edge of tck once have seen rising
  // edge on rtck - this ensures that TDO is valid whatever
  // the JTAG slave operating frequency
  assign tdo_cap_en = tdo_read & (next_state == `JE_TDIFALL) &
                         (state == `JE_TDIRISE) & dapclken;

  // Sample TDO if TDO flag set in first TDI_TDO command byte
  // Not reset because not read until after being loaded
  always @ (posedge dapclk)
    begin : p_tdoreg
      if (tdo_cap_en)
        tdo_byte_int <= tdo_byte_next;
    end
  assign tdo_byte = tdo_byte_int;

  // Now request transfer of TDO Byte to the read-FIFO
  assign r_fifo_req = (state == `JE_TDOXFER) | (state == `JE_TDOWAIT);

//------------------------------------------------------------------------------
// OVL Assertions
//------------------------------------------------------------------------------
`ifdef ARM_ASSERT_ON

  // Ensure no x or z in JTAG command register
  // Severity 1
  assert_never_unknown #(`OVL_ERROR, 8, `OVL_ASSERT, "x or z detected in JTAG command register")
    dapjtagap_jtagcmd_x
      (
       .clk       (dapclk),
       .reset_n   (dapresetn),
       .qualifier (1'b1),
       .test_expr (jtag_cmd[7:0])
      );

 // Check that tms counter is within legal range
 assert_range #(`OVL_ERROR, 3, 0, 5, `OVL_ASSERT, "tms_count is outside of range 0 to 5")
    dapjtagap_tmscount_range (
      .clk        (dapclk),
      .reset_n    (dapresetn),
      .test_expr  (tms_count[2:0])
      );


 // Check that tdi counter is within legal range
 assert_range #(`OVL_ERROR, 4, 0, 8, `OVL_ASSERT, "tdi_count is outside of range 0 to 8")
    dapjtagap_tdicount_range (
      .clk        (dapclk),
      .reset_n    (dapresetn),
      .test_expr  (tdi_count[3:0])
      );

 // Check that tdi initial value counter is within legal range
 assert_range #(`OVL_ERROR, 4, 0, 8, `OVL_ASSERT, "tdi_init is outside of range 0 to 8")
    dapjtagap_tdiinit_range (
      .clk        (dapclk),
      .reset_n    (dapresetn),
      .test_expr  (tdi_init[3:0])
      );

 // Check that tdi initial value counter is within legal range
 assert_range #(`OVL_ERROR, 8, 0, 128, `OVL_ASSERT, "tdi_length counter is outside of range 0 to 128")
    dapjtagap_tdilength_range (
      .clk        (dapclk),
      .reset_n    (dapresetn),
      .test_expr  (tdi_length[7:0])
      );

   // Ensure no x or z in tdi output register
  // Severity 1
  assert_never_unknown #(`OVL_ERROR, 1, `OVL_ASSERT, "x or z detected in tdi output register")
    dapjtagap_tdiint_x
      (
       .clk       (dapclk),
       .reset_n   (dapresetn),
       .qualifier (1'b1),
       .test_expr (tdi_int)
      );

   // Ensure no x or z in tck output register
  // Severity 1
  assert_never_unknown #(`OVL_ERROR, 1, `OVL_ASSERT, "x or z detected in tck output register")
    dapjtagap_tckint_x
      (
       .clk       (dapclk),
       .reset_n   (dapresetn),
       .qualifier (1'b1),
       .test_expr (tck_int)
      );

   // Ensure no x or z in tms output register
  // Severity 1
  assert_never_unknown #(`OVL_ERROR, 1, `OVL_ASSERT, "x or z detected in tms output register")
    dapjtagap_tmsint_x
      (
       .clk       (dapclk),
       .reset_n   (dapresetn),
       .qualifier (1'b1),
       .test_expr (tmsint_loc)
      );

`endif //  `ifdef ARM_ASSERT_ON


endmodule // cxdapjtagap_engine
