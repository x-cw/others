//+FHDR*************************************************************************
// 
//   Copyright (c) 2024 Innosilicon. Ltd.  All rights reserved. 
// 
//   THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF INNOSILICON
//   The copyright notice above does not evidence any actual or intended
//   publication of such source code.
// 
//************************************************************************
//    Module name: trace_wrapper.v
//    Create by  : lidh
//    Email      : chenqw@innosilicon.com.cn
//    Create time: 2024-09-04
//************************************************************************
//    Description: 
//-FHDR*************************************************************************

module trace_wrapper (
input         etr_axi_bvalid,
output        etr_axi_bready,

input  [3:0]  etr_awqos_fr_reg,
input  [3:0]  etr_arqos_fr_reg,
input  [15:0] etr_awuser_fr_reg,
input  [15:0] etr_aruser_fr_reg,
output [15:0] etr_buser_to_reg,
output [15:0] etr_ruser_to_reg,
input  [10:0] etr_addr_h11_fr_reg,

input  [15:0] etr_axi_buser,
input  [15:0] etr_axi_ruser,

output        etf_etr_interrupt,

/*autoinput*/
// Beginning of automatic inputs (from unused autoinst inputs)
input [31:0]            apb1to2_paddrm1,        // To ip_common_reg_u0 of ip_common_reg.v
input                   apb1to2_penablem1,      // To ip_common_reg_u0 of ip_common_reg.v
input                   apb1to2_pselm1,         // To ip_common_reg_u0 of ip_common_reg.v
input [31:0]            apb1to2_pwdatam1,       // To ip_common_reg_u0 of ip_common_reg.v
input                   apb1to2_pwritem1,       // To ip_common_reg_u0 of ip_common_reg.v
input                   apbic_paddr31_to_cti_etf,// To u_cxcti_etf of cxcti.v
input                   apbic_paddr31_to_cti_etr,// To u_cxcti_etr of cxcti.v
input                   apbic_paddr31_to_etf,   // To cxapbasyncbridge_u_etf of cxapbasyncbridge_1.v
input                   apbic_paddr31_to_etr,   // To cxapbasyncbridge_u_etr of cxapbasyncbridge_1.v
input                   apbic_paddr31_to_funnel,// To cxapbasyncbridge_u_funnel of cxapbasyncbridge_1.v
input [11:2]            apbic_paddr_to_cti_etf, // To u_cxcti_etf of cxcti.v
input [11:2]            apbic_paddr_to_cti_etr, // To u_cxcti_etr of cxcti.v
input [11:2]            apbic_paddr_to_etf,     // To cxapbasyncbridge_u_etf of cxapbasyncbridge_1.v
input [11:2]            apbic_paddr_to_etr,     // To cxapbasyncbridge_u_etr of cxapbasyncbridge_1.v
input [11:2]            apbic_paddr_to_funnel,  // To cxapbasyncbridge_u_funnel of cxapbasyncbridge_1.v
input                   apbic_penable_to_cti_etf,// To u_cxcti_etf of cxcti.v
input                   apbic_penable_to_cti_etr,// To u_cxcti_etr of cxcti.v
input                   apbic_penable_to_etf,   // To cxapbasyncbridge_u_etf of cxapbasyncbridge_1.v
input                   apbic_penable_to_etr,   // To cxapbasyncbridge_u_etr of cxapbasyncbridge_1.v
input                   apbic_penable_to_funnel,// To cxapbasyncbridge_u_funnel of cxapbasyncbridge_1.v
input                   apbic_psel_to_cti_etf,  // To u_cxcti_etf of cxcti.v
input                   apbic_psel_to_cti_etr,  // To u_cxcti_etr of cxcti.v
input                   apbic_psel_to_etf,      // To cxapbasyncbridge_u_etf of cxapbasyncbridge_1.v
input                   apbic_psel_to_etr,      // To cxapbasyncbridge_u_etr of cxapbasyncbridge_1.v
input                   apbic_psel_to_funnel,   // To cxapbasyncbridge_u_funnel of cxapbasyncbridge_1.v
input [31:0]            apbic_pwdata_to_cti_etf,// To u_cxcti_etf of cxcti.v
input [31:0]            apbic_pwdata_to_cti_etr,// To u_cxcti_etr of cxcti.v
input [31:0]            apbic_pwdata_to_etf,    // To cxapbasyncbridge_u_etf of cxapbasyncbridge_1.v
input [31:0]            apbic_pwdata_to_etr,    // To cxapbasyncbridge_u_etr of cxapbasyncbridge_1.v
input [31:0]            apbic_pwdata_to_funnel, // To cxapbasyncbridge_u_funnel of cxapbasyncbridge_1.v
input                   apbic_pwrite_to_cti_etf,// To u_cxcti_etf of cxcti.v
input                   apbic_pwrite_to_cti_etr,// To u_cxcti_etr of cxcti.v
input                   apbic_pwrite_to_etf,    // To cxapbasyncbridge_u_etf of cxapbasyncbridge_1.v
input                   apbic_pwrite_to_etr,    // To cxapbasyncbridge_u_etr of cxapbasyncbridge_1.v
input                   apbic_pwrite_to_funnel, // To cxapbasyncbridge_u_funnel of cxapbasyncbridge_1.v
input [3:0]             cxctm0_ctmchin2,        // To cxctm_u0 of cxctm.v
input [3:0]             cxctm0_ctmchin3,        // To cxctm_u0 of cxctm.v
input [3:0]             cxctm0_ctmchoutack2,    // To cxctm_u0 of cxctm.v
input [3:0]             cxctm0_ctmchoutack3,    // To cxctm_u0 of cxctm.v
input                   dbg_clk,                // To cxapbasyncbridge_u_funnel of cxapbasyncbridge_1.v, ...
input                   dbg_rstn,               // To cxapbasyncbridge_u_funnel of cxapbasyncbridge_1.v, ...
input                   dft_test_mode,          // To cxtmc_etf_u0 of CXTMC_ETF.v, ...
input                   etr_axi_arready,        // To intlv_main_u0 of intlv.v
input                   etr_axi_awready,        // To intlv_main_u0 of intlv.v
input [5:0]             etr_axi_bid,            // To etr_usermge_u0 of etr_usermge.v
input [1:0]             etr_axi_bresp,          // To cxtmc_etr_u0 of CXTMC_ETR.v
input [127:0]           etr_axi_rdata,          // To cxtmc_etr_u0 of CXTMC_ETR.v
input [5:0]             etr_axi_rid,            // To etr_usermge_u0 of etr_usermge.v
input                   etr_axi_rlast,          // To cxtmc_etr_u0 of CXTMC_ETR.v
input [1:0]             etr_axi_rresp,          // To cxtmc_etr_u0 of CXTMC_ETR.v
input                   etr_axi_rvalid,         // To cxtmc_etr_u0 of CXTMC_ETR.v
input                   etr_axi_wready,         // To cxtmc_etr_u0 of CXTMC_ETR.v
input [31:0]            etr_id_ctrl_fr_reg,     // To etr_usermge_u0 of etr_usermge.v
input                   funnel_afreadys0,       // To cxatbfunnel_u0 of cxatbfunnel_7_pro.v
input                   funnel_afreadys1,       // To cxatbfunnel_u0 of cxatbfunnel_7_pro.v
input                   funnel_afreadys2,       // To cxatbfunnel_u0 of cxatbfunnel_7_pro.v
input                   funnel_afreadys3,       // To cxatbfunnel_u0 of cxatbfunnel_7_pro.v
input                   funnel_afreadys4,       // To cxatbfunnel_u0 of cxatbfunnel_7_pro.v
input                   funnel_afreadys5,       // To cxatbfunnel_u0 of cxatbfunnel_7_pro.v
input                   funnel_afreadys6,       // To cxatbfunnel_u0 of cxatbfunnel_7_pro.v
input [3:0]             funnel_atbytess0,       // To cxatbfunnel_u0 of cxatbfunnel_7_pro.v
input [3:0]             funnel_atbytess1,       // To cxatbfunnel_u0 of cxatbfunnel_7_pro.v
input [3:0]             funnel_atbytess2,       // To cxatbfunnel_u0 of cxatbfunnel_7_pro.v
input [3:0]             funnel_atbytess3,       // To cxatbfunnel_u0 of cxatbfunnel_7_pro.v
input [3:0]             funnel_atbytess4,       // To cxatbfunnel_u0 of cxatbfunnel_7_pro.v
input [3:0]             funnel_atbytess5,       // To cxatbfunnel_u0 of cxatbfunnel_7_pro.v
input [3:0]             funnel_atbytess6,       // To cxatbfunnel_u0 of cxatbfunnel_7_pro.v
input [127:0]           funnel_atdatas0,        // To cxatbfunnel_u0 of cxatbfunnel_7_pro.v
input [127:0]           funnel_atdatas1,        // To cxatbfunnel_u0 of cxatbfunnel_7_pro.v
input [127:0]           funnel_atdatas2,        // To cxatbfunnel_u0 of cxatbfunnel_7_pro.v
input [127:0]           funnel_atdatas3,        // To cxatbfunnel_u0 of cxatbfunnel_7_pro.v
input [127:0]           funnel_atdatas4,        // To cxatbfunnel_u0 of cxatbfunnel_7_pro.v
input [127:0]           funnel_atdatas5,        // To cxatbfunnel_u0 of cxatbfunnel_7_pro.v
input [127:0]           funnel_atdatas6,        // To cxatbfunnel_u0 of cxatbfunnel_7_pro.v
input [6:0]             funnel_atids0,          // To cxatbfunnel_u0 of cxatbfunnel_7_pro.v
input [6:0]             funnel_atids1,          // To cxatbfunnel_u0 of cxatbfunnel_7_pro.v
input [6:0]             funnel_atids2,          // To cxatbfunnel_u0 of cxatbfunnel_7_pro.v
input [6:0]             funnel_atids3,          // To cxatbfunnel_u0 of cxatbfunnel_7_pro.v
input [6:0]             funnel_atids4,          // To cxatbfunnel_u0 of cxatbfunnel_7_pro.v
input [6:0]             funnel_atids5,          // To cxatbfunnel_u0 of cxatbfunnel_7_pro.v
input [6:0]             funnel_atids6,          // To cxatbfunnel_u0 of cxatbfunnel_7_pro.v
input                   funnel_atvalids0,       // To cxatbfunnel_u0 of cxatbfunnel_7_pro.v
input                   funnel_atvalids1,       // To cxatbfunnel_u0 of cxatbfunnel_7_pro.v
input                   funnel_atvalids2,       // To cxatbfunnel_u0 of cxatbfunnel_7_pro.v
input                   funnel_atvalids3,       // To cxatbfunnel_u0 of cxatbfunnel_7_pro.v
input                   funnel_atvalids4,       // To cxatbfunnel_u0 of cxatbfunnel_7_pro.v
input                   funnel_atvalids5,       // To cxatbfunnel_u0 of cxatbfunnel_7_pro.v
input                   funnel_atvalids6,       // To cxatbfunnel_u0 of cxatbfunnel_7_pro.v
input                   trace_clk,              // To cxapbasyncbridge_u_funnel of cxapbasyncbridge_1.v, ...
input                   trace_rstn,             // To cxapbasyncbridge_u_funnel of cxapbasyncbridge_1.v, ...
// End of automatics
/*autooutput*/
// Beginning of automatic outputs (from unused autoinst outputs)
output [31:0]           apb1to2_prdatam1,       // From ip_common_reg_u0 of ip_common_reg.v
output                  apb1to2_preadym1,       // From ip_common_reg_u0 of ip_common_reg.v
output                  apb1to2_pslverrm1,      // From ip_common_reg_u0 of ip_common_reg.v
output [31:0]           apbic_prdata_to_cti_etf,// From u_cxcti_etf of cxcti.v
output [31:0]           apbic_prdata_to_cti_etr,// From u_cxcti_etr of cxcti.v
output [31:0]           apbic_prdata_to_etf,    // From cxapbasyncbridge_u_etf of cxapbasyncbridge_1.v
output [31:0]           apbic_prdata_to_etr,    // From cxapbasyncbridge_u_etr of cxapbasyncbridge_1.v
output [31:0]           apbic_prdata_to_funnel, // From cxapbasyncbridge_u_funnel of cxapbasyncbridge_1.v
output                  apbic_pready_to_cti_etf,// From u_cxcti_etf of cxcti.v
output                  apbic_pready_to_cti_etr,// From u_cxcti_etr of cxcti.v
output                  apbic_pready_to_etf,    // From cxapbasyncbridge_u_etf of cxapbasyncbridge_1.v
output                  apbic_pready_to_etr,    // From cxapbasyncbridge_u_etr of cxapbasyncbridge_1.v
output                  apbic_pready_to_funnel, // From cxapbasyncbridge_u_funnel of cxapbasyncbridge_1.v
output                  apbic_pslverr_to_etf,   // From cxapbasyncbridge_u_etf of cxapbasyncbridge_1.v
output                  apbic_pslverr_to_etr,   // From cxapbasyncbridge_u_etr of cxapbasyncbridge_1.v
output                  apbic_pslverr_to_funnel,// From cxapbasyncbridge_u_funnel of cxapbasyncbridge_1.v
output [3:0]            cxctm0_ctmchinack2,     // From cxctm_u0 of cxctm.v
output [3:0]            cxctm0_ctmchinack3,     // From cxctm_u0 of cxctm.v
output [3:0]            cxctm0_ctmchout2,       // From cxctm_u0 of cxctm.v
output [3:0]            cxctm0_ctmchout3,       // From cxctm_u0 of cxctm.v
output [51:0]           etr_axi_araddr,         // From intlv_main_u0 of intlv.v
output [1:0]            etr_axi_arburst,        // From intlv_main_u0 of intlv.v
output [3:0]            etr_axi_arcache,        // From intlv_main_u0 of intlv.v
output [5:0]            etr_axi_arid,           // From intlv_main_u0 of intlv.v
output [3:0]            etr_axi_arlen,          // From intlv_main_u0 of intlv.v
output                  etr_axi_arlock,         // From intlv_main_u0 of intlv.v
output [2:0]            etr_axi_arprot,         // From intlv_main_u0 of intlv.v
output [3:0]            etr_axi_arqos,          // From intlv_main_u0 of intlv.v
output [2:0]            etr_axi_arsize,         // From intlv_main_u0 of intlv.v
output [15:0]           etr_axi_aruser,         // From intlv_main_u0 of intlv.v
output                  etr_axi_arvalid,        // From intlv_main_u0 of intlv.v
output [51:0]           etr_axi_awaddr,         // From intlv_main_u0 of intlv.v
output [1:0]            etr_axi_awburst,        // From intlv_main_u0 of intlv.v
output [3:0]            etr_axi_awcache,        // From intlv_main_u0 of intlv.v
output [5:0]            etr_axi_awid,           // From intlv_main_u0 of intlv.v
output [3:0]            etr_axi_awlen,          // From intlv_main_u0 of intlv.v
output                  etr_axi_awlock,         // From intlv_main_u0 of intlv.v
output [2:0]            etr_axi_awprot,         // From intlv_main_u0 of intlv.v
output [3:0]            etr_axi_awqos,          // From intlv_main_u0 of intlv.v
output [2:0]            etr_axi_awsize,         // From intlv_main_u0 of intlv.v
output [15:0]           etr_axi_awuser,         // From intlv_main_u0 of intlv.v
output                  etr_axi_awvalid,        // From intlv_main_u0 of intlv.v
output                  etr_axi_rready,         // From cxtmc_etr_u0 of CXTMC_ETR.v
output [127:0]          etr_axi_wdata,          // From cxtmc_etr_u0 of CXTMC_ETR.v
output                  etr_axi_wlast,          // From cxtmc_etr_u0 of CXTMC_ETR.v
output [15:0]           etr_axi_wstrb,          // From cxtmc_etr_u0 of CXTMC_ETR.v
output                  etr_axi_wvalid,         // From cxtmc_etr_u0 of CXTMC_ETR.v
output                  funnel_afvalids0,       // From cxatbfunnel_u0 of cxatbfunnel_7_pro.v
output                  funnel_afvalids1,       // From cxatbfunnel_u0 of cxatbfunnel_7_pro.v
output                  funnel_afvalids2,       // From cxatbfunnel_u0 of cxatbfunnel_7_pro.v
output                  funnel_afvalids3,       // From cxatbfunnel_u0 of cxatbfunnel_7_pro.v
output                  funnel_afvalids4,       // From cxatbfunnel_u0 of cxatbfunnel_7_pro.v
output                  funnel_afvalids5,       // From cxatbfunnel_u0 of cxatbfunnel_7_pro.v
output                  funnel_afvalids6,       // From cxatbfunnel_u0 of cxatbfunnel_7_pro.v
output                  funnel_atreadys0,       // From cxatbfunnel_u0 of cxatbfunnel_7_pro.v
output                  funnel_atreadys1,       // From cxatbfunnel_u0 of cxatbfunnel_7_pro.v
output                  funnel_atreadys2,       // From cxatbfunnel_u0 of cxatbfunnel_7_pro.v
output                  funnel_atreadys3,       // From cxatbfunnel_u0 of cxatbfunnel_7_pro.v
output                  funnel_atreadys4,       // From cxatbfunnel_u0 of cxatbfunnel_7_pro.v
output                  funnel_atreadys5,       // From cxatbfunnel_u0 of cxatbfunnel_7_pro.v
output                  funnel_atreadys6,       // From cxatbfunnel_u0 of cxatbfunnel_7_pro.v
output                  funnel_syncreqs0,       // From cxatbfunnel_u0 of cxatbfunnel_7_pro.v
output                  funnel_syncreqs1,       // From cxatbfunnel_u0 of cxatbfunnel_7_pro.v
output                  funnel_syncreqs2,       // From cxatbfunnel_u0 of cxatbfunnel_7_pro.v
output                  funnel_syncreqs3,       // From cxatbfunnel_u0 of cxatbfunnel_7_pro.v
output                  funnel_syncreqs4,       // From cxatbfunnel_u0 of cxatbfunnel_7_pro.v
output                  funnel_syncreqs5,       // From cxatbfunnel_u0 of cxatbfunnel_7_pro.v
output                  funnel_syncreqs6        // From cxatbfunnel_u0 of cxatbfunnel_7_pro.v
// End of automatics
);
/*autowire*/
// Beginning of automatic wires (for undeclared instantiated-module outputs)
wire [3:0]              bankid_sel_0_0;         // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              bankid_sel_0_1;         // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              bankid_sel_0_2;         // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              bankid_sel_0_3;         // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              bankid_sel_0_4;         // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              bankid_sel_0_5;         // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              bankid_sel_0_6;         // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              bankid_sel_0_7;         // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              bankid_sel_1_0;         // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              bankid_sel_1_1;         // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              bankid_sel_1_2;         // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              bankid_sel_1_3;         // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              bankid_sel_1_4;         // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              bankid_sel_1_5;         // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              bankid_sel_1_6;         // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              bankid_sel_1_7;         // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              bankid_sel_2_0;         // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              bankid_sel_2_1;         // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              bankid_sel_2_2;         // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              bankid_sel_2_3;         // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              bankid_sel_2_4;         // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              bankid_sel_2_5;         // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              bankid_sel_2_6;         // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              bankid_sel_2_7;         // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              bankid_sel_3_0;         // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              bankid_sel_3_1;         // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              bankid_sel_3_2;         // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              bankid_sel_3_3;         // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              bankid_sel_3_4;         // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              bankid_sel_3_5;         // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              bankid_sel_3_6;         // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              bankid_sel_3_7;         // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              bankid_sel_4_0;         // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              bankid_sel_4_1;         // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              bankid_sel_4_2;         // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              bankid_sel_4_3;         // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              bankid_sel_4_4;         // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              bankid_sel_4_5;         // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              bankid_sel_4_6;         // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              bankid_sel_4_7;         // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              bankid_sel_5_0;         // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              bankid_sel_5_1;         // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              bankid_sel_5_2;         // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              bankid_sel_5_3;         // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              bankid_sel_5_4;         // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              bankid_sel_5_5;         // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              bankid_sel_5_6;         // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              bankid_sel_5_7;         // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              bankid_sel_6_0;         // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              bankid_sel_6_1;         // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              bankid_sel_6_2;         // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              bankid_sel_6_3;         // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              bankid_sel_6_4;         // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              bankid_sel_6_5;         // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              bankid_sel_6_6;         // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              bankid_sel_6_7;         // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              buf_intlv_bankid_0;     // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              buf_intlv_bankid_1;     // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              buf_intlv_bankid_10;    // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              buf_intlv_bankid_11;    // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              buf_intlv_bankid_12;    // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              buf_intlv_bankid_13;    // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              buf_intlv_bankid_14;    // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              buf_intlv_bankid_15;    // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              buf_intlv_bankid_16;    // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              buf_intlv_bankid_17;    // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              buf_intlv_bankid_18;    // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              buf_intlv_bankid_19;    // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              buf_intlv_bankid_2;     // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              buf_intlv_bankid_20;    // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              buf_intlv_bankid_21;    // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              buf_intlv_bankid_22;    // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              buf_intlv_bankid_23;    // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              buf_intlv_bankid_24;    // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              buf_intlv_bankid_25;    // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              buf_intlv_bankid_26;    // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              buf_intlv_bankid_27;    // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              buf_intlv_bankid_28;    // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              buf_intlv_bankid_29;    // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              buf_intlv_bankid_3;     // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              buf_intlv_bankid_30;    // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              buf_intlv_bankid_31;    // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              buf_intlv_bankid_32;    // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              buf_intlv_bankid_33;    // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              buf_intlv_bankid_34;    // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              buf_intlv_bankid_35;    // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              buf_intlv_bankid_36;    // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              buf_intlv_bankid_37;    // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              buf_intlv_bankid_38;    // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              buf_intlv_bankid_39;    // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              buf_intlv_bankid_4;     // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              buf_intlv_bankid_40;    // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              buf_intlv_bankid_41;    // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              buf_intlv_bankid_42;    // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              buf_intlv_bankid_43;    // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              buf_intlv_bankid_44;    // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              buf_intlv_bankid_45;    // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              buf_intlv_bankid_46;    // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              buf_intlv_bankid_47;    // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              buf_intlv_bankid_48;    // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              buf_intlv_bankid_49;    // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              buf_intlv_bankid_5;     // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              buf_intlv_bankid_50;    // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              buf_intlv_bankid_51;    // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              buf_intlv_bankid_52;    // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              buf_intlv_bankid_53;    // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              buf_intlv_bankid_54;    // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              buf_intlv_bankid_55;    // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              buf_intlv_bankid_56;    // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              buf_intlv_bankid_57;    // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              buf_intlv_bankid_58;    // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              buf_intlv_bankid_59;    // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              buf_intlv_bankid_6;     // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              buf_intlv_bankid_60;    // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              buf_intlv_bankid_61;    // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              buf_intlv_bankid_62;    // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              buf_intlv_bankid_63;    // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              buf_intlv_bankid_64;    // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              buf_intlv_bankid_65;    // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              buf_intlv_bankid_66;    // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              buf_intlv_bankid_67;    // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              buf_intlv_bankid_68;    // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              buf_intlv_bankid_69;    // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              buf_intlv_bankid_7;     // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              buf_intlv_bankid_70;    // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              buf_intlv_bankid_71;    // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              buf_intlv_bankid_72;    // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              buf_intlv_bankid_73;    // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              buf_intlv_bankid_74;    // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              buf_intlv_bankid_75;    // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              buf_intlv_bankid_76;    // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              buf_intlv_bankid_77;    // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              buf_intlv_bankid_78;    // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              buf_intlv_bankid_79;    // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              buf_intlv_bankid_8;     // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              buf_intlv_bankid_9;     // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              cti_etf_ctichout_to_ctm;// From u_cxcti_etf of cxcti.v
wire [3:0]              cti_etf_ctichoutack_to_ctm;// From cxctm_u0 of cxctm.v
wire [3:0]              cti_etr_ctichout_to_ctm;// From u_cxcti_etr of cxcti.v
wire [3:0]              cti_etr_ctichoutack_to_ctm;// From cxctm_u0 of cxctm.v
wire [3:0]              ctm_ctichin_to_cti_etf; // From cxctm_u0 of cxctm.v
wire [3:0]              ctm_ctichin_to_cti_etr; // From cxctm_u0 of cxctm.v
wire [3:0]              ctm_ctichinack_to_cti_etf;// From u_cxcti_etf of cxcti.v
wire [3:0]              ctm_ctichinack_to_cti_etr;// From u_cxcti_etr of cxcti.v
wire                    ecc_mode;               // From ip_common_reg_u0 of ip_common_reg.v
wire                    etf_acqcomp;            // From cxtmc_etf_u0 of CXTMC_ETF.v
wire                    etf_afready;            // From cxtmc_etf_u0 of CXTMC_ETF.v
wire                    etf_afvalid;            // From cxtmc_etr_u0 of CXTMC_ETR.v
wire [3:0]              etf_atbytes;            // From cxtmc_etf_u0 of CXTMC_ETF.v
wire [127:0]            etf_atdata;             // From cxtmc_etf_u0 of CXTMC_ETF.v
wire [6:0]              etf_atid;               // From cxtmc_etf_u0 of CXTMC_ETF.v
wire                    etf_atready;            // From cxtmc_etr_u0 of CXTMC_ETR.v
wire                    etf_atvalid;            // From cxtmc_etf_u0 of CXTMC_ETF.v
wire                    etf_flushin;            // From u_cxcti_etf of cxcti.v
wire                    etf_full;               // From cxtmc_etf_u0 of CXTMC_ETF.v
wire [5:0]              etf_memaddr;            // From cxtmc_etf_u0 of CXTMC_ETF.v
wire                    etf_memcen;             // From cxtmc_etf_u0 of CXTMC_ETF.v
wire [255:0]            etf_memd;               // From cxtmc_etf_u0 of CXTMC_ETF.v
wire [255:0]            etf_memq;               // From etf_mem of ss_coresight_sp_64x256_wrapper.v
wire                    etf_memwen;             // From cxtmc_etf_u0 of CXTMC_ETF.v
wire [11:2]             etf_paddr;              // From cxapbasyncbridge_u_etf of cxapbasyncbridge_1.v
wire                    etf_paddr31;            // From cxapbasyncbridge_u_etf of cxapbasyncbridge_1.v
wire                    etf_penable;            // From cxapbasyncbridge_u_etf of cxapbasyncbridge_1.v
wire [31:0]             etf_prdata;             // From cxtmc_etf_u0 of CXTMC_ETF.v
wire                    etf_pready;             // From cxtmc_etf_u0 of CXTMC_ETF.v
wire                    etf_psel;               // From cxapbasyncbridge_u_etf of cxapbasyncbridge_1.v
wire                    etf_pslverr;            // From cxtmc_etf_u0 of CXTMC_ETF.v
wire [31:0]             etf_pwdata;             // From cxapbasyncbridge_u_etf of cxapbasyncbridge_1.v
wire                    etf_pwrite;             // From cxapbasyncbridge_u_etf of cxapbasyncbridge_1.v
wire                    etf_syncreq;            // From cxtmc_etr_u0 of CXTMC_ETR.v
wire                    etf_trigin;             // From u_cxcti_etf of cxcti.v
wire                    etr_acqcomp;            // From cxtmc_etr_u0 of CXTMC_ETR.v
wire [39:0]             etr_axi_araddr_t;       // From cxtmc_etr_u0 of CXTMC_ETR.v
wire [1:0]              etr_axi_arburst_t;      // From cxtmc_etr_u0 of CXTMC_ETR.v
wire [3:0]              etr_axi_arcache_t;      // From cxtmc_etr_u0 of CXTMC_ETR.v
wire [5:0]              etr_axi_arid_t;         // From etr_usermge_u0 of etr_usermge.v
wire [3:0]              etr_axi_arlen_t;        // From cxtmc_etr_u0 of CXTMC_ETR.v
wire [2:0]              etr_axi_arprot_t;       // From cxtmc_etr_u0 of CXTMC_ETR.v
wire                    etr_axi_arready_t;      // From intlv_main_u0 of intlv.v
wire [2:0]              etr_axi_arsize_t;       // From cxtmc_etr_u0 of CXTMC_ETR.v
wire                    etr_axi_arvalid_t;      // From cxtmc_etr_u0 of CXTMC_ETR.v
wire [39:0]             etr_axi_awaddr_t;       // From cxtmc_etr_u0 of CXTMC_ETR.v
wire [1:0]              etr_axi_awburst_t;      // From cxtmc_etr_u0 of CXTMC_ETR.v
wire [3:0]              etr_axi_awcache_t;      // From cxtmc_etr_u0 of CXTMC_ETR.v
wire [5:0]              etr_axi_awid_t;         // From etr_usermge_u0 of etr_usermge.v
wire [3:0]              etr_axi_awlen_t;        // From cxtmc_etr_u0 of CXTMC_ETR.v
wire [2:0]              etr_axi_awprot_t;       // From cxtmc_etr_u0 of CXTMC_ETR.v
wire                    etr_axi_awready_t;      // From intlv_main_u0 of intlv.v
wire [2:0]              etr_axi_awsize_t;       // From cxtmc_etr_u0 of CXTMC_ETR.v
wire                    etr_axi_awvalid_t;      // From cxtmc_etr_u0 of CXTMC_ETR.v
wire                    etr_flushin;            // From u_cxcti_etr of cxcti.v
wire                    etr_full;               // From cxtmc_etr_u0 of CXTMC_ETR.v
wire [11:2]             etr_paddr;              // From cxapbasyncbridge_u_etr of cxapbasyncbridge_1.v
wire [1:0]              etr_paddr1_0_noused;    // From cxapbasyncbridge_u_etr of cxapbasyncbridge_1.v
wire [18:0]             etr_paddr30_12_noused;  // From cxapbasyncbridge_u_etr of cxapbasyncbridge_1.v
wire                    etr_paddr31;            // From cxapbasyncbridge_u_etr of cxapbasyncbridge_1.v
wire                    etr_penable;            // From cxapbasyncbridge_u_etr of cxapbasyncbridge_1.v
wire [31:0]             etr_prdata;             // From cxtmc_etr_u0 of CXTMC_ETR.v
wire                    etr_pready;             // From cxtmc_etr_u0 of CXTMC_ETR.v
wire                    etr_psel;               // From cxapbasyncbridge_u_etr of cxapbasyncbridge_1.v
wire                    etr_pslverr;            // From cxtmc_etr_u0 of CXTMC_ETR.v
wire [31:0]             etr_pwdata;             // From cxapbasyncbridge_u_etr of cxapbasyncbridge_1.v
wire                    etr_pwrite;             // From cxapbasyncbridge_u_etr of cxapbasyncbridge_1.v
wire                    etr_trigin;             // From u_cxcti_etr of cxcti.v
wire                    funnel_128_7_slice_atb_afready;// From funnel_128_7_slice_u of atb_slice_sync.v
wire                    funnel_128_7_slice_atb_afvalid;// From cxtmc_etf_u0 of CXTMC_ETF.v
wire [3:0]              funnel_128_7_slice_atb_atbytes;// From funnel_128_7_slice_u of atb_slice_sync.v
wire [127:0]            funnel_128_7_slice_atb_atdata;// From funnel_128_7_slice_u of atb_slice_sync.v
wire [6:0]              funnel_128_7_slice_atb_atid;// From funnel_128_7_slice_u of atb_slice_sync.v
wire                    funnel_128_7_slice_atb_atready;// From cxtmc_etf_u0 of CXTMC_ETF.v
wire                    funnel_128_7_slice_atb_atvalid;// From funnel_128_7_slice_u of atb_slice_sync.v
wire                    funnel_128_7_slice_atb_syncreq;// From cxtmc_etf_u0 of CXTMC_ETF.v
wire                    funnel_afreadym;        // From cxatbfunnel_u0 of cxatbfunnel_7_pro.v
wire                    funnel_afvalidm;        // From funnel_128_7_slice_u of atb_slice_sync.v
wire [3:0]              funnel_atbytesm;        // From cxatbfunnel_u0 of cxatbfunnel_7_pro.v
wire [127:0]            funnel_atdatam;         // From cxatbfunnel_u0 of cxatbfunnel_7_pro.v
wire [6:0]              funnel_atidm;           // From cxatbfunnel_u0 of cxatbfunnel_7_pro.v
wire                    funnel_atreadym;        // From funnel_128_7_slice_u of atb_slice_sync.v
wire                    funnel_atvalidm;        // From cxatbfunnel_u0 of cxatbfunnel_7_pro.v
wire [11:2]             funnel_paddr;           // From cxapbasyncbridge_u_funnel of cxapbasyncbridge_1.v
wire                    funnel_paddr31;         // From cxapbasyncbridge_u_funnel of cxapbasyncbridge_1.v
wire                    funnel_penable;         // From cxapbasyncbridge_u_funnel of cxapbasyncbridge_1.v
wire [31:0]             funnel_prdata;          // From cxatbfunnel_u0 of cxatbfunnel_7_pro.v
wire                    funnel_pready;          // From cxatbfunnel_u0 of cxatbfunnel_7_pro.v
wire                    funnel_psel;            // From cxapbasyncbridge_u_funnel of cxapbasyncbridge_1.v
wire                    funnel_pslverr;         // From cxatbfunnel_u0 of cxatbfunnel_7_pro.v
wire [31:0]             funnel_pwdata;          // From cxapbasyncbridge_u_funnel of cxapbasyncbridge_1.v
wire                    funnel_pwrite;          // From cxapbasyncbridge_u_funnel of cxapbasyncbridge_1.v
wire                    funnel_syncreqm;        // From funnel_128_7_slice_u of atb_slice_sync.v
wire [79:0]             rf_bank_damage;         // From ip_common_reg_u0 of ip_common_reg.v, ...
wire [79:0]             rf_bank_ddr_damage;     // From ip_common_reg_u0 of ip_common_reg.v, ...
wire                    rf_buffer_intlv_mode;   // From ip_common_reg_u0 of ip_common_reg.v
wire                    rf_buffer_mode;         // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              rf_ddr_channel_size;    // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              rf_ddr_intlv_bankid_0;  // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              rf_ddr_intlv_bankid_1;  // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              rf_ddr_intlv_bankid_10; // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              rf_ddr_intlv_bankid_11; // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              rf_ddr_intlv_bankid_12; // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              rf_ddr_intlv_bankid_13; // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              rf_ddr_intlv_bankid_14; // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              rf_ddr_intlv_bankid_15; // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              rf_ddr_intlv_bankid_16; // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              rf_ddr_intlv_bankid_17; // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              rf_ddr_intlv_bankid_18; // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              rf_ddr_intlv_bankid_19; // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              rf_ddr_intlv_bankid_2;  // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              rf_ddr_intlv_bankid_20; // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              rf_ddr_intlv_bankid_21; // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              rf_ddr_intlv_bankid_22; // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              rf_ddr_intlv_bankid_23; // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              rf_ddr_intlv_bankid_24; // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              rf_ddr_intlv_bankid_25; // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              rf_ddr_intlv_bankid_26; // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              rf_ddr_intlv_bankid_27; // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              rf_ddr_intlv_bankid_28; // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              rf_ddr_intlv_bankid_29; // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              rf_ddr_intlv_bankid_3;  // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              rf_ddr_intlv_bankid_30; // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              rf_ddr_intlv_bankid_31; // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              rf_ddr_intlv_bankid_32; // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              rf_ddr_intlv_bankid_33; // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              rf_ddr_intlv_bankid_34; // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              rf_ddr_intlv_bankid_35; // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              rf_ddr_intlv_bankid_36; // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              rf_ddr_intlv_bankid_37; // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              rf_ddr_intlv_bankid_38; // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              rf_ddr_intlv_bankid_39; // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              rf_ddr_intlv_bankid_4;  // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              rf_ddr_intlv_bankid_40; // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              rf_ddr_intlv_bankid_41; // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              rf_ddr_intlv_bankid_42; // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              rf_ddr_intlv_bankid_43; // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              rf_ddr_intlv_bankid_44; // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              rf_ddr_intlv_bankid_45; // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              rf_ddr_intlv_bankid_46; // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              rf_ddr_intlv_bankid_47; // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              rf_ddr_intlv_bankid_48; // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              rf_ddr_intlv_bankid_49; // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              rf_ddr_intlv_bankid_5;  // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              rf_ddr_intlv_bankid_50; // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              rf_ddr_intlv_bankid_51; // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              rf_ddr_intlv_bankid_52; // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              rf_ddr_intlv_bankid_53; // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              rf_ddr_intlv_bankid_54; // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              rf_ddr_intlv_bankid_55; // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              rf_ddr_intlv_bankid_56; // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              rf_ddr_intlv_bankid_57; // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              rf_ddr_intlv_bankid_58; // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              rf_ddr_intlv_bankid_59; // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              rf_ddr_intlv_bankid_6;  // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              rf_ddr_intlv_bankid_60; // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              rf_ddr_intlv_bankid_61; // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              rf_ddr_intlv_bankid_62; // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              rf_ddr_intlv_bankid_63; // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              rf_ddr_intlv_bankid_64; // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              rf_ddr_intlv_bankid_65; // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              rf_ddr_intlv_bankid_66; // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              rf_ddr_intlv_bankid_67; // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              rf_ddr_intlv_bankid_68; // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              rf_ddr_intlv_bankid_69; // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              rf_ddr_intlv_bankid_7;  // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              rf_ddr_intlv_bankid_70; // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              rf_ddr_intlv_bankid_71; // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              rf_ddr_intlv_bankid_72; // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              rf_ddr_intlv_bankid_73; // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              rf_ddr_intlv_bankid_74; // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              rf_ddr_intlv_bankid_75; // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              rf_ddr_intlv_bankid_76; // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              rf_ddr_intlv_bankid_77; // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              rf_ddr_intlv_bankid_78; // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              rf_ddr_intlv_bankid_79; // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              rf_ddr_intlv_bankid_8;  // From ip_common_reg_u0 of ip_common_reg.v
wire [6:0]              rf_ddr_intlv_bankid_9;  // From ip_common_reg_u0 of ip_common_reg.v
wire [1:0]              rf_ddr_intlv_mode;      // From ip_common_reg_u0 of ip_common_reg.v
wire [31:0]             rf_debug_0;             // From intlv_main_u0 of intlv.v
wire [31:0]             rf_debug_1;             // From intlv_main_u0 of intlv.v
wire [31:0]             rf_debug_2;             // From intlv_main_u0 of intlv.v
wire [31:0]             rf_debug_3;             // From intlv_main_u0 of intlv.v
wire [3:0]              rf_setid_sel_0_0;       // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              rf_setid_sel_0_1;       // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              rf_setid_sel_0_2;       // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              rf_setid_sel_0_3;       // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              rf_setid_sel_0_4;       // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              rf_setid_sel_0_5;       // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              rf_setid_sel_0_6;       // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              rf_setid_sel_0_7;       // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              rf_setid_sel_1_0;       // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              rf_setid_sel_1_1;       // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              rf_setid_sel_1_2;       // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              rf_setid_sel_1_3;       // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              rf_setid_sel_1_4;       // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              rf_setid_sel_1_5;       // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              rf_setid_sel_1_6;       // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              rf_setid_sel_1_7;       // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              rf_setid_sel_2_0;       // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              rf_setid_sel_2_1;       // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              rf_setid_sel_2_2;       // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              rf_setid_sel_2_3;       // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              rf_setid_sel_2_4;       // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              rf_setid_sel_2_5;       // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              rf_setid_sel_2_6;       // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              rf_setid_sel_2_7;       // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              rf_setid_sel_3_0;       // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              rf_setid_sel_3_1;       // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              rf_setid_sel_3_2;       // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              rf_setid_sel_3_3;       // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              rf_setid_sel_3_4;       // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              rf_setid_sel_3_5;       // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              rf_setid_sel_3_6;       // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              rf_setid_sel_3_7;       // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              rf_setid_sel_4_0;       // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              rf_setid_sel_4_1;       // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              rf_setid_sel_4_2;       // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              rf_setid_sel_4_3;       // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              rf_setid_sel_4_4;       // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              rf_setid_sel_4_5;       // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              rf_setid_sel_4_6;       // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              rf_setid_sel_4_7;       // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              rf_setid_sel_5_0;       // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              rf_setid_sel_5_1;       // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              rf_setid_sel_5_2;       // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              rf_setid_sel_5_3;       // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              rf_setid_sel_5_4;       // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              rf_setid_sel_5_5;       // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              rf_setid_sel_5_6;       // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              rf_setid_sel_5_7;       // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              rf_setid_sel_6_0;       // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              rf_setid_sel_6_1;       // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              rf_setid_sel_6_2;       // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              rf_setid_sel_6_3;       // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              rf_setid_sel_6_4;       // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              rf_setid_sel_6_5;       // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              rf_setid_sel_6_6;       // From ip_common_reg_u0 of ip_common_reg.v
wire [3:0]              rf_setid_sel_6_7;       // From ip_common_reg_u0 of ip_common_reg.v
wire [5:0]              unused_cti_etf_trigout; // From u_cxcti_etf of cxcti.v
wire [5:0]              unused_cti_etr_trigout; // From u_cxcti_etr of cxcti.v
// End of automatics

wire    [18:0]  funnel_paddr30_12_noused;
//wire    [18:0]  replicator_paddr30_12_noused;
wire    [18:0]  etf_paddr30_12_noused;
wire    [1:0]   funnel_paddr1_0_noused;
//wire    [1:0]   replicator_paddr1_0_noused;
wire    [1:0]   etf_paddr1_0_noused;

assign etf_etr_interrupt = |{etf_flushin, etf_trigin, etr_flushin, etr_trigin};

//**************************************
//   apb async for funnel/replicator/etr/etf
//**************************************

/* cxapbasyncbridge_1 auto_template "cxapbasyncbridge_u_\(.*\)"(
//slave port
    .pclkens        (1'b1),
    .pclks          (dbg_clk),
    .presetsn       (dbg_rstn),

    .paddrs         ({apbic_paddr31_to_@, 19'd0, apbic_paddr_to_@[11:2], 2'd0}),
    .\(p.*\)s       (apbic_\1_to_@[]),

//master port 
    .pclkenm        (1'b1),
    .pclkm          (trace_clk),
    .presetmn       (trace_rstn),

    .paddrm         ({@_paddr31, @_paddr30_12_noused[18:0], @_paddr[11:2], @_paddr1_0_noused[1:0]}),
    .\(p.*\)m       (@_\1[]),
);
*/

cxapbasyncbridge_1 
cxapbasyncbridge_u_funnel (
/*autoinst*/
                           // Outputs
                           .prdatas             (apbic_prdata_to_funnel[31:0]), // Templated
                           .pslverrs            (apbic_pslverr_to_funnel), // Templated
                           .preadys             (apbic_pready_to_funnel), // Templated
                           .paddrm              ({funnel_paddr31, funnel_paddr30_12_noused[18:0], funnel_paddr[11:2], funnel_paddr1_0_noused[1:0]}), // Templated
                           .pwdatam             (funnel_pwdata[31:0]), // Templated
                           .pwritem             (funnel_pwrite), // Templated
                           .penablem            (funnel_penable), // Templated
                           .pselm               (funnel_psel),   // Templated
                           // Inputs
                           .pclkens             (1'b1),          // Templated
                           .pclks               (dbg_clk),       // Templated
                           .presetsn            (dbg_rstn),      // Templated
                           .paddrs              ({apbic_paddr31_to_funnel, 19'd0, apbic_paddr_to_funnel[11:2], 2'd0}), // Templated
                           .pwdatas             (apbic_pwdata_to_funnel[31:0]), // Templated
                           .pwrites             (apbic_pwrite_to_funnel), // Templated
                           .penables            (apbic_penable_to_funnel), // Templated
                           .psels               (apbic_psel_to_funnel), // Templated
                           .pclkenm             (1'b1),          // Templated
                           .pclkm               (trace_clk),     // Templated
                           .presetmn            (trace_rstn),    // Templated
                           .prdatam             (funnel_prdata[31:0]), // Templated
                           .pslverrm            (funnel_pslverr), // Templated
                           .preadym             (funnel_pready)); // Templated

//cxapbasyncbridge_1 
//cxapbasyncbridge_u_replicator (
///*autoinst*/);

cxapbasyncbridge_1 
cxapbasyncbridge_u_etf (
/*autoinst*/
                        // Outputs
                        .prdatas        (apbic_prdata_to_etf[31:0]), // Templated
                        .pslverrs       (apbic_pslverr_to_etf),  // Templated
                        .preadys        (apbic_pready_to_etf),   // Templated
                        .paddrm         ({etf_paddr31, etf_paddr30_12_noused[18:0], etf_paddr[11:2], etf_paddr1_0_noused[1:0]}), // Templated
                        .pwdatam        (etf_pwdata[31:0]),      // Templated
                        .pwritem        (etf_pwrite),            // Templated
                        .penablem       (etf_penable),           // Templated
                        .pselm          (etf_psel),              // Templated
                        // Inputs
                        .pclkens        (1'b1),                  // Templated
                        .pclks          (dbg_clk),               // Templated
                        .presetsn       (dbg_rstn),              // Templated
                        .paddrs         ({apbic_paddr31_to_etf, 19'd0, apbic_paddr_to_etf[11:2], 2'd0}), // Templated
                        .pwdatas        (apbic_pwdata_to_etf[31:0]), // Templated
                        .pwrites        (apbic_pwrite_to_etf),   // Templated
                        .penables       (apbic_penable_to_etf),  // Templated
                        .psels          (apbic_psel_to_etf),     // Templated
                        .pclkenm        (1'b1),                  // Templated
                        .pclkm          (trace_clk),             // Templated
                        .presetmn       (trace_rstn),            // Templated
                        .prdatam        (etf_prdata[31:0]),      // Templated
                        .pslverrm       (etf_pslverr),           // Templated
                        .preadym        (etf_pready));           // Templated

cxapbasyncbridge_1 
cxapbasyncbridge_u_etr (
/*autoinst*/
                        // Outputs
                        .prdatas        (apbic_prdata_to_etr[31:0]), // Templated
                        .pslverrs       (apbic_pslverr_to_etr),  // Templated
                        .preadys        (apbic_pready_to_etr),   // Templated
                        .paddrm         ({etr_paddr31, etr_paddr30_12_noused[18:0], etr_paddr[11:2], etr_paddr1_0_noused[1:0]}), // Templated
                        .pwdatam        (etr_pwdata[31:0]),      // Templated
                        .pwritem        (etr_pwrite),            // Templated
                        .penablem       (etr_penable),           // Templated
                        .pselm          (etr_psel),              // Templated
                        // Inputs
                        .pclkens        (1'b1),                  // Templated
                        .pclks          (dbg_clk),               // Templated
                        .presetsn       (dbg_rstn),              // Templated
                        .paddrs         ({apbic_paddr31_to_etr, 19'd0, apbic_paddr_to_etr[11:2], 2'd0}), // Templated
                        .pwdatas        (apbic_pwdata_to_etr[31:0]), // Templated
                        .pwrites        (apbic_pwrite_to_etr),   // Templated
                        .penables       (apbic_penable_to_etr),  // Templated
                        .psels          (apbic_psel_to_etr),     // Templated
                        .pclkenm        (1'b1),                  // Templated
                        .pclkm          (trace_clk),             // Templated
                        .presetmn       (trace_rstn),            // Templated
                        .prdatam        (etr_prdata[31:0]),      // Templated
                        .pslverrm       (etr_pslverr),           // Templated
                        .preadym        (etr_pready));           // Templated


//**************************************
//   atb trace data 
//**************************************
//        
//          ______________
//          |    funnel  |
//          |____________|
//                 |128
//          _______|______
//          |     ETF    |
//          |____________|
//                 |128
// ________________|__________________
// |         replicator              |
// |_________________________________|
//        |0(128)       |1（128）
//        |             |
//  downsizer(32)       |
//        |             |
//      TPIU           ETR


/* cxatbfunnel_7_pro auto_template (
    .clk            (trace_clk),
    .resetn         (trace_rstn),
    
    .pclkendbg      (1'b1),
    .paddrdbg31     (funnel_paddr31),
    .\(p.*\)dbg     (funnel_\1[]),
    
    .\(.*m\)        (funnel_\1[]),
    .\(.*s.*\)      (funnel_\1[]),
);
*/

cxatbfunnel_7_pro 
cxatbfunnel_u0 (
/*autoinst*/
                // Outputs
                .preadydbg              (funnel_pready),         // Templated
                .pslverrdbg             (funnel_pslverr),        // Templated
                .prdatadbg              (funnel_prdata[31:0]),   // Templated
                .atvalidm               (funnel_atvalidm),       // Templated
                .afreadym               (funnel_afreadym),       // Templated
                .atidm                  (funnel_atidm[6:0]),     // Templated
                .atdatam                (funnel_atdatam[128-1:0]), // Templated
                .atbytesm               (funnel_atbytesm[3:0]),  // Templated
                .atreadys2              (funnel_atreadys2),      // Templated
                .afvalids2              (funnel_afvalids2),      // Templated
                .syncreqs2              (funnel_syncreqs2),      // Templated
                .atreadys3              (funnel_atreadys3),      // Templated
                .afvalids3              (funnel_afvalids3),      // Templated
                .syncreqs3              (funnel_syncreqs3),      // Templated
                .atreadys4              (funnel_atreadys4),      // Templated
                .afvalids4              (funnel_afvalids4),      // Templated
                .syncreqs4              (funnel_syncreqs4),      // Templated
                .atreadys5              (funnel_atreadys5),      // Templated
                .afvalids5              (funnel_afvalids5),      // Templated
                .syncreqs5              (funnel_syncreqs5),      // Templated
                .atreadys6              (funnel_atreadys6),      // Templated
                .afvalids6              (funnel_afvalids6),      // Templated
                .syncreqs6              (funnel_syncreqs6),      // Templated
                .atreadys0              (funnel_atreadys0),      // Templated
                .afvalids0              (funnel_afvalids0),      // Templated
                .syncreqs0              (funnel_syncreqs0),      // Templated
                .atreadys1              (funnel_atreadys1),      // Templated
                .afvalids1              (funnel_afvalids1),      // Templated
                .syncreqs1              (funnel_syncreqs1),      // Templated
                // Inputs
                .clk                    (trace_clk),             // Templated
                .resetn                 (trace_rstn),            // Templated
                .pclkendbg              (1'b1),                  // Templated
                .pseldbg                (funnel_psel),           // Templated
                .penabledbg             (funnel_penable),        // Templated
                .pwritedbg              (funnel_pwrite),         // Templated
                .paddrdbg31             (funnel_paddr31),        // Templated
                .paddrdbg               (funnel_paddr[11:2]),    // Templated
                .pwdatadbg              (funnel_pwdata[31:0]),   // Templated
                .atvalids0              (funnel_atvalids0),      // Templated
                .afreadys0              (funnel_afreadys0),      // Templated
                .atids0                 (funnel_atids0[6:0]),    // Templated
                .atdatas0               (funnel_atdatas0[128-1:0]), // Templated
                .atbytess0              (funnel_atbytess0[3:0]), // Templated
                .atvalids1              (funnel_atvalids1),      // Templated
                .afreadys1              (funnel_afreadys1),      // Templated
                .atids1                 (funnel_atids1[6:0]),    // Templated
                .atdatas1               (funnel_atdatas1[128-1:0]), // Templated
                .atbytess1              (funnel_atbytess1[3:0]), // Templated
                .atvalids2              (funnel_atvalids2),      // Templated
                .afreadys2              (funnel_afreadys2),      // Templated
                .atids2                 (funnel_atids2[6:0]),    // Templated
                .atdatas2               (funnel_atdatas2[128-1:0]), // Templated
                .atbytess2              (funnel_atbytess2[3:0]), // Templated
                .atvalids3              (funnel_atvalids3),      // Templated
                .afreadys3              (funnel_afreadys3),      // Templated
                .atids3                 (funnel_atids3[6:0]),    // Templated
                .atdatas3               (funnel_atdatas3[128-1:0]), // Templated
                .atbytess3              (funnel_atbytess3[3:0]), // Templated
                .atvalids4              (funnel_atvalids4),      // Templated
                .afreadys4              (funnel_afreadys4),      // Templated
                .atids4                 (funnel_atids4[6:0]),    // Templated
                .atdatas4               (funnel_atdatas4[128-1:0]), // Templated
                .atbytess4              (funnel_atbytess4[3:0]), // Templated
                .atvalids5              (funnel_atvalids5),      // Templated
                .afreadys5              (funnel_afreadys5),      // Templated
                .atids5                 (funnel_atids5[6:0]),    // Templated
                .atdatas5               (funnel_atdatas5[128-1:0]), // Templated
                .atbytess5              (funnel_atbytess5[3:0]), // Templated
                .atvalids6              (funnel_atvalids6),      // Templated
                .afreadys6              (funnel_afreadys6),      // Templated
                .atids6                 (funnel_atids6[6:0]),    // Templated
                .atdatas6               (funnel_atdatas6[128-1:0]), // Templated
                .atbytess6              (funnel_atbytess6[3:0]), // Templated
                .atreadym               (funnel_atreadym),       // Templated
                .afvalidm               (funnel_afvalidm),       // Templated
                .syncreqm               (funnel_syncreqm));      // Templated


///////////////////////////////////////add funnel8 output slice////////////////////////////
/*atb_slice_sync   auto_template "\(.*\)_slice_u"(
    .clk              (trace_clk),
    .resetn           (trace_rstn),
    .src_\(.*\)       (funnel_\1m[]),
    .dst_\(.*\)       (@_slice_atb_\1[]),
);
*/

atb_slice_sync 
#( .SLICE_NUM_ATB (4),
   .ATB_BYTES_WIDTH (4),
   .ATB_DATA_WIDTH (128))
funnel_128_7_slice_u (/*autoinst*/
                      // Outputs
                      .dst_afready      (funnel_128_7_slice_atb_afready), // Templated
                      .dst_atbytes      (funnel_128_7_slice_atb_atbytes[3:0]), // Templated
                      .dst_atdata       (funnel_128_7_slice_atb_atdata[127:0]), // Templated
                      .dst_atid         (funnel_128_7_slice_atb_atid[6:0]), // Templated
                      .dst_atvalid      (funnel_128_7_slice_atb_atvalid), // Templated
                      .src_afvalid      (funnel_afvalidm),       // Templated
                      .src_atready      (funnel_atreadym),       // Templated
                      .src_syncreq      (funnel_syncreqm),       // Templated
                      // Inputs
                      .clk              (trace_clk),             // Templated
                      .resetn           (trace_rstn),            // Templated
                      .dst_afvalid      (funnel_128_7_slice_atb_afvalid), // Templated
                      .dst_atready      (funnel_128_7_slice_atb_atready), // Templated
                      .dst_syncreq      (funnel_128_7_slice_atb_syncreq), // Templated
                      .src_afready      (funnel_afreadym),       // Templated
                      .src_atbytes      (funnel_atbytesm[3:0]),  // Templated
                      .src_atdata       (funnel_atdatam[127:0]), // Templated
                      .src_atid         (funnel_atidm[6:0]),     // Templated
                      .src_atvalid      (funnel_atvalidm));      // Templated


/* CXTMC_ETF auto_template (
              .CLK                      (trace_clk),
              .RESETn                   (trace_rstn),


              .PADDRDBG31               (etf_paddr31),
              .PCLKENDBG                (1'b1),
              .\(P.*\)DBG               (etf_@"(downcase \\"\1\\")"[]),
              
              .\(ATDATA\)S              (funnel_128_7_slice_atb_@"(downcase \\"\1\\")"[127:0]),
              .\(AT.*\)S                (funnel_128_7_slice_atb_@"(downcase \\"\1\\")"[]),
              .\(AF.*\)S                (funnel_128_7_slice_atb_@"(downcase \\"\1\\")"[]),
              .SYNCREQS                 (funnel_128_7_slice_atb_syncreq),

              .\(ATDATA\)M              (etf_@"(downcase \\"\1\\")"[127:0]),
              .\(AT.*\)M                (etf_@"(downcase \\"\1\\")"[]),
              .\(AF.*\)M                (etf_@"(downcase \\"\1\\")"[]),
              .SYNCREQM                 (etf_syncreq[]),

              .\(MEM\(D\|Q\).*\)        (etf_@"(downcase \\"\1\\")"[255:0]),
              .\(MEMADDR\)               (etf_@"(downcase \\"\1\\")"[5:0]),
              .\(MEM.*\)                (etf_@"(downcase \\"\1\\")"[]),

              .DBGEN                    (1'b1),
              .SPIDEN                   (1'b1),

              .CSYSREQ                  (1'b1),
              .CACTIVE                  (),
              .CSYSACK                  (),

              .FULL                     (etf_full[]),
              .ACQCOMP                  (etf_acqcomp[]),

              .TRIGIN                   (etf_trigin[]),
              .FLUSHIN                  (etf_flushin[]),

              .DFTTESTMODE              (dft_test_mode),
              .DFTCLKDISABLE            (1'b0));
*/                          

CXTMC_ETF 
cxtmc_etf_u0 (
/*autoinst*/
              // Outputs
              .ATVALIDM                 (etf_atvalid),           // Templated
              .ATIDM                    (etf_atid[6:0]),         // Templated
              .ATBYTESM                 (etf_atbytes[3:0]),      // Templated
              .ATDATAM                  (etf_atdata[127:0]),     // Templated
              .AFREADYM                 (etf_afready),           // Templated
              .ATREADYS                 (funnel_128_7_slice_atb_atready), // Templated
              .AFVALIDS                 (funnel_128_7_slice_atb_afvalid), // Templated
              .PREADYDBG                (etf_pready),            // Templated
              .PSLVERRDBG               (etf_pslverr),           // Templated
              .PRDATADBG                (etf_prdata[31:0]),      // Templated
              .MEMCEN                   (etf_memcen),            // Templated
              .MEMADDR                  (etf_memaddr[5:0]),      // Templated
              .MEMWEN                   (etf_memwen),            // Templated
              .MEMD                     (etf_memd[255:0]),       // Templated
              .CACTIVE                  (),                      // Templated
              .CSYSACK                  (),                      // Templated
              .SYNCREQS                 (funnel_128_7_slice_atb_syncreq), // Templated
              .FULL                     (etf_full),              // Templated
              .ACQCOMP                  (etf_acqcomp),           // Templated
              // Inputs
              .CLK                      (trace_clk),             // Templated
              .RESETn                   (trace_rstn),            // Templated
              .ATREADYM                 (etf_atready),           // Templated
              .AFVALIDM                 (etf_afvalid),           // Templated
              .ATVALIDS                 (funnel_128_7_slice_atb_atvalid), // Templated
              .ATIDS                    (funnel_128_7_slice_atb_atid[6:0]), // Templated
              .ATBYTESS                 (funnel_128_7_slice_atb_atbytes[3:0]), // Templated
              .ATDATAS                  (funnel_128_7_slice_atb_atdata[127:0]), // Templated
              .AFREADYS                 (funnel_128_7_slice_atb_afready), // Templated
              .PCLKENDBG                (1'b1),                  // Templated
              .PSELDBG                  (etf_psel),              // Templated
              .PENABLEDBG               (etf_penable),           // Templated
              .PWRITEDBG                (etf_pwrite),            // Templated
              .PADDRDBG31               (etf_paddr31),           // Templated
              .PADDRDBG                 (etf_paddr[11:2]),       // Templated
              .PWDATADBG                (etf_pwdata[31:0]),      // Templated
              .MEMQ                     (etf_memq[255:0]),       // Templated
              .DBGEN                    (1'b1),                  // Templated
              .SPIDEN                   (1'b1),                  // Templated
              .CSYSREQ                  (1'b1),                  // Templated
              .TRIGIN                   (etf_trigin),            // Templated
              .FLUSHIN                  (etf_flushin),           // Templated
              .SYNCREQM                 (etf_syncreq),           // Templated
              .DFTTESTMODE              (dft_test_mode),         // Templated
              .DFTCLKDISABLE            (1'b0));                         // Templated

/* ss_coresight_sp_64x256_wrapper auto_template ( 
                                     .memq              (etf_memq[255:0]),
                                     .mem_addr          (etf_memaddr[5:0]),
                                     .memd              (etf_memd[255:0]),
                                     .mem_cen           (etf_memcen),
                                     .mem_wen           (etf_memwen),
                                     .clk               (trace_clk),                                                           
    ); */
ss_coresight_sp_64x256_wrapper etf_mem(/*autoinst*/
                                       // Outputs
                                       .memq            (etf_memq[255:0]), // Templated
                                       // Inputs
                                       .clk             (trace_clk),     // Templated
                                       .mem_cen         (etf_memcen),    // Templated
                                       .mem_wen         (etf_memwen),    // Templated
                                       .mem_addr        (etf_memaddr[5:0]), // Templated
                                       .memd            (etf_memd[255:0])); // Templated


/* cxatbreplicator_128 auto_template (
    .clk            (trace_clk),
    .resetn         (trace_rstn),

    .pclkendbg      (1'b1),
    .paddrdbg31     (replicator_paddr31[]),
    .\(p.*\)dbg     (replicator_\1[]),

    .\(.*\)s        (etf_\1[]),

    .\(.*m0.*\)      (replicator_\1_to_downsizer[]),
    .\(.*m1.*\)      (replicator_\1_to_etr[]),
);
*/
//cxatbreplicator_128 
//cxatbreplicator_u0 (
///*autoinst*/);


/* cxatbdownsizer auto_template (
    .clk            (trace_clk),
    .resetn         (trace_rstn),

    .\(.*\)s        (replicator_\1m0_to_downsizer[]),

    .syncreqm      (1'b0),
    .\(.*\)m      (downsizer_\1[]),
);
*/
//cxatbdownsizer cxatbdownsizer_u0 (/*autoinst*/);




/* cxtpiu auto_template (
//trace input signal
    .atclk          (trace_clk),        //syn with replicator clock
    .atclken        (1'b1),
    .atresetn       (trace_rstn),

    .\(a.*\)s       (downsizer_\1[]),

    .\(flush.*\)       (tpiu_\1[]),
    .\(trig.*\)        (tpiu_\1[]),


//config signal
    .pclkdbg        (dbg_clk),
    .pclkendbg      (1'b1),
    .presetdbgn     (dbg_rstn),

    .paddrdbg31     (apbic_paddr31_to_tpiu[]),
    .\(p.*\)dbg     (apbic_\1_to_tpiu[]),

//trace port signal
    .traceclkin     (tpiu_port_clk_in[]),
    .tresetn        (tpiu_port_rstn_in[]),
        
    .tpctl          (1'b0),    //dont need tracectl in soc pin, tie0
    .tpmaxdatasize  (5'h1f),   //used all of tracedata in soc pin

    .traceclk       (tpiu_port_clk_to_io[]),
    .tracedata      (tpiu_port_data_to_io[]),
    .tracectl       (),

    .extctlout      (),        //only in register, dont use
    .extctlin       (8'h0),  
);*/

//cxtpiu 
//cxtpiu_u0(
///*autoinst*/);

assign etr_buser_to_reg = etr_axi_buser;
assign etr_ruser_to_reg = etr_axi_ruser;
/* CXTMC_ETR auto_template (
              .CLK                      (trace_clk),
              .RESETn                   (trace_rstn),
              .PCLKENDBG                (1'b1),

        
              .\(PADDR\)DBG31           (etr_@"(downcase \\"\1\\")"31[]),
              .\(P.*\)DBG               (etr_@"(downcase \\"\1\\")"[]),


              .\(.*DATA\)S              (etf_@"(downcase \\"\1\\")"[127:0]),
              .\(.*\)S                  (etf_@"(downcase \\"\1\\")"[]),
              .SYNCREQS                 (etf_syncreq),

              .\(.*DATA.*\)M            (etr_axi_@"(downcase \\"\1\\")"[127:0]),
              .\(.*STRB.*\)M            (etr_axi_@"(downcase \\"\1\\")"[15:0]),
              .AWLOCKM                  (),
              .ARLOCKM                  (),
              .\(AW.*\)M                (etr_axi_@"(downcase \\"\1\\")"_t[]),
              .\(AR.*\)M                (etr_axi_@"(downcase \\"\1\\")"_t[]),
              .\(.*\)M                  (etr_axi_@"(downcase \\"\1\\")"[]),

              .TRIGIN                   (etr_trigin[]),
              .FLUSHIN                  (etr_flushin[]),
              .FULL                     (etr_full[]),
              .ACQCOMP                  (etr_acqcomp[]),

              .DBGEN                    (1'b1),
              .SPIDEN                   (1'b1),

              .CSYSREQ                  (1'b1),
              .CACTIVE                  (),
              .CSYSACK                  (),


              .DFTTESTMODE              (dft_test_mode),
              .DFTCLKDISABLE            (1'b0));
*/

CXTMC_ETR 
cxtmc_etr_u0 (
/*autoinst*/
              // Outputs
              .ATREADYS                 (etf_atready),           // Templated
              .AFVALIDS                 (etf_afvalid),           // Templated
              .PREADYDBG                (etr_pready),            // Templated
              .PSLVERRDBG               (etr_pslverr),           // Templated
              .PRDATADBG                (etr_prdata[31:0]),      // Templated
              .ARADDRM                  (etr_axi_araddr_t[39:0]), // Templated
              .ARLENM                   (etr_axi_arlen_t[3:0]),  // Templated
              .ARSIZEM                  (etr_axi_arsize_t[2:0]), // Templated
              .ARBURSTM                 (etr_axi_arburst_t[1:0]), // Templated
              .ARLOCKM                  (),                      // Templated
              .ARCACHEM                 (etr_axi_arcache_t[3:0]), // Templated
              .ARPROTM                  (etr_axi_arprot_t[2:0]), // Templated
              .ARVALIDM                 (etr_axi_arvalid_t),     // Templated
              .RREADYM                  (etr_axi_rready),        // Templated
              .AWADDRM                  (etr_axi_awaddr_t[39:0]), // Templated
              .AWLENM                   (etr_axi_awlen_t[3:0]),  // Templated
              .AWSIZEM                  (etr_axi_awsize_t[2:0]), // Templated
              .AWBURSTM                 (etr_axi_awburst_t[1:0]), // Templated
              .AWLOCKM                  (),                      // Templated
              .AWCACHEM                 (etr_axi_awcache_t[3:0]), // Templated
              .AWPROTM                  (etr_axi_awprot_t[2:0]), // Templated
              .AWVALIDM                 (etr_axi_awvalid_t),     // Templated
              .WDATAM                   (etr_axi_wdata[127:0]),  // Templated
              .WSTRBM                   (etr_axi_wstrb[15:0]),   // Templated
              .WLASTM                   (etr_axi_wlast),         // Templated
              .WVALIDM                  (etr_axi_wvalid),        // Templated
              .BREADYM                  (etr_axi_bready),        // Templated
              .CACTIVE                  (),                      // Templated
              .CSYSACK                  (),                      // Templated
              .SYNCREQS                 (etf_syncreq),           // Templated
              .FULL                     (etr_full),              // Templated
              .ACQCOMP                  (etr_acqcomp),           // Templated
              // Inputs
              .CLK                      (trace_clk),             // Templated
              .RESETn                   (trace_rstn),            // Templated
              .ATVALIDS                 (etf_atvalid),           // Templated
              .ATIDS                    (etf_atid[6:0]),         // Templated
              .ATBYTESS                 (etf_atbytes[3:0]),      // Templated
              .ATDATAS                  (etf_atdata[127:0]),     // Templated
              .AFREADYS                 (etf_afready),           // Templated
              .PCLKENDBG                (1'b1),                  // Templated
              .PSELDBG                  (etr_psel),              // Templated
              .PENABLEDBG               (etr_penable),           // Templated
              .PWRITEDBG                (etr_pwrite),            // Templated
              .PADDRDBG31               (etr_paddr31),           // Templated
              .PADDRDBG                 (etr_paddr[11:2]),       // Templated
              .PWDATADBG                (etr_pwdata[31:0]),      // Templated
              .ARREADYM                 (etr_axi_arready_t),     // Templated
              .RDATAM                   (etr_axi_rdata[127:0]),  // Templated
              .RRESPM                   (etr_axi_rresp[1:0]),    // Templated
              .RLASTM                   (etr_axi_rlast),         // Templated
              .RVALIDM                  (etr_axi_rvalid),        // Templated
              .AWREADYM                 (etr_axi_awready_t),     // Templated
              .WREADYM                  (etr_axi_wready),        // Templated
              .BRESPM                   (etr_axi_bresp[1:0]),    // Templated
              .BVALIDM                  (etr_axi_bvalid),        // Templated
              .DBGEN                    (1'b1),                  // Templated
              .SPIDEN                   (1'b1),                  // Templated
              .CSYSREQ                  (1'b1),                  // Templated
              .TRIGIN                   (etr_trigin),            // Templated
              .FLUSHIN                  (etr_flushin),           // Templated
              .DFTTESTMODE              (dft_test_mode),         // Templated
              .DFTCLKDISABLE            (1'b0));                         // Templated

/* etr_usermge auto_template (
    .clk            (trace_clk),
    .rstn         (trace_rstn),

    .etr_id_ctrl      (etr_id_ctrl_fr_reg[]),
    .\(etr_axi_a[wr].*\)        (\1_t[]),
    .\(etr.*\)        (\1[]),
);
*/
etr_usermge etr_usermge_u0 (/*autoinst*/
                            // Outputs
                            .etr_axi_awid       (etr_axi_awid_t[5:0]), // Templated
                            .etr_axi_arid       (etr_axi_arid_t[5:0]), // Templated
                            // Inputs
                            .clk                (trace_clk),     // Templated
                            .rstn               (trace_rstn),    // Templated
                            .etr_axi_awvalid    (etr_axi_awvalid_t), // Templated
                            .etr_axi_awready    (etr_axi_awready_t), // Templated
                            .etr_axi_bvalid     (etr_axi_bvalid), // Templated
                            .etr_axi_bready     (etr_axi_bready), // Templated
                            .etr_id_ctrl        (etr_id_ctrl_fr_reg[31:0]), // Templated
                            .etr_axi_bid        (etr_axi_bid[5:0]), // Templated
                            .etr_axi_rid        (etr_axi_rid[5:0])); // Templated



//**************************************
//   trigger connect
//**************************************
//      ________    ________     ________
//      |  ETF |    |  ETR |     | TPIU |
//      |______|    |______|     |______|
//          |           |            |
//       ___|__     ____|__      ____|__
//      | CTI0 |    | CTI1 |     | CTI2 |
//      |______|    |______|     |______|
//          |           |            |
// _________|___________|____________|__________
// |                   CTM0                     |
// |____________________________________________|
//                     |            
//                     |            


/* cxcti auto_template "u_cxcti_\(.*\)" (
//apb domain
    .pclkdbg                (dbg_clk),
    .pclkendbg              (1'b1),
    .presetdbgn             (dbg_rstn),

    .\(paddr\)dbg31         (apbic_\131_to_cti_@[]),
    .\(p.*\)dbg             (apbic_\1_to_cti_@[]),

//cti domain
    .cticlk                 (dbg_clk),
    .ctiresetn              (dbg_rstn),
    .cticlken               (1'b1),

    .ctitrigin              ({6'd0,@_acqcomp,@_full}),
    .ctitriginack           (),

    .ctitrigout             ({unused_cti_@_trigout[5:0],@_flushin,@_trigin}),
    .ctitrigoutack          (8'd0),

    .\(ctich.*\)in\(.*\)                (ctm_\1in\2_to_cti_@[3:0]),
    .\(ctich.*\)out\(.*\)                (cti_@_\1out\2_to_ctm[3:0]),

//other
    .ctiapbsbypass          (1'b0),    //apb async

    .cisbypass              (1'b0),    //channel interface sync
    .cihsbypass             (4'h0),    //channel interface handshake sync

    .tisbypassin            (8'h0),   //trigger in interface sync
    .tisbypassack           (8'h0),   //trigger out ack interface sync
    .tihsbypass             (8'h0),   //ctitrigout handshake bypass for sync

    .dbgen                  (1'b1),
    .niden                  (1'b1),
    .tinidensel             (8'hff),   //byass niden mask
    .todbgensel             (8'hff),   //bypass dbgen mask
    .asicctl                (),

)
*/
cxcti u_cxcti_etf (/*autoinst*/
                   // Outputs
                   .preadydbg           (apbic_pready_to_cti_etf), // Templated
                   .prdatadbg           (apbic_prdata_to_cti_etf[31:0]), // Templated
                   .ctitrigout          ({unused_cti_etf_trigout[5:0],etf_flushin,etf_trigin}), // Templated
                   .ctitriginack        (),                      // Templated
                   .ctichout            (cti_etf_ctichout_to_ctm[3:0]), // Templated
                   .ctichinack          (ctm_ctichinack_to_cti_etf[3:0]), // Templated
                   .asicctl             (),                      // Templated
                   // Inputs
                   .cticlk              (dbg_clk),               // Templated
                   .cticlken            (1'b1),                  // Templated
                   .ctiresetn           (dbg_rstn),              // Templated
                   .pclkdbg             (dbg_clk),               // Templated
                   .pclkendbg           (1'b1),                  // Templated
                   .presetdbgn          (dbg_rstn),              // Templated
                   .ctiapbsbypass       (1'b0),                  // Templated
                   .cisbypass           (1'b0),                  // Templated
                   .tisbypassin         (8'h0),                  // Templated
                   .tisbypassack        (8'h0),                  // Templated
                   .cihsbypass          (4'h0),                  // Templated
                   .tihsbypass          (8'h0),                  // Templated
                   .dbgen               (1'b1),                  // Templated
                   .niden               (1'b1),                  // Templated
                   .penabledbg          (apbic_penable_to_cti_etf), // Templated
                   .pseldbg             (apbic_psel_to_cti_etf), // Templated
                   .paddrdbg            (apbic_paddr_to_cti_etf[11:2]), // Templated
                   .paddrdbg31          (apbic_paddr31_to_cti_etf), // Templated
                   .pwritedbg           (apbic_pwrite_to_cti_etf), // Templated
                   .pwdatadbg           (apbic_pwdata_to_cti_etf[31:0]), // Templated
                   .ctitrigin           ({6'd0,etf_acqcomp,etf_full}), // Templated
                   .ctitrigoutack       (8'd0),                  // Templated
                   .ctichin             (ctm_ctichin_to_cti_etf[3:0]), // Templated
                   .ctichoutack         (cti_etf_ctichoutack_to_ctm[3:0]), // Templated
                   .tinidensel          (8'hff),                 // Templated
                   .todbgensel          (8'hff));                // Templated
cxcti u_cxcti_etr (/*autoinst*/
                   // Outputs
                   .preadydbg           (apbic_pready_to_cti_etr), // Templated
                   .prdatadbg           (apbic_prdata_to_cti_etr[31:0]), // Templated
                   .ctitrigout          ({unused_cti_etr_trigout[5:0],etr_flushin,etr_trigin}), // Templated
                   .ctitriginack        (),                      // Templated
                   .ctichout            (cti_etr_ctichout_to_ctm[3:0]), // Templated
                   .ctichinack          (ctm_ctichinack_to_cti_etr[3:0]), // Templated
                   .asicctl             (),                      // Templated
                   // Inputs
                   .cticlk              (dbg_clk),               // Templated
                   .cticlken            (1'b1),                  // Templated
                   .ctiresetn           (dbg_rstn),              // Templated
                   .pclkdbg             (dbg_clk),               // Templated
                   .pclkendbg           (1'b1),                  // Templated
                   .presetdbgn          (dbg_rstn),              // Templated
                   .ctiapbsbypass       (1'b0),                  // Templated
                   .cisbypass           (1'b0),                  // Templated
                   .tisbypassin         (8'h0),                  // Templated
                   .tisbypassack        (8'h0),                  // Templated
                   .cihsbypass          (4'h0),                  // Templated
                   .tihsbypass          (8'h0),                  // Templated
                   .dbgen               (1'b1),                  // Templated
                   .niden               (1'b1),                  // Templated
                   .penabledbg          (apbic_penable_to_cti_etr), // Templated
                   .pseldbg             (apbic_psel_to_cti_etr), // Templated
                   .paddrdbg            (apbic_paddr_to_cti_etr[11:2]), // Templated
                   .paddrdbg31          (apbic_paddr31_to_cti_etr), // Templated
                   .pwritedbg           (apbic_pwrite_to_cti_etr), // Templated
                   .pwdatadbg           (apbic_pwdata_to_cti_etr[31:0]), // Templated
                   .ctitrigin           ({6'd0,etr_acqcomp,etr_full}), // Templated
                   .ctitrigoutack       (8'd0),                  // Templated
                   .ctichin             (ctm_ctichin_to_cti_etr[3:0]), // Templated
                   .ctichoutack         (cti_etr_ctichoutack_to_ctm[3:0]), // Templated
                   .tinidensel          (8'hff),                 // Templated
                   .todbgensel          (8'hff));                // Templated



/* cxcti auto_template "u_cxcti_\(.*\)" (
//apb domain
    .pclkdbg                (dbg_clk),
    .pclkendbg              (1'b1),
    .presetdbgn             (dbg_rstn),

    .\(paddr\)dbg31         (apbic_\131_to_cti_@[]),
    .\(p.*\)dbg             (apbic_\1_to_cti_@[]),

//cti domain
    .cticlk                 (trace_clk),
    .ctiresetn              (trace_rstn),
    .cticlken               (1'b1),

    .ctitrigin              (8'd0),
    .ctitriginack           (),

    .ctitrigout             ({unused_cti_@_trigout[5:0],@_flushin,@_trigin}),
    .ctitrigoutack          ({6'd0,@_flushinack,@_triginack}),

    .\(ctich.*\)in\(.*\)                (ctm_\1in\2_to_cti_@[3:0]),
    .\(ctich.*\)out\(.*\)                (cti_@_\1out\2_to_ctm[3:0]),

//other
    .ctiapbsbypass          (1'b0),    //apb async

    .cisbypass              (1'b0),    //channel interface sync
    .cihsbypass             (4'h0),    //channel interface handshake sync

    .tisbypassin            (8'h0),   //trigger in interface sync
    .tisbypassack           (8'h0),   //trigger out ack interface sync
    .tihsbypass             (8'h0),   //ctitrigout handshake bypass for sync

    .dbgen                  (1'b1),
    .niden                  (1'b1),
    .tinidensel             (8'hff),   //byass niden mask
    .todbgensel             (8'hff),   //bypass dbgen mask
    .asicctl                (),

)
*/
//cxcti u_cxcti_tpiu (/*autoinst*/);



/* cxctm auto_template (
    .ctmclk                 (dbg_clk),
    .ctmresetn              (dbg_rstn),
    .ctmclken               (1'b1),

    .\(ctmch.*[2\|3]\)            (cxctm0_\1[3:0]),    

    .ctm\(ch.*\)out\(.*\)0             (ctm_cti\1in\2_to_cti_etf[3:0]),
    .ctm\(ch.*\)in\(.*\)0              (cti_etf_cti\1out\2_to_ctm[3:0]),
        
    .ctm\(ch.*\)out\(.*\)1             (ctm_cti\1in\2_to_cti_etr[3:0]),
    .ctm\(ch.*\)in\(.*\)1              (cti_etr_cti\1out\2_to_ctm[3:0]),
        
    .cisbypass.*            (1'b0),  //interface sync byass
    .cihsbypass.*           (4'h0),  //handshake sync bypass
)
*/

cxctm  cxctm_u0 (/*autoinst*/
                 // Outputs
                 .ctmchout1             (ctm_ctichin_to_cti_etr[3:0]), // Templated
                 .ctmchout2             (cxctm0_ctmchout2[3:0]), // Templated
                 .ctmchout3             (cxctm0_ctmchout3[3:0]), // Templated
                 .ctmchout0             (ctm_ctichin_to_cti_etf[3:0]), // Templated
                 .ctmchinack1           (cti_etr_ctichoutack_to_ctm[3:0]), // Templated
                 .ctmchinack2           (cxctm0_ctmchinack2[3:0]), // Templated
                 .ctmchinack3           (cxctm0_ctmchinack3[3:0]), // Templated
                 .ctmchinack0           (cti_etf_ctichoutack_to_ctm[3:0]), // Templated
                 // Inputs
                 .ctmresetn             (dbg_rstn),              // Templated
                 .ctmclk                (dbg_clk),               // Templated
                 .ctmclken              (1'b1),                  // Templated
                 .cisbypass1            (1'b0),                  // Templated
                 .cisbypass2            (1'b0),                  // Templated
                 .cisbypass3            (1'b0),                  // Templated
                 .cisbypass0            (1'b0),                  // Templated
                 .cihsbypass1           (4'h0),                  // Templated
                 .cihsbypass2           (4'h0),                  // Templated
                 .cihsbypass3           (4'h0),                  // Templated
                 .cihsbypass0           (4'h0),                  // Templated
                 .ctmchin1              (cti_etr_ctichout_to_ctm[3:0]), // Templated
                 .ctmchin2              (cxctm0_ctmchin2[3:0]),  // Templated
                 .ctmchin3              (cxctm0_ctmchin3[3:0]),  // Templated
                 .ctmchin0              (cti_etf_ctichout_to_ctm[3:0]), // Templated
                 .ctmchoutack1          (ctm_ctichinack_to_cti_etr[3:0]), // Templated
                 .ctmchoutack2          (cxctm0_ctmchoutack2[3:0]), // Templated
                 .ctmchoutack3          (cxctm0_ctmchoutack3[3:0]), // Templated
                 .ctmchoutack0          (ctm_ctichinack_to_cti_etf[3:0])); // Templated


/* ip_common_reg auto_template (
        .pclk        (dbg_clk),
        .presetn     (dbg_rstn),

        .\(p.*\)     (apb1to2_\1m1[]),

    //interlever
   .debug_0_0                       (rf_debug_0[]),
   .debug_0_1                       (rf_debug_1[]),
   .debug_0_2                       (rf_debug_2[]),
   .debug_0_3                       (rf_debug_3[]),
   .debug_\(1[0-5]\|[1-9]\)_\(.*\)       (@"(if(equal vl-dir \\"output\\") (concat ) (concat \\"{\\"vl-width\\"{1'b0}}\\")  )"),
   .ddr_\(.*\)                      (rf_ddr_\1[]),
   .subbankid_sel_\(.*\)            (rf_subbankid_sel_\1[]),
   .setid_sel_\(.*\)                (rf_setid_sel_\1[]),
   .ddrch_damage_31_0               (rf_bank_ddr_damage[31:0]),
   .ddrch_damage_63_32              (rf_bank_ddr_damage[63:32]),
   .ddrch_damage_79_64              (rf_bank_ddr_damage[79:64]),
   .buffer_\(.*\)                   (rf_buffer_\1[]),
   .bank_damage_31_0                (rf_bank_damage[31:0]),
   .bank_damage_63_32               (rf_bank_damage[63:32]),
   .bank_damage_79_64               (rf_bank_damage[79:64]),
   .innolink_\(.*\)                 (rf_innolink_\1[]),

   //ar monitor
   .reg_gpu.*                       (),
   .reg_router_div2_.*              (),
   .reg_monitor_.*                  (@"(if(equal vl-dir \\"output\\") (concat ) (concat \\"{\\"vl-width\\"{1'b0}}\\")  )"),
   .reg_axi_.*                      (@"(if(equal vl-dir \\"output\\") (concat ) (concat \\"{\\"vl-width\\"{1'b0}}\\")  )"),
   .reg_2m4s_.*                     (@"(if(equal vl-dir \\"output\\") (concat ) (concat \\"{\\"vl-width\\"{1'b0}}\\")  )"),
   .raw_trigger_.*                  (@"(if(equal vl-dir \\"output\\") (concat ) (concat \\"{\\"vl-width\\"{1'b0}}\\")  )"),
   .in_expand_ports                 ('0),
   .adb_.*                          (@"(if(equal vl-dir \\"output\\") (concat ) (concat \\"{\\"vl-width\\"{1'b0}}\\")  )"),
   .out_expand_ports                (),
   .atomic_pcie_reg                 (),

   );
*/
ip_common_reg ip_common_reg_u0(/*autoinst*/
                               // Outputs
                               .prdata          (apb1to2_prdatam1[31:0]), // Templated
                               .pready          (apb1to2_preadym1), // Templated
                               .pslverr         (apb1to2_pslverrm1), // Templated
                               .reg_axi_monitor_id_ar_0(),       // Templated
                               .reg_axi_monitor_id_aw_0(),       // Templated
                               .reg_axi_monitor_num_index_0(),   // Templated
                               .reg_axi_monitor_auto_id_en_0(),  // Templated
                               .reg_axi_lat_calc_en_0(),         // Templated
                               .reg_axi_lat_calc_clr_0(),        // Templated
                               .reg_axi_cnt_en_0(),              // Templated
                               .reg_axi_cnt_clr_0(),             // Templated
                               .reg_axi_monitor_id_ar_1(),       // Templated
                               .reg_axi_monitor_id_aw_1(),       // Templated
                               .reg_axi_monitor_num_index_1(),   // Templated
                               .reg_axi_monitor_auto_id_en_1(),  // Templated
                               .reg_axi_lat_calc_en_1(),         // Templated
                               .reg_axi_lat_calc_clr_1(),        // Templated
                               .reg_axi_cnt_en_1(),              // Templated
                               .reg_axi_cnt_clr_1(),             // Templated
                               .reg_axi_monitor_id_ar_2(),       // Templated
                               .reg_axi_monitor_id_aw_2(),       // Templated
                               .reg_axi_monitor_num_index_2(),   // Templated
                               .reg_axi_monitor_auto_id_en_2(),  // Templated
                               .reg_axi_lat_calc_en_2(),         // Templated
                               .reg_axi_lat_calc_clr_2(),        // Templated
                               .reg_axi_cnt_en_2(),              // Templated
                               .reg_axi_cnt_clr_2(),             // Templated
                               .reg_axi_monitor_id_ar_3(),       // Templated
                               .reg_axi_monitor_id_aw_3(),       // Templated
                               .reg_axi_monitor_num_index_3(),   // Templated
                               .reg_axi_monitor_auto_id_en_3(),  // Templated
                               .reg_axi_lat_calc_en_3(),         // Templated
                               .reg_axi_lat_calc_clr_3(),        // Templated
                               .reg_axi_cnt_en_3(),              // Templated
                               .reg_axi_cnt_clr_3(),             // Templated
                               .reg_axi_monitor_id_ar_4(),       // Templated
                               .reg_axi_monitor_id_aw_4(),       // Templated
                               .reg_axi_monitor_num_index_4(),   // Templated
                               .reg_axi_monitor_auto_id_en_4(),  // Templated
                               .reg_axi_lat_calc_en_4(),         // Templated
                               .reg_axi_lat_calc_clr_4(),        // Templated
                               .reg_axi_cnt_en_4(),              // Templated
                               .reg_axi_cnt_clr_4(),             // Templated
                               .reg_axi_monitor_id_ar_5(),       // Templated
                               .reg_axi_monitor_id_aw_5(),       // Templated
                               .reg_axi_monitor_num_index_5(),   // Templated
                               .reg_axi_monitor_auto_id_en_5(),  // Templated
                               .reg_axi_lat_calc_en_5(),         // Templated
                               .reg_axi_lat_calc_clr_5(),        // Templated
                               .reg_axi_cnt_en_5(),              // Templated
                               .reg_axi_cnt_clr_5(),             // Templated
                               .reg_axi_monitor_id_ar_6(),       // Templated
                               .reg_axi_monitor_id_aw_6(),       // Templated
                               .reg_axi_monitor_num_index_6(),   // Templated
                               .reg_axi_monitor_auto_id_en_6(),  // Templated
                               .reg_axi_lat_calc_en_6(),         // Templated
                               .reg_axi_lat_calc_clr_6(),        // Templated
                               .reg_axi_cnt_en_6(),              // Templated
                               .reg_axi_cnt_clr_6(),             // Templated
                               .reg_axi_monitor_id_ar_7(),       // Templated
                               .reg_axi_monitor_id_aw_7(),       // Templated
                               .reg_axi_monitor_num_index_7(),   // Templated
                               .reg_axi_monitor_auto_id_en_7(),  // Templated
                               .reg_axi_lat_calc_en_7(),         // Templated
                               .reg_axi_lat_calc_clr_7(),        // Templated
                               .reg_axi_cnt_en_7(),              // Templated
                               .reg_axi_cnt_clr_7(),             // Templated
                               .reg_axi_monitor_id_ar_8(),       // Templated
                               .reg_axi_monitor_id_aw_8(),       // Templated
                               .reg_axi_monitor_num_index_8(),   // Templated
                               .reg_axi_monitor_auto_id_en_8(),  // Templated
                               .reg_axi_lat_calc_en_8(),         // Templated
                               .reg_axi_lat_calc_clr_8(),        // Templated
                               .reg_axi_cnt_en_8(),              // Templated
                               .reg_axi_cnt_clr_8(),             // Templated
                               .reg_axi_monitor_id_ar_9(),       // Templated
                               .reg_axi_monitor_id_aw_9(),       // Templated
                               .reg_axi_monitor_num_index_9(),   // Templated
                               .reg_axi_monitor_auto_id_en_9(),  // Templated
                               .reg_axi_lat_calc_en_9(),         // Templated
                               .reg_axi_lat_calc_clr_9(),        // Templated
                               .reg_axi_cnt_en_9(),              // Templated
                               .reg_axi_cnt_clr_9(),             // Templated
                               .reg_axi_monitor_id_ar_10(),      // Templated
                               .reg_axi_monitor_id_aw_10(),      // Templated
                               .reg_axi_monitor_num_index_10(),  // Templated
                               .reg_axi_monitor_auto_id_en_10(), // Templated
                               .reg_axi_lat_calc_en_10(),        // Templated
                               .reg_axi_lat_calc_clr_10(),       // Templated
                               .reg_axi_cnt_en_10(),             // Templated
                               .reg_axi_cnt_clr_10(),            // Templated
                               .reg_axi_monitor_id_ar_11(),      // Templated
                               .reg_axi_monitor_id_aw_11(),      // Templated
                               .reg_axi_monitor_num_index_11(),  // Templated
                               .reg_axi_monitor_auto_id_en_11(), // Templated
                               .reg_axi_lat_calc_en_11(),        // Templated
                               .reg_axi_lat_calc_clr_11(),       // Templated
                               .reg_axi_cnt_en_11(),             // Templated
                               .reg_axi_cnt_clr_11(),            // Templated
                               .reg_axi_monitor_id_ar_12(),      // Templated
                               .reg_axi_monitor_id_aw_12(),      // Templated
                               .reg_axi_monitor_num_index_12(),  // Templated
                               .reg_axi_monitor_auto_id_en_12(), // Templated
                               .reg_axi_lat_calc_en_12(),        // Templated
                               .reg_axi_lat_calc_clr_12(),       // Templated
                               .reg_axi_cnt_en_12(),             // Templated
                               .reg_axi_cnt_clr_12(),            // Templated
                               .reg_axi_monitor_id_ar_13(),      // Templated
                               .reg_axi_monitor_id_aw_13(),      // Templated
                               .reg_axi_monitor_num_index_13(),  // Templated
                               .reg_axi_monitor_auto_id_en_13(), // Templated
                               .reg_axi_lat_calc_en_13(),        // Templated
                               .reg_axi_lat_calc_clr_13(),       // Templated
                               .reg_axi_cnt_en_13(),             // Templated
                               .reg_axi_cnt_clr_13(),            // Templated
                               .reg_axi_monitor_id_ar_14(),      // Templated
                               .reg_axi_monitor_id_aw_14(),      // Templated
                               .reg_axi_monitor_num_index_14(),  // Templated
                               .reg_axi_monitor_auto_id_en_14(), // Templated
                               .reg_axi_lat_calc_en_14(),        // Templated
                               .reg_axi_lat_calc_clr_14(),       // Templated
                               .reg_axi_cnt_en_14(),             // Templated
                               .reg_axi_cnt_clr_14(),            // Templated
                               .reg_axi_monitor_id_ar_15(),      // Templated
                               .reg_axi_monitor_id_aw_15(),      // Templated
                               .reg_axi_monitor_num_index_15(),  // Templated
                               .reg_axi_monitor_auto_id_en_15(), // Templated
                               .reg_axi_lat_calc_en_15(),        // Templated
                               .reg_axi_lat_calc_clr_15(),       // Templated
                               .reg_axi_cnt_en_15(),             // Templated
                               .reg_axi_cnt_clr_15(),            // Templated
                               .bankid_sel_0_7  (bankid_sel_0_7[3:0]),
                               .bankid_sel_0_6  (bankid_sel_0_6[3:0]),
                               .bankid_sel_0_5  (bankid_sel_0_5[3:0]),
                               .bankid_sel_0_4  (bankid_sel_0_4[3:0]),
                               .bankid_sel_0_3  (bankid_sel_0_3[3:0]),
                               .bankid_sel_0_2  (bankid_sel_0_2[3:0]),
                               .bankid_sel_0_1  (bankid_sel_0_1[3:0]),
                               .bankid_sel_0_0  (bankid_sel_0_0[3:0]),
                               .bankid_sel_1_7  (bankid_sel_1_7[3:0]),
                               .bankid_sel_1_6  (bankid_sel_1_6[3:0]),
                               .bankid_sel_1_5  (bankid_sel_1_5[3:0]),
                               .bankid_sel_1_4  (bankid_sel_1_4[3:0]),
                               .bankid_sel_1_3  (bankid_sel_1_3[3:0]),
                               .bankid_sel_1_2  (bankid_sel_1_2[3:0]),
                               .bankid_sel_1_1  (bankid_sel_1_1[3:0]),
                               .bankid_sel_1_0  (bankid_sel_1_0[3:0]),
                               .bankid_sel_2_7  (bankid_sel_2_7[3:0]),
                               .bankid_sel_2_6  (bankid_sel_2_6[3:0]),
                               .bankid_sel_2_5  (bankid_sel_2_5[3:0]),
                               .bankid_sel_2_4  (bankid_sel_2_4[3:0]),
                               .bankid_sel_2_3  (bankid_sel_2_3[3:0]),
                               .bankid_sel_2_2  (bankid_sel_2_2[3:0]),
                               .bankid_sel_2_1  (bankid_sel_2_1[3:0]),
                               .bankid_sel_2_0  (bankid_sel_2_0[3:0]),
                               .bankid_sel_3_7  (bankid_sel_3_7[3:0]),
                               .bankid_sel_3_6  (bankid_sel_3_6[3:0]),
                               .bankid_sel_3_5  (bankid_sel_3_5[3:0]),
                               .bankid_sel_3_4  (bankid_sel_3_4[3:0]),
                               .bankid_sel_3_3  (bankid_sel_3_3[3:0]),
                               .bankid_sel_3_2  (bankid_sel_3_2[3:0]),
                               .bankid_sel_3_1  (bankid_sel_3_1[3:0]),
                               .bankid_sel_3_0  (bankid_sel_3_0[3:0]),
                               .bankid_sel_4_7  (bankid_sel_4_7[3:0]),
                               .bankid_sel_4_6  (bankid_sel_4_6[3:0]),
                               .bankid_sel_4_5  (bankid_sel_4_5[3:0]),
                               .bankid_sel_4_4  (bankid_sel_4_4[3:0]),
                               .bankid_sel_4_3  (bankid_sel_4_3[3:0]),
                               .bankid_sel_4_2  (bankid_sel_4_2[3:0]),
                               .bankid_sel_4_1  (bankid_sel_4_1[3:0]),
                               .bankid_sel_4_0  (bankid_sel_4_0[3:0]),
                               .bankid_sel_5_7  (bankid_sel_5_7[3:0]),
                               .bankid_sel_5_6  (bankid_sel_5_6[3:0]),
                               .bankid_sel_5_5  (bankid_sel_5_5[3:0]),
                               .bankid_sel_5_4  (bankid_sel_5_4[3:0]),
                               .bankid_sel_5_3  (bankid_sel_5_3[3:0]),
                               .bankid_sel_5_2  (bankid_sel_5_2[3:0]),
                               .bankid_sel_5_1  (bankid_sel_5_1[3:0]),
                               .bankid_sel_5_0  (bankid_sel_5_0[3:0]),
                               .bankid_sel_6_7  (bankid_sel_6_7[3:0]),
                               .bankid_sel_6_6  (bankid_sel_6_6[3:0]),
                               .bankid_sel_6_5  (bankid_sel_6_5[3:0]),
                               .bankid_sel_6_4  (bankid_sel_6_4[3:0]),
                               .bankid_sel_6_3  (bankid_sel_6_3[3:0]),
                               .bankid_sel_6_2  (bankid_sel_6_2[3:0]),
                               .bankid_sel_6_1  (bankid_sel_6_1[3:0]),
                               .bankid_sel_6_0  (bankid_sel_6_0[3:0]),
                               .setid_sel_0_7   (rf_setid_sel_0_7[3:0]), // Templated
                               .setid_sel_0_6   (rf_setid_sel_0_6[3:0]), // Templated
                               .setid_sel_0_5   (rf_setid_sel_0_5[3:0]), // Templated
                               .setid_sel_0_4   (rf_setid_sel_0_4[3:0]), // Templated
                               .setid_sel_0_3   (rf_setid_sel_0_3[3:0]), // Templated
                               .setid_sel_0_2   (rf_setid_sel_0_2[3:0]), // Templated
                               .setid_sel_0_1   (rf_setid_sel_0_1[3:0]), // Templated
                               .setid_sel_0_0   (rf_setid_sel_0_0[3:0]), // Templated
                               .setid_sel_1_7   (rf_setid_sel_1_7[3:0]), // Templated
                               .setid_sel_1_6   (rf_setid_sel_1_6[3:0]), // Templated
                               .setid_sel_1_5   (rf_setid_sel_1_5[3:0]), // Templated
                               .setid_sel_1_4   (rf_setid_sel_1_4[3:0]), // Templated
                               .setid_sel_1_3   (rf_setid_sel_1_3[3:0]), // Templated
                               .setid_sel_1_2   (rf_setid_sel_1_2[3:0]), // Templated
                               .setid_sel_1_1   (rf_setid_sel_1_1[3:0]), // Templated
                               .setid_sel_1_0   (rf_setid_sel_1_0[3:0]), // Templated
                               .setid_sel_2_7   (rf_setid_sel_2_7[3:0]), // Templated
                               .setid_sel_2_6   (rf_setid_sel_2_6[3:0]), // Templated
                               .setid_sel_2_5   (rf_setid_sel_2_5[3:0]), // Templated
                               .setid_sel_2_4   (rf_setid_sel_2_4[3:0]), // Templated
                               .setid_sel_2_3   (rf_setid_sel_2_3[3:0]), // Templated
                               .setid_sel_2_2   (rf_setid_sel_2_2[3:0]), // Templated
                               .setid_sel_2_1   (rf_setid_sel_2_1[3:0]), // Templated
                               .setid_sel_2_0   (rf_setid_sel_2_0[3:0]), // Templated
                               .setid_sel_3_7   (rf_setid_sel_3_7[3:0]), // Templated
                               .setid_sel_3_6   (rf_setid_sel_3_6[3:0]), // Templated
                               .setid_sel_3_5   (rf_setid_sel_3_5[3:0]), // Templated
                               .setid_sel_3_4   (rf_setid_sel_3_4[3:0]), // Templated
                               .setid_sel_3_3   (rf_setid_sel_3_3[3:0]), // Templated
                               .setid_sel_3_2   (rf_setid_sel_3_2[3:0]), // Templated
                               .setid_sel_3_1   (rf_setid_sel_3_1[3:0]), // Templated
                               .setid_sel_3_0   (rf_setid_sel_3_0[3:0]), // Templated
                               .setid_sel_4_7   (rf_setid_sel_4_7[3:0]), // Templated
                               .setid_sel_4_6   (rf_setid_sel_4_6[3:0]), // Templated
                               .setid_sel_4_5   (rf_setid_sel_4_5[3:0]), // Templated
                               .setid_sel_4_4   (rf_setid_sel_4_4[3:0]), // Templated
                               .setid_sel_4_3   (rf_setid_sel_4_3[3:0]), // Templated
                               .setid_sel_4_2   (rf_setid_sel_4_2[3:0]), // Templated
                               .setid_sel_4_1   (rf_setid_sel_4_1[3:0]), // Templated
                               .setid_sel_4_0   (rf_setid_sel_4_0[3:0]), // Templated
                               .setid_sel_5_7   (rf_setid_sel_5_7[3:0]), // Templated
                               .setid_sel_5_6   (rf_setid_sel_5_6[3:0]), // Templated
                               .setid_sel_5_5   (rf_setid_sel_5_5[3:0]), // Templated
                               .setid_sel_5_4   (rf_setid_sel_5_4[3:0]), // Templated
                               .setid_sel_5_3   (rf_setid_sel_5_3[3:0]), // Templated
                               .setid_sel_5_2   (rf_setid_sel_5_2[3:0]), // Templated
                               .setid_sel_5_1   (rf_setid_sel_5_1[3:0]), // Templated
                               .setid_sel_5_0   (rf_setid_sel_5_0[3:0]), // Templated
                               .setid_sel_6_7   (rf_setid_sel_6_7[3:0]), // Templated
                               .setid_sel_6_6   (rf_setid_sel_6_6[3:0]), // Templated
                               .setid_sel_6_5   (rf_setid_sel_6_5[3:0]), // Templated
                               .setid_sel_6_4   (rf_setid_sel_6_4[3:0]), // Templated
                               .setid_sel_6_3   (rf_setid_sel_6_3[3:0]), // Templated
                               .setid_sel_6_2   (rf_setid_sel_6_2[3:0]), // Templated
                               .setid_sel_6_1   (rf_setid_sel_6_1[3:0]), // Templated
                               .setid_sel_6_0   (rf_setid_sel_6_0[3:0]), // Templated
                               .ecc_mode        (ecc_mode),
                               .ddr_intlv_mode  (rf_ddr_intlv_mode[1:0]), // Templated
                               .buffer_intlv_mode(rf_buffer_intlv_mode), // Templated
                               .buffer_mode     (rf_buffer_mode), // Templated
                               .ddr_channel_size(rf_ddr_channel_size[3:0]), // Templated
                               .ddrch_damage_31_0(rf_bank_ddr_damage[31:0]), // Templated
                               .ddrch_damage_63_32(rf_bank_ddr_damage[63:32]), // Templated
                               .ddrch_damage_79_64(rf_bank_ddr_damage[79:64]), // Templated
                               .bank_damage_31_0(rf_bank_damage[31:0]), // Templated
                               .bank_damage_63_32(rf_bank_damage[63:32]), // Templated
                               .bank_damage_79_64(rf_bank_damage[79:64]), // Templated
                               .ddr_intlv_bankid_3(rf_ddr_intlv_bankid_3[6:0]), // Templated
                               .ddr_intlv_bankid_2(rf_ddr_intlv_bankid_2[6:0]), // Templated
                               .ddr_intlv_bankid_1(rf_ddr_intlv_bankid_1[6:0]), // Templated
                               .ddr_intlv_bankid_0(rf_ddr_intlv_bankid_0[6:0]), // Templated
                               .ddr_intlv_bankid_7(rf_ddr_intlv_bankid_7[6:0]), // Templated
                               .ddr_intlv_bankid_6(rf_ddr_intlv_bankid_6[6:0]), // Templated
                               .ddr_intlv_bankid_5(rf_ddr_intlv_bankid_5[6:0]), // Templated
                               .ddr_intlv_bankid_4(rf_ddr_intlv_bankid_4[6:0]), // Templated
                               .ddr_intlv_bankid_11(rf_ddr_intlv_bankid_11[6:0]), // Templated
                               .ddr_intlv_bankid_10(rf_ddr_intlv_bankid_10[6:0]), // Templated
                               .ddr_intlv_bankid_9(rf_ddr_intlv_bankid_9[6:0]), // Templated
                               .ddr_intlv_bankid_8(rf_ddr_intlv_bankid_8[6:0]), // Templated
                               .ddr_intlv_bankid_15(rf_ddr_intlv_bankid_15[6:0]), // Templated
                               .ddr_intlv_bankid_14(rf_ddr_intlv_bankid_14[6:0]), // Templated
                               .ddr_intlv_bankid_13(rf_ddr_intlv_bankid_13[6:0]), // Templated
                               .ddr_intlv_bankid_12(rf_ddr_intlv_bankid_12[6:0]), // Templated
                               .ddr_intlv_bankid_19(rf_ddr_intlv_bankid_19[6:0]), // Templated
                               .ddr_intlv_bankid_18(rf_ddr_intlv_bankid_18[6:0]), // Templated
                               .ddr_intlv_bankid_17(rf_ddr_intlv_bankid_17[6:0]), // Templated
                               .ddr_intlv_bankid_16(rf_ddr_intlv_bankid_16[6:0]), // Templated
                               .ddr_intlv_bankid_23(rf_ddr_intlv_bankid_23[6:0]), // Templated
                               .ddr_intlv_bankid_22(rf_ddr_intlv_bankid_22[6:0]), // Templated
                               .ddr_intlv_bankid_21(rf_ddr_intlv_bankid_21[6:0]), // Templated
                               .ddr_intlv_bankid_20(rf_ddr_intlv_bankid_20[6:0]), // Templated
                               .ddr_intlv_bankid_27(rf_ddr_intlv_bankid_27[6:0]), // Templated
                               .ddr_intlv_bankid_26(rf_ddr_intlv_bankid_26[6:0]), // Templated
                               .ddr_intlv_bankid_25(rf_ddr_intlv_bankid_25[6:0]), // Templated
                               .ddr_intlv_bankid_24(rf_ddr_intlv_bankid_24[6:0]), // Templated
                               .ddr_intlv_bankid_31(rf_ddr_intlv_bankid_31[6:0]), // Templated
                               .ddr_intlv_bankid_30(rf_ddr_intlv_bankid_30[6:0]), // Templated
                               .ddr_intlv_bankid_29(rf_ddr_intlv_bankid_29[6:0]), // Templated
                               .ddr_intlv_bankid_28(rf_ddr_intlv_bankid_28[6:0]), // Templated
                               .ddr_intlv_bankid_35(rf_ddr_intlv_bankid_35[6:0]), // Templated
                               .ddr_intlv_bankid_34(rf_ddr_intlv_bankid_34[6:0]), // Templated
                               .ddr_intlv_bankid_33(rf_ddr_intlv_bankid_33[6:0]), // Templated
                               .ddr_intlv_bankid_32(rf_ddr_intlv_bankid_32[6:0]), // Templated
                               .ddr_intlv_bankid_39(rf_ddr_intlv_bankid_39[6:0]), // Templated
                               .ddr_intlv_bankid_38(rf_ddr_intlv_bankid_38[6:0]), // Templated
                               .ddr_intlv_bankid_37(rf_ddr_intlv_bankid_37[6:0]), // Templated
                               .ddr_intlv_bankid_36(rf_ddr_intlv_bankid_36[6:0]), // Templated
                               .ddr_intlv_bankid_43(rf_ddr_intlv_bankid_43[6:0]), // Templated
                               .ddr_intlv_bankid_42(rf_ddr_intlv_bankid_42[6:0]), // Templated
                               .ddr_intlv_bankid_41(rf_ddr_intlv_bankid_41[6:0]), // Templated
                               .ddr_intlv_bankid_40(rf_ddr_intlv_bankid_40[6:0]), // Templated
                               .ddr_intlv_bankid_47(rf_ddr_intlv_bankid_47[6:0]), // Templated
                               .ddr_intlv_bankid_46(rf_ddr_intlv_bankid_46[6:0]), // Templated
                               .ddr_intlv_bankid_45(rf_ddr_intlv_bankid_45[6:0]), // Templated
                               .ddr_intlv_bankid_44(rf_ddr_intlv_bankid_44[6:0]), // Templated
                               .ddr_intlv_bankid_51(rf_ddr_intlv_bankid_51[6:0]), // Templated
                               .ddr_intlv_bankid_50(rf_ddr_intlv_bankid_50[6:0]), // Templated
                               .ddr_intlv_bankid_49(rf_ddr_intlv_bankid_49[6:0]), // Templated
                               .ddr_intlv_bankid_48(rf_ddr_intlv_bankid_48[6:0]), // Templated
                               .ddr_intlv_bankid_55(rf_ddr_intlv_bankid_55[6:0]), // Templated
                               .ddr_intlv_bankid_54(rf_ddr_intlv_bankid_54[6:0]), // Templated
                               .ddr_intlv_bankid_53(rf_ddr_intlv_bankid_53[6:0]), // Templated
                               .ddr_intlv_bankid_52(rf_ddr_intlv_bankid_52[6:0]), // Templated
                               .ddr_intlv_bankid_59(rf_ddr_intlv_bankid_59[6:0]), // Templated
                               .ddr_intlv_bankid_58(rf_ddr_intlv_bankid_58[6:0]), // Templated
                               .ddr_intlv_bankid_57(rf_ddr_intlv_bankid_57[6:0]), // Templated
                               .ddr_intlv_bankid_56(rf_ddr_intlv_bankid_56[6:0]), // Templated
                               .ddr_intlv_bankid_63(rf_ddr_intlv_bankid_63[6:0]), // Templated
                               .ddr_intlv_bankid_62(rf_ddr_intlv_bankid_62[6:0]), // Templated
                               .ddr_intlv_bankid_61(rf_ddr_intlv_bankid_61[6:0]), // Templated
                               .ddr_intlv_bankid_60(rf_ddr_intlv_bankid_60[6:0]), // Templated
                               .ddr_intlv_bankid_67(rf_ddr_intlv_bankid_67[6:0]), // Templated
                               .ddr_intlv_bankid_66(rf_ddr_intlv_bankid_66[6:0]), // Templated
                               .ddr_intlv_bankid_65(rf_ddr_intlv_bankid_65[6:0]), // Templated
                               .ddr_intlv_bankid_64(rf_ddr_intlv_bankid_64[6:0]), // Templated
                               .ddr_intlv_bankid_71(rf_ddr_intlv_bankid_71[6:0]), // Templated
                               .ddr_intlv_bankid_70(rf_ddr_intlv_bankid_70[6:0]), // Templated
                               .ddr_intlv_bankid_69(rf_ddr_intlv_bankid_69[6:0]), // Templated
                               .ddr_intlv_bankid_68(rf_ddr_intlv_bankid_68[6:0]), // Templated
                               .ddr_intlv_bankid_75(rf_ddr_intlv_bankid_75[6:0]), // Templated
                               .ddr_intlv_bankid_74(rf_ddr_intlv_bankid_74[6:0]), // Templated
                               .ddr_intlv_bankid_73(rf_ddr_intlv_bankid_73[6:0]), // Templated
                               .ddr_intlv_bankid_72(rf_ddr_intlv_bankid_72[6:0]), // Templated
                               .ddr_intlv_bankid_79(rf_ddr_intlv_bankid_79[6:0]), // Templated
                               .ddr_intlv_bankid_78(rf_ddr_intlv_bankid_78[6:0]), // Templated
                               .ddr_intlv_bankid_77(rf_ddr_intlv_bankid_77[6:0]), // Templated
                               .ddr_intlv_bankid_76(rf_ddr_intlv_bankid_76[6:0]), // Templated
                               .buf_intlv_bankid_3(buf_intlv_bankid_3[6:0]),
                               .buf_intlv_bankid_2(buf_intlv_bankid_2[6:0]),
                               .buf_intlv_bankid_1(buf_intlv_bankid_1[6:0]),
                               .buf_intlv_bankid_0(buf_intlv_bankid_0[6:0]),
                               .buf_intlv_bankid_7(buf_intlv_bankid_7[6:0]),
                               .buf_intlv_bankid_6(buf_intlv_bankid_6[6:0]),
                               .buf_intlv_bankid_5(buf_intlv_bankid_5[6:0]),
                               .buf_intlv_bankid_4(buf_intlv_bankid_4[6:0]),
                               .buf_intlv_bankid_11(buf_intlv_bankid_11[6:0]),
                               .buf_intlv_bankid_10(buf_intlv_bankid_10[6:0]),
                               .buf_intlv_bankid_9(buf_intlv_bankid_9[6:0]),
                               .buf_intlv_bankid_8(buf_intlv_bankid_8[6:0]),
                               .buf_intlv_bankid_15(buf_intlv_bankid_15[6:0]),
                               .buf_intlv_bankid_14(buf_intlv_bankid_14[6:0]),
                               .buf_intlv_bankid_13(buf_intlv_bankid_13[6:0]),
                               .buf_intlv_bankid_12(buf_intlv_bankid_12[6:0]),
                               .buf_intlv_bankid_19(buf_intlv_bankid_19[6:0]),
                               .buf_intlv_bankid_18(buf_intlv_bankid_18[6:0]),
                               .buf_intlv_bankid_17(buf_intlv_bankid_17[6:0]),
                               .buf_intlv_bankid_16(buf_intlv_bankid_16[6:0]),
                               .buf_intlv_bankid_23(buf_intlv_bankid_23[6:0]),
                               .buf_intlv_bankid_22(buf_intlv_bankid_22[6:0]),
                               .buf_intlv_bankid_21(buf_intlv_bankid_21[6:0]),
                               .buf_intlv_bankid_20(buf_intlv_bankid_20[6:0]),
                               .buf_intlv_bankid_27(buf_intlv_bankid_27[6:0]),
                               .buf_intlv_bankid_26(buf_intlv_bankid_26[6:0]),
                               .buf_intlv_bankid_25(buf_intlv_bankid_25[6:0]),
                               .buf_intlv_bankid_24(buf_intlv_bankid_24[6:0]),
                               .buf_intlv_bankid_31(buf_intlv_bankid_31[6:0]),
                               .buf_intlv_bankid_30(buf_intlv_bankid_30[6:0]),
                               .buf_intlv_bankid_29(buf_intlv_bankid_29[6:0]),
                               .buf_intlv_bankid_28(buf_intlv_bankid_28[6:0]),
                               .buf_intlv_bankid_35(buf_intlv_bankid_35[6:0]),
                               .buf_intlv_bankid_34(buf_intlv_bankid_34[6:0]),
                               .buf_intlv_bankid_33(buf_intlv_bankid_33[6:0]),
                               .buf_intlv_bankid_32(buf_intlv_bankid_32[6:0]),
                               .buf_intlv_bankid_39(buf_intlv_bankid_39[6:0]),
                               .buf_intlv_bankid_38(buf_intlv_bankid_38[6:0]),
                               .buf_intlv_bankid_37(buf_intlv_bankid_37[6:0]),
                               .buf_intlv_bankid_36(buf_intlv_bankid_36[6:0]),
                               .buf_intlv_bankid_43(buf_intlv_bankid_43[6:0]),
                               .buf_intlv_bankid_42(buf_intlv_bankid_42[6:0]),
                               .buf_intlv_bankid_41(buf_intlv_bankid_41[6:0]),
                               .buf_intlv_bankid_40(buf_intlv_bankid_40[6:0]),
                               .buf_intlv_bankid_47(buf_intlv_bankid_47[6:0]),
                               .buf_intlv_bankid_46(buf_intlv_bankid_46[6:0]),
                               .buf_intlv_bankid_45(buf_intlv_bankid_45[6:0]),
                               .buf_intlv_bankid_44(buf_intlv_bankid_44[6:0]),
                               .buf_intlv_bankid_51(buf_intlv_bankid_51[6:0]),
                               .buf_intlv_bankid_50(buf_intlv_bankid_50[6:0]),
                               .buf_intlv_bankid_49(buf_intlv_bankid_49[6:0]),
                               .buf_intlv_bankid_48(buf_intlv_bankid_48[6:0]),
                               .buf_intlv_bankid_55(buf_intlv_bankid_55[6:0]),
                               .buf_intlv_bankid_54(buf_intlv_bankid_54[6:0]),
                               .buf_intlv_bankid_53(buf_intlv_bankid_53[6:0]),
                               .buf_intlv_bankid_52(buf_intlv_bankid_52[6:0]),
                               .buf_intlv_bankid_59(buf_intlv_bankid_59[6:0]),
                               .buf_intlv_bankid_58(buf_intlv_bankid_58[6:0]),
                               .buf_intlv_bankid_57(buf_intlv_bankid_57[6:0]),
                               .buf_intlv_bankid_56(buf_intlv_bankid_56[6:0]),
                               .buf_intlv_bankid_63(buf_intlv_bankid_63[6:0]),
                               .buf_intlv_bankid_62(buf_intlv_bankid_62[6:0]),
                               .buf_intlv_bankid_61(buf_intlv_bankid_61[6:0]),
                               .buf_intlv_bankid_60(buf_intlv_bankid_60[6:0]),
                               .buf_intlv_bankid_67(buf_intlv_bankid_67[6:0]),
                               .buf_intlv_bankid_66(buf_intlv_bankid_66[6:0]),
                               .buf_intlv_bankid_65(buf_intlv_bankid_65[6:0]),
                               .buf_intlv_bankid_64(buf_intlv_bankid_64[6:0]),
                               .buf_intlv_bankid_71(buf_intlv_bankid_71[6:0]),
                               .buf_intlv_bankid_70(buf_intlv_bankid_70[6:0]),
                               .buf_intlv_bankid_69(buf_intlv_bankid_69[6:0]),
                               .buf_intlv_bankid_68(buf_intlv_bankid_68[6:0]),
                               .buf_intlv_bankid_75(buf_intlv_bankid_75[6:0]),
                               .buf_intlv_bankid_74(buf_intlv_bankid_74[6:0]),
                               .buf_intlv_bankid_73(buf_intlv_bankid_73[6:0]),
                               .buf_intlv_bankid_72(buf_intlv_bankid_72[6:0]),
                               .buf_intlv_bankid_79(buf_intlv_bankid_79[6:0]),
                               .buf_intlv_bankid_78(buf_intlv_bankid_78[6:0]),
                               .buf_intlv_bankid_77(buf_intlv_bankid_77[6:0]),
                               .buf_intlv_bankid_76(buf_intlv_bankid_76[6:0]),
                               .out_expand_ports(),              // Templated
                               .atomic_pcie_reg (),              // Templated
                               .reg_2m4s_from_common_reg_0_0(),  // Templated
                               .reg_2m4s_from_common_reg_0_1(),  // Templated
                               .reg_2m4s_from_common_reg_1_0(),  // Templated
                               .reg_2m4s_from_common_reg_1_1(),  // Templated
                               .reg_2m4s_aw_trigger_raw_addr0(), // Templated
                               .reg_2m4s_aw_trigger_raw_addr1(), // Templated
                               .reg_2m4s_aw_trigger_raw_addr2(), // Templated
                               .reg_2m4s_aw_trigger_raw_addr3(), // Templated
                               .reg_2m4s_aw_trigger_raw_addr4(), // Templated
                               .reg_router_div2_common_reg(),    // Templated
                               .reg_router_div2_common_reg_size_0(), // Templated
                               .reg_router_div2_common_reg_size_1(), // Templated
                               .reg_gpu0_pcie0_bar0(),           // Templated
                               .reg_gpu1_pcie0_bar0(),           // Templated
                               .reg_gpu2_pcie0_bar0(),           // Templated
                               .reg_gpu3_pcie0_bar0(),           // Templated
                               .reg_gpu4_pcie0_bar0(),           // Templated
                               .reg_gpu5_pcie0_bar0(),           // Templated
                               .reg_gpu6_pcie0_bar0(),           // Templated
                               .reg_gpu7_pcie0_bar0(),           // Templated
                               .reg_gpu8_pcie0_bar0(),           // Templated
                               .reg_gpu9_pcie0_bar0(),           // Templated
                               .reg_gpu10_pcie0_bar0(),          // Templated
                               .reg_gpu11_pcie0_bar0(),          // Templated
                               .reg_gpu12_pcie0_bar0(),          // Templated
                               .reg_gpu13_pcie0_bar0(),          // Templated
                               .reg_gpu14_pcie0_bar0(),          // Templated
                               .reg_gpu15_pcie0_bar0(),          // Templated
                               .reg_gpu0_pcie0_bar2(),           // Templated
                               .reg_gpu1_pcie0_bar2(),           // Templated
                               .reg_gpu2_pcie0_bar2(),           // Templated
                               .reg_gpu3_pcie0_bar2(),           // Templated
                               .reg_gpu4_pcie0_bar2(),           // Templated
                               .reg_gpu5_pcie0_bar2(),           // Templated
                               .reg_gpu6_pcie0_bar2(),           // Templated
                               .reg_gpu7_pcie0_bar2(),           // Templated
                               .reg_gpu8_pcie0_bar2(),           // Templated
                               .reg_gpu9_pcie0_bar2(),           // Templated
                               .reg_gpu10_pcie0_bar2(),          // Templated
                               .reg_gpu11_pcie0_bar2(),          // Templated
                               .reg_gpu12_pcie0_bar2(),          // Templated
                               .reg_gpu13_pcie0_bar2(),          // Templated
                               .reg_gpu14_pcie0_bar2(),          // Templated
                               .reg_gpu15_pcie0_bar2(),          // Templated
                               .reg_gpu0_pcie1_bar0(),           // Templated
                               .reg_gpu1_pcie1_bar0(),           // Templated
                               .reg_gpu2_pcie1_bar0(),           // Templated
                               .reg_gpu3_pcie1_bar0(),           // Templated
                               .reg_gpu4_pcie1_bar0(),           // Templated
                               .reg_gpu5_pcie1_bar0(),           // Templated
                               .reg_gpu6_pcie1_bar0(),           // Templated
                               .reg_gpu7_pcie1_bar0(),           // Templated
                               .reg_gpu8_pcie1_bar0(),           // Templated
                               .reg_gpu9_pcie1_bar0(),           // Templated
                               .reg_gpu10_pcie1_bar0(),          // Templated
                               .reg_gpu11_pcie1_bar0(),          // Templated
                               .reg_gpu12_pcie1_bar0(),          // Templated
                               .reg_gpu13_pcie1_bar0(),          // Templated
                               .reg_gpu14_pcie1_bar0(),          // Templated
                               .reg_gpu15_pcie1_bar0(),          // Templated
                               // Inputs
                               .pclk            (dbg_clk),       // Templated
                               .presetn         (dbg_rstn),      // Templated
                               .paddr           (apb1to2_paddrm1[31:0]), // Templated
                               .psel            (apb1to2_pselm1), // Templated
                               .penable         (apb1to2_penablem1), // Templated
                               .pwrite          (apb1to2_pwritem1), // Templated
                               .pwdata          (apb1to2_pwdatam1[31:0]), // Templated
                               .reg_monitor_aw_axi_cnt_low_0({32{1'b0}}), // Templated
                               .reg_monitor_aw_axi_cnt_high_0({12{1'b0}}), // Templated
                               .reg_monitor_aw_axi_latency_0({32{1'b0}}), // Templated
                               .reg_monitor_aw_axi_latency_avg_0({32{1'b0}}), // Templated
                               .reg_monitor_aw_axi_latency_min_0({32{1'b0}}), // Templated
                               .reg_monitor_aw_axi_latency_max_0({32{1'b0}}), // Templated
                               .reg_monitor_ar_axi_cnt_low_0({32{1'b0}}), // Templated
                               .reg_monitor_ar_axi_cnt_high_0({12{1'b0}}), // Templated
                               .reg_monitor_ar_axi_latency_0({32{1'b0}}), // Templated
                               .reg_monitor_ar_axi_latency_avg_0({32{1'b0}}), // Templated
                               .reg_monitor_ar_axi_latency_min_0({32{1'b0}}), // Templated
                               .reg_monitor_ar_axi_latency_max_0({32{1'b0}}), // Templated
                               .reg_monitor_aw_axi_cnt_low_1({32{1'b0}}), // Templated
                               .reg_monitor_aw_axi_cnt_high_1({12{1'b0}}), // Templated
                               .reg_monitor_aw_axi_latency_1({32{1'b0}}), // Templated
                               .reg_monitor_aw_axi_latency_avg_1({32{1'b0}}), // Templated
                               .reg_monitor_aw_axi_latency_min_1({32{1'b0}}), // Templated
                               .reg_monitor_aw_axi_latency_max_1({32{1'b0}}), // Templated
                               .reg_monitor_ar_axi_cnt_low_1({32{1'b0}}), // Templated
                               .reg_monitor_ar_axi_cnt_high_1({12{1'b0}}), // Templated
                               .reg_monitor_ar_axi_latency_1({32{1'b0}}), // Templated
                               .reg_monitor_ar_axi_latency_avg_1({32{1'b0}}), // Templated
                               .reg_monitor_ar_axi_latency_min_1({32{1'b0}}), // Templated
                               .reg_monitor_ar_axi_latency_max_1({32{1'b0}}), // Templated
                               .reg_monitor_aw_axi_cnt_low_2({32{1'b0}}), // Templated
                               .reg_monitor_aw_axi_cnt_high_2({12{1'b0}}), // Templated
                               .reg_monitor_aw_axi_latency_2({32{1'b0}}), // Templated
                               .reg_monitor_aw_axi_latency_avg_2({32{1'b0}}), // Templated
                               .reg_monitor_aw_axi_latency_min_2({32{1'b0}}), // Templated
                               .reg_monitor_aw_axi_latency_max_2({32{1'b0}}), // Templated
                               .reg_monitor_ar_axi_cnt_low_2({32{1'b0}}), // Templated
                               .reg_monitor_ar_axi_cnt_high_2({12{1'b0}}), // Templated
                               .reg_monitor_ar_axi_latency_2({32{1'b0}}), // Templated
                               .reg_monitor_ar_axi_latency_avg_2({32{1'b0}}), // Templated
                               .reg_monitor_ar_axi_latency_min_2({32{1'b0}}), // Templated
                               .reg_monitor_ar_axi_latency_max_2({32{1'b0}}), // Templated
                               .reg_monitor_aw_axi_cnt_low_3({32{1'b0}}), // Templated
                               .reg_monitor_aw_axi_cnt_high_3({12{1'b0}}), // Templated
                               .reg_monitor_aw_axi_latency_3({32{1'b0}}), // Templated
                               .reg_monitor_aw_axi_latency_avg_3({32{1'b0}}), // Templated
                               .reg_monitor_aw_axi_latency_min_3({32{1'b0}}), // Templated
                               .reg_monitor_aw_axi_latency_max_3({32{1'b0}}), // Templated
                               .reg_monitor_ar_axi_cnt_low_3({32{1'b0}}), // Templated
                               .reg_monitor_ar_axi_cnt_high_3({12{1'b0}}), // Templated
                               .reg_monitor_ar_axi_latency_3({32{1'b0}}), // Templated
                               .reg_monitor_ar_axi_latency_avg_3({32{1'b0}}), // Templated
                               .reg_monitor_ar_axi_latency_min_3({32{1'b0}}), // Templated
                               .reg_monitor_ar_axi_latency_max_3({32{1'b0}}), // Templated
                               .reg_monitor_aw_axi_cnt_low_4({32{1'b0}}), // Templated
                               .reg_monitor_aw_axi_cnt_high_4({12{1'b0}}), // Templated
                               .reg_monitor_aw_axi_latency_4({32{1'b0}}), // Templated
                               .reg_monitor_aw_axi_latency_avg_4({32{1'b0}}), // Templated
                               .reg_monitor_aw_axi_latency_min_4({32{1'b0}}), // Templated
                               .reg_monitor_aw_axi_latency_max_4({32{1'b0}}), // Templated
                               .reg_monitor_ar_axi_cnt_low_4({32{1'b0}}), // Templated
                               .reg_monitor_ar_axi_cnt_high_4({12{1'b0}}), // Templated
                               .reg_monitor_ar_axi_latency_4({32{1'b0}}), // Templated
                               .reg_monitor_ar_axi_latency_avg_4({32{1'b0}}), // Templated
                               .reg_monitor_ar_axi_latency_min_4({32{1'b0}}), // Templated
                               .reg_monitor_ar_axi_latency_max_4({32{1'b0}}), // Templated
                               .reg_monitor_aw_axi_cnt_low_5({32{1'b0}}), // Templated
                               .reg_monitor_aw_axi_cnt_high_5({12{1'b0}}), // Templated
                               .reg_monitor_aw_axi_latency_5({32{1'b0}}), // Templated
                               .reg_monitor_aw_axi_latency_avg_5({32{1'b0}}), // Templated
                               .reg_monitor_aw_axi_latency_min_5({32{1'b0}}), // Templated
                               .reg_monitor_aw_axi_latency_max_5({32{1'b0}}), // Templated
                               .reg_monitor_ar_axi_cnt_low_5({32{1'b0}}), // Templated
                               .reg_monitor_ar_axi_cnt_high_5({12{1'b0}}), // Templated
                               .reg_monitor_ar_axi_latency_5({32{1'b0}}), // Templated
                               .reg_monitor_ar_axi_latency_avg_5({32{1'b0}}), // Templated
                               .reg_monitor_ar_axi_latency_min_5({32{1'b0}}), // Templated
                               .reg_monitor_ar_axi_latency_max_5({32{1'b0}}), // Templated
                               .reg_monitor_aw_axi_cnt_low_6({32{1'b0}}), // Templated
                               .reg_monitor_aw_axi_cnt_high_6({12{1'b0}}), // Templated
                               .reg_monitor_aw_axi_latency_6({32{1'b0}}), // Templated
                               .reg_monitor_aw_axi_latency_avg_6({32{1'b0}}), // Templated
                               .reg_monitor_aw_axi_latency_min_6({32{1'b0}}), // Templated
                               .reg_monitor_aw_axi_latency_max_6({32{1'b0}}), // Templated
                               .reg_monitor_ar_axi_cnt_low_6({32{1'b0}}), // Templated
                               .reg_monitor_ar_axi_cnt_high_6({12{1'b0}}), // Templated
                               .reg_monitor_ar_axi_latency_6({32{1'b0}}), // Templated
                               .reg_monitor_ar_axi_latency_avg_6({32{1'b0}}), // Templated
                               .reg_monitor_ar_axi_latency_min_6({32{1'b0}}), // Templated
                               .reg_monitor_ar_axi_latency_max_6({32{1'b0}}), // Templated
                               .reg_monitor_aw_axi_cnt_low_7({32{1'b0}}), // Templated
                               .reg_monitor_aw_axi_cnt_high_7({12{1'b0}}), // Templated
                               .reg_monitor_aw_axi_latency_7({32{1'b0}}), // Templated
                               .reg_monitor_aw_axi_latency_avg_7({32{1'b0}}), // Templated
                               .reg_monitor_aw_axi_latency_min_7({32{1'b0}}), // Templated
                               .reg_monitor_aw_axi_latency_max_7({32{1'b0}}), // Templated
                               .reg_monitor_ar_axi_cnt_low_7({32{1'b0}}), // Templated
                               .reg_monitor_ar_axi_cnt_high_7({12{1'b0}}), // Templated
                               .reg_monitor_ar_axi_latency_7({32{1'b0}}), // Templated
                               .reg_monitor_ar_axi_latency_avg_7({32{1'b0}}), // Templated
                               .reg_monitor_ar_axi_latency_min_7({32{1'b0}}), // Templated
                               .reg_monitor_ar_axi_latency_max_7({32{1'b0}}), // Templated
                               .reg_monitor_aw_axi_cnt_low_8({32{1'b0}}), // Templated
                               .reg_monitor_aw_axi_cnt_high_8({12{1'b0}}), // Templated
                               .reg_monitor_aw_axi_latency_8({32{1'b0}}), // Templated
                               .reg_monitor_aw_axi_latency_avg_8({32{1'b0}}), // Templated
                               .reg_monitor_aw_axi_latency_min_8({32{1'b0}}), // Templated
                               .reg_monitor_aw_axi_latency_max_8({32{1'b0}}), // Templated
                               .reg_monitor_ar_axi_cnt_low_8({32{1'b0}}), // Templated
                               .reg_monitor_ar_axi_cnt_high_8({12{1'b0}}), // Templated
                               .reg_monitor_ar_axi_latency_8({32{1'b0}}), // Templated
                               .reg_monitor_ar_axi_latency_avg_8({32{1'b0}}), // Templated
                               .reg_monitor_ar_axi_latency_min_8({32{1'b0}}), // Templated
                               .reg_monitor_ar_axi_latency_max_8({32{1'b0}}), // Templated
                               .reg_monitor_aw_axi_cnt_low_9({32{1'b0}}), // Templated
                               .reg_monitor_aw_axi_cnt_high_9({12{1'b0}}), // Templated
                               .reg_monitor_aw_axi_latency_9({32{1'b0}}), // Templated
                               .reg_monitor_aw_axi_latency_avg_9({32{1'b0}}), // Templated
                               .reg_monitor_aw_axi_latency_min_9({32{1'b0}}), // Templated
                               .reg_monitor_aw_axi_latency_max_9({32{1'b0}}), // Templated
                               .reg_monitor_ar_axi_cnt_low_9({32{1'b0}}), // Templated
                               .reg_monitor_ar_axi_cnt_high_9({12{1'b0}}), // Templated
                               .reg_monitor_ar_axi_latency_9({32{1'b0}}), // Templated
                               .reg_monitor_ar_axi_latency_avg_9({32{1'b0}}), // Templated
                               .reg_monitor_ar_axi_latency_min_9({32{1'b0}}), // Templated
                               .reg_monitor_ar_axi_latency_max_9({32{1'b0}}), // Templated
                               .reg_monitor_aw_axi_cnt_low_10({32{1'b0}}), // Templated
                               .reg_monitor_aw_axi_cnt_high_10({12{1'b0}}), // Templated
                               .reg_monitor_aw_axi_latency_10({32{1'b0}}), // Templated
                               .reg_monitor_aw_axi_latency_avg_10({32{1'b0}}), // Templated
                               .reg_monitor_aw_axi_latency_min_10({32{1'b0}}), // Templated
                               .reg_monitor_aw_axi_latency_max_10({32{1'b0}}), // Templated
                               .reg_monitor_ar_axi_cnt_low_10({32{1'b0}}), // Templated
                               .reg_monitor_ar_axi_cnt_high_10({12{1'b0}}), // Templated
                               .reg_monitor_ar_axi_latency_10({32{1'b0}}), // Templated
                               .reg_monitor_ar_axi_latency_avg_10({32{1'b0}}), // Templated
                               .reg_monitor_ar_axi_latency_min_10({32{1'b0}}), // Templated
                               .reg_monitor_ar_axi_latency_max_10({32{1'b0}}), // Templated
                               .reg_monitor_aw_axi_cnt_low_11({32{1'b0}}), // Templated
                               .reg_monitor_aw_axi_cnt_high_11({12{1'b0}}), // Templated
                               .reg_monitor_aw_axi_latency_11({32{1'b0}}), // Templated
                               .reg_monitor_aw_axi_latency_avg_11({32{1'b0}}), // Templated
                               .reg_monitor_aw_axi_latency_min_11({32{1'b0}}), // Templated
                               .reg_monitor_aw_axi_latency_max_11({32{1'b0}}), // Templated
                               .reg_monitor_ar_axi_cnt_low_11({32{1'b0}}), // Templated
                               .reg_monitor_ar_axi_cnt_high_11({12{1'b0}}), // Templated
                               .reg_monitor_ar_axi_latency_11({32{1'b0}}), // Templated
                               .reg_monitor_ar_axi_latency_avg_11({32{1'b0}}), // Templated
                               .reg_monitor_ar_axi_latency_min_11({32{1'b0}}), // Templated
                               .reg_monitor_ar_axi_latency_max_11({32{1'b0}}), // Templated
                               .reg_monitor_aw_axi_cnt_low_12({32{1'b0}}), // Templated
                               .reg_monitor_aw_axi_cnt_high_12({12{1'b0}}), // Templated
                               .reg_monitor_aw_axi_latency_12({32{1'b0}}), // Templated
                               .reg_monitor_aw_axi_latency_avg_12({32{1'b0}}), // Templated
                               .reg_monitor_aw_axi_latency_min_12({32{1'b0}}), // Templated
                               .reg_monitor_aw_axi_latency_max_12({32{1'b0}}), // Templated
                               .reg_monitor_ar_axi_cnt_low_12({32{1'b0}}), // Templated
                               .reg_monitor_ar_axi_cnt_high_12({12{1'b0}}), // Templated
                               .reg_monitor_ar_axi_latency_12({32{1'b0}}), // Templated
                               .reg_monitor_ar_axi_latency_avg_12({32{1'b0}}), // Templated
                               .reg_monitor_ar_axi_latency_min_12({32{1'b0}}), // Templated
                               .reg_monitor_ar_axi_latency_max_12({32{1'b0}}), // Templated
                               .reg_monitor_aw_axi_cnt_low_13({32{1'b0}}), // Templated
                               .reg_monitor_aw_axi_cnt_high_13({12{1'b0}}), // Templated
                               .reg_monitor_aw_axi_latency_13({32{1'b0}}), // Templated
                               .reg_monitor_aw_axi_latency_avg_13({32{1'b0}}), // Templated
                               .reg_monitor_aw_axi_latency_min_13({32{1'b0}}), // Templated
                               .reg_monitor_aw_axi_latency_max_13({32{1'b0}}), // Templated
                               .reg_monitor_ar_axi_cnt_low_13({32{1'b0}}), // Templated
                               .reg_monitor_ar_axi_cnt_high_13({12{1'b0}}), // Templated
                               .reg_monitor_ar_axi_latency_13({32{1'b0}}), // Templated
                               .reg_monitor_ar_axi_latency_avg_13({32{1'b0}}), // Templated
                               .reg_monitor_ar_axi_latency_min_13({32{1'b0}}), // Templated
                               .reg_monitor_ar_axi_latency_max_13({32{1'b0}}), // Templated
                               .reg_monitor_aw_axi_cnt_low_14({32{1'b0}}), // Templated
                               .reg_monitor_aw_axi_cnt_high_14({12{1'b0}}), // Templated
                               .reg_monitor_aw_axi_latency_14({32{1'b0}}), // Templated
                               .reg_monitor_aw_axi_latency_avg_14({32{1'b0}}), // Templated
                               .reg_monitor_aw_axi_latency_min_14({32{1'b0}}), // Templated
                               .reg_monitor_aw_axi_latency_max_14({32{1'b0}}), // Templated
                               .reg_monitor_ar_axi_cnt_low_14({32{1'b0}}), // Templated
                               .reg_monitor_ar_axi_cnt_high_14({12{1'b0}}), // Templated
                               .reg_monitor_ar_axi_latency_14({32{1'b0}}), // Templated
                               .reg_monitor_ar_axi_latency_avg_14({32{1'b0}}), // Templated
                               .reg_monitor_ar_axi_latency_min_14({32{1'b0}}), // Templated
                               .reg_monitor_ar_axi_latency_max_14({32{1'b0}}), // Templated
                               .reg_monitor_aw_axi_cnt_low_15({32{1'b0}}), // Templated
                               .reg_monitor_aw_axi_cnt_high_15({12{1'b0}}), // Templated
                               .reg_monitor_aw_axi_latency_15({32{1'b0}}), // Templated
                               .reg_monitor_aw_axi_latency_avg_15({32{1'b0}}), // Templated
                               .reg_monitor_aw_axi_latency_min_15({32{1'b0}}), // Templated
                               .reg_monitor_aw_axi_latency_max_15({32{1'b0}}), // Templated
                               .reg_monitor_ar_axi_cnt_low_15({32{1'b0}}), // Templated
                               .reg_monitor_ar_axi_cnt_high_15({12{1'b0}}), // Templated
                               .reg_monitor_ar_axi_latency_15({32{1'b0}}), // Templated
                               .reg_monitor_ar_axi_latency_avg_15({32{1'b0}}), // Templated
                               .reg_monitor_ar_axi_latency_min_15({32{1'b0}}), // Templated
                               .reg_monitor_ar_axi_latency_max_15({32{1'b0}}), // Templated
                               .debug_0_0       (rf_debug_0[31:0]), // Templated
                               .debug_0_1       (rf_debug_1[31:0]), // Templated
                               .debug_0_2       (rf_debug_2[31:0]), // Templated
                               .debug_0_3       (rf_debug_3[31:0]), // Templated
                               .debug_1_0       ({32{1'b0}}),    // Templated
                               .debug_1_1       ({32{1'b0}}),    // Templated
                               .debug_1_2       ({32{1'b0}}),    // Templated
                               .debug_1_3       ({32{1'b0}}),    // Templated
                               .debug_2_0       ({32{1'b0}}),    // Templated
                               .debug_2_1       ({32{1'b0}}),    // Templated
                               .debug_2_2       ({32{1'b0}}),    // Templated
                               .debug_2_3       ({32{1'b0}}),    // Templated
                               .debug_3_0       ({32{1'b0}}),    // Templated
                               .debug_3_1       ({32{1'b0}}),    // Templated
                               .debug_3_2       ({32{1'b0}}),    // Templated
                               .debug_3_3       ({32{1'b0}}),    // Templated
                               .debug_4_0       ({32{1'b0}}),    // Templated
                               .debug_4_1       ({32{1'b0}}),    // Templated
                               .debug_4_2       ({32{1'b0}}),    // Templated
                               .debug_4_3       ({32{1'b0}}),    // Templated
                               .debug_5_0       ({32{1'b0}}),    // Templated
                               .debug_5_1       ({32{1'b0}}),    // Templated
                               .debug_5_2       ({32{1'b0}}),    // Templated
                               .debug_5_3       ({32{1'b0}}),    // Templated
                               .debug_6_0       ({32{1'b0}}),    // Templated
                               .debug_6_1       ({32{1'b0}}),    // Templated
                               .debug_6_2       ({32{1'b0}}),    // Templated
                               .debug_6_3       ({32{1'b0}}),    // Templated
                               .debug_7_0       ({32{1'b0}}),    // Templated
                               .debug_7_1       ({32{1'b0}}),    // Templated
                               .debug_7_2       ({32{1'b0}}),    // Templated
                               .debug_7_3       ({32{1'b0}}),    // Templated
                               .debug_8_0       ({32{1'b0}}),    // Templated
                               .debug_8_1       ({32{1'b0}}),    // Templated
                               .debug_8_2       ({32{1'b0}}),    // Templated
                               .debug_8_3       ({32{1'b0}}),    // Templated
                               .debug_9_0       ({32{1'b0}}),    // Templated
                               .debug_9_1       ({32{1'b0}}),    // Templated
                               .debug_9_2       ({32{1'b0}}),    // Templated
                               .debug_9_3       ({32{1'b0}}),    // Templated
                               .debug_10_0      ({32{1'b0}}),    // Templated
                               .debug_10_1      ({32{1'b0}}),    // Templated
                               .debug_10_2      ({32{1'b0}}),    // Templated
                               .debug_10_3      ({32{1'b0}}),    // Templated
                               .debug_11_0      ({32{1'b0}}),    // Templated
                               .debug_11_1      ({32{1'b0}}),    // Templated
                               .debug_11_2      ({32{1'b0}}),    // Templated
                               .debug_11_3      ({32{1'b0}}),    // Templated
                               .debug_12_0      ({32{1'b0}}),    // Templated
                               .debug_12_1      ({32{1'b0}}),    // Templated
                               .debug_12_2      ({32{1'b0}}),    // Templated
                               .debug_12_3      ({32{1'b0}}),    // Templated
                               .debug_13_0      ({32{1'b0}}),    // Templated
                               .debug_13_1      ({32{1'b0}}),    // Templated
                               .debug_13_2      ({32{1'b0}}),    // Templated
                               .debug_13_3      ({32{1'b0}}),    // Templated
                               .debug_14_0      ({32{1'b0}}),    // Templated
                               .debug_14_1      ({32{1'b0}}),    // Templated
                               .debug_14_2      ({32{1'b0}}),    // Templated
                               .debug_14_3      ({32{1'b0}}),    // Templated
                               .debug_15_0      ({32{1'b0}}),    // Templated
                               .debug_15_1      ({32{1'b0}}),    // Templated
                               .debug_15_2      ({32{1'b0}}),    // Templated
                               .debug_15_3      ({32{1'b0}}),    // Templated
                               .in_expand_ports ('0),            // Templated
                               .reg_2m4s_to_common_reg_0({32{1'b0}}), // Templated
                               .reg_2m4s_to_common_reg_1({32{1'b0}}), // Templated
                               .raw_trigger_cnt0({32{1'b0}}),    // Templated
                               .raw_trigger_cnt1({32{1'b0}}),    // Templated
                               .raw_trigger_cnt2({32{1'b0}}),    // Templated
                               .raw_trigger_cnt3({32{1'b0}}),    // Templated
                               .adb_debug_monitor_reg_0({32{1'b0}}), // Templated
                               .adb_debug_monitor_reg_1({32{1'b0}}), // Templated
                               .adb_debug_monitor_reg_2({32{1'b0}}), // Templated
                               .adb_debug_monitor_reg_3({32{1'b0}}), // Templated
                               .adb_debug_monitor_reg_4({32{1'b0}}), // Templated
                               .adb_debug_monitor_reg_5({32{1'b0}}), // Templated
                               .adb_debug_monitor_reg_6({32{1'b0}}), // Templated
                               .adb_debug_monitor_reg_7({32{1'b0}}), // Templated
                               .adb_debug_monitor_reg_8({32{1'b0}}), // Templated
                               .adb_debug_monitor_reg_9({32{1'b0}}), // Templated
                               .adb_debug_monitor_reg_10({32{1'b0}}), // Templated
                               .adb_debug_monitor_reg_11({32{1'b0}}), // Templated
                               .adb_debug_monitor_reg_12({32{1'b0}}), // Templated
                               .adb_debug_monitor_reg_13({32{1'b0}}), // Templated
                               .adb_debug_monitor_reg_14({32{1'b0}}), // Templated
                               .adb_debug_monitor_reg_15({32{1'b0}}), // Templated
                               .adb_debug_monitor_reg_16({32{1'b0}})); // Templated

/*intlv auto_template(
    
    .clk                        (trace_clk),
    .rstn                       (trace_rstn),

    .upstrm_awaddr              ({3'b0,etr_addr_h11_fr_reg[8:0], etr_axi_awaddr_t[39:0]}),
    .upstrm_awqos               (etr_awqos_fr_reg),
    .upstrm_awuser              (etr_awuser_fr_reg),
    .upstrm_araddr              ({3'b0,etr_addr_h11_fr_reg[8:0], etr_axi_araddr_t[39:0]}),
    .upstrm_arqos               (etr_arqos_fr_reg),
    .upstrm_aruser              (etr_aruser_fr_reg),
    .upstrm_awatop              (1'h0),
    .upstrm_awlock              (1'b0),
    .upstrm_arlock              (1'b0),
    .upstrm_\(.*\)              (etr_axi_\1_t[]),
    .downstrm_awatop            (),
    .downstrm_\(.*\)            (etr_axi_\1[]),
    .debug_0                    (rf_debug_0[]),
    .debug_1                    (rf_debug_1[]),
    .debug_2                    (rf_debug_2[]),
    .debug_3                    (rf_debug_3[]),
    .subbankid_sel_\(.*\)       (rf_subbankid_sel_\1[]),
    .setid_sel_\(.*\)           (rf_setid_sel_\1[]),
    .ddrch_damage               (rf_bank_ddr_damage[79:0]),
    .buffer_mode                (rf_buffer_mode),
    .buffer_intlv_mode          (rf_buffer_intlv_mode),
    .bank_damage                (rf_bank_damage[79:0]),
    .innolink_intlv_mode        (rf_innolink_intlv_mode),
    .innolink_damage            (rf_innolink_damage[15:0]),
    .innolink_linear_id         (rf_innolink_linear_id[5:0]),
    .ddr_\(.*\)                 (rf_ddr_\1[]),


 );
*/
intlv
    #(
      .IDW         (6  ),
      .ADDRW       (52 ),
      .LENW        (4  ),
      .USERW       (16 ),
      .ATOPW       (1  ),     
      .SLICE_0     ( 3 ),
      .SLICE_1     ( 3 ),
      .SLICE_2     ( 3 )
    )
intlv_main_u0 (/*autoinst*/
               // Outputs
               .upstrm_awready          (etr_axi_awready_t),     // Templated
               .upstrm_arready          (etr_axi_arready_t),     // Templated
               .downstrm_awvalid        (etr_axi_awvalid),       // Templated
               .downstrm_awid           (etr_axi_awid[5:0]),     // Templated
               .downstrm_awaddr         (etr_axi_awaddr[51:0]),  // Templated
               .downstrm_awlen          (etr_axi_awlen[3:0]),    // Templated
               .downstrm_awsize         (etr_axi_awsize[2:0]),   // Templated
               .downstrm_awburst        (etr_axi_awburst[1:0]),  // Templated
               .downstrm_awprot         (etr_axi_awprot[2:0]),   // Templated
               .downstrm_awcache        (etr_axi_awcache[3:0]),  // Templated
               .downstrm_awqos          (etr_axi_awqos[3:0]),    // Templated
               .downstrm_awuser         (etr_axi_awuser[15:0]),  // Templated
               .downstrm_awatop         (),                      // Templated
               .downstrm_awlock         (etr_axi_awlock),        // Templated
               .downstrm_arvalid        (etr_axi_arvalid),       // Templated
               .downstrm_arid           (etr_axi_arid[5:0]),     // Templated
               .downstrm_araddr         (etr_axi_araddr[51:0]),  // Templated
               .downstrm_arlen          (etr_axi_arlen[3:0]),    // Templated
               .downstrm_arsize         (etr_axi_arsize[2:0]),   // Templated
               .downstrm_arburst        (etr_axi_arburst[1:0]),  // Templated
               .downstrm_arprot         (etr_axi_arprot[2:0]),   // Templated
               .downstrm_arcache        (etr_axi_arcache[3:0]),  // Templated
               .downstrm_arqos          (etr_axi_arqos[3:0]),    // Templated
               .downstrm_aruser         (etr_axi_aruser[15:0]),  // Templated
               .downstrm_arlock         (etr_axi_arlock),        // Templated
               .debug_0                 (rf_debug_0[31:0]),      // Templated
               .debug_1                 (rf_debug_1[31:0]),      // Templated
               .debug_2                 (rf_debug_2[31:0]),      // Templated
               .debug_3                 (rf_debug_3[31:0]),      // Templated
               // Inputs
               .clk                     (trace_clk),             // Templated
               .rstn                    (trace_rstn),            // Templated
               .ddr_channel_size        (rf_ddr_channel_size[3:0]), // Templated
               .ddr_intlv_mode          (rf_ddr_intlv_mode[1:0]), // Templated
               .ecc_mode                (ecc_mode),
               .ddrch_damage            (rf_bank_ddr_damage[79:0]), // Templated
               .bank_damage             (rf_bank_damage[79:0]),  // Templated
               .bankid_sel_0_0          (bankid_sel_0_0[3:0]),
               .bankid_sel_0_1          (bankid_sel_0_1[3:0]),
               .bankid_sel_0_2          (bankid_sel_0_2[3:0]),
               .bankid_sel_0_3          (bankid_sel_0_3[3:0]),
               .bankid_sel_0_4          (bankid_sel_0_4[3:0]),
               .bankid_sel_0_5          (bankid_sel_0_5[3:0]),
               .bankid_sel_0_6          (bankid_sel_0_6[3:0]),
               .bankid_sel_0_7          (bankid_sel_0_7[3:0]),
               .bankid_sel_1_0          (bankid_sel_1_0[3:0]),
               .bankid_sel_1_1          (bankid_sel_1_1[3:0]),
               .bankid_sel_1_2          (bankid_sel_1_2[3:0]),
               .bankid_sel_1_3          (bankid_sel_1_3[3:0]),
               .bankid_sel_1_4          (bankid_sel_1_4[3:0]),
               .bankid_sel_1_5          (bankid_sel_1_5[3:0]),
               .bankid_sel_1_6          (bankid_sel_1_6[3:0]),
               .bankid_sel_1_7          (bankid_sel_1_7[3:0]),
               .bankid_sel_2_0          (bankid_sel_2_0[3:0]),
               .bankid_sel_2_1          (bankid_sel_2_1[3:0]),
               .bankid_sel_2_2          (bankid_sel_2_2[3:0]),
               .bankid_sel_2_3          (bankid_sel_2_3[3:0]),
               .bankid_sel_2_4          (bankid_sel_2_4[3:0]),
               .bankid_sel_2_5          (bankid_sel_2_5[3:0]),
               .bankid_sel_2_6          (bankid_sel_2_6[3:0]),
               .bankid_sel_2_7          (bankid_sel_2_7[3:0]),
               .bankid_sel_3_0          (bankid_sel_3_0[3:0]),
               .bankid_sel_3_1          (bankid_sel_3_1[3:0]),
               .bankid_sel_3_2          (bankid_sel_3_2[3:0]),
               .bankid_sel_3_3          (bankid_sel_3_3[3:0]),
               .bankid_sel_3_4          (bankid_sel_3_4[3:0]),
               .bankid_sel_3_5          (bankid_sel_3_5[3:0]),
               .bankid_sel_3_6          (bankid_sel_3_6[3:0]),
               .bankid_sel_3_7          (bankid_sel_3_7[3:0]),
               .bankid_sel_4_0          (bankid_sel_4_0[3:0]),
               .bankid_sel_4_1          (bankid_sel_4_1[3:0]),
               .bankid_sel_4_2          (bankid_sel_4_2[3:0]),
               .bankid_sel_4_3          (bankid_sel_4_3[3:0]),
               .bankid_sel_4_4          (bankid_sel_4_4[3:0]),
               .bankid_sel_4_5          (bankid_sel_4_5[3:0]),
               .bankid_sel_4_6          (bankid_sel_4_6[3:0]),
               .bankid_sel_4_7          (bankid_sel_4_7[3:0]),
               .bankid_sel_5_0          (bankid_sel_5_0[3:0]),
               .bankid_sel_5_1          (bankid_sel_5_1[3:0]),
               .bankid_sel_5_2          (bankid_sel_5_2[3:0]),
               .bankid_sel_5_3          (bankid_sel_5_3[3:0]),
               .bankid_sel_5_4          (bankid_sel_5_4[3:0]),
               .bankid_sel_5_5          (bankid_sel_5_5[3:0]),
               .bankid_sel_5_6          (bankid_sel_5_6[3:0]),
               .bankid_sel_5_7          (bankid_sel_5_7[3:0]),
               .bankid_sel_6_0          (bankid_sel_6_0[3:0]),
               .bankid_sel_6_1          (bankid_sel_6_1[3:0]),
               .bankid_sel_6_2          (bankid_sel_6_2[3:0]),
               .bankid_sel_6_3          (bankid_sel_6_3[3:0]),
               .bankid_sel_6_4          (bankid_sel_6_4[3:0]),
               .bankid_sel_6_5          (bankid_sel_6_5[3:0]),
               .bankid_sel_6_6          (bankid_sel_6_6[3:0]),
               .bankid_sel_6_7          (bankid_sel_6_7[3:0]),
               .setid_sel_0_0           (rf_setid_sel_0_0[3:0]), // Templated
               .setid_sel_0_1           (rf_setid_sel_0_1[3:0]), // Templated
               .setid_sel_0_2           (rf_setid_sel_0_2[3:0]), // Templated
               .setid_sel_0_3           (rf_setid_sel_0_3[3:0]), // Templated
               .setid_sel_0_4           (rf_setid_sel_0_4[3:0]), // Templated
               .setid_sel_0_5           (rf_setid_sel_0_5[3:0]), // Templated
               .setid_sel_0_6           (rf_setid_sel_0_6[3:0]), // Templated
               .setid_sel_0_7           (rf_setid_sel_0_7[3:0]), // Templated
               .setid_sel_1_0           (rf_setid_sel_1_0[3:0]), // Templated
               .setid_sel_1_1           (rf_setid_sel_1_1[3:0]), // Templated
               .setid_sel_1_2           (rf_setid_sel_1_2[3:0]), // Templated
               .setid_sel_1_3           (rf_setid_sel_1_3[3:0]), // Templated
               .setid_sel_1_4           (rf_setid_sel_1_4[3:0]), // Templated
               .setid_sel_1_5           (rf_setid_sel_1_5[3:0]), // Templated
               .setid_sel_1_6           (rf_setid_sel_1_6[3:0]), // Templated
               .setid_sel_1_7           (rf_setid_sel_1_7[3:0]), // Templated
               .setid_sel_2_0           (rf_setid_sel_2_0[3:0]), // Templated
               .setid_sel_2_1           (rf_setid_sel_2_1[3:0]), // Templated
               .setid_sel_2_2           (rf_setid_sel_2_2[3:0]), // Templated
               .setid_sel_2_3           (rf_setid_sel_2_3[3:0]), // Templated
               .setid_sel_2_4           (rf_setid_sel_2_4[3:0]), // Templated
               .setid_sel_2_5           (rf_setid_sel_2_5[3:0]), // Templated
               .setid_sel_2_6           (rf_setid_sel_2_6[3:0]), // Templated
               .setid_sel_2_7           (rf_setid_sel_2_7[3:0]), // Templated
               .setid_sel_3_0           (rf_setid_sel_3_0[3:0]), // Templated
               .setid_sel_3_1           (rf_setid_sel_3_1[3:0]), // Templated
               .setid_sel_3_2           (rf_setid_sel_3_2[3:0]), // Templated
               .setid_sel_3_3           (rf_setid_sel_3_3[3:0]), // Templated
               .setid_sel_3_4           (rf_setid_sel_3_4[3:0]), // Templated
               .setid_sel_3_5           (rf_setid_sel_3_5[3:0]), // Templated
               .setid_sel_3_6           (rf_setid_sel_3_6[3:0]), // Templated
               .setid_sel_3_7           (rf_setid_sel_3_7[3:0]), // Templated
               .setid_sel_4_0           (rf_setid_sel_4_0[3:0]), // Templated
               .setid_sel_4_1           (rf_setid_sel_4_1[3:0]), // Templated
               .setid_sel_4_2           (rf_setid_sel_4_2[3:0]), // Templated
               .setid_sel_4_3           (rf_setid_sel_4_3[3:0]), // Templated
               .setid_sel_4_4           (rf_setid_sel_4_4[3:0]), // Templated
               .setid_sel_4_5           (rf_setid_sel_4_5[3:0]), // Templated
               .setid_sel_4_6           (rf_setid_sel_4_6[3:0]), // Templated
               .setid_sel_4_7           (rf_setid_sel_4_7[3:0]), // Templated
               .setid_sel_5_0           (rf_setid_sel_5_0[3:0]), // Templated
               .setid_sel_5_1           (rf_setid_sel_5_1[3:0]), // Templated
               .setid_sel_5_2           (rf_setid_sel_5_2[3:0]), // Templated
               .setid_sel_5_3           (rf_setid_sel_5_3[3:0]), // Templated
               .setid_sel_5_4           (rf_setid_sel_5_4[3:0]), // Templated
               .setid_sel_5_5           (rf_setid_sel_5_5[3:0]), // Templated
               .setid_sel_5_6           (rf_setid_sel_5_6[3:0]), // Templated
               .setid_sel_5_7           (rf_setid_sel_5_7[3:0]), // Templated
               .setid_sel_6_0           (rf_setid_sel_6_0[3:0]), // Templated
               .setid_sel_6_1           (rf_setid_sel_6_1[3:0]), // Templated
               .setid_sel_6_2           (rf_setid_sel_6_2[3:0]), // Templated
               .setid_sel_6_3           (rf_setid_sel_6_3[3:0]), // Templated
               .setid_sel_6_4           (rf_setid_sel_6_4[3:0]), // Templated
               .setid_sel_6_5           (rf_setid_sel_6_5[3:0]), // Templated
               .setid_sel_6_6           (rf_setid_sel_6_6[3:0]), // Templated
               .setid_sel_6_7           (rf_setid_sel_6_7[3:0]), // Templated
               .buffer_mode             (rf_buffer_mode),        // Templated
               .buffer_intlv_mode       (rf_buffer_intlv_mode),  // Templated
               .ddr_intlv_bankid_0      (rf_ddr_intlv_bankid_0[6:0]), // Templated
               .ddr_intlv_bankid_1      (rf_ddr_intlv_bankid_1[6:0]), // Templated
               .ddr_intlv_bankid_2      (rf_ddr_intlv_bankid_2[6:0]), // Templated
               .ddr_intlv_bankid_3      (rf_ddr_intlv_bankid_3[6:0]), // Templated
               .ddr_intlv_bankid_4      (rf_ddr_intlv_bankid_4[6:0]), // Templated
               .ddr_intlv_bankid_5      (rf_ddr_intlv_bankid_5[6:0]), // Templated
               .ddr_intlv_bankid_6      (rf_ddr_intlv_bankid_6[6:0]), // Templated
               .ddr_intlv_bankid_7      (rf_ddr_intlv_bankid_7[6:0]), // Templated
               .ddr_intlv_bankid_8      (rf_ddr_intlv_bankid_8[6:0]), // Templated
               .ddr_intlv_bankid_9      (rf_ddr_intlv_bankid_9[6:0]), // Templated
               .ddr_intlv_bankid_10     (rf_ddr_intlv_bankid_10[6:0]), // Templated
               .ddr_intlv_bankid_11     (rf_ddr_intlv_bankid_11[6:0]), // Templated
               .ddr_intlv_bankid_12     (rf_ddr_intlv_bankid_12[6:0]), // Templated
               .ddr_intlv_bankid_13     (rf_ddr_intlv_bankid_13[6:0]), // Templated
               .ddr_intlv_bankid_14     (rf_ddr_intlv_bankid_14[6:0]), // Templated
               .ddr_intlv_bankid_15     (rf_ddr_intlv_bankid_15[6:0]), // Templated
               .ddr_intlv_bankid_16     (rf_ddr_intlv_bankid_16[6:0]), // Templated
               .ddr_intlv_bankid_17     (rf_ddr_intlv_bankid_17[6:0]), // Templated
               .ddr_intlv_bankid_18     (rf_ddr_intlv_bankid_18[6:0]), // Templated
               .ddr_intlv_bankid_19     (rf_ddr_intlv_bankid_19[6:0]), // Templated
               .ddr_intlv_bankid_20     (rf_ddr_intlv_bankid_20[6:0]), // Templated
               .ddr_intlv_bankid_21     (rf_ddr_intlv_bankid_21[6:0]), // Templated
               .ddr_intlv_bankid_22     (rf_ddr_intlv_bankid_22[6:0]), // Templated
               .ddr_intlv_bankid_23     (rf_ddr_intlv_bankid_23[6:0]), // Templated
               .ddr_intlv_bankid_24     (rf_ddr_intlv_bankid_24[6:0]), // Templated
               .ddr_intlv_bankid_25     (rf_ddr_intlv_bankid_25[6:0]), // Templated
               .ddr_intlv_bankid_26     (rf_ddr_intlv_bankid_26[6:0]), // Templated
               .ddr_intlv_bankid_27     (rf_ddr_intlv_bankid_27[6:0]), // Templated
               .ddr_intlv_bankid_28     (rf_ddr_intlv_bankid_28[6:0]), // Templated
               .ddr_intlv_bankid_29     (rf_ddr_intlv_bankid_29[6:0]), // Templated
               .ddr_intlv_bankid_30     (rf_ddr_intlv_bankid_30[6:0]), // Templated
               .ddr_intlv_bankid_31     (rf_ddr_intlv_bankid_31[6:0]), // Templated
               .ddr_intlv_bankid_32     (rf_ddr_intlv_bankid_32[6:0]), // Templated
               .ddr_intlv_bankid_33     (rf_ddr_intlv_bankid_33[6:0]), // Templated
               .ddr_intlv_bankid_34     (rf_ddr_intlv_bankid_34[6:0]), // Templated
               .ddr_intlv_bankid_35     (rf_ddr_intlv_bankid_35[6:0]), // Templated
               .ddr_intlv_bankid_36     (rf_ddr_intlv_bankid_36[6:0]), // Templated
               .ddr_intlv_bankid_37     (rf_ddr_intlv_bankid_37[6:0]), // Templated
               .ddr_intlv_bankid_38     (rf_ddr_intlv_bankid_38[6:0]), // Templated
               .ddr_intlv_bankid_39     (rf_ddr_intlv_bankid_39[6:0]), // Templated
               .ddr_intlv_bankid_40     (rf_ddr_intlv_bankid_40[6:0]), // Templated
               .ddr_intlv_bankid_41     (rf_ddr_intlv_bankid_41[6:0]), // Templated
               .ddr_intlv_bankid_42     (rf_ddr_intlv_bankid_42[6:0]), // Templated
               .ddr_intlv_bankid_43     (rf_ddr_intlv_bankid_43[6:0]), // Templated
               .ddr_intlv_bankid_44     (rf_ddr_intlv_bankid_44[6:0]), // Templated
               .ddr_intlv_bankid_45     (rf_ddr_intlv_bankid_45[6:0]), // Templated
               .ddr_intlv_bankid_46     (rf_ddr_intlv_bankid_46[6:0]), // Templated
               .ddr_intlv_bankid_47     (rf_ddr_intlv_bankid_47[6:0]), // Templated
               .ddr_intlv_bankid_48     (rf_ddr_intlv_bankid_48[6:0]), // Templated
               .ddr_intlv_bankid_49     (rf_ddr_intlv_bankid_49[6:0]), // Templated
               .ddr_intlv_bankid_50     (rf_ddr_intlv_bankid_50[6:0]), // Templated
               .ddr_intlv_bankid_51     (rf_ddr_intlv_bankid_51[6:0]), // Templated
               .ddr_intlv_bankid_52     (rf_ddr_intlv_bankid_52[6:0]), // Templated
               .ddr_intlv_bankid_53     (rf_ddr_intlv_bankid_53[6:0]), // Templated
               .ddr_intlv_bankid_54     (rf_ddr_intlv_bankid_54[6:0]), // Templated
               .ddr_intlv_bankid_55     (rf_ddr_intlv_bankid_55[6:0]), // Templated
               .ddr_intlv_bankid_56     (rf_ddr_intlv_bankid_56[6:0]), // Templated
               .ddr_intlv_bankid_57     (rf_ddr_intlv_bankid_57[6:0]), // Templated
               .ddr_intlv_bankid_58     (rf_ddr_intlv_bankid_58[6:0]), // Templated
               .ddr_intlv_bankid_59     (rf_ddr_intlv_bankid_59[6:0]), // Templated
               .ddr_intlv_bankid_60     (rf_ddr_intlv_bankid_60[6:0]), // Templated
               .ddr_intlv_bankid_61     (rf_ddr_intlv_bankid_61[6:0]), // Templated
               .ddr_intlv_bankid_62     (rf_ddr_intlv_bankid_62[6:0]), // Templated
               .ddr_intlv_bankid_63     (rf_ddr_intlv_bankid_63[6:0]), // Templated
               .ddr_intlv_bankid_64     (rf_ddr_intlv_bankid_64[6:0]), // Templated
               .ddr_intlv_bankid_65     (rf_ddr_intlv_bankid_65[6:0]), // Templated
               .ddr_intlv_bankid_66     (rf_ddr_intlv_bankid_66[6:0]), // Templated
               .ddr_intlv_bankid_67     (rf_ddr_intlv_bankid_67[6:0]), // Templated
               .ddr_intlv_bankid_68     (rf_ddr_intlv_bankid_68[6:0]), // Templated
               .ddr_intlv_bankid_69     (rf_ddr_intlv_bankid_69[6:0]), // Templated
               .ddr_intlv_bankid_70     (rf_ddr_intlv_bankid_70[6:0]), // Templated
               .ddr_intlv_bankid_71     (rf_ddr_intlv_bankid_71[6:0]), // Templated
               .ddr_intlv_bankid_72     (rf_ddr_intlv_bankid_72[6:0]), // Templated
               .ddr_intlv_bankid_73     (rf_ddr_intlv_bankid_73[6:0]), // Templated
               .ddr_intlv_bankid_74     (rf_ddr_intlv_bankid_74[6:0]), // Templated
               .ddr_intlv_bankid_75     (rf_ddr_intlv_bankid_75[6:0]), // Templated
               .ddr_intlv_bankid_76     (rf_ddr_intlv_bankid_76[6:0]), // Templated
               .ddr_intlv_bankid_77     (rf_ddr_intlv_bankid_77[6:0]), // Templated
               .ddr_intlv_bankid_78     (rf_ddr_intlv_bankid_78[6:0]), // Templated
               .ddr_intlv_bankid_79     (rf_ddr_intlv_bankid_79[6:0]), // Templated
               .buf_intlv_bankid_0      (buf_intlv_bankid_0[6:0]),
               .buf_intlv_bankid_1      (buf_intlv_bankid_1[6:0]),
               .buf_intlv_bankid_2      (buf_intlv_bankid_2[6:0]),
               .buf_intlv_bankid_3      (buf_intlv_bankid_3[6:0]),
               .buf_intlv_bankid_4      (buf_intlv_bankid_4[6:0]),
               .buf_intlv_bankid_5      (buf_intlv_bankid_5[6:0]),
               .buf_intlv_bankid_6      (buf_intlv_bankid_6[6:0]),
               .buf_intlv_bankid_7      (buf_intlv_bankid_7[6:0]),
               .buf_intlv_bankid_8      (buf_intlv_bankid_8[6:0]),
               .buf_intlv_bankid_9      (buf_intlv_bankid_9[6:0]),
               .buf_intlv_bankid_10     (buf_intlv_bankid_10[6:0]),
               .buf_intlv_bankid_11     (buf_intlv_bankid_11[6:0]),
               .buf_intlv_bankid_12     (buf_intlv_bankid_12[6:0]),
               .buf_intlv_bankid_13     (buf_intlv_bankid_13[6:0]),
               .buf_intlv_bankid_14     (buf_intlv_bankid_14[6:0]),
               .buf_intlv_bankid_15     (buf_intlv_bankid_15[6:0]),
               .buf_intlv_bankid_16     (buf_intlv_bankid_16[6:0]),
               .buf_intlv_bankid_17     (buf_intlv_bankid_17[6:0]),
               .buf_intlv_bankid_18     (buf_intlv_bankid_18[6:0]),
               .buf_intlv_bankid_19     (buf_intlv_bankid_19[6:0]),
               .buf_intlv_bankid_20     (buf_intlv_bankid_20[6:0]),
               .buf_intlv_bankid_21     (buf_intlv_bankid_21[6:0]),
               .buf_intlv_bankid_22     (buf_intlv_bankid_22[6:0]),
               .buf_intlv_bankid_23     (buf_intlv_bankid_23[6:0]),
               .buf_intlv_bankid_24     (buf_intlv_bankid_24[6:0]),
               .buf_intlv_bankid_25     (buf_intlv_bankid_25[6:0]),
               .buf_intlv_bankid_26     (buf_intlv_bankid_26[6:0]),
               .buf_intlv_bankid_27     (buf_intlv_bankid_27[6:0]),
               .buf_intlv_bankid_28     (buf_intlv_bankid_28[6:0]),
               .buf_intlv_bankid_29     (buf_intlv_bankid_29[6:0]),
               .buf_intlv_bankid_30     (buf_intlv_bankid_30[6:0]),
               .buf_intlv_bankid_31     (buf_intlv_bankid_31[6:0]),
               .buf_intlv_bankid_32     (buf_intlv_bankid_32[6:0]),
               .buf_intlv_bankid_33     (buf_intlv_bankid_33[6:0]),
               .buf_intlv_bankid_34     (buf_intlv_bankid_34[6:0]),
               .buf_intlv_bankid_35     (buf_intlv_bankid_35[6:0]),
               .buf_intlv_bankid_36     (buf_intlv_bankid_36[6:0]),
               .buf_intlv_bankid_37     (buf_intlv_bankid_37[6:0]),
               .buf_intlv_bankid_38     (buf_intlv_bankid_38[6:0]),
               .buf_intlv_bankid_39     (buf_intlv_bankid_39[6:0]),
               .buf_intlv_bankid_40     (buf_intlv_bankid_40[6:0]),
               .buf_intlv_bankid_41     (buf_intlv_bankid_41[6:0]),
               .buf_intlv_bankid_42     (buf_intlv_bankid_42[6:0]),
               .buf_intlv_bankid_43     (buf_intlv_bankid_43[6:0]),
               .buf_intlv_bankid_44     (buf_intlv_bankid_44[6:0]),
               .buf_intlv_bankid_45     (buf_intlv_bankid_45[6:0]),
               .buf_intlv_bankid_46     (buf_intlv_bankid_46[6:0]),
               .buf_intlv_bankid_47     (buf_intlv_bankid_47[6:0]),
               .buf_intlv_bankid_48     (buf_intlv_bankid_48[6:0]),
               .buf_intlv_bankid_49     (buf_intlv_bankid_49[6:0]),
               .buf_intlv_bankid_50     (buf_intlv_bankid_50[6:0]),
               .buf_intlv_bankid_51     (buf_intlv_bankid_51[6:0]),
               .buf_intlv_bankid_52     (buf_intlv_bankid_52[6:0]),
               .buf_intlv_bankid_53     (buf_intlv_bankid_53[6:0]),
               .buf_intlv_bankid_54     (buf_intlv_bankid_54[6:0]),
               .buf_intlv_bankid_55     (buf_intlv_bankid_55[6:0]),
               .buf_intlv_bankid_56     (buf_intlv_bankid_56[6:0]),
               .buf_intlv_bankid_57     (buf_intlv_bankid_57[6:0]),
               .buf_intlv_bankid_58     (buf_intlv_bankid_58[6:0]),
               .buf_intlv_bankid_59     (buf_intlv_bankid_59[6:0]),
               .buf_intlv_bankid_60     (buf_intlv_bankid_60[6:0]),
               .buf_intlv_bankid_61     (buf_intlv_bankid_61[6:0]),
               .buf_intlv_bankid_62     (buf_intlv_bankid_62[6:0]),
               .buf_intlv_bankid_63     (buf_intlv_bankid_63[6:0]),
               .buf_intlv_bankid_64     (buf_intlv_bankid_64[6:0]),
               .buf_intlv_bankid_65     (buf_intlv_bankid_65[6:0]),
               .buf_intlv_bankid_66     (buf_intlv_bankid_66[6:0]),
               .buf_intlv_bankid_67     (buf_intlv_bankid_67[6:0]),
               .buf_intlv_bankid_68     (buf_intlv_bankid_68[6:0]),
               .buf_intlv_bankid_69     (buf_intlv_bankid_69[6:0]),
               .buf_intlv_bankid_70     (buf_intlv_bankid_70[6:0]),
               .buf_intlv_bankid_71     (buf_intlv_bankid_71[6:0]),
               .buf_intlv_bankid_72     (buf_intlv_bankid_72[6:0]),
               .buf_intlv_bankid_73     (buf_intlv_bankid_73[6:0]),
               .buf_intlv_bankid_74     (buf_intlv_bankid_74[6:0]),
               .buf_intlv_bankid_75     (buf_intlv_bankid_75[6:0]),
               .buf_intlv_bankid_76     (buf_intlv_bankid_76[6:0]),
               .buf_intlv_bankid_77     (buf_intlv_bankid_77[6:0]),
               .buf_intlv_bankid_78     (buf_intlv_bankid_78[6:0]),
               .buf_intlv_bankid_79     (buf_intlv_bankid_79[6:0]),
               .upstrm_awvalid          (etr_axi_awvalid_t),     // Templated
               .upstrm_awid             (etr_axi_awid_t[5:0]),   // Templated
               .upstrm_awaddr           ({3'b0,etr_addr_h11_fr_reg[8:0], etr_axi_awaddr_t[39:0]}), // Templated
               .upstrm_awlen            (etr_axi_awlen_t[3:0]),  // Templated
               .upstrm_awsize           (etr_axi_awsize_t[2:0]), // Templated
               .upstrm_awburst          (etr_axi_awburst_t[1:0]), // Templated
               .upstrm_awprot           (etr_axi_awprot_t[2:0]), // Templated
               .upstrm_awcache          (etr_axi_awcache_t[3:0]), // Templated
               .upstrm_awqos            (etr_awqos_fr_reg),      // Templated
               .upstrm_awuser           (etr_awuser_fr_reg),     // Templated
               .upstrm_awatop           (1'h0),                  // Templated
               .upstrm_awlock           (1'b0),                  // Templated
               .upstrm_arvalid          (etr_axi_arvalid_t),     // Templated
               .upstrm_arid             (etr_axi_arid_t[5:0]),   // Templated
               .upstrm_araddr           ({3'b0,etr_addr_h11_fr_reg[8:0], etr_axi_araddr_t[39:0]}), // Templated
               .upstrm_arlen            (etr_axi_arlen_t[3:0]),  // Templated
               .upstrm_arsize           (etr_axi_arsize_t[2:0]), // Templated
               .upstrm_arburst          (etr_axi_arburst_t[1:0]), // Templated
               .upstrm_arprot           (etr_axi_arprot_t[2:0]), // Templated
               .upstrm_arcache          (etr_axi_arcache_t[3:0]), // Templated
               .upstrm_arqos            (etr_arqos_fr_reg),      // Templated
               .upstrm_aruser           (etr_aruser_fr_reg),     // Templated
               .upstrm_arlock           (1'b0),                  // Templated
               .downstrm_awready        (etr_axi_awready),       // Templated
               .downstrm_arready        (etr_axi_arready));      // Templated


// Local Variables:
// verilog-library-directories:("./" "../../../interleaver/rtl/" "../../../top/rtl/ip_common_reg/" "../coresight_component/debug_module/cxapbasyncbridge_1/verilog/" "../coresight_component/trace_module/cxatbasyncbridge_1/verilog/" "../coresight_component/trace_module/cxatbfunnel_7_pro/verilog/" "../coresight_component/trace_module/cxatbreplicator_1/" "../coresight_component/trace_module/cxetb_cxetf/" "../coresight_component/trace_module/cxtpiu/verilog/" "../coresight_component/trace_module/cxatbdownsizer_128_32/" "../coresight_component/trigger_module/cxcti/verilog/" "../coresight_component/trigger_module/cxctm/verilog/" "../../sim_model/memory/" "../../memory_wrapper/") 
// verilog-auto-inst-param-value:t
// verilog-auto-wire-type:"wire"
// verilog-auto-output-ignore-regexp:"\\(.*noused\\|.*unused.*\\)"
// verilog-case-fold:t
// End:

endmodule
