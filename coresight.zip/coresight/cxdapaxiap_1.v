
//--========================================================================
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2011-2015 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//  Version and Release Control Information:
//
//  File Name           : cxdapaxiap_xmlcfg.v.xsl
//
//  Checked In          : $Date: 2015-02-16 14:55:41 +0000 (Mon, 16 Feb 2015) $
//
//  File Revision       : $Revision: 41661 $
//
//  Release Information : CoreSight-SoC-TM100-r3p2-00rel0
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// Abstract : CoreSight AXIAP - Top Level Block
//-----------------------------------------------------------------------------
//
// cxdapaxiap - CoreSight AXIAP
// ----------------------------
//
// CoreSight AXIAP is a memory access port which complies with
// AXI4 protocol and performs read/write access through AXI Interconnect.
//-----------------------------------------------------------------------------

module cxdapaxiap_1 (

  // Clock and Reset
  input wire            clk,
  input wire            resetn,

  // DAP Interface
  input wire [7:2]      dapcaddr,
  input wire            dapsel,
  input wire            dapenable,
  input wire            dapwrite,
  input wire [31:0]     dapwdata,
  input wire            dapabort,
  output wire [31:0]    daprdata,
  output wire           dapready,
  output wire           dapslverr,

  // Authentication Interface
  input wire            dbgen,
  input wire            spiden,

  // AXI Master Interface

  // AW Channel
  output wire [63:0]    awaddr,
  output wire [7:0]     awlen,
  output wire [2:0]     awsize,
  output wire [1:0]     awburst,
  output wire           awlock,
  output wire [3:0]     awcache,
  output wire [2:0]     awprot,
  output wire           awvalid,
  input wire            awready,

  // W Channel
  output wire [31:0]    wdata,
  output wire [3:0]     wstrb,
  output wire           wlast,
  output wire           wvalid,
  input wire            wready,

  // w resp channel
  input wire [1:0]      bresp,
  input wire            bvalid,
  output wire           bready,

  // ar channel
  output wire [63:0]    araddr,
  output wire [7:0]     arlen,
  output wire [2:0]     arsize,
  output wire [1:0]     arburst,
  output wire           arlock,
  output wire [3:0]     arcache,
  output wire [2:0]     arprot,
  output wire           arvalid,
  input wire            arready,

  // r channel
  input wire [31:0]     rdata,
  input wire [1:0]      rresp,
  input wire            rlast,
  input wire            rvalid,
  output wire           rready,

  // ace - lite interface

  // w channel
  output wire [1:0]     awdomain,
  output wire [2:0]     awsnoop,
  output wire [1:0]     awbar,

  // r channel
  output wire [1:0]     ardomain,
  output wire [3:0]     arsnoop,
  output wire [1:0]     arbar,

  // tie-off

  input wire [31:0]     rombaseaddru,

  input wire [31:0]     rombaseaddrl

  );

//----------------------------------------------------------------------------
// Wires
//----------------------------------------------------------------------------
  wire          bnk_sel_0;
  wire          bnk_sel_1;
  wire          bnk_sel_2;
  wire          bnk_sel_15;
  wire [3:0]    reg_sel;
  wire          wr_en;
  wire [31:0]   reg_wdata;
  wire          rd_en;
  wire [31:0]   reg_rdata;
  wire          axi_ap_rdy;
  wire          abrt_req;
  wire          err_resp;

  wire [2:0]    fsm_state;
  wire [2:0]    fsm_state_next;
  wire          fsm_state_en;
  wire          bar_req;
  wire          drw_wr_req_fsm;
  wire          bd_wr_req_fsm;
  wire          drw_rd_req_fsm;
  wire          bd_rd_req_fsm;

  wire          drw_wr_req;
  wire          drw_rd_req;
  wire          bd0_req;
  wire          bd1_req;
  wire          bd2_req;
  wire          bd3_req;
  wire [31:0]   tar_l;

  wire [31:0]   tar_u;

  wire [1:0]    axi_size;
  wire [3:0]    cache_enc;
  wire [2:0]    prot_enc;
  wire          sprot;
  wire [1:0]    addr_inc;
  wire [1:0]    bar_enc;
  wire [1:0]    domain;
  wire          abort_req;
  wire [9:0]    inc_tar_l;
  wire          inc_tar;
  wire [31:0]   rdata_l;
  wire          rdata_vld;

  wire bar_resp;
  wire bar_awready;
  wire mst_wready;
  wire wr_resp;
  wire bar_arready;
  wire rd_resp;
  wire axi_err_resp;
  wire pck_tr_done;

  wire dbgen_rg;
  wire spiden_rg;

  wire drw_en;
  wire bd0_en;
  wire bd1_en;
  wire bd2_en;
  wire bd3_en;

//============================================================================
//
// Main body of code
//
//============================================================================

cxdapaxiapdapslvif_1
  u_dapslvif (

  // clock and reset
  .clk          (clk),
  .resetn       (resetn),

  // dap interface
  .dapcaddr      (dapcaddr[7:2]),
  .dapsel       (dapsel),
  .dapenable    (dapenable),
  .dapwrite     (dapwrite),
  .dapwdata     (dapwdata),
  .dapabort     (dapabort),
  .daprdata     (daprdata),
  .dapready     (dapready),
  .dapslverr    (dapslverr),

  // reg block interface
  .bnk_sel_0    (bnk_sel_0),
  .bnk_sel_1    (bnk_sel_1),
  .bnk_sel_2    (bnk_sel_2),
  .bnk_sel_15   (bnk_sel_15),
  .reg_sel      (reg_sel),
  .wr_en        (wr_en),
  .wdata        (reg_wdata),
  .rd_en        (rd_en),
  .rdata        (reg_rdata),
  .rdy          (axi_ap_rdy),
  .abrt_req     (abrt_req),
  .err_resp     (err_resp)

  );

cxdapaxiapregblk_1
  u_regblk(

  // clock and reset
  .clk            (clk),
  .resetn         (resetn),

  // dap slave interface
  .bnk_sel_0      (bnk_sel_0),
  .bnk_sel_1      (bnk_sel_1),
  .bnk_sel_2      (bnk_sel_2),
  .bnk_sel_15     (bnk_sel_15),
  .reg_sel        (reg_sel),
  .wr_en          (wr_en),

  .wdata          (reg_wdata),
  .rd_en          (rd_en),
  .abrt_req       (abrt_req),
  .rdata          (reg_rdata),
  .axi_ap_rdy     (axi_ap_rdy),
  .err_resp       (err_resp),

  // top level fsm interface
  .fsm_state      (fsm_state),
  .fsm_state_next (fsm_state_next),
  .fsm_state_en   (fsm_state_en),
  .bar_req        (bar_req),
  .drw_wr_req_fsm (drw_wr_req_fsm),
  .bd_wr_req_fsm  (bd_wr_req_fsm),
  .drw_rd_req_fsm (drw_rd_req_fsm),
  .bd_rd_req_fsm  (bd_rd_req_fsm),

  // axi master interface
  .drw_wr_req     (drw_wr_req),
  .drw_rd_req     (drw_rd_req),
  .bd0_req        (bd0_req),
  .bd1_req        (bd1_req),
  .bd2_req        (bd2_req),
  .bd3_req        (bd3_req),
  .drw_en         (drw_en),
  .bd0_en         (bd0_en),
  .bd1_en         (bd1_en),
  .bd2_en         (bd2_en),
  .bd3_en         (bd3_en),

  .tar_l          (tar_l),

  .tar_u          (tar_u),

  .axi_size       (axi_size),
  .cache_enc      (cache_enc),
  .prot_enc       (prot_enc),
  .sprot          (sprot),
  .addr_inc       (addr_inc),
  .bar_enc        (bar_enc),
  .domain         (domain),
  .abort_req      (abort_req),
  .inc_tar_l      (inc_tar_l),
  .inc_tar        (inc_tar),
  .rdata_l        (rdata_l),
  .rdata_vld      (rdata_vld),
  .axi_err_resp   (axi_err_resp),

  // tie-off
  .rombaseaddrl   (rombaseaddrl),

  .rombaseaddru   (rombaseaddru),


  // authentication interface
  .dbgen          (dbgen),
  .spiden         (spiden),

  .spiden_rg      (spiden_rg),
  .dbgen_rg       (dbgen_rg)

  );

cxdapaxiapfsm_1
  u_axiapfsm(

  // clock and reset
  .clk            (clk),
  .resetn         (resetn),

  // reg block interface
  .sprot          (sprot),
  .bar_req        (bar_req),
  .drw_wr_req     (drw_wr_req_fsm),
  .bd_wr_req      (bd_wr_req_fsm),
  .drw_rd_req     (drw_rd_req_fsm),
  .bd_rd_req      (bd_rd_req_fsm),

  // axi master interface
  .bar_resp       (bar_resp),
  .bar_awready    (bar_awready),
  .mst_wready     (mst_wready),
  .wr_resp        (wr_resp),
  .bar_arready    (bar_arready),
  .rd_resp        (rd_resp),
  .axi_err_resp   (axi_err_resp),
  .pck_tr_done    (pck_tr_done),

  // authentication interface
  .dbgen_rg       (dbgen_rg),
  .spiden_rg      (spiden_rg),

  // fsm state
  .fsm_state_next (fsm_state_next),
  .fsm_state_en   (fsm_state_en),
  .fsm_state      (fsm_state)

  );

cxdapaxiapmstif_1
  u_mstif(

  // clock and reset
  .clk          (clk),
  .resetn       (resetn),

  // aw channel
  .awaddr       (awaddr),
  .awlen        (awlen),
  .awsize       (awsize),
  .awburst      (awburst),
  .awlock       (awlock),
  .awcache      (awcache),
  .awprot       (awprot),
  .awvalid      (awvalid),
  .awready      (awready),

  // w channel
  .wdata        (wdata),
  .wstrb        (wstrb),
  .wlast        (wlast),
  .wvalid       (wvalid),
  .wready       (wready),

  // w resp channel
  .bresp        (bresp),
  .bvalid       (bvalid),
  .bready       (bready),

  // ar channel
  .araddr       (araddr),
  .arlen        (arlen),
  .arsize       (arsize),
  .arburst      (arburst),
  .arlock       (arlock),
  .arcache      (arcache),
  .arprot       (arprot),
  .arvalid      (arvalid),
  .arready      (arready),

  // r channel
  .rdata        (rdata),
  .rresp        (rresp),
  .rlast        (rlast),
  .rvalid       (rvalid),
  .rready       (rready),

  // ace - lite interface

  // w channel
  .awdomain     (awdomain),
  .awsnoop      (awsnoop),
  .awbar        (awbar),

  // r channel
  .ardomain     (ardomain),
  .arsnoop      (arsnoop),
  .arbar        (arbar),

  // register block interface
  .drw_wr_req   (drw_wr_req),
  .drw_rd_req   (drw_rd_req),
  .bd0_req      (bd0_req),
  .bd1_req      (bd1_req),
  .bd2_req      (bd2_req),
  .bd3_req      (bd3_req),
  .drw_en         (drw_en),
  .bd0_en         (bd0_en),
  .bd1_en         (bd1_en),
  .bd2_en         (bd2_en),
  .bd3_en         (bd3_en),
  .wr_en          (wr_en),

  .tar_l        (tar_l),

  .tar_u        (tar_u),

  .dap_wdata    (reg_wdata),
  .axi_size     (axi_size),
  .cache_enc    (cache_enc),
  .prot_enc     (prot_enc),
  .addr_inc     (addr_inc),
  .bar_enc      (bar_enc),
  .domain       (domain),
  .abort_req    (abort_req),
  .inc_tar_l    (inc_tar_l),
  .inc_tar      (inc_tar),
  .rdata_l      (rdata_l),
  .rdata_vld    (rdata_vld),


  // top level fsm interface
  .fsm_state    (fsm_state),
  .bar_resp     (bar_resp),
  .bar_awready  (bar_awready),
  .mst_wready   (mst_wready),
  .wr_resp      (wr_resp),
  .bar_arready  (bar_arready),
  .rd_resp      (rd_resp),
  .axi_err_resp (axi_err_resp),
  .pck_tr_done  (pck_tr_done),

  // authentication interface
  .spiden_rg    (spiden_rg)

  );

//----------------------------------------------------------------------------
// ASSERTIONS
//----------------------------------------------------------------------------

`ifdef ARM_ASSERT_ON

//-----------------------------------------------------------------------------
// Local constant definition
//-----------------------------------------------------------------------------
localparam AXI_ADDR_WIDTH = 64;
localparam AXI_DATA_WIDTH = 32;

//-----------------------------------------------------------------------------
// Check for legal values of AXI_ADDR_WIDTH parameter
// Valid values: 32,64
//-----------------------------------------------------------------------------
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxdapaxiap - Illegal value for parameter AXI_ADDR_WIDTH")
      uzovl_cxdapaxiap_addr_param_chk
        (
         .clk         (clk),
         .reset_n     (resetn),
         .test_expr   ((AXI_ADDR_WIDTH != 32) &&
                       (AXI_ADDR_WIDTH != 64))
        );

//-----------------------------------------------------------------------------
// Check for legal values of AXI_DATA_WIDTH parameter
// Valid values: 32,64
//-----------------------------------------------------------------------------
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxdapaxiap - Illegal value for parameter AXI_DATA_WIDTH")
      uzovl_cxdapaxiap_data_param_chk
        (
         .clk         (clk),
         .reset_n     (resetn),
         .test_expr   ((AXI_DATA_WIDTH != 32) &&
                       (AXI_DATA_WIDTH != 64))
        );
`endif // ARM_ASSERT_ON

endmodule
