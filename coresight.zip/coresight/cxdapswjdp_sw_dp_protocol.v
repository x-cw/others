// --------------------------------------------------------------------------
//  The confidential and proprietary information contained in this file may
//  only be used by a person authorised under and to the extent permitted
//  by a subsisting licensing agreement from ARM Limited.
//
//                (C) COPYRIGHT 2004-2015 ARM Limited.
//                    ALL RIGHTS RESERVED
//
//  This entire notice must be reproduced on all copies of this file
//  and copies of this file may only be made by a person if such person is
//  permitted to do so under the terms of a subsisting license agreement
//  from ARM Limited.
//
//    Checked In : $Date: 2014-08-14 16:01:35 +0100 (Thu, 14 Aug 2014) $
//    Revision   : $Revision: 39945 $
//    Release    : CoreSight-SoC-TM100-r3p2-00rel0
// ----------------------------------------------------------------------------
//  Purpose : SW-DP protocol Block.
// ----------------------------------------------------------------------------

module cxdapswjdp_sw_dp_protocol
  (
   //Inputs
   dbgresetn, dbgclk, swdsel, dbgdi, wireresetreq,
   busack, busrdata, buscmp, buserr, busendcnt,
   cdbgpwrupack, csyspwrupack, cdbgrstack, targetid, instanceid,
   //Outputs
   dbgdo, dbgdoen, busreq, buswrite, busabort, busaddr_31to24, busaddr_7to2,
   buswdata, busmode, busmask, bustrncnt,
   cdbgpwrupreq, csyspwrupreq, cdbgrstreq, wirereset
  );

`include "cxdapswjdp_dp_apb_constants.v"
`include "cxdapswjdp_sw_dp_constants.v"

// ---------------------------------------------------------------------------
// Overview
// ========
// Writes are managed as a two stage buffer -- shifter and write-buffer.
// Reads use the same interface to maintain DAP transaction order.
//
// A mechanism similar to jtag Capture-xR and Update-xR is used in SW-DP.
// Reads are skewed by one transaction for reasons of performance.
//
// The Bus Turn Around cycle before RDY/nCONT is used as a capture state.
// The cycle after the last data cycle, (the start for write, the second
// turn around for read) will be used as the update cycle.
// ---------------------------------------------------------------------------

// --------------------------------------------------------------------------
// Port Definitions
// --------------------------------------------------------------------------
  input          dbgresetn;     // Power-On Reset
  input          dbgclk;        // SW-DP Clock
  input          swdsel;        // SW-DP selected
  input          dbgdi;         // SW-DP Data In
  input          wireresetreq;  // Reset request
  input          busack;        // Bus Trasnaction Acknowledge
  input  [31:0]  busrdata;      // Bus read Data Port
  input          buscmp;        // Bus Pushed Verify/Find
  input          buserr;        // Bus Error
  input  [11:0]  busendcnt;     // Bus end count
  input          cdbgpwrupack;  // Debug Power Domain up acknowledge
  input          csyspwrupack;  // System Power Domain up acknowledge
  input          cdbgrstack;    // Debug reset acknowledge to reset controller
  input  [31:0]  targetid;      // Target ID for multidrop selection
  input  [3:0]   instanceid;    // Instance ID for multidrop selection
  output         dbgdo;         // SW-DP Data Out
  output         dbgdoen;       // SW-DP Data Out Enable
  output         busreq;        // Bus Transaction Request
  output         buswrite;      // Bus write
  output         busabort;      // Bus abort
  output [31:24] busaddr_31to24;// Bus Address Port - AP Sel
  output [7:2]   busaddr_7to2;  // Bus Address Port - Bank/Reg Sel
  output [31:0]  buswdata;      // Bus write Data Port
  output [1:0]   busmode;       // Bus Mode
  output [3:0]   busmask;       // Bus Compare Mask
  output [11:0]  bustrncnt;     // Bus Transfer Cnt
  output         cdbgpwrupreq;  // Debug Power Domain up request
  output         csyspwrupreq;  // System Power Domain up request
  output         cdbgrstreq;    // Debug reset request to reset controller
  output         wirereset;     // SW-DP is in it's standby state.

// ----------------------------------------------------------------------------
// Signal declarations
// ----------------------------------------------------------------------------

  // I/O pins
  wire          dbgresetn;          // Power-On Reset
  wire          dbgclk;             // SW-DP Clock
  wire          dbg_clk_en;         // SW-DP Clock Enable
  wire          dbgdi;              // SW-DP Data In
  wire          busack;             // Bus Trasnaction Acknowledge
  wire   [31:0] busrdata;           // Bus RD Data Port
  wire          buscmp;             // Bus Pushed Verify/Find
  wire          buserr;             // Bus Error
  wire   [11:0] busendcnt;          // Bus end count
  wire          cdbgpwrupack;       // Debug Power Domain up acknowledge
  wire          csyspwrupack;       // System Power Domain up acknowledge
  wire          cdbgrstack;         // Debug reset acknowledge to reset controller
  reg           dbg_do_reg;         // SW-DP Data Out
  wire          dbgdoen;            // SW-DP Data Out Enable
  reg           dbg_do_en_int;      // SW-DP Data Out Enable - internal version
  wire          busreq;             // Bus Transaction Request
  wire          buswrite;           // Bus write
  wire          busabort;           // Bus abort
  wire  [31:24] busaddr_31to24;     // Bus Address Port - AP Sel
  wire  [7:2]   busaddr_7to2;       // Bus Address Port - Bank/Reg Sel
  wire   [31:0] buswdata;           // Bus write Data Port
  wire    [1:0] busmode;            // Bus Mode
  wire    [3:0] busmask;            // Bus Compare Mask
  wire   [11:0] bustrncnt;          // Bus Transfer Cnt
  reg           cdbgpwrupreq_reg;   // Debug Power Domain up request
  reg           csyspwrupreq_reg;   // System Power Domain up request
  reg           cdbgrstreq_reg;     // Debug reset request to reset controller

  // Internal signals
// SLE state machine registers
  reg     [4:0] state;       // SLE current state
  reg     [4:0] nxt_state;   // SLE next state
  wire    [4:0] rst_state;   // SLE next state with wire reset
// SLE transaction registers,. pulled directly from SW wire.
  reg           ser_dir;     // DP serial direction
  wire          ser_dir_en;  // DP serial direction enable
  reg           ser_bank;    // DP serial bank
  wire          ser_bank_en; // DP serial bank enable
  reg     [1:0] ser_addr;    // DP serial address
  wire    [1:0] ser_addr_d;  // DP serial data input
  wire          ser_addr_en; // DP serial address enable
  reg     [4:0] ser_cnt;     // DP serial count, 32-bits
  wire    [4:0] ser_cnt_d;   // DP serial count DFF input
  wire          ser_cnt_en;  // DP serial count DFF enable
// local write buffer and shift register handshake signals
  reg           w_buf_req;   // write buffer request
  reg           w_buf_req_d; // write buffer request DFF input
  reg           w_buf_req_en;// write buffer request DFF enable
  reg           w_buf_ack;   // write buffer acknowledge
  reg           w_buf_ack_d; // write buffer acknowledge DFF input
  reg           w_buf_ack_en;// write buffer acknowledge DFF enable
  wire          w_buf_cancel;// write buffer cancel
// generate ready status for next state logic and SYNDO.
  reg           iface_rdy_c;    // interface ready capture DFF_Q
  wire          iface_rdy_c_d;  // interface ready capture (~nCONT)
  wire          iface_rdy_c_en; // interface ready capture DFF_En
  reg           iface_rdy_ac;   // interface ready acknowledged DFF_Q
  wire          ac_state_en;    // iface_rdy_ac & resp_fault_reg En

// shift register, for PWDATA output, and PRDATA readbuffer input
  reg    [31:0] shift_reg;      // shift register
  reg    [31:0] shift_reg_d;    // shift register DFF input
  reg           shift_reg_en;   // shift register DFF enable
// Handshake and synchronisation between shift register and R/W buffers
  reg           i_bus_req;      // bus request
  reg           i_bus_req_d;    // bus request DFF input
  reg           i_bus_req_en;   // bus request DFF enable
  wire    [31:0] i_bus_wdata;   // bus write data register
  reg    [31:0] ibuswdata_cdc_check;  // bus write data register
  wire          i_bus_wdata_en; // bus write data DFF enable
  reg [31:0]    retry_reg;      // Bus read data shadow
  wire [31:0]   retry_reg_d;    // Bus read data shadow input
  reg           retry_reg_en;   // Bus read data shadow enable

// parity generation
  reg           parity;         // parity bit for read/write
  wire          parity_d;       // parity DFF.D
  wire          parity_en;      // parity DFF.En
// Error check (per header)
  reg           err_chk;        // Error Check
  wire          err_chk_d;      // Error Check DFF.D
  wire          err_chk_en;     // Error Check DFF.En
// write Packet Error
  reg           write_err_reg;  // write Error DFF
  reg           write_err_d;    // write Error DFF.D
  reg           write_err_en;   // write Error DFF.En
  wire          prevent_write;  // Error before write completes

// Reag OK status bit
  reg           read_ok_reg;    // Previous read was accepted
  reg           read_ok_d;      // ReadOK Dff.D
  reg           read_ok_en;     // ReadOK Dff.En
// ID register read after reset
  reg           need_id_read_reg; // ID register read must be next
  wire          need_id_read_en;  // need_id_read_reg Dff.En
  wire          need_id_read_d;   // need_id_read_reg Dff.D


// fault response
  wire          resp_fault_d;   // Resp is fault Dff.D
  reg           resp_fault_reg; // Resp is fault

// control/Status register
  wire          ctrl_stat_en;        // control register enable
  wire          sticky_status;       // sticky status
  reg           sticky_cmp;          // sticky compare status
  reg           sticky_cmp_d;        // sticky compare DFF input
  reg           sticky_cmp_en;       // sticky compare DFF enable
  reg           sticky_err;          // sticky error register
  reg           sticky_err_d;        // sticky error DFF input
  reg           sticky_err_en;       // sticky error DFF enable
  reg           prevent_clr_sticky;  // sticky error clear disable
  wire     [3:0] mask_lane;          // compare operation byte lane masks
  reg     [3:0] mask_lane_cdc_check; // compare operation byte lane masks
  wire     [1:0] trnfer_mode;        // transfer mode
  reg     [1:0] trnfermode_cdc_check;// transfer mode
  wire    [11:0] trnfer_cnt;         // transfer counter
  reg    [11:0] trnfercnt_cdc_check; // transfer counter
  reg    [11:0] trnfer_cnt_d;        // transfer counter DFF input
  reg           trnfer_cnt_en;       // transfer counter DFF enable
  reg           continue_detect_reg; // Static packet length mode
  reg           continue_err_reg;    // wait was sent
  reg           continue_err_d;      // D input for continue_err_reg
  reg           continue_err_en;     // enable for continue_err_reg

// Wire control Register
  wire          wire_ctrl_en;        // Wire control Enable
  reg     [1:0] prescaler_reg;       // dbgclk prescaler
  wire    [1:0] prescaler_d;         // dbgclk prescaler DFF.D
  reg     [1:0] turn_cnt;            // Turn Around Counter
  wire    [1:0] turn_cnt_d;          // Turn Around Counter DFF.D
// AP select register
  reg     [3:0] ap_bank_sel;         // AP bank select
  wire           ap_dir;             // AP direction
  reg           ap_dir_cdc_check;    // AP direction
  wire          ap_dir_d;            // AP direction DFF input
  reg     [1:0] ap_reg_sel;          // AP register select
  wire    [1:0] ap_reg_sel_d;        // AP register select DFF input
  wire          ap_reg_sel_en;       // AP register select DFF enable
  reg     [7:0] ap_sel;              // AP select
  wire          ap_sel_en;           // AP select enable
  reg     [3:0] ctrl_sel;            // address bank select
  reg           dap_dir;             // DAP APB direction
  wire          dap_dir_en;          // DAP APB direction DFF input
  reg           dap_bank;            // DAP APB direction DFF enable
  wire          dap_bank_en;         // DAP APB bank
  reg     [1:0] dap_reg_sel;         // DAP AP bank register select
  reg           dap_abort;           // DAP AP abort
  reg           dap_abort_d;         // DAP AP abort DFF input
  reg           dap_abort_en;        // DAP AP abort DFF enable
  wire          mask_ack;            // Mask acknowledge bits
  reg           nxt_dbg_do;          // next dbgdo
  reg           nxt_dbg_do_en;       // next dbgdoen

  wire          i_wire_reset;        // From (optional) wire interface
  wire [5:0]    reset_count_d;       // Line reset DFF input
  reg  [5:0]    reset_count_reg;     // Line Reset counter
  wire          reset_count_en;      // Line Reset DFF Enabled


// dbgdi mask control
  wire nxt_mask_dbg_di;              // D-input of the mask signal
  reg  mask_dbg_di;                  // Mask control for dbgdi during turn around
  wire dbg_di_masked;                // Masked dbgdi


// --========================================================================--
// Beginning of main code
// --========================================================================--

  // This would be driven from wire manager block in Async version
  assign dbg_clk_en  = swdsel & (~i_wire_reset | ~reset_count_reg[0]);
  assign wirereset = i_wire_reset;

// ----------------------------------------------------------------------------
// Mask dbgdi when the state machine is in turnaround state as there will be no
// driver on the line
// ----------------------------------------------------------------------------

  assign dbg_di_masked = dbgdi | mask_dbg_di;

// ----------------------------------------------------------------------------
// Synchronous mode wire reset counter
// ----------------------------------------------------------------------------
  assign reset_count_en = dbg_di_masked & ~dbg_do_en_int ?
                        (~i_wire_reset|~reset_count_reg[0]) : (|reset_count_reg);
  assign reset_count_d  = dbg_di_masked & ~dbg_do_en_int ? (reset_count_reg+6'd1) : {6{1'b0}};

  //Synchronous block for reset counter
  always @(posedge dbgclk or negedge dbgresetn)
    if (~dbgresetn)
      reset_count_reg <= {6{1'b0}};
    else if (reset_count_en)
      reset_count_reg <= reset_count_d;

  assign i_wire_reset = ((reset_count_reg[5:1] == 5'd25) | wireresetreq);

// ----------------------------------------------------------------------------
// state machine register for SingleWire protocol
// ----------------------------------------------------------------------------
  always @ (*)
    case (state)
      // Header States
      SWDP_SLERESET     : nxt_state = dbg_di_masked ? SWDP_SLERESET : SWDP_SLEIDLE;
      SWDP_SLEIDLE      : nxt_state = dbg_di_masked ? SWDP_SLEBANK  : SWDP_SLEIDLE;
      SWDP_SLEBANK      : nxt_state = SWDP_SLEDIR;
      SWDP_SLEDIR       : nxt_state = SWDP_SLEADDR0;
      SWDP_SLEADDR0     : nxt_state = SWDP_SLEADDR1;
      SWDP_SLEADDR1     : nxt_state = SWDP_SLEPARITYH;
      SWDP_SLEPARITYH   : nxt_state = SWDP_SLESTOPH;
      SWDP_SLESTOPH     : nxt_state = SWDP_SLEPARKH;
      SWDP_SLEPARKH     : case (turn_cnt)
                        2'b11 : nxt_state = SWDP_SLETRNH2;
                        2'b10 : nxt_state = SWDP_SLETRNH1;
                        2'b01 : nxt_state = SWDP_SLETRNH0;
                        2'b00 : nxt_state = SWDP_SLEACK0;
                        default:nxt_state = {5{1'bx}};
                      endcase // case (turn_cnt)
      SWDP_SLETRNH2     : nxt_state = SWDP_SLETRNH1;
      SWDP_SLETRNH1     : nxt_state = SWDP_SLETRNH0;
      SWDP_SLETRNH0     : nxt_state = SWDP_SLEACK0;
      // Acknowledge States
      SWDP_SLEACK0      : nxt_state = SWDP_SLEACK1;
      SWDP_SLEACK1      : nxt_state = SWDP_SLEACK2;
      // write data path is used in contdetect mode for padding
      // Goes straight to error state on protocol error
      SWDP_SLEACK2      : nxt_state = err_chk ? SWDP_SLEERR :
                                      ({5{ (~iface_rdy_ac | resp_fault_reg |
                                           (ser_dir==SWDP_SERWRITE))}} & SWDP_SLEPARKW) |
                                      ({5{~(~iface_rdy_ac | resp_fault_reg |
                                           (ser_dir==SWDP_SERWRITE))}} & SWDP_SLEDATAR);
      // write States, turn is also used at end of read
      SWDP_SLEPARKW     : case (turn_cnt)
                             2'b11 : nxt_state = SWDP_SLETRNW3;
                             2'b10 : nxt_state = SWDP_SLETRNW2;
                             2'b01 : nxt_state = SWDP_SLETRNW1;
                             2'b00 : nxt_state = SWDP_SLETRNW0;
                             default:nxt_state = {5{1'bx}};
                           endcase // case(turn_cnt)
      SWDP_SLETRNW3     : nxt_state = SWDP_SLETRNW2;
      SWDP_SLETRNW2     : nxt_state = SWDP_SLETRNW1;
      SWDP_SLETRNW1     : nxt_state = SWDP_SLETRNW0;
      // To write data or resume (if transfer was a read in contdetect mode)
      SWDP_SLETRNW0     : nxt_state = (((ser_dir==SWDP_SERREAD) &
                                        ~((~iface_rdy_ac | resp_fault_reg) &
                                          continue_detect_reg)) |
                                       ((ser_dir==SWDP_SERWRITE) &
                                        ((~iface_rdy_ac | resp_fault_reg) &
                                         ~continue_detect_reg))) ?
                                      SWDP_SLERESC:SWDP_SLEDATAW;
      SWDP_SLEDATAW     : nxt_state = (ser_cnt==SWDP_CNT32) ?
                                      SWDP_SLEPARITYW : SWDP_SLEDATAW;
      SWDP_SLEPARITYW   : nxt_state = SWDP_SLESTOPW;
      // Check for errors in case the port has just been deselected
      SWDP_SLESTOPW     : nxt_state = err_chk ? SWDP_SLEERR :
                                      (({5{ dbg_di_masked}} & SWDP_SLEBANK) |
                                       ({5{~dbg_di_masked}} & SWDP_SLEIDLE));
      // read States
      SWDP_SLEDATAR     : nxt_state = (ser_cnt==SWDP_CNT32) ?
                                      SWDP_SLEPARITYR : SWDP_SLEDATAR;
      SWDP_SLEPARITYR   : nxt_state = SWDP_SLEPARKW;
      // Closing States
      SWDP_SLERESC      : nxt_state = dbg_di_masked ? SWDP_SLEBANK : SWDP_SLEIDLE;
      // Error States
      SWDP_SLEERR     : nxt_state = SWDP_SLEERR;
      // Un-used states - force to ERROR even though unreachable.
      SWDP_SLEMARKW,
      SWDP_SLESTOPR,
      SWDP_SLERESW,
      SWDP_UNUSED01 : nxt_state = SWDP_SLEERR;
      // Default
      default : nxt_state = {5{1'bx}};
    endcase

  assign rst_state = i_wire_reset ? SWDP_SLERESET : nxt_state;

// Sequential logic for state
  always @ (negedge dbgresetn or posedge dbgclk)
    if (!dbgresetn)
      state <= SWDP_SLERESET;
    else if (dbg_clk_en)
      state <= rst_state;

  // Require the first access after a reset to be an ID register read
  assign need_id_read_en = (state==SWDP_SLESTOPH & ~err_chk &
                            ser_dir==SWDP_SERREAD &
                            ser_bank==SWDP_DPREG & ser_addr==SWDP_IDCODE) |
                             i_wire_reset;
  assign need_id_read_d = i_wire_reset;

// Sequential logic for NeedReadIdReg
  always @ (negedge dbgresetn or posedge dbgclk)
    if (!dbgresetn)
      need_id_read_reg <= 1'b1;
    else if (need_id_read_en)
      need_id_read_reg <= need_id_read_d;

// ----------------------------------------------------------------------------
// Generate Mask for DI when the state machine is in turn around states
// ----------------------------------------------------------------------------

  assign nxt_mask_dbg_di = (nxt_state == SWDP_SLETRNW3 |
                            nxt_state == SWDP_SLETRNW2 |
                            nxt_state == SWDP_SLETRNW1 |
                            nxt_state == SWDP_SLETRNW0 ) ;


// Sequential logic for MaskDiReg
  always @ (negedge dbgresetn or posedge dbgclk)
    if (!dbgresetn)
      mask_dbg_di <= 1'b0;
    else
      mask_dbg_di <= nxt_mask_dbg_di;


// ----------------------------------------------------------------------------
// Allow access to specific registers when sticky bits are set
// ----------------------------------------------------------------------------
  // Permit access to IDCODE, ABORT, CTRL/STAT, targetsel
  assign resp_fault_d = sticky_status &
                       ~(ser_bank==SWDP_DPREG &
                         (ser_addr==SWDP_ABORT |
                          (ser_dir==SWDP_SERREAD & ctrl_sel == SWDP_BNKCTRL &
                           ser_addr==SWDP_STAT) |
                          (ser_dir==SWDP_SERWRITE & ser_addr==SWDP_TARGETSEL)));

  //Capture resp fault at ACK
  always @ (negedge dbgresetn or posedge dbgclk)
    if (!dbgresetn)
      resp_fault_reg <= 1'b0;
    else if (ac_state_en)
      resp_fault_reg <= resp_fault_d;

// ----------------------------------------------------------------------------
// dbgdo output data and control
// ----------------------------------------------------------------------------
  // Mask response bits if target selector register written,
  // or protocol error
  assign mask_ack = (err_chk |
                    (ser_dir==SWDP_SERWRITE & ser_bank==SWDP_DPREG &
                     ser_addr==SWDP_TARGETSEL));

  always @ (*)
    begin
      case (state)
        // Receive states
        SWDP_SLEIDLE,SWDP_SLEBANK,SWDP_SLEDIR,SWDP_SLEADDR0,SWDP_SLEADDR1,
        SWDP_SLEPARITYH,SWDP_SLESTOPH,
        SWDP_SLEPARKH,SWDP_SLETRNH2,SWDP_SLETRNH1,SWDP_SLETRNH0,
        SWDP_SLETRNC,SWDP_SLERESC,
        SWDP_SLEDATAW,SWDP_SLEPARITYW,SWDP_SLESTOPW,SWDP_SLEERR,
        SWDP_SLERESET : begin
          nxt_dbg_do   = 1'b0;
          nxt_dbg_do_en = 1'b0;
        end
        // 1st cycle of ACK, driven if not ERROR
        SWDP_SLEACK0 : begin
          nxt_dbg_do   = err_chk | (iface_rdy_ac&~resp_fault_reg);
          nxt_dbg_do_en = ~mask_ack;
        end
        // 2nd cycle of ACK, driven if not ERROR
        SWDP_SLEACK1 : begin
          nxt_dbg_do   = err_chk | (~iface_rdy_ac&~resp_fault_reg);
          nxt_dbg_do_en = ~mask_ack;
        end
        // 3rd cycle of ACK, driven if not ERROR
        SWDP_SLEACK2 : begin
          nxt_dbg_do   = err_chk | resp_fault_reg;
          nxt_dbg_do_en = ~mask_ack;
        end
        // Turn round states. Wire is undriven, expect external pullup
        SWDP_SLEPARKW,SWDP_SLETRNW3, SWDP_SLETRNW2,
          SWDP_SLETRNW1,SWDP_SLETRNW0: begin
          nxt_dbg_do   = 1'b1;
          nxt_dbg_do_en = 1'b0;
          end
        // Drive read data
        SWDP_SLEDATAR : begin
          nxt_dbg_do   = shift_reg[0];
          nxt_dbg_do_en = 1'b1;
        end
        // Drive read parity
        SWDP_SLEPARITYR : begin
          nxt_dbg_do   = parity;
          nxt_dbg_do_en = 1'b1;
        end
        // Un-used states - checked never reached in assertion
        SWDP_SLEMARKW,
        SWDP_SLESTOPR,
        SWDP_SLERESW,
        SWDP_UNUSED01 :  begin
            nxt_dbg_do   = 1'bX;
            nxt_dbg_do_en = 1'bX;
          end
        default: begin
          nxt_dbg_do   = 1'bx;
          nxt_dbg_do_en = 1'bx;
        end
      endcase
    end

// Sequential logic for  dbgdo registers
  always @ (negedge dbgresetn or posedge dbgclk)
    if (!dbgresetn)
      begin
        dbg_do_reg <= 1'b0;
        dbg_do_en_int  <= 1'b0;
      end
    else
      begin
        dbg_do_reg <= nxt_dbg_do;
        dbg_do_en_int  <= nxt_dbg_do_en;
      end
  assign dbgdoen = dbg_do_en_int;

  //Drive output signal
  assign dbgdo = dbg_do_reg;


// --========================================================================--
// Local Transaction Registers
// --========================================================================--

// ----------------------------------------------------------------------------
// Transaction Bank register
// ----------------------------------------------------------------------------
  assign ser_bank_en = dbg_clk_en & state==SWDP_SLEBANK;

  // Sequential logic for ser_bank register
  always @ (negedge dbgresetn or posedge dbgclk)
    if (!dbgresetn)
      ser_bank <= 1'b0;
    else if (ser_bank_en)
      ser_bank <= dbg_di_masked;

// ----------------------------------------------------------------------------
// Transaction direction register
// ----------------------------------------------------------------------------
  assign ser_dir_en = dbg_clk_en & state==SWDP_SLEDIR;

  // Sequential logic for ser_dir register
  always @ (negedge dbgresetn or posedge dbgclk)
    if (!dbgresetn)
      ser_dir <= 1'b0;
    else if (ser_dir_en)
      ser_dir <= dbg_di_masked;

// ----------------------------------------------------------------------------
// Transaction Address register
// ----------------------------------------------------------------------------
  assign ser_addr_en = dbg_clk_en & (state==SWDP_SLEADDR0 | state==SWDP_SLEADDR1);
  assign ser_addr_d  = {dbg_di_masked,ser_addr[1]};

  // Sequential logic for ser_addr register
  always @ (negedge dbgresetn or posedge dbgclk)
    if (!dbgresetn)
      ser_addr <= 2'b00;
    else if (ser_addr_en)
      ser_addr <= ser_addr_d;

// ----------------------------------------------------------------------------
// Transaction Data register and shadow
// ----------------------------------------------------------------------------
  always @ (*)
    begin
      if (dbg_clk_en)
        case (state)
          // capture ID/busrdata into ReadBuffer/shift_reg.
          SWDP_SLEACK1 : begin
            if (ser_dir==SWDP_SERREAD & ~err_chk)
              begin
                if (iface_rdy_ac&~resp_fault_reg)
                  begin
                    if (ser_bank==SWDP_APREG)
                      begin
                        shift_reg_d  = busrdata;
                        shift_reg_en = 1'b1;
                        retry_reg_en = 1'b1;
                        read_ok_d    = 1'b1;
                        read_ok_en   = 1'b1;
                      end
                    else // if (ser_bank==SWDP_DPREG)
                      begin
                        case (ser_addr)
                          SWDP_IDCODE : begin
                            shift_reg_d  = {SWDP_REV, SWDP_ID}; // DeviceID
                            shift_reg_en = 1'b1;
                            retry_reg_en = 1'b0;
                            read_ok_d    = 1'b0;
                            read_ok_en   = 1'b0;
                          end
                          SWDP_STAT : begin
                            case (ctrl_sel)
                              SWDP_BNKCTRL     : shift_reg_d = {csyspwrupack, csyspwrupreq_reg,
                                                                 cdbgpwrupack, cdbgpwrupreq_reg,
                                                                 cdbgrstack,   cdbgrstreq_reg,
                                                                 2'b00,trnfer_cnt, mask_lane,
                                                                 write_err_reg, read_ok_reg,
                                                                 sticky_err, sticky_cmp,
                                                                 trnfer_mode, continue_err_reg,
                                                                 continue_detect_reg};
                              SWDP_BNKWCR      : shift_reg_d = {20'h00000,2'b00,
                                                               turn_cnt,1'b0,1'b1,
                                                               4'b0000,prescaler_reg};
                              SWDP_BNKTARGETID : shift_reg_d = targetid;
                              SWDP_BNKDLPIDR   : shift_reg_d = {instanceid, 24'h000000,
                                                               SWDP_PROTOVER};
                              SWDP_BNKUNK4, SWDP_BNKUNK5,
                              SWDP_BNKUNK6, SWDP_BNKUNK7,
                              SWDP_BNKUNK8, SWDP_BNKUNK9,
                              SWDP_BNKUNKA, SWDP_BNKUNKB,
                              SWDP_BNKUNKC, SWDP_BNKUNKD,
                              SWDP_BNKUNKE, SWDP_BNKUNKF : shift_reg_d = 32'h00000000;
                              default           : shift_reg_d = 32'hXXXXXXXX;
                            endcase
                            shift_reg_en = 1'b1;
                            retry_reg_en = 1'b0;
                            read_ok_d    = 1'b0;
                            read_ok_en   = 1'b0;
                          end
                          SWDP_RESEND: begin
                            shift_reg_d  = retry_reg;
                            shift_reg_en = 1'b1;
                            retry_reg_en = 1'b0;
                            read_ok_d    = 1'b0;
                            read_ok_en   = 1'b0;
                          end
                          SWDP_RDBUFF : begin
                            shift_reg_d  = busrdata;
                            shift_reg_en = 1'b1;
                            retry_reg_en = 1'b1;
                            read_ok_d  = 1'b1;
                            read_ok_en = 1'b1;
                          end
                          default : begin
                            shift_reg_d  = {32{1'bx}};
                            shift_reg_en = 1'bx;
                            retry_reg_en = 1'bx;
                            read_ok_d    = 1'bx;
                            read_ok_en   = 1'bx;
                          end
                        endcase
                      end // else: !if(ser_bank==SWDP_APREG)
                  end else // if (iface_rdy_ac)
                    begin
                      shift_reg_d  = {32{1'b0}};
                      shift_reg_en = 1'b0;
                      retry_reg_en = 1'b0;
                      read_ok_d    = 1'b0;
                      read_ok_en   = ((ser_bank==SWDP_APREG)|
                                      (ser_addr==SWDP_RDBUFF));
                    end
              end // if (ser_dir==SWDP_SERREAD & ~err_chk)
            else
              begin
                shift_reg_d  = {32{1'b0}};
                shift_reg_en = 1'b0;
                retry_reg_en = 1'b0;
                read_ok_d    = 1'b0;
                read_ok_en   = 1'b0;
              end // else: !if(ser_dir==SWDP_SERREAD & ~err_chk)

          end
          SWDP_SLEDATAW : begin
            shift_reg_d  = {dbg_di_masked,shift_reg[31:1]};
            shift_reg_en = ~resp_fault_reg;
            retry_reg_en = 1'b0;
            read_ok_d    = 1'b0;
            read_ok_en   = 1'b0;
          end
          SWDP_SLEDATAR : begin
            shift_reg_d  = {1'b0,shift_reg[31:1]};
            shift_reg_en = 1'b1;
            retry_reg_en = 1'b0;
            read_ok_d    = 1'b0;
            read_ok_en   = 1'b0;
          end
          SWDP_SLERESET, SWDP_SLEIDLE, SWDP_SLEBANK, SWDP_SLEDIR ,
            SWDP_SLEADDR0, SWDP_SLEADDR1,
            SWDP_SLEPARITYH, SWDP_SLESTOPH, SWDP_SLEPARKH,
            SWDP_SLETRNH0, SWDP_SLETRNH1, SWDP_SLETRNH2,
            SWDP_SLEACK0, SWDP_SLEACK2,
            SWDP_SLEPARKW, SWDP_SLETRNW3, SWDP_SLETRNW2, SWDP_SLETRNW1,
            SWDP_SLETRNW0, SWDP_SLEPARITYW, SWDP_SLESTOPW,
            SWDP_SLEPARITYR,SWDP_SLETRNC, SWDP_SLERESC, SWDP_SLEERR:
            begin
              shift_reg_d  = {32{1'b0}};
              shift_reg_en = 1'b0;
              retry_reg_en = 1'b0;
              read_ok_d    = 1'b0;
              read_ok_en   = 1'b0;
            end
          // Un-used states
          SWDP_SLEMARKW,
          SWDP_SLESTOPR,
          SWDP_SLERESW,
          SWDP_UNUSED01 :  begin
            shift_reg_d  = {32{1'b0}};
            shift_reg_en = 1'b0;
            retry_reg_en = 1'b0;
            read_ok_d    = 1'b0;
            read_ok_en   = 1'b0;
          end
          default: begin
            shift_reg_d  = {32{1'bx}};
            shift_reg_en = 1'bx;
            retry_reg_en = 1'bx;
            read_ok_d    = 1'bx;
            read_ok_en   = 1'bx;
         end
        endcase // case(state)
      else
        begin
          shift_reg_d  = {32{1'b0}};
          shift_reg_en = 1'b0;
          retry_reg_en = 1'b0;
          read_ok_d    = 1'b0;
          read_ok_en   = 1'b0;
        end // else: !if(dbg_clk_en)
    end


  // Sequential logic for shift_reg register
  always @ (posedge dbgclk)
    if (shift_reg_en)
      shift_reg <= shift_reg_d;

  // Retry reg is alwasy loaded from BusRDATA when enabled.
  assign retry_reg_d  = busrdata;

  // Sequential logic for Retry register
  always @ (posedge dbgclk or negedge dbgresetn)
    if(!dbgresetn)
       retry_reg <= 32'h00000000;
    else
      if (retry_reg_en)
        retry_reg <= retry_reg_d;

  // Sequential logic for ReadOK register
  always @ (posedge dbgclk or negedge dbgresetn)
    if(!dbgresetn)
      read_ok_reg <= 1'b0;
    else
      if (read_ok_en)
        read_ok_reg <= read_ok_d;

// ----------------------------------------------------------------------------
// Transaction Data Count register
// ----------------------------------------------------------------------------
  assign ser_cnt_en = i_wire_reset | (dbg_clk_en & (state==SWDP_SLEDATAW |
                                              state==SWDP_SLEDATAR));
  assign ser_cnt_d  = i_wire_reset ? 5'b0000 : (ser_cnt + 5'b00001);

  // Sequential logic for Transaction count register
  always @ (negedge dbgresetn or posedge dbgclk)
    if (!dbgresetn)
      ser_cnt <= 5'b00000;
    else if (ser_cnt_en)
      ser_cnt <= ser_cnt_d;

// ----------------------------------------------------------------------------
// Generate parity
// ----------------------------------------------------------------------------
  assign parity_en = dbg_clk_en & (// clear the parity bit
                                (state==SWDP_SLERESC     |
                                 state==SWDP_SLESTOPW    |
                                 state==SWDP_SLEIDLE     |
                                 state==SWDP_SLEPARITYH) |
                                // write the parity bit
                                (state==SWDP_SLEBANK  |
                                 state==SWDP_SLEDIR   |
                                 state==SWDP_SLEADDR0 |
                                 state==SWDP_SLEADDR1 |
                                 state==SWDP_SLEDATAW |
                                 state==SWDP_SLEDATAR));
  assign parity_d  = ((parity ^ shift_reg[0]) & (state==SWDP_SLEDATAR)) |
                    ((parity ^ dbg_di_masked) & (state==SWDP_SLEDATAW |
                                         state==SWDP_SLEBANK  |
                                         state==SWDP_SLEDIR   |
                                         state==SWDP_SLEADDR0 |
                                         state==SWDP_SLEADDR1));

  // Sequential logic for parity register
  always @ (negedge dbgresetn or posedge dbgclk)
    if (!dbgresetn)
      parity <= 1'b0;
    else if (parity_en)
      parity <= parity_d;

// ----------------------------------------------------------------------------
// Error Check - Detect protocol error in header. Self clearing
// ----------------------------------------------------------------------------
  assign err_chk_en = dbg_clk_en & (// Set
                                  err_chk_d |
                                  // Clr
                                  i_wire_reset);

  assign err_chk_d  = // parity error
                      ((dbg_di_masked!=parity) & (state==SWDP_SLEPARITYH)) |
                      // Stop-bit error
                      ((dbg_di_masked==1'b1)   & (state==SWDP_SLESTOPH )) |
                      // Mark/Resume-bit error
                      ((dbg_di_masked==1'b0)   & (state==SWDP_SLEPARKH)) |
                      // ID-register not read or TargetSel not written
                      // after WireReset
                      (need_id_read_reg & (state==SWDP_SLESTOPH) &
                       ~(ser_bank==SWDP_DPREG & ser_dir==SWDP_SERREAD &
                         ser_addr==SWDP_IDCODE) &
                       ~(ser_bank==SWDP_DPREG & ser_dir==SWDP_SERWRITE &
                         ser_addr==SWDP_TARGETSEL)) |
                      // TargetSel written at any time other than after reset
                      (~need_id_read_reg & (state==SWDP_SLESTOPH) &
                       ser_bank==SWDP_DPREG & ser_dir==SWDP_SERWRITE &
                       ser_addr==SWDP_TARGETSEL) |
                      // Target selected doesn't select this target or has
                      // a parity error
                      ((state==SWDP_SLEPARITYW) &
                       ser_dir==SWDP_SERWRITE & ser_bank==SWDP_DPREG &
                       ser_addr==SWDP_TARGETSEL &
                       ~((shift_reg[31:0] == {instanceid, targetid[27:0]}) &
                         (dbg_di_masked==parity)));

  // Sequential logic for err_chk register
  always @ (negedge dbgresetn or posedge dbgclk)
    if (!dbgresetn)
      err_chk <= 1'b0;
    else if (err_chk_en)
      err_chk <= err_chk_d;

// ----------------------------------------------------------------------------
// Host write Data parity Error - sticky cleared by abort reg write
// ----------------------------------------------------------------------------
  always @ (*)
    begin
      if (dbg_clk_en & (state==SWDP_SLEPARITYW |
                        state==SWDP_SLESTOPW   |
                        w_buf_cancel))
        begin
          write_err_d = ((dbg_di_masked!=parity) & (state==SWDP_SLEPARITYW)) |
                        w_buf_cancel;
          write_err_en= ((dbg_di_masked!=parity) & (state==SWDP_SLEPARITYW) &
                         (~continue_err_reg | (ser_bank==SWDP_DPREG & ser_dir==SWDP_SERWRITE & ser_addr==SWDP_ABORT)) &
                         // Ignore write data parity errors on TargetSel
                         ~(ser_bank==SWDP_DPREG & ser_dir==SWDP_SERWRITE &
                           ser_addr==SWDP_TARGETSEL)) |
                        (iface_rdy_ac & state==SWDP_SLESTOPW & ~prevent_clr_sticky &
                         ser_dir==SWDP_SERWRITE &
                         ser_bank==SWDP_DPREG & ser_addr==SWDP_ABORT &
                         ~err_chk & shift_reg[3] & write_err_reg) |
                          w_buf_cancel;
        end // if (dbg_clk_en & (state==SWDP_SLEPARITYW |...
      else
        begin
          write_err_d  = 1'b0;
          write_err_en = 1'b0;
        end
    end // always @ (dbg_clk_en or iface_rdy_ac or state or...

  // Sequential logic for WriteErr register
  always @ (negedge dbgresetn or posedge dbgclk)
    if (!dbgresetn)
      write_err_reg <=  1'b0;
    else if (write_err_en)
      write_err_reg <= write_err_d;

  assign prevent_write = write_err_reg | write_err_d;

// --========================================================================--
// Local shift register controls -- write/read Ready.
// --========================================================================--

// ----------------------------------------------------------------------------
// Handshake of the local shift register write interface.
// ----------------------------------------------------------------------------
  always @(*)
    begin
      if (dbg_clk_en & iface_rdy_ac & state==SWDP_SLESTOPW &
          ser_dir==SWDP_SERWRITE)
        begin
          if (ser_bank==SWDP_DPREG & ser_addr==SWDP_ABORT)
            begin
              w_buf_req_d  = 1'b0;
              w_buf_req_en = 1'b1;
            end
          else if (ser_bank==SWDP_APREG & ~resp_fault_reg & ~sticky_cmp & ~sticky_err &
                   cdbgpwrupack & cdbgpwrupreq_reg & ~prevent_write)
            begin
              w_buf_req_d  = 1'b1;
              w_buf_req_en = 1'b1;
            end
          else
            begin
              w_buf_req_d  = 1'b0;
              w_buf_req_en = 1'b0;
            end
        end
      else if (w_buf_ack | w_buf_cancel)
        begin
          w_buf_req_d  = 1'b0;
          w_buf_req_en = 1'b1;
        end
      else
        begin
          w_buf_req_d  = 1'b0;
          w_buf_req_en = 1'b0;
        end
    end

  // Sequential logic for Wbuf Register
  always @ (negedge dbgresetn or posedge dbgclk)
    if (!dbgresetn)
      w_buf_req <= 1'b0;
    else if (w_buf_req_en)
      w_buf_req <= w_buf_req_d;

// ----------------------------------------------------------------------------
// Handshake of the local shift register, and register capture.
//   Do not accept if last APB transaction incomplete.
//   Only assert for a single clock.
// ----------------------------------------------------------------------------
  always @ (*)
    if (w_buf_req & ~w_buf_cancel & ~w_buf_ack & ~i_bus_req & ~busack)
      begin
        w_buf_ack_d  = 1'b1;
        w_buf_ack_en = 1'b1;
      end
    else
      begin
        w_buf_ack_d  = 1'b0;
        w_buf_ack_en = w_buf_ack;
      end

  // Sequential logic for WbuffAck register
  always @ (negedge dbgresetn or posedge dbgclk)
    if (!dbgresetn)
      w_buf_ack <= 1'b0;
    else if (w_buf_ack_en)
      w_buf_ack <= w_buf_ack_d;

// ----------------------------------------------------------------------------
// Cancel write buffer pipelined write if previous write faulted  or
// shift_reg used for a dp_acc
// ----------------------------------------------------------------------------
  assign w_buf_cancel = w_buf_req & ((
                                   (ser_bank==SWDP_DPREG) & iface_rdy_c &
                                   (state==SWDP_SLEACK0)) |
                                 (sticky_cmp_d & sticky_cmp_en) |
                                 (sticky_err_d & sticky_err_en) |
                                  sticky_cmp | sticky_err
                                 );



// ----------------------------------------------------------------------------
// Wire interface is ready for new transaction.
//   APB transactions have completed and no pending buffered writes.
//   No pending shift_reg buffered writes.
//   Always accept on abort/ID/TargetSel Register
//   Accept control register reads, but not writes
//   w_buf_req will remain '1' while there is a pending APB transfer,
//   but this allows the next command to be queued.
// ----------------------------------------------------------------------------
  assign iface_rdy_c_en = dbg_clk_en & state==SWDP_SLESTOPH;
  assign iface_rdy_c_d  =  // read
                        (~w_buf_req & ser_dir==SWDP_SERREAD  & ~(i_bus_req|busack)) |
                        // write
                        (~w_buf_req & ser_dir==SWDP_SERWRITE & ~(i_bus_req|busack)) |
                        // Pipelined AP write
                        (~w_buf_req & ser_dir==SWDP_SERWRITE &
                         ser_bank==SWDP_APREG &
                         (trnfer_cnt=={12{1'b0}})) |
                        // abort write, ID read
                        (ser_bank==SWDP_DPREG & ser_addr==SWDP_ABORT) |
                        // TargetSel write
                        (ser_bank==SWDP_DPREG & ser_addr==SWDP_TARGETSEL &
                        ser_dir == SWDP_SERWRITE) |
                        // Status register read
                        (ser_bank==SWDP_DPREG & ser_addr==SWDP_STAT &
                         ser_dir == SWDP_SERREAD);

  // Sequential logic for iface_rdy_c register
  always @ (negedge dbgresetn or posedge dbgclk)
    if (!dbgresetn)
      iface_rdy_c <= 1'b0;
    else if (iface_rdy_c_en)
      iface_rdy_c <= iface_rdy_c_d;

  //Capture state of IfaceRdy which is acknowledged
  assign ac_state_en = (nxt_state==SWDP_SLEACK0);

  //Sequential logic for ACK ready state
  always @ (negedge dbgresetn or posedge dbgclk)
    if (!dbgresetn)
      iface_rdy_ac <= 1'b0;
    else if (ac_state_en)
      iface_rdy_ac <= iface_rdy_c;


// --========================================================================--
// Local Interface registers
// --========================================================================--

// ----------------------------------------------------------------------------
// abort register
//   abort requests are always accepted.
//   Always assert dap_abort for at least one cycle, until transaction closed.
// ----------------------------------------------------------------------------
  always @ (*)
    begin
      if (dbg_clk_en & state==SWDP_SLESTOPW & ser_dir==SWDP_SERWRITE &
              ser_bank==SWDP_DPREG & ser_addr==SWDP_ABORT & ~err_chk
          & ~prevent_write )
        begin
          if (shift_reg[0]==1'b1)
            begin
              dap_abort_d  = 1'b1;
              dap_abort_en = 1'b1;
            end
          else
            begin
              dap_abort_d  = 1'b0;
              dap_abort_en = 1'b0;
            end
        end
      else if (~i_bus_req & ~busack)
        begin
          dap_abort_d  = 1'b0;
          dap_abort_en = 1'b1;
        end
      else
        begin
          dap_abort_d  = 1'b0;
          dap_abort_en = 1'b0;
        end
    end

//Sequential logic for dap_abort
  always @ (negedge dbgresetn or posedge dbgclk)
    if (!dbgresetn)
      dap_abort <= 1'b0;
    else if (dap_abort_en)
      dap_abort <= dap_abort_d;

// ----------------------------------------------------------------------------
// APB Address register
//   Do not use dbg_clk_en in async mode as this will block the operation until
//   the next packet is received.
// ----------------------------------------------------------------------------
  assign ap_sel_en = dbg_clk_en & iface_rdy_ac & state==SWDP_SLESTOPW &
         ser_dir==SWDP_SERWRITE & ser_bank==SWDP_DPREG &
         ser_addr==SWDP_ADDR & ~err_chk & ~resp_fault_reg & ~prevent_write;

//Sequential logic for address register
  always @ (negedge dbgresetn or posedge dbgclk)
    if (!dbgresetn)
      begin
        ap_sel     <= {8{1'b0}};
        ap_bank_sel <= {4{1'b0}};
        ctrl_sel   <= {4{1'b0}};
      end
    else if (ap_sel_en)
      begin
        ap_sel     <= shift_reg[31:24];
        ap_bank_sel <= shift_reg[7:4];
        ctrl_sel   <= shift_reg[3:0];
      end

// ----------------------------------------------------------------------------
// APB write data register (double buffer the controls)
//   Do not use dbg_clk_en, as this will block the operation until
//   the next packet is received.
// ----------------------------------------------------------------------------
  assign dap_bank_en = dbg_clk_en & state==SWDP_SLEACK1 & iface_rdy_ac & ~err_chk
                     & ~resp_fault_reg;
  assign dap_dir_en  = dap_bank_en & ser_bank==SWDP_APREG;

//Sequential logic for dap_bank
  always @ (negedge dbgresetn or posedge dbgclk)
    if (!dbgresetn)
      dap_bank <= 1'b0;
    else if (dap_bank_en)
      dap_bank <= ser_bank;

//Sequential logic for header bits of AP access
  always @ (negedge dbgresetn or posedge dbgclk)
    if (!dbgresetn)
      begin
        dap_dir    <= 1'b0;
        dap_reg_sel <= 2'b00;
      end
    else if (dap_dir_en)
      begin
        dap_dir    <= ~ser_dir;
        dap_reg_sel <= ser_addr;
      end

// ----------------------------------------------------------------------------
// SW-DP control/Status Register
// ----------------------------------------------------------------------------
  assign ctrl_stat_en = dbg_clk_en & iface_rdy_ac & state==SWDP_SLESTOPW &
                      ser_dir==SWDP_SERWRITE &
                      ser_bank==SWDP_DPREG & ser_addr==SWDP_CTRL &
                      ctrl_sel==SWDP_BNKCTRL &
                      ~resp_fault_reg & ~err_chk & ~prevent_write;

//Sequential logic for control register
  always @ (negedge dbgresetn or posedge dbgclk)
    if (!dbgresetn)
      begin
        continue_detect_reg   <= 1'b0;
        trnfermode_cdc_check  <= 2'b00;
        mask_lane_cdc_check   <= 4'b0000;
        cdbgrstreq_reg        <= 1'b0;
        cdbgpwrupreq_reg      <= 1'b0;
        csyspwrupreq_reg      <= 1'b0;
      end
    else if (ctrl_stat_en)
      begin
        continue_detect_reg   <= shift_reg[0];
        trnfermode_cdc_check  <= shift_reg[3:2];
        mask_lane_cdc_check   <= shift_reg[11:8];
        cdbgrstreq_reg        <= shift_reg[26];
        cdbgpwrupreq_reg      <= shift_reg[28];
        csyspwrupreq_reg      <= shift_reg[30];
      end

  //Drive output signals
  assign cdbgpwrupreq    = cdbgpwrupreq_reg;
  assign cdbgrstreq      = cdbgrstreq_reg;
  assign csyspwrupreq    = csyspwrupreq_reg;

// -----------------------------------------------------------------------------
// Transaction count register
// -----------------------------------------------------------------------------
  always @ (*)
    begin
      if (ctrl_stat_en)
        begin
          trnfer_cnt_d  = shift_reg[23:12];
          trnfer_cnt_en = 1'b1;
        end
      else if (busack & i_bus_req)
        begin
          trnfer_cnt_d  = busendcnt;
          trnfer_cnt_en = 1'b1;
        end
      else
        begin
          trnfer_cnt_d  = {12{1'b0}};
          trnfer_cnt_en = 1'b0;
        end
    end // always @ (ctrl_stat_en or busack or i_bus_req or busendcnt or shift_reg)

//Sequential logic for transactoun Count register
  always @ (negedge dbgresetn or posedge dbgclk)
    if (!dbgresetn)
       trnfercnt_cdc_check  <= {12{1'b0}};
    else if (trnfer_cnt_en)
       trnfercnt_cdc_check  <= trnfer_cnt_d;

// ----------------------------------------------------------------------------
// Wire control register
// ----------------------------------------------------------------------------
  assign wire_ctrl_en = (dbg_clk_en & iface_rdy_ac & state==SWDP_SLESTOPW &
                       ser_dir==SWDP_SERWRITE & ~resp_fault_reg &
                       ser_bank==SWDP_DPREG & ser_addr==SWDP_CTRL &
                       ctrl_sel==SWDP_BNKWCR & ~err_chk & ~prevent_write) |
                      (i_wire_reset & (prescaler_reg!=2'b11 | turn_cnt!=2'b00));

  assign prescaler_d  = i_wire_reset ? 2'b11 : shift_reg[1:0];
  assign turn_cnt_d   = i_wire_reset ? 2'b00 : shift_reg[9:8];

//Sequential logic for wire control register
  always @ (negedge dbgresetn or posedge dbgclk)
    if (!dbgresetn)
      begin
        prescaler_reg <= 2'b11;
        turn_cnt   <= 2'b00;
      end
    else if (wire_ctrl_en)
      begin
        prescaler_reg <= prescaler_d;
        turn_cnt   <= turn_cnt_d;
      end


// ----------------------------------------------------------------------------
// SW-DP Verify Sticky Compare
// ----------------------------------------------------------------------------
  always @ (*)
    begin
      if (busack & i_bus_req)
        begin
          sticky_cmp_d  = 1'b1;
          sticky_cmp_en = ( buscmp & trnfer_mode==DAP_M_FIND) |
                          (~buscmp & trnfer_mode==DAP_M_VERIFY);
        end
      else if (dbg_clk_en & iface_rdy_ac & state==SWDP_SLESTOPW &
               ser_dir==SWDP_SERWRITE & ser_bank==SWDP_DPREG &
               ser_addr==SWDP_ABORT & ~err_chk & ~resp_fault_reg
               & ~continue_err_d & ~prevent_clr_sticky)
        begin
          sticky_cmp_d  = 1'b0;
          sticky_cmp_en = shift_reg[1] & sticky_cmp;
        end
      else
        begin
          sticky_cmp_d  = 1'b0;
          sticky_cmp_en = 1'b0;
        end
    end // always @ (busack or i_bus_req or buscmp or...

//Sequential logic for StickyCompare register
  always @ (negedge dbgresetn or posedge dbgclk)
    if (!dbgresetn)
      sticky_cmp <= 1'b0;
    else if (sticky_cmp_en)
      sticky_cmp <= sticky_cmp_d;

// -----------------------------------------------------------------------------
// Sticky Error
// -----------------------------------------------------------------------------

  // Sequential logic for blocking Sticky Clear in case of Error
  always @ (negedge dbgresetn or posedge dbgclk)
    if (!dbgresetn)
      prevent_clr_sticky <=  1'b0;
    else
      prevent_clr_sticky <= write_err_d;


  always @ (*)
    begin
      if (busack & i_bus_req)
        begin
          sticky_err_d  = 1'b1;
          sticky_err_en = buserr;
        end
      else if (dbg_clk_en & iface_rdy_ac & state==SWDP_SLESTOPW &
               ser_dir==SWDP_SERWRITE & ser_bank==SWDP_APREG &
               ~err_chk & ~resp_fault_reg)
        begin
          sticky_err_d  = 1'b1;
          sticky_err_en = ~(cdbgpwrupack & cdbgpwrupreq_reg);
        end
      else if (dbg_clk_en & iface_rdy_ac & state==SWDP_SLESTOPW &
               ser_dir==SWDP_SERWRITE & ser_bank==SWDP_DPREG &
               ser_addr==SWDP_ABORT & ~err_chk & ~resp_fault_reg
               & ~continue_err_d & ~prevent_clr_sticky)
        begin
          sticky_err_d  = 1'b0;
          sticky_err_en = shift_reg[2] & sticky_err;
        end
      else
        begin
          sticky_err_d  = 1'b0;
          sticky_err_en = 1'b0;
        end
    end

//Sequential logic for Sticky error register
  always @ (negedge dbgresetn or posedge dbgclk)
    if (!dbgresetn)
      sticky_err <= 1'b0;
    else if (sticky_err_en)
      sticky_err <= sticky_err_d;

// -----------------------------------------------------------------------------
// Continue Error
// -----------------------------------------------------------------------------
  always @ (*)
    begin
      if (continue_detect_reg & dbg_clk_en & state==SWDP_SLEACK2 &
          (sticky_status|err_chk|~iface_rdy_ac))
        begin
          continue_err_d  = 1'b1;
          continue_err_en = ~continue_err_reg;
        end
      else if (dbg_clk_en & iface_rdy_ac & state==SWDP_SLESTOPW &
               ser_dir==SWDP_SERWRITE & ser_bank==SWDP_DPREG &
               ser_addr==SWDP_ABORT & ~err_chk & ~prevent_clr_sticky)
        begin
          continue_err_d  = 1'b0;
          continue_err_en = shift_reg[4] & continue_err_reg;
        end
      else
        begin
          continue_err_d  = 1'b0;
          continue_err_en = 1'b0;
        end
    end

//Sequential logic for Continue error register
  always @ (negedge dbgresetn or posedge dbgclk)
    if (!dbgresetn)
      continue_err_reg <= 1'b0;
    else if (continue_err_en)
      continue_err_reg <= continue_err_d;


// -----------------------------------------------------------------------------
// sticky_status - any state causing transfers to be discarded
// -----------------------------------------------------------------------------
  assign sticky_status = sticky_cmp | sticky_err | write_err_reg | continue_err_reg;


// --========================================================================--
// Bus Interface to APB port.
// --========================================================================--

// ----------------------------------------------------------------------------
// Generate APB Request
//   Do not allow a transfer to start if sticky_status is set.
//   Reads are only performed in normal mode.
// ----------------------------------------------------------------------------
  always @ (*)
    if (i_bus_req)
      begin
        i_bus_req_d  = ~busack;
        i_bus_req_en = busack;
      end
    else if ((w_buf_ack) |
             (dbg_clk_en & state==SWDP_SLEACK1 & ser_dir==SWDP_SERREAD &
              ser_bank==SWDP_APREG & iface_rdy_ac & ~err_chk & ~sticky_status
              & (trnfer_mode==DAP_M_NORMAL) & ~prevent_write))
      begin
        i_bus_req_d  = cdbgpwrupack & cdbgpwrupreq_reg & ~busack;
        i_bus_req_en = cdbgpwrupack & cdbgpwrupreq_reg & ~busack;
      end
    else
      begin
        i_bus_req_d  = i_bus_req;
        i_bus_req_en = 1'b0;
      end

//Sequential logic for i_bus_req
  always @ (negedge dbgresetn or posedge dbgclk)
    if (!dbgresetn)
      i_bus_req <= 1'b0;
    else if (i_bus_req_en)
      i_bus_req <= i_bus_req_d;

// ----------------------------------------------------------------------------
// APB write buffer
// ----------------------------------------------------------------------------
  assign i_bus_wdata_en = w_buf_ack & dap_bank==SWDP_APREG;

//Sequential logic for DAP write buffer
  always @ (negedge dbgresetn or posedge dbgclk)
    if (!dbgresetn)
       ibuswdata_cdc_check  <= 32'h00000000;
    else if (i_bus_wdata_en)
       ibuswdata_cdc_check  <= shift_reg;

// ----------------------------------------------------------------------------
// APB Register Address select
// ----------------------------------------------------------------------------
  assign ap_reg_sel_en = i_bus_req_d & i_bus_req_en;
  assign ap_dir_d     = w_buf_ack ? dap_dir    : ~ser_dir;
  assign ap_reg_sel_d  = w_buf_ack ? dap_reg_sel : ser_addr;

//Sequential logic for AP select
  always @ (negedge dbgresetn or posedge dbgclk)
    if (!dbgresetn)
      begin
         ap_dir_cdc_check     <= 1'b0;
        ap_reg_sel <= 2'b00;
      end
    else if (ap_reg_sel_en)
      begin
         ap_dir_cdc_check     <= ap_dir_d;
        ap_reg_sel <= ap_reg_sel_d;
      end

// ----------------------------------------------------------------------------
// APB outputs
// ----------------------------------------------------------------------------
  assign busreq         = i_bus_req_d;
  assign busaddr_31to24 = ap_sel;
  assign busaddr_7to2   = {ap_bank_sel, ap_reg_sel};
  assign buswdata       = i_bus_wdata;
  assign busabort       = i_bus_req_d & dap_abort;
  assign buswrite       = ap_dir;
  assign busmode        = trnfer_mode;
  assign busmask        = mask_lane;
  assign bustrncnt      = trnfer_cnt;

`ifdef ARM_ASSERT_ON
`include "std_ovl_defines.h"
  reg           w_buf_ack_q; // for checking
//
  always @ (negedge dbgresetn or posedge dbgclk)
    if (!dbgresetn)
      w_buf_ack_q <= 1'b0;
    else
      w_buf_ack_q <= w_buf_ack;

  // w_buf_ack has been incorrectly formed.
  assert_never #(`OVL_ERROR, `OVL_ASSERT, "w_buf_ack has been incorrectly formed.")
    wbufack_check(
                  .clk       (dbgclk),
                  .reset_n   (dbgresetn),
                  .test_expr (w_buf_ack_q & ~i_bus_req));

  // w_buf_ack transaction must not start if previous faulted.
  assert_never #(`OVL_ERROR, `OVL_ASSERT, "w_buf_ack transaction must not start if previous faulted.")
  wbufack_error(
                .clk       (dbgclk),
                .reset_n   (dbgresetn),
                .test_expr (w_buf_ack &
                            (sticky_cmp | sticky_err | write_err_reg)));

  // dbgresetn must be pulsed for simulation to run correctly.
  assert_never_unknown #(`OVL_ERROR, 5, `OVL_ASSERT, "state variable must not be x")
  swdp_dbgresetn(
                 .clk       (dbgclk),
                 .reset_n   (dbgresetn),
                 .qualifier (1'b1),
                 .test_expr (state));

  // Initialise transfer counter via software before using APACC interface.
  assert_never_unknown #(`OVL_ERROR, 12, `OVL_ASSERT,
      "Initialise transfer counter via software before using APACC interface.")
    swdp_trncnt(
                .clk       (dbgclk),
                .reset_n   (dbgresetn),
                .qualifier (i_bus_req),
                .test_expr (trnfer_cnt));

  // Initialise address register via software before using APACC interface.
  assert_never_unknown #(`OVL_ERROR, 14, `OVL_ASSERT,
      "Initialise address register via software before using APACC interface.")
    swdp_apsel(
               .clk       (dbgclk),
               .reset_n   (dbgresetn),
               .qualifier (i_bus_req),
               .test_expr ({ap_sel,ap_bank_sel,dap_reg_sel}));

  // shift_reg must not be x during transaction.
  assert_never_unknown #(`OVL_ERROR, 32, `OVL_ASSERT, "shift_reg must not be x during transaction.")
    swdp_shiftreg(
                  .clk       (dbgclk),
                  .reset_n   (dbgresetn),
                  .qualifier (i_bus_req),
                  .test_expr (shift_reg));

  // shift_reg_en must not be x.
  assert_never_unknown #(`OVL_ERROR, 1, `OVL_ASSERT, "shift_reg_en must not be x.")
    swdp_shiftregen(
                    .clk (dbgclk),
                    .reset_n (dbgresetn),
                    .qualifier (1'b1),
                    .test_expr (shift_reg_en)
                    );


  // i_bus_wdata must not be x during transaction.
  assert_never_unknown #(`OVL_ERROR, 32, `OVL_ASSERT, "i_bus_wdata must not be x during transaction.")
    swdp_ibuswdata(
                   .clk       (dbgclk),
                   .reset_n   (dbgresetn),
                   .qualifier (i_bus_req),
                   .test_expr (i_bus_wdata)
                   );

  // write buffer handshake.
  assert_implication #(`OVL_ERROR, 0, `OVL_ASSERT, "Write buffer ack requires req.")
    swdp_wbufhs_req(
                    .clk             (dbgclk),
                    .reset_n         (dbgresetn),
                    .antecedent_expr (w_buf_ack | w_buf_cancel),
                    .consequent_expr (w_buf_req)
                    );
  assert_transition #(`OVL_ERROR, 2, `OVL_ASSERT, "Write buffer req stays high till ack")
    swdp_wbufhs_ack(
                    .clk             (dbgclk),
                    .reset_n         (dbgresetn),
                    .test_expr       ({w_buf_req,w_buf_ack | w_buf_cancel}),
                    .start_state     (2'b10),
                    .next_state      (2'b11)
                    );
  assert_transition #(`OVL_ERROR, 2, `OVL_ASSERT, "Write buffer req and ack both low after request is acknowledged")
    swdp_wbufhs_next(
                    .clk             (dbgclk),
                    .reset_n         (dbgresetn),
                    .test_expr       ({w_buf_req,w_buf_ack | w_buf_cancel}),
                    .start_state     (2'b11),
                    .next_state      (2'b00)
                    );
  assert_no_transition #(`OVL_ERROR, 0, `OVL_ASSERT, "Write buffer ack requires bus request once previous bus sequence is done")
    swdp_wbufhs_busreq(
                    .clk             (dbgclk),
                    .reset_n         (dbgresetn),
                    .test_expr       ({w_buf_req & ~busack, busreq}),
                    .start_state     (2'b10),
                    .next_state      (2'b10));


  // ser_cnt must not be non-zero outside of shift states.
  assert_never #(`OVL_ERROR, `OVL_ASSERT, "ser_cnt must not be non-zero outside of shift states.")
    sercnt_check(
                 .clk       (dbgclk),
                 .reset_n   (dbgresetn),
                 .test_expr ((|ser_cnt) & ~(state==SWDP_SLEDATAW |
                               state==SWDP_SLEDATAR | i_wire_reset)));

  // Assert that ACK can only be of valid forms
  assert_cycle_sequence #(`OVL_ERROR, 3, 2'b00, `OVL_ASSERT, "ACK none corrupted")
    ack_chk_none(
                .clk           (dbgclk),
                .reset_n       (dbgresetn),
                .event_sequence ({(state==SWDP_SLEACK0&nxt_dbg_do),
                                 nxt_dbg_do,nxt_dbg_do}));

  assert_cycle_sequence #(`OVL_ERROR, 3, 2'b00, `OVL_ASSERT, "ACK OK corrupted")
    ack_chk_ok(
              .clk           (dbgclk),
              .reset_n       (dbgresetn),
              .event_sequence({(state==SWDP_SLEACK0&nxt_dbg_do),~nxt_dbg_do,
                               ~nxt_dbg_do}));

  assert_cycle_sequence #(`OVL_ERROR, 3, 2'b00, `OVL_ASSERT, "ACK wait corrupted")
    ack_chk_wait(
                .clk           (dbgclk),
                .reset_n       (dbgresetn),
                .event_sequence({(state==SWDP_SLEACK0&~nxt_dbg_do),
                                 nxt_dbg_do,~nxt_dbg_do}));

  assert_cycle_sequence #(`OVL_ERROR, 3, 2'b00, `OVL_ASSERT, "ACK fault corrupted")
    ack_chk_fault(
                 .clk           (dbgclk),
                 .reset_n       (dbgresetn),
                 .event_sequence({(state==SWDP_SLEACK0&~nxt_dbg_do),
                                 ~nxt_dbg_do,nxt_dbg_do}));

  // Assert that signals driving ACK may not change whilst in ACK states
  assert_win_unchange #(`OVL_ERROR, 3, `OVL_ASSERT, "response type changed during ACK")
    ack_sig_change(
                 .clk           (dbgclk),
                 .reset_n       (dbgresetn),
                 .start_event   (state==SWDP_SLEACK0),
                 .test_expr     ({err_chk,iface_rdy_ac,resp_fault_reg}),
                 .end_event     (state==SWDP_SLEACK2));

  // Decode the unsed states to check unreacheable.
  reg          state_undef;
  always @(state)
    case (state)
      SWDP_SLEMARKW,
      SWDP_SLESTOPR,
      SWDP_SLERESW,
      SWDP_UNUSED01: state_undef = 1'b1;
      default  : state_undef = 1'b0;
    endcase // case(state)

  // state must never take un-used value
  assert_never #(`OVL_ERROR, `OVL_ASSERT, "state variable has taken an un-used value")
    s_w_state_undef(
                 .clk        (dbgclk),
                 .reset_n    (dbgresetn),
                 .test_expr  (state_undef)
                 );

  assert_never_unknown #(`OVL_ERROR, 5, `OVL_ASSERT, "state variable must not be x")
    s_w_state_x (
              .clk       (dbgclk),
              .reset_n   (dbgresetn),
              .qualifier (1'b1),
              .test_expr (state)
              );

  //parity checker must be clear when header decode starts
  assert_never #(`OVL_ERROR, `OVL_ASSERT, "parity not reset for header")
    s_w_par_reset(
                 .clk        (dbgclk),
                 .reset_n    (dbgresetn),
                 .test_expr  (state == SWDP_SLEBANK & parity)
                 );

// ----------------------------------------------------------------------------
// Debug
// ----------------------------------------------------------------------------
  reg  [8*20:0] mnemonic; // Debug test for current state

  //Decode the state
  always @ (state)
    case (state)
      SWDP_SLERESET     : mnemonic = {"SLERESET"};
      SWDP_SLEIDLE      : mnemonic = {"IDLE"};
      SWDP_SLEBANK      : mnemonic = {"BANK"};
      SWDP_SLEDIR       : mnemonic = {"DIR"};
      SWDP_SLEADDR0     : mnemonic = {"ADDR0"};
      SWDP_SLEADDR1     : mnemonic = {"ADDR1"};
      SWDP_SLEPARITYH   : mnemonic = {"PARITYH"};
      SWDP_SLESTOPH     : mnemonic = {"STOPH"};
      SWDP_SLEPARKH     : mnemonic = {"PARKH"};
      SWDP_SLETRNH2     : mnemonic = {"TRNH2"};
      SWDP_SLETRNH1     : mnemonic = {"TRNH1"};
      SWDP_SLEACK0      : mnemonic = {"ACK0"};
      SWDP_SLEACK1      : mnemonic = {"ACK1"};
      SWDP_SLEACK2      : mnemonic = {"ACK2"};
      SWDP_SLEPARKW     : mnemonic = {"PARKW"};
      SWDP_SLETRNW3     : mnemonic = {"TRNW3"};
      SWDP_SLETRNW2     : mnemonic = {"TRNW2"};
      SWDP_SLETRNW1     : mnemonic = {"TRNW1"};
      SWDP_SLETRNW0     : mnemonic = {"TRNW0"};
      SWDP_SLERESW      : mnemonic = {"RESW"};
      SWDP_SLEDATAW     : mnemonic = {"DATAW"};
      SWDP_SLEPARITYW   : mnemonic = {"PARITYW"};
      SWDP_SLEMARKW     : mnemonic = {"MARKW"};
      SWDP_SLESTOPW     : mnemonic = {"STOPW"};
      SWDP_SLEDATAR     : mnemonic = {"DATAR"};
      SWDP_SLEPARITYR   : mnemonic = {"PARITYR"};
      SWDP_SLESTOPR     : mnemonic = {"STOPR"};
      SWDP_SLETRNC      : mnemonic = {"TRNC"};
      SWDP_SLERESC      : mnemonic = {"RESC"};
      SWDP_SLEERR       : mnemonic = {"ERR"};
      default       : mnemonic = {"UNKNOWN"};
    endcase

  reg [(8*20)-1:0]  decode_header; // Debug text for header decode

 // Decode the header.
  always @(posedge dbgclk or negedge dbgresetn)
    if (~dbgresetn)
      decode_header <= {"reset"};
    else
      begin
        if (state == SWDP_SLEACK0)
          begin
            if(err_chk)
              decode_header <= {"ERROR"};
            else
              if (ser_bank==SWDP_DPREG)
                case ({ser_dir,ser_addr})
                  {SWDP_SERREAD,SWDP_IDCODE} :
                                       decode_header <= {"read ID"};
                  {SWDP_SERREAD,SWDP_STAT}   :
                                       decode_header <= {"read STATUS"};
                  {SWDP_SERREAD,SWDP_RESEND} :
                                       decode_header <= {"read resend"};
                  {SWDP_SERREAD,SWDP_RDBUFF} :
                                       decode_header <= {"read rdbuff"};
                  {SWDP_SERWRITE,SWDP_ABORT} :
                                       decode_header <= {"write abort"};
                  {SWDP_SERWRITE,SWDP_CTRL } :
                                       decode_header <= {"write control"};
                  {SWDP_SERWRITE,SWDP_ADDR } :
                                       decode_header <= {"write ADDR"};
                  {SWDP_SERWRITE,SWDP_TARGETSEL} :
                                       decode_header <= {"write targetsel"};
                  default: decode_header <= {"write undefined"};
                endcase // case({ser_dir,ser_addr})
              else
                begin
                  if (ser_dir==SWDP_SERREAD)
                    begin
                      decode_header <= {"AP read xxxxx"};
                      decode_header[7:0] <= 8'd48+ser_addr;
                    end
                  else
                    begin
                      decode_header <= {"AP write xxxxx"};
                      decode_header[7:0] <= 8'd48+ser_addr;
                    end
                  case ({ap_bank_sel,ser_addr})
                    6'b000000 : decode_header[39:0] <= " csw";
                    6'b000001 : decode_header[39:0] <= " TAR";
                    6'b000010 : decode_header[39:0] <= " xxx";
                    6'b000011 : decode_header[39:0] <= " drw";

                    6'b000100 : decode_header[39:0] <= " BD0";
                    6'b000101 : decode_header[39:0] <= " BD1";
                    6'b000110 : decode_header[39:0] <= " BD2";
                    6'b000111 : decode_header[39:0] <= " BD3";

                    6'b111100 : decode_header[39:0] <= "aaaa";
                    6'b111101 : decode_header[39:0] <= " cfg";
                    6'b111110 : decode_header[39:0] <= "base";
                    6'b111111 : decode_header[39:0] <= " IDR";
                    endcase // case({ap_bank_sel,ser_addr})

                  decode_header[47:40] <= 8'd32;

                end
          end // if (state == SWDP_SLEACK0)
      end // else: !if(~dbgresetn)



assert_window #(`OVL_ERROR, `OVL_ASSERT, "targetsel write must be followed by a protocol error response")
  target_sel_proto_error (
                       .clk       (dbgclk),
                       .reset_n   (dbgresetn),
                       .start_event (state==SWDP_SLEPARITYH &
                                     ser_bank==SWDP_DPREG &
                                     ser_dir==SWDP_SERWRITE &
                                     ser_addr==SWDP_TARGETSEL),
                       .test_expr (!dbg_do_en_int),
                       .end_event (state==SWDP_SLEBANK)
                       );

`endif  // `ifdef ARM_ASSERT_ON

`ifdef ARM_CDC_ON
  cdc_connect #(3,0) u_cdc_masklane(
                                   .clk_launch(dbgclk),
                                   .clk_capture(cxdapswjdp.u_cxdapswjdp_dapclk.u_cxdapswjdp_sw_dp_apb_if.dapclk),
                                   .d_in(mask_lane_cdc_check),
                                   .d_out_async(mask_lane)
                                   );
`else
  assign mask_lane = mask_lane_cdc_check;
`endif
`ifdef ARM_CDC_ON
  cdc_connect #(1,0) u_cdc_trnfermode(
                                     .clk_launch(dbgclk),
                                     .clk_capture(cxdapswjdp.u_cxdapswjdp_dapclk.u_cxdapswjdp_sw_dp_apb_if.dapclk),
                                     .d_in(trnfermode_cdc_check),
                                     .d_out_async(trnfer_mode)
                                     );
`else
  assign trnfer_mode = trnfermode_cdc_check;
`endif
`ifdef ARM_CDC_ON
  cdc_connect #(31,0) u_cdc_ibuswdata(
                                     .clk_launch(dbgclk),
                                     .clk_capture(cxdapswjdp.u_cxdapswjdp_dapclk.u_cxdapswjdp_sw_dp_apb_if.dapclk),
                                     .d_in(ibuswdata_cdc_check),
                                     .d_out_async(i_bus_wdata)
                                     );
`else
  assign i_bus_wdata = ibuswdata_cdc_check;
`endif
`ifdef ARM_CDC_ON
  cdc_connect u_cdc_apdir(
                         .clk_launch(dbgclk),
                         .clk_capture(cxdapswjdp.u_cxdapswjdp_dapclk.u_cxdapswjdp_sw_dp_apb_if.dapclk),
                         .d_in(ap_dir_cdc_check),
                         .d_out_async(ap_dir)
                         );
`else
  assign ap_dir = ap_dir_cdc_check;
`endif
`ifdef ARM_CDC_ON
  cdc_connect #(11,0) u_cdc_trnfercnt(
                                     .clk_launch(dbgclk),
                                     .clk_capture(cxdapswjdp.u_cxdapswjdp_dapclk.u_cxdapswjdp_sw_dp_apb_if.dapclk),
                                     .d_in(trnfercnt_cdc_check),
                                     .d_out_async(trnfer_cnt)
                                     );
`else
  assign trnfer_cnt = trnfercnt_cdc_check;
`endif
endmodule
