
//--========================================================================
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2011-2015 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//  Version and Release Control Information:
//
//  File Name           : cxdapaxiapfsm_xmlcfg.v.xsl
//
//  Checked In          : $Date: 2015-02-16 14:55:41 +0000 (Mon, 16 Feb 2015) $
//
//  File Revision       : $Revision: 41661 $
//
//  Release Information : CoreSight-SoC-TM100-r3p2-00rel0
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// Abstract : CoreSight AXIAP - Top Level FSM
//-----------------------------------------------------------------------------
//
// cxdapaxiap - CoreSight AXIAP - Top Level FSM
// --------------------------------------------
//
//-----------------------------------------------------------------------------

module cxdapaxiapfsm_1 (

  // Clock and Reset
  input wire            clk,
  input wire            resetn,

  // Reg block interface
  input wire            sprot,
  input wire            bar_req,
  input wire            drw_wr_req,
  input wire            bd_wr_req,
  input wire            drw_rd_req,
  input wire            bd_rd_req,

  // AXI Master interface
  input wire            bar_resp,
  input wire            bar_awready,
  input wire            mst_wready,
  input wire            wr_resp,
  input wire            bar_arready,
  input wire            rd_resp,
  input wire            axi_err_resp,
  input wire            pck_tr_done,

  // Authentication interface
  input wire            spiden_rg,
  input wire            dbgen_rg,

  // FSM state
  output wire           fsm_state_en,
  output wire [2:0]     fsm_state_next,
  output wire [2:0]     fsm_state

  );

`include "cxdapaxiap_constants.v"

//============================================================================
// Wires
//============================================================================
  wire      fsm_state_int_en;

//============================================================================
// Registers
//============================================================================
  reg [2:0] fsm_state_int_next;
  reg [2:0] fsm_state_int;

//============================================================================
//
// Main body of code
//
//============================================================================

  always @ (*)
    begin
      case (fsm_state_int)
        RDY :
          if ((dbgen_rg && (sprot || spiden_rg))) begin
            if (bar_req) begin
              fsm_state_int_next = BRR;
            end else if (drw_rd_req || (bd_rd_req)) begin
              fsm_state_int_next = RD_CMD;
            end else if (drw_wr_req || (bd_wr_req)) begin
              fsm_state_int_next = WR_CMD;
            end else begin
              fsm_state_int_next = RDY;
            end
          end else begin
            fsm_state_int_next = RDY;
          end
        BRR :
          if (!bar_awready || !bar_arready) begin
            fsm_state_int_next = BRR;
          end else begin
            fsm_state_int_next = BRR_RESP;
          end
        BRR_RESP :
          if (bar_resp) begin
            fsm_state_int_next = RDY;
          end else begin
            fsm_state_int_next = fsm_state_int;
          end
        WR_CMD :
          if (bar_awready) begin
            fsm_state_int_next = WR_DT;
          end else begin
            fsm_state_int_next = fsm_state_int;
          end
        WR_DT :
          if (mst_wready) begin
            fsm_state_int_next = WRITE_RESP;
          end else begin
            fsm_state_int_next = fsm_state_int;
          end
        WRITE_RESP :
          if (wr_resp && !axi_err_resp && !pck_tr_done) begin
            fsm_state_int_next = WR_CMD;
          end else if (wr_resp && (pck_tr_done || axi_err_resp)) begin
            fsm_state_int_next = RDY;
          end else begin
            fsm_state_int_next = fsm_state_int;
          end
        RD_CMD :
          if (bar_arready) begin
            fsm_state_int_next = READ_RESP;
          end else begin
            fsm_state_int_next = fsm_state_int;
          end
        READ_RESP :
          if (rd_resp && !axi_err_resp && !pck_tr_done) begin
            fsm_state_int_next = RD_CMD;
          end else if (rd_resp && (pck_tr_done || axi_err_resp)) begin
            fsm_state_int_next = RDY;
          end else begin
            fsm_state_int_next = fsm_state_int;
          end
        default : fsm_state_int_next = {3{1'bx}};
      endcase
    end

    assign fsm_state_int_en = (fsm_state_int != fsm_state_int_next);

    always @ (posedge clk or negedge resetn)
      begin
        if (!resetn) begin
          fsm_state_int <= RDY;
        end else if (fsm_state_int_en) begin
          fsm_state_int <= fsm_state_int_next;
        end
      end

    assign fsm_state_next = fsm_state_int_next;

    assign fsm_state_en   = fsm_state_int_en;

    assign fsm_state      = fsm_state_int;

//----------------------------------------------------------------------------
// ASSERTIONS
//----------------------------------------------------------------------------

`ifdef ARM_ASSERT_ON

//-----------------------------------------------------------------------------
// Check if the fsm enters illegal state
// If it enters default, generate an error message
//-----------------------------------------------------------------------------
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxdapaxiap - Top-Level FSM has entered an illegal state")
      uzovl_cxdapaxiap_illegal_state_chk
        (
         .clk         (clk),
         .reset_n     (resetn),
         .test_expr   ((fsm_state_int != `RDY) &&
                       (fsm_state_int != BRR) &&
                       (fsm_state_int != BRR_RESP) &&
                       (fsm_state_int != WR_CMD) &&
                       (fsm_state_int != WR_DT) &&
                       (fsm_state_int != WRITE_RESP) &&
                       (fsm_state_int != RD_CMD) &&
                       (fsm_state_int != READ_RESP))
        );

//-----------------------------------------------------------------------------
// Check if the fsm enters illegal state transition
// Following state transitions are legal
//
// RDY       - BRR
// RDY       - WR_CMD
// RDY       - RD_CMD
//
//-----------------------------------------------------------------------------
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxdapaxiap - FSM has made an illegal state transition from RDY")
      uzovl_cxdapaxiap_illegal_state_tran_RDY_chk
        (
         .clk         (clk),
         .reset_n     (resetn),
         .test_expr   ((fsm_state_int_en) &&
                       (fsm_state_int == RDY) &&
                       (fsm_state_int_next != BRR) &&
                       (fsm_state_int_next != WR_CMD) &&
                       (fsm_state_int_next != RD_CMD))
        );

//-----------------------------------------------------------------------------
// Check if the fsm enters illegal state transition
// Following state transitions are legal
// BRR       - BRR_RESP
//
//-----------------------------------------------------------------------------
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxdapaxiap - FSM has made an illegal state transition from BRR")
      uzovl_cxdapaxiap_illegal_state_tran_BRR_chk
        (
         .clk         (clk),
         .reset_n     (resetn),
         .test_expr   ((fsm_state_int_en) &&
                       (fsm_state_int == BRR) &&
                       (fsm_state_int_next != BRR_RESP))
        );

//-----------------------------------------------------------------------------
// Check if the fsm makes an illegal state transition
// Following state transitions are legal
// BRR_RESP  - RDY
//
//-----------------------------------------------------------------------------
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxdapaxiap - FSM has made an illegal state transition from BRR_RESP")
      uzovl_cxdapaxiap_illegal_state_tran_BRR_RESP_chk
        (
         .clk         (clk),
         .reset_n     (resetn),
         .test_expr   ((fsm_state_int_en) &&
                       (fsm_state_int == BRR_RESP) &&
                       (fsm_state_int_next != RDY))
        );

//-----------------------------------------------------------------------------
// Check if the fsm makes an illegal state transition
// Following state transitions are legal
// WR_CMD    - WR_DT
//
//-----------------------------------------------------------------------------
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxdapaxiap - FSM has made an illegal state transition from WR_CMD")
      uzovl_cxdapaxiap_illegal_state_tran_WR_CMD_chk
        (
         .clk         (clk),
         .reset_n     (resetn),
         .test_expr   ((fsm_state_int_en) &&
                       (fsm_state_int == WR_CMD) &&
                       (fsm_state_int_next != WR_DT))
        );

//-----------------------------------------------------------------------------
// Check if the fsm makes an illegal state transition
// Following state transitions are legal
// WR_DT     - WRITE_RESP
//
//-----------------------------------------------------------------------------
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxdapaxiap - FSM has made an illegal state transition from WR_DT")
      uzovl_cxdapaxiap_illegal_state_tran_WR_DT_chk
        (
         .clk         (clk),
         .reset_n     (resetn),
         .test_expr   ((fsm_state_int_en) &&
                       (fsm_state_int == WR_DT) &&
                       (fsm_state_int_next != WRITE_RESP))
        );

//-----------------------------------------------------------------------------
// Check if the fsm makes an illegal state transition
// Following state transitions are legal
// WRITE_RESP   - RDY
// WRITE_RESP   - WR_CMD
//
//-----------------------------------------------------------------------------
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxdapaxiap - FSM has made an illegal state transition from WRITE_RESP")
      uzovl_cxdapaxiap_illegal_state_tran_WRITE_RESP_chk
        (
         .clk         (clk),
         .reset_n     (resetn),
         .test_expr   ((fsm_state_int_en) &&
                       (fsm_state_int == WRITE_RESP) &&
                       (fsm_state_int_next != RDY) &&
                       (fsm_state_int_next != WR_CMD))
        );

//-----------------------------------------------------------------------------
// Check if the fsm makes an illegal state transition
// Following state transitions are legal
// RD_CMD    - READ_RESP
//
//-----------------------------------------------------------------------------
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxdapaxiap - FSM has made an illegal state transition from RD_CMD")
      uzovl_cxdapaxiap_illegal_state_tran_RD_CMD_chk
        (
         .clk         (clk),
         .reset_n     (resetn),
         .test_expr   ((fsm_state_int_en) &&
                       (fsm_state_int == RD_CMD) &&
                       (fsm_state_int_next != READ_RESP))
        );

//-----------------------------------------------------------------------------
// Check if the fsm makes an illegal state transition
// Following state transitions are legal
// READ_RESP - RD_CMD
// READ_RESP - RDY
//-----------------------------------------------------------------------------
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxdapaxiap - FSM has made an illegal state transition from READ_RESP")
      uzovl_cxdapaxiap_illegal_state_tran_READ_RESP_chk
        (
         .clk         (clk),
         .reset_n     (resetn),
         .test_expr   ((fsm_state_int_en) &&
                       (fsm_state_int == READ_RESP) &&
                       (fsm_state_int_next != RDY) &&
                       (fsm_state_int_next != RD_CMD))
        );

`endif // ARM_ASSERT_ON

endmodule
