//-----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2009-2010 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//    Checked In   :  2010-06-16 11:32:45 +0100 (Wed, 16 Jun 2010) 
//    Revision     :  8170 
//    Release      : TM961-BU-50000-r0p1-00rel0
//
//-----------------------------------------------------------------------------
// Purpose : CoreSight Trace Memory Controller (CXTMC) - Formatter Control
//-----------------------------------------------------------------------------
//
// CXTMC - CoreSight Trace Memory Controller
// -----------------------------------------
// 
// CoreSight AMBA Trace Bus (ATB) sink/link device to store trace data in
// dedicated on chip Trace RAM or System RAM of configurable size.
//
// cxtmc_format_control.v
// ----------------------
//
// cxtmc_format_control.v provides the control logic for the CXTMC formatter
// module. This module is responsible for generating the Trigger and Stop
// request for the Formatter.
// The AFVALIDS generation is also carried out in this block.
//
// Instantiated blocks
// -------------------
//
// None
//  
//-----------------------------------------------------------------------------

module cxtmc_format_control
  #(parameter CXTMC_TRG_WIDTH  = 32,
    parameter CXTMC_ATBM_AXIM_CFG  = 1,
    parameter CXTMC_ATB_DATA_WIDTH  = 32)
  (
  // Inputs
  input wire       cxtmc_clk,          // Clock
  input wire       RESETn,             // Reset for the clock domain
  input wire       [31:0] apb_wdata,   // APB write data bus
  input wire       AFREADYS,           // Data flush compelete indication
  input wire       TRIGIN,             // Trigger input from event interface
  input wire       FLUSHIN,            // Flush input from event interface
  input wire       ctl_trace_capt_en,  // Trace capture enable register
                                       // to accept ATB data
  input wire       circ_buf_mode,      // Trace capture enable register
  input wire       ffcr_stop_on_trig_evt_masked,
                                       // FFCR StopOnTrigEvt bit masked for
                                       // error conditions
  input wire       ffcr_stop_on_fl,    // FFCR StopOnFl bit
  input wire       ffcr_trig_on_fl_masked,
                                       // FFCR TrigOnFl bit masked for error
                                       // conditions
  input wire       ffcr_trig_on_trig_evt_masked,
                                       // FFCR TrigOnTrigEvt bit masked for
                                       // error conditions
  input wire       ffcr_trig_on_trigin_masked,
                                       // FFCR TrigOnTrigIn bit masked for
                                       // error conditions
  input wire       ffcr_flsh_on_trig_evt_masked,
                                       // FFCR FOnTrigEvt bit masked for error
                                       // conditions
  input wire       ffcr_flsh_on_flshin,
                                       // FFCR FOnFlIn bit
  input wire       ffcr_flush_man,     // FFCR FOnMan register
  input wire       ffcr_en_trig_ins,
                                       // FFCR EnTI bit masked for error
                                       // conditions
  input wire       trg_ctr_decr_pulse, // Trigger decrement pulse
  input wire       ft_stopped,         // Formatter stopped
  input wire       ft_trig_ack,        // Trigger acknowledgement from formatter
  input wire       trig_id_detect,     // trigger ID detected in input trace
  input wire       trg_wr_en,          // Trigger counter write enable from APB
  input wire       it_ctrl,            // Integration Mode Control  
  input wire       it_atb_ctr_2_wr_en, // Write enable for ITATBCTR2 register 
  input wire       ft_flush_ack,       // Formatter flush Acknowledge
  input wire       wb_flush_ack,       // Write buffer flush Acknowledge
  input wire       mem_flush_ack,      // Memory flush Acknowledge
  input wire       sw_fifo_mode,       // Software FIFO mode
  input wire       hw_fifo_mode,       // Hardware FIFO mode
  input wire       atbm_flush_valid,   // Indication that the flush was sampled
                                       // by ATB master
  input wire       mem_err,            // Memory error has occured
  input wire       trace_mem_empty,    // Trace memory is empty

  // Outputs
  output reg       AFVALIDS,           // Flush request for upstream
  output reg       af_ready_reg,       // Registered version of AFREADYS
  output reg       trigin_reg,         // Registered version of TRIGIN 
  output reg       flushin_reg,        // Registered version of FLUSHIN
  output reg       triggered,          // Trigger event has occurred
  output wire [(CXTMC_TRG_WIDTH-1):0] trg,
                                       // Trigger counter register
  output reg       flush_man_clr,      // Clear FOnMan bit in FFCR
  output reg       ft_trig_req,        // Trigger request
  output reg       ft_stop_req,        // Stop request
  output reg       ft_flush_req,       // Formatter flush request
  output reg       wb_flush_req,       // Write buffer flush request
  output reg       mem_flush_req,      // Memory flush request
  output reg       atbm_flush_ready,   // Indication that Unformatter
                                       // can flush its internal contents
  output wire      ctl_trace_capt_en_0_1,
                                       // Indication that 0->1 transition on
                                       // ctl_trace_capt_en is sensed
  output wire      fl_in_prog          // Indication that flush in
                                       // progress because of link
  );

  //---------------------------------------------------------------------------
  // Constants definitions
  //---------------------------------------------------------------------------
  `include "cxtmc_constants.v"

  localparam TRG_WIDTH =
    (CXTMC_ATB_DATA_WIDTH == 32) ? CXTMC_TRG_WIDTH :
       (CXTMC_ATB_DATA_WIDTH == 64) ? CXTMC_TRG_WIDTH - 1 :
                                         CXTMC_TRG_WIDTH - 2;

  //---------------------------------------------------------------------------
  // Flush FSM state declarations
  //---------------------------------------------------------------------------
  localparam FLUSH_IDLE                     = 3'b000;
  localparam EXTERNAL_FLUSH                 = 3'b001;
  localparam TRIG_IN_PROGRESS               = 3'b010;
  localparam FORMATTER_FLUSH                = 3'b011;
  localparam WBUFFER_FLUSH                  = 3'b100;
  localparam MEM_FLUSH                      = 3'b101;
  localparam FLUSH_UNKNOWN                  = 3'bxxx;


  //---------------------------------------------------------------------------
  // Reg declarations
  //---------------------------------------------------------------------------

  reg       trg_evt_active;        // Trigger event is active
  reg       flush_pend;            // Register to hold the pending flush info
  reg       f_on_man_reg;          // Manual flush register
  reg       f_on_man_actv;         // Manual flush is active
  reg       f_on_man_pend;         // Manual flush is pended
  reg       st_on_trig_active_reg; // Registered stop on trigger active
  reg       st_on_fl_active_reg;   // Registered stop on FLUSHIN active
  reg       st_tc_en_pend;         // Stop on trace capture enable pending
  reg       st_trig_pend;          // Stop of trigger event pending
  reg       st_fl_pend;            // Stop of FLUSHIN pending
  reg       trigin_reg1;           // Registered trigin_reg for edge detection
  reg       flushin_reg1;          // Registered FLUSHIN port for edge detection
  reg       ctl_trace_capt_en_reg; // Registered ctl_trace_capt_en to
                                   // detect 0->1
                                   // transition
  reg       ft_stop_req_reg;       // Registered stop request
  reg       f_on_atbm_pend;        // Indication that ATBM flush is pended
  reg       f_on_atbm_actv;        // Indication that ATBM flush is active
  reg [2:0] nxt_flush_state;       // D-Input of ATB Master FSM
  reg [2:0] flush_state;           // State vector for ATB Master FSM
  reg       nxt_ft_flush_req;      // D-Input of ft_flush_req
  reg       nxt_wb_flush_req;      // D-Input of wb_flush_req
  reg       nxt_mem_flush_req;     // D-Input of mem_flush_req
  reg       nxt_atbm_flush_ready;  // D-Input of atbm_flush_ready
  reg       ft_trig_pend;          // Indication that Trigger is pended
                                   // because of internal flush
  reg       flush_fsm_busy_del;
                                   // Delayed version of flush_fsm_busy
  reg       f_on_fl_in_pend;       // Indication that FLUSHIN flush is pended
  reg       f_on_fl_in_actv;       // Indication that FLUSHIN flush is active
  reg       mem_err_reg;           // Delayed version of mem_err
  reg       atbm_flush_valid_del;  // Delayed version of atbm_flush_valid
  reg       afvalids_bef_integ;    // AFVALIDS signal before final integ mux
  reg       f_on_trig_pend;        // Indication that f_on_trig is pended
  reg       f_on_trig_actv;        // Indication that f_on_trig is active
  reg       nxt_flush_man_clr;     // D-Input of flush_man_clr
  reg       nxt_f_on_man_actv;     // D-Input of f_on_man_actv
  reg       nxt_f_on_man_pend;     // D-Input of f_on_man_pend
  reg       nxt_flush_pend;        // D - Input of flush_pend register
  reg       nxt_f_on_atbm_pend;    // D-Input of f_on_atbm_pend register
  reg       nxt_f_on_atbm_actv;    // D-Input of f_on_atbm_actv register
  reg       nxt_f_on_fl_in_pend;   // D-Input of f_on_fl_in_pend register
  reg       nxt_f_on_fl_in_actv;   // D-Input of f_on_fl_in_actv register
  reg       nxt_afvalids_bef_integ;// D-Input of afvalids_bef_integ
  reg       nxt_f_on_trig_pend;    // D-Input of f_on_trig_pend
  reg       nxt_f_on_trig_actv;    // D-Input of f_on_trig_actv

 
  //---------------------------------------------------------------------------
  // Wire declarations
  //---------------------------------------------------------------------------

  wire     trig_in_detect;        // Trigger detected on TRIGIN
  wire     trigger_event;         // Trigger event has occurred - Internal ver
  wire     trg_one;               // Trigger counter will change from 1 to 0
  wire     trg_zero;              // Trigger counter is at zero
  wire     trg_evt_det_or_actv;   // Indication that the new trigger is sampled
  wire     nxt_ft_trig_req;       // D - Input of Trigger request
  // Trigger detection
  wire     t_on_flush_detect;     // Trigger on flush detect
  wire     t_on_trig_evt_detect;  // Trigger on trigger event detect
  wire     t_on_trig_in_detect;   // Trigger on TRIGIN detect
  wire     nxt_trg_evt_active;    // D - Input of trg_evt_active register
  wire     nxt_afvalids;          // D - Input of AFVALIDS register
  // Flush detection and request
  wire     af_ready_qual;         // Indication of flush handshake on ATB
  wire     f_on_man_detect;       // Indication that Manual flush detected 
  wire     f_on_trig_detect;      // Indication that Flush on trigger detected
  wire     f_on_fl_in_detect;     // Indication that Flush on FLUSHIN detected  
  wire     f_on_atbm_detect;      // Pulse generation when ATBm flush is
                                  // detected
  // Stop detection
  wire     st_on_tc_en_detect;    // Indication that stop on trace capture
                                  // enable detected
  wire     st_on_trig_detect;     // Indication that stop on trigger event
                                  // detected
  wire     st_on_mem_err_detect;  // Indication that stop on memory error
                                  // detected
  wire     st_on_fl_detect;       // Indication that stop on FLUSIN detected
  // Stop active
  wire     st_on_tc_en_active;    // Indication that stop on trace capture
                                  // enable active
  wire     st_on_trig_active;     // Indication that stop on trigger event
                                  // active
  wire     st_on_fl_active;       // Indication that stop on FLUSIN active
  // Pending stop generation  
  wire     nxt_st_tc_en_pend;     // D - Input of st_tc_en_pend register
  wire     nxt_st_trig_pend;      // D - Input of st_trig_pend register
  wire     nxt_st_fl_pend;        // D - Input of st_fl_pend register
  wire [(CXTMC_TRG_WIDTH-1):0] nxt_trg;
                                  // D-Input of Trigger counter register
  wire     nxt_ft_stop_req;       // D-Input of ft_stop_req register
  wire     trg_dec_en;            // Enable to decrement trigger counter
                                  // register
  wire     trg_en;                // Enable for trigger counter register
  wire     sts_trig_reg_en;       // Status Triggered bit enable
  wire     nxt_sts_trig_reg;      // D - Input of triggered register 
  wire     stop_pending;          // Indication that the stop request is pended
  wire     nxt_stop_pending;      // D-input of all stop pending sources
  wire     flush_source;          // Indication that the flush is requested
                                  // from one of the four sources
  wire     flush_from_sink;       // Indication that the flush is requested
                                  // from one of the three sink sources
  wire     f_on_atbm_serv_in_prog;// Indication that the flush is active
                                  // because of AFVALIDM
  wire     nxt_ft_trig_pend;      // D-Input of ft_trig_pend register
  wire [(CXTMC_TRG_WIDTH-1):0] trg_decr_value;
                                  // Trigger counter decrement value
  wire     etr_config;            // Signal to indicate that the config is ETR
  wire     flush_from_sink_actv;  // Indication that the flush from sink
                                  // sources are sampled asserted
  wire     flush_fsm_busy;        // Indication that flush in progress 
  wire [TRG_WIDTH-1 :0] nxt_trg_int;
                                  // D-Input of Intermediate trigger counter
  reg [TRG_WIDTH-1 :0] trg_int;   // Intermediate trigger counter

  // --------------------------------------------------------------------------
  //
  //  Main body of code
  //  =================
  //
  // --------------------------------------------------------------------------


  // --------------------------------------------------------------------------
  // Indication of ATB Slave Flush handshake
  // --------------------------------------------------------------------------
  assign af_ready_qual = AFVALIDS & AFREADYS;
  
  // --------------------------------------------------------------------------
  // Trigger request generation
  // ~~~~~~~~~~~~~~~~~~~~~~~~~~
  // A trigger request to the ATB formatter can only be generated when
  // ft_stopped is LOW. The trigger request input will be held HIGH until a
  // ft_trig_ack is observed. Unlike flushes, trigger requests are not pended
  // if another is in progress. While a trigger is in progress, any further
  // requests to embed a trigger are ignored, as a trigger is already being
  // inserted into the trace stream.
  // --------------------------------------------------------------------------
  //
  // Trigger event generation
  //
  // a) Occurs when trigger counter @0 and prev @0 with TRIGIN rising or with
  //    trigger packet observed (ATIDS = 0x7D) on trace stream.
  // b) Occurs when trigger counter @0 and prev @1 
  //
  // --------------------------------------------------------------------------
  // trg_dec_en:
  // ~~~~~~~~~~~
  // Trigger counter is decremented when following conditions are satisfied.
  // a) (trig_in_detect | trg_evt_active | trig_id_detect) -> Implies that the
  //    trigger was observed on TRIGIN input or trigger packet was observed in
  //    upstream trace. If the counter decrementing is already in progress,
  //    decrementing is enabled until the counter down counts to zero.
  // b) ~trg_zero -> Implies that the counter should be non-zero for
  //    decrementing.
  // c) ~ft_stop_req -> Implies that the TMC is not disabled. When disabled,
  //    it does not make sense to decrement the counter.
  // d) trg_ctr_decr_pulse -> Implies the timing of decremnting the counter.
  //    Formatter drives this signal when it has full data corresponding to
  //    ATB_DATA_WIDTH ready.
  // --------------------------------------------------------------------------
  assign trg_evt_det_or_actv = trig_in_detect | trg_evt_active | trig_id_detect;

  assign trg_dec_en = trg_evt_det_or_actv &
                      ~trg_zero &
                      circ_buf_mode &
                      ~ft_stop_req & 
                      trg_ctr_decr_pulse;

  // --------------------------------------------------------------------------
  // trg_en:
  // ~~~~~~~~~~~
  // Trigger register is updated whenever there is a write from APB side or
  // when the counter needs to be decremented.
  // The counter is cleared when a stop sequence is initiated, as no more
  // further triggers will be inserted.
  // --------------------------------------------------------------------------
  assign trg_en = trg_wr_en |
                  trg_dec_en |
                  (~ft_stop_req_reg & ft_stop_req);

  assign nxt_trg =
        trg_wr_en ? {apb_wdata[(CXTMC_TRG_WIDTH-1):2], 2'b00} :
                     (!ft_stop_req_reg && ft_stop_req) ?
                      {(CXTMC_TRG_WIDTH){1'b0}} :
                      (trg - trg_decr_value);

  generate 
    if (CXTMC_ATB_DATA_WIDTH == 32)
      begin
        assign nxt_trg_int = nxt_trg;
        assign trg = trg_int;
      end
    else if (CXTMC_ATB_DATA_WIDTH == 64)
      begin
        assign nxt_trg_int = nxt_trg[CXTMC_TRG_WIDTH-1 : 1];
        assign trg = {trg_int, 1'b0};
      end
    else
      begin
        assign nxt_trg_int = nxt_trg[CXTMC_TRG_WIDTH-1 : 2];
        assign trg = {trg_int, 2'b0};
      end
  endgenerate

  // --------------------------------------------------------------------------
  // Clock process to implement Trigger counter register.
  // --------------------------------------------------------------------------
  always @(posedge cxtmc_clk or negedge RESETn)
    begin : p_trg_seq
      if (!RESETn)
        trg_int <= {TRG_WIDTH{1'b0}};
      else if (trg_en)
        trg_int <= nxt_trg_int;
    end // p_trg_seq

  // --------------------------------------------------------------------------
  // Realization of trg_decr_value based on ATB_DATA_WIDTH
  // --------------------------------------------------------------------------
  generate
    if (CXTMC_ATB_DATA_WIDTH == 32)
      begin
        assign trg_decr_value = {{(CXTMC_TRG_WIDTH-1){1'b0}}, 1'b1};
      end
    else if (CXTMC_ATB_DATA_WIDTH == 64)
      begin
        assign trg_decr_value = {{(CXTMC_TRG_WIDTH-2){1'b0}}, 2'b10};
      end
    else
      begin
        assign trg_decr_value = {{(CXTMC_TRG_WIDTH-3){1'b0}}, 3'b100};
      end
  endgenerate

  // --------------------------------------------------------------------------
  // trg_evt_active:
  // ~~~~~~~~~~~~~~~
  // trg_evt_active indicates that the trigger counter decrementing is in
  // progress. This flag is set until formatter has not disabled. 
  // --------------------------------------------------------------------------
  assign nxt_trg_evt_active = trg_evt_det_or_actv & ~ft_stopped;

  // --------------------------------------------------------------------------
  // Clock process to implement trg_evt_active register.
  // --------------------------------------------------------------------------
  always @(posedge cxtmc_clk or negedge RESETn)
    begin : p_trg_evt_active_seq
      if (!RESETn)
        trg_evt_active <= 1'b0;
      else
        trg_evt_active <= nxt_trg_evt_active;
    end // p_trg_evt_active_seq


  // --------------------------------------------------------------------------
  // Intermediate signal which indicates that the trigger counter value is zero.
  // --------------------------------------------------------------------------
  assign trg_zero = (trg == {CXTMC_TRG_WIDTH{1'b0}});


  // --------------------------------------------------------------------------
  // Intermediate signal which indicates that the trigger counter is down
  // counting from non-zero (1 in case of ATB_DATA_WIDTH = 32:
  // 2 in case of ATB_DATA_WIDTH = 64: 4 in case of ATB_DATA_WIDTH = 128) to
  // 0 in next cycle
  // --------------------------------------------------------------------------
  generate
    if (CXTMC_ATB_DATA_WIDTH == 32)
      begin
        assign trg_one = (trg == {{(CXTMC_TRG_WIDTH-1){1'b0}}, 1'b1}) &
                         trg_dec_en;
      end
    else if (CXTMC_ATB_DATA_WIDTH == 64)
      begin
        assign trg_one = (trg == {{(CXTMC_TRG_WIDTH-2){1'b0}}, 2'b10}) &
                         trg_dec_en;
      end
    else
      begin
        assign trg_one = (trg == {{(CXTMC_TRG_WIDTH-3){1'b0}}, 3'b100}) &
                         trg_dec_en;
      end
  endgenerate
   

  // --------------------------------------------------------------------------
  // To sense the 0->1 transition of TRIGIN input the signal is registered.
  // --------------------------------------------------------------------------
  always @(posedge cxtmc_clk or negedge RESETn)
    begin : p_trig_event_seq
      if (!RESETn)
        begin
          trigin_reg  <= 1'b0;
          trigin_reg1  <= 1'b0;
        end
      else
        begin
          trigin_reg  <= TRIGIN;
          trigin_reg1  <= trigin_reg;
        end
    end // p_trig_event_seq

  // --------------------------------------------------------------------------
  // Trigger edge detection from the TRIGIN port
  // --------------------------------------------------------------------------
  assign trig_in_detect = trigin_reg & ~trigin_reg1;

  // --------------------------------------------------------------------------
  // Indication that a trigger event has occurred.
  // trigger_event is asserted when either of following conditions are satisfied
  // a) Trigger counter at zero value and a trigger sampled
  // b) Trigger counter is in the process of downcounting to zero from non-zero
  //    value.
  // --------------------------------------------------------------------------
  assign trigger_event = (((trig_in_detect | trig_id_detect) & trg_zero ) |
                          trg_one) & 
                         ~ft_stop_req;

  // --------------------------------------------------------------------------
  // ffcr_trig_on_fl_masked = TrigFl. Generate a trigger when a flush completes.
  // When TrigFl bit is set a trigger will be generated, when a flush completes.
  // A flush complete is indicated when AFREADYS and AFVALIDS are sampled
  // asserted.
  // When the flush is because of ATB master initiated flush then the
  // trig_on_fl bit is ignored.
  // --------------------------------------------------------------------------
  assign t_on_flush_detect = ffcr_trig_on_fl_masked & af_ready_qual &
                             ~f_on_atbm_serv_in_prog;
  
  // --------------------------------------------------------------------------
  // ffcr_trig_on_trig_evt_masked = TrigEvt. Generate a trigger when a trigger
  // event occurs. When this bit is set a trigger will be generated on a
  // trigger event
  // --------------------------------------------------------------------------
  assign t_on_trig_evt_detect = ffcr_trig_on_trig_evt_masked & trigger_event; 
  
  // --------------------------------------------------------------------------
  // ffcr_trig_on_trigin_masked = TrigIn. Generate trigger when TRIGIN changes
  // from 0 to 1. If this bit is set a trigger will be generated on a TRIGIN
  // rising edge
  // --------------------------------------------------------------------------
  assign t_on_trig_in_detect = ffcr_trig_on_trigin_masked & trig_in_detect;
  
  // --------------------------------------------------------------------------
  // ft_trig_req :
  // ~~~~~~~~~~~~~
  // ft_trig_req can only be generated if ffcr_en_trig_ins is HIGH and
  // ft_stopped is LOW when the formatter is in continuous mode, as it does not
  // make sense to insert triggers when the formatter is disabled. Also the
  // trigger setting conditions must be true.
  // Once asserted the level should be sustained until ft_trig_ack is sampled
  // high.
  // --------------------------------------------------------------------------
  assign nxt_ft_trig_req = (~ft_stop_req &
                             ffcr_en_trig_ins & ~stop_pending &
                            // Ensures that when formatter flush in progress
                            // stop requesting for trigger insertion
                             ~(ft_flush_req & ~ft_flush_ack) &
                            (t_on_flush_detect |
                             t_on_trig_evt_detect |
                             t_on_trig_in_detect |
                            // If the trigger was pended because of ongoing
                            // flush then request for trigger once flush
                            // acknowledge is received.
                             (ft_trig_pend & ft_flush_ack))) |
                            (ft_trig_req & ~ft_trig_ack);
  
  
  // --------------------------------------------------------------------------
  // Clock process to realize ft_trig_req register
  // --------------------------------------------------------------------------
  always @(posedge cxtmc_clk or negedge RESETn)
    begin : p_trig_req_seq   
      if (!RESETn)
        begin
          ft_trig_req    <= 1'b0;
          ft_trig_pend   <= 1'b0;
        end
      else
        begin
          ft_trig_req    <= nxt_ft_trig_req;
          ft_trig_pend   <= nxt_ft_trig_pend;
        end
    end // p_trig_req_seq

  // --------------------------------------------------------------------------
  // Pend the trigger insertion if formatter flush is requested.
  // --------------------------------------------------------------------------
  assign nxt_ft_trig_pend = (ft_flush_req && !ft_flush_ack && !ft_trig_pend) ?
                              (t_on_flush_detect ||
                               t_on_trig_evt_detect ||
                               t_on_trig_in_detect) :
                               (ft_trig_pend && ft_flush_ack) ? 1'b0 :
                                 ft_trig_pend;

  // --------------------------------------------------------------------------
  // Triggered bit in status register:
  // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  // Triggered status bit should be set when there is a trigger condition as
  // indicated by trigger_event signal in circular buffer mode. The status
  // needs to be cleared when the formatter has stopped.
  // --------------------------------------------------------------------------
  assign sts_trig_reg_en  = (trigger_event | ctl_trace_capt_en_0_1);
  assign nxt_sts_trig_reg = sts_trig_reg_en ? (trigger_event &&
                                                circ_buf_mode &&
                                                !ft_stop_req) : triggered;

  // --------------------------------------------------------------------------
  // Clock process to realize triggered bit.
  // --------------------------------------------------------------------------
  always @(posedge cxtmc_clk or negedge RESETn)
    begin : p_trig_sts_seq
      if (!RESETn)
        triggered <= 1'b0;
      else
        triggered <= nxt_sts_trig_reg;
    end // p_trig_sts_seq
 
  // --------------------------------------------------------------------------
  // Formatter flush request generation:
  // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  // Flush can be requested on following scenarios,
  // a) Manually generated flush by writing to FOnMan bit in FFCR register.
  // b) Request for Flush when trigger event is detected. This can be achieved
  //    by writing to FOnTrig bit in FFCR register.
  // c) Flush request from FLUSHIN input.
  // The flush can be requested by all the sources at the same time.
  // In this scenario, if there is an ongoing flush indicated by flush in
  // progress (bit in STS register), then the flush request will be pended
  // until the current ongoing transfer completes.
  // --------------------------------------------------------------------------
    
  // --------------------------------------------------------------------------
  // ffcr_flush_man = FOnMan. Manually generate a flush of the system. 
  // When this bit is set a flush will be generated. This bit is cleared when
  // the flush has been serviced (AFREADYS is sampled asserted).
  // --------------------------------------------------------------------------
  assign f_on_man_detect = ffcr_flush_man & ~f_on_man_reg & ~ft_stop_req;
  
  // --------------------------------------------------------------------------
  // Clock process to realize f_on_man_reg
  // --------------------------------------------------------------------------
  always @(posedge cxtmc_clk or negedge RESETn)
    begin : p_flush_on_man_seq   
      if (!RESETn)
        begin
          f_on_man_reg   <= 1'b0;
        end
      else
        begin
          f_on_man_reg   <= ffcr_flush_man;
        end
    end // p_flush_on_man_seq
  
  // --------------------------------------------------------------------------
  // ffcr_flsh_on_trig_evt_masked = FOnTrig. Generate flush via a trigger event.
  // When this bit is set a flush will be generated when a trigger event occurs
  // Cannot be initiated when ft_stop_req is sampled asserted.
  // --------------------------------------------------------------------------
  assign f_on_trig_detect = ffcr_flsh_on_trig_evt_masked &
                            trigger_event &
                            // When abrupt stop is sampled, then the flush
                            // need not be initiated.
                            ~ffcr_stop_on_trig_evt_masked &
                            // Flush on trigger event is valid only when
                            // circular buffer mode is programmed. 
                            circ_buf_mode &
                            ~ft_stop_req;
  
  // --------------------------------------------------------------------------
  // ffcr_flsh_on_flshin = FlOnFlIn. Generate a flush via the FLUSHIN interface.
  // When this bit is set the FLUSHIN interface is used. 
  // Cannot be initiated when ft_stop_req is sampled asserted.
  // --------------------------------------------------------------------------
  assign f_on_fl_in_detect = ffcr_flsh_on_flshin &
                             (flushin_reg & ~flushin_reg1) &
                             ~ft_stop_req;

  // --------------------------------------------------------------------------
  // ATB master flush request is killed if the stop is already in progress,
  // otherwise it is considered as one more source of flush.
  // --------------------------------------------------------------------------
  assign f_on_atbm_detect = atbm_flush_valid & ~atbm_flush_valid_del &
                            ~ft_stop_req;

  // --------------------------------------------------------------------------
  // Clock process to register FLUSHIN signal. Also to register flushin_reg
  // for 0->1 edge detection.
  // --------------------------------------------------------------------------
  always @(posedge cxtmc_clk or negedge RESETn)
    begin : p_flushin_seq   
      if (!RESETn)
        begin
          flushin_reg  <= 1'b0;
          flushin_reg1 <= 1'b0;
        end
      else
        begin 
          flushin_reg  <= FLUSHIN;
          flushin_reg1 <= flushin_reg;
        end
    end // p_flushin_seq

  
  // --------------------------------------------------------------------------
  // Flush pending:
  // ~~~~~~~~~~~~~~
  // Flush is pended when there is an ongoing flush.
  // When the ongoing flush is completed the pending flush needs to be reissued.
  //
  // Flush is pended until it is issued on the ATB bus.
  // (flush_source & AFVALIDS) -> Ensures that if there is an ongoing flush
  // then pend the flush.
  // (af_ready_qual & flush_pend) -> Ensures that when the ongoing flush is
  // complete reissue the pending flush.
  // ft_stop_req -> Ensures that the pending flush is cleared once stop request
  // is asserted.
  // --------------------------------------------------------------------------
  assign flush_source = f_on_man_detect | f_on_trig_detect |
                        f_on_fl_in_detect | f_on_atbm_detect;

  assign flush_from_sink = f_on_man_detect | f_on_trig_detect |
                           f_on_fl_in_detect;

  assign flush_from_sink_actv = f_on_man_actv | f_on_trig_actv |
                           f_on_fl_in_actv;

  // --------------------------------------------------------------------------
  // Indication that the Config is ETR
  // --------------------------------------------------------------------------
  generate
    if (CXTMC_ATBM_AXIM_CFG != CXTMC_CFG_ETR)
      begin
        assign etr_config = 1'b0;
      end
    else
      begin
        assign etr_config = 1'b1;
      end
  endgenerate

  // --------------------------------------------------------------------------
  // Indication that flush FSM has moved out of FLUSH_IDLE state.
  // --------------------------------------------------------------------------
  assign flush_fsm_busy = (flush_state != FLUSH_IDLE);

  // --------------------------------------------------------------------------
  // When ATB master alone flush is in progress, the design should be
  // insensitive to TrigOnFl and StopOnFl bit settings.
  // --------------------------------------------------------------------------
  assign f_on_atbm_serv_in_prog =
     (af_ready_qual & f_on_atbm_actv &
      ~((f_on_man_actv |f_on_fl_in_actv) &
        (ffcr_stop_on_fl | ffcr_trig_on_fl_masked)));
                                    

  // --------------------------------------------------------------------------
  // Combinatorial process to realize the FSM for ATB Master related flushing.
  // --------------------------------------------------------------------------
  // When Unformatter module samples AFVALIDM, then following steps needs to be
  // completed before asserting AFREADYM.
  // Step 1: Unformatter asserts atbm_flush_valid indicating that the AFVALIDM
  //         sampled on ATB Master interface.
  // Step 2: FSM will issue the flush request to the pstream ATB master by
  //         asserting AFVALIDS on bus.
  // Step 3: FSM will wait for flush handshake on ATB slave bus before
  //         de-asserting AFVALIDS signal.
  // Step 3a: FSM will wait for any new trigger request or an ongoing trigger
  //          insertion to be completed before requesting for Formatter flush.
  // Step 4: FSM will request for formatter block to flush its fifo by asserting
  //         ft_flush_req signal.
  // Step 5: Formatter will acknowledge by asserting ft_flush_ack signal
  //         indicating that it has flushed its internal fifo.
  // Step 6: FSM will request for write buffer to flush its fifo by asserting
  //         wb_flush_req signal.
  // Step 7: Write buffer will acknowledge by asserting wb_flush_ack signal
  //         indicating that it has flushed its internal fifo.
  // Step 8: FSM will request for Memory content to be flushed by asserting,
  //         mem_flush_req signal.
  // Step 9: memory will store the write pointer and compares it against the
  //         current read pointer, if they are not equal then it will wait for
  //         the read pointer to catch up with latched write pointer before
  //         asserting mem_flush_ack signal. When write
  //         pointer is equal to the read pointer then the fifo empty flag is
  //         compared to ensure that the local fifo is either full or empty
  //         to assert mem_flush_ack. When full the FSM will wait for the
  //         read pointer to roll over before asserting mem_flush_ack.
  // Step 10: Once mem_flush_ack is sampled FSM will assert atbm_flush_ready to
  //          unformatter block to drain its fifo contents so as to assert
  //          AFREADYM.


  always @*
    begin : p_flush_control_comb
      nxt_flush_state          = flush_state;         // Default Assignment
      nxt_afvalids_bef_integ   = afvalids_bef_integ;  // Default Assignment
      nxt_f_on_man_pend        = f_on_man_pend;       // Default Assignment
      nxt_f_on_man_actv        = f_on_man_actv;       // Default Assignment
      nxt_f_on_fl_in_pend      = f_on_fl_in_pend;     // Default Assignment
      nxt_f_on_fl_in_actv      = f_on_fl_in_actv;     // Default Assignment
      nxt_f_on_atbm_pend       = f_on_atbm_pend;      // Default Assignment
      nxt_f_on_atbm_actv       = f_on_atbm_actv;      // Default Assignment
      nxt_f_on_trig_pend       = f_on_trig_pend;      // Default Assignment
      nxt_f_on_trig_actv       = f_on_trig_actv;      // Default Assignment
      nxt_flush_pend           = flush_pend;          // Default Assignment
      nxt_flush_man_clr        = ft_stop_req;         // Default Assignment
      nxt_ft_flush_req         = ft_flush_req;        // Default Assignment
      nxt_mem_flush_req        = mem_flush_req;       // Default Assignment
      nxt_wb_flush_req         = wb_flush_req;        // Default Assignment
      nxt_atbm_flush_ready     = atbm_flush_valid &
                                  ft_stop_req &
                                  ft_stopped &
                                  trace_mem_empty &
                                  ~atbm_flush_ready;   // Default Assignment

      case (flush_state)
        FLUSH_IDLE :
          begin
            // Reset all the pend registers
            nxt_flush_pend             = 1'b0;
            nxt_f_on_fl_in_pend        = 1'b0;
            nxt_f_on_atbm_pend         = 1'b0;
            nxt_f_on_trig_pend         = 1'b0;
            nxt_f_on_man_pend          = 1'b0;

            // If flush source is detected and TMC has not stopped abruptly,
            // or not in the process of stopping, initiate external flush
            if ((flush_source || flush_pend) &&
                ctl_trace_capt_en &&
                !nxt_ft_stop_req &&
                !nxt_stop_pending)
              begin
                nxt_flush_state        = EXTERNAL_FLUSH;
                nxt_afvalids_bef_integ = 1'b1;

                // Activate all the flush sources if detected.
                nxt_f_on_man_actv   = f_on_man_detect | f_on_man_pend;
                nxt_f_on_fl_in_actv = (~flush_pend & f_on_fl_in_detect) |
                                       f_on_fl_in_pend;
                nxt_f_on_trig_actv  = (~flush_pend & f_on_trig_detect) |
                                       f_on_trig_pend;
                nxt_f_on_atbm_actv  = f_on_atbm_detect | f_on_atbm_pend;

              end
          end

        EXTERNAL_FLUSH :
          begin
            // Store all the new flush sources in pend register
            nxt_flush_pend      = (~flush_pend & flush_source) | flush_pend;
            nxt_f_on_man_pend   = (~f_on_man_pend & f_on_man_detect) |
                                   f_on_man_pend;
            nxt_f_on_fl_in_pend = (~f_on_fl_in_pend & f_on_fl_in_detect) |
                                   f_on_fl_in_pend;
            nxt_f_on_trig_pend  = (~f_on_trig_pend & f_on_trig_detect) |
                                   f_on_trig_pend;
            nxt_f_on_atbm_pend  = (~f_on_atbm_pend & f_on_atbm_detect) |
                                   f_on_atbm_pend;

            if (AFREADYS)
              begin
                nxt_afvalids_bef_integ = 1'b0;
                nxt_flush_man_clr      = f_on_man_actv & hw_fifo_mode;

                // Only external flush is sufficient in circular buffer mode.
                // In hardware fifo mode if the flush is because of sink sources
                // only, then just external flush is sufficient.
                if (circ_buf_mode ||
                    (hw_fifo_mode &&
                     (f_on_man_actv || f_on_fl_in_actv) &&
                     !f_on_atbm_actv) ||
                    !ctl_trace_capt_en)
                  begin
                    nxt_flush_state     = FLUSH_IDLE;

                    // Reset all the flush active registers
                    nxt_f_on_man_actv   = 1'b0;
                    nxt_f_on_fl_in_actv = 1'b0;
                    nxt_f_on_trig_actv  = 1'b0;
                    nxt_f_on_atbm_actv  = 1'b0;


                    nxt_flush_man_clr   = f_on_man_actv;
                  end

                // If a trigger insertion is in progress or a new trigger
                // insertion is requested then wait for its completion before
                // requesting for formatter flush.
                else if (nxt_ft_trig_req)
                  begin
                    nxt_flush_state = TRIG_IN_PROGRESS;
                  end
                else
                  begin
                    nxt_ft_flush_req = 1'b1;
                    nxt_flush_state  = FORMATTER_FLUSH;
                  end
              end
          end

        TRIG_IN_PROGRESS :
          begin
            // Store all the new flush sources in pend register
            nxt_flush_pend      = (~flush_pend & flush_source) | flush_pend;
            nxt_f_on_man_pend   = (~f_on_man_pend & f_on_man_detect) |
                                   f_on_man_pend;
            nxt_f_on_fl_in_pend = (~f_on_fl_in_pend & f_on_fl_in_detect) |
                                   f_on_fl_in_pend;
            nxt_f_on_atbm_pend  = f_on_atbm_pend;

            if (!nxt_ft_trig_req)
              begin
                if (ctl_trace_capt_en)
                  begin
                    nxt_flush_state  = FORMATTER_FLUSH;
                    nxt_ft_flush_req = 1'b1;
                  end
                else
                  begin
                    nxt_flush_state = FLUSH_IDLE;

                    // Reset all the flush active registers
                    nxt_f_on_man_actv   = 1'b0;
                    nxt_f_on_fl_in_actv = 1'b0;
                    nxt_f_on_trig_actv  = 1'b0;
                    nxt_f_on_atbm_actv  = 1'b0;

                    nxt_flush_man_clr  = f_on_man_actv & sw_fifo_mode;
                  end
              end
          end

        FORMATTER_FLUSH :
          begin
            // Store all the new flush sources in pend register
            nxt_flush_pend      = (~flush_pend & flush_source) | flush_pend;
            nxt_f_on_man_pend   = (~f_on_man_pend & f_on_man_detect) |
                                   f_on_man_pend;
            nxt_f_on_fl_in_pend = (~f_on_fl_in_pend & f_on_fl_in_detect) |
                                   f_on_fl_in_pend;

            if (ft_flush_ack)
              begin
                nxt_ft_flush_req = 1'b0;
                if (ctl_trace_capt_en)
                  begin
                    nxt_flush_state  = WBUFFER_FLUSH;
                    nxt_wb_flush_req = 1'b1;
                  end
                else
                  begin
                    nxt_flush_state     = FLUSH_IDLE;

                    // Reset all the flush active registers
                    nxt_f_on_man_actv   = 1'b0;
                    nxt_f_on_fl_in_actv = 1'b0;
                    nxt_f_on_trig_actv  = 1'b0;
                    nxt_f_on_atbm_actv  = 1'b0;

                    nxt_flush_man_clr  = f_on_man_actv & sw_fifo_mode;
                  end
              end
          end

        WBUFFER_FLUSH :
          begin
            // Store all the new flush sources in pend register
            nxt_flush_pend      = (~flush_pend & flush_source) | flush_pend;
            nxt_f_on_man_pend   = (~f_on_man_pend & f_on_man_detect) |
                                   f_on_man_pend;
            nxt_f_on_fl_in_pend = (~f_on_fl_in_pend & f_on_fl_in_detect) |
                                   f_on_fl_in_pend;

            if (!etr_config)
              begin
                if (wb_flush_ack)
                  begin
                    nxt_wb_flush_req = 1'b0;
                    if ((hw_fifo_mode) && ctl_trace_capt_en)
                      begin
                        nxt_flush_state   = MEM_FLUSH;
                        nxt_mem_flush_req = 1'b1;
                      end
                    else
                      begin
                        nxt_flush_state = FLUSH_IDLE;

                        // Reset all the flush active registers
                        nxt_f_on_man_actv   = 1'b0;
                        nxt_f_on_fl_in_actv = 1'b0;
                        nxt_f_on_trig_actv  = 1'b0;
                        nxt_f_on_atbm_actv  = 1'b0;

                        nxt_flush_man_clr  = f_on_man_actv & sw_fifo_mode;
                      end
                  end
              end
            else
              // In case of ETR configuration, and SWF mode, the manual flush
              // clear needs to be asserted after memory flush
              begin
                if (wb_flush_ack)
                  begin
                    nxt_wb_flush_req = 1'b0;
                    if (ctl_trace_capt_en)
                      begin
                        nxt_flush_state  = MEM_FLUSH;
                        nxt_mem_flush_req = 1'b1;
                      end
                    else
                      begin
                        nxt_flush_state = FLUSH_IDLE;

                        // Reset all the flush active registers
                        nxt_f_on_man_actv   = 1'b0;
                        nxt_f_on_fl_in_actv = 1'b0;
                        nxt_f_on_trig_actv  = 1'b0;
                        nxt_f_on_atbm_actv  = 1'b0;

                        nxt_flush_man_clr  = f_on_man_actv & sw_fifo_mode;
                      end
                  end
              end

          end

        MEM_FLUSH :
          begin
            // Store all the new flush sources in pend register
            nxt_flush_pend      = (~flush_pend & flush_source) | flush_pend;
            nxt_f_on_man_pend   = (~f_on_man_pend & f_on_man_detect) |
                                   f_on_man_pend;
            nxt_f_on_fl_in_pend = (~f_on_fl_in_pend & f_on_fl_in_detect) |
                                   f_on_fl_in_pend;

            if (!etr_config && mem_flush_ack)
              begin
                nxt_atbm_flush_ready = 1'b1;
              end

            if (mem_flush_ack)
              begin
                nxt_flush_state      = FLUSH_IDLE;
                nxt_atbm_flush_ready = 1'b1;
                nxt_mem_flush_req    = 1'b0;

                // Reset all the flush active registers
                nxt_f_on_man_actv   = 1'b0;
                nxt_f_on_fl_in_actv = 1'b0;
                nxt_f_on_trig_actv  = 1'b0;
                nxt_f_on_atbm_actv  = 1'b0;

                nxt_flush_man_clr  = f_on_man_actv & sw_fifo_mode;
              end
          end

        default :
          begin
            nxt_flush_state = FLUSH_UNKNOWN;
          end
      endcase

    end // p_flush_control_comb

  // --------------------------------------------------------------------------
  // Clock process to realize the registers
  // --------------------------------------------------------------------------
  always @(posedge cxtmc_clk or negedge RESETn)
    begin : p_flush_control_seq
      if (!RESETn)
        begin
          flush_state             <= FLUSH_IDLE;
          ft_flush_req            <= 1'b0;
          wb_flush_req            <= 1'b0;
          mem_flush_req           <= 1'b0;
          atbm_flush_ready        <= 1'b0;
          atbm_flush_valid_del    <= 1'b0;
          f_on_man_pend           <= 1'b0;
          f_on_man_actv           <= 1'b0;
          f_on_fl_in_pend         <= 1'b0;
          f_on_fl_in_actv         <= 1'b0;
          f_on_atbm_pend          <= 1'b0;
          f_on_atbm_actv          <= 1'b0;
          f_on_trig_pend          <= 1'b0;
          f_on_trig_actv          <= 1'b0;
          flush_pend              <= 1'b0;
          flush_man_clr           <= 1'b1;
          afvalids_bef_integ      <= 1'b0;
        end
      else
        begin
          flush_state             <= nxt_flush_state;
          ft_flush_req            <= nxt_ft_flush_req;
          wb_flush_req            <= nxt_wb_flush_req;
          mem_flush_req           <= nxt_mem_flush_req;
          atbm_flush_ready        <= nxt_atbm_flush_ready;
          atbm_flush_valid_del    <= atbm_flush_valid;
          f_on_man_pend           <= nxt_f_on_man_pend;
          f_on_man_actv           <= nxt_f_on_man_actv;
          f_on_fl_in_pend         <= nxt_f_on_fl_in_pend;
          f_on_fl_in_actv         <= nxt_f_on_fl_in_actv;
          f_on_atbm_pend          <= nxt_f_on_atbm_pend;
          f_on_atbm_actv          <= nxt_f_on_atbm_actv;
          f_on_trig_pend          <= nxt_f_on_trig_pend;
          f_on_trig_actv          <= nxt_f_on_trig_actv;
          flush_pend              <= nxt_flush_pend;
          flush_man_clr           <= nxt_flush_man_clr;
          afvalids_bef_integ      <= nxt_afvalids_bef_integ;
        end
    end // p_flush_control_seq

  // --------------------------------------------------------------------------
  // AFVALIDS generation:
  // ~~~~~~~~~~~~~~~~~~~~
  // AFVALIDS is asserted when the combined flush source (ie pended flush and
  // flush source are 'OR'ed) is sampled asserted.
  // Once asserted the AFVALIDS is sustained until AFREADYS is sampled asserted.
  // When the handshake is completed the AFVALIDS is pulled low for 1
  // cycle(could be optimized if needed).
  // --------------------------------------------------------------------------
  assign nxt_afvalids =  (it_ctrl) ?
                            (it_atb_ctr_2_wr_en ? apb_wdata[1] : AFVALIDS) :
                            nxt_afvalids_bef_integ;

  // --------------------------------------------------------------------------
  // Clock process to realize AFVALIDS registers.
  // --------------------------------------------------------------------------
  always @(posedge cxtmc_clk or negedge RESETn)
    begin : p_afvalids_seq  
      if (!RESETn)
        begin
          AFVALIDS     <= 1'b0;
          af_ready_reg <= 1'b0;
        end
      else
        begin
          AFVALIDS     <= nxt_afvalids;
          af_ready_reg <= AFREADYS;
        end
    end // p_afvalids_seq

  // --------------------------------------------------------------------------
  // Flush in progress status bit is a direct reflection of external flush
  // --------------------------------------------------------------------------
  assign fl_in_prog = AFVALIDS;  

  // --------------------------------------------------------------------------
  // Stop request has to be pended until the flush FSM transitions back to
  // FLUSH_IDLE state.
  // --------------------------------------------------------------------------
  always @(posedge cxtmc_clk or negedge RESETn)
    begin : p_flush_fsm_busy_del_seq  
      if (!RESETn)
        begin
          flush_fsm_busy_del <= 1'b0;
        end
      else
        begin
          flush_fsm_busy_del <= flush_fsm_busy;
        end
    end // p_flush_fsm_busy_del_seq


  // --------------------------------------------------------------------------
  // Formatter stop request generation:
  // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  //
  // Stop requests to the formatter can only be asserted when a trigger request
  // is not in operation. If a trigger request is in operation the stop must
  // pend until the trigger acknowledgement is received from the formatter.
  // When a stop is generated, ft_stop_req must stay HIGH until the formatter
  // is permitted to begin capturing data again.
  // Formatter stop can be initiated by following sources
  // a) Disabling TraceCaptEn in CTL register
  // b) Setting StopTrig bit in FFCR register, which will trigger a stop
  //    request when trigger event is detected.
  // c) Setting StopFl bit in FFCR register, which will trigger a stop request
  //    when FLUSH is complete on ATB.
  // d) In ETR config, mem_err bit can be set which will result in stop request
  //    being asserted.
  // --------------------------------------------------------------------------

  // --------------------------------------------------------------------------
  // Generate a stop request when trace capture enable (ctl_trace_capt_en) is 0
  // --------------------------------------------------------------------------
  assign st_on_tc_en_detect = ~ctl_trace_capt_en;


  // --------------------------------------------------------------------------
  // Clock process to register ctl_trace_capt_en bit to detect 1->0 transition.
  // --------------------------------------------------------------------------
  always @(posedge cxtmc_clk or negedge RESETn)
    begin : p_ctl_trace_capt_en_seq  
      if (!RESETn)
        begin
          ctl_trace_capt_en_reg   <= 1'b0;
        end
      else
        begin
          ctl_trace_capt_en_reg   <= ctl_trace_capt_en;
        end
    end // p_ctl_trace_capt_en_seq

  // --------------------------------------------------------------------------
  // Clock process to register mem_err bit to detect 0->1 transition.
  // --------------------------------------------------------------------------
  always @(posedge cxtmc_clk or negedge RESETn)
    begin : p_mem_err_seq  
      if (!RESETn)
        begin
          mem_err_reg   <= 1'b0;
        end
      else
        begin
          mem_err_reg   <= mem_err;
        end
    end // p_mem_err_seq

  // --------------------------------------------------------------------------
  // 1->0 transition detection on ctl_trace_capt_en bit.
  // --------------------------------------------------------------------------
  assign ctl_trace_capt_en_0_1 = ctl_trace_capt_en & ~ctl_trace_capt_en_reg;

  // --------------------------------------------------------------------------
  // ffcr_stop_on_trig_evt_masked = StopTrig. Generate a stop request when a
  // trigger event has been detected.
  // --------------------------------------------------------------------------
  assign st_on_trig_detect = ffcr_stop_on_trig_evt_masked & trigger_event; 
                            
  // --------------------------------------------------------------------------
  // Memory error is detected and treated like a stop on trigger case.
  // --------------------------------------------------------------------------
  assign st_on_mem_err_detect = mem_err & ~mem_err_reg;

  // --------------------------------------------------------------------------
  // ffcr_stop_on_fl =  StopFl. Generate a stop request when AFREADYS is HIGH
  // --------------------------------------------------------------------------
  assign st_on_fl_detect = ffcr_stop_on_fl & af_ready_qual &
                           ~f_on_atbm_serv_in_prog;

  // --------------------------------------------------------------------------
  // Stop request activation
  // Stop requests must stay HIGH until the device is disabled and re-enabled.
  // --------------------------------------------------------------------------

  // --------------------------------------------------------------------------
  // Activate stop on trace capture disable:
  // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  // If a flush/trigger insertion is in progress the stop request because of
  // ctl_trace_capt_en de-asserted is pended and in all other scenarios
  // ft_stop_req is asserted.
  // --------------------------------------------------------------------------
  assign st_on_tc_en_active =  (st_on_tc_en_detect &
                                ~(nxt_ft_trig_req |
                                  // Wait for internal flush to complete
                                  flush_fsm_busy)) |
                               (st_tc_en_pend & ~flush_fsm_busy &
                                (ft_trig_ack |
                                 // reissue stop request when internal flush
                                 // completes
                                 (~flush_fsm_busy &
                                   flush_fsm_busy_del &
                                   ~nxt_ft_trig_req)));

  // --------------------------------------------------------------------------
  // Activate stop on trigger event:
  // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  // If a flush/trigger insertion is in progress the stop request because of
  // trigger event or mem_err is pended and in all other scenarios ft_stop_req
  // is asserted.
  // --------------------------------------------------------------------------
  assign st_on_trig_active = ((st_on_trig_detect | st_on_mem_err_detect) &
                              ~(nxt_ft_trig_req  |
                                  // Wait for internal flush to complete
                                  flush_fsm_busy)) |
                             (st_on_trig_active_reg & ~ctl_trace_capt_en_0_1) |
                             (st_trig_pend & ~flush_fsm_busy &
                              (ft_trig_ack |
                                 // reissue stop request when internal flush
                                 // completes
                                 (~flush_fsm_busy &
                                   flush_fsm_busy_del &
                                   ~nxt_ft_trig_req)));
  
  // --------------------------------------------------------------------------
  // Activate stop on flush completion:
  // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  // If a flush/trigger insertion is in progress the stop request because of
  // stop on flush event is pended and in all other scenarios ft_stop_req
  // is asserted.
  // --------------------------------------------------------------------------
  assign st_on_fl_active = (st_on_fl_detect &
                            ~(nxt_ft_trig_req |
                                // Wait for internal flush to complete
                                flush_fsm_busy)) |
                           (st_on_fl_active_reg & ~ctl_trace_capt_en_0_1) |
                           (st_fl_pend & ~flush_fsm_busy &
                            (ft_trig_ack |
                                 // reissue stop request when internal flush
                                 // completes
                                 (~flush_fsm_busy &
                                   flush_fsm_busy_del &
                                   ~nxt_ft_trig_req)));

  // --------------------------------------------------------------------------
  // Clock process to realize st_on_trig_active_reg/st_on_fl_active_reg register
  // --------------------------------------------------------------------------
  always @(posedge cxtmc_clk or negedge RESETn)
    begin : p_trg_flsh_act_seq   
      if (!RESETn)
        begin
          st_on_trig_active_reg <= 1'b0;
          st_on_fl_active_reg   <= 1'b0;
        end
      else
        begin 
          st_on_trig_active_reg <= st_on_trig_active;
          st_on_fl_active_reg   <= st_on_fl_active;
        end
    end // p_trg_flsh_act_seq
  
  // --------------------------------------------------------------------------
  // Pend a StOnTCEn if ft_trig_req or flush is in progress.
  // --------------------------------------------------------------------------
  assign nxt_st_tc_en_pend = (st_on_tc_en_detect &
                               (nxt_ft_trig_req |
                               // If internal flush in progress pend it
                                flush_fsm_busy)) |
                              (st_tc_en_pend &
                               (~ft_trig_ack & ft_trig_req |
                               // De-assert pend when the internal flush
                               // completes
                                flush_fsm_busy));
  
  // --------------------------------------------------------------------------
  // Pend a StOnTrigEvt/mem_err if ft_trig_req or flush is in progress.
  // --------------------------------------------------------------------------
  assign nxt_st_trig_pend = ((st_on_trig_detect | st_on_mem_err_detect) &
                               (nxt_ft_trig_req |
                               // If internal flush in progress pend it
                                flush_fsm_busy)) |
                             (st_trig_pend &
                              (~ft_trig_ack & ft_trig_req |
                               // De-assert pend when the internal flush
                               // completes
                               flush_fsm_busy));

  // --------------------------------------------------------------------------
  // Pend a StOnFlush if ft_trig_req or flush is in progress.
  // --------------------------------------------------------------------------
  assign nxt_st_fl_pend = (st_on_fl_detect &
                             (nxt_ft_trig_req |
                               // If internal flush in progress pend it
                                flush_fsm_busy)) |
                           (st_fl_pend &
                            (~ft_trig_ack & ft_trig_req |
                               // De-assert pend when the internal flush
                               // completes
                             flush_fsm_busy));

  // --------------------------------------------------------------------------
  // Clock process to realize st_tc_en_pend/st_trig_pend/st_fl_pend register
  // --------------------------------------------------------------------------
  always @(posedge cxtmc_clk or negedge RESETn)
    begin : p_st_pend_seq   
      if (!RESETn)
        begin
          st_tc_en_pend <= 1'b0;
          st_trig_pend  <= 1'b0;
          st_fl_pend    <= 1'b0;
        end    
      else
        begin      
          st_tc_en_pend <= nxt_st_tc_en_pend;
          st_trig_pend  <= nxt_st_trig_pend;
          st_fl_pend    <= nxt_st_fl_pend;
        end
    end // p_st_pend_seq
  
  // --------------------------------------------------------------------------
  // Indication that there is a stop pending because of trigger handshake
  // not completed. This signal is helpful in stopping further trigger
  // insertion into the trace stream.
  // --------------------------------------------------------------------------
  assign stop_pending = (st_tc_en_pend | st_trig_pend | st_fl_pend) &
                         ~flush_fsm_busy;

  assign nxt_stop_pending = (nxt_st_tc_en_pend | nxt_st_trig_pend |
                             nxt_st_fl_pend);
  // --------------------------------------------------------------------------
  // OR'ing of all the stop resources.
  // --------------------------------------------------------------------------
  assign nxt_ft_stop_req = st_on_tc_en_active |
                           st_on_trig_active |
                           st_on_fl_active;  
 
  // --------------------------------------------------------------------------
  // Clock process to realize ft_stop_req register
  // --------------------------------------------------------------------------
  always @(posedge cxtmc_clk or negedge RESETn)
    begin : p_stop_req_seq   
      if (!RESETn)
        begin
          ft_stop_req     <= 1'b1;
          ft_stop_req_reg <= 1'b1;
        end
      else
        begin
          ft_stop_req     <= nxt_ft_stop_req;
          ft_stop_req_reg <= ft_stop_req;
        end
    end // p_stop_req_seq

  //============================================================================
  // ASSERTIONS
  //============================================================================
`ifdef ARM_ASSERT_ON
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : Trigger events are generated only in circular buffer mode.")
      uzovl_cxtmc_format_control_001
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   ({ffcr_flsh_on_trig_evt_masked,trigger_event,((~ffcr_stop_on_trig_evt_masked)),circ_buf_mode,((~ft_stop_req))} == {1'b1,1'b1,1'b1,1'b0,1'b1})
        );
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : Triggers are not generated when ft_stop_req is asserted.")
      uzovl_cxtmc_format_control_002
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   ({ffcr_flsh_on_trig_evt_masked,trigger_event,((~ffcr_stop_on_trig_evt_masked)),circ_buf_mode,((~ft_stop_req))} == {1'b1,1'b1,1'b1,1'b1,1'b0})
        );
  generate
    if (CXTMC_ATBM_AXIM_CFG != CXTMC_CFG_ETF)
    begin
        assert_never #(`OVL_ERROR, `OVL_ASSERT,
         "OVL Message : The code is written in generic way to cater for all configuration, in ETF configuration alone f_on_atbm_serv_in_prog is active.")
            uzovl_cxtmc_format_control_003
              (
               .clk         (cxtmc_clk),
               .reset_n     (RESETn),
               .test_expr   ({ffcr_trig_on_fl_masked,af_ready_qual,((~f_on_atbm_serv_in_prog))} == {1'b1,1'b1,1'b0})
              );
        assert_never #(`OVL_ERROR, `OVL_ASSERT,
         "OVL Message : f_on_atbm_actv is asserted only in ETF configuration.")
            uzovl_cxtmc_format_control_004
              (
               .clk         (cxtmc_clk),
               .reset_n     (RESETn),
               .test_expr   ({af_ready_qual,f_on_atbm_actv,(~((f_on_man_actv|f_on_fl_in_actv)&(ffcr_stop_on_fl|ffcr_trig_on_fl_masked)))} == {1'b0,1'b1,1'b1})
              );
        assert_never #(`OVL_ERROR, `OVL_ASSERT,
         "OVL Message : f_on_atbm_actv is asserted only in ETF configuration.")
            uzovl_cxtmc_format_control_005
              (
               .clk         (cxtmc_clk),
               .reset_n     (RESETn),
               .test_expr   ({af_ready_qual,f_on_atbm_actv,(~((f_on_man_actv|f_on_fl_in_actv)&(ffcr_stop_on_fl|ffcr_trig_on_fl_masked)))} == {1'b1,1'b1,1'b1})
              );
        assert_never #(`OVL_ERROR, `OVL_ASSERT,
         "OVL Message : f_on_atbm_actv is asserted only in ETF configuration.")
            uzovl_cxtmc_format_control_006
              (
               .clk         (cxtmc_clk),
               .reset_n     (RESETn),
               .test_expr   ({af_ready_qual,f_on_atbm_actv,(~((f_on_man_actv|f_on_fl_in_actv)&(ffcr_stop_on_fl|ffcr_trig_on_fl_masked)))} == {1'b1,1'b1,1'b0})
              );
        assert_never #(`OVL_ERROR, `OVL_ASSERT,
         "OVL Message : f_on_atbm_serv_in_prog is asserted only in ETF configuration.")
            uzovl_cxtmc_format_control_007
              (
               .clk         (cxtmc_clk),
               .reset_n     (RESETn),
               .test_expr   ({ffcr_stop_on_fl,af_ready_qual,((~f_on_atbm_serv_in_prog))} == {1'b1,1'b1,1'b0})
              );
    end
  endgenerate

`endif
  
endmodule
