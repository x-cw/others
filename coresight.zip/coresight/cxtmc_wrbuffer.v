//----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2009-2010 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//    Checked In :  2010-06-21 17:43:41 +0530 (Mon, 21 Jun 2010) 
//    Revision   :  8317 
//    Release    : TM961-BU-50000-r0p0-00rel0
//
//----------------------------------------------------------------------------
// Purpose             : Data is written to the Write Buffer from the 
//                       Formatter or the APB Interface. Write Buffer drives
//                       the Data to Memory in ETB/ETF Configurations and to
//                       AXI in ETR Configurations
//----------------------------------------------------------------------------

module cxtmc_wrbuffer
  #( 
    // Width of ATB Bus - and is half of Memory width
    parameter CXTMC_ATB_DATA_WIDTH = 64,
    // Depth of Write buffer (=1 in ETB/ETF configs, =4/8/16/32 in ETR)
    parameter CXTMC_WBUFFER_DEPTH = 4, 
    // Defines (ETB-0/ETR-1/ETF-2) Configuration
    parameter CXTMC_ATBM_AXIM_CFG  = 1,
    // Defines PTR_WIDTH of AXI WRITE BUFFER
    parameter CXTMC_WB_PTR_WIDTH   = 1,
    // Defines the Writer Buffer data width
    parameter CXTMC_WB_DATA_WIDTH = 128) 
  (
  // Clock
  input wire                            cxtmc_clk,

  // Reset
  input wire                            RESETn,

  // Data from formatter
  input wire [CXTMC_ATB_DATA_WIDTH-1:0] ft_data,

  // Data from APB
  input wire                     [31:0] apb_wdata,

  // Formatter Data valid
  input wire                            ft_data_valid,

  // Request to Write APB Data into Write Buffer
  input wire                            rwd_wr_req,

  // write request has been accepted - data consumed same clock for AXI, 
  // next clock for memif
  input wire                            wb_req_ready,

  // Write buffer flush request from Flush control block
  input wire                            wb_flush_req,

  // If TraceCaptEn=0 and TMCReady=1, direct control of pointers and the memory
  // by the APB is allowed, regardless of empty status
  input wire                            tmc_disabled,

  // Pulse to clear trace memory pointers
  input wire                            ptr_clr,


  // Write buffer is empty
  output reg                            wb_empty,

  // Request for writing to write buffer accepted
  output reg                            wb_ready,

  // D-input of wb_ready
  output wire                           nxt_wb_ready,

  // write buffer request to memif/AXI
  output reg                            wb_req_valid,

  // Indicating the AXI If the burst of the current transfer
  output wire    [CXTMC_WB_PTR_WIDTH:0] wb_fill_level,

  // Write buffer data to memif/AXI
  output reg  [CXTMC_WB_DATA_WIDTH-1:0] wb_data,

  // Write buffer flush completion ack to Flush control block
  output wire                           wb_flush_ack

  );

//-----------------------------------------------------------------------------
// Constants definitions
//-----------------------------------------------------------------------------
`include "cxtmc_constants.v"

  //----------------------------------------------------------------------------
  // Local Constants definitions
  //----------------------------------------------------------------------------
// This paramters gives the ratio between Writer buffer Width and APB WIDTH, 
// which is 32. This will be used to determine, how many APB transactions will 
// make a single write buffer transaction
localparam APB_WB_RATIO     = CXTMC_WB_DATA_WIDTH/32;

// In case of non-AXI Configs, DEPTH is always 1, or in case of AXI, Write 
// buffer depth can be configured to be 1
localparam FIFO_DEPTH_EQ_1  = ((CXTMC_ATBM_AXIM_CFG != CXTMC_CFG_ETR) || 
                               (CXTMC_WBUFFER_DEPTH == 1)) ? 1'b1 : 1'b0;

// FIFO State machine states
localparam FIFO_READ_IDLE   = 1'b0; // Not enough data in write buffer to drain
localparam FIFO_READ_DRAIN  = 1'b1; // Drain of write buffer data in progress

//----------------------------------------------------------------------------
// WIRES AND REGS
//----------------------------------------------------------------------------

// This variables are used only when Write buffer width is not 32
  // write enables used to write the APB data into the correct Write buffer slot
  reg           [APB_WB_RATIO-1:0] apb_wren;
  // D-input for apb wren
  wire          [APB_WB_RATIO-1:0] nxt_apb_wren;
  // Clock enable for apb_wren
  wire                             apb_wren_clk_en;

// These variables are used only in Non-ETR Configurations
  // Write buffer width is always twice that ATB Data WIDTH/Formatter data 
  // width in Non-ETR Configs. So Formatter write enable has two bits, which 
  // are used to determine, whether Formatter data should be written to LSB or 
  // MSB
  reg                         [1:0] ft_data_wren;
  // D-input of ft_data_wren
  reg                         [1:0] nxt_ft_data_wren;

  // Clock enables for the write buffer flops
  reg            [APB_WB_RATIO-1:0] wb_data_we;

  // Clock enables for FIFO entry flops
  // These clock enables control writes to the FIFO element pointed to by
  // wptr[]
  reg            [APB_WB_RATIO-1:0] fifo_data_we;

  // Clocked version of wb_req_valid
  reg                               wb_req_valid_reg;

  // D-input of wb_req_valid
  reg                               nxt_wb_req_valid;
  // D-input of fifo data
  wire    [CXTMC_WB_DATA_WIDTH-1:0] nxt_fifo_data;
  // fifo which CXTMC_WB_DATA_WIDTH wide, CXTMC_WBUFFER_DEPTH deep
  reg     [CXTMC_WB_DATA_WIDTH-1:0] fifo[CXTMC_WBUFFER_DEPTH-1:0];
  // write pointer to the FIFO
  // read pointer to the FIFO
  reg      [CXTMC_WB_PTR_WIDTH-1:0] rptr;
  // write pointer to the FIFO
  reg      [CXTMC_WB_PTR_WIDTH-1:0] wptr;
  // D-input of wptr
  reg      [CXTMC_WB_PTR_WIDTH-1:0] nxt_wptr;
  // D-input of rptr
  reg      [CXTMC_WB_PTR_WIDTH-1:0] nxt_rptr;
  // Indicates the Fifo fill level
  reg        [CXTMC_WB_PTR_WIDTH:0] wb_fill_level_int;
  // Indicates the Fifo fill level
  reg        [CXTMC_WB_PTR_WIDTH:0] fifo_fill_level;
  // D-input of wb_fill_level
  wire       [CXTMC_WB_PTR_WIDTH:0] nxt_wb_fill_level;
  // D-input of wb_fill_level
  reg        [CXTMC_WB_PTR_WIDTH:0] nxt_fifo_fill_level;
  // Indicates that write buffer is full
  reg                               full;
  // D-input of full
  reg                               nxt_full;
  // Indicates that write buffer is not empty
  reg                               nxt_not_empty;
  // D-input of not_empty
  reg                               not_empty;
  // state machine which controls the reading of the write buffer
  reg                               fifo_read_state;
  // D_input of fifo_read_state
  reg                               nxt_fifo_read_state;
  // Indicates that fifo write pointer can be incremented
  wire                              fifo_wptr_incr;
  // clock enable for write buffer data
  reg                               wb_data_wren;

  // D-input for write buffer data from formatter
  wire    [CXTMC_WB_DATA_WIDTH-1:0] nxt_wb_ft_data;
  // D-input of write buffer data
  wire    [CXTMC_WB_DATA_WIDTH-1:0] nxt_wb_data;
  // D-input of wb_empty
  wire                              nxt_wb_empty;
  // apb write req is valid
  wire                              apb_wr_req_valid;
  // formatter write req is valid
  wire                              ft_wr_req_valid;

  // Count the number of write buffer elements to read out to complete a
  // flush operation
  reg        [CXTMC_WB_PTR_WIDTH:0] flush_cnt;

  // This signal enables a write to be initiated to axi interface
  wire                              axi_wr_en;
  // loop variables
  integer                           loopvar_l;
  integer                           loopvar_m;
  integer                           loopvar_i;
  integer                           loopvar_j;
  integer                           loopvar_k;

  //----------------------------------------------------------------------------
  //
  // MAIN CODE
  //
  //----------------------------------------------------------------------------
  // Write Buffer
  // 
  //----------------------------------------------------------------------------
  //
  // This generate block is for Non ETR Configurations 
  // Here the write buffer depth is 1 and width is twice of ATB_WIDTH
  generate 
  if (CXTMC_ATBM_AXIM_CFG != CXTMC_CFG_ETR) 
    begin

    // wb_fill_level is a AXI signal and hence not relevant in non ETR Configs
    assign wb_fill_level = {CXTMC_WB_PTR_WIDTH{1'b0}};

    // rwd_wr_req indicates request from apb to write write buffer, req is valid when
    // wb_ready is high
    assign apb_wr_req_valid = rwd_wr_req & wb_ready;
    assign ft_wr_req_valid  = ft_data_valid & wb_ready;

    // wb_req_valid is combinationally set when the write buffer is completely 
    // written. ft_data_wren signal initialized to 2'b01. When a write happens 
    // it toggles to 2'b10 and toggles back to 2'b01 on further write.
    // apb_wren signal is a N=2bit or a N=4bit or a N=8 bit signal depending on
    // ATB_WIDTH being 32 bit or 64 bit and 128 bit. N is denoted by 
    // APB_WB_RATIO. 
    always @*
    begin : p_etb_etf
      case ({apb_wr_req_valid,ft_wr_req_valid})
        2'b00 : begin
          // wb_ready being high means that wb_req_ready has been asserted last
          // clock, hence it can be reset
          wb_req_valid         = wb_ready ? 1'b0 : wb_req_valid_reg;
          // retain old value when both requests are not valid
          nxt_ft_data_wren    = ft_data_wren;
        end
        2'b01 : begin
          // Write buffer is twice as wide as data coming from formatter.
          // hence wb req to AXI/Memif is set
          wb_req_valid      = ft_data_wren[1];
          // Formatter write is happening - hence rotate the wrenables
          // Only section of the data for which the wren is high will be
          // written
          nxt_ft_data_wren = {ft_data_wren[0], ft_data_wren[1]};
        end
        2'b10 : begin 
          // wb req to AXI/memif is set if the MSB of wr enables is set
          wb_req_valid      = apb_wren[APB_WB_RATIO-1];
          // retain formatter wr enables as they are not set
          nxt_ft_data_wren = ft_data_wren;
          // rotate the apb write enables as APB write is happening
        end
        default : begin
          wb_req_valid      = 1'bx;
          nxt_ft_data_wren = 2'bxx;
        end
      endcase
    end

    // apb_wren is initialized to 'd1 and is left shifted for 
    // every write until the last 32bit value is written then it is reassigned 
    // to 'd1.
    assign nxt_apb_wren = apb_wr_req_valid ? {apb_wren[APB_WB_RATIO-2:0],
                                               apb_wren[APB_WB_RATIO-1]} :
                            (ptr_clr ? {{APB_WB_RATIO-1{1'b0}},1'b1} :
                            apb_wren);

    // write buffer is empty if request is asserted by write buffer and is 
    // accepted. If there is a apb or formatter write request and the final write 
    // buffer data part is being written, then write buffer is not empty
    assign nxt_wb_empty = wb_req_valid && wb_req_ready ? 1'b1 : 
                           (((rwd_wr_req && apb_wren[APB_WB_RATIO-1]) 
                             || (ft_data_valid && ft_data_wren[1])) ? 1'b0 : wb_empty);

    // write buffer is ready if either its request to AXI/Memif is not asserted
    // or, if the asserted request is accepted
    assign  nxt_wb_ready = ~wb_req_valid | wb_req_ready;


    // If the formatter is stopped, then all 0's need to written to write buffer, else
    // the formatter data is duplicated, so that the correct data is written based
    // on the mask
    assign nxt_wb_ft_data = {2{ft_data}};


    // Data that is written to the write buffer is determined based on whether 
    // it is a formatter write or a apb write. For APB writes, write data is
    // replicated on all 32-bit lanes, but the lane that is enabled to be 
    // written is controlled by wb_data_we[].
  assign nxt_wb_data = ft_wr_req_valid ? nxt_wb_ft_data :
                        apb_wr_req_valid ? {APB_WB_RATIO{apb_wdata}} : wb_data;


    // Write buffer is updated when formatter or apb requests are valid.
    // The write databus from the formatter is of width ATB_DATA_WIDTH, so
    // it could be 32, 64 or 128 bits wide.
    // In the non-ETR configuration, the write buffer is twice as wide as
    // the formatter write databus, so the write buffer can be 64, 128
    // or 256-bits wide. 
    // APB accesses are always of 32-bits width, so this mandates a 32-bit
    // granularity in generating write enables.
    // When there is an APB access, the specific 32-bit section of the 
    // write buffer pointed-to by apb_wren[] is enabled to be written.
    // When there is a write from the formatter, the write data is routed 
    // to the specific half of the write buffer pointed-to by ft_data_wren[].
    always @*
      begin
        for (loopvar_i=0;loopvar_i<APB_WB_RATIO/2;loopvar_i=loopvar_i+1)
          wb_data_we[loopvar_i] = ft_wr_req_valid ? ft_data_wren[0] :
                          apb_wr_req_valid ? apb_wren[loopvar_i] : 1'b0;
        for (loopvar_j=APB_WB_RATIO/2;loopvar_j<APB_WB_RATIO;loopvar_j=loopvar_j+1)
          wb_data_we[loopvar_j] = ft_wr_req_valid ? ft_data_wren[1] :
                          apb_wr_req_valid ? apb_wren[loopvar_j] : 1'b0;
      end

    // Each 32-bit section of the write buffer is updated if the corresponding
    // clock enable term is asserted.
    // The part-select syntax wb_data[loopvar_k*32 +: 32] represents
    // wb_data[loopvar_k*32+31 : loopvar_k*32]
    always @(posedge cxtmc_clk)
    begin
      for (loopvar_k=0;loopvar_k<APB_WB_RATIO;loopvar_k=loopvar_k+1)
        if (wb_data_we[loopvar_k])
          wb_data[loopvar_k*32 +: 32] <= nxt_wb_data[loopvar_k*32 +: 32];
    end

    // Register logic for above comb signals
    always @(posedge cxtmc_clk or negedge RESETn)
    begin
      if (!RESETn) begin
        ft_data_wren     <= 2'b01;
        wb_ready         <= 1'b0;
        wb_req_valid_reg <= 1'b0;
        wb_empty         <= 1'b1;
      end else begin
        ft_data_wren     <= nxt_ft_data_wren;
        wb_ready         <= nxt_wb_ready;
        wb_req_valid_reg <= wb_req_valid;
        wb_empty         <= nxt_wb_empty;
      end
    end

    // Register logic for above comb signals
    always @(posedge cxtmc_clk or negedge RESETn)
    begin
      if (!RESETn) begin
        apb_wren         <= {{APB_WB_RATIO-1{1'b0}},1'b1};
      end else if (apb_wr_req_valid) begin
        apb_wren         <= nxt_apb_wren;
      end
    end
  end 
  endgenerate

  generate 
  if ((CXTMC_ATBM_AXIM_CFG == CXTMC_CFG_ETR) && (CXTMC_WB_DATA_WIDTH !=32))
    begin

    // Write FIFO elements are wider than APB, so enabling of the correct lane
    // is needed on APB writes. Write FIFO elements are of same width as
    // formatter write databus, so no specific control of writes on data lanes 
    // needed for formatter writes.

    // fifo wptr increment happens if it is a formatter write or if enough
    // writes happened from APB to fill one write buffer entry.
    assign fifo_wptr_incr = ft_data_valid | (apb_wr_req_valid & apb_wren[APB_WB_RATIO-1]);

    // The apb wren determine which section of the write buffer entry is updated
    // They are rotated left after each write to write to next section of the
    // write buffer
    assign nxt_apb_wren  = apb_wr_req_valid ? {apb_wren[APB_WB_RATIO-2:0],
                                               apb_wren[APB_WB_RATIO-1]} : 
                             (ptr_clr ? {{APB_WB_RATIO-1{1'b0}},1'b1} :
                             apb_wren);
    // FIFO is written when there is a formatter write request or APB request
    // Generate enables for each 32-bit section of a FIFO entry
    always @*
      begin
        for (loopvar_l=0;loopvar_l<APB_WB_RATIO;loopvar_l=loopvar_l+1)
          fifo_data_we[loopvar_l] = (ft_data_valid | (apb_wr_req_valid & apb_wren[loopvar_l]));
      end

    // formatter data is written to fifo if formatter data is valid
    // Else appropriate portion of the fifo is written with apb data
    // as per the apb mask
    assign  nxt_fifo_data = apb_wr_req_valid ? {APB_WB_RATIO{apb_wdata}} : 
                            ft_data;

    // Clock enable for apb_wren flop
    assign apb_wren_clk_en = apb_wr_req_valid | ptr_clr;

    // Register logic for above apb_wren signal
    always @(posedge cxtmc_clk or negedge RESETn)
    begin
      if (!RESETn) begin
        apb_wren          <= {{APB_WB_RATIO-1{1'b0}},1'b1};
      end else if (apb_wren_clk_en) begin
        apb_wren          <= nxt_apb_wren;
      end
    end
    // Register block for fifo data
    always @(posedge cxtmc_clk)
      begin
        for (loopvar_m=0;loopvar_m<APB_WB_RATIO;loopvar_m=loopvar_m+1)
          if (fifo_data_we[loopvar_m])
            fifo[wptr][loopvar_m*32 +: 32] <= nxt_fifo_data[loopvar_m*32 +: 32];
      end

    // If tmc is enabled write buffer is ready as long as it is not full
    // In disabled state, for the last write from APB which completes the burst length, nxt_wb_ready is set
    // to low, and pulled high only when the write completes.
    assign nxt_wb_ready = tmc_disabled ? 
                             ((~apb_wren[APB_WB_RATIO-1] && (fifo_read_state == FIFO_READ_IDLE) && ~axi_wr_en) | 
                             (wb_req_valid & wb_req_ready)) : ~nxt_full;
  end
  else if ((CXTMC_ATBM_AXIM_CFG == CXTMC_CFG_ETR) && (CXTMC_WB_DATA_WIDTH == 32))
  begin
    assign fifo_wptr_incr = apb_wr_req_valid | ft_data_valid;
    // formatter data is written is formatter request is valid, else apb
    // data is written if apb request is valid
    assign  nxt_fifo_data = apb_wr_req_valid ? apb_wdata : ft_data; 

    // Register block for fifo data
    always @(posedge cxtmc_clk)
    begin
      if (fifo_wptr_incr) begin
        fifo[wptr] <= nxt_fifo_data;
      end
    end
    // If tmc is enabled write buffer is ready as long as it is not full
    // In disabled state, for the last write from APB which completes the burst length, nxt_wb_ready is set
    // to low, and pulled high only when the write completes.
    assign nxt_wb_ready = tmc_disabled ? 
                               (wb_req_valid & wb_req_ready) : ~nxt_full;
  end
  endgenerate

  generate 
  if (CXTMC_ATBM_AXIM_CFG == CXTMC_CFG_ETR) begin

    // clock enable for wptr and rptr
    wire ptr_en;

    // rwd_wr_req indicates request from apb to write write buffer, req is valid when
    // wb_ready is high
    assign apb_wr_req_valid = rwd_wr_req & (wb_ready | tmc_disabled);
    // FIFO control logic
    // wb_data_wren refers to reading from fifo
    // fifo_wptr_incr refers to incrementing of fifo wptr
    // with apb writes, write can happen to fifo without incrementing the pointer for 
    // 64 or 128 bit widths
    always @*
    begin
      case ({fifo_wptr_incr,wb_data_wren})
        2'b00: begin
          // No read, no write, retain the pointers
          nxt_wptr            = wptr;
          nxt_rptr            = rptr;
          nxt_not_empty       = not_empty;
          nxt_full            = full;
          nxt_fifo_fill_level = fifo_fill_level;
        end
        2'b01 : begin
          // read only. increment read pointer, retain write pointer
          // not_empty is reset if the incremented read pointer
          // equals write pointer
          // full is reset as read is happening
          // fill level gets decremented by 1
          nxt_wptr            = wptr;
          nxt_rptr            = rptr + {{CXTMC_WB_PTR_WIDTH-1{1'b0}},1'b1};
          nxt_not_empty       = (nxt_rptr != wptr);
          nxt_full            = 1'b0;
          nxt_fifo_fill_level = fifo_fill_level - {{CXTMC_WB_PTR_WIDTH{1'b0}},1'b1};
        end
        2'b10 : begin
          // write only. increment write pointer, retain read pointer
          // not_empty is set as a write is happening
          // full is reset if incremented write pointer equals 
          // read pointer
          // fill level gets incremented by 1
          nxt_wptr            = wptr + {{CXTMC_WB_PTR_WIDTH-1{1'b0}},1'b1};
          nxt_rptr            = rptr;
          nxt_not_empty       = 1'b1;
          nxt_full            = (nxt_wptr == rptr);
          nxt_fifo_fill_level = fifo_fill_level + {{CXTMC_WB_PTR_WIDTH{1'b0}},1'b1};
        end
        2'b11 : begin
          // write and read happen together.
          // both write and read pointers are incremented
          // Neither empty nor full - as both read/write happen
          // together. fill level is retained
          nxt_wptr            = wptr + {{CXTMC_WB_PTR_WIDTH-1{1'b0}},1'b1};
          nxt_rptr            = rptr + {{CXTMC_WB_PTR_WIDTH-1{1'b0}},1'b1};
          nxt_not_empty       = not_empty;
          nxt_full            = full;
          nxt_fifo_fill_level = fifo_fill_level;
        end
        default : begin
          nxt_wptr            = {CXTMC_WB_PTR_WIDTH{1'bx}};
          nxt_rptr            = {CXTMC_WB_PTR_WIDTH{1'bx}}; 
          nxt_not_empty       = 1'bx;
          nxt_full            = 1'bx;
          nxt_fifo_fill_level = {CXTMC_WB_PTR_WIDTH+1{1'bx}};
        end
      endcase
    end

    assign ptr_en = fifo_wptr_incr | wb_data_wren;
  
    assign axi_wr_en = |fifo_fill_level;

    assign nxt_wb_fill_level = (!wb_req_valid || wb_req_ready) ? fifo_fill_level : 
                                 fifo_fill_level + {{CXTMC_WB_PTR_WIDTH{1'b0}},1'b1}; 

    // State machine to control FIFO reads/writes
    always @*
    begin
      case (fifo_read_state)
        FIFO_READ_IDLE : begin
          // FIFO state is IDLE, so no read is in progress
          // if the fill level of the FIFO equals to the programmed value
          // or if the formatter has stopped - req to AXI is asserted to
          // drain write buffer data
          nxt_wb_req_valid    = axi_wr_en;
          // transition to READ DRAIN state if req to AXI is getting asserted
          nxt_fifo_read_state = axi_wr_en ?  FIFO_READ_DRAIN : FIFO_READ_IDLE;
          // wb_data is written if a request is not asserted or is accepted
          // and fifo is not empty
          wb_data_wren        = axi_wr_en;
        end
        FIFO_READ_DRAIN : begin
          // If the read count equals to the burst length programmed then
          // SM transitions to IDLE state
          nxt_fifo_read_state  = (wb_req_ready && !axi_wr_en) ? 
                                           FIFO_READ_IDLE : FIFO_READ_DRAIN;
          // data valid is asserted as long as data exists to be transfered
          // Request valid is deasserted as it is not a new request
          nxt_wb_req_valid     = (wb_req_ready && !axi_wr_en) ? 1'b0 : 1'b1;
          // wb_data is written if a request is not asserted or is accepted
          // and fifo is not empty
          wb_data_wren          = (wb_req_ready && !axi_wr_en) ?  
                                           1'b0 : wb_req_ready & not_empty;

        end
        default : begin
          nxt_fifo_read_state  = 1'bx;
          nxt_wb_req_valid     = 1'bx;
          wb_data_wren         = 1'bx;
        end
      endcase
    end
  
    // wb_empty is generated from not_empty signal and the extra register stage being empty
    assign nxt_wb_empty = ~nxt_not_empty & ~nxt_wb_req_valid;

    // Register block for fifo and other control signals
    always @(posedge cxtmc_clk or negedge RESETn)
    begin
      if (!RESETn) begin
        wb_ready          <= 1'b0;
        wb_req_valid      <= 1'b0;
        fifo_read_state   <= FIFO_READ_IDLE;
        wb_fill_level_int <= {CXTMC_WB_PTR_WIDTH+1{1'b0}};
        wb_empty          <= 1'b1;
      end else begin
        wb_ready          <= nxt_wb_ready;
        wb_req_valid      <= nxt_wb_req_valid;
        fifo_read_state   <= nxt_fifo_read_state;
        wb_fill_level_int <= nxt_wb_fill_level;
        wb_empty          <= nxt_wb_empty;
      end
    end
  
    always @(posedge cxtmc_clk or negedge RESETn)
    begin
      if (!RESETn) begin
        wptr              <= {CXTMC_WB_PTR_WIDTH{1'b0}};
        rptr              <= {CXTMC_WB_PTR_WIDTH{1'b0}};
        not_empty         <= 1'b0;
        fifo_fill_level   <= {CXTMC_WB_PTR_WIDTH+1{1'b0}};
        full              <= 1'b0;
      end else if (ptr_en) begin
        wptr              <= nxt_wptr;
        rptr              <= nxt_rptr;
        not_empty         <= nxt_not_empty;
        fifo_fill_level   <= nxt_fifo_fill_level;
        full              <= nxt_full;
      end
    end

    // wb_data is muxed from fifo pointed to by the rptr
    assign nxt_wb_data  = fifo[rptr];

    // fill level external signal
    assign wb_fill_level = wb_fill_level_int;
  
    // Register block for write buffer data
    always @(posedge cxtmc_clk)
    begin
      if (wb_data_wren) begin
        wb_data <= nxt_wb_data;
      end
    end
  end
  endgenerate


//----------------------------------------------------------------------------
// Flush control logic
//----------------------------------------------------------------------------
generate
  if (CXTMC_ATBM_AXIM_CFG != CXTMC_CFG_ETR) // ETB/ETF configurations
    assign wb_flush_ack = wb_empty;
  else // ETR configuration
    begin
      // D-input of flush_cnt
      wire [CXTMC_WB_PTR_WIDTH:0] nxt_flush_cnt;

      // Remember that a flush request has been detected when the write buffer
      // is not empty
      reg wb_flush_req_det;
  
      // D-input of wb_flush_req_det
      wire nxt_wb_flush_req_det;

      // Write buffer flush acknowledge corresponding to non-empty 
      // write buffer 
      wire wb_fl_ack_non_empty;

      // Check whether wb_fill_level is 0
      wire wb_fill_level_eq0;

      // Check whether flush_cnt is 0
      wire flush_cnt_eq0;

      // Load enable for the flush_cnt counter
      wire flush_cnt_load_en;

      // Decrement control for the flush_cnt counter
      wire flush_cnt_decr;

      //------------------------------------------------------------------------
      // In the ETR configuration, the write buffer has a holding buffer on the
      // read path in addition to the FIFO. The wb_fill_level signal indicates
      // the overall fill level in the write buffer taking into account the
      // holding buffer.
      // When the write buffer is empty, the flush acknowledge is asserted
      // regardless of a flush request.
      // When the write buffer is non-empty and a flush request is asserted, 
      // the fill level is clocked into the flush_cnt counter. With every
      // read from the write buffer, this counter is decremented. When it 
      // reaches 0, the flush is acknowledged.
      //------------------------------------------------------------------------
      assign wb_flush_ack = wb_fill_level_eq0 | wb_fl_ack_non_empty;

      //------------------------------------------------------------------------
      // For the case when the flush request is asserted when the write
      // buffer fill level was non-zero, wait for the flush_cnt counter to
      // reach 0 to assert the flush acknowledge.
      //------------------------------------------------------------------------
      assign wb_fl_ack_non_empty = wb_flush_req_det & flush_cnt_eq0; 

      //------------------------------------------------------------------------
      // Comparators to check fill level and flush counter
      //------------------------------------------------------------------------
      assign wb_fill_level_eq0 = ~|wb_fill_level;
      assign flush_cnt_eq0 = ~|flush_cnt;

      //------------------------------------------------------------------------
      // When the flush request is asserted when the write buffer fill level is
      // non-zero, remember this till the flush counter counts down to 0.
      //------------------------------------------------------------------------
      assign nxt_wb_flush_req_det = (~wb_flush_req_det & wb_flush_req & 
                                      ~wb_fill_level_eq0) |
                                    (wb_flush_req_det & ~flush_cnt_eq0);

      always @(posedge cxtmc_clk or negedge RESETn)
      begin
        if (!RESETn)
            wb_flush_req_det <= 1'b0;
        else
            wb_flush_req_det <= nxt_wb_flush_req_det;
      end

      //------------------------------------------------------------------------
      // Flush counter logic.
      // When the write buffer is non-empty and a flush request is asserted, 
      // the fill level is clocked into the flush_cnt counter. With every
      // read from the write buffer, this counter is decremented. When it 
      // reaches 0, the flush is acknowledged.
      //------------------------------------------------------------------------
      assign flush_cnt_load_en = wb_flush_req & ~wb_fill_level_eq0 & 
                                 ~wb_flush_req_det;

      assign flush_cnt_decr = wb_flush_req_det & wb_req_valid & wb_req_ready;

      assign nxt_flush_cnt = flush_cnt_load_en ? nxt_wb_fill_level :
                             flush_cnt_decr ? (flush_cnt -  
                               {{CXTMC_WB_PTR_WIDTH{1'b0}}, 1'b1}) :
                               flush_cnt;

        always @(posedge cxtmc_clk or negedge RESETn)
        begin
          if (!RESETn)
            begin
              flush_cnt   <= {CXTMC_WB_PTR_WIDTH+1{1'b0}};
            end
          else
            begin
              flush_cnt   <= nxt_flush_cnt;
            end
        end
    end
endgenerate

  //----------------------------------------------------------------------------
  // ASSERTIONS
  //----------------------------------------------------------------------------
`ifdef ARM_ASSERT_ON

// Check for illegal combination in case selection

  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxtmc_wrbuffer - Invalid combination of 2'b11 in case statement at p_etr_n32")
      uzovl_cxtmc_wrbuffer_case_item_p_etr_n32
        ( 
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   (rwd_wr_req & ft_data_valid)
        );

generate 
  if (CXTMC_ATBM_AXIM_CFG != CXTMC_CFG_ETR) begin

  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxtmc_wrbuffer - apb_wr_req_valid and ft_wr_req_valid cant be set together")
      uzovl_cxtmc_wrbuffer_apb_wr_req_ft_wr_req
        ( 
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   (apb_wr_req_valid & ft_wr_req_valid)
        );

  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxtmc_wrbuffer - wb_ready cant go low in tmc_disabled state and rwd_wr_req only comes in disabled")
      uzovl_cxtmc_wrbuffer_wb_ready_disabled
        ( 
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   (rwd_wr_req & ~wb_ready)
        );
end
endgenerate

// Once Flush request is asserted, it must not be de-asserted before flush ack is asserted
  reg wb_flush_req_reg;
  reg wb_flush_ack_reg;

  always @(posedge cxtmc_clk or negedge RESETn)
  begin
    if (!RESETn)
      begin
        wb_flush_req_reg <= 1'b0;
        wb_flush_ack_reg <= 1'b0;
      end
    else
      begin
        wb_flush_req_reg <= wb_flush_req;
        wb_flush_ack_reg <= wb_flush_ack;
      end
  end

   assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxtmc_memif - Once Flush request is asserted, it must not be de-asserted before flush ack is asserted")
      uzovl_cxtmc_memif_flush_req_ack
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   (~wb_flush_req & wb_flush_req_reg & ~wb_flush_ack_reg)
        );


  wire [CXTMC_ATB_DATA_WIDTH-1 : 0] wb_data_mask;

  assign wb_data_mask = (CXTMC_ATB_DATA_WIDTH == 32) ? 32'h00FEFFFE :
                         (CXTMC_ATB_DATA_WIDTH == 64) ? 64'h00FEFFFEFFFEFFFE :
                          128'h00FEFFFEFFFEFFFEFFFEFFFEFFFEFFFE;

generate 
  if (CXTMC_ATBM_AXIM_CFG == CXTMC_CFG_ETR) 
    begin
      wire flush_cnt_eq1;
      assign flush_cnt_eq1 = (flush_cnt == {{CXTMC_WB_PTR_WIDTH{1'b0}}, 1'b1});

      assert_never #(`OVL_ERROR, `OVL_ASSERT,
      "OVL Message : cxtmc_wrbuffer - Write Buffer flush happened with non -zero data")
      uzovl_cxtmc_wbuffer_flush_non_zero_data_etr
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   (wb_flush_req && flush_cnt_eq1 && wb_req_ready && 
                       wb_req_valid && ((wb_data & wb_data_mask) != 'h0))
        );
    end
  else // ETB/ETF
    assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxtmc_wrbuffer - Write Buffer flush happened with non -zero data")
      uzovl_cxtmc_wbuffer_flush_non_zero_data_etb_etf
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   (wb_flush_req && nxt_wb_empty && wb_req_valid && 
                      ((wb_data & wb_data_mask) != 'h0))
        );
endgenerate

`endif
     
endmodule
