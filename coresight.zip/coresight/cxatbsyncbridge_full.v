//-----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2004-2015 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//  Version and Release Control Information:
//
//  File Revision       : $Revision: 40320 $
//  File Date           : $Date: 2014-10-23 10:07:08 +0100 (Thu, 23 Oct 2014) $
//
//  Release Information : CoreSight-SoC-TM100-r3p2-00rel0
//-----------------------------------------------------------------------------

//  Overview
// ==========
//
//   The cxatbsyncbridge_full provides full timing isolation between the source
//   and destination interfaces.
//
//   The cxatbsyncbridge_full monitors and drives the handshake signals from/to
// the master and slave interfaces.  The component instantiates atleast two storage
// registers to ensure a minimum latency of 1 and back to back transfer
// support.  A minimum of two storage registers are required for full timing
// isolation due to the latency effects of the registers and protocol
// requirements.
//
//
//
//----------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Module Declaration
//------------------------------------------------------------------------------
module cxatbsyncbridge_full
       #( parameter ATB_BYTES_WIDTH =2,
          parameter ATB_DATA_WIDTH =32,
          parameter FIFO_DEPTH=2,
          parameter LPI_PRESENT=1)
  (
  //----------------------------------------------------------------------------
  // port definitions
  //----------------------------------------------------------------------------

 // Slave Port

  input                        clk,          // ATB Bus clock
  input                        clkens,       // ATB Bus clock enable for slave port
  input                        resetn,       // ATB Bus reset
  input                        atvalids,     // ATB Bus transfer valid slave
  input [6:0]                  atids,        // ATB Bus id slave
  input [ATB_BYTES_WIDTH-1:0]  atbytess,     // ATB Bus bytes slave
  input [ATB_DATA_WIDTH-1:0]   atdatas,      // ATB Bus data slave
  input                        afreadys,     // ATB Bus flush ready slave
  // Master Port
  input                        clkenm,       // ATB Bus clock enable for master port
  input                        atreadym,     // ATB Bus transfer ready master
  input                        afvalidm,     // ATB Bus flush valid master
  input                        syncreqm,     // Synchronization request

  // LPI Ports
  input                        csysreq,      // Power down request


  //----------------------------------------------------------------------------
  // OUTPUTS
  //----------------------------------------------------------------------------

  // Slave Port
  output                       atreadys,     // ATB Bus transfer ready slave
  output wire                  afvalids,     // ATB Bus flush valid slave
  // Master Port
  output                       atvalidm,     // ATB Bus transfer valid master
  output [6:0]                 atidm,        // ATB Bus id master
  output [ATB_BYTES_WIDTH-1:0] atbytesm,     // ATB Bus bytes master
  output [ATB_DATA_WIDTH-1:0]  atdatam,      // ATB Bus data master
  output wire                  afreadym,     // ATB Bus flush ready master
  output wire                  syncreqs,     // Synchronization request
  // LPI Ports
  output wire                  csysack,      // Low Power Acknowledge
  output wire                  cactive

);



  //----------------------------------------------------------------------------
  // parameters
  //----------------------------------------------------------------------------
  // user defined parameters
  localparam PAYLD_WIDTH = (ATB_BYTES_WIDTH+ATB_DATA_WIDTH+7);

  // calculated parameters (do not alter)
  localparam PAYLD_MAX = (PAYLD_WIDTH - 1);

  localparam FIFO_PTR_WIDTH = (FIFO_DEPTH == 2) ? 1 :
                              (FIFO_DEPTH == 4) ? 2 :
                              (FIFO_DEPTH == 8) ? 3 :
                              (FIFO_DEPTH == 16)? 4 :
                              (FIFO_DEPTH == 32) ? 5 :
                              (FIFO_DEPTH == 64) ? 6 :
                              (FIFO_DEPTH == 128) ? 7 :
                                                  8;


  localparam  F_IDLE          =2'b00;
  localparam  F_SLAVE_FLUSH   =2'b01;
  localparam  F_MSTR_FLUSH    =2'b10;
  localparam  F_FLUSH_COMPLETE=2'b11;
  localparam  F_UNDEFINED     =2'bxx;



  //----------------------------------------------------------------------------
  // internal signals declarations
  //----------------------------------------------------------------------------

  wire                    valid_src;                      // transfer valid from the source
  wire [PAYLD_MAX:0]      payload_src;                    // transfer payload from source

  wire                    valid_dst;                      // transfer valid to the destination
  wire                    ready_src;                      // source ready to accept transfer
  reg [FIFO_DEPTH-1 :0]   payload_out [PAYLD_MAX :0];     // FIFO data along with selected rd_ptr
  reg [PAYLD_MAX:0]       payload_dst;                    // transfer payload to destination

  reg [FIFO_DEPTH-1 :0]   output_en;                      // Select line for the fifo read
  wire[FIFO_DEPTH-1 :0]   nxt_output_en;                  // Select line for the fifo read
  wire                    load_en;                        // Fifo load enable
  wire                    iready_src;                     // internal version of ready_src
  reg                     valid_dst_reg;                  // register to generate valid_dst
  wire                    ivalid_dst;                     // internal version of valid_dst


  reg [1:0]               nxt_flush_state;                // Next state for flush FSM
  reg [1:0]               flush_state;                    // Flush FSM state
  reg                     iafreadym;
  wire                    nxt_afreadym;
  wire                    nxt_afvalids;
  wire                    last_data_xfer;                 // Last flush data is being transfered
  wire                    last_slv_data_accepted_on_mstr; // Last flush data beign accepted on master port
  wire[FIFO_PTR_WIDTH:0]  wr_ptr_minus_one;

  reg [PAYLD_MAX :0]      fifo_payload [FIFO_DEPTH-1 :0]; // FIFO storage
  reg [FIFO_DEPTH-1 :0]   fifo_load_en;                   // Write enable lines for FIFO locations
  wire                    nxt_fifo_empty;                 // FIFO empty status
  wire                    nxt_fifo_full;                  // FIFO full status
  reg                     fifo_empty;                     // FIFO empty status
  reg                     fifo_full;                      // FIFO full status
  wire                    inc_rd_ptr;                     // Control siganl to increment read pointer
  wire [FIFO_PTR_WIDTH:0] nxt_rd_ptr;                     // Next Read pointer value
  wire [FIFO_PTR_WIDTH:0] nxt_wr_ptr;                     // Next write pointer value
  reg [FIFO_PTR_WIDTH:0]  rd_ptr;                         // Read pointer
  reg [FIFO_PTR_WIDTH:0]  wr_ptr;                         // write pointer
  wire [FIFO_PTR_WIDTH:0] nxt_last_flush_data_ptr;
  reg  [FIFO_PTR_WIDTH:0] last_flush_data_ptr;            // Last data location marker for flush
  wire                    nxt_pd_ack;
  reg                     pd_ack_i;                       // Power down acknowledge
  wire                    pd_ack;                         // Power down acknowledge
  wire                    ack_slave;                      // Slave acknowledge during low power statde
  wire                    pd_flush_req;                   // Flush request due to low power request
  wire                    nxt_pd_flush;
  reg                     pd_flush;                       // Flush due to low power request

  //Syncreq signal
  reg                     set_syncreqs;                   // set signal for syncreqs
  wire                    nxt_set_syncreqs;               // set signal for syncreqs
  wire                    nxt_syncreqs;

  reg                     isyncreqs;
  reg                     iafvalids;
  wire                    icsysack;


  genvar i;   // used for looping over the locations of FIFO
  genvar j;   // used for looping over the length of the FIFO pointers



  //----------------------------------------------------------------------------
  // start of code
  //----------------------------------------------------------------------------

  // Re-mapping of signal names

  //----------------------------------------------------------------------------
  // Inputs
  //----------------------------------------------------------------------------

   assign valid_src = atvalids;
   assign payload_src = {atids, atdatas , atbytess};

  //----------------------------------------------------------------------------
  // outputs
  //----------------------------------------------------------------------------
   assign atvalidm = valid_dst;
   assign atreadys = ready_src;
   assign {atidm, atdatam, atbytesm} = payload_dst;
   assign cactive = 1'b0;

  //----------------------------------------------------------------------------
  // syncreqs generation
  //----------------------------------------------------------------------------

  // set syncreqs when syncreqm and clkenm is sampled high
  // reset syncreqs when it is already set and clkens is high
  // reset has the priority over set as it is allowed to merge
  // 2 syncreqm occuring too close
  // syncreqs changes only when clkens is sampled high
  // syncreqm will be sampled only when the bridge is  not in low power state

  assign nxt_set_syncreqs =  clkens & set_syncreqs  ? 1'b0 :
                      (clkenm & syncreqm & csysreq & icsysack & ~set_syncreqs & ~clkens)| set_syncreqs;

  always @(posedge clk or negedge resetn)
  begin
    if (~resetn)
      set_syncreqs <= 1'b0;
    else
      set_syncreqs <= nxt_set_syncreqs;
  end

  assign nxt_syncreqs = ~isyncreqs & ((clkenm & syncreqm & csysreq & icsysack & clkens)|set_syncreqs);

  always @(posedge clk or negedge resetn)
  begin
    if (~resetn)
      isyncreqs <= 1'b0;
    else  if (clkens)
      isyncreqs <= nxt_syncreqs;
  end
  assign syncreqs = isyncreqs;

  //----------------------------------------------------------------------------
  // valid_dst;
  //----------------------------------------------------------------------------
  assign valid_dst = ivalid_dst;

  //----------------------------------------------------------------------------
  // ready_src;
  //----------------------------------------------------------------------------
  assign ready_src = iready_src;


  //----------------------------------------------------------------------------
  // Enable for loading the FIFO
  //----------------------------------------------------------------------------
  // When handshake completes on the slave side, enable is generated to load the
  // the location selected by the write pointer (wr_ptr). The signal
  // iready_src is only driven high when either of the payload registers are
  // empty, which ensures the payload cannot be overridden.

  generate
  for (i=0; i<FIFO_DEPTH; i=i+1)
  begin : p_fifo_load_en
    always @*
    begin
      fifo_load_en[i] = (i == wr_ptr[FIFO_PTR_WIDTH-1 :0] ) & load_en;
    end
  end  // p_fifo_load_en
  endgenerate



  //----------------------------------------------------------------------------
  // Write pointer implementation
  //----------------------------------------------------------------------------
  // Increment write pointer on each load of FIFO. The fifo is loaded when a
  // handshake occurs on the slave side (i.e load_en = 1)
  // when slave side flush due to power down request is completed stop
  // incrementing the pointers and stop loading
  // the data and when power down is acknowledged, FIFo Pointers are reset

  assign nxt_wr_ptr = (load_en & clkens ? wr_ptr+1'b1 : wr_ptr) & {FIFO_PTR_WIDTH+1{icsysack}};


  always @(posedge clk or negedge resetn)
  begin
    if (~resetn)
      wr_ptr <= {FIFO_PTR_WIDTH+1{1'b0}};
    else
      wr_ptr <= nxt_wr_ptr;
  end

  //----------------------------------------------------------------------------
  // wire load_en;
  //----------------------------------------------------------------------------
  // Enable signal for the register that selects which payload register will
  // be loaded next.  The control is updated when a handshake occurs on the
  // source interface.  The signal iready_src is only driven high when either of
  // the payload registers are empty, which ensures the payload cannot be
  // overridden.
  // Data will not be loaded when the bridge has completed the flush initiated due
  // to a power down request on the slave side

  assign load_en = valid_src & ~fifo_full & ~ack_slave;

  //----------------------------------------------------------------------------
  // Read pointer implementation
  // Increment read pointer on each read of FIFO. The fifo is read when a
  // handshake occurs on the master side (i.e load_en = 1)
  // When power down is acknowledged, FIFO pointers are reset
  //----------------------------------------------------------------------------

  assign nxt_rd_ptr = (inc_rd_ptr & clkenm ? rd_ptr+1'b1 : rd_ptr) & {FIFO_PTR_WIDTH+1{icsysack}};

  always @(posedge clk or negedge resetn)
  begin
    if (~resetn)
      rd_ptr <= {FIFO_PTR_WIDTH+1{1'b0}};
    else
      rd_ptr <= nxt_rd_ptr;
  end



  //----------------------------------------------------------------------------
  // wire inc_rd_ptr;
  //----------------------------------------------------------------------------
  // Read pointer will be incremented when the data on the master port is accepted
  // i.e. the handshake completes at the master port

  assign inc_rd_ptr = valid_dst & atreadym;


  //----------------------------------------------------------------------------
  // wire fifo_full;
  //----------------------------------------------------------------------------
  // FIFO is deemed full when rd_ptr equals wr_ptr with the exception of MSB

  assign nxt_fifo_full = (nxt_rd_ptr[FIFO_PTR_WIDTH] != nxt_wr_ptr[FIFO_PTR_WIDTH] ) &
         (nxt_rd_ptr[FIFO_PTR_WIDTH-1 :0] == nxt_wr_ptr[FIFO_PTR_WIDTH-1 :0] );

  always @(posedge clk or negedge resetn)
  begin
    if (~resetn)
      fifo_full <= 1'b0;
    else
      fifo_full <= nxt_fifo_full;
  end


  //----------------------------------------------------------------------------
  // wire fifo_empty;
  //----------------------------------------------------------------------------
  // FIFO is deemed empty if rd_ptr equals wr_ptr

  assign nxt_fifo_empty = (nxt_rd_ptr == nxt_wr_ptr);

  always @(posedge clk or negedge resetn)
  begin
    if (~resetn)
      fifo_empty <= 1'b1;
    else
      fifo_empty <= nxt_fifo_empty;
  end

  //----------------------------------------------------------------------------
  // wire iready_src;
  //----------------------------------------------------------------------------
  // If FIFO is not full then the component is ready to accept a payload
  // In case power down has been acknowledged, FIFO would be empty(as writes to
  // FIFO are blocked when the flush is completed and ready would be asserted high

  assign iready_src = ~fifo_full ;


  //----------------------------------------------------------------------------
  // wire ivalid_dst;
  //----------------------------------------------------------------------------
  // If FIFO holds a data, then destination can be issued a valid

  always @(posedge clk or negedge resetn)
  begin
    if (~resetn)
      valid_dst_reg <= 1'b0;
    else
      if (clkenm)
        valid_dst_reg <= ~nxt_fifo_empty;
  end

  assign ivalid_dst = valid_dst_reg;



  //----------------------------------------------------------------------------
  // FIFO
  //----------------------------------------------------------------------------
  // Holds transfer payload information.  A payload is loaded when a
  // handshake occurs on the source interface and this register has been
  // selected. see fifo_load_en for details
  //----------------------------------------------------------------------------

  generate
  for (i=0; i<FIFO_DEPTH; i=i+1)
  begin : gen_fifo

    always @(posedge clk)
    begin
      if (fifo_load_en[i] & clkens)
        fifo_payload[i] <= payload_src;
    end
  end // block : gen_fifo
  endgenerate


  //----------------------------------------------------------------------------
  // output enables
  // Decide which location of fifo to be output based on the rd_ptr value
  //----------------------------------------------------------------------------


  assign nxt_output_en[0] = (nxt_rd_ptr[FIFO_PTR_WIDTH-1 :0] == {FIFO_PTR_WIDTH{1'b0}});
  always @(posedge clk or negedge resetn)
  begin
    if (~resetn)
      output_en[0] <= 1'b1;
    else
      if ((inc_rd_ptr & clkenm) | ~icsysack)
        output_en[0] <= nxt_output_en[0] ;
  end

  generate
  for (i=1; i<FIFO_DEPTH; i=i+1)
  begin : gen_output_en
  assign nxt_output_en[i] = (nxt_rd_ptr[FIFO_PTR_WIDTH-1 :0] == i);
  always @(posedge clk or negedge resetn)
  begin
    if (~resetn)
      output_en[i] <= 1'b0;
    else
      if ((inc_rd_ptr & clkenm)| ~icsysack)
        output_en[i] <= nxt_output_en[i] ;
  end
  end // block: gen_output_en
  endgenerate


  //----------------------------------------------------------------------------
  // payload_dst
  //----------------------------------------------------------------------------

  always @*
  begin  : p_payload_out
    integer m,n;
    for (m=0; m<FIFO_DEPTH; m=m+1)
    begin :p_loop_fifo_location
      for (n=0; n<PAYLD_WIDTH; n=n+1)
      begin :p_loop_data_bits
          payload_out[n][m] = fifo_payload[m][n] & output_en[m] ;
      end  //block: p_loop_data_bits
    end // block: p_loop_fifo_location
  end // block: p_payload_out;

  always @*
  begin : p_payload_dst
  integer k;
   for (k=0;k<PAYLD_WIDTH;k=k+1)
      begin
      payload_dst[k] = | payload_out[k];
     end
  end // block: p_payload_dst




  //----------------------------------------------------------------------------
  // Flush logic implementation
  //----------------------------------------------------------------------------

  //----------------------------------------------------------------------------
  // Memorize the fifo location where the last data part of flush is loaded
  //----------------------------------------------------------------------------

  assign nxt_last_flush_data_ptr = (afreadys & iafvalids) ? wr_ptr-1'b1 : last_flush_data_ptr;

  always @(posedge clk or negedge resetn)
  begin : p_last_flush_data_ptr
    if (~resetn)
      last_flush_data_ptr <= {FIFO_PTR_WIDTH+1{1'b0}};
    else if(clkens)
      last_flush_data_ptr <= nxt_last_flush_data_ptr;
  end  // p_last_flush_data_ptr


  //----------------------------------------------------------------------------
  // Flush FSM consists of 4 states
  // F_IDLE                   :IDLE state. Looks for a flush_req to move into
  //                           F_SLAVE_FLUSH. Once power down is acknowledged,
  //                           FSM will stay in IDLE state till power is restored
  // F_SLAVE_FLUSH            :Flush on the Slave side. Wait for flush completion
  //                           on slave side to move into F_MASTER_FLUSH state
  //                           If there is no valid data in the FIFO then move to
  //                           F_FLUSH_COMPLETE
  // F_MSTR_FLUSH             :Flush on the master side. Wait for flush completion
  //                           on master side to F_FLUSH_COMPLETE state
  // F_FLUSH_COMPLETE         :Assert afreadym to indicate the completion of flush
  //----------------------------------------------------------------------------

  always @*
  begin

    nxt_flush_state = flush_state;
    case (flush_state)

    F_IDLE            : nxt_flush_state = ((afvalidm & ~iafreadym & pd_ack & clkenm) | pd_flush_req) ? F_SLAVE_FLUSH : F_IDLE;
    F_SLAVE_FLUSH    : nxt_flush_state = (afreadys & iafvalids & clkens) ? ((fifo_empty|last_slv_data_accepted_on_mstr)  ? F_FLUSH_COMPLETE :F_MSTR_FLUSH) : F_SLAVE_FLUSH;
    F_MSTR_FLUSH      : nxt_flush_state = last_data_xfer ? F_FLUSH_COMPLETE : F_MSTR_FLUSH;
    F_FLUSH_COMPLETE  : nxt_flush_state = clkenm ? F_IDLE : F_FLUSH_COMPLETE;
    default            : nxt_flush_state = F_UNDEFINED;
   endcase
  end


  always @(posedge clk or negedge resetn)
  begin
    if (~resetn)
     flush_state  <= F_IDLE;
    else
     flush_state  <= nxt_flush_state;
  end

// AFVALIDS is set when FSM moves to F_SLAVE_FLUSH and reset when FSM moves out of this state

  assign nxt_afvalids = ((nxt_flush_state== F_SLAVE_FLUSH) & ~iafvalids) ? 1'b1 : ~(nxt_flush_state != F_SLAVE_FLUSH & flush_state == F_SLAVE_FLUSH) & iafvalids ;

  always @(posedge clk or negedge resetn)
  begin
    if (~resetn)
     iafvalids  <= 1'b0;
    else if(clkens)
      iafvalids <= nxt_afvalids;
  end
  assign afvalids = iafvalids;


  assign wr_ptr_minus_one = wr_ptr-1'b1;
  assign last_slv_data_accepted_on_mstr = (wr_ptr_minus_one == rd_ptr) & atreadym & valid_dst & clkenm;
  assign last_data_xfer = (last_flush_data_ptr == rd_ptr)  & atreadym & valid_dst & clkenm;

  // In normal mode, afreadym is asserted when the flush fsm is in flush complete state
  // afreadym is asserted high immediately on afreadym when the bridge has acknowledged
  // the power down

  assign nxt_afreadym = ((nxt_flush_state == F_FLUSH_COMPLETE | (nxt_flush_state == F_IDLE & flush_state == F_FLUSH_COMPLETE)) & ~iafreadym) ;

  always @(posedge clk or negedge resetn)
  begin
    if (~resetn)
     iafreadym  <= 1'b1;
    else if (clkenm)
        iafreadym <= nxt_afreadym;
  end

  assign afreadym = iafreadym | (~icsysack );

  generate
    if (LPI_PRESENT ==1)
    begin :  gen_lpi
      //-------------------------------------------------------------------------------
      // LPI implementation
      //-------------------------------------------------------------------------------

      // Low power entry steps
      // Step 1: Low power entry request (csysreq asserted low)
      // step 2: request flush. If a flush is ongoing, the  wait for the flush to complete
      // step 3: Once a flush initiated by power down request completes on slave side,
      //         assert ATREADYS high and dont take in new data if csysreq is still low
      // step 4: On completion of flush on master side, assert csysack to 0
      // step 5: csysack deasserted one cycle after csysreq de-asserted and bridge comes back
      //         to active state
      // Note :  If CSYSREQ goes back to 1 before the flush is complete, then csysack will not
      //         go low

      // Initiate flush on a power down request
      // Power down request is indicated by csysreq going low

      assign pd_flush_req = ~csysreq & pd_ack &clkenm;

      // pd_flush indicates that flush has started due to power down request

      assign nxt_pd_flush = flush_state== F_IDLE ? pd_flush_req : pd_flush;
      always @(posedge clk or negedge resetn)
      begin
        if (~resetn)
           pd_flush <= 1'b0;
        else if(clkenm)
            pd_flush <= nxt_pd_flush;
      end


      // When the flush initiated due to power down completes on the slave side, always
      // assert the atreadys and block the writes to the buffer if csysreq is still low
      // Once a power down is acknowledged (csysack = 0), all transactions on the slave side
      // will be acknowledged without writing the buffer

      assign ack_slave = (pd_flush & (nxt_flush_state == F_MSTR_FLUSH |
                  nxt_flush_state == F_FLUSH_COMPLETE |
                  nxt_flush_state == F_IDLE )) | ~pd_ack;

      // Power down will be acknowledged when the flush is completed and FIFO is empty
      // csysack will stay high till csysreq gets de-asserted


      assign nxt_pd_ack = (pd_flush&flush_state == F_FLUSH_COMPLETE & clkenm)?csysreq: (pd_ack | csysreq);

      always @(posedge clk or negedge resetn)
      begin
        if (~resetn)
          pd_ack_i <= 1'b0;
        else if(clkenm)
            pd_ack_i <= nxt_pd_ack;
      end

      assign pd_ack = pd_ack_i;

  end // block: gen_lpi
  else
    begin // gen_no_lpi
      assign ack_slave = 1'b0;
      assign pd_flush_req = 1'b0;
      assign pd_ack = 1'b1;
    end // block: gen_no_lpi
  endgenerate


  assign icsysack = pd_ack ;
  assign csysack = icsysack ;



`ifdef ARM_ASSERT_ON
  //----------------------------------------------------------------------------
  // OVL Assertions
  //----------------------------------------------------------------------------

  //----------------------------------------------------------------------------
  // When FIFO is not full, transaction on slave side are always accepted
  //----------------------------------------------------------------------------
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
    "OVL Message : ATREADYS not asserted when FIFO is not full")
      uzovl_cxatbsyncbridge_atreadys_when_fifo_not_full
        (
         .clk         (clk),
         .reset_n     (resetn),
         .test_expr   (~atreadys & ~fifo_full)
        );

  //----------------------------------------------------------------------------
  // When FIFO is full, transaction on slave side will not be accepted
  //----------------------------------------------------------------------------
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
    "OVL Message : ATREADYS asserted when FIFO is full")
      uzovl_cxatbsyncbridge_atreadys_when_fifo_full
        (
         .clk         (clk),
         .reset_n     (resetn),
         .test_expr   (atreadys & fifo_full)
        );


  //----------------------------------------------------------------------------
  // Once low power request is acknowledged, all transactions on master
  // interface will be accpeted
  //----------------------------------------------------------------------------
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
    "OVL Message : ATREADYS low after power down acknowledge")
      uzovl_cxatbsyncbridge_atreadys_low_power
        (
         .clk         (clk),
         .reset_n     (resetn),
         .test_expr   (~atreadys & ~icsysack)
        );

  //----------------------------------------------------------------------------
  // Once low power request is acknowledged, all flush req on master
  // interface will always be accepted
  //----------------------------------------------------------------------------
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
    "OVL Message : AFREADYM low after power down acknowledge")
      uzovl_cxatbsyncbridge_afreadym_low_power
        (
         .clk         (clk),
         .reset_n     (resetn),
         .test_expr   (~afreadym & ~icsysack)
        );
  //----------------------------------------------------------------------------
  // Once low power request is acknowledged, no new flush requests will be
  // initiated on the slave side till low power request is removed
  //----------------------------------------------------------------------------
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
    "OVL Message : AFVALIDS high after power down acknowledge")
      uzovl_cxatbsyncbridge_afvalids_low_power
        (
         .clk         (clk),
         .reset_n     (resetn),
         .test_expr   (afvalids & ~icsysack)
        );


  //----------------------------------------------------------------------------
  // Low power request cannot be acknowledge if FIFO is not empty
  //----------------------------------------------------------------------------
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
    "OVL Message : fifo not empty before low power acknowledge")
      uzovl_cxatbsyncbridge_atready_low_power
        (
         .clk         (clk),
         .reset_n     (resetn),
         .test_expr   (~fifo_empty & ~icsysack)
        );

  //----------------------------------------------------------------------------
  // Syncreqs will not be asserted once the low power request is acknowledged
  //----------------------------------------------------------------------------
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
    "OVL Message : syncreqs is asserted after low power acknowledge")
      uzovl_cxatbsyncbridge_syncreqs_low_power
        (
         .clk         (clk),
         .reset_n     (resetn),
         .test_expr   (syncreqs & ~icsysack)
        );


`endif

endmodule // cxatbsyncbridge_full
