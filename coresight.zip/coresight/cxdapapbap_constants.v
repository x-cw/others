//-----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2003-2015 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//  Version and Release Control Information:
//
//
//  Checked In          : $Date: 2014-08-15 12:03:08 +0100 (Fri, 15 Aug 2014) $
//
//  File Revision       : $Revision: 39946 $
//
//  Release Information : CoreSight-SoC-TM100-r3p2-00rel0
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// Abstract : Debug Access Port APB Access Port (DAPAPBAP) - constants
//-----------------------------------------------------------------------------

//------------------------------------------------------------------------------
// NOT USER MODIFIED
//------------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// DAP slave interface state machine
//-----------------------------------------------------------------------------
localparam        ST_DAPAPB_IDLE    = 2'b00;
localparam        ST_DAPAPB_REG     = 2'b01;
localparam        ST_DAPAPB_APB     = 2'b10;
localparam        ST_DAPAPB_RDY     = 2'b11;
localparam        ST_DAPAPB_UNDEF   = 2'bxx;

//-----------------------------------------------------------------------------
// APB master interface state machine
//-----------------------------------------------------------------------------
localparam        ST_APBAP_IDLE     = 2'b00;
localparam        ST_APBAP_ADDR     = 2'b01;
localparam        ST_APBAP_RDY      = 2'b10;
localparam        ST_APBAP_UNDEF    = 2'bxx;

//-----------------------------------------------------------------------------
// APB-AP registers
//-----------------------------------------------------------------------------
localparam        APB_CSWREG        = 6'b000000;
localparam        APB_TAREG         = 6'b000001;
localparam        APB_DRWREG        = 6'b000011;
localparam        APB_BD0REG        = 6'b000100;
localparam        APB_BD1REG        = 6'b000101;
localparam        APB_BD2REG        = 6'b000110;
localparam        APB_BD3REG        = 6'b000111;
localparam        APB_ROMREG        = 6'b111110;
localparam        APB_IDREG         = 6'b111111;

//-----------------------------------------------------------------------------
// Miscellaneous
//-----------------------------------------------------------------------------
localparam        APB_ADDR_INC      = 1'b1;
localparam        ID_REG_APBAP      = 32'h54770002;
