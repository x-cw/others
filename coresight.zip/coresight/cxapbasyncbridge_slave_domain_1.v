//-----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2007-2015 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//  Version and Release Control Information:
//
//  File Revision       : $Revision: 41969 $
//  File Date           : $Date: 2015-03-09 14:04:25 +0000 (Mon, 09 Mar 2015) $
//
//  Release Information : CoreSight-SoC-TM100-r3p2-00rel0
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// Slave interface side of the apb asynchronous bridge
//-----------------------------------------------------------------------------

module cxapbasyncbridge_slave_domain_1
(
  //----------------------------------------------------------------------------
  // Port Declarations
  //----------------------------------------------------------------------------

  // Bus
  input  wire  [31:0]     paddrs,        //address of  bus
  input  wire  [31:0]     pwdatas,       //write data of  bus
  input  wire             pwrites,       //read/write control of  bus
  input  wire             penables,      //enable of  bus
  input  wire             psels,         //peripheral select of  bus
  
  output wire [31:0]      prdatas,       //read data of  bus
  output wire             pslverrs,      //error response of  bus
  output wire             preadys,       //ready of  bus

  //Inter-domain  bus
  output wire             apbm_req_async,           // Transaction req signal
  input  wire             apbm_ack_async,           // Transaction ack signal
  output wire [64:0]      apbm_fwd_data_async,      // Transaction Forward Payload
  input  wire  [32:0]     apbm_rev_data_async,      // Transaction Reverse Payload
    // Abort request to master

    

  //Clock and reset signals
  input wire              pclkens,       // clock enable (slave)
  input wire              pclks,         // clock (slave)
  input wire              presetsn       // reset (slave)

);


  //----------------------------------------------------------------------------
  // Wire Declaration
  //----------------------------------------------------------------------------

  wire              pending_req;
  reg               hs_req_q;
  wire              nxt_hs_req;
  wire              hs_req_en;
  reg               pready_q;
  wire              clk_ready_en;

  wire              nxt_pready_q;

  wire              apbm_ack_corrupt_async;
  wire              apbm_ack_sync;

  wire              apbm_req_sync;

  wire      [32:0]  apbm_rev_data_corrupt_async;

  wire              capture_en;
  wire              clk_fwd_en;
  wire      [64:0]  apbm_fwd_data_sync;

  wire      [32:0]  apbm_rev_data_capt;
  

  //----------------------------------------------------------------------------
  //                Slave interface req -> Master interface
  //----------------------------------------------------------------------------

  // Handshake is initiated when there's a pending request
  // (PSEL high) and when previous transfer is completed (synchronized
  // acknowledge from master domain is low)

  assign pending_req = psels;

  assign hs_req_en  = pclkens & 
                    ((~hs_req_q & pending_req ) |
                     (hs_req_q & apbm_ack_sync));
  assign nxt_hs_req = ~apbm_ack_sync & pending_req & ~pready_q ;

  always @ (posedge pclks or negedge presetsn)
    if (~presetsn)
      hs_req_q <= 1'b0;
    else if (hs_req_en)
      hs_req_q <= nxt_hs_req;

  //----------------------------------------------------------------------------
  //                Master interface ack -> Slave interface
  //----------------------------------------------------------------------------
  // preadym will be asserted when the ack is
  // received from the master interface.
  // 
  //----------------------------------------------------------------------------

  assign clk_ready_en = pclkens & (apbm_ack_sync & hs_req_q | pready_q );

  assign nxt_pready_q = (apbm_ack_sync & hs_req_q ) ;

  always @ (posedge pclks or negedge presetsn)
    if (~presetsn)
      pready_q <= 1'b1;
    else if (clk_ready_en)
      pready_q <= nxt_pready_q;

  assign preadys = pready_q;







  //----------------------------------------------------------------------------
  // Incoming Ack
  //----------------------------------------------------------------------------

  // Test component to corrupt ack going into synchroniser
  cxapbasyncbridge_cdc_corrupt_gry #(.WIDTH(1)) u_cdc_corrupt_ack
  (
      .clk       (pclks),
      .resetn    (presetsn),
      .sync      (1'b0),
      .d_async   (apbm_ack_async),
      .q_async   (apbm_ack_corrupt_async)
  );

  // Synchroniser to bring the ack into the clock domain
  cx_en_sync  u_cdc_sync_ack
  (
      .clk       (pclks),
      .clken     (1'b1),
      .resetn    (presetsn),
      .sync_di   (apbm_ack_corrupt_async),
      .sync_do   (apbm_ack_sync)
  );

  //----------------------------------------------------------------------------
  // Incoming Data
  //----------------------------------------------------------------------------

  // Test component to corrupt data
  cxapbasyncbridge_cdc_corrupt #(.WIDTH(33)) u_cdc_corrupt_rev_data
  (
      .clk       (pclks),
      .sync      (1'b0),
      .d         (apbm_rev_data_async),
      .q         (apbm_rev_data_corrupt_async)
  );

  // Test component to check for corrupted data
  cxapbasyncbridge_cdc_capt #(.WIDTH(33)) u_cdc_capt_rev
  (
      .clk       (pclks),
      .resetn    (presetsn),
      .q         (apbm_rev_data_capt),
      .d_async   (apbm_rev_data_corrupt_async),
      .enable    (capture_en)
  );

  assign capture_en = hs_req_q & apbm_ack_sync & pclkens;

  // Expand Reverse Payload
  assign prdatas = apbm_rev_data_capt[32:1];
  assign pslverrs = apbm_rev_data_capt[0] ;

  //----------------------------------------------------------------------------
  // Outgoing Req
  //----------------------------------------------------------------------------

  cxapbasyncbridge_cdc_launch_gry #(.WIDTH(1)) u_cdc_launch_req
  (
      .clk       (pclks),
      .resetn    (presetsn),
      .enable    (hs_req_en),
      .in_cdc    (apbm_req_sync),
      .out_async (apbm_req_async)
  );

  assign apbm_req_sync = nxt_hs_req;

  //----------------------------------------------------------------------------
  // Outgoing Data
  //----------------------------------------------------------------------------

  // Test component and registering
  cxapbasyncbridge_cdc_launch_data #(.WIDTH(65)) u_cdc_launch_fwd_data
  (
     .clk       (pclks),
     .resetn    (presetsn),
     .enable    (clk_fwd_en),
     .in_cdc    (apbm_fwd_data_sync),
     .out_async (apbm_fwd_data_async));

  // Generate Clock Enable
  assign clk_fwd_en = ~hs_req_q & ~pready_q & pending_req & pclkens;

  // Concatenate Forward Payload
  assign apbm_fwd_data_sync = {paddrs, pwdatas, pwrites};




`ifdef ARM_ASSERT_ON

  //----------------------------------------------------------------------------
  // OVL Assertions
  //----------------------------------------------------------------------------
  

  //----------------------------------------------------------------------------
  // fwd_data should not change when the request is active
  // This can be checked by monitoring clk_fwd_en
  //----------------------------------------------------------------------------
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
    "OVL Message : fwd_data changing during the transaction")
      uzovl_cxapbasyncbridge_fwd_data_stable
        (
         .clk         (pclks),
         .reset_n     (presetsn),
         .test_expr   (clk_fwd_en & hs_req_q & pclkens)
        );
  



`endif

endmodule
