`include "../general/general.vh"

module gp_clr_fifo_async_core(din, rd_reset_n, rd_clk, rd_en, wr_reset_n, wr_clk, wr_en,
  aempty, afull, dout, empty, full, overflow, underflow, valid_entries, wr_clear, rd_clear
  );
  // If have RD_REG and SAME_SYNC, then the number of usabel words is 2**LOG2WORDS.
  //   If have !RD_REG, add 1 for output holding register.
  //   If have !SAME_SYNC, subtract 1 since rd/wr ptrs cannot be equal.
  parameter LOG2WORDS = 0;         // log base 2 of number of entries = # address bits
  parameter WIDTH = 0;             // # bits per word
  parameter WR_SYNC = 1;           // 1: write port is synchronous (free running clock), 0: asynchronous (strobe)
  `define WORDS (2**LOG2WORDS)     // number of fifo entries
  parameter AFULL_THRESH = `WORDS; // min # of valid entries that triggers 'almost full' flag
  parameter RD_SYNC = 1;           // 1: read port is synchronous (free running clock), 0: asynchronous (strobe)
  parameter AEMPTY_THRESH = 0;     // max # of valid entries that triggers 'almost empty' flag
  parameter SAME_SYNC = (RD_SYNC && WR_SYNC); 
    // 1: if WR_SYNC and RD_SYNC, indicates wr_clk is same as rd_clk, 0: separate rd/wr clks
  parameter RD_REG = 0;            // 1: use registered fifo output directly (else emulate unregistered)
  parameter FULL_FLOP = 0 ; 
  parameter VALID_ENTRIES_SYNC_RD_CLK = 0; // 0=valid_entries sync to wr_clk, 1=sync to rd_clk
  parameter MODULE_NAME = "NONE"; // 0=valid_entries sync to wr_clk, 1=sync to rd_clk

  input wire wr_reset_n;           // resets fifo to empty, clears under/overflow flags
  input wire wr_clear;
  input wire rd_reset_n;           // resets fifo to empty, clears under/overflow flags
  input wire rd_clear;

  // all signals in this group are synchronized to wr_clk
  input wire wr_clk;            // write port clock (or async strobe - writes on trailing falling edge)
  input wire wr_en;             // if WR_SYNC indicates valid 'wr_data', else ignored (qualifies wr_clk)
  input wire [WIDTH-1:0] din;   // write data
  output wire full;             // fifo is full (WORDS entries if SAME_SYNC, else WORDS-1)
  output wire afull;            // almost full - fifo has has >= AFULL_THRESH valid entries
  output reg overflow;          // '1' if wrote when full since last reset_n
  output wire [LOG2WORDS:0] valid_entries; // number of filled entries

  // all signals in this group are synchronized to rd_clk
  input wire rd_clk;            // read port clock (or async strobe - reads on trailing falling edge)
  input wire rd_en;             // if RD_SYNC reading on 'rd_data' this rd_clk, else ignored
  output wire [WIDTH-1:0] dout; // read data
  output wire empty;            // fifo has no valid entries
  output wire aempty;           // almost empty - fifo has <= AEMPTY_THRESH valid entries
  output reg underflow;         // '1' if read when empty since last reset_n
  
  wire [LOG2WORDS-1:0] wr_addr;    // write address for fifo RAM
  wire [LOG2WORDS-1:0] rd_addr;    // read address for fifo RAM
  wire fifo_ctl_empty;             // fifo empty from point-of-view of gp_fifo_ctl
  wire [LOG2WORDS:0] fifo_valid_entries; // number of entries from point-of-view of gp_fifo_ctl
  
    // signals for what will actually go to the fifo ctl/ram
    wire actual_wr_clk;
    wire actual_wr_en;
    wire actual_rd_clk;
    wire actual_rd_en;
    reg actual_rd_en_dly;
   wire [WIDTH-1:0] dout_tmp; 
   reg [WIDTH-1:0] actual_rdata; 
    
  generate
    // sync and async ports modify how clocks/enables are connected (or not used)
    if (WR_SYNC) begin: ws
      assign actual_wr_clk = wr_clk;
      assign actual_wr_en  = wr_en;
    end
    else begin: wa
      assign actual_wr_clk = ~wr_clk; // invert async strobe so clocks on trailing (rising) edge
      assign actual_wr_en  = 1'b1;
    end
    
    if (RD_SYNC) begin: rs
      assign actual_rd_clk = rd_clk;
      if (RD_REG) begin: rr
        assign actual_rd_en  = rd_en; // expose registered fifo output directly (pipelined read)
        assign empty = fifo_ctl_empty;
        assign valid_entries = fifo_valid_entries;
      end
      else begin: ur
        // emulate unregistered fifo output (non-pipelined read)
        gp_clr_fifo_out_ctl gfoc (
          .rd_reset_n(rd_reset_n),
          .rd_clk(actual_rd_clk),
          .rd_en(rd_en),
          .rd_clear(rd_clear),
          .fifo_array_empty(fifo_ctl_empty),
          .actual_fifo_empty(empty),
          .fifo_rd_en(actual_rd_en)
          );
        // add 1 to number of entries if using extra holding register at output
        assign valid_entries = fifo_valid_entries + (empty ? 1'b0 : 1'b1);
        // bad fix: assign valid_entries = fifo_valid_entries + (fifo_ctl_empty ? 1'b0 : 1'b1);
      end
    end
    else begin: ra
      assign actual_rd_clk = ~rd_clk; // invert async strobe so clocks on trailing (rising) edge
      assign actual_rd_en  = 1'b1;
      assign empty = fifo_ctl_empty;
      assign valid_entries = fifo_valid_entries;
    end
  endgenerate

  gp_clr_fifo_ctl
    #(.LOG2WORDS(LOG2WORDS), .WR_SYNC(WR_SYNC), .RD_SYNC(RD_SYNC), .SAME_SYNC(SAME_SYNC),
      .AEMPTY_THRESH(AEMPTY_THRESH), .AFULL_THRESH(AFULL_THRESH), .FULL_FLOP(FULL_FLOP),
      .VALID_ENTRIES_SYNC_RD_CLK(VALID_ENTRIES_SYNC_RD_CLK))
    gpf (
    .wr_reset_n(wr_reset_n),
    .wr_clear(wr_clear),
    .rd_reset_n(rd_reset_n),
    .rd_clear(rd_clear),
    .wr_clk(actual_wr_clk),
    .wr_en(actual_wr_en),
    .wr_addr(wr_addr),
    .afull(afull),
    .full(full),
    .rd_clk(actual_rd_clk),
    .rd_en(actual_rd_en),
    .rd_addr(rd_addr),
    .aempty(aempty),
    .empty(fifo_ctl_empty),
    .valid_entries(fifo_valid_entries)
    );

`ifndef ASIC_MEM

  mem_1r1w
    #(.MEM_WORDS(`WORDS), .MEM_WIDTH(WIDTH)) 
    ram (
    .wr_clk(actual_wr_clk),
    .wr_en(actual_wr_en),
    .wr_addr(wr_addr),
    .din(din),
    .rd_clk(actual_rd_clk),
    .rd_en(actual_rd_en),
    .rd_addr(rd_addr),
    .dout(dout_tmp)
    );

`else
generate
if (MODULE_NAME == "AI_SR")
 begin:afifo_ai_sr
   ai_sr_fifo_abstraction #(

   .FIFO_WORD(`WORDS),
   .FIFO_WIDTH(WIDTH),
   .FIFO_LOG2WORD(LOG2WORDS)
   ) ai_si_abstraction_async(

    .wr_clk(actual_wr_clk),
    .wr_en(actual_wr_en),
    .wr_addr(wr_addr),
   .wr_data(din[WIDTH-1:0]),
   .wr_strb({WIDTH{1'b0}}),
    .rd_clk(actual_rd_clk),
    .rd_en(actual_rd_en),
    .rd_addr(rd_addr),
   .rd_data(dout_tmp[WIDTH-1:0])
    );
   end


else if (MODULE_NAME == "PCIE_CTR_ITC")
 begin:ITC_pcie_slv_aw_w_lock_R2F
     wire [583:0] dout_i;
     assign dout_tmp = dout_i[576:0];
     ITC_pcie_slv_aw_w_lock_dp2_d16_w144_wrapper
     ITC_pcie_slv_aw_w_lock_R2F_0 (
     .CLKA       (actual_wr_clk),
     .WEA        (actual_wr_en ),
     .AA         (wr_addr),
     .D          (din[143:0]),
     .CLKB       (actual_rd_clk),
     .REB        (actual_rd_en ),
     .AB         (rd_addr),
     .Q          (dout_i[143:0])
    );
     ITC_pcie_slv_aw_w_lock_dp2_d16_w144_wrapper
     ITC_pcie_slv_aw_w_lock_R2F_1 (
     .CLKA       (actual_wr_clk),
     .WEA        (actual_wr_en ),
     .AA         (wr_addr),
     .D          (din[287:144]),
     .CLKB       (actual_rd_clk),
     .REB        (actual_rd_en ),
     .AB         (rd_addr),
     .Q          (dout_i[287:144])
    );

     ITC_pcie_slv_aw_w_lock_dp2_d16_w148_wrapper
     ITC_pcie_slv_aw_w_lock_R2F_2 (
     .CLKA       (actual_wr_clk),
     .WEA        (actual_wr_en ),
     .AA         (wr_addr),
     .D          (din[435:288]),
     .CLKB       (actual_rd_clk),
     .REB        (actual_rd_en ),
     .AB         (rd_addr),
     .Q          (dout_i[435:288])
    );
     ITC_pcie_slv_aw_w_lock_dp2_d16_w148_wrapper
     ITC_pcie_slv_aw_w_lock_R2F_3 (
     .CLKA       (actual_wr_clk),
     .WEA        (actual_wr_en ),
     .AA         (wr_addr),
     .D          ({7'd0,din[576:436]}),
     .CLKB       (actual_rd_clk),
     .REB        (actual_rd_en ),
     .AB         (rd_addr),
     .Q          (dout_i[583:436])
    );


 end




else if (MODULE_NAME == "PCIE_CTR")
 begin:pcie_slv_aw_w_lock_R2F
     wire [583:0] dout_i;
     assign dout_tmp = dout_i[576:0];
     pcie_slv_aw_w_lock_dp2_d16_w144_wrapper
     pcie_slv_aw_w_lock_R2F_0 (
     .CLKA       (actual_wr_clk),
     .WEA        (actual_wr_en ),
     .AA         (wr_addr),
     .D          (din[143:0]),
     .CLKB       (actual_rd_clk),
     .REB        (actual_rd_en ),
     .AB         (rd_addr),
     .Q          (dout_i[143:0])
    );
     pcie_slv_aw_w_lock_dp2_d16_w144_wrapper
     pcie_slv_aw_w_lock_R2F_1 (
     .CLKA       (actual_wr_clk),
     .WEA        (actual_wr_en ),
     .AA         (wr_addr),
     .D          (din[287:144]),
     .CLKB       (actual_rd_clk),
     .REB        (actual_rd_en ),
     .AB         (rd_addr),
     .Q          (dout_i[287:144])
    );

     pcie_slv_aw_w_lock_dp2_d16_w148_wrapper
     pcie_slv_aw_w_lock_R2F_2 (
     .CLKA       (actual_wr_clk),
     .WEA        (actual_wr_en ),
     .AA         (wr_addr),
     .D          (din[435:288]),
     .CLKB       (actual_rd_clk),
     .REB        (actual_rd_en ),
     .AB         (rd_addr),
     .Q          (dout_i[435:288])
    );
     pcie_slv_aw_w_lock_dp2_d16_w148_wrapper
     pcie_slv_aw_w_lock_R2F_3 (
     .CLKA       (actual_wr_clk),
     .WEA        (actual_wr_en ),
     .AA         (wr_addr),
     .D          ({7'd0,din[576:436]}),
     .CLKB       (actual_rd_clk),
     .REB        (actual_rd_en ),
     .AB         (rd_addr),
     .Q          (dout_i[583:436])
    );


 end





else if (MODULE_NAME == "PCIE_CTR_DMA")
 begin:pcie_slv_aw_w_lock_R2F
     wire [583:0] dout_i;
     assign dout_tmp = dout_i[576:0];
     pcie_slv_aw_w_lock_dp2_d64_w144_wrapper
     pcie_slv_aw_w_lock_R2F_0 (
     .CLKA       (actual_wr_clk),
     .WEA        (actual_wr_en ),
     .AA         (wr_addr),
     .D          (din[143:0]),
     .CLKB       (actual_rd_clk),
     .REB        (actual_rd_en ),
     .AB         (rd_addr),
     .Q          (dout_i[143:0])
    );
     pcie_slv_aw_w_lock_dp2_d64_w144_wrapper
     pcie_slv_aw_w_lock_R2F_1 (
     .CLKA       (actual_wr_clk),
     .WEA        (actual_wr_en ),
     .AA         (wr_addr),
     .D          (din[287:144]),
     .CLKB       (actual_rd_clk),
     .REB        (actual_rd_en ),
     .AB         (rd_addr),
     .Q          (dout_i[287:144])
    );

     pcie_slv_aw_w_lock_dp2_d64_w148_wrapper
     pcie_slv_aw_w_lock_R2F_2 (
     .CLKA       (actual_wr_clk),
     .WEA        (actual_wr_en ),
     .AA         (wr_addr),
     .D          (din[435:288]),
     .CLKB       (actual_rd_clk),
     .REB        (actual_rd_en ),
     .AB         (rd_addr),
     .Q          (dout_i[435:288])
    );
     pcie_slv_aw_w_lock_dp2_d64_w148_wrapper
     pcie_slv_aw_w_lock_R2F_3 (
     .CLKA       (actual_wr_clk),
     .WEA        (actual_wr_en ),
     .AA         (wr_addr),
     .D          ({7'd0,din[576:436]}),
     .CLKB       (actual_rd_clk),
     .REB        (actual_rd_en ),
     .AB         (rd_addr),
     .Q          (dout_i[583:436])
    );


 end




else if (MODULE_NAME == "PDP")
 begin:afifo_pdp
   pdp_fifo_abstraction #(

   .FIFO_WORD(`WORDS),
   .FIFO_WIDTH(WIDTH),
   .FIFO_LOG2WORD(LOG2WORDS)
   ) pdp_abstraction_async(

    .wr_clk(actual_wr_clk),
    .wr_en(actual_wr_en),
    .wr_addr(wr_addr),
    .wr_data(din[WIDTH-1:0]),
    .wr_strb({WIDTH{1'b0}}),
    .rd_clk(actual_rd_clk),
    .rd_en(actual_rd_en),
    .rd_addr(rd_addr),
    .rd_data(dout_tmp[WIDTH-1:0])
    );
 end

else if (MODULE_NAME == "WAVE517")
 begin:afifo_wave517
     wave517_fifo_abstraction #(

        .FIFO_WORD(`WORDS),
        .FIFO_WIDTH(WIDTH),
        .FIFO_LOG2WORD(LOG2WORDS)

    ) wave517_abstraction_async(
       .wr_clk(actual_wr_clk),
       .wr_en(actual_wr_en),
       .wr_addr(wr_addr),
       .wr_data(din[WIDTH-1:0]),
       .wr_strb({WIDTH{1'b0}}),
       .rd_clk(actual_rd_clk),
       .rd_en(actual_rd_en),
       .rd_addr(rd_addr),
       .rd_data(dout_tmp[WIDTH-1:0])
   );
end

   else begin :mem_UNDEFxUNDEF
     //MEMORY_CASE_LINES_END
   
`ifdef MEM_NOT_FATAL_IF_NOT_DEFINED
          initial assert (0) else
            $warning("MEMORY 1r1w %dx%d requested but not built",`WORDS,WIDTH);
               mem_1r1w
     #(.MEM_WORDS(`WORDS), .MEM_WIDTH(WIDTH)) 
     ram (
    	.wr_clk(actual_wr_clk),
    	.wr_en(actual_wr_en),
    	.wr_addr(wr_addr),
    	.din(din),
    	.rd_clk(actual_rd_clk),
    	.rd_en(actual_rd_en),
    	.rd_addr(rd_addr),
    	.dout(dout_tmp)
        );

`else
initial assert (0) else
            $fatal("MEMORY %dx%d requested but not built",`WORDS,WIDTH);
          mem_model_not_defined #(
                                  .MEM_WORDS(`WORDS),
                                  .MEM_WIDTH(WIDTH)
                                  ) mem();

`endif
end
endgenerate

`endif



  // under and over flow flag generation
  always @(posedge actual_wr_clk, negedge wr_reset_n) begin
    if (!wr_reset_n)        overflow <= 1'b0;
    else if(wr_clear)       overflow <= 1'b0;
    else if (wr_en && full) overflow <= 1'b1;
  end
  
  always @(posedge actual_rd_clk, negedge rd_reset_n) begin
    if (!rd_reset_n)         underflow <= 1'b0;
    else if(rd_clear)        underflow <= 1'b0;
    else if (rd_en && empty) underflow <= 1'b1;
  end
 always @(posedge actual_rd_clk, negedge rd_reset_n) begin
    if (!rd_reset_n)         actual_rd_en_dly <= 1'b0;
    else                     actual_rd_en_dly <= actual_rd_en;
  end

 always @(posedge actual_rd_clk, negedge rd_reset_n) begin
    if (!rd_reset_n)         actual_rdata <= {(WIDTH){1'b0}};
    else if (actual_rd_en_dly) actual_rdata <= dout_tmp;
  end
assign dout = actual_rd_en_dly ? dout_tmp : actual_rdata;
//assign dout = dout_tmp;//actual_rdata;

  //`ifdef SIMULATING
  //ovl_never #(.msg("fifo overflow"))  ovl3( wr_clk, wr_reset_n, 1'b1, wr_en && full,);
  //ovl_never #(.msg("fifo underflow")) ovl4(rd_clk, rd_reset_n, 1'b1, rd_en && empty,);
  //ovl_proposition #(.msg("fifo must have RD_REG if !RD_SYNC"))
  //  ovl5(wr_reset_n, 1'b1, RD_SYNC || RD_REG,);
  //`endif
endmodule // gp_fifo_async_core
