//------------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2003-2013 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//    Checked In : $Date: 2013-09-12 19:02:23 +0100 (Thu, 12 Sep 2013) $
//    Revision   : $Revision: 37221 $
//    Release    : CoreSight-SoC-TM100-r3p1-00rel0
//------------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// Abstract : Debug Access Port AHB Access Port (DAPAHBAP)- dapclk Synchronizers
//------------------------------------------------------------------------------
//
// DAPAHBAP - Debug Access Port AHB Access Port
// --------------------------------------------
//
// Debug Access Port AHB Access Port component provides an AHB-Lite interface to
// a System On Chip (SOC).
//
// cxdapahbap_dap_sync.v
// -----------------
//
// cxdapahbap_dap_sync.v provides the dapclk domain synchronizers for the DAPAHBAP
// block.
//
// Instantiated blocks
// -------------------
// cx_en_sync.v      - 2 DFF synchronizer module, reset low
// Can be replaced with a 3 stage DFF synchronizer if required.
//------------------------------------------------------------------------------

module cxdapahbap_dap_sync (
  // Inputs
  dapclk, dapclken, dapresetn, dbgen, spiden, ahb_state_dbg,
  // Outputs
  dbgen_sync, spid_en_sync, ahb_state_sync
  );

  //----------------------------------------------------------------------------
  // Inputs
  //----------------------------------------------------------------------------
  input         dapclk;          // DAP clock
  input         dapclken;        // DAP clock enable
  input         dapresetn;       // DAP asynchronous reset active low

  input         dbgen;           // AHB-AP debug enable
  input         spiden;          // AHB-AP secure transfers enable
  input [2:0]   ahb_state_dbg;   // AHB state from AHB interface

  //----------------------------------------------------------------------------
  // Outputs
  //----------------------------------------------------------------------------
  output        dbgen_sync;      // Synchronized debug enable
  output        spid_en_sync;    // Synchronized secure transfers enable
  output [2:0]  ahb_state_sync;  // Synchronized AHB state

  //---------------------------------------------------------------------------
  //
  // Main body of code
  // =================
  //
  //---------------------------------------------------------------------------

  //---------------------------------------------------------------------------
  // Double synchronizer instantiation for dbgen signal.
  //---------------------------------------------------------------------------
  cx_en_sync u_ahbap_dap_sync_0
    (
     // Outputs
     .sync_do                    (dbgen_sync),
     // Inputs
     .clk                        (dapclk),
     .clken                      (dapclken),
     .resetn                     (dapresetn),
     .sync_di                    (dbgen)
     );

  //---------------------------------------------------------------------------
  // Double synchronizer instantiation for spiden signal.
  //---------------------------------------------------------------------------
  cx_en_sync u_ahbap_dap_sync_1
    (
     // Outputs
     .sync_do                    (spid_en_sync),
     // Inputs
     .clk                        (dapclk),
     .clken                      (dapclken),
     .resetn                     (dapresetn),
     .sync_di                    (spiden)
     );

  //---------------------------------------------------------------------------
  // Double synchronizer instantiation for ahb_state_sync[0] signal.
  //---------------------------------------------------------------------------
  cx_en_sync u_ahbap_dap_sync_2
    (
     // Outputs
     .sync_do                    (ahb_state_sync[0]),
     // Inputs
     .clk                        (dapclk),
     .clken                      (dapclken),
     .resetn                     (dapresetn),
     .sync_di                    (ahb_state_dbg[0])
     );

  //---------------------------------------------------------------------------
  // Double synchronizer instantiation for ahb_state_sync[1] signal.
  //---------------------------------------------------------------------------
  cx_en_sync u_ahbap_dap_sync_3
    (
     // Outputs
     .sync_do                    (ahb_state_sync[1]),
     // Inputs
     .clk                        (dapclk),
     .clken                      (dapclken),
     .resetn                     (dapresetn),
     .sync_di                    (ahb_state_dbg[1])
     );

  //---------------------------------------------------------------------------
  // Double synchronizer instantiation for ahb_state_sync[2] signal.
  //---------------------------------------------------------------------------
  cx_en_sync u_ahbap_dap_sync_4
    (
     // Outputs
     .sync_do                    (ahb_state_sync[2]),
     // Inputs
     .clk                        (dapclk),
     .clken                      (dapclken),
     .resetn                     (dapresetn),
     .sync_di                    (ahb_state_dbg[2])
     );

endmodule // cxdapahbap_dap_sync
