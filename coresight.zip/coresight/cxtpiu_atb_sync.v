//-----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2004-2015 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//    Checked In : $Date: 2014-08-14 16:01:35 +0100 (Thu, 14 Aug 2014) $
//    Revision   : $Revision: 39945 $
//    Release    : CoreSight-SoC-TM100-r3p2-00rel0
//-----------------------------------------------------------------------------
//  Purpose             : Double Synchronizer for FIFO module in TPIU block.
//-----------------------------------------------------------------------------

module cxtpiu_atb_sync  (
  // Inputs
  atclk, atclken, atresetn, rd_ptr_gray, trig_port_sync, trigin, flushin,
  // Outputs
  rd_ptr_gray_sync, trig_port_done_sync, trigin_sync, flushin_sync
  );


  // Inputs
  input         atclk;          // ATB clock
  input         atclken;        // ATB Clock enable
  input         atresetn;       // ATB asychronous reset active low
  input [3:0]   rd_ptr_gray;    // Read pointer from the read clock domain
  input         trig_port_sync; // Straight turn around of the trig_port request
  input         trigin;         // External Trigger request
  input         flushin;        // External Flush request

  // Outputs
  output [3:0]  rd_ptr_gray_sync;    // Read pointer to the write clock domain
  output        trig_port_done_sync; // indicator to clear the trig_port signal
  output        trigin_sync;         // External Trigger request
  output        flushin_sync;        // External Flush request

  // ---------------------------------------------------------------------------
  //                     Synchronizers For atclk Domain
  //                     ==============================
  // ---------------------------------------------------------------------------
  // Overview
  // ========
  // Synchronizers for the signals of the TPIU block in the atclk domain.
  // Converts: rd_ptr_gray (TraceFIFO) from traceclkin
  //           trig_port_sync (TraceSync) [used in RegT] from traceclkin
  // ---------------------------------------------------------------------------

  wire [3:0] rd_ptr_gray_corrupt;
  wire       trig_port_sync_corrupt;
  wire       trigin_corrupt;
  wire       flushin_corrupt;

  // ---------------------------------------------------------------------------
  // Corrupt blocks
  // ---------------------------------------------------------------------------
  cx_cdc_corrupt_gry #(4) u_rd_ptr_corrupt (
    .clk      (atclk),
    .resetn   (atresetn),
    .sync     (1'b0),
    .d_async  (rd_ptr_gray),
    .q_async  (rd_ptr_gray_corrupt));

  cx_cdc_corrupt_gry #(1) u_trig_port_corrupt (
    .clk      (atclk),
    .resetn   (atresetn),
    .sync     (1'b0),
    .d_async  (trig_port_sync),
    .q_async  (trig_port_sync_corrupt));

  cx_cdc_corrupt_gry #(1) u_trig_in_corrupt (
    .clk      (atclk),
    .resetn   (atresetn),
    .sync     (1'b0),
    .d_async  (trigin),
    .q_async  (trigin_corrupt));

  cx_cdc_corrupt_gry #(1) u_flush_in_corrupt (
    .clk      (atclk),
    .resetn   (atresetn),
    .sync     (1'b0),
    .d_async  (flushin),
    .q_async  (flushin_corrupt));

  // ---------------------------------------------------------------------------
  // Instantiating the cx_en_sync module for synchronizing rd_ptr_gray[0] bit.
  // ---------------------------------------------------------------------------
  cx_en_sync u_rd_ptr_gray_0 (
                          // Outputs
                          .sync_do          (rd_ptr_gray_sync[0]),
                          // Inputs
                          .clk              (atclk),
                          .clken            (atclken),
                          .resetn           (atresetn),
                          .sync_di          (rd_ptr_gray_corrupt[0]));

  // ---------------------------------------------------------------------------
  // Instantiating the cx_en_sync module for synchronizing rd_ptr_gray[1] bit.
  // ---------------------------------------------------------------------------
  cx_en_sync u_rd_ptr_gray_1 (
                          // Outputs
                          .sync_do          (rd_ptr_gray_sync[1]),
                          // Inputs
                          .clk              (atclk),
                          .clken            (atclken),
                          .resetn           (atresetn),
                          .sync_di          (rd_ptr_gray_corrupt[1]));

  // ---------------------------------------------------------------------------
  // Instantiating the cx_en_sync module for synchronizing rd_ptr_gray[2] bit.
  // ---------------------------------------------------------------------------
  cx_en_sync u_rd_ptr_gray_2 (
                          // Outputs
                          .sync_do          (rd_ptr_gray_sync[2]),
                          // Inputs
                          .clk              (atclk),
                          .clken            (atclken),
                          .resetn           (atresetn),
                          .sync_di          (rd_ptr_gray_corrupt[2]));

  // ---------------------------------------------------------------------------
  // Instantiating the cx_en_sync module for synchronizing rd_ptr_gray[3] bit.
  // ---------------------------------------------------------------------------
  cx_en_sync u_rd_ptr_gray_3 (
                          // Outputs
                          .sync_do          (rd_ptr_gray_sync[3]),
                          // Inputs
                          .clk              (atclk),
                          .clken            (atclken),
                          .resetn           (atresetn),
                          .sync_di          (rd_ptr_gray_corrupt[3]));

  // ---------------------------------------------------------------------------
  // Instantiating the cx_en_sync module for TrigPortDone bit.
  // ---------------------------------------------------------------------------
  cx_en_sync u_trig_port_done (
                          // Outputs
                          .sync_do          (trig_port_done_sync),
                          // Inputs
                          .clk              (atclk),
                          .clken            (atclken),
                          .resetn           (atresetn),
                          .sync_di          (trig_port_sync_corrupt));

  // ---------------------------------------------------------------------------
  // Instantiating the cx_en_sync module for trigin.
  // ---------------------------------------------------------------------------
  cx_en_sync u_trig_in (
                          // Outputs
                          .sync_do          (trigin_sync),
                          // Inputs
                          .clk              (atclk),
                          .clken            (atclken),
                          .resetn           (atresetn),
                          .sync_di          (trigin_corrupt));

  // ---------------------------------------------------------------------------
  // Instantiating the cx_en_sync module for flushin.
  // ---------------------------------------------------------------------------
  cx_en_sync u_flush_in (
                          // Outputs
                          .sync_do          (flushin_sync),
                          // Inputs
                          .clk              (atclk),
                          .clken            (atclken),
                          .resetn           (atresetn),
                          .sync_di          (flushin_corrupt));

endmodule
