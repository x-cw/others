//******************************************************************************
//
//   Copyright (c) 2020 Innosilicon. All rights reserved.
//
//   THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF INNOSILICON
//   The copyright notice above does not evidence any actual or intended
//   publication of such source code.
//
//    Module name: debug_reg
//    Create by: fangxn
//    Create time: 2025-09-05
//    Based  on: ./GP3_coresight_Reg_Definition_20250905.xls
//
//    Change List:
// 
//
//
//******************************************************************************

module debug_reg (
        pclk,
        presetn,


        paddr,
        psel,
        penable,
        pwrite,
        prdata,
        pwdata,
        pready,
        pslverr,
        
        //AXIAP_AWUSER(axiap_awuser) (reg000)
        axiap_awuser_fr_reg,

        //AXIAP_ARUSER(axiap_aruser) (reg004)
        axiap_aruser_fr_reg,

        //ETR_AW(ETR_aw) (reg008)
        etr_awqos_fr_reg,
        etr_awuser_fr_reg,

        //ETR_AR(etr_ar) (reg00c)
        etr_arqos_fr_reg,
        etr_aruser_fr_reg,

        //ETR_ADDR(etr_addr) (reg010)
        etr_addr_h11_fr_reg,

        //ATB_FORMATTER_BTM_PCIE_R0(atb_formatter_btm_pcie_r0) (reg014)
        atb_formatter_btm_pcie_r0_fr_reg,

        //ATB_FORMATTER_BTM_PCIE_R1(atb_formatter_btm_pcie_r1) (reg018)
        atb_formatter_btm_pcie_r1_fr_reg,

        //ATB_FORMATTER_UP_UALINK0(atb_formatter_up_ualink0) (reg01c)
        atb_formatter_up_ualink0_fr_reg,

        //ATB_FORMATTER_UP_UALINK1(atb_formatter_up_ualink1) (reg020)
        atb_formatter_up_ualink1_fr_reg,

        //ATB_FORMATTER_CTRL_SCP(atb_formatter_ctrl_scp) (reg024)
        atb_formatter_ctrl_scp_fr_reg,

        //ATB_FORMATTER_VPU0_VDEC(atb_formatter_vpu0_vdec) (reg028)
        atb_formatter_vpu0_vdec_fr_reg,

        //ATB_FORMATTER_VPU0_JPEG0(atb_formatter_vpu0_jpeg0) (reg02c)
        atb_formatter_vpu0_jpeg0_fr_reg,

        //ATB_FORMATTER_VPU0_JPEG1(atb_formatter_vpu0_jpeg1) (reg030)
        atb_formatter_vpu0_jpeg1_fr_reg,

        //ATB_FORMATTER_VPU1_VDEC(atb_formatter_vpu1_vdec) (reg034)
        atb_formatter_vpu1_vdec_fr_reg,

        //ATB_FORMATTER_VPU1_JPEG0(atb_formatter_vpu1_jpeg0) (reg038)
        atb_formatter_vpu1_jpeg0_fr_reg,

        //ATB_FORMATTER_VPU1_JPEG1(atb_formatter_vpu1_jpeg1) (reg03c)
        atb_formatter_vpu1_jpeg1_fr_reg,

        //CORESIGHT_CLK_SEL(coresight_clk_sel) (reg040)
        reg_coresight_clk_sel,

        //CORESIGHT_CLK_FREQDDIV(coresight_clk_freqdiv) (reg044)
        reg_coresight_freqdiv
        );
             
//-----------------------------------------------------------//
//                          PARAMETERS                       //
//-----------------------------------------------------------//
localparam ADDR_WIDTH = 12 ;
//

//-----------------------------------------------------------//
//                          REG_ADDRESS_DEFINEs              //
//-----------------------------------------------------------//

`define   IP_COMMON_REG_AXIAP_AWUSER   12'h000
`define   IP_COMMON_REG_AXIAP_ARUSER   12'h004
`define   IP_COMMON_REG_ETR_AW   12'h008
`define   IP_COMMON_REG_ETR_AR   12'h00C
`define   IP_COMMON_REG_ETR_ADDR   12'h010
`define   IP_COMMON_REG_ATB_FORMATTER_BTM_PCIE_R0   12'h014
`define   IP_COMMON_REG_ATB_FORMATTER_BTM_PCIE_R1   12'h018
`define   IP_COMMON_REG_ATB_FORMATTER_UP_UALINK0   12'h01C
`define   IP_COMMON_REG_ATB_FORMATTER_UP_UALINK1   12'h020
`define   IP_COMMON_REG_ATB_FORMATTER_CTRL_SCP   12'h024
`define   IP_COMMON_REG_ATB_FORMATTER_VPU0_VDEC   12'h028
`define   IP_COMMON_REG_ATB_FORMATTER_VPU0_JPEG0   12'h02C
`define   IP_COMMON_REG_ATB_FORMATTER_VPU0_JPEG1   12'h030
`define   IP_COMMON_REG_ATB_FORMATTER_VPU1_VDEC   12'h034
`define   IP_COMMON_REG_ATB_FORMATTER_VPU1_JPEG0   12'h038
`define   IP_COMMON_REG_ATB_FORMATTER_VPU1_JPEG1   12'h03C
`define   IP_COMMON_REG_CORESIGHT_CLK_SEL   12'h040
`define   IP_COMMON_REG_CORESIGHT_CLK_FREQDIV   12'h044


//-----------------------------------------------------------//
//                      INPUTS/OUTPUTS                       //
//-----------------------------------------------------------//  
             
input          pclk;
input          presetn;

input  [31:0]  paddr;
input          psel;
input          penable;
input          pwrite;
input  [31:0]  pwdata;
output [31:0]  prdata;
output reg     pready;
output         pslverr;
output [31:0]  axiap_awuser_fr_reg;

output [31:0]  axiap_aruser_fr_reg;

output [3:0]   etr_awqos_fr_reg;
output [15:0]  etr_awuser_fr_reg;

output [3:0]   etr_arqos_fr_reg;
output [15:0]  etr_aruser_fr_reg;

output [10:0]  etr_addr_h11_fr_reg;

output [31:0]  atb_formatter_btm_pcie_r0_fr_reg;

output [31:0]  atb_formatter_btm_pcie_r1_fr_reg;

output [31:0]  atb_formatter_up_ualink0_fr_reg;

output [31:0]  atb_formatter_up_ualink1_fr_reg;

output [31:0]  atb_formatter_ctrl_scp_fr_reg;

output [31:0]  atb_formatter_vpu0_vdec_fr_reg;

output [31:0]  atb_formatter_vpu0_jpeg0_fr_reg;

output [31:0]  atb_formatter_vpu0_jpeg1_fr_reg;

output [31:0]  atb_formatter_vpu1_vdec_fr_reg;

output [31:0]  atb_formatter_vpu1_jpeg0_fr_reg;

output [31:0]  atb_formatter_vpu1_jpeg1_fr_reg;

output [1:0]   reg_coresight_clk_sel;

output [2:0]   reg_coresight_freqdiv;



//-----------------------------------------------------------//
//                    REGISTERS & WIRES                      //
//-----------------------------------------------------------//

wire  [31:0]   prdata;
wire  [31:0]   bus_wdata;
reg   [31:0]   bus_rdata;
wire  [ADDR_WIDTH -1 :0]    bus_addr;
wire           bus_rd;
wire           bus_wr;
wire           apb_rd_wr_cmd;

wire   [31:0]  axiap_awuser_fr_reg; //[31:8]:Reserved

wire   [31:0]  axiap_aruser_fr_reg; //[31:8]:Reserved

wire   [3:0]   etr_awqos_fr_reg; //etr_awqos
wire   [15:0]  etr_awuser_fr_reg; //etr_awuser

wire   [3:0]   etr_arqos_fr_reg; //etr_arqos
wire   [15:0]  etr_aruser_fr_reg; //etr_aruser

wire   [10:0]  etr_addr_h11_fr_reg; //config etr axi write/read addr high 11bit

wire   [31:0]  atb_formatter_btm_pcie_r0_fr_reg; //[31:8]:Reserved

wire   [31:0]  atb_formatter_btm_pcie_r1_fr_reg; //[31:8]:Reserved

wire   [31:0]  atb_formatter_up_ualink0_fr_reg; //[31:8]:Reserved

wire   [31:0]  atb_formatter_up_ualink1_fr_reg; //[31:8]:Reserved

wire   [31:0]  atb_formatter_ctrl_scp_fr_reg; //[31:8]:Reserved

wire   [31:0]  atb_formatter_vpu0_vdec_fr_reg; //[31:8]:Reserved

wire   [31:0]  atb_formatter_vpu0_jpeg0_fr_reg; //[31:8]:Reserved

wire   [31:0]  atb_formatter_vpu0_jpeg1_fr_reg; //[31:8]:Reserved

wire   [31:0]  atb_formatter_vpu1_vdec_fr_reg; //[31:8]:Reserved

wire   [31:0]  atb_formatter_vpu1_jpeg0_fr_reg; //[31:8]:Reserved

wire   [31:0]  atb_formatter_vpu1_jpeg1_fr_reg; //[31:8]:Reserved

wire   [1:0]   reg_coresight_clk_sel; //coresight clock selection

wire   [2:0]   reg_coresight_freqdiv; //databus freq_div = coresight_clk, default is div4,default coresight_clk=400M


reg    [31:0]  inter_axiap_awuser_fr_reg;
reg    [31:0]  inter_axiap_aruser_fr_reg;
reg    [3:0]   inter_etr_awqos_fr_reg;
reg    [15:0]  inter_etr_awuser_fr_reg;
reg    [3:0]   inter_etr_arqos_fr_reg;
reg    [15:0]  inter_etr_aruser_fr_reg;
reg    [10:0]  inter_etr_addr_h11_fr_reg;
reg    [31:0]  inter_atb_formatter_btm_pcie_r0_fr_reg;
reg    [31:0]  inter_atb_formatter_btm_pcie_r1_fr_reg;
reg    [31:0]  inter_atb_formatter_up_ualink0_fr_reg;
reg    [31:0]  inter_atb_formatter_up_ualink1_fr_reg;
reg    [31:0]  inter_atb_formatter_ctrl_scp_fr_reg;
reg    [31:0]  inter_atb_formatter_vpu0_vdec_fr_reg;
reg    [31:0]  inter_atb_formatter_vpu0_jpeg0_fr_reg;
reg    [31:0]  inter_atb_formatter_vpu0_jpeg1_fr_reg;
reg    [31:0]  inter_atb_formatter_vpu1_vdec_fr_reg;
reg    [31:0]  inter_atb_formatter_vpu1_jpeg0_fr_reg;
reg    [31:0]  inter_atb_formatter_vpu1_jpeg1_fr_reg;
reg    [1:0]   inter_reg_coresight_clk_sel;
reg    [2:0]   inter_reg_coresight_freqdiv;


//-----------------------------------------------------------//
//                          ARCHITECTURE                     //
//-----------------------------------------------------------//  

assign bus_addr        = paddr[ADDR_WIDTH-1:0];
assign  bus_rd         = psel & penable & (~pwrite);
assign  bus_wr         = psel & penable & pwrite;
assign  apb_rd_wr_cmd  = psel & ~penable;

assign bus_wdata = pwdata;
assign prdata    = bus_rdata;

always @(posedge pclk or negedge presetn)begin
  if(!presetn)begin
    pready <= 1'b0;
  end else if (pready) begin
    pready <= 1'b0; 
  end else begin
    pready <= apb_rd_wr_cmd;
  end
end
assign pslverr = 1'b0;


//========================
//Write operation to registers
//========================
always @ (posedge pclk or negedge presetn)
begin
    if(!presetn)
    begin 
        inter_axiap_awuser_fr_reg <= 32'd0;
        inter_axiap_aruser_fr_reg <= 32'd0;
        inter_etr_awqos_fr_reg <= 4'd0;
        inter_etr_awuser_fr_reg <= 16'd0;
        inter_etr_arqos_fr_reg <= 4'd0;
        inter_etr_aruser_fr_reg <= 16'd0;
        inter_etr_addr_h11_fr_reg <= 11'd0;
        inter_atb_formatter_btm_pcie_r0_fr_reg <= 32'd0;
        inter_atb_formatter_btm_pcie_r1_fr_reg <= 32'd0;
        inter_atb_formatter_up_ualink0_fr_reg <= 32'd0;
        inter_atb_formatter_up_ualink1_fr_reg <= 32'd0;
        inter_atb_formatter_ctrl_scp_fr_reg <= 32'd0;
        inter_atb_formatter_vpu0_vdec_fr_reg <= 32'd0;
        inter_atb_formatter_vpu0_jpeg0_fr_reg <= 32'd0;
        inter_atb_formatter_vpu0_jpeg1_fr_reg <= 32'd0;
        inter_atb_formatter_vpu1_vdec_fr_reg <= 32'd0;
        inter_atb_formatter_vpu1_jpeg0_fr_reg <= 32'd0;
        inter_atb_formatter_vpu1_jpeg1_fr_reg <= 32'd0;
        inter_reg_coresight_clk_sel <= 2'd0;
        inter_reg_coresight_freqdiv <= 3'd1;
    end
    else if (bus_wr) 
    begin 
        case (bus_addr)
        12'h000 : inter_axiap_awuser_fr_reg <= bus_wdata[31:0];
        12'h004 : inter_axiap_aruser_fr_reg <= bus_wdata[31:0];
        12'h008 :
        begin 
            inter_etr_awqos_fr_reg <= bus_wdata[19:16];
            inter_etr_awuser_fr_reg <= bus_wdata[15:0];
        end
        12'h00C :
        begin 
            inter_etr_arqos_fr_reg <= bus_wdata[19:16];
            inter_etr_aruser_fr_reg <= bus_wdata[15:0];
        end
        12'h010 : inter_etr_addr_h11_fr_reg <= bus_wdata[10:0];
        12'h014 : inter_atb_formatter_btm_pcie_r0_fr_reg <= bus_wdata[31:0];
        12'h018 : inter_atb_formatter_btm_pcie_r1_fr_reg <= bus_wdata[31:0];
        12'h01C : inter_atb_formatter_up_ualink0_fr_reg <= bus_wdata[31:0];
        12'h020 : inter_atb_formatter_up_ualink1_fr_reg <= bus_wdata[31:0];
        12'h024 : inter_atb_formatter_ctrl_scp_fr_reg <= bus_wdata[31:0];
        12'h028 : inter_atb_formatter_vpu0_vdec_fr_reg <= bus_wdata[31:0];
        12'h02C : inter_atb_formatter_vpu0_jpeg0_fr_reg <= bus_wdata[31:0];
        12'h030 : inter_atb_formatter_vpu0_jpeg1_fr_reg <= bus_wdata[31:0];
        12'h034 : inter_atb_formatter_vpu1_vdec_fr_reg <= bus_wdata[31:0];
        12'h038 : inter_atb_formatter_vpu1_jpeg0_fr_reg <= bus_wdata[31:0];
        12'h03C : inter_atb_formatter_vpu1_jpeg1_fr_reg <= bus_wdata[31:0];
        12'h040 : inter_reg_coresight_clk_sel <= bus_wdata[1:0];
        12'h044 : inter_reg_coresight_freqdiv <= bus_wdata[2:0];
        default : ;
        endcase
    end
end  
      

//========================
//Read operation to registers
//========================
wire [31:0] reg000 = axiap_awuser_fr_reg;

wire [31:0] reg004 = axiap_aruser_fr_reg;

wire [31:0] reg008 = { 
                      12'b0,
                      etr_awqos_fr_reg,
                      etr_awuser_fr_reg
                      };

wire [31:0] reg00c = { 
                      12'b0,
                      etr_arqos_fr_reg,
                      etr_aruser_fr_reg
                      };

wire [31:0] reg010 = { 
                      21'b0,
                      etr_addr_h11_fr_reg
                      };

wire [31:0] reg014 = atb_formatter_btm_pcie_r0_fr_reg;

wire [31:0] reg018 = atb_formatter_btm_pcie_r1_fr_reg;

wire [31:0] reg01c = atb_formatter_up_ualink0_fr_reg;

wire [31:0] reg020 = atb_formatter_up_ualink1_fr_reg;

wire [31:0] reg024 = atb_formatter_ctrl_scp_fr_reg;

wire [31:0] reg028 = atb_formatter_vpu0_vdec_fr_reg;

wire [31:0] reg02c = atb_formatter_vpu0_jpeg0_fr_reg;

wire [31:0] reg030 = atb_formatter_vpu0_jpeg1_fr_reg;

wire [31:0] reg034 = atb_formatter_vpu1_vdec_fr_reg;

wire [31:0] reg038 = atb_formatter_vpu1_jpeg0_fr_reg;

wire [31:0] reg03c = atb_formatter_vpu1_jpeg1_fr_reg;

wire [31:0] reg040 = { 
                      30'b0,
                      reg_coresight_clk_sel
                      };

wire [31:0] reg044 = { 
                      29'b0,
                      reg_coresight_freqdiv
                      };

always @ *
begin
    if( bus_rd ) 
        case (bus_addr)
        12'h000 : bus_rdata = reg000;
        12'h004 : bus_rdata = reg004;
        12'h008 : bus_rdata = reg008;
        12'h00C : bus_rdata = reg00c;
        12'h010 : bus_rdata = reg010;
        12'h014 : bus_rdata = reg014;
        12'h018 : bus_rdata = reg018;
        12'h01C : bus_rdata = reg01c;
        12'h020 : bus_rdata = reg020;
        12'h024 : bus_rdata = reg024;
        12'h028 : bus_rdata = reg028;
        12'h02C : bus_rdata = reg02c;
        12'h030 : bus_rdata = reg030;
        12'h034 : bus_rdata = reg034;
        12'h038 : bus_rdata = reg038;
        12'h03C : bus_rdata = reg03c;
        12'h040 : bus_rdata = reg040;
        12'h044 : bus_rdata = reg044;
        default : bus_rdata = 32'b0;
        endcase
    else
        bus_rdata = 32'b0;
end


//========================
//dont touch block
//========================

        cell_clk_buf   axiap_awuser_fr_reg_inst0(.clki(inter_axiap_awuser_fr_reg[0]), .clko(axiap_awuser_fr_reg[0]));
        cell_clk_buf   axiap_awuser_fr_reg_inst1(.clki(inter_axiap_awuser_fr_reg[1]), .clko(axiap_awuser_fr_reg[1]));
        cell_clk_buf   axiap_awuser_fr_reg_inst2(.clki(inter_axiap_awuser_fr_reg[2]), .clko(axiap_awuser_fr_reg[2]));
        cell_clk_buf   axiap_awuser_fr_reg_inst3(.clki(inter_axiap_awuser_fr_reg[3]), .clko(axiap_awuser_fr_reg[3]));
        cell_clk_buf   axiap_awuser_fr_reg_inst4(.clki(inter_axiap_awuser_fr_reg[4]), .clko(axiap_awuser_fr_reg[4]));
        cell_clk_buf   axiap_awuser_fr_reg_inst5(.clki(inter_axiap_awuser_fr_reg[5]), .clko(axiap_awuser_fr_reg[5]));
        cell_clk_buf   axiap_awuser_fr_reg_inst6(.clki(inter_axiap_awuser_fr_reg[6]), .clko(axiap_awuser_fr_reg[6]));
        cell_clk_buf   axiap_awuser_fr_reg_inst7(.clki(inter_axiap_awuser_fr_reg[7]), .clko(axiap_awuser_fr_reg[7]));
        cell_clk_buf   axiap_awuser_fr_reg_inst8(.clki(inter_axiap_awuser_fr_reg[8]), .clko(axiap_awuser_fr_reg[8]));
        cell_clk_buf   axiap_awuser_fr_reg_inst9(.clki(inter_axiap_awuser_fr_reg[9]), .clko(axiap_awuser_fr_reg[9]));
        cell_clk_buf   axiap_awuser_fr_reg_inst10(.clki(inter_axiap_awuser_fr_reg[10]), .clko(axiap_awuser_fr_reg[10]));
        cell_clk_buf   axiap_awuser_fr_reg_inst11(.clki(inter_axiap_awuser_fr_reg[11]), .clko(axiap_awuser_fr_reg[11]));
        cell_clk_buf   axiap_awuser_fr_reg_inst12(.clki(inter_axiap_awuser_fr_reg[12]), .clko(axiap_awuser_fr_reg[12]));
        cell_clk_buf   axiap_awuser_fr_reg_inst13(.clki(inter_axiap_awuser_fr_reg[13]), .clko(axiap_awuser_fr_reg[13]));
        cell_clk_buf   axiap_awuser_fr_reg_inst14(.clki(inter_axiap_awuser_fr_reg[14]), .clko(axiap_awuser_fr_reg[14]));
        cell_clk_buf   axiap_awuser_fr_reg_inst15(.clki(inter_axiap_awuser_fr_reg[15]), .clko(axiap_awuser_fr_reg[15]));
        cell_clk_buf   axiap_awuser_fr_reg_inst16(.clki(inter_axiap_awuser_fr_reg[16]), .clko(axiap_awuser_fr_reg[16]));
        cell_clk_buf   axiap_awuser_fr_reg_inst17(.clki(inter_axiap_awuser_fr_reg[17]), .clko(axiap_awuser_fr_reg[17]));
        cell_clk_buf   axiap_awuser_fr_reg_inst18(.clki(inter_axiap_awuser_fr_reg[18]), .clko(axiap_awuser_fr_reg[18]));
        cell_clk_buf   axiap_awuser_fr_reg_inst19(.clki(inter_axiap_awuser_fr_reg[19]), .clko(axiap_awuser_fr_reg[19]));
        cell_clk_buf   axiap_awuser_fr_reg_inst20(.clki(inter_axiap_awuser_fr_reg[20]), .clko(axiap_awuser_fr_reg[20]));
        cell_clk_buf   axiap_awuser_fr_reg_inst21(.clki(inter_axiap_awuser_fr_reg[21]), .clko(axiap_awuser_fr_reg[21]));
        cell_clk_buf   axiap_awuser_fr_reg_inst22(.clki(inter_axiap_awuser_fr_reg[22]), .clko(axiap_awuser_fr_reg[22]));
        cell_clk_buf   axiap_awuser_fr_reg_inst23(.clki(inter_axiap_awuser_fr_reg[23]), .clko(axiap_awuser_fr_reg[23]));
        cell_clk_buf   axiap_awuser_fr_reg_inst24(.clki(inter_axiap_awuser_fr_reg[24]), .clko(axiap_awuser_fr_reg[24]));
        cell_clk_buf   axiap_awuser_fr_reg_inst25(.clki(inter_axiap_awuser_fr_reg[25]), .clko(axiap_awuser_fr_reg[25]));
        cell_clk_buf   axiap_awuser_fr_reg_inst26(.clki(inter_axiap_awuser_fr_reg[26]), .clko(axiap_awuser_fr_reg[26]));
        cell_clk_buf   axiap_awuser_fr_reg_inst27(.clki(inter_axiap_awuser_fr_reg[27]), .clko(axiap_awuser_fr_reg[27]));
        cell_clk_buf   axiap_awuser_fr_reg_inst28(.clki(inter_axiap_awuser_fr_reg[28]), .clko(axiap_awuser_fr_reg[28]));
        cell_clk_buf   axiap_awuser_fr_reg_inst29(.clki(inter_axiap_awuser_fr_reg[29]), .clko(axiap_awuser_fr_reg[29]));
        cell_clk_buf   axiap_awuser_fr_reg_inst30(.clki(inter_axiap_awuser_fr_reg[30]), .clko(axiap_awuser_fr_reg[30]));
        cell_clk_buf   axiap_awuser_fr_reg_inst31(.clki(inter_axiap_awuser_fr_reg[31]), .clko(axiap_awuser_fr_reg[31]));
        cell_clk_buf   axiap_aruser_fr_reg_inst0(.clki(inter_axiap_aruser_fr_reg[0]), .clko(axiap_aruser_fr_reg[0]));
        cell_clk_buf   axiap_aruser_fr_reg_inst1(.clki(inter_axiap_aruser_fr_reg[1]), .clko(axiap_aruser_fr_reg[1]));
        cell_clk_buf   axiap_aruser_fr_reg_inst2(.clki(inter_axiap_aruser_fr_reg[2]), .clko(axiap_aruser_fr_reg[2]));
        cell_clk_buf   axiap_aruser_fr_reg_inst3(.clki(inter_axiap_aruser_fr_reg[3]), .clko(axiap_aruser_fr_reg[3]));
        cell_clk_buf   axiap_aruser_fr_reg_inst4(.clki(inter_axiap_aruser_fr_reg[4]), .clko(axiap_aruser_fr_reg[4]));
        cell_clk_buf   axiap_aruser_fr_reg_inst5(.clki(inter_axiap_aruser_fr_reg[5]), .clko(axiap_aruser_fr_reg[5]));
        cell_clk_buf   axiap_aruser_fr_reg_inst6(.clki(inter_axiap_aruser_fr_reg[6]), .clko(axiap_aruser_fr_reg[6]));
        cell_clk_buf   axiap_aruser_fr_reg_inst7(.clki(inter_axiap_aruser_fr_reg[7]), .clko(axiap_aruser_fr_reg[7]));
        cell_clk_buf   axiap_aruser_fr_reg_inst8(.clki(inter_axiap_aruser_fr_reg[8]), .clko(axiap_aruser_fr_reg[8]));
        cell_clk_buf   axiap_aruser_fr_reg_inst9(.clki(inter_axiap_aruser_fr_reg[9]), .clko(axiap_aruser_fr_reg[9]));
        cell_clk_buf   axiap_aruser_fr_reg_inst10(.clki(inter_axiap_aruser_fr_reg[10]), .clko(axiap_aruser_fr_reg[10]));
        cell_clk_buf   axiap_aruser_fr_reg_inst11(.clki(inter_axiap_aruser_fr_reg[11]), .clko(axiap_aruser_fr_reg[11]));
        cell_clk_buf   axiap_aruser_fr_reg_inst12(.clki(inter_axiap_aruser_fr_reg[12]), .clko(axiap_aruser_fr_reg[12]));
        cell_clk_buf   axiap_aruser_fr_reg_inst13(.clki(inter_axiap_aruser_fr_reg[13]), .clko(axiap_aruser_fr_reg[13]));
        cell_clk_buf   axiap_aruser_fr_reg_inst14(.clki(inter_axiap_aruser_fr_reg[14]), .clko(axiap_aruser_fr_reg[14]));
        cell_clk_buf   axiap_aruser_fr_reg_inst15(.clki(inter_axiap_aruser_fr_reg[15]), .clko(axiap_aruser_fr_reg[15]));
        cell_clk_buf   axiap_aruser_fr_reg_inst16(.clki(inter_axiap_aruser_fr_reg[16]), .clko(axiap_aruser_fr_reg[16]));
        cell_clk_buf   axiap_aruser_fr_reg_inst17(.clki(inter_axiap_aruser_fr_reg[17]), .clko(axiap_aruser_fr_reg[17]));
        cell_clk_buf   axiap_aruser_fr_reg_inst18(.clki(inter_axiap_aruser_fr_reg[18]), .clko(axiap_aruser_fr_reg[18]));
        cell_clk_buf   axiap_aruser_fr_reg_inst19(.clki(inter_axiap_aruser_fr_reg[19]), .clko(axiap_aruser_fr_reg[19]));
        cell_clk_buf   axiap_aruser_fr_reg_inst20(.clki(inter_axiap_aruser_fr_reg[20]), .clko(axiap_aruser_fr_reg[20]));
        cell_clk_buf   axiap_aruser_fr_reg_inst21(.clki(inter_axiap_aruser_fr_reg[21]), .clko(axiap_aruser_fr_reg[21]));
        cell_clk_buf   axiap_aruser_fr_reg_inst22(.clki(inter_axiap_aruser_fr_reg[22]), .clko(axiap_aruser_fr_reg[22]));
        cell_clk_buf   axiap_aruser_fr_reg_inst23(.clki(inter_axiap_aruser_fr_reg[23]), .clko(axiap_aruser_fr_reg[23]));
        cell_clk_buf   axiap_aruser_fr_reg_inst24(.clki(inter_axiap_aruser_fr_reg[24]), .clko(axiap_aruser_fr_reg[24]));
        cell_clk_buf   axiap_aruser_fr_reg_inst25(.clki(inter_axiap_aruser_fr_reg[25]), .clko(axiap_aruser_fr_reg[25]));
        cell_clk_buf   axiap_aruser_fr_reg_inst26(.clki(inter_axiap_aruser_fr_reg[26]), .clko(axiap_aruser_fr_reg[26]));
        cell_clk_buf   axiap_aruser_fr_reg_inst27(.clki(inter_axiap_aruser_fr_reg[27]), .clko(axiap_aruser_fr_reg[27]));
        cell_clk_buf   axiap_aruser_fr_reg_inst28(.clki(inter_axiap_aruser_fr_reg[28]), .clko(axiap_aruser_fr_reg[28]));
        cell_clk_buf   axiap_aruser_fr_reg_inst29(.clki(inter_axiap_aruser_fr_reg[29]), .clko(axiap_aruser_fr_reg[29]));
        cell_clk_buf   axiap_aruser_fr_reg_inst30(.clki(inter_axiap_aruser_fr_reg[30]), .clko(axiap_aruser_fr_reg[30]));
        cell_clk_buf   axiap_aruser_fr_reg_inst31(.clki(inter_axiap_aruser_fr_reg[31]), .clko(axiap_aruser_fr_reg[31]));
        cell_clk_buf   etr_awqos_fr_reg_inst0(.clki(inter_etr_awqos_fr_reg[0]), .clko(etr_awqos_fr_reg[0]));
        cell_clk_buf   etr_awqos_fr_reg_inst1(.clki(inter_etr_awqos_fr_reg[1]), .clko(etr_awqos_fr_reg[1]));
        cell_clk_buf   etr_awqos_fr_reg_inst2(.clki(inter_etr_awqos_fr_reg[2]), .clko(etr_awqos_fr_reg[2]));
        cell_clk_buf   etr_awqos_fr_reg_inst3(.clki(inter_etr_awqos_fr_reg[3]), .clko(etr_awqos_fr_reg[3]));
        cell_clk_buf   etr_awuser_fr_reg_inst0(.clki(inter_etr_awuser_fr_reg[0]), .clko(etr_awuser_fr_reg[0]));
        cell_clk_buf   etr_awuser_fr_reg_inst1(.clki(inter_etr_awuser_fr_reg[1]), .clko(etr_awuser_fr_reg[1]));
        cell_clk_buf   etr_awuser_fr_reg_inst2(.clki(inter_etr_awuser_fr_reg[2]), .clko(etr_awuser_fr_reg[2]));
        cell_clk_buf   etr_awuser_fr_reg_inst3(.clki(inter_etr_awuser_fr_reg[3]), .clko(etr_awuser_fr_reg[3]));
        cell_clk_buf   etr_awuser_fr_reg_inst4(.clki(inter_etr_awuser_fr_reg[4]), .clko(etr_awuser_fr_reg[4]));
        cell_clk_buf   etr_awuser_fr_reg_inst5(.clki(inter_etr_awuser_fr_reg[5]), .clko(etr_awuser_fr_reg[5]));
        cell_clk_buf   etr_awuser_fr_reg_inst6(.clki(inter_etr_awuser_fr_reg[6]), .clko(etr_awuser_fr_reg[6]));
        cell_clk_buf   etr_awuser_fr_reg_inst7(.clki(inter_etr_awuser_fr_reg[7]), .clko(etr_awuser_fr_reg[7]));
        cell_clk_buf   etr_awuser_fr_reg_inst8(.clki(inter_etr_awuser_fr_reg[8]), .clko(etr_awuser_fr_reg[8]));
        cell_clk_buf   etr_awuser_fr_reg_inst9(.clki(inter_etr_awuser_fr_reg[9]), .clko(etr_awuser_fr_reg[9]));
        cell_clk_buf   etr_awuser_fr_reg_inst10(.clki(inter_etr_awuser_fr_reg[10]), .clko(etr_awuser_fr_reg[10]));
        cell_clk_buf   etr_awuser_fr_reg_inst11(.clki(inter_etr_awuser_fr_reg[11]), .clko(etr_awuser_fr_reg[11]));
        cell_clk_buf   etr_awuser_fr_reg_inst12(.clki(inter_etr_awuser_fr_reg[12]), .clko(etr_awuser_fr_reg[12]));
        cell_clk_buf   etr_awuser_fr_reg_inst13(.clki(inter_etr_awuser_fr_reg[13]), .clko(etr_awuser_fr_reg[13]));
        cell_clk_buf   etr_awuser_fr_reg_inst14(.clki(inter_etr_awuser_fr_reg[14]), .clko(etr_awuser_fr_reg[14]));
        cell_clk_buf   etr_awuser_fr_reg_inst15(.clki(inter_etr_awuser_fr_reg[15]), .clko(etr_awuser_fr_reg[15]));
        cell_clk_buf   etr_arqos_fr_reg_inst0(.clki(inter_etr_arqos_fr_reg[0]), .clko(etr_arqos_fr_reg[0]));
        cell_clk_buf   etr_arqos_fr_reg_inst1(.clki(inter_etr_arqos_fr_reg[1]), .clko(etr_arqos_fr_reg[1]));
        cell_clk_buf   etr_arqos_fr_reg_inst2(.clki(inter_etr_arqos_fr_reg[2]), .clko(etr_arqos_fr_reg[2]));
        cell_clk_buf   etr_arqos_fr_reg_inst3(.clki(inter_etr_arqos_fr_reg[3]), .clko(etr_arqos_fr_reg[3]));
        cell_clk_buf   etr_aruser_fr_reg_inst0(.clki(inter_etr_aruser_fr_reg[0]), .clko(etr_aruser_fr_reg[0]));
        cell_clk_buf   etr_aruser_fr_reg_inst1(.clki(inter_etr_aruser_fr_reg[1]), .clko(etr_aruser_fr_reg[1]));
        cell_clk_buf   etr_aruser_fr_reg_inst2(.clki(inter_etr_aruser_fr_reg[2]), .clko(etr_aruser_fr_reg[2]));
        cell_clk_buf   etr_aruser_fr_reg_inst3(.clki(inter_etr_aruser_fr_reg[3]), .clko(etr_aruser_fr_reg[3]));
        cell_clk_buf   etr_aruser_fr_reg_inst4(.clki(inter_etr_aruser_fr_reg[4]), .clko(etr_aruser_fr_reg[4]));
        cell_clk_buf   etr_aruser_fr_reg_inst5(.clki(inter_etr_aruser_fr_reg[5]), .clko(etr_aruser_fr_reg[5]));
        cell_clk_buf   etr_aruser_fr_reg_inst6(.clki(inter_etr_aruser_fr_reg[6]), .clko(etr_aruser_fr_reg[6]));
        cell_clk_buf   etr_aruser_fr_reg_inst7(.clki(inter_etr_aruser_fr_reg[7]), .clko(etr_aruser_fr_reg[7]));
        cell_clk_buf   etr_aruser_fr_reg_inst8(.clki(inter_etr_aruser_fr_reg[8]), .clko(etr_aruser_fr_reg[8]));
        cell_clk_buf   etr_aruser_fr_reg_inst9(.clki(inter_etr_aruser_fr_reg[9]), .clko(etr_aruser_fr_reg[9]));
        cell_clk_buf   etr_aruser_fr_reg_inst10(.clki(inter_etr_aruser_fr_reg[10]), .clko(etr_aruser_fr_reg[10]));
        cell_clk_buf   etr_aruser_fr_reg_inst11(.clki(inter_etr_aruser_fr_reg[11]), .clko(etr_aruser_fr_reg[11]));
        cell_clk_buf   etr_aruser_fr_reg_inst12(.clki(inter_etr_aruser_fr_reg[12]), .clko(etr_aruser_fr_reg[12]));
        cell_clk_buf   etr_aruser_fr_reg_inst13(.clki(inter_etr_aruser_fr_reg[13]), .clko(etr_aruser_fr_reg[13]));
        cell_clk_buf   etr_aruser_fr_reg_inst14(.clki(inter_etr_aruser_fr_reg[14]), .clko(etr_aruser_fr_reg[14]));
        cell_clk_buf   etr_aruser_fr_reg_inst15(.clki(inter_etr_aruser_fr_reg[15]), .clko(etr_aruser_fr_reg[15]));
        cell_clk_buf   etr_addr_h11_fr_reg_inst0(.clki(inter_etr_addr_h11_fr_reg[0]), .clko(etr_addr_h11_fr_reg[0]));
        cell_clk_buf   etr_addr_h11_fr_reg_inst1(.clki(inter_etr_addr_h11_fr_reg[1]), .clko(etr_addr_h11_fr_reg[1]));
        cell_clk_buf   etr_addr_h11_fr_reg_inst2(.clki(inter_etr_addr_h11_fr_reg[2]), .clko(etr_addr_h11_fr_reg[2]));
        cell_clk_buf   etr_addr_h11_fr_reg_inst3(.clki(inter_etr_addr_h11_fr_reg[3]), .clko(etr_addr_h11_fr_reg[3]));
        cell_clk_buf   etr_addr_h11_fr_reg_inst4(.clki(inter_etr_addr_h11_fr_reg[4]), .clko(etr_addr_h11_fr_reg[4]));
        cell_clk_buf   etr_addr_h11_fr_reg_inst5(.clki(inter_etr_addr_h11_fr_reg[5]), .clko(etr_addr_h11_fr_reg[5]));
        cell_clk_buf   etr_addr_h11_fr_reg_inst6(.clki(inter_etr_addr_h11_fr_reg[6]), .clko(etr_addr_h11_fr_reg[6]));
        cell_clk_buf   etr_addr_h11_fr_reg_inst7(.clki(inter_etr_addr_h11_fr_reg[7]), .clko(etr_addr_h11_fr_reg[7]));
        cell_clk_buf   etr_addr_h11_fr_reg_inst8(.clki(inter_etr_addr_h11_fr_reg[8]), .clko(etr_addr_h11_fr_reg[8]));
        cell_clk_buf   etr_addr_h11_fr_reg_inst9(.clki(inter_etr_addr_h11_fr_reg[9]), .clko(etr_addr_h11_fr_reg[9]));
        cell_clk_buf   etr_addr_h11_fr_reg_inst10(.clki(inter_etr_addr_h11_fr_reg[10]), .clko(etr_addr_h11_fr_reg[10]));
        cell_clk_buf   atb_formatter_btm_pcie_r0_fr_reg_inst0(.clki(inter_atb_formatter_btm_pcie_r0_fr_reg[0]), .clko(atb_formatter_btm_pcie_r0_fr_reg[0]));
        cell_clk_buf   atb_formatter_btm_pcie_r0_fr_reg_inst1(.clki(inter_atb_formatter_btm_pcie_r0_fr_reg[1]), .clko(atb_formatter_btm_pcie_r0_fr_reg[1]));
        cell_clk_buf   atb_formatter_btm_pcie_r0_fr_reg_inst2(.clki(inter_atb_formatter_btm_pcie_r0_fr_reg[2]), .clko(atb_formatter_btm_pcie_r0_fr_reg[2]));
        cell_clk_buf   atb_formatter_btm_pcie_r0_fr_reg_inst3(.clki(inter_atb_formatter_btm_pcie_r0_fr_reg[3]), .clko(atb_formatter_btm_pcie_r0_fr_reg[3]));
        cell_clk_buf   atb_formatter_btm_pcie_r0_fr_reg_inst4(.clki(inter_atb_formatter_btm_pcie_r0_fr_reg[4]), .clko(atb_formatter_btm_pcie_r0_fr_reg[4]));
        cell_clk_buf   atb_formatter_btm_pcie_r0_fr_reg_inst5(.clki(inter_atb_formatter_btm_pcie_r0_fr_reg[5]), .clko(atb_formatter_btm_pcie_r0_fr_reg[5]));
        cell_clk_buf   atb_formatter_btm_pcie_r0_fr_reg_inst6(.clki(inter_atb_formatter_btm_pcie_r0_fr_reg[6]), .clko(atb_formatter_btm_pcie_r0_fr_reg[6]));
        cell_clk_buf   atb_formatter_btm_pcie_r0_fr_reg_inst7(.clki(inter_atb_formatter_btm_pcie_r0_fr_reg[7]), .clko(atb_formatter_btm_pcie_r0_fr_reg[7]));
        cell_clk_buf   atb_formatter_btm_pcie_r0_fr_reg_inst8(.clki(inter_atb_formatter_btm_pcie_r0_fr_reg[8]), .clko(atb_formatter_btm_pcie_r0_fr_reg[8]));
        cell_clk_buf   atb_formatter_btm_pcie_r0_fr_reg_inst9(.clki(inter_atb_formatter_btm_pcie_r0_fr_reg[9]), .clko(atb_formatter_btm_pcie_r0_fr_reg[9]));
        cell_clk_buf   atb_formatter_btm_pcie_r0_fr_reg_inst10(.clki(inter_atb_formatter_btm_pcie_r0_fr_reg[10]), .clko(atb_formatter_btm_pcie_r0_fr_reg[10]));
        cell_clk_buf   atb_formatter_btm_pcie_r0_fr_reg_inst11(.clki(inter_atb_formatter_btm_pcie_r0_fr_reg[11]), .clko(atb_formatter_btm_pcie_r0_fr_reg[11]));
        cell_clk_buf   atb_formatter_btm_pcie_r0_fr_reg_inst12(.clki(inter_atb_formatter_btm_pcie_r0_fr_reg[12]), .clko(atb_formatter_btm_pcie_r0_fr_reg[12]));
        cell_clk_buf   atb_formatter_btm_pcie_r0_fr_reg_inst13(.clki(inter_atb_formatter_btm_pcie_r0_fr_reg[13]), .clko(atb_formatter_btm_pcie_r0_fr_reg[13]));
        cell_clk_buf   atb_formatter_btm_pcie_r0_fr_reg_inst14(.clki(inter_atb_formatter_btm_pcie_r0_fr_reg[14]), .clko(atb_formatter_btm_pcie_r0_fr_reg[14]));
        cell_clk_buf   atb_formatter_btm_pcie_r0_fr_reg_inst15(.clki(inter_atb_formatter_btm_pcie_r0_fr_reg[15]), .clko(atb_formatter_btm_pcie_r0_fr_reg[15]));
        cell_clk_buf   atb_formatter_btm_pcie_r0_fr_reg_inst16(.clki(inter_atb_formatter_btm_pcie_r0_fr_reg[16]), .clko(atb_formatter_btm_pcie_r0_fr_reg[16]));
        cell_clk_buf   atb_formatter_btm_pcie_r0_fr_reg_inst17(.clki(inter_atb_formatter_btm_pcie_r0_fr_reg[17]), .clko(atb_formatter_btm_pcie_r0_fr_reg[17]));
        cell_clk_buf   atb_formatter_btm_pcie_r0_fr_reg_inst18(.clki(inter_atb_formatter_btm_pcie_r0_fr_reg[18]), .clko(atb_formatter_btm_pcie_r0_fr_reg[18]));
        cell_clk_buf   atb_formatter_btm_pcie_r0_fr_reg_inst19(.clki(inter_atb_formatter_btm_pcie_r0_fr_reg[19]), .clko(atb_formatter_btm_pcie_r0_fr_reg[19]));
        cell_clk_buf   atb_formatter_btm_pcie_r0_fr_reg_inst20(.clki(inter_atb_formatter_btm_pcie_r0_fr_reg[20]), .clko(atb_formatter_btm_pcie_r0_fr_reg[20]));
        cell_clk_buf   atb_formatter_btm_pcie_r0_fr_reg_inst21(.clki(inter_atb_formatter_btm_pcie_r0_fr_reg[21]), .clko(atb_formatter_btm_pcie_r0_fr_reg[21]));
        cell_clk_buf   atb_formatter_btm_pcie_r0_fr_reg_inst22(.clki(inter_atb_formatter_btm_pcie_r0_fr_reg[22]), .clko(atb_formatter_btm_pcie_r0_fr_reg[22]));
        cell_clk_buf   atb_formatter_btm_pcie_r0_fr_reg_inst23(.clki(inter_atb_formatter_btm_pcie_r0_fr_reg[23]), .clko(atb_formatter_btm_pcie_r0_fr_reg[23]));
        cell_clk_buf   atb_formatter_btm_pcie_r0_fr_reg_inst24(.clki(inter_atb_formatter_btm_pcie_r0_fr_reg[24]), .clko(atb_formatter_btm_pcie_r0_fr_reg[24]));
        cell_clk_buf   atb_formatter_btm_pcie_r0_fr_reg_inst25(.clki(inter_atb_formatter_btm_pcie_r0_fr_reg[25]), .clko(atb_formatter_btm_pcie_r0_fr_reg[25]));
        cell_clk_buf   atb_formatter_btm_pcie_r0_fr_reg_inst26(.clki(inter_atb_formatter_btm_pcie_r0_fr_reg[26]), .clko(atb_formatter_btm_pcie_r0_fr_reg[26]));
        cell_clk_buf   atb_formatter_btm_pcie_r0_fr_reg_inst27(.clki(inter_atb_formatter_btm_pcie_r0_fr_reg[27]), .clko(atb_formatter_btm_pcie_r0_fr_reg[27]));
        cell_clk_buf   atb_formatter_btm_pcie_r0_fr_reg_inst28(.clki(inter_atb_formatter_btm_pcie_r0_fr_reg[28]), .clko(atb_formatter_btm_pcie_r0_fr_reg[28]));
        cell_clk_buf   atb_formatter_btm_pcie_r0_fr_reg_inst29(.clki(inter_atb_formatter_btm_pcie_r0_fr_reg[29]), .clko(atb_formatter_btm_pcie_r0_fr_reg[29]));
        cell_clk_buf   atb_formatter_btm_pcie_r0_fr_reg_inst30(.clki(inter_atb_formatter_btm_pcie_r0_fr_reg[30]), .clko(atb_formatter_btm_pcie_r0_fr_reg[30]));
        cell_clk_buf   atb_formatter_btm_pcie_r0_fr_reg_inst31(.clki(inter_atb_formatter_btm_pcie_r0_fr_reg[31]), .clko(atb_formatter_btm_pcie_r0_fr_reg[31]));
        cell_clk_buf   atb_formatter_btm_pcie_r1_fr_reg_inst0(.clki(inter_atb_formatter_btm_pcie_r1_fr_reg[0]), .clko(atb_formatter_btm_pcie_r1_fr_reg[0]));
        cell_clk_buf   atb_formatter_btm_pcie_r1_fr_reg_inst1(.clki(inter_atb_formatter_btm_pcie_r1_fr_reg[1]), .clko(atb_formatter_btm_pcie_r1_fr_reg[1]));
        cell_clk_buf   atb_formatter_btm_pcie_r1_fr_reg_inst2(.clki(inter_atb_formatter_btm_pcie_r1_fr_reg[2]), .clko(atb_formatter_btm_pcie_r1_fr_reg[2]));
        cell_clk_buf   atb_formatter_btm_pcie_r1_fr_reg_inst3(.clki(inter_atb_formatter_btm_pcie_r1_fr_reg[3]), .clko(atb_formatter_btm_pcie_r1_fr_reg[3]));
        cell_clk_buf   atb_formatter_btm_pcie_r1_fr_reg_inst4(.clki(inter_atb_formatter_btm_pcie_r1_fr_reg[4]), .clko(atb_formatter_btm_pcie_r1_fr_reg[4]));
        cell_clk_buf   atb_formatter_btm_pcie_r1_fr_reg_inst5(.clki(inter_atb_formatter_btm_pcie_r1_fr_reg[5]), .clko(atb_formatter_btm_pcie_r1_fr_reg[5]));
        cell_clk_buf   atb_formatter_btm_pcie_r1_fr_reg_inst6(.clki(inter_atb_formatter_btm_pcie_r1_fr_reg[6]), .clko(atb_formatter_btm_pcie_r1_fr_reg[6]));
        cell_clk_buf   atb_formatter_btm_pcie_r1_fr_reg_inst7(.clki(inter_atb_formatter_btm_pcie_r1_fr_reg[7]), .clko(atb_formatter_btm_pcie_r1_fr_reg[7]));
        cell_clk_buf   atb_formatter_btm_pcie_r1_fr_reg_inst8(.clki(inter_atb_formatter_btm_pcie_r1_fr_reg[8]), .clko(atb_formatter_btm_pcie_r1_fr_reg[8]));
        cell_clk_buf   atb_formatter_btm_pcie_r1_fr_reg_inst9(.clki(inter_atb_formatter_btm_pcie_r1_fr_reg[9]), .clko(atb_formatter_btm_pcie_r1_fr_reg[9]));
        cell_clk_buf   atb_formatter_btm_pcie_r1_fr_reg_inst10(.clki(inter_atb_formatter_btm_pcie_r1_fr_reg[10]), .clko(atb_formatter_btm_pcie_r1_fr_reg[10]));
        cell_clk_buf   atb_formatter_btm_pcie_r1_fr_reg_inst11(.clki(inter_atb_formatter_btm_pcie_r1_fr_reg[11]), .clko(atb_formatter_btm_pcie_r1_fr_reg[11]));
        cell_clk_buf   atb_formatter_btm_pcie_r1_fr_reg_inst12(.clki(inter_atb_formatter_btm_pcie_r1_fr_reg[12]), .clko(atb_formatter_btm_pcie_r1_fr_reg[12]));
        cell_clk_buf   atb_formatter_btm_pcie_r1_fr_reg_inst13(.clki(inter_atb_formatter_btm_pcie_r1_fr_reg[13]), .clko(atb_formatter_btm_pcie_r1_fr_reg[13]));
        cell_clk_buf   atb_formatter_btm_pcie_r1_fr_reg_inst14(.clki(inter_atb_formatter_btm_pcie_r1_fr_reg[14]), .clko(atb_formatter_btm_pcie_r1_fr_reg[14]));
        cell_clk_buf   atb_formatter_btm_pcie_r1_fr_reg_inst15(.clki(inter_atb_formatter_btm_pcie_r1_fr_reg[15]), .clko(atb_formatter_btm_pcie_r1_fr_reg[15]));
        cell_clk_buf   atb_formatter_btm_pcie_r1_fr_reg_inst16(.clki(inter_atb_formatter_btm_pcie_r1_fr_reg[16]), .clko(atb_formatter_btm_pcie_r1_fr_reg[16]));
        cell_clk_buf   atb_formatter_btm_pcie_r1_fr_reg_inst17(.clki(inter_atb_formatter_btm_pcie_r1_fr_reg[17]), .clko(atb_formatter_btm_pcie_r1_fr_reg[17]));
        cell_clk_buf   atb_formatter_btm_pcie_r1_fr_reg_inst18(.clki(inter_atb_formatter_btm_pcie_r1_fr_reg[18]), .clko(atb_formatter_btm_pcie_r1_fr_reg[18]));
        cell_clk_buf   atb_formatter_btm_pcie_r1_fr_reg_inst19(.clki(inter_atb_formatter_btm_pcie_r1_fr_reg[19]), .clko(atb_formatter_btm_pcie_r1_fr_reg[19]));
        cell_clk_buf   atb_formatter_btm_pcie_r1_fr_reg_inst20(.clki(inter_atb_formatter_btm_pcie_r1_fr_reg[20]), .clko(atb_formatter_btm_pcie_r1_fr_reg[20]));
        cell_clk_buf   atb_formatter_btm_pcie_r1_fr_reg_inst21(.clki(inter_atb_formatter_btm_pcie_r1_fr_reg[21]), .clko(atb_formatter_btm_pcie_r1_fr_reg[21]));
        cell_clk_buf   atb_formatter_btm_pcie_r1_fr_reg_inst22(.clki(inter_atb_formatter_btm_pcie_r1_fr_reg[22]), .clko(atb_formatter_btm_pcie_r1_fr_reg[22]));
        cell_clk_buf   atb_formatter_btm_pcie_r1_fr_reg_inst23(.clki(inter_atb_formatter_btm_pcie_r1_fr_reg[23]), .clko(atb_formatter_btm_pcie_r1_fr_reg[23]));
        cell_clk_buf   atb_formatter_btm_pcie_r1_fr_reg_inst24(.clki(inter_atb_formatter_btm_pcie_r1_fr_reg[24]), .clko(atb_formatter_btm_pcie_r1_fr_reg[24]));
        cell_clk_buf   atb_formatter_btm_pcie_r1_fr_reg_inst25(.clki(inter_atb_formatter_btm_pcie_r1_fr_reg[25]), .clko(atb_formatter_btm_pcie_r1_fr_reg[25]));
        cell_clk_buf   atb_formatter_btm_pcie_r1_fr_reg_inst26(.clki(inter_atb_formatter_btm_pcie_r1_fr_reg[26]), .clko(atb_formatter_btm_pcie_r1_fr_reg[26]));
        cell_clk_buf   atb_formatter_btm_pcie_r1_fr_reg_inst27(.clki(inter_atb_formatter_btm_pcie_r1_fr_reg[27]), .clko(atb_formatter_btm_pcie_r1_fr_reg[27]));
        cell_clk_buf   atb_formatter_btm_pcie_r1_fr_reg_inst28(.clki(inter_atb_formatter_btm_pcie_r1_fr_reg[28]), .clko(atb_formatter_btm_pcie_r1_fr_reg[28]));
        cell_clk_buf   atb_formatter_btm_pcie_r1_fr_reg_inst29(.clki(inter_atb_formatter_btm_pcie_r1_fr_reg[29]), .clko(atb_formatter_btm_pcie_r1_fr_reg[29]));
        cell_clk_buf   atb_formatter_btm_pcie_r1_fr_reg_inst30(.clki(inter_atb_formatter_btm_pcie_r1_fr_reg[30]), .clko(atb_formatter_btm_pcie_r1_fr_reg[30]));
        cell_clk_buf   atb_formatter_btm_pcie_r1_fr_reg_inst31(.clki(inter_atb_formatter_btm_pcie_r1_fr_reg[31]), .clko(atb_formatter_btm_pcie_r1_fr_reg[31]));
        cell_clk_buf   atb_formatter_up_ualink0_fr_reg_inst0(.clki(inter_atb_formatter_up_ualink0_fr_reg[0]), .clko(atb_formatter_up_ualink0_fr_reg[0]));
        cell_clk_buf   atb_formatter_up_ualink0_fr_reg_inst1(.clki(inter_atb_formatter_up_ualink0_fr_reg[1]), .clko(atb_formatter_up_ualink0_fr_reg[1]));
        cell_clk_buf   atb_formatter_up_ualink0_fr_reg_inst2(.clki(inter_atb_formatter_up_ualink0_fr_reg[2]), .clko(atb_formatter_up_ualink0_fr_reg[2]));
        cell_clk_buf   atb_formatter_up_ualink0_fr_reg_inst3(.clki(inter_atb_formatter_up_ualink0_fr_reg[3]), .clko(atb_formatter_up_ualink0_fr_reg[3]));
        cell_clk_buf   atb_formatter_up_ualink0_fr_reg_inst4(.clki(inter_atb_formatter_up_ualink0_fr_reg[4]), .clko(atb_formatter_up_ualink0_fr_reg[4]));
        cell_clk_buf   atb_formatter_up_ualink0_fr_reg_inst5(.clki(inter_atb_formatter_up_ualink0_fr_reg[5]), .clko(atb_formatter_up_ualink0_fr_reg[5]));
        cell_clk_buf   atb_formatter_up_ualink0_fr_reg_inst6(.clki(inter_atb_formatter_up_ualink0_fr_reg[6]), .clko(atb_formatter_up_ualink0_fr_reg[6]));
        cell_clk_buf   atb_formatter_up_ualink0_fr_reg_inst7(.clki(inter_atb_formatter_up_ualink0_fr_reg[7]), .clko(atb_formatter_up_ualink0_fr_reg[7]));
        cell_clk_buf   atb_formatter_up_ualink0_fr_reg_inst8(.clki(inter_atb_formatter_up_ualink0_fr_reg[8]), .clko(atb_formatter_up_ualink0_fr_reg[8]));
        cell_clk_buf   atb_formatter_up_ualink0_fr_reg_inst9(.clki(inter_atb_formatter_up_ualink0_fr_reg[9]), .clko(atb_formatter_up_ualink0_fr_reg[9]));
        cell_clk_buf   atb_formatter_up_ualink0_fr_reg_inst10(.clki(inter_atb_formatter_up_ualink0_fr_reg[10]), .clko(atb_formatter_up_ualink0_fr_reg[10]));
        cell_clk_buf   atb_formatter_up_ualink0_fr_reg_inst11(.clki(inter_atb_formatter_up_ualink0_fr_reg[11]), .clko(atb_formatter_up_ualink0_fr_reg[11]));
        cell_clk_buf   atb_formatter_up_ualink0_fr_reg_inst12(.clki(inter_atb_formatter_up_ualink0_fr_reg[12]), .clko(atb_formatter_up_ualink0_fr_reg[12]));
        cell_clk_buf   atb_formatter_up_ualink0_fr_reg_inst13(.clki(inter_atb_formatter_up_ualink0_fr_reg[13]), .clko(atb_formatter_up_ualink0_fr_reg[13]));
        cell_clk_buf   atb_formatter_up_ualink0_fr_reg_inst14(.clki(inter_atb_formatter_up_ualink0_fr_reg[14]), .clko(atb_formatter_up_ualink0_fr_reg[14]));
        cell_clk_buf   atb_formatter_up_ualink0_fr_reg_inst15(.clki(inter_atb_formatter_up_ualink0_fr_reg[15]), .clko(atb_formatter_up_ualink0_fr_reg[15]));
        cell_clk_buf   atb_formatter_up_ualink0_fr_reg_inst16(.clki(inter_atb_formatter_up_ualink0_fr_reg[16]), .clko(atb_formatter_up_ualink0_fr_reg[16]));
        cell_clk_buf   atb_formatter_up_ualink0_fr_reg_inst17(.clki(inter_atb_formatter_up_ualink0_fr_reg[17]), .clko(atb_formatter_up_ualink0_fr_reg[17]));
        cell_clk_buf   atb_formatter_up_ualink0_fr_reg_inst18(.clki(inter_atb_formatter_up_ualink0_fr_reg[18]), .clko(atb_formatter_up_ualink0_fr_reg[18]));
        cell_clk_buf   atb_formatter_up_ualink0_fr_reg_inst19(.clki(inter_atb_formatter_up_ualink0_fr_reg[19]), .clko(atb_formatter_up_ualink0_fr_reg[19]));
        cell_clk_buf   atb_formatter_up_ualink0_fr_reg_inst20(.clki(inter_atb_formatter_up_ualink0_fr_reg[20]), .clko(atb_formatter_up_ualink0_fr_reg[20]));
        cell_clk_buf   atb_formatter_up_ualink0_fr_reg_inst21(.clki(inter_atb_formatter_up_ualink0_fr_reg[21]), .clko(atb_formatter_up_ualink0_fr_reg[21]));
        cell_clk_buf   atb_formatter_up_ualink0_fr_reg_inst22(.clki(inter_atb_formatter_up_ualink0_fr_reg[22]), .clko(atb_formatter_up_ualink0_fr_reg[22]));
        cell_clk_buf   atb_formatter_up_ualink0_fr_reg_inst23(.clki(inter_atb_formatter_up_ualink0_fr_reg[23]), .clko(atb_formatter_up_ualink0_fr_reg[23]));
        cell_clk_buf   atb_formatter_up_ualink0_fr_reg_inst24(.clki(inter_atb_formatter_up_ualink0_fr_reg[24]), .clko(atb_formatter_up_ualink0_fr_reg[24]));
        cell_clk_buf   atb_formatter_up_ualink0_fr_reg_inst25(.clki(inter_atb_formatter_up_ualink0_fr_reg[25]), .clko(atb_formatter_up_ualink0_fr_reg[25]));
        cell_clk_buf   atb_formatter_up_ualink0_fr_reg_inst26(.clki(inter_atb_formatter_up_ualink0_fr_reg[26]), .clko(atb_formatter_up_ualink0_fr_reg[26]));
        cell_clk_buf   atb_formatter_up_ualink0_fr_reg_inst27(.clki(inter_atb_formatter_up_ualink0_fr_reg[27]), .clko(atb_formatter_up_ualink0_fr_reg[27]));
        cell_clk_buf   atb_formatter_up_ualink0_fr_reg_inst28(.clki(inter_atb_formatter_up_ualink0_fr_reg[28]), .clko(atb_formatter_up_ualink0_fr_reg[28]));
        cell_clk_buf   atb_formatter_up_ualink0_fr_reg_inst29(.clki(inter_atb_formatter_up_ualink0_fr_reg[29]), .clko(atb_formatter_up_ualink0_fr_reg[29]));
        cell_clk_buf   atb_formatter_up_ualink0_fr_reg_inst30(.clki(inter_atb_formatter_up_ualink0_fr_reg[30]), .clko(atb_formatter_up_ualink0_fr_reg[30]));
        cell_clk_buf   atb_formatter_up_ualink0_fr_reg_inst31(.clki(inter_atb_formatter_up_ualink0_fr_reg[31]), .clko(atb_formatter_up_ualink0_fr_reg[31]));
        cell_clk_buf   atb_formatter_up_ualink1_fr_reg_inst0(.clki(inter_atb_formatter_up_ualink1_fr_reg[0]), .clko(atb_formatter_up_ualink1_fr_reg[0]));
        cell_clk_buf   atb_formatter_up_ualink1_fr_reg_inst1(.clki(inter_atb_formatter_up_ualink1_fr_reg[1]), .clko(atb_formatter_up_ualink1_fr_reg[1]));
        cell_clk_buf   atb_formatter_up_ualink1_fr_reg_inst2(.clki(inter_atb_formatter_up_ualink1_fr_reg[2]), .clko(atb_formatter_up_ualink1_fr_reg[2]));
        cell_clk_buf   atb_formatter_up_ualink1_fr_reg_inst3(.clki(inter_atb_formatter_up_ualink1_fr_reg[3]), .clko(atb_formatter_up_ualink1_fr_reg[3]));
        cell_clk_buf   atb_formatter_up_ualink1_fr_reg_inst4(.clki(inter_atb_formatter_up_ualink1_fr_reg[4]), .clko(atb_formatter_up_ualink1_fr_reg[4]));
        cell_clk_buf   atb_formatter_up_ualink1_fr_reg_inst5(.clki(inter_atb_formatter_up_ualink1_fr_reg[5]), .clko(atb_formatter_up_ualink1_fr_reg[5]));
        cell_clk_buf   atb_formatter_up_ualink1_fr_reg_inst6(.clki(inter_atb_formatter_up_ualink1_fr_reg[6]), .clko(atb_formatter_up_ualink1_fr_reg[6]));
        cell_clk_buf   atb_formatter_up_ualink1_fr_reg_inst7(.clki(inter_atb_formatter_up_ualink1_fr_reg[7]), .clko(atb_formatter_up_ualink1_fr_reg[7]));
        cell_clk_buf   atb_formatter_up_ualink1_fr_reg_inst8(.clki(inter_atb_formatter_up_ualink1_fr_reg[8]), .clko(atb_formatter_up_ualink1_fr_reg[8]));
        cell_clk_buf   atb_formatter_up_ualink1_fr_reg_inst9(.clki(inter_atb_formatter_up_ualink1_fr_reg[9]), .clko(atb_formatter_up_ualink1_fr_reg[9]));
        cell_clk_buf   atb_formatter_up_ualink1_fr_reg_inst10(.clki(inter_atb_formatter_up_ualink1_fr_reg[10]), .clko(atb_formatter_up_ualink1_fr_reg[10]));
        cell_clk_buf   atb_formatter_up_ualink1_fr_reg_inst11(.clki(inter_atb_formatter_up_ualink1_fr_reg[11]), .clko(atb_formatter_up_ualink1_fr_reg[11]));
        cell_clk_buf   atb_formatter_up_ualink1_fr_reg_inst12(.clki(inter_atb_formatter_up_ualink1_fr_reg[12]), .clko(atb_formatter_up_ualink1_fr_reg[12]));
        cell_clk_buf   atb_formatter_up_ualink1_fr_reg_inst13(.clki(inter_atb_formatter_up_ualink1_fr_reg[13]), .clko(atb_formatter_up_ualink1_fr_reg[13]));
        cell_clk_buf   atb_formatter_up_ualink1_fr_reg_inst14(.clki(inter_atb_formatter_up_ualink1_fr_reg[14]), .clko(atb_formatter_up_ualink1_fr_reg[14]));
        cell_clk_buf   atb_formatter_up_ualink1_fr_reg_inst15(.clki(inter_atb_formatter_up_ualink1_fr_reg[15]), .clko(atb_formatter_up_ualink1_fr_reg[15]));
        cell_clk_buf   atb_formatter_up_ualink1_fr_reg_inst16(.clki(inter_atb_formatter_up_ualink1_fr_reg[16]), .clko(atb_formatter_up_ualink1_fr_reg[16]));
        cell_clk_buf   atb_formatter_up_ualink1_fr_reg_inst17(.clki(inter_atb_formatter_up_ualink1_fr_reg[17]), .clko(atb_formatter_up_ualink1_fr_reg[17]));
        cell_clk_buf   atb_formatter_up_ualink1_fr_reg_inst18(.clki(inter_atb_formatter_up_ualink1_fr_reg[18]), .clko(atb_formatter_up_ualink1_fr_reg[18]));
        cell_clk_buf   atb_formatter_up_ualink1_fr_reg_inst19(.clki(inter_atb_formatter_up_ualink1_fr_reg[19]), .clko(atb_formatter_up_ualink1_fr_reg[19]));
        cell_clk_buf   atb_formatter_up_ualink1_fr_reg_inst20(.clki(inter_atb_formatter_up_ualink1_fr_reg[20]), .clko(atb_formatter_up_ualink1_fr_reg[20]));
        cell_clk_buf   atb_formatter_up_ualink1_fr_reg_inst21(.clki(inter_atb_formatter_up_ualink1_fr_reg[21]), .clko(atb_formatter_up_ualink1_fr_reg[21]));
        cell_clk_buf   atb_formatter_up_ualink1_fr_reg_inst22(.clki(inter_atb_formatter_up_ualink1_fr_reg[22]), .clko(atb_formatter_up_ualink1_fr_reg[22]));
        cell_clk_buf   atb_formatter_up_ualink1_fr_reg_inst23(.clki(inter_atb_formatter_up_ualink1_fr_reg[23]), .clko(atb_formatter_up_ualink1_fr_reg[23]));
        cell_clk_buf   atb_formatter_up_ualink1_fr_reg_inst24(.clki(inter_atb_formatter_up_ualink1_fr_reg[24]), .clko(atb_formatter_up_ualink1_fr_reg[24]));
        cell_clk_buf   atb_formatter_up_ualink1_fr_reg_inst25(.clki(inter_atb_formatter_up_ualink1_fr_reg[25]), .clko(atb_formatter_up_ualink1_fr_reg[25]));
        cell_clk_buf   atb_formatter_up_ualink1_fr_reg_inst26(.clki(inter_atb_formatter_up_ualink1_fr_reg[26]), .clko(atb_formatter_up_ualink1_fr_reg[26]));
        cell_clk_buf   atb_formatter_up_ualink1_fr_reg_inst27(.clki(inter_atb_formatter_up_ualink1_fr_reg[27]), .clko(atb_formatter_up_ualink1_fr_reg[27]));
        cell_clk_buf   atb_formatter_up_ualink1_fr_reg_inst28(.clki(inter_atb_formatter_up_ualink1_fr_reg[28]), .clko(atb_formatter_up_ualink1_fr_reg[28]));
        cell_clk_buf   atb_formatter_up_ualink1_fr_reg_inst29(.clki(inter_atb_formatter_up_ualink1_fr_reg[29]), .clko(atb_formatter_up_ualink1_fr_reg[29]));
        cell_clk_buf   atb_formatter_up_ualink1_fr_reg_inst30(.clki(inter_atb_formatter_up_ualink1_fr_reg[30]), .clko(atb_formatter_up_ualink1_fr_reg[30]));
        cell_clk_buf   atb_formatter_up_ualink1_fr_reg_inst31(.clki(inter_atb_formatter_up_ualink1_fr_reg[31]), .clko(atb_formatter_up_ualink1_fr_reg[31]));
        cell_clk_buf   atb_formatter_ctrl_scp_fr_reg_inst0(.clki(inter_atb_formatter_ctrl_scp_fr_reg[0]), .clko(atb_formatter_ctrl_scp_fr_reg[0]));
        cell_clk_buf   atb_formatter_ctrl_scp_fr_reg_inst1(.clki(inter_atb_formatter_ctrl_scp_fr_reg[1]), .clko(atb_formatter_ctrl_scp_fr_reg[1]));
        cell_clk_buf   atb_formatter_ctrl_scp_fr_reg_inst2(.clki(inter_atb_formatter_ctrl_scp_fr_reg[2]), .clko(atb_formatter_ctrl_scp_fr_reg[2]));
        cell_clk_buf   atb_formatter_ctrl_scp_fr_reg_inst3(.clki(inter_atb_formatter_ctrl_scp_fr_reg[3]), .clko(atb_formatter_ctrl_scp_fr_reg[3]));
        cell_clk_buf   atb_formatter_ctrl_scp_fr_reg_inst4(.clki(inter_atb_formatter_ctrl_scp_fr_reg[4]), .clko(atb_formatter_ctrl_scp_fr_reg[4]));
        cell_clk_buf   atb_formatter_ctrl_scp_fr_reg_inst5(.clki(inter_atb_formatter_ctrl_scp_fr_reg[5]), .clko(atb_formatter_ctrl_scp_fr_reg[5]));
        cell_clk_buf   atb_formatter_ctrl_scp_fr_reg_inst6(.clki(inter_atb_formatter_ctrl_scp_fr_reg[6]), .clko(atb_formatter_ctrl_scp_fr_reg[6]));
        cell_clk_buf   atb_formatter_ctrl_scp_fr_reg_inst7(.clki(inter_atb_formatter_ctrl_scp_fr_reg[7]), .clko(atb_formatter_ctrl_scp_fr_reg[7]));
        cell_clk_buf   atb_formatter_ctrl_scp_fr_reg_inst8(.clki(inter_atb_formatter_ctrl_scp_fr_reg[8]), .clko(atb_formatter_ctrl_scp_fr_reg[8]));
        cell_clk_buf   atb_formatter_ctrl_scp_fr_reg_inst9(.clki(inter_atb_formatter_ctrl_scp_fr_reg[9]), .clko(atb_formatter_ctrl_scp_fr_reg[9]));
        cell_clk_buf   atb_formatter_ctrl_scp_fr_reg_inst10(.clki(inter_atb_formatter_ctrl_scp_fr_reg[10]), .clko(atb_formatter_ctrl_scp_fr_reg[10]));
        cell_clk_buf   atb_formatter_ctrl_scp_fr_reg_inst11(.clki(inter_atb_formatter_ctrl_scp_fr_reg[11]), .clko(atb_formatter_ctrl_scp_fr_reg[11]));
        cell_clk_buf   atb_formatter_ctrl_scp_fr_reg_inst12(.clki(inter_atb_formatter_ctrl_scp_fr_reg[12]), .clko(atb_formatter_ctrl_scp_fr_reg[12]));
        cell_clk_buf   atb_formatter_ctrl_scp_fr_reg_inst13(.clki(inter_atb_formatter_ctrl_scp_fr_reg[13]), .clko(atb_formatter_ctrl_scp_fr_reg[13]));
        cell_clk_buf   atb_formatter_ctrl_scp_fr_reg_inst14(.clki(inter_atb_formatter_ctrl_scp_fr_reg[14]), .clko(atb_formatter_ctrl_scp_fr_reg[14]));
        cell_clk_buf   atb_formatter_ctrl_scp_fr_reg_inst15(.clki(inter_atb_formatter_ctrl_scp_fr_reg[15]), .clko(atb_formatter_ctrl_scp_fr_reg[15]));
        cell_clk_buf   atb_formatter_ctrl_scp_fr_reg_inst16(.clki(inter_atb_formatter_ctrl_scp_fr_reg[16]), .clko(atb_formatter_ctrl_scp_fr_reg[16]));
        cell_clk_buf   atb_formatter_ctrl_scp_fr_reg_inst17(.clki(inter_atb_formatter_ctrl_scp_fr_reg[17]), .clko(atb_formatter_ctrl_scp_fr_reg[17]));
        cell_clk_buf   atb_formatter_ctrl_scp_fr_reg_inst18(.clki(inter_atb_formatter_ctrl_scp_fr_reg[18]), .clko(atb_formatter_ctrl_scp_fr_reg[18]));
        cell_clk_buf   atb_formatter_ctrl_scp_fr_reg_inst19(.clki(inter_atb_formatter_ctrl_scp_fr_reg[19]), .clko(atb_formatter_ctrl_scp_fr_reg[19]));
        cell_clk_buf   atb_formatter_ctrl_scp_fr_reg_inst20(.clki(inter_atb_formatter_ctrl_scp_fr_reg[20]), .clko(atb_formatter_ctrl_scp_fr_reg[20]));
        cell_clk_buf   atb_formatter_ctrl_scp_fr_reg_inst21(.clki(inter_atb_formatter_ctrl_scp_fr_reg[21]), .clko(atb_formatter_ctrl_scp_fr_reg[21]));
        cell_clk_buf   atb_formatter_ctrl_scp_fr_reg_inst22(.clki(inter_atb_formatter_ctrl_scp_fr_reg[22]), .clko(atb_formatter_ctrl_scp_fr_reg[22]));
        cell_clk_buf   atb_formatter_ctrl_scp_fr_reg_inst23(.clki(inter_atb_formatter_ctrl_scp_fr_reg[23]), .clko(atb_formatter_ctrl_scp_fr_reg[23]));
        cell_clk_buf   atb_formatter_ctrl_scp_fr_reg_inst24(.clki(inter_atb_formatter_ctrl_scp_fr_reg[24]), .clko(atb_formatter_ctrl_scp_fr_reg[24]));
        cell_clk_buf   atb_formatter_ctrl_scp_fr_reg_inst25(.clki(inter_atb_formatter_ctrl_scp_fr_reg[25]), .clko(atb_formatter_ctrl_scp_fr_reg[25]));
        cell_clk_buf   atb_formatter_ctrl_scp_fr_reg_inst26(.clki(inter_atb_formatter_ctrl_scp_fr_reg[26]), .clko(atb_formatter_ctrl_scp_fr_reg[26]));
        cell_clk_buf   atb_formatter_ctrl_scp_fr_reg_inst27(.clki(inter_atb_formatter_ctrl_scp_fr_reg[27]), .clko(atb_formatter_ctrl_scp_fr_reg[27]));
        cell_clk_buf   atb_formatter_ctrl_scp_fr_reg_inst28(.clki(inter_atb_formatter_ctrl_scp_fr_reg[28]), .clko(atb_formatter_ctrl_scp_fr_reg[28]));
        cell_clk_buf   atb_formatter_ctrl_scp_fr_reg_inst29(.clki(inter_atb_formatter_ctrl_scp_fr_reg[29]), .clko(atb_formatter_ctrl_scp_fr_reg[29]));
        cell_clk_buf   atb_formatter_ctrl_scp_fr_reg_inst30(.clki(inter_atb_formatter_ctrl_scp_fr_reg[30]), .clko(atb_formatter_ctrl_scp_fr_reg[30]));
        cell_clk_buf   atb_formatter_ctrl_scp_fr_reg_inst31(.clki(inter_atb_formatter_ctrl_scp_fr_reg[31]), .clko(atb_formatter_ctrl_scp_fr_reg[31]));
        cell_clk_buf   atb_formatter_vpu0_vdec_fr_reg_inst0(.clki(inter_atb_formatter_vpu0_vdec_fr_reg[0]), .clko(atb_formatter_vpu0_vdec_fr_reg[0]));
        cell_clk_buf   atb_formatter_vpu0_vdec_fr_reg_inst1(.clki(inter_atb_formatter_vpu0_vdec_fr_reg[1]), .clko(atb_formatter_vpu0_vdec_fr_reg[1]));
        cell_clk_buf   atb_formatter_vpu0_vdec_fr_reg_inst2(.clki(inter_atb_formatter_vpu0_vdec_fr_reg[2]), .clko(atb_formatter_vpu0_vdec_fr_reg[2]));
        cell_clk_buf   atb_formatter_vpu0_vdec_fr_reg_inst3(.clki(inter_atb_formatter_vpu0_vdec_fr_reg[3]), .clko(atb_formatter_vpu0_vdec_fr_reg[3]));
        cell_clk_buf   atb_formatter_vpu0_vdec_fr_reg_inst4(.clki(inter_atb_formatter_vpu0_vdec_fr_reg[4]), .clko(atb_formatter_vpu0_vdec_fr_reg[4]));
        cell_clk_buf   atb_formatter_vpu0_vdec_fr_reg_inst5(.clki(inter_atb_formatter_vpu0_vdec_fr_reg[5]), .clko(atb_formatter_vpu0_vdec_fr_reg[5]));
        cell_clk_buf   atb_formatter_vpu0_vdec_fr_reg_inst6(.clki(inter_atb_formatter_vpu0_vdec_fr_reg[6]), .clko(atb_formatter_vpu0_vdec_fr_reg[6]));
        cell_clk_buf   atb_formatter_vpu0_vdec_fr_reg_inst7(.clki(inter_atb_formatter_vpu0_vdec_fr_reg[7]), .clko(atb_formatter_vpu0_vdec_fr_reg[7]));
        cell_clk_buf   atb_formatter_vpu0_vdec_fr_reg_inst8(.clki(inter_atb_formatter_vpu0_vdec_fr_reg[8]), .clko(atb_formatter_vpu0_vdec_fr_reg[8]));
        cell_clk_buf   atb_formatter_vpu0_vdec_fr_reg_inst9(.clki(inter_atb_formatter_vpu0_vdec_fr_reg[9]), .clko(atb_formatter_vpu0_vdec_fr_reg[9]));
        cell_clk_buf   atb_formatter_vpu0_vdec_fr_reg_inst10(.clki(inter_atb_formatter_vpu0_vdec_fr_reg[10]), .clko(atb_formatter_vpu0_vdec_fr_reg[10]));
        cell_clk_buf   atb_formatter_vpu0_vdec_fr_reg_inst11(.clki(inter_atb_formatter_vpu0_vdec_fr_reg[11]), .clko(atb_formatter_vpu0_vdec_fr_reg[11]));
        cell_clk_buf   atb_formatter_vpu0_vdec_fr_reg_inst12(.clki(inter_atb_formatter_vpu0_vdec_fr_reg[12]), .clko(atb_formatter_vpu0_vdec_fr_reg[12]));
        cell_clk_buf   atb_formatter_vpu0_vdec_fr_reg_inst13(.clki(inter_atb_formatter_vpu0_vdec_fr_reg[13]), .clko(atb_formatter_vpu0_vdec_fr_reg[13]));
        cell_clk_buf   atb_formatter_vpu0_vdec_fr_reg_inst14(.clki(inter_atb_formatter_vpu0_vdec_fr_reg[14]), .clko(atb_formatter_vpu0_vdec_fr_reg[14]));
        cell_clk_buf   atb_formatter_vpu0_vdec_fr_reg_inst15(.clki(inter_atb_formatter_vpu0_vdec_fr_reg[15]), .clko(atb_formatter_vpu0_vdec_fr_reg[15]));
        cell_clk_buf   atb_formatter_vpu0_vdec_fr_reg_inst16(.clki(inter_atb_formatter_vpu0_vdec_fr_reg[16]), .clko(atb_formatter_vpu0_vdec_fr_reg[16]));
        cell_clk_buf   atb_formatter_vpu0_vdec_fr_reg_inst17(.clki(inter_atb_formatter_vpu0_vdec_fr_reg[17]), .clko(atb_formatter_vpu0_vdec_fr_reg[17]));
        cell_clk_buf   atb_formatter_vpu0_vdec_fr_reg_inst18(.clki(inter_atb_formatter_vpu0_vdec_fr_reg[18]), .clko(atb_formatter_vpu0_vdec_fr_reg[18]));
        cell_clk_buf   atb_formatter_vpu0_vdec_fr_reg_inst19(.clki(inter_atb_formatter_vpu0_vdec_fr_reg[19]), .clko(atb_formatter_vpu0_vdec_fr_reg[19]));
        cell_clk_buf   atb_formatter_vpu0_vdec_fr_reg_inst20(.clki(inter_atb_formatter_vpu0_vdec_fr_reg[20]), .clko(atb_formatter_vpu0_vdec_fr_reg[20]));
        cell_clk_buf   atb_formatter_vpu0_vdec_fr_reg_inst21(.clki(inter_atb_formatter_vpu0_vdec_fr_reg[21]), .clko(atb_formatter_vpu0_vdec_fr_reg[21]));
        cell_clk_buf   atb_formatter_vpu0_vdec_fr_reg_inst22(.clki(inter_atb_formatter_vpu0_vdec_fr_reg[22]), .clko(atb_formatter_vpu0_vdec_fr_reg[22]));
        cell_clk_buf   atb_formatter_vpu0_vdec_fr_reg_inst23(.clki(inter_atb_formatter_vpu0_vdec_fr_reg[23]), .clko(atb_formatter_vpu0_vdec_fr_reg[23]));
        cell_clk_buf   atb_formatter_vpu0_vdec_fr_reg_inst24(.clki(inter_atb_formatter_vpu0_vdec_fr_reg[24]), .clko(atb_formatter_vpu0_vdec_fr_reg[24]));
        cell_clk_buf   atb_formatter_vpu0_vdec_fr_reg_inst25(.clki(inter_atb_formatter_vpu0_vdec_fr_reg[25]), .clko(atb_formatter_vpu0_vdec_fr_reg[25]));
        cell_clk_buf   atb_formatter_vpu0_vdec_fr_reg_inst26(.clki(inter_atb_formatter_vpu0_vdec_fr_reg[26]), .clko(atb_formatter_vpu0_vdec_fr_reg[26]));
        cell_clk_buf   atb_formatter_vpu0_vdec_fr_reg_inst27(.clki(inter_atb_formatter_vpu0_vdec_fr_reg[27]), .clko(atb_formatter_vpu0_vdec_fr_reg[27]));
        cell_clk_buf   atb_formatter_vpu0_vdec_fr_reg_inst28(.clki(inter_atb_formatter_vpu0_vdec_fr_reg[28]), .clko(atb_formatter_vpu0_vdec_fr_reg[28]));
        cell_clk_buf   atb_formatter_vpu0_vdec_fr_reg_inst29(.clki(inter_atb_formatter_vpu0_vdec_fr_reg[29]), .clko(atb_formatter_vpu0_vdec_fr_reg[29]));
        cell_clk_buf   atb_formatter_vpu0_vdec_fr_reg_inst30(.clki(inter_atb_formatter_vpu0_vdec_fr_reg[30]), .clko(atb_formatter_vpu0_vdec_fr_reg[30]));
        cell_clk_buf   atb_formatter_vpu0_vdec_fr_reg_inst31(.clki(inter_atb_formatter_vpu0_vdec_fr_reg[31]), .clko(atb_formatter_vpu0_vdec_fr_reg[31]));
        cell_clk_buf   atb_formatter_vpu0_jpeg0_fr_reg_inst0(.clki(inter_atb_formatter_vpu0_jpeg0_fr_reg[0]), .clko(atb_formatter_vpu0_jpeg0_fr_reg[0]));
        cell_clk_buf   atb_formatter_vpu0_jpeg0_fr_reg_inst1(.clki(inter_atb_formatter_vpu0_jpeg0_fr_reg[1]), .clko(atb_formatter_vpu0_jpeg0_fr_reg[1]));
        cell_clk_buf   atb_formatter_vpu0_jpeg0_fr_reg_inst2(.clki(inter_atb_formatter_vpu0_jpeg0_fr_reg[2]), .clko(atb_formatter_vpu0_jpeg0_fr_reg[2]));
        cell_clk_buf   atb_formatter_vpu0_jpeg0_fr_reg_inst3(.clki(inter_atb_formatter_vpu0_jpeg0_fr_reg[3]), .clko(atb_formatter_vpu0_jpeg0_fr_reg[3]));
        cell_clk_buf   atb_formatter_vpu0_jpeg0_fr_reg_inst4(.clki(inter_atb_formatter_vpu0_jpeg0_fr_reg[4]), .clko(atb_formatter_vpu0_jpeg0_fr_reg[4]));
        cell_clk_buf   atb_formatter_vpu0_jpeg0_fr_reg_inst5(.clki(inter_atb_formatter_vpu0_jpeg0_fr_reg[5]), .clko(atb_formatter_vpu0_jpeg0_fr_reg[5]));
        cell_clk_buf   atb_formatter_vpu0_jpeg0_fr_reg_inst6(.clki(inter_atb_formatter_vpu0_jpeg0_fr_reg[6]), .clko(atb_formatter_vpu0_jpeg0_fr_reg[6]));
        cell_clk_buf   atb_formatter_vpu0_jpeg0_fr_reg_inst7(.clki(inter_atb_formatter_vpu0_jpeg0_fr_reg[7]), .clko(atb_formatter_vpu0_jpeg0_fr_reg[7]));
        cell_clk_buf   atb_formatter_vpu0_jpeg0_fr_reg_inst8(.clki(inter_atb_formatter_vpu0_jpeg0_fr_reg[8]), .clko(atb_formatter_vpu0_jpeg0_fr_reg[8]));
        cell_clk_buf   atb_formatter_vpu0_jpeg0_fr_reg_inst9(.clki(inter_atb_formatter_vpu0_jpeg0_fr_reg[9]), .clko(atb_formatter_vpu0_jpeg0_fr_reg[9]));
        cell_clk_buf   atb_formatter_vpu0_jpeg0_fr_reg_inst10(.clki(inter_atb_formatter_vpu0_jpeg0_fr_reg[10]), .clko(atb_formatter_vpu0_jpeg0_fr_reg[10]));
        cell_clk_buf   atb_formatter_vpu0_jpeg0_fr_reg_inst11(.clki(inter_atb_formatter_vpu0_jpeg0_fr_reg[11]), .clko(atb_formatter_vpu0_jpeg0_fr_reg[11]));
        cell_clk_buf   atb_formatter_vpu0_jpeg0_fr_reg_inst12(.clki(inter_atb_formatter_vpu0_jpeg0_fr_reg[12]), .clko(atb_formatter_vpu0_jpeg0_fr_reg[12]));
        cell_clk_buf   atb_formatter_vpu0_jpeg0_fr_reg_inst13(.clki(inter_atb_formatter_vpu0_jpeg0_fr_reg[13]), .clko(atb_formatter_vpu0_jpeg0_fr_reg[13]));
        cell_clk_buf   atb_formatter_vpu0_jpeg0_fr_reg_inst14(.clki(inter_atb_formatter_vpu0_jpeg0_fr_reg[14]), .clko(atb_formatter_vpu0_jpeg0_fr_reg[14]));
        cell_clk_buf   atb_formatter_vpu0_jpeg0_fr_reg_inst15(.clki(inter_atb_formatter_vpu0_jpeg0_fr_reg[15]), .clko(atb_formatter_vpu0_jpeg0_fr_reg[15]));
        cell_clk_buf   atb_formatter_vpu0_jpeg0_fr_reg_inst16(.clki(inter_atb_formatter_vpu0_jpeg0_fr_reg[16]), .clko(atb_formatter_vpu0_jpeg0_fr_reg[16]));
        cell_clk_buf   atb_formatter_vpu0_jpeg0_fr_reg_inst17(.clki(inter_atb_formatter_vpu0_jpeg0_fr_reg[17]), .clko(atb_formatter_vpu0_jpeg0_fr_reg[17]));
        cell_clk_buf   atb_formatter_vpu0_jpeg0_fr_reg_inst18(.clki(inter_atb_formatter_vpu0_jpeg0_fr_reg[18]), .clko(atb_formatter_vpu0_jpeg0_fr_reg[18]));
        cell_clk_buf   atb_formatter_vpu0_jpeg0_fr_reg_inst19(.clki(inter_atb_formatter_vpu0_jpeg0_fr_reg[19]), .clko(atb_formatter_vpu0_jpeg0_fr_reg[19]));
        cell_clk_buf   atb_formatter_vpu0_jpeg0_fr_reg_inst20(.clki(inter_atb_formatter_vpu0_jpeg0_fr_reg[20]), .clko(atb_formatter_vpu0_jpeg0_fr_reg[20]));
        cell_clk_buf   atb_formatter_vpu0_jpeg0_fr_reg_inst21(.clki(inter_atb_formatter_vpu0_jpeg0_fr_reg[21]), .clko(atb_formatter_vpu0_jpeg0_fr_reg[21]));
        cell_clk_buf   atb_formatter_vpu0_jpeg0_fr_reg_inst22(.clki(inter_atb_formatter_vpu0_jpeg0_fr_reg[22]), .clko(atb_formatter_vpu0_jpeg0_fr_reg[22]));
        cell_clk_buf   atb_formatter_vpu0_jpeg0_fr_reg_inst23(.clki(inter_atb_formatter_vpu0_jpeg0_fr_reg[23]), .clko(atb_formatter_vpu0_jpeg0_fr_reg[23]));
        cell_clk_buf   atb_formatter_vpu0_jpeg0_fr_reg_inst24(.clki(inter_atb_formatter_vpu0_jpeg0_fr_reg[24]), .clko(atb_formatter_vpu0_jpeg0_fr_reg[24]));
        cell_clk_buf   atb_formatter_vpu0_jpeg0_fr_reg_inst25(.clki(inter_atb_formatter_vpu0_jpeg0_fr_reg[25]), .clko(atb_formatter_vpu0_jpeg0_fr_reg[25]));
        cell_clk_buf   atb_formatter_vpu0_jpeg0_fr_reg_inst26(.clki(inter_atb_formatter_vpu0_jpeg0_fr_reg[26]), .clko(atb_formatter_vpu0_jpeg0_fr_reg[26]));
        cell_clk_buf   atb_formatter_vpu0_jpeg0_fr_reg_inst27(.clki(inter_atb_formatter_vpu0_jpeg0_fr_reg[27]), .clko(atb_formatter_vpu0_jpeg0_fr_reg[27]));
        cell_clk_buf   atb_formatter_vpu0_jpeg0_fr_reg_inst28(.clki(inter_atb_formatter_vpu0_jpeg0_fr_reg[28]), .clko(atb_formatter_vpu0_jpeg0_fr_reg[28]));
        cell_clk_buf   atb_formatter_vpu0_jpeg0_fr_reg_inst29(.clki(inter_atb_formatter_vpu0_jpeg0_fr_reg[29]), .clko(atb_formatter_vpu0_jpeg0_fr_reg[29]));
        cell_clk_buf   atb_formatter_vpu0_jpeg0_fr_reg_inst30(.clki(inter_atb_formatter_vpu0_jpeg0_fr_reg[30]), .clko(atb_formatter_vpu0_jpeg0_fr_reg[30]));
        cell_clk_buf   atb_formatter_vpu0_jpeg0_fr_reg_inst31(.clki(inter_atb_formatter_vpu0_jpeg0_fr_reg[31]), .clko(atb_formatter_vpu0_jpeg0_fr_reg[31]));
        cell_clk_buf   atb_formatter_vpu0_jpeg1_fr_reg_inst0(.clki(inter_atb_formatter_vpu0_jpeg1_fr_reg[0]), .clko(atb_formatter_vpu0_jpeg1_fr_reg[0]));
        cell_clk_buf   atb_formatter_vpu0_jpeg1_fr_reg_inst1(.clki(inter_atb_formatter_vpu0_jpeg1_fr_reg[1]), .clko(atb_formatter_vpu0_jpeg1_fr_reg[1]));
        cell_clk_buf   atb_formatter_vpu0_jpeg1_fr_reg_inst2(.clki(inter_atb_formatter_vpu0_jpeg1_fr_reg[2]), .clko(atb_formatter_vpu0_jpeg1_fr_reg[2]));
        cell_clk_buf   atb_formatter_vpu0_jpeg1_fr_reg_inst3(.clki(inter_atb_formatter_vpu0_jpeg1_fr_reg[3]), .clko(atb_formatter_vpu0_jpeg1_fr_reg[3]));
        cell_clk_buf   atb_formatter_vpu0_jpeg1_fr_reg_inst4(.clki(inter_atb_formatter_vpu0_jpeg1_fr_reg[4]), .clko(atb_formatter_vpu0_jpeg1_fr_reg[4]));
        cell_clk_buf   atb_formatter_vpu0_jpeg1_fr_reg_inst5(.clki(inter_atb_formatter_vpu0_jpeg1_fr_reg[5]), .clko(atb_formatter_vpu0_jpeg1_fr_reg[5]));
        cell_clk_buf   atb_formatter_vpu0_jpeg1_fr_reg_inst6(.clki(inter_atb_formatter_vpu0_jpeg1_fr_reg[6]), .clko(atb_formatter_vpu0_jpeg1_fr_reg[6]));
        cell_clk_buf   atb_formatter_vpu0_jpeg1_fr_reg_inst7(.clki(inter_atb_formatter_vpu0_jpeg1_fr_reg[7]), .clko(atb_formatter_vpu0_jpeg1_fr_reg[7]));
        cell_clk_buf   atb_formatter_vpu0_jpeg1_fr_reg_inst8(.clki(inter_atb_formatter_vpu0_jpeg1_fr_reg[8]), .clko(atb_formatter_vpu0_jpeg1_fr_reg[8]));
        cell_clk_buf   atb_formatter_vpu0_jpeg1_fr_reg_inst9(.clki(inter_atb_formatter_vpu0_jpeg1_fr_reg[9]), .clko(atb_formatter_vpu0_jpeg1_fr_reg[9]));
        cell_clk_buf   atb_formatter_vpu0_jpeg1_fr_reg_inst10(.clki(inter_atb_formatter_vpu0_jpeg1_fr_reg[10]), .clko(atb_formatter_vpu0_jpeg1_fr_reg[10]));
        cell_clk_buf   atb_formatter_vpu0_jpeg1_fr_reg_inst11(.clki(inter_atb_formatter_vpu0_jpeg1_fr_reg[11]), .clko(atb_formatter_vpu0_jpeg1_fr_reg[11]));
        cell_clk_buf   atb_formatter_vpu0_jpeg1_fr_reg_inst12(.clki(inter_atb_formatter_vpu0_jpeg1_fr_reg[12]), .clko(atb_formatter_vpu0_jpeg1_fr_reg[12]));
        cell_clk_buf   atb_formatter_vpu0_jpeg1_fr_reg_inst13(.clki(inter_atb_formatter_vpu0_jpeg1_fr_reg[13]), .clko(atb_formatter_vpu0_jpeg1_fr_reg[13]));
        cell_clk_buf   atb_formatter_vpu0_jpeg1_fr_reg_inst14(.clki(inter_atb_formatter_vpu0_jpeg1_fr_reg[14]), .clko(atb_formatter_vpu0_jpeg1_fr_reg[14]));
        cell_clk_buf   atb_formatter_vpu0_jpeg1_fr_reg_inst15(.clki(inter_atb_formatter_vpu0_jpeg1_fr_reg[15]), .clko(atb_formatter_vpu0_jpeg1_fr_reg[15]));
        cell_clk_buf   atb_formatter_vpu0_jpeg1_fr_reg_inst16(.clki(inter_atb_formatter_vpu0_jpeg1_fr_reg[16]), .clko(atb_formatter_vpu0_jpeg1_fr_reg[16]));
        cell_clk_buf   atb_formatter_vpu0_jpeg1_fr_reg_inst17(.clki(inter_atb_formatter_vpu0_jpeg1_fr_reg[17]), .clko(atb_formatter_vpu0_jpeg1_fr_reg[17]));
        cell_clk_buf   atb_formatter_vpu0_jpeg1_fr_reg_inst18(.clki(inter_atb_formatter_vpu0_jpeg1_fr_reg[18]), .clko(atb_formatter_vpu0_jpeg1_fr_reg[18]));
        cell_clk_buf   atb_formatter_vpu0_jpeg1_fr_reg_inst19(.clki(inter_atb_formatter_vpu0_jpeg1_fr_reg[19]), .clko(atb_formatter_vpu0_jpeg1_fr_reg[19]));
        cell_clk_buf   atb_formatter_vpu0_jpeg1_fr_reg_inst20(.clki(inter_atb_formatter_vpu0_jpeg1_fr_reg[20]), .clko(atb_formatter_vpu0_jpeg1_fr_reg[20]));
        cell_clk_buf   atb_formatter_vpu0_jpeg1_fr_reg_inst21(.clki(inter_atb_formatter_vpu0_jpeg1_fr_reg[21]), .clko(atb_formatter_vpu0_jpeg1_fr_reg[21]));
        cell_clk_buf   atb_formatter_vpu0_jpeg1_fr_reg_inst22(.clki(inter_atb_formatter_vpu0_jpeg1_fr_reg[22]), .clko(atb_formatter_vpu0_jpeg1_fr_reg[22]));
        cell_clk_buf   atb_formatter_vpu0_jpeg1_fr_reg_inst23(.clki(inter_atb_formatter_vpu0_jpeg1_fr_reg[23]), .clko(atb_formatter_vpu0_jpeg1_fr_reg[23]));
        cell_clk_buf   atb_formatter_vpu0_jpeg1_fr_reg_inst24(.clki(inter_atb_formatter_vpu0_jpeg1_fr_reg[24]), .clko(atb_formatter_vpu0_jpeg1_fr_reg[24]));
        cell_clk_buf   atb_formatter_vpu0_jpeg1_fr_reg_inst25(.clki(inter_atb_formatter_vpu0_jpeg1_fr_reg[25]), .clko(atb_formatter_vpu0_jpeg1_fr_reg[25]));
        cell_clk_buf   atb_formatter_vpu0_jpeg1_fr_reg_inst26(.clki(inter_atb_formatter_vpu0_jpeg1_fr_reg[26]), .clko(atb_formatter_vpu0_jpeg1_fr_reg[26]));
        cell_clk_buf   atb_formatter_vpu0_jpeg1_fr_reg_inst27(.clki(inter_atb_formatter_vpu0_jpeg1_fr_reg[27]), .clko(atb_formatter_vpu0_jpeg1_fr_reg[27]));
        cell_clk_buf   atb_formatter_vpu0_jpeg1_fr_reg_inst28(.clki(inter_atb_formatter_vpu0_jpeg1_fr_reg[28]), .clko(atb_formatter_vpu0_jpeg1_fr_reg[28]));
        cell_clk_buf   atb_formatter_vpu0_jpeg1_fr_reg_inst29(.clki(inter_atb_formatter_vpu0_jpeg1_fr_reg[29]), .clko(atb_formatter_vpu0_jpeg1_fr_reg[29]));
        cell_clk_buf   atb_formatter_vpu0_jpeg1_fr_reg_inst30(.clki(inter_atb_formatter_vpu0_jpeg1_fr_reg[30]), .clko(atb_formatter_vpu0_jpeg1_fr_reg[30]));
        cell_clk_buf   atb_formatter_vpu0_jpeg1_fr_reg_inst31(.clki(inter_atb_formatter_vpu0_jpeg1_fr_reg[31]), .clko(atb_formatter_vpu0_jpeg1_fr_reg[31]));
        cell_clk_buf   atb_formatter_vpu1_vdec_fr_reg_inst0(.clki(inter_atb_formatter_vpu1_vdec_fr_reg[0]), .clko(atb_formatter_vpu1_vdec_fr_reg[0]));
        cell_clk_buf   atb_formatter_vpu1_vdec_fr_reg_inst1(.clki(inter_atb_formatter_vpu1_vdec_fr_reg[1]), .clko(atb_formatter_vpu1_vdec_fr_reg[1]));
        cell_clk_buf   atb_formatter_vpu1_vdec_fr_reg_inst2(.clki(inter_atb_formatter_vpu1_vdec_fr_reg[2]), .clko(atb_formatter_vpu1_vdec_fr_reg[2]));
        cell_clk_buf   atb_formatter_vpu1_vdec_fr_reg_inst3(.clki(inter_atb_formatter_vpu1_vdec_fr_reg[3]), .clko(atb_formatter_vpu1_vdec_fr_reg[3]));
        cell_clk_buf   atb_formatter_vpu1_vdec_fr_reg_inst4(.clki(inter_atb_formatter_vpu1_vdec_fr_reg[4]), .clko(atb_formatter_vpu1_vdec_fr_reg[4]));
        cell_clk_buf   atb_formatter_vpu1_vdec_fr_reg_inst5(.clki(inter_atb_formatter_vpu1_vdec_fr_reg[5]), .clko(atb_formatter_vpu1_vdec_fr_reg[5]));
        cell_clk_buf   atb_formatter_vpu1_vdec_fr_reg_inst6(.clki(inter_atb_formatter_vpu1_vdec_fr_reg[6]), .clko(atb_formatter_vpu1_vdec_fr_reg[6]));
        cell_clk_buf   atb_formatter_vpu1_vdec_fr_reg_inst7(.clki(inter_atb_formatter_vpu1_vdec_fr_reg[7]), .clko(atb_formatter_vpu1_vdec_fr_reg[7]));
        cell_clk_buf   atb_formatter_vpu1_vdec_fr_reg_inst8(.clki(inter_atb_formatter_vpu1_vdec_fr_reg[8]), .clko(atb_formatter_vpu1_vdec_fr_reg[8]));
        cell_clk_buf   atb_formatter_vpu1_vdec_fr_reg_inst9(.clki(inter_atb_formatter_vpu1_vdec_fr_reg[9]), .clko(atb_formatter_vpu1_vdec_fr_reg[9]));
        cell_clk_buf   atb_formatter_vpu1_vdec_fr_reg_inst10(.clki(inter_atb_formatter_vpu1_vdec_fr_reg[10]), .clko(atb_formatter_vpu1_vdec_fr_reg[10]));
        cell_clk_buf   atb_formatter_vpu1_vdec_fr_reg_inst11(.clki(inter_atb_formatter_vpu1_vdec_fr_reg[11]), .clko(atb_formatter_vpu1_vdec_fr_reg[11]));
        cell_clk_buf   atb_formatter_vpu1_vdec_fr_reg_inst12(.clki(inter_atb_formatter_vpu1_vdec_fr_reg[12]), .clko(atb_formatter_vpu1_vdec_fr_reg[12]));
        cell_clk_buf   atb_formatter_vpu1_vdec_fr_reg_inst13(.clki(inter_atb_formatter_vpu1_vdec_fr_reg[13]), .clko(atb_formatter_vpu1_vdec_fr_reg[13]));
        cell_clk_buf   atb_formatter_vpu1_vdec_fr_reg_inst14(.clki(inter_atb_formatter_vpu1_vdec_fr_reg[14]), .clko(atb_formatter_vpu1_vdec_fr_reg[14]));
        cell_clk_buf   atb_formatter_vpu1_vdec_fr_reg_inst15(.clki(inter_atb_formatter_vpu1_vdec_fr_reg[15]), .clko(atb_formatter_vpu1_vdec_fr_reg[15]));
        cell_clk_buf   atb_formatter_vpu1_vdec_fr_reg_inst16(.clki(inter_atb_formatter_vpu1_vdec_fr_reg[16]), .clko(atb_formatter_vpu1_vdec_fr_reg[16]));
        cell_clk_buf   atb_formatter_vpu1_vdec_fr_reg_inst17(.clki(inter_atb_formatter_vpu1_vdec_fr_reg[17]), .clko(atb_formatter_vpu1_vdec_fr_reg[17]));
        cell_clk_buf   atb_formatter_vpu1_vdec_fr_reg_inst18(.clki(inter_atb_formatter_vpu1_vdec_fr_reg[18]), .clko(atb_formatter_vpu1_vdec_fr_reg[18]));
        cell_clk_buf   atb_formatter_vpu1_vdec_fr_reg_inst19(.clki(inter_atb_formatter_vpu1_vdec_fr_reg[19]), .clko(atb_formatter_vpu1_vdec_fr_reg[19]));
        cell_clk_buf   atb_formatter_vpu1_vdec_fr_reg_inst20(.clki(inter_atb_formatter_vpu1_vdec_fr_reg[20]), .clko(atb_formatter_vpu1_vdec_fr_reg[20]));
        cell_clk_buf   atb_formatter_vpu1_vdec_fr_reg_inst21(.clki(inter_atb_formatter_vpu1_vdec_fr_reg[21]), .clko(atb_formatter_vpu1_vdec_fr_reg[21]));
        cell_clk_buf   atb_formatter_vpu1_vdec_fr_reg_inst22(.clki(inter_atb_formatter_vpu1_vdec_fr_reg[22]), .clko(atb_formatter_vpu1_vdec_fr_reg[22]));
        cell_clk_buf   atb_formatter_vpu1_vdec_fr_reg_inst23(.clki(inter_atb_formatter_vpu1_vdec_fr_reg[23]), .clko(atb_formatter_vpu1_vdec_fr_reg[23]));
        cell_clk_buf   atb_formatter_vpu1_vdec_fr_reg_inst24(.clki(inter_atb_formatter_vpu1_vdec_fr_reg[24]), .clko(atb_formatter_vpu1_vdec_fr_reg[24]));
        cell_clk_buf   atb_formatter_vpu1_vdec_fr_reg_inst25(.clki(inter_atb_formatter_vpu1_vdec_fr_reg[25]), .clko(atb_formatter_vpu1_vdec_fr_reg[25]));
        cell_clk_buf   atb_formatter_vpu1_vdec_fr_reg_inst26(.clki(inter_atb_formatter_vpu1_vdec_fr_reg[26]), .clko(atb_formatter_vpu1_vdec_fr_reg[26]));
        cell_clk_buf   atb_formatter_vpu1_vdec_fr_reg_inst27(.clki(inter_atb_formatter_vpu1_vdec_fr_reg[27]), .clko(atb_formatter_vpu1_vdec_fr_reg[27]));
        cell_clk_buf   atb_formatter_vpu1_vdec_fr_reg_inst28(.clki(inter_atb_formatter_vpu1_vdec_fr_reg[28]), .clko(atb_formatter_vpu1_vdec_fr_reg[28]));
        cell_clk_buf   atb_formatter_vpu1_vdec_fr_reg_inst29(.clki(inter_atb_formatter_vpu1_vdec_fr_reg[29]), .clko(atb_formatter_vpu1_vdec_fr_reg[29]));
        cell_clk_buf   atb_formatter_vpu1_vdec_fr_reg_inst30(.clki(inter_atb_formatter_vpu1_vdec_fr_reg[30]), .clko(atb_formatter_vpu1_vdec_fr_reg[30]));
        cell_clk_buf   atb_formatter_vpu1_vdec_fr_reg_inst31(.clki(inter_atb_formatter_vpu1_vdec_fr_reg[31]), .clko(atb_formatter_vpu1_vdec_fr_reg[31]));
        cell_clk_buf   atb_formatter_vpu1_jpeg0_fr_reg_inst0(.clki(inter_atb_formatter_vpu1_jpeg0_fr_reg[0]), .clko(atb_formatter_vpu1_jpeg0_fr_reg[0]));
        cell_clk_buf   atb_formatter_vpu1_jpeg0_fr_reg_inst1(.clki(inter_atb_formatter_vpu1_jpeg0_fr_reg[1]), .clko(atb_formatter_vpu1_jpeg0_fr_reg[1]));
        cell_clk_buf   atb_formatter_vpu1_jpeg0_fr_reg_inst2(.clki(inter_atb_formatter_vpu1_jpeg0_fr_reg[2]), .clko(atb_formatter_vpu1_jpeg0_fr_reg[2]));
        cell_clk_buf   atb_formatter_vpu1_jpeg0_fr_reg_inst3(.clki(inter_atb_formatter_vpu1_jpeg0_fr_reg[3]), .clko(atb_formatter_vpu1_jpeg0_fr_reg[3]));
        cell_clk_buf   atb_formatter_vpu1_jpeg0_fr_reg_inst4(.clki(inter_atb_formatter_vpu1_jpeg0_fr_reg[4]), .clko(atb_formatter_vpu1_jpeg0_fr_reg[4]));
        cell_clk_buf   atb_formatter_vpu1_jpeg0_fr_reg_inst5(.clki(inter_atb_formatter_vpu1_jpeg0_fr_reg[5]), .clko(atb_formatter_vpu1_jpeg0_fr_reg[5]));
        cell_clk_buf   atb_formatter_vpu1_jpeg0_fr_reg_inst6(.clki(inter_atb_formatter_vpu1_jpeg0_fr_reg[6]), .clko(atb_formatter_vpu1_jpeg0_fr_reg[6]));
        cell_clk_buf   atb_formatter_vpu1_jpeg0_fr_reg_inst7(.clki(inter_atb_formatter_vpu1_jpeg0_fr_reg[7]), .clko(atb_formatter_vpu1_jpeg0_fr_reg[7]));
        cell_clk_buf   atb_formatter_vpu1_jpeg0_fr_reg_inst8(.clki(inter_atb_formatter_vpu1_jpeg0_fr_reg[8]), .clko(atb_formatter_vpu1_jpeg0_fr_reg[8]));
        cell_clk_buf   atb_formatter_vpu1_jpeg0_fr_reg_inst9(.clki(inter_atb_formatter_vpu1_jpeg0_fr_reg[9]), .clko(atb_formatter_vpu1_jpeg0_fr_reg[9]));
        cell_clk_buf   atb_formatter_vpu1_jpeg0_fr_reg_inst10(.clki(inter_atb_formatter_vpu1_jpeg0_fr_reg[10]), .clko(atb_formatter_vpu1_jpeg0_fr_reg[10]));
        cell_clk_buf   atb_formatter_vpu1_jpeg0_fr_reg_inst11(.clki(inter_atb_formatter_vpu1_jpeg0_fr_reg[11]), .clko(atb_formatter_vpu1_jpeg0_fr_reg[11]));
        cell_clk_buf   atb_formatter_vpu1_jpeg0_fr_reg_inst12(.clki(inter_atb_formatter_vpu1_jpeg0_fr_reg[12]), .clko(atb_formatter_vpu1_jpeg0_fr_reg[12]));
        cell_clk_buf   atb_formatter_vpu1_jpeg0_fr_reg_inst13(.clki(inter_atb_formatter_vpu1_jpeg0_fr_reg[13]), .clko(atb_formatter_vpu1_jpeg0_fr_reg[13]));
        cell_clk_buf   atb_formatter_vpu1_jpeg0_fr_reg_inst14(.clki(inter_atb_formatter_vpu1_jpeg0_fr_reg[14]), .clko(atb_formatter_vpu1_jpeg0_fr_reg[14]));
        cell_clk_buf   atb_formatter_vpu1_jpeg0_fr_reg_inst15(.clki(inter_atb_formatter_vpu1_jpeg0_fr_reg[15]), .clko(atb_formatter_vpu1_jpeg0_fr_reg[15]));
        cell_clk_buf   atb_formatter_vpu1_jpeg0_fr_reg_inst16(.clki(inter_atb_formatter_vpu1_jpeg0_fr_reg[16]), .clko(atb_formatter_vpu1_jpeg0_fr_reg[16]));
        cell_clk_buf   atb_formatter_vpu1_jpeg0_fr_reg_inst17(.clki(inter_atb_formatter_vpu1_jpeg0_fr_reg[17]), .clko(atb_formatter_vpu1_jpeg0_fr_reg[17]));
        cell_clk_buf   atb_formatter_vpu1_jpeg0_fr_reg_inst18(.clki(inter_atb_formatter_vpu1_jpeg0_fr_reg[18]), .clko(atb_formatter_vpu1_jpeg0_fr_reg[18]));
        cell_clk_buf   atb_formatter_vpu1_jpeg0_fr_reg_inst19(.clki(inter_atb_formatter_vpu1_jpeg0_fr_reg[19]), .clko(atb_formatter_vpu1_jpeg0_fr_reg[19]));
        cell_clk_buf   atb_formatter_vpu1_jpeg0_fr_reg_inst20(.clki(inter_atb_formatter_vpu1_jpeg0_fr_reg[20]), .clko(atb_formatter_vpu1_jpeg0_fr_reg[20]));
        cell_clk_buf   atb_formatter_vpu1_jpeg0_fr_reg_inst21(.clki(inter_atb_formatter_vpu1_jpeg0_fr_reg[21]), .clko(atb_formatter_vpu1_jpeg0_fr_reg[21]));
        cell_clk_buf   atb_formatter_vpu1_jpeg0_fr_reg_inst22(.clki(inter_atb_formatter_vpu1_jpeg0_fr_reg[22]), .clko(atb_formatter_vpu1_jpeg0_fr_reg[22]));
        cell_clk_buf   atb_formatter_vpu1_jpeg0_fr_reg_inst23(.clki(inter_atb_formatter_vpu1_jpeg0_fr_reg[23]), .clko(atb_formatter_vpu1_jpeg0_fr_reg[23]));
        cell_clk_buf   atb_formatter_vpu1_jpeg0_fr_reg_inst24(.clki(inter_atb_formatter_vpu1_jpeg0_fr_reg[24]), .clko(atb_formatter_vpu1_jpeg0_fr_reg[24]));
        cell_clk_buf   atb_formatter_vpu1_jpeg0_fr_reg_inst25(.clki(inter_atb_formatter_vpu1_jpeg0_fr_reg[25]), .clko(atb_formatter_vpu1_jpeg0_fr_reg[25]));
        cell_clk_buf   atb_formatter_vpu1_jpeg0_fr_reg_inst26(.clki(inter_atb_formatter_vpu1_jpeg0_fr_reg[26]), .clko(atb_formatter_vpu1_jpeg0_fr_reg[26]));
        cell_clk_buf   atb_formatter_vpu1_jpeg0_fr_reg_inst27(.clki(inter_atb_formatter_vpu1_jpeg0_fr_reg[27]), .clko(atb_formatter_vpu1_jpeg0_fr_reg[27]));
        cell_clk_buf   atb_formatter_vpu1_jpeg0_fr_reg_inst28(.clki(inter_atb_formatter_vpu1_jpeg0_fr_reg[28]), .clko(atb_formatter_vpu1_jpeg0_fr_reg[28]));
        cell_clk_buf   atb_formatter_vpu1_jpeg0_fr_reg_inst29(.clki(inter_atb_formatter_vpu1_jpeg0_fr_reg[29]), .clko(atb_formatter_vpu1_jpeg0_fr_reg[29]));
        cell_clk_buf   atb_formatter_vpu1_jpeg0_fr_reg_inst30(.clki(inter_atb_formatter_vpu1_jpeg0_fr_reg[30]), .clko(atb_formatter_vpu1_jpeg0_fr_reg[30]));
        cell_clk_buf   atb_formatter_vpu1_jpeg0_fr_reg_inst31(.clki(inter_atb_formatter_vpu1_jpeg0_fr_reg[31]), .clko(atb_formatter_vpu1_jpeg0_fr_reg[31]));
        cell_clk_buf   atb_formatter_vpu1_jpeg1_fr_reg_inst0(.clki(inter_atb_formatter_vpu1_jpeg1_fr_reg[0]), .clko(atb_formatter_vpu1_jpeg1_fr_reg[0]));
        cell_clk_buf   atb_formatter_vpu1_jpeg1_fr_reg_inst1(.clki(inter_atb_formatter_vpu1_jpeg1_fr_reg[1]), .clko(atb_formatter_vpu1_jpeg1_fr_reg[1]));
        cell_clk_buf   atb_formatter_vpu1_jpeg1_fr_reg_inst2(.clki(inter_atb_formatter_vpu1_jpeg1_fr_reg[2]), .clko(atb_formatter_vpu1_jpeg1_fr_reg[2]));
        cell_clk_buf   atb_formatter_vpu1_jpeg1_fr_reg_inst3(.clki(inter_atb_formatter_vpu1_jpeg1_fr_reg[3]), .clko(atb_formatter_vpu1_jpeg1_fr_reg[3]));
        cell_clk_buf   atb_formatter_vpu1_jpeg1_fr_reg_inst4(.clki(inter_atb_formatter_vpu1_jpeg1_fr_reg[4]), .clko(atb_formatter_vpu1_jpeg1_fr_reg[4]));
        cell_clk_buf   atb_formatter_vpu1_jpeg1_fr_reg_inst5(.clki(inter_atb_formatter_vpu1_jpeg1_fr_reg[5]), .clko(atb_formatter_vpu1_jpeg1_fr_reg[5]));
        cell_clk_buf   atb_formatter_vpu1_jpeg1_fr_reg_inst6(.clki(inter_atb_formatter_vpu1_jpeg1_fr_reg[6]), .clko(atb_formatter_vpu1_jpeg1_fr_reg[6]));
        cell_clk_buf   atb_formatter_vpu1_jpeg1_fr_reg_inst7(.clki(inter_atb_formatter_vpu1_jpeg1_fr_reg[7]), .clko(atb_formatter_vpu1_jpeg1_fr_reg[7]));
        cell_clk_buf   atb_formatter_vpu1_jpeg1_fr_reg_inst8(.clki(inter_atb_formatter_vpu1_jpeg1_fr_reg[8]), .clko(atb_formatter_vpu1_jpeg1_fr_reg[8]));
        cell_clk_buf   atb_formatter_vpu1_jpeg1_fr_reg_inst9(.clki(inter_atb_formatter_vpu1_jpeg1_fr_reg[9]), .clko(atb_formatter_vpu1_jpeg1_fr_reg[9]));
        cell_clk_buf   atb_formatter_vpu1_jpeg1_fr_reg_inst10(.clki(inter_atb_formatter_vpu1_jpeg1_fr_reg[10]), .clko(atb_formatter_vpu1_jpeg1_fr_reg[10]));
        cell_clk_buf   atb_formatter_vpu1_jpeg1_fr_reg_inst11(.clki(inter_atb_formatter_vpu1_jpeg1_fr_reg[11]), .clko(atb_formatter_vpu1_jpeg1_fr_reg[11]));
        cell_clk_buf   atb_formatter_vpu1_jpeg1_fr_reg_inst12(.clki(inter_atb_formatter_vpu1_jpeg1_fr_reg[12]), .clko(atb_formatter_vpu1_jpeg1_fr_reg[12]));
        cell_clk_buf   atb_formatter_vpu1_jpeg1_fr_reg_inst13(.clki(inter_atb_formatter_vpu1_jpeg1_fr_reg[13]), .clko(atb_formatter_vpu1_jpeg1_fr_reg[13]));
        cell_clk_buf   atb_formatter_vpu1_jpeg1_fr_reg_inst14(.clki(inter_atb_formatter_vpu1_jpeg1_fr_reg[14]), .clko(atb_formatter_vpu1_jpeg1_fr_reg[14]));
        cell_clk_buf   atb_formatter_vpu1_jpeg1_fr_reg_inst15(.clki(inter_atb_formatter_vpu1_jpeg1_fr_reg[15]), .clko(atb_formatter_vpu1_jpeg1_fr_reg[15]));
        cell_clk_buf   atb_formatter_vpu1_jpeg1_fr_reg_inst16(.clki(inter_atb_formatter_vpu1_jpeg1_fr_reg[16]), .clko(atb_formatter_vpu1_jpeg1_fr_reg[16]));
        cell_clk_buf   atb_formatter_vpu1_jpeg1_fr_reg_inst17(.clki(inter_atb_formatter_vpu1_jpeg1_fr_reg[17]), .clko(atb_formatter_vpu1_jpeg1_fr_reg[17]));
        cell_clk_buf   atb_formatter_vpu1_jpeg1_fr_reg_inst18(.clki(inter_atb_formatter_vpu1_jpeg1_fr_reg[18]), .clko(atb_formatter_vpu1_jpeg1_fr_reg[18]));
        cell_clk_buf   atb_formatter_vpu1_jpeg1_fr_reg_inst19(.clki(inter_atb_formatter_vpu1_jpeg1_fr_reg[19]), .clko(atb_formatter_vpu1_jpeg1_fr_reg[19]));
        cell_clk_buf   atb_formatter_vpu1_jpeg1_fr_reg_inst20(.clki(inter_atb_formatter_vpu1_jpeg1_fr_reg[20]), .clko(atb_formatter_vpu1_jpeg1_fr_reg[20]));
        cell_clk_buf   atb_formatter_vpu1_jpeg1_fr_reg_inst21(.clki(inter_atb_formatter_vpu1_jpeg1_fr_reg[21]), .clko(atb_formatter_vpu1_jpeg1_fr_reg[21]));
        cell_clk_buf   atb_formatter_vpu1_jpeg1_fr_reg_inst22(.clki(inter_atb_formatter_vpu1_jpeg1_fr_reg[22]), .clko(atb_formatter_vpu1_jpeg1_fr_reg[22]));
        cell_clk_buf   atb_formatter_vpu1_jpeg1_fr_reg_inst23(.clki(inter_atb_formatter_vpu1_jpeg1_fr_reg[23]), .clko(atb_formatter_vpu1_jpeg1_fr_reg[23]));
        cell_clk_buf   atb_formatter_vpu1_jpeg1_fr_reg_inst24(.clki(inter_atb_formatter_vpu1_jpeg1_fr_reg[24]), .clko(atb_formatter_vpu1_jpeg1_fr_reg[24]));
        cell_clk_buf   atb_formatter_vpu1_jpeg1_fr_reg_inst25(.clki(inter_atb_formatter_vpu1_jpeg1_fr_reg[25]), .clko(atb_formatter_vpu1_jpeg1_fr_reg[25]));
        cell_clk_buf   atb_formatter_vpu1_jpeg1_fr_reg_inst26(.clki(inter_atb_formatter_vpu1_jpeg1_fr_reg[26]), .clko(atb_formatter_vpu1_jpeg1_fr_reg[26]));
        cell_clk_buf   atb_formatter_vpu1_jpeg1_fr_reg_inst27(.clki(inter_atb_formatter_vpu1_jpeg1_fr_reg[27]), .clko(atb_formatter_vpu1_jpeg1_fr_reg[27]));
        cell_clk_buf   atb_formatter_vpu1_jpeg1_fr_reg_inst28(.clki(inter_atb_formatter_vpu1_jpeg1_fr_reg[28]), .clko(atb_formatter_vpu1_jpeg1_fr_reg[28]));
        cell_clk_buf   atb_formatter_vpu1_jpeg1_fr_reg_inst29(.clki(inter_atb_formatter_vpu1_jpeg1_fr_reg[29]), .clko(atb_formatter_vpu1_jpeg1_fr_reg[29]));
        cell_clk_buf   atb_formatter_vpu1_jpeg1_fr_reg_inst30(.clki(inter_atb_formatter_vpu1_jpeg1_fr_reg[30]), .clko(atb_formatter_vpu1_jpeg1_fr_reg[30]));
        cell_clk_buf   atb_formatter_vpu1_jpeg1_fr_reg_inst31(.clki(inter_atb_formatter_vpu1_jpeg1_fr_reg[31]), .clko(atb_formatter_vpu1_jpeg1_fr_reg[31]));
        cell_clk_buf   reg_coresight_clk_sel_inst0(.clki(inter_reg_coresight_clk_sel[0]), .clko(reg_coresight_clk_sel[0]));
        cell_clk_buf   reg_coresight_clk_sel_inst1(.clki(inter_reg_coresight_clk_sel[1]), .clko(reg_coresight_clk_sel[1]));
        cell_clk_buf   reg_coresight_freqdiv_inst0(.clki(inter_reg_coresight_freqdiv[0]), .clko(reg_coresight_freqdiv[0]));
        cell_clk_buf   reg_coresight_freqdiv_inst1(.clki(inter_reg_coresight_freqdiv[1]), .clko(reg_coresight_freqdiv[1]));
        cell_clk_buf   reg_coresight_freqdiv_inst2(.clki(inter_reg_coresight_freqdiv[2]), .clko(reg_coresight_freqdiv[2]));


 endmodule 
 
