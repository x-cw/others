//************************************************************************
//    Module name: pktatb.v
//    Create by  : haoyl
//    Email      : haoyl@innosilicon.com.cn
//    Create time: 2025-01-06   initial
//    Modify     : fangxn,solve overflow data output 
//************************************************************************
//    Description: 
//-FHDR*************************************************************************
module pkt2atb(
input clk,
input reset_n,
input [31:0] control_reg,
input [6:0] atid_static,

//from ip
input pkt_vld,
input pkt_head,
input pkt_tail,
input [63:0] pkt_data,

//timestamp
input [63:0] tsvalue,
//ATB Port
input clkenm,       // ATB clock enable for masterport
//input resetmn,      // ATB Bus reset on Master side
input atreadym,     // ATB Bus transfer ready master
input afvalidm,     // ATB Bus flush valid master
input syncreqm,     // Synchronization request

output          atvalidm,     // ATB Bus transfer valid master
output [6:0]    atidm,        // ATB Bus id master
output [3:0]    atbytesm,     // ATB byte select master
output [127:0]  atdatam,      // ATB Bus data master
output          afreadym      // ATB Bus flush ready master
        );

wire [7:0]     control_reg_sync;
reg  [6:0]      atidm_reg;
wire            atidm_cfg_en;
wire [6:0]      atidm_cfg;
reg  [3:0]      atbytesm_reg;
wire [63:0]     atdata_63_0_reg;
wire [59:0]     atdata_123_64_reg;
wire [3:0]      atdata_127_124_reg;

wire            data_overflow;
reg             data_overflow_reg;
reg             afreadym_reg;

wire            trace_fifo_rd;
wire [127:0]    trace_fifo_dout;
wire            trace_fifo_wr;
wire [127:0]    trace_fifo_din;
wire            trace_fifo_empty;
wire            trace_fifo_full;
wire [63:0]     overflow_number_t;

sig_sync #(.WIDTH(8)) cotrol_reg_sync(.clk(clk), .rst_n(reset_n), .A(control_reg[7:0]), .Y(control_reg_sync));

assign atidm_cfg_en = control_reg_sync[7];
assign atidm_cfg    = control_reg_sync[6:0];

always@(posedge clk or negedge reset_n)begin
    if(~reset_n)begin
        afreadym_reg <= 1'b0;
    end else if(clkenm) begin
        afreadym_reg <= (~atvalidm) || (atvalidm & atreadym);
    end else begin
        afreadym_reg <= 1'b0;
    end
end

always@(posedge clk or negedge reset_n)begin
    if(~reset_n)begin
        atidm_reg <= 7'h0;
    end else if(clkenm) begin
        atidm_reg <= atidm_cfg_en ? atidm_cfg : atid_static;
    end else begin
        atidm_reg <= 7'h0;
    end
end


assign atdata_127_124_reg = data_overflow_reg ? 4'hf : pkt_head ? 4'hb : 4'h7;
                                               
assign atdata_123_64_reg  = pkt_head          ? tsvalue[59:0] : 60'h0;
assign atdata_63_0_reg    = pkt_data;

assign trace_fifo_rd      = atreadym && atvalidm && clkenm;

assign trace_fifo_wr      = (~trace_fifo_full) && pkt_vld && clkenm;

assign trace_fifo_din     = {atdata_127_124_reg, atdata_123_64_reg, atdata_63_0_reg};

assign atvalidm = ~trace_fifo_empty;
assign atidm    = atidm_reg;
assign atbytesm = atvalidm ? 4'hf : 4'h0;
assign atdatam  = atvalidm ? trace_fifo_dout : 128'h0;
assign afreadym = afreadym_reg;

assign data_overflow = pkt_vld & trace_fifo_full;

always@(posedge clk or negedge reset_n)begin
    if(~reset_n)begin
        data_overflow_reg <= 1'b0;
    end else if(clkenm) begin
        if(data_overflow)begin
            data_overflow_reg <= 1'b1;
        end else begin
            data_overflow_reg <= 1'b0;
        end
    end else begin
        data_overflow_reg <= 1'b0;
    end
end

//gp_fifo #(
//        .WIDTH(128),
//        .LOG2WORDS(2),
//        .AEMPTY_THRESH(0),
//        .WR_SYNC(1),
//        .RD_SYNC(1),
//        .RD_REG(0),
//        .FULL_FLOP(0),
//        .VALID_ENTRIES_SYNC_RD_CLK(0))
//    trace_fifo_inst(
//        .clk        (clk),
//        .reset_n    (reset_n),
//        .init       (1'b0),
       
//       //read
//       .rd_en       (trace_fifo_rd),
//       .dout        (trace_fifo_dout),
       
//       //write
//       .wr_en       (trace_fifo_wr),
//       .din         (trace_fifo_din),
       
//       //status
//       .aempty      (),
//       .afull       (), 
//       .empty       (trace_fifo_empty),
//       .full        (trace_fifo_full),
//       .overflow    (),
//       .underflow   (),
//       .valid_entries()); 

      gp_fifo_small2 #(
                       // Parameters
                       .ENABLE_INIT_INPUT (1         ),                   
                       .FIFO_WIDTH        (128       ),
                       .FIFO_WORDS        (4         ),
                       .AFULL_THRESH      (4         ),
                       .AEMPTY_THRESH     (0         ),
                       .L2_FIFO_WORDS     (2         ))
      trace_fifo_inst(
           // Outputs
           .dout                        (trace_fifo_dout               ),
           .aempty                      (                              ),
           .afull                       (                              ),
           .empty                       (trace_fifo_empty              ),
           .full                        (trace_fifo_full               ),
           .overflow                    (                              ),
           .underflow                   (                              ),
           .valid_entries               (                              ),
           // Inputs
           .clk                         (clk                           ),               
           .reset_n                     (reset_n                       ),
           .init                        (1'b0                          ),                
           .rd_en                       (trace_fifo_rd                 ),
           .wr_en                       (trace_fifo_wr                 ),
           .din                         (trace_fifo_din                )
           );

endmodule
