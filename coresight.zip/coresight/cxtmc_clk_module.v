//-----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2009-2010 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//    Checked In :  2010-04-12 11:03:47 +0530 (Mon, 12 Apr 2010) 
//    Revision   :  7029 
//    Release    : TM961-BU-50000-r0p0-00rel0
//
//-----------------------------------------------------------------------------
//      Purpose:
//      CXTMC clock generation
//-----------------------------------------------------------------------------

module cxtmc_clk_module (
  // Inputs
  input  wire  CLK,            
  // free running clock

  input  wire  tmc_clk_req,    
  // clock requets on TMC enabled

  input  wire  DFTTESTMODE,    
  // Test mode

  input  wire  DFTCLKDISABLE,  
  // Clock disable in test mode


  // Outputs
  output wire  cxtmc_clk       
  // gated clock
);

  //----------------------------------------------------------------------------
  // Wires
  //----------------------------------------------------------------------------
  //wire  cxtmc_clk_enable_dft;
 
  //// DFT controls
  //assign cxtmc_clk_enable_dft = (tmc_clk_req & ~DFTCLKDISABLE) | 
  //                              DFTTESTMODE;

  //// CLK gate
  //cxtmc_clk_gate u_clk_gate_0 (
  //  .CLK          (CLK),
  //  .clk_enable_i (cxtmc_clk_enable_dft),
  //  .clk_o        (cxtmc_clk)
  //);

  ////replace gpu common clockgate
  wire  cxtmc_clk_enable_dft;
 
  assign cxtmc_clk_enable_dft = (tmc_clk_req & ~DFTCLKDISABLE); 

  /// clk gate
  cell_clk_gate u_clk_gate_0(
    .clk_in   (CLK),
    .en       (cxtmc_clk_enable_dft), //clk enable,  high valid
    .ten      (DFTTESTMODE),          //test enable, high valid
    .clk_out  (cxtmc_clk)   
   );


endmodule
