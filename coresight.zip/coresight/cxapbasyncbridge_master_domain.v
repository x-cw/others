//-----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2007-2015 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//  Version and Release Control Information:
//
//  File Revision       : $Revision: 40925 $
//  File Date           : $Date: 2014-12-24 12:48:33 +0000 (Wed, 24 Dec 2014) $
//
//  Release Information : CoreSight-SoC-TM100-r3p2-00rel0
//-----------------------------------------------------------------------------


//-----------------------------------------------------------------------------
// Master interface side of the APB asynchronous bridge
//-----------------------------------------------------------------------------

module cxapbasyncbridge_master_domain
(
  //----------------------------------------------------------------------------
  // Port Declarations
  //----------------------------------------------------------------------------

  //apb Bus
  output wire  [31:0]      paddrm,        //address of apb bus
  output wire  [31:0]      pwdatam,       //write data of apb bus
  output wire              pwritem,       //read/write control of apb bus
  output wire              penablem,      //enable of apb bus
  output wire              pselm,         //peripheral select of apb bus
  

  input  wire   [31:0]      prdatam,       //read data of apb bus
  input  wire               pslverrm,      //error response of apb bus
  input  wire               preadym,       //ready of apb bus

  //Inter-domain APB bus
  input  wire               apbs_req_async,           //apb Transaction Req signal
  output wire               apbs_ack_async,           //apb Transaction Ack signal
  input  wire   [64:0]      apbs_fwd_data_async,      //apb Transaction Forward Payload
  output wire   [32:0]      apbs_rev_data_async,      //apb Transaction Reverse Payload
 

  //Clock and reset signals
  input  wire               pclkenm,       //apb clock enable (master)
  input  wire               pclkm,         //apb clock (master)
  input  wire               presetmn       //apb reset (master)

);

//-----------------------------------------------------------------------------
// localparams
//-----------------------------------------------------------------------------

  localparam    APBAS_ST_IDLE    =    2'b00;
  localparam    APBAS_ST_SETUP   =    2'b01;
  localparam    APBAS_ST_ACCESS  =    2'b10;
  localparam    APBAS_ST_ACK     =    2'b11;
  



  //----------------------------------------------------------------------------
  // Wire Declaration
  //----------------------------------------------------------------------------
  reg               [1:0]  current_state_q;
  reg               [1:0]  next_state;
  wire              clk_en;
  reg               psel_q;

  wire              nxt_psel_q;

  wire              apbs_req_corrupt_async;
  wire              apbs_req_sync;

  wire              capt_en;

  wire      [64:0]  apbs_fwd_data_corrupt_async;
  wire      [64:0]  apbs_fwd_data_sync;

  wire              apbs_ack_sync;

  wire              clk_rev_en;
  wire      [32:0]  apbs_rev_data_sync;
  



  //----------------------------------------------------------------------------
  //                Slave interface req -> Master interface
  //----------------------------------------------------------------------------

  assign clk_en = pclkenm &
                  (apbs_req_sync | (current_state_q != APBAS_ST_IDLE));

  always @ (posedge pclkm or negedge presetmn)
    if (~presetmn)
      current_state_q <= APBAS_ST_IDLE;
    else if (clk_en)
      current_state_q <= next_state;

  //----------------------------------------------------------------------------
  //  Master FSM
  //----------------------------------------------------------------------------
  // APBAS_ST_IDLE  : Idle state of FSM. This is reset state. Moves to Setup phase
  //                  when a request is received from the slave domain
  // APBAS_ST_SETUP : Setup phase.pselm is driven high in this state
  // APBAS_ST_ACCESS: Access phase. Moves to ST_ACK state when the ready is received
  //                  from the target.pselm and penablem are driven high in this state.
  // APBAS_ST_ACK   : In this state, the fsm waits for the handshake from slave interface
  //                  before moving to IDLE state
  //----------------------------------------------------------------------------
  always @*
  begin
    case (current_state_q)
      APBAS_ST_IDLE:
        next_state = apbs_req_sync ? APBAS_ST_SETUP : APBAS_ST_IDLE;
      APBAS_ST_SETUP:
        next_state = APBAS_ST_ACCESS;
      APBAS_ST_ACCESS:
        next_state = preadym ? APBAS_ST_ACK : APBAS_ST_ACCESS;
      
      APBAS_ST_ACK:
        next_state = ~apbs_req_sync ? APBAS_ST_IDLE : APBAS_ST_ACK;
      default: next_state = current_state_q;
    endcase
  end


  assign penablem = (current_state_q == APBAS_ST_ACCESS );

  assign nxt_psel_q = (next_state != APBAS_ST_IDLE) & (next_state != APBAS_ST_ACK);

  always @ (posedge pclkm or negedge presetmn)
    if (~presetmn)
      psel_q <= 1'b0;
    else if (clk_en)
      psel_q <= nxt_psel_q;

  assign pselm = psel_q;



  //----------------------------------------------------------------------------
  // Incoming Req
  //----------------------------------------------------------------------------

  // Test component to corrupt req going into synchroniser
  cxapbasyncbridge_cdc_corrupt_gry #(.WIDTH(1)) u_cdc_corrupt_req
  (
      .clk       (pclkm),
      .resetn    (presetmn),
      .sync      (1'b0),
      .d_async   (apbs_req_async),
      .q_async   (apbs_req_corrupt_async)
  );

  // Synchroniser to bring the req into the clock domain
  cx_en_sync u_cdc_sync_req
  (
      .clk       (pclkm),
      .clken     (1'b1),
      .resetn    (presetmn),
      .sync_di   (apbs_req_corrupt_async),
      .sync_do   (apbs_req_sync)
  );

  //----------------------------------------------------------------------------
  // Incoming Data
  //----------------------------------------------------------------------------

  // Test component to corrupt data
  cxapbasyncbridge_cdc_corrupt #(.WIDTH(65)) u_cdc_corrupt_fwd_data
  (
      .clk       (pclkm),
      .sync      (1'b0),
      .d         (apbs_fwd_data_async),
      .q         (apbs_fwd_data_corrupt_async)
  );

  // Test component to check for corrupted data
  cxapbasyncbridge_cdc_capt #(.WIDTH(65)) u_cdc_comb_capt
  (
      .clk       (pclkm),
      .resetn    (presetmn),
      .q         (apbs_fwd_data_sync),
      .d_async   (apbs_fwd_data_corrupt_async),
      .enable     (capt_en)
  );

  // Capture data on enabled edge when transitioning to APBAS_ST_SETUP state
  assign capt_en = pclkenm & (next_state == APBAS_ST_SETUP);

  // Expand Forward Payload
  assign {paddrm, pwdatam, pwritem} = apbs_fwd_data_sync;

  //----------------------------------------------------------------------------
  // Outgoing Ack
  //----------------------------------------------------------------------------

  cxapbasyncbridge_cdc_launch_gry #(.WIDTH(1)) u_cdc_launch_ack
  (
      .clk       (pclkm),
      .resetn    (presetmn),
      .enable    (pclkenm),
      .in_cdc    (apbs_ack_sync),
      .out_async (apbs_ack_async)
  );

  assign apbs_ack_sync = (next_state == APBAS_ST_ACK);

  //----------------------------------------------------------------------------
  // Outgoing Data
  //----------------------------------------------------------------------------

  // Test component and registering
  cxapbasyncbridge_cdc_launch_data #(.WIDTH(33)) u_cdc_launch_rev_data
  (
     .clk       (pclkm),
     .resetn    (presetmn),
     .enable    (clk_rev_en),
     .in_cdc    (apbs_rev_data_sync),
     .out_async (apbs_rev_data_async));

  // Generate Clock Enable
  assign clk_rev_en = pclkenm & (current_state_q == APBAS_ST_ACCESS) & preadym;

  // Concatenate Reverse Payload
  assign apbs_rev_data_sync = {prdatam, pslverrm};

`ifdef ARM_ASSERT_ON
  //----------------------------------------------------------------------------
  // OVL Assertions
  //----------------------------------------------------------------------------
  //----------------------------------------------------------------------------
  // Valid states of the FSM
  //----------------------------------------------------------------------------
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
    "OVL Message : apb_master_domain FSM is in illegal state")
      uzovl_apb_master_domain_fsm_state
        (
         .clk         (pclkm),
         .reset_n     (presetmn),
         .test_expr   (current_state_q != APBAS_ST_IDLE & current_state_q != APBAS_ST_SETUP & current_state_q != APBAS_ST_ACCESS & current_state_q != APBAS_ST_ACK )
        );

  //----------------------------------------------------------------------------
  // No transaction active when the FSM is in APBAS_ST_ACK state
  //----------------------------------------------------------------------------
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
    "OVL Message : Active transaction in APBAS_ST_ACK state")
      uzovl_apb_master_domain_bus_idle
        (
         .clk         (pclkm),
         .reset_n     (presetmn),
         .test_expr   (current_state_q == APBAS_ST_ACK & (pselm |penablem))
        );


`endif

endmodule
