//-----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2010-2013 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//
//      Checked In          : $Date: 2013-09-18 14:05:57 +0100 (Wed, 18 Sep 2013) $
//
//      Revision            : $Revision: 37420 $
//
//      Release Information : CoreSight-SoC-TM100-r3p1-00rel0
//-----------------------------------------------------------------------------
//  Purpose             : Double Synchronizer for signals from ATCLKS to atclkm
//-----------------------------------------------------------------------------

module cxatbasyncbridge_mst_sync_mst (
  // Inputs
  atclkm,
  atclkenm,
  atresetmn,
  wrptr_grey,
  flush_done,
  //slv_safe_state,
  // Outputs
  wrptr_grey_sync,
  flush_done_sync
  //slv_safestate_sync
  );


  // Inputs
  input wire         atclkm;            // ATB Master clock
  input wire         atclkenm;          // ATB Master clock enable
  input wire         atresetmn;         // ATB Master asychronous reset active low
  input wire [3:0]   wrptr_grey;        // Write pointer from the ATB Slave clock domain
  input wire         flush_done;        // Flush Done signal from the ATB Slave clock domain
  //input wire         slv_safe_state;    // Safe state signal from the ATB Slave clock domain

  // Outputs
  output wire [3:0]  wrptr_grey_sync;   // Write pointer to the read clock domain
  output wire        flush_done_sync;   // Synchronized Flush Done signal in the ATB Master clock domain
  //output wire        slv_safestate_sync;// Synchronized Safe state signal in the ATB Slave clock domain

  // ---------------------------------------------------------------------------
  //                            Synchronizers For ATB Master Clock Domain
  //                            =========================================
  // ---------------------------------------------------------------------------
  // Overview
  // ========
  // Synchronizers for the signals of the CSBRIDGEASYNC block in the ATB Master
  // clock domain.
  // Converts: wrptr_grey (AtbsFIFO) from ATB Slave CLK Domain
  //           flush_done (AtbsFIFO) from ATB Slave CLK Domain
  // ---------------------------------------------------------------------------

  // ---------------------------------------------------------------------------
  // Instantiating the cxatbasyncbridge_sync module for synchronizing wrptr_grey[0] bit.
  // ---------------------------------------------------------------------------
  cx_en_sync u_wrptr_grey0
    (
    // Outputs
    .sync_do          (wrptr_grey_sync[0]),
    // Inputs
    .clk              (atclkm),
    .clken            (atclkenm),
    .resetn           (atresetmn),
    .sync_di          (wrptr_grey[0]));

  // ---------------------------------------------------------------------------
  // Instantiating the cxatbasyncbridge_sync module for synchronizing wrptr_grey[1] bit.
  // ---------------------------------------------------------------------------
  cx_en_sync u_wrptr_grey1
    (
    // Outputs
    .sync_do          (wrptr_grey_sync[1]),
    // Inputs
    .clk              (atclkm),
    .clken            (atclkenm),
    .resetn           (atresetmn),
    .sync_di          (wrptr_grey[1]));

  // ---------------------------------------------------------------------------
  // Instantiating the cxatbasyncbridge_sync module for synchronizing wrptr_grey[2] bit.
  // ---------------------------------------------------------------------------
  cx_en_sync u_wrptr_grey2
    (
    // Outputs
    .sync_do          (wrptr_grey_sync[2]),
    // Inputs
    .clk              (atclkm),
    .clken            (atclkenm),
    .resetn           (atresetmn),
    .sync_di          (wrptr_grey[2]));

  // ---------------------------------------------------------------------------
  // Instantiating the cxatbasyncbridge_sync module for synchronizing wrptr_grey[3] bit.
  // ---------------------------------------------------------------------------
  cx_en_sync u_wrptr_grey3
    (
    // Outputs
    .sync_do          (wrptr_grey_sync[3]),
    // Inputs
    .clk              (atclkm),
    .clken            (atclkenm),
    .resetn           (atresetmn),
    .sync_di          (wrptr_grey[3]));

  // ---------------------------------------------------------------------------
  // Instantiating the cxatbasyncbridge_sync module for synchronizing flush_done.
  // ---------------------------------------------------------------------------
  cx_en_sync u_flush_done
    (
    // Outputs
    .sync_do          (flush_done_sync),
    // Inputs
    .clk              (atclkm),
    .clken            (atclkenm),
    .resetn           (atresetmn),
    .sync_di          (flush_done));

  //// ---------------------------------------------------------------------------
  //// Instantiating the cxatbasyncbridge_sync module for synchronizing slv_safe_state.
  //// ---------------------------------------------------------------------------
  //cx_en_sync_high u_slv_safe_state
  //  (
  //  // Outputs
  //  .sync_do          (slv_safestate_sync),
  //  // Inputs
  //  .clk              (atclkm),
  //  .clken            (atclkenm),
  //  .resetn           (atresetmn),
  //  .sync_di          (slv_safe_state));

endmodule // cxatbasyncbridge_mst_sync
