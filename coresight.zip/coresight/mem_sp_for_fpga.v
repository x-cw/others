//-----------------------------------------------------------------------------
// Purpose : behavioural single-port RAM model (for simulation only)
//-----------------------------------------------------------------------------

module mem_sp_for_fpga (
  // clocks and resets:
  clk,
  // write/read interface:
  ce0,
  we0,
  a0,
  di0,
  do0
  );

  //===========================================================================
  // parameters
  //===========================================================================
  parameter DEPTH                           = 6;
  parameter WIDTH                           = 256;
  parameter HEIGHT                          = 64;

  //===========================================================================
  // port declarations
  //===========================================================================

  //---------------------------------------------------------------------------
  // clocks and resets
  //---------------------------------------------------------------------------
  input wire                                clk;                          // clock

  //---------------------------------------------------------------------------
  // write/read interface
  //---------------------------------------------------------------------------
  input wire                                ce0;                          // chip enable
  input wire                                we0;                          // write enable
  input wire                    [DEPTH-1:0] a0;                           // address
  input wire                    [WIDTH-1:0] di0;                          // write data
  output reg                    [WIDTH-1:0] do0;                          // read data

  //===========================================================================
  // internal signal declarations
  //===========================================================================
  reg                           [WIDTH-1:0] mem_r [HEIGHT-1:0];           // memory array

  always @(posedge clk) begin
     if ({ce0,we0} == 2'b11) begin
        mem_r[a0] <= di0;
     end       
  end
   
   
  always @(posedge clk) begin
     if ({ce0,we0} == 2'b10) begin
       do0 <= mem_r[a0];
     end
     else begin
       do0 <= {WIDTH{1'b0}};
     end
  end

endmodule
