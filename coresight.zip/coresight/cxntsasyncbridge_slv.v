
//-----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2011-2015 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//  Version and Release Control Information:
//
//  File Name           : cxntsasyncbridge_xmlcfg.v.xsl
//
//  Checked In          : $Date: 2015-02-16 14:55:41 +0000 (Mon, 16 Feb 2015) $
//
//  File Revision       : $Revision: 41661 $
//
//  Release Information : CoreSight-SoC-TM100-r3p2-00rel0
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// Abstract : CoreSight NTAB - Top Level Block
//-----------------------------------------------------------------------------
//
// cxntsasyncbridge - CoreSight NTAB (Narrow Timestamp Asynchronous Bridge)
//-----------------------------------------------------------------------------

module cxntsasyncbridge_slv (


  // Clock and Reset

  input wire clks,
  input wire resetsn,

  // Slave Interface
  input wire [6:0] tsbits,
  input wire [1:0] tssyncs,
  output wire tssyncreadys,

  // AXI-C Low Power Interface
  input wire csysreq,
  output wire csysack,
  output wire cactive,

  // Async Bridge Data Hand Shake
  input wire [3:0] rd_ptr_gry_s,
  output wire [3:0] wr_ptr_gry_s,
  output wire [8:0] encd_data0_s,
  output wire [8:0] encd_data1_s,
  output wire [8:0] encd_data2_s,


  // Async Bridge Low Power Hand Shake
  output wire lp_req_s,
  input wire lp_ack_s

  );

//----------------------------------------------------------------------------
// Wires
//----------------------------------------------------------------------------
  wire [8:0] encd_data0_cdc_check;
  wire [8:0] encd_data1_cdc_check;
  wire [8:0] encd_data2_cdc_check;


//============================================================================
//
// Main body of code
//
//============================================================================

cxntsasyncbridgeslvif_slv
  u_slvif (

  // Clock and Reset
  .clks (clks),
  .resetsn (resetsn),

  // Slave Interface
  .tsbits (tsbits),
  .tssyncs (tssyncs),
  .tssyncreadys (tssyncreadys),

  // AXI-C Low Power Interface
  .csysreq (csysreq),
  .csysack (csysack),
  .cactive (cactive),

  // Master Interface
  .rd_ptr_gry_s (rd_ptr_gry_s),
  .wr_ptr_gry_s (wr_ptr_gry_s),

  .encd_data0_s  (encd_data0_cdc_check),
  .encd_data1_s  (encd_data1_cdc_check),
  .encd_data2_s  (encd_data2_cdc_check),


  .lp_req_s (lp_req_s),
  .lp_ack_s (lp_ack_s)

  );

//----------------------------------------------------------------------------
// CDC Checks
//----------------------------------------------------------------------------

`ifdef ARM_CDC_CHECK

  
        cdc_connect #(8,0) uxcdc_encd_data0 (
                .clk_launch(clks),
                .clk_capture(clkm),
                .d_in(encd_data0_cdc_check),
                .d_out_async(encd_data0_s)
                );

        cdc_connect #(8,0) uxcdc_encd_data1 (
                .clk_launch(clks),
                .clk_capture(clkm),
                .d_in(encd_data1_cdc_check),
                .d_out_async(encd_data1_s)
                );

        cdc_connect #(8,0) uxcdc_encd_data2 (
                .clk_launch(clks),
                .clk_capture(clkm),
                .d_in(encd_data2_cdc_check),
                .d_out_async(encd_data2_s)
                );


`else

  assign encd_data0_s = encd_data0_cdc_check;
  assign encd_data1_s = encd_data1_cdc_check;
  assign encd_data2_s = encd_data2_cdc_check;


`endif
//----------------------------------------------------------------------------
// ASSERTIONS
//----------------------------------------------------------------------------

`ifdef ARM_ASSERT_ON

//-----------------------------------------------------------------------------
// Local constant definition
//-----------------------------------------------------------------------------
localparam ASYNC_FIFO_DEPTH = 3;

//-----------------------------------------------------------------------------
// Check for legal values of ASYNC_FIFO_DEPTH parameter
// Valid values: 3,4,6,8
//-----------------------------------------------------------------------------
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxntsasyncbridge - Illegal value for parameter ASYNC_FIFO_DEPTH")
      uzovl_cxntsasyncbridge_async_fifo_depth_param_chk
        (
         .clk         (clks),
         .reset_n     (resetsn),
         .test_expr   ((ASYNC_FIFO_DEPTH != 3) &&
                       (ASYNC_FIFO_DEPTH != 4) &&
                       (ASYNC_FIFO_DEPTH != 6) &&
                       (ASYNC_FIFO_DEPTH != 8))
        );

`endif // ARM_ASSERT_ON

endmodule
