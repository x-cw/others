//-----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2012-2015 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//  Checked In          : $Date: 2014-06-25 08:59:36 +0100 (Wed, 25 Jun 2014) $
//  Revision            : $Revision: 39630 $
//  Release             : CoreSight-SoC-TM100-r3p2-00rel0
//
//  ----------------------------------------------------------------------------
//  Purpose             : DAPBUS Interconnect Response Mux
//
//  --========================================================================--

module cxdapbusic_mux_3ap
  (
  // Inputs

  // DAPBUS Master intf select signals
  input  wire dapselm2,
  input  wire dapselm1,
  input  wire dapselm0,
  input  wire dapseldef,

  // Read Data
  input  wire [31:0] daprdatam2,
  input  wire [31:0] daprdatam1,
  input  wire [31:0] daprdatam0,

  // AP Response
  input  wire dapreadym2,
  input  wire dapreadym1,
  input  wire dapreadym0,

  // Error indication
  input  wire dapslverrm2,
  input  wire dapslverrm1,
  input  wire dapslverrm0,

  // Outputs
  output  wire [31:0] daprdatas,
  output  wire        dapreadys,
  output  wire        dapslverrs
  );

//-----------------------------------------------------------------------------
//
// Main body of code
// =================
//
//-----------------------------------------------------------------------------

// Data mux
assign daprdatas = 
  
         ({32{dapselm2}} & daprdatam2) | 
  
         ({32{dapselm1}} & daprdatam1) | 
  
         ({32{dapselm0}} & daprdatam0);

// DAPREADY mux
// Default slave must return ready immediately
assign dapreadys = dapseldef | 
  
         (dapselm2 & dapreadym2) | 
  
         (dapselm1 & dapreadym1) | 
  
         (dapselm0 & dapreadym0);

// DAPSLVERR mux
// Default slave does not return an error
assign dapslverrs = 
  
         (dapselm2 & dapslverrm2) | 
  
         (dapselm1 & dapslverrm1) | 
  
         (dapselm0 & dapslverrm0);

endmodule // cxdapbusic_mux_3ap
