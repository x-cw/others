//----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2009-2010 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//    Checked In :  2010-06-21 18:09:11 +0530 (Mon, 21 Jun 2010) 
//    Revision   :  8321 
//    Release    : TM961-BU-50000-r0p0-00rel0
//
//----------------------------------------------------------------------------
// Purpose : This AXI Interface writes the data from Write
//           Buffer into Memory and reads the data out to the
//           APB Read FIFO
//----------------------------------------------------------------------------

module cxtmc_axi_if
  #(
    // Width of the AXI databus
    parameter CXTMC_AXI_DATA_WIDTH      = 32,

    // Max width of the Memory address in words - this corresponds to a
    // memory of size of 4GB programmed in the RSZ register and of width 
    // CXTMC_AXI_DATA_WIDTH
    // For CXTMC_AXI_DATA_WIDTH=32/64/128, this parameter takes values of
    // 38/37/36.
    parameter CXTMC_MEM_ADDR_WIDTH      = 38,

    // Max width of the memory address in bytes
    parameter CXTMC_MEM_BYTE_ADDR_WIDTH = 40,

    // Depth of Write buffer (=4/8/16/32 in ETR config)
    parameter CXTMC_WBUFFER_DEPTH      = 4,

    // Defines the Writer Buffer data width
    parameter CXTMC_WB_DATA_WIDTH       = 32,

    // Width of the Write buffer pointers
    parameter CXTMC_WB_PTR_WIDTH        = 2,

    // Width of fill-level signals
    parameter CXTMC_FILL_LEVEL_WIDTH    = 31)
  (
  // Clock
  input wire                                      cxtmc_clk,

  // Reset
  input wire                                      RESETn,

  // AR Channel
  input  wire                                    ARREADYM,
  output reg  [39:0]                             ARADDRM,
  output wire [3:0]                              ARLENM,
  output wire [2:0]                              ARSIZEM,
  output wire [1:0]                              ARBURSTM,
  output wire [1:0]                              ARLOCKM,
  output reg  [3:0]                              ARCACHEM,
  output reg  [2:0]                              ARPROTM,
  output reg                                     ARVALIDM,

  // R Channel
  input  wire [CXTMC_AXI_DATA_WIDTH-1:0]         RDATAM,
  input  wire [1:0]                              RRESPM,
  input  wire                                    RLASTM,
  input  wire                                    RVALIDM,
  output wire                                    RREADYM,

  // AW Channel
  input  wire                                    AWREADYM,
  output reg  [39:0]                             AWADDRM,
  output reg  [3:0]                              AWLENM,
  output wire [2:0]                              AWSIZEM,
  output wire [1:0]                              AWBURSTM,
  output wire [1:0]                              AWLOCKM,
  output reg  [3:0]                              AWCACHEM,
  output reg  [2:0]                              AWPROTM,
  output reg                                     AWVALIDM,

  // W Channel
  input  wire                                    WREADYM,
  output reg  [CXTMC_AXI_DATA_WIDTH-1:0]         WDATAM,
  output wire [(CXTMC_AXI_DATA_WIDTH/8)-1:0]     WSTRBM,
  output reg                                     WLASTM,
  output reg                                     WVALIDM,

  // B Channel
  input  wire [1:0]                              BRESPM,
  input  wire                                    BVALIDM,
  output wire                                    BREADYM,

  // Authentication Interface inputs registered
  input wire                                     dbgen_reg,
  input wire                                     spiden_reg,

  // Write data from write buffer
  input wire  [CXTMC_WB_DATA_WIDTH-1:0]          wb_data,

  // Write Buffer request 
  input wire                                     wb_req_valid,

  // Write buffer flush request from Flush control block
  // Used by the AXI interface to detect that a flush is in progress
  // in the write buffer so that smaller AXI bursts are initiated
  // than the value programmed in AXICTL
  input wire                                     wb_flush_req,

  // Write buffer flush acknowledge
  // Used by the AXI interface to calculate the number of write
  // transfers that must be completed on the B Channel before
  // the AXI interface can acknowledge a flush request
  input wire                                     wb_flush_ack,

  // Formatter has stopped - used by the AXI interface to initiate
  // smaller AXI bursts than the value programmed in AXICTL
  input wire                                     ft_stopped,

  // Write buffer fill level
  input wire  [CXTMC_WB_PTR_WIDTH:0]             wb_fill_level,

  // Read buffer request 
  input wire                                     rb_req_valid,

  // Read pointer write request from APB
  input wire                                     rrp_wr_en,

  // Read pointer write request from APB for higher order bits
  input wire                                     rrp_hi_wr_en,

  // Write pointer write request from APB
  input wire                                     rwp_wr_en,

  // Write pointer write request from APB for higher order bits
  input wire                                     rwp_hi_wr_en,

  // Data from APB
  input wire  [31:0]                             apb_wdata,

  // Formatter is in Circular Buffer Mode
  input wire                                     circ_buf_mode,

  // APB Read FIFO indicating that data read is all sent to APB and Read Pointer
  // Increment can happen
  input wire                                     apb_read_fifo_rrp_en,

  // All Read/Write pointers to be cleared. 
  input wire                                     ptr_clr,

  // Pulse to clear fill level registers
  input wire                                     ctl_trace_capt_en_1_0,
  
  // If trace capture is enabled, pointers are maintained by the TMC
  input wire                                     ctl_trace_capt_en,
  
  // If TraceCaptEn=0 and TMCReady=1, direct control of pointers and the memory
  // by the APB is allowed, regardless of empty status
  input wire                                     tmc_disabled,
  
  // TraceCaptEn is cleared when TMCReady=0 and the TMC is in a FIFO mode 
  // or with Drain in progress
  input wire                                     tmc_abort,
  
  // Indicates that buf level has been read and hence can be cleared
  input wire                                     lat_buf_level_rd_done,
  
  // Buffer water mark register
  input wire  [CXTMC_FILL_LEVEL_WIDTH-2:0]       buf_wm,
  
  // Write enable for ITMISCOP0 register
  input wire                                     it_misc_op_0_wr_en,
  
  // Integration Mode Control
  input wire                                     it_ctrl,

  // Memory flush request from Flush control block
  input wire                                     mem_flush_req,

  // RSZ register - contains trace memory size in ETR config
  input wire  [30:0]                             rsz_masked,
  
  // AXICTL register bits related to write burst length
  input wire  [3:0]                              axictl_wr_burst_len,

  // AXICTL register bit related to mode of operation
  input wire                                     axictl_sg_mode,

  // AXICTL register bits related to cache control
  input wire  [3:0]                              axictl_cache_ctrl,

  // AXICTL register bits related to protection control
  input wire  [1:0]                              axictl_prot_ctrl,

  // AXI Data Buffer Low Address
  input wire  [31:0]                             dba_lo,

  // AXI Data Buffer High Address
  input wire  [7:0]                              dba_hi,

  // Pulse to clear mem_err signal 
  input wire                                     mem_err_clr,

  // Error detected in page table entry by Scatter Gather block
  input wire                                     mem_err_pt,
  
  // Request to fetch a page table entry from the address driven on
  // pt_addr
  input wire                                     pt_valid,

  // Address from which page table entry is to be fetched
  input wire  [39:0]                             pt_addr,

  // Qualifier for dba_w_addr and dba_w_last
  input wire                                     dba_w_valid,

  // Base address for the next 4KB data buffer on the AXI for writes - upper 
  // 28 bits
  input wire  [27:0]                             dba_w_addr,

  // Base address on dba_w_addr is the last data buffer - used in the
  // generation of FULL output
  input wire                                     dba_w_last,

  // Qualifier for dba_r_addr 
  input wire                                     dba_r_valid,

  // Base address for the next 4KB data buffer on the AXI for reads - upper 
  // 28 bits
  input wire  [27:0]                             dba_r_addr,

  // Clocked version of CSYSREQ - registered to minimise load on input port
  input wire                                     csysreq_reg,

  // CSYSACK output from the TMC - new transfers are initiated by the AXI
  // interface only if CSYSACK is high and csysreq_reg is high
  input wire                                     CSYSACK,

  // Read data from Memory 
  output reg  [CXTMC_WB_DATA_WIDTH-1:0]          rb_data,

  // Indicating to APB Read fifo that memory read data is valid
  output reg                                     rb_rdata_valid,
  
  // Request/data from write buffer is accepted
  output wire                                    wb_req_ready,
  
  // Request from apb read fifo is accepted
  output wire                                    rb_req_ready,
  
  // Memory read pointer in bytes
  output wire [CXTMC_MEM_BYTE_ADDR_WIDTH-1:0]    rrp,
  
  // Memory write pointer in bytes
  output wire [CXTMC_MEM_BYTE_ADDR_WIDTH-1:0]    rwp,
  
  // Maximum fifo fill level in 32-bit words
  output wire [CXTMC_FILL_LEVEL_WIDTH-1:0]       lat_buf_level,
  
  // Current fill level of the trace memory in 32-bit words
  output wire [CXTMC_FILL_LEVEL_WIDTH-1:0]       c_buf_level,
  
  // Memory is empty
  output wire                                    trace_mem_empty,
  
  // Memory is FULL or the TMC has wrapped around the top address of the trace 
  // memory area at one point in circular buffer mode
  output reg                                     FULL,
  
  // Memory flush completion ack to Flush control block
  output reg                                     mem_flush_ack,

  // AXI error occurred
  output reg                                     mem_err,

  // AXI interface idle
  output wire                                    axi_intf_ready,

  // Valid page table data available on pt_data 
  output wire                                    pt_ready,

  // Page table data read from address pt_addr - higher order bits
  output reg  [27:0]                             pt_data_hi,

  // Page table data read from address pt_addr - lower order bits
  output reg  [1:0]                              pt_data_lo,

  // Base address on dba_w_addr has been sampled by the AXI interface
  // Scatter-Gather block can modify dba_w_addr 
  output reg                                     dba_w_ready,

  // Base address on dba_r_addr has been sampled by the AXI interface
  // Scatter-Gather block can modify dba_r_addr 
  output reg                                     dba_r_ready,

  // Decrement signal for the PSCR counter with every beat of data transferred
  output wire                                    axi_w_ch_beat_done,

  // On-going transfers on the AXI - used by the APB slave interface 
  // to assert CSYSACK 
  output wire                                    axi_intf_pend,

  // Check for outstanding_wreq_cnt being 0
  output wire                                    outstanding_wreq_cnt_eq0

  );

//-----------------------------------------------------------------------------
// Local Constants definitions
//-----------------------------------------------------------------------------
// Write burst counter width
// The max value of this counter is governed by the depth of the write buffer
// and the maximum allowable beats in an AXI burst (16 beats).
localparam WCNT_WIDTH = (CXTMC_WBUFFER_DEPTH == 4) ? 2 :
                        (CXTMC_WBUFFER_DEPTH == 8) ? 3 :
                                                      4; // 16/32

// AXI bus encodings
// AWSIZE[2:0]/ARSIZE[2:0]
localparam AXI_SIZE_32 = 3'b010;
localparam AXI_SIZE_64 = 3'b011;
localparam AXI_SIZE_128 = 3'b100;

// ARLEN[3:0]
localparam AXI_BURST_LEN_1 = 4'b0000;

// AWLOCK[1:0]/ARLOCK[1:0]
localparam AXI_LOCK_NORMAL = 2'b00;

// AWBURST[1:0]/ARBURST[1:0]
localparam AXI_BURST_TYPE_FIXED = 2'b00;
localparam AXI_BURST_TYPE_INCR = 2'b01;

// This parameter determines the number of 0's to be padded to the Memory 
// Address Vector to arrive at Byte Address which needs to be driven on the 
// Read/Write Pointers going to APB
localparam CXTMC_PTR_PAD = (CXTMC_MEM_BYTE_ADDR_WIDTH-CXTMC_MEM_ADDR_WIDTH);

// This parameter determines the number of bits that need to masked to 0, to 
// achieve frame alignment for APB data written to the pointers. Since a frame
// is 16 bytes of data, the lower 4 bits are to be masked to 0 to achieve
// frame alignment.
localparam CXTMC_PTR_LSB  = 4;

// This parameter indicates the number of 32-bit words in one memory dataword
// This is the same as CXTMC_WB_DATA_WIDTH/32
// It is used in incrementing/decrementing c_buf_level with every memory
// write/read.
// In the ETR configuration, CXTMC_WB_DATA_WIDTH can take values of
// 32/64/128.
localparam CXTMC_BUF_LEVEL_STEP =
               (CXTMC_WB_DATA_WIDTH == 32) ?
                 {{CXTMC_FILL_LEVEL_WIDTH-1{1'b0}}, 1'b1}  : // 1
               (CXTMC_WB_DATA_WIDTH == 64) ?
                 {{CXTMC_FILL_LEVEL_WIDTH-2{1'b0}}, 2'b10} : // 2
                 {{CXTMC_FILL_LEVEL_WIDTH-3{1'b0}}, 3'b100}; // 4

// This parameter indicates the number of bits to compare in the c_buf_level
// value with the threshold space setting. This helps use an equality check
// logic instead of a ">=" operator which carries an area penalty. 
localparam CXTMC_BUF_LEVEL_CMP_MASK =
               (CXTMC_BUF_LEVEL_STEP == 1) ? // Ignore none of the bits
                 {{CXTMC_FILL_LEVEL_WIDTH{1'b1}}}  :
               (CXTMC_BUF_LEVEL_STEP == 2) ? // Ignore LSBit during comparison
                 {{CXTMC_FILL_LEVEL_WIDTH-1{1'b1}}, 1'b0} :// Ignore 2 LSBits
                 {{CXTMC_FILL_LEVEL_WIDTH-2{1'b1}}, 2'b00};


// AWSIZEM/ARSIZEM value depends on the parameter CXTMC_AXI_DATA_WIDTH
localparam CXTMC_AXI_SIZE_VAL = (CXTMC_AXI_DATA_WIDTH == 32) ? AXI_SIZE_32 :
                                (CXTMC_AXI_DATA_WIDTH == 64) ? AXI_SIZE_64 :
                                                               AXI_SIZE_128;

  // This parameter indicates the width for c_buf_level register
  // for 64 bit Write buffer, it will be one less than fill_level_width
  // 2 less for 128 and 3 for 256. 
  localparam CXTMC_BUF_LEVEL_WIDTH = 
               (CXTMC_WB_DATA_WIDTH == 32) ?
                 CXTMC_FILL_LEVEL_WIDTH  : // 32 bit WB
               (CXTMC_WB_DATA_WIDTH == 64) ?
                 CXTMC_FILL_LEVEL_WIDTH-1 : // 64 bit WB
                 CXTMC_FILL_LEVEL_WIDTH-2; // 128 bit WB

  // This parameter indicates the number of 0's to be appended to 
  // c_buf_level_reg to assign it to c_buf_level
  // No appending for 32 bit
  localparam CXTMC_BUF_LEVEL_PAD = (CXTMC_WB_DATA_WIDTH == 64) ? 1 : 2; 


//-----------------------------------------------------------------------------
// Wire declarations
//-----------------------------------------------------------------------------
// Write enable for rwp_word_addr_p1
wire rwp_word_addr_p1_we;

// In SG operation, when rwp_word_addr is pointing to the last data word in a 
// 4KB block, a reload of SG address is needed. Hence rwp_word_addr_p1 which
// maintains a value one greater than rwp_word_addr is not valid.
wire  rwp_p1_invalid;

// Pipelined AW channel address. When a write access is in progress on the
// W Channel, rwp_word_addr_p holds the address to which the next access is
// to be initiated.
wire [CXTMC_MEM_ADDR_WIDTH-1:0] rwp_word_addr_p;

// rwp_word_addr_p appended with 0s
wire [CXTMC_MEM_BYTE_ADDR_WIDTH-1:0] rwp_p;

// Check whether the read pointer and the write pointer are on different
// 4K pages. Used to determine whether a new AXI write burst can be initiated.
wire        rrp_rwp_diff_4kb_page;

// Set the wr_skid_buf_full signal when data cannot be posted on the
// W Channel
wire        wr_skid_buf_full_set;

// Reset the wr_skid_buf_full signal when the skid buffer data has been 
// read out
wire        wr_skid_buf_full_clr;

// Clock enable for signals in the AW channel
wire        aw_we;

// Clock enable for wcnt counter that counts the number of beats in the
// burst
wire        wcnt_we;

// Pulse to identify start of a new write transfer
wire        new_write_xfer;

// Sustain a write request till it is initiated on the AW/W channels
wire        write_data_avlbl;

// Prevent issue of new write access if the required conditions are not met
wire        write_init_deny;

// D-input of AWVALIDM
wire        nxt_awvalidm;

// D-input of AWPROTM
wire [2:0]  nxt_awprotm;

// D-input of AWCACHEM
wire [3:0]  nxt_awcachem;

// Authentication interface permissions removed
wire        mem_err_auth;

// D-input of AWADDRM
wire [39:0] nxt_awaddrm;

// D-input of AWLENM
wire [3:0]  nxt_awlenm;

// D-input of WLASTM
wire        nxt_wlastm;

// D-input of wr_skid_buf_full
wire        nxt_wr_skid_buf_full;

// Write access in progress - prevents another write access from being
// initiated by the AXI interface
wire        write_in_prog;

// Clock enable for WDATAM
wire        wdatam_we;

// D-input of ARVALIDM
wire        nxt_arvalidm;

// D-input of ARADDRM
wire [39:0] nxt_araddrm;

// Memory Read request detected
wire        mem_rd_en;

// D-input of ARCACHEM
wire [3:0]  nxt_arcachem;

// D-input of ARPROTM
wire [2:0]  nxt_arprotm;

// D-input of WVALIDM
wire        nxt_wvalidm;

// D-input of read_in_prog
wire        nxt_read_in_prog;

// D-input of rb_rdata_valid
wire        nxt_rb_rdata_valid;

// Count of the number of write transactions that are awaiting a slave response
wire [5:0]  outstanding_wreq_cnt;

// Clock enable for outstanding_wreq_cnt_p
wire        outstanding_wreq_cnt_p_we;

// Clock enable for fl_outstanding_wreq_cnt
wire        fl_outstanding_wreq_cnt_we;

// Signal to indicate read pointer increment
wire        rrp_incr;

// Clock enable for read pointer
wire        rrp_we;

// Signal to indicate write pointer increment
wire        rwp_incr;

// Clock enable for write pointer
wire        rwp_we;

// This is used for updating read and write pointers when a write happens 
// from APB. This signal ensures that appropriate number of bits at the LSB 
// are zeroed out, so that an incorrect write from software to those bits, 
// which are illegal will be ignored.
wire [31:0] masked_apb_wdata;

// Write enable for the combined read pointer which includes the
// higher order and lower order bits - asserted when there is an APB
// write to either portion
wire       rrp_full_wr_en;

// Start address of trace buffer - byte address
wire [39:0] dba_min_byte_addr;

// Start address of trace buffer - qualified with AXI databus width
wire [CXTMC_MEM_ADDR_WIDTH-1:0] dba_min;

// Intermediate signal to calculate nxt_dba_max
wire [39:0] nxt_dba_max_byte_addr;

// D-input of dba_max
wire [CXTMC_MEM_ADDR_WIDTH-1:0] nxt_dba_max;

// Post new write on AW channel
wire        write_start;

// Trace memory space threshold
wire [CXTMC_FILL_LEVEL_WIDTH-1:0] trace_mem_space_thrshold;

// Clock enable term for lat_buf_level
wire                                 lat_buf_level_we;

// Clock enable term for c_buf_level
wire                                 c_buf_level_we;
  
// D-input of wcnt
wire [WCNT_WIDTH-1:0] nxt_wcnt;
 
// Clock enable for wr_skid_buf
wire wr_skid_buf_we;

// D-input of wr_skid_buf
wire  [CXTMC_WB_DATA_WIDTH-1:0]          nxt_wr_skid_buf;

// D-input of lat_buf_level
wire [CXTMC_BUF_LEVEL_WIDTH-1:0]     nxt_lat_buf_level_reg;

// D-input of pt_read_in_prog
wire nxt_pt_read_in_prog;

// D-input of dba_w_empty
wire nxt_dba_w_empty;

// D-input of dba_r_empty
wire nxt_dba_r_empty;

// Clock enable for dba_w_empty
wire dba_w_empty_we;

// Clock enable for dba_r_empty
wire dba_r_empty_we;

// D-input of mem_err
wire nxt_mem_err;

// D-input of rb_req_ready_stg1
wire nxt_rb_req_ready_stg1;

// D-input of WDATAM
wire [CXTMC_AXI_DATA_WIDTH-1:0] nxt_wdatam;

// Clock enable for AR Channel signals
wire ar_ch_we;

// Common write enable signal for RWP and RWP_HI registers
wire rwp_full_wr_en;

// Intermediate signal used to calculate wb_thrshold_min4
wire [3:0] wb_thrshold_min3;

// When the TMC is running and there a flush request, the
// length of the burst initiated on the AXI is the minimum of 4 items:
// 1. axictl_wr_burst_len - Programmed burst length
// 2. wlen_4kb                - The length that would just meet a 4KB boundary
// 3. wlen_dba_max            - The length that would just touch the max limit
//                              of the trace buffer address range (in non-SG
//                              operation.
// 4. wlen_wb_fill_level      - Current fill level of the write buffer
wire [3:0] wb_thrshold_min4;

// Wlen based on just the current fill level of the write buffer
wire [3:0] wlen_wb_fill_level;

// Empty level considering only those writes that have received a 
// response on the B channel
wire trace_mem_empty_compl; 

// D-input of dba_r_ready
wire nxt_dba_r_ready;

// D-input of dba_r_ready
wire nxt_dba_w_ready;

// RWP has reached the end of a 4KB memory window
wire rwp_4kb;

// RRP has reached the end of a 4KB memory window
wire rrp_4kb;

// Page table read from Scatter Gather block
wire pt_rd_en;

// D-input of pt_data_hi
wire [27:0] nxt_pt_data_hi;

// D-input of pt_data_lo
wire [1:0] nxt_pt_data_lo;

// Distance of rwp_word_addr from the top of the trace memory window
wire [CXTMC_MEM_ADDR_WIDTH-1:0] rwp_dist_to_dba_max;

// Prevent issue of wb_req_ready if the trace memory is full in SWF mode
wire wb_req_ready_mask_trace_mem_full;

// D-input of pt_ready_axi_fetch
wire nxt_pt_ready_axi_fetch;

// Pointer wrap around detection in Circular buffer mode for FULL generation
wire sg_cbm_full_det;

// Maximum of 32 write transfers are outstanding
wire max_outstndg_wr_reached;

// D-input of sg_empty_pend
wire nxt_sg_empty_pend;

// Trace memory fill level for allowing Scatter Gather reads
wire [10:0] trace_mem_fill_level_sg_rd;

// D-input of rwp_last_4kb
wire nxt_rwp_last_4kb;

// Threshold level met for initiating a burst on AXI
wire wb_thrshold_met;

// D-input of fl_outstanding_wreq_cnt
wire [5:0] nxt_fl_outstanding_wreq_cnt;

// D-input of mem_flush_ack
wire nxt_mem_flush_ack;

// Check for  nxt_c_buf_level == trace_mem_space_thrshold
wire c_buf_level_eq_thrshold;

// Check for rwp_word_addr == rrp_word_addr
wire rwp_eq_rrp;

// Check for rwp_word_addr == dba_max
wire rwp_eq_dba_max;

// Check for rwp_word_addr_p1 == dba_max
wire rwp_p1_eq_dba_max;

// Initiate a new write access - if not permitted by the authentication
// interface, this results in mem_err
wire write_init_req;

// Read request results in mem_err due to insufficient privileges on
// the authentication interface
wire rd_auth_err;

// Initiate a new page table read access - if not permitted by the 
// authentication interface, this results in mem_err
wire pt_init_req;

// Full status of trace memory when in scatter-gather operation
wire trace_mem_full_sg;

// Distance of rwp_word_addr from crossing a 4KB boundary.
wire [11-CXTMC_PTR_PAD:0] rwp_p_dist_to_4kb;

// Update empty status bit once the read pointer and write pointer are
// valid following an update of the base address from the scatter gather
// block
wire  sg_empty_upd;

// Trace memory has sufficient empty locations to accommodate a burst of
// the programmed burst length
wire trace_mem_wr_thrshold_met;

// Burst length that would make the write pointer catch up with the read pointer
// The value is saturated to 'd16 which is the maximum allowed AXI burst length
wire [4:0] wlen_rwp_dist_to_rrp;

// When the pointers are on the same 4KB page, wr_burst_spc_avlbl indicates
// that the trace memory has sufficient empty locations to accommodate a burst 
// of the programmed burst length 
wire wr_burst_spc_avlbl;

// Calculate the distance of the Write pointer from the read pointer - used
// to determine whether a burst can be initiated when the pointers are on the 
// same 4KB page
wire [11-CXTMC_PTR_PAD:0] rwp_dist_to_rrp_same_page;

// Memory read initiation blocked by error response on B Channel
// Used to return a read acknowledge to the APB read fifo
wire mem_rd_init_err;

// Initiation request for a memory read
wire mem_rd_init_req;

// In Circular buffer mode, once the trace memory has wrapped around on writes,
// the read pointer is auto-incremented with writes so that reads return the
// oldest trace data first.
wire rrp_incr_fol;

// Detect the end of a 4KB block in scatter-gather operation on RRP increment
// that is a result of post-wrap memory writes in circular buffer mode
wire dba_r_empty_cbm_fol;

// D-input of rwp_upd_sg
wire nxt_rwp_upd_sg;

// Re-calculate and update FULL output since the write pointer has changed
wire full_wr_upd;

// Issue pt_ready to scatter-gather block if there is an address match with
// the last-issued read address
wire pt_ready_araddrm_match;

// D-input of araddrm_valid
wire nxt_araddrm_valid;

// Read pointer or write pointer invalid - awaiting base address of next
// 4KB block from scatter-gather block
wire sg_ptrs_invalid;

// In Scatter-Gather operation, the write pointer is invalid until it is
// loaded with the base address of the next 4KB block to which writes must
// occur
wire rwp_valid;

// In Scatter-Gather operation, the read pointer is invalid until it is
// loaded with the base address of the next 4KB block from which reads must
// occur
wire rrp_valid;

// In Scatter-Gather operation, the sg_empty_pend signal is set when the read 
// pointer has reached the end of the current 4KB block of memory
wire sg_empty_pend_set;

// Update lat_buf_level register since the current fill level has
// incresed beyond the last latched value
wire lat_buf_level_upd;

// D-input of rwp_word_addr_p1
wire [CXTMC_MEM_ADDR_WIDTH-1:0] nxt_rwp_word_addr_p1;

// D-input of skid_fl_pend
wire nxt_skid_fl_pend;

// Load enable for fl_outstanding_wreq_cnt counter
wire fl_wreq_cnt_load_en;

// Decrement fl_outstanding_wreq_cnt counter
wire fl_wreq_cnt_decr;

// Load value for fl_outstanding_wreq_cnt counter
wire [5:0] fl_wreq_cnt_load_val;

// D-input of rsz_single_word
wire       nxt_rsz_single_word;

// Longest burst that can be initiated without crossing the programmed
// address limits for the trace buffer
wire [3:0] wlen_dba_max;

// Longest burst that can be initiated without crossing a 4KB address boundary
wire [3:0] wlen_4kb;

// D-input of sg_cbm_empty_fol
wire nxt_sg_cbm_empty_fol;

//-----------------------------------------------------------------------------
// Reg declarations
//-----------------------------------------------------------------------------
// W Channel busy 
reg w_ch_busy;

// RSZ programmed for a single AXI data word size
reg rsz_single_word;

// In scatter-gather operation, empty bit update in circular buffer mode
// must take into account auto increment of the read pointer with writes.
// During such auto increment, the pointers being equal does not imply the
// trace memory is empty.
reg sg_cbm_empty_fol;

// Holds the value of rwp_word_addr + 1. Used to predict AW Channel address.
// For timing reasons, rwp_word_addr cannot be used directly as the 
// next address on the AW channel.
reg [CXTMC_MEM_ADDR_WIDTH-1:0] rwp_word_addr_p1;

// Upper address limit of trace buffer
reg [CXTMC_MEM_ADDR_WIDTH-1:0] dba_max;

// Pipelined count value for the number of outstanding write transfers
// awaiting a response on the B Channel
reg [5:0]                      outstanding_wreq_cnt_p;

// D-input of outstanding_wreq_cnt_p
reg [5:0]                      nxt_outstanding_wreq_cnt_p;

// After a AXI flush request is asserted, count the number of slave responses
// that are needed to acknowledge the flush request
reg [5:0]                      fl_outstanding_wreq_cnt;

// Count of the number of pending beats per write burst
reg [WCNT_WIDTH-1:0]           wcnt;

// Write pointer address in words
reg [CXTMC_MEM_ADDR_WIDTH-1:0] rwp_word_addr;

// D-input of rwp_word_addr
reg [CXTMC_MEM_ADDR_WIDTH-1:0] nxt_rwp_word_addr;

// Write skid buffer valid/full
reg                            wr_skid_buf_full;

// Write skid buffer
reg [CXTMC_WB_DATA_WIDTH-1:0]  wr_skid_buf;

// Read access in progress - 'ready' not received yet on R Channel
reg                            read_in_prog;

// D-input for read pointer address in words
reg       [CXTMC_MEM_ADDR_WIDTH-1:0] nxt_rrp_word_addr;

// Write pointer address in words
reg       [CXTMC_MEM_ADDR_WIDTH-1:0] rrp_word_addr;

// D-input of trace_mem_empty_sg
reg                             nxt_trace_mem_empty_sg;

// D-input of trace_mem_empty_no_sg
reg                             nxt_trace_mem_empty_no_sg;

// Sampled version of WREADYM
reg                            wreadym_reg;

// D-input of c_buf_level
reg     [CXTMC_BUF_LEVEL_WIDTH-1:0]  nxt_c_buf_level_reg;

// D-input for FULL
reg                                   nxt_full;

// Clocked version of lat_buf_level
reg  [CXTMC_BUF_LEVEL_WIDTH-1:0]       lat_buf_level_reg;

// Page table read in progress
reg pt_read_in_prog;

// No valid write base address, block writes to AXI trace memory in
// Scatter-Gather mode
reg dba_w_empty;

// No valid read base address, block reads to AXI trace memory in
// Scatter-Gather mode
reg dba_r_empty;

// Ready signal for reads without qualifying with Memory error
reg rb_req_ready_stg1;

// Registered version of BVALIDM
reg bvalidm_reg;

// Registered version of rwp_incr - used for synthesis timing reasons
reg rwp_incr_reg;

// Registered version of rrp_incr - used for synthesis timing reasons
reg rrp_incr_reg;

// Registered version of WVALIDM
reg wvalidm_reg;

// Number of locations awaiting a response on the B Channel
reg  [CXTMC_FILL_LEVEL_WIDTH-1:0] pend_level;

// Clocked version of c_buf_level based on rwp_incr_reg and rrp_incr_reg
reg  [CXTMC_BUF_LEVEL_WIDTH-1:0]       c_buf_level_reg;

// Trace memory empty status when in scatter-gather mode
reg                                  trace_mem_empty_sg;

// In Scatter-gather mode, when the read pointer crosses a 4KB address boundary,
// and a new 4kb block base address is not available from the scatter gather
// block, remember that the empty bit needs to be updated once the next
// read pointer address is known.
reg sg_empty_pend; 

// Last 4kb block address has been copied into rwp_word_addr
reg rwp_last_4kb;

// Empty status of trace memory when in non-scatter-gather operation
reg trace_mem_empty_no_sg;

// Delayed version of c_buf_level_eq_thrshold - used for negation of FULL on
// reads
reg c_buf_level_eq_thrshold_reg;

// Delayed version of new_write_xfer
reg new_write_xfer_reg;

// Detect the start of a new read transfer on the AXI for an access
// to trace memory - delayed version of mem_rd_en to reduce loading.
reg mem_rd_en_reg;

// Detect an update of rwp_word_addr in scatter gather operation - this is
// used to generate the FULL output
reg rwp_upd_sg;

// Registered version of ptr_clr - used to update wlen_dba_max after
// dba_max is generated. Helps synthesis timing.
reg ptr_clr_reg;

// Check whether ARADDRM is valid before it is used for comparison with the
// next page table read
reg araddrm_valid;

// Mark the last clock cycle of a write transfer considering both the 
// W Channel and the AW Channel
reg write_last;

// Delayed version of lat_buf_level_upd
reg lat_buf_level_upd_reg;

// pt_ready to scatter-gather block after an explicit page table read
reg pt_ready_axi_fetch;

// Delayed version of sg_cbm_full_det
reg sg_cbm_full_det_reg;

// Delayed version of rwp_eq_dba_max
reg rwp_eq_dba_max_reg;

// Flush of skid buffer data pending. Used in generation of mem_flush_ack
reg skid_fl_pend;

// Intermediate signal to calculate FULL output
reg full_wr_calc;

//-----------------------------------------------------------------------------
//
//  Main body of code 
//  =================
//
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// Write control logic
// When the TMC is disabled:
//   The last beat of the burst on the write buffer interface is acknowledged
// only after the burst has completed on the AXI interface (including a
// response on the B Channel).
// When the write buffer asserts a request and the AXI interface is able
// to accept the request, start a write transfer. However, the transfer is
// not started if there are 32 outstanding AXI writes, or if a write
// transfer is currently in progress. If the last beat of an AXI write burst
// transfer is about to be accepted by the AXI slave, then a new request can
// be initiated immediately.
// If a memory error has occurred, new transfers are not initiated.
// If a Low power interface request has been received, new transfers are not 
// initiated.
//-----------------------------------------------------------------------------
assign new_write_xfer = write_start & (~write_in_prog | write_last);

assign write_start = ~(mem_err | mem_err_auth) & write_init_req;

assign write_init_req = !(csysreq_reg && CSYSACK) ? 
                          1'b0 :
                        tmc_disabled ?
                          (wb_req_valid & ~write_in_prog & 
                           outstanding_wreq_cnt_eq0) :
                          (write_data_avlbl & ~write_init_deny);

assign write_data_avlbl = wb_req_valid | wr_skid_buf_full;

assign write_init_deny = wb_req_ready_mask_trace_mem_full |
                         ~wb_thrshold_met |
                         max_outstndg_wr_reached |
                         sg_ptrs_invalid |
                         (rwp_p1_invalid & WVALIDM);

  always @(posedge cxtmc_clk or negedge RESETn)
  begin : p_new_write_xfer_reg
    if (!RESETn)
      begin
        new_write_xfer_reg <= 1'b0;
      end
    else
      begin
        new_write_xfer_reg <= new_write_xfer;
      end
  end // block: p_new_write_xfer_reg

//-----------------------------------------------------------------------------
// Encode wb_fill_level to be consistent with WLEN to facilitate
// comparisons.
//-----------------------------------------------------------------------------
generate 
  if (CXTMC_WB_PTR_WIDTH == 2) // CXTMC_WBUFFER_DEPTH == 4
    assign wlen_wb_fill_level = wb_req_valid ? // wb_fill_level != 0
                                  (wr_skid_buf_full ? 
                                    ({1'b0, wb_fill_level[2:0]}) :
                                    ({1'b0, wb_fill_level[2:0]} - 4'h1)) :
                                  4'h0;
  else if (CXTMC_WB_PTR_WIDTH == 3) // CXTMC_WBUFFER_DEPTH == 8
    assign wlen_wb_fill_level = wb_req_valid ? // wb_fill_level != 0
                                  (wr_skid_buf_full ?
                                    (wb_fill_level[3:0]) : 
                                    (wb_fill_level[3:0] - 4'h1)) : 
                                  4'h0;
  else // CXTMC_WBUFFER_DEPTH == 16/32
    assign wlen_wb_fill_level = (wb_fill_level > 
                                {{CXTMC_WB_PTR_WIDTH+1-4{1'b0}}, 4'hF}) ? 
                                  4'hF : 
                                wb_req_valid ? // wb_fill_level != 0
                                  (wr_skid_buf_full ?
                                    (wb_fill_level[3:0]) :
                                    (wb_fill_level[3:0] - 4'h1)) :
                                  4'h0;
endgenerate

//-----------------------------------------------------------------------------
// An AXI burst is started only when sufficient data is available in the
// write buffer.
// When the TMC is disabled, a single data element present in the write buffer
// is sufficient to initiate an AXI access. This is because such accesses are
// initiated by APB register writes (relatively slow interface).
// When the TMC is enabled, a burst is initiated only when the write buffer
// fill level is greater than a threshold. However, if a write buffer flush
// has been requested or if the formatter has already stopped (no further
// data to be written to the write buffer), an AXI burst is initiated so as
// to speed up the completion of the flush.
//-----------------------------------------------------------------------------
assign wb_thrshold_met = tmc_disabled ? wb_req_valid : // wb_fill_level != 0  
                         ((wlen_wb_fill_level >= axictl_wr_burst_len) | 
                          (ft_stopped | wb_flush_req | mem_flush_req));

//-----------------------------------------------------------------------------
// To calculate the length of the AXI write burst, compare the programmed
// burst length, the distance to 4KB boundary crossing, the distance to
// reaching the top of the trace buffer (in Scatter Gather operation) and 
// the fill level in the write buffer (if a write buffer flush is in progress
// or if the formatter has stopped).
// This comparison is split into 2 steps. 
// Min of 3 values:
//   1. axictl_wr_burst_len
//   2. wlen_4kb
//   3. wlen_dba_max 
//-----------------------------------------------------------------------------
assign wb_thrshold_min3 =
        axictl_sg_mode ? // dba_max not valid in SG mode
         ((axictl_wr_burst_len < wlen_4kb) ? 
           axictl_wr_burst_len : wlen_4kb) :
         (((axictl_wr_burst_len <= wlen_4kb) && // Non-SG mode
          (axictl_wr_burst_len <= wlen_dba_max)) ? axictl_wr_burst_len :
         ((wlen_4kb <= wlen_dba_max) &&
          (wlen_4kb <= axictl_wr_burst_len)) ? wlen_4kb :
           wlen_dba_max);

//-----------------------------------------------------------------------------
// When a write buffer flush is in progress or the formatter has stopped,
// initiate a burst of length that also considers the fill level in the
// write buffer.
//-----------------------------------------------------------------------------
assign wb_thrshold_min4 = (wb_thrshold_min3 < wlen_wb_fill_level) ?
                           wb_thrshold_min3 : wlen_wb_fill_level;

//-----------------------------------------------------------------------------
// Distance of rwp_word_addr from crossing a 4KB boundary. The result is
// consistent with AWLEN encoding.
//-----------------------------------------------------------------------------
assign rwp_p_dist_to_4kb = {(12-CXTMC_PTR_PAD){1'b1}} -
                             rwp_word_addr_p[11-CXTMC_PTR_PAD:0];

assign wlen_4kb = (rwp_p_dist_to_4kb > 
                    {{(12-CXTMC_PTR_PAD-4){1'b0}}, 4'hF}) ?
                    4'hF : 
                  rwp_p_dist_to_4kb[3:0];

//-----------------------------------------------------------------------------
// Distance of rwp_word_addr from the top of the trace memory window. The 
// result is consistent with AWLEN encoding.
// If the write pointer is about to be updated, use the value on its D-input.
//-----------------------------------------------------------------------------
assign rwp_dist_to_dba_max = dba_max - rwp_word_addr_p;

assign wlen_dba_max = (rwp_dist_to_dba_max  >
                      {{(CXTMC_MEM_ADDR_WIDTH-4){1'b0}}, 4'hF}) ?
                        4'hF : 
                        rwp_dist_to_dba_max[3:0];

always @(posedge cxtmc_clk or negedge RESETn)
begin         
  if (!RESETn)
    begin
      ptr_clr_reg  <= 1'h0;
    end
  else 
    begin
      ptr_clr_reg  <= ptr_clr;
    end
end

//-----------------------------------------------------------------------------
// write_in_prog is asserted when a write transfer is in progress on the AW 
// channel or the W channel. Once a write transfer is initiated on the AW
// channel and the W channel, the TMC waits for a 'ready' on both the AW
// channel and the W channel before initiating a new write transfer on either
// channel.
//-----------------------------------------------------------------------------
assign write_in_prog = AWVALIDM | WVALIDM;

always @*
  begin
    case ({AWVALIDM, WVALIDM})
      2'b00 : // No transfer in progress
        write_last = 1'b0;
      2'b01 : // AW channel done, but W channel busy
        write_last = WLASTM & WREADYM;
      2'b10 : // AW channel busy, but W channel done
        write_last = AWREADYM;
      2'b11 : // Bothe AW Channel and W Channel busy
        write_last = AWREADYM & WLASTM & WREADYM;
      default :
        write_last = 1'bx;
    endcase
  end

//-----------------------------------------------------------------------------
// AWVALIDM generation.
// When there is a request from the Write buffer, initiate an access on the
// AW channel. Once asserted, AWVALIDM is held till the address and control
// information are accepted by the AXI.
//-----------------------------------------------------------------------------
assign nxt_awvalidm = new_write_xfer |
                      (AWVALIDM & ~AWREADYM);

//-----------------------------------------------------------------------------
// Sequential block for AWVALIDM
//-----------------------------------------------------------------------------
always @(posedge cxtmc_clk or negedge RESETn)
  if (!RESETn)
    AWVALIDM <= 1'b0;
  else 
    AWVALIDM <= nxt_awvalidm;


//-----------------------------------------------------------------------------
// AWPROTM generation
// When a new transaction is posted on the AW channel, sample the programmed
// values in the AXICTL register. AWPROT[2] is always driven 0 because the
// TMC always initiates 'data' accesses.
//-----------------------------------------------------------------------------
assign nxt_awprotm = {1'b0, axictl_prot_ctrl};

//-----------------------------------------------------------------------------
// AWCACHEM generation
// When a new transaction is posted on the AW channel, sample the programmed
// values in the AXICTL register.
//-----------------------------------------------------------------------------
assign nxt_awcachem = axictl_cache_ctrl;

//-----------------------------------------------------------------------------
// AWBURSTM generation.
// The TMC always initiates INCR-type bursts for writes.
//-----------------------------------------------------------------------------
assign AWBURSTM = AXI_BURST_TYPE_INCR;

//-----------------------------------------------------------------------------
// AWADDRM generation.
// In the non-Scatter-Gather mode, the Write address depends on the 
// programmed base address (DBALO, DBAHI) and the Write pointer.   
// Once write_start is asserted at the start of a transfer on the AW 
// channel, it is not asserted again till the address and control information 
// are accepted on the AXI. This ensures that AWADDRM is stable during a
// transfer.
//-----------------------------------------------------------------------------
assign nxt_awaddrm = {rwp_word_addr_p, {CXTMC_PTR_PAD{1'b0}}};

//-----------------------------------------------------------------------------
// AWLENM generation.
// The write buffer indicates for each request the length of the burst it
// can support for that request (this_xfr_blen[3:0]) based on the amount of 
// data present in the write buffer. The AXI interface registers this signal
// onto AWLENM[3:0] output when a new write transfer is initiated.
//-----------------------------------------------------------------------------
assign nxt_awlenm = (tmc_disabled) ? 4'h0 : wb_thrshold_min4;
 
//-----------------------------------------------------------------------------
// Initiate a new transfer when there is no transfer in progress or on the
// last cycle of an on-going transfer.
//-----------------------------------------------------------------------------
assign aw_we = new_write_xfer; 

//-----------------------------------------------------------------------------
// Sequential block for other AW channel outputs
//-----------------------------------------------------------------------------
always @(posedge cxtmc_clk)
  if (aw_we)
    begin
      AWCACHEM <= nxt_awcachem;
      AWADDRM  <= nxt_awaddrm;
      AWLENM   <= nxt_awlenm;
      AWPROTM  <= nxt_awprotm;
    end

//-----------------------------------------------------------------------------
// AW Channel tie-offs
// AWLOCK generation
// The TMC generates 'Normal' accesses only, so AWLOCKM is tied to 2'b00
// The TMC always generates write accesses that use all byte lanes in the
// databus, so AWSIZEM is driven with a constant based on AXI databus width.
//-----------------------------------------------------------------------------
assign AWLOCKM = AXI_LOCK_NORMAL;
assign AWSIZEM = CXTMC_AXI_SIZE_VAL;

//-----------------------------------------------------------------------------
// When a write access is started, load the write burst counter with the
// number of beats of burst that the write buffer can support. Decrement the
// write burst counter with each beat of data accepted on the AXI.
//-----------------------------------------------------------------------------
assign nxt_wcnt = new_write_xfer ?
                    (nxt_awlenm[WCNT_WIDTH-1:0]) :
                  (!WLASTM) ?
                    (wcnt - {{(WCNT_WIDTH-1){1'b0}}, 1'b1}) : wcnt;


assign wcnt_we = new_write_xfer | (WVALIDM && WREADYM); 

//-----------------------------------------------------------------------------
// Clock process for write burst counter 
//-----------------------------------------------------------------------------
always @(posedge cxtmc_clk or negedge RESETn)
  begin
    if (!RESETn)
      begin
        wcnt   <= {WCNT_WIDTH{1'b0}};
      end
    else if (wcnt_we)
      begin
        wcnt   <= nxt_wcnt;
      end
  end

//-----------------------------------------------------------------------------
// Clock process for WLASTM - not reset since this is qualified by WVALIDM
//-----------------------------------------------------------------------------
always @(posedge cxtmc_clk)
  begin
    if (wdatam_we)
      WLASTM <= nxt_wlastm;
  end

//-----------------------------------------------------------------------------
// WLASTM generation.
// When the write burst counter has reached 0, the last beat of write burst 
// is in progress.
//-----------------------------------------------------------------------------
assign nxt_wlastm = (~|(nxt_wcnt));

//-----------------------------------------------------------------------------
// WVALIDM generation.
// When there is a request from the Write buffer, initiate an access on the
// W channel. Once asserted, WVALIDM is held till the last beat of write data
// is accepted on the AXI.
//-----------------------------------------------------------------------------
assign nxt_wvalidm = new_write_xfer |
                     (WVALIDM & ~(WLASTM & WREADYM));

//-----------------------------------------------------------------------------
// Sequential block for WVALIDM
//-----------------------------------------------------------------------------
always @(posedge cxtmc_clk or negedge RESETn)
  if (!RESETn)
    WVALIDM <= 1'b0;
  else
    WVALIDM <= nxt_wvalidm;

//-----------------------------------------------------------------------------
// Clocked process for W Channel outputs
//-----------------------------------------------------------------------------
always @(posedge cxtmc_clk)
  begin
    if (wdatam_we)
      begin
        WDATAM <= nxt_wdatam;
      end
  end

//-----------------------------------------------------------------------------
// WDATAM generation
// If a write request is initiated, choose the write data from either the skid 
// buffer in the AXI interface or from the write buffer in the TMC. For the
// first beat of data, Higher priority is given to the data in the skid buffer 
// since that data corresponds to an earlier beat of the burst.
//-----------------------------------------------------------------------------
assign nxt_wdatam = wr_skid_buf_full ? wr_skid_buf : wb_data;

//-----------------------------------------------------------------------------
// Clock enable for WDATAM.
// Update WDATAM output when a beat of data has been accepted on the AXI or
// if a new write transfer is initiated.
//-----------------------------------------------------------------------------
assign wdatam_we = new_write_xfer | (WVALIDM & WREADYM);

//-----------------------------------------------------------------------------
// W Channel tie-offs                          
// WSTRBM generation
// The TMC uses all byte lanes on the AXI databus for all transfers.
//-----------------------------------------------------------------------------
assign WSTRBM = {(CXTMC_AXI_DATA_WIDTH/8){1'b1}};

//-----------------------------------------------------------------------------
// Sequential block for BVALIDM registering
//-----------------------------------------------------------------------------
always @(posedge cxtmc_clk or negedge RESETn)
  begin
    if (!RESETn)
      begin
        bvalidm_reg <= 1'b0;
      end
    else
      begin
        bvalidm_reg <= BVALIDM;
      end
  end

//-----------------------------------------------------------------------------
// Assert wb_req_ready when the AXI interface is able to post a transfer
// on the AXI.
// When a memory error has occurred, accept and discard data from the write
// buffer.
// When the TMC is disabled, wait for a response on the B Channel before
// signaling to the write buffer that the write data has been accepted.
//-----------------------------------------------------------------------------
assign wb_req_ready = (mem_err && (!WVALIDM)) ? 
                         1'b1 :
                      tmc_disabled ? 
                         bvalidm_reg : 
                         // When disabled, writes are of single beat. Response 
                         // from B Channel awaited to avoid data coherency 
                         // issues.
                         ~(wr_skid_buf_full); 
                         // If the internal buffer is already holding a beat 
                         // of write data, then block further data beats from 
                         // the write buffer. 

//-----------------------------------------------------------------------------
// In Software FIFO mode, do not accept further data from the write buffer
// if the trace memory is full. However, when there is an abrupt disable in
// SWF mode, overwrite of trace data is allowed to allow the TMC to return to 
// idle state as quickly as possible. The trace memory is considered full
// if it is short of the required empty locations to perform the required
// AXI burst - if not, the TMC waits till sufficient locations are empty.
//-----------------------------------------------------------------------------
assign wb_req_ready_mask_trace_mem_full = ~circ_buf_mode & 
                                          ~trace_mem_wr_thrshold_met &
                                          ~tmc_abort;

//-----------------------------------------------------------------------------
// Check if the space available in the trace memory is sufficient for an
// AXI burst. If the pointers are on different 4KB pages, then it is 
// ok to initiate an AXI burst (length of the burst being limited by the 4KB
// boundary crossing and other conditions). If the pointers are on the same
// 4KB page, then the wr_burst_spc_avlbl indicates whether the space
// requirement is met.
//-----------------------------------------------------------------------------
assign trace_mem_wr_thrshold_met = rrp_rwp_diff_4kb_page | 
                                   wr_burst_spc_avlbl;

assign rrp_rwp_diff_4kb_page = (rwp_word_addr_p[CXTMC_MEM_ADDR_WIDTH-1:
                                                 12-CXTMC_PTR_PAD] !=
                                rrp_word_addr[CXTMC_MEM_ADDR_WIDTH-1:
                                                 12-CXTMC_PTR_PAD]);
                                  
assign rwp_dist_to_rrp_same_page = rrp_word_addr[11-CXTMC_PTR_PAD:0] -
                                   rwp_word_addr_p[11-CXTMC_PTR_PAD:0];

assign wlen_rwp_dist_to_rrp = (rwp_dist_to_rrp_same_page >=
                              {{(12-CXTMC_PTR_PAD-5){1'b0}}, 5'b10000}) ?
                                5'b10000 :
                                {1'b0, rwp_dist_to_rrp_same_page[3:0]};

assign wr_burst_spc_avlbl = (wlen_rwp_dist_to_rrp > 
                              {1'b0, axictl_wr_burst_len}) |
                            (rwp_word_addr_p[11-CXTMC_PTR_PAD:0] > 
                             rrp_word_addr[11-CXTMC_PTR_PAD:0]) |
                            (trace_mem_empty & ~write_in_prog);

//-----------------------------------------------------------------------------
// When the outstanding_wreq_cnt counter has reached the max value of 32,
// prevent further writes from being initiated.
//-----------------------------------------------------------------------------
assign max_outstndg_wr_reached = (outstanding_wreq_cnt == 6'b100000);

//----------------------------------------------------------------------------
// Write skid buffer.
// This buffer helps minimise loading on the WREADYM input.
// This buffer is 1 element deep and CXTMC_AXI_DATA_WIDTH wide.
// This buffer is filled when a write is initiated on the W channel, but has
// not been accepted on the AXI and there is a further valid word of data from 
// the write buffer.
// This buffer is cleared when the last presented data is accepted by
// the AXI (which results in the skid buffer contents being copied onto the
// WDATAM output holding stage). 
//----------------------------------------------------------------------------
assign wr_skid_buf_full_set = ~tmc_disabled & wb_req_valid & ~wr_skid_buf_full &
                              (w_ch_busy | (write_last & ~write_start) | 
                              (~new_write_xfer & ~WVALIDM));

//-----------------------------------------------------------------------------
// The W Channel is not available to accept the next beat of write data 
// if 
//   - the current data beat has not been accepted OR
//   - the address on the AW channel for the on-going burst has not been 
//     accepted even after the data burst is complete on the W Channel
//-----------------------------------------------------------------------------
always @*
  begin
    case ({WVALIDM, AWVALIDM})
      2'b00 : // No transfer in progress
        w_ch_busy = 1'b0;
      2'b01 : // AW channel busy, but W channel done
        w_ch_busy = ~AWREADYM;
      2'b10 : // AW channel done, but W channel busy
        w_ch_busy = ~WREADYM;
      2'b11 : // Both AW Channel and W Channel busy
        w_ch_busy = WLASTM ? (~WREADYM | ~AWREADYM) : ~WREADYM;
      default :
        w_ch_busy = 1'bx;
    endcase
  end

assign wr_skid_buf_full_clr = new_write_xfer | 
                              (WVALIDM & WREADYM & ~WLASTM) |
                              (mem_err & ~WVALIDM);

assign nxt_wr_skid_buf_full = wr_skid_buf_full_set |
                              (wr_skid_buf_full & ~wr_skid_buf_full_clr);

assign wr_skid_buf_we = wr_skid_buf_full_set;

assign nxt_wr_skid_buf = wb_data;

//----------------------------------------------------------------------------
// Clocked process for data buffer 
//----------------------------------------------------------------------------
always @(posedge cxtmc_clk)
begin
  if (wr_skid_buf_we)
    begin
      wr_skid_buf <= nxt_wr_skid_buf;
    end
end

//----------------------------------------------------------------------------
// Clocked process for buffer status signal
//----------------------------------------------------------------------------
always @(posedge cxtmc_clk or negedge RESETn)
begin
  if (!RESETn)
    begin
      wr_skid_buf_full <= 1'b0;
    end
  else
    begin
      wr_skid_buf_full <= nxt_wr_skid_buf_full;
    end
end

//----------------------------------------------------------------------------
// B Channel tie-off.
// BREADYM output is tied high since response can be sampled by the TMC
// immediately. 
//----------------------------------------------------------------------------
assign BREADYM = 1'b1;

//----------------------------------------------------------------------------
// Outstanding write requests counter
// With every write transfer issued, this counter is incremented by 1.
// With every write response received on the B Channel, this counter is
// decremented by 1.
// Since BREADYM is tied high, it is not sampled in the generation of this
// counter.
// If an AXI error response is received, then the outstanding transfers
// are dropped, so the counter is made 0.
//----------------------------------------------------------------------------
assign outstanding_wreq_cnt_p_we = new_write_xfer_reg | bvalidm_reg;

assign outstanding_wreq_cnt = (new_write_xfer_reg && !bvalidm_reg) ? 
                                (outstanding_wreq_cnt_p + 6'b000001) :
                                (outstanding_wreq_cnt_p);

always @*
  begin
    case ({new_write_xfer_reg, bvalidm_reg})
      2'b10 : // New write transfer issued
        nxt_outstanding_wreq_cnt_p = (outstanding_wreq_cnt_p + 6'b000001);

      2'b01 : // Response received on B Channel
        nxt_outstanding_wreq_cnt_p = (outstanding_wreq_cnt_p - 6'b000001);
                                     
      2'b11,  // Simultaneous occurrence of a new write transfer being
               // issued and a response being received for an earlier
               // write transfer - no change in count
      2'b00 :
        nxt_outstanding_wreq_cnt_p = outstanding_wreq_cnt_p;
      default :
        nxt_outstanding_wreq_cnt_p = 6'bxxxxxx;
    endcase 
  end

//----------------------------------------------------------------------------
// Clocked process for outstanding_wreq_cnt 
//----------------------------------------------------------------------------
always @(posedge cxtmc_clk or negedge RESETn)
  begin : p_wreq_cnt
    if (!RESETn)
      outstanding_wreq_cnt_p <= 6'b000000;
    else if (outstanding_wreq_cnt_p_we)
      outstanding_wreq_cnt_p <= nxt_outstanding_wreq_cnt_p;
  end // p_wreq_cnt

//----------------------------------------------------------------------------
// Check for outstanding_wreq_cnt becoming 0
//----------------------------------------------------------------------------
assign outstanding_wreq_cnt_eq0 = ~|outstanding_wreq_cnt;

//----------------------------------------------------------------------------
// axi_intf_ready generation
// When the TMC is disabled, writes and reads are stalled on the APB anyway,
// so TMCReady is pulled high.
// If there are no outstanding write transfers and if there are no ongoing
// read or write transfers, then the AXI interface is in idle state. This
// is used to generate TMCReady in the APB interface.
//----------------------------------------------------------------------------
assign axi_intf_ready = tmc_disabled |
                        (outstanding_wreq_cnt_eq0 & 
                        ~(write_data_avlbl | write_in_prog) & 
                        ~(rb_req_valid | read_in_prog) & 
                        ~(pt_valid | pt_read_in_prog));

//----------------------------------------------------------------------------
// AXI Error status
// Error could be because the AXI slave returned an error response or the
// Authentication interface permissions conflict with the value programmed in 
// the AXICTL register. If the Scatter Gather block has detected an invalid
// page table entry, mem_err_pt input is asserted, leading to mem_err
// assertion.
//----------------------------------------------------------------------------
assign nxt_mem_err = ~(ptr_clr | mem_err_clr) &
                     (mem_err |
                     ((nxt_rb_rdata_valid | nxt_pt_ready_axi_fetch) & 
                       RRESPM[1]) |
                       // Read error response occurred 

                     (BVALIDM & BRESPM[1]) |
                       // Write error response occurred

                     ((write_init_req | mem_rd_init_req | 
                      pt_init_req) & mem_err_auth) |
                       // Authentication error occurred

                     mem_err_pt);
                       // Error in page table entry
            
assign mem_err_auth = (~dbgen_reg | (dbgen_reg & ~spiden_reg &
                       ~axictl_prot_ctrl[1]));

//-----------------------------------------------------------------------------
// Clocked process for mem_err functionality
//-----------------------------------------------------------------------------
  always @(posedge cxtmc_clk or negedge RESETn)
  begin : p_mem_err
    if (!RESETn)
      begin
        mem_err <= 1'b0;
      end
    else
      begin
        mem_err <= nxt_mem_err;
      end
  end // block: p_mem_err

//-----------------------------------------------------------------------------
// mem_rd_en is asserted, when a read request is accepted from the APB read
// FIFO and reads are not prohibited by authentication interface privilege
// levels.
//-----------------------------------------------------------------------------
assign mem_rd_init_req = rb_req_valid & rb_req_ready;
assign mem_rd_en = mem_rd_init_req & ~mem_err_auth & ~mem_err;

//-----------------------------------------------------------------------------
// Initiate a page table read access when there is no trace memory read in
// progress and AXI reads are not prohibited by authentication interface 
// privilege levels.
//-----------------------------------------------------------------------------
assign pt_rd_en = pt_init_req & ~mem_err_auth & ~mem_err;
assign pt_init_req = pt_valid & ~pt_ready_araddrm_match & ~read_in_prog & 
                     ~pt_read_in_prog & ~mem_rd_init_req & csysreq_reg & 
                     CSYSACK;

//-----------------------------------------------------------------------------
// If the end of the current page for writes has been reached, then remember 
// this by setting dba_w_empty. Memory read request takes higher priority than 
// page table read request
//-----------------------------------------------------------------------------
assign nxt_dba_w_empty = ((AWADDRM[11:CXTMC_PTR_PAD] + 
                         {{(12-CXTMC_PTR_PAD-4){1'b0}}, AWLENM} == 
                         {(12-CXTMC_PTR_PAD){1'b1}}) & 
                         ~dba_w_valid & new_write_xfer_reg) | 
                         ptr_clr |
                         (dba_w_empty & ~(dba_w_valid & dba_w_ready));

assign dba_w_empty_we = new_write_xfer_reg | dba_w_valid | ptr_clr;

//-----------------------------------------------------------------------------
// Clocked process for dba_w_empty
//-----------------------------------------------------------------------------
  always @(posedge cxtmc_clk or negedge RESETn)
  begin : p_dba_w_empty
    if (!RESETn)
      begin
        dba_w_empty <= 1'b1;
      end
    else if (dba_w_empty_we)
      begin
        dba_w_empty <= nxt_dba_w_empty;
      end
  end // block: p_dba_w_empty

//-----------------------------------------------------------------------------
// If the end of the current page for reads has been reached, then remember 
// this by setting dba_r_empty. Memory read request takes higher priority than 
// page table read request.  Reads are always single beat bursts.
// In Circular buffer mode, once the trace memory has wrapped around on writes,
// the read pointer is auto-incremented with writes so that reads return the
// oldest trace data first.
//-----------------------------------------------------------------------------
assign dba_r_empty_cbm_fol = rrp_4kb & rrp_incr_fol;
assign nxt_dba_r_empty = (((((&(ARADDRM[11:CXTMC_PTR_PAD])) & ARVALIDM &
                           read_in_prog) |
                           dba_r_empty_cbm_fol) & ~dba_r_valid) 
                           | ptr_clr) |
                         (dba_r_empty & ~(dba_r_valid & dba_r_ready));

assign dba_r_empty_we = mem_rd_en_reg | dba_r_valid | dba_r_empty_cbm_fol | 
                        ptr_clr;

//-----------------------------------------------------------------------------
// Clocked process for dba_r_empty
//-----------------------------------------------------------------------------
  always @(posedge cxtmc_clk or negedge RESETn)
  begin : p_dba_r_empty
    if (!RESETn)
      begin
        dba_r_empty <= 1'b1;
      end
    else if (dba_r_empty_we)
      begin
        dba_r_empty <= nxt_dba_r_empty;
      end
  end // block: p_dba_r_empty

//-----------------------------------------------------------------------------
// Accept a new read request only if the memory has atleast one valid entry.
// If the TMC is disabled, then reads are allowed regardless of the fill status
// of the trace memory since the pointers are under direct software control
// when the TMC is disabled.
//-----------------------------------------------------------------------------
assign nxt_rb_req_ready_stg1 = tmc_disabled | 
                           ~(trace_mem_empty_compl | nxt_pt_read_in_prog |
                             (nxt_dba_r_empty & axictl_sg_mode));

assign rb_req_ready = rb_req_ready_stg1 & csysreq_reg & 
                      CSYSACK & ~(dba_r_valid & dba_r_ready);

//-----------------------------------------------------------------------------
// Clocked process for rb_req_ready
//-----------------------------------------------------------------------------
  always @(posedge cxtmc_clk or negedge RESETn)
  begin : p_rb_req_ready
    if (!RESETn)
      rb_req_ready_stg1 <= 1'b0;
    else
      rb_req_ready_stg1 <= nxt_rb_req_ready_stg1;
  end // block: p_rb_req_ready

//-----------------------------------------------------------------------------
// Sequential block for ARVALIDM output
//-----------------------------------------------------------------------------
  always @(posedge cxtmc_clk or negedge RESETn)
  begin : p_arvalidm
    if (!RESETn)
      ARVALIDM <= 1'b0;
    else
      ARVALIDM <= nxt_arvalidm;
  end // block: p_arvalidm

//-----------------------------------------------------------------------------
// Enable AR Channel outputs when a memory read is initiated or a page table
// read is initiated.
//-----------------------------------------------------------------------------
assign ar_ch_we = mem_rd_en | pt_rd_en;

//-----------------------------------------------------------------------------
// Sequential block for other AR channel outputs
//-----------------------------------------------------------------------------
always @(posedge cxtmc_clk)
  if (ar_ch_we)
    begin
      ARADDRM  <= nxt_araddrm;
      ARCACHEM <= nxt_arcachem;
      ARPROTM  <= nxt_arprotm;
    end

//-----------------------------------------------------------------------------
// ARVALIDM generation.
// When there is a request from the APB Read FIFO, initiate an access on the
// AR channel. Once asserted, ARVALIDM is held till the address and control
// information are accepted by the AXI.
//-----------------------------------------------------------------------------
assign nxt_arvalidm = mem_rd_en | pt_rd_en |
                      (ARVALIDM & ~ARREADYM);

//----------------------------------------------------------------------------
// Start address of trace buffer is as programmed in to DBA_HI and DBA_LO
// registers 
//----------------------------------------------------------------------------
assign dba_min_byte_addr = {dba_hi, dba_lo};
assign dba_min = dba_min_byte_addr[39:CXTMC_PTR_PAD];

//----------------------------------------------------------------------------
// The upper address limit of the trace buffer is obtained by adding the
// size programmed into RSZ to the lower address limit. The value in RSZ is
// in 32-bit words.
//----------------------------------------------------------------------------
assign nxt_dba_max_byte_addr = dba_min_byte_addr + 
                               {7'b0000000, rsz_masked, 2'b00} - 
                               {{39{1'b0}}, 1'b1};
assign nxt_dba_max = nxt_dba_max_byte_addr[39:CXTMC_PTR_PAD];

//-----------------------------------------------------------------------------
// Update dba_max only when there is a 0 -> 1 transition on ctl_trace_capt_en
//-----------------------------------------------------------------------------
always @(posedge cxtmc_clk or negedge RESETn)
begin         
  if (!RESETn) begin
    dba_max  <= {CXTMC_MEM_ADDR_WIDTH{1'b0}};
  end else if (ptr_clr) begin
    dba_max  <= nxt_dba_max;
  end
end

//----------------------------------------------------------------------------
// ARADDRM generation.
// In the non-Scatter-Gather mode, the Read address depends on the 
// programmed base address (DBALO, DBAHI) and the Read pointer.   
// Once mem_rd_en is asserted at the start of a transfer on the AR 
// channel, it is not asserted again till the address and control information 
// are accepted on the AXI. This ensures that ARADDRM is stable during a
// transfer.
//----------------------------------------------------------------------------
assign nxt_araddrm = pt_rd_en ? pt_addr : rrp;

//-----------------------------------------------------------------------------
// AR Channel tie-offs
// The TMC generates 'Normal' accesses only, so ARLOCKM is tied to 2'b00
// ARLENM is tied to a constant value since the read accesses generated by the
// TMC are always of single-beat transfers.
// The TMC always generates read accesses that use all byte lanes in the
// databus, so ARSIZEM is driven with a constant value based on AXI databus 
// width.  
// The read accesses generated by the TMC are always of burst type 'FIXED'.
//-----------------------------------------------------------------------------
assign ARSIZEM = CXTMC_AXI_SIZE_VAL;
assign ARLOCKM = AXI_LOCK_NORMAL;
assign ARLENM = AXI_BURST_LEN_1;
//assign ARBURSTM = AXI_BURST_TYPE_FIXED;
assign ARBURSTM = AXI_BURST_TYPE_INCR;

//-----------------------------------------------------------------------------
// ARCACHEM generation
// When a new transaction is posted on the AR channel, sample the programmed
// values in the AXICTL register.
// To comply with AXI protocol, if CacheCtrlBit1 is 0, then CacheCtrlBit2 
// and CacheCtrlBit3 must also be 0. 
//-----------------------------------------------------------------------------
assign nxt_arcachem = axictl_cache_ctrl;

//-----------------------------------------------------------------------------
// ARPROTM generation
// When a new transaction is posted on the AR channel, sample the programmed
// values in the AXICTL register. ARPROT[2] is always driven 0 because the
// TMC always initiates 'data' accesses.
// Once mem_rd_en is asserted at the start of a transfer on the AR 
// channel, it is not asserted again till the address and control information 
// are accepted on the AXI.
//-----------------------------------------------------------------------------
assign nxt_arprotm = {1'b0, axictl_prot_ctrl};

//-----------------------------------------------------------------------------
// Tie-offs for R Channel
// The TMC always accepts read data when available on the AXI R Channel.
// The read transfers initiated by the TMC are always of single-beat burst 
// length.
//-----------------------------------------------------------------------------
assign RREADYM = 1'b1;

//-----------------------------------------------------------------------------
// Read control.
// read_in_prog is asserted when a Read access is initiated by the TMC. It is
// held till read data is sampled on the AXI. RREADYM is 
// always high, so it is not sampled in the generation of read_in_prog.
//-----------------------------------------------------------------------------
assign nxt_read_in_prog = mem_rd_en | (read_in_prog & ~RVALIDM); 
assign nxt_pt_read_in_prog = pt_rd_en | (pt_read_in_prog & ~pt_ready);

//-----------------------------------------------------------------------------
// Clock process for read_in_prog and pt_read_in_prog
//-----------------------------------------------------------------------------
always @(posedge cxtmc_clk or negedge RESETn)
  begin
    if (!RESETn)
      begin
        read_in_prog <= 1'b0;
        pt_read_in_prog <= 1'b0;
        mem_rd_en_reg <= 1'b0;
      end
    else
      begin
        read_in_prog <= nxt_read_in_prog;
        pt_read_in_prog <= nxt_pt_read_in_prog;
        mem_rd_en_reg <= mem_rd_en;
      end
  end

//-----------------------------------------------------------------------------
// Read buffer data valid is asserted when the AXI R channel is ready. RREADYM 
// is always high, so it is not sampled in the generation of 
//  nxt_rb_rdata_valid. The TMC always issues single-beat bursts on AXI reads.
// If a memory error has occurred due to this read, return a default 
// rb_rdata_valid to complete the transfer. Read data is discarded anyway
// since a mem_err results in PSLVERR being returned on the APB.
//-----------------------------------------------------------------------------
assign  nxt_rb_rdata_valid = (read_in_prog & RVALIDM) | rd_auth_err | 
                              mem_rd_init_err;
assign nxt_pt_ready_axi_fetch = pt_read_in_prog & RVALIDM;
assign pt_ready = pt_ready_axi_fetch | pt_ready_araddrm_match;
assign rd_auth_err = rb_req_valid & rb_req_ready & mem_err_auth;
assign mem_rd_init_err = mem_rd_init_req & mem_err;

//-----------------------------------------------------------------------------
// If a page table read address matches the last access on the AR channel,
// then issue a pt_ready without issuing an AXI read access. ARADDRM is valid
// only after atleast one page table read has completed on the AR channel since
// TraceCaptEn is set. This is to force an AXI read access to re-fetch the
// page table entry if TraceCaptEn had been cleared (for software to possibly 
// modify the page table) and set again between two successive page table reads.
//-----------------------------------------------------------------------------
assign pt_ready_araddrm_match = araddrm_valid & pt_valid & 
                                (ARADDRM == pt_addr) & ~pt_read_in_prog;
assign nxt_araddrm_valid = (ctl_trace_capt_en & pt_ready) |
                           (araddrm_valid & ctl_trace_capt_en);

//-----------------------------------------------------------------------------
// Clock process for read path logic
//-----------------------------------------------------------------------------
always @(posedge cxtmc_clk or negedge RESETn)
  begin
    if (!RESETn)
      begin
        rb_rdata_valid <= 1'b0;
        pt_ready_axi_fetch <= 1'b0;
        araddrm_valid <= 1'b0;
      end
    else
      begin
        rb_rdata_valid <=  nxt_rb_rdata_valid;
        pt_ready_axi_fetch <= nxt_pt_ready_axi_fetch;
        araddrm_valid <= nxt_araddrm_valid;
      end
  end

//-----------------------------------------------------------------------------
// Read data sampling.
// AXI read data is sampled when the AXI R channel is ready. RREADYM 
// is always high, so it is not used when sampling read data.  
//-----------------------------------------------------------------------------
always @(posedge cxtmc_clk or negedge RESETn)
  begin
    if (!RESETn)
      rb_data <= {CXTMC_WB_DATA_WIDTH{1'b0}};
    else if ( nxt_rb_rdata_valid)
      rb_data <= RDATAM;
  end

//-----------------------------------------------------------------------------
// Mux the correct lane of read data based on address bit pt_addr
//-----------------------------------------------------------------------------
generate
  if (CXTMC_AXI_DATA_WIDTH == 32)
    begin
      assign nxt_pt_data_hi = RDATAM[31:4];
      assign nxt_pt_data_lo = RDATAM[1:0];
    end
  else if (CXTMC_AXI_DATA_WIDTH == 64) 
    begin
      assign nxt_pt_data_hi = pt_addr[2] ? RDATAM[63:36] : RDATAM[31:4];
      assign nxt_pt_data_lo = pt_addr[2] ? RDATAM[33:32] : RDATAM[1:0];
    end
  else // (CXTMC_AXI_DATA_WIDTH == 128)
    begin
      reg [27:0] nxt_pt_data_hi_128; // nxt_pt_data_hi when AXI datawidth is 
                                     //   128 bits
      reg [1:0] nxt_pt_data_lo_128;  // nxt_pt_data_lo when AXI datawidth is 
                                     //   128 bits
      
      always @*
        case (pt_addr[3:2])
          2'b00 : begin
                    nxt_pt_data_hi_128 = RDATAM[31:4];
                    nxt_pt_data_lo_128 = RDATAM[1:0];
                  end
          2'b01 : begin
                    nxt_pt_data_hi_128 = RDATAM[63:36];
                    nxt_pt_data_lo_128 = RDATAM[33:32];
                  end
          2'b10 : begin
                    nxt_pt_data_hi_128 = RDATAM[95:68];
                    nxt_pt_data_lo_128 = RDATAM[65:64];
                  end
          2'b11 : begin
                    nxt_pt_data_hi_128 = RDATAM[127:100];
                    nxt_pt_data_lo_128 = RDATAM[97:96];
                  end
          default : 
                  begin
                    nxt_pt_data_hi_128 = {28{1'bx}};
                    nxt_pt_data_lo_128 = {2{1'bx}};
                  end
        endcase

      assign nxt_pt_data_hi = nxt_pt_data_hi_128;
      assign nxt_pt_data_lo = nxt_pt_data_lo_128;
    end
endgenerate

always @(posedge cxtmc_clk or negedge RESETn)
  begin
    if (!RESETn)
      begin
        pt_data_hi <= {28{1'b0}};
        pt_data_lo <= {2{1'b0}};
      end
    else if (nxt_pt_ready_axi_fetch)
      begin
        pt_data_hi <= nxt_pt_data_hi;
        pt_data_lo <= nxt_pt_data_lo;
      end
  end

//-----------------------------------------------------------------------------
// Read pointer increment control logic
// In the ETR configuration, memory reads can only be initiated from the APB.
// In this case, when APB reads of RRD are initiated, the read pointer
// is incremented only after the complete memory dataword is read out through
// the APB (apb_read_fifo_rrp_en asserted)
// In the Circular buffer mode, memory writes result in an impact on the read
// pointer after the trace memory is filled completely. This is to ensure that
// the first data read out from the trace memory is the oldest.
// The read pointer must be maintained when the TMC is enabled in 
// circular buffer mode.
// The read pointer is written with the write pointer value when trace 
// capture is enabled in circular buffer mode. Subsequently, when the 
// trace memory is written and the write pointer advances to again match
// the read pointer, the read pointer must progress along with the
// write pointer with every memory write to ensure that the oldest data 
// is read out first after trace capture stops.
// In the ETR configuration, when the ATB data width is 32 bits wide, 
// a single AXI read provides all data needed to service an APB read (APB 
// data bus is of 32bits width and is not configurable).
//-----------------------------------------------------------------------------
assign rrp_incr_fol = circ_buf_mode & nxt_full & rwp_incr;
generate 
  if (CXTMC_AXI_DATA_WIDTH == 32) 
    assign rrp_incr = rb_rdata_valid | rrp_incr_fol;
  else
    assign rrp_incr = apb_read_fifo_rrp_en | rrp_incr_fol;
endgenerate

//-----------------------------------------------------------------------------
// masked_apb_wdata is generated from apb_wdata by making appropriate bits in 
// LSB as 0. Refer description for CXTMC_PTR_LSB for more details
//-----------------------------------------------------------------------------
assign masked_apb_wdata = apb_wdata
                          & {{32-CXTMC_PTR_LSB{1'b1}}, {CXTMC_PTR_LSB{1'b0}}};

//-----------------------------------------------------------------------------
// Read pointer update logic
// When APB issues a pointer clear (when ctl_trace_capt_en goes from 0 to 1), 
// read pointer is reset to the value programmed in DBALO/HI registers.
// When a read pointer write happens (rrp_wr_en asserted), the read pointer is 
// updated. Note that rrp_wr_en input cannot be asserted when any memory 
// reads/writes occur because:
//   - RRP writes are allowed only when TraceCaptEn=0 and TMCReady=1, which 
//     implies that there is no trace capture in progress.
//   - When there is no trace capture in progress, reads/writes to memory can 
//     occur only from the APB.
//   - There can only be one access from the APB at a time - the assertion of 
//     rrp_wr_en implies an APB access to the RRP register (and not to RRD)
// Note that ptr_clr input cannot be asserted when any memory reads/writes can
// occur because:
//   - ptr_clr is the result of a 0 -> 1 transition on TraceCaptEn.
//   - Setting of TraceCaptEn bit is allowed only when TraceCaptEn=0 and 
//     TMCReady=1, which implies that there is no trace capture in progress.
// When rrp_incr is set, indicating the last data in apb read fifo is drained 
// out, the read pointer is incremented.
//-----------------------------------------------------------------------------
always @*
begin
    case ({ptr_clr, rrp_full_wr_en})
      2'b10,
      2'b11 : // ptr_clr overrides
        nxt_rrp_word_addr = dba_min;
      2'b01 : // Write access to the RRP/RRP_HI pointer registers
        nxt_rrp_word_addr = rrp_hi_wr_en ?
                                   {apb_wdata[7:0], 
                                    rrp_word_addr[
                                      CXTMC_MEM_ADDR_WIDTH-8-1 : 0]} :
                                 // rrp_wr_en - lower order bits
                                   {rrp_word_addr[
                                      CXTMC_MEM_ADDR_WIDTH-1:
                                      CXTMC_MEM_ADDR_WIDTH-8], 
                                    masked_apb_wdata[31:CXTMC_PTR_PAD]};
      2'b00 : // By default prepare for incrementing by 1 - clock enabled
              // by late-arriving signal dependent on WREADYM
        nxt_rrp_word_addr = (dba_r_valid && dba_r_ready) ?
                                {dba_r_addr[27:0], {(12-CXTMC_PTR_PAD){1'b0}}} :
                            ((!axictl_sg_mode) && (!tmc_disabled) &&
                              ((rrp_word_addr == dba_max))) ?
                                dba_min :
                                (rrp_word_addr +
                                {{CXTMC_MEM_ADDR_WIDTH-1{1'b0}}, 1'b1});
      default :
        nxt_rrp_word_addr = {CXTMC_MEM_ADDR_WIDTH{1'bx}};
    endcase
end

//-----------------------------------------------------------------------------
// Detect a write to upper/lower portion of RRP
//-----------------------------------------------------------------------------
assign rrp_full_wr_en = rrp_wr_en | rrp_hi_wr_en;

//-----------------------------------------------------------------------------
// rrp_we is clock enable for rrp
// rrp_we is set when apb_read_fifo_rrp_en is set, which
// denotes that the last data has been emptied from APB Read fifo
// or when a write to the read pointer happens from APB, or when a clear happens
//-----------------------------------------------------------------------------
assign rrp_we = rrp_full_wr_en | rrp_incr | ptr_clr |
                (dba_r_valid & dba_r_ready);

//-----------------------------------------------------------------------------
// Update read pointer address only when rrp_we is set
//-----------------------------------------------------------------------------
always @(posedge cxtmc_clk or negedge RESETn)
begin
  if (!RESETn) begin
    rrp_word_addr  <= {CXTMC_MEM_ADDR_WIDTH{1'b0}};
  end else if (rrp_we) begin
    rrp_word_addr  <= nxt_rrp_word_addr;
  end
end

//-----------------------------------------------------------------------------
// Pad rrp_word_addr with the required number of '0's to make rrp a 
// byte address. 
//-----------------------------------------------------------------------------
assign rrp = {rrp_word_addr, {CXTMC_PTR_PAD{1'b0}}};

//-----------------------------------------------------------------------------
// Write pointer increment control logic
// When a write transfer has been accepted on the AXI, the write pointer is 
// incremented.
//-----------------------------------------------------------------------------
assign rwp_incr = WVALIDM & WREADYM;

//-----------------------------------------------------------------------------
// Write pointer update logic
// When a write pointer write happens, the write pointer is updated.
// When TraceCaptEn is set (pulse on ptr_clr), the write pointer is cleared
// if in FIFO modes. If in Circular buffer mode, the pointer retains its
// value (previously initialised through APB)
// When there is an APB access to write to the pointers, it is updated with 
// the APB write data masked to ensure alignment of value to memory datawidth
// and frame size.
// When a write access has been issued to memory (rwp_incr asserted), the
// write pointer is incremented. 
//-----------------------------------------------------------------------------
assign rwp_full_wr_en = rwp_wr_en | rwp_hi_wr_en;

always @*
  begin
    case ({ptr_clr, rwp_full_wr_en})
      2'b10,
      2'b11 : // ptr_clr overrides
        begin
          nxt_rwp_word_addr    = dba_min;
        end

      2'b01 :
        nxt_rwp_word_addr = rwp_hi_wr_en ?
                                   {apb_wdata[7:0],
                                    rwp_word_addr[
                                      CXTMC_MEM_ADDR_WIDTH-8-1 : 0]} :
                                 // rwp_wr_en - lower order bits
                                   {rwp_word_addr[
                                      CXTMC_MEM_ADDR_WIDTH-1:
                                      CXTMC_MEM_ADDR_WIDTH-8],
                                    masked_apb_wdata[31:CXTMC_PTR_PAD]};
      2'b00 : // By default prepare for incrementing by 1 - clock enabled
              // by late-arriving signal dependent on WREADYM
        nxt_rwp_word_addr = (dba_w_valid && dba_w_ready) ? 
                                {dba_w_addr[27:0], {(12-CXTMC_PTR_PAD){1'b0}}} :
                            ((!axictl_sg_mode) && (!tmc_disabled) && 
                             rwp_eq_dba_max) ?
                             dba_min :
                             (rwp_word_addr +
                             {{CXTMC_MEM_ADDR_WIDTH-1{1'b0}}, 1'b1});
      default :
        nxt_rwp_word_addr = {CXTMC_MEM_ADDR_WIDTH{1'bx}};
    endcase
  end
 
//-----------------------------------------------------------------------------
// Check whether the RSZ register is programmed for a single dataword.
//-----------------------------------------------------------------------------
generate
  if (CXTMC_AXI_DATA_WIDTH == 32) 
    assign nxt_rsz_single_word = ~axictl_sg_mode & ~tmc_disabled &
                                 (rsz_masked == {{30{1'b0}}, 1'b1});   
  else if (CXTMC_AXI_DATA_WIDTH == 64)
    assign nxt_rsz_single_word = ~axictl_sg_mode & ~tmc_disabled &
                                 (rsz_masked == {{29{1'b0}}, 2'b10});
  else // CXTMC_AXI_DATA_WIDTH == 128
    assign nxt_rsz_single_word = ~axictl_sg_mode & ~tmc_disabled &
                                 (rsz_masked == {{28{1'b0}}, 3'b100});
endgenerate

  always @(posedge cxtmc_clk or negedge RESETn)
  begin : p_rsz
    if (!RESETn)
      begin
        rsz_single_word <= 1'b0;
      end
    else if (ptr_clr)
      begin
        rsz_single_word <= nxt_rsz_single_word;
      end
  end // p_rsz

//-----------------------------------------------------------------------------
// If a write transfer is on-going, choose the predicted address for the next 
// transfer on-going. If RSZ is programmed for a single AXI data word size, 
// then all transfers are to the same address.
//-----------------------------------------------------------------------------
assign rwp_word_addr_p = (rsz_single_word || !WVALIDM) ?  
                           rwp_word_addr : rwp_word_addr_p1;
assign rwp_p = {rwp_word_addr_p, {CXTMC_PTR_PAD{1'b0}}};

//-----------------------------------------------------------------------------
// Clock enable for rwp_word_addr
//-----------------------------------------------------------------------------
assign rwp_we = rwp_incr | rwp_full_wr_en | ptr_clr |
                (dba_w_valid & dba_w_ready);

//-----------------------------------------------------------------------------
// Update write pointer address only when rwp_we is set
//-----------------------------------------------------------------------------
always @(posedge cxtmc_clk or negedge RESETn)
begin
  if (!RESETn) begin
    rwp_word_addr  <= {CXTMC_MEM_ADDR_WIDTH{1'b0}};
  end else if (rwp_we) begin
    rwp_word_addr  <= nxt_rwp_word_addr;
  end
end

//-----------------------------------------------------------------------------
// rwp_full_word_addr stores the Write Pointer as a word address. rwp is a byte 
// pointer.
// CXTMC_PTR_PAD provides the number of bits to be padded to arrive at the byte
// pointer from word address
//-----------------------------------------------------------------------------
assign rwp = {rwp_word_addr,{CXTMC_PTR_PAD{1'b0}}};

//-----------------------------------------------------------------------------
// Detect the end of a page for reads/writes in scatter gather operation 
//-----------------------------------------------------------------------------
assign rrp_4kb = &(rrp_word_addr[12-CXTMC_PTR_PAD-1:0]);
assign rwp_4kb = &(rwp_word_addr[12-CXTMC_PTR_PAD-1:0]);

//-----------------------------------------------------------------------------
// The write pointer is updated only when WREADYM for a beat of burst is
// detected on the AXI. To predict the address of the next transfer, use a
// shadow rwp that is ahead of rwp by 1. This helps in ensuring that the next 
// transfer is initiated on the AXI on the very next clock after the WREADYM 
// for the last beat is detected.
//-----------------------------------------------------------------------------
assign nxt_rwp_word_addr_p1 = 
                            (ptr_clr_reg) ?
                              (rwp_word_addr + 
                              {{(CXTMC_MEM_ADDR_WIDTH-1){1'b0}}, 1'b1}) :
                            (dba_w_valid && dba_w_ready) ?
                              ({dba_w_addr[27:0], {(12-CXTMC_PTR_PAD){1'b0}}} +
                               {{(CXTMC_MEM_ADDR_WIDTH-1){1'b0}}, 1'b1}) :
                            ((!axictl_sg_mode) && (!tmc_disabled) &&
                              rwp_p1_eq_dba_max) ?
                              (dba_min) :
                              (rwp_word_addr_p1 +
                               {{(CXTMC_MEM_ADDR_WIDTH-1){1'b0}}, 1'b1});

assign rwp_word_addr_p1_we = rwp_incr | ptr_clr_reg | 
                             (dba_w_valid & dba_w_ready); 

//-----------------------------------------------------------------------------
// Update the predicted write pointer address only when rwp_word_addr_p1_we is 
// set
//-----------------------------------------------------------------------------
always @(posedge cxtmc_clk or negedge RESETn)
begin
  if (!RESETn) begin
    rwp_word_addr_p1  <= {CXTMC_MEM_ADDR_WIDTH{1'b0}};
  end else if (rwp_word_addr_p1_we) begin
    rwp_word_addr_p1  <= nxt_rwp_word_addr_p1;
  end
end

//-----------------------------------------------------------------------------
// In scatter-gather operation, when the write pointer is on the verge of a 
// 4KB boundary, prevent the use of the pipelined address for deciding on the 
// issue of the next transfer.
// This is to wait till the address of the next 4KB block is loaded into the
// write pointer.
//-----------------------------------------------------------------------------
assign rwp_p1_invalid = axictl_sg_mode & rwp_4kb;

//-----------------------------------------------------------------------------
// In scatter gather operation, assert dba_r_ready when the internal read 
// pointer has reached the end of the current 4KB page. Since the pointer will
// be over-written with the new page address, wait till any on-going read is
// complete. dba_r_ready is asserted regardless of whether dba_r_valid is
// asserted.
//-----------------------------------------------------------------------------
assign nxt_dba_r_ready = axictl_sg_mode & 
                         ((rrp_4kb & rrp_incr) | 
                          (~nxt_read_in_prog & nxt_dba_r_empty));

//-----------------------------------------------------------------------------
// In scatter gather operation, assert dba_w_ready when the internal write 
// pointer has reached the end of the current 4KB page. Since the pointer will
// be over-written with the new page address, wait till any on-going write is
// complete. dba_w_ready is asserted regardless of whether dba_w_valid is
// asserted.
//-----------------------------------------------------------------------------
assign nxt_dba_w_ready = axictl_sg_mode &
                         ((rwp_4kb & rwp_incr) | 
                          (~nxt_wvalidm & nxt_dba_w_empty)); 

//-----------------------------------------------------------------------------
// Clocked process for dba_r_ready and dba_w_ready 
//-----------------------------------------------------------------------------
  always @(posedge cxtmc_clk or negedge RESETn)
  begin : p_dba_x_ready
    if (!RESETn)
      begin
        dba_r_ready <= 1'b0;
        dba_w_ready <= 1'b0;
      end
    else
      begin
        dba_r_ready <= nxt_dba_r_ready;
        dba_w_ready <= nxt_dba_w_ready;
      end
  end // block: p_dba_x_ready

//-----------------------------------------------------------------------------
// The threshold space for signaling FULL is calculated from the
// programmed water mark fill level and the max fill level 
// Based on the width of the memory databus, the c_buf_level increments
// in steps of 1, 2 or 4. The value programmed into the BFWM register
// is masked to ignore the corresponding number of LSBits. 
//-----------------------------------------------------------------------------
assign trace_mem_space_thrshold = rsz_masked[CXTMC_FILL_LEVEL_WIDTH-1:0] -
                                  ({1'b0, buf_wm} & CXTMC_BUF_LEVEL_CMP_MASK);

//-----------------------------------------------------------------------------
// Compare checks
//-----------------------------------------------------------------------------
generate
  if (CXTMC_AXI_DATA_WIDTH == 32) 
    assign c_buf_level_eq_thrshold = (nxt_c_buf_level_reg == trace_mem_space_thrshold);
  else
    assign c_buf_level_eq_thrshold = 
     ({nxt_c_buf_level_reg,{CXTMC_BUF_LEVEL_PAD{1'b0}}} == trace_mem_space_thrshold);
endgenerate
assign rwp_eq_rrp = (rwp_word_addr == rrp_word_addr); 
assign rwp_eq_dba_max = (rwp_word_addr == dba_max);
assign rwp_p1_eq_dba_max = (rwp_word_addr_p1 == dba_max);

//-----------------------------------------------------------------------------
// Sequential block for delaying c_buf_level_eq_thrshold. Used in the 
// generation of FULL output.
//-----------------------------------------------------------------------------
always @(posedge cxtmc_clk or negedge RESETn)
  if (!RESETn)
    c_buf_level_eq_thrshold_reg <= 1'b0;
  else
    c_buf_level_eq_thrshold_reg <= c_buf_level_eq_thrshold; 

//-----------------------------------------------------------------------------
// FULL generation
// When TraceCaptureEn is set (ptr_clr asserted), FULL is cleared.
// When in Circular Buffer mode, the FULL flag is set when the write pointer
// wraps around to 0. Once the FULL flag is set, it remains set
// till cleared by the assertion of ptr_clr (regardless of reads from the
// trace memory making it non full).
// When TraceCaptEn is cleared, FULL retains its value till cleared by ptr_clr
// By design, ptr_clr cannot occur at the same time as a read or write being
// issued to memory.  
// In FIFO modes, the FULL output reflects the fill status of the trace
// memory dynamically.
// On reads, if the fill level is about to fall below the set threshold, FULL 
// is cleared.
// On writes, if the fill level is about to reach the threshold, FULL is set. 
// Use of the '==' operator results in lesser logic gates over use of '<=' 
// operator.
// In the Integration test mode, FULL output is controlled by writes to the
// ITMISCOP0 register.
//-----------------------------------------------------------------------------
assign full_wr_upd = rwp_incr_reg | rwp_upd_sg;
always @*
begin
  if (it_ctrl)
     nxt_full = it_misc_op_0_wr_en ? apb_wdata[1] : FULL;
  else
    case ({full_wr_upd, rrp_incr_reg})
      2'b00,  // Neither pointers change
      2'b11 : // Both pointers increment, so fill level remains same
         nxt_full = (ptr_clr) ? 1'b0 : FULL;
      2'b01 : // Read pointer increment
         nxt_full = (circ_buf_mode || (!ctl_trace_capt_en)) ? FULL :
                    (axictl_sg_mode ||  // SWF mode, any read makes non-full
                     c_buf_level_eq_thrshold_reg) ? 1'b0 : FULL;
      2'b10 : // Write pointer increment 
         nxt_full = full_wr_calc;
      default :
         nxt_full           = 1'bx;
    endcase
end

//-----------------------------------------------------------------------------
// The logic below calculates the FULL output when there is an update to the 
// write pointer without a simultaneous update to the read pointer. 
// In Circular buffer mode, once FULL output is set, it is retained till
// there is a rising edge on TraceCaptEn.
// In Scatter-Gather operation, the DBALO/HI registers do not determine the
// top of the trace memory area. 
// In SWF mode, the FULL output is set when the buffer level exceeds the
// programmed threshold value in the BUFWM register.
//-----------------------------------------------------------------------------
always @*
begin
  case ({circ_buf_mode, axictl_sg_mode})
    2'b00 : full_wr_calc = (!ctl_trace_capt_en) ? 
                             FULL :
                             (FULL | c_buf_level_eq_thrshold);
    2'b10 : full_wr_calc = FULL | rwp_eq_dba_max_reg;
    2'b11 : full_wr_calc = FULL | sg_cbm_full_det_reg;
    2'b01 : full_wr_calc = trace_mem_full_sg; 
    default :
            full_wr_calc = 1'bx;
  endcase
end

//-----------------------------------------------------------------------------
// In scatter gather operation, if the write pointer has been updated with
// address from the scatter gather block, then recalculate FULL with the 
// updated write pointer value.
//-----------------------------------------------------------------------------
assign nxt_rwp_upd_sg = dba_w_valid & dba_w_ready;
  
//-----------------------------------------------------------------------------
// Clock process for FULL output and related logic
//-----------------------------------------------------------------------------
always @(posedge cxtmc_clk or negedge RESETn)
begin
  if (!RESETn)
    begin
      FULL <= 1'b0;
      rwp_upd_sg <= 1'b0;
    end
  else
    begin
      FULL <=  nxt_full;
      rwp_upd_sg <= nxt_rwp_upd_sg;
    end
end

//-----------------------------------------------------------------------------
// In scatter-gather operation in circular buffer mode, the FULL bit is set when
// last 4KB block of memory has been written
//-----------------------------------------------------------------------------
assign sg_cbm_full_det = rwp_4kb & rwp_last_4kb;

//-----------------------------------------------------------------------------
// Delay sg_cbm_full_det by 1 clock to align with rwp_incr_reg used to
// update the FULL output.
//-----------------------------------------------------------------------------
  always @(posedge cxtmc_clk or negedge RESETn)
  begin
    if (!RESETn)
      begin
        sg_cbm_full_det_reg  <= 1'b0;
        rwp_eq_dba_max_reg   <= 1'b0;
      end
    else 
      begin
        sg_cbm_full_det_reg  <= sg_cbm_full_det;
        rwp_eq_dba_max_reg   <= rwp_eq_dba_max;
      end
  end

//-----------------------------------------------------------------------------
// Detect the occurrence of the last 4KB page in scatter-gather operation.
// This is used in the generation of FULL output.
//-----------------------------------------------------------------------------
assign nxt_rwp_last_4kb = (dba_w_last & dba_w_valid & dba_w_ready) |
                          (rwp_last_4kb & 
                         ~((dba_w_valid & dba_w_ready) | ptr_clr));

//-----------------------------------------------------------------------------
// Clocked process for rwp_last_4kb
//-----------------------------------------------------------------------------
  always @(posedge cxtmc_clk or negedge RESETn)
  begin
    if (!RESETn)
      begin
        rwp_last_4kb  <= 1'b0;
      end
    else
      begin
        rwp_last_4kb  <= nxt_rwp_last_4kb;
      end
  end
 
//-----------------------------------------------------------------------------
// Trace memory full condition detection
// In scatter-gather operation, the trace memory is full if the pointers are
// valid, equal and the trace memory is not empty. The pointers are said to
// be invalid when either pointer has reached the end of a 4KB page and the
// scatter-gather block is not yet ready with the base address of the next
// 4KB page. New accesses are blocked from being issued till the pointers are
// valid and the empty status flag is updated.
//-----------------------------------------------------------------------------
assign trace_mem_full_sg = (rwp_eq_rrp & 
                           ~sg_ptrs_invalid & ~trace_mem_empty_sg);

assign sg_ptrs_invalid = axictl_sg_mode & 
                         (~rrp_valid | ~rwp_valid | sg_empty_upd);

//-----------------------------------------------------------------------------
// Trace memory empty condition detection. In non-scatter gather operation,
// trace_mem_empty flag will be set if the new read pointer matches the 
// write pointer
//-----------------------------------------------------------------------------
always @*
begin
  case ({ctl_trace_capt_en, ptr_clr, rwp_incr, rrp_incr})
    4'b0000,
    4'b0001,
    4'b0010,
    4'b0011,
    4'b0100,
    4'b0101,
    4'b0110,
    4'b0111 : // ctl_trace_capt_en low
       nxt_trace_mem_empty_no_sg = 1'b0;
    4'b1100,      
    4'b1101,      
    4'b1110,        
    4'b1111 : // ptr_clr asserted
       nxt_trace_mem_empty_no_sg = 1'b1;
    4'b1000,  // No change in pointers
    4'b1011 : // Both pointers increment, so fill level remains same
       nxt_trace_mem_empty_no_sg = trace_mem_empty_no_sg;
    4'b1001 : // Increment Read pointer only
       nxt_trace_mem_empty_no_sg = (nxt_rrp_word_addr == rwp_word_addr);
    4'b1010 : // Increment Write pointer only
              // trace_mem_empty is reset because the write would make the 
              // memory non-empty
       nxt_trace_mem_empty_no_sg = 1'b0;
    default :
       nxt_trace_mem_empty_no_sg = 1'bx;
  endcase
end

//-----------------------------------------------------------------------------
// Clocked process for trace_mem_empty_no_sg
//-----------------------------------------------------------------------------
always @(posedge cxtmc_clk or negedge RESETn)
  if (!RESETn)
    trace_mem_empty_no_sg <= 1'b0;
  else
    trace_mem_empty_no_sg <=  nxt_trace_mem_empty_no_sg; 

//----------------------------------------------------------------------------
// Empty status detection in scatter-gather operation
//----------------------------------------------------------------------------
always @*
begin
  case ({ctl_trace_capt_en, ptr_clr, rwp_incr, rrp_incr, sg_empty_upd})
    5'b00000,
    5'b00001,
    5'b00010,
    5'b00011,
    5'b00100,
    5'b00101,
    5'b00110,
    5'b00111,
    5'b01000,
    5'b01001,
    5'b01010,
    5'b01011,
    5'b01100,
    5'b01101,
    5'b01110,
    5'b01111 : // ctl_trace_capt_en low
       nxt_trace_mem_empty_sg = 1'b0;
    5'b11000,      
    5'b11001,      
    5'b11010,      
    5'b11011,      
    5'b11100,        
    5'b11101,        
    5'b11110,
    5'b11111 : // ptr_clr asserted
       nxt_trace_mem_empty_sg = 1'b1;
    5'b10000,  // No change in pointers
    5'b10111,  // This combination will never occur, but is present for
               //   full case coverage. Assertion added.
    5'b10110 : // Both pointers increment, so fill level remains same
       nxt_trace_mem_empty_sg = trace_mem_empty_sg;
    5'b10011,  // This combination will never occur, but is present for
               //   full case coverage. 
    5'b10001 : // Pending update of empty status - no simultaneous write
       nxt_trace_mem_empty_sg = rwp_eq_rrp & ~sg_cbm_empty_fol;
    5'b10010 : // Increment Read pointer only - within the same 4kb block
       nxt_trace_mem_empty_sg = rrp_4kb ? trace_mem_empty_sg :
                                         (nxt_rrp_word_addr == rwp_word_addr);
    5'b10100,  // Increment Write pointer only
    5'b10101 : // Pending update of empty status - simultaneous write
              // trace_mem_empty is reset because the write would make the 
              // memory non-empty
       nxt_trace_mem_empty_sg = 1'b0;
    default :
       nxt_trace_mem_empty_sg = 1'bx;
  endcase
end

//-----------------------------------------------------------------------------
// If the read pointer becomes invalid on reaching the end of a 4KB page,
// remember to update the empty flag when the pointers become valid
// subsequently.
//-----------------------------------------------------------------------------
assign sg_empty_pend_set = rrp_incr & axictl_sg_mode & 
                           (nxt_dba_r_empty | rrp_4kb);
                           
assign rwp_valid = ~dba_w_empty & ~(dba_w_valid & dba_w_ready);
assign rrp_valid = ~dba_r_empty & ~(dba_r_valid & dba_r_ready);

assign nxt_sg_empty_pend = sg_empty_pend_set |
                           (sg_empty_pend & ~(rwp_valid & rrp_valid));

always @(posedge cxtmc_clk or negedge RESETn)
begin
  if (!RESETn)
    begin
      sg_empty_pend <= 1'b0;
    end
  else
    begin
      sg_empty_pend <= nxt_sg_empty_pend;
    end
end

assign sg_empty_upd = sg_empty_pend & rwp_valid & rrp_valid; 

//-----------------------------------------------------------------------------
// If an update to the write pointer happened while the read pointer was
// awaiting an update from the scatter-gather block, then the trace memory
// is not empty even if the pointers are equal in value. This can occur in
// Scatter-gather operation in Circular buffer mode once the trace memory
// is full and the read pointer starts incrementing with further writes.
//-----------------------------------------------------------------------------
assign nxt_sg_cbm_empty_fol = (axictl_sg_mode & rrp_incr_fol & rrp_4kb) |
                              (sg_cbm_empty_fol & ~sg_empty_upd);

//-----------------------------------------------------------------------------
// Clock processes for trace_mem_empty_sg and related signals
//-----------------------------------------------------------------------------
always @(posedge cxtmc_clk or negedge RESETn)
begin
  if (!RESETn)
    begin
      trace_mem_empty_sg <= 1'b0;
      sg_cbm_empty_fol <= 1'b0;
    end
  else
    begin
      trace_mem_empty_sg <=  nxt_trace_mem_empty_sg;
      sg_cbm_empty_fol <= nxt_sg_cbm_empty_fol;
    end
end

//-----------------------------------------------------------------------------
// Combine the empty status from scatter-gather operation and non-scatter-
// gather operation into a single status flag for the trace memory.
//-----------------------------------------------------------------------------
assign trace_mem_empty = (!ctl_trace_capt_en || ptr_clr) ? 1'b0 :
                         axictl_sg_mode ?
                           trace_mem_empty_sg :
                           trace_mem_empty_no_sg;

//-----------------------------------------------------------------------------
// Register the rwp_incr and rrp_incr signals to reduce load
//-----------------------------------------------------------------------------
always @(posedge cxtmc_clk or negedge RESETn)
  begin
    if (!RESETn)
      begin 
        rwp_incr_reg <= 1'b0;
        rrp_incr_reg <= 1'b0;
      end 
    else
      begin
        rwp_incr_reg <= rwp_incr;
        rrp_incr_reg <= rrp_incr;
      end
  end

//-----------------------------------------------------------------------------
// Current fill level
// If ctl_trace_capt_en is LOW or if trace capture has just been enabled 
// (ptr_clr asserted), then clear the fill level.
// On reads, decrement the fill level. On writes, increment the fill level.
//-----------------------------------------------------------------------------
assign c_buf_level_we = ctl_trace_capt_en_1_0 | rwp_incr_reg | rrp_incr_reg | 
                        ptr_clr;

always @*
  begin
    if (ctl_trace_capt_en & ~ptr_clr & ~axictl_sg_mode)
      case ({rwp_incr_reg, rrp_incr_reg})
        2'b00,  // No change in pointers
        2'b11 : // Both pointers increment, so fill level remains same
              begin
                 nxt_c_buf_level_reg = c_buf_level_reg;
              end
        2'b01 : // Read pointer increment
              begin
                 nxt_c_buf_level_reg = c_buf_level_reg - {{CXTMC_BUF_LEVEL_WIDTH-1{1'b0}},1'b1};
              end
        2'b10 : // Write pointer increment
              begin
                 nxt_c_buf_level_reg = c_buf_level_reg + {{CXTMC_BUF_LEVEL_WIDTH-1{1'b0}},1'b1};
              end
        default :
              begin
                 nxt_c_buf_level_reg = {CXTMC_BUF_LEVEL_WIDTH{1'bx}};
              end
      endcase
    else
      begin
         nxt_c_buf_level_reg = {CXTMC_BUF_LEVEL_WIDTH{1'b0}};
      end
  end

//-----------------------------------------------------------------------------
// Clocked process for c_buf_level
//-----------------------------------------------------------------------------
  always @(posedge cxtmc_clk or negedge RESETn)
  begin
    if (!RESETn)
        c_buf_level_reg   <= {CXTMC_BUF_LEVEL_WIDTH{1'b0}};
    else if (c_buf_level_we)
        c_buf_level_reg   <=  nxt_c_buf_level_reg;
  end

//-----------------------------------------------------------------------------
// In scatter-gather operation, CBUFLEVEL is 0
//-----------------------------------------------------------------------------
generate
  if (CXTMC_AXI_DATA_WIDTH == 32) 
    assign c_buf_level = axictl_sg_mode ? {CXTMC_FILL_LEVEL_WIDTH{1'b0}} :
                                          c_buf_level_reg;
  else
    assign c_buf_level = axictl_sg_mode ? {CXTMC_FILL_LEVEL_WIDTH{1'b0}} :
                           {c_buf_level_reg,{CXTMC_BUF_LEVEL_PAD{1'b0}}};
endgenerate

//-----------------------------------------------------------------------------
// Max buf level storage
// If ptr_clr is asserted, lat_buf_level is cleared because the pointers
// are cleared anyway. If the LBUFLEVEL register is read, then it is updated to 
// the current fill level. If there is a write to trace memory and the
// computed fill level is greater than the latched fill level, then 
// the latched fill level is updated to the computed fill level. 
//-----------------------------------------------------------------------------
assign  nxt_lat_buf_level_reg = (ptr_clr) ? {CXTMC_BUF_LEVEL_WIDTH{1'b0}} :
                            (ctl_trace_capt_en &&
                               ((lat_buf_level_rd_done &&
                                !lat_buf_level_upd_reg) ||
                                lat_buf_level_upd)) ?
                            nxt_c_buf_level_reg :
                            lat_buf_level_reg;

generate
  if (CXTMC_AXI_DATA_WIDTH == 32) 
    assign lat_buf_level = lat_buf_level_reg;
  else
    assign lat_buf_level = {lat_buf_level_reg,{CXTMC_BUF_LEVEL_PAD{1'b0}}};
endgenerate

assign lat_buf_level_upd = (rwp_incr_reg &
                           (nxt_c_buf_level_reg > lat_buf_level_reg));

assign lat_buf_level_we = ptr_clr | lat_buf_level_rd_done | rwp_incr_reg;

//-----------------------------------------------------------------------------
// Clocked processes for lat_buf_level
//-----------------------------------------------------------------------------
  always @(posedge cxtmc_clk or negedge RESETn)
  begin
    if (!RESETn)
      lat_buf_level_reg <= {CXTMC_BUF_LEVEL_WIDTH{1'b0}};
    else if (lat_buf_level_we)
      lat_buf_level_reg <=  nxt_lat_buf_level_reg;
  end

  always @(posedge cxtmc_clk or negedge RESETn)
  begin
    if (!RESETn)
      begin
        lat_buf_level_upd_reg <= 1'b0;
      end
    else
      begin
        lat_buf_level_upd_reg <= lat_buf_level_upd;
      end
  end

//----------------------------------------------------------------------------
// In scatter-gather operation, reads are initiated only if the trace memory
// has data for which write response has been received. Towards this, the
// fill level of the trace memory is computed for the specific 4kB block
// in which the rrp currently is. 
// 1. If rrp and rwp are on different 4kB blocks, then reads can proceed
//    till the top of the current 4kB block of rrp.
// 2. If rrp and rwp are on the same 4kB block and if they are equal,
//    the decision on whether to allow further reads depends on 
//    trace_mem_empty_sg. If trace_mem_empty_sg is not set, then it means the 
//    trace memory is full since the pointers are equal. Hence the fill level 
//    is set to 4kB correspoding to atleast one 4kB block. If 
//    trace_mem_empty_sg is set, it means the trace memory is empty, so the
//    fill level is set to 0.
// 3. If rrp and rwp are on the same 4kB block and if rwp > rrp, the fill level
//    is set to (rwp - rrp).
// 4. If rrp and rwp are on the same 4kB block and if rrp > rwp, the fill level
//    is set to correspond to the top of the current 4kB block of rrp.  
//----------------------------------------------------------------------------
assign trace_mem_fill_level_sg_rd = (rrp[CXTMC_MEM_BYTE_ADDR_WIDTH-1:12] !=
                                     rwp_p[CXTMC_MEM_BYTE_ADDR_WIDTH-1:12]) ? 
                                      ({1'b1, {10{1'b0}}} - {1'b0, rrp[11:2]}) :
                                    (rrp[11:2] == rwp_p[11:2]) ?
                                     (trace_mem_empty_sg ?
                                       {11{1'b0}} : {1'b1, {10{1'b0}}}) :
                                    (rwp_p[11:2] > rrp[11:2]) ?
                                     ({1'b0, rwp_p[11:2]} - {1'b0, rrp[11:2]}) :
                                     ({1'b1, {10{1'b0}}} - {1'b0, rrp[11:2]});

//----------------------------------------------------------------------------
// Reads can be initiated only if the corresponding writes to trace memory
// have received a response on the B channel. Those writes that have not
// received a response are conservatively assumed to have been initiated
// with a burst length equal to the programmed burst length (although the
// write burst length could have been lesser due to a 4KB boundary crossing
// or due to the top of the trace memory range being hit).
//----------------------------------------------------------------------------
assign trace_mem_empty_compl = axictl_sg_mode ?
                              (({{(CXTMC_FILL_LEVEL_WIDTH-11){1'b0}}, 
                                  trace_mem_fill_level_sg_rd} <= pend_level) | 
                                  trace_mem_empty_sg |
                                  sg_empty_pend) :
                                 (c_buf_level <= pend_level);

//----------------------------------------------------------------------------
// Reads are allowed only to those locations in trace memory to which
// writes have been acknowledged with an okay response on the B Channel.
// This is to ensure data coherency.
// The outstanding_wreq_cnt counter tracks the number of write bursts which 
// have not yet been acknowledged on the B Channel. Each of the outstanding
// writes could have been with any burst length based on several factors such
// as the programmed burst length, the depth of the write buffer, whether a 
// 4kB boundary crossing was encountered besides other factors. As an 
// approximation, all of the outstanding bursts are (pessimistically) assumed
// to be of axictl_wr_burst_len (which depends on the programmed burst
// length and the depth of the write buffer). Reads are allowed only if
// the fill level of the trace memory is greater than the computed level
// of outstanding writes.
// pend_level is expressed in terms of 32-bit words because it is compared 
// with c_buf_level which is in terms of 32-bit words.
//----------------------------------------------------------------------------
generate 
  if (CXTMC_AXI_DATA_WIDTH == 32)
    always @*
    begin
      case (axictl_wr_burst_len) 
        4'b0000 : pend_level = {{(CXTMC_FILL_LEVEL_WIDTH-6){1'b0}}, 
                                 outstanding_wreq_cnt};
        4'b0001 : pend_level = {{(CXTMC_FILL_LEVEL_WIDTH-7){1'b0}}, 
                                 outstanding_wreq_cnt, 1'b0}; 
    
        4'b0010,
        4'b0011 : pend_level = {{(CXTMC_FILL_LEVEL_WIDTH-8){1'b0}}, 
                                 outstanding_wreq_cnt, {2{1'b0}}}; 
    
        4'b0100,
        4'b0101,
        4'b0110,
        4'b0111 : pend_level = {{(CXTMC_FILL_LEVEL_WIDTH-9){1'b0}}, 
                                 outstanding_wreq_cnt, {3{1'b0}}}; 
    
        4'b1000,
        4'b1001,
        4'b1010,
        4'b1011,
        4'b1100,
        4'b1101,
        4'b1110,
        4'b1111 : pend_level = {{(CXTMC_FILL_LEVEL_WIDTH-10){1'b0}},
                                 outstanding_wreq_cnt, {4{1'b0}}}; 
        default :
                  pend_level = {CXTMC_FILL_LEVEL_WIDTH{1'bx}};
      endcase
    end
  else if (CXTMC_AXI_DATA_WIDTH == 64)
    always @*
    begin
      case (axictl_wr_burst_len) 
        4'b0000 : pend_level = {{(CXTMC_FILL_LEVEL_WIDTH-7){1'b0}}, 
                                 outstanding_wreq_cnt, 1'b0};
        4'b0001 : pend_level = {{(CXTMC_FILL_LEVEL_WIDTH-8){1'b0}}, 
                                 outstanding_wreq_cnt, 2'b00}; 
    
        4'b0010,
        4'b0011 : pend_level = {{(CXTMC_FILL_LEVEL_WIDTH-9){1'b0}}, 
                                 outstanding_wreq_cnt, {3{1'b0}}}; 
    
        4'b0100,
        4'b0101,
        4'b0110,
        4'b0111 : pend_level = {{(CXTMC_FILL_LEVEL_WIDTH-10){1'b0}}, 
                                 outstanding_wreq_cnt, {4{1'b0}}}; 
    
        4'b1000,
        4'b1001,
        4'b1010,
        4'b1011,
        4'b1100,
        4'b1101,
        4'b1110,
        4'b1111 : pend_level = {{(CXTMC_FILL_LEVEL_WIDTH-11){1'b0}},
                                 outstanding_wreq_cnt, {5{1'b0}}}; 
        default :
                  pend_level = {CXTMC_FILL_LEVEL_WIDTH{1'bx}};
      endcase
    end
  else // (CXTMC_AXI_DATA_WIDTH == 128)
    always @*
    begin
      case (axictl_wr_burst_len) 
        4'b0000 : pend_level = {{(CXTMC_FILL_LEVEL_WIDTH-8){1'b0}}, 
                                 outstanding_wreq_cnt, 2'b00};
        4'b0001 : pend_level = {{(CXTMC_FILL_LEVEL_WIDTH-9){1'b0}}, 
                                 outstanding_wreq_cnt, 3'b000}; 
    
        4'b0010,
        4'b0011 : pend_level = {{(CXTMC_FILL_LEVEL_WIDTH-10){1'b0}}, 
                                 outstanding_wreq_cnt, {4{1'b0}}}; 
    
        4'b0100,
        4'b0101,
        4'b0110,
        4'b0111 : pend_level = {{(CXTMC_FILL_LEVEL_WIDTH-11){1'b0}}, 
                                 outstanding_wreq_cnt, {5{1'b0}}}; 
    
        4'b1000,
        4'b1001,
        4'b1010,
        4'b1011,
        4'b1100,
        4'b1101,
        4'b1110,
        4'b1111 : pend_level = {{(CXTMC_FILL_LEVEL_WIDTH-12){1'b0}},
                                 outstanding_wreq_cnt, {6{1'b0}}}; 
        default :
                  pend_level = {CXTMC_FILL_LEVEL_WIDTH{1'bx}};
      endcase
    end
endgenerate
    
//----------------------------------------------------------------------------
// Memory flush logic.
// If a Memory Flush request is asserted, store the current number of
// outstanding writes. Once there have been responses on the B Channel for 
// this number of writes, mem_flush_ack is asserted. This ensures that write of
// all flushed data has been acknowledged on the B Channel. 
//----------------------------------------------------------------------------
assign nxt_fl_outstanding_wreq_cnt = mem_err ?
                                       6'b000000 :
                                     fl_wreq_cnt_load_en ?
                                       fl_wreq_cnt_load_val :
                                     fl_wreq_cnt_decr ?
                                       (fl_outstanding_wreq_cnt - 6'b000001) :
                                       fl_outstanding_wreq_cnt;

assign fl_wreq_cnt_load_en = (wb_flush_req & wb_flush_ack & ~wr_skid_buf_full) |
                             (mem_flush_req & skid_fl_pend & ~wr_skid_buf_full);

assign fl_wreq_cnt_decr = bvalidm_reg & (|fl_outstanding_wreq_cnt);

assign fl_wreq_cnt_load_val = (bvalidm_reg  && !outstanding_wreq_cnt_eq0 &&
                               !new_write_xfer_reg) ? 
                                (outstanding_wreq_cnt - 6'b000001) :
                                (outstanding_wreq_cnt);
                                
assign fl_outstanding_wreq_cnt_we = (wb_flush_req & wb_flush_ack) | 
                                    bvalidm_reg | mem_err |
                                    (skid_fl_pend & ~wr_skid_buf_full);

//----------------------------------------------------------------------------
// Clocked process for fl_outstanding_wreq_cnt 
//----------------------------------------------------------------------------
always @(posedge cxtmc_clk or negedge RESETn)
  begin : p_fl_outstnd
    if (!RESETn)
      fl_outstanding_wreq_cnt <= 6'b000000;
    else if (fl_outstanding_wreq_cnt_we)
      fl_outstanding_wreq_cnt <= nxt_fl_outstanding_wreq_cnt;
  end // p_fl_outstnd

//----------------------------------------------------------------------------
// If a flush request has resulted in data being written into the skid buffer,
// ensure that the skid buffer is flushed before starting to count for 
// responses on the B Channel. The completion of write buffer flush is used
// in this logic because of dependencies between write buffer flush completion
// and the assertion of memory flush request.
//----------------------------------------------------------------------------
assign nxt_skid_fl_pend = (wb_flush_req & wb_flush_ack & wr_skid_buf_full) |
                          (skid_fl_pend & wr_skid_buf_full); 

//----------------------------------------------------------------------------
// Acknowledge memory flush when the fl_outstanding_wreq_cnt counter has
// counted down to 0. This ensures that all data that was written as part of
// the flush operation has been acknowledged with a response on the B channel.
//----------------------------------------------------------------------------
assign nxt_mem_flush_ack = mem_flush_req & ~mem_flush_ack & ~skid_fl_pend &
                           ~|(fl_outstanding_wreq_cnt);  

//----------------------------------------------------------------------------
// Clocked process for mem_flush_ack and skid_fl_pend
//----------------------------------------------------------------------------
always @(posedge cxtmc_clk or negedge RESETn)
  begin : p_mem_fl_ack
    if (!RESETn)
      begin
        mem_flush_ack <= 1'b0;
        skid_fl_pend  <= 1'b0;
      end
    else
      begin
        mem_flush_ack <= nxt_mem_flush_ack;
        skid_fl_pend  <= nxt_skid_fl_pend;
      end
  end // p_mem_fl_ack

//----------------------------------------------------------------------------
// Decrement logic for PSCR counter
//----------------------------------------------------------------------------
assign axi_w_ch_beat_done = wvalidm_reg & wreadym_reg;

  always @(posedge cxtmc_clk or negedge RESETn)
  begin
    if (!RESETn)
      begin
        wvalidm_reg <= 1'b0;
        wreadym_reg <= 1'b0;
      end
    else
      begin
        wvalidm_reg <= WVALIDM;
        wreadym_reg <= WREADYM;
      end
  end

//----------------------------------------------------------------------------
// AXI Low power interface output.
// When CSYSREQ is asserted, wait for any pending AXI transfers to complete
// before issuing CSYSACK. 
//----------------------------------------------------------------------------
assign axi_intf_pend = write_in_prog | read_in_prog | pt_read_in_prog | 
                       ~outstanding_wreq_cnt_eq0;

//----------------------------------------------------------------------------
// ASSERTIONS
//----------------------------------------------------------------------------
`ifdef ARM_ASSERT_ON

   assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxtmc_axi_if - Number of outstanding write requests must not be greater than 32")
      uzovl_cxtmc_axi_if_wreq_cnt
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   (outstanding_wreq_cnt > 6'b100000)
        );

// RSZ must not exceed 4GB
   assert_never #(`OVL_WARNING, `OVL_ASSERT,
   "OVL Message : cxtmc_axi_if - Trace buffer size must not exceed 4GB")
      uzovl_cxtmc_axi_if_4GB_chk
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   (ctl_trace_capt_en && (rsz_masked > 31'h40000000))
        );

// Check for invalid parameter combination - CXTMC_WB_DATA_WIDTH vs 
// CXTMC_AXI_DATA_WIDTH
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxtmc_axi_if - In the ETR configuration, CXTMC_WB_DATA_WIDTH must be the same as CXTMC_AXI_DATA_WIDTH")
      uzovl_cxtmc_param_chk_wbuf_axi
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   (CXTMC_AXI_DATA_WIDTH != CXTMC_WB_DATA_WIDTH)
        );

// In the ETR configuration, when the counter for outstanding write requests is
// 0, there must not be any write accesses in progress
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxtmc_axi_if - In the ETR configuration, when the counter for outstanding write requests is 0, there must not be any write accesses in progress")
      uzovl_cxtmc_os_wreq_cnt_write_prog
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   ((outstanding_wreq_cnt == 6'b000000) & 
                       WVALIDM & ~mem_err)
        );

// pt_rd_en and mem_rd_en are one hot
  assert_zero_one_hot #(`OVL_ERROR, 2, `OVL_ASSERT,
    "OVL Message : cxtmc_axi_if - pt_rd_en and mem_rd_en must not be both asserted at the same time")
      uzovl_cxtmc_axi_if_pt_mem_rd
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   ({pt_rd_en, mem_rd_en})
        );

// If trace capture is enabled, APB write accesses to RRP are not expected 
   assert_never #(`OVL_WARNING, `OVL_ASSERT,
   "OVL Message : cxtmc_axi_if - APB write accesses to RRP are not allowed when trace capture is enabled")
      uzovl_cxtmc_axi_if_rrp
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   (ctl_trace_capt_en & rrp_wr_en)
        );

// If trace capture is enabled, APB write accesses to RWP are not expected 
   assert_never #(`OVL_WARNING, `OVL_ASSERT,
   "OVL Message : cxtmc_axi_if - APB write accesses to RWP are not allowed when trace capture is enabled")
      uzovl_cxtmc_axi_if_rwp
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   (ctl_trace_capt_en & rwp_wr_en)
        );

// Once Flush request is asserted, it must not be de-asserted before flush ack 
// is asserted
  reg mem_flush_req_reg;
  reg mem_flush_ack_reg;

  always @(posedge cxtmc_clk or negedge RESETn)
  begin
    if (!RESETn)
      begin
        mem_flush_req_reg <= 1'b0;
        mem_flush_ack_reg <= 1'b0;
      end
    else
      begin
        mem_flush_req_reg <= mem_flush_req;
        mem_flush_ack_reg <= mem_flush_ack;
      end
  end

   assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxtmc_axi_if - Once Flush request is asserted, it must not be de-asserted before flush ack is asserted")
      uzovl_cxtmc_axi_if_flush_req_ack
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   (~mem_flush_req & mem_flush_req_reg & ~mem_flush_ack_reg)
        );

// In non-Scatter-Gather operation, the pointers must always stay within the 
// address boundaries of the trace buffer programmed in the DBA_LO/HI registers
   assert_never #(`OVL_WARNING, `OVL_ASSERT,
   "OVL Message : cxtmc_axi_if - When the TMC is enabled, the write pointer must always stay within the address boundaries of the trace buffer")
      uzovl_cxtmc_axi_if_rwp_dba
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   (~tmc_disabled & ~ptr_clr & ~axictl_sg_mode &
                      ((rwp > {dba_max, {CXTMC_PTR_PAD{1'b0}}}) || 
                       (rwp < dba_min_byte_addr)))
        );

// When the TMC is enabled, the read pointer must always stay within the 
// address boundaries of the trace buffer
   assert_never #(`OVL_WARNING, `OVL_ASSERT,
   "OVL Message : cxtmc_axi_if - When the TMC is enabled, the read pointer must always stay within the address boundaries of the trace buffer")
      uzovl_cxtmc_axi_if_rrp_dba
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   (~tmc_disabled & ~ptr_clr & ~axictl_sg_mode &
                      ((rrp > {dba_max, {CXTMC_PTR_PAD{1'b0}}}) || 
                       (rrp < dba_min_byte_addr)))
        );

// pt_addr must be stable when pt_valid is high
reg pt_hold_chk;  // Set for the duration in which pt_valid and pt_addr
                  //   are expected to retain their values
reg pt_valid_reg; // Delayed version of pt_valid
reg [39:0] pt_addr_reg; // Delayed version of pt_addr
wire nxt_pt_hold_chk; // D-input of pt_hold_chk

assign nxt_pt_hold_chk = (pt_valid & ~pt_ready & ~mem_err) |
                         (pt_hold_chk & ~(pt_ready | mem_err));

  always @(posedge cxtmc_clk or negedge RESETn)
  begin
    if (!RESETn)
      begin
        pt_hold_chk  <= 1'b0;
        pt_valid_reg <= 1'b0;
        pt_addr_reg  <= {40{1'b0}};
      end
    else
      begin
        pt_hold_chk  <= nxt_pt_hold_chk;
        pt_valid_reg <= pt_valid;
        pt_addr_reg  <= pt_addr;
      end
  end

// pt_valid once asserted must not change until acknowledged by pt_ready
   assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxtmc_axi_if - pt_valid once asserted must not change until acknowledged by pt_ready")
      uzovl_cxtmc_axi_if_pt_valid
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   (pt_hold_chk & ~pt_valid & ~mem_err)
        );

// pt_addr must not change when pt_valid is high until acknowledged by pt_ready
   assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxtmc_axi_if - pt_addr must not change when pt_valid is high until acknowledged by pt_ready")
      uzovl_cxtmc_axi_if_pt_addr
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn), 
         .test_expr   (pt_hold_chk & (pt_addr_reg != pt_addr))
        );

// c_buf_level can never be greater than RSZ value in non-SG mode
   assert_never #(`OVL_WARNING, `OVL_ASSERT,
   "OVL Message : cxtmc_axi_if - CBUFLEVEL cannot be greater than RSZ in ETR configuration")
      uzovl_cxtmc_axi_if_c_buf_lvl
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   ((c_buf_level > rsz_masked) && ~axictl_sg_mode)
        );

// pt_addr must be aligned to a 32-bit address boundary
   assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxtmc_axi_if - pt_addr[1:0] must always be 2'b00 to align to a 32-bit address boundary")
      uzovl_cxtmc_axi_if_pt_addr_bits_01
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   (pt_valid & (pt_addr[1:0] != 2'b00))
        );

// rrp_incr must not occur if trace memory is empty
   assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxtmc_axi_if - rrp_incr must not occur when trace memory is empty because the read must not have been issued when the trace memory is empty.")
      uzovl_cxtmc_axi_if_rrp_incr
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   (rrp_incr & trace_mem_empty)
        );

// When wcnt is 0, the decrement condition must not occur
   assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxtmc_axi_if - wcnt counter has wrapped around below 0.")
      uzovl_cxtmc_axi_if_wcnt
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   ((wcnt == {WCNT_WIDTH{1'b0}}) & 
                       WVALIDM & WREADYM & ~WLASTM)
        );

// When outstanding_wreq_cnt is 6'b10_0000, the increment condition must not 
// occur
   assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxtmc_axi_if - outstanding_wreq_cnt counter has incremented beyond 32.")
      uzovl_cxtmc_axi_os_cnt_max
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   ((outstanding_wreq_cnt == 6'b100000) & new_write_xfer &
                       ~bvalidm_reg & ~mem_err)
        );

// When outstanding_wreq_cnt is 6'b00_0000, the decrement condition must not 
// occur
   assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxtmc_axi_if - outstanding_wreq_cnt counter has wrapped around 0. BVALIDM detected in the absence of an outstanding write transfer")
      uzovl_cxtmc_axi_os_cnt_min
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   ((outstanding_wreq_cnt == 6'b000000) & ~new_write_xfer &
                        bvalidm_reg & ~mem_err)
        );

// When the TMC is disabled, read and write requests cannot occur at the
// same time
   assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxtmc_axi_if - When the TMC is disabled, read and write requests cannot occur at the same time")
      uzovl_cxtmc_axi_rd_wr
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   (tmc_disabled & mem_rd_en & wb_req_valid)
        );

// If wb_req_valid is asserted, write buffer must have some data
   assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxtmc_axi_if - If wb_req_valid is asserted, write buffer must have some data")
      uzovl_cxtmc_axi_if_wb_chk
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   ((wb_req_valid && 
                       (wb_fill_level == {(CXTMC_WB_PTR_WIDTH+1){1'b0}})) ||
                       ((~wb_req_valid) &&
                       (wb_fill_level != {(CXTMC_WB_PTR_WIDTH+1){1'b0}})))
        );

reg awvalidm_reg; // Delayed version of AWVALIDM
reg arvalidm_reg; // Delayed version of ARVALIDM
reg dbgen_reg_2; // DBGEN delayed by 2 cycles
reg spiden_reg_2; // SPIDEN delayed by 2 cycles

  always @(posedge cxtmc_clk or negedge RESETn)
  begin
    if (!RESETn)
      begin
        awvalidm_reg  <= 1'b0;
        arvalidm_reg  <= 1'b0;
        dbgen_reg_2   <= 1'b0;
        spiden_reg_2  <= 1'b0;
      end
    else
      begin
        awvalidm_reg  <= AWVALIDM;
        arvalidm_reg  <= ARVALIDM;
        dbgen_reg_2   <= dbgen_reg;
        spiden_reg_2  <= spiden_reg;
      end
  end

// When DBGEN is LOW (plus 2 cycles), AWVALID, WVALID and ARVALID must never go 
// high (Debug disabled)
   assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxtmc_axi_if - If DBGEN is LOW (plus 2 cycles), AWVALID, WVALID and ARVALID must never go high.")
      uzovl_cxtmc_axi_if_dbgen_chk
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   (~dbgen_reg_2 &&
                       ((AWVALIDM && (~awvalidm_reg)) || 
                        (WVALIDM && (~wvalidm_reg)) || 
                        (ARVALIDM && (~arvalidm_reg))))
        );

// When SPIDEN is LOW (plus 2 cycles), AWVALID, WVALID and ARVALID never go high
// with AxPROT[1] LOW.
   assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxtmc_axi_if - When SPIDEN is LOW (plus 1 cycle), AWVALID and ARVALID never go high with AxPROT[1] LOW.")
      uzovl_cxtmc_axi_if_spiden_chk
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   ((~spiden_reg_2) &&
                       ((AWVALIDM && (~awvalidm_reg) && (~AWPROTM[1])) || 
                        (ARVALIDM && (~arvalidm_reg) && (~ARPROTM[1]))))
        );

// In Scatter-Gather mode, if a 4KB area has been written, there must be a
// load of the next address onto the write pointer before the next write
// access is initiated. This is to ensure that unallocated system memory is not
// corrupted.
wire nxt_sg_rwp_reload_exp; // D-input of sg_rwp_reload_exp
reg  sg_rwp_reload_exp;     // Remember the fact that a 4KB window has been
                            // completely written

assign nxt_sg_rwp_reload_exp = (ptr_clr | (new_write_xfer_reg & 
                               (AWADDRM[11:CXTMC_PTR_PAD] +  
                                 {{(12-CXTMC_PTR_PAD-4){1'b0}}, AWLENM} ==
                                 {(12-CXTMC_PTR_PAD){1'b1}}))) |
                               (sg_rwp_reload_exp & 
                                 ~(dba_w_valid & dba_w_ready));

  always @(posedge cxtmc_clk or negedge RESETn)
  begin : p_sg_rwp_reload_exp
    if (!RESETn)
      begin
        sg_rwp_reload_exp <= 1'b1;
      end
    else
      begin
        sg_rwp_reload_exp <= nxt_sg_rwp_reload_exp;
      end
  end // block: p_sg_rwp_reload_exp

   assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxtmc_axi_if - In Scatter-Gather mode, if a 4KB area has been written, there must be a load of the next address onto the write pointer before the next write access is initiated.")
      uzovl_cxtmc_axi_if_sg_rwp_reload
        (                   
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   (new_write_xfer_reg && sg_rwp_reload_exp && 
                       axictl_sg_mode)
        );                       

reg axictl_sg_mode_reg; // Delayed version of axictl_sg_mode
  always @(posedge cxtmc_clk or negedge RESETn)
  begin : p_sg_del
    if (!RESETn)
      begin
        axictl_sg_mode_reg <= 1'b0;
      end
    else
      begin
        axictl_sg_mode_reg <= axictl_sg_mode;
      end
  end // block: p_sg_del

   assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxtmc_axi_if - dba_r_valid must be asserted by the Scatter-Gather block only in Scatter-Gather mode.")
      uzovl_cxtmc_axi_if_sg_dba_r_valid
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   (dba_r_valid && (!axictl_sg_mode) && (!axictl_sg_mode_reg))
        );

   assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxtmc_axi_if - dba_w_valid must be asserted by the Scatter-Gather block only in Scatter-Gather mode.")
      uzovl_cxtmc_axi_if_sg_dba_w_valid
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   (dba_w_valid && (!axictl_sg_mode) && (!axictl_sg_mode_reg))
        );

  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : Reload of pointers with address from scater-gather block does not occur in non-scatter-gather operation.")
      uzovl_cxtmc_axi_if_auto_3
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   ({axictl_sg_mode,dba_w_valid,dba_w_ready} == {1'b0,1'b1,1'b1})
        );
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : Reload of pointers with address from scater-gather block does not occur in non-scatter-gather operation.")
      uzovl_cxtmc_axi_if_auto_4
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   ({axictl_sg_mode,dba_r_valid,dba_r_ready} == {1'b0,1'b1,1'b1})
        );

  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : When trace capture is enabled, there must not be any data from past transfers in the skid buffer.")
      uzovl_cxtmc_axi_if_skid_ptr_clr
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   (ptr_clr && wr_skid_buf_full)
        );

  assert_never #(`OVL_WARNING, `OVL_ASSERT,
   "OVL Message : In ETR config, there cannot be a write ptr increment without a simultaneous read ptr increment when the CBUFLEVEL register is equal to the max value.")
      uzovl_cxtmc_axi_if_cbuf
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   ((c_buf_level == rsz_masked) && rwp_incr_reg &&
                       !rrp_incr_reg && ctl_trace_capt_en && !axictl_sg_mode)
        );

  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : The sg_empty_upd signal cannot occur simultaneously with rwp_incr and rrp_incr.")
      uzovl_cxtmc_axi_if_sg_empty_upd
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   (rwp_incr && rrp_incr && sg_empty_upd && axictl_sg_mode)
        );

  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : The ptr_clr signal cannot occur simultaneously with new_write_xfer.")
      uzovl_cxtmc_axi_if_ptr_clr
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   (new_write_xfer && ptr_clr)
        );

// In Scatter-Gather operation, RWP crossed a 4KB boundary when the RRP was
// awaiting an update from the scatter-gather block. This condition can occur
// only in circular buffer mode. 
reg rwp_mod;

// D-input of rwp_mod
wire nxt_rwp_mod;

assign nxt_rwp_mod = (~rrp_valid & dba_w_valid & dba_w_ready & sg_empty_pend &
                      ~circ_buf_mode) |
                        (rwp_mod & ~sg_empty_upd);

//-----------------------------------------------------------------------------
// Clock processes for rwp_mod
//-----------------------------------------------------------------------------
always @(posedge cxtmc_clk or negedge RESETn)
begin
  if (!RESETn)
    begin
      rwp_mod <= 1'b0;
    end
  else
    begin
      rwp_mod <= nxt_rwp_mod;
    end
end

   assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxtmc_axi_if - In scatter-gather operation SWF mode, when the read pointer awaits an updated address from the SG block, the Write pointer must not cross the same 4KB boundary.")
      uzovl_cxtmc_axi_if_sg_empty
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   (rwp_mod && axictl_sg_mode && sg_empty_upd &&
                       rwp_eq_rrp)
        );

  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : The ptr_clr signal cannot occur simultaneously with pt_valid.") 
      uzovl_cxtmc_axi_if_ptr_clr_pt_init
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   (pt_valid && ptr_clr)
        );

  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : The ptr_clr signal cannot occur simultaneously with rb_req_valid.") 
      uzovl_cxtmc_axi_if_ptr_clr_mem_rd_init
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   (rb_req_valid && ptr_clr)
        );

`endif

endmodule // cxtmc_axi_if
