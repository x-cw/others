//-----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2003-2013 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//    Checked In : $Date: 2013-09-18 19:08:03 +0100 (Wed, 18 Sep 2013) $
//    Revision   : $Revision: 37434 $
//    Release    : CoreSight-SoC-TM100-r3p1-00rel0
//
//----------------------------------------------------------------------------
//      Purpose             : ECT Register Module for CTI Clock domain
// --=========================================================================--
`include "cxcti_constants.v"

module cxcti_reg_c
  (
  // Inputs
  cticlk, cticlken, ctiresetn, ctiapbsbypass, paddrdbg, pwritedbg,
  pwdatadbg, ct_req, paddrdbg31, device_un_locked, reg_trig_in_status,
  reg_trig_out_status, reg_ch_in_status, reg_ch_out_status, internal_niden,
  dbgen_sync_2, itchout_ack_r_data, it_trigout_ack_r_data, itchin_r_data,
  it_trigin_r_data,
  // Outputs
  ctack, ct_rdata, ctiinen0, ctiouten0, ctiinen1, ctiouten1, ctiinen2,
  ctiouten2, ctiinen3, ctiouten3, ctiinen4, ctiouten4, ctiinen5,
  ctiouten5, ctiinen6, ctiouten6, ctiinen7, ctiouten7, app_trigger,
  cti_int_ack, cti_control, ch_out_enable, asicctl, iten, itchin_ack_en,
  it_triginack_en, itch_out_en, it_trigout_en
  );





  // ---------------------------------------------------------------------------
  // INPUTS AND OUTPUTS
  // ---------------------------------------------------------------------------

  // System controls
  input                               cticlk;           // Clock
  input                               cticlken;         // Clock Enable
  input                               ctiresetn;        // Reset
  // Synchronisation bypass control
  input                               ctiapbsbypass;    // Bypass for APB interface

  // Memory access controls (APB)
  input [11:2]                        paddrdbg;         // Address[9:0]
  input                               pwritedbg;        // Write (1=write, 0=read)
  input [7:0]                         pwdatadbg;        // Write data
  input                               ct_req;            // Request input
  input                               paddrdbg31;       // bypass lock access
  input                               device_un_locked;   // Allow Writes on ~paddrdbg31

  input [CSSOC_ECTTRIGGERWIDTH-1:0]  reg_trig_in_status;  // From Trigger in Register
  input [CSSOC_ECTTRIGGERWIDTH-1:0]  reg_trig_out_status; // From Trigger out Register
  input [CSSOC_ECTCHANNELWIDTH-1:0]  reg_ch_in_status;    // From Channel in Register
  input [CSSOC_ECTCHANNELWIDTH-1:0]  reg_ch_out_status;   // From Channel out Register

  // Security levels for Authentication Register
  input                               internal_niden;    // OR of niden, dbgen
  input                               dbgen_sync_2;       // dbgen

  // APB access outputs
  output                              ctack;            // Ack to APB interface
  output [7:0]                        ct_rdata;                         // read data to APB interface

  output [CSSOC_ECTCHANNELWIDTH-1:0] ctiinen0;         // Trig 2 Chan mapping enable
  output [CSSOC_ECTCHANNELWIDTH-1:0] ctiouten0;        // Chan 2 Trig mapping enable

  output [CSSOC_ECTCHANNELWIDTH-1:0] ctiinen1;         // Trig 2 Chan mapping enable
  output [CSSOC_ECTCHANNELWIDTH-1:0] ctiouten1;        // Chan 2 Trig mapping enable

  output [CSSOC_ECTCHANNELWIDTH-1:0] ctiinen2;         // Trig 2 Chan mapping enable
  output [CSSOC_ECTCHANNELWIDTH-1:0] ctiouten2;        // Chan 2 Trig mapping enable

  output [CSSOC_ECTCHANNELWIDTH-1:0] ctiinen3;         // Trig 2 Chan mapping enable
  output [CSSOC_ECTCHANNELWIDTH-1:0] ctiouten3;        // Chan 2 Trig mapping enable

  output [CSSOC_ECTCHANNELWIDTH-1:0] ctiinen4;         // Trig 2 Chan mapping enable
  output [CSSOC_ECTCHANNELWIDTH-1:0] ctiouten4;        // Chan 2 Trig mapping enable

  output [CSSOC_ECTCHANNELWIDTH-1:0] ctiinen5;         // Trig 2 Chan mapping enable
  output [CSSOC_ECTCHANNELWIDTH-1:0] ctiouten5;        // Chan 2 Trig mapping enable

  output [CSSOC_ECTCHANNELWIDTH-1:0] ctiinen6;         // Trig 2 Chan mapping enable
  output [CSSOC_ECTCHANNELWIDTH-1:0] ctiouten6;        // Chan 2 Trig mapping enable

  output [CSSOC_ECTCHANNELWIDTH-1:0] ctiinen7;         // Trig 2 Chan mapping enable
  output [CSSOC_ECTCHANNELWIDTH-1:0] ctiouten7;        // Chan 2 Trig mapping enable


  output [CSSOC_ECTCHANNELWIDTH-1:0] app_trigger;       // Application trigger output

  output [CSSOC_ECTTRIGGERWIDTH-1:0] cti_int_ack;        // Trigger out sw clear

  output                              cti_control;       // global enable

  output [CSSOC_ECTCHANNELWIDTH-1:0] ch_out_enable;     // Channel Out Enable
  output [7:0]                        asicctl;         // ASIC Control output


  // Integration registers signals
  output                              iten;             // Integration test enable
  output                              itchin_ack_en;      // Int.Reg ChInAck enable
  output                              it_triginack_en;    // Int.Reg TrigInAck enable
  output                              itch_out_en;        // Int.Reg ChOut enable
  output                              it_trigout_en;      // Int.Reg TrigOut enable

  input [CSSOC_ECTCHANNELWIDTH-1:0]  itchout_ack_r_data;  // Int.Reg ChOutAck data
  input [CSSOC_ECTTRIGGERWIDTH-1:0]  it_trigout_ack_r_data;// Int.Reg TrigOutAck data
  input [CSSOC_ECTCHANNELWIDTH-1:0]  itchin_r_data;      // Int.Reg ChIn data
  input [CSSOC_ECTTRIGGERWIDTH-1:0]  it_trigin_r_data;    // Int.Reg TrigIn data

  //----------------------------------------------------------------------------
  // WIRES AND REGS
  //----------------------------------------------------------------------------
  reg                                 reg_ctiapbsbypass;
  wire                                ct_req_sync_2;
  wire                                ct_req_synced;
  wire                                nxt_last_apb_req;
  reg                                 last_apb_req;
  wire                                nxt_apb_action;
  reg                                 apb_action;
  wire                                ctack_n;
  wire                                apb_action_clk_en;
  wire                                reg_ct_ack;
  reg                                 regctack_cdc_check;
  wire                                sample_ctrl;
  reg [9:0]                           ct_addr_q;
  reg                                 ct_write_q;
  reg [CSSOC_ECTTRIGGERWIDTH-1:0]    ct_w_data_q;
  wire [9:0]                          rb_addr;
  wire                                rb_write;
  wire [CSSOC_ECTTRIGGERWIDTH-1:0]   rb_wdata;
  wire                                write_accept;
  wire                                read_accept;
  reg                                 reg_cti_control;
  reg [CSSOC_ECTCHANNELWIDTH-1:0]    reg_cti_app_trig;
  wire [CSSOC_ECTCHANNELWIDTH-1:0]   nxt_cti_app_trig;
  reg [CSSOC_ECTCHANNELWIDTH-1:0]    reg_cti_app_pulse;
  reg [CSSOC_ECTCHANNELWIDTH-1:0]    reg_cti_in_en_0;
  reg [CSSOC_ECTCHANNELWIDTH-1:0]    reg_cti_out_en_0;
  reg [CSSOC_ECTCHANNELWIDTH-1:0]    reg_cti_in_en_1;
  reg [CSSOC_ECTCHANNELWIDTH-1:0]    reg_cti_out_en_1;
  reg [CSSOC_ECTCHANNELWIDTH-1:0]    reg_cti_in_en_2;
  reg [CSSOC_ECTCHANNELWIDTH-1:0]    reg_cti_out_en_2;
  reg [CSSOC_ECTCHANNELWIDTH-1:0]    reg_cti_in_en_3;
  reg [CSSOC_ECTCHANNELWIDTH-1:0]    reg_cti_out_en_3;
  reg [CSSOC_ECTCHANNELWIDTH-1:0]    reg_cti_in_en_4;
  reg [CSSOC_ECTCHANNELWIDTH-1:0]    reg_cti_out_en_4;
  reg [CSSOC_ECTCHANNELWIDTH-1:0]    reg_cti_in_en_5;
  reg [CSSOC_ECTCHANNELWIDTH-1:0]    reg_cti_out_en_5;
  reg [CSSOC_ECTCHANNELWIDTH-1:0]    reg_cti_in_en_6;
  reg [CSSOC_ECTCHANNELWIDTH-1:0]    reg_cti_out_en_6;
  reg [CSSOC_ECTCHANNELWIDTH-1:0]    reg_cti_in_en_7;
  reg [CSSOC_ECTCHANNELWIDTH-1:0]    reg_cti_out_en_7;
  wire [CSSOC_ECTTRIGGERWIDTH-1:0]   nxt_r_data;
  reg [CSSOC_ECTTRIGGERWIDTH-1:0]    reg_r_data;
  wire                                reg_cti_control_en;
  wire                                write_app_set;
  wire                                write_app_clr;
  wire                                reg_cti_app_trig_en;
  wire                                cti_app_pulse_en;
  wire [CSSOC_ECTCHANNELWIDTH-1:0]   nxt_cti_app_pulse;
  wire                                itcontrol_en;
  reg                                 itcontrol;
  wire                                itchin_ack_en;
  wire                                it_triginack_en;
  wire                                itch_out_en;
  wire                                it_trigout_en;
  wire                                cti_in_en_0_en;
  wire                                cti_out_en_0_en;
  wire                                cti_in_en_1_en;
  wire                                cti_out_en_1_en;
  wire                                cti_in_en_2_en;
  wire                                cti_out_en_2_en;
  wire                                cti_in_en_3_en;
  wire                                cti_out_en_3_en;
  wire                                cti_in_en_4_en;
  wire                                cti_out_en_4_en;
  wire                                cti_in_en_5_en;
  wire                                cti_out_en_5_en;
  wire                                cti_in_en_6_en;
  wire                                cti_out_en_6_en;
  wire                                cti_in_en_7_en;
  wire                                cti_out_en_7_en;
  wire                                read_control;
  wire                                read_appset;
  wire                                read_in_en_0;
  wire                                read_out_en_0;
  wire                                read_in_en_1;
  wire                                read_out_en_1;
  wire                                read_in_en_2;
  wire                                read_out_en_2;
  wire                                read_in_en_3;
  wire                                read_out_en_3;
  wire                                read_in_en_4;
  wire                                read_out_en_4;
  wire                                read_in_en_5;
  wire                                read_out_en_5;
  wire                                read_in_en_6;
  wire                                read_out_en_6;
  wire                                read_in_en_7;
  wire                                read_out_en_7;
  wire                                read_trigin_status;
  wire                                read_trigout_status;
  wire                                read_chin_status;
  wire                                read_chout_status;
  wire                                read_itcontrol;
  wire                                read_itch_out_ack;
  wire                                read_it_trigoutack;
  wire                                read_itchin;
  wire                                read_it_trigin;

  wire                                channel_gate_en;
  wire [CSSOC_ECTCHANNELWIDTH-1:0]   new_channel_gate;
  reg [CSSOC_ECTCHANNELWIDTH-1:0]    channel_gate;
  wire                                channel_gate_read;
  wire [CSSOC_ECTCHANNELWIDTH-1:0]   ch_out_enable;

  wire                                asicctl_en;
  wire [7:0]                          new_asicctl;
  wire [7:0]                          asicctl;
  reg [7:0]                           asicctl_reg;
  wire                                asicctl_read;

  wire                                authstatus_read;
  wire [7:0]                          authstatus_r_data;

  //----------------------------------------------------------------------------
  //
  // MAIN CODE
  //
  //----------------------------------------------------------------------------


  // Register bypass control signals
  always @(posedge cticlk or negedge ctiresetn)
    begin
      if (!ctiresetn)
        reg_ctiapbsbypass <= 1'b0;
      else if (cticlken)
        reg_ctiapbsbypass <= ctiapbsbypass;
    end

  // Synchronise REQ signals
  cx_en_sync u_ct_req_sync
    (
     .clk     (cticlk),
     .resetn  (ctiresetn),
     .clken   (cticlken),
     .sync_di (ct_req),
     .sync_do (ct_req_sync_2)
     );


  // Sync MUX
  assign ct_req_synced  = (reg_ctiapbsbypass ==1'b1) ? ct_req : ct_req_sync_2;

  // Store last status of APBREQ.
  assign nxt_last_apb_req = ct_req_synced;

  // Store last state of APB request
  always @(posedge cticlk or negedge ctiresetn)
    begin
      if (!ctiresetn)
        last_apb_req <= 1'b0;
      else if (cticlken)
        last_apb_req <= nxt_last_apb_req;
    end

  assign nxt_apb_action  = (ct_req_synced  ^ last_apb_req) ;
  assign apb_action_clk_en = cticlken & apb_action;

  //register stage
  always @(posedge cticlk or negedge ctiresetn)
    begin
      if (!ctiresetn)
        apb_action  <= 1'b0;
      else if (cticlken)
        apb_action  <= nxt_apb_action;
    end

  // Acknowledge generation
  assign ctack_n = ~reg_ct_ack;

  // Register ACK outputs
  always @(posedge cticlk or negedge ctiresetn)
    begin
      if (!ctiresetn)
        regctack_cdc_check   <= 1'b0;
      else if (apb_action_clk_en)
        regctack_cdc_check   <= ctack_n;
    end

  // Register control inputs
  //  to avoid problem with different clock domain
  //  Handshaking is used to ensure they are sampled when
  //  the values are stable.
  assign sample_ctrl = nxt_apb_action & cticlken;

  // Register inputs
  always @(posedge cticlk or negedge ctiresetn)
    begin
      if (!ctiresetn)
        begin
          ct_addr_q  <= {10{1'b0}};
          ct_write_q <= 1'b0;
          ct_w_data_q <= {CSSOC_ECTTRIGGERWIDTH{1'b0}};
        end
      else if (sample_ctrl)
        begin
          ct_addr_q  <= paddrdbg;
          ct_write_q <= pwritedbg;
          ct_w_data_q <= pwdatadbg[7:0];
        end
    end


  // Register bank Control mux
  assign rb_addr      = ct_addr_q;
  assign rb_write     = (ct_write_q & apb_action);
  assign rb_wdata     = ct_w_data_q;

  // Check access right of writing to general registers
  assign write_accept = rb_write & (paddrdbg31 | device_un_locked);
  // Check access right of reading registers
  assign read_accept = ~rb_write;

  // Registers next state
  assign reg_cti_control_en = cticlken & write_accept &
                           (rb_addr==CXCTI_CONTROL_ADD);

  always @(posedge cticlk or negedge ctiresetn)
    if (!ctiresetn)
      reg_cti_control <= 1'b0;
    else if (reg_cti_control_en)
      reg_cti_control <= rb_wdata[0];

  assign cti_int_ack = {CSSOC_ECTTRIGGERWIDTH{cticlken & write_accept & (rb_addr==CXCTI_INTACK_ADD)}} &
                      rb_wdata[CSSOC_ECTTRIGGERWIDTH-1:0];

  // application trigger (level) register
  assign write_app_set = write_accept & (rb_addr==CXCTI_APPSET_ADD);
  assign write_app_clr = write_accept & (rb_addr==CXCTI_APPCLR_ADD);
  assign reg_cti_app_trig_en = cticlken & (write_app_set | write_app_clr);

  assign nxt_cti_app_trig = (
                          ({CSSOC_ECTCHANNELWIDTH{write_app_set}} &
                           (reg_cti_app_trig | rb_wdata[CSSOC_ECTCHANNELWIDTH-1:0])) |
                          ({CSSOC_ECTCHANNELWIDTH{write_app_clr}} &
                           (reg_cti_app_trig & ~rb_wdata[CSSOC_ECTCHANNELWIDTH-1:0])));

  always @(posedge cticlk or negedge ctiresetn)
    if (!ctiresetn)
      reg_cti_app_trig <= {CSSOC_ECTCHANNELWIDTH{1'b0}};
    else if (reg_cti_app_trig_en)
      reg_cti_app_trig <= nxt_cti_app_trig;

  // application trigger pulse register
  assign cti_app_pulse_en = write_accept & (rb_addr==CXCTI_APPPULSE_ADD);
  assign nxt_cti_app_pulse = cti_app_pulse_en ?
         rb_wdata[CSSOC_ECTCHANNELWIDTH-1:0] :  {CSSOC_ECTCHANNELWIDTH{1'b0}};

  always @(posedge cticlk or negedge ctiresetn)
    if (!ctiresetn)
       reg_cti_app_pulse <= {CSSOC_ECTCHANNELWIDTH{1'b0}};
    else if (cticlken)
       reg_cti_app_pulse <= nxt_cti_app_pulse;

  //----------------------------------------------------------------------------
  // AuthStatus Register (R)
  //----------------------------------------------------------------------------

  assign      authstatus_r_data = {CXCTI_AUTHSTATUS_SNID_VAL, 1'b0,
                                 CXCTI_AUTHSTATUS_SID_VAL, 1'b0,
                                 CXCTI_AUTHSTATUS_NSNID_VAL, internal_niden,
                                 CXCTI_AUTHSTATUS_NSID_VAL, dbgen_sync_2};

  assign      authstatus_read = (
                                (rb_addr == CXCTI_AUTHSTATUS_ADD) &
                                read_accept);

  //----------------------------------------------------------------------------
  // channel_gate Register (R/W)
  //----------------------------------------------------------------------------

  assign      channel_gate_en = (cticlken &
                               (rb_addr == CXCTI_CHANNELGATE_ADD) &
                               write_accept);

  assign      new_channel_gate = rb_wdata[3:0];

  always @(posedge cticlk or negedge ctiresetn)
    if (!ctiresetn)
      channel_gate <= {CSSOC_ECTCHANNELWIDTH{1'b1}};
    else if (channel_gate_en)
      channel_gate <= new_channel_gate;

  assign      channel_gate_read = (
                                 (rb_addr == CXCTI_CHANNELGATE_ADD) &
                                 read_accept);

  assign                      ch_out_enable = channel_gate;

  //----------------------------------------------------------------------------
  // asicctl Register (R/W)
  //----------------------------------------------------------------------------

  assign      asicctl_en = (cticlken &
                           (rb_addr == CXCTI_EXTMUXCONTROL_ADD) &
                           write_accept);

  assign      new_asicctl = rb_wdata[7:0];

  always @(posedge cticlk or negedge ctiresetn)
    if (!ctiresetn)
      asicctl_reg <= {8{1'b0}};
    else if (asicctl_en)
      asicctl_reg <= new_asicctl;

  assign      asicctl_read = (
                             (rb_addr == CXCTI_EXTMUXCONTROL_ADD) &
                             read_accept);
  assign asicctl = asicctl_reg;

  //----------------------------------------------------------------------------
  // Mapping integration registers
  //----------------------------------------------------------------------------
  assign itcontrol_en = cticlken & write_accept & (rb_addr==CXCTI_ITCONTROL_ADD);

  always @(posedge cticlk or negedge ctiresetn)
    if (!ctiresetn)
      itcontrol <= 1'b0;
    else if (itcontrol_en)
      itcontrol <= rb_wdata[0];

  assign iten = itcontrol;


  assign itchin_ack_en = itcontrol & write_accept & (rb_addr==CXCTI_ITCHINACK_ADD);
  assign it_triginack_en = itcontrol & write_accept & (rb_addr==CXCTI_ITTRIGINACK_ADD);
  assign itch_out_en = itcontrol & write_accept & (rb_addr==CXCTI_ITCHOUT_ADD);
  assign it_trigout_en = itcontrol & write_accept & (rb_addr==CXCTI_ITTRIGOUT_ADD);

  //----------------------------------------------------------------------------
  // Mapping enable registers
  //----------------------------------------------------------------------------

  assign cti_in_en_0_en   = cticlken & write_accept & (rb_addr==CXCTI_INEN0_ADD);
  assign cti_out_en_0_en  = cticlken & write_accept & (rb_addr==CXCTI_OUTEN0_ADD);
  assign cti_in_en_1_en   = cticlken & write_accept & (rb_addr==CXCTI_INEN1_ADD);
  assign cti_out_en_1_en  = cticlken & write_accept & (rb_addr==CXCTI_OUTEN1_ADD);
  assign cti_in_en_2_en   = cticlken & write_accept & (rb_addr==CXCTI_INEN2_ADD);
  assign cti_out_en_2_en  = cticlken & write_accept & (rb_addr==CXCTI_OUTEN2_ADD);
  assign cti_in_en_3_en   = cticlken & write_accept & (rb_addr==CXCTI_INEN3_ADD);
  assign cti_out_en_3_en  = cticlken & write_accept & (rb_addr==CXCTI_OUTEN3_ADD);
  assign cti_in_en_4_en   = cticlken & write_accept & (rb_addr==CXCTI_INEN4_ADD);
  assign cti_out_en_4_en  = cticlken & write_accept & (rb_addr==CXCTI_OUTEN4_ADD);
  assign cti_in_en_5_en   = cticlken & write_accept & (rb_addr==CXCTI_INEN5_ADD);
  assign cti_out_en_5_en  = cticlken & write_accept & (rb_addr==CXCTI_OUTEN5_ADD);
  assign cti_in_en_6_en   = cticlken & write_accept & (rb_addr==CXCTI_INEN6_ADD);
  assign cti_out_en_6_en  = cticlken & write_accept & (rb_addr==CXCTI_OUTEN6_ADD);
  assign cti_in_en_7_en   = cticlken & write_accept & (rb_addr==CXCTI_INEN7_ADD);
  assign cti_out_en_7_en  = cticlken & write_accept & (rb_addr==CXCTI_OUTEN7_ADD);

  always @(posedge cticlk or negedge ctiresetn)
    if (!ctiresetn)
      reg_cti_in_en_0 <= {CSSOC_ECTCHANNELWIDTH{1'b0}};
    else if (cti_in_en_0_en)
      reg_cti_in_en_0 <= rb_wdata[CSSOC_ECTCHANNELWIDTH-1:0];

  always @(posedge cticlk or negedge ctiresetn)
    if (!ctiresetn)
      reg_cti_out_en_0 <= {CSSOC_ECTCHANNELWIDTH{1'b0}};
    else if (cti_out_en_0_en)
      reg_cti_out_en_0 <= rb_wdata[CSSOC_ECTCHANNELWIDTH-1:0];

  always @(posedge cticlk or negedge ctiresetn)
    if (!ctiresetn)
      reg_cti_in_en_1 <= {CSSOC_ECTCHANNELWIDTH{1'b0}};
    else if (cti_in_en_1_en)
      reg_cti_in_en_1 <= rb_wdata[CSSOC_ECTCHANNELWIDTH-1:0];

  always @(posedge cticlk or negedge ctiresetn)
    if (!ctiresetn)
      reg_cti_out_en_1 <= {CSSOC_ECTCHANNELWIDTH{1'b0}};
    else if (cti_out_en_1_en)
      reg_cti_out_en_1 <= rb_wdata[CSSOC_ECTCHANNELWIDTH-1:0];

  always @(posedge cticlk or negedge ctiresetn)
    if (!ctiresetn)
      reg_cti_in_en_2 <= {CSSOC_ECTCHANNELWIDTH{1'b0}};
    else if (cti_in_en_2_en)
      reg_cti_in_en_2 <= rb_wdata[CSSOC_ECTCHANNELWIDTH-1:0];

  always @(posedge cticlk or negedge ctiresetn)
    if (!ctiresetn)
      reg_cti_out_en_2 <= {CSSOC_ECTCHANNELWIDTH{1'b0}};
    else if (cti_out_en_2_en)
      reg_cti_out_en_2 <= rb_wdata[CSSOC_ECTCHANNELWIDTH-1:0];

  always @(posedge cticlk or negedge ctiresetn)
    if (!ctiresetn)
      reg_cti_in_en_3 <= {CSSOC_ECTCHANNELWIDTH{1'b0}};
    else if (cti_in_en_3_en)
      reg_cti_in_en_3 <= rb_wdata[CSSOC_ECTCHANNELWIDTH-1:0];

  always @(posedge cticlk or negedge ctiresetn)
    if (!ctiresetn)
      reg_cti_out_en_3 <= {CSSOC_ECTCHANNELWIDTH{1'b0}};
    else if (cti_out_en_3_en)
      reg_cti_out_en_3 <= rb_wdata[CSSOC_ECTCHANNELWIDTH-1:0];

  always @(posedge cticlk or negedge ctiresetn)
    if (!ctiresetn)
      reg_cti_in_en_4 <= {CSSOC_ECTCHANNELWIDTH{1'b0}};
    else if (cti_in_en_4_en)
      reg_cti_in_en_4 <= rb_wdata[CSSOC_ECTCHANNELWIDTH-1:0];

  always @(posedge cticlk or negedge ctiresetn)
    if (!ctiresetn)
      reg_cti_out_en_4 <= {CSSOC_ECTCHANNELWIDTH{1'b0}};
    else if (cti_out_en_4_en)
      reg_cti_out_en_4 <= rb_wdata[CSSOC_ECTCHANNELWIDTH-1:0];

  always @(posedge cticlk or negedge ctiresetn)
    if (!ctiresetn)
      reg_cti_in_en_5 <= {CSSOC_ECTCHANNELWIDTH{1'b0}};
    else if (cti_in_en_5_en)
      reg_cti_in_en_5 <= rb_wdata[CSSOC_ECTCHANNELWIDTH-1:0];

  always @(posedge cticlk or negedge ctiresetn)
    if (!ctiresetn)
      reg_cti_out_en_5 <= {CSSOC_ECTCHANNELWIDTH{1'b0}};
    else if (cti_out_en_5_en)
      reg_cti_out_en_5 <= rb_wdata[CSSOC_ECTCHANNELWIDTH-1:0];

  always @(posedge cticlk or negedge ctiresetn)
    if (!ctiresetn)
      reg_cti_in_en_6 <= {CSSOC_ECTCHANNELWIDTH{1'b0}};
    else if (cti_in_en_6_en)
      reg_cti_in_en_6 <= rb_wdata[CSSOC_ECTCHANNELWIDTH-1:0];

  always @(posedge cticlk or negedge ctiresetn)
    if (!ctiresetn)
      reg_cti_out_en_6 <= {CSSOC_ECTCHANNELWIDTH{1'b0}};
    else if (cti_out_en_6_en)
      reg_cti_out_en_6 <= rb_wdata[CSSOC_ECTCHANNELWIDTH-1:0];

  always @(posedge cticlk or negedge ctiresetn)
    if (!ctiresetn)
      reg_cti_in_en_7 <= {CSSOC_ECTCHANNELWIDTH{1'b0}};
    else if (cti_in_en_7_en)
      reg_cti_in_en_7 <= rb_wdata[CSSOC_ECTCHANNELWIDTH-1:0];

  always @(posedge cticlk or negedge ctiresetn)
    if (!ctiresetn)
      reg_cti_out_en_7 <= {CSSOC_ECTCHANNELWIDTH{1'b0}};
    else if (cti_out_en_7_en)
      reg_cti_out_en_7 <= rb_wdata[CSSOC_ECTCHANNELWIDTH-1:0];


  // Register read
  assign read_control = read_accept & (rb_addr == CXCTI_CONTROL_ADD);
  assign read_appset  = read_accept & (rb_addr == CXCTI_APPSET_ADD );
  assign read_in_en_0   = read_accept & (rb_addr == CXCTI_INEN0_ADD  );
  assign read_out_en_0  = read_accept & (rb_addr == CXCTI_OUTEN0_ADD );
  assign read_in_en_1   = read_accept & (rb_addr == CXCTI_INEN1_ADD  );
  assign read_out_en_1  = read_accept & (rb_addr == CXCTI_OUTEN1_ADD );
  assign read_in_en_2   = read_accept & (rb_addr == CXCTI_INEN2_ADD  );
  assign read_out_en_2  = read_accept & (rb_addr == CXCTI_OUTEN2_ADD );
  assign read_in_en_3   = read_accept & (rb_addr == CXCTI_INEN3_ADD  );
  assign read_out_en_3  = read_accept & (rb_addr == CXCTI_OUTEN3_ADD );
  assign read_in_en_4   = read_accept & (rb_addr == CXCTI_INEN4_ADD  );
  assign read_out_en_4  = read_accept & (rb_addr == CXCTI_OUTEN4_ADD );
  assign read_in_en_5   = read_accept & (rb_addr == CXCTI_INEN5_ADD  );
  assign read_out_en_5  = read_accept & (rb_addr == CXCTI_OUTEN5_ADD );
  assign read_in_en_6   = read_accept & (rb_addr == CXCTI_INEN6_ADD  );
  assign read_out_en_6  = read_accept & (rb_addr == CXCTI_OUTEN6_ADD );
  assign read_in_en_7   = read_accept & (rb_addr == CXCTI_INEN7_ADD  );
  assign read_out_en_7  = read_accept & (rb_addr == CXCTI_OUTEN7_ADD );

  assign read_trigin_status  = read_accept & (rb_addr == CXCTI_TRIGINSTATUS_ADD );
  assign read_trigout_status = read_accept & (rb_addr == CXCTI_TRIGOUTSTATUS_ADD);

  assign read_chin_status  = read_accept & (rb_addr == CXCTI_CHINSTATUS_ADD );
  assign read_chout_status = read_accept & (rb_addr == CXCTI_CHOUTSTATUS_ADD);

  assign read_itcontrol = read_accept & (rb_addr==CXCTI_ITCONTROL_ADD);

  assign read_itch_out_ack = itcontrol & read_accept & (rb_addr==CXCTI_ITCHOUTACK_ADD);
  assign read_itchin     = itcontrol & read_accept & (rb_addr==CXCTI_ITCHIN_ADD    );
  assign read_it_trigin   = itcontrol & read_accept & (rb_addr==CXCTI_ITTRIGIN_ADD  );
  assign read_it_trigoutack = itcontrol & read_accept &
                            (rb_addr==CXCTI_ITTRIGOUTACK_ADD);

  // This logic assumes TRIGGERWIDTH > CHANNELWIDTH (should be 8 vs 4)
  assign nxt_r_data =
         (({CSSOC_ECTTRIGGERWIDTH{read_control}}           &
                                 {{(CSSOC_ECTTRIGGERWIDTH-1){1'b0}},reg_cti_control}) |
          ({CSSOC_ECTTRIGGERWIDTH{read_appset}}            &
                 {{(CSSOC_ECTTRIGGERWIDTH-CSSOC_ECTCHANNELWIDTH){1'b0}}, reg_cti_app_trig}) |
          ({CSSOC_ECTTRIGGERWIDTH{read_in_en_0}}             &
                  {{(CSSOC_ECTTRIGGERWIDTH-CSSOC_ECTCHANNELWIDTH){1'b0}},  reg_cti_in_en_0}) |
          ({CSSOC_ECTTRIGGERWIDTH{read_out_en_0}}            &
                  {{(CSSOC_ECTTRIGGERWIDTH-CSSOC_ECTCHANNELWIDTH){1'b0}}, reg_cti_out_en_0}) |
          ({CSSOC_ECTTRIGGERWIDTH{read_in_en_1}}             &
                  {{(CSSOC_ECTTRIGGERWIDTH-CSSOC_ECTCHANNELWIDTH){1'b0}},  reg_cti_in_en_1}) |
          ({CSSOC_ECTTRIGGERWIDTH{read_out_en_1}}            &
                  {{(CSSOC_ECTTRIGGERWIDTH-CSSOC_ECTCHANNELWIDTH){1'b0}}, reg_cti_out_en_1}) |
          ({CSSOC_ECTTRIGGERWIDTH{read_in_en_2}}             &
                  {{(CSSOC_ECTTRIGGERWIDTH-CSSOC_ECTCHANNELWIDTH){1'b0}},  reg_cti_in_en_2}) |
          ({CSSOC_ECTTRIGGERWIDTH{read_out_en_2}}            &
                  {{(CSSOC_ECTTRIGGERWIDTH-CSSOC_ECTCHANNELWIDTH){1'b0}}, reg_cti_out_en_2}) |
          ({CSSOC_ECTTRIGGERWIDTH{read_in_en_3}}             &
                  {{(CSSOC_ECTTRIGGERWIDTH-CSSOC_ECTCHANNELWIDTH){1'b0}},  reg_cti_in_en_3}) |
          ({CSSOC_ECTTRIGGERWIDTH{read_out_en_3}}            &
                  {{(CSSOC_ECTTRIGGERWIDTH-CSSOC_ECTCHANNELWIDTH){1'b0}}, reg_cti_out_en_3}) |
          ({CSSOC_ECTTRIGGERWIDTH{read_in_en_4}}             &
                  {{(CSSOC_ECTTRIGGERWIDTH-CSSOC_ECTCHANNELWIDTH){1'b0}},  reg_cti_in_en_4}) |
          ({CSSOC_ECTTRIGGERWIDTH{read_out_en_4}}            &
                  {{(CSSOC_ECTTRIGGERWIDTH-CSSOC_ECTCHANNELWIDTH){1'b0}}, reg_cti_out_en_4}) |
          ({CSSOC_ECTTRIGGERWIDTH{read_in_en_5}}             &
                  {{(CSSOC_ECTTRIGGERWIDTH-CSSOC_ECTCHANNELWIDTH){1'b0}},  reg_cti_in_en_5}) |
          ({CSSOC_ECTTRIGGERWIDTH{read_out_en_5}}            &
                  {{(CSSOC_ECTTRIGGERWIDTH-CSSOC_ECTCHANNELWIDTH){1'b0}}, reg_cti_out_en_5}) |
          ({CSSOC_ECTTRIGGERWIDTH{read_in_en_6}}             &
                  {{(CSSOC_ECTTRIGGERWIDTH-CSSOC_ECTCHANNELWIDTH){1'b0}},  reg_cti_in_en_6}) |
          ({CSSOC_ECTTRIGGERWIDTH{read_out_en_6}}            &
                  {{(CSSOC_ECTTRIGGERWIDTH-CSSOC_ECTCHANNELWIDTH){1'b0}}, reg_cti_out_en_6}) |
          ({CSSOC_ECTTRIGGERWIDTH{read_in_en_7}}             &
                  {{(CSSOC_ECTTRIGGERWIDTH-CSSOC_ECTCHANNELWIDTH){1'b0}},  reg_cti_in_en_7}) |
          ({CSSOC_ECTTRIGGERWIDTH{read_out_en_7}}            &
                  {{(CSSOC_ECTTRIGGERWIDTH-CSSOC_ECTCHANNELWIDTH){1'b0}}, reg_cti_out_en_7}) |
          ({CSSOC_ECTTRIGGERWIDTH{read_trigin_status}}      &        reg_trig_in_status) |
          ({CSSOC_ECTTRIGGERWIDTH{read_trigout_status}}     &       reg_trig_out_status) |
          ({CSSOC_ECTTRIGGERWIDTH{read_chin_status}}        &
                  {{(CSSOC_ECTTRIGGERWIDTH-CSSOC_ECTCHANNELWIDTH){1'b0}},reg_ch_in_status}) |
          ({CSSOC_ECTTRIGGERWIDTH{read_chout_status}}       &
                 {{(CSSOC_ECTTRIGGERWIDTH-CSSOC_ECTCHANNELWIDTH){1'b0}},reg_ch_out_status}) |
          ({CSSOC_ECTTRIGGERWIDTH{read_itcontrol}}         &
                                     {{(CSSOC_ECTTRIGGERWIDTH-1){1'b0}},itcontrol}) |
          ({CSSOC_ECTTRIGGERWIDTH{read_itch_out_ack}}        &
               {{(CSSOC_ECTTRIGGERWIDTH-CSSOC_ECTCHANNELWIDTH){1'b0}}, itchout_ack_r_data}) |
          ({CSSOC_ECTTRIGGERWIDTH{read_it_trigoutack}}      &      it_trigout_ack_r_data) |
          ({CSSOC_ECTTRIGGERWIDTH{read_itchin}}            &
                   {{(CSSOC_ECTTRIGGERWIDTH-CSSOC_ECTCHANNELWIDTH){1'b0}}, itchin_r_data}) |
          ({CSSOC_ECTTRIGGERWIDTH{read_it_trigin}}          &          it_trigin_r_data) |
          ({CSSOC_ECTTRIGGERWIDTH{asicctl_read}}           &             asicctl_reg) |
          ({CSSOC_ECTTRIGGERWIDTH{channel_gate_read}}       &
                   {{(CSSOC_ECTTRIGGERWIDTH-CSSOC_ECTCHANNELWIDTH){1'b0}}, channel_gate}) |
          ({CSSOC_ECTTRIGGERWIDTH{authstatus_read}}        &        authstatus_r_data)
          );

  // Registered output of APB RDATA
  always @(posedge cticlk or negedge ctiresetn)
    begin
      if (!ctiresetn)
        reg_r_data <= {CSSOC_ECTTRIGGERWIDTH{1'b0}};
      else if (apb_action_clk_en)
        reg_r_data <= nxt_r_data;
    end

  // Connect register values to top level
  assign ctack   = reg_ct_ack;
  assign ct_rdata = reg_r_data[7:0];
  assign cti_control = reg_cti_control;
  assign app_trigger = reg_cti_app_trig | reg_cti_app_pulse;
  assign ctiinen0   = reg_cti_in_en_0;
  assign ctiouten0  = reg_cti_out_en_0;
  assign ctiinen1   = reg_cti_in_en_1;
  assign ctiouten1  = reg_cti_out_en_1;
  assign ctiinen2   = reg_cti_in_en_2;
  assign ctiouten2  = reg_cti_out_en_2;
  assign ctiinen3   = reg_cti_in_en_3;
  assign ctiouten3  = reg_cti_out_en_3;
  assign ctiinen4   = reg_cti_in_en_4;
  assign ctiouten4  = reg_cti_out_en_4;
  assign ctiinen5   = reg_cti_in_en_5;
  assign ctiouten5  = reg_cti_out_en_5;
  assign ctiinen6   = reg_cti_in_en_6;
  assign ctiouten6  = reg_cti_out_en_6;
  assign ctiinen7   = reg_cti_in_en_7;
  assign ctiouten7  = reg_cti_out_en_7;

`ifdef ARM_ASSERT_ON
  //----------------------------------------------------------------------------
  // OVL Assertions
  //----------------------------------------------------------------------------

  //----------------------------------------------------------------------------
  // read enables should be mutually exclusive.
  //----------------------------------------------------------------------------

  assert_zero_one_hot #(OVL_WARNING, 30, OVL_ASSERT,
    "OVL message : cxcti_reg_c - read enables should be exclusive")
      cxcti_reg_c
        (
         .clk         (cticlk),
         .reset_n     (ctiresetn),
         .test_expr   ({read_control,read_appset,read_in_en_0,read_out_en_0,read_in_en_1,
                        read_out_en_1,read_in_en_2,read_out_en_2,read_in_en_3,read_out_en_3,
                        read_in_en_4,read_out_en_4,read_in_en_5,read_out_en_5,read_in_en_6,
                        read_out_en_6,read_in_en_7,read_out_en_7,read_trigin_status,
                        read_trigout_status,read_chin_status,read_chout_status,
                        read_itcontrol,read_itch_out_ack,
                        asicctl_read,channel_gate_read,authstatus_read,
                        read_it_trigoutack,read_itchin,read_it_trigin})
        );

`endif


`ifdef ARM_CDC_ON
        cdc_launch u_cdc_regctack(
                .clk_launch(cticlk),
                .clk_capture(cscti.u_cxcti_apb_if.u_ct_ack_sync.sync_clk),
                .d_in(regctack_cdc_check),
                .d_out(reg_ct_ack)
                );
`else
        assign reg_ct_ack = regctack_cdc_check;
`endif

endmodule
