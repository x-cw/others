//-----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2004-2015 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//    Checked In : $Date: 2014-08-14 16:01:35 +0100 (Thu, 14 Aug 2014) $
//    Revision   : $Revision: 39945 $
//    Release    : CoreSight-SoC-TM100-r3p2-00rel0
//-----------------------------------------------------------------------------
//  Purpose             : Trace clock domain side FIFO for the TPIU Block.
//                        Contains the read-mux for the 4 data bays in the
//                        FIFO.
//-----------------------------------------------------------------------------

module cxtpiu_trace_fifo (
  // Inputs
  traceclkin, tresetn, pop_fifo, wr_ptr_gray_sync, fifo_data_0, fifo_data_1,
  fifo_data_2, fifo_data_3, fifo_data_4, fifo_data_5,
  // Outputs
  fifo_empty, rd_ptr_gray, fifo_r_data
  );


  // Inputs
  input         traceclkin;         // Trace clock
  input         tresetn;            // Trace asychronous reset active low
  input         pop_fifo;           // Pop signal for reading from the FIFO
  input [3:0]   wr_ptr_gray_sync;   // Write pointer from the synchronizer

  input [32:0]  fifo_data_0;        // Input all the data registers for use
  input [32:0]  fifo_data_1;        // in the read mux
  input [32:0]  fifo_data_2;        // NB 6 banks used, optimal for 2 clk
  input [32:0]  fifo_data_3;        // delays synchronising between both domains
  input [32:0]  fifo_data_4;        // and one clock delay for each domain to
  input [32:0]  fifo_data_5;        // calculate the pointer value

  // Outputs
  output        fifo_empty;         // FIFO empty signal
  output [3:0]  rd_ptr_gray;        // Read pointer to the write clock domain
  output [32:0] fifo_r_data;        // Output the read data values

  // ------------------------------------------------------------------------
  //
  //                            Trace clock domain side FIFO
  //                            ============================
  //
  // ------------------------------------------------------------------------
  //
  //
  // Overview
  // ========
  // Trace clock domain interface for the FIFO block of the TPIU.
  //
  // ------------------------------------------------------------------------

  // Select the correct data
  reg  [32:0]   fifo_r_data;   // output data
  wire [32:0]   nxt_fifo_r_data;   // muxed data
  wire          fifo_en;      // register enable

  // Read Pointer logic
  reg  [3:0]    next_rd_ptr_gray; // next pointer location
  wire          rd_ptr_en;       // move to the next pointer
  wire [3:0]    rd_ptr_gray;     // currently selected data
  wire [3:0]    rd_ptr_gray_int;
  reg  [3:0]    rdptrgray_cdc_check;     // currently selected data

  // FIFO Empty control signal
  wire          nxt_fifo_empty;
  wire          fifo_empty_en;
  wire          fifo_empty;     // currently selected data is the same as the
                               // write location (so not written into)
  reg           fifo_empty_int;

  // ------------------------------------------------------------------------
  //
  // Main body of code
  // =================
  //
  // ------------------------------------------------------------------------

  // ------------------------------------------------------------------------
  // Select the correct data
  // ------------------------------------------------------------------------
  // Each data bank has two select combination (to allow for the write
  // pointer to correctly track the read pointer when wrapping around the
  // last entry).
  assign nxt_fifo_r_data = (({33{(rd_ptr_gray_int[3:0] == 4'b0000)}} & fifo_data_0) |
                         ({33{(rd_ptr_gray_int[3:0] == 4'b1111)}} & fifo_data_0) |
                         ({33{(rd_ptr_gray_int[3:0] == 4'b0001)}} & fifo_data_1) |
                         ({33{(rd_ptr_gray_int[3:0] == 4'b1110)}} & fifo_data_1) |
                         ({33{(rd_ptr_gray_int[3:0] == 4'b0011)}} & fifo_data_2) |
                         ({33{(rd_ptr_gray_int[3:0] == 4'b1010)}} & fifo_data_2) |
                         ({33{(rd_ptr_gray_int[3:0] == 4'b0010)}} & fifo_data_3) |
                         ({33{(rd_ptr_gray_int[3:0] == 4'b1011)}} & fifo_data_3) |
                         ({33{(rd_ptr_gray_int[3:0] == 4'b0110)}} & fifo_data_4) |
                         ({33{(rd_ptr_gray_int[3:0] == 4'b1001)}} & fifo_data_4) |
                         ({33{(rd_ptr_gray_int[3:0] == 4'b0111)}} & fifo_data_5) |
                         ({33{(rd_ptr_gray_int[3:0] == 4'b1000)}} & fifo_data_5) );

  // ------------------------------------------------------------------------
  // Read Pointer logic
  // ------------------------------------------------------------------------

  always @(rd_ptr_gray_int)
    begin : c_rdptr_encode
      case (rd_ptr_gray_int)
        4'b0000 : next_rd_ptr_gray = 4'b0001;  // #0 going to #1
        4'b0001 : next_rd_ptr_gray = 4'b0011;  // #1 going to #2
        4'b0011 : next_rd_ptr_gray = 4'b0010;  // #2 going to #3
        4'b0010 : next_rd_ptr_gray = 4'b0110;  // #3 going to #4
        4'b0110 : next_rd_ptr_gray = 4'b0111;  // #4 going to #5
        4'b0111 : next_rd_ptr_gray = 4'b1111;  // #5 going to #0
        4'b1111 : next_rd_ptr_gray = 4'b1110;  // #0 going to #1
        4'b1110 : next_rd_ptr_gray = 4'b1010;  // #1 going to #2
        4'b1010 : next_rd_ptr_gray = 4'b1011;  // #2 going to #3
        4'b1011 : next_rd_ptr_gray = 4'b1001;  // #3 going to #4
        4'b1001 : next_rd_ptr_gray = 4'b1000;  // #4 going to #5
        4'b1000 : next_rd_ptr_gray = 4'b0000;  // #5 going to #0
        // unused
        4'b0100, 4'b0101,
          4'b1100, 4'b1101  :  next_rd_ptr_gray = 4'bxxxx;
        default : next_rd_ptr_gray = 4'bxxxx;
      endcase // case(rd_ptr_gray_int)
    end // always @ (rd_ptr_gray_int)

  // Only update the read pointer when a valid data value was removed or taken
  // into the buffer stage (and the FIFO was not empty)
  assign rd_ptr_en = (pop_fifo | fifo_empty_int) & ~nxt_fifo_empty;

  always @(posedge traceclkin or negedge tresetn)
    begin : s_rdptrgray
      if (!tresetn)
         rdptrgray_cdc_check    <= {4{1'b0}};
      else
        if (rd_ptr_en)
           rdptrgray_cdc_check  <= next_rd_ptr_gray;
    end

  // ------------------------------------------------------------------------
  // FIFO Empty control signal
  // ------------------------------------------------------------------------
  // Simple comparison to check that the Read Pointer has not reached the
  // same location as the write pointer

  // Actual 6-stage Fifo empty
  assign nxt_fifo_empty = (wr_ptr_gray_sync == rd_ptr_gray_int);

  // ------------------------------------------------------------------------
  // Extra buffer stage
  // ------------------------------------------------------------------------
  // provides a safe sample of the data and control signals for use within
  // the traceclkin domain

  // Register output data (and control)
  assign fifo_en = (pop_fifo | fifo_empty_int) & ~nxt_fifo_empty;

  // only update valid flag when taking an entry from the FIFO or when the slot was empty
  assign fifo_empty_en = pop_fifo | fifo_empty_int;

  always @(posedge traceclkin)
    if (fifo_en)
      fifo_r_data <= nxt_fifo_r_data;

  // actually indicates that this stage is empty
  always @(posedge traceclkin or negedge tresetn)
    if (!tresetn)
      fifo_empty_int <= 1'b1;
    else
      if (fifo_empty_en)
        fifo_empty_int <= nxt_fifo_empty;

  assign fifo_empty = fifo_empty_int;

`ifdef ARM_CDC_ON
        cdc_connect #(3,0) u_cdc_rdptrgray(
                .clk_launch(traceclkin),
                .clk_capture(cxtpiu.u_cxtpiu_atb_sync.u_rd_ptr_gray_0.clk),
                .d_in(rdptrgray_cdc_check),
                .d_out_async(rd_ptr_gray_int)
                );
`else
        assign rd_ptr_gray_int = rdptrgray_cdc_check;
`endif
assign rd_ptr_gray = rd_ptr_gray_int;
endmodule // cxtpiu_trace_fifo
