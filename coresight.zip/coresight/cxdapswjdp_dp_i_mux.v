// ----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//        (C) COPYRIGHT 2004-2015 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//    Checked In : $Date: 2014-08-14 16:01:35 +0100 (Thu, 14 Aug 2014) $
//    Revision   : $Revision: 39945 $
//    Release    : CoreSight-SoC-TM100-r3p2-00rel0
// ----------------------------------------------------------------------------
//  Purpose : DAP DP Interface Mux between SW-DP and JTAG-DP protocol blocks.
// ----------------------------------------------------------------------------

module cxdapswjdp_dp_i_mux
  (
  // Inputs
  dbgclk, npotrst, jtagsel, j_busreq, j_buswrite, jtag_busaddr_31to24,
  jtag_busaddr_7to2, j_busabort, j_buswdata, j_busmode, j_busmask, j_bustrncnt,
  j_cdbgpwrupreq, j_csyspwrupreq, j_cdbgrstreq, s_busreq, s_buswrite,
  sw_busaddr_31to24, sw_busaddr_7to2, s_busabort, s_buswdata, s_busmode,
  s_busmask, s_bustrncnt, s_cdbgpwrupreq, s_csyspwrupreq, s_cdbgrstreq,

  // Outputs
  busreq, bus_write, busaddr_31to24, busaddr_7to2, busabort, bus_wdata,
  busmode, busmask, bus_trn_cnt, cdbgpwrupreq, csyspwrupreq, cdbgrstreq
  );

// --------------------------------------------------------------------------
// Port Definitions
// --------------------------------------------------------------------------

  input          dbgclk;              // Debug clock
  input          npotrst;             // Power on reset
  input          jtagsel;             // JTAG select (not Serial Wire)

  input          j_busreq;            // JTAG Bus Transaction Request
  input          j_buswrite;          // JTAG Bus write
  input  [31:24] jtag_busaddr_31to24; // JTAG Bus Address - AP Sel
  input  [7:2]   jtag_busaddr_7to2;   // JTAG Bus Address - Bank/Reg Sel

  input          j_busabort;          // JTAG Bus abort
  input  [31:0]  j_buswdata;          // JTAG Bus write Data Port
  input  [1:0]   j_busmode;           // JTAG Bus Mode
  input  [3:0]   j_busmask;           // JTAG Bus Compare Mask
  input  [11:0]  j_bustrncnt;         // JTAG Bus Transfer Cnt
  input          j_cdbgpwrupreq;      // JTAG-DP Debug Power Domain up request
  input          j_csyspwrupreq;      // JTAG-DP System Power Domain up request
  input          j_cdbgrstreq;        // JTAG-DP Debug reset request to reset controller

  input          s_busreq;            // SW   Bus Transaction Request
  input          s_buswrite;          // SW   Bus write
  input  [31:24] sw_busaddr_31to24;   // SW Bus Address - AP Sel
  input  [7:2]   sw_busaddr_7to2;     // SW Bus Address - Bank/Reg Sel
  input          s_busabort;          // SW   Bus abort
  input  [31:0]  s_buswdata;          // SW   Bus write Data Port
  input  [1:0]   s_busmode;           // SW   Bus Mode
  input  [3:0]   s_busmask;           // SW   Bus Compare Mask
  input  [11:0]  s_bustrncnt;         // SW   Bus Transfer Cnt
  input          s_cdbgpwrupreq;      // SW-DP Debug Power Domain up request
  input          s_csyspwrupreq;      // SW-DP System Power Domain up request
  input          s_cdbgrstreq;        // SW-DP Debug reset request to reset controller

  output         busreq;              // Bus Transaction Request
  output         bus_write;           // Bus write
  output [31:24] busaddr_31to24;      // Bus Address - AP Sel
  output [7:2]   busaddr_7to2;        // Bus Address - Bank/Reg Sel
  output         busabort;            // Bus abort
  output [31:0]  bus_wdata;           // Bus write Data Port
  output [1:0]   busmode;             // Bus Mode
  output [3:0]   busmask;             // Bus Compare Mask
  output [11:0]  bus_trn_cnt;         // Bus Transfer Cnt
  output         cdbgpwrupreq;        // Debug Power Domain up request
  output        csyspwrupreq;         // System Power Domain up request
  output        cdbgrstreq;           // Debug reset request to reset controller

// ----------------------------------------------------------------------------
//  Signal Declarations
// ----------------------------------------------------------------------------
  // I/O pins
  wire          j_busreq;             // JTAG Bus Transaction Request
  wire          j_buswrite;           // JTAG Bus write
  wire          j_busabort;           // JTAG Bus abort
  wire   [31:0] j_buswdata;           // JTAG Bus write Data Port
  wire    [1:0] j_busmode;            // JTAG Bus Mode
  wire    [3:0] j_busmask;            // JTAG Bus Compare Mask
  wire   [11:0] j_bustrncnt;          // JTAG Bus Transfer Cnt
  wire          j_cdbgpwrupreq;       // JTAG-DP Debug Power Domain up request
  wire          j_csyspwrupreq;       // JTAG-DP System Power Domain up request
  wire          j_cdbgrstreq;         // JTAG-DP Debug reset request to reset controller
  wire          s_busreq;             // SW   Bus Transaction Request
  wire          s_buswrite;           // SW   Bus write
  wire  [31:24] sw_busaddr_31to24;    // SW Bus Address - AP Sel
  wire  [7:2]   sw_busaddr_7to2;      // SW Bus Address - Bank/Reg Sel
  wire  [31:24] jtag_busaddr_31to24;  // JTAG Bus Address - AP Sel
  wire  [7:2]   jtag_busaddr_7to2;    // JTAG Bus Address - Bank/Reg Sel
  wire          s_busabort;           // SW   Bus abort
  wire   [31:0] s_buswdata;           // SW   Bus write Data Port
  wire    [1:0] s_busmode;            // SW   Bus Mode
  wire    [3:0] s_busmask;            // SW   Bus Compare Mask
  wire   [11:0] s_bustrncnt;          // SW   Bus Transfer Cnt
  wire          s_cdbgpwrupreq;       // SW-DP Debug Power Domain up request
  wire          s_csyspwrupreq;       // SW-DP System Power Domain up request
  wire          s_cdbgrstreq;         // SW-DP Debug reset request to reset controller
  wire           busreq;              // Bus Transaction Request (registered)
  reg           busreq_cdc_check;     // Bus Transaction Request (registered)
  wire           busabort;            // Bus abort (registered)
  reg           busabort_cdc_check;   // Bus abort (registered)
  wire          next_busreq;          // Bus Transaction Request
  wire          next_busabort;        // Bus abort
  wire          bus_write;            // Bus write
  wire  [31:24] busaddr_31to24;       // Bus Address - AP Sel
  wire  [7:2]   busaddr_7to2;         // Bus Address - Bank/Reg Sel
  wire   [31:0] bus_wdata;            // Bus write Data Port
  wire    [1:0] busmode;              // Bus Mode
  wire    [3:0] busmask;              // Bus Compare Mask
  wire   [11:0] bus_trn_cnt;          // Bus Transfer Cnt

  wire          i_cdbgpwrupreq;       // Unregistered Debug Power Domain up request
  wire          i_csyspwrupreq;       // UnregisteredSystem Power Domain up request
  wire          i_cdbgrstreq;         // UnregisteredDebug reset request to reset controller

  reg           cdbgpwrupreq;         // Debug Power Domain up request
  reg           csyspwrupreq;         // System Power Domain up request
  reg           cdbgrstreq;           // Debug reset request to reset controller

// -------------------------------------------------------------------------
// Output Multiplexer (synchronisation performed externally)
// -------------------------------------------------------------------------

// Generate registered versions of the bus request and bus abort to ensure
// clean CDC circuitry (no glitching)

  always @ (posedge dbgclk or negedge npotrst)
    begin : p_busrequest
      if (!npotrst)
         busreq_cdc_check  <= 1'b0;
      else
         busreq_cdc_check  <= next_busreq;
    end

  always @ (posedge dbgclk or negedge npotrst)
    begin : p_busabort
      if (!npotrst)
         busabort_cdc_check  <= 1'b0;
      else
         busabort_cdc_check  <= next_busabort;
    end

  assign next_busreq     = jtagsel ? j_busreq    : s_busreq;
  assign next_busabort   = jtagsel ? j_busabort  : s_busabort;
  assign bus_write       = jtagsel ? j_buswrite  : s_buswrite;
  assign busaddr_31to24  = jtagsel ? jtag_busaddr_31to24 : sw_busaddr_31to24;
  assign busaddr_7to2    = jtagsel ? jtag_busaddr_7to2 : sw_busaddr_7to2;
  assign bus_wdata       = jtagsel ? j_buswdata  : s_buswdata;
  assign busmode         = jtagsel ? j_busmode   : s_busmode;
  assign busmask         = jtagsel ? j_busmask   : s_busmask;
  assign bus_trn_cnt     = jtagsel ? j_bustrncnt : s_bustrncnt;

// -------------------------------------------------------------------------
// Power-up and reset request multiplexers
// -------------------------------------------------------------------------

  assign i_cdbgpwrupreq = jtagsel ? j_cdbgpwrupreq : s_cdbgpwrupreq;
  assign i_csyspwrupreq = jtagsel ? j_csyspwrupreq : s_csyspwrupreq;
  assign i_cdbgrstreq   = jtagsel ? j_cdbgrstreq   : s_cdbgrstreq;

// -------------------------------------------------------------------------
// Register power-up and reset requests to prevent glitching when
// switching from JTAG to Serial Wire or vice versa
// -------------------------------------------------------------------------

  always @ (posedge dbgclk or negedge npotrst)
    begin : p_dbgpwrupreqreg
      if (!npotrst)
        cdbgpwrupreq <= 1'b0;
      else
        cdbgpwrupreq <= i_cdbgpwrupreq;
    end

  always @ (posedge dbgclk or negedge npotrst)
    begin : p_syspwrupreqreg
      if (!npotrst)
        csyspwrupreq <= 1'b0;
      else
        csyspwrupreq <= i_csyspwrupreq;
    end

  always @ (posedge dbgclk or negedge npotrst)
    begin : p_dbgrstreqreg
      if (!npotrst)
        cdbgrstreq <= 1'b0;
      else
        cdbgrstreq <= i_cdbgrstreq;
    end


`ifdef ARM_ASSERT_ON

// Assert that signals from inactive SwDpProtocol block
// do not change when jtagsel is HIGH
  assert_win_unchange #(`OVL_ERROR, 70, `OVL_ASSERT, "SWD protocol signals changed when JTAG selected")
  swd_sig_change(
               .clk           (dbgclk),
               .reset_n       (npotrst),
               .start_event   (jtagsel),
               .test_expr     ({s_busreq,s_buswrite,sw_busaddr_31to24,
                                sw_busaddr_7to2,s_busabort,
                                s_buswdata,s_busmode,s_busmask,s_bustrncnt,
                                s_cdbgpwrupreq,s_csyspwrupreq,s_cdbgrstreq}),
               .end_event     (~jtagsel));

// Assert that signals from inactive JtagDpProtocol block
// do not change when jtagsel is LOW
  assert_win_unchange #(`OVL_ERROR, 70, `OVL_ASSERT, "JTAG protocol signals changed when SWD selected")
  jtag_sig_change(
               .clk           (dbgclk),
               .reset_n       (npotrst),
               .start_event   (~jtagsel),
               .test_expr     ({j_busreq,j_buswrite,jtag_busaddr_31to24,
                                jtag_busaddr_7to2,j_busabort,
                                j_buswdata,j_busmode,j_busmask,j_bustrncnt,
                                j_cdbgpwrupreq,j_csyspwrupreq,j_cdbgrstreq}),
               .end_event     (jtagsel));

`endif

`ifdef ARM_CDC_ON
  cdc_connect u_cdc_busabort(
                            .clk_launch(dbgclk),
                            .clk_capture(cxdapswjdp.u_cxdapswjdp_dapclk.u_cxdapswjdp_dp_apb_sync.u_sync_bus_abort.clk),
                            .d_in(busabort_cdc_check),
                            .d_out_async(busabort)
                            );
`else
  assign busabort = busabort_cdc_check;
`endif
`ifdef ARM_CDC_ON
  cdc_connect u_cdc_busreq(
                          .clk_launch(dbgclk),
                          .clk_capture(cxdapswjdp.u_cxdapswjdp_dapclk.u_cxdapswjdp_dp_apb_sync.u_sync_bus_req.clk),
                          .d_in(busreq_cdc_check),
                          .d_out_async(busreq)
                          );
`else
        assign busreq = busreq_cdc_check;
`endif
endmodule
