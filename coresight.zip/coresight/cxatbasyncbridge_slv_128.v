//-----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2010-2015 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//  Version and Release Control Information:
//
//  Checked In          : $Date: 2015-01-29 15:49:43 +0000 (Thu, 29 Jan 2015) $
//  Revision	        : $Revision: 41305 $
//  Date	        : $Date: 2015-01-29 15:49:43 +0000 (Thu, 29 Jan 2015) $
//
//  Release Information : CoreSight-SoC-TM100-r3p2-00rel0
//-----------------------------------------------------------------------------

//----------------------------------------------------------------------------
//
//                               CXATBASYNCBRIDGE.v
//                              ================
//
//----------------------------------------------------------------------------
//
//  Overview
// ==========
//
// This component instantiates an ATBASYNCBRIDGE of configurable ATB_DATA_WIDTH and optional CLOCK_STOP feature
//
//
//----------------------------------------------------------------------------



//------------------------------------------------------------------------------
// Module Declaration
//------------------------------------------------------------------------------
module cxatbasyncbridge_slv_128
  (
  //----------------------------------------------------------------------------
  // port definitions
  //----------------------------------------------------------------------------

 // Slave Port

  clks,        // ATB Bus clock for Slaveport
  clkens,      // ATB clock enable for slaveport
  resetsn,     // ATB Bus reset on slave side
  atvalids,    // ATB Bus transfer valid slave
  atids,       // ATB Bus id slave
  atbytess,    // ATB byte lane information
  atdatas,     // ATB Bus data slave
  afreadys,    // ATB Bus flush ready slave
  // Slave Port
  atreadys,    // ATB Bus transfer ready slave
  afvalids,    // ATB Bus flush valid slave
  syncreqs,     // Synchronization request
  
  // Inter-domain ATB bus (Slave side)
  atb_rev_data_in,       // Handshake signals and pointers from master side
  zero_pointer_d,        // Indication that the fifo is empty
  atb_fwd_data_out,      // Fifo data which needs to be driven on master side
  syncreqs_req_async_in, // syncreqs assertion request from ATBM
  syncreqs_ack_async_out // ack from syncreqs domain for ATBM domain
  

);



  //----------------------------------------------------------------------------
  // parameters
  //----------------------------------------------------------------------------

  // calculated parameters (do not alter)

  localparam ATB_BYTES_WIDTH = 4;

  localparam ATB_DATA_WIDTH = 128;

  localparam DW = ATB_DATA_WIDTH - 1;
  localparam BW = ATB_BYTES_WIDTH - 1;

  localparam FIFO_DATA_WIDTH = BW+DW+9;



 // Slave Port

  input wire             clks;        // ATB Bus clock for Slaveport
  input wire             clkens;      // ATB clock enable for slaveport
  input wire             resetsn;     // ATB Bus reset on slave side
  input wire             atvalids;    // ATB Bus transfer valid slave
  input wire [6:0]       atids;       // ATB Bus id slave

  input wire [3:0]       atbytess;     // ATB byte lane information
  input wire [128-1:0]   atdatas;    // ATB Bus data slave
  input wire             afreadys;     // ATB Bus flush ready slave
  // Slave Port
  output wire            atreadys;     // ATB Bus transfer ready slave
  output wire            afvalids;     // ATB Bus flush valid slave
  output wire            syncreqs;     // Synchronization request

  // Master Port

  // Inter-domain ATB bus (Slave side)
  input wire [4:0]       atb_rev_data_in;   // Handshake signals and pointers from master side
  input wire             zero_pointer_d; // Indication that the fifo is empty
//   output wire [6*FIFO_DATA_WIDTH + 10 : 0] atb_fwd_data_out;
  output wire [6*139 + 10 : 0] atb_fwd_data_out;
                                    // Fifo data which needs to be driven on master side
  input wire        syncreqs_req_async_in;
                                    // syncreqs assertion request from ATBM
  output wire       syncreqs_ack_async_out;
                                    // ack from syncreqs domain for ATBM domain

  //----------------------------------------------------------------------------
  // WIRES AND REGS
  //----------------------------------------------------------------------------

  // ---------------------------------------------------------------------------
  // ATB Slave Interface
  // ---------------------------------------------------------------------------
  cxatbasyncbridge_slv_if_slv #(DW, BW, FIFO_DATA_WIDTH) u_cxatbasyncbridge_slv_if
    (
    // Inputs
    .atclks                            (clks),
    .atclkens                          (clkens),
    .atresetsn                         (resetsn),
    .atvalids                          (atvalids),
    .atids                             (atids),
    .atbytess                          (atbytess),
    .atdatas                           (atdatas),
    .afreadys                          (afreadys),
    .atb_fwd_data                      (atb_fwd_data_out),
    .atb_rev_data                      (atb_rev_data_in),
    .zero_pointer_d                    (zero_pointer_d),
    // Outputs
    .atreadys                          (atreadys),
    .afvalids                          (afvalids));

  // ---------------------------------------------------------------------------
  // syncreqs domain
  // ---------------------------------------------------------------------------
cxatbasyncbridge_syncreqs_domain_slv
  u_cxatbasyncbridge_syncreqs_domain (
                     .syncreqs_req_async (syncreqs_req_async_in),
                     .syncreqs_ack_async (syncreqs_ack_async_out),
                     
                     .syncreqs           (syncreqs),
                     .clkens             (clkens),
                     .clks               (clks),
                     .resetsn            (resetsn)
                                   );


`ifdef ARM_ASSERT_ON
  //----------------------------------------------------------------------------
  // OVL Assertions
  //----------------------------------------------------------------------------




`endif
endmodule // cxatbasyncbridge
