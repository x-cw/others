//-----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2004-2015 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//    Checked In : $Date: 2014-06-25 08:42:22 +0100 (Wed, 25 Jun 2014) $
//    Revision   : $Revision: 39629 $
//    Release    : CoreSight-SoC-TM100-r3p2-00rel0
//-----------------------------------------------------------------------------
//  Purpose             : Acts as a bridging unit for the TraceOut block that
//                       feeds it with either data from the FIFO,
//                       Synchronisation packets or packets from the pattern
//                       generator.
//-----------------------------------------------------------------------------

module cxtpiu_trace_bridge (
  // Inputs
  traceclkin, tresetn, trace_d_accepted, fifo_empty, fifo_r_data, gen_data,
  trace_pattern, reg_update, form_sync_counter_reg, pattern_counter_reg,
  curr_patt_mode_reg, continous_mode, formatter_enable, ft_stopped_sync,
  // Outputs
  trace_d_valid, trace_d, pop_fifo, pattern_complete
  );

  // ---------------------------------------------------------------------------
  // Inputs and Outputs
  // ---------------------------------------------------------------------------

  // Clock and Reset
  input           traceclkin;             // Trace clock
  input           tresetn;                // Trace asychronous reset active low

  // TraceOut block interface
  output           trace_d_valid;         // indicate valid data present
  output [31:0]    trace_d;               // Data
  input            trace_d_accepted;      // response from block

  // FIFO interface
  input            fifo_empty;            // High when the FIFO is empty
  output           pop_fifo;              // data taken off the FIFO
  input [32:0]     fifo_r_data;           // Read data from the FIFO
                                          // (bit 33 indicates last word)

  // Pattern Generator Interface
  input [31:0]     gen_data;              // Data from the pattern generator
  input            trace_pattern;         // Pattern Generator running
  output           pattern_complete;      // instructs the PatternGenerator to shift
                                          // to the next desired pattern

  // Programming values
  input            reg_update;            // High when the reg values are updated
  input [11:0]     form_sync_counter_reg; // Trace Sync Counter reset value
  input [7:0]      pattern_counter_reg;   // Pattern Generator repeat counter
  input [1:0]      curr_patt_mode_reg;    // Pattern generator enables
  input            continous_mode;        //set if the formatter is running in Continuous Mode
  input            formatter_enable;      //set if the formatter is running
  input            ft_stopped_sync;       // Formatter Status

  // ---------------------------------------------------------------------------
  // Wire declarations
  // ---------------------------------------------------------------------------
  wire             trace_d_valid;         // indicate valid data present
  wire             trace_d_valid_int;

  // ---------------------------------------------------------------------------
  // Internal Signals
  // ---------------------------------------------------------------------------

  // Selection Control Logic
  wire             sync_insert;
  wire             fifo_data;

  // Mux Bridge / TraceOut interface
  wire             update_buffer;
  wire             buffer_empty;
  wire             pop_fifo;                // Acknowledge response to the Fifo
  wire             pop_fifo_int;

  // Sync Packet Generator
  wire             sync_type_en;            // Gate to update the SyncType flag
  reg              full_sync;               // Set at the end of a Formatter Frame,
                                            // cleared at the start of the next Frame
  reg              sync_insert_pending;     // Holding logic for sync packet output
  wire             nxt_sync_insert_pending; // Holding logic for sync packet output
  wire             sync_insert_pending_en;  // Holding logic for sync packet output

  wire [31:0]      sync_data;

  // Dual function Counter
  wire             dec_count_sync;
  wire             dec_count;
  wire [11:0]      reset_count;
  wire             restart_counter;
  wire             count_en;
  wire [11:0]      nxt_count;
  reg [11:0]       count;

  // Pattern Generator Control
  wire             pattern_complete;

  // Forcefully insert a sync at the beginning of a formatted Session
  wire             ft_restart;
  wire             ft_stopped_sync_reg_en;
  reg              ft_stopped_sync_reg;
  wire             force_sync;


  // ---------------------------------------------------------------------------
  // Selection Control Logic
  // ---------------------------------------------------------------------------
  // Pattern Gen overides all,
  // If operating in continuous then when the Fifo is empty, switch to the Sync
  //  packets,
  // If Sync counter reaches zero then insert a sync packet at the next 'end'
  //  flag.
  // if not running formatter and
  // either a)SyncCounter zero & End of Frame & Formatting enabled
  // or b) fifo_empty & in continuous & Formatting enabled
  // or c) A full sync packet is forcibly inserted at the beginning of a session
  // Note that in the case where the TraceOut block is busy (trace_d_accepted low)
  // the Sync Insertion needs to be pended until it can be serviced.


  assign sync_insert = (~trace_pattern &
                       (((count == {12{1'b0}}) & full_sync & (formatter_enable | continous_mode)) |
                        force_sync |
                        (fifo_empty & continous_mode)));

  // The sync_insert needs to be pended if it cannot be serviced the same cycle
  // in which sync_insert is pulsed.
  assign nxt_sync_insert_pending = ~sync_insert_pending & sync_insert & ~trace_d_accepted;
  assign sync_insert_pending_en = sync_insert_pending ? trace_d_accepted :
                                                   sync_insert & ~trace_d_accepted;

  always @(posedge traceclkin or negedge tresetn)
    begin
      if (~tresetn)
        sync_insert_pending <= 1'b0;
      else if (sync_insert_pending_en)
        sync_insert_pending <= nxt_sync_insert_pending;
    end

  // Take data from the Fifo if the pattern generator and Sync are not running
  assign fifo_data = ~(sync_insert | sync_insert_pending | trace_pattern);

  // ---------------------------------------------------------------------------
  // Mux Bridge / TraceOut interface
  // ---------------------------------------------------------------------------
  // This contains a single cycle buffer that temporarily holds onto the data
  // values to stop a combinatorial path being created.
  // Either a data packet from the FIFO or a sync packet or a pattern is
  // inserted into the buffer before being sent to the TraceOut block.

  // Select Data according to current operation
  assign trace_d = (({32{trace_pattern}} & gen_data)  | //Pattern generator
                   ({32{sync_insert | sync_insert_pending}} & sync_data) | //Sync packets
                   ({32{fifo_data}}     & fifo_r_data[31:0])); //Normal Fifo Data

  // Indicate valid data
  assign trace_d_valid_int = ((fifo_data & ~fifo_empty) |    //if the FIFO is not empty
                        sync_insert | sync_insert_pending |  //if inserting a syncpacket
                        trace_pattern);               //if using a pattern
  assign trace_d_valid = trace_d_valid_int;

  //Empty Tracking
  // Becomes empty when data is being taken out and no new data being placed in
  assign buffer_empty = trace_d_accepted & ~trace_d_valid_int;

  // Only update the registers when something is being added to the buffer or
  // being taken from it
  assign update_buffer = trace_d_accepted | buffer_empty;

  // Respond to the FIFO (when there is data in the FIFO and the sync counter
  // is not signalling a fullsync packet!)
  assign pop_fifo_int = fifo_data & trace_d_accepted & ~fifo_empty;
  assign pop_fifo = pop_fifo_int;

  // ---------------------------------------------------------------------------
  // Sync Packet Generator
  // ---------------------------------------------------------------------------
  // This logic determines which type of syncronisation packet should be
  // inserted by tracking the 'end' flag that is output on every word from the
  // Fifo (fifo_r_data[33]).

  // Only update when taking data from the Fifo or Forcing a Start Sync Packet
  assign sync_type_en = pop_fifo_int | force_sync;

  wire   nxt_full_sync;

  assign nxt_full_sync = fifo_r_data[32] | force_sync;

  // Track if in(0) or out(1) of a frame.
  always @(posedge traceclkin or negedge tresetn)
    if (!tresetn)
      full_sync <= 1'b1;
    else
      if (sync_type_en)
        full_sync <= nxt_full_sync;

  assign sync_data = full_sync ? { 1'b0, {31{1'b1}}} :  // Full Sync Packet
                               { 1'b0, {15{1'b1}}, 1'b0, {15{1'b1}}};
                                                      // dual, Half-word Sync

  // ---------------------------------------------------------------------------
  // Dual function Counter
  // ---------------------------------------------------------------------------
  // This counter acts as the Pattern Generator Countdown when this is operating
  // otherwise this becomes the Syncronisation counter under normal operations

  // Decrease the Counter when in Sync mode whenever a new packet appears in the
  // FIFO after a 'last' flag
  //assign dec_count_sync = full_sync & ~fifo_r_data[32];
  assign dec_count_sync = pop_fifo_int & ~full_sync & fifo_r_data[32];
  // Decrement due to Sync when not running patterns
  // or every cycle when running patterns
  assign dec_count = (dec_count_sync & ~trace_pattern) | trace_pattern;

  // If the pattern generator is running the reset the counter value to the
  // PatternCount Value, otherwise load in the Sync Counter value
  //assign reset_count = trace_pattern ?
  assign reset_count = |(curr_patt_mode_reg[1:0]) ?
                        {4'b0000, pattern_counter_reg} : form_sync_counter_reg;

  // Reset the counter when :
  // a) placing a full_sync packet into the buffer -or-
  // b) reaching zero (either from pattern or Sync) -or-
  // c) updating the register values
  // NB b- also causes the reload when finishing the patterns
  assign restart_counter = (full_sync & update_buffer & (sync_insert | sync_insert_pending)) | // a)
                          (count == {12{1'b0}})                  | // b)
                          reg_update;                               // c)

  // Run the counter on reset or decrement
  assign count_en = (restart_counter | dec_count);
  assign nxt_count = restart_counter ? reset_count : (count - 12'h001);

  // Current counter running
  always @(posedge traceclkin or negedge tresetn)
    if (!tresetn)
      count <= 12'h000;
    else
      if (count_en)
        count <= nxt_count;

  // ---------------------------------------------------------------------------
  // Pattern Generator Marker
  // ---------------------------------------------------------------------------
  // As the pattern repeat counter re-uses the SyncCounter, the bridge has to
  // indicate when a pattern has reached is alloted time length and so the next
  // pattern should be selected.

  // Indicate the pattern completion one cycle before the counter reaches
  // zero (to counter some register delays in the system)
  assign pattern_complete = (count == 12'b000000000001) & trace_pattern;


  // ---------------------------------------------------------------------------
  // Forcefully insertion of a sync packet at formatted start
  // ---------------------------------------------------------------------------
  // When the TPIU is programmed into Formatted mode, the first thing to
  // be output once the formatter starts should be a Full Sync Packet.
  // Therefore, the force_sync signal detects a change in the formatter
  // status in ft_stopped and the formatting mode

  assign ft_stopped_sync_reg_en = ft_stopped_sync != ft_stopped_sync_reg;
  assign ft_restart = ~ft_stopped_sync & ft_stopped_sync_reg & (formatter_enable | continous_mode);

  assign force_sync = ft_restart;

  always @(posedge traceclkin or negedge tresetn)
    begin
      if(!tresetn)
        ft_stopped_sync_reg <= 1'b0;
      else if(ft_stopped_sync_reg_en)
        ft_stopped_sync_reg <= ft_stopped_sync;
    end


endmodule // cxtpiu_trace_bridge
