//-----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2010-2015 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//  Version and Release Control Information:
//
//  Checked In          : $Date: 2015-01-29 15:49:43 +0000 (Thu, 29 Jan 2015) $
//  Revision	        : $Revision: 41305 $
//  Date	        : $Date: 2015-01-29 15:49:43 +0000 (Thu, 29 Jan 2015) $
//
//  Release Information : CoreSight-SoC-TM100-r3p2-00rel0
//-----------------------------------------------------------------------------

//----------------------------------------------------------------------------
//
//                               CXATBASYNCBRIDGE.v
//                              ================
//
//----------------------------------------------------------------------------
//
//  Overview
// ==========
//
// This component instantiates an ATBASYNCBRIDGE of configurable ATB_DATA_WIDTH and optional CLOCK_STOP feature
//
//
//----------------------------------------------------------------------------



//------------------------------------------------------------------------------
// Module Declaration
//------------------------------------------------------------------------------
module cxatbasyncbridge_64
  (
  //----------------------------------------------------------------------------
  // port definitions
  //----------------------------------------------------------------------------

 // Slave Port

  clks,        // ATB Bus clock for Slaveport
  clkens,      // ATB clock enable for slaveport
  resetsn,     // ATB Bus reset on slave side
  atvalids,    // ATB Bus transfer valid slave
  atids,       // ATB Bus id slave
  atbytess,    // ATB byte lane information
  atdatas,     // ATB Bus data slave
  afreadys,    // ATB Bus flush ready slave
  // Slave Port
  atreadys,    // ATB Bus transfer ready slave
  afvalids,    // ATB Bus flush valid slave
  syncreqs,     // Synchronization request
  
  // Master Port
  clkm,        // ATB Bus clock for Masterport
  clkenm,      // ATB clock enable for masterport
  resetmn,     // ATB Bus reset on Master side
  atreadym,    // ATB Bus transfer ready master
  afvalidm,    // ATB Bus flush valid master
  syncreqm,    // Synchronization request
  atvalidm,    // ATB Bus transfer valid master
  atidm,       // ATB Bus id master
  atbytesm,    // ATB byte lane information
  atdatam,     // ATB Bus data master
  afreadym     // ATB Bus flush ready master


);



  //----------------------------------------------------------------------------
  // parameters
  //----------------------------------------------------------------------------

  // calculated parameters (do not alter)

  localparam ATB_BYTES_WIDTH = 3;

  localparam ATB_DATA_WIDTH = 64;

  localparam DW = ATB_DATA_WIDTH - 1;
  localparam BW = ATB_BYTES_WIDTH - 1;

  localparam FIFO_DATA_WIDTH = BW+DW+9;



 // Slave Port

  input wire             clks;        // ATB Bus clock for Slaveport
  input wire             clkens;      // ATB clock enable for slaveport
  input wire             resetsn;     // ATB Bus reset on slave side
  input wire             atvalids;    // ATB Bus transfer valid slave
  input wire [6:0]       atids;       // ATB Bus id slave

  input wire [2:0]       atbytess;     // ATB byte lane information
  input wire [64-1:0]   atdatas;    // ATB Bus data slave
  input wire             afreadys;     // ATB Bus flush ready slave
  // Slave Port
  output wire            atreadys;     // ATB Bus transfer ready slave
  output wire            afvalids;     // ATB Bus flush valid slave
  output wire            syncreqs;     // Synchronization request

  // Master Port

  input wire             clkm;         // ATB Bus clock for Masterport
  input wire             clkenm;       // ATB clock enable for masterport
  input wire             resetmn;      // ATB Bus reset on Master side
  input wire             atreadym;     // ATB Bus transfer ready master
  input wire             afvalidm;     // ATB Bus flush valid master
  input wire             syncreqm;     // Synchronization request
  // Master Port
  output wire            atvalidm;     // ATB Bus transfer valid master
  output wire [6:0]      atidm;        // ATB Bus id master

  output wire [2:0]      atbytesm;     // ATB byte select master
  output wire [64-1:0]  atdatam;      // ATB Bus data master
  output wire            afreadym;     // ATB Bus flush ready master

  //----------------------------------------------------------------------------
  // WIRES AND REGS
  //----------------------------------------------------------------------------

  // Intermediate signals for connecting the modules
  wire [6*FIFO_DATA_WIDTH + 10 : 0] atb_fwd_data;
  wire [4:0]                  atb_rev_data;
  wire                        zero_pointer;
  wire                        syncreqs_req_async;
  wire                        syncreqs_ack_async;
  wire                        slv_safe_state_unused; 
  // ---------------------------------------------------------------------------
  // ATB Slave Interface
  // ---------------------------------------------------------------------------
  cxatbasyncbridge_slv_if_1 #(DW, BW, FIFO_DATA_WIDTH) u_cxatbasyncbridge_slv_if
    (
    // Inputs
    .atclks                            (clks),
    .atclkens                          (clkens),
    .atresetsn                         (resetsn),
    .atvalids                          (atvalids),
    .atids                             (atids),
    .atbytess                          (atbytess),
    .atdatas                           (atdatas),
    .afreadys                          (afreadys),
    .atb_fwd_data                      (atb_fwd_data),
    .atb_rev_data                      (atb_rev_data),
    .zero_pointer_d                    (zero_pointer),
    // Outputs
    .slv_safe_state                    (slv_safe_state_unused),
    .atreadys                          (atreadys),
    .afvalids                          (afvalids));

  // ---------------------------------------------------------------------------
  // ATB Master Interface
  // ---------------------------------------------------------------------------
  cxatbasyncbridge_mst_if_1 #(DW, BW, FIFO_DATA_WIDTH) u_cxatbasyncbridge_mst_if
    (
    // Inputs
    .atclkm                            (clkm),
    .atclkenm                          (clkenm),
    .atresetmn                         (resetmn),

    .atreadym                          (atreadym),
    .afvalidm                          (afvalidm),
    .atb_fwd_data                      (atb_fwd_data),
    .atb_rev_data                      (atb_rev_data),
    // Outputs
    .atvalidm                          (atvalidm),
    .atbytesm                          (atbytesm),
    .atidm                             (atidm),
    .atdatam                           (atdatam),
    .afreadym                          (afreadym),

    .zero_pointer                      (zero_pointer));

  // ---------------------------------------------------------------------------
  // syncreqs domain
  // ---------------------------------------------------------------------------
cxatbasyncbridge_syncreqs_domain_1
  u_cxatbasyncbridge_syncreqs_domain (
                     .syncreqs_req_async (syncreqs_req_async),
                     .syncreqs_ack_async (syncreqs_ack_async),
                     
                     .syncreqs           (syncreqs),
                     .clkens             (clkens),
                     .clks               (clks),
                     .resetsn            (resetsn)
                                   );

  // ---------------------------------------------------------------------------
  // syncreqm domain
  // ---------------------------------------------------------------------------
cxatbasyncbridge_syncreqm_domain_1
  u_cxatbasyncbridge_syncreqm_domain (
                     .syncreqs_req_async       (syncreqs_req_async),
                     .syncreqs_ack_async       (syncreqs_ack_async),
                     
                     .syncreqm                 (syncreqm),
                     .clkm                     (clkm),
                     .clkenm                   (clkenm),
                     .resetmn                  (resetmn)
                                   );


`ifdef ARM_ASSERT_ON
  //----------------------------------------------------------------------------
  // OVL Assertions
  //----------------------------------------------------------------------------




`endif
endmodule // cxatbasyncbridge
