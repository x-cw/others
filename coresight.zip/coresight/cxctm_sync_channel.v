//--========================================================================
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2003-2015 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//    Checked In : $Date: 2014-08-14 16:01:35 +0100 (Thu, 14 Aug 2014) $
//    Revision   : $Revision: 39945 $
//    Release    : CoreSight-SoC-TM100-r3p2-00rel0
//-----------------------------------------------------------------------------
// Purpose :
//           ECT Channel Synchroniser Module
//
// --=========================================================================--

module cxctm_sync_channel
  (
  // Inputs
  ctmresetn, ctmclk, ctmclken, ctmchin, ctmchoutack,
  // Outputs
  ctm_chin_sync_2, ctm_chout_ack_sync_2
  );

`include "cxctm_constants.v"

  //----------------------------------------------------------------------------
  // INPUTS
  //----------------------------------------------------------------------------
  input                         ctmresetn;    // Reset
  input                         ctmclk;       // Clock
  input                         ctmclken;     // Clock Enable

  input [ECTCHANNELWIDTH-1:0]   ctmchin;      // Channel In port
  input [ECTCHANNELWIDTH-1:0]   ctmchoutack;  // Channel Out ACK port

  //----------------------------------------------------------------------------
  // OUTPUTS
  //----------------------------------------------------------------------------

  output [ECTCHANNELWIDTH-1:0]  ctm_chin_sync_2;      // ctmchin sync output
  output [ECTCHANNELWIDTH-1:0]  ctm_chout_ack_sync_2; // CTMCHOUT ACK sync output

  //----------------------------------------------------------------------------
  // WIRES
  //----------------------------------------------------------------------------

  wire [ECTCHANNELWIDTH-1:0] ctmchin_corrupt;
  wire [ECTCHANNELWIDTH-1:0] ctmchoutack_corrupt;

  //----------------------------------------------------------------------------
  // MAIN CODE
  //----------------------------------------------------------------------------
  // Instantiate synchronisers explicitly (using sub-module)

`ifdef ARM_CDC_CHECK
  cx_en_cdc_corrupt_gry #(1) u_cdc_corrupt_ctmchin0
  (
    .clk       (ctmclk),
    .resetn    (ctmresetn),
    .clken     (ctmclken),
    .sync      (1'b0),
    .d_async   (ctmchin[0]),
    .q_async   (ctmchin_corrupt[0])
  );

  cx_en_cdc_corrupt_gry #(1) u_cdc_corrupt_ctmchin1
  (
    .clk       (ctmclk),
    .resetn    (ctmresetn),
    .clken     (ctmclken),
    .sync      (1'b0),
    .d_async   (ctmchin[1]),
    .q_async   (ctmchin_corrupt[1])
  );

  cx_en_cdc_corrupt_gry #(1) u_cdc_corrupt_ctmchin2
  (
    .clk       (ctmclk),
    .resetn    (ctmresetn),
    .clken     (ctmclken),
    .sync      (1'b0),
    .d_async   (ctmchin[2]),
    .q_async   (ctmchin_corrupt[2])
  );

  cx_en_cdc_corrupt_gry #(1) u_cdc_corrupt_ctmchin3
  (
    .clk       (ctmclk),
    .resetn    (ctmresetn),
    .clken     (ctmclken),
    .sync      (1'b0),
    .d_async   (ctmchin[3]),
    .q_async   (ctmchin_corrupt[3])
  );

  cx_en_cdc_corrupt_gry #(1) u_cdc_corrupt_ctmchoutack0
  (
    .clk       (ctmclk),
    .resetn    (ctmresetn),
    .clken     (ctmclken),
    .sync      (1'b0),
    .d_async   (ctmchoutack[0]),
    .q_async   (ctmchoutack_corrupt[0])
  );

  cx_en_cdc_corrupt_gry #(1) u_cdc_corrupt_ctmchoutack1
  (
    .clk       (ctmclk),
    .resetn    (ctmresetn),
    .clken     (ctmclken),
    .sync      (1'b0),
    .d_async   (ctmchoutack[1]),
    .q_async   (ctmchoutack_corrupt[1])
  );

  cx_en_cdc_corrupt_gry #(1) u_cdc_corrupt_ctmchoutack2
  (
    .clk       (ctmclk),
    .resetn    (ctmresetn),
    .clken     (ctmclken),
    .sync      (1'b0),
    .d_async   (ctmchoutack[2]),
    .q_async   (ctmchoutack_corrupt[2])
  );

  cx_en_cdc_corrupt_gry #(1) u_cdc_corrupt_ctmchoutack3
  (
    .clk       (ctmclk),
    .resetn    (ctmresetn),
    .clken     (ctmclken),
    .sync      (1'b0),
    .d_async   (ctmchoutack[3]),
    .q_async   (ctmchoutack_corrupt[3])
  );

`else

  assign ctmchin_corrupt      = ctmchin;
  assign ctmchoutack_corrupt  = ctmchoutack;

`endif

  // ---------------------------------------------------------------------------
  // Instantiating the cx_sync module for synchronizing ctmchin[0] bit.
  // ---------------------------------------------------------------------------
  cx_en_sync u_channel_in_sync_0
    (
     // Outputs
     .sync_do          (ctm_chin_sync_2[0]),
     // Inputs
     .clk              (ctmclk),
     .clken            (ctmclken),
     .resetn           (ctmresetn),
     .sync_di          (ctmchin_corrupt[0])
     );

  // ---------------------------------------------------------------------------
  // Instantiating the cx_sync module for synchronizing ctmchin[1] bit.
  // ---------------------------------------------------------------------------
  cx_en_sync u_channel_in_sync_1
    (
     // Outputs
     .sync_do          (ctm_chin_sync_2[1]),
     // Inputs
     .clk              (ctmclk),
     .clken            (ctmclken),
     .resetn           (ctmresetn),
     .sync_di          (ctmchin_corrupt[1])
     );

  // ---------------------------------------------------------------------------
  // Instantiating the cx_sync module for synchronizing ctmchin[2] bit.
  // ---------------------------------------------------------------------------
  cx_en_sync u_channel_in_sync_2
    (
     // Outputs
     .sync_do          (ctm_chin_sync_2[2]),
     // Inputs
     .clk              (ctmclk),
     .clken            (ctmclken),
     .resetn           (ctmresetn),
     .sync_di          (ctmchin_corrupt[2])
     );

  // ---------------------------------------------------------------------------
  // Instantiating the cx_sync module for synchronizing ctmchin[3] bit.
  // ---------------------------------------------------------------------------
  cx_en_sync u_channel_in_sync_3
    (
     // Outputs
     .sync_do          (ctm_chin_sync_2[3]),
     // Inputs
     .clk              (ctmclk),
     .clken            (ctmclken),
     .resetn           (ctmresetn),
     .sync_di          (ctmchin_corrupt[3])
     );

  // ---------------------------------------------------------------------------
  // Instantiating the cx_sync module for synchronizing ctmchoutack[0] bit.
  // ---------------------------------------------------------------------------
  cx_en_sync u_channel_out_ack_sync_0
    (
     // Outputs
     .sync_do          (ctm_chout_ack_sync_2[0]),
     // Inputs
     .clk              (ctmclk),
     .clken            (ctmclken),
     .resetn           (ctmresetn),
     .sync_di          (ctmchoutack_corrupt[0])
     );

  // ---------------------------------------------------------------------------
  // Instantiating the cx_sync module for synchronizing ctmchoutack[1] bit.
  // ---------------------------------------------------------------------------
  cx_en_sync u_channel_out_ack_sync_1
    (
     // Outputs
     .sync_do          (ctm_chout_ack_sync_2[1]),
     // Inputs
     .clk              (ctmclk),
     .clken            (ctmclken),
     .resetn           (ctmresetn),
     .sync_di          (ctmchoutack_corrupt[1])
     );

  // ---------------------------------------------------------------------------
  // Instantiating the cx_sync module for synchronizing ctmchoutack[2] bit.
  // ---------------------------------------------------------------------------
  cx_en_sync u_channel_out_ack_sync_2
    (
     // Outputs
     .sync_do          (ctm_chout_ack_sync_2[2]),
     // Inputs
     .clk              (ctmclk),
     .clken            (ctmclken),
     .resetn           (ctmresetn),
     .sync_di          (ctmchoutack_corrupt[2])
     );

  // ---------------------------------------------------------------------------
  // Instantiating the cx_sync module for synchronizing ctmchoutack[3] bit.
  // ---------------------------------------------------------------------------
  cx_en_sync u_channel_out_ack_sync_3
    (
     // Outputs
     .sync_do          (ctm_chout_ack_sync_2[3]),
     // Inputs
     .clk              (ctmclk),
     .clken            (ctmclken),
     .resetn           (ctmresetn),
     .sync_di          (ctmchoutack_corrupt[3])
     );


endmodule // cxctm_sync_channel
