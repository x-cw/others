//-----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2004-2015 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//    Checked In : $Date: 2015-03-13 15:57:52 +0000 (Fri, 13 Mar 2015) $
//    Revision   : $Revision: 42144 $
//    Release    : CoreSight-SoC-TM100-r3p2-00rel0
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// Abstract : CoreSight Trace Port Interface (cxtpiu) - Top Level Block
//-----------------------------------------------------------------------------
//
// cxtpiu - CoreSight Trace Port Interface Unit
// --------------------------------------------
//
// CoreSight AMBA Trace Bus (ATB) device used to drain trace data and acts as
// a bridge between the on-chip trace data and the data stream captured by a
// Trace Port Analyser(TPA).
//
// cxtpiu.v
// --------
//
// cxtpiu.v provides the instantiations of all modules for the cxtpiu.
//
// Instantiated blocks
// -------------------
//
// cxtpiu_apb_if.v        - APB Interface Module
// cxtpiu_reg_a.v         - atclk Domain Register Module
// cxtpiu_reg_p.v         - pclkdbg Domain Register Module
// cxtpiu_reg_t.v         - traceclkin Domain Register Module
// cxtpiu_ft_ctl.v        - ATB Formatter Control Logic Module
// cxtpiu_formatter.v        - ATB Formatter Module
// cxtpiu_atb_fifo.v      - ATBCLK side FIFO Module
// cxtpiu_trace_fifo.v    - traceclkin side FIFO Module
// cxtpiu_trace_bridge.v  - traceclkin Bridge Unit Module
// cxtpiu_trace_pattern.v - traceclkin Pattern Generator Module
// cxtpiu_trace_out.v     - traceclkin side Output Module
// cxtpiu_trace_clk.v     - traceclkin side Clock Output Module
// cxtpiu_apb_sync.v      - APB Clock Domain Side Synchronizers
// cxtpiu_atb_sync.v      - ATB Clock Domain Side Synchronizers
// cxtpiu_trace_sync.v    - traceclkin Clock Domain Side Synchronizers
//-----------------------------------------------------------------------------

module cxtpiu (
  // Inputs
  atclk, pclkdbg, traceclkin, atclken, pclkendbg, atresetn,
  presetdbgn, tresetn, atvalids, afreadys, atbytess, atids, atdatas,
  pwritedbg, penabledbg, pseldbg, paddrdbg, paddrdbg31, pwdatadbg,
  trigin, flushin, extctlin, tpctl, tpmaxdatasize,
  // Outputs
  atreadys, afvalids, prdatadbg, preadydbg, traceclk, tracedata,
  tracectl, triginack, flushinack, extctlout
  );

  // Inputs
  input                 atclk;        // ATB clock
  input                 pclkdbg;      // APB clock
  input                 traceclkin;   // TRACEIN clock
  input                 atclken;      // ATB clock enable
  input                 pclkendbg;    // APB clock enable
  input                 atresetn;     // ATB asychronous reset active low
  input                 presetdbgn;   // APB asychronous reset active low
  input                 tresetn;      // traceclkin asychronous reset active low

  input                 atvalids;     // ATB valid signal
  input                 afreadys;     // ATB flush ready signal
  input [1:0]           atbytess;     // ATB bytes
  input [6:0]           atids;        // ATB ID
  input [31:0]          atdatas;      // ATB data

  input                 pwritedbg;    // APB write or read
  input                 penabledbg;   // APB enable
  input                 pseldbg;      // APB slave select
  input [11:2]          paddrdbg;     // APB address bus
  input                 paddrdbg31;   // APB dual mem-map (HIGH from APB-AP)
  input [31:0]          pwdatadbg;    // APB write data bus

  input                 trigin;       // Trigger input from the CTI
  input                 flushin;      // Flush input from the CTI
  input [7:0]           extctlin;     // External control input

  input                 tpctl;        // Tie-off to report presence of tracectl
  input [4:0]           tpmaxdatasize;// Tie-off to report Maximum no. of pins
                                      //  for tracedata[x:0]
                                      //  where (x + 1) = TPMAXDATAWIDTH
  // Outputs
  output                atreadys;     // ATB ready signal
  output                afvalids;     // ATB flush signal

  output [31:0]         prdatadbg;    // APB read data bus
  output                preadydbg;    // APB Ready Acknowledgement

  output                traceclk;     // traceclk output
  output [31:0]         tracedata;    // Trace Data
  output                tracectl;     // Trace Control

  output                triginack;    // Return response to trigin
  output                flushinack;   // Return response to flushin
  output [7:0]          extctlout;    // External control output

  // Beginning of automatic wires (for undeclared instantiated-module outputs)
  wire                  afready_reg;             // From u_cxtpiu_ft_ctl of cxtpiu_ft_ctl.v
  wire                  continous_mode;          // From u_cxtpiu_trace_sync of cxtpiu_trace_sync.v
  wire [1:0]            curr_patt_mode_reg;      // From u_cxtpiu_reg_t of cxtpiu_reg_t.v
  wire [3:0]            curr_patt_sel_reg;       // From u_cxtpiu_reg_t of cxtpiu_reg_t.v
  wire [31:0]           curr_port_sel_reg;       // From u_cxtpiu_reg_t of cxtpiu_reg_t.v
  wire                  device_un_locked;        // From u_cxtpiu_reg_p of cxtpiu_reg_p.v
  wire                  flushin_sync;            // From u_cxtpiu_atb_sync of cxtpiu_atb_sync.v
  wire                  f_on_man_active;         // From u_cxtpiu_ft_ctl of cxtpiu_ft_ctl.v
  wire                  f_on_man_clr;            // From u_cxtpiu_ft_ctl of cxtpiu_ft_ctl.v
  wire                  ffcr_f_on_man_reg;       // From u_cxtpiu_reg_a of cxtpiu_reg_a.v
  wire [1:0]            ffcr_flsh_reg;           // From u_cxtpiu_reg_p of cxtpiu_reg_p.v
  wire [1:0]            ffcr_ften_reg;           // From u_cxtpiu_reg_p of cxtpiu_reg_p.v
  wire [1:0]            ffcr_stop_reg;           // From u_cxtpiu_reg_p of cxtpiu_reg_p.v
  wire [2:0]            ffcr_trig_reg;           // From u_cxtpiu_reg_p of cxtpiu_reg_p.v
  wire [32:0]           fifo_data_0;             // From u_cxtpiu_atb_fifo of cxtpiu_atb_fifo.v
  wire [32:0]           fifo_data_1;             // From u_cxtpiu_atb_fifo of cxtpiu_atb_fifo.v
  wire [32:0]           fifo_data_2;             // From u_cxtpiu_atb_fifo of cxtpiu_atb_fifo.v
  wire [32:0]           fifo_data_3;             // From u_cxtpiu_atb_fifo of cxtpiu_atb_fifo.v
  wire [32:0]           fifo_data_4;             // From u_cxtpiu_atb_fifo of cxtpiu_atb_fifo.v
  wire [32:0]           fifo_data_5;             // From u_cxtpiu_atb_fifo of cxtpiu_atb_fifo.v
  wire                  fifo_empty;              // From u_cxtpiu_trace_fifo of cxtpiu_trace_fifo.v
  wire [32:0]           fifo_r_data;             // From u_cxtpiu_trace_fifo of cxtpiu_trace_fifo.v
  wire [11:0]           form_sync_counter_reg;   // From u_cxtpiu_reg_t of cxtpiu_reg_t.v
  wire                  formatter_enable;        // From u_cxtpiu_trace_sync of cxtpiu_trace_sync.v
  wire [31:0]           ft_data;                 // From u_cxtpiu_formatter of cxtpiu_formatter.v
  wire                  ft_data_rdy;             // From u_cxtpiu_atb_fifo of cxtpiu_atb_fifo.v
  wire                  ft_data_valid;           // From u_cxtpiu_formatter of cxtpiu_formatter.v
  wire                  ft_enable;               // From u_cxtpiu_ft_ctl of cxtpiu_ft_ctl.v
  wire                  ft_last_word;            // From u_cxtpiu_formatter of cxtpiu_formatter.v
  wire                  ft_stop_req;             // From u_cxtpiu_ft_ctl of cxtpiu_ft_ctl.v
  wire                  ft_stopped;              // From u_cxtpiu_formatter of cxtpiu_formatter.v
  wire                  ft_stopped_sync;         // From u_cxtpiu_trace_sync of cxtpiu_trace_sync.v
  wire                  ft_trig_ack;             // From u_cxtpiu_formatter of cxtpiu_formatter.v
  wire                  ft_trig_req;             // From u_cxtpiu_ft_ctl of cxtpiu_ft_ctl.v
  wire [31:0]           gen_data;                // From u_cxtpiu_trace_pattern of cxtpiu_trace_pattern.v
  wire                  itc_r_reg;               // From u_cxtpiu_reg_p of cxtpiu_reg_p.v
  wire [6:0]            it_atb_ctr_1_reg;        // From u_cxtpiu_formatter of cxtpiu_formatter.v
  wire                  it_atb_ctr_2_afv_reg;    // From u_cxtpiu_reg_a of cxtpiu_reg_a.v
  wire                  it_atb_ctr_2_atr_reg;    // From u_cxtpiu_reg_a of cxtpiu_reg_a.v
  wire [4:0]            it_atb_dat_0_reg;        // From u_cxtpiu_formatter of cxtpiu_formatter.v
  wire                  it_ctr_0_atv_reg;        // From u_cxtpiu_formatter of cxtpiu_formatter.v
  wire [1:0]            it_ctr_0_byt_reg;        // From u_cxtpiu_formatter of cxtpiu_formatter.v
  wire [1:0]            it_tr_fl_in_ack_reg;     // From u_cxtpiu_reg_a of cxtpiu_reg_a.v
  wire                  pattern_complete;        // From u_cxtpiu_trace_bridge of cxtpiu_trace_bridge.v
  wire [7:0]            pattern_counter_reg;     // From u_cxtpiu_reg_t of cxtpiu_reg_t.v
  wire                  pattern_done;            // From u_cxtpiu_trace_pattern of cxtpiu_trace_pattern.v
  wire                  pop_fifo;                // From u_cxtpiu_trace_bridge of cxtpiu_trace_bridge.v
  wire [3:0]            rd_ptr_gray;             // From u_cxtpiu_trace_fifo of cxtpiu_trace_fifo.v
  wire [3:0]            rd_ptr_gray_sync;        // From u_cxtpiu_atb_sync of cxtpiu_atb_sync.v
  wire                  rd_wr_ack_t;             // From u_cxtpiu_reg_t of cxtpiu_reg_t.v
  wire                  rd_wr_ack_t_sync;        // From u_cxtpiu_apb_sync of cxtpiu_apb_sync.v
  wire                  rd_wr_req_t;             // From u_cxtpiu_apb_if of cxtpiu_apb_if.v
  wire                  rd_wr_req;               // From u_cxtpiu_apb_if of cxtpiu_apb_if.v
  wire                  rd_wr_req_t_sync;        // From u_cxtpiu_trace_sync of cxtpiu_trace_sync.v
  wire [31:0]           read_data_a;             // From u_cxtpiu_reg_a of cxtpiu_reg_a.v
  wire [31:0]           read_data_p;             // From u_cxtpiu_reg_p of cxtpiu_reg_p.v
  wire [31:0]           read_data_t;             // From u_cxtpiu_reg_t of cxtpiu_reg_t.v
  wire                  reg_update;              // From u_cxtpiu_reg_t of cxtpiu_reg_t.v
  wire                  trigin_sync;             // From u_cxtpiu_atb_sync of cxtpiu_atb_sync.v
  wire [31:0]           trace_d;                 // From u_cxtpiu_trace_bridge of cxtpiu_trace_bridge.v
  wire                  trace_d_accepted;        // From u_cxtpiu_trace_out of cxtpiu_trace_out.v
  wire                  trace_d_valid;           // From u_cxtpiu_trace_bridge of cxtpiu_trace_bridge.v
  wire                  trace_pattern;           // From u_cxtpiu_trace_pattern of cxtpiu_trace_pattern.v
  wire                  trg_count_off;           // From u_cxtpiu_reg_a of cxtpiu_reg_a.v
  wire                  trg_one;                 // From u_cxtpiu_reg_a of cxtpiu_reg_a.v
  wire                  trg_running;             // From u_cxtpiu_reg_a of cxtpiu_reg_a.v
  wire                  trig_in_detect;          // From u_cxtpiu_ft_ctl of cxtpiu_ft_ctl.v
  wire                  trig_port;               // From u_cxtpiu_ft_ctl of cxtpiu_ft_ctl.v
  wire                  trig_port_done_sync;     // From u_cxtpiu_atb_sync of cxtpiu_atb_sync.v
  wire                  trig_port_sync;          // From u_cxtpiu_trace_sync of cxtpiu_trace_sync.v
  wire                  triggered;              // From u_cxtpiu_reg_a of cxtpiu_reg_a.v
  wire [3:0]            wr_ptr_gray;             // From u_cxtpiu_atb_fifo of cxtpiu_atb_fifo.v
  wire [3:0]            wr_ptr_gray_sync;        // From u_cxtpiu_trace_sync of cxtpiu_trace_sync.v

  wire                  afvalids_int;            // Internal version of afvalids

  //---------------------------------------------------------------------------
  // Registered APB signals
  //---------------------------------------------------------------------------
  wire           [11:2] paddrdbg_reg;           // Programming address
  wire                  paddrdbg31_reg;         // Programming address
  wire                  pwritedbg_reg;          // This access is a write transfer
  wire           [31:0] pwdatadbg_reg;          // Write data bus

  // ---------------------------------------------------------------------------
  // APB Interface
  // ---------------------------------------------------------------------------
  // Handles the control signals from the APB interface to the various register
  // banks, contains the read_data output register and preadydbg control.
  cxtpiu_apb_if u_cxtpiu_apb_if
    (
     // Outputs
     .rd_wr_req                         (rd_wr_req),
     .rd_wr_req_t                       (rd_wr_req_t),
     .preadydbg                         (preadydbg),
     .prdatadbg                         (prdatadbg[31:0]),
     .paddrdbg_reg                      (paddrdbg_reg),
     .paddrdbg31_reg                    (paddrdbg31_reg),
     .pwritedbg_reg                     (pwritedbg_reg),
     .pwdatadbg_reg                     (pwdatadbg_reg),

     // Inputs
     .pclkdbg                           (pclkdbg),
     .pclkendbg                         (pclkendbg),
     .presetdbgn                        (presetdbgn),
     .pwritedbg                         (pwritedbg),
     .penabledbg                        (penabledbg),
     .pseldbg                           (pseldbg),
     .rd_wr_ack_t_sync                  (rd_wr_ack_t_sync),
     .paddrdbg                          (paddrdbg[11:2]),
     .paddrdbg31                        (paddrdbg31),
     .pwdatadbg                         (pwdatadbg),
     .read_data_a                       (read_data_a[31:0]),
     .read_data_p                       (read_data_p[31:0]),
     .read_data_t                       (read_data_t[31:0]));

  // ---------------------------------------------------------------------------
  // Register Module For The atclk Domain
  // ---------------------------------------------------------------------------
  // Contains the registers in the atclk domain.
  cxtpiu_reg_a u_cxtpiu_reg_a
    (
     // Outputs
     .read_data_a                       (read_data_a[31:0]),
     .trg_one                           (trg_one),
     .trg_count_off                     (trg_count_off),
     .ffcr_f_on_man_reg                 (ffcr_f_on_man_reg),
     .trg_running                       (trg_running),
     .triggered                         (triggered),
     .extctlout                         (extctlout[7:0]),
     .it_atb_ctr_2_atr_reg              (it_atb_ctr_2_atr_reg),
     .it_tr_fl_in_ack_reg               (it_tr_fl_in_ack_reg[1:0]),
     .it_atb_ctr_2_afv_reg              (it_atb_ctr_2_afv_reg),
     // Inputs
     .atclk                             (atclk),
     .atclken                           (atclken),
     .atresetn                          (atresetn),
     .afvalids                          (afvalids_int),
     .pwritedbg                         (pwritedbg_reg),
     .rd_wr_req                         (rd_wr_req),
     .ft_stopped                        (ft_stopped),
     .paddrdbg                          (paddrdbg_reg[11:2]),
     .paddrdbg31                        (paddrdbg31_reg),
     .pwdatadbg                         (pwdatadbg_reg[7:0]),
     .device_un_locked                  (device_un_locked),
     .extctlin                          (extctlin[7:0]),
     .trig_in_detect                    (trig_in_detect),
     .ft_data_valid                     (ft_data_valid),
     .f_on_man_active                   (f_on_man_active),
     .f_on_man_clr                      (f_on_man_clr),
     .it_atb_ctr_1_reg                  (it_atb_ctr_1_reg[6:0]),
     .it_atb_dat_0_reg                  (it_atb_dat_0_reg[4:0]),
     .it_ctr_0_byt_reg                  (it_ctr_0_byt_reg[1:0]),
     .it_ctr_0_atv_reg                  (it_ctr_0_atv_reg),
     .trigin_sync                       (trigin_sync),
     .flushin_sync                      (flushin_sync),
     .afready_reg                       (afready_reg),
     .tpctl                             (tpctl));

  // ---------------------------------------------------------------------------
  // Register Module For The pclkdbg Domain
  // ---------------------------------------------------------------------------
  // Contains the registers in the pclkdbg domain.
  cxtpiu_reg_p u_cxtpiu_reg_p
    (
     // Outputs
     .ffcr_stop_reg                     (ffcr_stop_reg[1:0]),
     .ffcr_trig_reg                     (ffcr_trig_reg[2:0]),
     .ffcr_flsh_reg                     (ffcr_flsh_reg[1:0]),
     .ffcr_ften_reg                     (ffcr_ften_reg[1:0]),
     .read_data_p                       (read_data_p[31:0]),
     .itc_r_reg                         (itc_r_reg),
     .device_un_locked                  (device_un_locked),
     // Inputs
     .pclkdbg                           (pclkdbg),
     .pclkendbg                         (pclkendbg),
     .presetdbgn                        (presetdbgn),
     .pwritedbg                         (pwritedbg_reg),
     .rd_wr_req                         (rd_wr_req),
     .paddrdbg                          (paddrdbg_reg[11:2]),
     .paddrdbg31                        (paddrdbg31_reg),
     .pwdatadbg                         (pwdatadbg_reg[31:0]),
     .ffcr_f_on_man_reg                 (ffcr_f_on_man_reg),
     .trg_running                       (trg_running),
     .triggered                         (triggered),
     .tpmaxdatasize                     (tpmaxdatasize[4:0]));

  // ---------------------------------------------------------------------------
  // Register Module For The traceclkin Domain
  // ---------------------------------------------------------------------------
  // Contains the registers in the traceclkin domain.
  cxtpiu_reg_t u_cxtpiu_reg_t
    (
     // Outputs
     .rd_wr_ack_t                       (rd_wr_ack_t),
     .reg_update                        (reg_update),
     .pattern_counter_reg               (pattern_counter_reg[7:0]),
     .form_sync_counter_reg             (form_sync_counter_reg[11:0]),
     .curr_patt_sel_reg                 (curr_patt_sel_reg[3:0]),
     .curr_patt_mode_reg                (curr_patt_mode_reg[1:0]),
     .curr_port_sel_reg                 (curr_port_sel_reg[31:0]),
     .read_data_t                       (read_data_t[31:0]),
     // Inputs
     .traceclkin                        (traceclkin),
     .tresetn                           (tresetn),
     .pwritedbg                         (pwritedbg_reg),
     .paddrdbg31                        (paddrdbg31_reg),
     .device_un_locked                  (device_un_locked),
     .rd_wr_req_t_sync                  (rd_wr_req_t_sync),
     .paddrdbg                          (paddrdbg_reg[11:2]),
     .pwdatadbg                         (pwdatadbg_reg[31:0]),
     .pattern_done                      (pattern_done));

  // ---------------------------------------------------------------------------
  // Formatter Control Logic
  // ---------------------------------------------------------------------------
  // Logic for controlling the formatter either to enable formatting,embed
  // triggers or stop formatting.
  cxtpiu_ft_ctl u_cxtpiu_ft_ctl
    (
     // Outputs
     .afvalids                          (afvalids_int),
     .triginack                         (triginack),
     .flushinack                        (flushinack),
     .trig_in_detect                    (trig_in_detect),
     .trig_port                         (trig_port),
     .f_on_man_clr                      (f_on_man_clr),
     .ft_enable                         (ft_enable),
     .ft_trig_req                       (ft_trig_req),
     .ft_stop_req                       (ft_stop_req),
     .f_on_man_active                   (f_on_man_active),
     .afready_reg                       (afready_reg),
     // Inputs
     .atclk                             (atclk),
     .atclken                           (atclken),
     .atresetn                          (atresetn),
     .afreadys                          (afreadys),
     .trigin_sync                       (trigin_sync),
     .flushin_sync                      (flushin_sync),
     .ffcr_stop_reg                     (ffcr_stop_reg[1:0]),
     .ffcr_trig_reg                     (ffcr_trig_reg[2:0]),
     .ffcr_flsh_reg                     (ffcr_flsh_reg[1:0]),
     .ffcr_f_on_man_reg                 (ffcr_f_on_man_reg),
     .ffcr_ften_reg                     (ffcr_ften_reg[1:0]),
     .trg_count_off                     (trg_count_off),
     .trg_one                           (trg_one),
     .itc_r_reg                         (itc_r_reg),
     .it_tr_fl_in_ack_reg               (it_tr_fl_in_ack_reg[1:0]),
     .it_atb_ctr_2_afv_reg              (it_atb_ctr_2_afv_reg),
     .ft_stopped                        (ft_stopped),
     .ft_trig_ack                       (ft_trig_ack),
     .trig_port_done_sync               (trig_port_done_sync));

  assign afvalids = afvalids_int;

  // ---------------------------------------------------------------------------
  // Formatter
  // ---------------------------------------------------------------------------
  // Logic for embedding the trace source ID within the DATA to create a single
  // trace stream.

  cxtpiu_formatter u_cxtpiu_formatter
    (
     // Outputs
     .atreadys                          (atreadys),
     .ft_data_valid                     (ft_data_valid),
     .ft_last_word                      (ft_last_word),
     .ft_trig_ack                       (ft_trig_ack),
     .ft_stopped                        (ft_stopped),
     .ft_data                           (ft_data[31:0]),
     .it_ctr_0_atv_reg                  (it_ctr_0_atv_reg),
     .it_ctr_0_byt_reg                  (it_ctr_0_byt_reg[1:0]),
     .it_atb_dat_0_reg                  (it_atb_dat_0_reg[4:0]),
     .it_atb_ctr_1_reg                  (it_atb_ctr_1_reg[6:0]),
     // Inputs
     .atclk                             (atclk),
     .atclken                           (atclken),
     .atresetn                          (atresetn),
     .atvalids                          (atvalids),
     .atbytess                          (atbytess[1:0]),
     .atids                             (atids[6:0]),
     .atdatas                           (atdatas[31:0]),
     .ft_enable                         (ft_enable),
     .ft_data_rdy                       (ft_data_rdy),
     .ft_trig_req                       (ft_trig_req),
     .ft_stop_req                       (ft_stop_req),
     .itc_r_reg                         (itc_r_reg),
     .it_atb_ctr_2_atr_reg              (it_atb_ctr_2_atr_reg));

  // ---------------------------------------------------------------------------
  // atclk Domain FIFO Interface
  // ---------------------------------------------------------------------------
  // FIFO Write Interface on the traceclkin domain.The Formatter writes to
  // this interface.
  cxtpiu_atb_fifo u_cxtpiu_atb_fifo
    (// Inputs
     .write_data                        ({ft_last_word,ft_data[31:0]}),
     // Outputs
     .ft_data_rdy                       (ft_data_rdy),
     .wr_ptr_gray                       (wr_ptr_gray[3:0]),
     .fifo_data_0                       (fifo_data_0[32:0]),
     .fifo_data_1                       (fifo_data_1[32:0]),
     .fifo_data_2                       (fifo_data_2[32:0]),
     .fifo_data_3                       (fifo_data_3[32:0]),
     .fifo_data_4                       (fifo_data_4[32:0]),
     .fifo_data_5                       (fifo_data_5[32:0]),
     // Inputs
     .atclk                             (atclk),
     .atclken                           (atclken),
     .atresetn                          (atresetn),
     .ft_data_valid                     (ft_data_valid),
     .rd_ptr_gray_sync                  (rd_ptr_gray_sync[3:0]));

  // ---------------------------------------------------------------------------
  // traceclkin Domain FIFO Interface
  // ---------------------------------------------------------------------------
  // FIFO Read Interface on the traceclkin domain.The TraceBridge module reads
  // from this interface.
  cxtpiu_trace_fifo u_cxtpiu_trace_fifo
    (
     // Outputs
     .fifo_empty                        (fifo_empty),
     .rd_ptr_gray                       (rd_ptr_gray[3:0]),
     .fifo_r_data                       (fifo_r_data[32:0]),
     // Inputs
     .traceclkin                        (traceclkin),
     .tresetn                           (tresetn),
     .pop_fifo                          (pop_fifo),
     .wr_ptr_gray_sync                  (wr_ptr_gray_sync[3:0]),
     .fifo_data_0                       (fifo_data_0[32:0]),
     .fifo_data_1                       (fifo_data_1[32:0]),
     .fifo_data_2                       (fifo_data_2[32:0]),
     .fifo_data_3                       (fifo_data_3[32:0]),
     .fifo_data_4                       (fifo_data_4[32:0]),
     .fifo_data_5                       (fifo_data_5[32:0]));

  //----------------------------------------------------------------------------
  // Trace Bridge
  //----------------------------------------------------------------------------
  // Smart Bridge between the traceclkin side of the FIFO,the TraceOut stage and
  // the Pattern Generator.This auto inserts the synchronisation packets in the
  // normal and continuous modes.
  cxtpiu_trace_bridge u_cxtpiu_trace_bridge
    (
     // Outputs
     .trace_d_valid                     (trace_d_valid),
     .trace_d                           (trace_d[31:0]),
     .pop_fifo                          (pop_fifo),
     .pattern_complete                  (pattern_complete),
     // Inputs
     .traceclkin                        (traceclkin),
     .tresetn                           (tresetn),
     .trace_d_accepted                  (trace_d_accepted),
     .fifo_empty                        (fifo_empty),
     .fifo_r_data                       (fifo_r_data[32:0]),
     .gen_data                          (gen_data[31:0]),
     .trace_pattern                     (trace_pattern),
     .reg_update                        (reg_update),
     .form_sync_counter_reg             (form_sync_counter_reg[11:0]),
     .pattern_counter_reg               (pattern_counter_reg[7:0]),
     .curr_patt_mode_reg                (curr_patt_mode_reg[1:0]),
     .continous_mode                    (continous_mode),
     .formatter_enable                  (formatter_enable),
     .ft_stopped_sync                   (ft_stopped_sync));

  //----------------------------------------------------------------------------
  // Trace Pattern Generator
  //----------------------------------------------------------------------------
  // Selects the appropriate test pattern from the given configuration input
  cxtpiu_trace_pattern u_cxtpiu_trace_pattern
    (
     // Outputs
     .gen_data                          (gen_data[31:0]),
     .trace_pattern                     (trace_pattern),
     .pattern_done                      (pattern_done),
     // Inputs
     .traceclkin                        (traceclkin),
     .tresetn                           (tresetn),
     .pattern_complete                  (pattern_complete),
     .reg_update                        (reg_update),
     .curr_port_sel_reg                 (curr_port_sel_reg[31:0]),
     .curr_patt_sel_reg                 (curr_patt_sel_reg[3:0]),
     .curr_patt_mode_reg                (curr_patt_mode_reg[1:0]));

  //----------------------------------------------------------------------------
  // Trace Out Block
  //----------------------------------------------------------------------------
  // Final stage of the TPIU;this takes incoming data and converts it to =<32bit
  // port width (serialiser).
  cxtpiu_trace_out u_cxtpiu_trace_out
    (
     // Outputs
     .tracedata                         (tracedata[31:0]),
     .tracectl                          (tracectl),
     .trace_d_accepted                  (trace_d_accepted),
     // Inputs
     .traceclkin                        (traceclkin),
     .tresetn                           (tresetn),
     .trace_d_valid                     (trace_d_valid),
     .trace_d                           (trace_d[31:0]),
     .trig_port_sync                    (trig_port_sync),
     .curr_port_sel_reg                 (curr_port_sel_reg[31:0]),
     .trace_pattern                     (trace_pattern),
     .ft_stopped_sync                   (ft_stopped_sync));

  //----------------------------------------------------------------------------
  // Trace Clock Source
  //----------------------------------------------------------------------------
  // This module takes the incoming Trace Clock (traceclkin) and returns the
  // div2 clock that will give stable data on both clock edges.
  // ==== Does not use inverted clocks: Requires ECO Fixup on timing path ====
  cxtpiu_trace_clk u_cxtpiu_trace_clk
    (
     // Outputs
     .traceclk                          (traceclk),
     // Inputs
     .traceclkin                        (traceclkin),
     .tresetn                           (tresetn));

  // ---------------------------------------------------------------------------
  // APB Clock Domain Synchronizers
  // ---------------------------------------------------------------------------
  // Signals going to the APB clock domain from traceclkin
  cxtpiu_apb_sync u_cxtpiu_apb_sync
    (
     // Outputs
     .rd_wr_ack_t_sync                  (rd_wr_ack_t_sync),
     // Inputs
     .pclkdbg                           (pclkdbg),
     .pclkendbg                         (pclkendbg),
     .presetdbgn                        (presetdbgn),
     .rd_wr_ack_t                       (rd_wr_ack_t));

  // ---------------------------------------------------------------------------
  // ATB Clock Domain Synchronizers
  // ---------------------------------------------------------------------------
  // Signals going to the ATB clock domain from traceclkin
  cxtpiu_atb_sync u_cxtpiu_atb_sync
    (
     // Outputs
     .rd_ptr_gray_sync                  (rd_ptr_gray_sync[3:0]),
     .trig_port_done_sync               (trig_port_done_sync),
     .trigin_sync                       (trigin_sync),
     .flushin_sync                      (flushin_sync),
     // Inputs
     .atclk                             (atclk),
     .atclken                           (atclken),
     .atresetn                          (atresetn),
     .rd_ptr_gray                       (rd_ptr_gray[3:0]),
     .trig_port_sync                    (trig_port_sync),
     .trigin                            (trigin),
     .flushin                           (flushin));

  // ---------------------------------------------------------------------------
  // traceclkin Clock Domain Synchronizers
  // ---------------------------------------------------------------------------
  // Signals going to the traceclkin domain from atclk and pclkdbg
  cxtpiu_trace_sync u_cxtpiu_trace_sync
  (
   // Outputs
   .formatter_enable                    (formatter_enable),
   .continous_mode                      (continous_mode),
   .trig_port_sync                      (trig_port_sync),
   .rd_wr_req_t_sync                    (rd_wr_req_t_sync),
   .wr_ptr_gray_sync                    (wr_ptr_gray_sync[3:0]),
   .ft_stopped_sync                     (ft_stopped_sync),
   // Inputs
   .traceclkin                          (traceclkin),
   .tresetn                             (tresetn),
   .ffcr_ften_reg                       (ffcr_ften_reg[1:0]),
   .trig_port                           (trig_port),
   .rd_wr_req_t                         (rd_wr_req_t),
   .wr_ptr_gray                         (wr_ptr_gray[3:0]),
   .ft_stopped                          (ft_stopped));

endmodule // cxtpiu
