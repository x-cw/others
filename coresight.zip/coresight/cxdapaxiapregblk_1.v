
//--========================================================================
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2011-2015 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//  Version and Release Control Information:
//
//  File Name           : cxdapaxiapregblk_xmlcfg.v.xsl
//
//  Checked In          : $Date: 2015-03-02 15:24:55 +0000 (Mon, 02 Mar 2015) $
//
//  File Revision       : $Revision: 41794 $
//
//  Release Information : CoreSight-SoC-TM100-r3p2-00rel0
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// Abstract : CoreSight AXIAP Register Block
//-----------------------------------------------------------------------------
//
// cxdapaxiap - CoreSight AXIAP Register Block
// -------------------------------------------
//
//-----------------------------------------------------------------------------

module cxdapaxiapregblk_1 (

  // Clock and Reset
  input wire            clk,
  input wire            resetn,

  // DAP slave interface
  input wire            bnk_sel_0,
  input wire            bnk_sel_1,
  input wire            bnk_sel_2,
  input wire            bnk_sel_15,
  input wire  [3:0]     reg_sel,
  input wire            wr_en,
  input wire  [31:0]    wdata,
  input wire            rd_en,
  input wire            abrt_req,
  output wire [31:0]    rdata,
  output wire           axi_ap_rdy,
  output wire           err_resp,

  // Top level FSM interface
  input wire  [2:0]     fsm_state,
  input wire  [2:0]     fsm_state_next,
  input wire            fsm_state_en,
  output wire           bar_req,
  output reg            drw_wr_req_fsm,
  output reg            bd_wr_req_fsm,
  output reg            drw_rd_req_fsm,
  output reg            bd_rd_req_fsm,
  output wire           sprot,

  // AXI Master Interface
  output wire           drw_wr_req,
  output wire           drw_rd_req,
  output wire           bd0_req,
  output wire           bd1_req,
  output wire           bd2_req,
  output wire           bd3_req,
  output wire           drw_en,
  output wire           bd0_en,
  output wire           bd1_en,
  output wire           bd2_en,
  output wire           bd3_en,

  output wire [31:0]    tar_l,

  output reg  [31:0]    tar_u,

  output wire [1:0]     axi_size,
  output wire [3:0]     cache_enc,
  output wire [2:0]     prot_enc,
  output wire [1:0]     addr_inc,
  output wire [1:0]     bar_enc,
  output wire [1:0]     domain,
  output wire           abort_req,
  input wire  [9:0]     inc_tar_l,
  input wire            inc_tar,
  input wire  [31:0]    rdata_l,
  input wire            rdata_vld,
  input wire            axi_err_resp,

  // Authentication interface
  input wire            dbgen,
  input wire            spiden,

  // Tie-off

  input wire  [31:0] rombaseaddru,

  input wire  [31:0] rombaseaddrl,

  output wire        spiden_rg,
  output wire        dbgen_rg

  );

`include "cxdapaxiap_constants.v"

//------------------------------------------------------------------------------
// Constant definitions
//------------------------------------------------------------------------------
  localparam NOAXIACC  = 3'b000;
  localparam DRWWRREQC = 3'b001;
  localparam DRWRDREQC = 3'b010;
  localparam BKD0REQ   = 3'b011;
  localparam BKD1REQ   = 3'b100;
  localparam BKD2REQ   = 3'b101;
  localparam BKD3REQ   = 3'b110;
  localparam UNUS0REQ  = 3'b111;



//----------------------------------------------------------------------------
// Wires
//----------------------------------------------------------------------------
  wire        csw_en;
  wire        ta_l_en;

  wire        ta_u_en;

  wire        ace_bar_tran_en;
  wire        rom_base_l_en;

  wire        rom_base_u_en;

  wire        cfg_en;
  wire        id_en;
  wire [1:0]  axi_size_next;
  wire [1:0]  addr_inc_next;
  wire        en_ace_next;
  wire [1:0]  domain_next;
  wire [3:0]  cache_next;
  wire [2:0]  prot_next;

  wire        csw_rd_en;
  wire        tar_l_rd_en;

  wire        tar_u_rd_en;
  wire        rom_base_u_rd_en;
  wire [31:0] tar_u_rdata;
  wire [31:0] rom_u_rdata;
  wire        tar_u_en;

  wire        axi_rd_en;
  wire        ace_bar_tran_rd_en;
  wire        rom_base_l_rd_en;
  wire        cfg_rd_en;
  wire        id_rd_en;


  wire [31:0] csw_rdata;
  wire [31:0] tar_l_rdata;
  wire [31:0] axi_rdata;
  wire [31:0] ace_bar_tran_rdata;
  wire [31:0] rom_l_rdata;
  wire [31:0] cfg_rdata;
  wire [31:0] id_rdata;
  wire [31:0] rdata_rg_next;
  wire        abort_req_en;
  wire        rdata_rg_en;
  wire        tar_l_en;
  wire        trg_bar_tran_en;
  wire        bar_tran_en;
  wire        axi_rd_wr_req_en;
  wire        axi_err_resp_rg_en;
  wire        spiden_rg_en;
  wire        dbgen_rg_en;
  wire        bd0_en_int;
  wire        bd1_en_int;
  wire        bd2_en_int;
  wire        bd3_en_int;

  wire        drw_en_int;

//----------------------------------------------------------------------------
// Registers
//----------------------------------------------------------------------------
  reg        mode_next;
  reg [31:0] tar_l_next;

  reg        mode;
  reg [3:0]  cache;
  reg [2:0]  prot;
  reg        trg_bar_tran_next;
  reg        trg_bar_tran;
  reg [1:0]  bar_tran_next;
  reg [1:0]  bar_tran;
  reg        abort_req_next;
  reg [2:0]  axi_rd_wr_req_next;
  reg [2:0]  axi_rd_wr_req;
  reg [31:0] rdata_rg;
  reg        axi_err_resp_rg_next;
  reg        axi_err_resp_rg;
  reg [3:0]  axiap_revid;
  reg        allow_axi_tran;
  reg        en_ace;
  reg [1:0]  domain_q;
  reg [1:0]  axi_size_q;
  reg [1:0]  addr_inc_q;
  reg [31:0] tar_l_q;
  reg        dbgen_rg_q;
  reg        spiden_rg_q;
  reg        abort_req_q;

//============================================================================
//
// Main body of code
//
//============================================================================

  assign spiden_rg_en = (spiden_rg_q ^ spiden);

  always @ (posedge clk or negedge resetn)
    begin
      if (!resetn) begin
        spiden_rg_q <= 1'b0;
      end else if (spiden_rg_en) begin
        spiden_rg_q <= spiden;
      end
    end

  assign spiden_rg = spiden_rg_q;

  assign dbgen_rg_en = (dbgen_rg_q ^ dbgen);

  always @ (posedge clk or negedge resetn)
    begin
      if (!resetn) begin
        dbgen_rg_q <= 1'b0;
      end else if (dbgen_rg_en) begin
        dbgen_rg_q <= dbgen;
      end
    end

  assign dbgen_rg = dbgen_rg_q;

//----------------------------------------------------------------------------
// CSwEn, ta_l_en, ta_u_en, drw_en, bd0_en, bd1_en, bd2_en, bd3_en, ace_bar_tran_en, rom_base_l_en,
// rom_base_u_en, cfg_en, id_en are select signals for registers in programmer's
// view. These would select Control Status word, Transfer address (lower and
// upper), data read/write, Banked Data registers 0 to 3, Ace Barrier
// Transaction, Rom Base Address (lower and upper), Config and Identification
// registers.
//----------------------------------------------------------------------------
  assign csw_en          = bnk_sel_0 & reg_sel[0];
  assign ta_l_en         = bnk_sel_0 & reg_sel[1];

  assign ta_u_en         = bnk_sel_0 & reg_sel[2];

  assign drw_en_int      = bnk_sel_0 & reg_sel[3];

  assign drw_en          = drw_en_int;

  assign bd0_en_int      = bnk_sel_1 & reg_sel[0];
  assign bd1_en_int      = bnk_sel_1 & reg_sel[1];
  assign bd2_en_int      = bnk_sel_1 & reg_sel[2];
  assign bd3_en_int      = bnk_sel_1 & reg_sel[3];

  assign bd0_en          = bd0_en_int;
  assign bd1_en          = bd1_en_int;
  assign bd2_en          = bd2_en_int;
  assign bd3_en          = bd3_en_int;

  assign ace_bar_tran_en = bnk_sel_2 & reg_sel[0];

  assign rom_base_l_en   = bnk_sel_15 & reg_sel[2];

  assign rom_base_u_en   = bnk_sel_15 & reg_sel[0];

  assign cfg_en          = bnk_sel_15 & reg_sel[1];

  assign id_en           = bnk_sel_15 & reg_sel[3];

//----------------------------------------------------------------------------
// Control and Status word register
//----------------------------------------------------------------------------
// Csw Register fields
//  [31] SBZ
//  [30:28] RW (prot)
//  [27:24] RW (cache)
//  [23] RO (spiden)
//  [22:19] RW (cache)
//  [18:15] SBZ
//  [14:13] RW (domain)
//  [12] RW (en_ace)
//  [11:8] RW : condition : if wdata[11:9] != '0' then store zero (mode)
//  [7:6] RO (TrInProg)
//  [6] RO (DbgStatus)
//  [5:4] RW (addr_inc)
//  [3] SBZ
//  [2:0] RW (Size)
//----------------------------------------------------------------------------
  assign axi_size_next = (csw_en & (wr_en & (fsm_state == RDY))) ? wdata[1:0] : axi_size_q;

  assign addr_inc_next = (csw_en & (wr_en & (fsm_state == RDY))) ? wdata[5:4] : addr_inc_q;

  always @(*)
    begin
      mode_next = mode;

      if (csw_en & (wr_en & (fsm_state == RDY))) begin
        if (wdata[11:9] != 3'b000) begin
          mode_next = 1'b0;
        end else begin
          mode_next = wdata[8];
        end
      end
    end

  assign en_ace_next = (csw_en & (wr_en & (fsm_state == RDY))) ? wdata[12] : en_ace;

  assign domain_next = (csw_en & (wr_en & (fsm_state == RDY))) ? wdata[14:13] : domain_q;

  assign cache_next = (csw_en & (wr_en & (fsm_state == RDY))) ? wdata[27:24] : cache;

  assign prot_next = (csw_en & (wr_en & (fsm_state == RDY))) ? wdata[30:28] : prot;

  always @ (posedge clk or negedge resetn)
    begin : csw_reg
      if (!resetn)
        begin
          axi_size_q   <= 2'b10;  // 32-bit
          addr_inc_q   <= 2'b00;   // Auto-increment off
          mode         <= 1'b0; // Normal download/upload
          en_ace       <= 1'b0;    // Disable Barrier transaction
          domain_q     <= 2'b11;   // System-shareable
          cache        <= 4'b0000;
          prot         <= 3'b011;
        end
      else if (csw_en && (wr_en & (fsm_state == RDY)))
        begin
          axi_size_q   <= axi_size_next;
          addr_inc_q   <= addr_inc_next;
          mode         <= mode_next;
          en_ace       <= en_ace_next;
          domain_q     <= domain_next;
          cache        <= cache_next;
          prot         <= prot_next;
        end
    end

  assign axi_size = axi_size_q;

  assign addr_inc = addr_inc_q;

  assign domain = domain_q;

  assign cache_enc = cache;

  assign prot_enc = prot;

  assign sprot = prot[1];

//----------------------------------------------------------------------------
// Transfer Address Register (Lower 32-bit)
//----------------------------------------------------------------------------
// If a Read or a write access is in progress on the AXI interface then all
// write requests from DAP are ignored. However if a Barrier transaction is in
// progress then Tar will be updated with the value from the DAP access
//----------------------------------------------------------------------------
  always @(*)
    begin : tar_l_reg_decode

      tar_l_next = tar_l_q;

      case (fsm_state)
          RDY,
          BRR,
          BRR_RESP : begin
            if (ta_l_en && (wr_en & (fsm_state == RDY)))
              tar_l_next = wdata[31:0];
          end
          WRITE_RESP,
          READ_RESP : begin
            if (inc_tar)
              tar_l_next = {tar_l_q[31:10],inc_tar_l};
          end
          WR_CMD,
          WR_DT,
          RD_CMD : tar_l_next = tar_l_q;
          default : tar_l_next = {32{1'bx}};
      endcase
    end

  assign tar_l_en = inc_tar | (ta_l_en & (wr_en & (fsm_state == RDY)));

  always @ (posedge clk or negedge resetn)
    begin : tar_l_reg
      if (!resetn)
        tar_l_q <= {32{1'b0}};
      else if (tar_l_en)
        tar_l_q <= tar_l_next;
    end

  assign tar_l = tar_l_q;


//----------------------------------------------------------------------------
// Transfer Address Register (Upper 32-bit)
//----------------------------------------------------------------------------
// If a Read or a write access is in progress on the AXI interface then all
// write requests from DAP are ignored. However if a Barrier transaction is in
// progress then Tar will be updated with the value from the DAP access
//----------------------------------------------------------------------------
  assign tar_u_en = ((fsm_state == RDY) |
                     (fsm_state == BRR) |
                     (fsm_state == BRR_RESP)) &
                    (ta_u_en & (wr_en & (fsm_state == RDY)));

  always @ (posedge clk or negedge resetn)
    begin : tar_u_reg
      if (!resetn) begin
        tar_u <= {32{1'b0}};
      end else if (tar_u_en) begin
        tar_u <= wdata[31:0];
      end
    end


//----------------------------------------------------------------------------
// ACE Barrier Transaction Register
//----------------------------------------------------------------------------
// Register Fields
// [31:3] SBZ
// [2:1] RW (bar_tran)
// [0] RW (trg_bar_tran)
//----------------------------------------------------------------------------
// Writing 'b1' to trg_bar_tran bit from the DAP I/F will trigger a barrier
// transaction on the AXI interface.Once the barrier transaction completes,
// trg_bar_tran will be reset to 'b0'. If another barrier transaction is required
// then firmware has to write 'b1' to trg_bar_tran bit location. If trg_bar_tran is
// already 'b1' then this write will have no effect. It indicates that a barrier
// transaction is already in progress and it is yet to complete.
// If the AXI interface is busy with a read or write request then Writing 'b1'
// to trg_bar_tran bit will result in an error and request for barrier transaction
// will not be accepted.
//----------------------------------------------------------------------------
  always @(*)
    begin : trg_bar_tran_decode

      trg_bar_tran_next = trg_bar_tran;

      if (trg_bar_tran) begin
        if (bar_tran[0]) begin
          trg_bar_tran_next = ~((fsm_state_next == RDY) & fsm_state_en);
        end else begin
          trg_bar_tran_next = 1'b0;
        end
      end else if ((fsm_state == RDY) && (mode)) begin
        if (ace_bar_tran_en && wr_en && en_ace) begin
          trg_bar_tran_next = wdata[0];
        end
      end
    end

  assign trg_bar_tran_en = trg_bar_tran_next ^ trg_bar_tran;

  always @ (posedge clk or negedge resetn)
    begin : trg_bar_tran_reg
      if (!resetn) begin
        trg_bar_tran <= 1'b0;
      end else if (trg_bar_tran_en) begin
        trg_bar_tran <= trg_bar_tran_next;
      end
    end

  assign bar_req = trg_bar_tran & (bar_tran[0]);

  always @(*)
    begin : bar_tran_decode

      bar_tran_next = bar_tran;

      if (fsm_state == RDY) begin
        if (ace_bar_tran_en && wr_en) begin
          bar_tran_next = wdata[2:1];
        end
      end
    end

  assign bar_tran_en = (ace_bar_tran_en & wr_en) & (fsm_state == RDY);

  always @ (posedge clk or negedge resetn)
    begin : bar_tran_reg
      if (!resetn) begin
        bar_tran <= {2{1'b0}};
      end else if (bar_tran_en) begin
        bar_tran <= bar_tran_next;
      end
    end

  assign bar_enc = (mode) ? bar_tran : 2'b00;

//----------------------------------------------------------------------------
// Decode all the illegal combinations of AxCACHE and AxDOMAIN
//---------------------------------------------
// AxCACHE        AxDOMAIN                Legal
//---------------------------------------------
// 0000    Device 00      Non-shareable   NO
// 0001           01      Inner-shareable NO
//                10      Outer-shareable NO
//                11      System          Yes
//---------------------------------------------
// 0010    Non    00      Non-shareable   Allowed
// 0011 Cacheable 01      Inner-shareable Allowed
//                10      Outer-shareable Allowed
//                11      System          Yes
//---------------------------------------------
// 01xx    Write  00      Non-shareable   Yes
// 10xx   Through 01      Inner-shareable Yes
// 11xx    Write  10      Outer-shareable Yes
//         Back   11      System          NO
//----------------------------------------------------------------------------
  always @(*)
    begin
      case (cache[3:2])
        2'b00 : begin
          case(cache[1:0])
            2'b00 ,
            2'b01 : allow_axi_tran = (domain_q == 2'b11);
            2'b10 ,
            2'b11 : allow_axi_tran = ~(mode & bar_tran[0]);
            default : allow_axi_tran = 1'bx;
          endcase
        end
        2'b01 ,
        2'b10 ,
        2'b11 : begin
          case(cache[1:0])
            2'b00 ,
            2'b01 : allow_axi_tran = 1'b0;
            2'b10 ,
            2'b11 : allow_axi_tran = ~(domain_q == 2'b11);
            default : allow_axi_tran = 1'bx;
          endcase
        end
        default : allow_axi_tran = 1'bx;
      endcase
    end

//----------------------------------------------------------------------------
// Read/Write request generation
// Read or Write is accepted only when the top-level FSM is Ready, that is,
// top-level FSM should be in RDY state. If the FSM is in other state then
// new requests are not accepted.
//----------------------------------------------------------------------------

  always @(*)
  begin
    axi_rd_wr_req_next = axi_rd_wr_req;

    if ((axi_rd_wr_req == NOAXIACC) &&
         allow_axi_tran &&
           dbgen_rg_q &&
             (prot[1] || spiden_rg_q))
      begin
        if (drw_en_int && (axi_size_q <= AXIAP_WORD) && (addr_inc_q != 2'b11))
          begin
            if (wr_en)
              axi_rd_wr_req_next = DRWWRREQC;
            else if (rd_en)
              axi_rd_wr_req_next = DRWRDREQC;
          end
        else if (bd0_en_int || bd1_en_int || bd2_en_int || bd3_en_int)
          begin
            axi_rd_wr_req_next = (({3{bd0_en_int}} & BKD0REQ) |
                                  ({3{bd1_en_int}} & BKD1REQ) |
                                  ({3{bd2_en_int}} & BKD2REQ) |
                                  ({3{bd3_en_int}} & BKD3REQ)
                                  );
          end
      end
    else
      begin
        if ((fsm_state_next == RDY) && fsm_state_en)
          axi_rd_wr_req_next = NOAXIACC;
      end
  end


  assign axi_rd_wr_req_en = (axi_rd_wr_req != axi_rd_wr_req_next);

  always @ (posedge clk or negedge resetn)
    begin : axi_rd_wr_req_reg
      if (!resetn) begin
        axi_rd_wr_req <= NOAXIACC;
      end else if (axi_rd_wr_req_en) begin
        axi_rd_wr_req <= axi_rd_wr_req_next;
      end
    end

//----------------------------------------------------------------------------
// Seperate drw read/write and Banked Data register read/write requests are
// generated for the master Interface.
//
// The master interface cycles through different phases of AXI read/write
// These phases span across cycles. So in order to enable Master interface in
// each/phase cycle the request is encoded and stored to reduce storage FFs.
//
// Actual request is decoded and sent to the master interface.
// Individual strobes are generated to enable Master interface to calculate
// proper address in case of bd(0/1/2/3) access.
//----------------------------------------------------------------------------
  assign drw_wr_req = (axi_rd_wr_req == DRWWRREQC);
  assign drw_rd_req = (axi_rd_wr_req == DRWRDREQC);

  assign bd0_req = (axi_rd_wr_req == BKD0REQ);
  assign bd1_req = (axi_rd_wr_req == BKD1REQ);
  assign bd2_req = (axi_rd_wr_req == BKD2REQ);
  assign bd3_req = (axi_rd_wr_req == BKD3REQ);

//----------------------------------------------------------------------------
// Seperate drw read/write and Banked Data register read/write is generated
// as a pulse to the top-level fsm.
// However in case of 64-bit data width
// if axi_size is set as 32-bit data then
// access to all bd registers are allowed in any order.
// if axi_size is set as 64-bit data then
// access to pair of registers is expected
// that is bd0 followed by bd1, bd2-bd3, drw-drw
//----------------------------------------------------------------------------
  always @ (*)
    begin
      drw_wr_req_fsm = 1'b0;
      drw_rd_req_fsm = 1'b0;
      bd_wr_req_fsm  = 1'b0;
      bd_rd_req_fsm  = 1'b0;

      if (allow_axi_tran &&
           dbgen_rg_q &&
             (prot[1] | spiden_rg_q)) begin
        if (axi_size_q <= AXIAP_WORD) begin
          drw_wr_req_fsm = (drw_en_int &
                             wr_en &
                               (addr_inc_q != 2'b11));
          drw_rd_req_fsm = (drw_en_int &
                             rd_en &
                               (addr_inc_q != 2'b11));
        end

          bd_wr_req_fsm  = ((bd0_en_int | bd1_en_int | bd2_en_int | bd3_en_int) & wr_en);
          bd_rd_req_fsm  = ((bd0_en_int | bd1_en_int | bd2_en_int | bd3_en_int) & rd_en);

      end
    end

//----------------------------------------------------------------------------
// Abort request generation. This is generated when Abort is asserted and
// top-level FSM is busy and not in RDY state. This will be a sticky bit which
// will be reset once the top-level FSM returns to RDY state.
//----------------------------------------------------------------------------
  always @(*)
    begin : abort_req_decode
      if (abort_req_q) begin
        abort_req_next = ~(fsm_state == RDY);
      end else if (fsm_state != RDY) begin
        abort_req_next = abrt_req;
      end else begin
        abort_req_next = 1'b0;
      end
    end

  assign abort_req_en = (abort_req_q ^ abort_req_next);

  always @ (posedge clk or negedge resetn)
    begin : p_abort_req_reg
      if (!resetn) begin
        abort_req_q <= 1'b0;
      end else if (abort_req_en) begin
        abort_req_q <= abort_req_next;
      end
    end

  assign abort_req = abort_req_q;

//----------------------------------------------------------------------------
// Read Access
//----------------------------------------------------------------------------
  assign csw_rd_en      = csw_en & rd_en;
  assign tar_l_rd_en     = ta_l_en & rd_en;

  assign tar_u_rd_en     = ta_u_en & rd_en;

  assign axi_rd_en      = (~abort_req_q) & (rdata_vld & (fsm_state == RDY));
  assign ace_bar_tran_rd_en      = ace_bar_tran_en & rd_en;
  assign rom_base_l_rd_en = rom_base_l_en & rd_en;

  assign rom_base_u_rd_en = rom_base_u_en & rd_en;

  assign cfg_rd_en      = cfg_en & rd_en;
  assign id_rd_en       = id_en & rd_en;

  assign csw_rdata  = {1'b0,
                       prot,
                       cache,
                       spiden_rg_q,
                       {8{1'b0}},
                       domain_q,
                       en_ace,
                       {3{1'b0}},mode,
                      ~(fsm_state == RDY),
                      dbgen_rg_q,
                      addr_inc_q,
                      1'b0,
                      1'b0,axi_size_q};

  assign tar_l_rdata = tar_l_q;

  assign tar_u_rdata = tar_u;

  assign ace_bar_tran_rdata  = {{29{1'b0}},bar_tran,trg_bar_tran};
  assign rom_l_rdata = rombaseaddrl | 32'h00000002; // Bit 1 should always be set

  assign rom_u_rdata = rombaseaddru;

  assign cfg_rdata  = {{29{1'b0}},{1'b0},{1'b1},{1'b0}};


  always @ (posedge clk or negedge resetn)
    begin
      if (!resetn) begin
        axiap_revid    <= 4'h4;
      end else begin
        axiap_revid    <= 4'h4;
      end
    end

  assign id_rdata   = {axiap_revid,4'h4,7'h3B,1'b1,{8{1'b0}},8'h04};

  assign rdata_rg_next = (
                         ({32{csw_rd_en}} & csw_rdata) |
                         ({32{tar_l_rd_en}} & tar_l_rdata) |

                         ({32{tar_u_rd_en}} & tar_u_rdata) |

                         ({32{ace_bar_tran_rd_en}} & ace_bar_tran_rdata) |
                         ({32{rom_base_l_rd_en}} & rom_l_rdata) |

                         ({32{rom_base_u_rd_en}} & rom_u_rdata) |

                         ({32{cfg_rd_en}} & cfg_rdata) |
                         ({32{id_rd_en}} & id_rdata)
                       );

  assign rdata_rg_en = (
                         (csw_rd_en) |
                         (tar_l_rd_en) |

                         (tar_u_rd_en) |

                         (ace_bar_tran_rd_en) |
                         (rom_base_l_rd_en) |

                         (rom_base_u_rd_en) |

                         (cfg_rd_en) |
                         (id_rd_en) |
                         (rd_en)
                         );

  always @ (posedge clk or negedge resetn)
    begin : p_rdata_reg
      if (!resetn) begin
        rdata_rg <= {32{1'b0}};
      end else if (rdata_rg_en) begin
        rdata_rg <= rdata_rg_next;
      end
    end

  assign axi_rdata = rdata_l[31:0];

  assign rdata = (
                  ({32{axi_rd_en}} & axi_rdata[31:0]) |
                  ({32{~(axi_rd_en)}} & rdata_rg)
                 );

  assign axi_ap_rdy = (fsm_state == RDY) & (~trg_bar_tran);


//----------------------------------------------------------------------------
// Error Response. If the top-level FSM is not ready, it indicates that
// Master interface is busy with an ongoing AXI transaction.
// Any access to programmable registers which is expected to initiate a fresh
// AXI access will result in an error response. This means that access to
// ace_bar_tran or drw or bd(0/1/2/3) will result in an error
//----------------------------------------------------------------------------
  always @(*)
    begin
      axi_err_resp_rg_next = 1'b0;

      if (!(dbgen_rg_q & (prot[1] || spiden_rg_q)) || (fsm_state != RDY)) begin
        if ((ace_bar_tran_en & wr_en) || drw_en_int || bd0_en_int || bd1_en_int || bd2_en_int || bd3_en_int) begin
          axi_err_resp_rg_next = 1'b1;
        end else if (wr_en & (fsm_state != RDY)) begin
          axi_err_resp_rg_next = 1'b1;
        end else begin
          axi_err_resp_rg_next = axi_err_resp & ~abort_req_q;
        end
      end
    end

  assign axi_err_resp_rg_en = (axi_err_resp_rg ^ axi_err_resp_rg_next);

  always @ (posedge clk or negedge resetn)
    begin : p_err_resp
      if (!resetn) begin
        axi_err_resp_rg <= 1'b0;
      end else if (axi_err_resp_rg_en) begin
        axi_err_resp_rg <= axi_err_resp_rg_next;
      end
    end

  assign err_resp =  axi_err_resp_rg;



endmodule
