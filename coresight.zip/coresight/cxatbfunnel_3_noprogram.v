//-----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2003-2015 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//  Version and Release Control Information:
//
//  File Name           : cxatbfunnel_xmlcfg.v.xsl
//
//  Checked In          : $Date: 2015-02-16 14:55:41 +0000 (Mon, 16 Feb 2015) $
//
//  File Revision       : $Revision: 41661 $
//
//  Release Information : CoreSight-SoC-TM100-r3p2-00rel0
//-----------------------------------------------------------------------------


//-----------------------------------------------------------------------------
// Abstract : CoreSight  Trace Funnel (cxatbfunnel) - Top Level Block
//-----------------------------------------------------------------------------
//
// cxatbfunnel - CoreSight  Trace Funnel
// -------------------------------------
//
// CoreSight AMBA Trace Bus (ATB) trace link device used to combine multiple
// trace sources into a single bus.
//
// cxatbfunnel.v
// ----------
//
// cxatbfunnel.v provides the instantiations of all modules for the cxatbfunnel.
//
// Instantiated blocks
// -------------------
//
// cxatbfunnel_apb_if.v  - APB Interface Module
// cxatbfunnel_reg_blk.v - Register Module
// cxatbfunnel_arbiter.v - Arbiter Logic Module
//-----------------------------------------------------------------------------




module cxatbfunnel_3_noprogram  (
  // Inputs
  input wire         clk,
  input wire         resetn,

  input wire         atvalids0,
  input wire         afreadys0,
  input wire [6:0]   atids0,
  input wire [128-1:0] atdatas0,
  
  input wire [3:0]   atbytess0,
  input wire         atvalids1,
  input wire         afreadys1,
  input wire [6:0]   atids1,
  input wire [128-1:0] atdatas1,
  
  input wire [3:0]   atbytess1,
  input wire         atvalids2,
  input wire         afreadys2,
  input wire [6:0]   atids2,
  input wire [128-1:0] atdatas2,
  
  input wire [3:0]   atbytess2,

  // ATB Master signals
  input wire         atreadym,
  input wire         afvalidm,
  input wire         syncreqm,
  // Outputs

  output wire        atvalidm,
  output wire        afreadym,
  output wire [6:0]  atidm,
  output wire [128-1:0] atdatam,

  output [3:0]       atbytesm,
  output wire        atreadys2,
  output wire        afvalids2,
  output wire        syncreqs2,

  output wire        atreadys0,
  output wire        afvalids0,
  output wire        syncreqs0,
  output wire        atreadys1,
  output wire        afvalids1,
  output wire        syncreqs1
  );

//------------------------------------------------------------------------------
// Local param definitions
//------------------------------------------------------------------------------

  localparam CXFUNNEL_ATB_DATA_WIDTH = 128; // Width of the ATB databus
                                          // Valid values: 32, 64 and 128
  localparam CXFUNNEL_ATBYTES_WIDTH =
  
             4;

  localparam CXFUNNEL_FIXED_CONFIGURATION =  1;
  localparam CXFUNNEL_NUMBER_OF_ATB_SLAVES =  3;
  localparam CXFUNNEL_FIXED_CONFIG_HOLD_TIME = 4'b0011;


//------------------------------------------------------------------------------
// Wires
//------------------------------------------------------------------------------

  wire                  en_port_0;
  wire [2:0]            pri_port_0;

  wire                  en_port_1;
  wire [2:0]            pri_port_1;

  wire                  en_port_2;
  wire [2:0]            pri_port_2;

  wire [3:0]            min_hold_time;


      //-----------------------------------------------------------------------
      // Tie-off wires for no apb configuration
      // All ATB Slave ports are enabled
      // All ATB slave ports have equal priority
      // Hold time is set to the value defined in configuration parameter
      //-----------------------------------------------------------------------
      assign min_hold_time = CXFUNNEL_FIXED_CONFIG_HOLD_TIME;
  
      assign en_port_0 = 1'b1;
      assign pri_port_0 = 3'b000;
  
      assign en_port_1 = 1'b1;
      assign pri_port_1 = 3'b000;
  
      assign en_port_2 = 1'b1;
      assign pri_port_2 = 3'b000;
  
  //---------------------------------------------------------------------------
  // Funnel Arbiter Module.
  // This module arbitarates among the different slave ports.
  //---------------------------------------------------------------------------
  cxatbfunnel_arbiter_3_noprogram
    #(
     .CXFUNNEL_ATB_DATA_WIDTH           (CXFUNNEL_ATB_DATA_WIDTH),
     .CXFUNNEL_ATBYTES_WIDTH            (CXFUNNEL_ATBYTES_WIDTH))
    u_cxatbfunnel_arbiter
     (
     // Inputs
     .clk                               (clk),
     .resetn                            (resetn),
     .atreadym                          (atreadym),
     .afvalidm                          (afvalidm),
     .syncreqm                          (syncreqm),
     .atvalids0                         (atvalids0),
     .afreadys0                         (afreadys0),
     .atids0                            (atids0),
     .atdatas0                          (atdatas0),
     .atbytess0                         (atbytess0),
     .atvalids1                         (atvalids1),
     .afreadys1                         (afreadys1),
     .atids1                            (atids1),
     .atdatas1                          (atdatas1),
     .atbytess1                         (atbytess1),
     
     .atvalids2                         (atvalids2),
     .afreadys2                         (afreadys2),
     .atids2                            (atids2),
     .atdatas2                          (atdatas2),
     .atbytess2                         (atbytess2),
     
     .min_hold_time                     (min_hold_time),
      .en_port_0                        (en_port_0),
      .pri_port_0                       (pri_port_0),
      .en_port_1                        (en_port_1),
      .pri_port_1                       (pri_port_1),
     
      .en_port_2                        (en_port_2),
      .pri_port_2                       (pri_port_2),

     // Outputs
     

     .afreadym                          (afreadym),
     .atvalidm                          (atvalidm),
     .atbytesm                          (atbytesm),
     .atidm                             (atidm),
     .atdatam                           (atdatam),
     
     .atreadys2                         (atreadys2),
     .afvalids2                         (afvalids2),
     .syncreqs2                         (syncreqs2),
     
     .atreadys0                         (atreadys0),
     .afvalids0                         (afvalids0),
     .syncreqs0                         (syncreqs0),
     .atreadys1                         (atreadys1),
     .afvalids1                         (afvalids1),
     .syncreqs1                         (syncreqs1)
);

`ifdef ARM_ASSERT_ON
  //----------------------------------------------------------------------------
  // OVL Assertions
  //----------------------------------------------------------------------------

  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : Number of ATB slave ports cannot be less than 2 and greater than 8")
      uzovl_cxatbfunnel_num_atb_slave
        (
         .clk         (clk),
         .reset_n     (resetn),
         .test_expr   (CXFUNNEL_NUMBER_OF_ATB_SLAVES < 2 | CXFUNNEL_NUMBER_OF_ATB_SLAVES > 8 )
        );

  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : ATB Data width can be only in powers of 2 and within 128 bits")
      uzovl_cxatbfunnel_atb_data_width
        (
         .clk         (clk),
         .reset_n     (resetn),
         .test_expr   (~(CXFUNNEL_ATB_DATA_WIDTH == 8   |
                         CXFUNNEL_ATB_DATA_WIDTH == 16  |
                         CXFUNNEL_ATB_DATA_WIDTH == 32  |
                         CXFUNNEL_ATB_DATA_WIDTH == 64  |
                         CXFUNNEL_ATB_DATA_WIDTH == 128 ))
        );

`endif

endmodule // cxatbfunnel
