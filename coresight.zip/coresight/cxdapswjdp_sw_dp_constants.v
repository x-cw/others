// ----------------------------------------------------------------------------
//  The confidential and proprietary information contained in this file may
//  only be used by a person authorised under and to the extent permitted
//  by a subsisting licensing agreement from ARM Limited.
//
//                (C) COPYRIGHT 2004-2015 ARM Limited.
//                    ALL RIGHTS RESERVED
//
//  This entire notice must be reproduced on all copies of this file
//  and copies of this file may only be made by a person if such person is
//  permitted to do so under the terms of a subsisting license agreement
//  from ARM Limited.
//
//    Checked In : $Date: 2014-01-15 12:32:16 +0000 (Wed, 15 Jan 2014) $
//    Revision   : $Revision: 38664 $
//    Release    : CoreSight-SoC-TM100-r3p2-00rel0
// ----------------------------------------------------------------------------
//  Purpose : DAP SW-DP Definitions.
// ----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// Device ID
//-----------------------------------------------------------------------------
localparam SWDP_ID       = 28'hBA02477;
localparam SWDP_REV      = 4'h6;
localparam SWDP_PROTOVER = 4'h1; // Second protocol, for DLPIDR

//-----------------------------------------------------------------------------
// Wire Manager States
//-----------------------------------------------------------------------------
localparam SWWM_IDLE    = 2'b00;
localparam SWWM_RESET   = 2'b01;
localparam SWWM_W4TRAIN = 2'b10;
localparam SWWM_TRAIN   = 2'b11;

//-----------------------------------------------------------------------------
// Serial Protocol states
//-----------------------------------------------------------------------------
// Reset state,
localparam SWDP_SLERESET    = 5'b00000;
// Header States
localparam SWDP_SLEIDLE     = 5'b00001;
localparam SWDP_SLEBANK     = 5'b00010;
localparam SWDP_SLEDIR      = 5'b00011;
localparam SWDP_SLEADDR0    = 5'b00100;
localparam SWDP_SLEADDR1    = 5'b00101;
localparam SWDP_SLEPARITYH  = 5'b00110;
localparam SWDP_SLESTOPH    = 5'b00111;
localparam SWDP_SLEPARKH    = 5'b01000;
localparam SWDP_SLETRNH2    = 5'b01010;
localparam SWDP_SLETRNH1    = 5'b01011;
localparam SWDP_SLETRNH0    = 5'b01100;
localparam SWDP_UNUSED01    = 5'b01101;
// Acknowledge States
localparam SWDP_SLEACK0     = 5'b10000;
localparam SWDP_SLEACK1     = 5'b10001;
localparam SWDP_SLEACK2     = 5'b10010;
// Write States
localparam SWDP_SLEPARKW    = 5'b10011;
localparam SWDP_SLETRNW3    = 5'b10100;
localparam SWDP_SLETRNW2    = 5'b10101;
localparam SWDP_SLETRNW1    = 5'b10110;
localparam SWDP_SLETRNW0    = 5'b10111;
localparam SWDP_SLERESW     = 5'b11000;
localparam SWDP_SLEDATAW    = 5'b11001;
localparam SWDP_SLEPARITYW  = 5'b11010;
localparam SWDP_SLEMARKW    = 5'b11011;
localparam SWDP_SLESTOPW    = 5'b11100;
// Read States
localparam SWDP_SLEDATAR    = 5'b11101;
localparam SWDP_SLEPARITYR  = 5'b11110;
localparam SWDP_SLESTOPR    = 5'b11111;
// Wait States
// Closing States
localparam SWDP_SLETRNC     = 5'b01110;
localparam SWDP_SLERESC     = 5'b01111;
// Error States
localparam SWDP_SLEERR      = 5'b01001;

// X-prop state
localparam SWDP_SLEXXXX     = 5'bXXXXX;
//-----------------------------------------------------------------------------
// Internal register locations
//-----------------------------------------------------------------------------
//  Address  Register  Direction  Width  Reset       Description
//  0x0      AbortReg  W          32     0x00000000  Abort
//  0x0      IDReg     R          32     0x--------  IdCode
//  0x1      CSWReg    R/W        32     0x00000000  Control/Status (banked)
//  0x2      AddrReg   W          32     0x00000000  Address
//  0x2      Resend    R          32     0x00000000  Resend AP data
//  0x3      TargetSel W          32     0x--------  Target Select
//  0x3      RdBuffReg R          32     0x00000000  Read Buffer
localparam SWDP_ABORT       = 2'b00;   // Wr
localparam SWDP_IDCODE      = 2'b00;   // Rd
localparam SWDP_CTRL        = 2'b01;   // Wr
localparam SWDP_STAT        = 2'b01;   // Rd
localparam SWDP_ADDR        = 2'b10;   // Wr
localparam SWDP_RESEND      = 2'b10;   // Rd
localparam SWDP_TARGETSEL   = 2'b11;   // Wr
localparam SWDP_RDBUFF      = 2'b11;   // Rd

//-----------------------------------------------------------------------------
// Internal register banks for register 1
//-----------------------------------------------------------------------------
localparam SWDP_BNKCTRL     = 4'h0; // Control/Status Register
localparam SWDP_BNKWCR      = 4'h1; // Wire Control Register
localparam SWDP_BNKTARGETID = 4'h2; // Target Identification Register
localparam SWDP_BNKDLPIDR   = 4'h3; // Data Link Protocol Identification Register
localparam SWDP_BNKUNK4     = 4'h4;
localparam SWDP_BNKUNK5     = 4'h5;
localparam SWDP_BNKUNK6     = 4'h6;
localparam SWDP_BNKUNK7     = 4'h7;
localparam SWDP_BNKUNK8     = 4'h8;
localparam SWDP_BNKUNK9     = 4'h9;
localparam SWDP_BNKUNKA     = 4'hA;
localparam SWDP_BNKUNKB     = 4'hB;
localparam SWDP_BNKUNKC     = 4'hC;
localparam SWDP_BNKUNKD     = 4'hD;
localparam SWDP_BNKUNKE     = 4'hE;
localparam SWDP_BNKUNKF     = 4'hF;

//-----------------------------------------------------------------------------
// Serial Protocol bit meaning
//-----------------------------------------------------------------------------
localparam SWDP_STARTBIT = 1'b1;
localparam SWDP_SERREAD  = 1'b1;
localparam SWDP_SERWRITE = 1'b0;
localparam SWDP_APBREAD  = 1'b0;
localparam SWDP_APBWRITE = 1'b1;
localparam SWDP_DPREG    = 1'b0;
localparam SWDP_APREG    = 1'b1;

//-----------------------------------------------------------------------------
// SE protocol data count
//-----------------------------------------------------------------------------
localparam SWDP_CNT32 = 5'b11111;
