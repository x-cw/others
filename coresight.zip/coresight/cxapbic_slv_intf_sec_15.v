//-----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2011-2015 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//    Checked In : $Date: 2014-06-25 08:59:36 +0100 (Wed, 25 Jun 2014) $
//    Revision   : $Revision: 39630 $
//    Release    : CoreSight-SoC-TM100-r3p2-00rel0
//
//----------------------------------------------------------------------------
// Verilog-2001 (IEEE Std 1364-2001)
//----------------------------------------------------------------------------
// Purpose : APB Slave interface
//  This block provides address decoding to generate a one-hot vector
// (paddrs_decode) that indicates the master interface to which the access is
// addressed. It also validates that the access initiated decodes to a valid
// Master interface address range or to the ROM Table address range.
//  The dbgswen input determines whether accesses are allowed to be
// initiated by this slave interface instance. Slave interface 0 is expected
// to be connected in the fanout of the DAP APB-AP, so dbgswen for this
// slave interface instance is wired to 1 at the APBIC top-level.
//  If an access does not decode to a valid address range, or is not
// authenticated with the dbgswen signal, then the access is completed by
// the Slave interface block without initiating an access to the master
// interfaces.
//----------------------------------------------------------------------------
module cxapbic_slv_intf_sec_15
  (
  input wire clk,
  input wire resetn,
  
  input wire [3:0] paddrs_msb_to_12,
  input wire paddr31s,
  input wire psels,
  input wire penables,

  input wire pslverr_arbitrated,
  input wire pready_arbitrated,

  input wire dbgswen,

  output wire pslverrs,
  output wire preadys,
      
  output wire [14:0] paddrs_decode,
  output wire rom_table_sel
  );

//----------------------------------------------------------------------------
// Constants definitions
//----------------------------------------------------------------------------
`include "cxapbic_constants_sec_15.v"

//----------------------------------------------------------------------------
// Wire declarations
//----------------------------------------------------------------------------
wire def_slv_sel;         // Access does not decode to a known address space
wire dbgswen_smpl;        // dbgswen sampled at the start of an APB access
wire access_auth;         // Access to the APB is authenticated
wire pslverr_acc_in_prog; // pslverr when an access is in progress
wire pready_acc_in_prog;  // pready when an access is in progress
      
wire [14:0] paddrs_decode_int;
wire rom_table_sel_int;

//----------------------------------------------------------------------------
// Reg declarations
//----------------------------------------------------------------------------
reg dbgswen_smpl_reg; // Registered version of dbgswen_smpl
reg psels_reg;        // Registered version of psels

//-----------------------------------------------------------------------------
//
//  Main body of code
//  =================
//
//-----------------------------------------------------------------------------

      

//-----------------------------------------------------------------------------
// Access to APB is authenticated when the dbgswen input is high or the
// paddr31s input is high. The dbgswen input is pulled high when system
// accesses (ie. accesses originating from a non-debugger source) are allowed
// to the APB peripherals.
// Accesses with paddr31s = 1 are treated as external debugger accesses and
// are allowed regardless of authentication by dbgswen. At the top-level of the
// APBIC, paddr31s to Slave interface 0 is driven by the paddr31s0 top-level
// port. The paddr31s inputs of the other Slave interface instances, if
// configured to be present, are wired to 0 - this ensures that system accesses
// to the APB are only subject to dbgswen.
//-----------------------------------------------------------------------------
assign access_auth = dbgswen_smpl | paddr31s;

//-----------------------------------------------------------------------------
// Address decodes
//-----------------------------------------------------------------------------
// ROM table is at the lowest 4KB address space
  
assign rom_table_sel_int = psels & ~|paddrs_msb_to_12 & access_auth;
assign rom_table_sel = rom_table_sel_int;

assign paddrs_decode = paddrs_decode_int;

// Master 0 address range
// Base - MASTER_INTF0_BASE_ADDR
// Size - MASTER_INTF0_SIZE
        
assign paddrs_decode_int[0] = psels & access_auth &
                     (paddrs_msb_to_12[3:MASTER_INTF0_SIZE] ==
                      MASTER_INTF0_BASE_ADDR[3:MASTER_INTF0_SIZE]);
// Master 1 address range
// Base - MASTER_INTF1_BASE_ADDR
// Size - MASTER_INTF1_SIZE
        
assign paddrs_decode_int[1] = psels & access_auth &
                     (paddrs_msb_to_12[3:MASTER_INTF1_SIZE] ==
                      MASTER_INTF1_BASE_ADDR[3:MASTER_INTF1_SIZE]);
// Master 2 address range
// Base - MASTER_INTF2_BASE_ADDR
// Size - MASTER_INTF2_SIZE
        
assign paddrs_decode_int[2] = psels & access_auth &
                     (paddrs_msb_to_12[3:MASTER_INTF2_SIZE] ==
                      MASTER_INTF2_BASE_ADDR[3:MASTER_INTF2_SIZE]);
// Master 3 address range
// Base - MASTER_INTF3_BASE_ADDR
// Size - MASTER_INTF3_SIZE
        
assign paddrs_decode_int[3] = psels & access_auth &
                     (paddrs_msb_to_12[3:MASTER_INTF3_SIZE] ==
                      MASTER_INTF3_BASE_ADDR[3:MASTER_INTF3_SIZE]);
// Master 4 address range
// Base - MASTER_INTF4_BASE_ADDR
// Size - MASTER_INTF4_SIZE
        
assign paddrs_decode_int[4] = psels & access_auth &
                     (paddrs_msb_to_12[3:MASTER_INTF4_SIZE] ==
                      MASTER_INTF4_BASE_ADDR[3:MASTER_INTF4_SIZE]);
// Master 5 address range
// Base - MASTER_INTF5_BASE_ADDR
// Size - MASTER_INTF5_SIZE
        
assign paddrs_decode_int[5] = psels & access_auth &
                     (paddrs_msb_to_12[3:MASTER_INTF5_SIZE] ==
                      MASTER_INTF5_BASE_ADDR[3:MASTER_INTF5_SIZE]);
// Master 6 address range
// Base - MASTER_INTF6_BASE_ADDR
// Size - MASTER_INTF6_SIZE
        
assign paddrs_decode_int[6] = psels & access_auth &
                     (paddrs_msb_to_12[3:MASTER_INTF6_SIZE] ==
                      MASTER_INTF6_BASE_ADDR[3:MASTER_INTF6_SIZE]);
// Master 7 address range
// Base - MASTER_INTF7_BASE_ADDR
// Size - MASTER_INTF7_SIZE
        
assign paddrs_decode_int[7] = psels & access_auth &
                     (paddrs_msb_to_12[3:MASTER_INTF7_SIZE] ==
                      MASTER_INTF7_BASE_ADDR[3:MASTER_INTF7_SIZE]);
// Master 8 address range
// Base - MASTER_INTF8_BASE_ADDR
// Size - MASTER_INTF8_SIZE
        
assign paddrs_decode_int[8] = psels & access_auth &
                     (paddrs_msb_to_12[3:MASTER_INTF8_SIZE] ==
                      MASTER_INTF8_BASE_ADDR[3:MASTER_INTF8_SIZE]);
// Master 9 address range
// Base - MASTER_INTF9_BASE_ADDR
// Size - MASTER_INTF9_SIZE
        
assign paddrs_decode_int[9] = psels & access_auth &
                     (paddrs_msb_to_12[3:MASTER_INTF9_SIZE] ==
                      MASTER_INTF9_BASE_ADDR[3:MASTER_INTF9_SIZE]);
// Master 10 address range
// Base - MASTER_INTF10_BASE_ADDR
// Size - MASTER_INTF10_SIZE
        
assign paddrs_decode_int[10] = psels & access_auth &
                     (paddrs_msb_to_12[3:MASTER_INTF10_SIZE] ==
                      MASTER_INTF10_BASE_ADDR[3:MASTER_INTF10_SIZE]);
// Master 11 address range
// Base - MASTER_INTF11_BASE_ADDR
// Size - MASTER_INTF11_SIZE
        
assign paddrs_decode_int[11] = psels & access_auth &
                     (paddrs_msb_to_12[3:MASTER_INTF11_SIZE] ==
                      MASTER_INTF11_BASE_ADDR[3:MASTER_INTF11_SIZE]);
// Master 12 address range
// Base - MASTER_INTF12_BASE_ADDR
// Size - MASTER_INTF12_SIZE
        
assign paddrs_decode_int[12] = psels & access_auth &
                     (paddrs_msb_to_12[3:MASTER_INTF12_SIZE] ==
                      MASTER_INTF12_BASE_ADDR[3:MASTER_INTF12_SIZE]);
// Master 13 address range
// Base - MASTER_INTF13_BASE_ADDR
// Size - MASTER_INTF13_SIZE
        
assign paddrs_decode_int[13] = psels & access_auth &
                     (paddrs_msb_to_12[3:MASTER_INTF13_SIZE] ==
                      MASTER_INTF13_BASE_ADDR[3:MASTER_INTF13_SIZE]);
// Master 14 address range
// Base - MASTER_INTF14_BASE_ADDR
// Size - MASTER_INTF14_SIZE
        
assign paddrs_decode_int[14] = psels & access_auth &
                     (paddrs_msb_to_12[3:MASTER_INTF14_SIZE] ==
                      MASTER_INTF14_BASE_ADDR[3:MASTER_INTF14_SIZE]);
// Select default slave if the incoming address does not decode to any of the
// known address ranges or to the ROM table.
assign def_slv_sel = psels & ~(|paddrs_decode_int | rom_table_sel_int);
  

//-----------------------------------------------------------------------------
// Store the value of dbgswen when a new access request is detected - if
// dbgswen is LOW, the access is not propagated internally and an error is
// returned on the APB.
//-----------------------------------------------------------------------------
assign dbgswen_smpl = (psels & ~penables) ? dbgswen : dbgswen_smpl_reg;

//-----------------------------------------------------------------------------
// Sequential process to register dbgswen_smpl
//-----------------------------------------------------------------------------
always @(posedge clk or negedge resetn)
begin : p_dbgswen_smpl
  if (!resetn)
    dbgswen_smpl_reg <= 1'b0;
  else
    dbgswen_smpl_reg <= dbgswen_smpl;
end // p_dbgswen_smpl

//-----------------------------------------------------------------------------
// Detect whether an access is in progress.
// When an access is in progress, return the error/ready response from the
// addressed master interface. When there is no access in progress, return
// a default value of 1 on error/ready.
// Use the registered version of psels to help break synthesis timing path
// from psels to preadys/pslverrs.
//-----------------------------------------------------------------------------
assign pslverr_acc_in_prog = psels_reg ? pslverr_arbitrated : 1'b1;
assign pready_acc_in_prog  = psels_reg ? pready_arbitrated  : 1'b1;

//-----------------------------------------------------------------------------
// Sequential process to register psels
//-----------------------------------------------------------------------------
always @(posedge clk or negedge resetn)
begin : p_psels
  if (!resetn)
    psels_reg <= 1'b0;
  else
    psels_reg <= psels;
end // p_psels

//-----------------------------------------------------------------------------
// Return error if an access does not decode to any master interface
// If a master interface returns error, then propagate it to the slave interface
// A new access is not authenticated if dbgswen is low and there is a
// system access attempted. If new access is not permitted, then return an
// error.
//-----------------------------------------------------------------------------
assign pslverrs = def_slv_sel | pslverr_acc_in_prog;

//-----------------------------------------------------------------------------
// Return ready without initiating an access to a master interface
// if an access does not decode to any master interface.
// If a master interface returns error, then propagate it to the slave interface
// A new access is not authenticated if dbgswen is low and there is a
// system access attempted.
// If new access is not permitted, then complete the transfer immediately,
// since the access is not propagated internally.
//-----------------------------------------------------------------------------
assign preadys = def_slv_sel | pready_acc_in_prog;

`ifdef ARM_ASSERT_ON
//-----------------------------------------------------------------------------
// OVL Assertions
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
// Check for one-hot on select lines
//-----------------------------------------------------------------------------
// {def_slv_sel, rom_table_sel_int, paddrs_decode_int}
  wire [16:0] addr_decode_chk;
  assign addr_decode_chk = {def_slv_sel, rom_table_sel_int, paddrs_decode_int};
  assert_zero_one_hot #(`OVL_ERROR, 17, `OVL_ASSERT,
    "OVL Message : cxapbic_slv_intf_sec_15 - Multiple access targets selected at the same time.")
      uzovl_cxapbic_slv_intf_sec_15_psel_one_hot_chk
        (
         .clk         (clk),
         .reset_n     (resetn),
         .test_expr   (addr_decode_chk)
        );

//-----------------------------------------------------------------------------
// Check for alignment between MASTER_INTFn_BASE_ADDR and MASTER_INTFn_SIZE
// parameters.
//-----------------------------------------------------------------------------

  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxapbic_sec_15 - MASTER_INTF0_BASE_ADDR parameter value not aligned to MASTER_INTF0_SIZE parameter value.")
      uzovl_cxapbic_sec_15_param_chk_0
        (
         .clk         (clk),
         .reset_n     (resetn),
         .test_expr   ((MASTER_INTF0_BASE_ADDR % (1 << MASTER_INTF0_SIZE)) != 0)
        );

  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxapbic_sec_15 - MASTER_INTF1_BASE_ADDR parameter value not aligned to MASTER_INTF1_SIZE parameter value.")
      uzovl_cxapbic_sec_15_param_chk_1
        (
         .clk         (clk),
         .reset_n     (resetn),
         .test_expr   ((MASTER_INTF1_BASE_ADDR % (1 << MASTER_INTF1_SIZE)) != 0)
        );

  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxapbic_sec_15 - MASTER_INTF2_BASE_ADDR parameter value not aligned to MASTER_INTF2_SIZE parameter value.")
      uzovl_cxapbic_sec_15_param_chk_2
        (
         .clk         (clk),
         .reset_n     (resetn),
         .test_expr   ((MASTER_INTF2_BASE_ADDR % (1 << MASTER_INTF2_SIZE)) != 0)
        );

  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxapbic_sec_15 - MASTER_INTF3_BASE_ADDR parameter value not aligned to MASTER_INTF3_SIZE parameter value.")
      uzovl_cxapbic_sec_15_param_chk_3
        (
         .clk         (clk),
         .reset_n     (resetn),
         .test_expr   ((MASTER_INTF3_BASE_ADDR % (1 << MASTER_INTF3_SIZE)) != 0)
        );

  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxapbic_sec_15 - MASTER_INTF4_BASE_ADDR parameter value not aligned to MASTER_INTF4_SIZE parameter value.")
      uzovl_cxapbic_sec_15_param_chk_4
        (
         .clk         (clk),
         .reset_n     (resetn),
         .test_expr   ((MASTER_INTF4_BASE_ADDR % (1 << MASTER_INTF4_SIZE)) != 0)
        );

  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxapbic_sec_15 - MASTER_INTF5_BASE_ADDR parameter value not aligned to MASTER_INTF5_SIZE parameter value.")
      uzovl_cxapbic_sec_15_param_chk_5
        (
         .clk         (clk),
         .reset_n     (resetn),
         .test_expr   ((MASTER_INTF5_BASE_ADDR % (1 << MASTER_INTF5_SIZE)) != 0)
        );

  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxapbic_sec_15 - MASTER_INTF6_BASE_ADDR parameter value not aligned to MASTER_INTF6_SIZE parameter value.")
      uzovl_cxapbic_sec_15_param_chk_6
        (
         .clk         (clk),
         .reset_n     (resetn),
         .test_expr   ((MASTER_INTF6_BASE_ADDR % (1 << MASTER_INTF6_SIZE)) != 0)
        );

  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxapbic_sec_15 - MASTER_INTF7_BASE_ADDR parameter value not aligned to MASTER_INTF7_SIZE parameter value.")
      uzovl_cxapbic_sec_15_param_chk_7
        (
         .clk         (clk),
         .reset_n     (resetn),
         .test_expr   ((MASTER_INTF7_BASE_ADDR % (1 << MASTER_INTF7_SIZE)) != 0)
        );

  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxapbic_sec_15 - MASTER_INTF8_BASE_ADDR parameter value not aligned to MASTER_INTF8_SIZE parameter value.")
      uzovl_cxapbic_sec_15_param_chk_8
        (
         .clk         (clk),
         .reset_n     (resetn),
         .test_expr   ((MASTER_INTF8_BASE_ADDR % (1 << MASTER_INTF8_SIZE)) != 0)
        );

  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxapbic_sec_15 - MASTER_INTF9_BASE_ADDR parameter value not aligned to MASTER_INTF9_SIZE parameter value.")
      uzovl_cxapbic_sec_15_param_chk_9
        (
         .clk         (clk),
         .reset_n     (resetn),
         .test_expr   ((MASTER_INTF9_BASE_ADDR % (1 << MASTER_INTF9_SIZE)) != 0)
        );

  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxapbic_sec_15 - MASTER_INTF10_BASE_ADDR parameter value not aligned to MASTER_INTF10_SIZE parameter value.")
      uzovl_cxapbic_sec_15_param_chk_10
        (
         .clk         (clk),
         .reset_n     (resetn),
         .test_expr   ((MASTER_INTF10_BASE_ADDR % (1 << MASTER_INTF10_SIZE)) != 0)
        );

  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxapbic_sec_15 - MASTER_INTF11_BASE_ADDR parameter value not aligned to MASTER_INTF11_SIZE parameter value.")
      uzovl_cxapbic_sec_15_param_chk_11
        (
         .clk         (clk),
         .reset_n     (resetn),
         .test_expr   ((MASTER_INTF11_BASE_ADDR % (1 << MASTER_INTF11_SIZE)) != 0)
        );

  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxapbic_sec_15 - MASTER_INTF12_BASE_ADDR parameter value not aligned to MASTER_INTF12_SIZE parameter value.")
      uzovl_cxapbic_sec_15_param_chk_12
        (
         .clk         (clk),
         .reset_n     (resetn),
         .test_expr   ((MASTER_INTF12_BASE_ADDR % (1 << MASTER_INTF12_SIZE)) != 0)
        );

  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxapbic_sec_15 - MASTER_INTF13_BASE_ADDR parameter value not aligned to MASTER_INTF13_SIZE parameter value.")
      uzovl_cxapbic_sec_15_param_chk_13
        (
         .clk         (clk),
         .reset_n     (resetn),
         .test_expr   ((MASTER_INTF13_BASE_ADDR % (1 << MASTER_INTF13_SIZE)) != 0)
        );

  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxapbic_sec_15 - MASTER_INTF14_BASE_ADDR parameter value not aligned to MASTER_INTF14_SIZE parameter value.")
      uzovl_cxapbic_sec_15_param_chk_14
        (
         .clk         (clk),
         .reset_n     (resetn),
         .test_expr   ((MASTER_INTF14_BASE_ADDR % (1 << MASTER_INTF14_SIZE)) != 0)
        );


`endif

endmodule // cxapbic_slv_intf_sec_15

//-- END OF FILE --------------------------------------------------------------
