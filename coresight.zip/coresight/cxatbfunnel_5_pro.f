$GP3_RTL/coresight/rtl/coresight_component/trace_module/cxatbfunnel_5_pro/verilog/cxatbfunnel_5_pro.v
$GP3_RTL/coresight/rtl/coresight_component/trace_module/cxatbfunnel_5_pro/verilog/cxatbfunnel_apb_if_5_pro.v
$GP3_RTL/coresight/rtl/coresight_component/trace_module/cxatbfunnel_5_pro/verilog/cxatbfunnel_arbiter_5_pro.v
$GP3_RTL/coresight/rtl/coresight_component/trace_module/cxatbfunnel_5_pro/verilog/cxatbfunnel_reg_blk_5_pro.v
