//-----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2009-2010 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//    Checked In :  2010-06-21 18:34:18 +0530 (Mon, 21 Jun 2010) 
//    Revision   :  8322 
//    Release    : TM961-BU-50000-r0p0-00rel0
//
//-----------------------------------------------------------------------------
// Purpose : CoreSight Trace Memory Controller (CXTMC)      - ATB Formatter
//-----------------------------------------------------------------------------
//
//
// CXTMC  - CoreSight Trace Memory Controller
// ------------------------------------------
//
// CoreSight AMBA Trace Bus (ATB) sink/link device to store trace data in
// dedicated on chip Trace RAM or System RAM of configurable size.
//
// cxtmc_formatter.v
// -----------------
//
// cxtmc_formatter.v provides the formatting mechanism to optionally embed trace
// source IDs into the trace data stream.
//
// Instantiated blocks
// -------------------
// None
//-----------------------------------------------------------------------------


//---------------------------------------------------------------------------
// Constants definitions
//---------------------------------------------------------------------------


module cxtmc_formatter
  #(parameter CXTMC_ATB_DATA_WIDTH = 128,
    parameter CXTMC_ATBYTES_WIDTH = 4,
    parameter CXTMC_ITATBDATA0_WIDTH = 5)
  (
  // Inputs
  input wire         cxtmc_clk,            // Clock
  input wire         RESETn,               // Reset
  input wire         ATVALIDS,             // ATB valid signal
  input wire [(CXTMC_ATBYTES_WIDTH-1):0] ATBYTESS,
                                           // ATB valid number of bytes
  input wire [6:0]   ATIDS,                // ATB source ID
  input wire [(CXTMC_ATB_DATA_WIDTH-1):0] ATDATAS,
                                           // ATB trace data
  input wire         ffcr_en_formatting_masked,
                                           // Formatting enable
  input wire         ctl_trace_capt_en_0_1,
                                           // Indication that 0->1 transition on
                                           // ctl_trace_capt_en is sensed
  input wire         wb_ready,             // Formatter output interface ready
  input wire         nxt_wb_ready,         // D-Input of wb_ready
  input wire         ft_trig_req,          // Formatter trigger request
  input wire         ft_stop_req,          // Formatter stop request
  input wire         it_ctrl,              // Integration mode control register
  input wire         it_atb_ctr_2_wr_en,   // Write enable for ITATBCTR2
                                           // register
  input wire [31:0]  apb_wdata,            // APB write data bus
  input wire         ft_flush_req,         // Formatter flush request

  // Outputs
  output wire        ATREADYS,             // ATB ready
  output wire        ft_running_p0,        // ATB interface is accepting data
  output wire        ft_data_valid,        // Formatter output data valid
  output reg         ft_trig_ack,          // Return response to ft_trig_req
  output wire        ft_stopped,           // Return response to ft_stop_req
  output wire  [(CXTMC_ATB_DATA_WIDTH-1):0] ft_data,
                                           // Formatter data output
  output wire        trig_id_detect,       // Indication that trace ID detected
                                           // in trace stream
  output wire [(CXTMC_ITATBDATA0_WIDTH-1):0] it_atb_data_0,
                                           // Read data for ITATBDATA0 register
  output reg [6:0]   atids_p1,             // p1 stage sampled ATIDS
  output reg         atvalids_p1,          // p1 stage sampled ATVALIDS
  output reg [(CXTMC_ATBYTES_WIDTH-1):0] atbytess_p1,
                                           // p1 stage sampled ATBYTESS
  output wire        ft_flush_ack          // Formatter flush Acknowledge
  );
  
//------------------------------------------------------------------------------
// Constants definitions
//------------------------------------------------------------------------------

  localparam CXTMC_CTR_WIDTH = (CXTMC_ATB_DATA_WIDTH == 32) ? 2 : 1;

  localparam CXTMC_LBS_WIDTH = (CXTMC_ATB_DATA_WIDTH == 32) ? 6 : 4;

  localparam CXTMC_WRITESIZE_WIDTH = (CXTMC_ATB_DATA_WIDTH == 32) ? 3 :
                                     (CXTMC_ATB_DATA_WIDTH == 64) ? 4 : 5;
  
  localparam CXTMC_FIFOSIZE = (CXTMC_ATB_DATA_WIDTH == 32) ? 8 :
                              (CXTMC_ATB_DATA_WIDTH == 64) ? 16 : 32;

  localparam CXTMC_FIFOSIZE_WIDTH = (CXTMC_ATB_DATA_WIDTH == 32) ? 4 :
                                    (CXTMC_ATB_DATA_WIDTH == 64) ? 5 : 6;

  localparam CXTMC_ROTATOR_WIDTH = (CXTMC_ATB_DATA_WIDTH == 32) ? 72 :
                                   (CXTMC_ATB_DATA_WIDTH == 64) ? 144 : 288;

  localparam CXTMC_HALFROTATOR_WIDTH = (CXTMC_ATB_DATA_WIDTH == 32) ? 36 :
                                       (CXTMC_ATB_DATA_WIDTH == 64) ? 72 : 144;

  localparam CXTMC_FIFOREG8_WIDTH = (CXTMC_ATB_DATA_WIDTH == 32) ? 8 : 9;

  localparam CXTMC_FIFOREG16_WIDTH = (CXTMC_ATB_DATA_WIDTH == 64) ? 8 : 9;

  localparam CXTMC_WRITESIZE_MAX_VALUE = ({1'b1,
                                           {(CXTMC_WRITESIZE_WIDTH-1){1'b0}}});

  localparam CXTMC_WRITESIZE_ONE = ({{(CXTMC_WRITESIZE_WIDTH-1){1'b0}}, 1'b1});

  localparam CXTMC_GT_32 = (CXTMC_ATB_DATA_WIDTH == 32) ? 0 : 1;

  localparam CXTMC_MAX_ATB_BYTES_WITHID_CHANGE = (CXTMC_ATB_DATA_WIDTH == 32) ? 5 :
                                       (CXTMC_ATB_DATA_WIDTH == 64) ? 9 : 17;
  // Stop sequence state machine
  localparam FORM_STOP_STATE_STOPPED     = 3'b000;
  localparam FORM_STOP_STATE_RUNNING     = 3'b001;
  localparam FORM_STOP_STATE_P1_ALIGN    = 3'b010;
  localparam FORM_STOP_STATE_FINAL_ONE   = 3'b011;
  localparam FORM_STOP_STATE_P2_ALIGN    = 3'b100;
  localparam FORM_STOP_STATE_FLUSH1      = 3'b101;
  localparam FORM_STOP_STATE_FLUSH2      = 3'b110;
  localparam FORM_STOP_STATE_FRAME_ALIGN = 3'b111;
  localparam FORM_STOP_STATE_DEFAULT     = 3'bxxx;

  //----------------------------------------------------------------------------
  // Wires
  //----------------------------------------------------------------------------

  wire        sample_atb_p0;           // Sample ATB interface

  // p1 stage logic
  wire        atb_valid_p1;            // p1 stage is valid
  wire [(CXTMC_WRITESIZE_WIDTH-1):0] atb_size_p1;
                                       // Actual size of data in p1,inc ATVALID
  wire [(CXTMC_FIFOSIZE_WIDTH-1):0] fifo_size_after_read_p1;
                                       // Intermediate calculation
  wire [(CXTMC_FIFOSIZE_WIDTH-1):0] fifo_size_after_write_p1;
                                       // Intermediate calculation
  wire [(CXTMC_WRITESIZE_WIDTH-1):0] write_size_noid_p1;
                                       // Intermediate calculation
  wire [(CXTMC_FIFOSIZE_WIDTH-1):0] fifo_size_p1;
                                       // Fifo size as of p1 stage
  wire        insert_special_p1;       // Insert a special packet, which one of:
  wire        insert_trigger_p1;       // A trigger
  wire        insert_one_p1;           // A byte of 0x01 (bypass end sequence)
  wire        insert_null_p1;          // Null
  reg         first_id_not_fmted;      // Indication that first id is not
                                       // formatted
  wire        nxt_first_id_not_fmted;  // D-Input of first_id_not_fmted
  
  wire        repeat_id_p1;            // Force a new ID
  wire [3:0]  frames_since_id_change_p1;
                                       // Input to frames_since_id_change_p2

  // Formatter fifo input interface
  wire [6:0]  ftin_id_p1;              // ID value to be inserted to the FIFO
  wire        ftin_id_valid_p1;        // Whether to insert a new ID
  wire [(CXTMC_ATB_DATA_WIDTH-1):0] ftin_data_p1;
                                       // Data to be inserted
  wire [(CXTMC_WRITESIZE_WIDTH-1):0] write_size_p1;
                                       // Number of bytes (including ID) written
  wire        ftin_accept_p1;          // Whether the data will be accepted
                                       // this cycle.
                                       // If this is high but write_size_p1
                                       // is 0, no data is written.
  wire        atb_accept_p1;           // Accepting ATB p1 data
  wire        ftin_accept_nonnull_p1;  // Some data actually written this cycle

  // Stop state machine
  reg         form_stop_state_en;      // Update state machine
  reg [2:0]   nxt_form_stop_state;     // Next state
  wire        ft_flushing_p0;          // Formatter is flushing internal data
                                       // by stalling ATB bus
  wire        stop_seq_ended_p2;       // Stopped outputting data
  wire        stop_position_p2;        // We are performing a read this cycle
                                       // where it is legal to stop formatter
  wire        stop_position_p1;        // We are performing a read this cycle
                                       // where it is legal to stop formatter

  // Read and write control signals
  wire [(CXTMC_WRITESIZE_WIDTH-1):0] read_size_p1;
                                       // Formatter fifo read data size 1 cycle
                                       // in advance
  wire [(CXTMC_WRITESIZE_WIDTH-1):0] read_size_p2;
                                       // Formatter fifo read data size
   
  wire        read_not_frame_end_p2;   // Indication the current data draining
                                       // from fifo is of full data width
  wire        read_not_frame_end_p1;   // Indication the current data draining
                                       // from fifo is of full data width
  wire        read_frame_end_p2;       // Indication the current data draining
                                       // from fifo is end of frame
  wire        read_frame_end_p1;       // Indication the current data draining
                                       // from fifo is end of frame
  wire        read_nothing_p2;         // Essentially ~ft_data_valid_p2
  wire [(CXTMC_ATB_DATA_WIDTH-1):0] ft_data_p2;
                                       // A reminder that ft_data is a p2 signal
  wire        ft_data_valid_p2;        // ... as is ft_data_valid

  // Misc signals
  wire        nxt_ft_trig_ack;         // D-Input of ft_trig_ack register
  wire [(CXTMC_WRITESIZE_WIDTH-1):0] rotation_p1;
                                       // Amount to rotate input data to
                                       // formatter FIFO
  wire [(CXTMC_CTR_WIDTH-1):0] frame_pos_ctr_p1;  
                                       // D-Input of frame_pos_ctr_p2 register
  wire [(CXTMC_ROTATOR_WIDTH-1):0] rotator_out;
                                       // Rotator output which is written into
                                       // formatter fifo
  wire [(CXTMC_HALFROTATOR_WIDTH-1):0] rotate1;
                                       // Intermediate vector to hold 1 left
                                       // shift of trace data
  wire [(CXTMC_HALFROTATOR_WIDTH-1):0] rotate2;
                                       // Intermediate vector to hold 2 left
                                       // shift of trace data
  wire [(CXTMC_HALFROTATOR_WIDTH-1):0] rotate4;
                                       // Intermediate vector to hold 4 left
                                       // shift of trace data
  // vvv This signal only used in 64-bit and 128-bit configs
  wire [(CXTMC_HALFROTATOR_WIDTH-1):0] rotate8;
                                       // Rotate left by 3 position
  wire [(CXTMC_HALFROTATOR_WIDTH-1):0] rotate16;
                                       // Rotate left by 4 position
  // ^^^
  wire        fifo_reg1_en;            // Enable for fifo_reg1 register
  wire        fifo_reg2_en;            // Enable for fifo_reg2 register
  wire        fifo_reg3_en;            // Enable for fifo_reg3 register
  wire        fifo_reg4_en;            // Enable for fifo_reg4 register
  wire        fifo_reg5_en;            // Enable for fifo_reg5 register
  wire        fifo_reg6_en;            // Enable for fifo_reg6 register
  wire        fifo_reg7_en;            // Enable for fifo_reg7 register
  wire        fifo_reg8_en;            // Enable for fifo_reg8 register
  wire [8:0]  nxt_fifo_reg1;           // D-Input of fifo_reg1 register
  wire [8:0]  nxt_fifo_reg2;           // D-Input of fifo_reg2 register
  wire [8:0]  nxt_fifo_reg3;           // D-Input of fifo_reg3 register
  wire [8:0]  nxt_fifo_reg4;           // D-Input of fifo_reg3 register
  wire [8:0]  nxt_fifo_reg5;           // D-Input of fifo_reg5 register
  wire [8:0]  nxt_fifo_reg6;           // D-Input of fifo_reg6 register
  wire [8:0]  nxt_fifo_reg7;           // D-Input of fifo_reg7 register
  wire [(CXTMC_FIFOREG8_WIDTH-1):0] nxt_fifo_reg8;
                                       // D-Input of fifo_reg8 register
  // vvv This block of wires used only in 64-bit and 128-bit configs
  wire        fifo_reg17_en;           // Enable for fifo_reg17 register
  wire        fifo_reg18_en;           // Enable for fifo_reg18 register
  wire        fifo_reg19_en;           // Enable for fifo_reg19 register
  wire        fifo_reg20_en;           // Enable for fifo_reg20 register
  wire        fifo_reg21_en;           // Enable for fifo_reg21 register
  wire        fifo_reg22_en;           // Enable for fifo_reg22 register
  wire        fifo_reg23_en;           // Enable for fifo_reg23 register
  wire        fifo_reg24_en;           // Enable for fifo_reg24 register
  wire        fifo_reg25_en;           // Enable for fifo_reg25 register
  wire        fifo_reg26_en;           // Enable for fifo_reg26 register
  wire        fifo_reg27_en;           // Enable for fifo_reg27 register
  wire        fifo_reg28_en;           // Enable for fifo_reg28 register
  wire        fifo_reg29_en;           // Enable for fifo_reg29 register
  wire        fifo_reg30_en;           // Enable for fifo_reg30 register
  wire        fifo_reg31_en;           // Enable for fifo_reg31 register
  wire        fifo_reg32_en;           // Enable for fifo_reg32 register
  wire [8:0]  nxt_fifo_reg17;          // D-Input of fifo_reg17 register
  wire [8:0]  nxt_fifo_reg18;          // D-Input of fifo_reg18 register
  wire [8:0]  nxt_fifo_reg19;          // D-Input of fifo_reg19 register
  wire [8:0]  nxt_fifo_reg20;          // D-Input of fifo_reg20 register
  wire [8:0]  nxt_fifo_reg21;          // D-Input of fifo_reg21 register
  wire [8:0]  nxt_fifo_reg22;          // D-Input of fifo_reg22 register
  wire [8:0]  nxt_fifo_reg23;          // D-Input of fifo_reg23 register
  wire [8:0]  nxt_fifo_reg24;          // D-Input of fifo_reg24 register
  wire [8:0]  nxt_fifo_reg25;          // D-Input of fifo_reg25 register
  wire [8:0]  nxt_fifo_reg26;          // D-Input of fifo_reg26 register
  wire [8:0]  nxt_fifo_reg27;          // D-Input of fifo_reg27 register
  wire [8:0]  nxt_fifo_reg28;          // D-Input of fifo_reg28 register
  wire [8:0]  nxt_fifo_reg29;          // D-Input of fifo_reg29 register
  wire [8:0]  nxt_fifo_reg30;          // D-Input of fifo_reg30 register
  wire [8:0]  nxt_fifo_reg31;          // D-Input of fifo_reg31 register
  wire [7:0]  nxt_fifo_reg32;          // D-Input of fifo_reg32 register
  // ^^^
  wire        equal_0;                 // Formatter fifo is empty
  wire        le_eq_1;                 // Formatter fifo has <= 1 entries
  wire        le_eq_2;                 // Formatter fifo has <= 2 entries
  wire        le_eq_2_p1;              // Formatter fifo has <= 2 entries
  wire        le_eq_3;                 // Formatter fifo has <= 3 entries
  wire        le_eq_3_p1;              // Formatter fifo has <= 3 entries
  wire        le_eq_4;                 // Formatter fifo has <= 4 entries
  wire        le_eq_5;                 // Formatter fifo has <= 5 entries
  wire        le_eq_6;                 // Formatter fifo has <= 6 entries
  wire        le_eq_6_p1;              // Formatter fifo has <= 6 entries
  wire        le_eq_7;                 // Formatter fifo has <= 7 entries
  wire        le_eq_7_p1;              // Formatter fifo has <= 7 entries

  // vvv This block of wires used only in 64-bit and 128-bit configs
  wire        le_eq_8;                 // Formatter fifo has <= 8 entries
  wire        le_eq_9;                 // Formatter fifo has <= 9 entries
  wire        le_eq_10;                // Formatter fifo has <= 10 entries
  wire        le_eq_11;                // Formatter fifo has <= 11 entries
  wire        le_eq_12;                // Formatter fifo has <= 12 entries
  wire        le_eq_13;                // Formatter fifo has <= 13 entries
  wire        le_eq_14;                // Formatter fifo has <= 14 entries
  wire        le_eq_14_p1;             // Formatter fifo has <= 14 entries
  wire        le_eq_15;                // Formatter fifo has <= 15 entries
  wire        le_eq_15_p1;             // Formatter fifo has <= 15 entries

  wire        le_eq_16;                // Formatter fifo has <= 16 entries
  wire        le_eq_17;                // Formatter fifo has <= 17 entries
  wire        le_eq_18;                // Formatter fifo has <= 18 entries
  wire        le_eq_19;                // Formatter fifo has <= 19 entries
  wire        le_eq_20;                // Formatter fifo has <= 20 entries
  wire        le_eq_21;                // Formatter fifo has <= 21 entries
  wire        le_eq_22;                // Formatter fifo has <= 22 entries
  wire        le_eq_23;                // Formatter fifo has <= 23 entries
  wire        le_eq_24;                // Formatter fifo has <= 24 entries
  wire        le_eq_25;                // Formatter fifo has <= 25 entries
  wire        le_eq_26;                // Formatter fifo has <= 26 entries
  wire        le_eq_27;                // Formatter fifo has <= 27 entries
  wire        le_eq_28;                // Formatter fifo has <= 28 entries
  wire        le_eq_29;                // Formatter fifo has <= 29 entries
  wire        le_eq_30;                // Formatter fifo has <= 30 entries
  wire        le_eq_31;                // Formatter fifo has <= 31 entries
  // ^^^

  // vvv This signal only used in 32-bit and 64-bit configs
  wire [(CXTMC_LBS_WIDTH-1):0] nxt_lbs;
                                       // D-Input of lbs register
  wire [(CXTMC_LBS_WIDTH-1):0] lbs_mask;
                                       // Mask for Last Byte Strobe generation
  // ^^^
  wire        assert_atreadys_p0;      // D-Input of assert_atreadys_p1 register
  wire        atbdata_in_hold_p1;      // D-Input of atbdata_in_hold_p2 register
  wire        nxt_it_atb_ctr_2_atreadys;
                                       // D-Input of it_atb_ctr_2_atreadys
  wire        repeat_id_sustain;       // Sustain the repeat id signal
  
  //----------------------------------------------------------------------------
  // Registers
  //----------------------------------------------------------------------------

  // FIFO Registers
  reg [8:0]   fifo_reg1;               // 1st storage entry for formatter fifo
  reg [8:0]   fifo_reg2;               // 2nd storage entry for formatter fifo
  reg [8:0]   fifo_reg3;               // 3rd storage entry for formatter fifo
  reg [8:0]   fifo_reg4;               // 4th storage entry for formatter fifo
  reg [8:0]   fifo_reg5;               // 5th storage entry for formatter fifo
  reg [8:0]   fifo_reg6;               // 6th storage entry for formatter fifo
  reg [8:0]   fifo_reg7;               // 7th storage entry for formatter fifo
  reg [(CXTMC_FIFOREG8_WIDTH-1):0] fifo_reg8;
                                       // 8th storage entry for formatter fifo
  // vvv This block of regs used only in 64-bit and 128-bit configs
  reg [8:0]   fifo_reg9;               // 9th storage entry for formatter fifo
  reg [8:0]   fifo_reg10;              // 10th storage entry for formatter fifo
  reg [8:0]   fifo_reg11;              // 11th storage entry for formatter fifo
  reg [8:0]   fifo_reg12;              // 12th storage entry for formatter fifo
  reg [8:0]   fifo_reg13;              // 13th storage entry for formatter fifo
  reg [8:0]   fifo_reg14;              // 14th storage entry for formatter fifo
  reg [8:0]   fifo_reg15;              // 15th storage entry for formatter fifo
  reg  [(CXTMC_FIFOREG16_WIDTH-1):0] fifo_reg16;
                                       // 16th storage entry for formatter fifo
  reg [8:0]   fifo_reg17;              // 17th storage entry for formatter fifo
  reg [8:0]   fifo_reg18;              // 18th storage entry for formatter fifo
  reg [8:0]   fifo_reg19;              // 19th storage entry for formatter fifo
  reg [8:0]   fifo_reg20;              // 20th storage entry for formatter fifo
  reg [8:0]   fifo_reg21;              // 21th storage entry for formatter fifo
  reg [8:0]   fifo_reg22;              // 22th storage entry for formatter fifo
  reg [8:0]   fifo_reg23;              // 23th storage entry for formatter fifo
  reg [8:0]   fifo_reg24;              // 24th storage entry for formatter fifo
  reg [8:0]   fifo_reg25;              // 25th storage entry for formatter fifo
  reg [8:0]   fifo_reg26;              // 26th storage entry for formatter fifo
  reg [8:0]   fifo_reg27;              // 27th storage entry for formatter fifo
  reg [8:0]   fifo_reg28;              // 28th storage entry for formatter fifo
  reg [8:0]   fifo_reg29;              // 29th storage entry for formatter fifo
  reg [8:0]   fifo_reg30;              // 30th storage entry for formatter fifo
  reg [8:0]   fifo_reg31;              // 31st storage entry for formatter fifo
  reg [7:0]   fifo_reg32;              // 32nd storage entry for formatter fifo
  // ^^^
 
  reg [6:0]   ftin_id_p2;              // This register holds the ATID value
                                       // which will be inserted in formatter
                                       // after taking into consideration
                                       // trigger/trace/stop sequence
  reg [(CXTMC_FIFOSIZE_WIDTH-1):0] fifo_size_p2;
                                       // Indication of fifo size for formatter
  // vvv This signal only used in 32-bit and 64-bit configs
  reg [(CXTMC_LBS_WIDTH-1):0] lbs;     // Control byte of the formatted frame
  // ^^^

  reg [(CXTMC_ATB_DATA_WIDTH-1):0] atdatas_p1;
                                       // p1 stage sampled ATDATAS
  
  reg         sample_atb_p1;           // Did we sample the ATB interface last
                                       // cycle?
  reg         atb_valid_p2;            // Registered version of atb_valid_p1
  reg [2:0]   form_stop_state;         // Formatter stop sequence state machine
  reg [(CXTMC_CTR_WIDTH-1):0] frame_pos_ctr_p2;
                                       // Number of p2 transfers through the
                                       // frame
  reg  [3:0]  frames_since_id_change_p2;
                                       // Counter of number of frames without a
                                       // new ID
  reg         atb_accept_p2;           // Accepting ATB p2 data

  reg         atbdata_in_hold_p2;      // Indication that the ATB data is
                                       // accepted, but not written into
                                       // formatter FIFO.
  reg         it_atb_ctr_2_atreadys;   // Integration support for ATREADYS
  reg         ft_flush_req_del;        // Delayed version of ft_flush_req
  reg         assert_atreadys_p1;      // Indication that ATREADYS can be
                                       // asserted in the current cycle

  //============================================================================
  //
  // Main body of code
  // =================
  //
  //============================================================================
 
  // External world gets to see p2 versions of signals
  assign ft_stopped = stop_seq_ended_p2 & ft_stop_req;
  assign ft_data = ft_data_p2;
  assign ft_data_valid = ft_data_valid_p2;

  //============================================================================
  // Indication that the ATB data is accepted but not written into Formatter
  // FIFO.
  //============================================================================
  assign atbdata_in_hold_p1 = (sample_atb_p1 && !ftin_accept_p1) ? 1'b1 :
                              (atbdata_in_hold_p2 && ftin_accept_p1) ? 1'b0 :
                               atbdata_in_hold_p2; 

  //============================================================================
  // Integration support for ATREADYS
  //============================================================================
  assign nxt_it_atb_ctr_2_atreadys = (it_atb_ctr_2_wr_en) ?
                                          apb_wdata[0] : it_atb_ctr_2_atreadys;

  always @(posedge cxtmc_clk or negedge RESETn)
    begin
      if (!RESETn)
        begin
          it_atb_ctr_2_atreadys  <= 1'b0;
        end
      else
        begin
          it_atb_ctr_2_atreadys  <= nxt_it_atb_ctr_2_atreadys;
        end
    end

  //============================================================================
  // Integration support for ATDATAS
  //============================================================================
  generate
    if (CXTMC_ATB_DATA_WIDTH == 32)
      assign it_atb_data_0 = {atdatas_p1[31], atdatas_p1[23], atdatas_p1[15],
                              atdatas_p1[7], atdatas_p1[0]};
    else if (CXTMC_ATB_DATA_WIDTH == 64)
      assign it_atb_data_0 = {atdatas_p1[63], atdatas_p1[55], atdatas_p1[47],
                              atdatas_p1[39], atdatas_p1[31], atdatas_p1[23],
                              atdatas_p1[15], atdatas_p1[7], atdatas_p1[0]};
    else // 128-bit ATB
      assign it_atb_data_0 = {atdatas_p1[127], atdatas_p1[119], atdatas_p1[111],
                              atdatas_p1[103], atdatas_p1[95], atdatas_p1[87],
                              atdatas_p1[79], atdatas_p1[71], atdatas_p1[63],
                              atdatas_p1[55], atdatas_p1[47], atdatas_p1[39],
                              atdatas_p1[31], atdatas_p1[23], atdatas_p1[15],
                              atdatas_p1[7], atdatas_p1[0]};
  endgenerate
  //============================================================================
  // p0 pipeline stage -- ATB sampling.
  //============================================================================

  // Sample ATB interface when p1 data is accepted, or there is no p1 data to
  // accept.
  // Don't sample when we are stopped (minor power saving).
  assign sample_atb_p0 = it_ctrl | (atb_accept_p1 & ft_running_p0 & ~ft_flushing_p0);
  
  // Force high if we have had a stop request.
  assign ATREADYS = (it_ctrl) ? it_atb_ctr_2_atreadys :
                                  ((assert_atreadys_p1 &
                                    ~insert_special_p1) & ~ft_flushing_p0) |
                                   ~ft_running_p0;

  // Indication that the ATREADYS could be potentially be asserted in
  // current cycle
  assign assert_atreadys_p0 = (ATVALIDS || atbdata_in_hold_p2 ||
                               insert_special_p1) ?
                               (fifo_size_p1 +
                                CXTMC_MAX_ATB_BYTES_WITHID_CHANGE -
                                read_size_p1) <= CXTMC_FIFOSIZE :
                                (fifo_size_after_write_p1 -
                                 read_size_p1) < CXTMC_FIFOSIZE;
                        

  // Sequential process to realize the p1 registers
  always @(posedge cxtmc_clk or negedge RESETn)
    begin : p_ftseq_p1_reg
      if (!RESETn)
        begin
          atbytess_p1         <= {CXTMC_ATBYTES_WIDTH{1'b0}};
          atvalids_p1         <= 1'b0;
          atids_p1            <= 7'b0;
          atdatas_p1          <= {CXTMC_ATB_DATA_WIDTH{1'b0}};
          sample_atb_p1       <= 1'b0;
          assert_atreadys_p1  <= 1'b0;
        end               
      else
        begin
          if (sample_atb_p0)
            begin
              atdatas_p1          <= ATDATAS;
              atbytess_p1         <= ATBYTESS;
              atvalids_p1         <= ATVALIDS;
              atids_p1            <= ATIDS;
            end
          sample_atb_p1      <= sample_atb_p0;
          assert_atreadys_p1 <= assert_atreadys_p0;
        end
    end // p_ftseq_p1_reg

  // Sequential process to realize the p2 registers
  always @(posedge cxtmc_clk or negedge RESETn)
    begin : p_ftseq_p2_reg
      if (!RESETn)
        begin
          atb_accept_p2       <= 1'b0;
          atbdata_in_hold_p2  <= 1'b0;
        end               
      else
        begin
          atb_accept_p2       <= atb_accept_p1;
          atbdata_in_hold_p2  <= atbdata_in_hold_p1;
        end
    end // p_ftseq_p2_reg

  //============================================================================
  // p1 pipeline stage -- formatter fifo data input.
  //============================================================================

  // Maintain a separate register to indicate whether the p1 ATB registers have
  // valid data in them.  Normally this is just atvalids_p1, but we need to mark
  // the data as invalid when we have a stop request.
  assign atb_valid_p1 = (sample_atb_p1 ? atvalids_p1 : 
                                        (atb_valid_p2 & ~atb_accept_p2)) &
                        ~stop_seq_ended_p2;

  // Actual number of bytes presented to the ATB interface.  This is ATBYTES+1
  // if ATVALID, otherwise 0.  We need to add an extra bit to the width of the
  // signal at this point.
  assign atb_size_p1 = (atb_valid_p1 ? 
                        ({1'b0, atbytess_p1} + CXTMC_WRITESIZE_ONE) :
                        {CXTMC_WRITESIZE_WIDTH{1'b0}});

  assign fifo_size_after_read_p1 = fifo_size_p2 - read_size_p2;

  assign fifo_size_after_write_p1 = fifo_size_after_read_p1 + write_size_p1;

  // We are accepting data into the formatter fifo
  assign ftin_accept_p1 = assert_atreadys_p1 &
                          (fifo_size_after_write_p1 <= CXTMC_FIFOSIZE);

  // We are accepting data out of the ATB p1 stage.  This doesn't include
  // specials, and we immediately accept p1 data if the p1 stage is empty.
  assign atb_accept_p1 = ATREADYS & assert_atreadys_p1;

  // Current FIFO size.  This is cleared once we stop the formatter, since
  // there might be some data hanging around.
  assign fifo_size_p1 = (stop_seq_ended_p2 ? {CXTMC_FIFOSIZE_WIDTH{1'b0}} :
                         ftin_accept_p1 ? fifo_size_after_write_p1 : 
                         fifo_size_after_read_p1);

  // These input terms are mutually exclusive (an assertion verifies this)
  assign insert_special_p1 = insert_trigger_p1 | insert_one_p1 | insert_null_p1;

  // Insert a trigger.  This cannot be driven when the formatter is bypassed.
  assign insert_trigger_p1 = ft_trig_req & ~ft_trig_ack;

  // Output to the trigger control logic when we have traced a trigger ID
  assign trig_id_detect = (atids_p1 == 7'b1111101) &
                          ftin_accept_nonnull_p1 & ~insert_special_p1;

  // Bytes we are attempting to write to the FIFO, not including ID change
  assign write_size_noid_p1 = (({CXTMC_WRITESIZE_WIDTH{insert_trigger_p1}} &
                                CXTMC_WRITESIZE_ONE) |
                               ({CXTMC_WRITESIZE_WIDTH{insert_one_p1}} &
                                CXTMC_WRITESIZE_ONE) |
                               ({CXTMC_WRITESIZE_WIDTH{insert_null_p1}} &
                                CXTMC_WRITESIZE_MAX_VALUE) |
                               ({CXTMC_WRITESIZE_WIDTH{~insert_special_p1}} &
                                atb_size_p1));

  // Total bytes we are attempting to bytes to the FIFO, including ID change.
  // We only add a byte for the ID change if we are tracing something.
  assign write_size_p1 = ((ftin_id_valid_p1 &&
                          (insert_special_p1 || atb_valid_p1)) ? 
                          (write_size_noid_p1 + CXTMC_WRITESIZE_ONE) :
                          write_size_noid_p1);

  // ID change this cycle
  assign ftin_id_valid_p1 = ((ftin_id_p1 != ftin_id_p2) |
                             first_id_not_fmted |
                             repeat_id_p1) &
                             ffcr_en_formatting_masked;

  // ID to store in the formatter FIFO, if any.
  // Capture the ID for future comparison only when real data is written
  // to the FIFO.  Note that the last ID will always be cleared to 0 when
  // the formatter is stopped, because zeros on ID 0 are always written
  // into the FIFO as part of the stop sequence.
  assign ftin_id_p1 = (({7{insert_trigger_p1}} & 7'b1111101) |
                       ({7{insert_one_p1}} & 7'b0000000) |
                       ({7{insert_null_p1}} & 7'b0000000) |
                       ({7{~insert_special_p1}} & atids_p1));

  assign nxt_first_id_not_fmted = ctl_trace_capt_en_0_1 |
                                   (~(ftin_id_valid_p1 &
                                      ftin_accept_nonnull_p1) &
                                    first_id_not_fmted);

  always @(posedge cxtmc_clk or negedge RESETn)
    begin : p_first_id_not_fmted_seq
      if (!RESETn)
        begin
          first_id_not_fmted  <= 1'b0;
        end               
      else
        begin
          first_id_not_fmted  <= nxt_first_id_not_fmted;
        end
    end // p_first_id_not_fmted_seq

  // Used to capture the ID.  
  assign ftin_accept_nonnull_p1 = ftin_accept_p1 & |(write_size_p1);

  // Data to store in the formatter FIFO, if any.
  assign ftin_data_p1 = (({CXTMC_ATB_DATA_WIDTH{insert_trigger_p1}} &
                          {CXTMC_ATB_DATA_WIDTH{1'b0}}) |
                         ({CXTMC_ATB_DATA_WIDTH{insert_one_p1}} &
                          {{CXTMC_ATB_DATA_WIDTH-1{1'b0}},1'b1}) |
                         ({CXTMC_ATB_DATA_WIDTH{insert_null_p1}} & 
                          {CXTMC_ATB_DATA_WIDTH{1'b0}}) |
                         ({CXTMC_ATB_DATA_WIDTH{~insert_special_p1}} &
                          atdatas_p1));

  // Acknowledge the trigger request when we accept it into the formatter FIFO.
  assign nxt_ft_trig_ack = insert_trigger_p1 & ftin_accept_p1;

  assign repeat_id_sustain = stop_position_p2 &
                             (form_stop_state == FORM_STOP_STATE_FRAME_ALIGN) &
                              ft_flush_req;

  // Count the number of frames since the last ID change.
  assign frames_since_id_change_p1 = ((ftin_id_valid_p1 && ftin_accept_p1  &&
                                       !repeat_id_sustain &&
                                       |(write_size_p1)) || ft_stopped ? 4'b0000 :
                                       read_frame_end_p2 ?
                                            frames_since_id_change_p2 + 4'b0001 :
                                             frames_since_id_change_p2);

  // We have gone 10 frames without an ID change -- repeat it.
  // Actually we count 8 frames to allow for some pipelining in
  // write buffer.  With wider trace ports the write buffer pipelining
  // will be greater; We aren't aiming for a totally precise count, so this
  // should be acceptable.
  assign repeat_id_p1 = frames_since_id_change_p2[3];

  // p2 registers
  always @(posedge cxtmc_clk or negedge RESETn)
    if (!RESETn)
      begin
        ftin_id_p2                <= {7{1'b0}};
        fifo_size_p2              <= {CXTMC_FIFOSIZE_WIDTH{1'b0}};
        ft_trig_ack               <= 1'b0;
        frames_since_id_change_p2 <= 4'b0000;
        atb_valid_p2              <= 1'b0;
      end               
    else
      begin
        if (ftin_accept_nonnull_p1)
          ftin_id_p2              <= ftin_id_p1;
        fifo_size_p2              <= fifo_size_p1;
        ft_trig_ack               <= nxt_ft_trig_ack;
        frames_since_id_change_p2 <= frames_since_id_change_p1;
        atb_valid_p2              <= atb_valid_p1;
      end

  //============================================================================
  // Stop sequence handling
  //============================================================================

  // This state machine controls the sequence of events when a stop request is
  // received. It ensures the formatter is drained and a stop sequence is output.

  // Once disabled, the formatter fifo itself is cleared.  This is because it is
  // easier to write a little bit too much data into the fifo and then clear it,
  // than it is to precisely calculate how much data should be written into the
  // fifo.

  // The precise amount of data to be traced at the end is dependent upon the
  // position through the frame.  For simplicity, the FIFO is assumed to be
  // full -- this results in a bit more data being traced than required.

  // This state machine controls activities across multiple pipeline stages,
  // and therefore requires special handling to ensure the control signals that
  // stem from it are aligned to the correct stage.

  // The formatter always goes through a precise sequence when stopping.  The
  // following waveform shows the sequence when the formatter is disabled:

  // Cycle no           1   2   3   4   5   6   7   8   9  10  11  12  13
  //                   _   _   _   _   _   _   _   _   _   _   _   _   _
  // cxtmc_clk          \_/ \_/ \_/ \_/ \_/ \_/ \_/ \_/ \_/ \_/ \_/ \_/ \
  //                       ______________________________________________
  // ft_stop_req       ___/
  //                   _______ ___ ___ ___ ___ ___ _______________ ______
  // form_stop_state   _____1_X_2_X_3_X_4_X_5_X_6_X_______7_______X_0____
  //                   _______
  // ft_running_p0            \__________________________________________
  //                           __________________________________________
  // ATREADYS          -------/
  //                               ___
  // insert_one_p1     ___________/   \__________________________________
  //                                   ___________________________
  // insert_zero_p1    _______________/                           \______
  //                   __________________________________________________
  // ftin_accept_p1
  //                   ___________________________________________
  // ft_data_valid_p2                                             \______
  //                                                               ______
  // stop_seq_ended_p2 ___________________________________________/
  //

  // Cycle by cycle commentary:
  //
  // 1. Normal operation.
  //
  // 2. ft_stop_req observed.  This is the final cycle of ATB data that will
  //    be accepted.
  //    If ATVALIDS and ATREADYS are high on the cycle, the data will be
  //    captured and stored.
  //
  // 3. We have left FORM_STOP_STATE_RUNNING.  ATREADYS is now pulled
  //    permanently high, and ATB data from this cycle will be discarded.
  //    During this cycle we align to p1, and store the ATB data just accepted
  //    to the formatter FIFO.
  //
  // 4. Insert a final 0x01 into the trace stream.  This is skipped if the
  //    formatter is enabled.
  //
  // 5-11. Pad out the end of the trace with zeros.  This will push between one
  //       and four extra cycles of zeros (* ATB width), until we have reached
  //       both a frame boundary and, for a 128 bit configuration, an even
  //       number of writes to the memory interface.
  //
  // 12.  Stopped.  No valid data will be presented to the write buffer from
  //      this cycle onwards.
  
  always @*
    case (form_stop_state)
      // Stopped -- wait for the stop request to clear.
      FORM_STOP_STATE_STOPPED :
        begin
          form_stop_state_en = ~(ft_stop_req | (ft_flush_req & ~ft_flush_ack));
          nxt_form_stop_state = FORM_STOP_STATE_RUNNING;
        end
      // The regular running state -- wait for a stop request.
      // In p0 at this point. 
      // This is the last cycle we will sample the ATB bus.  If we haven't
      // accepted it this cycle, we'll throw it away next
      // cycle (and force ATREADY high).
      FORM_STOP_STATE_RUNNING :
        begin
          form_stop_state_en = ft_stop_req | ft_flush_req;
          nxt_form_stop_state = FORM_STOP_STATE_P1_ALIGN;
        end
      // Align to the p1 stage. Push any data just accepted in the p1 stage into
      // the formatter fifo.
      FORM_STOP_STATE_P1_ALIGN :
        begin
          // We use the p1 stage signal to advance here rather than a p0 stage
          // signal, because the two stages advance in lockstep, and because we
          // have now lost our p0 advanced signal -- it has already been
          // clobbered by ft_running_p0 going low.
          form_stop_state_en = ftin_accept_p1;
          nxt_form_stop_state = !ffcr_en_formatting_masked ?
                                  FORM_STOP_STATE_FINAL_ONE :
                                  FORM_STOP_STATE_P2_ALIGN;
        end
      // Push a terminating 0x01 into the formatter. This is only required if
      // the formatter is disabled 
      FORM_STOP_STATE_FINAL_ONE :
        begin
          form_stop_state_en = ftin_accept_p1;
          nxt_form_stop_state = FORM_STOP_STATE_P2_ALIGN;
        end
      // From this point, we will push zeros into the formatter in order to
      // align with our chosen stop position.  First align to p2, since we will
      // be aligning with ft_data_valid_p2.
      FORM_STOP_STATE_P2_ALIGN :
        begin
          form_stop_state_en = ftin_accept_p1;
          nxt_form_stop_state = FORM_STOP_STATE_FLUSH1;
        end
      // 3 stages to flush the fifo.  This assumes the worst case, which is that
      // the fifo is currently full -- note that 3 reads are required, because
      // one of them could include the LSB. The worst case is assumed to keep
      // the code simple.
      FORM_STOP_STATE_FLUSH1 :
        begin
          form_stop_state_en = ft_data_valid_p2;
          nxt_form_stop_state = FORM_STOP_STATE_FLUSH2;
        end
      FORM_STOP_STATE_FLUSH2 :
        begin
          form_stop_state_en = ft_data_valid_p2;
          nxt_form_stop_state = FORM_STOP_STATE_FRAME_ALIGN;
        end
      // Align to a frame boundary, or to an even frame in the 128-bit case.
      // Since at least one read is performed in this state, this constitutes
      // the third flush read.
      FORM_STOP_STATE_FRAME_ALIGN :
        begin
          form_stop_state_en = stop_position_p2 & ft_data_valid_p2;
          nxt_form_stop_state = FORM_STOP_STATE_STOPPED;
        end
      default :
        begin
          form_stop_state_en = 1'bx;
          nxt_form_stop_state = FORM_STOP_STATE_DEFAULT;
        end
    endcase

  always @(posedge cxtmc_clk or negedge RESETn)
    begin
      if (!RESETn)
        begin
          form_stop_state <= FORM_STOP_STATE_STOPPED;
        end               
      else if (form_stop_state_en)
        begin
          form_stop_state <= nxt_form_stop_state;
        end
    end


  // Insert a one at the end of trace if the formatter is bypassed.
  assign insert_one_p1 = (form_stop_state == FORM_STOP_STATE_FINAL_ONE);

  // Pad the end of trace with data 0, ID 0.  This corresponds to
  // form_stop_state[2], for timing efficiency.
  assign insert_null_p1 = ((form_stop_state == FORM_STOP_STATE_P2_ALIGN) |
                           (form_stop_state == FORM_STOP_STATE_FLUSH1) |
                           (form_stop_state == FORM_STOP_STATE_FLUSH2) |
                           (form_stop_state == FORM_STOP_STATE_FRAME_ALIGN));

  assign ft_running_p0 = (form_stop_state == FORM_STOP_STATE_RUNNING) |
                         ft_flush_req_del;
  assign ft_flushing_p0 = (form_stop_state != FORM_STOP_STATE_RUNNING) &
                          ft_flush_req_del;
  assign stop_seq_ended_p2 = (form_stop_state == FORM_STOP_STATE_STOPPED);
                          
  assign ft_flush_ack = (form_stop_state == FORM_STOP_STATE_STOPPED) &
                         ft_flush_req;

  always @(posedge cxtmc_clk or negedge RESETn)
    begin
      if (!RESETn)
        begin
          ft_flush_req_del <= 1'b0;
        end               
      else
        begin
          ft_flush_req_del <= ft_flush_req;
        end
    end

  //============================================================================
  // p1 pipeline stage -- formatter FIFO entry logic
  //============================================================================

  // Rotate the data on ftin_data_p1 by this amount before writing to the
  // formatter FIFO. Take account of the amount of data being read out, and
  // offset by one to allow the ID lane to be written if required.
  assign rotation_p1 = (fifo_size_p2 +
                        {{CXTMC_FIFOSIZE_WIDTH-1{1'b0}}, ftin_id_valid_p1} -
                        read_size_p2);

generate
  if (CXTMC_ATB_DATA_WIDTH == 32)
    begin
      assign frame_pos_ctr_p1 = stop_seq_ended_p2 ?
                                   {CXTMC_CTR_WIDTH{1'b0}} :
                                   (ft_data_valid_p2) ? 
                                   frame_pos_ctr_p2 +
                                   {{(CXTMC_CTR_WIDTH-1){1'b0}},{1'b1}} :
                                    frame_pos_ctr_p2;
    end
endgenerate
  
  // In the 64-bit case, frame_pos_ctr_p2 is a 1-bit counter. For the 128-bit
  // case, it's also a 1-bit counter -- this enables us to record whether we are
  // on an odd or even frame, so that we can align with the 256-bit memory width
generate
  if (CXTMC_ATB_DATA_WIDTH == 64 || CXTMC_ATB_DATA_WIDTH == 128)
    begin
      assign frame_pos_ctr_p1 = stop_seq_ended_p2 ? 1'b0 :
                                (ft_data_valid_p2) ? ~frame_pos_ctr_p2 :
                                frame_pos_ctr_p2;
    end
endgenerate
  
  //----------------------------------------------------------------------------
  // Rotator logic of the formatter for shifting ftin_data_p1 and ftin_id_p1
  // into the FIFO. The value by which the ftin_data_p1 and ftin_id_p1 should
  // be shifted is indicated by the value from rotation_p1. The trace ID is
  // only shifted into the FIFO if the ID is changed.
  //----------------------------------------------------------------------------

generate
  if (CXTMC_ATB_DATA_WIDTH == 32)
    begin
      assign rotate1[35:0] = rotation_p1[0] ?
                         { 1'b0,ftin_data_p1[23:16],1'b0,ftin_data_p1[15:8],
                           1'b0,ftin_data_p1[7:0],1'b1,ftin_id_p1[6:0],1'b0 } :
                         { 1'b0,ftin_data_p1[31:24],1'b0,ftin_data_p1[23:16],
                           1'b0,ftin_data_p1[15:8],1'b0,ftin_data_p1[7:0] };
  
      assign rotate2[35:0] = rotation_p1[1] ?
                         { rotate1[26:0],1'b1,ftin_id_p1[6:0],1'b0 } :
                         { 1'b0,ftin_data_p1[31:24],rotate1[35:9] };

      assign rotate4[35:0] = rotation_p1[2] ?
                         { rotate2[17:0],rotate1[8:0],1'b1,ftin_id_p1[6:0],
                                                                       1'b0 } :
                         { 1'b0,ftin_data_p1[31:24],rotate1[35:27],
                                                               rotate2[35:18] };

      assign rotator_out[71:0] = { rotate2[26:18],rotate4[35:0],
                                   rotate2[17:0],rotate1[8:0] };
    end
endgenerate
  
  
generate
  if (CXTMC_ATB_DATA_WIDTH == 64)
    begin
      assign rotate1[71:0] = rotation_p1[0] ?
                         { 1'b0,ftin_data_p1[55:48],1'b0,ftin_data_p1[47:40],
                           1'b0,ftin_data_p1[39:32],1'b0,ftin_data_p1[31:24],
                           1'b0,ftin_data_p1[23:16],1'b0,ftin_data_p1[15:8],
                           1'b0,ftin_data_p1[7:0],1'b1,ftin_id_p1[6:0],1'b0 } :
                         { 1'b0,ftin_data_p1[63:56],1'b0,ftin_data_p1[55:48],
                           1'b0,ftin_data_p1[47:40],1'b0,ftin_data_p1[39:32],
                           1'b0,ftin_data_p1[31:24],1'b0,ftin_data_p1[23:16],
                           1'b0,ftin_data_p1[15:8],1'b0,ftin_data_p1[7:0] };
  
      assign rotate2[71:0] = rotation_p1[1] ?
                         { rotate1[62:0],1'b1,ftin_id_p1[6:0],1'b0 } :
                         { 1'b0,ftin_data_p1[63:56],rotate1[71:9] };
  
      assign rotate4[71:0] = rotation_p1[2] ?
                         { rotate2[53:0],rotate1[8:0],1'b1,ftin_id_p1[6:0],
                                                                       1'b0 } :
                         { 1'b0,ftin_data_p1[63:56],rotate1[71:63],
                                                               rotate2[71:18] };
  
      assign rotate8[71:0] = rotation_p1[3] ?
                         { rotate4[35:0],rotate2[17:0],
                           rotate1[8:0],1'b1,ftin_id_p1[6:0],1'b0 } :
                         { 1'b0,ftin_data_p1[63:56],rotate1[71:63],
                                                    rotate2[71:54],
                                                     rotate4[71:36]};
  
      assign rotator_out[143:0] = { rotate4[44:36],rotate8[71:0],
                                    rotate4[35:0],rotate2[17:0],rotate1[8:0] };
    end
endgenerate
  
generate
  if (CXTMC_ATB_DATA_WIDTH == 128)
    begin
      assign rotate1[143:0] = rotation_p1[0] ?
                          { 1'b0,ftin_data_p1[119:112],1'b0,
                            ftin_data_p1[111:104],
                            1'b0,ftin_data_p1[103:96], 1'b0,ftin_data_p1[95:88],
                            1'b0,ftin_data_p1[87:80],  1'b0,ftin_data_p1[79:72],
                            1'b0,ftin_data_p1[71:64],  1'b0,ftin_data_p1[63:56],
                            1'b0,ftin_data_p1[55:48],  1'b0,ftin_data_p1[47:40],
                            1'b0,ftin_data_p1[39:32],  1'b0,ftin_data_p1[31:24],
                            1'b0,ftin_data_p1[23:16],  1'b0,ftin_data_p1[15:8],
                            1'b0,ftin_data_p1[7:0],    1'b1,ftin_id_p1[6:0],
                                                                        1'b0 } :
                          { 1'b0,ftin_data_p1[127:120],1'b0,
                            ftin_data_p1[119:112],
                            1'b0,ftin_data_p1[111:104],1'b0,
                            ftin_data_p1[103:96],
                            1'b0,ftin_data_p1[95:88]  ,1'b0,ftin_data_p1[87:80],
                            1'b0,ftin_data_p1[79:72]  ,1'b0,ftin_data_p1[71:64],
                            1'b0,ftin_data_p1[63:56]  ,1'b0,ftin_data_p1[55:48],
                            1'b0,ftin_data_p1[47:40]  ,1'b0,ftin_data_p1[39:32],
                            1'b0,ftin_data_p1[31:24]  ,1'b0,ftin_data_p1[23:16],
                            1'b0,ftin_data_p1[15:8]   ,1'b0,ftin_data_p1[7:0] };

      assign rotate2[143:0] = rotation_p1[1] ?
                          { rotate1[134:0],1'b1,ftin_id_p1[6:0],1'b0 } :
                          { 1'b0,ftin_data_p1[127:120],rotate1[143:9] };

      assign rotate4[143:0] = rotation_p1[2] ?
                          { rotate2[125:0],rotate1[8:0],1'b1,ftin_id_p1[6:0],
                                                                       1'b0 } :
                          { 1'b0,ftin_data_p1[127:120],rotate1[143:135],
                            rotate2[143:18] };

      assign rotate8[143:0] = rotation_p1[3] ?
                          { rotate4[107:0],rotate2[17:0],
                            rotate1[8:0],1'b1,ftin_id_p1[6:0],1'b0 } :
                          { 1'b0,ftin_data_p1[127:120],rotate1[143:135],
                            rotate2[143:126], rotate4[143:36] };

      assign rotate16[143:0] = rotation_p1[4] ?
                           { rotate8[71:0],rotate4[35:0],rotate2[17:0],
                             rotate1[8:0], 1'b1,ftin_id_p1[6:0],1'b0 } :
                           { 1'b0,ftin_data_p1[127:120],rotate1[143:135],
                             rotate2[143:126], rotate4[143:108],
                             rotate8[143:72] };

      assign rotator_out[287:0] = { rotate8[80:72],rotate16[143:0],
                                rotate8[71:0], rotate4[35:0],rotate2[17:0],
                                rotate1[8:0] };
    end
endgenerate
  
  //----------------------------------------------------------------------------
  // Comparators for different FIFO sizes. These comparators are used on the
  // input interface of the formatter to write data into the FIFO.
  //----------------------------------------------------------------------------
  
  assign equal_0   = (fifo_size_p2 == {{CXTMC_FIFOSIZE_WIDTH-2{1'b0}},2'b00});
  assign le_eq_1   = (fifo_size_p2 <= {{CXTMC_FIFOSIZE_WIDTH-2{1'b0}},2'b01});
  assign le_eq_2   = (fifo_size_p2 <= {{CXTMC_FIFOSIZE_WIDTH-2{1'b0}},2'b10});
  assign le_eq_2_p1= (fifo_size_p1 <= {{CXTMC_FIFOSIZE_WIDTH-2{1'b0}},2'b10});
  assign le_eq_3   = (fifo_size_p2 <= {{CXTMC_FIFOSIZE_WIDTH-2{1'b0}},2'b11});
  assign le_eq_3_p1= (fifo_size_p1 <= {{CXTMC_FIFOSIZE_WIDTH-2{1'b0}},2'b11});

  assign le_eq_4   = (fifo_size_p2 <= {{CXTMC_FIFOSIZE_WIDTH-3{1'b0}},3'b100});
  assign le_eq_5   = (fifo_size_p2 <= {{CXTMC_FIFOSIZE_WIDTH-3{1'b0}},3'b101});
  assign le_eq_6   = (fifo_size_p2 <= {{CXTMC_FIFOSIZE_WIDTH-3{1'b0}},3'b110});
  assign le_eq_6_p1= (fifo_size_p1 <= {{CXTMC_FIFOSIZE_WIDTH-3{1'b0}},3'b110});
  assign le_eq_7   = (fifo_size_p2 <= {{CXTMC_FIFOSIZE_WIDTH-3{1'b0}},3'b111});
  assign le_eq_7_p1= (fifo_size_p1 <= {{CXTMC_FIFOSIZE_WIDTH-3{1'b0}},3'b111});

generate
  if (CXTMC_GT_32 == 1)
    begin
      assign le_eq_8
               = (fifo_size_p2 <= {{CXTMC_FIFOSIZE_WIDTH-4{1'b0}},4'b1000});
      assign le_eq_9
               = (fifo_size_p2 <= {{CXTMC_FIFOSIZE_WIDTH-4{1'b0}},4'b1001});
      assign le_eq_10
              = (fifo_size_p2 <= {{CXTMC_FIFOSIZE_WIDTH-4{1'b0}},4'b1010});
      assign le_eq_11
              = (fifo_size_p2 <= {{CXTMC_FIFOSIZE_WIDTH-4{1'b0}},4'b1011});
      assign le_eq_12
              = (fifo_size_p2 <= {{CXTMC_FIFOSIZE_WIDTH-4{1'b0}},4'b1100});
      assign le_eq_13
              = (fifo_size_p2 <= {{CXTMC_FIFOSIZE_WIDTH-4{1'b0}},4'b1101});
      assign le_eq_14
              = (fifo_size_p2 <= {{CXTMC_FIFOSIZE_WIDTH-4{1'b0}},4'b1110});
      assign le_eq_14_p1
              = (fifo_size_p1 <= {{CXTMC_FIFOSIZE_WIDTH-4{1'b0}},4'b1110});
      assign le_eq_15
              = (fifo_size_p2 <= {{CXTMC_FIFOSIZE_WIDTH-4{1'b0}},4'b1111});
      assign le_eq_15_p1
              = (fifo_size_p1 <= {{CXTMC_FIFOSIZE_WIDTH-4{1'b0}},4'b1111});
    end
endgenerate

generate
  if (CXTMC_ATB_DATA_WIDTH == 128)
    begin
      assign le_eq_16
              = (fifo_size_p2 <= {{CXTMC_FIFOSIZE_WIDTH-5{1'b0}},5'b10000});
      assign le_eq_17
              = (fifo_size_p2 <= {{CXTMC_FIFOSIZE_WIDTH-5{1'b0}},5'b10001});
      assign le_eq_18
              = (fifo_size_p2 <= {{CXTMC_FIFOSIZE_WIDTH-5{1'b0}},5'b10010});
      assign le_eq_19
              = (fifo_size_p2 <= {{CXTMC_FIFOSIZE_WIDTH-5{1'b0}},5'b10011});
      assign le_eq_20
              = (fifo_size_p2 <= {{CXTMC_FIFOSIZE_WIDTH-5{1'b0}},5'b10100});
      assign le_eq_21
              = (fifo_size_p2 <= {{CXTMC_FIFOSIZE_WIDTH-5{1'b0}},5'b10101});
      assign le_eq_22
              = (fifo_size_p2 <= {{CXTMC_FIFOSIZE_WIDTH-5{1'b0}},5'b10110});
      assign le_eq_23
              = (fifo_size_p2 <= {{CXTMC_FIFOSIZE_WIDTH-5{1'b0}},5'b10111});
      assign le_eq_24
              = (fifo_size_p2 <= {{CXTMC_FIFOSIZE_WIDTH-5{1'b0}},5'b11000});
      assign le_eq_25
              = (fifo_size_p2 <= {{CXTMC_FIFOSIZE_WIDTH-5{1'b0}},5'b11001});
      assign le_eq_26
              = (fifo_size_p2 <= {{CXTMC_FIFOSIZE_WIDTH-5{1'b0}},5'b11010});
      assign le_eq_27
              = (fifo_size_p2 <= {{CXTMC_FIFOSIZE_WIDTH-5{1'b0}},5'b11011});
      assign le_eq_28
              = (fifo_size_p2 <= {{CXTMC_FIFOSIZE_WIDTH-5{1'b0}},5'b11100});
      assign le_eq_29
              = (fifo_size_p2 <= {{CXTMC_FIFOSIZE_WIDTH-5{1'b0}},5'b11101});
      assign le_eq_30
              = (fifo_size_p2 <= {{CXTMC_FIFOSIZE_WIDTH-5{1'b0}},5'b11110});
      assign le_eq_31
              = (fifo_size_p2 <= {{CXTMC_FIFOSIZE_WIDTH-5{1'b0}},5'b11111});
    end
endgenerate
  
  //----------------------------------------------------------------------------
  // Combinational block for the first register of the FIFO.
  //----------------------------------------------------------------------------

  assign fifo_reg1_en = (equal_0 & read_nothing_p2) | 
                        read_frame_end_p2 | 
                        read_not_frame_end_p2;
  
  
generate
  if (CXTMC_ATB_DATA_WIDTH == 32)
    begin  
      assign nxt_fifo_reg1 = ((equal_0 && read_nothing_p2) ||
                              (le_eq_3  && read_frame_end_p2) ||
                              (le_eq_4  && read_not_frame_end_p2)) ?
                              rotator_out[8:0] :
                                (!le_eq_3 && read_frame_end_p2) ?
                                 fifo_reg4 : fifo_reg5;
    end
endgenerate

generate
  if (CXTMC_ATB_DATA_WIDTH == 64)
    begin  
      assign nxt_fifo_reg1 = ((equal_0 && read_nothing_p2) ||
                              (le_eq_7  && read_frame_end_p2) ||
                              (le_eq_8  && read_not_frame_end_p2)) ?
                              rotator_out[8:0] :
                               (!le_eq_7 && read_frame_end_p2) ?
                                 fifo_reg8 : fifo_reg9;
    end
endgenerate

generate
  if (CXTMC_ATB_DATA_WIDTH == 128)
    begin  
      assign nxt_fifo_reg1 = ((equal_0 && read_nothing_p2)  ||
                              (le_eq_15 && read_frame_end_p2) ||
                              (le_eq_16 && read_not_frame_end_p2)) ?
                              rotator_out[8:0] :
                               (!le_eq_15 && read_frame_end_p2) ?
                                 fifo_reg16 : fifo_reg17;
    end
endgenerate
  
  //----------------------------------------------------------------------------
  // Clock process to realize fifo_reg1 register
  //----------------------------------------------------------------------------
  always @(posedge cxtmc_clk)
    begin
      if (fifo_reg1_en)
        fifo_reg1 <= nxt_fifo_reg1;
    end
  
  //----------------------------------------------------------------------------
  // Combinational block for the second register of the FIFO.
  //----------------------------------------------------------------------------
  
  assign fifo_reg2_en = (le_eq_1 & read_nothing_p2) |
                        read_frame_end_p2 | 
                        read_not_frame_end_p2;
  
  
generate
  if (CXTMC_ATB_DATA_WIDTH == 32)
    begin  
      assign nxt_fifo_reg2 = ((le_eq_1 && read_nothing_p2) ||
                              (le_eq_4 && read_frame_end_p2)  ||
                              (le_eq_5 && read_not_frame_end_p2)) ?
                              rotator_out[17:9] :
                               (!le_eq_4 && read_frame_end_p2) ?
                              fifo_reg5 : fifo_reg6;
    end
endgenerate
  
generate
  if (CXTMC_ATB_DATA_WIDTH == 64)
    begin  
      assign nxt_fifo_reg2 = ((le_eq_1 && read_nothing_p2) ||
                              (le_eq_8 && read_frame_end_p2) ||
                              (le_eq_9 && read_not_frame_end_p2)) ?
                              rotator_out[17:9] :
                              (!le_eq_8 && read_frame_end_p2) ?
                              fifo_reg9 : fifo_reg10;
    end
endgenerate
  
generate
  if (CXTMC_ATB_DATA_WIDTH == 128)
    begin  
      assign nxt_fifo_reg2 = ((le_eq_1 && read_nothing_p2)   ||
                               (le_eq_16 && read_frame_end_p2) ||
                               (le_eq_17 && read_not_frame_end_p2)) ?
                               rotator_out[17:9] :
                               (!le_eq_16 && read_frame_end_p2) ?
                               fifo_reg17 : fifo_reg18;
    end
endgenerate
  
  //----------------------------------------------------------------------------
  // Clock process to realize fifo_reg2 register
  //----------------------------------------------------------------------------
  always @(posedge cxtmc_clk)
    begin
      if (fifo_reg2_en)
        fifo_reg2 <= nxt_fifo_reg2;
    end
  
  //----------------------------------------------------------------------------
  // Combinational block for the third register of the FIFO.
  //----------------------------------------------------------------------------

  assign fifo_reg3_en = (le_eq_2 & read_nothing_p2) |
                        read_frame_end_p2 | 
                        read_not_frame_end_p2;
  
  
  
generate
  if (CXTMC_ATB_DATA_WIDTH == 32)
    begin  
      assign nxt_fifo_reg3 = ((le_eq_2 && read_nothing_p2) ||
                               (le_eq_5 && read_frame_end_p2) ||
                               (le_eq_6 && read_not_frame_end_p2)) ?
                               rotator_out[26:18] :
                               (!le_eq_5 && read_frame_end_p2) ?
                               fifo_reg6 : fifo_reg7;
    end
endgenerate
  
generate
  if (CXTMC_ATB_DATA_WIDTH == 64)
    begin  
      assign nxt_fifo_reg3 = ((le_eq_2  && read_nothing_p2) ||
                              (le_eq_9  && read_frame_end_p2) ||
                              (le_eq_10 && read_not_frame_end_p2)) ?
                              rotator_out[26:18] :
                              (!le_eq_9 && read_frame_end_p2) ?
                              fifo_reg10 : fifo_reg11;
    end
endgenerate
  
generate
  if (CXTMC_ATB_DATA_WIDTH == 128)
    begin  
      assign nxt_fifo_reg3 = ((le_eq_2  && read_nothing_p2)  ||
                               (le_eq_17 && read_frame_end_p2) ||
                               (le_eq_18 && read_not_frame_end_p2)) ?
                               rotator_out[26:18] :
                               (!le_eq_17 && read_frame_end_p2) ?
                               fifo_reg18 : fifo_reg19;
    end
endgenerate
  
  //----------------------------------------------------------------------------
  // Clock process to realize fifo_reg3 register
  //----------------------------------------------------------------------------
  always @(posedge cxtmc_clk)
    begin
      if (fifo_reg3_en)
        fifo_reg3 <= nxt_fifo_reg3;
    end
  
  //----------------------------------------------------------------------------
  // Combinational block for the fourth register of the FIFO.
  //----------------------------------------------------------------------------
  assign fifo_reg4_en = (le_eq_3 & read_nothing_p2) |
                        read_frame_end_p2 | 
                        read_not_frame_end_p2;
  
generate
  if (CXTMC_ATB_DATA_WIDTH == 32)
    begin  
      assign nxt_fifo_reg4 = ((le_eq_3 && read_nothing_p2) ||
                               (le_eq_6 && read_frame_end_p2) ||
                               (le_eq_7 && read_not_frame_end_p2)) ?
                               rotator_out[35:27] :
                               (!le_eq_6 && read_frame_end_p2) ?
                               fifo_reg7 : {1'b0,fifo_reg8};
    end
endgenerate
  
generate
  if (CXTMC_ATB_DATA_WIDTH == 64)
    begin  
      assign nxt_fifo_reg4 = ((le_eq_3  && read_nothing_p2) ||
                               (le_eq_10 && read_frame_end_p2) ||
                               (le_eq_11 && read_not_frame_end_p2)) ?
                               rotator_out[35:27] :
                               (!le_eq_10 && read_frame_end_p2) ?
                               fifo_reg11 : fifo_reg12;
    end
endgenerate
  
generate
  if (CXTMC_ATB_DATA_WIDTH == 128)
    begin  
      assign nxt_fifo_reg4 = ((le_eq_3  && read_nothing_p2)  ||
                               (le_eq_18 && read_frame_end_p2) ||
                               (le_eq_19 && read_not_frame_end_p2)) ?
                               rotator_out[35:27] :
                               (!le_eq_18 && read_frame_end_p2) ?
                               fifo_reg19 : fifo_reg20;
    end
endgenerate
  
  //----------------------------------------------------------------------------
  // Clock process to realize fifo_reg4 register
  //----------------------------------------------------------------------------
  always @(posedge cxtmc_clk)
    begin
      if (fifo_reg4_en)
        fifo_reg4 <= nxt_fifo_reg4;
    end
  
  //----------------------------------------------------------------------------
  // Combinational block for the fifth register of the FIFO.
  //----------------------------------------------------------------------------
  assign fifo_reg5_en = (le_eq_4 & read_nothing_p2) |
                        read_frame_end_p2 | 
                        read_not_frame_end_p2;
generate
  if (CXTMC_ATB_DATA_WIDTH == 32)
    begin  
      assign nxt_fifo_reg5 = ((le_eq_4 && read_nothing_p2) ||
                               (le_eq_7 & read_frame_end_p2) ||
                               (read_not_frame_end_p2)) ?
                               rotator_out[44:36] : {1'b0,fifo_reg8};
    end
endgenerate
  
generate
  if (CXTMC_ATB_DATA_WIDTH == 64)
    begin  
      assign nxt_fifo_reg5 = ((le_eq_4 && read_nothing_p2) ||
                               (le_eq_11 && read_frame_end_p2) ||
                               (le_eq_12 && read_not_frame_end_p2)) ?
                               rotator_out[44:36] :
                               (!le_eq_11 && read_frame_end_p2) ?
                                fifo_reg12 : fifo_reg13;
    end
endgenerate
  
generate
  if (CXTMC_ATB_DATA_WIDTH == 128)
    begin  
      assign nxt_fifo_reg5 = ((le_eq_4  && read_nothing_p2)  ||
                               (le_eq_19 && read_frame_end_p2) ||
                               (le_eq_20 && read_not_frame_end_p2)) ?
                               rotator_out[44:36] :
                               (!le_eq_19 && read_frame_end_p2) ?
                                fifo_reg20 : fifo_reg21;
    end
endgenerate

  //----------------------------------------------------------------------------
  // Clock process to realize fifo_reg5 register
  //----------------------------------------------------------------------------
  always @(posedge cxtmc_clk)
    begin
      if (fifo_reg5_en)
        fifo_reg5 <= nxt_fifo_reg5;
    end
  
  //----------------------------------------------------------------------------
  // Combinational block for the sixth register of the FIFO.
  //----------------------------------------------------------------------------
  assign fifo_reg6_en = (le_eq_5 & read_nothing_p2) |
                        read_frame_end_p2 | 
                        read_not_frame_end_p2;

generate
  if (CXTMC_ATB_DATA_WIDTH == 32)
    begin  
      assign nxt_fifo_reg6 = rotator_out[53:45];
    end
endgenerate
  
generate
  if (CXTMC_ATB_DATA_WIDTH == 64)
    begin  
      assign nxt_fifo_reg6 = ((le_eq_5 && read_nothing_p2)  ||
                               (le_eq_12 && read_frame_end_p2) ||
                               (le_eq_13 && read_not_frame_end_p2)) ?
                               rotator_out[53:45] :
                               (!le_eq_12 && read_frame_end_p2) ?
                                fifo_reg13 : fifo_reg14;
    end
endgenerate
  
generate
  if (CXTMC_ATB_DATA_WIDTH == 128)
    begin  
      assign nxt_fifo_reg6 = ((le_eq_5  && read_nothing_p2)  ||
                               (le_eq_20 && read_frame_end_p2) ||
                               (le_eq_21 && read_not_frame_end_p2)) ?
                               rotator_out[53:45] :
                               (!le_eq_20 && read_frame_end_p2) ?
                                fifo_reg21 : fifo_reg22;
    end
endgenerate

  //----------------------------------------------------------------------------
  // Clock process to realize fifo_reg6 register
  //----------------------------------------------------------------------------
  always @(posedge cxtmc_clk)
    begin
      if (fifo_reg6_en)
        fifo_reg6 <= nxt_fifo_reg6;
    end
  
  //----------------------------------------------------------------------------
  // Combinational block for the seventh register of the FIFO.
  //----------------------------------------------------------------------------
  assign fifo_reg7_en = (le_eq_6 & read_nothing_p2) |
                        read_frame_end_p2 | 
                        read_not_frame_end_p2;
  
generate
  if (CXTMC_ATB_DATA_WIDTH == 32)
    begin  
      assign nxt_fifo_reg7 = rotator_out[62:54];
    end
endgenerate
  
generate
  if (CXTMC_ATB_DATA_WIDTH == 64)
    begin  
      assign nxt_fifo_reg7 = ((le_eq_6  && read_nothing_p2) ||
                               (le_eq_13 && read_frame_end_p2) ||
                               (le_eq_14 && read_not_frame_end_p2)) ?
                               rotator_out[62:54] :
                               (!le_eq_13 && read_frame_end_p2) ?
                                fifo_reg14 : fifo_reg15;
    end
endgenerate
  
generate
  if (CXTMC_ATB_DATA_WIDTH == 128)
    begin  
      assign nxt_fifo_reg7 = ((le_eq_6  && read_nothing_p2)  ||
                               (le_eq_21 && read_frame_end_p2) ||
                               (le_eq_22 && read_not_frame_end_p2)) ?
                               rotator_out[62:54] :
                               (!le_eq_21 && read_frame_end_p2) ?
                                fifo_reg22 : fifo_reg23;
    end
endgenerate

  //----------------------------------------------------------------------------
  // Clock process to realize fifo_reg7 register
  //----------------------------------------------------------------------------
  always @(posedge cxtmc_clk)
    begin
      if (fifo_reg7_en)
        fifo_reg7 <= nxt_fifo_reg7;
    end
  
  //----------------------------------------------------------------------------
  // Combinational block for the eighth register of the FIFO.
  //----------------------------------------------------------------------------
  assign fifo_reg8_en = (le_eq_7 & read_nothing_p2) |
                        read_frame_end_p2 | 
                        read_not_frame_end_p2;
generate
  if (CXTMC_ATB_DATA_WIDTH == 32)
    begin  
      assign nxt_fifo_reg8 = rotator_out[70:63];
    end
endgenerate
  
generate
  if (CXTMC_ATB_DATA_WIDTH == 64)
    begin  
      assign nxt_fifo_reg8 = ((le_eq_7 && read_nothing_p2)  ||
                               (le_eq_14 && read_frame_end_p2) ||
                               (le_eq_15 && read_not_frame_end_p2)) ?
                               rotator_out[71:63] :
                               (!le_eq_14 && read_frame_end_p2) ?
                                fifo_reg15 : {1'b0,fifo_reg16};
    end
endgenerate
  
generate
  if (CXTMC_ATB_DATA_WIDTH == 128)
    begin  
      assign nxt_fifo_reg8 = ((le_eq_7  && read_nothing_p2)  ||
                               (le_eq_22 && read_frame_end_p2) ||
                               (le_eq_23 && read_not_frame_end_p2)) ?
                               rotator_out[71:63] :
                               (!le_eq_22 && read_frame_end_p2) ?
                                fifo_reg23 : fifo_reg24;
    end
endgenerate

  //----------------------------------------------------------------------------
  // Clock process to realize fifo_reg8 register
  //----------------------------------------------------------------------------
  always @(posedge cxtmc_clk)
    begin
      if (fifo_reg8_en)
        fifo_reg8 <= nxt_fifo_reg8;
    end
  
  //----------------------------------------------------------------------------
  // Combinational block for the ninth register of the FIFO.
  //----------------------------------------------------------------------------
generate
  if (CXTMC_GT_32 == 1)
    begin  
      wire        fifo_reg9_en;           // Enable for fifo_reg9 register
      wire [8:0]  nxt_fifo_reg9;          // D-Input of fifo_reg9 register
      assign fifo_reg9_en = (le_eq_8 & read_nothing_p2) |
                               read_frame_end_p2 | 
                               read_not_frame_end_p2;
      
      if (CXTMC_ATB_DATA_WIDTH == 64)
        begin  
          assign nxt_fifo_reg9 = ((le_eq_8 && read_nothing_p2)  ||
                                  (le_eq_15 && read_frame_end_p2) ||
                                  (read_not_frame_end_p2)) ?
                                  rotator_out[80:72] : {1'b0,fifo_reg16};
        end
      if (CXTMC_ATB_DATA_WIDTH == 128)
        begin  
          assign nxt_fifo_reg9 = ((le_eq_8  && read_nothing_p2)  ||
                                  (le_eq_23 && read_frame_end_p2) ||
                                  (le_eq_24 && read_not_frame_end_p2)) ?
                                  rotator_out[80:72] :
                                  (!le_eq_23 && read_frame_end_p2) ?
                                   fifo_reg24 : fifo_reg25;
        end
    
      //------------------------------------------------------------------------
      // Clock process to realize fifo_reg9 register
      //------------------------------------------------------------------------
       always @(posedge cxtmc_clk)
         begin
           if (fifo_reg9_en)
             fifo_reg9 <= nxt_fifo_reg9;
         end
  end
endgenerate

  //----------------------------------------------------------------------------
  // Combinational block for the tenth register of the FIFO.
  //----------------------------------------------------------------------------
generate
  if (CXTMC_GT_32 == 1)
    begin  
      wire        fifo_reg10_en;          // Enable for fifo_reg10 register
      wire [8:0]  nxt_fifo_reg10;         // D-Input of fifo_reg10 register
      assign fifo_reg10_en = (le_eq_9 & read_nothing_p2) |
                             read_frame_end_p2 | 
                             read_not_frame_end_p2;
      
      if (CXTMC_ATB_DATA_WIDTH == 64)
        begin  
          assign nxt_fifo_reg10 = rotator_out[89:81];
        end
      
      if (CXTMC_ATB_DATA_WIDTH == 128)
        begin  
          assign nxt_fifo_reg10 = ((le_eq_9  && read_nothing_p2)  ||
                                    (le_eq_24 && read_frame_end_p2) ||
                                    (le_eq_25 && read_not_frame_end_p2)) ?
                                    rotator_out[89:81] :
                                    (!le_eq_24 && read_frame_end_p2) ?
                                     fifo_reg25 : fifo_reg26;
        end
      
      //------------------------------------------------------------------------
      // Clock process to realize fifo_reg10 register
      //------------------------------------------------------------------------
      always @(posedge cxtmc_clk)
        begin
          if (fifo_reg10_en)
            fifo_reg10 <= nxt_fifo_reg10;
        end
    end
endgenerate
  
  //----------------------------------------------------------------------------
  // Combinational block for the eleventh register of the FIFO.
  //----------------------------------------------------------------------------
generate
  if (CXTMC_GT_32 == 1)
    begin  
      wire        fifo_reg11_en;          // Enable for fifo_reg11 register
      wire [8:0]  nxt_fifo_reg11;         // D-Input of fifo_reg11 register
      assign fifo_reg11_en = (le_eq_10 & read_nothing_p2) |
                                read_frame_end_p2 | 
                                read_not_frame_end_p2;
      
      if (CXTMC_ATB_DATA_WIDTH == 64)
        begin  
          assign nxt_fifo_reg11 = rotator_out[98:90];
        end
      
      if (CXTMC_ATB_DATA_WIDTH == 128)
        begin  
          assign nxt_fifo_reg11 = ((le_eq_10 && read_nothing_p2)  ||
                                   (le_eq_25 && read_frame_end_p2) ||
                                   (le_eq_26 && read_not_frame_end_p2)) ?
                                   rotator_out[98:90] :
                                   (!le_eq_25 && read_frame_end_p2) ?
                                    fifo_reg26 : fifo_reg27;
        end
      
      //------------------------------------------------------------------------
      // Clock process to realize fifo_reg11 register
      //------------------------------------------------------------------------
      always @(posedge cxtmc_clk)
        begin
          if (fifo_reg11_en)
            fifo_reg11 <= nxt_fifo_reg11;
        end
    end
endgenerate
  
  //----------------------------------------------------------------------------
  // Combinational block for the twelfth register of the FIFO.
  //----------------------------------------------------------------------------
generate
  if (CXTMC_GT_32 == 1)
    begin  
      wire        fifo_reg12_en;          // Enable for fifo_reg12 register
      wire [8:0]  nxt_fifo_reg12;         // D-Input of fifo_reg12 register
      assign fifo_reg12_en = (le_eq_11 & read_nothing_p2) |
                             read_frame_end_p2 | 
                             read_not_frame_end_p2;
      
      if (CXTMC_ATB_DATA_WIDTH == 64)
        begin  
          assign nxt_fifo_reg12 = rotator_out[107:99];
        end
      
      if (CXTMC_ATB_DATA_WIDTH == 128)
        begin  
          assign nxt_fifo_reg12 = ((le_eq_11 && read_nothing_p2)  ||
                                   (le_eq_26 && read_frame_end_p2) ||
                                   (le_eq_27 && read_not_frame_end_p2)) ?
                                   rotator_out[107:99] :
                                   (!le_eq_26 && read_frame_end_p2) ?
                                    fifo_reg27 : fifo_reg28;
        end
      
      //------------------------------------------------------------------------
      // Clock process to realize fifo_reg12 register
      //------------------------------------------------------------------------
      always @(posedge cxtmc_clk)
        begin
          if (fifo_reg12_en)
            fifo_reg12 <= nxt_fifo_reg12;
        end
    end
endgenerate
  
  //----------------------------------------------------------------------------
  // Combinational block for the thirteenth register of the FIFO.
  //----------------------------------------------------------------------------
generate
  if (CXTMC_GT_32 == 1)
    begin  
      wire        fifo_reg13_en;          // Enable for fifo_reg13 register
      wire [8:0]  nxt_fifo_reg13;         // D-Input of fifo_reg13 register
      assign fifo_reg13_en = (le_eq_12 & read_nothing_p2) |
                             read_frame_end_p2 | 
                             read_not_frame_end_p2;
      
      if (CXTMC_ATB_DATA_WIDTH == 64)
        begin  
          assign nxt_fifo_reg13 = rotator_out[116:108];
        end
      
      if (CXTMC_ATB_DATA_WIDTH == 128)
        begin  
          assign nxt_fifo_reg13 = ((le_eq_12 && read_nothing_p2)  ||
                                   (le_eq_27 && read_frame_end_p2) ||
                                   (le_eq_28 && read_not_frame_end_p2)) ?
                                   rotator_out[116:108] :
                                   (!le_eq_27 && read_frame_end_p2) ?
                                    fifo_reg28 : fifo_reg29;
        end
      
      //------------------------------------------------------------------------
      // Clock process to realize fifo_reg13 register
      //------------------------------------------------------------------------
      always @(posedge cxtmc_clk)
        begin
          if (fifo_reg13_en)
            fifo_reg13 <= nxt_fifo_reg13;
        end
  end
endgenerate
  
  //----------------------------------------------------------------------------
  // Combinational block for the fourteenth register of the FIFO.
  //----------------------------------------------------------------------------
generate
  if (CXTMC_GT_32 == 1)
    begin  
      wire        fifo_reg14_en;          // Enable for fifo_reg14 register
      wire [8:0]  nxt_fifo_reg14;         // D-Input of fifo_reg14 register
      assign fifo_reg14_en = (le_eq_13 & read_nothing_p2) |
                                read_frame_end_p2 | 
                                read_not_frame_end_p2;
    
      if (CXTMC_ATB_DATA_WIDTH == 64)
        begin  
          assign nxt_fifo_reg14 = rotator_out[125:117];
        end
      
      if (CXTMC_ATB_DATA_WIDTH == 128)
        begin  
      assign nxt_fifo_reg14 = ((le_eq_13 && read_nothing_p2)  ||
                                   (le_eq_28 && read_frame_end_p2) ||
                                   (le_eq_29 && read_not_frame_end_p2)) ?
                                   rotator_out[125:117] :
                                   (!le_eq_28 && read_frame_end_p2) ?
                                   fifo_reg29 : fifo_reg30;
        end
      
      //------------------------------------------------------------------------
      // Clock process to realize fifo_reg14 register
      //------------------------------------------------------------------------
      always @(posedge cxtmc_clk)
        begin
          if (fifo_reg14_en)
            fifo_reg14 <= nxt_fifo_reg14;
        end
    end
endgenerate
  
  //----------------------------------------------------------------------------
  // Combinational block for the fifteenth register of the FIFO.
  //----------------------------------------------------------------------------
generate
  if (CXTMC_GT_32 == 1)
    begin  
      wire        fifo_reg15_en;          // Enable for fifo_reg15 register
      wire [8:0]  nxt_fifo_reg15;         // D-Input of fifo_reg15 register
      assign fifo_reg15_en = (le_eq_14 & read_nothing_p2) |
                                read_frame_end_p2 | 
                                read_not_frame_end_p2;
      
      if (CXTMC_ATB_DATA_WIDTH == 64)
        begin  
          assign nxt_fifo_reg15 = rotator_out[134:126];
        end
      
      if (CXTMC_ATB_DATA_WIDTH == 128)
        begin  
      assign nxt_fifo_reg15 = ((le_eq_14 && read_nothing_p2)  ||
                                (le_eq_29 && read_frame_end_p2) ||
                                (le_eq_30 && read_not_frame_end_p2)) ?
                                rotator_out[134:126] :
                                (!le_eq_29 && read_frame_end_p2) ?
                                 fifo_reg30 : fifo_reg31;
        end
      
      //------------------------------------------------------------------------
      // Clock process to realize fifo_reg15 register
      //------------------------------------------------------------------------
      always @(posedge cxtmc_clk)
        begin
          if (fifo_reg15_en)
            fifo_reg15 <= nxt_fifo_reg15;
        end
    end
endgenerate
  
  //----------------------------------------------------------------------------
  // Combinational block for the sixteenth register of the FIFO.
  //----------------------------------------------------------------------------
generate
  if (CXTMC_GT_32 == 1)
    begin
      wire        fifo_reg16_en;           // Enable for fifo_reg16 register
      wire [(CXTMC_FIFOREG16_WIDTH-1):0] nxt_fifo_reg16;
                                           // D-Input of fifo_reg16 register
      assign fifo_reg16_en = (le_eq_15 & read_nothing_p2) |
                                read_frame_end_p2 | 
                                read_not_frame_end_p2;

      
      if (CXTMC_ATB_DATA_WIDTH == 64)
        begin  
          assign nxt_fifo_reg16 = rotator_out[142:135];
        end
      
      if (CXTMC_ATB_DATA_WIDTH == 128)
        begin  
          assign nxt_fifo_reg16 = ((le_eq_15 && read_nothing_p2)  ||
                                   (le_eq_30 && read_frame_end_p2) ||
                                   (le_eq_31 && read_not_frame_end_p2)) ?
                                   rotator_out[143:135] :
                                   (!le_eq_30 && read_frame_end_p2) ?
                                    fifo_reg31 : fifo_reg32;
        end

      //------------------------------------------------------------------------
      // Clock process to realize fifo_reg16 register
      //------------------------------------------------------------------------
      always @(posedge cxtmc_clk)
        begin
          if (fifo_reg16_en)
            fifo_reg16 <= nxt_fifo_reg16;
        end
    end
endgenerate

  //----------------------------------------------------------------------------
  // Combinational blocks for the remaining registers of the 128-bit formatter
  // FIFO.
  //----------------------------------------------------------------------------
generate
  if (CXTMC_ATB_DATA_WIDTH == 128)
    begin  

      assign fifo_reg17_en = (le_eq_16 & read_nothing_p2) |
                             read_frame_end_p2 |
                             read_not_frame_end_p2;
      assign fifo_reg18_en = (le_eq_17 & read_nothing_p2) |
                             read_frame_end_p2 |
                             read_not_frame_end_p2;
      assign fifo_reg19_en = (le_eq_18 & read_nothing_p2) |
                             read_frame_end_p2 |
                             read_not_frame_end_p2;
      assign fifo_reg20_en = (le_eq_19 & read_nothing_p2) |
                             read_frame_end_p2 |
                             read_not_frame_end_p2;
      assign fifo_reg21_en = (le_eq_20 & read_nothing_p2) |
                             read_frame_end_p2 |
                             read_not_frame_end_p2;
      assign fifo_reg22_en = (le_eq_21 & read_nothing_p2) |
                             read_frame_end_p2 |
                             read_not_frame_end_p2;
      assign fifo_reg23_en = (le_eq_22 & read_nothing_p2) |
                             read_frame_end_p2 |
                             read_not_frame_end_p2;
      assign fifo_reg24_en = (le_eq_23 & read_nothing_p2) |
                             read_frame_end_p2 |
                             read_not_frame_end_p2;
      assign fifo_reg25_en = (le_eq_24 & read_nothing_p2) |
                             read_frame_end_p2 |
                             read_not_frame_end_p2;
      assign fifo_reg26_en = (le_eq_25 & read_nothing_p2) |
                             read_frame_end_p2 |
                             read_not_frame_end_p2;
      assign fifo_reg27_en = (le_eq_26 & read_nothing_p2) |
                             read_frame_end_p2 |
                             read_not_frame_end_p2;
      assign fifo_reg28_en = (le_eq_27 & read_nothing_p2) |
                             read_frame_end_p2 |
                             read_not_frame_end_p2;
      assign fifo_reg29_en = (le_eq_28 & read_nothing_p2) |
                             read_frame_end_p2 |
                             read_not_frame_end_p2;
      assign fifo_reg30_en = (le_eq_29 & read_nothing_p2) |
                             read_frame_end_p2 |
                             read_not_frame_end_p2;
      assign fifo_reg31_en = (le_eq_30 & read_nothing_p2) |
                             read_frame_end_p2 |
                             read_not_frame_end_p2;
      assign fifo_reg32_en = (le_eq_31 & read_nothing_p2) |
                             read_frame_end_p2 |
                             read_not_frame_end_p2;

      assign nxt_fifo_reg17 = ((le_eq_16 && read_nothing_p2)  ||
                               (le_eq_31 && read_frame_end_p2) ||
                               read_not_frame_end_p2) ?
                               rotator_out[152:144] : {1'b0,fifo_reg32};

      assign nxt_fifo_reg18 = rotator_out[161:153];
      assign nxt_fifo_reg19 = rotator_out[170:162];
      assign nxt_fifo_reg20 = rotator_out[179:171];
      assign nxt_fifo_reg21 = rotator_out[188:180];
      assign nxt_fifo_reg22 = rotator_out[197:189];
      assign nxt_fifo_reg23 = rotator_out[206:198];
      assign nxt_fifo_reg24 = rotator_out[215:207];
      assign nxt_fifo_reg25 = rotator_out[224:216];
      assign nxt_fifo_reg26 = rotator_out[233:225];
      assign nxt_fifo_reg27 = rotator_out[242:234];
      assign nxt_fifo_reg28 = rotator_out[251:243];
      assign nxt_fifo_reg29 = rotator_out[260:252];
      assign nxt_fifo_reg30 = rotator_out[269:261];
      assign nxt_fifo_reg31 = rotator_out[278:270];
      assign nxt_fifo_reg32 = rotator_out[286:279];

  //----------------------------------------------------------------------------
  // Clock process to realize formatter fifo entries 17 to 32
  //----------------------------------------------------------------------------
      always @(posedge cxtmc_clk)
        begin : p_fifo_17_to_32_seq
         if (fifo_reg17_en)
           fifo_reg17 <= nxt_fifo_reg17;
         if (fifo_reg18_en)
           fifo_reg18 <= nxt_fifo_reg18;
         if (fifo_reg19_en)
           fifo_reg19 <= nxt_fifo_reg19;
         if (fifo_reg20_en)
           fifo_reg20 <= nxt_fifo_reg20;
         if (fifo_reg21_en)
           fifo_reg21 <= nxt_fifo_reg21;
         if (fifo_reg22_en)
           fifo_reg22 <= nxt_fifo_reg22;
         if (fifo_reg23_en)
           fifo_reg23 <= nxt_fifo_reg23;
         if (fifo_reg24_en)
           fifo_reg24 <= nxt_fifo_reg24;
         if (fifo_reg25_en)
           fifo_reg25 <= nxt_fifo_reg25;
         if (fifo_reg26_en)
           fifo_reg26 <= nxt_fifo_reg26;
         if (fifo_reg27_en)
           fifo_reg27 <= nxt_fifo_reg27;
         if (fifo_reg28_en)
           fifo_reg28 <= nxt_fifo_reg28;
         if (fifo_reg29_en)
           fifo_reg29 <= nxt_fifo_reg29;
         if (fifo_reg30_en)
           fifo_reg30 <= nxt_fifo_reg30;
         if (fifo_reg31_en)
           fifo_reg31 <= nxt_fifo_reg31;
         if (fifo_reg32_en)
           fifo_reg32 <= nxt_fifo_reg32;
        end // p_fifo_17_to_32_seq
    end
endgenerate

  //============================================================================
  // p2 pipeline stage -- formatter FIFO read side
  //============================================================================
  
  //----------------------------------------------------------------------------
  // Combinational block for calculating the read_size_p2 value.
  // Indicates the value in number of bytes that the output interface of the
  // formatter is reading from the internal FIFO.
  //----------------------------------------------------------------------------

  // The legal stop position is:
  // * On an even write, to align with the memory write width
  // * On a frame boundary.  Strictly speaking this is only required when the
  //   formatter is enabled, but maintaining this property when the formatter
  //   is disabled reduces the validation space and has negligible performance
  //   impact.
  // From 64-bit onwards, even writes are always on frame boundaries.
  
generate
  if (CXTMC_ATB_DATA_WIDTH == 32)
    begin
      // We are on the last transfer of the frame
      assign stop_position_p2 = (frame_pos_ctr_p2 == 2'b11);
      
      assign read_not_frame_end_p2 = wb_ready & ~le_eq_3 &
                                     ~stop_seq_ended_p2 &
                                     ~(ffcr_en_formatting_masked &
                                       stop_position_p2);
      assign read_frame_end_p2 = wb_ready & ffcr_en_formatting_masked &
                                 ~le_eq_2 & stop_position_p2;
      assign read_size_p2 = ({3{read_not_frame_end_p2}} & 3'b100) |
                            ({3{read_frame_end_p2}} & 3'b011);

      // We are on the last transfer of the frame
      assign stop_position_p1 = (frame_pos_ctr_p1 == 2'b11);
      
      assign read_not_frame_end_p1 = nxt_wb_ready & ~le_eq_3_p1 &
                                     ~(ffcr_en_formatting_masked &
                                       stop_position_p1);
      assign read_frame_end_p1 = nxt_wb_ready & ffcr_en_formatting_masked &
                                 ~le_eq_2_p1 & stop_position_p1;
      assign read_size_p1 = ({3{read_not_frame_end_p1}} & 3'b100) |
                            ({3{read_frame_end_p1}} & 3'b011);
    end

  else if (CXTMC_ATB_DATA_WIDTH == 64)
    begin  
      // We are on the last transfer of the frame
      assign stop_position_p2 = (frame_pos_ctr_p2 == 1'b1);
      
      assign read_not_frame_end_p2 = wb_ready & ~le_eq_7 &
                                     ~stop_seq_ended_p2 &
                                     ~(ffcr_en_formatting_masked &
                                       stop_position_p2);
      assign read_frame_end_p2 = wb_ready & ffcr_en_formatting_masked &
                                 ~le_eq_6 & stop_position_p2;
      assign read_size_p2 = ({4{read_not_frame_end_p2}} & 4'b1000) |
                            ({4{read_frame_end_p2}} & 4'b0111);
      // We are on the last transfer of the frame
      assign stop_position_p1 = (frame_pos_ctr_p1 == 1'b1);
      
      assign read_not_frame_end_p1 = nxt_wb_ready & ~le_eq_7_p1 &
                                     ~(ffcr_en_formatting_masked &
                                       stop_position_p1);
      assign read_frame_end_p1 = nxt_wb_ready & ffcr_en_formatting_masked &
                                 ~le_eq_6_p1 & stop_position_p1;
      assign read_size_p1 = ({4{read_not_frame_end_p1}} & 4'b1000) |
                            ({4{read_frame_end_p1}} & 4'b0111);
    end

  else if (CXTMC_ATB_DATA_WIDTH == 128)
    begin
      // We are on an even frame
      assign stop_position_p2 = (frame_pos_ctr_p2 == 1'b1);

      // No need to take stop_position_p2 into account, since we are always on a
      // frame boundary.
      assign read_not_frame_end_p2 = wb_ready & ~le_eq_15 &
                                     ~stop_seq_ended_p2 &
                                     ~ffcr_en_formatting_masked;
      assign read_frame_end_p2 = wb_ready & ffcr_en_formatting_masked &
                                 ~le_eq_14 & ~stop_seq_ended_p2;
      assign read_size_p2 = ({5{read_not_frame_end_p2}} & 5'b10000) |
                            ({5{read_frame_end_p2}} & 5'b01111);
      
      assign read_not_frame_end_p1 = nxt_wb_ready & ~le_eq_15_p1 &
                                     ~ffcr_en_formatting_masked;
      assign read_frame_end_p1 = nxt_wb_ready & ffcr_en_formatting_masked &
                                 ~le_eq_14_p1;
      assign read_size_p1 = ({5{read_not_frame_end_p1}} & 5'b10000) |
                            ({5{read_frame_end_p1}} & 5'b01111);
    end
endgenerate
  
  // Shorthand for when no data is being read
  assign read_nothing_p2 = ~read_frame_end_p2 & ~read_not_frame_end_p2;

  // ft_data_valid_p2 is asserted when formatter fifo has sufficient entries to
  // satisfy the full data.
  assign ft_data_valid_p2 = (read_not_frame_end_p2 | read_frame_end_p2) &
                             ~(stop_seq_ended_p2 & ft_stop_req);
  
  //----------------------------------------------------------------------------
  // Combinational block for calculating ft_data. This block generates
  // the formatted data in bypass and normal modes.
  //----------------------------------------------------------------------------
  
  assign ft_data_p2[15:0] = ffcr_en_formatting_masked ?
                            fifo_reg2[8] ?
                            {fifo_reg1[7:0],fifo_reg2[7:1],fifo_reg2[8]} :
                            {fifo_reg2[7:0],fifo_reg1[7:1],fifo_reg1[8]} :
                            {fifo_reg2[7:0],fifo_reg1[7:0]};

generate
  if (CXTMC_ATB_DATA_WIDTH == 32)
    begin  
      assign ft_data_p2[23:16] = ffcr_en_formatting_masked ?
                                 (read_not_frame_end_p2 ?
                                  (fifo_reg4[8] ?
                                   {fifo_reg4[7:1],fifo_reg4[8]} :
                                   {fifo_reg3[7:1],fifo_reg3[8]}) :
                                  (read_frame_end_p2 ?
                                   {fifo_reg3[7:1],fifo_reg3[8]} :
                                   fifo_reg3[7:0])) :
                                 fifo_reg3[7:0];
  
  
      assign ft_data_p2[29:24] = (ffcr_en_formatting_masked ?
                                  (read_not_frame_end_p2 ?
                                   (fifo_reg4[8] ?
                                    fifo_reg3[5:0] :
                                    fifo_reg4[5:0]) :
                                   lbs[5:0]) :
                                  fifo_reg4[5:0]);

      assign ft_data_p2[30] = (ffcr_en_formatting_masked ?
                               (read_not_frame_end_p2 ?
                                (fifo_reg4[8] ?
                                 fifo_reg3[6] : fifo_reg4[6]) :
                                (fifo_reg2[8] ?
                                 ~fifo_reg2[0] : fifo_reg1[0])) :
                               fifo_reg4[6]);
  
      assign ft_data_p2[31] = (ffcr_en_formatting_masked ?
                               (read_not_frame_end_p2 ?
                                (fifo_reg4[8] ?
                                 fifo_reg3[7] : fifo_reg4[7]) :
                                fifo_reg3[0]) :
                               fifo_reg4[7]);
    end
endgenerate

generate
  if ((CXTMC_ATB_DATA_WIDTH == 64) || (CXTMC_ATB_DATA_WIDTH == 128))
    begin  
      assign ft_data_p2[31:16] = ffcr_en_formatting_masked ?
                                 fifo_reg4[8] ?
                                 {fifo_reg3[7:0],fifo_reg4[7:1],fifo_reg4[8]} :
                                 {fifo_reg4[7:0],fifo_reg3[7:1],fifo_reg3[8]} :
                                 {fifo_reg4[7:0],fifo_reg3[7:0]};
  
      assign ft_data_p2[47:32] = ffcr_en_formatting_masked ?
                                 fifo_reg6[8] ?
                                 {fifo_reg5[7:0],fifo_reg6[7:1],fifo_reg6[8]} :
                                 {fifo_reg6[7:0],fifo_reg5[7:1],fifo_reg5[8]} :
                                 {fifo_reg6[7:0],fifo_reg5[7:0]};
    end
endgenerate

generate
  if (CXTMC_ATB_DATA_WIDTH == 64)
    begin  
      assign ft_data_p2[55:48] = ffcr_en_formatting_masked ?
                                 (read_not_frame_end_p2 ?
                                  (fifo_reg8[8] ?
                                   {fifo_reg8[7:1],fifo_reg8[8]} :
                                   {fifo_reg7[7:1],fifo_reg7[8]}) :
                                  (read_frame_end_p2 ?
                                   {fifo_reg7[7:1],fifo_reg7[8]} :
                                   fifo_reg7[7:0])) :
                                 fifo_reg7[7:0];
  
      assign ft_data_p2[59:56] = (ffcr_en_formatting_masked ?
                                  (read_not_frame_end_p2 ?
                                   (fifo_reg8[8] ?
                                    fifo_reg7[3:0] :
                                    fifo_reg8[3:0]) :
                                   lbs[3:0]) :
                                  fifo_reg8[3:0]);
  
      assign ft_data_p2[60] = (ffcr_en_formatting_masked ?
                               (read_not_frame_end_p2 ?
                                (fifo_reg8[8] ?
                                 fifo_reg7[4] : fifo_reg8[4]) :
                                (fifo_reg2[8] ?
                                 ~fifo_reg2[0] : fifo_reg1[0])) :
                               fifo_reg8[4]);
  
      assign ft_data_p2[61] = (ffcr_en_formatting_masked ?
                               (read_not_frame_end_p2 ?
                                (fifo_reg8[8] ?
                                 fifo_reg7[5] : fifo_reg8[5]) :
                                (fifo_reg4[8] ?
                                 ~fifo_reg4[0] : fifo_reg3[0])) :
                               fifo_reg8[5]);
  
      assign ft_data_p2[62] = (ffcr_en_formatting_masked ?
                               (read_not_frame_end_p2 ?
                                (fifo_reg8[8] ?
                                 fifo_reg7[6] : fifo_reg8[6]) :
                                (fifo_reg6[8] ?
                                 ~fifo_reg6[0] : fifo_reg5[0])) :
                               fifo_reg8[6]);
  
      assign ft_data_p2[63] = (ffcr_en_formatting_masked ?
                               (read_not_frame_end_p2 ?
                                (fifo_reg8[8] ?
                                 fifo_reg7[7] : fifo_reg8[7]) :
                                fifo_reg7[0]) :
                               fifo_reg8[7]);
    end
endgenerate
  
generate
  if (CXTMC_ATB_DATA_WIDTH == 128)
    begin  
      assign ft_data_p2[63:48] = ffcr_en_formatting_masked ?
                                 fifo_reg8[8] ?
                                 {fifo_reg7[7:0],fifo_reg8[7:1],fifo_reg8[8]} :
                                 {fifo_reg8[7:0],fifo_reg7[7:1],fifo_reg7[8]} :
                                 {fifo_reg8[7:0],fifo_reg7[7:0]};

      assign ft_data_p2[79:64] = ffcr_en_formatting_masked ?
                                 fifo_reg10[8] ?
                                 {fifo_reg9[7:0],fifo_reg10[7:1],
                                  fifo_reg10[8]} : 
                                  {fifo_reg10[7:0], fifo_reg9[7:1],
                                  fifo_reg9[8]} :
                                 {fifo_reg10[7:0],fifo_reg9[7:0]};

      assign ft_data_p2[95:80] = ffcr_en_formatting_masked ?
                                 fifo_reg12[8] ?
                                 {fifo_reg11[7:0],fifo_reg12[7:1],
                                  fifo_reg12[8]} :
                                 {fifo_reg12[7:0],fifo_reg11[7:1],
                                  fifo_reg11[8]} :
                                 {fifo_reg12[7:0],fifo_reg11[7:0]};
  
      assign ft_data_p2[111:96] = ffcr_en_formatting_masked ?
                                  fifo_reg14[8] ?
                                  {fifo_reg13[7:0],fifo_reg14[7:1],
                                   fifo_reg14[8]} :
                                  {fifo_reg14[7:0],fifo_reg13[7:1],
                                   fifo_reg13[8]} :
                                  {fifo_reg14[7:0],fifo_reg13[7:0]};
      
      assign ft_data_p2[119:112] = ffcr_en_formatting_masked ?
                                   {fifo_reg15[7:1],fifo_reg15[8]} :
                                   {fifo_reg15[7:0]};
  
      assign ft_data_p2[120] = (ffcr_en_formatting_masked ?
                                (fifo_reg2[8] ?
                                 ~fifo_reg2[0] : fifo_reg1[0]) :
                                 fifo_reg16[0]);
      
      assign ft_data_p2[121] = (ffcr_en_formatting_masked ?
                                (fifo_reg4[8] ?
                                 ~fifo_reg4[0] : fifo_reg3[0]) :
                                 fifo_reg16[1]);
  
      assign ft_data_p2[122] = (ffcr_en_formatting_masked ?
                                (fifo_reg6[8] ?
                                 ~fifo_reg6[0] : fifo_reg5[0]) :
                                 fifo_reg16[2]);
  
      assign ft_data_p2[123] = (ffcr_en_formatting_masked ?
                                (fifo_reg8[8] ?
                                 ~fifo_reg8[0] : fifo_reg7[0]) :
                                 fifo_reg16[3]);
      
      assign ft_data_p2[124] = (ffcr_en_formatting_masked ?
                                (fifo_reg10[8] ?
                                 ~fifo_reg10[0] : fifo_reg9[0]) :
                                 fifo_reg16[4]);
      
      assign ft_data_p2[125] = (ffcr_en_formatting_masked ?
                                (fifo_reg12[8] ?
                                 ~fifo_reg12[0] : fifo_reg11[0]) :
                                 fifo_reg16[5]);
      
      assign ft_data_p2[126] = (ffcr_en_formatting_masked ?
                                (fifo_reg14[8] ?
                                 ~fifo_reg14[0] : fifo_reg13[0]) :
                                 fifo_reg16[6]);
  
      assign ft_data_p2[127] = ffcr_en_formatting_masked ?
                               fifo_reg15[0] :
                               fifo_reg16[7];
    end
endgenerate
  
  //----------------------------------------------------------------------------
  // Combinational block for calculating the LBS for the formatted frames in
  // normal mode. The block stores some bits of the LBS, depending on formatter
  // size. Some of the bits of the LBS are appended on the fly in the block
  // where the ft_data_p2 is generated.
  // lbs_mask is used to allow one bit of the LBS to be calculated at a time.
  //----------------------------------------------------------------------------

generate
  if (CXTMC_ATB_DATA_WIDTH != 128)
    begin : g1_lbs
      if (CXTMC_ATB_DATA_WIDTH == 32)
        begin
          assign lbs_mask[0] = (frame_pos_ctr_p2 == 2'b00);
          assign lbs_mask[1] = (frame_pos_ctr_p2 == 2'b00);
          assign lbs_mask[2] = (frame_pos_ctr_p2 == 2'b01);
          assign lbs_mask[3] = (frame_pos_ctr_p2 == 2'b01);
          assign lbs_mask[4] = (frame_pos_ctr_p2 == 2'b10);
          assign lbs_mask[5] = (frame_pos_ctr_p2 == 2'b10);
  
          assign nxt_lbs[5:0] = (read_not_frame_end_p2 &&
                                  ffcr_en_formatting_masked) ?
                        ((lbs_mask[5:0] &
                          {fifo_reg4[8] ? ~fifo_reg4[0] : fifo_reg3[0],
                           fifo_reg2[8] ? ~fifo_reg2[0] : fifo_reg1[0],
                           fifo_reg4[8] ? ~fifo_reg4[0] : fifo_reg3[0],
                           fifo_reg2[8] ? ~fifo_reg2[0] : fifo_reg1[0],
                           fifo_reg4[8] ? ~fifo_reg4[0] : fifo_reg3[0],
                           fifo_reg2[8] ? ~fifo_reg2[0] : fifo_reg1[0]}) |
                         lbs[5:0]) :
                        (read_not_frame_end_p2 && !ffcr_en_formatting_masked) ?
                        {6{1'b0}} :
                        ((read_frame_end_p2 && ffcr_en_formatting_masked) ||
                         stop_seq_ended_p2) ?
                        {6{1'b0}} : lbs[5:0];
        end
    else if (CXTMC_ATB_DATA_WIDTH == 64)
      begin  
        assign lbs_mask[0] = (frame_pos_ctr_p2 == 1'b0);
        assign lbs_mask[1] = (frame_pos_ctr_p2 == 1'b0);
        assign lbs_mask[2] = (frame_pos_ctr_p2 == 1'b0);
        assign lbs_mask[3] = (frame_pos_ctr_p2 == 1'b0);

        assign nxt_lbs[3:0] = (read_not_frame_end_p2 &&
                                ffcr_en_formatting_masked) ?
                        (lbs_mask[3:0] &
                         {fifo_reg8[8] ? ~fifo_reg8[0] : fifo_reg7[0],
                          fifo_reg6[8] ? ~fifo_reg6[0] : fifo_reg5[0],
                          fifo_reg4[8] ? ~fifo_reg4[0] : fifo_reg3[0],
                          fifo_reg2[8] ? ~fifo_reg2[0] : fifo_reg1[0]}) |
                        lbs[3:0] :
                        ((read_frame_end_p2 && ffcr_en_formatting_masked) ||
                         stop_seq_ended_p2) ?
                        {4{1'b0}} :
                        (read_frame_end_p2 && !ffcr_en_formatting_masked) ?
                        {4{1'b0}} : lbs[3:0];
      end

  //----------------------------------------------------------------------------
  // Sequential logic to register lbs
  //----------------------------------------------------------------------------
      always @(posedge cxtmc_clk or negedge RESETn)
        begin : p_int_reg_seq
          if (!RESETn)
            begin
              lbs             <= {CXTMC_LBS_WIDTH{1'b0}};
            end
          else 
            begin
              // No need for an LBS in the 128-bit case, as the whole
              // frame is output in one go.
              lbs             <= nxt_lbs;
            end
        end // p_int_reg_seq  
    end
endgenerate
  

  always @(posedge cxtmc_clk or negedge RESETn)
    if (!RESETn)
      begin
        frame_pos_ctr_p2   <= {CXTMC_CTR_WIDTH{1'b0}};
      end
    else 
      begin
        // The frame position counter is used in the 128-bit case to indicate
        // whether we are on an even write to the write buffer, so is used in
        // all configurations.
        if (ft_data_valid_p2)
          frame_pos_ctr_p2 <= frame_pos_ctr_p1;
      end
  
  //============================================================================
  // ASSERTIONS
  //============================================================================
`ifdef ARM_ASSERT_ON
  
    assert_zero_one_hot #(`OVL_ERROR, 3, `OVL_ASSERT,
    "OVL Message : cxtmc_formatter - Multiple special packets selected on formatter input")
      uzovl_cxtmc_formatter_000
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   ({insert_trigger_p1, insert_one_p1, insert_null_p1})
        );

  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxtmc_formatter - Trigger packet requested when formatter bypassed")
      uzovl_cxtmc_formatter_001
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   (insert_trigger_p1 & ~ffcr_en_formatting_masked)
        );

  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxtmc_formatter - Trigger packet requested when formatter stop requested")
      uzovl_cxtmc_formatter_002
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   (ft_trig_req & ft_stop_req)
        );

  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxtmc_formatter - ftin_id_p2 not reset to zero when formatter stopped")
      uzovl_cxtmc_formatter_003
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   (stop_seq_ended_p2 & (|ftin_id_p2))
        );

  wire valid_state;
  assign valid_state = (form_stop_state == FORM_STOP_STATE_STOPPED) |
                       (form_stop_state == FORM_STOP_STATE_RUNNING) |
                       (form_stop_state == FORM_STOP_STATE_P1_ALIGN) |
                       (form_stop_state == FORM_STOP_STATE_FINAL_ONE) |
                       (form_stop_state == FORM_STOP_STATE_P2_ALIGN) |
                       (form_stop_state == FORM_STOP_STATE_FLUSH1) |
                       (form_stop_state == FORM_STOP_STATE_FLUSH2) |
                       (form_stop_state == FORM_STOP_STATE_FRAME_ALIGN);

  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxtmc_formatter - formatter FSM enetered default state")
      uzovl_cxtmc_formatter_004
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   (~valid_state)
        );

    assert_zero_one_hot #(`OVL_ERROR, 2, `OVL_ASSERT,
    "OVL Message : cxtmc_formatter - Frame End and Middle of the frame indicator \
                                     signal is set in p1 stage")
      uzovl_cxtmc_formatter_005
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   ({read_not_frame_end_p1, read_frame_end_p1})
        );

    assert_zero_one_hot #(`OVL_ERROR, 2, `OVL_ASSERT,
    "OVL Message : cxtmc_formatter - Frame End and Middle of the frame indicator \
                                     signal is set in p2 stage")
      uzovl_cxtmc_formatter_006
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   ({read_not_frame_end_p2, read_frame_end_p2})
        );

    assert_zero_one_hot #(`OVL_ERROR, 2, `OVL_ASSERT,
    "OVL Message : cxtmc_formatter - Formatter flush request and stop request \
                                     asserted at same time")
      uzovl_cxtmc_formatter_007
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   ({ft_stop_req, ft_flush_req})
        );

    assert_zero_one_hot #(`OVL_ERROR, 2, `OVL_ASSERT,
    "OVL Message : cxtmc_formatter - Formatter flush request and trigger request \
                                     asserted at same time")
      uzovl_cxtmc_formatter_008
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   ({ft_trig_req, ft_flush_req})
        );
  wire [CXTMC_ATB_DATA_WIDTH-1 : 0] ft_data_mask;
  assign ft_data_mask = (CXTMC_ATB_DATA_WIDTH == 32) ? 32'h00FEFFFE :
                         (CXTMC_ATB_DATA_WIDTH == 64) ? 64'h00FEFFFEFFFEFFFE :
                          128'h00FEFFFEFFFEFFFEFFFEFFFEFFFEFFFE;

  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxtmc_formatter - formatter flush happened with non -zero data")
      uzovl_cxtmc_formatter_009
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   (ft_flush_req && form_stop_state_en && (form_stop_state == FORM_STOP_STATE_FRAME_ALIGN) && ((ft_data & ft_data_mask) != 'h0))
        );

  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : When formatter flush is in progress FSM enters this state only for 1 clock cycle to assert ft_flush_ack, hence both being '1' is not possible.")
      uzovl_cxtmc_formatter_010
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   (({ft_stop_req,(ft_flush_req&((~ft_flush_ack)))} == {1'b0,1'b1}) && (form_stop_state == FORM_STOP_STATE_STOPPED))
        );
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : When formatter flush is in progress FSM enters this state only for 1 clock cycle to assert ft_flush_ack, hence both being '1' is not possible.")
      uzovl_cxtmc_formatter_011
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   (({ft_flush_req,((~ft_flush_ack))} == {1'b1,1'b1} && (form_stop_state == FORM_STOP_STATE_STOPPED)))
        );
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : read_nothing_p2 is de-asserted when there is sufficient data to drive on ftdata bus")
      uzovl_cxtmc_formatter_012
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   ({equal_0,read_nothing_p2} == {1'b1,1'b0})
        );
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : read_nothing_p2 is de-asserted when there is sufficient data to drive on ftdata bus")
      uzovl_cxtmc_formatter_013
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   ({le_eq_1,read_nothing_p2} == {1'b1,1'b0})
        );
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : read_nothing_p2 is de-asserted when there is sufficient data to drive on ftdata bus")
      uzovl_cxtmc_formatter_014
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   ({le_eq_2,read_nothing_p2} == {1'b1,1'b0})
        );
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : read_frame_end_p2 is asserted when formatting is disabled.")
      uzovl_cxtmc_formatter_015
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   ({read_frame_end_p2,ffcr_en_formatting_masked} == {1'b1,1'b0})
        );

  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : FSM will not enter default state.")
      uzovl_cxtmc_formatter_016
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   ({(form_stop_state==FORM_STOP_STATE_STOPPED),(form_stop_state==FORM_STOP_STATE_RUNNING),(form_stop_state==FORM_STOP_STATE_P1_ALIGN),(form_stop_state==FORM_STOP_STATE_FINAL_ONE),(form_stop_state==FORM_STOP_STATE_P2_ALIGN),(form_stop_state==FORM_STOP_STATE_FLUSH1),(form_stop_state==FORM_STOP_STATE_FLUSH2),(form_stop_state==FORM_STOP_STATE_FRAME_ALIGN)} == {1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0})
        );

generate
  if ((CXTMC_ATB_DATA_WIDTH == 128) || (CXTMC_ATB_DATA_WIDTH == 64))
    begin
      assert_never #(`OVL_ERROR, `OVL_ASSERT,
     "OVL Message : read_nothing_p2 is de-asserted when there is sufficient data to drive on ftdata bus")
        uzovl_cxtmc_formatter_017
          (
           .clk         (cxtmc_clk),
           .reset_n     (RESETn),
           .test_expr   ({le_eq_3,read_nothing_p2} == {1'b1,1'b0})
          );
      assert_never #(`OVL_ERROR, `OVL_ASSERT,
     "OVL Message : read_nothing_p2 is de-asserted when there is sufficient data to drive on ftdata bus")
        uzovl_cxtmc_formatter_018
          (
           .clk         (cxtmc_clk),
           .reset_n     (RESETn),
           .test_expr   ({le_eq_4,read_nothing_p2} == {1'b1,1'b0})
          );
      assert_never #(`OVL_ERROR, `OVL_ASSERT,
     "OVL Message : read_nothing_p2 is de-asserted when there is sufficient data to drive on ftdata bus")
        uzovl_cxtmc_formatter_019
          (
           .clk         (cxtmc_clk),
           .reset_n     (RESETn),
           .test_expr   ({le_eq_5,read_nothing_p2} == {1'b1,1'b0})
          );
      assert_never #(`OVL_ERROR, `OVL_ASSERT,
     "OVL Message : read_nothing_p2 is de-asserted when there is sufficient data to drive on ftdata bus")
        uzovl_cxtmc_formatter_020
          (
           .clk         (cxtmc_clk),
           .reset_n     (RESETn),
           .test_expr   ({le_eq_6,read_nothing_p2} == {1'b1,1'b0})
          );
    end
endgenerate
generate
  if (CXTMC_ATB_DATA_WIDTH == 128)
    begin
      assert_never #(`OVL_ERROR, `OVL_ASSERT,
     "OVL Message : read_nothing_p2 is de-asserted when there is sufficient data to drive on ftdata bus")
        uzovl_cxtmc_formatter_021
          (
           .clk         (cxtmc_clk),
           .reset_n     (RESETn),
           .test_expr   ({le_eq_7,read_nothing_p2} == {1'b1,1'b0})
          );
      assert_never #(`OVL_ERROR, `OVL_ASSERT,
     "OVL Message : read_nothing_p2 is de-asserted when there is sufficient data to drive on ftdata bus")
        uzovl_cxtmc_formatter_022
          (
           .clk         (cxtmc_clk),
           .reset_n     (RESETn),
           .test_expr   ({le_eq_8,read_nothing_p2} == {1'b1,1'b0})
          );
      assert_never #(`OVL_ERROR, `OVL_ASSERT,
     "OVL Message : read_nothing_p2 is de-asserted when there is sufficient data to drive on ftdata bus")
        uzovl_cxtmc_formatter_023
          (
           .clk         (cxtmc_clk),
           .reset_n     (RESETn),
           .test_expr   ({le_eq_9,read_nothing_p2} == {1'b1,1'b0})
          );
      assert_never #(`OVL_ERROR, `OVL_ASSERT,
     "OVL Message : read_nothing_p2 is de-asserted when there is sufficient data to drive on ftdata bus")
        uzovl_cxtmc_formatter_024
          (
           .clk         (cxtmc_clk),
           .reset_n     (RESETn),
           .test_expr   ({le_eq_10,read_nothing_p2} == {1'b1,1'b0})
          );
      assert_never #(`OVL_ERROR, `OVL_ASSERT,
     "OVL Message : read_nothing_p2 is de-asserted when there is sufficient data to drive on ftdata bus")
        uzovl_cxtmc_formatter_025
          (
           .clk         (cxtmc_clk),
           .reset_n     (RESETn),
           .test_expr   ({le_eq_11,read_nothing_p2} == {1'b1,1'b0})
          );
      assert_never #(`OVL_ERROR, `OVL_ASSERT,
     "OVL Message : read_nothing_p2 is de-asserted when there is sufficient data to drive on ftdata bus")
        uzovl_cxtmc_formatter_026
          (
           .clk         (cxtmc_clk),
           .reset_n     (RESETn),
           .test_expr   ({le_eq_12,read_nothing_p2} == {1'b1,1'b0})
          );
      assert_never #(`OVL_ERROR, `OVL_ASSERT,
     "OVL Message : read_nothing_p2 is de-asserted when there is sufficient data to drive on ftdata bus")
        uzovl_cxtmc_formatter_027
          (
           .clk         (cxtmc_clk),
           .reset_n     (RESETn),
           .test_expr   ({le_eq_13,read_nothing_p2} == {1'b1,1'b0})
          );
    end
endgenerate

`endif
     
endmodule
