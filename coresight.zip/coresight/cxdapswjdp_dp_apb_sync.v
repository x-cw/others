//----------------------------------------------------------------------------
//  The confidential and proprietary information contained in this file may
//  only be used by a person authorised under and to the extent permitted
//  by a subsisting licensing agreement from ARM Limited.
//
//                (C) COPYRIGHT 2004-2015 ARM Limited.
//                    ALL RIGHTS RESERVED
//
//  This entire notice must be reproduced on all copies of this file
//  and copies of this file may only be made by a person if such person is
//  permitted to do so under the terms of a subsisting license agreement
//  from ARM Limited.
//
//    Checked In : $Date: 2014-08-14 16:01:35 +0100 (Thu, 14 Aug 2014) $
//    Revision   : $Revision: 39945 $
//    Release    : CoreSight-SoC-TM100-r3p2-00rel0
// ----------------------------------------------------------------------------
//  Purpose : DAP JTAG-DP dapclk domain synchronisers
// ----------------------------------------------------------------------------

module cxdapswjdp_dp_apb_sync
  (
  // Inputs
  dapresetn, dapclk, dapclken, busreq, busabort,
  // Outputs
  busreq_d, busabort_d
  );

// ----------------------------------------------------------------------------
// Port Definitions
// ----------------------------------------------------------------------------
  input         dapresetn;      // synchroniser reset
  input         dapclk;         // synchroniser clock
  input         dapclken;       // synchroniser clock enable
  input         busreq;         // synchroniser input
  input         busabort;       // synchroniser input

  output        busreq_d;       // synchroniser output
  output        busabort_d;     // synchroniser output


// ----------------------------------------------------------------------------
// Variable definitions
// ----------------------------------------------------------------------------
  wire busreq_corrupt;
  wire busabort_corrupt;

// ----------------------------------------------------------------------------
// Corrupters
// ----------------------------------------------------------------------------

`ifdef ARM_CDC_CHECK
  // Test component to corrupt busreq going into synchroniser
  cx_cdc_corrupt_gry u_cdc_corrupt_busreq (
      .clk    (dapclk),
      .resetn (dapresetn),
      .sync   (1'b0),
      .d_async(busreq),
      .q_async(busreq_corrupt)
    );

  // Test component to corrupt busabort going into synchroniser
  cx_cdc_corrupt_gry u_cdc_corrupt_busabort (
      .clk    (dapclk),
      .resetn (dapresetn),
      .sync   (1'b0),
      .d_async(busabort),
      .q_async(busabort_corrupt)
    );
`else
  assign busreq_corrupt   = busreq;
  assign busabort_corrupt = busabort;
`endif

// ----------------------------------------------------------------------------
// synchronisers
// ----------------------------------------------------------------------------
  cx_en_sync  u_sync_bus_req
   (
    .resetn         (dapresetn),
    .clk            (dapclk),
    .clken          (dapclken),
    .sync_di        (busreq_corrupt),

    .sync_do        (busreq_d)
   );

  // synchroniser
  cx_en_sync  u_sync_bus_abort
   (
    .resetn         (dapresetn),
    .clk            (dapclk),
    .clken          (dapclken),
    .sync_di        (busabort_corrupt),

    .sync_do        (busabort_d)
   );

endmodule
