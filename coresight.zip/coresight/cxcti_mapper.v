//-----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2003-2015 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//    Checked In : $Date: 2014-07-28 11:23:24 +0100 (Mon, 28 Jul 2014) $
//    Revision   : $Revision: 39862 $
//    Release    : CoreSight-SoC-TM100-r3p2-00rel0
//
// -----------------------------------------------------------------------------
//      Purpose             : ECT channel and trigger mapping module
//
// --=========================================================================--

module cxcti_mapper
 (
  // Inputs
  cti_control, ctiinen0, ctiouten0, ctiinen1, ctiouten1, ctiinen2,
  ctiouten2, ctiinen3, ctiouten3, ctiinen4, ctiouten4, ctiinen5,
  ctiouten5, ctiinen6, ctiouten6, ctiinen7, ctiouten7, app_trigger,
  map_trig_in, map_ch_in,
  // Outputs
  map_trig_out, map_ch_out
  );

`include "cxcti_constants.v"

  //----------------------------------------------------------------------------
  // INPUTS
  //----------------------------------------------------------------------------
  input  cti_control;                        // SW enable

  // Trigger inputs
  input [CSSOC_ECTCHANNELWIDTH-1:0] ctiinen0;   // Enable trig in 0
  input [CSSOC_ECTCHANNELWIDTH-1:0] ctiouten0;  // Enable trig out 0
  input [CSSOC_ECTCHANNELWIDTH-1:0] ctiinen1;   // Enable trig in 1
  input [CSSOC_ECTCHANNELWIDTH-1:0] ctiouten1;  // Enable trig out 1
  input [CSSOC_ECTCHANNELWIDTH-1:0] ctiinen2;   // Enable trig in 2
  input [CSSOC_ECTCHANNELWIDTH-1:0] ctiouten2;  // Enable trig out 2
  input [CSSOC_ECTCHANNELWIDTH-1:0] ctiinen3;   // Enable trig in 3
  input [CSSOC_ECTCHANNELWIDTH-1:0] ctiouten3;  // Enable trig out 3
  input [CSSOC_ECTCHANNELWIDTH-1:0] ctiinen4;   // Enable trig in 4
  input [CSSOC_ECTCHANNELWIDTH-1:0] ctiouten4;  // Enable trig out 4
  input [CSSOC_ECTCHANNELWIDTH-1:0] ctiinen5;   // Enable trig in 5
  input [CSSOC_ECTCHANNELWIDTH-1:0] ctiouten5;  // Enable trig out 5
  input [CSSOC_ECTCHANNELWIDTH-1:0] ctiinen6;   // Enable trig in 6
  input [CSSOC_ECTCHANNELWIDTH-1:0] ctiouten6;  // Enable trig out 6
  input [CSSOC_ECTCHANNELWIDTH-1:0] ctiinen7;   // Enable trig in 7
  input [CSSOC_ECTCHANNELWIDTH-1:0] ctiouten7;  // Enable trig out 7


  input [CSSOC_ECTCHANNELWIDTH-1:0] app_trigger; // Application trigger

  input [CSSOC_ECTTRIGGERWIDTH-1:0] map_trig_in;  // Trigger inputs
  input [CSSOC_ECTCHANNELWIDTH-1:0] map_ch_in;    // Channel inputs

  //----------------------------------------------------------------------------
  // OUTPUTS
  //----------------------------------------------------------------------------

  output [CSSOC_ECTTRIGGERWIDTH-1:0] map_trig_out; // Trigger outputs
  output [CSSOC_ECTCHANNELWIDTH-1:0] map_ch_out;   // Channel outputs

  //----------------------------------------------------------------------------
  // WIRES AND REGS
  //----------------------------------------------------------------------------

  wire [CSSOC_ECTCHANNELWIDTH-1:0]   int_ch_out;   // Internal mapped channel o/p
  wire [CSSOC_ECTCHANNELWIDTH-1:0]   int_ch_in;    // Internal unmapped channel i/p

  wire    cti_map_en;   // Enable mapping


  //----------------------------------------------------------------------------
  //
  // MAIN CODE
  //
  //----------------------------------------------------------------------------


  assign  cti_map_en     = cti_control;  // Define Mapping enable

  // Input of channel to trigger mapping logic:
  // (local feedback + i/p from channel i/f + application trigger)
  assign  int_ch_in      = (cti_map_en==1'b1) ? (int_ch_out | map_ch_in | app_trigger):
                                              {CSSOC_ECTCHANNELWIDTH{1'b0}};

  // Channel output to CTI channel interface
  assign  map_ch_out     = (int_ch_out | app_trigger);

  // Mapping
  assign  int_ch_out[0] = (
                         (map_trig_in[0] & ctiinen0[0]) |
                         (map_trig_in[1] & ctiinen1[0]) |
                         (map_trig_in[2] & ctiinen2[0]) |
                         (map_trig_in[3] & ctiinen3[0]) |
                         (map_trig_in[4] & ctiinen4[0]) |
                         (map_trig_in[5] & ctiinen5[0]) |
                         (map_trig_in[6] & ctiinen6[0]) |
                         (map_trig_in[7] & ctiinen7[0]));

  //-------------------------------------------------
  assign  int_ch_out[1] = (
                         (map_trig_in[0] & ctiinen0[1]) |
                         (map_trig_in[1] & ctiinen1[1]) |
                         (map_trig_in[2] & ctiinen2[1]) |
                         (map_trig_in[3] & ctiinen3[1]) |
                         (map_trig_in[4] & ctiinen4[1]) |
                         (map_trig_in[5] & ctiinen5[1]) |
                         (map_trig_in[6] & ctiinen6[1]) |
                         (map_trig_in[7] & ctiinen7[1]));

  //-------------------------------------------------
  assign  int_ch_out[2] = (
                         (map_trig_in[0] & ctiinen0[2]) |
                         (map_trig_in[1] & ctiinen1[2]) |
                         (map_trig_in[2] & ctiinen2[2]) |
                         (map_trig_in[3] & ctiinen3[2]) |
                         (map_trig_in[4] & ctiinen4[2]) |
                         (map_trig_in[5] & ctiinen5[2]) |
                         (map_trig_in[6] & ctiinen6[2]) |
                         (map_trig_in[7] & ctiinen7[2]));
  //-------------------------------------------------
  assign  int_ch_out[3] = (
                         (map_trig_in[0] & ctiinen0[3]) |
                         (map_trig_in[1] & ctiinen1[3]) |
                         (map_trig_in[2] & ctiinen2[3]) |
                         (map_trig_in[3] & ctiinen3[3]) |
                         (map_trig_in[4] & ctiinen4[3]) |
                         (map_trig_in[5] & ctiinen5[3]) |
                         (map_trig_in[6] & ctiinen6[3]) |
                         (map_trig_in[7] & ctiinen7[3]));

  //-------------------------------------------------
  assign  map_trig_out[0] = (
                           (int_ch_in[0] & ctiouten0[0]) |
                           (int_ch_in[1] & ctiouten0[1]) |
                           (int_ch_in[2] & ctiouten0[2]) |
                           (int_ch_in[3] & ctiouten0[3]));
  //-------------------------------------------------
  assign  map_trig_out[1] = (
                           (int_ch_in[0] & ctiouten1[0]) |
                           (int_ch_in[1] & ctiouten1[1]) |
                           (int_ch_in[2] & ctiouten1[2]) |
                           (int_ch_in[3] & ctiouten1[3]));
  //-------------------------------------------------
  assign  map_trig_out[2] = (
                           (int_ch_in[0] & ctiouten2[0]) |
                           (int_ch_in[1] & ctiouten2[1]) |
                           (int_ch_in[2] & ctiouten2[2]) |
                           (int_ch_in[3] & ctiouten2[3]));
  //-------------------------------------------------
  assign  map_trig_out[3] = (
                           (int_ch_in[0] & ctiouten3[0]) |
                           (int_ch_in[1] & ctiouten3[1]) |
                           (int_ch_in[2] & ctiouten3[2]) |
                           (int_ch_in[3] & ctiouten3[3]));
  //-------------------------------------------------
  assign  map_trig_out[4] = (
                           (int_ch_in[0] & ctiouten4[0]) |
                           (int_ch_in[1] & ctiouten4[1]) |
                           (int_ch_in[2] & ctiouten4[2]) |
                           (int_ch_in[3] & ctiouten4[3]));
  //-------------------------------------------------
  assign  map_trig_out[5] = (
                           (int_ch_in[0] & ctiouten5[0]) |
                           (int_ch_in[1] & ctiouten5[1]) |
                           (int_ch_in[2] & ctiouten5[2]) |
                           (int_ch_in[3] & ctiouten5[3]));
  //-------------------------------------------------
  assign  map_trig_out[6] = (
                           (int_ch_in[0] & ctiouten6[0]) |
                           (int_ch_in[1] & ctiouten6[1]) |
                           (int_ch_in[2] & ctiouten6[2]) |
                           (int_ch_in[3] & ctiouten6[3]));
  //-------------------------------------------------
  assign  map_trig_out[7] = (
                           (int_ch_in[0] & ctiouten7[0]) |
                           (int_ch_in[1] & ctiouten7[1]) |
                           (int_ch_in[2] & ctiouten7[2]) |
                           (int_ch_in[3] & ctiouten7[3]));

endmodule
