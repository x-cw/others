//-----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2010-2015 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//
//      Checked In          : $Date: 2015-01-12 13:23:39 +0000 (Mon, 12 Jan 2015) $
//
//      Revision            : $Revision: 41056 $
//
//      Release Information : CoreSight-SoC-TM100-r3p2-00rel0
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
//  Purpose             : ATB Master clock domain side FIFO for the CSBRIDGEASYNC
//                        Block. Contains the read-mux for the 4 data bays in the
//                        FIFO.
//-----------------------------------------------------------------------------

module cxatbasyncbridge_mst_fifo_mst
       #( parameter DW =31,
          parameter BW =1,
          parameter FIFO_DATA_WIDTH=41)
 (
  // Inputs
  atclkm,
  atclkenm,
  atresetmn,
  atreadym,
  wrptr_grey_sync,
  flush_done_sync,
  fifo_data_0,
  fifo_data_1,
  fifo_data_2,
  fifo_data_3,
  fifo_data_4,
  fifo_data_5,
  flush_flag_0,
  flush_flag_1,
  flush_flag_2,
  flush_flag_3,
  flush_flag_4,
  flush_flag_5,
  afvalidm,

  // Outputs
  atvalidm,
  atbytesm,
  atidm,
  atdatam,
  afreadym,
  rdptr_grey,
  flush_req,

  zero_pointer
  );

  // Inputs
  input wire                       atclkm;           // ATB Master clock
  input wire                       atclkenm;         // ATB Master clock enable
  input wire                       atresetmn;        // ATB Master clock asychronous reset active low
  input wire                       atreadym;         // ATReady so data can be read from FIFO
  input wire                 [3:0] wrptr_grey_sync;    // Write pointer from the synchronizer
  input wire                       flush_done_sync;    // FlushDone signal from the synchronizer in read clock domain
  input wire                       afvalidm;         // Flush Request from the slave device

  input wire [FIFO_DATA_WIDTH-1:0] fifo_data_0;        // Input all the data registers for use
  input wire [FIFO_DATA_WIDTH-1:0] fifo_data_1;        // in the read mux
  input wire [FIFO_DATA_WIDTH-1:0] fifo_data_2;        // NB 6-deep FIFO used, optimal for 2 clk
  input wire [FIFO_DATA_WIDTH-1:0] fifo_data_3;        // delays synchronising between both domains
  input wire [FIFO_DATA_WIDTH-1:0] fifo_data_4;        //
  input wire [FIFO_DATA_WIDTH-1:0] fifo_data_5;        //
  input wire                       flush_flag_0;
  input wire                       flush_flag_1;
  input wire                       flush_flag_2;
  input wire                       flush_flag_3;
  input wire                       flush_flag_4;
  input wire                       flush_flag_5;

  // Outputs
  output wire                      atvalidm;         // Valid for output
  output wire               [BW:0] atbytesm;
  output wire                [6:0] atidm;            //
  output wire               [DW:0] atdatam;          // Output the read data values
  output reg                       afreadym;         // Flush Data complete to slave device
  output wire                [3:0] rdptr_grey;        // Read pointer to the write clock domain
  output wire                      flush_req;         // Flush Request
  output wire                      zero_pointer;      // Signal to zero the pointers


  // ------------------------------------------------------------------------
  //
  //                            ATB Master clock domain interface
  //                            =================================
  //
  // ------------------------------------------------------------------------
  //
  //
  // Overview
  // ========
  // Master side of the ATB Asynchronous Bridge.
  // ------------------------------------------------------------------------

  // ------------------------------------------------------------------------
  // Local parameters for FSM encoding
  // ------------------------------------------------------------------------
  localparam CSBA_ST_F_IDLE    = 2'b00;
  localparam CSBA_ST_F_WAIT1   = 2'b01;
  localparam CSBA_ST_F_ASSERT  = 2'b11;
  localparam CSBA_ST_F_WAIT2   = 2'b10;
  localparam CSBA_ST_F_UNDEF   = 2'bXX;

  localparam CSBA_ST_P_IDLE    = 3'b000;
  localparam CSBA_ST_P_FLUSH   = 3'b001;
  localparam CSBA_ST_P_ZERO    = 3'b010;
  localparam CSBA_ST_P_ACK     = 3'b011;
  localparam CSBA_ST_P_RESET   = 3'b100;
  localparam CSBA_ST_P_UNUSED1  = 3'b101;
  localparam CSBA_ST_P_UNUSED2  = 3'b110;
  localparam CSBA_ST_P_UNUSED3  = 3'b111;
  localparam CSBA_ST_P_UNDEF   = 3'bXXX;

  // ------------------------------------------------------------------------
  // Internal wire declartions
  // ------------------------------------------------------------------------
  wire                      rdptr_en;
  wire                      fifo_empty;
  wire                      sample;
  wire                      data_en;
  wire                      fifo_rdata_en;
  wire                      nxt_atvalidm;
  wire                      new_flush;
  wire                      nxt_flush_req;
  wire                      nxt_afreadym;

  wire [3:0]                rdptr_grey_int;
  wire                      flush_req_int;

  // ------------------------------------------------------------------------
  // Internal register declartions
  // ------------------------------------------------------------------------
  reg                       flush_req_cdc_check;

  reg [3:0]                 rdptr_grey_cdc_check;
  reg [3:0]                 nxt_rdptr_grey;
  reg [FIFO_DATA_WIDTH-1:0] fifo_rdata;
  reg                       flush_flag;
  reg [1:0]                 nxt_flush_state;
  reg [1:0]                 flush_state;
  reg                       atvalidm_q;
  reg                       flush_done_q;

  // ------------------------------------------------------------------------
  //
  // Main body of code
  // =================
  //
  // ------------------------------------------------------------------------

  // ------------------------------------------------------------------------
  // Combinational block for driving the fifo_rdata and flush_flag.
  // ------------------------------------------------------------------------
  always @(fifo_data_0 or fifo_data_1 or fifo_data_2 or fifo_data_3
           or fifo_data_4 or fifo_data_5 or flush_flag_0 or flush_flag_1
           or flush_flag_2 or flush_flag_3 or flush_flag_4 or flush_flag_5 or rdptr_grey_int)
    begin : c_fifo_rdata_flush_flag
      case (rdptr_grey_int[3:0])
        4'b0000,
        4'b1111: {flush_flag,fifo_rdata} = {flush_flag_0,fifo_data_0};
        4'b0001,
        4'b1110: {flush_flag,fifo_rdata} = {flush_flag_1,fifo_data_1};
        4'b0011,
        4'b1010: {flush_flag,fifo_rdata} = {flush_flag_2,fifo_data_2};
        4'b0010,
        4'b1011: {flush_flag,fifo_rdata} = {flush_flag_3,fifo_data_3};
        4'b0110,
        4'b1001: {flush_flag,fifo_rdata} = {flush_flag_4,fifo_data_4};
        4'b0111,
        4'b1000: {flush_flag,fifo_rdata} = {flush_flag_5,fifo_data_5};
        4'b0100,
        4'b0101,
        4'b1100,
        4'b1101: {flush_flag,fifo_rdata} = {1'b0,{FIFO_DATA_WIDTH{1'b0}}}; //not used
        default: {flush_flag,fifo_rdata} = {1'bx,{FIFO_DATA_WIDTH{1'bx}}};
      endcase // case
    end // block: c_fifo_rdata_flush_flag

  // ------------------------------------------------------------------------
  // Combinational block for the generation of the fifo_empty.
  // ------------------------------------------------------------------------
  assign fifo_empty = (wrptr_grey_sync == rdptr_grey_int);

  // ------------------------------------------------------------------------
  // Combinational block for the generation of the nxt_rdptr_grey.
  // ------------------------------------------------------------------------
  always @ *
    begin

        case (rdptr_grey_int[3:0])
          4'b0000: nxt_rdptr_grey = 4'b0001;
          4'b0001: nxt_rdptr_grey = 4'b0011;
          4'b0011: nxt_rdptr_grey = 4'b0010;
          4'b0010: nxt_rdptr_grey = 4'b0110;
          4'b0110: nxt_rdptr_grey = 4'b0111;
          4'b0111: nxt_rdptr_grey = 4'b1111;
          4'b1111: nxt_rdptr_grey = 4'b1110;
          4'b1110: nxt_rdptr_grey = 4'b1010;
          4'b1010: nxt_rdptr_grey = 4'b1011;
          4'b1011: nxt_rdptr_grey = 4'b1001;
          4'b1001: nxt_rdptr_grey = 4'b1000;
          4'b1000: nxt_rdptr_grey = 4'b0000;
          4'b0100,
          4'b1100,
          4'b0101,
          4'b1101: nxt_rdptr_grey = 4'b0000; //not used
          default: nxt_rdptr_grey = {4{1'bx}};
        endcase
    end

  // ------------------------------------------------------------------------
  // Assigning the rdptr_en signal.
  // ------------------------------------------------------------------------

  assign rdptr_en = sample & ~fifo_empty & atclkenm;


  // ------------------------------------------------------------------------
  // Sequential block for the generation of the rdptr_grey.
  // ------------------------------------------------------------------------
  always @(posedge atclkm or negedge atresetmn)
    begin : s_rdptrctl
      if (!atresetmn)
         rdptr_grey_cdc_check   <= {4{1'b0}};
      else
        if (rdptr_en)
           rdptr_grey_cdc_check   <= nxt_rdptr_grey;
    end // block: s_rdptrctl

  // ------------------------------------------------------------------------
  // Combinational block for the generation of the new_flush
  // & nxt_flush_req.
  // ------------------------------------------------------------------------
  // Next Flush request on afvalidm or pwrdn_flush only taken when internal signals
  // flush_req and flush_done_sync are reset
  // Flush requests are killed in SAFE state
  // ------------------------------------------------------------------------

  always @(posedge atclkm or negedge atresetmn)
    begin : s_flush_done_q
      if (!atresetmn)
        flush_done_q <= 1'b0;
      else
        flush_done_q <= flush_done_sync;
    end


  assign new_flush = (!flush_req_int & !flush_done_q) ? afvalidm : flush_req_int;
  assign nxt_flush_req = (flush_state == CSBA_ST_F_ASSERT) ? 1'b0 : new_flush;


  // ------------------------------------------------------------------------
  // Sequential block for the generation of the flush_req.
  // ------------------------------------------------------------------------
  always @(posedge atclkm or negedge atresetmn)
    begin : s_flush_req
      if (!atresetmn)
         flush_req_cdc_check   <= 1'b0;
      else
        if (atclkenm)
           flush_req_cdc_check   <= nxt_flush_req;
    end // block: s_flush_req



  //----------------------------------------------------------------------------
  // Flush State Machine
  //----------------------------------------------------------------------------
  // CSBA_ST_F_IDLE   - Waiting for a flush_req and flush_done_q or a flush_req
  //               in SAFE state. Move directly to CSBA_ST_F_ASSERT if all historical
  //               data has been flushed on the master side
  // CSBA_ST_F_WAIT1  - Flush requested has finished on the slave side but waiting
  //               for flushing historical data from FIFO.
  // CSBA_ST_F_ASSERT - Flush has finished in the Master side, afreadym is asserted.
  // CSBA_ST_F_WAIT2  - Waiting for internal signals to reset before returning to
  //               idle state.
  //----------------------------------------------------------------------------

  always@(flush_req_int or flush_done_q or flush_flag or fifo_empty or flush_state or sample)
    begin
      case (flush_state)
        CSBA_ST_F_IDLE   : nxt_flush_state = (flush_req_int & flush_done_q) ? ((((~flush_flag)|(fifo_empty)) & sample) ? CSBA_ST_F_ASSERT :CSBA_ST_F_WAIT1) : CSBA_ST_F_IDLE;
        CSBA_ST_F_WAIT1  : nxt_flush_state = (((~flush_flag)|(fifo_empty)) & sample) ? CSBA_ST_F_ASSERT : CSBA_ST_F_WAIT1;
        CSBA_ST_F_ASSERT : nxt_flush_state = CSBA_ST_F_WAIT2;
        CSBA_ST_F_WAIT2  : nxt_flush_state = flush_done_q ? CSBA_ST_F_WAIT2 : CSBA_ST_F_IDLE;
        default      : nxt_flush_state = CSBA_ST_F_UNDEF;
      endcase // case(flush_state)
    end

  always @(posedge atclkm or negedge atresetmn)
    begin : s_flush_state
      if (!atresetmn)
        flush_state <= CSBA_ST_F_IDLE;
      else if (atclkenm)
        flush_state <= nxt_flush_state;
    end // block: s_flush_state



  //----------------------------------------------------------------------------
  // zero_pointer generation
  //----------------------------------------------------------------------------


  //----------------------------------------------------------------------------
  // mask_flush generation
  //----------------------------------------------------------------------------


  //----------------------------------------------------------------------------
  // afreadym generation
  //----------------------------------------------------------------------------

  assign nxt_afreadym = (nxt_flush_state == CSBA_ST_F_ASSERT);


  always @(posedge atclkm or negedge atresetmn)
    begin : s_afreadym
      if (!atresetmn)
        afreadym <= 1'b1;
      else if (atclkenm)
        afreadym <= nxt_afreadym;
    end // block: s_afreadym

  //----------------------------------------------------------------------------
  // Asynchronous Bridge Master Side Ouputs - atvalidm,atbytesm,atidm,atdatam
  //----------------------------------------------------------------------------

  assign sample = ~atvalidm_q | atreadym;

  assign data_en = sample & atclkenm;


  assign nxt_atvalidm = ~(fifo_empty);


  assign fifo_rdata_en = data_en & nxt_atvalidm;

  always @(posedge atclkm or negedge atresetmn)
   begin
     if (!atresetmn)
        atvalidm_q <= 1'b0;
     else if (data_en)
        atvalidm_q <= nxt_atvalidm;
   end

  assign atvalidm = atvalidm_q;

  cxatbasyncbridge_dff #(BW+1) u_atbytes
      (
      // Outputs
      .dout       (atbytesm[BW:0]),
      // Inputs
      .clk        (atclkm),
      .clken      (fifo_rdata_en),
      .nreset     (atresetmn),
      .din        (fifo_rdata[DW+BW+8:DW+8]));


  cxatbasyncbridge_dff #(7) u_atid
      (
      // Outputs
      .dout       (atidm[6:0]),
      // Inputs
      .clk        (atclkm),
      .clken      (fifo_rdata_en),
      .nreset     (atresetmn),
      .din        (fifo_rdata[DW+7:DW+1]));

  cxatbasyncbridge_dff #(DW+1) u_atdata
      (
      // Outputs
      .dout       (atdatam[DW:0]),
      // Inputs
      .clk        (atclkm),
      .clken      (fifo_rdata_en),
      .nreset     (atresetmn),
      .din        (fifo_rdata[DW:0]));


       assign flush_req = flush_req_cdc_check;
       assign flush_req_int = flush_req_cdc_check;
       assign rdptr_grey_int = rdptr_grey_cdc_check;
       assign rdptr_grey = rdptr_grey_cdc_check;


        assign zero_pointer = 1'b0;



//------------------------------------------------------------------------------
// OVL Assertions
//------------------------------------------------------------------------------

  `ifdef ARM_ASSERT_ON

  `ifndef ARM_CDC_ON
  //----------------------------------------------------------------------------
  // OVL_ASSERT: Check if wrptr_grey_sync doesn't go to illegal values
  //----------------------------------------------------------------------------
  assert_never #(`OVL_FATAL, `OVL_ASSERT, "Illegal synchronized write pointer gray value")
    ovl_wrptr_grey_sync_illegal
      (
        .clk       (atclkm),
        .reset_n   (atresetmn),
        .test_expr ((wrptr_grey_sync == 4'b0100)|(wrptr_grey_sync == 4'b0101)|(wrptr_grey_sync == 4'b1100)|(wrptr_grey_sync == 4'b1101))
      );

  //----------------------------------------------------------------------------
  // OVL_ASSERT: Check if rdptr_grey doesn't go to illegal values
  //----------------------------------------------------------------------------
  assert_never #(`OVL_FATAL, `OVL_ASSERT, "Illegal read pointer gray value")
    ovl_rdptr_grey_illegal
      (
        .clk       (atclkm),
        .reset_n   (atresetmn),
        .test_expr ((rdptr_grey_int == 4'b0100)|(rdptr_grey_int == 4'b0101)|(rdptr_grey_int == 4'b1100)|(rdptr_grey_int == 4'b1101))
      );

  //----------------------------------------------------------------------------
  // OVL_ASSERT: Check if wrptr_grey  follows grey encoding
  //----------------------------------------------------------------------------

  wire [3:0] rd_ptr_grey_check;
  assign rd_ptr_grey_check = rdptr_grey_int ^ nxt_rdptr_grey;

  assert_never #(`OVL_FATAL, `OVL_ASSERT, "More than one bit changed in read pointer gray value")
    ovl_rdptr_grey_code
      (
        .clk       (atclkm),
        .reset_n   (atresetmn),
        .test_expr ((rd_ptr_grey_check != 4'b0001)&(rd_ptr_grey_check != 4'b0010)&(rd_ptr_grey_check != 4'b0100)&(rd_ptr_grey_check != 4'b1000)& ~zero_pointer)
      );



  `endif

`endif // `ifdef ARM_ASSERT_ON
endmodule // cxatbasync_mst_fifo
