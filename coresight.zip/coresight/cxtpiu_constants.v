//-----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2004-2015 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//    Checked In : $Date: 2015-03-02 13:34:47 +0000 (Mon, 02 Mar 2015) $
//    Revision   : $Revision: 41785 $
//    Release    : CoreSight-SoC-TM100-r3p2-00rel0
//-----------------------------------------------------------------------------
//  Purpose             : All definitions for the TPIU Block.
//                        Address Offsets + Static Read Values
//
// NONE OF THE FOLLOWING DEFINES CAN BE MODIFIED
// --=========================================================================--

// -----------------------------------------------------------------------------
// TPIU Register Address Offsets
// -----------------------------------------------------------------------------
// NOT USER MODIFIED
localparam CXTPIU_SUPPORTSIZE_ADD = 10'h000;    // Supported port size reg    (0x000)
localparam CXTPIU_CURPORTSIZE_ADD = 10'h001;    // Current port size reg      (0x004)
localparam CXTPIU_SUPTRIG_ADD     = 10'h040;    // Supported Trig Count reg   (0x100)
localparam CXTPIU_TRIGCNT_ADD     = 10'h041;    // Trigger Counter Value reg  (0x104)
localparam CXTPIU_TRIGMUL_ADD     = 10'h042;    // Trig Count Multiplier reg  (0x108)
localparam CXTPIU_SUPTEST_ADD     = 10'h080;    // Supported test mode reg    (0x200)
localparam CXTPIU_CURTEST_ADD     = 10'h081;    // Current test mode reg      (0x204)
localparam CXTPIU_TESTREP_ADD     = 10'h082;    // Test pattern repeat reg    (0x208)
localparam CXTPIU_FORMSTAT_ADD    = 10'h0C0;    // Formatter&Flush status reg (0x300)
localparam CXTPIU_FFCR_ADD        = 10'h0C1;    // Formatter&Flush control reg(0x304)
localparam CXTPIU_FORMSYNC_ADD    = 10'h0C2;    // Formatter sync reg         (0x308)
localparam CXTPIU_EXTCTLIN_ADD    = 10'h100;    // EXTCTL in port reg         (0x400)
localparam CXTPIU_EXTCTLOUT_ADD   = 10'h101;    // EXTCTL out port reg        (0x404)
localparam CXTPIU_ITTRFLINACK_ADD = 10'h3B9;    // Integration FLUSH/TRIGINACK(0xEE4)
localparam CXTPIU_ITTRFLIN_ADD    = 10'h3BA;    // Integration FLUSHIN/TRIGIN (0xEE8)
localparam CXTPIU_ITATBDATA0_ADD  = 10'h3BB;    // Integration ATDATAS        (0xEEC)
localparam CXTPIU_ITATBCTR2_ADD   = 10'h3BC;    // Integration AFVALID/ATREADY(0xEF0)
localparam CXTPIU_ITATBCTR1_ADD   = 10'h3BD;    // Integration ATIDS          (0xEF4)
localparam CXTPIU_ITATBCTR0_ADD   = 10'h3BE;    // Integration ATBYTES/ATV/AFR(0xEF8)

// -----------------------------------------------------------------------------
// TPIU Register Values
// -----------------------------------------------------------------------------
// NOT USER MODIFIED
localparam CXTPIU_SUPPORTSIZE_VAL = {32{1'b1}};   // Supported port size value
localparam CXTPIU_SUPTEST_VAL     = 20'h3000f;    // Supported test mode value
localparam CXTPIU_SUPTRIG_VAL     = 9'b100011111; // Supported Trig Count value
localparam CXTPIU_TRACECTL_VAL    = 1'b1;         // Trace control present

// ----------------------------------------------------------------------------
// CoreSight Management Register Address Offsets
// ----------------------------------------------------------------------------
// NOT USER MODIFIED

localparam CXTPIU_ITCTRL_ADD      = 10'h3C0;    // Integration Mode Ctrl reg (0xF00)
localparam CXTPIU_CLAIMSET_ADD    = 10'h3E8;    // Claim Tag Bit Set reg     (0xFA0)
localparam CXTPIU_CLAIMCLR_ADD    = 10'h3E9;    // Claim Tag Bit Clear reg   (0xFA4)
localparam CXTPIU_LOCKACCESS_ADD  = 10'h3EC;    // Lock Access reg           (0xFB0)
localparam CXTPIU_LOCKSTATUS_ADD  = 10'h3ED;    // Lock Status reg           (0xFB4)
localparam CXTPIU_AUTHSTATUS_ADD  = 10'h3EE;    // Authentication Status reg (0xFB8)
localparam CXTPIU_DEVID_ADD       = 10'h3F2;    // Device ID reg             (0xFC8)
localparam CXTPIU_DEVTYPE_ADD     = 10'h3F3;    // Device Type reg           (0xFCC)
localparam CXTPIU_PERIPHID4_ADD   = 10'h3F4;    // Peripheral ID4 reg        (0xFD0)
localparam CXTPIU_PERIPHID0_ADD   = 10'h3F8;    // Peripheral ID0 reg        (0xFE0)
localparam CXTPIU_PERIPHID1_ADD   = 10'h3F9;    // Peripheral ID1 reg        (0xFE4)
localparam CXTPIU_PERIPHID2_ADD   = 10'h3FA;    // Peripheral ID2 reg        (0xFE8)
localparam CXTPIU_PERIPHID3_ADD   = 10'h3FB;    // Peripheral ID3 reg        (0xFEC)
localparam CXTPIU_COMPONID0_ADD   = 10'h3FC;    // Component ID0 reg         (0xFF0)
localparam CXTPIU_COMPONID1_ADD   = 10'h3FD;    // Component ID1 reg         (0xFF4)
localparam CXTPIU_COMPONID2_ADD   = 10'h3FE;    // Component ID2 reg         (0xFF8)
localparam CXTPIU_COMPONID3_ADD   = 10'h3FF;    // Component ID3 reg         (0xFFC)

// ----------------------------------------------------------------------------
// CoreSight Management Register Values
// ----------------------------------------------------------------------------
// NOT USER MODIFIED

localparam CXTPIU_CLAIMSET_VAL    = 4'hf;         // Claim Tag Set/Size
localparam CXTPIU_LOCKSTATUS_PRESENT_VAL = 1'b1;  // - Lock Access Present
localparam CXTPIU_LOCKSTATUS_8BIT_VAL    = 1'b0;  // - Lock Access 8-bit
localparam CXTPIU_DEVID_VAL       = 32'h000000A0; // Device ID reg
localparam CXTPIU_DEVTYPE_VAL     = 8'h11;        // Device Type reg
localparam CXTPIU_PERIPHID4_VAL   = 8'h04;        // Peripheral ID4 reg
localparam CXTPIU_PERIPHID0_VAL   = 8'h12;        // Peripheral ID0 reg
localparam CXTPIU_PERIPHID1_VAL   = 8'hB9;        // Peripheral ID1 reg
localparam CXTPIU_PERIPHID2_VAL   = 8'h5B;        // Peripheral ID2 reg
localparam CXTPIU_PERIPHID3_CUSTOM_VAL  = 4'h0;   // Peripheral ID3 reg [3:0]
localparam CXTPIU_PERIPHID3_REVAND_VAL  = 4'h0;   // Peripheral ID3 reg [7:4]
localparam CXTPIU_COMPONID0_VAL   = 8'h0D;        // Component ID0 reg
localparam CXTPIU_COMPONID1_VAL   = 8'h90;        // Component ID1 reg (CS Class)
localparam CXTPIU_COMPONID2_VAL   = 8'h05;        // Component ID2 reg
localparam CXTPIU_COMPONID3_VAL   = 8'hB1;        // Component ID3 reg

// ----------------------------------------------------------------------------
// Serialiser Reset FSM State encodings
// ----------------------------------------------------------------------------
// NOT USER MODIFIED
localparam CXTPIU_FTSTOP_IDLE   = 2'b00;
localparam CXTPIU_FTSTOP_RPEND  = 2'b01;
localparam CXTPIU_FTSTOP_RHOLD  = 2'b10;
localparam CXTPIU_FTSTOP_UNUSED = 2'b11;
