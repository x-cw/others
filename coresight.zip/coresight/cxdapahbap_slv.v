//------------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2003-2013 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//    Checked In : $Date: 2013-09-06 16:05:05 +0100 (Fri, 06 Sep 2013) $
//    Revision   : $Revision: 37058 $
//    Release    : CoreSight-SoC-TM100-r3p1-00rel0
//------------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// Abstract : Debug Access Port AHB Access Port (DAPAHBAP)- DAP Slave Interface
//------------------------------------------------------------------------------
//
// DAPAHBAP - Debug Access Port AHB Access Port
// --------------------------------------------
//
// Debug Access Port AHB Access Port component provides an AHB-Lite interface to
// a System On Chip (SOC).
//
// cxdapahbap_slv.v
// -------------
//
// cxdapahbap_slv.v provides the DAP slave interface for the DAPAHBAP block.
//
// Instantiated blocks
// -------------------
// None.
//------------------------------------------------------------------------------
`include "cxdapahbap_constants.v"

module cxdapahbap_slv (
  // Inputs
  dapclk, dapclken, dapresetn, dapsel, dapenable, dapwrite, dapabort,
  dapaddr, dapwdata, ahb_err_resp, ahb_state_sync, ahb_rom_addr, ahb_rd_data, dbgen_sync,
  spid_en_sync,
  // Outputs
  dapready, dapslverr, daprdata, ahb_rd_wr, ahb_inc_pack, ahb_size,
  dap_state, ahb_prot_bit6, ahb_prot_bits4to0, ahb_addr, ahb_wr_data
  );

  //----------------------------------------------------------------------------
  // Inputs
  //----------------------------------------------------------------------------
  input         dapclk;           // DAP clock
  input         dapclken;         // DAP clock enable
  input         dapresetn;        // DAP asynchrnous reset active low

  input         dapsel;           // DAP select
  input         dapenable;        // DAP enable
  input         dapwrite;         // DAP write or read
  input         dapabort;         // DAP abort
  input   [7:2] dapaddr;          // DAP address bus
  input  [31:0] dapwdata;         // DAP write data bus

  input         ahb_err_resp;     // AHB interface error response
  input   [2:0] ahb_state_sync;   // AHB interface state (Synchronized)
  input  [31:0] ahb_rd_data;      // AHB interface read data bus
  input  [31:0] ahb_rom_addr;     // AHB ROM base address tie-off

  input         dbgen_sync;       // Debug enable (Synchronized)
  input         spid_en_sync;     // TrustZone enable (Synchronized)

  //----------------------------------------------------------------------------
  // Outputs
  //----------------------------------------------------------------------------
  output        dapready;         // DAP slave ready
  output        dapslverr;        // DAP slave error
  output [31:0] daprdata;         // DAP read data bus

  output        ahb_rd_wr;        // Read or write transfer to AHB interface
  output        ahb_inc_pack;     // Increment packed transfer to AHB interface
  output [1:0]  ahb_size;         // Transfer size to AHB interface
  output [3:0]  dap_state;        // DAP interface state to AHB interface
  output        ahb_prot_bit6;    // ahb_prot[6] - Protection control to AHB interface
  output [4:0]  ahb_prot_bits4to0;// Protection control to AHB interface
  output [31:0] ahb_addr;         // Address bus to the AHB interface
  output [31:0] ahb_wr_data;      // Write data bus to AHB interface

  //----------------------------------------------------------------------------
  // Wires
  //----------------------------------------------------------------------------
  wire          tr_abort;
  wire          ahb_tr_in_prog_en;

  wire          csw_sel;
  wire          ta_sel;
  wire          id_sel;
  wire          bd_sel;
  wire          bd_0_sel;
  wire          bd_1_sel;
  wire          bd_2_sel;
  wire          bd_3_sel;
  wire          drw_sel;
  wire          rom_sel;

  wire          ap_select;
  wire          reg_access;
  wire          ahb_access;
  wire          trig_sm;
  wire          ahb_inc_pack;
  wire          s_prot;
  wire          ahb_tr_req;
  wire          ahb_tr_done;
  wire [1:0]    addr_inc;
  wire [1:0]    ahb_size;
  wire [1:0]    ahb_size_int;
  wire [4:0]    prot;

  wire          ta_wr_en;
  wire          soc_rst;
  wire          bd_wr_en;
  wire          bd_access_en;
  wire          csw_sw_wr_en;
  wire          csw_sw_rd_en;
  wire          ta_sw_wr_en;
  wire          ta_sw_rd_en;
  wire          rom_sw_rd_en;
  wire          id_sw_rd_en;
  wire          ahb_sw_rd_en;
  wire          auto_inc_en;
  wire          sing_inc_en;
  wire          pack_inc_en;
  wire          ahb_ctl_en;
  wire          pack_inc_tr;
  wire          ahb_pack_tr;
  wire          ahb_word_tr;
  wire          pack_inc_done;
  wire          non_word_pack_en;
  wire          next_dap_slv_err;
  wire          dapabort_reg_en;

  wire [31:0]   next_ta_reg;
  wire [31:0]   csw_rd_data;
  wire [31:0]   ta_rd_data;
  wire [31:0]   id_rd_data;
  wire [31:0]   rom_rd_data;
  wire [31:0]   next_dap_rd_data;

  wire          ahb_sample_en;

  //----------------------------------------------------------------------------
  // Registers
  //----------------------------------------------------------------------------
  reg           dapready;
  reg           dapslverr;
  reg  [31:0]   daprdata;

  reg           next_dap_ready;
  wire          ahb_rd_wr;
  reg           ahb_rd_wr_cdc_check;
  reg           ahb_tr_in_prog;
  wire          bd_access;
  reg           bd_access_cdc_check;
  reg           dapabort_reg;
  reg  [1:0]    next_pack_ctr;
  reg  [1:0]    pack_ctr;
  wire [1:0]    bd_reg;
  reg  [1:0]    bd_reg_cdc_check;
  reg  [3:0]    cur_state;
  reg  [3:0]    next_state;
  reg  [2:0]    addr_inc_size;
  reg  [3:0]    next_dap_state;
  wire [3:0]    dap_state;
  reg  [3:0]    dapstate_cdc_check;
  wire [9:0]    csw_reg;
  reg  [9:0]    csw_reg_cdc_check;
  wire [31:0]   ta_reg;
  reg  [31:0]   ta_reg_cdc_check;
  wire [31:0]   ahb_wr_data;
  reg  [31:0]   ahb_wr_data_cdc_check;
  wire          ahb_spiden;
  reg           ahb_spiden_cdc_check;

  reg  [31:0]   ahb_rd_data_s;
  reg           ahb_err_resp_s;

  //----------------------------------------------------------------------------
  //
  // Main body of code
  // =================
  //
  //----------------------------------------------------------------------------

  //----------------------------------------------------------------------------
  // NOTE :- All the bits of AHB state are double synchronized from the hclk
  //         domain into the dapclk domain.Gray coding is not used for AHB state
  //         before synchronization because the AHB state need not transit in a
  //         linear manner.This is to say,the AHB state need not transit from
  //         state 2'b00 to 2'b01.It can also transit from state 2'b00 to 2'b10.
  //         This rules out usage of Gray coding.Hence the DAP slave interface
  //         state machine shall change its state only when the AHB state is one
  //         hot encoded.This takes care of the synchronization issues.
  //----------------------------------------------------------------------------

  //----------------------------------------------------------------------------
  // The ap_select is set for one clock period of dapclk.This signal indicates
  // that the AHB-AP block is selected for transactions.
  //----------------------------------------------------------------------------
  assign ap_select = dapsel & ~dapenable;

  //----------------------------------------------------------------------------
  // Comparators for address increment and AHB transfer size fields.
  //----------------------------------------------------------------------------
  assign ahb_pack_tr = (addr_inc == `INC_PACKED);
  assign ahb_word_tr = (ahb_size_int[1:0] == `AHBAP_WORD);

  //----------------------------------------------------------------------------
  // The csw_sel,ta_sel,bd_0_sel,bd_1_sel,bd_2_sel,bd_3_sel,drw_sel id_sel and rom_sel are
  // the select signals for selecting the control status word,transfer address,
  // banked data0,banked data1,banked data2,banked data3,data read write
  // identification and ROM address registers respectively.
  //----------------------------------------------------------------------------
  assign csw_sel  = (dapaddr[7:2] == `CSWREG);
  assign ta_sel   = (dapaddr[7:2] == `TAREG);
  assign bd_0_sel = (dapaddr[7:2] == `BD0REG);
  assign bd_1_sel = (dapaddr[7:2] == `BD1REG);
  assign bd_2_sel = (dapaddr[7:2] == `BD2REG);
  assign bd_3_sel = (dapaddr[7:2] == `BD3REG);
  assign drw_sel  = (dapaddr[7:2] == `DRWREG);
  assign id_sel   = (dapaddr[7:2] == `IDREG);
  assign rom_sel  = (dapaddr[7:2] == `ROMREG);

  //----------------------------------------------------------------------------
  // bd_sel indicates that the register accesses is to one of the banked data
  // registers.
  //----------------------------------------------------------------------------
  assign bd_sel = bd_0_sel | bd_1_sel | bd_2_sel | bd_3_sel;

  //----------------------------------------------------------------------------
  // The AHB-AP register read and write transactions can either be to the
  // registers within the AHB-AP block or can be in the registers residing
  // in the hclk domain outside the AHB-AP block.So the register read and
  // write transactions are classified into two sets of accesses.Firstly,
  // reg_access is the enable signal for the registers residing in the AHB-AP
  // block and secondly the ahb_access is the enable signal for the registers
  // residing outside the AHB-AP block.The reg_access is for the control status
  // word,transfer address and identification registers.The ahb_access is for
  // the banked data and data read write registers.
  //----------------------------------------------------------------------------
  assign reg_access = csw_sel | ta_sel  | id_sel  | rom_sel;
  assign ahb_access = drw_sel | bd_sel;

  //----------------------------------------------------------------------------
  // The csw_sw_wr_en and csw_sw_rd_en signals are the enable signals for writing and
  // reading respectively from the control status word register.The writes to
  // the control register are ignored if the ahb_tr_in_prog is set.
  //----------------------------------------------------------------------------
  assign csw_sw_wr_en = csw_sel & ap_select & dapwrite & ~ahb_tr_in_prog & dapclken;
  assign csw_sw_rd_en = csw_sel & ap_select & ~dapwrite;

  //----------------------------------------------------------------------------
  // Sequential block for writing into the control status word register.
  // Control Status Word Register : Offset 0x00 ( R/W )
  //----------------------------------------------------------------------------
  always @ (posedge dapclk or negedge dapresetn)
    begin : p_cswreg
      if (!dapresetn)
         csw_reg_cdc_check  <= `CSW_RESET;
      else
        if (csw_sw_wr_en)
          begin
             csw_reg_cdc_check[9]    <= dapwdata[30];
             csw_reg_cdc_check[8:4]  <= dapwdata[28:24];
             csw_reg_cdc_check[3:2]  <= dapwdata[5:4];
             csw_reg_cdc_check[1:0]  <= dapwdata[1:0];
          end
    end // block: p_cswreg

  //----------------------------------------------------------------------------
  // Logic for driving the read data from the control status word register.Not
  // all the bits are writeable by the software.The bits which are read only
  // are driven along with the writeable fields onto the read data.
  //----------------------------------------------------------------------------
  assign s_prot       = csw_reg[9];
  assign prot         = csw_reg[8:4];
  assign addr_inc     = csw_reg[3:2];
  assign ahb_size_int = csw_reg[1:0];
  assign ahb_size     = ahb_size_int;
  assign csw_rd_data  = {1'b0,s_prot,1'b0, prot,spid_en_sync,{15{1'b0}},
                         ahb_tr_in_prog,dbgen_sync,addr_inc,2'b00,ahb_size_int};

  //----------------------------------------------------------------------------
  // The ta_sw_wr_en and ta_sw_rd_en signals are the enable signals for writing and
  // reading respectively from the transfer address register.The software writes
  // to the transfer address register are ignored if the ahb_tr_in_prog is set.
  //----------------------------------------------------------------------------
  assign ta_sw_wr_en = ta_sel & ap_select & dapwrite & ~ahb_tr_in_prog;
  assign ta_sw_rd_en = ta_sel & ap_select & ~dapwrite;

  //----------------------------------------------------------------------------
  // Logic for the next_ta_reg.When the software selects the transfer address
  // register for performing a write transaction,the write data present on the
  // dapwdata is written into this register.Otherwise the value in this register
  // is incremented by ahb_size if the auto increment on in the control status
  // register is enabled.
  //----------------------------------------------------------------------------
  assign next_ta_reg[31:10] = ta_sw_wr_en ? dapwdata[31:10] : ta_reg[31:10];
  assign next_ta_reg[9:0]   = ta_sw_wr_en ? dapwdata[9:0]   : ta_reg[9:0] +
                                                       {{7{1'b0}},addr_inc_size};

  //----------------------------------------------------------------------------
  // The pack_inc_en signal is used for incrementing the address in the case of
  // packed transfers.The packed transfers are performed only on the data read
  // write register.
  //----------------------------------------------------------------------------
  assign pack_inc_en = ahb_tr_done & ahb_pack_tr & drw_sel;

  //----------------------------------------------------------------------------
  // The sing_inc_en signal is used for incrementing the address in the case of
  // single transfers.The single incrementing operation is performed only on the
  // data read write register.
  //----------------------------------------------------------------------------
  assign sing_inc_en = ahb_tr_done & (addr_inc == `INC_SINGLE) & drw_sel;

  //----------------------------------------------------------------------------
  // The auto_inc_en signal is used for incrementing the address in the transfer
  // address register.The address is only incremented if the transaction is
  // either a packed or a single transaction and if the current transaction
  // completes without an error response and the current transfer is not
  // aborted.
  //----------------------------------------------------------------------------
  assign auto_inc_en = (pack_inc_en | sing_inc_en) & ~(ahb_err_resp_s | tr_abort);

  //----------------------------------------------------------------------------
  // The ta_wr_en is the enable signal for writing into the transfer address
  // register.The register is updated by both software and hardware.The ta_sw_wr_en
  // and auto_inc_en are enable signals for software and hardware respectively.
  //----------------------------------------------------------------------------
  assign ta_wr_en = (ta_sw_wr_en | auto_inc_en) & dapclken;

  //----------------------------------------------------------------------------
  // Sequential block for writing into the transfer address register.
  // Transfer Address Register : Offset 0x04 ( R/W )
  //----------------------------------------------------------------------------
  always @ (posedge dapclk or negedge dapresetn)
    begin : p_tareg
      if (!dapresetn)
         ta_reg_cdc_check  <= {32{1'b0}};
      else
        if (ta_wr_en)
           ta_reg_cdc_check  <= next_ta_reg;
    end

  //----------------------------------------------------------------------------
  // The ta_rd_data is driven from the ta_reg.
  //----------------------------------------------------------------------------
  assign ta_rd_data = ta_reg;

  //----------------------------------------------------------------------------
  // Debug APB ROM Address Register : Offset 0xF8 ( R )
  //----------------------------------------------------------------------------
  assign rom_rd_data = ahb_rom_addr | 32'h00000002; // Bit 1 should always be set
  assign rom_sw_rd_en = rom_sel & ap_select & ~dapwrite;

  //----------------------------------------------------------------------------
  // Identification Register : Offset 0xFC ( R )
  //----------------------------------------------------------------------------
  assign id_rd_data = `ID_REG_AHBAP;
  assign id_sw_rd_en = id_sel & ap_select & ~dapwrite;

  //----------------------------------------------------------------------------
  // Logic for ahb_tr_req signal.This is generated for one clock cycle of the
  // dapclk to indicate that the DAP interface has requested for a transfer on
  // the AHB interface.
  //----------------------------------------------------------------------------
  assign ahb_tr_req = (cur_state == `ST_DAP_IDLE) & (next_state == `ST_DAP_AHB);

  //----------------------------------------------------------------------------
  // Logic for ahb_tr_done signal.This is generated for one clock cycle of the
  // dapclk to indicate the DAP interface that the transfer on the AHB interface
  // has completed.
  //----------------------------------------------------------------------------
  assign ahb_tr_done = (cur_state == `ST_DAP_RDY2) & (cur_state != next_state) &
                     (ahb_state_sync == `ST_AHBIF_RDY);

  //----------------------------------------------------------------------------
  // Logic for ahb_tr_in_prog_en signal.ahb_tr_in_prog_en is the enable signal for
  // latching ahb_tr_in_prog.The ahb_tr_in_prog is set when the DAP interface receives
  // a request for an AHB transfer.This signal is reset when the AHB interface
  // completes the AHB transaction or when the AHB interface gets reset.
  //----------------------------------------------------------------------------
  assign ahb_tr_in_prog_en = (ahb_tr_req | (ahb_tr_done & (next_state == `ST_DAP_RDY)) |
                          soc_rst)  & dapclken;

  //----------------------------------------------------------------------------
  // Sequential block for latching the ahb_tr_in_prog.
  //----------------------------------------------------------------------------
  always @ (posedge dapclk or negedge dapresetn)
    begin : p_ahbtrinprog
      if (!dapresetn)
        ahb_tr_in_prog <= 1'b0;
      else
        if (ahb_tr_in_prog_en)
          ahb_tr_in_prog <= ahb_tr_req;
    end

  //----------------------------------------------------------------------------
  // The ahb_inc_pack signal indicates the current AHB transaction is an non word
  // incrment packed transaction.A word transaction for packed and non-packed
  // transfer is one and the same.
  //----------------------------------------------------------------------------
  assign ahb_inc_pack = ahb_pack_tr & ~ahb_word_tr;

  //----------------------------------------------------------------------------
  // The ahb_sw_rd_en is the enable signal for reading from the AHB interface.
  //----------------------------------------------------------------------------
  assign ahb_sw_rd_en = ahb_access & ahb_tr_done;

  //----------------------------------------------------------------------------
  // The soc_rst signal indicates that the AHB interface is currently in reset
  // state.
  //----------------------------------------------------------------------------
  assign soc_rst = (ahb_state_sync == `ST_AHBIF_INIT);

  //----------------------------------------------------------------------------
  // Logic for the generation trig_sm.trig_sm is the pulse which triggers the DAP
  // interface state machine.The state machine shall get triggered for register
  // accesses within the AHB-AP block as well as the register accesses on the
  // AHB system side.The register read accesses within the AHB-AP block are
  // always allowed.All other accesses are only allowed if the ahb_tr_in_prog bit
  // is not set.All other accesses include register writes within the AHB-AP
  // block and register accesses on the AHB system side.The AHB-AP shall ignore
  // all these accesses if the ahb_tr_in_prog bit is set.The state machine shall
  // also not get triggered if the AHB interface is reset or is powered down.
  //----------------------------------------------------------------------------
  assign trig_sm = ((reg_access    & ((dapwrite & ~ahb_tr_in_prog)  | ~dapwrite)) |
                   (ahb_access    & dbgen_sync  & ~soc_rst        &
                   (~ahb_tr_in_prog & (s_prot     | spid_en_sync)))) & ap_select;

  //----------------------------------------------------------------------------
  // Logic for the DAP slave interface state machine.
  //----------------------------------------------------------------------------
  // ST_DAP_RST  : Reset state for the state machine.Moves out of this stae to
  //               ST_DAP_IDLE when the AHB interface is reset or ready.Other
  //               wise will remain in this state till the AHB interface is
  //               reset or ready.
  // ST_DAP_IDLE : Idle state for the state machine.This state indicates that
  //               DAP interface is ready to perform transactions.Moves out of
  //               this state to either ST_DAP_REG or ST_DAP_AHB state to
  //               perform register and AHB transactions respectively.
  // ST_DAP_REG  : AHB-AP block register transaction state for the state
  //               machine.Moves out of this state to ST_DAP_IDLE as the
  //               register transactions are serviced within zero wait states.
  // ST_DAP_AHB  : AHB transaction initiate state for the state machine.Moves
  //               out of this state to ST_DAP_WAIT state.
  // ST_DAP_WAIT : AHB transaction completion state for the state machine.Waits
  //               in this state till the transaction completes on the AHB side
  //               or a reset occurs on the AHB side.Moves out of this state to
  //               ST_DAP_RDY in the case of non packed transactions and packed
  //               word transactions.In the case of packed non word transfers
  //               the state moves to ST_DAP_PACK.
  // ST_DAP_PACK : packed transfer state for the state machine.Enters this state
  //               from ST_DAP_WAIT state in case of a non word packed transfer.
  //               Moves out of this state to the ST_DAP_AHB state to initiate
  //               another transaction.In the case of an abort,the state moves
  //               to ST_DAP_RDY.
  // ST_DAP_RDY1 : Ready state for the state machine.ST_DAP_RDY1 and ST_DAP_RDY2
  // ST_DAP_RDY2 : introduces two clock delays in the dapclk domain before
  //               driving the dapready.This is to take care of the scenario
  //               where the hclk domain is powered down or reset.In the case
  //               of the read transcations from the AHB interface,if the AHB
  //               interface is powered down or reset,the read data on the AHB
  //               interface is no more valid,and as the dapclk domain shall
  //               change its state based on the AHB interface state after two
  //               clock cycles of the dapclk due to double synchronization,the
  //               dapclk domain shall wait for two more clock cycles to ensure
  //               that the AHB interface is not powered down or reset while
  //               driving dapready and daprdata.
  // ST_DAP_RDY  : Ready state for the state machine.Moves to ST_DAP_IDLE from
  //               this state.
  //----------------------------------------------------------------------------
  always @(ahb_access or ahb_err_resp_s or ahb_state_sync
           or cur_state or non_word_pack_en or reg_access or trig_sm)
    begin : p_nextstate
      case(cur_state)
        `ST_DAP_RST  :
          case(ahb_state_sync)
            3'b001,
            3'b010 : next_state = `ST_DAP_IDLE;
            3'b000,
            3'b011,
            3'b100,
            3'b101,
            3'b110,
            3'b111  : next_state = `ST_DAP_RST;
            default : next_state = `ST_DAP_UNDEF;
          endcase // case(ahb_state_sync)
        `ST_DAP_IDLE :
          case(ahb_state_sync)
            3'b000,
            3'b001,
            3'b011,
            3'b100,
            3'b101,
            3'b110,
            3'b111  :
              begin
                case(reg_access)
                  1'b0    : next_state = `ST_DAP_IDLE;
                  1'b1    : next_state = trig_sm ? `ST_DAP_REG : `ST_DAP_IDLE;
                  default : next_state = `ST_DAP_UNDEF;
                endcase // case(reg_access)
              end
            3'b010  :
              begin
                case({reg_access,ahb_access})
                  2'b00   : next_state = `ST_DAP_IDLE;
                  2'b01   : next_state = trig_sm ? `ST_DAP_AHB : `ST_DAP_IDLE;
                  2'b10   : next_state = trig_sm ? `ST_DAP_REG : `ST_DAP_IDLE;
                  2'b11   : next_state = `ST_DAP_UNDEF;
                  default : next_state = `ST_DAP_UNDEF;
                endcase // case({reg_access,ahb_access})
              end
            default : next_state = `ST_DAP_UNDEF;
          endcase // case(ahb_state_sync)
        `ST_DAP_REG  : next_state = `ST_DAP_IDLE;
        `ST_DAP_AHB  :
          case(ahb_state_sync)
            3'b000,
            3'b010,
            3'b011,
            3'b101,
            3'b110,
            3'b111  : next_state = `ST_DAP_AHB;
            3'b001,
            3'b100  : next_state = `ST_DAP_WAIT;
            default : next_state = `ST_DAP_UNDEF;
          endcase // case(ahb_state_sync)
        `ST_DAP_WAIT :
          case(ahb_state_sync)
            3'b000,
            3'b011,
            3'b100,
            3'b101,
            3'b110,
            3'b111  : next_state = `ST_DAP_WAIT;
            3'b001  : next_state = `ST_DAP_RDY;
            3'b010  : next_state = `ST_DAP_RDY1;
            default : next_state = `ST_DAP_UNDEF;
          endcase // case(ahb_state_sync)
        `ST_DAP_RDY1 : next_state = `ST_DAP_RDY2;
        `ST_DAP_RDY2 :
          begin
            // Go to RDY on: error, not packed (single word) or AHB has been reset (INIT), else go to PACK
            next_state = (ahb_err_resp_s | ~non_word_pack_en | (ahb_state_sync == 3'b001)) ? `ST_DAP_RDY : `ST_DAP_PACK;
          end
        `ST_DAP_RDY  : next_state = `ST_DAP_IDLE;
        `ST_DAP_PACK : next_state = `ST_DAP_AHB;  // start another transaction
        `ST_DAP_UNUSED : next_state = `ST_DAP_UNDEF;
        default      : next_state = `ST_DAP_UNDEF;
      endcase // case(cur_state)
    end // block: p_nextstate

  //----------------------------------------------------------------------------
  // Sequential block for cur_state of the DAP slave interface state machine.
  //----------------------------------------------------------------------------
  always @(posedge dapclk or negedge dapresetn)
    begin : p_curstate
      if (!dapresetn)
        cur_state <= `ST_DAP_RST;
      else
        if(dapclken)
          cur_state <= next_state;
    end

  //----------------------------------------------------------------------------
  // The pack_inc_tr signal indicates a non word packed increment transfer.
  //----------------------------------------------------------------------------
  assign pack_inc_tr = ahb_tr_req & ahb_pack_tr & ~ahb_word_tr;

  //----------------------------------------------------------------------------
  // The pack_inc_done signal is used for indicating a transaction complete for
  // a non word packed transfer.
  //----------------------------------------------------------------------------
  assign pack_inc_done = pack_inc_en & ~ahb_word_tr;

  //----------------------------------------------------------------------------
  // The non_word_pack_en is the enable signal for performing non word packed
  // transfers.They are performed for non word transactions when the increment
  // enable is set in the control status word register.When the pack_ctr is non
  // zero,the DAP slave interface state machine shall initiate packed transfers
  // on the AHB interface.
  //----------------------------------------------------------------------------
  assign non_word_pack_en = (pack_ctr != 2'b00);

  //----------------------------------------------------------------------------
  // Combinational logic for next_pack_ctr.The counter indicates the number of
  // packed transfers to be performed on the AHB side.The number of transfers
  // are two and four for half word and byte transactions respectively.In the
  // case of error response from the AHB interface admist a packed transfer,
  // further transfers on the AHB interface are not initiated.
  //----------------------------------------------------------------------------
  always @(ahb_err_resp_s or ahb_size_int or non_word_pack_en
           or pack_ctr or pack_inc_done or pack_inc_tr or tr_abort)
    begin : p_nextpackctr
      case({pack_inc_done,pack_inc_tr})
        2'b00 : next_pack_ctr = tr_abort ? 2'b00 : pack_ctr;
        2'b01 :
          begin
            case(ahb_size_int[0])
              1'b0    : next_pack_ctr = 2'b11;
              1'b1    : next_pack_ctr = 2'b01;
              default : next_pack_ctr = 2'bxx;
            endcase // case(ahb_size_int[0])
          end
        2'b10 :
          begin
            case(ahb_err_resp_s)
              1'b0    : next_pack_ctr = non_word_pack_en ? pack_ctr - 2'b01 : 2'b00;
              1'b1    : next_pack_ctr = 2'b00;
              default : next_pack_ctr = 2'bxx;
            endcase // case(ahb_err_resp)
          end
        default : next_pack_ctr = 2'bxx;
      endcase // case({pack_inc_done,pack_inc_tr})
    end // block: p_nextpackctr

  //----------------------------------------------------------------------------
  // Sequential block for latching the PckCtr.
  //----------------------------------------------------------------------------
  always @(posedge dapclk or negedge dapresetn)
    begin : p_packctr
      if (!dapresetn)
        pack_ctr <= 2'b00;
      else
        if(dapclken)
          pack_ctr <= next_pack_ctr;
    end

  //----------------------------------------------------------------------------
  // Block to generate the next dap_state one hot encoded output.
  // Although the DAP interface
  // has seven states,ST_DAP_IDLE,ST_DAP_REG and ST_DAP_PACK states appear as
  // ready state to the AHB interface.ST_DAP_WAIT and ST_DAP_RDY appear as
  // hold state to the AHB interface.
  //----------------------------------------------------------------------------
  always @(ahb_access or ahb_state_sync or cur_state
           or reg_access or trig_sm)
    begin : p_nextdapstate
      case(cur_state)
        `ST_DAP_RST  :
          case(ahb_state_sync)
            3'b001,
            3'b010 : next_dap_state = `ST_DAPIF_RDY;
            3'b000,
            3'b011,
            3'b100,
            3'b101,
            3'b110,
            3'b111  : next_dap_state = `ST_DAPIF_INIT;
            default : next_dap_state = `ST_DAPIF_UNDEF;
          endcase // case(ahb_state_sync)
        `ST_DAP_IDLE :
          case(ahb_state_sync)
            3'b000,
            3'b001,
            3'b011,
            3'b100,
            3'b101,
            3'b110,
            3'b111  : next_dap_state = `ST_DAPIF_RDY;
            3'b010  :
              begin
                case({reg_access,ahb_access})
                  2'b00,
                  2'b10   : next_dap_state = `ST_DAPIF_RDY;
                  2'b01   : next_dap_state = trig_sm ? `ST_DAPIF_BSY : `ST_DAPIF_RDY;
                  2'b11   : next_dap_state = `ST_DAPIF_UNDEF;
                  default : next_dap_state = `ST_DAPIF_UNDEF;
                endcase // case({reg_access,ahb_access})
              end
            default : next_dap_state = `ST_DAPIF_UNDEF;
          endcase // case(ahb_state_sync)
        `ST_DAP_REG  : next_dap_state = `ST_DAPIF_RDY;
        `ST_DAP_AHB  :
          case(ahb_state_sync)
            3'b000,
            3'b010,
            3'b011,
            3'b101,
            3'b110,
            3'b111  : next_dap_state = `ST_DAPIF_BSY;
            3'b001,
            3'b100  : next_dap_state = `ST_DAPIF_HOLD;
            default : next_dap_state = `ST_DAPIF_UNDEF;
          endcase // case(ahb_state_sync)
        `ST_DAP_WAIT :
          case(ahb_state_sync)
            3'b000,
            3'b010,
            3'b011,
            3'b100,
            3'b101,
            3'b110,
            3'b111  : next_dap_state = `ST_DAPIF_HOLD;
            3'b001  : next_dap_state = `ST_DAPIF_RDY;
            default : next_dap_state = `ST_DAPIF_UNDEF;
          endcase // case(ahb_state_sync)
        `ST_DAP_RDY1 : next_dap_state = `ST_DAPIF_RDY;
        `ST_DAP_RDY2 : next_dap_state = `ST_DAPIF_RDY;
        `ST_DAP_RDY  : next_dap_state = `ST_DAPIF_RDY;
        `ST_DAP_PACK : next_dap_state = `ST_DAPIF_BSY;
        `ST_DAP_UNUSED : next_dap_state = `ST_DAPIF_UNDEF;
        default      : next_dap_state = `ST_DAPIF_UNDEF;
      endcase // case(cur_state)
    end // block: p_nextdapstate

  //----------------------------------------------------------------------------
  // Sequential block for dap_state of the DAP slave interface state machine.
  //----------------------------------------------------------------------------
  always @(posedge dapclk or negedge dapresetn)
    begin : p_dapstate
      if (!dapresetn)
         dapstate_cdc_check  <= `ST_DAPIF_INIT;
      else if(dapclken)
         dapstate_cdc_check  <= next_dap_state;
    end

  //----------------------------------------------------------------------------
  // Combinational block for driving the next_dap_ready.The next_dap_ready is
  // driven low when the state machine is in the ST_DAP_AHB state.For all the
  // other states of the state machine the next_dap_ready is driven high.
  //----------------------------------------------------------------------------
  always @(next_state or tr_abort)
    begin : p_nextdaprdy
      case(next_state)
        `ST_DAP_RST  : next_dap_ready = 1'b1;
        `ST_DAP_IDLE : next_dap_ready = 1'b1;
        `ST_DAP_REG  : next_dap_ready = 1'b1;
        `ST_DAP_AHB,
        `ST_DAP_PACK,
        `ST_DAP_RDY1,
        `ST_DAP_RDY2,
        `ST_DAP_WAIT :
          case(tr_abort)
            1'b0    : next_dap_ready = 1'b0;
            1'b1    : next_dap_ready = 1'b1;
            default : next_dap_ready = 1'bx;
          endcase // case(tr_abort)
        `ST_DAP_RDY  : next_dap_ready = 1'b1;
        `ST_DAP_UNUSED : next_dap_ready = 1'bx;
        default      : next_dap_ready = 1'bx;
      endcase // case(next_state)
    end // block: p_nextdaprdy

  //----------------------------------------------------------------------------
  // Combinational logic for driving the next_dap_slv_err.The next_dap_slv_err is
  // driven high when an error response occurs on the AHB interface or when the
  // system AHB is powered down or when the ahb_tr_in_prog is high and the DAP
  // interface requests for a write transfer to any register or a read transfer
  // to the data read write register or the banked data registers or when s_prot
  // and spid_en_sync are low and there is an ahb_access.For all the other
  // conditions the next_dap_slv_err is driven low.When the AHB system is powered
  // down,the register accesses within the AHB-AP are still allowed.
  //----------------------------------------------------------------------------
  assign next_dap_slv_err = (ahb_access   & ~dbgen_sync)                           |
                         (ahb_err_resp_s & ahb_tr_done)                            |
                         (ahb_access   & soc_rst)                               |
                         (ahb_access   & dbgen_sync & ~(s_prot | spid_en_sync))    |
                         (((reg_access & dapwrite) | (ahb_access & ~dapabort))  &
                         (ahb_tr_in_prog & ~ahb_tr_done));

  //----------------------------------------------------------------------------
  // The tr_abort indicates the current transaction is aborted.
  //----------------------------------------------------------------------------
  assign tr_abort = (dapabort & ahb_tr_in_prog) | dapabort_reg;

  //----------------------------------------------------------------------------
  // The dapabort_reg_en is the enable signal for dapabort.
  //----------------------------------------------------------------------------
  assign dapabort_reg_en = ((ahb_tr_in_prog & dapabort) | ahb_tr_done) & dapclken;

  //----------------------------------------------------------------------------
  // Sequential block for latching the dapabort_reg.
  //----------------------------------------------------------------------------
  always @ (posedge dapclk or negedge dapresetn)
    begin : p_dapabortreg
      if (!dapresetn)
        dapabort_reg <= 1'b0;
      else
        if (dapabort_reg_en)
          dapabort_reg <= ~ahb_tr_done;
    end

  //----------------------------------------------------------------------------
  // Sequential block for driving dapready from the AHB-AP block.
  //----------------------------------------------------------------------------
  always @(posedge dapclk or negedge dapresetn)
    begin : p_dapready
      if (!dapresetn)
        dapready <= 1'b1;
      else
        if(dapclken)
          dapready <= next_dap_ready;
    end

  //----------------------------------------------------------------------------
  // Sequential block for driving dapslverr from the AHB-AP block.
  //----------------------------------------------------------------------------
  always @(posedge dapclk or negedge dapresetn)
    begin : p_dapslverr
      if (!dapresetn)
        dapslverr <= 1'b0;
      else
        if(dapclken)
          dapslverr <= next_dap_slv_err;
    end

  //----------------------------------------------------------------------------
  // The ahb_ctl_en is the enable signal for the ahb_wr_data and ahb_rd_wr signals.
  //----------------------------------------------------------------------------
  assign ahb_ctl_en = ahb_access & ~ahb_tr_in_prog & dapsel & dapclken;

  //----------------------------------------------------------------------------
  // Sequential block for latching the ahb_wr_data.
  //----------------------------------------------------------------------------
  always @ (posedge dapclk or negedge dapresetn)
    begin : p_ahbwrdata
      if (!dapresetn)
         ahb_wr_data_cdc_check  <= {32{1'b0}};
      else
        if (ahb_ctl_en)
           ahb_wr_data_cdc_check  <= dapwdata;
    end

  //----------------------------------------------------------------------------
  // Sequential block for latching the ahb_rd_wr.
  //----------------------------------------------------------------------------
  always @ (posedge dapclk or negedge dapresetn)
    begin : p_ahbrdwr
      if (!dapresetn)
         ahb_rd_wr_cdc_check  <= 1'b0;
      else
        if (ahb_ctl_en)
           ahb_rd_wr_cdc_check  <= dapwrite;
    end

  //----------------------------------------------------------------------------
  // Register spiden to avoid it changing during an AHB transaction
  //----------------------------------------------------------------------------
  always @ (posedge dapclk or negedge dapresetn)
    begin : p_ahbspiden
      if (!dapresetn)
         ahb_spiden_cdc_check  <= 1'b0;
      else
        if (ahb_ctl_en)
           ahb_spiden_cdc_check  <= spid_en_sync;
    end

  //----------------------------------------------------------------------------
  // The bd_access_en is the enable signal for bd_access.
  //----------------------------------------------------------------------------
  assign bd_access_en = ((ahb_tr_req & bd_sel) | ahb_tr_done) & dapclken;

  //----------------------------------------------------------------------------
  // bd_access indicates that the current transaction is initiated by the banked
  // data register access.This signal is used to sustain the ahb_addr driven onto
  // the AHB interface.When a dapabort is received,the address on the DAP side
  // will change and hence the address driven onto the AHB interface should not
  // change.
  //----------------------------------------------------------------------------
  always @ (posedge dapclk or negedge dapresetn)
    begin : p_bdreg
      if (!dapresetn)
         bd_access_cdc_check  <= 1'b0;
      else
        if (bd_access_en)
           bd_access_cdc_check  <= ahb_tr_req;
    end

  //----------------------------------------------------------------------------
  // The bd_wr_en is the enable signal for writing into the banked data address
  // register.
  //----------------------------------------------------------------------------
  assign bd_wr_en = bd_sel & dapclken;

  //----------------------------------------------------------------------------
  // Sequential block for writing into the banked data address register.Only
  // the 3:2 bits of the dapaddr bus are latched as the AHB address for the
  // banked data register accesses are formed by the 31:4 bits of ta_reg and
  // the 3:0 bits of dapaddr bus.[1:0] bits of dapaddr shall be 2'b00 as the
  // word accesses are only performed on the banked data registers.
  //----------------------------------------------------------------------------
  always @ (posedge dapclk or negedge dapresetn)
    begin : p_bdaccess
      if (!dapresetn)
         bd_reg_cdc_check  <= {2{1'b0}};
      else
        if (bd_wr_en)
           bd_reg_cdc_check  <= dapaddr[3:2];
    end

  //----------------------------------------------------------------------------
  // The ahb_addr is the AHB address to be driven by the AHB master interface.The
  // address is driven from transfer address register when transfer address or
  // data read write registers is selected.Only the 3:2 bits of address are
  // driven from BdAddr in the case of the banked data registers.
  //----------------------------------------------------------------------------

  assign ahb_addr[3:2]  = bd_access ? bd_reg[1:0] : ta_reg[3:2];
  assign ahb_addr[31:4] = ta_reg[31:4];
  assign ahb_addr[1:0]  = bd_access ? 2'b00 : ta_reg[1:0];

  //----------------------------------------------------------------------------
  // Logic for the ahb_prot.The six least significant bits are derived from
  // the control status word register.The most significant bit is driven high
  // when spid_en_sync is low or when s_prot is set in control status word
  // register.
  //----------------------------------------------------------------------------
  assign ahb_prot_bit6   = s_prot | ~ahb_spiden;
  assign ahb_prot_bits4to0 = prot;

  //----------------------------------------------------------------------------
  // Combinational block for driving the daprdata.The read data is read from
  // the AHB master interface when it drives the ApbTrDone signal.The registers
  // within the AHB-AP block are read from their corresponding read data buses.
  //----------------------------------------------------------------------------
  assign next_dap_rd_data = (
                          ({32{csw_sw_rd_en}} & csw_rd_data) |
                          ({32{ta_sw_rd_en}}  & ta_rd_data)  |
                          ({32{ahb_sw_rd_en}} & ahb_rd_data_s)|
                          ({32{rom_sw_rd_en}} & rom_rd_data) |
                          ({32{id_sw_rd_en}}  & id_rd_data)
                         );

  //----------------------------------------------------------------------------
  // Sequential block for daprdata of the DAP slave interface.
  //----------------------------------------------------------------------------
  always @(posedge dapclk or negedge dapresetn)
    begin : p_prdata
      if (!dapresetn)
        daprdata <= {32{1'b0}};
      else
        if(dapclken)
          daprdata <= next_dap_rd_data;
    end

  //----------------------------------------------------------------------------
  // addr_inc_size indicates the amount by which the value in the transfer address
  // register should be incremented.
  //----------------------------------------------------------------------------
  always @ (ahb_size_int)
    begin : p_addrinc
      case (ahb_size_int[1:0])
        `AHBAP_BYTE      : addr_inc_size = 3'b001;
        `AHBAP_HALF_WORD : addr_inc_size = 3'b010;
        `AHBAP_WORD      : addr_inc_size = 3'b100;
        `AHBAP_UNUSED    : addr_inc_size = 3'bxxx;
        default    : addr_inc_size = 3'bxxx;
      endcase // case(ahb_size_int[1:0])
    end

  //----------------------------------------------------------------------------
  // AHB Interface latches
  // These sample the incoming AHB (data) signals for use in the APB domain
  // - sampled on completion of the AHB transaction but should not be used for
  //   two clock cycles in case the other clock domain reset during the sampling
  //   (DAP_RDY1 and DAP_RDY2 are used for this)

  assign ahb_sample_en = ((cur_state == `ST_DAP_WAIT) &         // Waiting for end
                         (ahb_state_sync == `ST_AHBIF_RDY) &    // AHB Completed
                         dapclken);


  always @(posedge dapclk or negedge dapresetn)
    begin : p_ahbsample
      if (!dapresetn)
        begin
          ahb_rd_data_s <= 32'h00000000;
          ahb_err_resp_s <= 1'b0;
        end
      else if (ahb_sample_en)
        begin
          ahb_rd_data_s <= ahb_rd_data;
          ahb_err_resp_s <= ahb_err_resp;
        end
    end // block: p_ahbsample

   assign ahb_rd_wr   = ahb_rd_wr_cdc_check;
   assign ahb_wr_data = ahb_wr_data_cdc_check;
   assign ahb_spiden  = ahb_spiden_cdc_check;
   assign dap_state   = dapstate_cdc_check;
   assign bd_access   = bd_access_cdc_check;
   assign bd_reg      = bd_reg_cdc_check;
   assign csw_reg     = csw_reg_cdc_check;
   assign ta_reg      = ta_reg_cdc_check;

`ifdef ARM_ASSERT_ON
  //----------------------------------------------------------------------------
  // OVL Assertions
  //----------------------------------------------------------------------------

  //----------------------------------------------------------------------------
  // ahb_access and reg_access should not be high at the same time.
  //----------------------------------------------------------------------------
  assert_zero_one_hot #(`OVL_ERROR, 2, `OVL_ASSERT,
    "OVL Message : dapahbap_dap_if - ahb_access and reg_access at the same time")
      dapahbap_access
        (
         .clk         (dapclk),
         .reset_n     (dapresetn),
         .test_expr   ({reg_access,ahb_access})
        );

  //----------------------------------------------------------------------------
  // auto_inc_en and reg_access should not be high at the same time.
  //----------------------------------------------------------------------------
  assert_zero_one_hot #(`OVL_ERROR, 2, `OVL_ASSERT,
    "OVL Message : dapahbap_dap_if - auto_inc_en and reg_access at the same time")
      dapahbap_inc_en
        (
         .clk         (dapclk),
         .reset_n     (dapresetn),
         .test_expr   ({reg_access,auto_inc_en})
        );

  //----------------------------------------------------------------------------
  // ahb_size[1:0] programmed in the control status register should not be 2'b11.
  //----------------------------------------------------------------------------
  assert_never #(`OVL_ERROR, `OVL_ASSUME,
    "OVL Message : dapahbap_dap_if - Unsupported AHB size programmed")
      dapahbap_ahb_size
        (
         .clk         (dapclk),
         .reset_n     (dapresetn),
         .test_expr   (ahb_size_int[1:0] == 2'b11)
        );

  //----------------------------------------------------------------------------
  // addr_inc programmed in the control status register should not be 2'b11.
  //----------------------------------------------------------------------------
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
    "OVL Message : dapahbap_dap_if - Unsupported address increment programmed")
      dapahbap_addr_inc
        (
         .clk         (dapclk),
         .reset_n     (dapresetn),
         .test_expr   (addr_inc == 2'b11)
        );

  //----------------------------------------------------------------------------
  // dap_state is onehot (not zero)
  //----------------------------------------------------------------------------
  assert_one_hot #(`OVL_ERROR, 4, `OVL_ASSERT,
    "OVL Message : dap_state should be onehot")
      dapahbap_onehot_dapstate
        (
         .clk         (dapclk),
         .reset_n     (dapresetn),
         .test_expr   (dap_state)
        );

  //----------------------------------------------------------------------------
  // banked register accesses support only word size transfers
  //----------------------------------------------------------------------------
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
    "OVL Message : dapahbap_dap_if - banked register access supports only word size transfers")
      dapahbap_bkd_access
        (
         .clk         (dapclk),
         .reset_n     (dapresetn),
         .test_expr   (bd_access && (ahb_addr[1:0] != 2'b00) )
        );

  //----------------------------------------------------------------------------
  // banked register accesses support only word size transfers
  //----------------------------------------------------------------------------
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
    "OVL Message : dapahbap_dap_if - The revision value is not 6")
      dapahbap_rev_value
        (
         .clk         (dapclk),
         .reset_n     (dapresetn),
         .test_expr   (id_rd_data[31:28] != 4'b0110)
        );

`endif
endmodule // cxdapahbap_slv
