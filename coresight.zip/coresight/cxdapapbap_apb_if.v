//------------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2003-2015 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//    Checked In : $Date: 2014-08-15 12:03:08 +0100 (Fri, 15 Aug 2014) $
//    Revision   : $Revision: 39946 $
//    Release    : CoreSight-SoC-TM100-r3p2-00rel0
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// Abstract : Debug Access Port APB Access Port (cxdapapbap) - APB Interface
//------------------------------------------------------------------------------
//
// cxdapapbap - Debug Access Port APB Access Port
// ----------------------------------------------
//
// Debug Access Port APB Access Port component provides an APB interface to a
// System On Chip (SOC).
//
// cxdapapbap_apb_if.v
// -------------------
//
// cxdapapbap_apb_if.v provides the APB master interface for the dapapbap block.
//
// Instantiated blocks
// -------------------
// None
//------------------------------------------------------------------------------


module cxdapapbap_apb_if (
  // Inputs
  dapclk, dapclken, dapresetn, pready, apb_rd_wr,
  apb_tr_req, dapwdata,
  // Outputs
  psel, penable, pwrite, pwdata, apb_tr_done
  );

`include "cxdapapbap_constants.v"

  //----------------------------------------------------------------------------
  // Inputs
  //----------------------------------------------------------------------------
  input         dapclk;         // DAP clock
  input         dapclken;       // DAP clock enable
  input         dapresetn;      // DAP asynchrnous reset active low

  input         pready;         // APB slave ready

  input         apb_rd_wr;      // APB read or write transfer fom DAP inteface
  input         apb_tr_req;     // APB transfer request from DAP inteface
  input [31:0]  dapwdata;       // APB write data bus from DAP inteface

  //----------------------------------------------------------------------------
  // Outputs
  //----------------------------------------------------------------------------
  output        psel;           // APB select
  output        penable;        // APB enable
  output        pwrite;         // APB write or read
  output [31:0] pwdata;         // APB write data bus

  output        apb_tr_done;    // APB interface transfer complete

  //----------------------------------------------------------------------------
  // Wires
  //----------------------------------------------------------------------------
  wire          apb_ctl_en;
  wire          next_psel;
  wire          next_penable;
  wire          apb_tr_done;

  //----------------------------------------------------------------------------
  // Registers
  //----------------------------------------------------------------------------
  reg           pwrite;
  wire          psel;
  reg           psel_int;
  reg           penable;
  reg [1:0]     cur_state;
  reg [1:0]     next_state;
  reg [31:0]    pwdata;

  //----------------------------------------------------------------------------
  //
  // Main body of code
  // =================
  //
  //----------------------------------------------------------------------------

  //----------------------------------------------------------------------------
  // Logic for the APB master interface state machine.
  // ST_APBAP_IDLE : Idle state for the state machine.Remains in this state till
  //                 a transfer request is received from the DAP slave
  //                 interface.
  // ST_APBAP_ADDR : Enters this state from the ST_APBAP_IDLE state when a
  //                 transfer request is received from the DAP slave interface.
  //                 Moves outo f this state to the ST_APBAP_RDY state.
  // ST_APBAP_RDY  : Enters this state from the ST_APBAP_ADDR state.Moves out of
  //                 this state when pready is received from the APB domain.
  //----------------------------------------------------------------------------
  always @(apb_tr_req or cur_state or pready)
    begin : p_nextstate
      case(cur_state)
        ST_APBAP_IDLE : next_state = apb_tr_req ? ST_APBAP_ADDR : ST_APBAP_IDLE;
        ST_APBAP_ADDR : next_state = ST_APBAP_RDY;
        ST_APBAP_RDY  : next_state = pready ? ST_APBAP_IDLE : ST_APBAP_RDY;
        default        : next_state = ST_APBAP_UNDEF;
      endcase
    end

  //----------------------------------------------------------------------------
  // Sequential block for cur_state of the APB master interface state machine.
  //----------------------------------------------------------------------------
  always @(posedge dapclk or negedge dapresetn)
    begin : p_curstate
      if (!dapresetn)
        cur_state <= ST_APBAP_IDLE;
      else
        if(dapclken)
          cur_state <= next_state;
    end

  //----------------------------------------------------------------------------
  // The apb_ctl_en is the enable signal for latching the control signals of the
  // APB master interface.
  //----------------------------------------------------------------------------
  assign apb_ctl_en = (next_state == ST_APBAP_ADDR) & dapclken;

  //----------------------------------------------------------------------------
  // The next_psel is driven when the APB master interface state machine is in
  // the ST_APBAP_ADDR and ST_APBAP_RDY states.This ensures that psel is driven
  // high when the address is driven on the APB bus and driven low when the
  // APB master interface receives pready.
  //----------------------------------------------------------------------------
  assign next_psel = (next_state == ST_APBAP_ADDR) |
                     (next_state == ST_APBAP_RDY);

  //----------------------------------------------------------------------------
  // The next_penable is driven high when the APB master state machine in the
  // the ST_APBAP_RDY state.This ensures that the penable signal from the APB
  // master is driven high one clock cycle after the psel signal is driven high
  // and psel is driven low when the APB state machine receives pready.
  //----------------------------------------------------------------------------
  assign next_penable = (next_state == ST_APBAP_RDY);

  //----------------------------------------------------------------------------
  // Handshaking signals to the DAP interface module.
  //----------------------------------------------------------------------------
  assign apb_tr_done   = pready & (cur_state == ST_APBAP_RDY);

  //----------------------------------------------------------------------------
  // Sequential block for psel of the APB master interface.
  //----------------------------------------------------------------------------
  always @(posedge dapclk or negedge dapresetn)
    begin : p_psel
      if (!dapresetn)
        psel_int <= 1'b0;
      else
        if(dapclken)
          psel_int <= next_psel;
    end
  assign psel = psel_int;

  //----------------------------------------------------------------------------
  // Sequential block for penable of the APB master interface.
  //----------------------------------------------------------------------------
  always @(posedge dapclk or negedge dapresetn)
    begin : p_penable
      if (!dapresetn)
        penable <= 1'b0;
      else
        if(dapclken)
          penable <= next_penable;
    end

  //----------------------------------------------------------------------------
  // Sequential block for pwrite of the APB master interface.
  //----------------------------------------------------------------------------
  always @(posedge dapclk or negedge dapresetn)
    begin : p_pwrite
      if (!dapresetn)
        pwrite <= 1'b0;
      else
        if(apb_ctl_en)
          pwrite <= apb_rd_wr;
    end

  //----------------------------------------------------------------------------
  // Sequential block for pwrite of the APB master interface.
  //----------------------------------------------------------------------------
  always @(posedge dapclk or negedge dapresetn)
    begin : p_pwdata
      if (!dapresetn)
        pwdata <= {32{1'b0}};
      else
        if(apb_ctl_en)
          pwdata <= dapwdata;
    end

`ifdef ARM_ASSERT_ON
  //----------------------------------------------------------------------------
  // OVL Assertions
  //----------------------------------------------------------------------------
  reg    apb_tr_req_del;        // Delayed APB transfer request

  //----------------------------------------------------------------------------
  // Register transfer request for edge detection
  //----------------------------------------------------------------------------
  always @ (posedge dapclk or negedge dapresetn)
    if (!dapresetn)
      apb_tr_req_del <= 1'b0;
    else
      if(dapclken)
        apb_tr_req_del <= apb_tr_req;

  //----------------------------------------------------------------------------
  // apb_tr_req should be a single cycle pulse.
  //----------------------------------------------------------------------------
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
    "OVL Message : dapapbap_apbif - apb_tr_req is not a single cycle pulse")
      dapapbap_apbtrreq
        (
         .clk         (dapclk),
         .reset_n     (dapresetn),
         .test_expr   (apb_tr_req & apb_tr_req_del)
        );

`endif

endmodule // cxdapapbap_apb_if
