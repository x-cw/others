`include "../general/general.vh"


module gp_fifo_sync_width2 
  #(parameter
    ENABLE_INIT_INPUT=0,
    FIFO_WIDTH=0,
    FIFO_WORDS=0,
    AFULL_THRESH=0,
    AEMPTY_THRESH=0,
    
    L2_FIFO_WORDS=log2(FIFO_WORDS)
    ) (
       input wire                    clk,
       input wire                    reset_n,
       
       input wire                    init,
       
       //read
       input wire                    rd_en,
       output reg [FIFO_WIDTH-1:0]   dout,
       
       //write
       input wire                    wr_en,
       input wire [FIFO_WIDTH-1:0]   din,
       
       //status
       output wire                   aempty,
       output reg                    afull, 
       output wire                   empty,
       output reg                    full,
       output reg                    overflow,
       output reg                    underflow,
       output wire [L2_FIFO_WORDS:0] valid_entries
       );

`include "../general/misc.vh"
  
  localparam
    MEM_WORDS=FIFO_WORDS>>1,
    MEM_WIDTH=FIFO_WIDTH*2,
    L2_MEM_WORDS=log2(MEM_WORDS);

  wire [L2_FIFO_WORDS:0] aemtpy_thresh=AEMPTY_THRESH;
  wire [L2_FIFO_WORDS:0] afull_thresh=AFULL_THRESH;
 
  reg [L2_FIFO_WORDS:0] valid_entries_internal;
  reg [L2_FIFO_WORDS:0] mem_valid_entries;
  reg [FIFO_WIDTH-1:0] in_holding[0:2];
  reg [FIFO_WIDTH-1:0] out_holding[0:2];
  reg [1:0] in_pending;
  reg [1:0] out_pending;

  reg [MEM_WIDTH-1:0] fifo_din;
  wire [MEM_WIDTH-1:0] fifo_dout;
  reg fifo_wr_en;
  reg [L2_MEM_WORDS-1:0] wr_addr, rd_addr;
  wire [L2_MEM_WORDS-1:0] fifo_addr = fifo_wr_en ? wr_addr : rd_addr;
  reg fifo_rd_en_d;
  reg fifo_rd_en;
  reg bypass;

  wire fifo_c_en=fifo_wr_en | fifo_rd_en;
  //reg rd_mode;
  
  always @(posedge clk, negedge reset_n)
    if (~reset_n) begin
      out_holding[0]<='d0;
      out_holding[1]<='d0;
      out_holding[2]<='d0;
      in_holding[0]<='d0;
      in_holding[1]<='d0;
      in_holding[2]<='d0;
      /*autoreset*/
      // Beginning of autoreset for uninitialized flops
      afull <= 1'h0;
      fifo_rd_en_d <= 1'h0;
      full <= 1'h0;
      in_pending <= 2'h0;
      mem_valid_entries <= {(1+(L2_FIFO_WORDS)){1'b0}};
      out_pending <= 2'h0;
      overflow <= 1'h0;
      rd_addr <= {L2_MEM_WORDS{1'b0}};
      underflow <= 1'h0;
      valid_entries_internal <= {(1+(L2_FIFO_WORDS)){1'b0}};
      wr_addr <= {L2_MEM_WORDS{1'b0}};
      // End of automatics
    end else if((ENABLE_INIT_INPUT==1) & init) begin
      out_holding[0]<='d0;
      out_holding[1]<='d0;
      out_holding[2]<='d0;
      in_holding[0]<='d0;
      in_holding[1]<='d0;
      in_holding[2]<='d0;    
      /*autoreset*/
      // Beginning of autoreset for uninitialized flops
      afull <= 1'h0;
      fifo_rd_en_d <= 1'h0;
      full <= 1'h0;
      in_pending <= 2'h0;
      mem_valid_entries <= {(1+(L2_FIFO_WORDS)){1'b0}};
      out_pending <= 2'h0;
      overflow <= 1'h0;
      rd_addr <= {L2_MEM_WORDS{1'b0}};
      underflow <= 1'h0;
      valid_entries_internal <= {(1+(L2_FIFO_WORDS)){1'b0}};
      wr_addr <= {L2_MEM_WORDS{1'b0}};
      // End of automatics
    end else begin
      if (wr_en && full)
        overflow<=1;
      if (rd_en && empty)
        underflow<=1;
      
      case ({wr_en,rd_en})
        2'b10: valid_entries_internal<=valid_entries_internal+1;
        2'b01: valid_entries_internal<=valid_entries_internal-1;
        default: ; //hold on +1-1 or nothing...
      endcase

      case ({fifo_wr_en,fifo_rd_en})
        2'b10: mem_valid_entries<=mem_valid_entries+1;
        2'b01: mem_valid_entries<=mem_valid_entries-1;
        default: ; //hold on +1-1 or nothing...
      endcase   
      
      if (wr_en) begin
        in_holding[0]<=din;
        in_holding[1]<=in_holding[0];
        in_holding[2]<=in_holding[1];
      end
      
      case ({wr_en,fifo_wr_en,bypass})
        3'b100: in_pending<=in_pending+1; //+1-0-0

        3'b010: in_pending<=in_pending-2; //+0-2-0
        3'b110: in_pending<=in_pending-1; //+1-2-0

        3'b001: in_pending<=in_pending-1; //+0-0-1
        3'b101: in_pending<=in_pending;   //+1-0-1

        3'b000: ; //hold
      endcase

      if (fifo_wr_en) begin
        if (wr_addr==MEM_WORDS-1)
          wr_addr<=0;
        else
          wr_addr<=wr_addr+1;
      end
      
      if (fifo_rd_en) begin
        if (rd_addr==MEM_WORDS-1)
          rd_addr<=0;
        else
          rd_addr<=rd_addr+1;
      end
      
      fifo_rd_en_d<=fifo_rd_en;

      case ({fifo_rd_en_d,bypass})
        2'b10: begin
          out_holding[0]<=fifo_dout[0+:FIFO_WIDTH];
          out_holding[1]<=fifo_dout[FIFO_WIDTH+:FIFO_WIDTH];
          out_holding[2]<=out_holding[0];
        end
        2'b01: begin
          out_holding[0]<=in_holding[in_pending-1];
          out_holding[1]<=out_holding[0];
          out_holding[2]<=out_holding[1];
        end
      endcase
      
      case ({rd_en,fifo_rd_en_d,bypass})
        3'b100: out_pending<=out_pending-1; //-1+0+0

        3'b010: out_pending<=out_pending+2; //-0+2+0
        3'b110: out_pending<=out_pending+1; //-1+2+0
        
        3'b001: out_pending<=out_pending+1; //-0+0+1
        3'b101: out_pending<=out_pending;   //-1+0+1
        default: ;
      endcase

      //rd_mode<=~rd_mode;

      if (
          ((valid_entries_internal==FIFO_WORDS - 1) && wr_en && ~rd_en) ||
          ((valid_entries_internal==FIFO_WORDS))
          )
        full<=1;
      else
        full<=0;

      if (valid_entries_internal>=AFULL_THRESH ||
          (valid_entries_internal>=AFULL_THRESH - 1) && wr_en && ~rd_en)
        afull<=1;
      else
        afull<=0;
      
      
    end

  wire mem_full = (wr_addr + 1 == rd_addr ||
                   (wr_addr==MEM_WORDS-1 && rd_addr==0));

  wire mem_empty = wr_addr == rd_addr;

  assign empty=out_pending==0;
  assign valid_entries= empty ? 0 : valid_entries_internal;
  
  
  assign aempty=empty || valid_entries<aemtpy_thresh;


  
  always @* begin

    case (in_pending)
      //2'd1: fifo_din={in_holding[0],din};
      2'd2: fifo_din={in_holding[1],in_holding[0]};
      2'd3: fifo_din={in_holding[2],in_holding[1]};
      default: fifo_din='bx;
    endcase

    case (out_pending)
      2'd1: dout=out_holding[0];
      2'd2: dout=out_holding[1];
      2'd3: dout=out_holding[2];
      default: dout='bx;
    endcase
    
    fifo_rd_en=0;
    fifo_wr_en=0;
    bypass=0;

    if (~mem_empty && ~fifo_rd_en_d && (out_pending<2 || out_pending<3 && rd_en)) begin
      fifo_rd_en=1;
    end else if (out_pending<3 && in_pending>0 && ~fifo_rd_en_d && mem_empty) begin
      bypass=1;
    end else if (in_pending>=2 && ~mem_full) begin
      fifo_wr_en=1;
    end


  end
  
  /*mem_1rw auto_template "\(.*\)" (
   .MEM_BIT_EN(0),
   .MEM_FAST(0),
   .\(^[A-Z].*\)(\1),
   .clk(clk),
   .bit_en({@"vl-width"{1'b1}}),
   .\(.*\)(@_\1),
   );*/
  
  mem_1rw #(/*autoinstparam*/
            // Parameters
            .MEM_BIT_EN                 (0),                     // Templated
            .MEM_WORDS                  (MEM_WORDS),             // Templated
            .MEM_WIDTH                  (MEM_WIDTH),             // Templated
            .MEM_FAST                   (0),                     // Templated
            .L2_MEM_WORDS               (L2_MEM_WORDS))          // Templated
  fifo(/*autoinst*/
       // Outputs
       .dout                            (fifo_dout),             // Templated
       // Inputs
       .din                             (fifo_din),              // Templated
       .bit_en                          ({MEM_WIDTH{1'b1}}),     // Templated
       .addr                            (fifo_addr),             // Templated
       .clk                             (clk),                   // Templated
       .c_en                            (fifo_c_en),             // Templated
       .wr_en                           (fifo_wr_en));           // Templated
  
  

endmodule
// Local Variables:
// verilog-library-flags:("-y ../memories")
// End:
