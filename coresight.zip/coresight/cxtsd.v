//-----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2010-2013 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//  Version and Release Control Information:
//
//  Checked In          : $Date: 2013-09-06 16:09:52 +0100 (Fri, 06 Sep 2013) $
//
//  File Revision       : $Revision: 37059 $
//
//  Release Information : CoreSight-SoC-TM100-r3p1-00rel0
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// Abstract : CoreSight Time Stamp Decoder - Top Level Block
//-----------------------------------------------------------------------------
//
// cxtse - CoreSight Time Stamp Decoder
//-----------------------------------------------------------------------------

module cxtsd (

  // Clock and Reset
  input wire        clk,
  input wire        resetn,

  // Time Stamp Decoder
  input wire [6:0]  tsbit,
  input wire [1:0]  tssync,
  output wire       tssyncready,

  // Decoded Time Stamp
  output wire [63:0] tsvalue

  );

//-----------------------------------------------------------------------------
// Algorithm
//-----------------------------------------------------------------------------
// Following sequence is followed. Immediately after Reset, wait for sync
// mark. Starting from the most significant bit, downwards, get all the 64-bits
// of the time-stamp, or till the next SYNC_MARK is received.
// Subsequent to this, all the index values will
// represent bits which are changing as part of normal count operation.
// Using the current index value, the bit at that index location is flipped and
// all bits in lower index positions are reset.
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
// Functions
//-----------------------------------------------------------------------------
// indx_2_cnt is a function which transforms the encoded value to actual count value.
//-----------------------------------------------------------------------------
function [63:0] indx_2_cnt;
  input [63:0] ts_cnt;
  input [6:0] ts_indx;
  reg [6:0] ts_act_indx;
  integer bit_indx;

  begin
    if (ts_indx == {7{1'b0}})
      ts_act_indx = {7{1'b0}};
    else
      ts_act_indx = ts_indx - {{6{1'b0}}, 1'b1};

    for(bit_indx = 0; bit_indx <= 63; bit_indx = bit_indx + 1)
      if (bit_indx < ts_act_indx)
        indx_2_cnt[bit_indx] = 1'b0;
      else if (bit_indx == ts_act_indx)
        indx_2_cnt[bit_indx] = 1'b1;
      else
        indx_2_cnt[bit_indx] = ts_cnt[bit_indx];
  end
endfunction

//-----------------------------------------------------------------------------
// Algorithm
//-----------------------------------------------------------------------------
// indx_2_bir is a function which replaces the bit position with the value
// provided. This function is passed the index value and the bit value which
// needs to be stored.
//-----------------------------------------------------------------------------
function [63:0] indx_2_bit;
  input [63:0]  ts_cnt;
  input [5:0]   ts_bit;
  reg [63:0]    indx_dec_en;
  integer       bit_indx;
  integer       indx_cnt;

  begin
    for(bit_indx = 0; bit_indx <= 63; bit_indx = bit_indx + 1)
      if (ts_bit == bit_indx)
        indx_dec_en[bit_indx] = 1'b1;
      else
        indx_dec_en[bit_indx] = 1'b0;

    for(indx_cnt = 63; indx_cnt >= 0; indx_cnt = indx_cnt - 1)
      if (indx_dec_en[indx_cnt])
        indx_2_bit[indx_cnt] = 1'b1;
      else
        indx_2_bit[indx_cnt] = ts_cnt[indx_cnt];
  end
endfunction

//------------------------------------------------------------------------------
// Local parameters
//------------------------------------------------------------------------------
  localparam ST_MARK   = 2'b00;
  localparam ST_SYNC   = 2'b01;
  localparam ST_CNT    = 2'b10;
  localparam ST_UNUSED = 2'b11;

  localparam CNTZERO   = {64{1'b0}};

//------------------------------------------------------------------------------
// wire declarations
//------------------------------------------------------------------------------
  wire        ts_bit_en;
  wire [63:0] ts_cnt_indx_2_cnt;

//------------------------------------------------------------------------------
// reg declarations
//------------------------------------------------------------------------------
  reg [5:0]  ts_int_indx_nxt;
  reg [5:0]  ts_int_indx;
  reg        ts_int_indx_en;
  reg [1:0]  sync_fsm_nxt;
  reg [1:0]  sync_fsm;
  reg [63:0] tsvalue_int;
  reg [63:0] tsvalue_int_nxt;
  reg        tsvalue_int_en;
  reg [6:0]  ts_bit_rg;
  reg        ts_bit_valid_rg;
  reg [1:0]  ts_sync_rg;

//============================================================================
//
// Main body of code
//
//============================================================================

//============================================================================
// Input values are immediately registered. This is to aid timing closure
// It is conditional to ensure that power dissipation is kept minimal.
// tsbit value needs to be registered only when tsbitVALID is high
//============================================================================
  assign ts_bit_en = (tsbit != {7{1'b0}});

  always @(posedge clk or negedge resetn)
    begin
      if (!resetn)
        ts_bit_rg <= {7{1'b0}};
      else if (ts_bit_en)
        ts_bit_rg <= tsbit;
    end

//============================================================================
// Input values are immediately registered. This is to aid timing closure
// This is not conditional since this qualifies whether the registered tsbit
// is valid or not. The status changes every cycle and hence has to be
// registered unconditionally.
//============================================================================
  always @(posedge clk or negedge resetn)
    begin
      if (!resetn)
        ts_bit_valid_rg <= 1'b0;
      else
        ts_bit_valid_rg <= ts_bit_en;
    end

//============================================================================
// Input values are immediately registered. This is to aid timing closure
// This conditional to ensure that power dissipation is kept minimal.
// tssync value need not be stored only when previous sync-value was
// invalid(2'b00) and the current sync-value is also invalid(2'b00)
// In all other cases the sync-value needs to be registered.
//============================================================================
  always @(posedge clk or negedge resetn)
    begin
      if (!resetn)
        ts_sync_rg <= {2{1'b0}};
      else
        ts_sync_rg <= tssync;
    end

//============================================================================
// Main state machine.
// There are three states:
// ST_MARK: Wait for the sync mark, then move to ST_SYNC.
// ST_SYNC: Build up the current timestamp from the sync stream.
//          Move to ST_CNT when the bit stream has caught up.
//          Move to ST_MARK again if we get a RESYNC event.
// ST_CNT : Normal operation, running off the bit stream and ignoring the
//          sync stream.
//          Move to ST_MARK again if we get a RESYNC event.
//============================================================================

  assign ts_cnt_indx_2_cnt = indx_2_cnt(tsvalue_int,ts_bit_rg);

  always @(*)
    begin
      case (sync_fsm)
        ST_MARK : begin // Wait until a sync mark is detected.
          ts_int_indx_nxt = 6'd63;
          ts_int_indx_en  = 1'b0;
          tsvalue_int_nxt = {1'b1,{63{1'b0}}}; // Stays at zero if not moving to ST_CNT
          tsvalue_int_en  = ts_bit_valid_rg && (ts_bit_rg == 7'h40);
          if (ts_sync_rg == 2'b01)
            begin // Found sync mark (or top bit just changed)
              sync_fsm_nxt = (ts_bit_valid_rg && (ts_bit_rg == 7'h40)) ? ST_CNT : ST_SYNC;
            end
          else
            begin // Keep waiting
              sync_fsm_nxt = ST_MARK;
            end
        end
        ST_SYNC : begin // Build up the start count value from the sync stream
          if (ts_bit_valid_rg && (ts_bit_rg == {7{1'b1}}))
            begin // RESYNC event
              ts_int_indx_nxt = 6'd63;
              ts_int_indx_en = 1'b1;
              tsvalue_int_nxt = CNTZERO;
              tsvalue_int_en = 1'b1;
              sync_fsm_nxt = (ts_sync_rg == 2'b01) ? ST_SYNC : ST_MARK;
            end
          else if (ts_bit_valid_rg && (ts_bit_rg > {1'b0,ts_int_indx}))
            // ts_bit has overtaken sync stream.
            // Note that ts_bit is encoded with 0 reserved to mean "no increment",
            // so the bit actually incremented is ts_bit - 1.  Therefore the above
            // > check is actually a >= from the point of view of the bit positions.
            begin
              ts_int_indx_nxt = 6'd63;
              ts_int_indx_en = 1'b1;
              tsvalue_int_nxt = ts_cnt_indx_2_cnt;
              tsvalue_int_en = 1'b1;
              sync_fsm_nxt = ST_CNT;
            end
          else if (ts_bit_valid_rg && (ts_bit_rg == {1'b0,ts_int_indx}) && ts_sync_rg[1])
            // ts_bit indicates bit following ts_sync bit present on this cycle
            // Must accept both bits together
            begin
              ts_int_indx_nxt = 6'd63;
              ts_int_indx_en = 1'b1;
              tsvalue_int_nxt = ts_cnt_indx_2_cnt | (indx_2_bit(tsvalue_int,ts_int_indx) & {64{ts_sync_rg[0]}});
              tsvalue_int_en = 1'b1;
              sync_fsm_nxt = ST_CNT;
            end
          else
            begin
              case (ts_sync_rg)
                2'b00 : begin // No progress
                  ts_int_indx_nxt = ts_int_indx;
                  ts_int_indx_en = 1'b0;
                  tsvalue_int_nxt = tsvalue_int;
                  tsvalue_int_en = 1'b0;
                  sync_fsm_nxt = ST_SYNC;
                end
                2'b01 : begin // Mark observed before we're synced.
                              // Back to back sync marks
                  ts_int_indx_nxt = 6'd63;
                  ts_int_indx_en = 1'b1;
                  tsvalue_int_nxt = CNTZERO;
                  tsvalue_int_en = 1'b1;
                  sync_fsm_nxt = ST_SYNC;
                end
                2'b10, 2'b11 : begin // Sync bit -- add it to the tsvalue so far
                  ts_int_indx_nxt = ts_int_indx - 6'd1;
                  ts_int_indx_en = 1'b1;
                  tsvalue_int_nxt = indx_2_bit(tsvalue_int,ts_int_indx);
                  tsvalue_int_en = ts_sync_rg[0];
                  sync_fsm_nxt = (ts_int_indx == 7'h00) ? ST_CNT : ST_SYNC;
                end
                default : begin // X propagation
                  ts_int_indx_nxt = {6{1'bx}};
                  ts_int_indx_en = 1'b1;
                  tsvalue_int_nxt = {64{1'bx}};
                  tsvalue_int_en = 1'bx;
                  sync_fsm_nxt = 2'bxx;
                end
              endcase
            end
        end
        ST_CNT : begin // Normal counting
          ts_int_indx_nxt = 6'd63;
          ts_int_indx_en = 1'b0;
          if (ts_bit_valid_rg && (ts_bit_rg == {7{1'b1}}))
            begin // RESYNC event
              tsvalue_int_nxt = CNTZERO;
              tsvalue_int_en = 1'b1;
              sync_fsm_nxt = (ts_sync_rg == 2'b01) ? ST_SYNC : ST_MARK;
            end
          else
            begin // Normal operation, add on a bit if tsbit is valid
              tsvalue_int_nxt = ts_cnt_indx_2_cnt;
              tsvalue_int_en = ts_bit_valid_rg;
              sync_fsm_nxt = ST_CNT;
            end
        end
        default : begin // X propagation
          ts_int_indx_nxt = {6{1'bx}};
          ts_int_indx_en = 1'b1;
          tsvalue_int_nxt = {64{1'bx}};
          tsvalue_int_en = 1'bx;
          sync_fsm_nxt = 2'bxx;
        end
      endcase
    end

  always @(posedge clk or negedge resetn)
    begin
      if (!resetn)
        ts_int_indx <= 6'd63;
      else if (ts_int_indx_en)
        ts_int_indx <= ts_int_indx_nxt;
    end

  always @(posedge clk or negedge resetn)
    begin
      if (!resetn)
        sync_fsm <= ST_MARK;
      else
        sync_fsm <= sync_fsm_nxt;
    end

  always @(posedge clk or negedge resetn)
    begin
      if (!resetn)
        tsvalue_int <= CNTZERO;
      else if (tsvalue_int_en)
        tsvalue_int <= tsvalue_int_nxt;
    end

  // Export value only when in state ST_CNT
  assign tsvalue = tsvalue_int & {64{sync_fsm[1]}};

  // No backpressure required on tssync
  assign tssyncready = 1'b1;

//----------------------------------------------------------------------------
// ASSERTIONS
//----------------------------------------------------------------------------

`ifdef ARM_ASSERT_ON

//-----------------------------------------------------------------------------
// Check if the fsm enters illegal state
// If it enters default, generate an error message
//-----------------------------------------------------------------------------
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxtsd - FSM has entered an illegal state")
      uzovl_cxdapaxiap_illegal_state_chk
        (
         .clk         (clk),
         .reset_n     (resetn),
         .test_expr   ((sync_fsm != SYNC_MARK) &&
                       (sync_fsm != CNT))
        );

  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxtsd - FSM should enter CNT state only when there is a cross over or sync mark")
      uzovl_cxtsd_fsm_illegal
        (
         .clk         (clk),
         .reset_n     (resetn),
         .test_expr   ((ts_bit_rg == {1'b0,ts_int_indx}) &&
                       (ts_sync_rg != 2'b01) && (sync_fsm_nxt == CNT) &&
                       (sync_fsm_en == 1'b1) && (sync_fsm == SYNC_MARK) && (ts_bit_rg != 7'h0))
         );

`endif // ARM_ASSERT_ON

endmodule
