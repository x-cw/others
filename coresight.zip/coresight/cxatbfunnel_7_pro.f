$GP3_RTL/coresight/rtl/coresight_component/trace_module/cxatbfunnel_7_pro/verilog/cxatbfunnel_7_pro.v
$GP3_RTL/coresight/rtl/coresight_component/trace_module/cxatbfunnel_7_pro/verilog/cxatbfunnel_apb_if_7_pro.v
$GP3_RTL/coresight/rtl/coresight_component/trace_module/cxatbfunnel_7_pro/verilog/cxatbfunnel_arbiter_7_pro.v
$GP3_RTL/coresight/rtl/coresight_component/trace_module/cxatbfunnel_7_pro/verilog/cxatbfunnel_reg_blk_7_pro.v
