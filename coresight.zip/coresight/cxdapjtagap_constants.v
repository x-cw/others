//-----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2003-2013 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//  Checked In          : $Date: 2013-09-06 16:05:05 +0100 (Fri, 06 Sep 2013) $
//  Revision            : $Revision: 37058 $
//  Release             : CoreSight-SoC-TM100-r3p1-00rel0
//-----------------------------------------------------------------------------
//
// ----------------------------------------------------------------------------
//  Purpose : JTAG-AP Definitions
//  DAPJtagApDefs.v contains the 'defines for DAPJtagApEngine.v and
//  DAPJtagApApbIf.v
// ----------------------------------------------------------------------------

// 'defines for DAPJtagApEngine

  // JTAG engine state machine encoding
  `define JE_IDLE     4'b0000     // Idle state - waiting for transfer to start
  `define JE_TMS      4'b0001     // TMS counter initialisation
  `define JE_TMSLOW   4'b0010     // Emit TMS with TCK LOW
  `define JE_TMSRISE  4'b0011     // Hold TMS with TCK rising
  `define JE_TMSFALL  4'b0100     // Emit TMS with TCK falling
  `define JE_TDITDO   4'b0101     // TDI_TDO initialisation
  `define JE_TDITDO2  4'b0110     // TDI_TDO : wait for 2nd byte
  `define JE_TDINP    4'b0111     // TDI_TDO : extract normal vs packed & length
  `define JE_NORMAL   4'b1000     // TDI_TDO : wait for 3rd byte
  `define JE_TDILOW   4'b1001     // Emit TDI with TCK LOW
  `define JE_TDIRISE  4'b1010     // Hold TDI with TCK rising
  `define JE_TDIFALL  4'b1011     // Emit TDI with TCK falling
  `define JE_TDOXFER  4'b1100     // Transfer TDO byte to Read FIFO
  `define JE_TDOWAIT  4'b1101     // Wait for ACK from Read FIFO
  `define JE_UTDIMORE 4'b1110     // Idle state to reload TDI counter
  `define JE_UNDEF    4'bXXXX     // Undefined state

  `define def_1xxxx_p0 5'b10000,5'b10001,5'b10010,5'b10011,5'b10100,5'b10101
  `define def_1xxxx_p1 5'b10110,5'b10111,5'b11000,5'b11001,5'b11010,5'b11011
  `define def_1xxxx_p2 5'b11100,5'b11101,5'b11110,5'b11111

  `define def_1xxxx `def_1xxxx_p0, `def_1xxxx_p1, `def_1xxxx_p2

  `define def_01xxx 5'b01000,5'b01001,5'b01010,5'b01011,5'b01100,5'b01101,5'b01110,5'b01111

  `define def_001xx 5'b00100,5'b00101,5'b00110,5'b00111

  `define def_0001x 5'b00010,5'b00011

  `define def_1xxxxx_p0 6'b100000,6'b100001,6'b100010,6'b100011
  `define def_1xxxxx_p1 6'b100100,6'b100101,6'b100110,6'b100111
  `define def_1xxxxx_p2 6'b101000,6'b101001,6'b101010,6'b101011
  `define def_1xxxxx_p3 6'b101100,6'b101101,6'b101110,6'b101111
  `define def_1xxxxx_p4 6'b110000,6'b110001,6'b110010,6'b110011
  `define def_1xxxxx_p5 6'b110100,6'b110101,6'b110110,6'b110111
  `define def_1xxxxx_p6 6'b111000,6'b111001,6'b111010,6'b111011
  `define def_1xxxxx_p7 6'b111100,6'b111101,6'b111110,6'b111111

  `define def_1xxxxx `def_1xxxxx_p0,`def_1xxxxx_p1,`def_1xxxxx_p2,`def_1xxxxx_p3,`def_1xxxxx_p4,`def_1xxxxx_p5,`def_1xxxxx_p6,`def_1xxxxx_p7

  `define def_01xxxx_p0 6'b010000,6'b010001,6'b010010,6'b010011
  `define def_01xxxx_p1 6'b010100,6'b010101,6'b010110,6'b010111
  `define def_01xxxx_p2 6'b011000,6'b011001,6'b011010,6'b011011
  `define def_01xxxx_p3 6'b011100,6'b011101,6'b011110,6'b011111

  `define def_01xxxx `def_01xxxx_p0,`def_01xxxx_p1,`def_01xxxx_p2,`def_01xxxx_p3

  `define def_001xxx_p0 6'b001000,6'b001001,6'b001010,6'b001011
  `define def_001xxx_p1 6'b001100,6'b001101,6'b001110,6'b001111

  `define def_001xxx `def_001xxx_p0,`def_001xxx_p1

  `define def_0001xx    6'b000100,6'b000101,6'b000110,6'b000111
  `define def_00001x    6'b000010,6'b000011


// 'defines for DAPJtagApApbIf

  // Register reset values
  `define CSWRSTVAL  2'b00
  `define BFIFORESET 32'h00000000
  `define PSELRESET  8'h00
  `define PSTARESET  8'h00

  // Identification register value
  `define IDREGVAL   32'h24760010

  // Register addresses
  `define CSWADDR   6'b000000
  `define PSELADDR  6'b000001
  `define PSTAADDR  6'b000010
  `define BF1ADDR   6'b000100
  `define BF2ADDR   6'b000101
  `define BF3ADDR   6'b000110
  `define BF4ADDR   6'b000111
  `define IDRADDR   6'b111111

  // Byte count depending on BFIFO address
  `define BF1BYTE   2'b00         // Byte FIF0 1 (1 byte)
  `define BF2BYTE   2'b01         // Byte FIF0 2 (2 bytes)
  `define BF3BYTE   2'b10         // Byte FIF0 3 (3 bytes)
  `define BF4BYTE   2'b11         // Byte FIF0 4 (4 bytes)

  // Slave state machine encoding
  `define JT_DAPIDLE    2'b00     // Idle state - waiting for transfer to start
  `define JT_DAPREG     2'b01     // Internal register access
  `define JT_DAPBFIFO1  2'b10     // Byte FIFO access cycle 1
  `define JT_DAPBFIFO2  2'b11     // Byte FIFO access cycle 2 and wait for empty
  `define JT_UNDEF      2'bxx     // Undefined state

  // Define Read FIFO and Write FIFO width and depth
  `define RFIFOWIDTH 8            // Byte-wide Read FIFO
  `define WFIFOWIDTH 8            // Byte-wide Write FIFO
  `define RFIFODEPTH 7            // Read FIFO Depth
  `define WFIFODEPTH 4            // Write FIFO Depth
  `define RFIFODEPTH_MAXVAL 3'b111   // Read FIFO Depth max value in binary
  `define WFIFODEPTH_MAXVAL 3'b100   // Write FIFO Depth max value in binary

  // Define byte to extract from BFIFO, depending on current
  // value of byte counter
  `define BFIFO4_LASTBYTE 5'b11001
  `define BFIFO4_3RDBYTE  5'b11010
  `define BFIFO3_LASTBYTE 5'b10001
  `define BFIFO4_2NDBYTE  5'b11011
  `define BFIFO3_2NDBYTE  5'b10010
  `define BFIFO2_LASTBYTE 5'b01001
  `define BFIFO1_LASTBYTE 5'b00001
  `define BFIFO4_1STBYTE  5'b11100
  `define BFIFO3_1STBYTE  5'b10011
  `define BFIFO2_1STBYTE  5'b01010
  `define BFIFO_ZCOUNT    5'b00000,5'b01000,5'b10000,5'b11000

  `define BFIFO_UNDEF     {32{1'bX}}
  `define BYTE_UNDEF       {8{1'bX}}
