//----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2010-2015 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//      Checked In          : $Date: 2015-01-29 15:49:43 +0000 (Thu, 29 Jan 2015) $
//
//      Revision            : $Revision: 41305 $
//
//      Release Information : CoreSight-SoC-TM100-r3p2-00rel0
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
// cxatbasyncbridge_slv_if.v
//-----------------------------------------------------------------------------
//
// cxatbasyncbridge_slv_if.v provides the instantiations of all modules on the Slave
// side of the Asynchronous Bridge
//
// Instantiated blocks
// -------------------
//
// cxatbasyncbridge_slv_fifo.v   - ATB Slave Clock Domain Side FIFO Module
// cxatbasyncbridge_slv_sync.v   - ATB Slave Clock Domain Side Synchronizers
//-----------------------------------------------------------------------------

module cxatbasyncbridge_slv_if_slv
       #( parameter DW =31,
          parameter BW =1,
          parameter FIFO_DATA_WIDTH=41)
 (
  // Inputs
  atclks,
  atclkens,
  atresetsn,
  atvalids,
  atids,
  atbytess,
  atdatas,
  afreadys,
  atb_fwd_data,
  atb_rev_data,
  zero_pointer_d,
  // Outputs
  atreadys,
  afvalids
  );

  // Inputs
  input wire                               atclks;           // ATB Slave clock
  input wire                               atclkens;         // ATB Slave clock enable
  input wire                               atresetsn;        // ATB Slave asychronous reset active low
  input wire                               atvalids;         // Data valid signal from the input
  input wire [6:0]                         atids;            // ATB Bus id slave
  input wire [BW:0]                        atbytess;         // ATB Bus bytes slave
  input wire [DW:0]                        atdatas;          // ATB Bus data slave
  input wire                               afreadys;         //
  input wire [4:0]                         atb_rev_data;     // ATB Reverse data from master interface
                                                             // ATB forward data
  input wire                               zero_pointer_d;   // ZeroPointer from the Master Clamp

  // Outputs
  output wire                              atreadys;         // Ready to accept data from input
  output wire                              afvalids;
  output wire [6*FIFO_DATA_WIDTH + 10 : 0] atb_fwd_data;

  // Wires
  wire [3:0]                               rdptr_grey_sync;
  wire                                     flush_req_sync;
  wire                                     zero_pointer_sync;
  wire [3:0]                               rdptr_grey_d;       // Read pointer from the Master Clamp
  wire                                     flush_req_d;        // FlushReq from the Master Clamp

  wire [3:0]                               wrptr_grey;        // Write pointer to the read clock domain
  wire [FIFO_DATA_WIDTH-1:0]               fifo_data_0;        // Fifo Entry 0
  wire [FIFO_DATA_WIDTH-1:0]               fifo_data_1;        // Fifo Entry 1
  wire [FIFO_DATA_WIDTH-1:0]               fifo_data_2;        // Fifo Entry 2
  wire [FIFO_DATA_WIDTH-1:0]               fifo_data_3;        // Fifo Entry 3
  wire [FIFO_DATA_WIDTH-1:0]               fifo_data_4;        // Fifo Entry 4
  wire [FIFO_DATA_WIDTH-1:0]               fifo_data_5;        // Fifo Entry 5
  wire                                     flush_flag_0;       // Flush Flag for Fifo Entry 0
  wire                                     flush_flag_1;       // Flush Flag for Fifo Entry 1
  wire                                     flush_flag_2;       // Flush Flag for Fifo Entry 2
  wire                                     flush_flag_3;       // Flush Flag for Fifo Entry 3
  wire                                     flush_flag_4;       // Flush Flag for Fifo Entry 4
  wire                                     flush_flag_5;       // Flush Flag for Fifo Entry 5
  wire                                     flush_done;        // Flush complete from the input side

  
  // ---------------------------------------------------------------------------
  // splitting the atb_rev_data bus
  // ---------------------------------------------------------------------------
  assign rdptr_grey_d = atb_rev_data[4:1];
  assign flush_req_d = atb_rev_data[0];

  // ---------------------------------------------------------------------------
  // Creating the atb_fwd_data bus
  // ---------------------------------------------------------------------------
  assign atb_fwd_data = {wrptr_grey, flush_done, flush_flag_5, fifo_data_5,
                         flush_flag_4, fifo_data_4, flush_flag_3, fifo_data_3,
                         flush_flag_2, fifo_data_2, flush_flag_1, fifo_data_1,
                         flush_flag_0, fifo_data_0};

  // ---------------------------------------------------------------------------
  // ATB Slave Clock Domain FIFO Interface
  // ---------------------------------------------------------------------------
  cxatbasyncbridge_slv_fifo_slv #(FIFO_DATA_WIDTH) u_cxatbasyncbridge_slv_fifo
    (
    // Inputs
    .write_data                          ({atbytess,atids,atdatas}),
    // Outputs
    .atreadys                            (atreadys),
    .afvalids                            (afvalids),
    .fifo_data_0                         (fifo_data_0),
    .fifo_data_1                         (fifo_data_1),
    .fifo_data_2                         (fifo_data_2),
    .fifo_data_3                         (fifo_data_3),
    .fifo_data_4                         (fifo_data_4),
    .fifo_data_5                         (fifo_data_5),
    .flush_flag_0                        (flush_flag_0),
    .flush_flag_1                        (flush_flag_1),
    .flush_flag_2                        (flush_flag_2),
    .flush_flag_3                        (flush_flag_3),
    .flush_flag_4                        (flush_flag_4),
    .flush_flag_5                        (flush_flag_5),
    .wrptr_grey                          (wrptr_grey),
    .flush_done                          (flush_done),
    // Inputs
    .atclks                              (atclks),
    .atclkens                            (atclkens),
    .atresetsn                           (atresetsn),
    .atvalids                            (atvalids),
    .afreadys                            (afreadys),
    .rdptr_grey_sync                     (rdptr_grey_sync[3:0]),
    .flush_req_sync                      (flush_req_sync),
    .zero_pointer_sync                   (zero_pointer_sync));

  // ---------------------------------------------------------------------------
  // ATB Slave Clock Domain Synchronizers
  // ---------------------------------------------------------------------------
  // Signals going to the ATB Slave Clock domain from ATB Master Clock domain
  cxatbasyncbridge_slv_sync u_cxatbasyncbridge_slv_sync
    (
    // Outputs
    .rdptr_grey_sync                     (rdptr_grey_sync[3:0]),
    .flush_req_sync                      (flush_req_sync),
    // Inputs
    .atclks                              (atclks),
    .atclkens                            (atclkens),
    .atresetsn                           (atresetsn),
    .rdptr_grey                          (rdptr_grey_d[3:0]),
    .flush_req                           (flush_req_d));

  // ---------------------------------------------------------------------------
  // Instantiating the doubleSync module for synchronizing zero_pointer.
  // ---------------------------------------------------------------------------
  cx_en_sync u_zero_pointer
    (
    // Outputs
    .sync_do          (zero_pointer_sync),
    // Inputs
    .clk              (atclks),
    .clken            (atclkens),
    .resetn           (atresetsn),
    .sync_di          (zero_pointer_d));

endmodule // cxatbasyncbridge_slv_if
