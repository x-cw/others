//-----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2010-2013 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//  Version and Release Control Information:
//
//  Checked In          : $Date: 2011-07-12 17:44:35 +0530 (Tue, 12 Jul 2011) $
//
//  File Revision       : $Revision: 18204 $
//
//  Release Information : CoreSight-SoC-TM100-r3p1-00rel0
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// Abstract : CoreSight Time Stamp Generator - Top Level Block
//-----------------------------------------------------------------------------
//
// cxtsgen - Time Stamp Counter including the APB interface
//-----------------------------------------------------------------------------

module cxtsgen (

  // Clock and Reset
  input wire         clk,
  input wire         resetn,

  // Halt on debug
  input wire         hltdbg,

  // APB Read-only interface
  input wire         pselread,      // APB select line - read only
  input wire         penableread,   // APB enable line
  input wire         pwriteread,    // Write/Read control line
  input wire  [11:2] paddrread,     // APB address line to select register
  input wire  [31:0] pwdataread,    // APB data line
  output wire        preadyread,    // APB transfer completion indication
  output wire        pslverrread,   // APB response
  output wire [31:0] prdataread,    // APB read data line

  // APB Control interface
  input wire         pselctrl,      // APB select line - control - read and write
  input wire         penablectrl,   // APB enable line
  input wire         pwritectrl,    // Write/Read control line
  input wire  [11:2] paddrctrl,     // APB address line to select register
  input wire  [31:0] pwdatactrl,    // APB data line
  output wire        preadyctrl,    // APB transfer completion indication
  output wire        pslverrctrl,   // APB response
  output wire [31:0] prdatactrl,    // APB read data line

  // Time Stamp Encoder interface
  output wire [63:0] tsvalueb,
  output wire        tsforcesync

  );

//----------------------------------------------------------------------------
// Wires
//----------------------------------------------------------------------------
  wire        enablecnt;
  wire [63:0] newcnt;
  wire        newcntwren;
  wire [63:0] tsvalueb_int;

//============================================================================
//
// Main body of code
//
//============================================================================

cxtsgenregblk
  u_cxtsgenregblk(

  // Clock and Reset
  .clk         (clk),
  .resetn      (resetn),

  // Halt on debug
  .hltdbg      (hltdbg),

  // Up-Counter interface
  .enablecnt   (enablecnt),
  .newcnt      (newcnt),
  .newcntwren  (newcntwren),
  .currcntl    (tsvalueb_int[31:0]),
  .currcntu    (tsvalueb_int[63:32]),

  // APB Read-only interface
  .pselread    (pselread),
  .penableread (penableread),
  .pwriteread  (pwriteread),
  .paddrread   (paddrread[11:2]),
  .preadyread  (preadyread),
  .pslverrread (pslverrread),
  .prdataread  (prdataread),

  // APB Control interface
  .pselctrl    (pselctrl),
  .penablectrl (penablectrl),
  .pwritectrl  (pwritectrl),
  .paddrctrl   (paddrctrl[11:2]),
  .pwdatactrl  (pwdatactrl),
  .preadyctrl  (preadyctrl),
  .pslverrctrl (pslverrctrl),
  .prdatactrl  (prdatactrl)

  );

cxtsgencntr
  u_cxtsgencntr(

  // Clock and Reset
  .clk         (clk),
  .resetn      (resetn),

  // Enable normal count operation
  .enablecnt   (enablecnt),

  // Write new count value
  .newcnt      (newcnt),
  .newcntwren  (newcntwren),

  // Time Stamp Encoder
  .tsvalueb    (tsvalueb_int),
  .tsforcesync (tsforcesync)

  );

  assign tsvalueb = tsvalueb_int;

endmodule
