//-----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2004-2015 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//    Checked In : $Date: 2014-06-25 08:42:22 +0100 (Wed, 25 Jun 2014) $
//    Revision   : $Revision: 39629 $
//    Release    : CoreSight-SoC-TM100-r3p2-00rel0
//-----------------------------------------------------------------------------
//  Purpose             : Double Synchronizer for FIFO module in TPIU block.
//-----------------------------------------------------------------------------

module cxtpiu_trace_sync
  (
  // Inputs
  traceclkin, tresetn, ffcr_ften_reg, trig_port, rd_wr_req_t, wr_ptr_gray,
  ft_stopped,
  // Outputs
  formatter_enable, continous_mode, trig_port_sync, rd_wr_req_t_sync,
  wr_ptr_gray_sync, ft_stopped_sync
  );


  // Inputs
  input         traceclkin;      // Trace clock
  input         tresetn;         // Trace asychronous reset active low

  input [1:0]   ffcr_ften_reg;   // Enable formatting from the pclkdbg domain
  input         trig_port;       // Trigger event embedding from atclk domain
  input         rd_wr_req_t;     // Read write request from the PLCK domain
  input [3:0]   wr_ptr_gray;     // Write pointer from the atclk clock domain
  input         ft_stopped;      // Formatter Status

  // Outputs
  output        formatter_enable;// Enable formatting to the traceclkin domain
  output        continous_mode;  // Continuous mode to the traceclkin domain
  output        trig_port_sync;  // Trace trigger to the traceclkin domain
  output        rd_wr_req_t_sync;// Read write request to the traceclkin domain
  output [3:0]  wr_ptr_gray_sync;// Write pointer to the read clock domain
  output        ft_stopped_sync; // Formatter status to the traceclkin domain

  // ---------------------------------------------------------------------------
  //                            Synchronizers For traceclkin Domain
  //                            ===================================
  // ---------------------------------------------------------------------------
  // Overview
  // ========
  // Synchronizers for the signals of the TPIU block in the traceclkin domain.
  // Converts: ffcr_ften_reg (RegP) from pclkdbg
  //           trig_port (FtCtl) from atclk
  //           rd_wr_req_t (ApbIf) from pclkdbg
  //           wr_ptr_gray (AtbFIFO) from atclk
  //           ft_stopped (Formatter) from atclk
  // ---------------------------------------------------------------------------

  // ---------------------------------------------------------------------------
  // Instantiating the cx_sync module for synchronizing wr_ptr_gray[0] bit.
  // ---------------------------------------------------------------------------
  cx_sync u_wr_ptr_gray_0 (
                          // Outputs
                          .sync_do          (wr_ptr_gray_sync[0]),
                          // Inputs
                          .clk              (traceclkin),
                          .resetn           (tresetn),
                          .sync_di          (wr_ptr_gray[0]));

  // ---------------------------------------------------------------------------
  // Instantiating the cx_sync module for synchronizing wr_ptr_gray[1] bit.
  // ---------------------------------------------------------------------------
  cx_sync u_wr_ptr_gray_1 (
                          // Outputs
                          .sync_do          (wr_ptr_gray_sync[1]),
                          // Inputs
                          .clk              (traceclkin),
                          .resetn           (tresetn),
                          .sync_di          (wr_ptr_gray[1]));

  // ---------------------------------------------------------------------------
  // Instantiating the cx_sync module for synchronizing wr_ptr_gray[2] bit.
  // ---------------------------------------------------------------------------
  cx_sync u_wr_ptr_gray_2 (
                          // Outputs
                          .sync_do          (wr_ptr_gray_sync[2]),
                          // Inputs
                          .clk              (traceclkin),
                          .resetn           (tresetn),
                          .sync_di          (wr_ptr_gray[2]));

  // ---------------------------------------------------------------------------
  // Instantiating the cx_sync module for synchronizing wr_ptr_gray[3] bit.
  // ---------------------------------------------------------------------------
  cx_sync u_wr_ptr_gray_3 (
                          // Outputs
                          .sync_do          (wr_ptr_gray_sync[3]),
                          // Inputs
                          .clk              (traceclkin),
                          .resetn           (tresetn),
                          .sync_di          (wr_ptr_gray[3]));

  // ---------------------------------------------------------------------------
  // Instantiating the cx_sync module for synchronizing rd_wr_req_t bit.
  // ---------------------------------------------------------------------------
  cx_sync u_rd_wr_req_t   (
                          // Outputs
                          .sync_do          (rd_wr_req_t_sync),
                          // Inputs
                          .clk              (traceclkin),
                          .resetn           (tresetn),
                          .sync_di          (rd_wr_req_t));

  // ---------------------------------------------------------------------------
  // Instantiating the cx_sync module for synchronizing ffcr_ften_reg[0] bit.
  // ---------------------------------------------------------------------------
  cx_sync u_ffcr_ften_reg_0 (
                            // Outputs
                            .sync_do          (formatter_enable),
                            // Inputs
                            .clk              (traceclkin),
                            .resetn           (tresetn),
                            .sync_di          (ffcr_ften_reg[0]));

  // ---------------------------------------------------------------------------
  // Instantiating the cx_sync module for synchronizing ffcr_ften_reg bit.
  // ---------------------------------------------------------------------------
  cx_sync u_ffcr_ften_reg_1  (
                            // Outputs
                            .sync_do          (continous_mode),
                            // Inputs
                            .clk              (traceclkin),
                            .resetn           (tresetn),
                            .sync_di          (ffcr_ften_reg[1]));

  // ---------------------------------------------------------------------------
  // Instantiating the cx_sync module for synchronizing t_on_trig_evt_detect bit.
  // ---------------------------------------------------------------------------
  cx_sync u_trig_port (
                        // Outputs
                        .sync_do          (trig_port_sync),
                        // Inputs
                        .clk              (traceclkin),
                        .resetn           (tresetn),
                        .sync_di          (trig_port));

  // ---------------------------------------------------------------------------
  // Instantiating the cx_sync module for synchronizing ft_stopped bit.
  // ---------------------------------------------------------------------------
  cx_sync u_ft_stopped (
                        // Outputs
                        .sync_do          (ft_stopped_sync),
                        // Inputs
                        .clk              (traceclkin),
                        .resetn           (tresetn),
                        .sync_di          (ft_stopped));
endmodule
