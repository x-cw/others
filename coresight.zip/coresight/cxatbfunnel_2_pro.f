$GP3_RTL/coresight/rtl/coresight_component/trace_module/cxatbfunnel_2_pro/verilog/cxatbfunnel_2_pro.v
$GP3_RTL/coresight/rtl/coresight_component/trace_module/cxatbfunnel_2_pro/verilog/cxatbfunnel_apb_if_2_pro.v
$GP3_RTL/coresight/rtl/coresight_component/trace_module/cxatbfunnel_2_pro/verilog/cxatbfunnel_arbiter_2_pro.v
$GP3_RTL/coresight/rtl/coresight_component/trace_module/cxatbfunnel_2_pro/verilog/cxatbfunnel_reg_blk_2_pro.v
