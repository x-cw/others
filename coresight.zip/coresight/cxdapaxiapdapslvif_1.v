
//--========================================================================
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2012-2015 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//  Version and Release Control Information:
//
//  File Name           : cxdapaxiapdapslvif_xmlcfg.v.xsl
//
//  Checked In          : $Date: 2015-03-09 14:04:25 +0000 (Mon, 09 Mar 2015) $
//
//  File Revision       : $Revision: 41969 $
//
//  Release Information : CoreSight-SoC-TM100-r3p2-00rel0
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// Abstract : CoreSight AXIAP DAP Slave Interface
//-----------------------------------------------------------------------------
//
// cxdapaxiap - CoreSight AXIAP DAP Slave Interface
// ---------------------------------------------
//
//-----------------------------------------------------------------------------

module cxdapaxiapdapslvif_1 (

  // Clock and Reset
  input wire            clk,
  input wire            resetn,

  // DAP Interface
  input wire [5:0]      dapcaddr,
  input wire            dapsel,
  input wire            dapenable,
  input wire            dapwrite,
  input wire [31:0]     dapwdata,
  input wire            dapabort,
  output wire [31:0]    daprdata,
  output wire           dapready,
  output wire           dapslverr,

  // Reg Block interface
  output wire           bnk_sel_0,
  output wire           bnk_sel_1,
  output wire           bnk_sel_2,
  output wire           bnk_sel_15,
  output wire [3:0]     reg_sel,
  output wire           wr_en,
  output wire [31:0]    wdata,
  output wire           rd_en,
  output wire           abrt_req,
  input wire [31:0]     rdata,
  input wire            rdy,
  input wire            err_resp

  );

//------------------------------------------------------------------------------
// Defines
//------------------------------------------------------------------------------
  localparam BANK0 = 4'h0;
  localparam BANK1 = 4'h1;
  localparam BANK2 = 4'h2;
  localparam BANK15 = 4'hF;

  localparam REG0 = 2'b00;
  localparam REG1 = 2'b01;
  localparam REG2 = 2'b10;
  localparam REG3 = 2'b11;

//----------------------------------------------------------------------------
// Wires
//----------------------------------------------------------------------------
  wire en_acc;
  wire int_abrt_req;
  wire dap_ready_rg_next;
  wire dap_ready_rg_en;

//----------------------------------------------------------------------------
// Reg
//----------------------------------------------------------------------------
  reg dap_ready_rg;

//============================================================================
//
// Main body of code
//
//============================================================================

//----------------------------------------------------------------------------
// When DAPSEL is high and DAPENABLE is low, it indicates the first cycle of
// the two-cycle access. This will be used to generate a response in the next
// cycle.
//----------------------------------------------------------------------------
  assign en_acc = dapsel & (~dapenable);

  assign bnk_sel_0 = en_acc & (dapcaddr[5:2] == BANK0);
  assign bnk_sel_1 = en_acc & (dapcaddr[5:2] == BANK1);
  assign bnk_sel_2 = en_acc & (dapcaddr[5:2] == BANK2);
  assign bnk_sel_15 = en_acc & (dapcaddr[5:2] == BANK15);

  assign reg_sel[0] = en_acc & (dapcaddr[1:0] == REG0);
  assign reg_sel[1] = en_acc & (dapcaddr[1:0] == REG1);
  assign reg_sel[2] = en_acc & (dapcaddr[1:0] == REG2);
  assign reg_sel[3] = en_acc & (dapcaddr[1:0] == REG3);

  assign wr_en = en_acc & dapwrite;

  assign wdata = dapwdata;

  assign rd_en = en_acc & (~dapwrite);

  assign daprdata = rdata;

//-----------------------------------------------------------------------------
// Abort request can only be generated when the transfer is still in progress
// Hence an abort condition is possible only when AXI-AP is selected along with
// DAPENABLE being high and DAPABORT is asserted
//-----------------------------------------------------------------------------
  assign int_abrt_req = dapsel & (dapenable & dapabort);

  assign abrt_req = int_abrt_req;

  assign dapslverr = err_resp;

  assign dap_ready_rg_next = dap_ready_rg ? ~rdy : int_abrt_req;

  assign dap_ready_rg_en = (dap_ready_rg ^ dap_ready_rg_next);

  always @ (posedge clk or negedge resetn)
    if (!resetn) begin
      dap_ready_rg <= 1'b1;
    end else if (dap_ready_rg_en) begin
      dap_ready_rg <= dap_ready_rg_next;
    end

  assign dapready = dap_ready_rg | rdy;

endmodule
