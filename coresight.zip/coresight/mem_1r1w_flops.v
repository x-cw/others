module mem_1r1w_flops
  #( parameter
     MEM_WORDS=0,
     MEM_WIDTH=1,
     MEM_BIT_EN=0,
     L2_MEM_WORDS=0
    ) (
       input wire [MEM_WIDTH-1:0]    din,
       input wire [L2_MEM_WORDS-1:0] rd_addr,
       input wire                    rd_clk,
       input wire                    rd_en,

       input wire [L2_MEM_WORDS-1:0] wr_addr,
       input wire                    wr_clk,
       input wire                    wr_en,
       input wire [MEM_WIDTH-1:0]    bit_en_internal,

       output wire [MEM_WIDTH-1:0]   dout_internal
       );

  localparam HOLD_DOUT=1; //toshiba holds dout on 1r1w regfile

  `ifdef FPGA
  localparam BYTE_WIDTH = MEM_WIDTH % 8 == 0 ? 8 : 
                          MEM_WIDTH % 9 == 0 ? 9 :
                          1;
  
  localparam WE_WIDTH= (MEM_WIDTH % BYTE_WIDTH) == 0 ? 
                       MEM_WIDTH / BYTE_WIDTH :
                       (MEM_WIDTH - (MEM_WIDTH % BYTE_WIDTH))/BYTE_WIDTH + 1;
  `else
  localparam BYTE_WIDTH=1;
  localparam WE_WIDTH=MEM_WIDTH;
  `endif

  
// `ifndef SYNTHESIS
//  // VCS coverage off
//  event                          dv_bd_wr;
//  event                          dv_bd_wr_ack;
//  reg [L2_MEM_WORDS-1:0]         dv_bd_wr_addr;
//  reg [MEM_WIDTH-1:0]            dv_bd_wr_bit_en;
//  reg [MEM_WIDTH-1:0]            dv_bd_din;
//  
//  event                          dv_bd_rd;
//  event                          dv_bd_rd_ack;
//  reg [L2_MEM_WORDS-1:0]         dv_bd_rd_addr;
//  reg [MEM_WIDTH-1:0]            dv_bd_dout;
//  // VCS coverage on
// `endif  

  generate
    genvar i;
    if (MEM_BIT_EN) begin: bit_en

      //`ifndef SYNTHESIS
      //localparam MEM_WIDTH_DIV_8 = WE_WIDTH * BYTE_WIDTH + 1;

      //wire [MEM_WIDTH_DIV_8-1:0] bit_wider = {{(MEM_WIDTH_DIV_8-MEM_WIDTH){bit_en_internal[MEM_WIDTH-1]}},
      //                                        bit_en_internal};
      //
      //for(i=0;i<MEM_WIDTH;i=i+BYTE_WIDTH) begin: bit_byte_check
      //  bit_byte_mismatch: assert property (@(posedge wr_clk)
      //                                      wr_en |->  &bit_wider[i+:BYTE_WIDTH] == |bit_wider[i+:BYTE_WIDTH]) else
      //    $error("Invalid number bit enable setting [%0d:%0d]",i+BYTE_WIDTH-1,i);
      //end

      //`endif

      wire [WE_WIDTH-1:0] we;
      for(i=0;i<WE_WIDTH;i=i+1) begin: we_gen
        assign we[i]=bit_en_internal[i*BYTE_WIDTH];
      end

     // `ifndef SYNTHESIS
     // // VCS coverage off
     // // Backdoor Access Interface:
     // event dv_bd_sub_wr;
     // event dv_bd_sub_wr_ack;
     // int   dv_bd_sub_wr_index;
     // wire [WE_WIDTH-1:0] dv_bd_we;
     // for(i=0;i<WE_WIDTH;i=i+1) begin: dv_bd_we_gen
     //   assign dv_bd_we[i]=dv_bd_wr_bit_en[i*BYTE_WIDTH];
     // end
     // always @(dv_bd_wr) begin: wr_loop
     //   int s;
     //   for(s=0;s<WE_WIDTH;s++) begin
     //     dv_bd_sub_wr_index = s;
     //     ->dv_bd_sub_wr;
     //     @(dv_bd_sub_wr_ack);
     //   end
     //   ->dv_bd_wr_ack;
     // end
     // event dv_bd_sub_rd;
     // event dv_bd_sub_rd_ack;
     // int   dv_bd_sub_rd_index;
     // always @(dv_bd_rd) begin: rd_loop
     //   int s;
     //   for(s=0;s<WE_WIDTH;s++) begin
     //     dv_bd_sub_rd_index = s;
     //     ->dv_bd_sub_rd;
     //     @(dv_bd_sub_rd_ack);
     //   end
     //   ->dv_bd_rd_ack;
     // end
     // // VCS coverage on
     //`endif

      for(i=0;i<WE_WIDTH;i=i+1) begin: memory
        reg [BYTE_WIDTH-1:0] ramarray [MEM_WORDS-1:0];

        // write port
        always @(posedge wr_clk) begin
          if (wr_en && we[i]) begin
            ramarray[wr_addr] <= din[BYTE_WIDTH*i+:BYTE_WIDTH];
          end
        end
        
        reg [BYTE_WIDTH-1:0] dout_fpga_internal;
        
        assign dout_internal[BYTE_WIDTH*i+:BYTE_WIDTH]=dout_fpga_internal;
      
        // read port
        always @(posedge rd_clk) begin
          if (rd_en) begin
            dout_fpga_internal <= ramarray[rd_addr];
          end
      //`ifndef SYNTHESIS
      //    else if (HOLD_DOUT==0 ||
      //             (rd_en && wr_en && rd_addr==wr_addr)
      //             )
      //      dout_fpga_internal<={BYTE_WIDTH{1'bx}};
      //`endif
        end
        
     // `ifndef SYNTHESIS
     //   // VCS coverage off
     //   // Backdoor Access Interface:
     //   always @(dv_bd_sub_wr) begin
     //     if (dv_bd_sub_wr_index == i) begin
     //       if (dv_bd_we[i]) begin
     //         ramarray[dv_bd_wr_addr] = dv_bd_din[BYTE_WIDTH*i+:BYTE_WIDTH];
     //       end
     //       ->dv_bd_sub_wr_ack;
     //     end
     //   end
     //   always @(dv_bd_sub_rd) begin
     //     if (dv_bd_sub_rd_index == i) begin
     //       dv_bd_dout[BYTE_WIDTH*i+:BYTE_WIDTH] = ramarray[dv_bd_rd_addr];
     //       ->dv_bd_sub_rd_ack;
     //     end
     //   end
     //   // VCS coverage on
     // `endif
     end

      
    end else begin: no_bit_en

      reg [MEM_WIDTH-1:0] ramarray [MEM_WORDS-1:0];
     
      // write port
      always @(posedge wr_clk) begin
        if (wr_en) begin
          ramarray[wr_addr] <= din;
        end
      end
    
      reg [MEM_WIDTH-1:0] dout_fpga_internal;
      
      assign dout_internal=dout_fpga_internal;
      
      // read port
      always @(posedge rd_clk) begin
        if (rd_en) begin
          dout_fpga_internal <= ramarray[rd_addr];
        end
      //`ifndef SYNTHESIS
      //  else if (HOLD_DOUT==0 ||
      //           (rd_en && wr_en && rd_addr==wr_addr)
      //           )
      //    dout_fpga_internal<={MEM_WIDTH{1'bx}};
      //`endif
      end

     // `ifndef SYNTHESIS
     // // VCS coverage off
     // // Backdoor Access Interface:
     // always @(dv_bd_wr) begin
     //   ramarray[dv_bd_wr_addr] = dv_bd_din;
     //   ->dv_bd_wr_ack;
     // end
     // always @(dv_bd_rd) begin
     //   dv_bd_dout = ramarray[dv_bd_rd_addr];
     //   ->dv_bd_rd_ack;
     // end
     // // VCS coverage on
     // `endif

    end
  endgenerate
  
endmodule
