//-----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2010-2015 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//  Version and Release Control Information:
//
//  File Name           : cxatbreplicator_xmlcfg.v.xsl
//
//  Checked In          : $Date: 2015-02-16 14:55:41 +0000 (Mon, 16 Feb 2015) $
//
//  File Revision       : $Revision: 41661 $
//
//  Release Information : CoreSight-SoC-TM100-r3p2-00rel0
//----------------------------------------------------------------------------
// Verilog-2001 (IEEE Std 1364-2001)
//----------------------------------------------------------------------------


//-----------------------------------------------------------------------------
// Abstract : CoreSight Replicator (cxatbreplicator)
//-----------------------------------------------------------------------------
//
// cxatbreplicator - CoreSight Replicator
// --------------------------------------
//
// CoreSight AMBA Trace Bus (ATB) Replicator for duplicating ATB Slave
// traffic onto two ATB master ports
//-----------------------------------------------------------------------------


module cxatbreplicator_128 (
  // Inputs
  input wire         clk,          // ATB clock
  input wire         resetn,       // ATB reset


    // Debug APB Slave interface
  input wire         pclkendbg,    // APB Clock enable
  input wire         pseldbg,      // APB select line
  input wire         penabledbg,   // APB enable line
  input wire         pwritedbg,    // Write/Read control line
  input wire         paddrdbg31,   // APB address bit 31
  input wire  [11:2] paddrdbg,     // APB address line to select register
  input wire  [31:0] pwdatadbg,    // APB data line
  output wire        preadydbg,    // APB transfer completion indication
  output wire        pslverrdbg,   // APB response
  output wire [31:0] prdatadbg,    // APB read data line

  input wire         atvalids,     // Indication of valid ATB transfer
  input wire   [6:0] atids,        // ID's for ATB transfers

  input wire   [3:0] atbytess,     // Indication of number of valid bytes
  input wire [127:0]  atdatas,
                                   // ATB data
  input wire         afreadys,     // Indication to flush the internal buffer
  input wire         atreadym0,    // Indication of acceptance of ATB transfer on M0
  input wire         atreadym1,    // Indication of acceptance of ATB transfer on M1
  input wire         afvalidm0,    // Indication to flush the internal buffer on M0
  input wire         afvalidm1,    // Indication to flush the internal buffer on M1
  input wire         syncreqm0,    // Indication to send sync packets on M0
  input wire         syncreqm1,    // Indication to send sync packets on M1
  // Outputs
  output wire        atreadys,     // Indication of acceptance of ATB transfer
  output wire        afvalids,     // Indication to flush the internal buffer
  output wire        atvalidm0,    // Indication of valid ATB transfer on M0
  output wire        atvalidm1,    // Indication of valid ATB transfer on M1
  output wire [6:0]  atidm0,       // ID's for ATB transfers on M0
  output wire [6:0]  atidm1,       // ID's for ATB transfers on M1

  output wire [3:0]  atbytesm0,    // Indication of number of valid bytes
  output wire [3:0]  atbytesm1,    // Indication of number of valid bytes
  output wire [127:0] atdatam0,
                                   // ATB data
  output wire [127:0] atdatam1,
                                   // ATB data
  output wire        afreadym0,    // Indication to flush the internal buffer
  output wire        afreadym1,    // Indication to flush the internal buffer
  output reg         syncreqs      // Indication to send sync packets
  );

//------------------------------------------------------------------------------
// Local parameters definitions
//------------------------------------------------------------------------------
  localparam CSR_F_IDLE       = 3'b000;
  localparam CSR_F_REQ_0      = 3'b001;
  localparam CSR_F_REQ_1      = 3'b010;
  localparam CSR_F_REQ_01     = 3'b011;
  localparam CSR_F_REQ_10     = 3'b100;
  localparam CSR_F_REQ_A      = 3'b101;
  localparam CSR_F_REQ_U0     = 3'b110;
  localparam CSR_F_REQ_U1     = 3'b111;
  localparam CSR_F_UNDEF      = 3'bXXX;

  localparam CSR_T_UNDEF      = 2'bXX;
  localparam CSR_T_IDLE       = 2'b00;
  localparam CSR_T_PEND_A     = 2'b01;
  localparam CSR_T_PEND_0     = 2'b10;
  localparam CSR_T_PEND_1     = 2'b11;



  localparam CSR_IDFILTER_0     = 10'h000; // IDFILTER0 register
  localparam CSR_IDFILTER_1     = 10'h001; // IDFILTER1 register
  localparam CSR_IT_ATB_CTR_1   = 10'h3BE; // Integration Register
  localparam CSR_IT_ATB_CTR_0   = 10'h3BF; // Integration Register
  localparam CSR_IT_CTRL        = 10'h3C0; // Integration control register
  localparam CSR_CLAIMSET       = 10'h3E8; // Claim tag set register
  localparam CSR_CLAIMCLR       = 10'h3E9; // Claim tag clear register
  localparam CSR_LOCKACCESS     = 10'h3EC; // Lock access register
  localparam CSR_LOCKSTATUS     = 10'h3ED; // Lock status register
  localparam CSR_AUTHSTATUS     = 10'h3EE; // Authentication status register
  localparam CSR_DEVICEID       = 10'h3F2; // Device identification register
  localparam CSR_DEVICETYPE     = 10'h3F3; // Device type register
  localparam CSR_PERIPH_ID_4    = 10'h3F4; // Peripheral ID4 register
  localparam CSR_PERIPH_ID_5    = 10'h3F5; // Peripheral ID5 register
  localparam CSR_PERIPH_ID_6    = 10'h3F6; // Peripheral ID6 register
  localparam CSR_PERIPH_ID_7    = 10'h3F7; // Peripheral ID7 register
  localparam CSR_PERIPH_ID_0    = 10'h3F8; // Peripheral ID0 register
  localparam CSR_PERIPH_ID_1    = 10'h3F9; // Peripheral ID1 register
  localparam CSR_PERIPH_ID_2    = 10'h3FA; // Peripheral ID2 register
  localparam CSR_PERIPH_ID_3    = 10'h3FB; // Peripheral ID3 register
  localparam CSR_COMP_ID_0      = 10'h3FC; // Component ID0 register
  localparam CSR_COMP_ID_1      = 10'h3FD; // Component ID1 register
  localparam CSR_COMP_ID_2      = 10'h3FE; // Component ID2 register
  localparam CSR_COMP_ID_3      = 10'h3FF; // Component ID3 register


  //-----------------------------------------------------------------------------
  // Replicator Register read values for read-only fields
  //-----------------------------------------------------------------------------
  localparam CSR_CLAIMSET_VAL           = 4'hF;     // Claim Tag Size
  localparam CSR_LOCKSTATUS_8BIT_VAL    = 1'b0;     // Lock Access Not 8-bit
  localparam CSR_LOCKSTATUS_PRESENT_VAL = 1'b1;     // Lock Access Present
  localparam CSR_DEVTYPE_VAL            = 8'h22;    // Device Type reg
  localparam CSR_DEVICEID_VAL           = 8'h02;     // Device ID reg
  localparam CSR_PERIPHID4_VAL          = 8'h04;    // Peripheral ID4 reg
  localparam CSR_PERIPHID5_VAL          = 8'h00;    // Peripheral ID5 reg
  localparam CSR_PERIPHID6_VAL          = 8'h00;    // Peripheral ID6 reg
  localparam CSR_PERIPHID7_VAL          = 8'h00;    // Peripheral ID7 reg
  localparam CSR_PERIPHID0_VAL          = 8'h09;    // Peripheral ID0 reg
  localparam CSR_PERIPHID1_VAL          = 8'hB9;    // Peripheral ID1 reg
  localparam CSR_PERIPHID2_VAL          = 8'h2B;    // Peripheral ID2 reg
  localparam PERIPHID3_CUSTOM           = 4'h0;     // Peripheral ID3 value
  localparam PERIPHID3_REVAND           = 4'h0;     // Peripheral ID3 value
  localparam CSR_COMPID0_VAL            = 8'h0D;    // Component ID0 reg
  localparam CSR_COMPID1_VAL            = 8'h90;    // Component ID1 reg
  localparam CSR_COMPID2_VAL            = 8'h05;    // Component ID2 reg
  localparam CSR_COMPID3_VAL            = 8'hB1;    // Component ID3 reg

  localparam CSR_AUTHSTATUS_SNID_VAL    = 1'b0; // Secure non-invasive
  localparam CSR_AUTHSTATUS_SID_VAL     = 1'b0; // Secure invasive
  localparam CSR_AUTHSTATUS_NSNID_VAL   = 1'b0; // Non-secure non-invasive
  localparam CSR_AUTHSTATUS_NSID_VAL    = 1'b0; // Non-secure invasive




  //----------------------------------------------------------------------------
  // Wires AND Regs declarations
  //----------------------------------------------------------------------------


  reg [11:2]  paddrdbg_r;
  reg [3:0]   revand_reg;
  reg         paddrdbg31_r;
  wire        nxt_apb_valid;
  // wire [31:0] nxt_prdatadbg;
  wire [31:0] read_data;
  reg         apb_valid;
  wire [11:2] apb_addr;
  wire        apb_addr31;
  reg  [31:0] apb_wdata;
  reg         pseldbg_r;
  reg         pwritedbg_r;
  wire        reg_wr_en;
  // Device unlocked and register write detected

  wire        nxt_dev_unlocked;
  // D-input of dev_unlocked

  wire [3:0]  nxt_claim_tag;
  // D-input of Claim Tag register
  wire idfilter_0_sel; // Address decode for IDFILTER0 register
  wire idfilter_1_sel; // Address decode for IDFILTER1 register
  wire it_atb_ctr_1_sel;
  wire it_atb_ctr_0_sel;
  wire it_ctrl_sel;
  reg it_ctrl;
  wire claim_tag_set_sel;
  wire claim_tag_clr_sel;
  wire lock_acc_sel;
  wire lock_status_sel;
  wire device_id_sel;
  wire device_type_sel;
  wire periph_id_0_sel;
  wire periph_id_1_sel;
  wire periph_id_2_sel;
  wire periph_id_3_sel;
  wire periph_id_4_sel;
  wire periph_id_5_sel;
  wire periph_id_6_sel;
  wire periph_id_7_sel;
  wire comp_id_0_sel;
  wire comp_id_1_sel;
  wire comp_id_2_sel;
  wire comp_id_3_sel;
  wire idfilter_0_wr_en;
  wire idfilter_1_wr_en;
  wire it_ctrl_wr_en;
  wire claim_tag_wr_en;
  wire lock_access_wr_en;
  wire it_atb_ctr_0_wr_en;
  wire reg_write;
  wire reg_read;
  wire idfilter_0_rd_en;
  wire idfilter_1_rd_en;
  wire it_atb_ctr_1_rd_en;
  wire it_atb_ctr_0_rd_en;
  wire it_ctrl_rd_en;
  wire claim_tag_set_rd_en;
  wire claim_tag_clr_rd_en;
  wire lock_status_rd_en;
  wire auth_status_rd_en;
  wire device_id_rd_en;
  wire device_type_rd_en;
  wire periph_id_0_rd_en;
  wire periph_id_1_rd_en;
  wire periph_id_2_rd_en;
  wire periph_id_3_rd_en;
  wire periph_id_4_rd_en;
  wire periph_id_5_rd_en;
  wire periph_id_6_rd_en;
  wire periph_id_7_rd_en;
  wire comp_id_0_rd_en;
  wire comp_id_1_rd_en;
  wire comp_id_2_rd_en;
  wire comp_id_3_rd_en;
  wire [2:0] it_atb_ctr_0_wr_data;
  wire [31:0] it_atb_ctr_1_rd_data;
  wire [31:0] it_atb_ctr_0_rd_data;
  wire [31:0] it_ctrl_rd_data;
  wire [31:0] claim_tag_set_rd_data;
  wire [31:0] claim_tag_clr_rd_data;
  wire [31:0] lock_status_rd_data;
  wire [31:0] auth_status_rd_data;
  wire [31:0] device_id_rd_data;
  wire [31:0] device_type_rd_data;
  wire [31:0] periph_id_0_rd_data;
  wire [31:0] periph_id_1_rd_data;
  wire [31:0] periph_id_2_rd_data;
  wire [31:0] periph_id_4_rd_data;
  wire [31:0] periph_id_3_rd_data;
  wire [31:0] periph_id_5_rd_data;
  wire [31:0] periph_id_6_rd_data;
  wire [31:0] periph_id_7_rd_data;
  wire [31:0] comp_id_0_rd_data;
  wire [31:0] comp_id_1_rd_data;
  wire [31:0] comp_id_2_rd_data;
  wire [31:0] comp_id_3_rd_data;
  reg        dev_unlocked;        // Writes to Replicator registers allowed
  reg [3:0]  claim_tag;       // Claim Tag register
  reg [7:0]  idfilter_0;
  reg [7:0]  idfilter_1;
  wire discard_master_0;
  wire discard_master_1;
  reg       it_atb_ctr_1_atreadym0_reg;
  reg       it_atb_ctr_1_atreadym1_reg;
  reg       it_atb_ctr_1_atvalids_reg;
  reg       it_atb_ctr_0_atreadys;
  reg       it_atb_ctr_0_atvalidm1;
  reg       it_atb_ctr_0_atvalidm0;
  reg       apb_valid_reg;

  wire atreadym0_mod;
  wire atreadym1_mod;

  reg [2:0] flush_state;           // Flush FSM
  reg [2:0] nxt_flush_state;       // D-input of flush_state
  reg [1:0] transfer_state;        // Data transfer FSM
  reg [1:0] nxt_transfer_state;    // D-input of transfer_state
  wire      nxt_syncreqs;          // D-input of syncreqs
  wire      sync_flag_m0_we;       // write enable for sync_flag_m0
  wire      sync_flag_m1_we;       // write enable for sync_flag_m1
  reg       sync_req_m0_reg;       // Registered version of syncreqm0
  reg       sync_req_m1_reg;       // egistered version of syncreqm1
  reg       sync_flag_m0;          // Flag to indicate syncreqm0 was serviced
  reg       sync_flag_m1;          // Flag to indicate syncreqm0 was serviced

  //============================================================================
  //
  // Main body of code
  // =================
  //
  //============================================================================


  // APB registered address and write data
  always @(posedge clk)
  begin
    if (pclkendbg)
    begin
      pwritedbg_r       <= pwritedbg;
      paddrdbg_r[11:2]  <= paddrdbg[11:2];
      paddrdbg31_r      <= paddrdbg31;
      apb_wdata[31:0]   <= pwdatadbg[31:0];
    end
  end

// Register pseldbg
  always @(posedge clk or negedge resetn)
  begin
    if (!resetn)
      pseldbg_r  <= 1'b0;
    else if (pclkendbg)
      pseldbg_r  <= pseldbg;
  end

  // APB read data
  assign prdatadbg[31:0] = (~pwritedbg_r & apb_valid) ?
                                 read_data[31:0] : 32'b0;

  // transaction is valid on internal interface
  //  - as soon as registered APB first phase is set
  //  - until ready is returned
  assign nxt_apb_valid = (pseldbg & ~penabledbg);

  always @(posedge clk or negedge resetn)
  begin
    if (!resetn)
      apb_valid  <= 1'b0;
    else if (pclkendbg)
      apb_valid  <= nxt_apb_valid;
  end

  assign preadydbg = 1'b1;
  assign pslverrdbg = 1'b0;

  //-----------------------------------------------------------------------------
  // Prevent toggle on the internal address bus when the device is not
  // selected.
  //-----------------------------------------------------------------------------
  assign apb_addr = paddrdbg_r & {10{pseldbg_r}};
  assign apb_addr31 = paddrdbg31_r & pseldbg_r;


  assign idfilter_0_sel    = (apb_addr == CSR_IDFILTER_0);
  assign idfilter_1_sel    = (apb_addr == CSR_IDFILTER_1);
  assign it_atb_ctr_1_sel  = (apb_addr == CSR_IT_ATB_CTR_1);
  assign it_atb_ctr_0_sel  = (apb_addr == CSR_IT_ATB_CTR_0);
  assign it_ctrl_sel       = (apb_addr == CSR_IT_CTRL);
  assign claim_tag_set_sel = (apb_addr == CSR_CLAIMSET);
  assign claim_tag_clr_sel = (apb_addr == CSR_CLAIMCLR);
  assign lock_acc_sel      = (apb_addr == CSR_LOCKACCESS);
  assign lock_status_sel   = (apb_addr == CSR_LOCKSTATUS);
  assign device_id_sel     = (apb_addr == CSR_DEVICEID);
  assign device_type_sel   = (apb_addr == CSR_DEVICETYPE);
  assign periph_id_0_sel   = (apb_addr == CSR_PERIPH_ID_0);
  assign periph_id_1_sel   = (apb_addr == CSR_PERIPH_ID_1);
  assign periph_id_2_sel   = (apb_addr == CSR_PERIPH_ID_2);
  assign periph_id_3_sel   = (apb_addr == CSR_PERIPH_ID_3);
  assign periph_id_4_sel   = (apb_addr == CSR_PERIPH_ID_4);
  assign periph_id_5_sel   = (apb_addr == CSR_PERIPH_ID_5);
  assign periph_id_6_sel   = (apb_addr == CSR_PERIPH_ID_6);
  assign periph_id_7_sel   = (apb_addr == CSR_PERIPH_ID_7);
  assign comp_id_0_sel     = (apb_addr == CSR_COMP_ID_0);
  assign comp_id_1_sel     = (apb_addr == CSR_COMP_ID_1);
  assign comp_id_2_sel     = (apb_addr == CSR_COMP_ID_2);
  assign comp_id_3_sel     = (apb_addr == CSR_COMP_ID_3);

  //---------------------------------------------------------------------------
  // Generate a delayed version of apb_valid to detect a rising edge
  //---------------------------------------------------------------------------
  always @(posedge clk or negedge resetn)
  begin
    if (!resetn)
      apb_valid_reg  <= 1'b0;
    else if (pclkendbg)
      apb_valid_reg  <= apb_valid;
  end

  assign reg_write = pwritedbg_r & (apb_valid & ~apb_valid_reg) & pclkendbg;
  assign reg_read  = ~pwritedbg_r & apb_valid;

//-----------------------------------------------------------------------------
// Writes to the LOCKACCESS register are allowed only when PADDRDBG31 is low.
// For external debuggers (PADDRDBG31 = 1), no lock mechanism is necessary.
// Unlock the device if 32'hC5ACCE55 is written to the LOCKACCESS register.
//-----------------------------------------------------------------------------
  assign lock_access_wr_en = reg_write & lock_acc_sel & ~apb_addr31;
  assign nxt_dev_unlocked = (apb_wdata == 32'hC5ACCE55);

//-----------------------------------------------------------------------------
// Sequential block for writing into the lock access register.
// Lock Access register    : Offset 0xFB0 ( W )
//-----------------------------------------------------------------------------
  always @(posedge clk or negedge resetn)
  begin : p_dev_unlocked
    if (!resetn)
      dev_unlocked <= 1'b0;
    else if(lock_access_wr_en)
      dev_unlocked <= nxt_dev_unlocked;
  end // block: p_dev_unlocked


//-----------------------------------------------------------------------------
// Register Writes are allowed only if the device is unlocked or PADDRDBG31 is
// asserted. External debugger accesses (PADDRDBG31 = 1), are not subject to
// lock checks.
//-----------------------------------------------------------------------------
  assign reg_wr_en = reg_write & (dev_unlocked | apb_addr31) & pclkendbg;


//-----------------------------------------------------------------------------
// Writes to IDFILTER register
//-----------------------------------------------------------------------------
  assign idfilter_0_wr_en = reg_wr_en & idfilter_0_sel & ~it_ctrl;
  assign idfilter_1_wr_en = reg_wr_en & idfilter_1_sel & ~it_ctrl;

  always @(posedge clk or negedge resetn)
  begin : p_idfilter0_seq
      if (!resetn)
        begin
          idfilter_0 <= 8'b0;
        end
      else if (idfilter_0_wr_en)
        begin
          idfilter_0 <= apb_wdata[7:0];
        end
    end // p_idfilter0_seq

  always @(posedge clk or negedge resetn)
  begin : p_idfilter1_seq
      if (!resetn)
        begin
          idfilter_1 <= 8'b0;
        end
      else if (idfilter_1_wr_en)
        begin
          idfilter_1 <= apb_wdata[7:0];
        end
    end // p_idfilter1_seq

//-----------------------------------------------------------------------------
// Write enables for Integration test registers ITATBMCTR0 and ITATBMCTR1
//-----------------------------------------------------------------------------
  assign it_atb_ctr_0_wr_en = reg_wr_en & it_atb_ctr_0_sel & it_ctrl;

  assign it_atb_ctr_0_wr_data = {apb_wdata[4], apb_wdata[2], apb_wdata[0]};

  always @(posedge clk or negedge resetn)
  begin : p_it_ctr0_reg
    if (!resetn)
      {it_atb_ctr_0_atreadys,
       it_atb_ctr_0_atvalidm1,
       it_atb_ctr_0_atvalidm0} <= 3'd0;
    else if (it_atb_ctr_0_wr_en)
      {it_atb_ctr_0_atreadys,
       it_atb_ctr_0_atvalidm1,
       it_atb_ctr_0_atvalidm0} <= it_atb_ctr_0_wr_data;
  end // p_it_ctr0_reg

//-----------------------------------------------------------------------------
// ITCTRL - Integration Mode Control Register.
// When set, the device is in integration mode to enable topology detection
// or integration testing to be carried out. At reset ITCTRL is disabled
//-----------------------------------------------------------------------------
  assign it_ctrl_wr_en = reg_wr_en & it_ctrl_sel;

  always @(posedge clk or negedge resetn)
  begin : p_it_ctrl
    if (!resetn)
      it_ctrl <= 1'b0;
    else if (it_ctrl_wr_en)
      it_ctrl <= apb_wdata[0];
  end // p_it_ctrl

//-----------------------------------------------------------------------------
// Claim tag
// Used by software tools when about to begin an access session to the Replicator
// Setting bits indicates to any other interrogating tools that this device
// is being programmed or has been programmed.
//
// Accessed using two registers:
// 0xFA0 - Claim Tag Set
//       - Read:  0 - claim bit not implemented, 1 - claim bit implemented
//       - Write: 0 - no effect, 1 - set claim bit
//
// 0xFA1 - Claim Tag Clear
//       - Read:  Current value of claim bit
//       - Write: 0 - no effect, 1 - clear claim bit
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
// The claim_tag_wr_en is the enable signal for writing into the claim tag
// register.The enable signal is set when either the claim set or
// claim clear registers is written.
//-----------------------------------------------------------------------------
  assign claim_tag_wr_en = reg_wr_en &
                           (claim_tag_set_sel | claim_tag_clr_sel);

//-----------------------------------------------------------------------------
// Logic for the  nxt_claim_tag value.
// Writing '0' has no effect on the Claim Tag Set register or the Claim Tag
// Clear register.
//-----------------------------------------------------------------------------
  assign  nxt_claim_tag = claim_tag_set_sel ?
                              (claim_tag | apb_wdata[3:0]):
                              (claim_tag & ~apb_wdata[3:0]);

//-----------------------------------------------------------------------------
// Sequential block for writing into the claim tag register.
// Claim tag set register     : Offset 0xFA0 ( R/W )
// Claim tag clear register   : Offset 0xFA4 ( R/W )
//-----------------------------------------------------------------------------
  always @(posedge clk or negedge resetn)
  begin : p_claim_tag_wr
    if (!resetn)
      claim_tag <= {4{1'b0}};
    else if(claim_tag_wr_en)
      claim_tag <=  nxt_claim_tag;
   end // block: p_claim_tag_wr

// IDFILTER0 register
assign idfilter_0_rd_en = reg_read & idfilter_0_sel;

// IDFILTER1 register
assign idfilter_1_rd_en = reg_read & idfilter_1_sel;

// ITATBCTR1 register
assign it_atb_ctr_1_rd_en = reg_read & it_atb_ctr_1_sel;

// ITATBCTR0 register
assign it_atb_ctr_0_rd_en = reg_read & it_atb_ctr_0_sel;

// ITCTRL register
assign it_ctrl_rd_en = reg_read & it_ctrl_sel;

// CLAIMSET register
assign claim_tag_set_rd_en = reg_read & claim_tag_set_sel;

// CLAIMCLR register
assign claim_tag_clr_rd_en = reg_read & claim_tag_clr_sel;

// LOCKSTATUS register
// Mask out the lock status on accesses with PADDRDBG31=='1'
// The OR-of-ANDs gives the appearance of no lock-access mechanism present
assign lock_status_rd_en = reg_read & lock_status_sel & ~apb_addr31;

// Authentication status register
assign auth_status_rd_en = reg_read & (apb_addr == CSR_AUTHSTATUS);

// DEVID register
assign device_id_rd_en = reg_read & device_id_sel;

// DEVTYPE register
assign device_type_rd_en = reg_read & device_type_sel;

// PERIPHIDx registers
assign periph_id_0_rd_en = reg_read & periph_id_0_sel;
assign periph_id_1_rd_en = reg_read & periph_id_1_sel;
assign periph_id_2_rd_en = reg_read & periph_id_2_sel;
assign periph_id_3_rd_en = reg_read & periph_id_3_sel;
assign periph_id_4_rd_en = reg_read & periph_id_4_sel;
assign periph_id_5_rd_en = reg_read & periph_id_5_sel;
assign periph_id_6_rd_en = reg_read & periph_id_6_sel;
assign periph_id_7_rd_en = reg_read & periph_id_7_sel;

// COMPIDx registers
assign comp_id_0_rd_en = reg_read & comp_id_0_sel;
assign comp_id_1_rd_en = reg_read & comp_id_1_sel;
assign comp_id_2_rd_en = reg_read & comp_id_2_sel;
assign comp_id_3_rd_en = reg_read & comp_id_3_sel;

//-----------------------------------------------------------------------------
// Sampling AFVALIDM and ATREADYM for integration register reads
// Sampling helps ease timing through APB read mux from these inputs
//-----------------------------------------------------------------------------
      always @(posedge clk or negedge resetn)
      begin : p_it_atbm_ctr1_reg
        if (!resetn)
          begin
            it_atb_ctr_1_atreadym0_reg <= 1'b0;
            it_atb_ctr_1_atreadym1_reg <= 1'b0;
            it_atb_ctr_1_atvalids_reg  <= 1'b0;
          end
        else
          begin
            it_atb_ctr_1_atreadym0_reg <= atreadym0;
            it_atb_ctr_1_atreadym1_reg <= atreadym1;
            it_atb_ctr_1_atvalids_reg  <= atvalids;
          end
      end // block: p_it_atbm_ctr1_reg

// ITATBCTR1 register
assign it_atb_ctr_1_rd_data = {{28{1'b0}}, it_atb_ctr_1_atvalids_reg, 1'b0, it_atb_ctr_1_atreadym1_reg, it_atb_ctr_1_atreadym0_reg};

// ITATBCTR0 register
assign it_atb_ctr_0_rd_data = {32{1'b0}};

// ITCTRL register
assign it_ctrl_rd_data = {{31{1'b0}}, it_ctrl};

// CLAIMSET register
assign claim_tag_set_rd_data = {{28{1'b0}}, CSR_CLAIMSET_VAL};

// CLAIMCLR register
assign claim_tag_clr_rd_data = {{28{1'b0}}, claim_tag};

// LOCKSTATUS register
assign lock_status_rd_data = {{29{1'b0}},
                              CSR_LOCKSTATUS_8BIT_VAL,
                              ~dev_unlocked,
                              CSR_LOCKSTATUS_PRESENT_VAL};

// Authentication status register
assign auth_status_rd_data = {{24{1'b0}},
                                 1'b0,CSR_AUTHSTATUS_SNID_VAL,
                                 1'b0,CSR_AUTHSTATUS_SID_VAL,
                                 1'b0,CSR_AUTHSTATUS_NSNID_VAL,
                                 1'b0,CSR_AUTHSTATUS_NSID_VAL};

// DEVID register
assign device_id_rd_data = {{24{1'b0}}, CSR_DEVICEID_VAL};

// DEVTYPE register
assign device_type_rd_data = {{24{1'b0}}, CSR_DEVTYPE_VAL};

// PERIPHIDx registers
assign periph_id_0_rd_data = {{24{1'b0}}, CSR_PERIPHID0_VAL};
assign periph_id_1_rd_data = {{24{1'b0}}, CSR_PERIPHID1_VAL};
assign periph_id_2_rd_data = {{24{1'b0}}, CSR_PERIPHID2_VAL};
  //---------------------------------------------------------------------------
  // Peripheral ID3 Register (PID3)
  //---------------------------------------------------------------------------
  assign periph_id_3_rd_data[31:0] = {{24{1'b0}},             // 31:8
                                      revand_reg[3:0],        // 7:4
                                      PERIPHID3_CUSTOM[3:0]   // 3:0
                                      };

  //---------------------------------------------------------------------------
  // The Rev-And data (bits 7:4) are driven from a register so that it
  // can be easily changed in the netlist.
  //---------------------------------------------------------------------------
  always @(posedge clk)
  begin
    revand_reg[3:0] <= PERIPHID3_REVAND[3:0];
  end

assign periph_id_4_rd_data = {{24{1'b0}}, CSR_PERIPHID4_VAL};
assign periph_id_5_rd_data = {{24{1'b0}}, CSR_PERIPHID5_VAL};
assign periph_id_6_rd_data = {{24{1'b0}}, CSR_PERIPHID6_VAL};
assign periph_id_7_rd_data = {{24{1'b0}}, CSR_PERIPHID7_VAL};

// COMPIDx registers
assign comp_id_0_rd_data = {{24{1'b0}}, CSR_COMPID0_VAL};
assign comp_id_1_rd_data = {{24{1'b0}}, CSR_COMPID1_VAL};
assign comp_id_2_rd_data = {{24{1'b0}}, CSR_COMPID2_VAL};
assign comp_id_3_rd_data = {{24{1'b0}}, CSR_COMPID3_VAL};


//-----------------------------------------------------------------------------
// Read data mux
//-----------------------------------------------------------------------------
  assign read_data   = (
                        ({32{idfilter_0_rd_en}}   & {24'b0, idfilter_0}) |
                        ({32{idfilter_1_rd_en}}   & {24'b0, idfilter_1}) |
                        ({32{it_atb_ctr_1_rd_en}} & it_atb_ctr_1_rd_data) |
                        ({32{it_atb_ctr_0_rd_en}} & it_atb_ctr_0_rd_data) |
                        ({32{it_ctrl_rd_en}}      & it_ctrl_rd_data) |
                        ({32{claim_tag_set_rd_en}}& claim_tag_set_rd_data) |
                        ({32{claim_tag_clr_rd_en}}& claim_tag_clr_rd_data) |
                        ({32{lock_status_rd_en}}  & lock_status_rd_data) |
                        ({32{auth_status_rd_en}}  & auth_status_rd_data)   |
                        ({32{device_id_rd_en}}    & device_id_rd_data) |
                        ({32{device_type_rd_en}}  & device_type_rd_data) |
                        ({32{periph_id_0_rd_en}}  & periph_id_0_rd_data) |
                        ({32{periph_id_1_rd_en}}  & periph_id_1_rd_data) |
                        ({32{periph_id_2_rd_en}}  & periph_id_2_rd_data) |
                        ({32{periph_id_3_rd_en}}  & periph_id_3_rd_data) |
                        ({32{periph_id_4_rd_en}}  & periph_id_4_rd_data) |
                        ({32{periph_id_5_rd_en}}  & periph_id_5_rd_data) |
                        ({32{periph_id_6_rd_en}}  & periph_id_6_rd_data) |
                        ({32{periph_id_7_rd_en}}  & periph_id_7_rd_data) |
                        ({32{comp_id_0_rd_en}}    & comp_id_0_rd_data) |
                        ({32{comp_id_1_rd_en}}    & comp_id_1_rd_data) |
                        ({32{comp_id_2_rd_en}}    & comp_id_2_rd_data) |
                        ({32{comp_id_3_rd_en}}    & comp_id_3_rd_data)
                       );


  //----------------------------------------------------------------------------
  // ID, BYTES and DATA signals are combinatorially generated and copied from
  // the slave port
  //----------------------------------------------------------------------------
  assign                       atidm0 = atids;
  assign                       atidm1 = atids;
  assign                       atbytesm0 = atbytess;
  assign                       atbytesm1 = atbytess;
  assign                       atdatam0 = atdatas;
  assign                       atdatam1 = atdatas;


  assign discard_master_0 = idfilter_0[0] & (atids < 7'h10) |
                            idfilter_0[1] & ((atids < 7'h20) && (atids >= 7'h10)) |
                            idfilter_0[2] & ((atids < 7'h30) && (atids >= 7'h20)) |
                            idfilter_0[3] & ((atids < 7'h40) && (atids >= 7'h30)) |
                            idfilter_0[4] & ((atids < 7'h50) && (atids >= 7'h40)) |
                            idfilter_0[5] & ((atids < 7'h60) && (atids >= 7'h50)) |
                            idfilter_0[6] & ((atids < 7'h70) && (atids >= 7'h60)) |
                            idfilter_0[7] & ((atids <= 7'h7F) && (atids >= 7'h70));

  assign atreadym0_mod = discard_master_0 | atreadym0;

  assign discard_master_1 = idfilter_1[0] & (atids < 7'h10) |
                            idfilter_1[1] & ((atids < 7'h20) && (atids >= 7'h10)) |
                            idfilter_1[2] & ((atids < 7'h30) && (atids >= 7'h20)) |
                            idfilter_1[3] & ((atids < 7'h40) && (atids >= 7'h30)) |
                            idfilter_1[4] & ((atids < 7'h50) && (atids >= 7'h40)) |
                            idfilter_1[5] & ((atids < 7'h60) && (atids >= 7'h50)) |
                            idfilter_1[6] & ((atids < 7'h70) && (atids >= 7'h60)) |
                            idfilter_1[7] & ((atids <= 7'h7F) && (atids >= 7'h70));

  assign atreadym1_mod = discard_master_1 | atreadym1;


  //----------------------------------------------------------------------------
  // State Machine that controls transfers
  //----------------------------------------------------------------------------
  //----------------------------------------------------------------------------
  // CSR_T_IDLE    - No transfer is requested from the slave port
  // CSR_T_PEND_0  - Transfer in port 0 is pending
  // CSR_T_PEND_1  - Transfer in port 1 is pending
  // CSR_T_PEND_A  - Transfers in ports 0 and 1 are pending
  //----------------------------------------------------------------------------

  always @ *
  begin : p_transfer_fsm_comb
    case (transfer_state)
      CSR_T_IDLE :
        if (atvalids)
          begin
            case ({atreadym0_mod,atreadym1_mod})
              2'b00 : nxt_transfer_state = CSR_T_PEND_A;
              2'b01 : nxt_transfer_state = CSR_T_PEND_0;
              2'b10 : nxt_transfer_state = CSR_T_PEND_1;
              2'b11 : nxt_transfer_state = CSR_T_IDLE;
            endcase // case({atreadym0,atreadym1})
          end
        else nxt_transfer_state = CSR_T_IDLE;
      CSR_T_PEND_0 :
        nxt_transfer_state = atreadym0 ? CSR_T_IDLE : CSR_T_PEND_0;
      CSR_T_PEND_1 :
        nxt_transfer_state = atreadym1 ? CSR_T_IDLE : CSR_T_PEND_1;
      CSR_T_PEND_A :
        case ({atreadym0,atreadym1})
          2'b00 : nxt_transfer_state = CSR_T_PEND_A;
          2'b01 : nxt_transfer_state = CSR_T_PEND_0;
          2'b10 : nxt_transfer_state = CSR_T_PEND_1;
          2'b11 : nxt_transfer_state = CSR_T_IDLE;
        endcase
      default : nxt_transfer_state = CSR_T_UNDEF;
    endcase // case(transfer_state)
  end // p_transfer_fsm_comb

  // Registering nxt_transfer_state state
  always @(posedge clk or negedge resetn)
  begin : p_transfer_fsm_seq
    if (!resetn)
      transfer_state <= CSR_T_IDLE;
    else
      transfer_state <= nxt_transfer_state;
  end // p_transfer_fsm_seq


  //----------------------------------------------------------------------------
  // atreadys
  //----------------------------------------------------------------------------
  //----------------------------------------------------------------------------
  // atreadys will be high when there is no transfer pending or when the
  // transfers requested have been acknowledged in the same cycle, so the
  // state machine has not moved from the CSR_T_IDLE state.
  //----------------------------------------------------------------------------

  assign atreadys = it_ctrl ? it_atb_ctr_0_atreadys : (nxt_transfer_state == CSR_T_IDLE);

  //----------------------------------------------------------------------------
  // atvalidm0
  //----------------------------------------------------------------------------
  //----------------------------------------------------------------------------
  // ATVALID for port 0 will be high in the following cases
  //
  // 1) CSR_T_IDLE state and atreadys asserted
  // 2) CSR_T_PEND_A both ports are waiting for transfers to be completed
  // 3) CSR_T_PEND_0 port 0 is waiting for a transfer to be completed
  //
  // Therefore, the only state in which it will not be high is CSR_T_PEND_1
  //----------------------------------------------------------------------------

  assign atvalidm0 = it_ctrl ? it_atb_ctr_0_atvalidm0 :
                      atvalids &
                       ((transfer_state == CSR_T_PEND_0) |
                        (transfer_state == CSR_T_PEND_A) |
                        (transfer_state == CSR_T_IDLE) & ~discard_master_0);


  //----------------------------------------------------------------------------
  // atvalidm1
  //----------------------------------------------------------------------------
  //----------------------------------------------------------------------------
  // ATVALID for port 1 will be high in the following cases
  //
  // 1) CSR_T_IDLE state and atreadys asserted
  // 2) CSR_T_PEND_A both ports are waiting for transfers to be completed
  // 3) CSR_T_PEND_1 port 1 is waiting for a transfer to be completed
  //
  // Therefore, the only state in which it will not be high is CSR_T_PEND_0
  //----------------------------------------------------------------------------

  assign atvalidm1 = it_ctrl ? it_atb_ctr_0_atvalidm1 :
                      atvalids &
                       ((transfer_state == CSR_T_PEND_1) |
                        (transfer_state == CSR_T_PEND_A) |
                        (transfer_state == CSR_T_IDLE) & ~discard_master_1);


  //----------------------------------------------------------------------------
  // State Machine that controls flushes
  //----------------------------------------------------------------------------
  //----------------------------------------------------------------------------
  // CSR_F_IDLE    - No flush has been requested
  // CSR_F_REQ_0   - Port 0 ONLY has requested a flush which is pending
  // CSR_F_REQ_1   - Port 1 ONLY has requested a flush which is pending
  // CSR_F_REQ_01  - Port 0 has requested a flush, followed by another by port 1
  //                both requests are pending
  // CSR_F_REQ_10  - Port 1 has requested a flush, followed by another by port 0
  //                both requests are pending
  // CSR_F_REQ_A   - Both ports 0 and 1 have requested a flush simultaneously
  //                both requests are pending
  //----------------------------------------------------------------------------


  always @ *
  begin : p_flush_fsm_comb
    case (flush_state)
      CSR_F_IDLE :
        case ({afvalidm0,afvalidm1})
          2'b00 : nxt_flush_state = CSR_F_IDLE;
          2'b01 : nxt_flush_state = CSR_F_REQ_1;
          2'b10 : nxt_flush_state = CSR_F_REQ_0;
          2'b11 : nxt_flush_state = CSR_F_REQ_A;
        endcase
      CSR_F_REQ_0 :
        case ({afreadys,afvalidm1})
          2'b00 : nxt_flush_state = CSR_F_REQ_0;
          2'b01 : nxt_flush_state = CSR_F_REQ_01;
          2'b10 : nxt_flush_state = CSR_F_IDLE;
          2'b11 : nxt_flush_state = CSR_F_REQ_1;
        endcase
      CSR_F_REQ_1 :
        case ({afreadys,afvalidm0})
          2'b00 : nxt_flush_state = CSR_F_REQ_1;
          2'b01 : nxt_flush_state = CSR_F_REQ_10;
          2'b10 : nxt_flush_state = CSR_F_IDLE;
          2'b11 : nxt_flush_state = CSR_F_REQ_0;
        endcase
      CSR_F_REQ_01 : nxt_flush_state = afreadys ? CSR_F_REQ_1 : CSR_F_REQ_01;
      CSR_F_REQ_10 : nxt_flush_state = afreadys ? CSR_F_REQ_0 : CSR_F_REQ_10;
      CSR_F_REQ_A : nxt_flush_state = afreadys ? CSR_F_IDLE : CSR_F_REQ_A;
      default : nxt_flush_state = CSR_F_UNDEF;
    endcase // case(flush_state)
  end // p_flush_fsm_comb


  // Registering nxt_flush_state state
  always @(posedge clk or negedge resetn)
  begin : p_flush_fsm_seq
    if (!resetn)
      flush_state <= CSR_F_IDLE;
    else
      flush_state <= nxt_flush_state;
  end // p_flush_fsm_seq

  //----------------------------------------------------------------------------
  // afvalids
  //----------------------------------------------------------------------------
  //----------------------------------------------------------------------------
  // afvalids will not be HIGH only when the state machine is in CSR_F_IDLE
  // state. In any other state there will be at least one flush request pending
  // so afvalids must remain HIGH.
  //----------------------------------------------------------------------------
  assign afvalids = (flush_state != CSR_F_IDLE);

  // Adding a register to allow a default high value of afreadym while the module
  // is held in reset.

  reg rst_state;

  always @(posedge clk or negedge resetn)
  begin : p_rst_state
    if (!resetn)
      rst_state <= 1'b1;
    else
      rst_state <= 1'b0;
  end

  //----------------------------------------------------------------------------
  // afreadym0
  //----------------------------------------------------------------------------
  // afreadym for port 0 will be HIGH if afreadys is set and the flush system is
  // IDLE, or when the statemachine completes a flush request.
  //----------------------------------------------------------------------------
  assign afreadym0 = rst_state |
                     (
                      (flush_state == CSR_F_REQ_0)  | // only port#0
                      (flush_state == CSR_F_REQ_01) | // port#0 then port#1
                      (flush_state == CSR_F_REQ_A)    // both
                     ) & afreadys;

  //----------------------------------------------------------------------------
  // afreadym1
  //----------------------------------------------------------------------------
  // afreadym for port 1 will be HIGH if afreadys is set and the flush system is
  // IDLE, or when the statemachine completes a flush request.
  //----------------------------------------------------------------------------
  assign afreadym1 = rst_state |
                     (
                      (flush_state == CSR_F_REQ_1)  | // only port#1
                      (flush_state == CSR_F_REQ_10) | // port#1 then port#0
                      (flush_state == CSR_F_REQ_A)    // both
                     ) & afreadys;

  //----------------------------------------------------------------------------
  // SYNCREQ merging logic
  //----------------------------------------------------------------------------

  // Register the incoming syncreqm's
  always @(posedge clk or negedge resetn)
  begin : p_sync_req_seq
    if (!resetn)
      begin
        sync_req_m0_reg <= 1'b0;
        sync_req_m1_reg <= 1'b0;
      end
    else
      begin
        sync_req_m0_reg <= syncreqm0;
        sync_req_m1_reg <= syncreqm1;
      end
  end // p_sync_req_seq

  // Internal and external sync request combining logic
  // Flags:
  //   flag is set upon request active
  //   flag is cleared when combined sync is generated after request from
  //   another source
  assign sync_flag_m0_we  = sync_req_m0_reg |
                            (sync_req_m1_reg & sync_flag_m1);


  assign sync_flag_m1_we  = sync_req_m1_reg |
                            (sync_req_m0_reg & sync_flag_m0);

  // Register sync_flag_m0
  always @(posedge clk or negedge resetn)
  begin : p_sync_flag_m0_seq
    if (!resetn)
      begin
        sync_flag_m0 <= 1'b0;
      end
    else if (sync_flag_m0_we)
      begin
        sync_flag_m0 <= sync_req_m0_reg;
      end
  end // p_sync_flag_m0_seq

  // Register sync_flag_m1
  always @(posedge clk or negedge resetn)
  begin : p_sync_flag_m1_seq
    if (!resetn)
      begin
        sync_flag_m1 <= 1'b0;
      end
    else if (sync_flag_m1_we)
      begin
        sync_flag_m1 <= sync_req_m1_reg;
      end
  end // p_sync_flag_m1_seq

  // Combined sync is generated when input request and associated flag are set
  assign nxt_syncreqs = ((sync_req_m0_reg & sync_flag_m0) |
                         (sync_req_m1_reg & sync_flag_m1));


  //----------------------------------------------------------------------------
  // Sequential block for syncreqs
  //----------------------------------------------------------------------------
  always @(posedge clk or negedge resetn)
  begin : p_syncreqs
    if (!resetn)
      syncreqs <= 1'b0;
    else
      syncreqs <= nxt_syncreqs;
  end // block: p_syncreqs


  //----------------------------------------------------------------------------
  // Assertions
  //----------------------------------------------------------------------------
  `ifdef ARM_ASSERT_ON

    // Flush state machine in undefined state
    assert_never #(`OVL_ERROR, `OVL_ASSERT, "Flush FSM in undefined state")
    flush_fsm_undef (
      .clk       (clk),
      .reset_n   (resetn),
      .test_expr ((flush_state != CSR_F_IDLE  ) &
                  (flush_state != CSR_F_REQ_0 ) &
                  (flush_state != CSR_F_REQ_1 ) &
                  (flush_state != CSR_F_REQ_01) &
                  (flush_state != CSR_F_REQ_10) &
                  (flush_state != CSR_F_REQ_A))
    );

    // Transfer state machine in undefined state
    assert_never #(`OVL_ERROR, `OVL_ASSERT, "Transfer FSM in undefined state")
    transfer_fsm_undef (
      .clk        (clk),
      .reset_n    (resetn),
      .test_expr ((transfer_state != CSR_T_IDLE  ) &
                  (transfer_state != CSR_T_PEND_0) &
                  (transfer_state != CSR_T_PEND_1) &
                  (transfer_state != CSR_T_PEND_A))
    );

  `endif

endmodule // cxatbreplicator
