//-----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2003-2013 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//  Checked In          : $Date: 2013-09-06 16:05:05 +0100 (Fri, 06 Sep 2013) $
//  Revision            : $Revision: 37058 $
//  Release             : CoreSight-SoC-TM100-r3p1-00rel0
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
//  Purpose            : This block synchronises the eight bit asynchronous
//                       rtck input bus to a new clock domain by passing it
//                       through 2 registers clocked by the new clock.
//-----------------------------------------------------------------------------

module cxdapjtagap_sync(
  // Inputs
  dapclk, dapclken, dapresetn, csrtck,
  // Outputs
  rtck_sync
  );


//------------------------------------------------------------------------------
// Port Definitions
//------------------------------------------------------------------------------

  input        dapclk;     // Clock to synchronise to
  input        dapclken;   // Clock enable
  input        dapresetn;  // dapresetn for synchronisation registers

  input  [7:0] csrtck;     // Bus to be synchronised
  output [7:0] rtck_sync;  // Synchronised output

// -----------------------------------------------------------------------------
// Signal declarations
// -----------------------------------------------------------------------------

  // I/O pins of type wire
  wire        dapclk;      // Clock to synchronise to
  wire        dapclken;    // Clock enable
  wire        dapresetn;   // nReset for synchronisation registers
  wire  [7:0] csrtck;      // Bus to be synchronised

  reg   [7:0] rtck_sync;   //  Synchronised output
  reg   [7:0] sync_int;    //  1st stage synchronised version of csrtck

//---------------------------------------------------------------------------
// Signals used to test random asynchronous delays on the inputs
//---------------------------------------------------------------------------

`ifdef ASYNC_TEST_ON
  // Random number generator seed
  integer     seed;
  real        JTAGAP_ASYNC_DELAY;
  // Delayed signal
  wire [7:0]  csrtck_delayed;

  initial
    begin
      seed = 1;
      if (!$value$plusargs("JTAGAP_ASYNC_DELAY=%F", JTAGAP_ASYNC_DELAY))
        JTAGAP_ASYNC_DELAY = 0;
    end

  assign #JTAGAP_ASYNC_DELAY csrtck_delayed = csrtck;
`endif //  `ifdef ASYNC_TEST_ON

//------------------------------------------------------------------------------
// Main code
//------------------------------------------------------------------------------

// Double registers to synchronise bus
  always @ (posedge dapclk or negedge dapresetn)
    begin : p_syncclkseq
      if (!dapresetn)
        begin
          sync_int  <= 8'h00;
          rtck_sync <= 8'h00;
        end
      else if (dapclken)
        begin
`ifdef ASYNC_TEST_ON
          sync_int <= ($random(seed) & 32'h1 == 32'h1) ? csrtck : csrtck_delayed;
`else
          sync_int <= csrtck;
`endif
          rtck_sync <= sync_int;
        end
    end // block: p_syncclkseq


`ifdef ARM_ASSERT_ON

 //Halt x propagation at synchroniser level.
  // Severity 1
  assert_never_unknown #(`OVL_ERROR, 8, `OVL_ASSERT, "x or z detected in rtck synchroniser")
    dapjtagap_rtcksync_x
      (
       .clk       (dapclk),
       .reset_n   (dapresetn),
       .qualifier (1'b1),
       .test_expr (csrtck | rtck_sync)
      );

`endif

endmodule // cxdapjtagap_sync
