+incdir+$GP3_RTL/coresight/rtl/coresight_component/trigger_module/cxcti/verilog 

$GP3_RTL/coresight/rtl/coresight_component/trigger_module/cxcti/verilog/cxcti_ci.v
$GP3_RTL/coresight/rtl/coresight_component/trigger_module/cxcti/verilog/cxcti.v
$GP3_RTL/coresight/rtl/coresight_component/trigger_module/cxcti/verilog/cxcti_apb_if.v
//$GP3_RTL/coresight/rtl/coresight_component/trigger_module/cxcti/verilog/cxcti_constants.v
$GP3_RTL/coresight/rtl/coresight_component/trigger_module/cxcti/verilog/cxcti_reg_c.v
$GP3_RTL/coresight/rtl/coresight_component/trigger_module/cxcti/verilog/cxcti_mapper.v
$GP3_RTL/coresight/rtl/coresight_component/trigger_module/cxcti/verilog/cxcti_cdc_capt_nosync.v
//$GP3_RTL/coresight/rtl/coresight_component/trigger_module/cxcti/verilog/cx_en_sync.v
$GP3_RTL/coresight/rtl/coresight_component/trigger_module/cxcti/verilog/cxcti_reg_p.v
//$GP3_RTL/coresight/rtl/coresight_component/trigger_module/cxcti/verilog/cx_comb_mux2.v
$GP3_RTL/coresight/rtl/coresight_component/trigger_module/cxcti/verilog/cxcti_ti.v
