//-----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2003-2015 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//  Version and Release Control Information:
//
//  File Name           : cxatbfunnel_reg_blk_xmlcfg.v.xsl
//
//  Checked In          : $Date: 2015-02-16 14:55:41 +0000 (Mon, 16 Feb 2015) $
//
//  File Revision       : $Revision: 41661 $
//
//  Release Information : CoreSight-SoC-TM100-r3p2-00rel0
//-----------------------------------------------------------------------------
// Verilog-2001 (IEEE Std 1364-2001)
//----------------------------------------------------------------------------


//-----------------------------------------------------------------------------
// Abstract : CoreSight Trace Funnel (cxatbfunnel_reg_blk) - PCLK Domain Registers
//-----------------------------------------------------------------------------
//
// cxatbfunnel - CoreSight Trace Funnel
// ----------------------------------
//
// CoreSight AMBA Trace Bus (ATB) device used to combine multiple trace sources
// into a single bus.
//
// cxatbfunnel_reg_blk.v
// ----------------
//
// CoreSight AMBA Trace Bus (ATB) trace link device used to combine multiple
// trace sources into a single bus.
//
// Instantiated blocks
// -------------------
// None
//-----------------------------------------------------------------------------

module cxatbfunnel_reg_blk_6_pro
 #(parameter CXFUNNEL_FIXED_CONFIG_HOLD_TIME = 4'b0011,
   parameter CXFUNNEL_ATB_DATA_WIDTH = 32,
   parameter CXFUNNEL_ATBYTES_WIDTH= 2)
  (
  // Inputs
  //--------------------------------------------------------------------------------
  // Clock and Reset
  //--------------------------------------------------------------------------------
 input   wire                                   clk,
 input   wire                                   pclkendbg,
 input   wire                                   resetn,
  //--------------------------------------------------------------------------------
  // Read, Write and Protection (paddrdbg31) signals
  //--------------------------------------------------------------------------------
 input   wire                                   paddrdbg31,
 input   wire                                   reg_write,
 input   wire                                   reg_read,
 input   wire                           [9:0]   reg_addr,
  //--------------------------------------------------------------------------------
  // Integration register read values
  //--------------------------------------------------------------------------------
 input   wire [(CXFUNNEL_ATB_DATA_WIDTH/8):0]   it_atb_data_0_rd_reg,
 input   wire    [CXFUNNEL_ATBYTES_WIDTH+1:0]   it_atb_ctr_0_rd_reg,
 input   wire                           [6:0]   it_atb_ctr_1_rd_reg,
 input   wire                           [1:0]   it_atb_ctr_2_rd_reg,
 input   wire                          [31:0]   write_data,
  //--------------------------------------------------------------------------------
  // Valid ready , ready signals for all ATB Slave ports
  //--------------------------------------------------------------------------------

 input   wire                                   atreadys0,
 input   wire                                   atvalids0,
 input   wire                                   afvalids0,
 input   wire                                   atreadys1,
 input   wire                                   atvalids1,
 input   wire                                   afvalids1,
 input   wire                                   atreadys2,
 input   wire                                   atvalids2,
 input   wire                                   afvalids2,
 input   wire                                   atreadys3,
 input   wire                                   atvalids3,
 input   wire                                   afvalids3,
 input   wire                                   atreadys4,
 input   wire                                   atvalids4,
 input   wire                                   afvalids4,
 input   wire                                   atreadys5,
 input   wire                                   atvalids5,
 input   wire                                   afvalids5,

  // Outputs
  output  wire                          [31:0] read_data,
  //--------------------------------------------------------------------------------
  // Slave port enables
  //--------------------------------------------------------------------------------

  output  wire                                  en_port_0,
  output  wire                                  en_port_1,
  output  wire                                  en_port_2,
  output  wire                                  en_port_3,
  output  wire                                  en_port_4,
  output  wire                                  en_port_5,
  //--------------------------------------------------------------------------------
  // Slave port Priority
  //--------------------------------------------------------------------------------

  output  wire                           [2:0]  pri_port_0,
  output  wire                           [2:0]  pri_port_1,
  output  wire                           [2:0]  pri_port_2,
  output  wire                           [2:0]  pri_port_3,
  output  wire                           [2:0]  pri_port_4,
  output  wire                           [2:0]  pri_port_5,

  //--------------------------------------------------------------------------------
  // Integration mode select bit
  //--------------------------------------------------------------------------------
  output  wire                                   itc_reg,
  //--------------------------------------------------------------------------------
  // Integration register values
  //--------------------------------------------------------------------------------
  output  reg  [(CXFUNNEL_ATB_DATA_WIDTH/8):0]  it_atb_data_0_wr_reg,
  output  reg     [CXFUNNEL_ATBYTES_WIDTH+1:0]  it_atb_ctr_0_wr_reg,
  output  reg                            [6:0]  it_atb_ctr_1_wr_reg,
  output  reg                            [1:0]  it_atb_ctr_2_wr_reg,
  //--------------------------------------------------------------------------------
  // Min hold time value
  //--------------------------------------------------------------------------------
  output  wire                           [3:0]  min_hold_time
  );


//---------------------------------------------------------------------------
// Constants definitions
//---------------------------------------------------------------------------
// Define the state of Funnel ATB Slave interfaces at reset
  localparam CXFUNNEL_IT_DATA0_WIDTH = (CXFUNNEL_ATB_DATA_WIDTH == 128)? 17 :
                                       (CXFUNNEL_ATB_DATA_WIDTH == 64)? 9 :
                                       (CXFUNNEL_ATB_DATA_WIDTH == 32)? 5 :
                                       (CXFUNNEL_ATB_DATA_WIDTH == 16)? 3 :
                                        2 ;

//----------------------------------------------------------------------------
// CXFUNNEL Control Registers
//----------------------------------------------------------------------------
  localparam CXFUNNEL_FUNCTL = 10'h000;              // Funnel control register
  localparam CXFUNNEL_PRICTL = 10'h001;              // Priority control register

//----------------------------------------------------------------------------
// CXFUNNEL Management Registers
//----------------------------------------------------------------------------
  localparam  CXFUNNEL_ITCTL      = 10'h3C0;         // Integration control register
  localparam  CXFUNNEL_CLAIMSET   = 10'h3E8;         // Claim tag set register
  localparam  CXFUNNEL_CLAIMCLR   = 10'h3E9;         // Claim tag clear register
  localparam  CXFUNNEL_LOCKACCESS = 10'h3EC;         // Lock access register
  localparam  CXFUNNEL_LOCKSTATUS = 10'h3ED;         // Lock status register
  localparam  CXFUNNEL_AUTHSTATUS = 10'h3EE;         // Authentication status register
  localparam  CXFUNNEL_DEVICEID   = 10'h3F2;         // Device identification register
  localparam  CXFUNNEL_DEVICETYPE = 10'h3F3;         // Device type register

//----------------------------------------------------------------------------
// CXFUNNEL Integration Registers
//----------------------------------------------------------------------------
  localparam CXFUNNEL_IT_ATB_DATA_0 = 10'h3BB;       // Integration register
  localparam CXFUNNEL_IT_ATB_CTR_2 = 10'h3BC;        // Integration register
  localparam CXFUNNEL_IT_ATB_CTR_1 = 10'h3BD;        // Integration register
  localparam CXFUNNEL_IT_ATB_CTR_0 = 10'h3BE;        // Integration register

//------------------------------------------------------------------------------
// CXFUNNEL Component Identification Registers
//------------------------------------------------------------------------------
  localparam CXFUNNEL_PERIPH_ID_4 = 10'h3F4;         // Peripheral ID4 register
  localparam CXFUNNEL_PERIPH_ID_5 = 10'h3F5;         // Peripheral ID5 register
  localparam CXFUNNEL_PERIPH_ID_6 = 10'h3F6;         // Peripheral ID6 register
  localparam CXFUNNEL_PERIPH_ID_7 = 10'h3F7;         // Peripheral ID7 register
  localparam CXFUNNEL_PERIPH_ID_0 = 10'h3F8;         // Peripheral ID0 register
  localparam CXFUNNEL_PERIPH_ID_1 = 10'h3F9;         // Peripheral ID1 register
  localparam CXFUNNEL_PERIPH_ID_2 = 10'h3FA;         // Peripheral ID2 register
  localparam CXFUNNEL_PERIPH_ID_3 = 10'h3FB;         // Peripheral ID3 register
  localparam CXFUNNEL_COMP_ID_0   = 10'h3FC;         // Component ID0 register
  localparam CXFUNNEL_COMP_ID_1   = 10'h3FD;         // Component ID1 register
  localparam CXFUNNEL_COMP_ID_2   = 10'h3FE;         // Component ID2 register
  localparam CXFUNNEL_COMP_ID_3   = 10'h3FF;         // Component ID3 register

//------------------------------------------------------------------------------
// CXFUNNEL Read Only Register Values
//------------------------------------------------------------------------------
  localparam CXFUNNEL_PERIPH_ID_4_VAL = 8'h04;       // Peripheral ID4 value
  localparam CXFUNNEL_PERIPH_ID_5_VAL = 8'h00;       // Peripheral ID5 value
  localparam CXFUNNEL_PERIPH_ID_6_VAL = 8'h00;       // Peripheral ID6 value
  localparam CXFUNNEL_PERIPH_ID_7_VAL = 8'h00;       // Peripheral ID7 value
  localparam CXFUNNEL_PERIPH_ID_0_VAL = 8'h08;       // Peripheral ID0 value
  localparam CXFUNNEL_PERIPH_ID_1_VAL = 8'hB9;       // Peripheral ID1 value
  localparam CXFUNNEL_PERIPH_ID_2_VAL = 8'h3B;       // Peripheral ID2 value
  localparam CXFUNNEL_PERIPH_ID_3_CUSTOM_VAL = 4'h0; // Peripheral ID3 value
  localparam CXFUNNEL_PERIPH_ID_3_REVAND_VAL = 4'h0; // Peripheral ID3 value

  localparam CXFUNNEL_COMP_ID_0_VAL = 8'h0D;         // Component ID0 value
  localparam CXFUNNEL_COMP_ID_1_VAL = 8'h90;         // Component ID1 value
  localparam CXFUNNEL_COMP_ID_2_VAL = 8'h05;         // Component ID2 value
  localparam CXFUNNEL_COMP_ID_3_VAL = 8'hB1;         // Component ID3 value
  localparam CXFUNNEL_DEVICEID_VAL_2PORTS   = 8'h32; // Device identification value if 2 ATB slave ports are present
  localparam CXFUNNEL_DEVICEID_VAL_3PORTS   = 8'h33; // Device identification value if 3 ATB slave ports are present
  localparam CXFUNNEL_DEVICEID_VAL_4PORTS   = 8'h34; // Device identification value if 4 ATB slave ports are present
  localparam CXFUNNEL_DEVICEID_VAL_5PORTS   = 8'h35; // Device identification value if 5 ATB slave ports are present
  localparam CXFUNNEL_DEVICEID_VAL_6PORTS   = 8'h36; // Device identification value if 6 ATB slave ports are present
  localparam CXFUNNEL_DEVICEID_VAL_7PORTS   = 8'h37; // Device identification value if 7 ATB slave ports are present
  localparam CXFUNNEL_DEVICEID_VAL_8PORTS   = 8'h38; // Device identification value if 8 ATB slave ports are present
  localparam CXFUNNEL_DEVICETYPE_VAL = 8'h12;        // Device type value
  localparam CXFUNNEL_CLAIM_TAG_VAL  = 4'hF;         // Claim tag value

  localparam CXFUNNEL_AUTHSTATUS_SNID_VAL    = 1'b0; // Secure non-invasive
  localparam CXFUNNEL_AUTHSTATUS_SID_VAL     = 1'b0; // Secure invasive
  localparam CXFUNNEL_AUTHSTATUS_NSNID_VAL   = 1'b0; // Non-secure non-invasive
  localparam CXFUNNEL_AUTHSTATUS_NSID_VAL    = 1'b0; // Non-secure invasive
  localparam CXFUNNEL_LOCKSTATUS_8BIT_VAL    = 1'b0; // Lock access 8 bit
  localparam CXFUNNEL_LOCKSTATUS_PRESENT_VAL = 1'b1; // Lock access present

  //---------------------------------------------------------------------------
  // Wires
  //---------------------------------------------------------------------------
  // Signals for Priority control register
  //---------------------------------------------------------------------------
  wire [17:0]   pri_ctl_write_data;

  wire [2:0]    pri_ctl_write_data_port_0;
  wire [2:0]    pri_ctl_write_data_port_1;
  wire [2:0]    pri_ctl_write_data_port_2;
  wire [2:0]    pri_ctl_write_data_port_3;
  wire [2:0]    pri_ctl_write_data_port_4;
  wire [2:0]    pri_ctl_write_data_port_5;
  //---------------------------------------------------------------------------
  // Signals for port enable
  //---------------------------------------------------------------------------

  reg           en_port_int_0;
  reg           en_port_int_1;
  reg           en_port_int_2;
  reg           en_port_int_3;
  reg           en_port_int_4;
  reg           en_port_int_5;
  //---------------------------------------------------------------------------
  // Register select signals
  //---------------------------------------------------------------------------
  wire          fun_ctl_sel;
  wire          pri_ctl_sel;
  wire          itc_sel;
  wire          lock_acc_sel;
  wire          claim_set_sel;
  wire          claim_clr_sel;
  wire          it_atb_data_0_sel;
  wire          it_atb_ctr_0_sel;
  wire          it_atb_ctr_1_sel;
  wire          it_atb_ctr_2_sel;
  //---------------------------------------------------------------------------
  // Write enable signals for each register
  //---------------------------------------------------------------------------
  wire          fun_ctl_wr_en;
  wire          pri_ctl_wr_en;
  wire          itc_wr_en;
  wire          claim_tag_wr_en;
  wire          it_atb_data_0_wr_en;
  wire          it_atb_ctr_2_wr_en;
  wire          it_atb_ctr_1_wr_en;
  wire          it_atb_ctr_0_wr_en;
  //---------------------------------------------------------------------------
  // Read enable signals for each register
  //---------------------------------------------------------------------------
  wire          itc_rd_en;
  wire          it_atb_data_0_rd_en;
  wire          it_atb_ctr_0_rd_en;
  wire          it_atb_ctr_1_rd_en;
  wire          it_atb_ctr_2_rd_en;
  wire          lock_access_wr_en;
  wire          fun_ctl_rd_en;
  wire          pri_ctl_rd_en;
  wire          periph_id_0_rd_en;
  wire          periph_id_1_rd_en;
  wire          periph_id_2_rd_en;
  wire          periph_id_3_rd_en;
  wire          periph_id_4_rd_en;
  wire          periph_id_5_rd_en;
  wire          periph_id_6_rd_en;
  wire          periph_id_7_rd_en;
  wire          comp_id_0_rd_en;
  wire          comp_id_1_rd_en;
  wire          comp_id_2_rd_en;
  wire          comp_id_3_rd_en;
  wire          claim_tag_set_rd_en;
  wire          claim_tag_clr_rd_en;
  wire          lock_status_rd_en;
  wire          auth_status_rd_en;
  wire          device_id_rd_en;
  wire          device_type_rd_en;

  //---------------------------------------------------------------------------
  // Read/write signals
  //---------------------------------------------------------------------------
  wire          it_rd;
  wire          it_wr;
  wire          reg_p_write;
  wire          next_dev_unlocked;
  wire [3:0]    next_claim_tag_reg;
  //---------------------------------------------------------------------------
  // Read data signals for each registers
  //---------------------------------------------------------------------------
  wire [31:0]   fun_ctl_rd_data;
  wire [31:0]   pri_ctl_rd_data;
  wire [31:0]   itc_rd_data;
  wire [31:0]   it_atb_data_0_rd_data;
  wire [31:0]   it_atb_ctr_0_rd_data;
  wire [31:0]   it_atb_ctr_1_rd_data;
  wire [31:0]   it_atb_ctr_2_rd_data;
  wire [31:0]   claim_tag_set_rd_data;
  wire [31:0]   claim_tag_clr_rd_data;
  wire [31:0]   lock_status_rd_data;
  wire [31:0]   auth_status_rd_data;
  wire [31:0]   device_id_rd_data;
  wire [31:0]   device_type_rd_data;
  wire [31:0]   periph_id_0_rd_data;
  wire [31:0]   periph_id_1_rd_data;
  wire [31:0]   periph_id_2_rd_data;
  wire [31:0]   periph_id_3_rd_data;
  wire [31:0]   periph_id_4_rd_data;
  wire [31:0]   periph_id_5_rd_data;
  wire [31:0]   periph_id_6_rd_data;
  wire [31:0]   periph_id_7_rd_data;
  wire [31:0]   comp_id_0_rd_data;
  wire [31:0]   comp_id_1_rd_data;
  wire [31:0]   comp_id_2_rd_data;
  wire [31:0]   comp_id_3_rd_data;



  //---------------------------------------------------------------------------
  // Registers
  //---------------------------------------------------------------------------
  wire [5:0]    pending_transfer;
  reg           pprotdbg_reg;
  reg           device_un_locked;
  reg [3:0]     claim_tag_reg;
  reg [11:0]    fun_ctl_reg;
  reg [3:0]     ht_reg;
  reg           itc_reg_int;
  reg [5:0]    slv_port_en_reg;
  reg [17:0]    pri_ctl_reg;
  reg [3:0]     periph_id_3_rev_and_reg; // Register for Rev-And data

  //---------------------------------------------------------------------------
  //
  // Main body of code
  // =================
  //
  //---------------------------------------------------------------------------

  //---------------------------------------------------------------------------
  // Sequential block for latching the paddrdbg31.
  //---------------------------------------------------------------------------
  always @(posedge clk or negedge resetn)
    begin : p_pprot_dbg
      if (!resetn)
        pprotdbg_reg <= 1'b0;
      else
        if(pclkendbg)
          pprotdbg_reg <= paddrdbg31;
    end // block: p_pprot_dbg

  //---------------------------------------------------------------------------
  // Logic for reg_p_write.This signal is a write pulse in the clk domain.
  // This signal is only generated if the reg_write from the clk interface
  // is set and the device is not locked or if pprotdbg_reg is set.
  //---------------------------------------------------------------------------
  assign reg_p_write = reg_write & (device_un_locked | pprotdbg_reg);

  //---------------------------------------------------------------------------
  // Logic for selecting the write registers
  //---------------------------------------------------------------------------
  assign fun_ctl_sel   = (reg_addr == CXFUNNEL_FUNCTL);
  assign pri_ctl_sel   = (reg_addr == CXFUNNEL_PRICTL);
  assign itc_sel       = (reg_addr == CXFUNNEL_ITCTL);
  assign lock_acc_sel  = (reg_addr == CXFUNNEL_LOCKACCESS);
  assign claim_set_sel = (reg_addr == CXFUNNEL_CLAIMSET);
  assign claim_clr_sel = (reg_addr == CXFUNNEL_CLAIMCLR);
  assign it_atb_data_0_sel  = (reg_addr == CXFUNNEL_IT_ATB_DATA_0);
  assign it_atb_ctr_0_sel  = (reg_addr == CXFUNNEL_IT_ATB_CTR_0);
  assign it_atb_ctr_1_sel  = (reg_addr == CXFUNNEL_IT_ATB_CTR_1);
  assign it_atb_ctr_2_sel  = (reg_addr == CXFUNNEL_IT_ATB_CTR_2);

  //---------------------------------------------------------------------------
  // Sequential block for writing into the funnel control register.
  // Funnel control register   : Offset 0x000 ( R/W )
  //---------------------------------------------------------------------------

  always @(posedge clk or negedge resetn)
    begin : p_fun_ctl_wr
      if (!resetn)
        begin
          ht_reg[3:0] <= CXFUNNEL_FIXED_CONFIG_HOLD_TIME;
          slv_port_en_reg[5:0] <= {6{1'b0}};
        end
      else
        if(fun_ctl_wr_en)
          begin
            ht_reg[3:0] <= write_data[11:8];
            slv_port_en_reg[5:0] <= write_data[5:0];
          end
    end // block: p_fun_ctl_wr

  //---------------------------------------------------------------------------
  // Assign fun_ctl_reg
  //---------------------------------------------------------------------------

  always @*
    begin
      fun_ctl_reg[11:8] = ht_reg;
      fun_ctl_reg[7:6] = {2{1'b0}};
      fun_ctl_reg[5:0] = slv_port_en_reg;
    end

  //---------------------------------------------------------------------------
  // The fun_ctl_wr_en and fun_ctl_rd_en signals are the enable signals for
  // writing and reading respectively from the funnel control register.
  //---------------------------------------------------------------------------
  assign fun_ctl_wr_en   = reg_p_write & fun_ctl_sel & pclkendbg;
  assign fun_ctl_rd_en   = reg_read  & fun_ctl_sel;
  assign fun_ctl_rd_data = {{20{1'b0}},fun_ctl_reg};

  //---------------------------------------------------------------------------
  // Pending transfers  0 : No pending transfers 1: pending transfers
  //---------------------------------------------------------------------------


  assign pending_transfer[0] = (~itc_reg_int & ((atvalids0 & ~atreadys0) | afvalids0) & en_port_int_0);
  assign pending_transfer[1] = (~itc_reg_int & ((atvalids1 & ~atreadys1) | afvalids1) & en_port_int_1);
  assign pending_transfer[2] = (~itc_reg_int & ((atvalids2 & ~atreadys2) | afvalids2) & en_port_int_2);
  assign pending_transfer[3] = (~itc_reg_int & ((atvalids3 & ~atreadys3) | afvalids3) & en_port_int_3);
  assign pending_transfer[4] = (~itc_reg_int & ((atvalids4 & ~atreadys4) | afvalids4) & en_port_int_4);
  assign pending_transfer[5] = (~itc_reg_int & ((atvalids5 & ~atreadys5) | afvalids5) & en_port_int_5);

  //---------------------------------------------------------------------------
  // The slave port enable and minimum hold fields in the funnel control
  // register are assigned to the corresponding signals.
  //---------------------------------------------------------------------------

  always @(posedge clk or negedge resetn)
  begin : p_en_port_0
    if (!resetn)
      en_port_int_0 <= 1'b0;
    else
      if (!pending_transfer[0])
        en_port_int_0 <= fun_ctl_reg[0];
  end // p_en_port_int_0
  assign en_port_0 = en_port_int_0;

  always @(posedge clk or negedge resetn)
  begin : p_en_port_1
    if (!resetn)
      en_port_int_1 <= 1'b0;
    else
      if (!pending_transfer[1])
        en_port_int_1 <= fun_ctl_reg[1];
  end // p_en_port_int_1
  assign en_port_1 = en_port_int_1;

  always @(posedge clk or negedge resetn)
  begin : p_en_port_2
    if (!resetn)
      en_port_int_2 <= 1'b0;
    else
      if (!pending_transfer[2])
        en_port_int_2 <= fun_ctl_reg[2];
  end // p_en_port_int_2
  assign en_port_2 = en_port_int_2;

  always @(posedge clk or negedge resetn)
  begin : p_en_port_3
    if (!resetn)
      en_port_int_3 <= 1'b0;
    else
      if (!pending_transfer[3])
        en_port_int_3 <= fun_ctl_reg[3];
  end // p_en_port_int_3
  assign en_port_3 = en_port_int_3;

  always @(posedge clk or negedge resetn)
  begin : p_en_port_4
    if (!resetn)
      en_port_int_4 <= 1'b0;
    else
      if (!pending_transfer[4])
        en_port_int_4 <= fun_ctl_reg[4];
  end // p_en_port_int_4
  assign en_port_4 = en_port_int_4;

  always @(posedge clk or negedge resetn)
  begin : p_en_port_5
    if (!resetn)
      en_port_int_5 <= 1'b0;
    else
      if (!pending_transfer[5])
        en_port_int_5 <= fun_ctl_reg[5];
  end // p_en_port_int_5
  assign en_port_5 = en_port_int_5;


  assign min_hold_time  = fun_ctl_reg[11:8];

  //---------------------------------------------------------------------------
  // Sequential block for writing into the priority control register.
  // Priority control register   : Offset 0x004 ( R/W )
  //---------------------------------------------------------------------------
  always @(posedge clk or negedge resetn)
  begin : p_pri_ctl_wr
    if (!resetn)
      pri_ctl_reg <= {18{1'b0}};
    else
      if(pri_ctl_wr_en)
        pri_ctl_reg <= pri_ctl_write_data[17:0];
   end // block: p_pri_ctl_wr

  //---------------------------------------------------------------------------
  // The pri_ctl_wr_en and pri_ctl_rd_en signals are the enable signals for
  // writing and reading respectively from the priority control register.
  //---------------------------------------------------------------------------
  assign pri_ctl_wr_en   = reg_p_write & pri_ctl_sel & pclkendbg;
  assign pri_ctl_rd_en   = reg_read  & pri_ctl_sel;
  assign pri_ctl_rd_data = {{14{1'b0}},pri_ctl_reg};

  //---------------------------------------------------------------------------
  // Priority for ATB slaves shall only be changed when the ATB slave interface
  // is disabled.
  //---------------------------------------------------------------------------
  assign pri_ctl_write_data_port_0 = en_port_int_0 ? pri_ctl_reg[2:0] :
                                                 write_data[2:0];
  assign pri_ctl_write_data_port_1 = en_port_int_1 ? pri_ctl_reg[5:3] :
                                                 write_data[5:3];

  assign pri_ctl_write_data_port_2 = en_port_int_2 ? pri_ctl_reg[8:6] :
                                                 write_data[8:6];
  assign pri_ctl_write_data_port_3 = en_port_int_3 ? pri_ctl_reg[11:9] :
                                                 write_data[11:9];
  assign pri_ctl_write_data_port_4 = en_port_int_4 ? pri_ctl_reg[14:12] :
                                                 write_data[14:12];
  assign pri_ctl_write_data_port_5 = en_port_int_5 ? pri_ctl_reg[17:15] :
                                                 write_data[17:15];


  //---------------------------------------------------------------------------
  // Write data for the priority control register
  //---------------------------------------------------------------------------
  assign pri_ctl_write_data = {pri_ctl_write_data_port_5,pri_ctl_write_data_port_4,pri_ctl_write_data_port_3,pri_ctl_write_data_port_2,
                               pri_ctl_write_data_port_1,
                               pri_ctl_write_data_port_0};

  //---------------------------------------------------------------------------
  // The slave port priority fields in the priority control register are
  // assigned to the corresponding signals.
  //---------------------------------------------------------------------------
  assign pri_port_0 = pri_ctl_reg[2:0];
  assign pri_port_1 = pri_ctl_reg[5:3];
  assign pri_port_2 = pri_ctl_reg[8:6];
  assign pri_port_3 = pri_ctl_reg[11:9];
  assign pri_port_4 = pri_ctl_reg[14:12];
  assign pri_port_5 = pri_ctl_reg[17:15];

  //---------------------------------------------------------------------------
  // Sequential block for writing into the integration mode control register.
  // Integration mode control register   : Offset 0xF00 ( R/W )
  //---------------------------------------------------------------------------
  always @(posedge clk or negedge resetn)
  begin : p_itc_wr
    if (!resetn)
      itc_reg_int <= 1'b0;
    else
      if(itc_wr_en)
        itc_reg_int <= write_data[0];
   end // block: p_itc_wr

   assign itc_reg = itc_reg_int;

  //---------------------------------------------------------------------------
  // The itc_wr_en and itc_rd_en signals are the enable signals for writing and
  // reading respectively from the integration mode control register.
  //---------------------------------------------------------------------------
  assign itc_wr_en   = reg_p_write & itc_sel & pclkendbg;
  assign itc_rd_en   = reg_read  & itc_sel;
  assign itc_rd_data = {{31{1'b0}},itc_reg_int};

  // ---------------------------------------------------------------------------
  // Sequential block for writing into the lock access register.
  // Lock Access register    : Offset 0xFB0 ( W )
  // ---------------------------------------------------------------------------
  always @(posedge clk or negedge resetn)
  begin : p_device_un_locked
    if (!resetn)
      device_un_locked <= 1'b0;
    else
      if(lock_access_wr_en)
        device_un_locked <= next_dev_unlocked;
  end // block: p_device_un_locked

  //---------------------------------------------------------------------------
  // The lock_access_wr_en is the enable signal for writing into the lock access
  // register.The write to this register is qualified with reg_write but not
  // reg_p_write because the lock access write is only enabled when the
  // PPROTDBG is low.
  //---------------------------------------------------------------------------
  assign lock_access_wr_en = reg_write & lock_acc_sel & ~pprotdbg_reg &
                             pclkendbg;
  assign next_dev_unlocked = (write_data == 32'hC5ACCE55);

  //---------------------------------------------------------------------------
  // Sequential block for writing into the claim tag register.
  // Claim tag set register     : Offset 0xFA0 ( R/W )
  // Claim tag clear register   : Offset 0xFA4 ( R/W )
  //---------------------------------------------------------------------------
  always @(posedge clk or negedge resetn)
  begin : p_claim_tag_wr
    if (!resetn)
      claim_tag_reg <= {4{1'b0}};
    else
      if(claim_tag_wr_en)
        claim_tag_reg <= next_claim_tag_reg;
   end // block: p_claim_tag_wr

  //---------------------------------------------------------------------------
  // The claim_tag_wr_en is the enable signal for writing into the claim tag
  // register.The enable signal is set when either the claim set or claim
  // claim clear registers is selected.
  //---------------------------------------------------------------------------
  assign claim_tag_wr_en = reg_p_write & pclkendbg &
                           (claim_set_sel | claim_clr_sel);

  //---------------------------------------------------------------------------
  // Logic for the next_claim_tag_reg value.This value is latched into the claim
  // tag register.Claim set tag register is ored with current value.Claim clear
  // tag register is anded with the inverted value.
  //---------------------------------------------------------------------------
  assign next_claim_tag_reg = claim_set_sel ?
                              (claim_tag_reg | write_data[3:0]):
                              (claim_tag_reg & ~write_data[3:0]);

  //---------------------------------------------------------------------------
  // The claim_tag_set_rd_en and claim_tag_clr_rd_en signals are the enable
  // signals for reading from the claim tag set and claim tag clear registers
  // respectively.
  //---------------------------------------------------------------------------
  assign claim_tag_set_rd_en   = reg_read & claim_set_sel;
  assign claim_tag_clr_rd_en   = reg_read & claim_clr_sel;
  assign claim_tag_set_rd_data = {{28{1'b0}},CXFUNNEL_CLAIM_TAG_VAL};
  assign claim_tag_clr_rd_data = {{28{1'b0}},claim_tag_reg};

  //---------------------------------------------------------------------------
  // Lock status register : Offset 0xFB4 ( R )
  //---------------------------------------------------------------------------
  assign lock_status_rd_en   = reg_read & (reg_addr == CXFUNNEL_LOCKSTATUS) &
                            ~pprotdbg_reg;
  assign lock_status_rd_data = {{29{1'b0}},CXFUNNEL_LOCKSTATUS_8BIT_VAL,
                                        ~device_un_locked,
                                        CXFUNNEL_LOCKSTATUS_PRESENT_VAL};

  //---------------------------------------------------------------------------
  // Authentication status register : Offset 0xFB8 ( R )
  //---------------------------------------------------------------------------
  assign auth_status_rd_en   = reg_read & (reg_addr == CXFUNNEL_AUTHSTATUS);
  assign auth_status_rd_data = {{24{1'b0}},
                                 1'b0,CXFUNNEL_AUTHSTATUS_SNID_VAL,
                                 1'b0,CXFUNNEL_AUTHSTATUS_SID_VAL,
                                 1'b0,CXFUNNEL_AUTHSTATUS_NSNID_VAL,
                                 1'b0,CXFUNNEL_AUTHSTATUS_NSID_VAL};

  //---------------------------------------------------------------------------
  // Device identification register : Offset 0xFC8 ( R )
  //---------------------------------------------------------------------------
  assign device_id_rd_en   = reg_read & (reg_addr == CXFUNNEL_DEVICEID);
        assign device_id_rd_data = {{24{1'b0}},
                                    CXFUNNEL_DEVICEID_VAL_6PORTS};

  //---------------------------------------------------------------------------
  // Device type identifier register : Offset 0xFCC ( R )
  //---------------------------------------------------------------------------
  assign device_type_rd_en   = reg_read & (reg_addr == CXFUNNEL_DEVICETYPE);
  assign device_type_rd_data = {{24{1'b0}},CXFUNNEL_DEVICETYPE_VAL};

  //---------------------------------------------------------------------------
  // Peripheral ID4 register : Offset 0xFD0 ( R )
  //---------------------------------------------------------------------------
  assign periph_id_4_rd_en   = reg_read & (reg_addr == CXFUNNEL_PERIPH_ID_4);
  assign periph_id_4_rd_data = {{24{1'b0}},CXFUNNEL_PERIPH_ID_4_VAL};

  //---------------------------------------------------------------------------
  // Peripheral ID5 register : Offset 0xFD4 ( R )
  //---------------------------------------------------------------------------
  assign periph_id_5_rd_en   = reg_read & (reg_addr == CXFUNNEL_PERIPH_ID_5);
  assign periph_id_5_rd_data = {{24{1'b0}},CXFUNNEL_PERIPH_ID_5_VAL};

  //---------------------------------------------------------------------------
  // Peripheral ID6 register : Offset 0xFD8 ( R )
  //---------------------------------------------------------------------------
  assign periph_id_6_rd_en   = reg_read & (reg_addr == CXFUNNEL_PERIPH_ID_6);
  assign periph_id_6_rd_data = {{24{1'b0}},CXFUNNEL_PERIPH_ID_6_VAL};

  //---------------------------------------------------------------------------
  // Peripheral ID7 register : Offset 0xFDC ( R )
  //---------------------------------------------------------------------------
  assign periph_id_7_rd_en   = reg_read & (reg_addr == CXFUNNEL_PERIPH_ID_7);
  assign periph_id_7_rd_data = {{24{1'b0}},CXFUNNEL_PERIPH_ID_7_VAL};

  //---------------------------------------------------------------------------
  // Peripheral ID0 register : Offset 0xFE0 ( R )
  //---------------------------------------------------------------------------
  assign periph_id_0_rd_en   = reg_read & (reg_addr == CXFUNNEL_PERIPH_ID_0);
  assign periph_id_0_rd_data = {{24{1'b0}},CXFUNNEL_PERIPH_ID_0_VAL};

  //---------------------------------------------------------------------------
  // Peripheral ID1 register : Offset 0xFE4 ( R )
  //---------------------------------------------------------------------------
  assign periph_id_1_rd_en   = reg_read & (reg_addr == CXFUNNEL_PERIPH_ID_1);
  assign periph_id_1_rd_data = {{24{1'b0}},CXFUNNEL_PERIPH_ID_1_VAL};

  //---------------------------------------------------------------------------
  // Peripheral ID2 register : Offset 0xFE8 ( R )
  //---------------------------------------------------------------------------
  assign periph_id_2_rd_en   = reg_read & (reg_addr == CXFUNNEL_PERIPH_ID_2);
  assign periph_id_2_rd_data = {{24{1'b0}},CXFUNNEL_PERIPH_ID_2_VAL};

  //---------------------------------------------------------------------------
  // Peripheral ID3 register : Offset 0xFEC ( R )
  //---------------------------------------------------------------------------
  assign periph_id_3_rd_en    = reg_read & (reg_addr == CXFUNNEL_PERIPH_ID_3);
  assign periph_id_3_rd_data  = {{24{1'b0}}, periph_id_3_rev_and_reg[3:0],
                            CXFUNNEL_PERIPH_ID_3_CUSTOM_VAL };

  //---------------------------------------------------------------------------
  // The Rev-And data (bits 7:4) should be driven from a register so that it
  // can be easily changed in the netlist.
  //
  // No Reset is required because this register cannot be read in the first
  // cycle after reset.
  //---------------------------------------------------------------------------
  always @(posedge clk)
    begin
      periph_id_3_rev_and_reg[3:0] <= CXFUNNEL_PERIPH_ID_3_REVAND_VAL;
    end

  //---------------------------------------------------------------------------
  // Component ID0 register : Offset 0xFF0 ( R )
  //---------------------------------------------------------------------------
  assign comp_id_0_rd_en   = reg_read & (reg_addr == CXFUNNEL_COMP_ID_0);
  assign comp_id_0_rd_data = {{24{1'b0}},CXFUNNEL_COMP_ID_0_VAL};

  //---------------------------------------------------------------------------
  // Component ID1 register : Offset 0xFF4 ( R )
  //---------------------------------------------------------------------------
  assign comp_id_1_rd_en   = reg_read & (reg_addr == CXFUNNEL_COMP_ID_1);
  assign comp_id_1_rd_data = {{24{1'b0}},CXFUNNEL_COMP_ID_1_VAL};

  // --------------------------------------------------------------------------
  // Component ID2 register : Offset 0xFF8 ( R )
  // --------------------------------------------------------------------------
  assign comp_id_2_rd_en   = reg_read & (reg_addr == CXFUNNEL_COMP_ID_2);
  assign comp_id_2_rd_data = {{24{1'b0}},CXFUNNEL_COMP_ID_2_VAL};

  //---------------------------------------------------------------------------
  // Component ID3 register : Offset 0xFFC ( R )
  //---------------------------------------------------------------------------
  assign comp_id_3_rd_en   = reg_read & (reg_addr == CXFUNNEL_COMP_ID_3);
  assign comp_id_3_rd_data = {{24{1'b0}},CXFUNNEL_COMP_ID_3_VAL};

  //----------------------------------------------------------------------------
  // Logic for generating it_wr and it_rd signals.ItWr and ItRd indicates the
  // integration register write and read enable signals respectively.
  //----------------------------------------------------------------------------
  assign it_wr = reg_p_write & itc_reg_int;
  assign it_rd = reg_read   & itc_reg_int;

  //---------------------------------------------------------------------------
  // Integration register : Offset 0xEEC ( R/W )
  //---------------------------------------------------------------------------
  assign it_atb_data_0_wr_en   = it_atb_data_0_sel & it_wr;
  assign it_atb_data_0_rd_en   = it_atb_data_0_sel & it_rd;
  assign it_atb_data_0_rd_data = {{31-(CXFUNNEL_ATB_DATA_WIDTH/8){1'b0}},it_atb_data_0_rd_reg};

  //---------------------------------------------------------------------------
  // Sequential block for writing into the Data 0 register
  // Integration test data 0 register   : Offset 0xEEC ( R/W )
  //---------------------------------------------------------------------------
  always @(posedge clk or negedge resetn)
  begin : p_it_atb_data_0_wr_reg
    if (!resetn)
      it_atb_data_0_wr_reg <= {(CXFUNNEL_ATB_DATA_WIDTH/8)+1{1'b0}};
    else
      if(it_atb_data_0_wr_en)
        it_atb_data_0_wr_reg <= write_data[(CXFUNNEL_ATB_DATA_WIDTH/8):0];
   end // block: p_it_atb_data_0_wr_reg

  //---------------------------------------------------------------------------
  // Sequential block for writing into the IT CTRL 0 register
  // Integration test data 0 register   : Offset 0xEF8 ( R/W )
  // Bits 7:2 are reserved
  // Actual register is implemented without missing bits to avoid lint errors
  //---------------------------------------------------------------------------
  always @(posedge clk or negedge resetn)
  begin : p_it_atb_ctr_0_wr_reg
    if (!resetn)
      begin
      it_atb_ctr_0_wr_reg[CXFUNNEL_ATBYTES_WIDTH+1:0] <= {CXFUNNEL_ATBYTES_WIDTH+2{1'b0}};
      end
    else
      if(it_atb_ctr_0_wr_en)
        begin
        it_atb_ctr_0_wr_reg[CXFUNNEL_ATBYTES_WIDTH+1:2]<= write_data[CXFUNNEL_ATBYTES_WIDTH+7:8];
        it_atb_ctr_0_wr_reg[1:0]<= write_data[1:0];
        end
   end // block: p_it_atb_ctr_0_wr_reg



  //---------------------------------------------------------------------------
  // Sequential block for writing into the IT CTRL 1 register
  // Integration test data 0 register   : Offset 0xEF4 ( R/W )
  //---------------------------------------------------------------------------
  always @(posedge clk or negedge resetn)
  begin : p_it_atb_ctr_1_wr_reg
    if (!resetn)
      it_atb_ctr_1_wr_reg <= {7{1'b0}};
    else
      if(it_atb_ctr_1_wr_en)
        it_atb_ctr_1_wr_reg <= write_data[6:0];
   end // block: p_it_atb_ctr_1_wr_reg

  //---------------------------------------------------------------------------
  // Sequential block for writing into the IT CTRL 2 register
  // Integration test data 0 register   : Offset 0xEF0 ( R/W )
  //---------------------------------------------------------------------------
  always @(posedge clk or negedge resetn)
  begin : p_it_atb_ctr_2_wr_reg
    if (!resetn)
      it_atb_ctr_2_wr_reg <= {2{1'b0}};
    else
      if(it_atb_ctr_2_wr_en)
        it_atb_ctr_2_wr_reg <= write_data[1:0];
   end // block: p_it_atb_ctr_2_wr_reg


  //---------------------------------------------------------------------------
  // Integration register : Offset 0xEF0 ( R/W )
  //---------------------------------------------------------------------------
  assign it_atb_ctr_2_wr_en   = it_atb_ctr_2_sel & it_wr;
  assign it_atb_ctr_2_rd_en   = it_atb_ctr_2_sel & it_rd;
  assign it_atb_ctr_2_rd_data = {{30{1'b0}},it_atb_ctr_2_rd_reg};

  //---------------------------------------------------------------------------
  // Integration register : Offset 0xEF4 ( R/W )
  //---------------------------------------------------------------------------
  assign it_atb_ctr_1_wr_en   = it_atb_ctr_1_sel & it_wr;
  assign it_atb_ctr_1_rd_en   = it_atb_ctr_1_sel & it_rd;
  assign it_atb_ctr_1_rd_data = {{25{1'b0}},it_atb_ctr_1_rd_reg};

  //---------------------------------------------------------------------------
  // Integration register : Offset 0xEF8 ( R/W )
  //---------------------------------------------------------------------------
  assign it_atb_ctr_0_wr_en   = it_atb_ctr_0_sel & it_wr;
  assign it_atb_ctr_0_rd_en   = it_atb_ctr_0_sel & it_rd;
  assign it_atb_ctr_0_rd_data = {{32-CXFUNNEL_ATBYTES_WIDTH-8{1'b0}},it_atb_ctr_0_rd_reg[CXFUNNEL_ATBYTES_WIDTH+1:2],{6{1'b0}},it_atb_ctr_0_rd_reg[1:0]};

  //---------------------------------------------------------------------------
  // The read data is driven out from the register module.
  //---------------------------------------------------------------------------
  assign read_data   = (
                      ({32{fun_ctl_rd_en}}       & fun_ctl_rd_data)       |
                      ({32{pri_ctl_rd_en}}       & pri_ctl_rd_data)       |
                      ({32{itc_rd_en}}           & itc_rd_data)           |
                      ({32{it_atb_data_0_rd_en}} & it_atb_data_0_rd_data)  |
                      ({32{it_atb_ctr_0_rd_en}}  & it_atb_ctr_0_rd_data)  |
                      ({32{it_atb_ctr_1_rd_en}}  & it_atb_ctr_1_rd_data)  |
                      ({32{it_atb_ctr_2_rd_en}}  & it_atb_ctr_2_rd_data)  |
                      ({32{claim_tag_set_rd_en}} & claim_tag_set_rd_data) |
                      ({32{claim_tag_clr_rd_en}} & claim_tag_clr_rd_data) |
                      ({32{lock_status_rd_en}}   & lock_status_rd_data)   |
                      ({32{auth_status_rd_en}}   & auth_status_rd_data)   |
                      ({32{device_id_rd_en}}     & device_id_rd_data)     |
                      ({32{device_type_rd_en}}   & device_type_rd_data)   |
                      ({32{periph_id_0_rd_en}}   & periph_id_0_rd_data)   |
                      ({32{periph_id_1_rd_en}}   & periph_id_1_rd_data)   |
                      ({32{periph_id_2_rd_en}}   & periph_id_2_rd_data)   |
                      ({32{periph_id_3_rd_en}}   & periph_id_3_rd_data)   |
                      ({32{periph_id_4_rd_en}}   & periph_id_4_rd_data)   |
                      ({32{periph_id_5_rd_en}}   & periph_id_5_rd_data)   |
                      ({32{periph_id_6_rd_en}}   & periph_id_6_rd_data)   |
                      ({32{periph_id_7_rd_en}}   & periph_id_7_rd_data)   |
                      ({32{comp_id_0_rd_en}}     & comp_id_0_rd_data)     |
                      ({32{comp_id_1_rd_en}}     & comp_id_1_rd_data)     |
                      ({32{comp_id_2_rd_en}}     & comp_id_2_rd_data)     |
                      ({32{comp_id_3_rd_en}}     & comp_id_3_rd_data)
                     );


`ifdef ARM_ASSERT_ON
  //----------------------------------------------------------------------------
  // OVL Assertions
  //----------------------------------------------------------------------------

  //----------------------------------------------------------------------------
  // Read enables should be mutually exclusive.
  //----------------------------------------------------------------------------
  assert_zero_one_hot #(`OVL_ERROR, 23, `OVL_ASSERT,
    "OVL Message : CXFUNNEL_RegP - Read enables should be exclusive")
      uzovl_cxatbfunnel_reg_selp
        (
         .clk         (clk),
         .reset_n     (resetn),
         .test_expr   ({fun_ctl_rd_en,pri_ctl_rd_en,itc_rd_en,
                        it_atb_ctr_0_rd_en,
                        it_atb_ctr_2_rd_en,claim_tag_set_rd_en,
                        claim_tag_clr_rd_en,lock_status_rd_en,auth_status_rd_en,
                        device_id_rd_en,device_type_rd_en,periph_id_0_rd_en,
                        periph_id_1_rd_en,periph_id_2_rd_en,periph_id_3_rd_en,
                        periph_id_4_rd_en,periph_id_5_rd_en,periph_id_6_rd_en,
                        periph_id_7_rd_en,comp_id_0_rd_en,comp_id_1_rd_en,
                        comp_id_2_rd_en,comp_id_3_rd_en})
        );

  assert_zero_one_hot #(`OVL_ERROR, 6, `OVL_ASSERT,
    "OVL Message : cxatbfunnel_reg - It is illegal to have more than one ATB slave port enabled while in Integration mode")
      uzovl_cxatbfunnel_en_port
        (
         .clk         (clk),
         .reset_n     (resetn),
         .test_expr   ({

                        (itc_reg & en_port_0),

                        (itc_reg & en_port_1),

                        (itc_reg & en_port_2),

                        (itc_reg & en_port_3),

                        (itc_reg & en_port_4),

                        (itc_reg & en_port_5)
                        })
        );

  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxatbfunnel_reg - Port0 - It is illegal to change the programmed priority when a port is enabled")
      uzovl_cxatbfunnel_atready_s0
        (
         .clk         (clk),
         .reset_n     (resetn),
         .test_expr   (pri_ctl_wr_en & en_port_int_0 &
                      (pri_ctl_write_data_port_0 != pri_ctl_reg[2:0]))
        );

  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxatbfunnel_reg - Port1 - It is illegal to change the programmed priority when a port is enabled")
      uzovl_cxatbfunnel_atready_s1
        (
         .clk         (clk),
         .reset_n     (resetn),
         .test_expr   (pri_ctl_wr_en & en_port_int_1 &
                      (pri_ctl_write_data_port_1 != pri_ctl_reg[5:3]))
        );


  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxatbfunnel_reg - Port2 - It is illegal to change the programmed priority when a port is enabled")
      uzovl_cxatbfunnel_atready_s2
        (
         .clk         (clk),
         .reset_n     (resetn),
         .test_expr   (pri_ctl_wr_en & en_port_int_2 &
                      (pri_ctl_write_data_port_2 != pri_ctl_reg[8:6]))
        );
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxatbfunnel_reg - Port3 - It is illegal to change the programmed priority when a port is enabled")
      uzovl_cxatbfunnel_atready_s3
        (
         .clk         (clk),
         .reset_n     (resetn),
         .test_expr   (pri_ctl_wr_en & en_port_int_3 &
                      (pri_ctl_write_data_port_3 != pri_ctl_reg[11:9]))
        );
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxatbfunnel_reg - Port4 - It is illegal to change the programmed priority when a port is enabled")
      uzovl_cxatbfunnel_atready_s4
        (
         .clk         (clk),
         .reset_n     (resetn),
         .test_expr   (pri_ctl_wr_en & en_port_int_4 &
                      (pri_ctl_write_data_port_4 != pri_ctl_reg[14:12]))
        );
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxatbfunnel_reg - Port5 - It is illegal to change the programmed priority when a port is enabled")
      uzovl_cxatbfunnel_atready_s5
        (
         .clk         (clk),
         .reset_n     (resetn),
         .test_expr   (pri_ctl_wr_en & en_port_int_5 &
                      (pri_ctl_write_data_port_5 != pri_ctl_reg[17:15]))
        );

`endif

endmodule // cxatbfunnel_reg_blk_6_pro
