//-----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2004-2015 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//    Checked In : $Date: 2014-01-15 12:32:16 +0000 (Wed, 15 Jan 2014) $
//    Revision   : $Revision: 38664 $
//    Release    : CoreSight-SoC-TM100-r3p2-00rel0
//-----------------------------------------------------------------------------
//
// ----------------------------------------------------------------------------
//  Purpose : SWJ-DP Definitions
// ----------------------------------------------------------------------------

// Main watcher state machine encoding for cxdapswjdp_swj_watcher.v

// DAPSwjWatcher makes several assumptions about the encodings used here, including:
// [9:8] : 00 = JTAG, 11 = SW, 01 = Dormant
//   [7] : Searching for dormant exit sequence (input has unsafe timing)
// Before changing any encodings, check the logic that uses them.

  // JTAG selected

localparam SWJ_JFROMS   = 10'b0001001111;    // Retiming cycle, SWD to JTAG
localparam SWJ_JFROMD   = 10'b0001001011;    // Retiming cycle, Dormant to JTAG

localparam SWJ_JRST     = 10'b0000000000;    // JTAG-Selected - JTAG-DP performing transactions

localparam SWJ_J2SSEQ1  = 10'b0000000001;    // Received 1st bit in JTAG to SWD Select sequence
localparam SWJ_J2SSEQ2  = 10'b0000000010;    // Received 2nd bit in JTAG to SWD Select sequence
localparam SWJ_J2SSEQ3  = 10'b0000000011;    // Received 3rd bit in JTAG to SWD Select sequence
localparam SWJ_J2SSEQ4  = 10'b0000000100;    // Received 4th bit in JTAG to SWD Select sequence
localparam SWJ_J2SSEQ5  = 10'b0000000101;    // Received 5th bit in JTAG to SWD Select sequence
localparam SWJ_J2SSEQ6  = 10'b0000000110;    // Received 6th bit in JTAG to SWD Select sequence
localparam SWJ_J2SSEQ7  = 10'b0000000111;    // Received 7th bit in JTAG to SWD Select sequence
localparam SWJ_J2SSEQ8  = 10'b0000001000;    // Received 8th bit in JTAG to SWD Select sequence
localparam SWJ_J2SSEQ9  = 10'b0000001001;    // Received 9th bit in JTAG to SWD Select sequence
localparam SWJ_J2SSEQ10 = 10'b0000001010;    // Received 10th bit in JTAG to SWD Select sequence
localparam SWJ_J2SSEQ11 = 10'b0000001011;    // Received 11th bit in JTAG to SWD Select sequence
localparam SWJ_J2SSEQ12 = 10'b0000001100;    // Received 12th bit in JTAG to SWD Select sequence
localparam SWJ_J2SSEQ13 = 10'b0000001101;    // Received 13th bit in JTAG to SWD Select sequence
localparam SWJ_J2SSEQ14 = 10'b0000001110;    // Received 14th bit in JTAG to SWD Select sequence

localparam SWJ_JSLP     = 10'b0000100000;    // JTAG-Selected - JTAG-DP performing transactions
localparam SWJ_JZBS0    = 10'b0000100001;    // Zero-bit-scan level 0
localparam SWJ_JZBS1    = 10'b0000100010;    // Zero-bit-scan level 1
localparam SWJ_JZBS2    = 10'b0000100011;    // Zero-bit-scan level 2
localparam SWJ_JZBS3    = 10'b0000100100;    // Zero-bit-scan level 3
localparam SWJ_JZBS4    = 10'b0000100101;    // Zero-bit-scan level 4
localparam SWJ_JZBS5    = 10'b0000100110;    // Zero-bit-scan level 5
localparam SWJ_JZBS6    = 10'b0000100111;    // Zero-bit-scan level 6
localparam SWJ_JLOCK6   = 10'b0000101000;    // Zero-bit-scan level 6 locked
localparam SWJ_JLOCKN   = 10'b0000101001;    // Zero-bit-scan level locked at other level

  // SWD selected

localparam SWJ_SFROMJD  = 10'b1101000000;    // Retiming cycle, JTAG/Dormant to SWD

localparam SWJ_SRST     = 10'b1100000000;    // SW-Selected - SW-DP in line reset

localparam SWJ_SSEQ1    = 10'b1100000001;    // Received 1st bit in SWD to JTAG/Dormant Select sequence
localparam SWJ_SSEQ2    = 10'b1100000010;    // Received 2nd bit in SWD to JTAG/Dormant Select sequence
localparam SWJ_SSEQ3    = 10'b1100000011;    // Received 3rd bit in SWD to JTAG/Dormant Select sequence
localparam SWJ_SSEQ4    = 10'b1100000100;    // Received 4th bit in SWD to JTAG/Dormant Select sequence
localparam SWJ_SSEQ5    = 10'b1100000101;    // Received 5th bit in SWD to JTAG/Dormant Select sequence
localparam SWJ_SSEQ6    = 10'b1100000110;    // Received 6th bit in SWD to JTAG/Dormant Select sequence
localparam SWJ_SSEQ7    = 10'b1100000111;    // Received 7th bit in SWD to JTAG/Dormant Select sequence

localparam SWJ_S2JSEQ8  = 10'b1100001000;    // Received 8th bit in SWD to JTAG Select sequence
localparam SWJ_S2JSEQ9  = 10'b1100001001;    // Received 9th bit in SWD to JTAG Select sequence
localparam SWJ_S2JSEQ10 = 10'b1100001010;    // Received 10th bit in SWD to JTAG Select sequence
localparam SWJ_S2JSEQ11 = 10'b1100001011;    // Received 11th bit in SWD to JTAG Select sequence
localparam SWJ_S2JSEQ12 = 10'b1100001100;    // Received 12th bit in SWD to JTAG Select sequence
localparam SWJ_S2JSEQ13 = 10'b1100001101;    // Received 13th bit in SWD to JTAG Select sequence
localparam SWJ_S2JSEQ14 = 10'b1100001110;    // Received 14th bit in SWD to JTAG Select sequence

localparam SWJ_S2DSEQ8  = 10'b1100011000;    // Received 8th bit in SWD to Dormant Select sequence
localparam SWJ_S2DSEQ9  = 10'b1100011001;    // Received 9th bit in SWD to Dormant Select sequence
localparam SWJ_S2DSEQ10 = 10'b1100011010;    // Received 10th bit in SWD to Dormant Select sequence
localparam SWJ_S2DSEQ11 = 10'b1100011011;    // Received 11th bit in SWD to Dormant Select sequence
localparam SWJ_S2DSEQ12 = 10'b1100011100;    // Received 12th bit in SWD to Dormant Select sequence
localparam SWJ_S2DSEQ13 = 10'b1100011101;    // Received 13th bit in SWD to Dormant Select sequence
localparam SWJ_S2DSEQ14 = 10'b1100011110;    // Received 14th bit in SWD to Dormant Select sequence

localparam SWJ_SSLP     = 10'b1100100000;    // SW selected - SW-DP performing transactions

  // Dormant selected

localparam SWJ_DFROMJS  = 10'b0101000000;    // Retiming cycle, JTAG to Dormant

localparam SWJ_DSLP     = 10'b0100000000;    // Dormant entry state; switch to synchronizer
localparam SWJ_DSYNC1   = 10'b0100000001;    // Second cycle switching to synchronizer
localparam SWJ_DSYNC2   = 10'b0100000010;    // Third cycle switching to synchronizer

localparam SWJ_DSEQ0    = 10'b0110000000;    // Switched to synchronizer; looking for first bit of
                                             // Dormant exit sequence (encoding not used by LFSR)
localparam SWJ_DSEQ1    = 10'b0111001001;    // Received 1st bit in Dormant exit sequence
localparam SWJ_DSEQ127  = 10'b0110010010;    // Received 127th bit in Dormant exit sequence
localparam SWJ_DSEQPREFIX = 3'b011;          // For combining with dormant LFSR
localparam SWJ_DSEQX    = 10'b011???????;    // Wild card for Dormant LFSR states

localparam SWJ_DSYNC3   = 10'b0100000011;    // Fourth padding cycle; on switch back from synchronizer

localparam SWJ_DSEL0    = 10'b0100000100;    // Cycle 1 of exit code
localparam SWJ_DSEL1    = 10'b0100000101;    // Cycle 2 of exit code
localparam SWJ_DSELA2   = 10'b0100000110;    // Cycle 3 of exit code: searching for '0101' for ARM
localparam SWJ_DSELA3   = 10'b0100000111;    // Cycle 4 of exit code: searching for '0101' for ARM
localparam SWJ_DSELA4   = 10'b0100001000;    // Cycle 5 of exit code: '0101' selected, go to JTAG or SWD?
localparam SWJ_DSELAJ5  = 10'b0100001001;    // Cycle 6 of exit code: '0101' selected, go to JTAG?
localparam SWJ_DSELAJ6  = 10'b0100001010;    // Cycle 7 of exit code: '0101' selected, go to JTAG?
localparam SWJ_DSELAS5  = 10'b0100001101;    // Cycle 6 of exit code: '0101' selected, go to SWD?
localparam SWJ_DSELAS6  = 10'b0100001110;    // Cycle 7 of exit code: '0101' selected, go to SWD?
localparam SWJ_DSELJ2   = 10'b0100010000;    // Cycle 3 of exit code: searching for '00x0 00x' for JTAG
localparam SWJ_DSELJ3   = 10'b0100010001;    // Cycle 4 of exit code: searching for '00x0 00x' for JTAG
localparam SWJ_DSELJ4   = 10'b0100010010;    // Cycle 5 of exit code: searching for '00x0 00x' for JTAG
localparam SWJ_DSELJ5   = 10'b0100010011;    // Cycle 6 of exit code: searching for '00x0 00x' for JTAG
localparam SWJ_DSELJ6   = 10'b0100010100;    // Cycle 7 of exit code: searching for '00x0 00x' for JTAG
localparam SWJ_DSELJ7   = 10'b0100010101;    // Cycle 8 of exit code: select short or long branch

localparam SWJ_DSELJ8   = 10'b0100010110;    // Short branch
localparam SWJ_DSKIP0   = 10'b0100100000;    // First cycle of long branch
localparam SWJ_DSKIP24  = 10'b0100111000;    // Last cycle of long branch
localparam SWJ_DSKIPPREFIX = 5'b01001;       // Long branch prefix
localparam SWJ_DSKIPX   = 10'b01001?????;    // Long branch wild card

localparam SWJ_DZEB     = 10'b0100010111;    // Zebra code entry
localparam SWJ_DZEB0    = 10'b0100011000;    // Zebra code branch 0
localparam SWJ_DZEB1    = 10'b0100011010;    // Zebra code branch 1
localparam SWJ_DZEBX1   = 10'b0100011011;    // Zebra code branch 1 exit

  // Undefined

localparam SWJ_UNDEF    = 10'bXXXXXXXXXX;    // Undefined state
