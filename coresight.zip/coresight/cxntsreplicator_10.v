
//-----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2012-2015 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//  Version and Release Control Information:
//
//  File Name           : cxntsreplicator_xmlcfg.v.xsl
//
//  Checked In          : $Date: 2015-02-16 14:55:41 +0000 (Mon, 16 Feb 2015) $
//
//  File Revision       : $Revision: 41661 $
//
//  Release Information : CoreSight-SoC-TM100-r3p2-00rel0
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// Abstract : CoreSight NTSREPLICATOR - Top Level Block
//-----------------------------------------------------------------------------
//
// cxntsreplicator - CoreSight NTSREPLICATOR (Narrow Timestamp Replicator)
// -----------------------------------------------------------------------
// Coresight XDK TS Replicator is a component which replicates the encoded form
// of timestamp into the required number of encoded timestamps
//-----------------------------------------------------------------------------

module cxntsreplicator_10 (

  // Clock and Reset
  input wire clk,
  input wire resetn,
  
  // Master Interface0
  output wire [6:0] tsbitm0,
  output wire [1:0] tssyncm0,
  input wire tssyncreadym0,
 
  // Master Interface1
  output wire [6:0] tsbitm1,
  output wire [1:0] tssyncm1,
  input wire tssyncreadym1,
 
  // Master Interface2
  output wire [6:0] tsbitm2,
  output wire [1:0] tssyncm2,
  input wire tssyncreadym2,
 
  // Master Interface3
  output wire [6:0] tsbitm3,
  output wire [1:0] tssyncm3,
  input wire tssyncreadym3,
 
  // Master Interface4
  output wire [6:0] tsbitm4,
  output wire [1:0] tssyncm4,
  input wire tssyncreadym4,
 
  // Master Interface5
  output wire [6:0] tsbitm5,
  output wire [1:0] tssyncm5,
  input wire tssyncreadym5,
 
  // Master Interface6
  output wire [6:0] tsbitm6,
  output wire [1:0] tssyncm6,
  input wire tssyncreadym6,
 
  // Master Interface7
  output wire [6:0] tsbitm7,
  output wire [1:0] tssyncm7,
  input wire tssyncreadym7,
 
  // Master Interface8
  output wire [6:0] tsbitm8,
  output wire [1:0] tssyncm8,
  input wire tssyncreadym8,
 
  // Master Interface9
  output wire [6:0] tsbitm9,
  output wire [1:0] tssyncm9,
  input wire tssyncreadym9,
 
  // Slave Interface
  input wire [6:0] tsbits,
  input wire [1:0] tssyncs,
  output wire tssyncreadys

  );

//----------------------------------------------------------------------------
// Wires
//----------------------------------------------------------------------------
  wire [9:0] mst_if_rdy_rg;
  wire [9:0] mst_if_rdy;
  wire ts_expct_rpt;
  wire tssyncs_rg_en;
  wire tssyncs_sync_mark;

//----------------------------------------------------------------------------
// reg declarations
//----------------------------------------------------------------------------
  reg [9:0] ts_data_stored_nxt;
  reg [9:0] ts_data_stored;
  reg [1:0] tssyncs_rg;

//============================================================================
//
// Main body of code
//
//============================================================================

//============================================================================
// NTSREPLICATOR combines the ready input from multiple slave bridges and
// provides a unified ready output to the master interface.
// NTSREPLICATOR can be connected to output of TSE to distribute the encoded
// data and synchronization channel.
//
// It can also be connected to output of each bridge for further
// distribution to multiple bridges downstream. This can only be used to
// distribute data among bridges. It can only be used to distribute data to
// bridges in the same power domain.
//
// This has a simple structure to aggregate all
// the TSSYNCREADYMn signals from the slave Bridges. It has a FF associated
// with each slave Bridge. This FF stores a status bit called ts_data_stored(n)
// (TSSYNC data stored). TSSYNC will be sent to respective bridges only if
// ts_data_stored(n) is reset. If this status bit is set then 'b00' will be sent
// to Bridge(n) indicating invalid TSSYNC value.
//
// TSBITS will be broadcast to all the Bridges unchanged.
//============================================================================

//============================================================================
// This has a simple structure to aggregate all
// the TSSYNCREADYMn signals from the slave Bridges. It has a FF associated
// with each slave Bridge. This FF stores a status bit called ts_data_stored(n)
// (TSSYNC data stored). If this is set or the slave bridge is ready then that
// slave bridge is considered ready for the current cycle. It is aggregated
// across all the channels
//============================================================================
  assign ts_expct_rpt = |ts_data_stored;

  assign tssyncs_rg_en = (tssyncs != tssyncs_rg);

  always @(posedge clk or negedge resetn)
    begin
      if (!resetn)
        tssyncs_rg <= {2{1'b0}};
      else if (tssyncs_rg_en)
        tssyncs_rg <= tssyncs;
    end

  assign tssyncs_sync_mark = (tssyncs_rg_en & (tssyncs == 2'b01)) & ts_expct_rpt;

  assign tssyncreadys = (
  
                         (tssyncreadym0 |
                           (~tssyncs_sync_mark & ts_data_stored[0])) &
                         (tssyncreadym1 |
                           (~tssyncs_sync_mark & ts_data_stored[1])) &
                         (tssyncreadym2 |
                           (~tssyncs_sync_mark & ts_data_stored[2])) &
                         (tssyncreadym3 |
                           (~tssyncs_sync_mark & ts_data_stored[3])) &
                         (tssyncreadym4 |
                           (~tssyncs_sync_mark & ts_data_stored[4])) &
                         (tssyncreadym5 |
                           (~tssyncs_sync_mark & ts_data_stored[5])) &
                         (tssyncreadym6 |
                           (~tssyncs_sync_mark & ts_data_stored[6])) &
                         (tssyncreadym7 |
                           (~tssyncs_sync_mark & ts_data_stored[7])) &
                         (tssyncreadym8 |
                           (~tssyncs_sync_mark & ts_data_stored[8])) &
                         (tssyncreadym9 |
                           (~tssyncs_sync_mark & ts_data_stored[9]))
                         );

  
//============================================================================
// In the current cycle if other slaves are not ready but this slave is ready to
// accept sync-value then ts_data_stored will be set, to indicate that this
// slave does not have to store this data. Once all the other slaves are ready
// to accept data then this bit will be cleared in anticipation that the next
// sync-value and TSBIT value is expected to be new and valid.
//============================================================================
  assign mst_if_rdy_rg[0] = (
  
                         (tssyncreadym1 | ts_data_stored[1]) &
   
                         (tssyncreadym2 | ts_data_stored[2]) &
   
                         (tssyncreadym3 | ts_data_stored[3]) &
   
                         (tssyncreadym4 | ts_data_stored[4]) &
   
                         (tssyncreadym5 | ts_data_stored[5]) &
   
                         (tssyncreadym6 | ts_data_stored[6]) &
   
                         (tssyncreadym7 | ts_data_stored[7]) &
   
                         (tssyncreadym8 | ts_data_stored[8]) &
   
                         (tssyncreadym9 | ts_data_stored[9]) &
   
                         {1'b1}
                       );

  assign mst_if_rdy[0] = (
  
                         (tssyncreadym1) &
   
                         (tssyncreadym2) &
   
                         (tssyncreadym3) &
   
                         (tssyncreadym4) &
   
                         (tssyncreadym5) &
   
                         (tssyncreadym6) &
   
                         (tssyncreadym7) &
   
                         (tssyncreadym8) &
   
                         (tssyncreadym9) &
   
                         {1'b1}
                       );
  always @(*)
    begin
      case (ts_data_stored[0])
        1'b0 : begin
          ts_data_stored_nxt[0] = ~(mst_if_rdy_rg[0]) & tssyncreadym0 & (|tssyncs);
        end
        1'b1 : begin
          if (tssyncs_sync_mark) begin
            ts_data_stored_nxt[0] =  tssyncreadym0 & ~mst_if_rdy[0];
          end else begin
            ts_data_stored_nxt[0] = ~(mst_if_rdy_rg[0]);
          end
        end
        default : ts_data_stored_nxt[0] = 1'bx;
      endcase
    end

 
//============================================================================
// In the current cycle if other slaves are not ready but this slave is ready to
// accept sync-value then ts_data_stored will be set, to indicate that this
// slave does not have to store this data. Once all the other slaves are ready
// to accept data then this bit will be cleared in anticipation that the next
// sync-value and TSBIT value is expected to be new and valid.
//============================================================================
  assign mst_if_rdy_rg[1] = (
  
                         (tssyncreadym0 | ts_data_stored[0]) &
   
                         (tssyncreadym2 | ts_data_stored[2]) &
   
                         (tssyncreadym3 | ts_data_stored[3]) &
   
                         (tssyncreadym4 | ts_data_stored[4]) &
   
                         (tssyncreadym5 | ts_data_stored[5]) &
   
                         (tssyncreadym6 | ts_data_stored[6]) &
   
                         (tssyncreadym7 | ts_data_stored[7]) &
   
                         (tssyncreadym8 | ts_data_stored[8]) &
   
                         (tssyncreadym9 | ts_data_stored[9]) &
   
                         {1'b1}
                       );

  assign mst_if_rdy[1] = (
  
                         (tssyncreadym0) &
   
                         (tssyncreadym2) &
   
                         (tssyncreadym3) &
   
                         (tssyncreadym4) &
   
                         (tssyncreadym5) &
   
                         (tssyncreadym6) &
   
                         (tssyncreadym7) &
   
                         (tssyncreadym8) &
   
                         (tssyncreadym9) &
   
                         {1'b1}
                       );
  always @(*)
    begin
      case (ts_data_stored[1])
        1'b0 : begin
          ts_data_stored_nxt[1] = ~(mst_if_rdy_rg[1]) & tssyncreadym1 & (|tssyncs);
        end
        1'b1 : begin
          if (tssyncs_sync_mark) begin
            ts_data_stored_nxt[1] =  tssyncreadym1 & ~mst_if_rdy[1];
          end else begin
            ts_data_stored_nxt[1] = ~(mst_if_rdy_rg[1]);
          end
        end
        default : ts_data_stored_nxt[1] = 1'bx;
      endcase
    end

 
//============================================================================
// In the current cycle if other slaves are not ready but this slave is ready to
// accept sync-value then ts_data_stored will be set, to indicate that this
// slave does not have to store this data. Once all the other slaves are ready
// to accept data then this bit will be cleared in anticipation that the next
// sync-value and TSBIT value is expected to be new and valid.
//============================================================================
  assign mst_if_rdy_rg[2] = (
  
                         (tssyncreadym0 | ts_data_stored[0]) &
   
                         (tssyncreadym1 | ts_data_stored[1]) &
   
                         (tssyncreadym3 | ts_data_stored[3]) &
   
                         (tssyncreadym4 | ts_data_stored[4]) &
   
                         (tssyncreadym5 | ts_data_stored[5]) &
   
                         (tssyncreadym6 | ts_data_stored[6]) &
   
                         (tssyncreadym7 | ts_data_stored[7]) &
   
                         (tssyncreadym8 | ts_data_stored[8]) &
   
                         (tssyncreadym9 | ts_data_stored[9]) &
   
                         {1'b1}
                       );

  assign mst_if_rdy[2] = (
  
                         (tssyncreadym0) &
   
                         (tssyncreadym1) &
   
                         (tssyncreadym3) &
   
                         (tssyncreadym4) &
   
                         (tssyncreadym5) &
   
                         (tssyncreadym6) &
   
                         (tssyncreadym7) &
   
                         (tssyncreadym8) &
   
                         (tssyncreadym9) &
   
                         {1'b1}
                       );
  always @(*)
    begin
      case (ts_data_stored[2])
        1'b0 : begin
          ts_data_stored_nxt[2] = ~(mst_if_rdy_rg[2]) & tssyncreadym2 & (|tssyncs);
        end
        1'b1 : begin
          if (tssyncs_sync_mark) begin
            ts_data_stored_nxt[2] =  tssyncreadym2 & ~mst_if_rdy[2];
          end else begin
            ts_data_stored_nxt[2] = ~(mst_if_rdy_rg[2]);
          end
        end
        default : ts_data_stored_nxt[2] = 1'bx;
      endcase
    end

 
//============================================================================
// In the current cycle if other slaves are not ready but this slave is ready to
// accept sync-value then ts_data_stored will be set, to indicate that this
// slave does not have to store this data. Once all the other slaves are ready
// to accept data then this bit will be cleared in anticipation that the next
// sync-value and TSBIT value is expected to be new and valid.
//============================================================================
  assign mst_if_rdy_rg[3] = (
  
                         (tssyncreadym0 | ts_data_stored[0]) &
   
                         (tssyncreadym1 | ts_data_stored[1]) &
   
                         (tssyncreadym2 | ts_data_stored[2]) &
   
                         (tssyncreadym4 | ts_data_stored[4]) &
   
                         (tssyncreadym5 | ts_data_stored[5]) &
   
                         (tssyncreadym6 | ts_data_stored[6]) &
   
                         (tssyncreadym7 | ts_data_stored[7]) &
   
                         (tssyncreadym8 | ts_data_stored[8]) &
   
                         (tssyncreadym9 | ts_data_stored[9]) &
   
                         {1'b1}
                       );

  assign mst_if_rdy[3] = (
  
                         (tssyncreadym0) &
   
                         (tssyncreadym1) &
   
                         (tssyncreadym2) &
   
                         (tssyncreadym4) &
   
                         (tssyncreadym5) &
   
                         (tssyncreadym6) &
   
                         (tssyncreadym7) &
   
                         (tssyncreadym8) &
   
                         (tssyncreadym9) &
   
                         {1'b1}
                       );
  always @(*)
    begin
      case (ts_data_stored[3])
        1'b0 : begin
          ts_data_stored_nxt[3] = ~(mst_if_rdy_rg[3]) & tssyncreadym3 & (|tssyncs);
        end
        1'b1 : begin
          if (tssyncs_sync_mark) begin
            ts_data_stored_nxt[3] =  tssyncreadym3 & ~mst_if_rdy[3];
          end else begin
            ts_data_stored_nxt[3] = ~(mst_if_rdy_rg[3]);
          end
        end
        default : ts_data_stored_nxt[3] = 1'bx;
      endcase
    end

 
//============================================================================
// In the current cycle if other slaves are not ready but this slave is ready to
// accept sync-value then ts_data_stored will be set, to indicate that this
// slave does not have to store this data. Once all the other slaves are ready
// to accept data then this bit will be cleared in anticipation that the next
// sync-value and TSBIT value is expected to be new and valid.
//============================================================================
  assign mst_if_rdy_rg[4] = (
  
                         (tssyncreadym0 | ts_data_stored[0]) &
   
                         (tssyncreadym1 | ts_data_stored[1]) &
   
                         (tssyncreadym2 | ts_data_stored[2]) &
   
                         (tssyncreadym3 | ts_data_stored[3]) &
   
                         (tssyncreadym5 | ts_data_stored[5]) &
   
                         (tssyncreadym6 | ts_data_stored[6]) &
   
                         (tssyncreadym7 | ts_data_stored[7]) &
   
                         (tssyncreadym8 | ts_data_stored[8]) &
   
                         (tssyncreadym9 | ts_data_stored[9]) &
   
                         {1'b1}
                       );

  assign mst_if_rdy[4] = (
  
                         (tssyncreadym0) &
   
                         (tssyncreadym1) &
   
                         (tssyncreadym2) &
   
                         (tssyncreadym3) &
   
                         (tssyncreadym5) &
   
                         (tssyncreadym6) &
   
                         (tssyncreadym7) &
   
                         (tssyncreadym8) &
   
                         (tssyncreadym9) &
   
                         {1'b1}
                       );
  always @(*)
    begin
      case (ts_data_stored[4])
        1'b0 : begin
          ts_data_stored_nxt[4] = ~(mst_if_rdy_rg[4]) & tssyncreadym4 & (|tssyncs);
        end
        1'b1 : begin
          if (tssyncs_sync_mark) begin
            ts_data_stored_nxt[4] =  tssyncreadym4 & ~mst_if_rdy[4];
          end else begin
            ts_data_stored_nxt[4] = ~(mst_if_rdy_rg[4]);
          end
        end
        default : ts_data_stored_nxt[4] = 1'bx;
      endcase
    end

 
//============================================================================
// In the current cycle if other slaves are not ready but this slave is ready to
// accept sync-value then ts_data_stored will be set, to indicate that this
// slave does not have to store this data. Once all the other slaves are ready
// to accept data then this bit will be cleared in anticipation that the next
// sync-value and TSBIT value is expected to be new and valid.
//============================================================================
  assign mst_if_rdy_rg[5] = (
  
                         (tssyncreadym0 | ts_data_stored[0]) &
   
                         (tssyncreadym1 | ts_data_stored[1]) &
   
                         (tssyncreadym2 | ts_data_stored[2]) &
   
                         (tssyncreadym3 | ts_data_stored[3]) &
   
                         (tssyncreadym4 | ts_data_stored[4]) &
   
                         (tssyncreadym6 | ts_data_stored[6]) &
   
                         (tssyncreadym7 | ts_data_stored[7]) &
   
                         (tssyncreadym8 | ts_data_stored[8]) &
   
                         (tssyncreadym9 | ts_data_stored[9]) &
   
                         {1'b1}
                       );

  assign mst_if_rdy[5] = (
  
                         (tssyncreadym0) &
   
                         (tssyncreadym1) &
   
                         (tssyncreadym2) &
   
                         (tssyncreadym3) &
   
                         (tssyncreadym4) &
   
                         (tssyncreadym6) &
   
                         (tssyncreadym7) &
   
                         (tssyncreadym8) &
   
                         (tssyncreadym9) &
   
                         {1'b1}
                       );
  always @(*)
    begin
      case (ts_data_stored[5])
        1'b0 : begin
          ts_data_stored_nxt[5] = ~(mst_if_rdy_rg[5]) & tssyncreadym5 & (|tssyncs);
        end
        1'b1 : begin
          if (tssyncs_sync_mark) begin
            ts_data_stored_nxt[5] =  tssyncreadym5 & ~mst_if_rdy[5];
          end else begin
            ts_data_stored_nxt[5] = ~(mst_if_rdy_rg[5]);
          end
        end
        default : ts_data_stored_nxt[5] = 1'bx;
      endcase
    end

 
//============================================================================
// In the current cycle if other slaves are not ready but this slave is ready to
// accept sync-value then ts_data_stored will be set, to indicate that this
// slave does not have to store this data. Once all the other slaves are ready
// to accept data then this bit will be cleared in anticipation that the next
// sync-value and TSBIT value is expected to be new and valid.
//============================================================================
  assign mst_if_rdy_rg[6] = (
  
                         (tssyncreadym0 | ts_data_stored[0]) &
   
                         (tssyncreadym1 | ts_data_stored[1]) &
   
                         (tssyncreadym2 | ts_data_stored[2]) &
   
                         (tssyncreadym3 | ts_data_stored[3]) &
   
                         (tssyncreadym4 | ts_data_stored[4]) &
   
                         (tssyncreadym5 | ts_data_stored[5]) &
   
                         (tssyncreadym7 | ts_data_stored[7]) &
   
                         (tssyncreadym8 | ts_data_stored[8]) &
   
                         (tssyncreadym9 | ts_data_stored[9]) &
   
                         {1'b1}
                       );

  assign mst_if_rdy[6] = (
  
                         (tssyncreadym0) &
   
                         (tssyncreadym1) &
   
                         (tssyncreadym2) &
   
                         (tssyncreadym3) &
   
                         (tssyncreadym4) &
   
                         (tssyncreadym5) &
   
                         (tssyncreadym7) &
   
                         (tssyncreadym8) &
   
                         (tssyncreadym9) &
   
                         {1'b1}
                       );
  always @(*)
    begin
      case (ts_data_stored[6])
        1'b0 : begin
          ts_data_stored_nxt[6] = ~(mst_if_rdy_rg[6]) & tssyncreadym6 & (|tssyncs);
        end
        1'b1 : begin
          if (tssyncs_sync_mark) begin
            ts_data_stored_nxt[6] =  tssyncreadym6 & ~mst_if_rdy[6];
          end else begin
            ts_data_stored_nxt[6] = ~(mst_if_rdy_rg[6]);
          end
        end
        default : ts_data_stored_nxt[6] = 1'bx;
      endcase
    end

 
//============================================================================
// In the current cycle if other slaves are not ready but this slave is ready to
// accept sync-value then ts_data_stored will be set, to indicate that this
// slave does not have to store this data. Once all the other slaves are ready
// to accept data then this bit will be cleared in anticipation that the next
// sync-value and TSBIT value is expected to be new and valid.
//============================================================================
  assign mst_if_rdy_rg[7] = (
  
                         (tssyncreadym0 | ts_data_stored[0]) &
   
                         (tssyncreadym1 | ts_data_stored[1]) &
   
                         (tssyncreadym2 | ts_data_stored[2]) &
   
                         (tssyncreadym3 | ts_data_stored[3]) &
   
                         (tssyncreadym4 | ts_data_stored[4]) &
   
                         (tssyncreadym5 | ts_data_stored[5]) &
   
                         (tssyncreadym6 | ts_data_stored[6]) &
   
                         (tssyncreadym8 | ts_data_stored[8]) &
   
                         (tssyncreadym9 | ts_data_stored[9]) &
   
                         {1'b1}
                       );

  assign mst_if_rdy[7] = (
  
                         (tssyncreadym0) &
   
                         (tssyncreadym1) &
   
                         (tssyncreadym2) &
   
                         (tssyncreadym3) &
   
                         (tssyncreadym4) &
   
                         (tssyncreadym5) &
   
                         (tssyncreadym6) &
   
                         (tssyncreadym8) &
   
                         (tssyncreadym9) &
   
                         {1'b1}
                       );
  always @(*)
    begin
      case (ts_data_stored[7])
        1'b0 : begin
          ts_data_stored_nxt[7] = ~(mst_if_rdy_rg[7]) & tssyncreadym7 & (|tssyncs);
        end
        1'b1 : begin
          if (tssyncs_sync_mark) begin
            ts_data_stored_nxt[7] =  tssyncreadym7 & ~mst_if_rdy[7];
          end else begin
            ts_data_stored_nxt[7] = ~(mst_if_rdy_rg[7]);
          end
        end
        default : ts_data_stored_nxt[7] = 1'bx;
      endcase
    end

 
//============================================================================
// In the current cycle if other slaves are not ready but this slave is ready to
// accept sync-value then ts_data_stored will be set, to indicate that this
// slave does not have to store this data. Once all the other slaves are ready
// to accept data then this bit will be cleared in anticipation that the next
// sync-value and TSBIT value is expected to be new and valid.
//============================================================================
  assign mst_if_rdy_rg[8] = (
  
                         (tssyncreadym0 | ts_data_stored[0]) &
   
                         (tssyncreadym1 | ts_data_stored[1]) &
   
                         (tssyncreadym2 | ts_data_stored[2]) &
   
                         (tssyncreadym3 | ts_data_stored[3]) &
   
                         (tssyncreadym4 | ts_data_stored[4]) &
   
                         (tssyncreadym5 | ts_data_stored[5]) &
   
                         (tssyncreadym6 | ts_data_stored[6]) &
   
                         (tssyncreadym7 | ts_data_stored[7]) &
   
                         (tssyncreadym9 | ts_data_stored[9]) &
   
                         {1'b1}
                       );

  assign mst_if_rdy[8] = (
  
                         (tssyncreadym0) &
   
                         (tssyncreadym1) &
   
                         (tssyncreadym2) &
   
                         (tssyncreadym3) &
   
                         (tssyncreadym4) &
   
                         (tssyncreadym5) &
   
                         (tssyncreadym6) &
   
                         (tssyncreadym7) &
   
                         (tssyncreadym9) &
   
                         {1'b1}
                       );
  always @(*)
    begin
      case (ts_data_stored[8])
        1'b0 : begin
          ts_data_stored_nxt[8] = ~(mst_if_rdy_rg[8]) & tssyncreadym8 & (|tssyncs);
        end
        1'b1 : begin
          if (tssyncs_sync_mark) begin
            ts_data_stored_nxt[8] =  tssyncreadym8 & ~mst_if_rdy[8];
          end else begin
            ts_data_stored_nxt[8] = ~(mst_if_rdy_rg[8]);
          end
        end
        default : ts_data_stored_nxt[8] = 1'bx;
      endcase
    end

 
//============================================================================
// In the current cycle if other slaves are not ready but this slave is ready to
// accept sync-value then ts_data_stored will be set, to indicate that this
// slave does not have to store this data. Once all the other slaves are ready
// to accept data then this bit will be cleared in anticipation that the next
// sync-value and TSBIT value is expected to be new and valid.
//============================================================================
  assign mst_if_rdy_rg[9] = (
  
                         (tssyncreadym0 | ts_data_stored[0]) &
   
                         (tssyncreadym1 | ts_data_stored[1]) &
   
                         (tssyncreadym2 | ts_data_stored[2]) &
   
                         (tssyncreadym3 | ts_data_stored[3]) &
   
                         (tssyncreadym4 | ts_data_stored[4]) &
   
                         (tssyncreadym5 | ts_data_stored[5]) &
   
                         (tssyncreadym6 | ts_data_stored[6]) &
   
                         (tssyncreadym7 | ts_data_stored[7]) &
   
                         (tssyncreadym8 | ts_data_stored[8]) &
   
                         {1'b1}
                       );

  assign mst_if_rdy[9] = (
  
                         (tssyncreadym0) &
   
                         (tssyncreadym1) &
   
                         (tssyncreadym2) &
   
                         (tssyncreadym3) &
   
                         (tssyncreadym4) &
   
                         (tssyncreadym5) &
   
                         (tssyncreadym6) &
   
                         (tssyncreadym7) &
   
                         (tssyncreadym8) &
   
                         {1'b1}
                       );
  always @(*)
    begin
      case (ts_data_stored[9])
        1'b0 : begin
          ts_data_stored_nxt[9] = ~(mst_if_rdy_rg[9]) & tssyncreadym9 & (|tssyncs);
        end
        1'b1 : begin
          if (tssyncs_sync_mark) begin
            ts_data_stored_nxt[9] =  tssyncreadym9 & ~mst_if_rdy[9];
          end else begin
            ts_data_stored_nxt[9] = ~(mst_if_rdy_rg[9]);
          end
        end
        default : ts_data_stored_nxt[9] = 1'bx;
      endcase
    end

 

  always @(posedge clk or negedge resetn)
    begin
      if (!resetn)
        ts_data_stored <= {10{1'b0}};
      else
        ts_data_stored <= ts_data_stored_nxt;
    end

  
//============================================================================
// If data has already been sent then invalidate the repeated sync-value
//============================================================================
  assign tssyncm0     = ts_data_stored[0] ? ({2{tssyncs_sync_mark}} & tssyncs) : tssyncs;

//============================================================================
// TSBITS will be broadcast to all the Bridges.
//============================================================================
  assign tsbitm0      = tsbits;

 
//============================================================================
// If data has already been sent then invalidate the repeated sync-value
//============================================================================
  assign tssyncm1     = ts_data_stored[1] ? ({2{tssyncs_sync_mark}} & tssyncs) : tssyncs;

//============================================================================
// TSBITS will be broadcast to all the Bridges.
//============================================================================
  assign tsbitm1      = tsbits;

 
//============================================================================
// If data has already been sent then invalidate the repeated sync-value
//============================================================================
  assign tssyncm2     = ts_data_stored[2] ? ({2{tssyncs_sync_mark}} & tssyncs) : tssyncs;

//============================================================================
// TSBITS will be broadcast to all the Bridges.
//============================================================================
  assign tsbitm2      = tsbits;

 
//============================================================================
// If data has already been sent then invalidate the repeated sync-value
//============================================================================
  assign tssyncm3     = ts_data_stored[3] ? ({2{tssyncs_sync_mark}} & tssyncs) : tssyncs;

//============================================================================
// TSBITS will be broadcast to all the Bridges.
//============================================================================
  assign tsbitm3      = tsbits;

 
//============================================================================
// If data has already been sent then invalidate the repeated sync-value
//============================================================================
  assign tssyncm4     = ts_data_stored[4] ? ({2{tssyncs_sync_mark}} & tssyncs) : tssyncs;

//============================================================================
// TSBITS will be broadcast to all the Bridges.
//============================================================================
  assign tsbitm4      = tsbits;

 
//============================================================================
// If data has already been sent then invalidate the repeated sync-value
//============================================================================
  assign tssyncm5     = ts_data_stored[5] ? ({2{tssyncs_sync_mark}} & tssyncs) : tssyncs;

//============================================================================
// TSBITS will be broadcast to all the Bridges.
//============================================================================
  assign tsbitm5      = tsbits;

 
//============================================================================
// If data has already been sent then invalidate the repeated sync-value
//============================================================================
  assign tssyncm6     = ts_data_stored[6] ? ({2{tssyncs_sync_mark}} & tssyncs) : tssyncs;

//============================================================================
// TSBITS will be broadcast to all the Bridges.
//============================================================================
  assign tsbitm6      = tsbits;

 
//============================================================================
// If data has already been sent then invalidate the repeated sync-value
//============================================================================
  assign tssyncm7     = ts_data_stored[7] ? ({2{tssyncs_sync_mark}} & tssyncs) : tssyncs;

//============================================================================
// TSBITS will be broadcast to all the Bridges.
//============================================================================
  assign tsbitm7      = tsbits;

 
//============================================================================
// If data has already been sent then invalidate the repeated sync-value
//============================================================================
  assign tssyncm8     = ts_data_stored[8] ? ({2{tssyncs_sync_mark}} & tssyncs) : tssyncs;

//============================================================================
// TSBITS will be broadcast to all the Bridges.
//============================================================================
  assign tsbitm8      = tsbits;

 
//============================================================================
// If data has already been sent then invalidate the repeated sync-value
//============================================================================
  assign tssyncm9     = ts_data_stored[9] ? ({2{tssyncs_sync_mark}} & tssyncs) : tssyncs;

//============================================================================
// TSBITS will be broadcast to all the Bridges.
//============================================================================
  assign tsbitm9      = tsbits;

 

//----------------------------------------------------------------------------
// ASSERTIONS
//----------------------------------------------------------------------------

`ifdef ARM_ASSERT_ON

//-----------------------------------------------------------------------------
// Local constant definition
//-----------------------------------------------------------------------------
localparam NUM_NTSREPLICATOR_CHANNELS = 10;

//-----------------------------------------------------------------------------
// Check for legal values of NUM_NTSREPLICATOR_CHANNELS parameter
// Valid values: 2 to 16
//-----------------------------------------------------------------------------
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxntsreplicator - Illegal value for parameter NUM_NTSREPLICATOR_CHANNELS")
      uzovl_cxntsreplicator_num_nbi_channels_param_chk
        (
         .clk         (clk),
         .reset_n     (resetn),
         .test_expr   ((NUM_NTSREPLICATOR_CHANNELS < 2) ||
                       (NUM_NTSREPLICATOR_CHANNELS > 16))
        );

  
//-----------------------------------------------------------------------------
// when ts_data_stored[0] is high then
// tssyncm0 should be zero if tssyncs_mark_det is low
// Otherwise it should reflect the status of tssyncs
//-----------------------------------------------------------------------------
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxntsreplicator - TSBIT should be zero when ts_data_stored[0] is high")
      uzovl_cxntsreplicator_tssync_ts_st_0
        (
         .clk         (clk),
         .reset_n     (resetn),
         .test_expr   (ts_data_stored[0] &
                       ((tssyncm0 == 2'd2) ||
                        (tssyncm0 == 2'd3) ||
                        ((tssyncm0 == 2'd1) &
                          ~tssyncs_sync_mark)))
        );
 
//-----------------------------------------------------------------------------
// when ts_data_stored[1] is high then
// tssyncm1 should be zero if tssyncs_mark_det is low
// Otherwise it should reflect the status of tssyncs
//-----------------------------------------------------------------------------
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxntsreplicator - TSBIT should be zero when ts_data_stored[1] is high")
      uzovl_cxntsreplicator_tssync_ts_st_1
        (
         .clk         (clk),
         .reset_n     (resetn),
         .test_expr   (ts_data_stored[1] &
                       ((tssyncm1 == 2'd2) ||
                        (tssyncm1 == 2'd3) ||
                        ((tssyncm1 == 2'd1) &
                          ~tssyncs_sync_mark)))
        );
 
//-----------------------------------------------------------------------------
// when ts_data_stored[2] is high then
// tssyncm2 should be zero if tssyncs_mark_det is low
// Otherwise it should reflect the status of tssyncs
//-----------------------------------------------------------------------------
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxntsreplicator - TSBIT should be zero when ts_data_stored[2] is high")
      uzovl_cxntsreplicator_tssync_ts_st_2
        (
         .clk         (clk),
         .reset_n     (resetn),
         .test_expr   (ts_data_stored[2] &
                       ((tssyncm2 == 2'd2) ||
                        (tssyncm2 == 2'd3) ||
                        ((tssyncm2 == 2'd1) &
                          ~tssyncs_sync_mark)))
        );
 
//-----------------------------------------------------------------------------
// when ts_data_stored[3] is high then
// tssyncm3 should be zero if tssyncs_mark_det is low
// Otherwise it should reflect the status of tssyncs
//-----------------------------------------------------------------------------
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxntsreplicator - TSBIT should be zero when ts_data_stored[3] is high")
      uzovl_cxntsreplicator_tssync_ts_st_3
        (
         .clk         (clk),
         .reset_n     (resetn),
         .test_expr   (ts_data_stored[3] &
                       ((tssyncm3 == 2'd2) ||
                        (tssyncm3 == 2'd3) ||
                        ((tssyncm3 == 2'd1) &
                          ~tssyncs_sync_mark)))
        );
 
//-----------------------------------------------------------------------------
// when ts_data_stored[4] is high then
// tssyncm4 should be zero if tssyncs_mark_det is low
// Otherwise it should reflect the status of tssyncs
//-----------------------------------------------------------------------------
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxntsreplicator - TSBIT should be zero when ts_data_stored[4] is high")
      uzovl_cxntsreplicator_tssync_ts_st_4
        (
         .clk         (clk),
         .reset_n     (resetn),
         .test_expr   (ts_data_stored[4] &
                       ((tssyncm4 == 2'd2) ||
                        (tssyncm4 == 2'd3) ||
                        ((tssyncm4 == 2'd1) &
                          ~tssyncs_sync_mark)))
        );
 
//-----------------------------------------------------------------------------
// when ts_data_stored[5] is high then
// tssyncm5 should be zero if tssyncs_mark_det is low
// Otherwise it should reflect the status of tssyncs
//-----------------------------------------------------------------------------
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxntsreplicator - TSBIT should be zero when ts_data_stored[5] is high")
      uzovl_cxntsreplicator_tssync_ts_st_5
        (
         .clk         (clk),
         .reset_n     (resetn),
         .test_expr   (ts_data_stored[5] &
                       ((tssyncm5 == 2'd2) ||
                        (tssyncm5 == 2'd3) ||
                        ((tssyncm5 == 2'd1) &
                          ~tssyncs_sync_mark)))
        );
 
//-----------------------------------------------------------------------------
// when ts_data_stored[6] is high then
// tssyncm6 should be zero if tssyncs_mark_det is low
// Otherwise it should reflect the status of tssyncs
//-----------------------------------------------------------------------------
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxntsreplicator - TSBIT should be zero when ts_data_stored[6] is high")
      uzovl_cxntsreplicator_tssync_ts_st_6
        (
         .clk         (clk),
         .reset_n     (resetn),
         .test_expr   (ts_data_stored[6] &
                       ((tssyncm6 == 2'd2) ||
                        (tssyncm6 == 2'd3) ||
                        ((tssyncm6 == 2'd1) &
                          ~tssyncs_sync_mark)))
        );
 
//-----------------------------------------------------------------------------
// when ts_data_stored[7] is high then
// tssyncm7 should be zero if tssyncs_mark_det is low
// Otherwise it should reflect the status of tssyncs
//-----------------------------------------------------------------------------
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxntsreplicator - TSBIT should be zero when ts_data_stored[7] is high")
      uzovl_cxntsreplicator_tssync_ts_st_7
        (
         .clk         (clk),
         .reset_n     (resetn),
         .test_expr   (ts_data_stored[7] &
                       ((tssyncm7 == 2'd2) ||
                        (tssyncm7 == 2'd3) ||
                        ((tssyncm7 == 2'd1) &
                          ~tssyncs_sync_mark)))
        );
 
//-----------------------------------------------------------------------------
// when ts_data_stored[8] is high then
// tssyncm8 should be zero if tssyncs_mark_det is low
// Otherwise it should reflect the status of tssyncs
//-----------------------------------------------------------------------------
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxntsreplicator - TSBIT should be zero when ts_data_stored[8] is high")
      uzovl_cxntsreplicator_tssync_ts_st_8
        (
         .clk         (clk),
         .reset_n     (resetn),
         .test_expr   (ts_data_stored[8] &
                       ((tssyncm8 == 2'd2) ||
                        (tssyncm8 == 2'd3) ||
                        ((tssyncm8 == 2'd1) &
                          ~tssyncs_sync_mark)))
        );
 
//-----------------------------------------------------------------------------
// when ts_data_stored[9] is high then
// tssyncm9 should be zero if tssyncs_mark_det is low
// Otherwise it should reflect the status of tssyncs
//-----------------------------------------------------------------------------
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxntsreplicator - TSBIT should be zero when ts_data_stored[9] is high")
      uzovl_cxntsreplicator_tssync_ts_st_9
        (
         .clk         (clk),
         .reset_n     (resetn),
         .test_expr   (ts_data_stored[9] &
                       ((tssyncm9 == 2'd2) ||
                        (tssyncm9 == 2'd3) ||
                        ((tssyncm9 == 2'd1) &
                          ~tssyncs_sync_mark)))
        );
 

`endif // ARM_ASSERT_ON

endmodule
