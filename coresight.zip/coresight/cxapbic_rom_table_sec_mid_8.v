//-----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2011-2015 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//    Checked In : $Date: 2015-01-16 15:29:03 +0000 (Fri, 16 Jan 2015) $
//    Revision   : $Revision: 41127 $
//    Release    : CoreSight-SoC-TM100-r3p2-00rel0
//
//----------------------------------------------------------------------------
// Verilog-2001 (IEEE Std 1364-2001)
//----------------------------------------------------------------------------
// Purpose : ROM Table
//   This block serves as an internal APB slave that, on reads, returns
// ROM Table data that has been configured by the user. The ROM Table does not
// return an error response. Accesses to addresses that do not have valid
// entries will return 0s.
//   This block implements CoreSight management registers. If this APBIC
// is configured to be the top-level APBIC, then the settings for a few
// of the CoreSight management registers are derived from the targetid[31:0]
// input port, which is expected to be tied off to the required value by
// the user at the APBIC instantiation.
//   The registered version of psel_rom_table and paddr_rom_table are used
// in this block to break the timing path from the address bus of the slave
// interfaces to the corresponding databuses.
//   The revand* registers in this block implement the RevAnd field using
// flip-flops so that the value can be changed at implementation level.
//----------------------------------------------------------------------------
module cxapbic_rom_table_sec_mid_8
 #(
  // Parameters to specify manual ROM Entries
  // Non-zero default to avoid harmless lint warning
  
  parameter ROM_MANUAL_ENTRY0 = 32'h00000000,
  parameter ROM_MANUAL_ENTRY1 = 32'h00000000,
  parameter ROM_MANUAL_ENTRY2 = 32'h00000000,
  parameter ROM_MANUAL_ENTRY3 = 32'h00000000,
  parameter ROM_MANUAL_ENTRY4 = 32'h00000000,
  parameter ROM_MANUAL_ENTRY5 = 32'h00000000,
  parameter ROM_MANUAL_ENTRY6 = 32'h00000000,
  parameter ROM_MANUAL_ENTRY7 = 32'h00000000,
  parameter ROM_MANUAL_ENTRY8 = 32'h00000000,
  parameter ROM_MANUAL_ENTRY9 = 32'h00000000,
  parameter ROM_MANUAL_ENTRY10 = 32'h00000000,
  parameter ROM_MANUAL_ENTRY11 = 32'h00000000,
  parameter ROM_MANUAL_ENTRY12 = 32'h00000000,
  parameter ROM_MANUAL_ENTRY13 = 32'h00000000,
  parameter ROM_MANUAL_ENTRY14 = 32'h00000000,
  parameter ROM_MANUAL_ENTRY15 = 32'h00000000,
  parameter ROM_MANUAL_ENTRY16 = 32'h00000000,
  parameter ROM_MANUAL_ENTRY17 = 32'h00000000,
  parameter ROM_MANUAL_ENTRY18 = 32'h00000000,
  parameter ROM_MANUAL_ENTRY19 = 32'h00000000,
  parameter ROM_MANUAL_ENTRY20 = 32'h00000000,
  parameter ROM_MANUAL_ENTRY21 = 32'h00000000,
  parameter ROM_MANUAL_ENTRY22 = 32'h00000000,
  parameter ROM_MANUAL_ENTRY23 = 32'h00000000,
  parameter ROM_MANUAL_ENTRY24 = 32'h00000000,
  parameter ROM_MANUAL_ENTRY25 = 32'h00000000,
  parameter ROM_MANUAL_ENTRY26 = 32'h00000000,
  parameter ROM_MANUAL_ENTRY27 = 32'h00000000,
  parameter ROM_MANUAL_ENTRY28 = 32'h00000000,
  parameter ROM_MANUAL_ENTRY29 = 32'h00000000,
  parameter ROM_MANUAL_ENTRY30 = 32'h00000000,
  parameter ROM_MANUAL_ENTRY31 = 32'h00000000,
  parameter ROM_MANUAL_ENTRY32 = 32'h00000000,
  parameter ROM_MANUAL_ENTRY33 = 32'h00000000,
  parameter ROM_MANUAL_ENTRY34 = 32'h00000000,
  parameter ROM_MANUAL_ENTRY35 = 32'h00000000,
  parameter ROM_MANUAL_ENTRY36 = 32'h00000000,
  parameter ROM_MANUAL_ENTRY37 = 32'h00000000,
  parameter ROM_MANUAL_ENTRY38 = 32'h00000000,
  parameter ROM_MANUAL_ENTRY39 = 32'h00000000,
  parameter ROM_MANUAL_ENTRY40 = 32'h00000000,
  parameter ROM_MANUAL_ENTRY41 = 32'h00000000,
  parameter ROM_MANUAL_ENTRY42 = 32'h00000000,
  parameter ROM_MANUAL_ENTRY43 = 32'h00000000,
  parameter ROM_MANUAL_ENTRY44 = 32'h00000000,
  parameter ROM_MANUAL_ENTRY45 = 32'h00000000,
  parameter ROM_MANUAL_ENTRY46 = 32'h00000000,
  parameter ROM_MANUAL_ENTRY47 = 32'h00000000,
  parameter ROM_MANUAL_ENTRY48 = 32'h00000000,
  parameter ROM_MANUAL_ENTRY49 = 32'h00000000,
  parameter ROM_MANUAL_ENTRY50 = 32'h00000000,
  parameter ROM_MANUAL_ENTRY51 = 32'h00000000,
  parameter ROM_MANUAL_ENTRY52 = 32'h00000000,
  parameter ROM_MANUAL_ENTRY53 = 32'h00000000,
  parameter ROM_MANUAL_ENTRY54 = 32'h00000000,
  parameter ROM_MANUAL_ENTRY55 = 32'h00000000,
  parameter ROM_MANUAL_ENTRY56 = 32'h00000000,
  parameter ROM_MANUAL_ENTRY57 = 32'h00000000,
  parameter ROM_MANUAL_ENTRY58 = 32'h00000000,
  parameter ROM_MANUAL_ENTRY59 = 32'h00000000,
  parameter ROM_MANUAL_ENTRY60 = 32'h00000000,
  parameter ROM_MANUAL_ENTRY61 = 32'h00000000,
  parameter ROM_MANUAL_ENTRY62 = 32'h00000000,
  parameter ROM_MANUAL_ENTRY63 = 32'h00000000,
  // Parameter to disable automatically generated ROM Entries
  parameter ROM_AUTO_DISABLED = 1'b0)
  (
  input wire clk,
  input wire resetn,
  input wire psel_rom_table,
  input wire [11:2] paddr_rom_table,

  

  output wire [31:0] rom_data
  );

`include "cxapbic_constants_sec_mid_8.v"

//-----------------------------------------------------------------------------
// Local Parameters
//-----------------------------------------------------------------------------
localparam ROM_ENTRY_0_ADDR = 10'd0;
localparam ROM_ENTRY_1_ADDR = 10'd1;
localparam ROM_ENTRY_2_ADDR = 10'd2;
localparam ROM_ENTRY_3_ADDR = 10'd3;
localparam ROM_ENTRY_4_ADDR = 10'd4;
localparam ROM_ENTRY_5_ADDR = 10'd5;
localparam ROM_ENTRY_6_ADDR = 10'd6;
localparam ROM_ENTRY_7_ADDR = 10'd7;
localparam ROM_MANUAL_ENTRY_0_ADDR = 10'd8 + 10'd0;
localparam ROM_MANUAL_ENTRY_1_ADDR = 10'd8 + 10'd1;
localparam ROM_MANUAL_ENTRY_2_ADDR = 10'd8 + 10'd2;
localparam ROM_MANUAL_ENTRY_3_ADDR = 10'd8 + 10'd3;
localparam ROM_MANUAL_ENTRY_4_ADDR = 10'd8 + 10'd4;
localparam ROM_MANUAL_ENTRY_5_ADDR = 10'd8 + 10'd5;
localparam ROM_MANUAL_ENTRY_6_ADDR = 10'd8 + 10'd6;
localparam ROM_MANUAL_ENTRY_7_ADDR = 10'd8 + 10'd7;
localparam ROM_MANUAL_ENTRY_8_ADDR = 10'd8 + 10'd8;
localparam ROM_MANUAL_ENTRY_9_ADDR = 10'd8 + 10'd9;
localparam ROM_MANUAL_ENTRY_10_ADDR = 10'd8 + 10'd10;
localparam ROM_MANUAL_ENTRY_11_ADDR = 10'd8 + 10'd11;
localparam ROM_MANUAL_ENTRY_12_ADDR = 10'd8 + 10'd12;
localparam ROM_MANUAL_ENTRY_13_ADDR = 10'd8 + 10'd13;
localparam ROM_MANUAL_ENTRY_14_ADDR = 10'd8 + 10'd14;
localparam ROM_MANUAL_ENTRY_15_ADDR = 10'd8 + 10'd15;
localparam ROM_MANUAL_ENTRY_16_ADDR = 10'd8 + 10'd16;
localparam ROM_MANUAL_ENTRY_17_ADDR = 10'd8 + 10'd17;
localparam ROM_MANUAL_ENTRY_18_ADDR = 10'd8 + 10'd18;
localparam ROM_MANUAL_ENTRY_19_ADDR = 10'd8 + 10'd19;
localparam ROM_MANUAL_ENTRY_20_ADDR = 10'd8 + 10'd20;
localparam ROM_MANUAL_ENTRY_21_ADDR = 10'd8 + 10'd21;
localparam ROM_MANUAL_ENTRY_22_ADDR = 10'd8 + 10'd22;
localparam ROM_MANUAL_ENTRY_23_ADDR = 10'd8 + 10'd23;
localparam ROM_MANUAL_ENTRY_24_ADDR = 10'd8 + 10'd24;
localparam ROM_MANUAL_ENTRY_25_ADDR = 10'd8 + 10'd25;
localparam ROM_MANUAL_ENTRY_26_ADDR = 10'd8 + 10'd26;
localparam ROM_MANUAL_ENTRY_27_ADDR = 10'd8 + 10'd27;
localparam ROM_MANUAL_ENTRY_28_ADDR = 10'd8 + 10'd28;
localparam ROM_MANUAL_ENTRY_29_ADDR = 10'd8 + 10'd29;
localparam ROM_MANUAL_ENTRY_30_ADDR = 10'd8 + 10'd30;
localparam ROM_MANUAL_ENTRY_31_ADDR = 10'd8 + 10'd31;
localparam ROM_MANUAL_ENTRY_32_ADDR = 10'd8 + 10'd32;
localparam ROM_MANUAL_ENTRY_33_ADDR = 10'd8 + 10'd33;
localparam ROM_MANUAL_ENTRY_34_ADDR = 10'd8 + 10'd34;
localparam ROM_MANUAL_ENTRY_35_ADDR = 10'd8 + 10'd35;
localparam ROM_MANUAL_ENTRY_36_ADDR = 10'd8 + 10'd36;
localparam ROM_MANUAL_ENTRY_37_ADDR = 10'd8 + 10'd37;
localparam ROM_MANUAL_ENTRY_38_ADDR = 10'd8 + 10'd38;
localparam ROM_MANUAL_ENTRY_39_ADDR = 10'd8 + 10'd39;
localparam ROM_MANUAL_ENTRY_40_ADDR = 10'd8 + 10'd40;
localparam ROM_MANUAL_ENTRY_41_ADDR = 10'd8 + 10'd41;
localparam ROM_MANUAL_ENTRY_42_ADDR = 10'd8 + 10'd42;
localparam ROM_MANUAL_ENTRY_43_ADDR = 10'd8 + 10'd43;
localparam ROM_MANUAL_ENTRY_44_ADDR = 10'd8 + 10'd44;
localparam ROM_MANUAL_ENTRY_45_ADDR = 10'd8 + 10'd45;
localparam ROM_MANUAL_ENTRY_46_ADDR = 10'd8 + 10'd46;
localparam ROM_MANUAL_ENTRY_47_ADDR = 10'd8 + 10'd47;
localparam ROM_MANUAL_ENTRY_48_ADDR = 10'd8 + 10'd48;
localparam ROM_MANUAL_ENTRY_49_ADDR = 10'd8 + 10'd49;
localparam ROM_MANUAL_ENTRY_50_ADDR = 10'd8 + 10'd50;
localparam ROM_MANUAL_ENTRY_51_ADDR = 10'd8 + 10'd51;
localparam ROM_MANUAL_ENTRY_52_ADDR = 10'd8 + 10'd52;
localparam ROM_MANUAL_ENTRY_53_ADDR = 10'd8 + 10'd53;
localparam ROM_MANUAL_ENTRY_54_ADDR = 10'd8 + 10'd54;
localparam ROM_MANUAL_ENTRY_55_ADDR = 10'd8 + 10'd55;
localparam ROM_MANUAL_ENTRY_56_ADDR = 10'd8 + 10'd56;
localparam ROM_MANUAL_ENTRY_57_ADDR = 10'd8 + 10'd57;
localparam ROM_MANUAL_ENTRY_58_ADDR = 10'd8 + 10'd58;
localparam ROM_MANUAL_ENTRY_59_ADDR = 10'd8 + 10'd59;
localparam ROM_MANUAL_ENTRY_60_ADDR = 10'd8 + 10'd60;
localparam ROM_MANUAL_ENTRY_61_ADDR = 10'd8 + 10'd61;
localparam ROM_MANUAL_ENTRY_62_ADDR = 10'd8 + 10'd62;
localparam ROM_MANUAL_ENTRY_63_ADDR = 10'd8 + 10'd63;

localparam ROM_AUTO_VALID = (ROM_AUTO_DISABLED == 1'b0) ? 1'b1 : 1'b0;

localparam ROM_ENTRY_0 = {1'b0, MASTER_INTF0_BASE_ADDR, 3'b000, MASTER_INTF0_POWER_ID, 1'b0, MASTER_INTF0_POWER_ID_VALID, 1'b1, ROM_AUTO_VALID};
localparam ROM_ENTRY_1 = {1'b0, MASTER_INTF1_BASE_ADDR, 3'b000, MASTER_INTF1_POWER_ID, 1'b0, MASTER_INTF1_POWER_ID_VALID, 1'b1, ROM_AUTO_VALID};
localparam ROM_ENTRY_2 = {1'b0, MASTER_INTF2_BASE_ADDR, 3'b000, MASTER_INTF2_POWER_ID, 1'b0, MASTER_INTF2_POWER_ID_VALID, 1'b1, ROM_AUTO_VALID};
localparam ROM_ENTRY_3 = {1'b0, MASTER_INTF3_BASE_ADDR, 3'b000, MASTER_INTF3_POWER_ID, 1'b0, MASTER_INTF3_POWER_ID_VALID, 1'b1, ROM_AUTO_VALID};
localparam ROM_ENTRY_4 = {1'b0, MASTER_INTF4_BASE_ADDR, 3'b000, MASTER_INTF4_POWER_ID, 1'b0, MASTER_INTF4_POWER_ID_VALID, 1'b1, ROM_AUTO_VALID};
localparam ROM_ENTRY_5 = {1'b0, MASTER_INTF5_BASE_ADDR, 3'b000, MASTER_INTF5_POWER_ID, 1'b0, MASTER_INTF5_POWER_ID_VALID, 1'b1, ROM_AUTO_VALID};
localparam ROM_ENTRY_6 = {1'b0, MASTER_INTF6_BASE_ADDR, 3'b000, MASTER_INTF6_POWER_ID, 1'b0, MASTER_INTF6_POWER_ID_VALID, 1'b1, ROM_AUTO_VALID};
localparam ROM_ENTRY_7 = {1'b0, MASTER_INTF7_BASE_ADDR, 3'b000, MASTER_INTF7_POWER_ID, 1'b0, MASTER_INTF7_POWER_ID_VALID, 1'b1, ROM_AUTO_VALID};

// ----------------------------------------------------------------------------
// CoreSight Management Register Address Offsets
// ----------------------------------------------------------------------------
// This defines the registers in terms of paddr[11:2]
localparam ROM_PERIPHID4_ADD = 10'h3F4;  // Peripheral ID4 reg        (0xFD0)
localparam ROM_PERIPHID5_ADD = 10'h3F5;  // Peripheral ID5 reg        (0xFD4)
localparam ROM_PERIPHID6_ADD = 10'h3F6;  // Peripheral ID6 reg        (0xFD8)
localparam ROM_PERIPHID7_ADD = 10'h3F7;  // Peripheral ID7 reg        (0xFDC)
localparam ROM_PERIPHID0_ADD = 10'h3F8;  // Peripheral ID0 reg        (0xFE0)
localparam ROM_PERIPHID1_ADD = 10'h3F9;  // Peripheral ID1 reg        (0xFE4)
localparam ROM_PERIPHID2_ADD = 10'h3FA;  // Peripheral ID2 reg        (0xFE8)
localparam ROM_PERIPHID3_ADD = 10'h3FB;  // Peripheral ID3 reg        (0xFEC)
localparam ROM_COMPID0_ADD   = 10'h3FC;  // Component ID0 reg         (0xFF0)
localparam ROM_COMPID1_ADD   = 10'h3FD;  // Component ID1 reg         (0xFF4)
localparam ROM_COMPID2_ADD   = 10'h3FE;  // Component ID2 reg         (0xFF8)
localparam ROM_COMPID3_ADD   = 10'h3FF;  // Component ID3 reg         (0xFFC)

// ----------------------------------------------------------------------------
// CoreSight Management Register Values
// ----------------------------------------------------------------------------
localparam ROM_PERIPHID4_JEP106_CONTINUATION_CODE = 4'b0000;
localparam ROM_PERIPHID4_4KB_COUNT = 4'b0000;

localparam ROM_PART_NUM = 12'h000;
localparam ROM_JEP106_IDENT_CODE = 7'b0000000;
localparam ROM_PERIPHID2_REVISION = 4'b0000;

localparam ROM_PERIPHID3_CUSTMR = 4'b0000;
localparam ROM_PERIPHID3_REVAND = 4'h0;     // Peripheral ID3 value

localparam ROM_COMPID0_VAL = 8'h0D;   // Component ID0 reg
localparam ROM_COMPID1_VAL = 8'h10;   // Component ID1 reg (ROM Class)
localparam ROM_COMPID2_VAL = 8'h05;   // Component ID2 reg
localparam ROM_COMPID3_VAL = 8'hB1;   // Component ID3 reg

localparam COMPID0_RD_DATA = {{24{1'b0}}, ROM_COMPID0_VAL};
localparam COMPID1_RD_DATA = {{24{1'b0}}, ROM_COMPID1_VAL};
localparam COMPID2_RD_DATA = {{24{1'b0}}, ROM_COMPID2_VAL};
localparam COMPID3_RD_DATA = {{24{1'b0}}, ROM_COMPID3_VAL};


//-----------------------------------------------------------------------------
// Wire declarations
//-----------------------------------------------------------------------------
// Read enables
wire rom_entry_0_en;
wire rom_entry_1_en;
wire rom_entry_2_en;
wire rom_entry_3_en;
wire rom_entry_4_en;
wire rom_entry_5_en;
wire rom_entry_6_en;
wire rom_entry_7_en;
// Read enables for manual ROM entries

wire rom_manual_entry_0_en;
wire rom_manual_entry_1_en;
wire rom_manual_entry_2_en;
wire rom_manual_entry_3_en;
wire rom_manual_entry_4_en;
wire rom_manual_entry_5_en;
wire rom_manual_entry_6_en;
wire rom_manual_entry_7_en;
wire rom_manual_entry_8_en;
wire rom_manual_entry_9_en;
wire rom_manual_entry_10_en;
wire rom_manual_entry_11_en;
wire rom_manual_entry_12_en;
wire rom_manual_entry_13_en;
wire rom_manual_entry_14_en;
wire rom_manual_entry_15_en;
wire rom_manual_entry_16_en;
wire rom_manual_entry_17_en;
wire rom_manual_entry_18_en;
wire rom_manual_entry_19_en;
wire rom_manual_entry_20_en;
wire rom_manual_entry_21_en;
wire rom_manual_entry_22_en;
wire rom_manual_entry_23_en;
wire rom_manual_entry_24_en;
wire rom_manual_entry_25_en;
wire rom_manual_entry_26_en;
wire rom_manual_entry_27_en;
wire rom_manual_entry_28_en;
wire rom_manual_entry_29_en;
wire rom_manual_entry_30_en;
wire rom_manual_entry_31_en;
wire rom_manual_entry_32_en;
wire rom_manual_entry_33_en;
wire rom_manual_entry_34_en;
wire rom_manual_entry_35_en;
wire rom_manual_entry_36_en;
wire rom_manual_entry_37_en;
wire rom_manual_entry_38_en;
wire rom_manual_entry_39_en;
wire rom_manual_entry_40_en;
wire rom_manual_entry_41_en;
wire rom_manual_entry_42_en;
wire rom_manual_entry_43_en;
wire rom_manual_entry_44_en;
wire rom_manual_entry_45_en;
wire rom_manual_entry_46_en;
wire rom_manual_entry_47_en;
wire rom_manual_entry_48_en;
wire rom_manual_entry_49_en;
wire rom_manual_entry_50_en;
wire rom_manual_entry_51_en;
wire rom_manual_entry_52_en;
wire rom_manual_entry_53_en;
wire rom_manual_entry_54_en;
wire rom_manual_entry_55_en;
wire rom_manual_entry_56_en;
wire rom_manual_entry_57_en;
wire rom_manual_entry_58_en;
wire rom_manual_entry_59_en;
wire rom_manual_entry_60_en;
wire rom_manual_entry_61_en;
wire rom_manual_entry_62_en;
wire rom_manual_entry_63_en;

wire periphid0_en;
wire periphid1_en;
wire periphid2_en;
wire periphid3_en;
wire periphid4_en;
wire compid0_en;
wire compid1_en;
wire compid2_en;
wire compid3_en;

wire [3:0] periphid4_jep106_continuation_code;
wire [11:0] rom_part_number;
wire [6:0] jep106_ident_code;
wire [31:0] periphid0_rd_data;
wire [31:0] periphid1_rd_data;
wire [3:0] periphid2_revision;
wire [31:0] periphid2_rd_data;
wire [31:0] periphid3_rd_data;
wire [31:0] periphid4_rd_data;

//-----------------------------------------------------------------------------
// Reg declarations
//-----------------------------------------------------------------------------
reg [3:0]   revand_reg;
reg [11:2]  paddr_rom_table_reg; // Registered version of paddr_rom_table

//-----------------------------------------------------------------------------
//
//  Main body of code
//  =================
//
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// PERIPHID4 register read value
// The value for the JEP106 Continuation code is optionally determined
// by the targetid[11:8] input port slice if the APBIC is configured as a
// top-level component that has a direct connection to the DAP APB-AP.
//-----------------------------------------------------------------------------
assign periphid4_jep106_continuation_code = ROM_PERIPHID4_JEP106_CONTINUATION_CODE;
assign periphid4_rd_data = {24'h000000, ROM_PERIPHID4_4KB_COUNT,
                            periphid4_jep106_continuation_code};

//-----------------------------------------------------------------------------
// Read data for PERIPHID0
// The value for Part number is determined by targetid[27:16] if the APBIC
// is configured as a top-level component that has a direct connection to the
// DAP APB-AP.
//-----------------------------------------------------------------------------
assign rom_part_number = ROM_PART_NUM;
assign periphid0_rd_data = {24'h000000, rom_part_number[7:0]};

//-----------------------------------------------------------------------------
// Read data for PERIPHID1
// The value for JEP106 Identity code is determined by targetid[7:1] if the
// APBIC is configured as a top-level component that has a direct connection
// to the DAP APB-AP.
//-----------------------------------------------------------------------------
assign jep106_ident_code = ROM_JEP106_IDENT_CODE;
assign periphid1_rd_data = {24'h000000, jep106_ident_code[3:0],
                            rom_part_number[11:8]};

//-----------------------------------------------------------------------------
// Read data for PERIPHID2
// The value for the Revision field is determined by targetid[31:28] if the
// APBIC is configured as a top-level component that has a direct connection
// to the DAP APB-AP.
//-----------------------------------------------------------------------------
assign periphid2_revision = ROM_PERIPHID2_REVISION;
assign periphid2_rd_data = {24'h000000, periphid2_revision, 1'b1,
                            jep106_ident_code[6:4]};

//-----------------------------------------------------------------------------
// Read data for PERIPHID3
//-----------------------------------------------------------------------------
assign periphid3_rd_data = {  24'h000000,             // 31:8
                              revand_reg,             // 7:4
                              ROM_PERIPHID3_CUSTMR    // 3:0
                              };

//---------------------------------------------------------------------------
// The Rev-And data are driven from a register so that it
// can be easily changed in the netlist.
//---------------------------------------------------------------------------
always @(posedge clk)
  begin : p_revand
    if (psel_rom_table)
      revand_reg <= ROM_PERIPHID3_REVAND;
  end // p_revand

//---------------------------------------------------------------------------
// Register paddr_rom_table to help synthesis timing by breaking timing
// path from paddrs* to prdatas*
//---------------------------------------------------------------------------
always @(posedge clk or negedge resetn)
  begin
    if (!resetn)
      paddr_rom_table_reg <= {10{1'b0}};
    else if (psel_rom_table)
      paddr_rom_table_reg <= paddr_rom_table;
  end

//-----------------------------------------------------------------------------
// Read enables
//-----------------------------------------------------------------------------
assign rom_entry_0_en = (paddr_rom_table_reg == ROM_ENTRY_0_ADDR);
assign rom_entry_1_en = (paddr_rom_table_reg == ROM_ENTRY_1_ADDR);
assign rom_entry_2_en = (paddr_rom_table_reg == ROM_ENTRY_2_ADDR);
assign rom_entry_3_en = (paddr_rom_table_reg == ROM_ENTRY_3_ADDR);
assign rom_entry_4_en = (paddr_rom_table_reg == ROM_ENTRY_4_ADDR);
assign rom_entry_5_en = (paddr_rom_table_reg == ROM_ENTRY_5_ADDR);
assign rom_entry_6_en = (paddr_rom_table_reg == ROM_ENTRY_6_ADDR);
assign rom_entry_7_en = (paddr_rom_table_reg == ROM_ENTRY_7_ADDR);
assign rom_manual_entry_0_en = (paddr_rom_table_reg == ROM_MANUAL_ENTRY_0_ADDR);
assign rom_manual_entry_1_en = (paddr_rom_table_reg == ROM_MANUAL_ENTRY_1_ADDR);
assign rom_manual_entry_2_en = (paddr_rom_table_reg == ROM_MANUAL_ENTRY_2_ADDR);
assign rom_manual_entry_3_en = (paddr_rom_table_reg == ROM_MANUAL_ENTRY_3_ADDR);
assign rom_manual_entry_4_en = (paddr_rom_table_reg == ROM_MANUAL_ENTRY_4_ADDR);
assign rom_manual_entry_5_en = (paddr_rom_table_reg == ROM_MANUAL_ENTRY_5_ADDR);
assign rom_manual_entry_6_en = (paddr_rom_table_reg == ROM_MANUAL_ENTRY_6_ADDR);
assign rom_manual_entry_7_en = (paddr_rom_table_reg == ROM_MANUAL_ENTRY_7_ADDR);
assign rom_manual_entry_8_en = (paddr_rom_table_reg == ROM_MANUAL_ENTRY_8_ADDR);
assign rom_manual_entry_9_en = (paddr_rom_table_reg == ROM_MANUAL_ENTRY_9_ADDR);
assign rom_manual_entry_10_en = (paddr_rom_table_reg == ROM_MANUAL_ENTRY_10_ADDR);
assign rom_manual_entry_11_en = (paddr_rom_table_reg == ROM_MANUAL_ENTRY_11_ADDR);
assign rom_manual_entry_12_en = (paddr_rom_table_reg == ROM_MANUAL_ENTRY_12_ADDR);
assign rom_manual_entry_13_en = (paddr_rom_table_reg == ROM_MANUAL_ENTRY_13_ADDR);
assign rom_manual_entry_14_en = (paddr_rom_table_reg == ROM_MANUAL_ENTRY_14_ADDR);
assign rom_manual_entry_15_en = (paddr_rom_table_reg == ROM_MANUAL_ENTRY_15_ADDR);
assign rom_manual_entry_16_en = (paddr_rom_table_reg == ROM_MANUAL_ENTRY_16_ADDR);
assign rom_manual_entry_17_en = (paddr_rom_table_reg == ROM_MANUAL_ENTRY_17_ADDR);
assign rom_manual_entry_18_en = (paddr_rom_table_reg == ROM_MANUAL_ENTRY_18_ADDR);
assign rom_manual_entry_19_en = (paddr_rom_table_reg == ROM_MANUAL_ENTRY_19_ADDR);
assign rom_manual_entry_20_en = (paddr_rom_table_reg == ROM_MANUAL_ENTRY_20_ADDR);
assign rom_manual_entry_21_en = (paddr_rom_table_reg == ROM_MANUAL_ENTRY_21_ADDR);
assign rom_manual_entry_22_en = (paddr_rom_table_reg == ROM_MANUAL_ENTRY_22_ADDR);
assign rom_manual_entry_23_en = (paddr_rom_table_reg == ROM_MANUAL_ENTRY_23_ADDR);
assign rom_manual_entry_24_en = (paddr_rom_table_reg == ROM_MANUAL_ENTRY_24_ADDR);
assign rom_manual_entry_25_en = (paddr_rom_table_reg == ROM_MANUAL_ENTRY_25_ADDR);
assign rom_manual_entry_26_en = (paddr_rom_table_reg == ROM_MANUAL_ENTRY_26_ADDR);
assign rom_manual_entry_27_en = (paddr_rom_table_reg == ROM_MANUAL_ENTRY_27_ADDR);
assign rom_manual_entry_28_en = (paddr_rom_table_reg == ROM_MANUAL_ENTRY_28_ADDR);
assign rom_manual_entry_29_en = (paddr_rom_table_reg == ROM_MANUAL_ENTRY_29_ADDR);
assign rom_manual_entry_30_en = (paddr_rom_table_reg == ROM_MANUAL_ENTRY_30_ADDR);
assign rom_manual_entry_31_en = (paddr_rom_table_reg == ROM_MANUAL_ENTRY_31_ADDR);
assign rom_manual_entry_32_en = (paddr_rom_table_reg == ROM_MANUAL_ENTRY_32_ADDR);
assign rom_manual_entry_33_en = (paddr_rom_table_reg == ROM_MANUAL_ENTRY_33_ADDR);
assign rom_manual_entry_34_en = (paddr_rom_table_reg == ROM_MANUAL_ENTRY_34_ADDR);
assign rom_manual_entry_35_en = (paddr_rom_table_reg == ROM_MANUAL_ENTRY_35_ADDR);
assign rom_manual_entry_36_en = (paddr_rom_table_reg == ROM_MANUAL_ENTRY_36_ADDR);
assign rom_manual_entry_37_en = (paddr_rom_table_reg == ROM_MANUAL_ENTRY_37_ADDR);
assign rom_manual_entry_38_en = (paddr_rom_table_reg == ROM_MANUAL_ENTRY_38_ADDR);
assign rom_manual_entry_39_en = (paddr_rom_table_reg == ROM_MANUAL_ENTRY_39_ADDR);
assign rom_manual_entry_40_en = (paddr_rom_table_reg == ROM_MANUAL_ENTRY_40_ADDR);
assign rom_manual_entry_41_en = (paddr_rom_table_reg == ROM_MANUAL_ENTRY_41_ADDR);
assign rom_manual_entry_42_en = (paddr_rom_table_reg == ROM_MANUAL_ENTRY_42_ADDR);
assign rom_manual_entry_43_en = (paddr_rom_table_reg == ROM_MANUAL_ENTRY_43_ADDR);
assign rom_manual_entry_44_en = (paddr_rom_table_reg == ROM_MANUAL_ENTRY_44_ADDR);
assign rom_manual_entry_45_en = (paddr_rom_table_reg == ROM_MANUAL_ENTRY_45_ADDR);
assign rom_manual_entry_46_en = (paddr_rom_table_reg == ROM_MANUAL_ENTRY_46_ADDR);
assign rom_manual_entry_47_en = (paddr_rom_table_reg == ROM_MANUAL_ENTRY_47_ADDR);
assign rom_manual_entry_48_en = (paddr_rom_table_reg == ROM_MANUAL_ENTRY_48_ADDR);
assign rom_manual_entry_49_en = (paddr_rom_table_reg == ROM_MANUAL_ENTRY_49_ADDR);
assign rom_manual_entry_50_en = (paddr_rom_table_reg == ROM_MANUAL_ENTRY_50_ADDR);
assign rom_manual_entry_51_en = (paddr_rom_table_reg == ROM_MANUAL_ENTRY_51_ADDR);
assign rom_manual_entry_52_en = (paddr_rom_table_reg == ROM_MANUAL_ENTRY_52_ADDR);
assign rom_manual_entry_53_en = (paddr_rom_table_reg == ROM_MANUAL_ENTRY_53_ADDR);
assign rom_manual_entry_54_en = (paddr_rom_table_reg == ROM_MANUAL_ENTRY_54_ADDR);
assign rom_manual_entry_55_en = (paddr_rom_table_reg == ROM_MANUAL_ENTRY_55_ADDR);
assign rom_manual_entry_56_en = (paddr_rom_table_reg == ROM_MANUAL_ENTRY_56_ADDR);
assign rom_manual_entry_57_en = (paddr_rom_table_reg == ROM_MANUAL_ENTRY_57_ADDR);
assign rom_manual_entry_58_en = (paddr_rom_table_reg == ROM_MANUAL_ENTRY_58_ADDR);
assign rom_manual_entry_59_en = (paddr_rom_table_reg == ROM_MANUAL_ENTRY_59_ADDR);
assign rom_manual_entry_60_en = (paddr_rom_table_reg == ROM_MANUAL_ENTRY_60_ADDR);
assign rom_manual_entry_61_en = (paddr_rom_table_reg == ROM_MANUAL_ENTRY_61_ADDR);
assign rom_manual_entry_62_en = (paddr_rom_table_reg == ROM_MANUAL_ENTRY_62_ADDR);
assign rom_manual_entry_63_en = (paddr_rom_table_reg == ROM_MANUAL_ENTRY_63_ADDR);

// PERIPHIDx registers

assign periphid0_en = (paddr_rom_table_reg == ROM_PERIPHID0_ADD);
assign periphid1_en = (paddr_rom_table_reg == ROM_PERIPHID1_ADD);
assign periphid2_en = (paddr_rom_table_reg == ROM_PERIPHID2_ADD);
assign periphid3_en = (paddr_rom_table_reg == ROM_PERIPHID3_ADD);
assign periphid4_en = (paddr_rom_table_reg == ROM_PERIPHID4_ADD);

// COMPIDx registers
assign compid0_en = (paddr_rom_table_reg == ROM_COMPID0_ADD);
assign compid1_en = (paddr_rom_table_reg == ROM_COMPID1_ADD);
assign compid2_en = (paddr_rom_table_reg == ROM_COMPID2_ADD);
assign compid3_en = (paddr_rom_table_reg == ROM_COMPID3_ADD);

//-----------------------------------------------------------------------------
// ROM Table read data mux
// Return 32'h00000000 if access is to an address that does not decode to
// a valid ROM Table entry.
// Accesses to PERIPHID5, PERIPHID6 and PERIPHID7 registers also
// return 32'h00000000.
//-----------------------------------------------------------------------------
assign rom_data = 
                   ({32{rom_entry_0_en}} & ROM_ENTRY_0) | 
                   ({32{rom_entry_1_en}} & ROM_ENTRY_1) | 
                   ({32{rom_entry_2_en}} & ROM_ENTRY_2) | 
                   ({32{rom_entry_3_en}} & ROM_ENTRY_3) | 
                   ({32{rom_entry_4_en}} & ROM_ENTRY_4) | 
                   ({32{rom_entry_5_en}} & ROM_ENTRY_5) | 
                   ({32{rom_entry_6_en}} & ROM_ENTRY_6) | 
                   ({32{rom_entry_7_en}} & ROM_ENTRY_7) | 
                   ({32{rom_manual_entry_0_en}} & ROM_MANUAL_ENTRY0) | 
                   ({32{rom_manual_entry_1_en}} & ROM_MANUAL_ENTRY1) | 
                   ({32{rom_manual_entry_2_en}} & ROM_MANUAL_ENTRY2) | 
                   ({32{rom_manual_entry_3_en}} & ROM_MANUAL_ENTRY3) | 
                   ({32{rom_manual_entry_4_en}} & ROM_MANUAL_ENTRY4) | 
                   ({32{rom_manual_entry_5_en}} & ROM_MANUAL_ENTRY5) | 
                   ({32{rom_manual_entry_6_en}} & ROM_MANUAL_ENTRY6) | 
                   ({32{rom_manual_entry_7_en}} & ROM_MANUAL_ENTRY7) | 
                   ({32{rom_manual_entry_8_en}} & ROM_MANUAL_ENTRY8) | 
                   ({32{rom_manual_entry_9_en}} & ROM_MANUAL_ENTRY9) | 
                   ({32{rom_manual_entry_10_en}} & ROM_MANUAL_ENTRY10) | 
                   ({32{rom_manual_entry_11_en}} & ROM_MANUAL_ENTRY11) | 
                   ({32{rom_manual_entry_12_en}} & ROM_MANUAL_ENTRY12) | 
                   ({32{rom_manual_entry_13_en}} & ROM_MANUAL_ENTRY13) | 
                   ({32{rom_manual_entry_14_en}} & ROM_MANUAL_ENTRY14) | 
                   ({32{rom_manual_entry_15_en}} & ROM_MANUAL_ENTRY15) | 
                   ({32{rom_manual_entry_16_en}} & ROM_MANUAL_ENTRY16) | 
                   ({32{rom_manual_entry_17_en}} & ROM_MANUAL_ENTRY17) | 
                   ({32{rom_manual_entry_18_en}} & ROM_MANUAL_ENTRY18) | 
                   ({32{rom_manual_entry_19_en}} & ROM_MANUAL_ENTRY19) | 
                   ({32{rom_manual_entry_20_en}} & ROM_MANUAL_ENTRY20) | 
                   ({32{rom_manual_entry_21_en}} & ROM_MANUAL_ENTRY21) | 
                   ({32{rom_manual_entry_22_en}} & ROM_MANUAL_ENTRY22) | 
                   ({32{rom_manual_entry_23_en}} & ROM_MANUAL_ENTRY23) | 
                   ({32{rom_manual_entry_24_en}} & ROM_MANUAL_ENTRY24) | 
                   ({32{rom_manual_entry_25_en}} & ROM_MANUAL_ENTRY25) | 
                   ({32{rom_manual_entry_26_en}} & ROM_MANUAL_ENTRY26) | 
                   ({32{rom_manual_entry_27_en}} & ROM_MANUAL_ENTRY27) | 
                   ({32{rom_manual_entry_28_en}} & ROM_MANUAL_ENTRY28) | 
                   ({32{rom_manual_entry_29_en}} & ROM_MANUAL_ENTRY29) | 
                   ({32{rom_manual_entry_30_en}} & ROM_MANUAL_ENTRY30) | 
                   ({32{rom_manual_entry_31_en}} & ROM_MANUAL_ENTRY31) | 
                   ({32{rom_manual_entry_32_en}} & ROM_MANUAL_ENTRY32) | 
                   ({32{rom_manual_entry_33_en}} & ROM_MANUAL_ENTRY33) | 
                   ({32{rom_manual_entry_34_en}} & ROM_MANUAL_ENTRY34) | 
                   ({32{rom_manual_entry_35_en}} & ROM_MANUAL_ENTRY35) | 
                   ({32{rom_manual_entry_36_en}} & ROM_MANUAL_ENTRY36) | 
                   ({32{rom_manual_entry_37_en}} & ROM_MANUAL_ENTRY37) | 
                   ({32{rom_manual_entry_38_en}} & ROM_MANUAL_ENTRY38) | 
                   ({32{rom_manual_entry_39_en}} & ROM_MANUAL_ENTRY39) | 
                   ({32{rom_manual_entry_40_en}} & ROM_MANUAL_ENTRY40) | 
                   ({32{rom_manual_entry_41_en}} & ROM_MANUAL_ENTRY41) | 
                   ({32{rom_manual_entry_42_en}} & ROM_MANUAL_ENTRY42) | 
                   ({32{rom_manual_entry_43_en}} & ROM_MANUAL_ENTRY43) | 
                   ({32{rom_manual_entry_44_en}} & ROM_MANUAL_ENTRY44) | 
                   ({32{rom_manual_entry_45_en}} & ROM_MANUAL_ENTRY45) | 
                   ({32{rom_manual_entry_46_en}} & ROM_MANUAL_ENTRY46) | 
                   ({32{rom_manual_entry_47_en}} & ROM_MANUAL_ENTRY47) | 
                   ({32{rom_manual_entry_48_en}} & ROM_MANUAL_ENTRY48) | 
                   ({32{rom_manual_entry_49_en}} & ROM_MANUAL_ENTRY49) | 
                   ({32{rom_manual_entry_50_en}} & ROM_MANUAL_ENTRY50) | 
                   ({32{rom_manual_entry_51_en}} & ROM_MANUAL_ENTRY51) | 
                   ({32{rom_manual_entry_52_en}} & ROM_MANUAL_ENTRY52) | 
                   ({32{rom_manual_entry_53_en}} & ROM_MANUAL_ENTRY53) | 
                   ({32{rom_manual_entry_54_en}} & ROM_MANUAL_ENTRY54) | 
                   ({32{rom_manual_entry_55_en}} & ROM_MANUAL_ENTRY55) | 
                   ({32{rom_manual_entry_56_en}} & ROM_MANUAL_ENTRY56) | 
                   ({32{rom_manual_entry_57_en}} & ROM_MANUAL_ENTRY57) | 
                   ({32{rom_manual_entry_58_en}} & ROM_MANUAL_ENTRY58) | 
                   ({32{rom_manual_entry_59_en}} & ROM_MANUAL_ENTRY59) | 
                   ({32{rom_manual_entry_60_en}} & ROM_MANUAL_ENTRY60) | 
                   ({32{rom_manual_entry_61_en}} & ROM_MANUAL_ENTRY61) | 
                   ({32{rom_manual_entry_62_en}} & ROM_MANUAL_ENTRY62) | 
                   ({32{rom_manual_entry_63_en}} & ROM_MANUAL_ENTRY63) | 
                   ({32{periphid0_en}} & periphid0_rd_data) |
                   ({32{periphid1_en}} & periphid1_rd_data) |
                   ({32{periphid2_en}} & periphid2_rd_data) |
                   ({32{periphid3_en}} & periphid3_rd_data) |
                   ({32{periphid4_en}} & periphid4_rd_data) |
                   ({32{compid0_en}}   & COMPID0_RD_DATA)   |
                   ({32{compid1_en}}   & COMPID1_RD_DATA)   |
                   ({32{compid2_en}}   & COMPID2_RD_DATA)   |
                   ({32{compid3_en}}   & COMPID3_RD_DATA);

endmodule // cxapbic_rom_table_sec_mid_8

//-- END OF FILE --------------------------------------------------------------
