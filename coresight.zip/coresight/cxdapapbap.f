+incdir+$GP3_RTL/coresight/rtl/coresight_component/debug_module/cxdapapbap/verilog
$GP3_RTL/coresight/rtl/coresight_component/debug_module/cxdapapbap/verilog/cxdapapbap.v
$GP3_RTL/coresight/rtl/coresight_component/debug_module/cxdapapbap/verilog/cxdapapbap_apb_if.v
$GP3_RTL/coresight/rtl/coresight_component/debug_module/cxdapapbap/verilog/cxdapapbap_dap_if.v
$GP3_RTL/coresight/rtl/coresight_component/debug_module/cxdapapbap/verilog/cxdapapbap_constants.v
