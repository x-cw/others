//----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2009-2010 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//    Checked In :  2010-06-11 20:16:10 +0530 (Fri, 11 Jun 2010) 
//    Revision   :  8067 
//    Release    : TM961-BU-50000-r0p0-00rel0
//
//----------------------------------------------------------------------------
// Purpose           : This Unformatter block receives formatted data stored in 
//                   : Read Buffer and transmits it on ATB Master Interface
//                   : after unformatting it
//----------------------------------------------------------------------------

module cxtmc_unformatter
  #(parameter CXTMC_ATB_DATA_WIDTH = 128,
    parameter CXTMC_ATBYTES_WIDTH  = 4)
  (
                                          // Clock
  input wire                              cxtmc_clk,
                                          // Reset
  input wire                              RESETn,
                                          // request for read has been accepted
  input wire                              rb_req_ready,
                                          // read data is valid
  input wire                              rb_rdata_valid,
                                          // read data
  input wire [2*CXTMC_ATB_DATA_WIDTH-1:0] rb_data,
                                          // ATB transaction is accepted
  input wire                              ATREADYM,
                                          // Flush request raised
  input wire                              AFVALIDM,
                                          // last data for Current Flush
  input wire                              atbm_flush_ready,
                                          // Unformatting is enabled. if this signal is 0, APB read fifo will be enabled
  input wire                              unformatter_en,
                                          // This signal indicates if the hw_fifo_mode is on
  input wire                              hw_fifo_mode,
                                          // Flush out all internal data and assert empty
  input wire                              unformatter_stop,
                                          // APB read request for data
  input wire                              rrd_rd_req,
                                          // Clear Read pointer
  input wire                              apbreadfifo_clr,

                                          // Integration Mode Control
  input wire                              it_ctrl,

                                          // Write enable for ITATBMCTR0 Integration register
  input wire                              it_atb_m_ctr_0_wr_en,

                                          // Write enable for ITATBMCTR1 Integration register
  input wire                              it_atb_m_ctr_1_wr_en,

                                          // Write enable for ITATBMDATA0 Integration register
  input wire                              it_atb_m_data_0_wr_en,

                                          // APB write data bus for Integration register writes
  input wire [16:0]                       apb_wdata_16to0,

                                          // read request for data from unformatter
  output wire                             rb_req_valid,
                                          // No data stored within unformatter
  output wire                             unformatter_empty,
                                          // Read pointer can be incremented for the read initiated for APB request
                                          // This signal is set when all the data read through a single read from Read
                                          // buffer is read through APB
  output reg                              apb_read_fifo_rrp_en,
                                          // APB read data is valid
  output reg                              rrd_rd_ack,
                                          // APB read data
  output wire                    [31:0]   rrd,
                                          // ATB transaction is valid
  output reg                              ATVALIDM,
                                          // ID for the ATB transactions
  output reg                       [6:0]  ATIDM,
                                          // Number of bytes valid for ATB transaction
  output reg    [CXTMC_ATBYTES_WIDTH-1:0] ATBYTESM,
                                          // ATB Data
  output reg   [CXTMC_ATB_DATA_WIDTH-1:0] ATDATAM,
                                          // Flush Valid set on ATB Master Interface
  output reg                              atbm_flush_valid,
                                          // Internal data flushed
  output reg                              AFREADYM
  );

  //----------------------------------------------------------------------------
  // Constants definitions
  //----------------------------------------------------------------------------
  // For 128 bit ATB, depth of the frame buffer is 60, for 64 bit 30 and for 
  // 32bit the frame buffer is 15 deep. Since RPTR is one hot, RPTR width depends on the
  // frame buffer depth
  localparam RPTR_WIDTH               = (CXTMC_ATB_DATA_WIDTH == 128) ? 60 :
                                        (CXTMC_ATB_DATA_WIDTH == 64) ? 30 : 15;
  // Depth of the lower half of the frame buffer
  localparam RPTR_HALF                = (CXTMC_ATB_DATA_WIDTH == 128) ? 30 :
                                        (CXTMC_ATB_DATA_WIDTH == 64) ? 15 : 8;
  // Depth of the upper half of the frame buffer
  // For 32 bit case, the top half is only 7 deep as the 'Flag' byte of the Frame is not
  // stored in the frame buffer
  localparam RPTR_TOP_HALF            = (CXTMC_ATB_DATA_WIDTH == 128) ? 30 :
                                        (CXTMC_ATB_DATA_WIDTH == 64) ? 15 : 7;

  // Sel signal is used to rotate the Frame buffer. The width of the sel signal is
  // based on ATB Width
  localparam SEL_WIDTH                = (CXTMC_ATB_DATA_WIDTH == 128) ?  6 :
                                        (CXTMC_ATB_DATA_WIDTH == 64) ? 5 :  4;

  // Width of the Input Buffer is twice that of ATB WIDTH. This is because the read data
  // Width is also twice that of ATB Width
  localparam INPUT_BUFFER_WIDTH       = 2*CXTMC_ATB_DATA_WIDTH;

  // FRAME WIDTH is always 128 bit.
  localparam FRAME_WIDTH              = 128;

  // There are two frame buffers FRAME0 and FRAME1. For 32bit ATB half the frame is stored in FRAME0
  // For 64 bit ATB, Frame0 contains 120 bits of data and for 128 bit ATB FRAME0 contains 240 bits of data,
  // which is the ID/Data, with the flag information stored in seperate register
  localparam FRAME0_BUFFER_WIDTH      = (CXTMC_ATB_DATA_WIDTH == 32) ? 2*CXTMC_ATB_DATA_WIDTH :
                                        (CXTMC_ATB_DATA_WIDTH == 64) ? 2*CXTMC_ATB_DATA_WIDTH-8 :
                                                                       2*(CXTMC_ATB_DATA_WIDTH-8);
  // For 32 bit ATB FRAME1 contains 56 bits, For 64 bit ATB FRAME1 contains 120 bits of data, 
  // and For 128 bit FRAME1 contains 240 bits of data - because the Flag byte in each frame is not
  // stored
  localparam FRAME1_BUFFER_WIDTH      = (CXTMC_ATB_DATA_WIDTH == 128) ? 2*(CXTMC_ATB_DATA_WIDTH-8) :
                                                                        2*CXTMC_ATB_DATA_WIDTH-8;
  // FRAME_BUFFER_WIDTH is sum of FRAME0 and FRAME1 widths
  localparam FRAME_BUFFER_WIDTH       = FRAME0_BUFFER_WIDTH + FRAME1_BUFFER_WIDTH;

  // For 32 bit ATB, the internal buffer, which consists of input buffer and frame buffer is 4 times 
  // that of the Read Data width - hence 3 bits are required to represent the same. For 64 and 128 ATB, 
  // internal buffer is 3 times that of Read Data width - hence two bits are sufficient.
  localparam REQ_CNTR_WIDTH           = (CXTMC_ATB_DATA_WIDTH == 32) ? 3 : 2;

  // For 32 bit ATB, the internal buffer, which consists of input buffer and frame buffer is 4 times 
  // that of the Read Data width, hence max buffers represented in Read width terms are 4. For 64/128 bit
  // internal buffer is 3 times that of Read Data width, as input_buffer1 is not used
  localparam MAX_BUFFERS              = (CXTMC_ATB_DATA_WIDTH == 32) ? 4 : 3;
  
  // Number of Bytes on ATB can be arrived at by dividing the ATB Data width by 8
  localparam CXTMC_ATB_NUM_BYTES      = CXTMC_ATB_DATA_WIDTH/8;

  // This is used while reading data through APB input_buffer0 is used as storage FIFO
  // FIFO_DEPTH represents the depth of this buffer in 32-bit words
  // For 32 bit, FIFO Depth will be 2, for 64 bit 4 and 128 bit 8.
  localparam FIFO_DEPTH               = (CXTMC_ATB_DATA_WIDTH == 128) ? 8 :
                                        (CXTMC_ATB_DATA_WIDTH == 64)  ? 4 : 2;
  // This indicates FIFO DEPTH -2 in cases where it is greater than or equal to 0. Used in FIFO_NOT_EMPTY
  // State, which wont be reached if FIFO_DEPTH==1
  localparam FIFO_DEPTH_MINUS_2       = (CXTMC_ATB_DATA_WIDTH == 128) ? 3'b110 : 
                                        (CXTMC_ATB_DATA_WIDTH == 64)  ? 2'b10 : 1'b0;

  // PTR_WIDTH is for pointers to the Storage FIFO when APB reads are happening
  // 1 bit for a depth of 2 for 32bit ATB, 2 bits for depth of 4 and 3 bits for 8
  localparam PTR_WIDTH                = (CXTMC_ATB_DATA_WIDTH == 128) ? 3 :
                                        (CXTMC_ATB_DATA_WIDTH == 64)  ? 2 : 1;

  // PADDED_1 is used to assign the LSB as 1 and other bits as 0 for the pointers
  localparam PADDED_1                 = (CXTMC_ATB_DATA_WIDTH == 128) ? 3'b001 : 
                                        (CXTMC_ATB_DATA_WIDTH == 64)  ? 2'b01 : 1'b1;

  // This parameters define the states for FIFO State machine used for APB Read
  localparam FIFO_EMPTY               = 2'b00; // FIFO is Empty
  localparam FIFO_REQ_RAISED          = 2'b01; // APB request received and read req raised
  localparam FIFO_NOT_EMPTY           = 2'b10; // Read data from Mem received, and FIFO has
                                               // some data

  //----------------------------------------------------------------------------
  // WIRES AND REGS
  //----------------------------------------------------------------------------
  // this signal indicates that the rptr would cross frame buffer 1 to frame buffer 0 or vice versa
  wire                             f1_f0_bndry_cross;
  // this signal is concatenation of frame buffer 0 and frame buffer 1
  wire    [FRAME_BUFFER_WIDTH-1:0] frame_buffer;
  // frame id 0 clock enable
  wire                             frame_id0_en;
  // frame id 1 clock enable
  wire                             frame_id1_en;
  // D-input of a signal which indicates which bytes in the frame 0 are id
  wire             [RPTR_HALF-1:0] nxt_is_frame0_id;
  // temporary version used to calculate nxt_is_frame0_id
  wire             [RPTR_HALF-1:0] temp_is_frame0_id;
  // D-input of a signal which indicates which bytes in the frame 1 are id
  wire         [RPTR_TOP_HALF-1:0] nxt_is_frame1_id;
  // temporary version used to calculate nxt_is_frame1_id
  wire         [RPTR_TOP_HALF-1:0] temp_is_frame1_id;
  // This signal indicates which bytes in the concatenated frame are id
  wire            [RPTR_WIDTH-1:0] is_frame_id;
  // D-input of is_frame_id
  wire            [RPTR_WIDTH-1:0] nxt_is_frame_id;
  // 0th bit of nxt_is_frame_id is or'ed with nxt_fready to arrive at this signal. This is used to make sure
  // all the data in frame1 buffer is flushed out.
  wire            [RPTR_WIDTH-1:0] nxt_is_frame_id_fready;
  // 0th bit of is_frame_id is or'ed with fready to arrive at this signal. This is used to make sure
  // all the data in frame1 buffer is flushed out.
  wire            [RPTR_WIDTH-1:0] is_frame_id_fready;
  // temporary version of signal used to calculate atb_clken
  wire                             temp_atb_clken;
  // This signal is used to clock ATB control, ID and Data signals
  wire                             atb_clken;
  // this signal is used to clock rptr signals
  wire                             rptr_clken;
  // D-input of ATVALIDM
  wire                             nxt_atvalidm;
  // D-input of ATIDM
  wire                       [6:0] nxt_atidm;
  // D-input of ATBYTESM
  wire   [CXTMC_ATBYTES_WIDTH-1:0] nxt_atbytesm;
  // D-input of AFREADYM
  wire                             nxt_afreadym;
  // this signal is used to determine if unformatter needs to be flushed
  // this signal indicates that there is enough data available in frame1, to form a single ATB cycle
  wire                             atdata_for_1cycle_available_f1;
  // this signal indicates that there is enough data available in frame0, to form a single ATB cycle
  wire                             atdata_for_1cycle_available_f0;
  // This signal indicates that the nth byte next to read pointer is a id
  reg   [CXTMC_ATB_NUM_BYTES:0]    rptr_nth_bit_id;
  // D-input of rb_req_valid_apb - which indicates read buffer request from apb is valid
  wire                             nxt_rb_req_valid_apb;
  // request to read buffer valid from unformatter logic
  wire                             rb_req_valid_unf;
  // clock enable for input_buffer0
  wire                             input_buffer0_en;
  // clock enable for input_buffer1
  wire                             input_buffer1_en;
  // clock enable for input_buffer0
  wire                             input_buffer0_en_unf;
  // D-input for input_buffer0_val
  wire                             nxt_input_buffer0_val;
  // D-input for input_buffer1_val
  wire                             nxt_input_buffer1_val;
  // This signal indicates the ATVALIDM output not considering skid value. Final nxt_atvalidm will be generated 
  // After skid value is consdiered
  wire                             nxt_atvalidm_current;
  // D-input of ATIDM in current clock
  wire                       [6:0] nxt_atidm_current;
  // D-input of ATBYTESM current clock
  wire   [CXTMC_ATBYTES_WIDTH-1:0] nxt_atbytesm_current;
  // D-input for ATDATAM
  wire [CXTMC_ATB_DATA_WIDTH-1:0]  nxt_atdatam;
  // D-input of skid data is valid
  wire                             nxt_atb_skid_valid;
  // load skid data
  wire                             atb_skid_ld;
  // clock enable for frame_buffer0
  wire                             frame_buffer0_en;
  // clock enable for frame_buffer1
  wire                             frame_buffer1_en;
  // This signal is used to make all bits in is_frame0_id 0 when read pointer moves from when frame0 to frame1
  wire                             frame_buffer0_clr;
  // This signal is used to make all bits in is_frame1_id 0 when read pointer moves from when frame1 to frame0
  wire                             frame_buffer1_clr;
  // D-input of signal that Indicates that read ponter is in frame0 if high, and in frame 1 if low
  wire                             nxt_rptr_in_frame0;
  // D-input of signal that Indicates that next write is to frame0 if high and to frame 1 if low
  wire                             nxt_wptr_in_frame0;
  // inverse of unformatter_en
  wire                             unformatter_dis;
  // Indicates that the data in frame_buffer0 is valid
  wire                             nxt_frame_buffer0_val;
  // Indicates that the data in frame_buffer1 is valid
  wire                             nxt_frame_buffer1_val;
  // total number of BUFFERS that are valid
  wire        [REQ_CNTR_WIDTH-1:0] total_valid_buffers;
  // Indicates that last frame has to be flushed
  wire                             nxt_last_frame_flush;
  wire                             last_frame_flush;
  wire                             nxt_last_frame_flush0;
  wire                             nxt_last_frame_flush1;
  wire                             rdata_input_buf_val;

  reg                              last_frame_flush0;
  reg                              last_frame_flush1;
  reg                              flush_frame0_last;
  reg                              nxt_flush_frame0_last;

  // skid data is valid
  reg                              atb_skid_valid;
  // ATIDM Skid Buffer
  reg                        [6:0] atidm_skid;
  // ATBYTESM Skid Buffer
  reg    [CXTMC_ATBYTES_WIDTH-1:0] atbytesm_skid;
  // ATDATAM Skid Buffer
  reg  [CXTMC_ATB_DATA_WIDTH-1:0]  atdatam_skid;
  // input_buffer0 data valid
  reg                              input_buffer0_val;
  // input_buffer1 data valid
  reg                              input_buffer1_val;
  // read buffer request valid from APB Read FIFO Logic
  reg                              rb_req_valid_apb;
  // This signal is used to mux the data from frame buffer onto ATDATAM
  reg              [SEL_WIDTH-1:0] sel;
  // D-input for sel
  reg              [SEL_WIDTH-1:0] nxt_sel;
  // Data from input_buffer0 is wired as apb read FIFO signal
  reg                    [31:0]    apb_read_fifo[FIFO_DEPTH-1:0];
  // This signal points to data within apb read fifo which will be muxed onto APB Interface
  reg            [PTR_WIDTH-1:0]   apb_rptr;
  // D-input of apb_rptr
  reg           [PTR_WIDTH-1:0]    nxt_apb_rptr;
  // This signal indicates the request to read buffer has to be set
  reg                              rb_req_set;
  // This signal indicates the read ptr in the read buffer can be incremented as the last data from apb read fifo has been read
  reg                              nxt_apb_read_fifo_rrp_en;
  // D-input of rrd_rd_ack
  reg                              nxt_rrd_rd_ack;
  // This is state machine for APB read fifo logic
  reg                      [1:0]   fifo_state;
  // D-input for fifo_state
  reg                      [1:0]   nxt_fifo_state;
  // This signal indexes in to frame buffer from which data will be muxed in next cycle
  reg             [RPTR_WIDTH-1:0] rptr_nxt_cycle;
  // D-input for rptr_nxt_cycle
  reg            [RPTR_WIDTH-1:0]  nxt_rptr_nxt_cycle;
  // This signal indexes into frame buffer from which data will be muxed in this cycle
  reg             [RPTR_WIDTH-1:0] current_rptr;
  // LSB of the frame buffer from which data will be muxed onto ATDATAM
  reg    [FRAME0_BUFFER_WIDTH-1:0] frame_buffer0;
  // MSB of the frame buffer from which data will be muxed onto ATDATAM
  reg    [FRAME1_BUFFER_WIDTH-1:0] frame_buffer1;
  // D-input for frame buffer0
  reg    [FRAME0_BUFFER_WIDTH-1:0] nxt_frame_buffer0;
  // D-input for frame buffer1
  reg    [FRAME1_BUFFER_WIDTH-1:0] nxt_frame_buffer1;
  // Indicates that the data in frame_buffer0 is valid
  reg                              frame_buffer0_val;
  // Indicates that the data in frame_buffer1 is valid
  reg                              frame_buffer1_val;
  // ndicates that read ponter is in frame0 if high, and in frame 1 if low
  reg                              rptr_in_frame0;
  // Indicates that next write is to frame0 if high and to frame 1 if low
  reg                              wptr_in_frame0;
  // this signal counts the number of read requests raised to the read buffer
  reg      [REQ_CNTR_WIDTH-1:0]    req_cntr;
  // D-input of req_cntr
  reg      [REQ_CNTR_WIDTH-1:0]    nxt_req_cntr;
  // This signal is used to empty out any data present in frame 1  - so that unformatter empty can be asserted
  wire                             unf_stop_in_progress;
  // This signal indicates that in the next clock enough data will be available in Frame buffers to create 
  // atleast one ATB transaction. This signal will be set also when for flushing purposes, a 
  // ATB transaction is going to be generated less than the full ATB Width.
  wire                             nxt_atb_data_avail;
  // D Input for Flush Valid set on ATB Master Interface
  wire                             nxt_atbm_flush_valid;
  // Clocked version of above
  reg                              atb_data_avail;
  // If ATREADYM is not high when atb_data_avail is set, then this signal is used to store the value until ATREADYM is back high
  reg                              atb_data_avail_stored;
  // D-input of rdctrl_en_sotred
  reg                              nxt_atb_data_avail_stored;
  // Register that stores incoming read data
  reg     [INPUT_BUFFER_WIDTH-1:0] input_buffer0;
  // Register that stores incoming read data - only in 32bit mode
  reg     [INPUT_BUFFER_WIDTH-1:0] input_buffer1;
  // This signal indicates if any bytes in the frame0 signal are id
  reg              [RPTR_HALF-1:0] is_frame0_id;
  // This signal indicates if any bytes in the frame1 signal are id
  reg          [RPTR_TOP_HALF-1:0] is_frame1_id;
  // this signal is used to determine if unformatter needs to be flushed
  // indicates that flush is pending
  reg     [REQ_CNTR_WIDTH-1:0]     flush_pending;
  reg                              flush_done;
  // D-input of flush_pending
  wire    [REQ_CNTR_WIDTH-1:0]     nxt_flush_pending;
  wire                             nxt_flush_done;
  // loop variable to mux apb read fifo
  integer                          loopvar_i;
  // loop variable to generate rptr_nth_bit_id
  integer                          loopvar_j;
  // loop variables to generate nxt_rptr
  integer                          loopvar_k;
  integer                          loopvar_m;
  integer                          loopvar_n;
  // loop variable to generate nxt_rptr
  integer                          loopvar_l;

//----------------------------------------------------------------------------
//Functions
//----------------------------------------------------------------------------

//----------------------------------------------------------------------------
// Double Byte Mux
//----------------------------------------------------------------------------
// This function takes input as 2 bytes of the TPIU frame and swap them
// if the Data part belongs to previous ID rather than current ID.
// It also replaces the ID bit with the data, if it is not a ID
function [15:0] frame_double_byte_mux;
  input [15:0] input_double_byte;
  // This bit is the relevant flag bit for this double byte from the Frame
  input        data_rep_or_id_next;
  reg   [15:0] output_double_byte;
begin
  // 0th of input_double_byte is assigned to 8th bit input_double_byte
  // if the 0 bit indicates an ID. This is because for cases no swapping
  // is needed, this bit is ignored finally, and in cases swapping is required
  // 8bit needs to be assigned to that.
  output_double_byte[0]    = input_double_byte[0] ? input_double_byte[8]
                                                     : data_rep_or_id_next;
  // Swap if ID and Id is for next data, else retain current data
  output_double_byte[7:1]  = (input_double_byte[0] && data_rep_or_id_next) ?
                                                     input_double_byte[15:9]  : input_double_byte[7:1];
  // Swap if ID and Id is for next data, else retain current data
  output_double_byte[15:9] = (input_double_byte[0] && data_rep_or_id_next) ?
                                                     input_double_byte[7:1]   : input_double_byte[15:9];
  // For cases when no swapping is required, same data bit is retained. For cases
  // when swapping is required, this byte will be assigned to an id, and the LSB will 
  // be ignored
  output_double_byte[8]    = input_double_byte[8];
  frame_double_byte_mux    = output_double_byte;
end
endfunction

//----------------------------------------------------------------------------
// frame mux
//----------------------------------------------------------------------------
// This function receives a TIPU frame as input. In the logic this frame is
// then rearranged in such a way that all the ID's and their data are grouped
// together.  Rearrangement happens when Data after the ID corresponds
// to previous ID. This is indicated by both ID bit being 1 and the corresponding
// Flag bit being high.
function [119:0] input_frame_mux_fn;
  input [127:0] input_buffer;
  reg   [119:0] input_frame_mux;
  integer i;
begin
  // Rearrange data/id based on the id bit and flag bit selection
  for (i = 0; i<= 6; i=i+1)
  begin
    input_frame_mux[i*16 +: 16] = frame_double_byte_mux(input_buffer[i*16 +: 16], input_buffer[120+i]);
  end
  // For the 15th byte, rearrangement is illegal by protocol and hence not necessary
  input_frame_mux[119:113] = input_buffer[119:113];
  // If the 15byte is an ID, then the LSB is ignored. If it is Data corresponding flag bit
  // is assigned
  input_frame_mux[112]     = input_buffer[127];
  input_frame_mux_fn       = input_frame_mux;
end
endfunction

//----------------------------------------------------------------------------
// ID or Data calculation
//----------------------------------------------------------------------------
// This function calculates which byte is ID after the rearrangement of frame
// as described in input_frame_mux_fn
function [14:0] id_or_data_fn;
  input [127:0] input_buffer;
  reg    [14:0] id_or_data;
begin
  // This bit is set when byte refers to ID. For odd bytes, It is an ID
  // if the ID bit is set and corresponding flag bit is not set.
  // For even bytes, it is an ID if the corresponding odd byte is an ID and 
  // corresponding flag bit is set
  id_or_data[0]  = input_buffer[0]  &  ~input_buffer[120];
  id_or_data[1]  = input_buffer[0]  &   input_buffer[120];
  id_or_data[2]  = input_buffer[16] &  ~input_buffer[121];
  id_or_data[3]  = input_buffer[16] &   input_buffer[121];
  id_or_data[4]  = input_buffer[32] &  ~input_buffer[122];
  id_or_data[5]  = input_buffer[32] &   input_buffer[122];
  id_or_data[6]  = input_buffer[48] &  ~input_buffer[123];
  id_or_data[7]  = input_buffer[48] &   input_buffer[123];
  id_or_data[8]  = input_buffer[64] &  ~input_buffer[124];
  id_or_data[9]  = input_buffer[64] &   input_buffer[124];
  id_or_data[10] = input_buffer[80] &  ~input_buffer[125];
  id_or_data[11] = input_buffer[80] &   input_buffer[125];
  id_or_data[12] = input_buffer[96] &  ~input_buffer[126];
  id_or_data[13] = input_buffer[96] &   input_buffer[126];
  id_or_data[14] = input_buffer[112];
  id_or_data_fn  = id_or_data;
end
endfunction

//----------------------------------------------------------------------------
//
// MAIN CODE
//
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
// APB Read FIFO
// Read Data from Read Buffer when APB Read ack is asserted.
// Return data to APB after that.
//----------------------------------------------------------------------------
always @*
begin
  // Default value of rb_req_set is always low
  rb_req_set                    = 1'b0;
  // Retain old fifo state
  nxt_fifo_state               = fifo_state;
  // Read data acknowledge to APB is set low
  nxt_rrd_rd_ack               = 1'b0;
  // Retain old value of rtpr
  nxt_apb_rptr                 = apb_rptr;
  // default value of apb_read_fifo_rrp_en is 0
  nxt_apb_read_fifo_rrp_en     = 1'b0;
  case (fifo_state)
    // No data in FIFO
    FIFO_EMPTY : begin
      // Retain rptr, since rrd must be kept stable if rrd_rd_ack is low
      nxt_apb_rptr             = apb_rptr;
      // IF a read request from APB is set, assert rb_req_valid
      rb_req_set                = rrd_rd_req;
      // If a read request from APB is set, transition to REQ_RAISED
      nxt_fifo_state           = rrd_rd_req ? FIFO_REQ_RAISED : FIFO_EMPTY;
    end
    FIFO_REQ_RAISED : begin
      // If data received, transition to NOT_EMPTY state, else stay
      nxt_fifo_state           = rb_rdata_valid ? FIFO_NOT_EMPTY : FIFO_REQ_RAISED;
      // Provide first acknowledgement to APB next clock when data received this clock
      nxt_rrd_rd_ack           = rb_rdata_valid;
      // When data is received, initialise the pointer to point to the least
      // significant 32-bit word of data.
      nxt_apb_rptr             = rb_rdata_valid ? {PTR_WIDTH{1'b0}} : apb_rptr;
    end
    FIFO_NOT_EMPTY : begin
      // In this state, FIFO has data existing, so read data can be returned next clock
      nxt_rrd_rd_ack           = rrd_rd_req;
      // Increment read pointer when a request is received. Data will be read out
      // of the incremented rptr
      nxt_apb_rptr             = rrd_rd_req ? apb_rptr + PADDED_1 : apb_rptr;
      // When a read request is asserted, and if the rptr is FIFO_DEPTH-2, then
      // in the next clock all data in the FIFO would be read out. So apb_read_fifo_rrp_en
      // will be set to memory interface to increment the read pointer
      nxt_apb_read_fifo_rrp_en = (rrd_rd_req && (apb_rptr == FIFO_DEPTH_MINUS_2)) ? 1'b1 : 1'b0;
      // When a read request is asserted and if rtpr is FIFO_DEPTH_GT_1-2, then all data in FIFO
      // would be read out next clock. transition to empty. Transition to empty even when
      // apbreadfifo_clr is set
      nxt_fifo_state           = (apbreadfifo_clr || (rrd_rd_req && (apb_rptr == FIFO_DEPTH_MINUS_2))) ? FIFO_EMPTY :
                                   FIFO_NOT_EMPTY;
    end
    default : begin
      nxt_rrd_rd_ack           = 1'bx;
      nxt_apb_rptr             = {PTR_WIDTH{1'bx}};
      nxt_fifo_state           = 2'bxx;
      rb_req_set                = 1'bx;
      nxt_apb_read_fifo_rrp_en = 1'bx;
    end
  endcase
end

// APB Data is combinationally read out of the APB Read FIFO
assign rrd = apb_read_fifo[apb_rptr];

// Representing rb_data_reg as a memory, to enable easy muxing using rptr
always @*
begin
  for (loopvar_i=0; loopvar_i < FIFO_DEPTH; loopvar_i=loopvar_i+1) begin : apbreadfifo_for
    apb_read_fifo[loopvar_i] = input_buffer0[loopvar_i*32 +: 32];
  end
end

// Generating unformatter_dis to be used for clock enable
assign unformatter_dis = ~unformatter_en;

// FLops for above logic
always @(posedge cxtmc_clk or negedge RESETn)
begin
  if (!RESETn) begin
    rrd_rd_ack            <= 1'b0;
    rb_req_valid_apb      <= 1'b0;
    fifo_state            <= FIFO_EMPTY;
    apb_rptr              <= {PTR_WIDTH{1'b0}};
    apb_read_fifo_rrp_en  <= 1'b0;
  end else if (unformatter_dis) begin
    apb_read_fifo_rrp_en  <= nxt_apb_read_fifo_rrp_en;
    rrd_rd_ack            <= nxt_rrd_rd_ack;
    rb_req_valid_apb      <= nxt_rb_req_valid_apb;
    fifo_state            <= nxt_fifo_state;
    apb_rptr              <= nxt_apb_rptr;
  end
end

//----------------------------------------------------------------------------
// Unformatter Empty generation
//----------------------------------------------------------------------------
//   1. Unformatter not enabled:
//        a. Input/frame buffers are empty, request counter is 0 and ATVALID is not set - this is to ensure that
//           If unformatter_en goes low when there is data in input/framebuffer/ATDATA registers -
//           empty is not set until all that data is emptied out
//   2. Unformatter enabled
//        a. input/frame buffers are empty, request counter is 0 and atleast one of req_valid/req_ready is low and ATVALID is not set
//            Ensures that empty is not set when a request raised is not acknowledged.
//
assign unformatter_empty = (req_cntr == {REQ_CNTR_WIDTH{1'b0}}) && (ATVALIDM == 1'b0) && (unformatter_en ? 
                           (~rb_req_valid_unf || ~rb_req_ready) : (fifo_state == FIFO_EMPTY));

//----------------------------------------------------------------------------
// Combined Request Valid generated
//----------------------------------------------------------------------------
assign rb_req_valid = rb_req_valid_unf | rb_req_valid_apb;

//----------------------------------------------------------------------------
// APB READ FIFO LOGIC
// Read Data from Read Buffer when APB Read ack is asserted.
// Return data to APB after that.
//----------------------------------------------------------------------------
assign nxt_rb_req_valid_apb = (rb_req_valid_apb & ~rb_req_ready) | rb_req_set;

//----------------------------------------------------------------------------
// atmbf_valid is asserted only when hw_fifo_mode is set
// if AFVALIDM and atbm_flush_ready are set together this signal is reset
// if AVALIDM is set when atbm_flush_ready is not there, then the signal is asserted
// Else the signal is maintained
//----------------------------------------------------------------------------
assign nxt_atbm_flush_valid = hw_fifo_mode && unformatter_en && (AFVALIDM && !atbm_flush_ready  && 
                           !((|flush_pending)|| flush_done || AFREADYM)) ? 1'b1 : 
                           ((AFVALIDM && atbm_flush_ready) || !unformatter_en) ? 1'b0 : atbm_flush_valid;
                          

//----------------------------------------------------------------------------
// when atbm_flush_ready is set, record the number of valid buffers to be flushed.
// These number of buffers get decremented on a f1_f0_bndry_cross
//----------------------------------------------------------------------------
assign nxt_flush_pending   = !unformatter_en ? {MAX_BUFFERS{1'b0}} : 
                               atbm_flush_ready ? (total_valid_buffers - {{REQ_CNTR_WIDTH-1{1'b0}},f1_f0_bndry_cross}): 
                               (f1_f0_bndry_cross && |flush_pending) ? flush_pending - {{MAX_BUFFERS-1{1'b0}},1'b1} : 
                               flush_pending;
assign nxt_flush_done      = unformatter_en && last_frame_flush && f1_f0_bndry_cross ? 1'b1 : 
                              nxt_afreadym ? 1'b0 : flush_done;

always @(posedge cxtmc_clk or negedge RESETn)
begin
  if (!RESETn) begin
    flush_pending     <= {MAX_BUFFERS{1'b0}};
    flush_done        <= 1'b0;
    atbm_flush_valid  <= 1'b0;
  end else begin
    flush_pending     <= nxt_flush_pending;
    flush_done        <= nxt_flush_done;
    atbm_flush_valid  <= nxt_atbm_flush_valid;
  end
end

//----------------------------------------------------------------------------
// Calculation of total buffers that are valid
// This is used to reset the req_cntr when unformatter_en goes unpredictably
// low
//----------------------------------------------------------------------------
generate if (CXTMC_ATB_DATA_WIDTH == 32)
begin
  // Only 4 of the 5 signals will be high at any point of time
  assign total_valid_buffers = rb_rdata_valid + input_buffer0_val +
                               input_buffer1_val + frame_buffer0_val 
                               + frame_buffer1_val;
end else
begin
  // Only 3 of the 4 signals will be high at any point of time
  assign total_valid_buffers = rb_rdata_valid + input_buffer0_val +
                               frame_buffer0_val + frame_buffer1_val;
end
endgenerate

//----------------------------------------------------------------------------
// read buffer request generation
// If the sum of requests pending are less than 4 requests - rb_req_valid is set
// request counter is incremented when a request is accepted by the
// read buffer and decremented when data has been read into ATDATAM buffer
//----------------------------------------------------------------------------
  always @*
  begin
    if (!unformatter_en) begin
      // If unformatter is disabled abruptly, there could some pending requests to
      // the read buffer. Ensure that all the data for the pending requests is received
      // before setting the req cntr to 0
      nxt_req_cntr = (req_cntr != {REQ_CNTR_WIDTH{1'b0}}) ?  req_cntr - total_valid_buffers :
                      req_cntr;
    end else begin
      case ({(rb_req_valid&rb_req_ready),f1_f0_bndry_cross})
        2'b00, 2'b11 : nxt_req_cntr = req_cntr;
               2'b01 : nxt_req_cntr = req_cntr - {{REQ_CNTR_WIDTH-1{1'b0}},1'b1};
               2'b10 : nxt_req_cntr = req_cntr + {{REQ_CNTR_WIDTH-1{1'b0}},1'b1};
        default      : nxt_req_cntr = {REQ_CNTR_WIDTH{1'bx}};
      endcase
    end
  end
  assign rb_req_valid_unf = unformatter_en ? (((req_cntr != MAX_BUFFERS) || f1_f0_bndry_cross) ? 1'b1 : 1'b0) :
                                             1'b0;
// Register logic for req_cntr and clocked versions of rb_req_valid and rb_req_ready
always @(posedge cxtmc_clk or negedge RESETn)
begin
  if (!RESETn) begin
    req_cntr       <= {REQ_CNTR_WIDTH{1'b0}};
  end else begin
    req_cntr       <= nxt_req_cntr;
  end
end

generate if (CXTMC_ATB_DATA_WIDTH == 32)
begin
  // input_buffer0 can be written to - either when it is empty or being
  // emptied 
  assign input_buffer0_en_unf   = unformatter_en & (~input_buffer0_val | frame_buffer0_en) & rb_rdata_valid;
  // input_buffer1 can be written to - either when it is empty or being
  // emptied. It can be only written when there is data already present in
  // input_buffer0
  assign input_buffer1_en       = unformatter_en & input_buffer0_val & ~frame_buffer0_en & (~input_buffer1_val | frame_buffer1_en) & rb_rdata_valid;
  // input_buffer0 is valid when a data write happens to it, and becomes
  // invalid when data in it is read out
  assign nxt_input_buffer0_val = input_buffer0_en_unf ? 1'b1 :
                                  (frame_buffer0_en || !unformatter_en) ? 1'b0 : input_buffer0_val;
  // input_buffer1 is valid when a data write happens to it, and becomes
  // invalid when data in it is read out
  assign nxt_input_buffer1_val = input_buffer1_en ? 1'b1 :
                                  (frame_buffer1_en || !unformatter_en) ? 1'b0 : input_buffer1_val;
                             
  // input_buffer val register block
  always @(posedge cxtmc_clk or negedge RESETn)
  begin
    if (!RESETn) begin
      input_buffer0_val <= 1'b0;
      input_buffer1_val <= 1'b0;
    end else begin
      input_buffer0_val <= nxt_input_buffer0_val;
      input_buffer1_val <= nxt_input_buffer1_val;
    end
  end
  // input_buffer1 register block
  always @(posedge cxtmc_clk)
  begin
    if (input_buffer1_en) begin
      input_buffer1 <= rb_data;
    end
  end
end else 
begin
  // input_buffer0 can be written to - either when it is empty or being
  // emptied 
  assign input_buffer0_en_unf   = unformatter_en & (~input_buffer0_val | frame_buffer0_en | frame_buffer1_en) & rb_rdata_valid;
  // input_buffer0 is valid when a data write happens to it, and becomes
  // invalid when data in it is read out
  assign nxt_input_buffer0_val = input_buffer0_en_unf ? 1'b1 :
                                  (frame_buffer0_en  || frame_buffer1_en || !unformatter_en)  ? 1'b0 : input_buffer0_val;

  // input_buffer val register block
  always @(posedge cxtmc_clk or negedge RESETn)
  begin
    if (!RESETn) begin
      input_buffer0_val <= 1'b0;
    end else begin
      input_buffer0_val <= nxt_input_buffer0_val;
    end
  end
end
endgenerate

assign input_buffer0_en = input_buffer0_en_unf | (~unformatter_en & rb_rdata_valid); 

// Input Buffer 0
always @(posedge cxtmc_clk)
begin
  if (input_buffer0_en) begin
    input_buffer0 <= rb_data;
  end
end


generate if (CXTMC_ATB_DATA_WIDTH == 32)
begin
  // Clock enable for frame buffer0. Is set only when unformatting is enabled
  // Frame buffer0 can be written only when there is data in both input_buffer0 and input_buffer1
  // in 32 bit case. This is because, the flag information present in input buffer1 is used to 
  // update the data that is to be clocked to input buffer0. This is set if frame buffer0 doesnt
  // contain valid data, or if the valid data is being read out.
  assign frame_buffer0_en       = unformatter_en & input_buffer1_val & (~frame_buffer0_val | 
                                      (wptr_in_frame0 & rptr_in_frame0 & f1_f0_bndry_cross));
  // Clock enable for frame buffer1. Is set only when unformatting is enabled
  // frame buffer1 always gets written from input buffer1 in 32 bit case. Is set when frame buffer1
  // doesnt contain data or if data from frame buffer1 is being read out.
  assign frame_buffer1_en       = unformatter_en & input_buffer1_val & (~frame_buffer1_val | 
                                                 (~rptr_in_frame0 & f1_f0_bndry_cross));
  // This signal indicates the frame which the read buffer data will be written. This is reset when
  // unformatter_en goes low. This is changed only when one of the buffers is getting written to 
  // retains value when both are written to simultaneously.
  assign nxt_wptr_in_frame0    = !unformatter_en ? 1'b1 : (wptr_in_frame0 ^ frame_buffer0_en ^ frame_buffer1_en);
  // If APB Control block asserts unformatter_stop to indicate that all pending data has to be flushed then
  // this signal is asserted when frame buffer1 has valid data and frame buffer0 has no valid data
  // When this signal is asserted, all pending data in frame buffer1 is flushed out whether or not 
  // it forms a complete ATB Data cycle
  assign unf_stop_in_progress   = unformatter_stop & nxt_frame_buffer1_val & ~nxt_frame_buffer0_val;
  // This signal indicates that in the next clock enough data will be available in Frame buffers to create 
  // atleast one ATB transaction. This signal will be set also when for flushing purposes, a 
  // ATB transaction is going to be generated less than the full ATB Width.
  // Enough data for a transaction will be available when both frame buffers have valid data, or if the
  // next rptr calculation from frame buffer1 shows that there is enough data available in frame buffer1
  // to form a single ATB transaction. Else this will be set either when stop or flush is in progress
  assign nxt_atb_data_avail    = (nxt_frame_buffer0_val & nxt_frame_buffer1_val) | 
                                  (~nxt_rptr_in_frame0 & nxt_frame_buffer1_val & 
                                  (atdata_for_1cycle_available_f1 | unf_stop_in_progress | nxt_last_frame_flush));
end else
begin
  // Clock enable for frame buffer0. Is set only when unformatting is enabled
  // Frame buffer0 can be written when ther write pointer is pointing to frame buffer0 
  // and if there is no valid data in frame buffer0 or if the valid data is being read out in this
  // clock
  assign frame_buffer0_en       = unformatter_en & input_buffer0_val & wptr_in_frame0 & 
                                  (~frame_buffer0_val | (rptr_in_frame0 & f1_f0_bndry_cross));
  // Clock enable for frame buffer1. Is set only when unformatting is enabled
  // Frame buffer1 can be written when ther write pointer is pointing to frame buffer1 
  // and if there is no valid data in frame buffer1 or if the valid data is being read out in this
  // clock
  assign frame_buffer1_en       = unformatter_en & input_buffer0_val & ~wptr_in_frame0 & 
                                  (~frame_buffer1_val | (~rptr_in_frame0 & f1_f0_bndry_cross));
  // This signal indicates the frame which the read buffer data will be written. This is reset when
  // unformatter_en goes low. This is toggled only when any one of the buffers are getting written to 
  assign nxt_wptr_in_frame0    = !unformatter_en ? 1'b1 : (wptr_in_frame0 ^ (frame_buffer0_en | frame_buffer1_en));
  // If APB Control block asserts unformatter_stop to indicate that all pending data has to be flushed then
  // this signal is asserted when frame buffer1 has valid data and frame buffer0 has no valid data or vice versa
  // When this signal is asserted, all pending data in frame buffer1/frame buffer0 is flushed out whether or not 
  // it forms a complete ATB Data cycle
  assign unf_stop_in_progress   = unformatter_stop & (nxt_frame_buffer1_val ^ nxt_frame_buffer0_val);
  // This signal indicates that in the next clock enough data will be available in Frame buffers to create 
  // atleast one ATB transaction. This signal will be set also when for flushing purposes, a 
  // ATB transaction is going to be generated less than the full ATB Width.
  // Enough data for a transaction will be available when both frame buffers have valid data, or if the
  // next rptr calculation from frame buffer0/1 shows that there is enough data available in frame buffer0/1
  // to form a single ATB transaction. Else this will be set either when stop or flush is in progress
  assign nxt_atb_data_avail    = (nxt_frame_buffer0_val & nxt_frame_buffer1_val) | 
                                  (~nxt_rptr_in_frame0 & nxt_frame_buffer1_val & 
                                  (atdata_for_1cycle_available_f1 | unf_stop_in_progress | nxt_last_frame_flush1)) |
                                  (nxt_rptr_in_frame0 & nxt_frame_buffer0_val & 
                                  (atdata_for_1cycle_available_f0 | unf_stop_in_progress | nxt_last_frame_flush0));
end
endgenerate

// frame buffer0 is cleared when rptr moves away from frame buffer0 to frame buffer1
assign frame_buffer0_clr     = frame_buffer0_val & rptr_in_frame0 & f1_f0_bndry_cross;
// frame buffer1 is cleared when rptr moves away from frame buffer1 to frame buffer0
assign frame_buffer1_clr     = frame_buffer1_val & ~rptr_in_frame0 & f1_f0_bndry_cross;
// frame buffer 0 data will be valid when a write happens or when the existing data is not being cleared
assign nxt_frame_buffer0_val = unformatter_en & ((frame_buffer0_val & ~frame_buffer0_clr) | frame_buffer0_en);
// frame buffer 1 data will be valid when a write happens or when the existing data is not being cleared
assign nxt_frame_buffer1_val = unformatter_en & ((frame_buffer1_val & ~frame_buffer1_clr) | frame_buffer1_en);
// f1_f0_bndry_cross indicates if rptr jumps from frame0 to frame 1 or vice-versa. When this happens
// rptr_in_frame0 i stoggled
assign nxt_rptr_in_frame0    = !unformatter_en ? 1'b1 : (rptr_in_frame0 ^ f1_f0_bndry_cross);


always @(posedge cxtmc_clk or negedge RESETn)
begin
  if (!RESETn) begin
    frame_buffer0_val <= 1'b0;
    frame_buffer1_val <= 1'b0;
    rptr_in_frame0    <= 1'b1;
    wptr_in_frame0    <= 1'b1;
    atb_data_avail    <= 1'b0;
  end else begin
    frame_buffer0_val <= nxt_frame_buffer0_val;
    frame_buffer1_val <= nxt_frame_buffer1_val;
    rptr_in_frame0    <= nxt_rptr_in_frame0;
    wptr_in_frame0    <= nxt_wptr_in_frame0;
    atb_data_avail    <= nxt_atb_data_avail;
  end
end
                                
generate if (CXTMC_ATB_DATA_WIDTH == 32)
begin
  // temp_is_frame1_id and temp_is_frame0_id are calculated from input_buffer1 and input_buffer0
  // using id_or_data_fn function
  assign {temp_is_frame1_id,temp_is_frame0_id}    = id_or_data_fn({input_buffer1,input_buffer0});
  always @*
  begin
  // nxt_frame_buffer1 and nxt_frame_buffer0 are calculated from input_buffer1 and input_buffer0
  // using input_frame_mux_fn function
    {nxt_frame_buffer1,nxt_frame_buffer0}       = input_frame_mux_fn({input_buffer1,input_buffer0});
  end
end 
else if (CXTMC_ATB_DATA_WIDTH == 64)
begin
  // temp_is_frame1_id and temp_is_frame0_id are calculated from input_buffer0
  // using id_or_data_fn function
  assign temp_is_frame1_id                        = id_or_data_fn(input_buffer0);
  assign temp_is_frame0_id                        = id_or_data_fn(input_buffer0);

  always @*
  begin
    // nxt_frame_buffer1 and nxt_frame_buffer0 are calculated from input_buffer0
    // using input_frame_mux_fn function
    nxt_frame_buffer0                             = input_frame_mux_fn(input_buffer0);
    nxt_frame_buffer1                             = input_frame_mux_fn(input_buffer0);
  end
end 
else
begin
  wire  [14:0] temp_id0;
  wire  [14:0] temp_id1;
  reg  [119:0] temp_frame0;
  reg  [119:0] temp_frame1;
  // temp_is_frame1_id and temp_is_frame0_id are calculated from input_buffer0
  // using id_or_data_fn function
  assign temp_id1            = id_or_data_fn(input_buffer0[INPUT_BUFFER_WIDTH-1:FRAME_WIDTH]);
  assign temp_id0            = id_or_data_fn(input_buffer0[FRAME_WIDTH-1:0]);
  assign temp_is_frame1_id   = {temp_id1,temp_id0};
  assign temp_is_frame0_id   = {temp_id1,temp_id0};

  always @*
  begin
    // nxt_frame_buffer1 and nxt_frame_buffer0 are calculated from input_buffer0
    // using input_frame_mux_fn function
    temp_frame1         = input_frame_mux_fn(input_buffer0[INPUT_BUFFER_WIDTH-1:FRAME_WIDTH]);
    temp_frame0         = input_frame_mux_fn(input_buffer0[FRAME_WIDTH-1:0]);
    nxt_frame_buffer1  = {temp_frame1,temp_frame0};
    nxt_frame_buffer0  = {temp_frame1,temp_frame0};
  end
end
endgenerate


// Register block for frame_buffer0
always @(posedge cxtmc_clk)
begin
  if (frame_buffer0_en) begin
    frame_buffer0        <= nxt_frame_buffer0;
  end
end

// is_frame1_id generation - assigned to temp_is_frame1_id when frame_buffer1_en is set
assign nxt_is_frame0_id = frame_buffer0_en ?  temp_is_frame0_id :
                           (frame_buffer0_clr || !unformatter_en) ? {RPTR_HALF{1'b0}} : is_frame0_id;

// Clock frame id when frame is enabled or disabled
assign frame_id0_en      = frame_buffer0_en | frame_buffer0_clr | (~unformatter_en & ~unformatter_empty);

always @(posedge cxtmc_clk or negedge RESETn)
begin
  if (!RESETn) begin
    is_frame0_id  <= {RPTR_HALF{1'b0}};
  end else if (frame_id0_en) begin
    is_frame0_id  <= nxt_is_frame0_id;
  end
end

// Register block for frame_buffer1
always @(posedge cxtmc_clk)
begin
  if (frame_buffer1_en) begin
    frame_buffer1        <= nxt_frame_buffer1;
  end
end

// is_frame1_id generation - assigned to temp_is_frame1_id when frame_buffer1_en is set
assign nxt_is_frame1_id = frame_buffer1_en ?  temp_is_frame1_id :
                           (frame_buffer1_clr || !unformatter_en) ? {RPTR_TOP_HALF{1'b0}} : is_frame1_id;

assign frame_id1_en      = frame_buffer1_en | frame_buffer1_clr | (~unformatter_en & ~unformatter_empty);

always @(posedge cxtmc_clk or negedge RESETn)
begin
  if (!RESETn) begin
    is_frame1_id  <= {RPTR_TOP_HALF{1'b0}};
  end else if (frame_id1_en) begin
    is_frame1_id  <= nxt_is_frame1_id;
  end
end


// is_frame1_id indicate all bytes that are id in frame1
// is_frame0_id indicate all bytes that are id in frame0
// is_frame_id is concatenation of is_frame1_id and is_frame0_id signals
// When flush or unformatter stop in progress, 0th bit of nxt_is_frame_id_fready is set - This ensures that
// all the last bytes in frame 1 are flushed out, even when they do not form a complete ATB Cycle
assign is_frame_id            = {is_frame1_id,is_frame0_id};
assign nxt_is_frame_id        = {nxt_is_frame1_id,nxt_is_frame0_id};
generate if (CXTMC_ATB_DATA_WIDTH == 32)
begin
  assign nxt_last_frame_flush   = (nxt_flush_pending == {{MAX_BUFFERS-1{1'b0}},1'b1}) & nxt_frame_buffer1_val;
  assign last_frame_flush       = (flush_pending == {{MAX_BUFFERS-1{1'b0}},1'b1}) & frame_buffer1_val;
  assign nxt_is_frame_id_fready = ({nxt_is_frame1_id,nxt_is_frame0_id} | 
                                    {{RPTR_WIDTH-1{1'b0}},(nxt_last_frame_flush | unf_stop_in_progress)});
  assign is_frame_id_fready     = ({is_frame1_id,is_frame0_id} | 
                                    {{RPTR_WIDTH-1{1'b0}},(last_frame_flush | unf_stop_in_progress)});
end else
begin

  assign rdata_input_buf_val    = rb_rdata_valid|input_buffer0_val;
  always @*
  begin
    if (atbm_flush_ready) begin
      case({rdata_input_buf_val,frame_buffer0_val,frame_buffer1_val})
        3'b010, 3'b100, 3'b101 : nxt_flush_frame0_last = 1'b1;
        3'b001, 3'b011, 3'b110 : nxt_flush_frame0_last = 1'b0;
                3'b000, 3'b111 : nxt_flush_frame0_last = wptr_in_frame0;
                       default : nxt_flush_frame0_last = 1'bx;
      endcase
    end else begin
      nxt_flush_frame0_last = flush_frame0_last;
    end
  end 

  assign nxt_last_frame_flush0  = (nxt_flush_pending == {{MAX_BUFFERS-1{1'b0}},1'b1}) & 
                                      flush_frame0_last;
  assign nxt_last_frame_flush1  = (nxt_flush_pending == {{MAX_BUFFERS-1{1'b0}},1'b1}) & 
                                      ~flush_frame0_last;
  assign last_frame_flush       = last_frame_flush0 |last_frame_flush1;
  assign nxt_is_frame_id_fready = ({nxt_is_frame1_id,nxt_is_frame0_id} | 
                                    {{{RPTR_TOP_HALF-1{1'b0}},(nxt_last_frame_flush0 | unf_stop_in_progress)},
                                    {{RPTR_HALF-1{1'b0}},(nxt_last_frame_flush1 | unf_stop_in_progress)}});
  assign is_frame_id_fready     = ({is_frame1_id,is_frame0_id} | 
                                     {{{RPTR_TOP_HALF-1{1'b0}},(last_frame_flush0 | unf_stop_in_progress)},
                                     {{RPTR_HALF-1{1'b0}},(last_frame_flush1 | unf_stop_in_progress)}});



always @(posedge cxtmc_clk or negedge RESETn)
begin
  if (!RESETn) begin
    last_frame_flush0 <= 1'b0;
    last_frame_flush1 <= 1'b0;
    flush_frame0_last <= 1'b0;
  end else begin
    last_frame_flush0 <= nxt_last_frame_flush0;
    last_frame_flush1 <= nxt_last_frame_flush1;
    flush_frame0_last <= nxt_flush_frame0_last;
  end
end


end
endgenerate

// sel calculation is based on rptr for the next cycle
// If current rptr is a id
//   - sel value is selected such a way that byte pointing to rptr is muxed in to ATIDM
//   - and the bytes after that are muxed onto ATDATAM
// If current rptr is not a id
//   - sel value is selected such a way that byte pointing to rptr is muxed onto ATDATAM
generate if (CXTMC_ATB_DATA_WIDTH == 128)
begin
  always @*
  begin
    case(rptr_nxt_cycle)
        60'h000_0000_0000_0001  : nxt_sel =  nxt_is_frame_id[0]  ?  6'b000000 : 6'b000001;
        60'h000_0000_0000_0002  : nxt_sel =  nxt_is_frame_id[1]  ?  6'b111011 : 6'b000000;
        60'h000_0000_0000_0004  : nxt_sel =  nxt_is_frame_id[2]  ?  6'b111010 : 6'b111011;
        60'h000_0000_0000_0008  : nxt_sel =  nxt_is_frame_id[3]  ?  6'b111001 : 6'b111010;
        60'h000_0000_0000_0010  : nxt_sel =  nxt_is_frame_id[4]  ?  6'b111000 : 6'b111001;
        60'h000_0000_0000_0020  : nxt_sel =  nxt_is_frame_id[5]  ?  6'b110111 : 6'b111000;
        60'h000_0000_0000_0040  : nxt_sel =  nxt_is_frame_id[6]  ?  6'b110110 : 6'b110111;
        60'h000_0000_0000_0080  : nxt_sel =  nxt_is_frame_id[7]  ?  6'b110101 : 6'b110110;
        60'h000_0000_0000_0100  : nxt_sel =  nxt_is_frame_id[8]  ?  6'b110100 : 6'b110101;
        60'h000_0000_0000_0200  : nxt_sel =  nxt_is_frame_id[9]  ?  6'b110011 : 6'b110100;
        60'h000_0000_0000_0400  : nxt_sel = nxt_is_frame_id[10]  ?  6'b110010 : 6'b110011;
        60'h000_0000_0000_0800  : nxt_sel = nxt_is_frame_id[11]  ?  6'b110001 : 6'b110010;
        60'h000_0000_0000_1000  : nxt_sel = nxt_is_frame_id[12]  ?  6'b110000 : 6'b110001;
        60'h000_0000_0000_2000  : nxt_sel = nxt_is_frame_id[13]  ?  6'b101111 : 6'b110000;
        60'h000_0000_0000_4000  : nxt_sel = nxt_is_frame_id[14]  ?  6'b101110 : 6'b101111;
        60'h000_0000_0000_8000  : nxt_sel = nxt_is_frame_id[15]  ?  6'b101101 : 6'b101110;
        60'h000_0000_0001_0000  : nxt_sel = nxt_is_frame_id[16]  ?  6'b101100 : 6'b101101;
        60'h000_0000_0002_0000  : nxt_sel = nxt_is_frame_id[17]  ?  6'b101011 : 6'b101100;
        60'h000_0000_0004_0000  : nxt_sel = nxt_is_frame_id[18]  ?  6'b101010 : 6'b101011;
        60'h000_0000_0008_0000  : nxt_sel = nxt_is_frame_id[19]  ?  6'b101001 : 6'b101010;
        60'h000_0000_0010_0000  : nxt_sel = nxt_is_frame_id[20]  ?  6'b101000 : 6'b101001;
        60'h000_0000_0020_0000  : nxt_sel = nxt_is_frame_id[21]  ?  6'b100111 : 6'b101000;
        60'h000_0000_0040_0000  : nxt_sel = nxt_is_frame_id[22]  ?  6'b100110 : 6'b100111;
        60'h000_0000_0080_0000  : nxt_sel = nxt_is_frame_id[23]  ?  6'b100101 : 6'b100110;
        60'h000_0000_0100_0000  : nxt_sel = nxt_is_frame_id[24]  ?  6'b100100 : 6'b100101;
        60'h000_0000_0200_0000  : nxt_sel = nxt_is_frame_id[25]  ?  6'b100011 : 6'b100100;
        60'h000_0000_0400_0000  : nxt_sel = nxt_is_frame_id[26]  ?  6'b100010 : 6'b100011;
        60'h000_0000_0800_0000  : nxt_sel = nxt_is_frame_id[27]  ?  6'b100001 : 6'b100010;
        60'h000_0000_1000_0000  : nxt_sel = nxt_is_frame_id[28]  ?  6'b100000 : 6'b100001;
        60'h000_0000_2000_0000  : nxt_sel = nxt_is_frame_id[29]  ?  6'b011111 : 6'b100000;
        60'h000_0000_4000_0000  : nxt_sel = nxt_is_frame_id[30]  ?  6'b011110 : 6'b011111;
        60'h000_0000_8000_0000  : nxt_sel = nxt_is_frame_id[31]  ?  6'b011101 : 6'b011110;
        60'h000_0001_0000_0000  : nxt_sel = nxt_is_frame_id[32]  ?  6'b011100 : 6'b011101;
        60'h000_0002_0000_0000  : nxt_sel = nxt_is_frame_id[33]  ?  6'b011011 : 6'b011100;
        60'h000_0004_0000_0000  : nxt_sel = nxt_is_frame_id[34]  ?  6'b011010 : 6'b011011;
        60'h000_0008_0000_0000  : nxt_sel = nxt_is_frame_id[35]  ?  6'b011001 : 6'b011010;
        60'h000_0010_0000_0000  : nxt_sel = nxt_is_frame_id[36]  ?  6'b011000 : 6'b011001;
        60'h000_0020_0000_0000  : nxt_sel = nxt_is_frame_id[37]  ?  6'b010111 : 6'b011000;
        60'h000_0040_0000_0000  : nxt_sel = nxt_is_frame_id[38]  ?  6'b010110 : 6'b010111;
        60'h000_0080_0000_0000  : nxt_sel = nxt_is_frame_id[39]  ?  6'b010101 : 6'b010110;
        60'h000_0100_0000_0000  : nxt_sel = nxt_is_frame_id[40]  ?  6'b010100 : 6'b010101;
        60'h000_0200_0000_0000  : nxt_sel = nxt_is_frame_id[41]  ?  6'b010011 : 6'b010100;
        60'h000_0400_0000_0000  : nxt_sel = nxt_is_frame_id[42]  ?  6'b010010 : 6'b010011;
        60'h000_0800_0000_0000  : nxt_sel = nxt_is_frame_id[43]  ?  6'b010001 : 6'b010010;
        60'h000_1000_0000_0000  : nxt_sel = nxt_is_frame_id[44]  ?  6'b010000 : 6'b010001;
        60'h000_2000_0000_0000  : nxt_sel = nxt_is_frame_id[45]  ?  6'b001111 : 6'b010000;
        60'h000_4000_0000_0000  : nxt_sel = nxt_is_frame_id[46]  ?  6'b001110 : 6'b001111;
        60'h000_8000_0000_0000  : nxt_sel = nxt_is_frame_id[47]  ?  6'b001101 : 6'b001110;
        60'h001_0000_0000_0000  : nxt_sel = nxt_is_frame_id[48]  ?  6'b001100 : 6'b001101;
        60'h002_0000_0000_0000  : nxt_sel = nxt_is_frame_id[49]  ?  6'b001011 : 6'b001100;
        60'h004_0000_0000_0000  : nxt_sel = nxt_is_frame_id[50]  ?  6'b001010 : 6'b001011;
        60'h008_0000_0000_0000  : nxt_sel = nxt_is_frame_id[51]  ?  6'b001001 : 6'b001010;
        60'h010_0000_0000_0000  : nxt_sel = nxt_is_frame_id[52]  ?  6'b001000 : 6'b001001;
        60'h020_0000_0000_0000  : nxt_sel = nxt_is_frame_id[53]  ?  6'b000111 : 6'b001000;
        60'h040_0000_0000_0000  : nxt_sel = nxt_is_frame_id[54]  ?  6'b000110 : 6'b000111;
        60'h080_0000_0000_0000  : nxt_sel = nxt_is_frame_id[55]  ?  6'b000101 : 6'b000110;
        60'h100_0000_0000_0000  : nxt_sel = nxt_is_frame_id[56]  ?  6'b000100 : 6'b000101;
        60'h200_0000_0000_0000  : nxt_sel = nxt_is_frame_id[57]  ?  6'b000011 : 6'b000100;
        60'h400_0000_0000_0000  : nxt_sel = nxt_is_frame_id[58]  ?  6'b000010 : 6'b000011;
        60'h800_0000_0000_0000  : nxt_sel = nxt_is_frame_id[59]  ?  6'b000001 : 6'b000010;
        default                 : nxt_sel = 6'bxxxxxx;
    endcase
  end
end 
else 
if (CXTMC_ATB_DATA_WIDTH == 64) 
begin
  always @*
  begin
    case(rptr_nxt_cycle)
      30'h0000_0001 : nxt_sel = nxt_is_frame_id[0] ? 5'b00000:5'b00001;
      30'h0000_0002 : nxt_sel = nxt_is_frame_id[1] ? 5'b11101:5'b00000;
      30'h0000_0004 : nxt_sel = nxt_is_frame_id[2] ? 5'b11100:5'b11101;
      30'h0000_0008 : nxt_sel = nxt_is_frame_id[3] ? 5'b11011:5'b11100;
      30'h0000_0010 : nxt_sel = nxt_is_frame_id[4] ? 5'b11010:5'b11011;
      30'h0000_0020 : nxt_sel = nxt_is_frame_id[5] ? 5'b11001:5'b11010;
      30'h0000_0040 : nxt_sel = nxt_is_frame_id[6] ? 5'b11000:5'b11001;
      30'h0000_0080 : nxt_sel = nxt_is_frame_id[7] ? 5'b10111:5'b11000;
      30'h0000_0100 : nxt_sel = nxt_is_frame_id[8] ? 5'b10110:5'b10111;
      30'h0000_0200 : nxt_sel = nxt_is_frame_id[9] ? 5'b10101:5'b10110;
      30'h0000_0400 : nxt_sel = nxt_is_frame_id[10] ? 5'b10100:5'b10101;
      30'h0000_0800 : nxt_sel = nxt_is_frame_id[11] ? 5'b10011:5'b10100;
      30'h0000_1000 : nxt_sel = nxt_is_frame_id[12] ? 5'b10010:5'b10011;
      30'h0000_2000 : nxt_sel = nxt_is_frame_id[13] ? 5'b10001:5'b10010;
      30'h0000_4000 : nxt_sel = nxt_is_frame_id[14] ? 5'b10000:5'b10001;
      30'h0000_8000 : nxt_sel = nxt_is_frame_id[15] ? 5'b01111:5'b10000;
      30'h0001_0000 : nxt_sel = nxt_is_frame_id[16] ? 5'b01110:5'b01111;
      30'h0002_0000 : nxt_sel = nxt_is_frame_id[17] ? 5'b01101:5'b01110;
      30'h0004_0000 : nxt_sel = nxt_is_frame_id[18] ? 5'b01100:5'b01101;
      30'h0008_0000 : nxt_sel = nxt_is_frame_id[19] ? 5'b01011:5'b01100;
      30'h0010_0000 : nxt_sel = nxt_is_frame_id[20] ? 5'b01010:5'b01011;
      30'h0020_0000 : nxt_sel = nxt_is_frame_id[21] ? 5'b01001:5'b01010;
      30'h0040_0000 : nxt_sel = nxt_is_frame_id[22] ? 5'b01000:5'b01001;
      30'h0080_0000 : nxt_sel = nxt_is_frame_id[23] ? 5'b00111:5'b01000;
      30'h0100_0000 : nxt_sel = nxt_is_frame_id[24] ? 5'b00110:5'b00111;
      30'h0200_0000 : nxt_sel = nxt_is_frame_id[25] ? 5'b00101:5'b00110;
      30'h0400_0000 : nxt_sel = nxt_is_frame_id[26] ? 5'b00100:5'b00101;
      30'h0800_0000 : nxt_sel = nxt_is_frame_id[27] ? 5'b00011:5'b00100;
      30'h1000_0000 : nxt_sel = nxt_is_frame_id[28] ? 5'b00010:5'b00011;
      30'h2000_0000 : nxt_sel = nxt_is_frame_id[29] ? 5'b00001:5'b00010;
      default       : nxt_sel = 5'bxxxxx;
    endcase
  end
end else
begin
  always @*
  begin
    case(rptr_nxt_cycle)
      15'h0001 : nxt_sel = nxt_is_frame_id[0] ? 4'b0000:4'b0001;
      15'h0002 : nxt_sel = nxt_is_frame_id[1] ? 4'b1110:4'b0000;
      15'h0004 : nxt_sel = nxt_is_frame_id[2] ? 4'b1101:4'b1110;
      15'h0008 : nxt_sel = nxt_is_frame_id[3] ? 4'b1100:4'b1101;
      15'h0010 : nxt_sel = nxt_is_frame_id[4] ? 4'b1011:4'b1100;
      15'h0020 : nxt_sel = nxt_is_frame_id[5] ? 4'b1010:4'b1011;
      15'h0040 : nxt_sel = nxt_is_frame_id[6] ? 4'b1001:4'b1010;
      15'h0080 : nxt_sel = nxt_is_frame_id[7] ? 4'b1000:4'b1001;
      15'h0100 : nxt_sel = nxt_is_frame_id[8] ? 4'b0111:4'b1000;
      15'h0200 : nxt_sel = nxt_is_frame_id[9] ? 4'b0110:4'b0111;
      15'h0400 : nxt_sel = nxt_is_frame_id[10] ? 4'b0101:4'b0110;
      15'h0800 : nxt_sel = nxt_is_frame_id[11] ? 4'b0100:4'b0101;
      15'h1000 : nxt_sel = nxt_is_frame_id[12] ? 4'b0011:4'b0100;
      15'h2000 : nxt_sel = nxt_is_frame_id[13] ? 4'b0010:4'b0011;
      15'h4000 : nxt_sel = nxt_is_frame_id[14] ? 4'b0001:4'b0010;
      default  : nxt_sel = 4'bxxxx;
    endcase
  end
end
endgenerate


wire [2*RPTR_WIDTH-1:RPTR_WIDTH-CXTMC_ATB_NUM_BYTES-1] rptr_circ;
wire [2*RPTR_WIDTH-1:RPTR_WIDTH-CXTMC_ATB_NUM_BYTES-1] frame_id_circ;

assign rptr_circ     = {rptr_nxt_cycle,
                        rptr_nxt_cycle[RPTR_WIDTH-CXTMC_ATB_NUM_BYTES-1 +: CXTMC_ATB_NUM_BYTES+1]};
assign frame_id_circ = {nxt_is_frame_id_fready,
                        nxt_is_frame_id_fready[RPTR_WIDTH-CXTMC_ATB_NUM_BYTES-1 +: CXTMC_ATB_NUM_BYTES+1]};

//----------------------------------------------------------------------------
// read pointer calculation
//----------------------------------------------------------------------------
// rptr_nxt_cycle is one hot signal
// 32 bit: 5 previous bits of rptr_nxt_cycle and 6 previous bits nxt_is_frame_id_fready used for calculation
// 64 bit: 9 previous bits of rptr_nxt_cycle and 10 previous bits nxt_is_frame_id_fready used for calculation
// 128 bit: 17 previous bits of rptr_nxt_cycle and 18 previous bits nxt_is_frame_id_fready used for calculation

generate if (CXTMC_ATB_DATA_WIDTH == 32)
begin

//----------------------------------------------------------------------------
// 32 bit read pointer calculation
//----------------------------------------------------------------------------
// rptr is one hot signal
// read pointer calculation happens on each individual bit seperately - hence for loop
// For each instance, 5 previous bits of rptr and 6 previous bits is_rptr_bit_id
// including the current rptr bit are called.
// Set this bit if the current rptr is in one of the previous 5 rptr bits
// and none of the id bits are set in between.
// The rptr bit is set in one of the following conditions:
// 1. current rptr bit is an id:
//    a. if one of 2 previous rptr bits(4 or 3) are set
//    b. if the two previous bits to that (2 or1) is set and the id bits till that bit
//       are not set
// 2. previous 4 rptr bits are not id and the previous 4th rptr bit is set - or
//    the previous 5th rptr and id bits are set
// The current bit is defined as bit 5. 
  reg    [CXTMC_ATB_NUM_BYTES:0] rptr_32;
  reg  [CXTMC_ATB_NUM_BYTES+1:0] is_rptr_bit_id_32;

    
  always @*
  begin
    if(!unformatter_en) begin
      nxt_rptr_nxt_cycle = {{RPTR_WIDTH-1{1'b0}},1'b1};
      rptr_32            = {CXTMC_ATB_NUM_BYTES+1{1'b0}};
      is_rptr_bit_id_32  = {CXTMC_ATB_NUM_BYTES+2{1'b0}};
    end else begin
      for (loopvar_k=2*RPTR_WIDTH-1; loopvar_k >= RPTR_WIDTH; loopvar_k=loopvar_k-1) 
      begin : nxt_rptr_for_32
        rptr_32           = rptr_circ[loopvar_k-CXTMC_ATB_NUM_BYTES-1 +: CXTMC_ATB_NUM_BYTES+1];
        is_rptr_bit_id_32 = frame_id_circ[loopvar_k-CXTMC_ATB_NUM_BYTES-1 +: CXTMC_ATB_NUM_BYTES+2];
        nxt_rptr_nxt_cycle[loopvar_k-RPTR_WIDTH] = 
                     ((rptr_32[4] |
                     (rptr_32[3] & is_rptr_bit_id_32[4]   == 1'b0 )|
                     (rptr_32[2] & is_rptr_bit_id_32[4:3] == 2'b00) |
                     (rptr_32[1] & is_rptr_bit_id_32[4:2] == 3'b000))
                                                        & is_rptr_bit_id_32[5]) |
                     (((rptr_32[0] & is_rptr_bit_id_32[0]) | rptr_32[1]) &
                                              is_rptr_bit_id_32[4:1] == 4'b0000);
      end
    end
  end
end else
if (CXTMC_ATB_DATA_WIDTH == 64)
begin

//----------------------------------------------------------------------------
// 64 bit read pointer calculation
//----------------------------------------------------------------------------
// rptr is one hot signal
// read pointer calculation happens on each individual bit seperately - hence for loop
// For each instance, 9 previous bits of rptr and 10 previous bits is_rptr_bit_id
// including the current rptr bit is called.
// The rptr bit is set in one of the following conditions:
// 1. current rptr bit is an id:
//    a. if rptr bit is set on any of the previous bits and the id bits till that bit are not set
// 2. previous 8 rptr bits are not id and the previous 8th rptr bit is set - or
//    the previous 9th rptr and id bits are set
// The current bit is defined as bit 9. 
  reg    [CXTMC_ATB_NUM_BYTES:0] rptr_64;
  reg  [CXTMC_ATB_NUM_BYTES+1:0] is_rptr_bit_id_64;

  always @*
  begin
    if(!unformatter_en) begin
      nxt_rptr_nxt_cycle = {{RPTR_WIDTH-1{1'b0}},1'b1};
      rptr_64            = {CXTMC_ATB_NUM_BYTES+1{1'b0}};
      is_rptr_bit_id_64  = {CXTMC_ATB_NUM_BYTES+2{1'b0}};
    end else begin
      for (loopvar_m=2*RPTR_WIDTH-1; loopvar_m >= RPTR_WIDTH; loopvar_m=loopvar_m-1) 
      begin : nxt_rptr_for_64
        rptr_64           = rptr_circ[loopvar_m-CXTMC_ATB_NUM_BYTES-1 +: CXTMC_ATB_NUM_BYTES+1];
        is_rptr_bit_id_64 = frame_id_circ[loopvar_m-CXTMC_ATB_NUM_BYTES-1 +: CXTMC_ATB_NUM_BYTES+2];
        nxt_rptr_nxt_cycle[loopvar_m-RPTR_WIDTH] = 
                      ((rptr_64[8] |
                       (rptr_64[7] & is_rptr_bit_id_64[8]   == 1'b0 )|
                       (rptr_64[6] & is_rptr_bit_id_64[8:7] == 2'b00)      |
                       (rptr_64[5] & is_rptr_bit_id_64[8:6] == 3'b000)     |
                       (rptr_64[4] & is_rptr_bit_id_64[8:5] == 4'b0000)    |
                       (rptr_64[3] & is_rptr_bit_id_64[8:4] == 5'b00000)   |
                       (rptr_64[2] & is_rptr_bit_id_64[8:3] == 6'b000000)  |
                       (rptr_64[1] & is_rptr_bit_id_64[8:2] == 7'b0000000)
                                                           ) & is_rptr_bit_id_64[9]) |
                       (((rptr_64[0] & is_rptr_bit_id_64[0]) | rptr_64[1])
                                                            & is_rptr_bit_id_64[8:1] == 8'h00);
      end
    end
  end
end else
begin
//----------------------------------------------------------------------------
// 128 bit read pointer calculation
//----------------------------------------------------------------------------
// rptr is one hot signal
// read pointer calculation happens on each individual bit seperately - hence for loop
// For each instance, 17 previous bits of rptr and 18 previous bits is_rptr_bit_id
// including the current rptr bit is called.
// The rptr bit is set in one of the following conditions:
// 1. current rptr bit is an id:
//    a. if rptr bit is set on any of the previous bits and the id bits till that bit are not set
// 2. previous 16 rptr bits are not id and the previous 17 rptr bit is set - or
//    the previous 18th rptr and id bits are set
  reg    [CXTMC_ATB_NUM_BYTES:0] rptr_128;
  reg  [CXTMC_ATB_NUM_BYTES+1:0] is_rptr_bit_id_128;

  always @*
  begin
    if(!unformatter_en) begin
      nxt_rptr_nxt_cycle = {{RPTR_WIDTH-1{1'b0}},1'b1};
      rptr_128           = {CXTMC_ATB_NUM_BYTES+1{1'b0}};
      is_rptr_bit_id_128 = {CXTMC_ATB_NUM_BYTES+2{1'b0}};
    end else begin
      for (loopvar_n=2*RPTR_WIDTH-1; loopvar_n >= RPTR_WIDTH; loopvar_n=loopvar_n-1) 
      begin : nxt_rptr_for_128
        rptr_128           = rptr_circ[loopvar_n-CXTMC_ATB_NUM_BYTES-1 +: CXTMC_ATB_NUM_BYTES+1];
        is_rptr_bit_id_128 = frame_id_circ[loopvar_n-CXTMC_ATB_NUM_BYTES-1 +: CXTMC_ATB_NUM_BYTES+2];
        nxt_rptr_nxt_cycle[loopvar_n-RPTR_WIDTH] = 
                       ((rptr_128[16] |
                        (rptr_128[15] & is_rptr_bit_id_128[16]    == 1'b0 )|
                        (rptr_128[14] & is_rptr_bit_id_128[16:15] == 2'b00)    |
                        (rptr_128[13] & is_rptr_bit_id_128[16:14] == 3'b000)   |
                        (rptr_128[12] & is_rptr_bit_id_128[16:13] == 4'h0)     |
                        (rptr_128[11] & is_rptr_bit_id_128[16:12] == 5'h00)    |
                        (rptr_128[10] & is_rptr_bit_id_128[16:11] == 6'h00)    |
                        (rptr_128[9] & is_rptr_bit_id_128[16:10]  == 7'h00)    |
                        (rptr_128[8] & is_rptr_bit_id_128[16:9]   == 8'h00)    |
                        (rptr_128[7] & is_rptr_bit_id_128[16:8]   == 9'h000)   |
                        (rptr_128[6] & is_rptr_bit_id_128[16:7]   == 10'h000)  |
                        (rptr_128[5] & is_rptr_bit_id_128[16:6]   == 11'h000)  |
                        (rptr_128[4] & is_rptr_bit_id_128[16:5]   == 12'h000)  |
                        (rptr_128[3] & is_rptr_bit_id_128[16:4]   == 13'h0000) |
                        (rptr_128[2] & is_rptr_bit_id_128[16:3]   == 14'h0000) |
                        (rptr_128[1] & is_rptr_bit_id_128[16:2]   == 15'h0000)
                                                            ) & is_rptr_bit_id_128[17]) |
                        (((rptr_128[0] & is_rptr_bit_id_128[0]) | rptr_128[1]) & is_rptr_bit_id_128[16:1] == 16'h0000);
      end
    end
  end
end
endgenerate

       
// atb_clken generation depends on intgetration register status, ATVALIDM and ATREADYM
// it is set in two stages to help timing
assign temp_atb_clken = it_ctrl | ~ATVALIDM;
assign atb_clken      = temp_atb_clken | ATREADYM;

// rptr_clken is set in the following conditions:
// 1. unformatter_en is not set. This is because other conditions that set the
//    clock enable wont be available, and the final pointer settling before empty
//    can be declared happens after unformatter_en goes low, in a abrupt disable case.
// 2. ATB Data is available in the next clock - rptr update needs to happen this clock.
//    This cant be set when atb_skid_valid is high, indicating the transaction cant progress
//    If atb_data_avail or its stored version is already set, then rptr shouldnt be updated
//    as it means it has already been updated once for the current data.
assign rptr_clken    = ~unformatter_en | (nxt_atb_data_avail & 
                         (~atb_skid_valid | 
                         (~atb_data_avail & ~atb_data_avail_stored)));

// Register block for atb_data_avail_stored
always @(posedge cxtmc_clk or negedge RESETn)
begin
  if (!RESETn) begin
    atb_data_avail_stored <= 1'b0;
  end else begin
    atb_data_avail_stored <= nxt_atb_data_avail_stored;
  end
end

// rptr_clken is used to clock current_rptr and rptr_nxt_cycle and sel
always @(posedge cxtmc_clk or negedge RESETn)
begin
  if (!RESETn) begin
    current_rptr    <= {{RPTR_WIDTH-1{1'b0}},1'b1};
    sel             <= {SEL_WIDTH{1'b0}};
    rptr_nxt_cycle  <= {{RPTR_WIDTH-1{1'b0}},1'b1};
  end else if (rptr_clken) begin
    current_rptr    <= rptr_nxt_cycle;
    sel             <= nxt_sel;
    rptr_nxt_cycle  <= nxt_rptr_nxt_cycle;
  end
end

// frame_buffer is a concatenation of frame_buffer1 and frame_buffer0
assign frame_buffer = {frame_buffer1,frame_buffer0};

// nxt_atb_data_avail is stored when atb_skid_valid being high stops rtpr from getting advanced.
// it gets reset when atb_skid_valid is low again
always @*
begin
  if (!atb_skid_valid) begin
    nxt_atb_data_avail_stored = 1'b0;
  end else if (atb_data_avail && !nxt_atb_data_avail) begin
    nxt_atb_data_avail_stored = 1'b1;
  end else begin
    nxt_atb_data_avail_stored = atb_data_avail_stored;
  end
end

// if rptr for next cycle is not in the same frame as current_rptr - then f1_f0_bndry_cross is set
// rtpr_nxt_cycle is a predictive signal, which is valid only when the data from frame buffer is clocked into ATDATA
assign f1_f0_bndry_cross = ~atb_skid_valid & (atb_data_avail  | atb_data_avail_stored) & 
                           ((|current_rptr[RPTR_WIDTH-1:RPTR_HALF]) ^ (|rptr_nxt_cycle[RPTR_WIDTH-1:RPTR_HALF]));

// if the rptr for next cycle is within f1 or in the 0th byte of f0, then it means that atleast one ATDATA
// can be formed from f1 data
assign atdata_for_1cycle_available_f1 = |{nxt_rptr_nxt_cycle[RPTR_WIDTH-1:RPTR_HALF],nxt_rptr_nxt_cycle[0]};
// if the rptr for next cycle is within f0 or in the 0th byte of f1, then it means that atleast one ATDATA
// can be formed from f0 data
assign atdata_for_1cycle_available_f0 = |{nxt_rptr_nxt_cycle[RPTR_HALF:0]};


wire [2*RPTR_WIDTH-1:0] current_rptr_circ;
assign current_rptr_circ     = {current_rptr,current_rptr};

// This set of signals calculate which bytes in the frame buffer carry ID Bytes
// current_rptr is a one hot signal for the read pointer. is_frame_id has id bits set for all
// bytes which are id. These two signals are anded to arrive at which bytes are ID
always @*
begin
  for (loopvar_j=0; loopvar_j <= CXTMC_ATB_NUM_BYTES; loopvar_j=loopvar_j+1) 
  begin : rptr_nth_id_for
    rptr_nth_bit_id[loopvar_j] = 
          |(current_rptr_circ[RPTR_WIDTH-loopvar_j +: RPTR_WIDTH] & is_frame_id);
  end
end

// --------------------------------------------------------------------------
// Unformatter Mux Instantiation
// data_mux_fn inside the mux calculates the Data and ID from the frame buffer 
// based on the sel signal. Data and ID are stored in unformatted_id and 
// unformatted_data
// --------------------------------------------------------------------------
wire                      [6:0] unformatted_id;
wire [CXTMC_ATB_DATA_WIDTH-1:0] unformatted_data;
  cxtmc_unf_data_mux
  #(
    .CXTMC_FRAME_BUFFER_WIDTH   (FRAME_BUFFER_WIDTH),
    .CXTMC_ATB_DATA_WIDTH       (CXTMC_ATB_DATA_WIDTH),
    .CXTMC_SEL_WIDTH            (SEL_WIDTH)
  )
  u_cxtmc_unf_data_mux
  (
   .frame_buffer     (frame_buffer),
   .sel              (sel),
   .unformatted_id   (unformatted_id),
   .unformatted_data (unformatted_data)
  );

// flush ready calculation
assign nxt_afreadym = it_ctrl ? (it_atb_m_ctr_0_wr_en ? apb_wdata_16to0[1] : AFREADYM) :
                                (~unformatter_en | flush_done);

// Load current data into skid buffer if already a transaction is present on ATB Bus and still not accepted
assign atb_skid_ld         = ~atb_skid_valid & nxt_atvalidm_current & ATVALIDM & ~ATREADYM;

// skid data will be valid if skid data is loaded this clock or if it is already loaded and ATREADYM is still low
assign nxt_atb_skid_valid = (atb_skid_valid & ~ATREADYM) | atb_skid_ld;

// ATBYTESM calculation
// If the Byte that RPTR is pointing is a ID, then ATBYTESM either equals or the maximum value
// for the Width of the bus, or the the number of bytes from rptr to the byte that contains ID
// not including rptr byte. If RPTR is not a ID, then the rptr byte is included as well
// load data stored in skid buffer if skid is valid, else current data
generate if (CXTMC_ATB_DATA_WIDTH == 32)
begin
  assign nxt_atbytesm_current = rptr_nth_bit_id[1] ? 2'b00:
                                rptr_nth_bit_id[2] ? (rptr_nth_bit_id[0] ? 2'b00 : 2'b01) :
                                rptr_nth_bit_id[3] ? (rptr_nth_bit_id[0] ? 2'b01 : 2'b10) :
                                (rptr_nth_bit_id[0] && rptr_nth_bit_id[4] ? 2'b10 : 2'b11);

  assign nxt_atbytesm = it_ctrl ? (it_atb_m_ctr_0_wr_en ? apb_wdata_16to0[9:8] : ATBYTESM) :
                                  (atb_skid_valid ? atbytesm_skid : nxt_atbytesm_current);
end else if (CXTMC_ATB_DATA_WIDTH == 64)
begin
  assign nxt_atbytesm_current = rptr_nth_bit_id[1] ? 3'b000:
                                rptr_nth_bit_id[2]  ? (rptr_nth_bit_id[0] ? 3'b000  : 3'b001):
                                rptr_nth_bit_id[3]  ? (rptr_nth_bit_id[0] ? 3'b001  : 3'b010):
                                rptr_nth_bit_id[4]  ? (rptr_nth_bit_id[0] ? 3'b010  : 3'b011):
                                rptr_nth_bit_id[5]  ? (rptr_nth_bit_id[0] ? 3'b011  : 3'b100):
                                rptr_nth_bit_id[6]  ? (rptr_nth_bit_id[0] ? 3'b100  : 3'b101):
                                rptr_nth_bit_id[7]  ? (rptr_nth_bit_id[0] ? 3'b101  : 3'b110):
                                (rptr_nth_bit_id[0] && rptr_nth_bit_id[8] ? 3'b110  : 3'b111);
  assign nxt_atbytesm = it_ctrl ? (it_atb_m_ctr_0_wr_en ? apb_wdata_16to0[10:8] : ATBYTESM) :
                                  (atb_skid_valid ? atbytesm_skid : nxt_atbytesm_current);
end else
begin
  assign nxt_atbytesm_current = rptr_nth_bit_id[1] ? 4'b0000:
                                rptr_nth_bit_id[2]  ? (rptr_nth_bit_id[0] ? 4'b0000 : 4'b0001):
                                rptr_nth_bit_id[3]  ? (rptr_nth_bit_id[0] ? 4'b0001 : 4'b0010):
                                rptr_nth_bit_id[4]  ? (rptr_nth_bit_id[0] ? 4'b0010 : 4'b0011):
                                rptr_nth_bit_id[5]  ? (rptr_nth_bit_id[0] ? 4'b0011 : 4'b0100):
                                rptr_nth_bit_id[6]  ? (rptr_nth_bit_id[0] ? 4'b0100 : 4'b0101):
                                rptr_nth_bit_id[7]  ? (rptr_nth_bit_id[0] ? 4'b0101 : 4'b0110):
                                rptr_nth_bit_id[8]  ? (rptr_nth_bit_id[0] ? 4'b0110 : 4'b0111):
                                rptr_nth_bit_id[9]  ? (rptr_nth_bit_id[0] ? 4'b0111 : 4'b1000):
                                rptr_nth_bit_id[10] ? (rptr_nth_bit_id[0] ? 4'b1000 : 4'b1001):
                                rptr_nth_bit_id[11] ? (rptr_nth_bit_id[0] ? 4'b1001 : 4'b1010):
                                rptr_nth_bit_id[12] ? (rptr_nth_bit_id[0] ? 4'b1010 : 4'b1011):
                                rptr_nth_bit_id[13] ? (rptr_nth_bit_id[0] ? 4'b1011 : 4'b1100):
                                rptr_nth_bit_id[14] ? (rptr_nth_bit_id[0] ? 4'b1100 : 4'b1101):
                                rptr_nth_bit_id[15] ? (rptr_nth_bit_id[0] ? 4'b1101 : 4'b1110):
                                (rptr_nth_bit_id[0] && rptr_nth_bit_id[16] ? 4'b1110 : 4'b1111);
  assign nxt_atbytesm = it_ctrl ? (it_atb_m_ctr_0_wr_en ? apb_wdata_16to0[11:8] : ATBYTESM) :
                                  (atb_skid_valid ? atbytesm_skid : nxt_atbytesm_current);
end
endgenerate

// atb_data_avail indicates that data in frame buffer is ready to be muxed on to ATDATAM bus
// atb_data_avail_stored is stored version of atb_data_avail when atb_data_avail is set and did
// not take effect. ATVALIDM is set when either of them are set. ATVALIDM is not set,
// if ID for the transaction is 0.
assign nxt_atvalidm_current = (atb_data_avail | atb_data_avail_stored);

// ATVALIDM is set when skid is valid or if the current atvalidm signal is set
// When the corresponding ID value is 0, ATVALIDM doesnt get set. This is becuase
// Formatter introduces a frame with ID of 0, at the end of every flush - This data
// doesnt need to be driven on the ATB Bus. This also helps out throwing out initial
// data until ID Valid bit is received when unformatter powers on, as the default ID
// on reset is 0.
// load data stored in skid buffer if skid is valid, else current data
assign nxt_atvalidm = it_ctrl ? (it_atb_m_ctr_0_wr_en ? apb_wdata_16to0[0] : ATVALIDM) :
                                (atb_skid_valid ? (atidm_skid != 7'b000_0000) :  
                                (nxt_atvalidm_current && (nxt_atidm_current != 7'b000_0000)));



// Integration mux for atdatam
// load data stored in skid buffer if skid is valid, else unformatted data
generate if (CXTMC_ATB_DATA_WIDTH == 32)
begin
  assign nxt_atdatam = it_ctrl ? 
                         (it_atb_m_data_0_wr_en ?
                           ({apb_wdata_16to0[4], {7{1'b0}},
                           apb_wdata_16to0[3], {7{1'b0}},
                           apb_wdata_16to0[2], {7{1'b0}},
                           apb_wdata_16to0[1], {6{1'b0}}, apb_wdata_16to0[0]}) : ATDATAM) : 
                         (atb_skid_valid ? atdatam_skid  : unformatted_data);
end 
else if (CXTMC_ATB_DATA_WIDTH == 64) 
begin
  assign nxt_atdatam = it_ctrl ?
                         (it_atb_m_data_0_wr_en ?
                           ({apb_wdata_16to0[8], {7{1'b0}},
                           apb_wdata_16to0[7], {7{1'b0}},
                           apb_wdata_16to0[6], {7{1'b0}},
                           apb_wdata_16to0[5], {7{1'b0}},
                           apb_wdata_16to0[4], {7{1'b0}},
                           apb_wdata_16to0[3], {7{1'b0}},
                           apb_wdata_16to0[2], {7{1'b0}},
                           apb_wdata_16to0[1], {6{1'b0}}, apb_wdata_16to0[0]}) : ATDATAM) :
                         (atb_skid_valid ? atdatam_skid  : unformatted_data);
                                      
end else
begin
  assign nxt_atdatam = it_ctrl ?
                         (it_atb_m_data_0_wr_en ?
                           ({apb_wdata_16to0[16], {7{1'b0}},
                           apb_wdata_16to0[15], {7{1'b0}},
                           apb_wdata_16to0[14], {7{1'b0}},
                           apb_wdata_16to0[13], {7{1'b0}},
                           apb_wdata_16to0[12], {7{1'b0}},
                           apb_wdata_16to0[11], {7{1'b0}},
                           apb_wdata_16to0[10], {7{1'b0}},
                           apb_wdata_16to0[9], {7{1'b0}},
                           apb_wdata_16to0[8], {7{1'b0}},
                           apb_wdata_16to0[7], {7{1'b0}},
                           apb_wdata_16to0[6], {7{1'b0}},
                           apb_wdata_16to0[5], {7{1'b0}},
                           apb_wdata_16to0[4], {7{1'b0}},
                           apb_wdata_16to0[3], {7{1'b0}},
                           apb_wdata_16to0[2], {7{1'b0}},
                           apb_wdata_16to0[1], {6{1'b0}}, apb_wdata_16to0[0]}) : ATDATAM) :
                         (atb_skid_valid ? atdatam_skid  : unformatted_data);
end
endgenerate

// ATIDM gets assigned only when rptr points to a id
assign nxt_atidm_current  = (rptr_nth_bit_id[0] && (atb_data_avail || atb_data_avail_stored))  ? unformatted_id : ATIDM;
// load data stored in skid buffer if skid is valid, else current data
assign nxt_atidm          = it_ctrl ? (it_atb_m_ctr_1_wr_en ? apb_wdata_16to0[6:0] : ATIDM) :
                              (atb_skid_valid ? atidm_skid : nxt_atidm_current);

// Register block for ATB Bus
always @(posedge cxtmc_clk or negedge RESETn)
begin
  if (!RESETn) begin
    ATBYTESM <= {CXTMC_ATBYTES_WIDTH{1'b0}};
    ATDATAM  <= {CXTMC_ATB_DATA_WIDTH{1'b0}};
    ATIDM    <= 7'b0000000;
    ATVALIDM <= 1'b0;
  end else if (atb_clken) begin
    ATIDM    <= nxt_atidm;
    ATBYTESM <= nxt_atbytesm;
    ATDATAM  <= nxt_atdatam;
    ATVALIDM <= nxt_atvalidm;
  end
end

always @(posedge cxtmc_clk or negedge RESETn)
begin
  if (!RESETn) begin
    AFREADYM <= 1'b1;
  end else begin
    AFREADYM <= nxt_afreadym;
  end
end

// Register block for ATB Skid Buffer
always @(posedge cxtmc_clk)
begin
  if (atb_skid_ld) begin
    atbytesm_skid  <= nxt_atbytesm_current;
    atdatam_skid   <= unformatted_data;
    atidm_skid     <= nxt_atidm_current;
  end
end

// Register block for atb skid valid
always @(posedge cxtmc_clk or negedge RESETn)
begin
  if (!RESETn) begin
    atb_skid_valid <= 1'b0;
  end else begin
    atb_skid_valid <= nxt_atb_skid_valid;
  end
end


  //----------------------------------------------------------------------------
  // ASSERTIONS
  //----------------------------------------------------------------------------
`ifdef ARM_ASSERT_ON


  assert_never_unknown #(`OVL_ERROR, 1, `OVL_ASSERT,
   "OVL Message : cxtmc_unformatter - atb_skid_valid should never go X ")
      uzovl_cxtmc_unformatter_atb_skid_valid_x
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .qualifier   (1'b1),
         .test_expr   (atb_skid_valid)
        );

  assert_never_unknown #(`OVL_ERROR, 1, `OVL_ASSERT,
   "OVL Message : cxtmc_unformatter - atb_data_avail should never go X ")
      uzovl_cxtmc_unformatter_atb_data_avail_x
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .qualifier   (1'b1),
         .test_expr   (atb_data_avail)
        );

  assert_never_unknown #(`OVL_ERROR, 1, `OVL_ASSERT,
   "OVL Message : cxtmc_unformatter - nxt_atb_data_avail should never go X ")
      uzovl_cxtmc_unformatter_nxt_atb_data_avail_x
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .qualifier   (1'b1),
         .test_expr   (nxt_atb_data_avail)
        );

  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxtmc_unformatter - boundary cross cant be set when frame buffers are empty")
      uzovl_cxtmc_unformatter_bndry_cross
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   (~frame_buffer1_val & ~frame_buffer0_val & f1_f0_bndry_cross & unformatter_en)
        );


    assert_zero_one_hot #(`OVL_ERROR, RPTR_WIDTH, `OVL_ASSERT,
    "OVL Message : cxtmc_unformatter - more than one bits set in rptr_nxt_cycle")
      uzovl_cxtmc_unformatter_rptr_one_hot
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   (rptr_nxt_cycle)
        );

    assert_zero_one_hot #(`OVL_ERROR, RPTR_WIDTH, `OVL_ASSERT,
    "OVL Message : cxtmc_unformatter - more than one bits set in current_rptr")
      uzovl_cxtmc_unformatter_current_rptr_one_hot
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   (current_rptr)
        );

  // No apbreadfifo_clr in FIFO_REQ_RAISED state
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxtmc_unformatter - apbreadfifo_clr must not be asserted in FIFO_REQ_RAISED state")
      uzovl_cxtmc_unformatter_apbreadfifo_clr
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   ((fifo_state == FIFO_REQ_RAISED) & apbreadfifo_clr)
        );

// rb_rdata_valid can be set only when fifo_state is FIFO_REQ_RAISED
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxtmc_apbreadfifo - rb_rdata_valid can be set only when fifo_state is FIFO_REQ_RAISED")
      uzovl_cxtmc_unformatter_rb_rdata_valid
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   ((fifo_state != FIFO_REQ_RAISED) & ~unformatter_en & ~frame_buffer1_val & ~frame_buffer0_val  & (req_cntr == 0) & rb_rdata_valid)
        );


generate if (CXTMC_ATB_DATA_WIDTH == 32)
begin

  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxtmc_unformatter - rb_rdata_valid cant be set when all Input and Frame Buffers are set ")
      uzovl_cxtmc_unformatter_rdata_set_32
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   (frame_buffer1_val & frame_buffer0_val & input_buffer0_val & input_buffer1_val & rb_rdata_valid)
        );

  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxtmc_unformatter - if frame_buffer 1 is not valid, rptr is in buffer0, then boundary cross doesnt occur ")
      uzovl_cxtmc_unformatter_bndry_cross
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   (~frame_buffer1_val & ~rptr_in_frame0 & f1_f0_bndry_cross)
        );

  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxtmc_unformatter - FIFO_DEPTH is always 0 in 32 bit mode in FIFO_NOT_EMPTY state")
      uzovl_cxtmc_unformatter_apb_rptr
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   ((fifo_state == FIFO_NOT_EMPTY) && (apb_rptr != 2'b00))
        );

  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxtmc_unformatter - frame_buffer 0 cannot be valid, when input buffers are not valid and frame buffer1 is not valid ")
      uzovl_cxtmc_unformatter_frame_buffer0
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   (~input_buffer0_val & ~input_buffer1_val & frame_buffer0_val & ~frame_buffer1_val)
        );

  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxtmc_unformatter - input buffer1 cannot be valid, when all other buffers are 0")
      uzovl_cxtmc_unformatter_input_buffer1
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   (~input_buffer0_val & input_buffer1_val & ~frame_buffer0_val & ~frame_buffer1_val)
        );

  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxtmc_unformatter - when frame_buffer0 is being written, frame_buffer1 has to be either valid, or should be written")
      uzovl_cxtmc_unformatter_frame_buffer0_wr
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   (nxt_frame_buffer0_val & ~nxt_frame_buffer1_val)
        );


  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : rptr will point to frame buffer1 only if it has valid data or a valid data is being written to it")
      uzovl_cxtmc_unformatter_frame1_rptr
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   (~nxt_rptr_in_frame0 & ~nxt_frame_buffer1_val)
        );

  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : when only one buffer has to be flushed, frame_buffer 1 is always valid")
      uzovl_cxtmc_unformatter_flush
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   ((flush_pending == {{(MAX_BUFFERS - 1) {1'b0}}, 1'b1}) && ~frame_buffer1_val)
        );

  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : bndry cross cant happen if wptr is pointing to frame1 and rptr is in frame0")
      uzovl_cxtmc_unformatter_wptr_bndry_cross
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   (~wptr_in_frame0 & rptr_in_frame0 & f1_f0_bndry_cross)
        );
end
endgenerate


generate if (CXTMC_ATB_DATA_WIDTH == 32)
begin
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : total_valid_buffers should never become 5 or more")
      uzovl_cxtmc_unformatter_wptr_bndry_cross
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   (total_valid_buffers >= 5)
        );
end else
begin
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : total_valid_buffers should never become 4 or more")
      uzovl_cxtmc_unformatter_wptr_bndry_cross
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   (total_valid_buffers >= 4)
        );
end
endgenerate


  reg     [REQ_CNTR_WIDTH-1:0]     nxt_ovl_flush_pending, ovl_flush_pending;
  wire nxt_ovl_flush_in_prog;
  reg ovl_flush_in_prog;
  
  assign nxt_ovl_flush_in_prog = AFVALIDM & atbm_flush_ready ? 1'b1 : AFREADYM ? 1'b0 : ovl_flush_in_prog;
  
  always @* begin
    if (unformatter_en) begin
      if (atbm_flush_ready) nxt_ovl_flush_pending = total_valid_buffers - f1_f0_bndry_cross;
      else if (ovl_flush_in_prog) begin
        case({rb_rdata_valid,f1_f0_bndry_cross})
          2'b00, 2'b11 : nxt_ovl_flush_pending = ovl_flush_pending;
          2'b01        : nxt_ovl_flush_pending = ovl_flush_pending - 1'b1;
          2'b10        : nxt_ovl_flush_pending = ovl_flush_pending + 1'b1;
        endcase
      end else nxt_ovl_flush_pending = ovl_flush_pending;
    end else nxt_ovl_flush_pending = 0;
  end

  always @(posedge cxtmc_clk or negedge RESETn)
  begin
    if (!RESETn) begin
      ovl_flush_pending <= 'b0;
      ovl_flush_in_prog <= 1'b0;
    end else begin
      ovl_flush_pending <= nxt_ovl_flush_pending;
      ovl_flush_in_prog <= nxt_ovl_flush_in_prog;
    end
  end

  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : total valid buffers should always be equal to flush_pending")
      uzovl_cxtmc_unformatter_flush_pending
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   (unformatter_en & AFREADYM & (total_valid_buffers != (ovl_flush_pending + rb_rdata_valid)))
        );


generate if (CXTMC_ATB_DATA_WIDTH != 32)
begin
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxtmc_unformatter - rb_rdata_valid cant be set when all Input and Frame Buffers are set ")
      uzovl_cxtmc_unformatter_rdata_set_64_128
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   (frame_buffer1_val & frame_buffer0_val & input_buffer0_val & rb_rdata_valid)
        );

  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxtmc_unformatter - when frame_buffer0_val is high, then req_cntr cant be 0 ")
      uzovl_cxtmc_unformatter_f0_only_set
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   (frame_buffer0_val & (req_cntr == 0))
        );

  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxtmc_unformatter - when frame_buffer1_val is high, then req_cntr cant be 0 ")
      uzovl_cxtmc_unformatter_f1_only_set
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   (frame_buffer1_val & (req_cntr == 0))
        );

  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxtmc_unformatter - when input_buffer0_val is high, then req_cntr cant be 0 ")
      uzovl_cxtmc_unformatter_i0_only_set
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   (input_buffer0_val & (req_cntr == 0))
        );

end
endgenerate

  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxtmc_unformatter - When request is raised for APB, no flow control from memory, as accesses from APB are sequential")
      uzovl_cxtmc_unformatter_req_valid_apb
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   (rb_req_valid_apb & ~rb_req_ready)
        );

  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxtmc_unformatter - atbm_flush_ready wont get asserted when AFVALIDM is 0")
      uzovl_cxtmc_unformatter_atbm_flush_ready
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   (atbm_flush_ready & ~AFVALIDM)
        );


`endif

endmodule
