//-----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2004-2015 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//    Checked In : $Date: 2014-06-25 08:42:22 +0100 (Wed, 25 Jun 2014) $
//    Revision   : $Revision: 39629 $
//    Release    : CoreSight-SoC-TM100-r3p2-00rel0
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// Abstract : CoreSight Trace Port Interface Unit (cxtpiu) &
//            CoreSight Embedded Trace Buffer (CSETB)      - ATB Formatter
//-----------------------------------------------------------------------------
//
// NOTE: The CoreSight ATB Formatter supports both TPIU and ETB formatting of
//       ATB trace data.
//
//
// cxtpiu - CoreSight Trace Port Interface Unit
// --------------------------------------------
//
// CoreSight AMBA Trace Bus (ATB) sink device used to drain trace data and acts
// as a bridge between the on-chip trace data and the data stream captured by a
// Trace Port Analyser(TPA).
//
// CSETB  - CoreSight Embedded Trace Buffer
// ----------------------------------------
//
// CoreSight AMBA Trace Bus (ATB) sink device to store trace data in dedicated
// on chip 32-bit Trace RAM.
//
// cxtpiu_formatter.v
// -------------
//
// cxtpiu_formatter.v provides the formatting mechanism to optionally embed trace
// source IDs into the trace data stream.The formatter outputs 32-bit data
// words.
//
// Instantiated blocks
// -------------------
// None
//-----------------------------------------------------------------------------

module cxtpiu_formatter  (
  // Inputs
  atclk, atclken, atresetn, atvalids, atbytess, atids, atdatas, ft_enable,
  ft_data_rdy, ft_trig_req, ft_stop_req, itc_r_reg, it_atb_ctr_2_atr_reg,
  // Outputs
  atreadys, ft_data_valid, ft_last_word, ft_trig_ack, ft_stopped, ft_data,
  it_ctr_0_atv_reg, it_ctr_0_byt_reg, it_atb_dat_0_reg, it_atb_ctr_1_reg
  );

  //---------------------------------------------------------------------------
  // Inputs
  //---------------------------------------------------------------------------
  input         atclk;                // ATB clock
  input         atclken;              // ATB clock enable
  input         atresetn;             // ATB sychronous reset

  input         atvalids;             // ATB valid signal
  input [1:0]   atbytess;             // ATB valid number of bytes (LSB aligned)
  input [6:0]   atids;                // ATB source ID
  input [31:0]  atdatas;              // ATB trace data

  input         ft_enable;            // Formatting enable
  input         ft_data_rdy;          // Formatter output interface ready
  input         ft_trig_req;          // Formatter trigger request
  input         ft_stop_req;          // Formatter stop request

  input         itc_r_reg;            // Integration mode control register
  input         it_atb_ctr_2_atr_reg; // Integration ItAtbCtr2 atreadys

  //---------------------------------------------------------------------------
  // Outputs
  //---------------------------------------------------------------------------
  output        atreadys;             // ATB ready

  output        ft_data_valid;        // Formatter output data valid
  output        ft_last_word;         // Formatter's last word in a frame
  output        ft_trig_ack;          // Return response to ft_trig_req
  output        ft_stopped;           // Return response to ft_stop_req
  output [31:0] ft_data;              // Formatter output data

  output        it_ctr_0_atv_reg;     // Integration ItAtbCtr0 atvalids register
  output [1:0]  it_ctr_0_byt_reg;     // Integration ItAtbCtr0 atbytess register
  output [4:0]  it_atb_dat_0_reg;     // Integration ItAtbData0 register
  output [6:0]  it_atb_ctr_1_reg;     // Integration ItAtbCtr1 register

  //----------------------------------------------------------------------------
  // Wires
  //----------------------------------------------------------------------------
  wire          it_atb_en;
  wire          atid_en;

  wire [8:0]    next_fifo_reg_4;
  wire [8:0]    next_fifo_reg_5;

  wire          null_id;
  wire          trig_id;
  wire          trace_id;
  wire          null_id_en;
  wire          trig_id_en;
  wire          trace_id_en;
  wire          current_id;

  wire          equal_0;
  wire          le_eq_1;
  wire          le_eq_2;
  wire          le_eq_3;
  wire          le_eq_4;
  wire          le_eq_5;
  wire          le_eq_6;
  wire          le_eq_7;
  wire          le_eq_8;

  wire          wr_valid;
  wire          rd_size_0;
  wire          rd_size_3;
  wire          rd_size_4;
  wire          next_bypass_stop;
  wire          next_ft_trig_ack;
  wire [2:0]    write_size;
  wire [2:0]    next_rotation;
  wire [6:0]    next_at_id;

  wire          fifo_reg_4_en;
  wire          fifo_reg_5_en;
  wire          fifo_reg_6_en;
  wire          fifo_reg_7_en;
  wire          fifo_reg_8_en;
  wire          fifo_not_full;
  wire [3:0]    fifo_calc_1;
  wire [3:0]    fifo_calc_2;

  wire [44:0]   rotate_1;
  wire [62:0]   rotate_2;
  wire [35:0]   rotate_4;
  wire [70:0]   rotator_out;

  wire          nxt_embed_id;
  wire          atreadys;
  wire          atreadys_int;
  wire [2:0]    next_read_size;
  wire          ctr_sel;
  wire          nr_1;
  wire          nr_2;

  //----------------------------------------------------------------------------
  // Registers
  //----------------------------------------------------------------------------
  reg [3:0]     id_ctr;

  wire          ft_stopped;
  reg           ft_stopped_int;
  wire          ft_data_valid;
  reg           ft_data_valid_int;
  reg           ft_last_word_int;
  wire          ft_last_word;
  wire          ft_trig_ack;
  reg           ft_trig_ack_int;
  wire [31:0]   ft_data;
  reg [31:0]    ft_data_int;

  reg           new_id;
  reg [2:0]     atbytes;
  reg [6:0]     atid;
  reg [31:0]    atdata;
  reg [31:0]    ft_data_reg;

  reg           ft_stop;
  reg           ft_stop_1;
  reg           bypass_stop;
  reg [1:0]     ctr;
  reg [1:0]     next_ctr;
  reg [2:0]     rotation;
  reg [3:0]     fifo_size;
  reg [3:0]     word_count;
  reg [5:0]     lbs;

  reg [8:0]     next_fifo_reg_1;
  reg [8:0]     next_fifo_reg_2;
  reg [8:0]     next_fifo_reg_3;

  reg [8:0]     fifo_reg_1;
  reg [8:0]     fifo_reg_2;
  reg [8:0]     fifo_reg_3;
  reg [8:0]     fifo_reg_4;
  reg [8:0]     fifo_reg_5;
  reg [8:0]     fifo_reg_6;
  reg [8:0]     fifo_reg_7;
  reg [7:0]     fifo_reg_8;

  reg           next_ft_stop;
  reg [2:0]     next_at_bytes;
  reg [3:0]     next_word_count;
  reg [3:0]     next_fifo_size;
  reg [5:0]     next_lbs;
  reg [31:0]    next_at_data;

  reg           it_ctr_0_atv_reg;
  reg [1:0]     it_ctr_0_byt_reg;
  reg [4:0]     it_atb_dat_0_reg;
  reg [6:0]     it_atb_ctr_1_reg;

  reg           ft_stop_reg;
  reg           new_id_reg;
  reg           fifo_not_full_reg;
  reg           ft_last_word_reg;
  reg [3:0]     id_ctr_reg;
  reg           embed_id;

  //----------------------------------------------------------------------------
  //
  // Main body of code
  // =================
  //
  //----------------------------------------------------------------------------

  //----------------------------------------------------------------------------
  // Logic for embed_id signal.This indicates that the current trace ID has to
  // be embedded as part of the formatted data stream.The trace ID is embedded
  // when the trace ID changes on the bus or the trace ID has not changed since
  // last eight frames.
  //----------------------------------------------------------------------------
  assign nxt_embed_id = (~(atid == next_at_id) & ft_enable) |
                        (id_ctr[3] & atvalids & fifo_not_full);

  always @(posedge atclk or negedge atresetn)
    begin : p_embedid
     if (!atresetn)
        embed_id <= 1'b0;
      else if (atclken)
        embed_id <= nxt_embed_id;
    end

  //----------------------------------------------------------------------------
  // Combinational logic for generating new_id signal.new_id indicates
  // to the formatter whether the current trace ID is same as the old trace ID
  // stored.If new_id is set,the formatter shall embed the trace ID into
  // the formatted data stream.When the internal FIFO is full the value of the
  // new_id is retained.This is for the formatter to embed the trace ID when
  // the internal FIFO has sufficient buffer space.For all other conditions,the
  // new_id is zero.
  //----------------------------------------------------------------------------
  always @(posedge atclk or negedge atresetn)
    begin : p_ftnewfull
      if (!atresetn)
        begin
          fifo_not_full_reg <= 1'b0;
          new_id_reg <= 1'b0;
        end
      else if (atclken)
        begin
          fifo_not_full_reg <= fifo_not_full;
          new_id_reg <= new_id;
        end
    end // block: p_ftreg

  // ft_stop_reg may stop new_id being set even though embed_id is set. We need a
  // special case for the end of a stop where for one cycle ft_stop is unset
  // and ft_stop_reg is set.
  always @(atbytes or embed_id or fifo_not_full_reg or ft_stop_reg
           or new_id_reg or ft_stop)
    begin : p_newid
      if (ft_stop_reg && ~ft_stop && embed_id)
        new_id = 1'b1;
      else
        new_id = ~(ft_stop_reg || (atbytes == 3'b000)) &
                   ((~fifo_not_full_reg & new_id_reg) |
                    ( fifo_not_full_reg & embed_id));
    end

  //----------------------------------------------------------------------------
  // Combinational block for the next_at_id bus.The next_at_id is assigned with a
  // NULL ID if the formatter is requested to stop.If the formatter gets a
  // trigger request,the next_at_id is assigned with the TRIGGER ID which is
  // 7'h7D.If there is valid data on the ATB bus and the atreadys is driven
  // high,the next_at_id is assigned the ID from the ATID bus.
  //----------------------------------------------------------------------------
  assign null_id     = ft_stop_req   &  ft_data_rdy;
  assign trig_id     = ft_trig_req   & ~ft_trig_ack_int;
  assign trace_id    = atvalids    &  atreadys_int;
  assign null_id_en  = fifo_not_full &  null_id;
  assign trig_id_en  = fifo_not_full &  trig_id;
  assign trace_id_en = fifo_not_full & ~null_id & ~trig_id &  trace_id;
  assign current_id  = ~(null_id | trig_id | trace_id) | ~fifo_not_full;

  assign next_at_id  = (({7{trig_id}}    & 7'b1111101) |
                       ({7{trace_id_en}} & atids)      |
                       ({7{current_id}} & atid));

  assign atid_en = (null_id_en | trig_id_en | trace_id_en) & atclken;

  always @(posedge atclk or negedge atresetn)
    begin : p_atid
     if (!atresetn)
        atid <= {7{1'b0}};
      else if (atid_en)
        atid <= next_at_id;
    end

  //----------------------------------------------------------------------------
  // Combinational block for the next_at_bytes bus.The next_at_bytes is assigned
  // with three if the formatter is requested to stop.The formatter will insert
  // four bytes of data bytes which are 8'h00 each.If the formatter gets a
  // trigger request,the next_at_bytes is assigned with zero as TRIGGER ID has
  // one byte of data which is 8'h00.If there is valid data on the ATB bus and
  // the ATREADY is driven high,the next_at_bytes is assigned the value from the
  // ATBYTES bus.
  //----------------------------------------------------------------------------
  always @(atbytess or atreadys_int or atvalids or atbytes
           or fifo_not_full or ft_data_rdy or ft_stop or ft_stop_req or ft_trig_req
           or next_ft_trig_ack)
    begin : p_nextatbytes
      if (!fifo_not_full)
        next_at_bytes = atbytes;
      else if ((ft_stop && ft_data_rdy) || (ft_stop_req && !ft_data_rdy))
        next_at_bytes = 3'b000;
      else if (ft_stop_req && ft_data_rdy)
        next_at_bytes = 3'b100;
      else
        next_at_bytes = ({3{ (ft_trig_req & next_ft_trig_ack)}}                                      & 3'b001) |
                      ({3{~(ft_trig_req & next_ft_trig_ack) &  (atvalids & atreadys_int)}}             & ({1'b0,atbytess} + 3'b001)) |
                      ({3{~(ft_trig_req & next_ft_trig_ack) & ~(atvalids & atreadys_int) & ~atreadys_int}} & atbytes);
    end

  //----------------------------------------------------------------------------
  // Combinational block for the next_at_data bus.The next_at_data is assigned
  // with 32'h0 if either the formatter is requested to stop or requested to
  // insert a trigger packet.The formatter shall insert four and one bytes
  // of data for the null and trigger packets respectively.If there is valid
  // on the ATB bus,then the formatter is assigned the data from the ATB bus.In
  // the bypass mode,the formatter shall embed 32'h0000_0001 word and then
  // embed a 32'h0000_0000 word before it stops.
  //----------------------------------------------------------------------------
  always @(atdatas or atreadys_int or atvalids or atdata
           or bypass_stop or fifo_not_full or ft_data_rdy or ft_enable
           or ft_stop_req or ft_trig_ack_int or ft_trig_req or word_count)
    begin : p_nextatdata
      if (!fifo_not_full || (ft_stop_req && !ft_data_rdy))
        next_at_data = atdata;
      else if (ft_stop_req && ft_enable)
        next_at_data = {32{1'b0}};
      else if (ft_stop_req && !ft_enable && !bypass_stop && (word_count == 0))
        next_at_data = 32'h0000_0001;
      else
        next_at_data = ({32{  (ft_trig_req && !ft_trig_ack_int)}}                                                      & {32{1'b0}}) |
                       ({32{(~(ft_trig_req && !ft_trig_ack_int) &  (!ft_stop_req && atvalids && atreadys_int))}}             & atdatas) |
                       ({32{(~(ft_trig_req && !ft_trig_ack_int) & ~(!ft_stop_req && atvalids && atreadys_int) & ~atreadys_int)}} & atdata);
    end

  //----------------------------------------------------------------------------
  // Combinational logic for driving the atreadys.This signal is driven high if
  // the FtFtStopReq is received.This is for sources not to stall the data.If
  // a ft_trig_req is received and a ft_trig_ack is not returned,atreadys is driven
  // low.This is for the trace source to drive the same trace data as the
  // formatter shall embed a trigger packet.If the number of valid bytes to be
  // written exceed the amount of space present in the FIFO,atreadys is returned
  // low.For all the other conditions,atreadys is driven high.
  //----------------------------------------------------------------------------
  assign atreadys_int = (itc_r_reg & it_atb_ctr_2_atr_reg) |
                        (~itc_r_reg & ft_stop_req) |
                        ~(itc_r_reg | (ft_trig_req & ~ft_trig_ack_int) | ~fifo_not_full);
  assign atreadys = atreadys_int;

  //----------------------------------------------------------------------------
  // The id_ctr increments when a frame is output from the current trace ID.
  // If the current trace ID does not change for eight consecutive frames,the
  // current trace ID is embedded as part of the formatted data stream.
  //----------------------------------------------------------------------------
  always @(posedge atclk or negedge atresetn)
    begin : p_ftreg
      if (!atresetn)
        begin
          ft_stop_reg     <= 1'b0;
          ft_last_word_reg <= 1'b0;
          id_ctr_reg      <= 4'b0000;
        end
      else if (atclken)
        begin
          ft_stop_reg     <= ft_stop;
          ft_last_word_reg <= ft_last_word_int;
          id_ctr_reg      <= id_ctr;
        end
    end

  always @(embed_id or ft_last_word_reg or ft_stop_reg or id_ctr_reg)
    begin : p_idctr
      if(embed_id || ft_stop_reg)
        id_ctr = 4'b0000;
      else if(ft_last_word_reg)
        id_ctr = id_ctr_reg + 4'b0001;
      else
        id_ctr = id_ctr_reg;
    end

  //----------------------------------------------------------------------------
  // Sequential block for latching atbytes and atdata signals.
  //----------------------------------------------------------------------------
  always @(posedge atclk or negedge atresetn)
    begin : p_atbus
      if (!atresetn)
        begin
          atbytes <= {3{1'b0}};
          atdata  <= {32{1'b0}};
        end
      else if (atclken)
         begin
           atbytes <= next_at_bytes;
           atdata  <= next_at_data;
         end
    end

  //----------------------------------------------------------------------------
  // Logic for next_bypass_stop signal.This signal indicates the formatter to
  // embed 32'h0000_0001 word after a stop request is received in the bypass
  // mode.Once a stop request is received and if this signal is not set,the
  // formatter shall embed 32'h0000_0001 as the first word.After this signal
  // is set,the formatter shall embed 32'h0000_0000 into the formatted data
  // stream.
  //----------------------------------------------------------------------------
  assign next_bypass_stop = ~ft_stop & ft_stop_req & ft_data_rdy & ~ft_enable;

  //----------------------------------------------------------------------------
  // Combinational logic for driving the ft_trig_ack.This is the return response
  // for the ft_trig_req signal.This is driven high when the two bytes of the
  // trigger packet fit into the remaining space of the FIFO.Else for all the
  // other conditions it is driven low.
  //----------------------------------------------------------------------------
  assign next_ft_trig_ack = ft_trig_req & ~ft_trig_ack_int & fifo_not_full;

  //----------------------------------------------------------------------------
  // Logic for next_rotation.The value specified by next_rotation shall indicate
  // the rotator logic to shift left by that much amount.When the formatter
  // drives atreadys low,the rotator should not shift any data as there is
  // no space in the FIFO.The rotation is also done when ft_trig_req is set
  // irrespective of atreadys because before the trigger request,there might
  // be valid data from the trace bus that needs to be pushed into the FIFO.
  // ---------------------------------------------------------------------------
  assign next_rotation[2:0] = (atreadys_int | ft_trig_req) ?
                             (fifo_size[2:0] + ({2'b00,new_id}) - next_read_size) :
                             rotation;

  //----------------------------------------------------------------------------
  // Combinational logic for calculating next_fifo_size.This will indicate the
  // number of bytes valid in the eight byte FIFO.If the next_fifo_size exceeds
  // the number of bytes present in the FIFO,the write data is not writtten
  // into the FIFO.The next_fifo_size is zero when the formatter stops.
  //----------------------------------------------------------------------------
  always @(fifo_not_full or fifo_size or ft_stop or next_read_size
           or wr_valid or write_size)
    begin : p_nextfifosize
      if (ft_stop)
        next_fifo_size = {4{1'b0}};
      else if (!fifo_not_full)
        next_fifo_size = fifo_size - {1'b0,next_read_size};
      else if (wr_valid)
        next_fifo_size = fifo_size + {1'b0,write_size} - {1'b0,next_read_size};
      else
        next_fifo_size = fifo_size - {1'b0,next_read_size};
    end

  //----------------------------------------------------------------------------
  // Sequential block for latching ft_trig_ack,bypass_stop,rotation and fifo_size.
  //----------------------------------------------------------------------------
  always @(posedge atclk or negedge atresetn)
    begin
      if (!atresetn)
        begin
          ft_trig_ack_int  <= 1'b0;
          bypass_stop      <= 1'b0;
          rotation         <= {3{1'b0}};
          fifo_size        <= {4{1'b0}};
        end
      else if (atclken)
        begin
          ft_trig_ack_int  <= next_ft_trig_ack;
          bypass_stop      <= next_bypass_stop;
          rotation         <= next_rotation;
          fifo_size        <= next_fifo_size;
        end
    end
  assign ft_trig_ack = ft_trig_ack_int;

  //----------------------------------------------------------------------------
  // Logic for calculating fifo_not_full.The formatter input interface shall write
  // data into the internal FIFO and the formatter output interface shall read
  // the data from the internal FIFO.If the internal FIFO of the formatter has
  // sufficient space to accomadate the write data from the input interface,the
  // formatter asserts fifo_not_full.If the fifo_not_full is de-asserted,then the
  // input interface shall be stalled by de-asserting the atreadys.The fifo_calc_2
  // indicates the number of bytes valid on the input interface and fifo_calc_1
  // indicates the number of bytes valid in the intenal FIFO.FifoFull is not
  // generated as ~fifo_calc_1[3] but instead generated as the way below because
  // of better improvement in timing.
  //----------------------------------------------------------------------------
  assign fifo_calc_2   =  fifo_size  + {1'b0,atbytes};
  assign fifo_calc_1   =  fifo_calc_2 - {1'b0,next_read_size};
  assign fifo_not_full = (fifo_calc_1 <= 7);

  //----------------------------------------------------------------------------
  // Combinational block to calculate the write_size.This indicates the total
  // total number of bytes to be written into the FIFO.This is calculated by
  // considering atbytes and the new_id signals.The write_size is only calculated
  // if the FIFO has empty space to write that many number of bytes.wr_valid
  // indicates there is some valid data to be written on the input interface on
  // the formatter.
  //----------------------------------------------------------------------------
  assign write_size[2:0] = atbytes + {2'b00,new_id};
  assign wr_valid = (write_size != 0);

  //----------------------------------------------------------------------------
  // Rotator logic of the formatter for shifting atdata and atid into the FIFO.
  // The value by which the atdata and atid should be shifted is indicated by
  // the value from rotation.The trace ID is only shifted into the FIFO if the
  // ID is changed.
  //----------------------------------------------------------------------------
  assign rotate_1[44:0] =  next_rotation[0] ?
                          {      1'b0,atdata[31:24],1'b0,atdata[23:16],
                                 1'b0,atdata[15:8], 1'b0,atdata[7:0],
                                 1'b1,atid[6:0],    1'b0} :
                          { 9'b0,1'b0,atdata[31:24],1'b0,atdata[23:16],
                                 1'b0,atdata[15:8], 1'b0,atdata[7:0]};

  assign rotate_2[62:0] =  next_rotation[1] ?
                          {     rotate_1[44:0],1'b1,atid[6:0],1'b0,rotate_1[8:0]}:
                          {18'b0,rotate_1[44:0]};

  assign rotate_4[35:0] =  next_rotation[2] ?
                          {rotate_2[26:0],1'b1,atid[6:0],1'b0} :
                          {     rotate_2[62:27]};

  assign rotator_out    =  {rotate_2[34:27],rotate_4[35:0],
                           rotate_2[26:9], rotate_1[8:0]};

  //----------------------------------------------------------------------------
  // Comparators for different FIFO sizes.These comparators are used on the
  // input interface of the formatter to write data into the eight byte register
  //----------------------------------------------------------------------------
  assign equal_0 = (fifo_size == 4'b0000);
  assign le_eq_1  = (fifo_size <= 4'b0001);
  assign le_eq_2  = (fifo_size <= 4'b0010);
  assign le_eq_3  = (fifo_size <= 4'b0011);
  assign le_eq_4  = (fifo_size <= 4'b0100);
  assign le_eq_5  = (fifo_size <= 4'b0101);
  assign le_eq_6  = (fifo_size <= 4'b0110);
  assign le_eq_7  = (fifo_size <= 4'b0111);
  assign le_eq_8  = (fifo_size <= 4'b1000);

  //----------------------------------------------------------------------------
  // Comparators for different read sizes.These comparators are used on the
  // output interface of the formatter to read the data from the eight byte
  // register.
  //----------------------------------------------------------------------------
  assign rd_size_0 = (next_read_size == 3'b000);
  assign rd_size_3 = (next_read_size == 3'b011);
  assign rd_size_4 = (next_read_size == 3'b100);

  //----------------------------------------------------------------------------
  // Combinational block for the first register of the FIFO.
  //----------------------------------------------------------------------------
  always @(equal_0 or fifo_reg_1 or fifo_reg_4 or fifo_reg_5 or le_eq_3
           or le_eq_4 or rd_size_0 or rd_size_3 or rd_size_4 or rotator_out)
  begin : p_fiforeg1
    if ((equal_0 && rd_size_0) || (le_eq_3 && rd_size_3) || (le_eq_4 && rd_size_4))
      next_fifo_reg_1 = rotator_out[8:0];
    else if (!le_eq_3 && rd_size_3)
      next_fifo_reg_1 = fifo_reg_4;
    else if (!le_eq_4 && rd_size_4)
      next_fifo_reg_1 = fifo_reg_5;
    else
      next_fifo_reg_1 = fifo_reg_1;
  end

  //----------------------------------------------------------------------------
  // Combinational block for the second register of the FIFO.
  //----------------------------------------------------------------------------
  always @(fifo_reg_2 or fifo_reg_5 or fifo_reg_6 or le_eq_1 or le_eq_4
           or le_eq_5 or rd_size_0 or rd_size_3 or rd_size_4 or rotator_out)
  begin : p_fiforeg2
    if ((le_eq_1 && rd_size_0) || (le_eq_4 && rd_size_3) || (le_eq_5 && rd_size_4))
      next_fifo_reg_2 = rotator_out[17:9];
    else if (!le_eq_4 && rd_size_3)
      next_fifo_reg_2 = fifo_reg_5;
    else if (!le_eq_5 && rd_size_4)
      next_fifo_reg_2 = fifo_reg_6;
    else
      next_fifo_reg_2 = fifo_reg_2;
  end

  //----------------------------------------------------------------------------
  // Combinational block for the third register of the FIFO.
  //----------------------------------------------------------------------------
  always @(fifo_reg_3 or fifo_reg_6 or fifo_reg_7 or le_eq_2 or le_eq_5
           or le_eq_6 or rd_size_0 or rd_size_3 or rd_size_4 or rotator_out)
  begin : p_fiforeg3
    if ((le_eq_2 && rd_size_0) || (le_eq_5 && rd_size_3) || (le_eq_6 && rd_size_4))
      next_fifo_reg_3 = rotator_out[26:18];
    else if (!le_eq_5 && rd_size_3)
      next_fifo_reg_3 = fifo_reg_6;
    else if (!le_eq_6 && rd_size_4)
      next_fifo_reg_3 = fifo_reg_7;
    else
      next_fifo_reg_3 = fifo_reg_3;
  end

  //----------------------------------------------------------------------------
  // Combinational block for the fourth register of the FIFO.
  //----------------------------------------------------------------------------
  assign fifo_reg_4_en =  (( le_eq_3 & rd_size_0) |
                        ( le_eq_6 & rd_size_3) |
                        ( le_eq_7 & rd_size_4) |
                        (~le_eq_6 & rd_size_3) |
                        (~le_eq_7 & rd_size_4)) & atclken;

  assign next_fifo_reg_4 = ((le_eq_3 & rd_size_0) |
                         (le_eq_6 & rd_size_3) |
                         (le_eq_7 & rd_size_4))
                                        ? rotator_out[35:27] :
                                        (({9{ (~le_eq_6 & rd_size_3)}} & fifo_reg_7) |
                                         ({9{~(~le_eq_6 & rd_size_3)}} & {1'b0,fifo_reg_8}));

  always @(posedge atclk or negedge atresetn)
    begin
      if (!atresetn)
        fifo_reg_4 <= {9{1'b0}};
      else if (fifo_reg_4_en)
        fifo_reg_4 <= next_fifo_reg_4;
    end

  //----------------------------------------------------------------------------
  // Fifth register of the FIFO.
  //----------------------------------------------------------------------------
  assign fifo_reg_5_en = (( le_eq_4 & rd_size_0) |
                       ( le_eq_7 & rd_size_3) |
                       ( le_eq_8 & rd_size_4) |
                       (~le_eq_7 & rd_size_3)) & atclken;

  assign next_fifo_reg_5 = ((le_eq_4 & rd_size_0) |
                         (le_eq_7 & rd_size_3) |
                         (le_eq_8 & rd_size_4))
                                         ? rotator_out[44:36] : {1'b0,fifo_reg_8};

  always @(posedge atclk or negedge atresetn)
    begin
      if (!atresetn)
        fifo_reg_5 <= {9{1'b0}};
      else if (fifo_reg_5_en)
        fifo_reg_5 <= next_fifo_reg_5;
    end

  //----------------------------------------------------------------------------
  // Sixth register of the FIFO.
  //----------------------------------------------------------------------------
  assign fifo_reg_6_en = ((le_eq_5 & rd_size_0) | (le_eq_8 & (rd_size_3 | rd_size_4)))
                                                                     & atclken;

  always @(posedge atclk or negedge atresetn)
    begin
      if (!atresetn)
        fifo_reg_6 <= {9{1'b0}};
      else if (fifo_reg_6_en)
        fifo_reg_6 <= rotator_out[53:45];
    end

  //----------------------------------------------------------------------------
  // Seventh register of the FIFO.
  //----------------------------------------------------------------------------
  assign fifo_reg_7_en = ((le_eq_6 & rd_size_0) | (le_eq_8 & (rd_size_3 | rd_size_4)))
                                                                     & atclken;

  always @(posedge atclk or negedge atresetn)
    begin
      if (!atresetn)
        fifo_reg_7 <= {9{1'b0}};
      else if (fifo_reg_7_en)
        fifo_reg_7 <= rotator_out[62:54];
    end

  //----------------------------------------------------------------------------
  // Combinational block for the eighth register of the FIFO.
  //----------------------------------------------------------------------------
  assign fifo_reg_8_en = ((le_eq_7 & rd_size_0) | (le_eq_8 & (rd_size_3 | rd_size_4)))
                                                                     & atclken;

  always @(posedge atclk or negedge atresetn)
    begin
      if (!atresetn)
        fifo_reg_8 <= {8{1'b0}};
      else if (fifo_reg_8_en)
        fifo_reg_8 <= rotator_out[70:63];
    end

  //----------------------------------------------------------------------------
  // Sequential block for latching registers 1-3 of the FIFO.
  //----------------------------------------------------------------------------
  always @(posedge atclk or negedge atresetn)
    begin : s_fiforeg
      if (!atresetn)
        begin
          fifo_reg_1 <= {9{1'b0}};
          fifo_reg_2 <= {9{1'b0}};
          fifo_reg_3 <= {9{1'b0}};
        end
      else if(atclken)
        begin
          fifo_reg_1 <= next_fifo_reg_1;
          fifo_reg_2 <= next_fifo_reg_2;
          fifo_reg_3 <= next_fifo_reg_3;
        end
    end

  //----------------------------------------------------------------------------
  // Combinational block for calculating the next_read_size value.This indicates
  // the value in number of bytes that the output interface of the formatter is
  // reading from the internal FIFO.
  //----------------------------------------------------------------------------
  assign ctr_sel = (ctr == 2'b11);
  assign nr_1 = ft_data_rdy & !le_eq_3 & ~(ft_enable & ctr_sel);
  assign nr_2 = ft_data_rdy & ft_enable & !le_eq_2 & ctr_sel;
  assign next_read_size = ({3{nr_1}} & 3'b100) | ({3{nr_2}} & 3'b011);

  //----------------------------------------------------------------------------
  // Combinational block for calculating the next_word_count value.This value
  // is used for stopping the formatter after embedding null frames.
  //----------------------------------------------------------------------------
  always @(ft_data_rdy or ft_data_valid_int or ft_stop_req or ft_stopped_int
           or word_count)
    begin : p_wordcount
      if (ft_stopped_int)
        next_word_count = 4'b0000;
      else if (ft_stop_req && ft_data_rdy && ft_data_valid_int)
        next_word_count = word_count + 4'b0001;
      else
        next_word_count = word_count;
    end

  //----------------------------------------------------------------------------
  // Combinational block for calculating the ctr value.This value is used to
  // determine the next_read_size value when the formatting is enabled.When the
  // last word of a frame is read out,only three bytes are required as the last
  // byte in the last word of a frame is LBS.
  //----------------------------------------------------------------------------
  always @(ctr or ft_enable or ft_stopped_int or rd_size_3 or rd_size_4)
    begin : p_ctr
      if (ft_stopped_int)
        next_ctr = 2'b00;
      else if (((rd_size_3 || rd_size_4) && ft_enable))
        next_ctr = ctr + 2'b01;
      else
        next_ctr = ctr;
    end

  //----------------------------------------------------------------------------
  // Combinational block for calculating the NextFtStopped signal.
  //----------------------------------------------------------------------------
  always @(ctr or ft_enable or ft_stop or ft_stop_req or word_count)
    begin : c_ftstop
      if (!ft_stop_req)
        next_ft_stop = 1'b0;
      else if (ft_enable && (!(word_count <= 8) && (ctr == 0)))
        next_ft_stop = 1'b1;
      else if (!ft_enable && (word_count == 4))
        next_ft_stop = 1'b1;
      else
        next_ft_stop = ft_stop;
    end

  //----------------------------------------------------------------------------
  // Combinational block for calculating the ft_data_valid signal.
  //----------------------------------------------------------------------------
  always @(next_ft_stop or rd_size_3 or rd_size_4)
  begin : c_ftdatavalid
    if((rd_size_3 || rd_size_4) && !next_ft_stop)
      ft_data_valid_int = 1'b1;
    else
      ft_data_valid_int = 1'b0;
  end
  assign ft_data_valid = ft_data_valid_int;

  //----------------------------------------------------------------------------
  // Combinational block for calculating the ft_last_word signal.
  //----------------------------------------------------------------------------
  always @(rd_size_3)
  begin : c_ftlastword
    if(rd_size_3)
      ft_last_word_int = 1'b1;
    else
      ft_last_word_int = 1'b0;
  end
  assign ft_last_word = ft_last_word_int;

  //----------------------------------------------------------------------------
  // Sequential block for the latching the ft_data_valid.
  //----------------------------------------------------------------------------
  always @(posedge atclk or negedge atresetn)
  begin : s_ftstopped
    if (!atresetn)
      begin
        ft_stop        <= 1'b1;
        ft_stop_1      <= 1'b1;
        ft_stopped_int <= 1'b1;
        ctr            <= {2{1'b0}};
        word_count     <= {4{1'b0}};
      end
    else if(atclken)
      begin
        ft_stop_1      <= ft_stop;
        ft_stopped_int <= ft_stop_1;
        ft_stop        <= next_ft_stop;
        ctr            <= next_ctr;
        word_count     <= next_word_count;
      end
  end
  assign ft_stopped = ft_stopped_int;

  //----------------------------------------------------------------------------
  // 'F' and LBS calculation logic for the formatter.These are calculated only
  // if the formatting is enabled.The 'F' and 'LBS' bits are calculated for
  // every half word.The LBS is written as a part of the last word of the frame.
  // This logic takes either four or three bytes from the eight byte register
  // and then calculates the 'F' and 'LBS' on them.The word is then driven
  // to the output interface of the formatter.
  //----------------------------------------------------------------------------

  //----------------------------------------------------------------------------
  // Combinational block for calculating the NextFtData.This block generates
  // the formatted data in the bypass and normal modes.For bypass mode,always
  // four bytes are read from the eight byte register.For normal mode,only for
  // the last word of the frame three bytes are read from the eight byte
  // register,else for the other the three words of the frame,four bytes are
  // read from the eight byte register.
  //----------------------------------------------------------------------------
  always @(fifo_reg_1 or fifo_reg_2 or fifo_reg_3 or fifo_reg_4
           or ft_data_reg or ft_enable or lbs or rd_size_3 or rd_size_4)
  begin : c_ftdata
    ft_data_int = ft_data_reg;
    if (rd_size_4 && !ft_enable)
      ft_data_int = {fifo_reg_4[7:0],fifo_reg_3[7:0],fifo_reg_2[7:0],fifo_reg_1[7:0]};
    else if (rd_size_4 && ft_enable)
      case ({fifo_reg_4[8],fifo_reg_3[8],fifo_reg_2[8],fifo_reg_1[8]})
        4'b0000,
        4'b0001,
        4'b0100,
        4'b0101 :
          ft_data_int = {fifo_reg_4[7:0],fifo_reg_3[7:1],fifo_reg_3[8],
                    fifo_reg_2[7:0],fifo_reg_1[7:1],fifo_reg_1[8]};
        4'b0010 :
          ft_data_int = {fifo_reg_4[7:0],fifo_reg_3[7:1],fifo_reg_3[8],
                    fifo_reg_1[7:0],fifo_reg_2[7:1],fifo_reg_2[8]};
        4'b1000,
        4'b1001 :
          ft_data_int = {fifo_reg_3[7:0],fifo_reg_4[7:1],fifo_reg_4[8],
                    fifo_reg_2[7:0],fifo_reg_1[7:1],fifo_reg_1[8]};
        4'b1010 :
          ft_data_int = {fifo_reg_3[7:0],fifo_reg_4[7:1],fifo_reg_4[8],
                    fifo_reg_1[7:0],fifo_reg_2[7:1],fifo_reg_2[8]};
        default :
          ft_data_int = {fifo_reg_4[7:0],fifo_reg_3[7:0],fifo_reg_2[7:0],fifo_reg_1[7:0]};
      endcase
    else if (rd_size_3 && ft_enable)
      case ({fifo_reg_3[8],fifo_reg_2[8],fifo_reg_1[8]})
        3'b000,
        3'b001,
        3'b100,
        3'b101 :
          ft_data_int = {fifo_reg_3[0],fifo_reg_1[0],lbs[5:0],fifo_reg_3[7:1],
                    fifo_reg_3[8],fifo_reg_2[7:0],fifo_reg_1[7:1],fifo_reg_1[8]};
        3'b010 :
          ft_data_int = {fifo_reg_3[0],~fifo_reg_2[0],lbs[5:0],fifo_reg_3[7:1],
                    fifo_reg_3[8],fifo_reg_1[7:0],fifo_reg_2[7:1],fifo_reg_2[8]};
        default :
          ft_data_int = {2'b0,lbs[5:0],fifo_reg_3[7:0],fifo_reg_2[7:0],fifo_reg_1[7:0]};
      endcase
    else
      ft_data_int = ft_data_reg;
  end
  assign ft_data = ft_data_int;

  //----------------------------------------------------------------------------
  // Combinational block for calculating the LBS for the formatted frames during
  // the normal mode.The block stores the first six bits of LBS.The two most
  // significant bits of the LBS are appended on the fly in the block where the
  // ft_data is generated.
  //----------------------------------------------------------------------------
  always @(fifo_reg_1 or fifo_reg_2 or fifo_reg_3 or fifo_reg_4
           or ft_enable or lbs or rd_size_3 or rd_size_4)
  begin : c_nextlbs
    next_lbs = lbs;
    if (rd_size_4 && !ft_enable)
      next_lbs = {6{1'b0}};
    else if (rd_size_4 && ft_enable)
      case({fifo_reg_4[8],fifo_reg_3[8],fifo_reg_2[8],fifo_reg_1[8]})
        4'b0000,
        4'b0001,
        4'b0100,
        4'b0101 :
          next_lbs[5:0] = {fifo_reg_3[0],fifo_reg_1[0],lbs[5:2]};
        4'b0010 :
          next_lbs[5:0] = {fifo_reg_3[0],~fifo_reg_2[0],lbs[5:2]};
        4'b1000,
        4'b1001 :
          next_lbs[5:0] = {~fifo_reg_4[0],fifo_reg_1[0],lbs[5:2]};
        4'b1010 :
          next_lbs[5:0] = {~fifo_reg_4[0],~fifo_reg_2[0],lbs[5:2]};
        default :
          next_lbs = {6{1'b0}};
      endcase
    else if (rd_size_3 && ft_enable)
      next_lbs = {6{1'b0}};
    else
      next_lbs = lbs;
  end

  //----------------------------------------------------------------------------
  // Sequential block for latching the lbs and ft_data.
  //----------------------------------------------------------------------------
  always @(posedge atclk or negedge atresetn)
    begin : p_lbsftdata
      if (!atresetn)
        begin
          lbs         <= {6{1'b0}};
          ft_data_reg <= {32{1'b0}};
        end
        else if (atclken)
          begin
            lbs         <= next_lbs;
            ft_data_reg <= ft_data_int;
          end
    end

  //----------------------------------------------------------------------------
  // Logic fo the integration test mode registers.
  //----------------------------------------------------------------------------
  assign it_atb_en = atclken & itc_r_reg;

  always @(posedge atclk)
    begin : p_itatbctr1
      if (it_atb_en)
        begin
          it_atb_ctr_1_reg <= atids;
          it_atb_dat_0_reg <= {atdatas[31], atdatas[23], atdatas[15],
                                        atdatas[7],  atdatas[0]};
          it_ctr_0_byt_reg <= atbytess;
          it_ctr_0_atv_reg <= atvalids;
        end
    end

endmodule // cxtpiu_formatter
