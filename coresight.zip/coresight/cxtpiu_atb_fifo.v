//-----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2004-2015 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//    Checked In : $Date: 2014-08-14 16:01:35 +0100 (Thu, 14 Aug 2014) $
//    Revision   : $Revision: 39945 $
//    Release    : CoreSight-SoC-TM100-r3p2-00rel0
//-----------------------------------------------------------------------------
//  Purpose             : atclk domain side (input) FIFO for the TPIU Block.
//                      : Contains FIFO storage registers
//-----------------------------------------------------------------------------

module cxtpiu_atb_fifo (
  // Inputs
  atclk, atclken, atresetn, ft_data_valid, rd_ptr_gray_sync, write_data,
  // Outputs
  ft_data_rdy, wr_ptr_gray, fifo_data_0, fifo_data_1, fifo_data_2, fifo_data_3,
  fifo_data_4, fifo_data_5
  );

  // Inputs
  input         atclk;          // ATB clock
  input         atclken;        // ATB clock enable
  input         atresetn;    // ATB asychronous reset active low
  input         ft_data_valid;    // Data valid signal from the formatter
  input  [3:0]  rd_ptr_gray_sync;  // Read pointer from the synchronizer
  input  [32:0] write_data;      // Write data to the FIFO

  // Outputs
  output        ft_data_rdy;      // Ready to accept data from formatter
  output [3:0]  wr_ptr_gray;      // Write pointer to the read clock domain

  output [32:0] fifo_data_0;      // Output all the data registers for use
  output [32:0] fifo_data_1;      // in the traceclkin domain
  output [32:0] fifo_data_2;      // NB 6 banks are used, optimal for 2 clk
  output [32:0] fifo_data_3;      // delays synchronising between both domains
  output [32:0] fifo_data_4;      // and one clock delay for each domain to
  output [32:0] fifo_data_5;      // calculate the pointer value

  // ------------------------------------------------------------------------
  //
  //                            ATB clock domain side FIFO
  //                            ==========================
  //
  // ------------------------------------------------------------------------
  //
  //
  // Overview
  // ========
  // ATB clock domain interface for the FIFO block of the TPIU.
  //
  // ------------------------------------------------------------------------

  // Data FIFO
  wire          wr_ptr_en;     // Global data write
  wire          fifo_data_en_0; // Specific bank select
  wire          fifo_data_en_1;
  wire          fifo_data_en_2;
  wire          fifo_data_en_3;
  wire          fifo_data_en_4;
  wire          fifo_data_en_5;
  wire [32:0]    fifo_data_0;   // Data banks
  reg [32:0]    fifodata0_cdc_check;   // Data banks
  wire [32:0]    fifo_data_1;
  reg [32:0]    fifodata1_cdc_check;
  wire [32:0]    fifo_data_2;
  reg [32:0]    fifodata2_cdc_check;
  wire [32:0]    fifo_data_3;
  reg [32:0]    fifodata3_cdc_check;
  wire [32:0]    fifo_data_4;
  reg [32:0]    fifodata4_cdc_check;
  wire [32:0]    fifo_data_5;
  reg [32:0]    fifodata5_cdc_check;

  // Write Pointer logic
  reg [3:0]         next_wr_ptr_gray;
  wire [3:0]         wr_ptr_gray;    // Last filled location
  wire [3:0]         wr_ptr_gray_int;    // Internal version of wr_ptr_gray
  reg [3:0]         wrptrgray_cdc_check;    // Last filled location

  // Generation of the ft_data_rdy.
  wire                 ft_data_rdy;  // ~FIFOFULL

  wire                 ft_data_rdy_int; // Internal version of ft_data_rdy

  // ------------------------------------------------------------------------
  //
  // Main body of code
  // =================
  //
  // ------------------------------------------------------------------------

  // ------------------------------------------------------------------------
  // Data FIFO
  // ------------------------------------------------------------------------

  // Individual FIFO data enable signals.
  // (valid data present that is being accepted)
  assign   fifo_data_en_0 = ( atclken & ft_data_valid & ft_data_rdy_int &
                           ( (wr_ptr_gray_int[3:0] == 4'b0000) |
                             (wr_ptr_gray_int[3:0] == 4'b1111) )   );
  assign   fifo_data_en_1 = ( atclken & ft_data_valid & ft_data_rdy_int &
                           ( (wr_ptr_gray_int[3:0] == 4'b0001) |
                             (wr_ptr_gray_int[3:0] == 4'b1110) )   );
  assign   fifo_data_en_2 = ( atclken & ft_data_valid & ft_data_rdy_int &
                           ( (wr_ptr_gray_int[3:0] == 4'b0011) |
                             (wr_ptr_gray_int[3:0] == 4'b1010) )   );
  assign   fifo_data_en_3 = ( atclken & ft_data_valid & ft_data_rdy_int &
                           ( (wr_ptr_gray_int[3:0] == 4'b0010) |
                             (wr_ptr_gray_int[3:0] == 4'b1011) )   );
  assign   fifo_data_en_4 = ( atclken & ft_data_valid & ft_data_rdy_int &
                           ( (wr_ptr_gray_int[3:0] == 4'b0110) |
                             (wr_ptr_gray_int[3:0] == 4'b1001) )   );
  assign   fifo_data_en_5 = ( atclken & ft_data_valid & ft_data_rdy_int &
                           ( (wr_ptr_gray_int[3:0] == 4'b0111) |
                             (wr_ptr_gray_int[3:0] == 4'b1000) )   );

  always @(posedge atclk)
    begin : s_fifodata0
      if (fifo_data_en_0)
         fifodata0_cdc_check  <= write_data;
    end

  always @(posedge atclk)
    begin : s_fifodata1
      if (fifo_data_en_1)
         fifodata1_cdc_check  <= write_data;
    end

  always @(posedge atclk)
    begin : s_fifodata2
      if (fifo_data_en_2)
         fifodata2_cdc_check  <= write_data;
    end

  always @(posedge atclk)
    begin : s_fifodata3
      if (fifo_data_en_3)
         fifodata3_cdc_check  <= write_data;
    end

  always @(posedge atclk)
    begin : s_fifodata4
      if (fifo_data_en_4)
         fifodata4_cdc_check  <= write_data;
    end

  always @(posedge atclk)
    begin : s_fifodata5
      if (fifo_data_en_5)
         fifodata5_cdc_check  <= write_data;
    end

  // ------------------------------------------------------------------------
  // Write Pointer logic
  // ------------------------------------------------------------------------

  always @(wr_ptr_gray_int)
    begin : c_wrptr_encode
      case (wr_ptr_gray_int)
        4'b0000 : next_wr_ptr_gray = 4'b0001;  // #0 going to #1
        4'b0001 : next_wr_ptr_gray = 4'b0011;  // #1 going to #2
        4'b0011 : next_wr_ptr_gray = 4'b0010;  // #2 going to #3
        4'b0010 : next_wr_ptr_gray = 4'b0110;  // #3 going to #4
        4'b0110 : next_wr_ptr_gray = 4'b0111;  // #4 going to #5
        4'b0111 : next_wr_ptr_gray = 4'b1111;  // #5 going to #0
        4'b1111 : next_wr_ptr_gray = 4'b1110;  // #0 going to #1
        4'b1110 : next_wr_ptr_gray = 4'b1010;  // #1 going to #2
        4'b1010 : next_wr_ptr_gray = 4'b1011;  // #2 going to #3
        4'b1011 : next_wr_ptr_gray = 4'b1001;  // #3 going to #4
        4'b1001 : next_wr_ptr_gray = 4'b1000;  // #4 going to #5
        4'b1000 : next_wr_ptr_gray = 4'b0000;  // #5 going to #0
        // unused
        4'b0100, 4'b0101,
        4'b1100, 4'b1101  :  next_wr_ptr_gray = 4'bxxxx;
        default : next_wr_ptr_gray = 4'bxxxx;
      endcase // case(wr_ptr_gray_int)
    end // always @ (wr_ptr_gray_int)

  assign wr_ptr_en = atclken & ft_data_valid & ft_data_rdy_int;

  always @(posedge atclk or negedge atresetn)
    begin : s_wrptrgray
      if (!atresetn)
         wrptrgray_cdc_check    <= {4{1'b0}};
      else
        if(wr_ptr_en)
           wrptrgray_cdc_check  <= next_wr_ptr_gray;
    end

  // ------------------------------------------------------------------------
  // Generation of the ft_data_rdy.
  // ------------------------------------------------------------------------
  // This indicates if there is space available in the FIFO.
  //
  // If they were binary encoded then the FIFO is full when the lower order
  // bits are the same (same Fifo entry) and the most significant bit is
  // different (Read and write have caught up)
  //
  // For Gray encoded, as the bits cannot be directly compared the lower
  // order bits need to be directly compared
  assign ft_data_rdy_int = ~( (wr_ptr_gray_int[3] != rd_ptr_gray_sync[3])   &
                        ( ((wr_ptr_gray_int[2:0]     == 3'b000) &
                           (rd_ptr_gray_sync[2:0] == 3'b111) ) |
                          ((wr_ptr_gray_int[2:0]     == 3'b001) &
                           (rd_ptr_gray_sync[2:0] == 3'b110) ) |
                          ((wr_ptr_gray_int[2:0]     == 3'b011) &
                           (rd_ptr_gray_sync[2:0] == 3'b010) ) |
                          ((wr_ptr_gray_int[2:0]     == 3'b010) &
                           (rd_ptr_gray_sync[2:0] == 3'b011) ) |
                          ((wr_ptr_gray_int[2:0]     == 3'b110) &
                           (rd_ptr_gray_sync[2:0] == 3'b001) ) |
                          ((wr_ptr_gray_int[2:0]     == 3'b111) &
                           (rd_ptr_gray_sync[2:0] == 3'b000) ) ) );
  assign ft_data_rdy = ft_data_rdy_int;

`ifdef ARM_CDC_ON
        cdc_connect #(32,0) u_cdc_fifodata0(
                .clk_launch(atclk),
                .clk_capture(cxtpiu.u_cxtpiu_trace_fifo.traceclkin),
                .d_in(fifodata0_cdc_check),
                .d_out_async(fifo_data_0)
                );
`else
        assign fifo_data_0 = fifodata0_cdc_check;
`endif
`ifdef ARM_CDC_ON
        cdc_connect #(32,0) u_cdc_fifodata1(
                .clk_launch(atclk),
                .clk_capture(cxtpiu.u_cxtpiu_trace_fifo.traceclkin),
                .d_in(fifodata1_cdc_check),
                .d_out_async(fifo_data_1)
                );
`else
        assign fifo_data_1 = fifodata1_cdc_check;
`endif
`ifdef ARM_CDC_ON
        cdc_connect #(32,0) u_cdc_fifodata2(
                .clk_launch(atclk),
                .clk_capture(cxtpiu.u_cxtpiu_trace_fifo.traceclkin),
                .d_in(fifodata2_cdc_check),
                .d_out_async(fifo_data_2)
                );
`else
        assign fifo_data_2 = fifodata2_cdc_check;
`endif
`ifdef ARM_CDC_ON
        cdc_connect #(32,0) u_cdc_fifodata3(
                .clk_launch(atclk),
                .clk_capture(cxtpiu.u_cxtpiu_trace_fifo.traceclkin),
                .d_in(fifodata3_cdc_check),
                .d_out_async(fifo_data_3)
                );
`else
        assign fifo_data_3 = fifodata3_cdc_check;
`endif
`ifdef ARM_CDC_ON
        cdc_connect #(32,0) u_cdc_fifodata4(
                .clk_launch(atclk),
                .clk_capture(cxtpiu.u_cxtpiu_trace_fifo.traceclkin),
                .d_in(fifodata4_cdc_check),
                .d_out_async(fifo_data_4)
                );
`else
        assign fifo_data_4 = fifodata4_cdc_check;
`endif
`ifdef ARM_CDC_ON
        cdc_connect #(32,0) u_cdc_fifodata5(
                .clk_launch(atclk),
                .clk_capture(cxtpiu.u_cxtpiu_trace_fifo.traceclkin),
                .d_in(fifodata5_cdc_check),
                .d_out_async(fifo_data_5)
                );
`else
        assign fifo_data_5 = fifodata5_cdc_check;
`endif
`ifdef ARM_CDC_ON
        cdc_connect #(3,0) u_cdc_wrptrgray(
                .clk_launch(atclk),
                .clk_capture(cxtpiu.u_cxtpiu_trace_sync.u_wr_ptr_gray_0.clk),
                .d_in(wrptrgray_cdc_check),
                .d_out_async(wr_ptr_gray_int)
                );
`else
        assign wr_ptr_gray_int = wrptrgray_cdc_check;
`endif
assign wr_ptr_gray = wr_ptr_gray_int;
endmodule // cxtpiu_atb_fifo
