//-----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2004-2015 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//    Checked In : $Date: 2015-03-13 15:57:52 +0000 (Fri, 13 Mar 2015) $
//    Revision   : $Revision: 42144 $
//    Release    : CoreSight-SoC-TM100-r3p2-00rel0
//-----------------------------------------------------------------------------
//  Purpose             : APB Slave Interface for the TPIU block.
//                        Parses requests from the Debug APB and synchronises
//                        requests to the different clock domains.
//
//-----------------------------------------------------------------------------

module cxtpiu_apb_if  (
  // Inputs
  pclkdbg, pclkendbg, presetdbgn, pwritedbg, penabledbg, pseldbg,
  rd_wr_ack_t_sync, paddrdbg, paddrdbg31, pwdatadbg,
  read_data_a, read_data_p, read_data_t,
  // Outputs
  rd_wr_req, rd_wr_req_t, preadydbg, prdatadbg,
  pwritedbg_reg, paddrdbg_reg, paddrdbg31_reg, pwdatadbg_reg
  );

`include "cxtpiu_constants.v"

  // Inputs
  input         pclkdbg;          // APB clock
  input         pclkendbg;        // APB clock enable
  input         presetdbgn;       // APB asychronous reset active low
  input         pwritedbg;        // APB write or read
  input         penabledbg;       // APB enable
  input         pseldbg;          // APB slave select
  input         rd_wr_ack_t_sync; // Return response for rd_wr_req_t
  input [11:2]  paddrdbg;         // APB address bus
  input         paddrdbg31;         // APB address bus
  input [31:0]  read_data_a;      // Read data bus from interface
  input [31:0]  read_data_p;      // Read data bus from interface
  input [31:0]  read_data_t;      // Read data bus from interface
  input [31:0]  pwdatadbg;        // APB write data

  // Outputs
  output        rd_wr_req;        // Read or write request to pclkdbg/atclk domain
  output        rd_wr_req_t;      // Read or write request to traceclkin domain
  output        preadydbg;        // APB ready
  output [31:0] prdatadbg;        // APB read data bus
  output        pwritedbg_reg;    // This access is a write transfer
  output [11:2] paddrdbg_reg;     // Programming address
  output        paddrdbg31_reg;   // Programming address
  output [31:0] pwdatadbg_reg;    // Write data bus


  // ---------------------------------------------------------------------------
  //                            APB Slave Interface
  //                            ===================
  // ---------------------------------------------------------------------------
  // Overview
  // ========
  // APB Slave Interface for the TPIU block which handles the req/ack system to
  // control registers and the APB equivalent control signals pseldbg/penabledbg
  // and preadydbg.
  // ---------------------------------------------------------------------------

  // ---------------------------------------------------------------------------
  // Internal signals
  // ---------------------------------------------------------------------------
  // Domain Selection
  wire          trace_clk_reg_en; // select for traceclkin addresses

  // Request Initiation
  wire          nxt_reg_r_w_req;
  wire          reg_r_w_req;
  wire          nxt_rd_wr_req_t;
  wire          rd_wr_req_t_en;    // enable for set and hold request to TraceClkIn
  reg           reg_r_w_req_1;
  reg           reg_r_w_req_2;
  wire          rd_wr_req_t;       // request to traceclkin
  wire          rd_wr_req_t_int;   // request to traceclkin - internal version
  reg           rdwrreqt_cdc_check;// request to traceclkin

  // Acknowledgement Response/preadydbg
  wire          r_w_ack;
  reg           preadydbg;

  // Read Data Register
  wire          reg_r_data_en;
  wire [31:0]   read_data;
  reg [31:0]    prdatadbg;

  // Registered APB signals
  reg           pwritedbg_reg;      // This access is a write transfer
  reg [11:2]    paddrdbg_reg;       // Programming address
  reg           paddrdbg31_reg;       // Programming address
  reg [31:0]    pwdatadbg_reg;      // Write data bus
  wire          reg_apb_en;

  // ---------------------------------------------------------------------------
  // Main body of code
  // =================
  // ---------------------------------------------------------------------------

  // ---------------------------------------------------------------------------
  // Domain Selection
  // ---------------------------------------------------------------------------
  // Need to identify any transfers that change clock domain to ensure the
  // interface is held for sufficiently long.
  // Assume everything else is within the pclkdbg/atclk domain
  assign trace_clk_reg_en = ( paddrdbg == CXTPIU_CURPORTSIZE_ADD |
                              paddrdbg == CXTPIU_CURTEST_ADD |
                              paddrdbg == CXTPIU_TESTREP_ADD  |
                              paddrdbg == CXTPIU_FORMSYNC_ADD );

  // ---------------------------------------------------------------------------
  // Request Initiation
  // ---------------------------------------------------------------------------
  // Generate transfer request when device is selected
  // Clear request when transfer is acknowledged
  // Only start as PSELDDBG is high and PENABLEDBGDBG 0 (first phase)
  assign nxt_reg_r_w_req  = pseldbg & ~penabledbg;
  assign reg_r_w_req      = pwritedbg_reg ? reg_r_w_req_2 : reg_r_w_req_1;

  // Request for traceclkin domain must not be started until the Ack is returned
  // Also need to keep high until the Ack is back
  assign nxt_rd_wr_req_t  = pseldbg & trace_clk_reg_en & ~rd_wr_ack_t_sync;
  assign rd_wr_req_t_en   = pclkendbg & ((nxt_rd_wr_req_t & ~rd_wr_req_t_int) |
                                     rd_wr_ack_t_sync               );

  // Register read/write requests
  always @ (posedge pclkdbg or negedge presetdbgn)
    begin : p_apbifseq_regrw
      if (!presetdbgn)
        begin
          reg_r_w_req_1 <= 1'b0;
          reg_r_w_req_2 <= 1'b0;
        end
      else if (pclkendbg)
        begin
          reg_r_w_req_1 <= nxt_reg_r_w_req;
          reg_r_w_req_2 <= reg_r_w_req_1;
        end
    end // p_apbifseq_regrw

  // Register the apb signals cleanly so they're stable for use elsewhere in the design
  assign reg_apb_en = pclkendbg & nxt_reg_r_w_req;

  always @ (posedge pclkdbg or negedge presetdbgn)
    begin : p_apb_data
      if (!presetdbgn)
        begin
           pwritedbg_reg     <= 1'b0;
           paddrdbg_reg      <= 12'b0;
           pwdatadbg_reg     <= 32'b0;
           paddrdbg31_reg    <= 1'b0;
        end
      else if (reg_apb_en)
        begin
           pwritedbg_reg     <= pwritedbg;
           paddrdbg_reg      <= paddrdbg;
           pwdatadbg_reg     <= pwdatadbg;
           paddrdbg31_reg    <= paddrdbg31;
        end
    end // p_apb_data

  // Hold read/write request to the traceclkin domain
  always @ (posedge pclkdbg or negedge presetdbgn)
    begin : p_apbifseq_regrwt
      if (!presetdbgn)
         rdwrreqt_cdc_check   <= 1'b0;
      else
        if (rd_wr_req_t_en)
           rdwrreqt_cdc_check   <= nxt_rd_wr_req_t;
    end

  assign rd_wr_req   = reg_r_w_req;

  // ---------------------------------------------------------------------------
  // Acknowledgement Response/preadydbg
  // ---------------------------------------------------------------------------
  // Select the traceclkin if the request was for that domain.
  assign r_w_ack = trace_clk_reg_en ? (rd_wr_ack_t_sync & rd_wr_req_t_int) : reg_r_w_req;

  // PREADYDBGDBG generation
  // This is normally a 2 cycle response,
  // except for RAM accesses when 1:1 clocking is used
  always @ (posedge pclkdbg or negedge presetdbgn)
    begin : p_apbifseq_preadydbg
      if (!presetdbgn)
        preadydbg <= 1'b1;
      else if (pclkendbg)
        preadydbg <= r_w_ack;
    end // p_apbifseq_preadydbg

  // ---------------------------------------------------------------------------
  // Read Data Register
  // ---------------------------------------------------------------------------
  // Register RegRData from the register bank, and output when an ack is
  // received that indicates the data is valid
  assign reg_r_data_en = r_w_ack & pclkendbg;

  // simply or the readmuxes together (all are OR-of-AND based), additionaly
  // mask the TraceCLk readmux with the request to ensure no latency in masking
  assign read_data = read_data_a | read_data_p | (read_data_t & {32{rd_wr_req_t_int}});

  // Data Read mux register
  always @ (posedge pclkdbg or negedge presetdbgn)
    begin : p_apbifseq_prdatadbg
      if (!presetdbgn)
        prdatadbg <= {32{1'b0}};
      else if (reg_r_data_en)
        prdatadbg <= read_data;
    end // p_apbifseq_prdatadbg


`ifdef ARM_CDC_ON
         cdc_connect u_cdc_rdwrreqt(
                .clk_launch(pclkdbg),
                .clk_capture(cxtpiu.u_cxtpiu_trace_sync.u_rd_wr_req_t.clk),
                .d_in(rdwrreqt_cdc_check),
                .d_out_async(rd_wr_req_t_int)
                );
`else
                assign rd_wr_req_t_int = rdwrreqt_cdc_check;
`endif
assign rd_wr_req_t = rd_wr_req_t_int;
endmodule // cxtpiu_apb_if
