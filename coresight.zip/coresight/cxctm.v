//--========================================================================
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2003-2015 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//    Checked In : $Date: 2014-10-08 14:51:24 +0100 (Wed, 08 Oct 2014) $
//    Revision   : $Revision: 40194 $
//    Release    : CoreSight-SoC-TM100-r3p2-00rel0
//-----------------------------------------------------------------------------
// Purpose :
//           ECT Channel Interconnect Module
//
// --=========================================================================--
//-----------------------------------------------------------------------------

module cxctm
  (
  // Inputs
  ctmresetn, ctmclk, ctmclken, cisbypass1, cisbypass2, cisbypass3,
  cisbypass0, cihsbypass1, cihsbypass2, cihsbypass3, cihsbypass0,
  ctmchin1, ctmchin2, ctmchin3, ctmchin0, ctmchoutack1, ctmchoutack2,
  ctmchoutack3, ctmchoutack0,
  // Outputs
  ctmchout1, ctmchout2, ctmchout3, ctmchout0, ctmchinack1,
  ctmchinack2, ctmchinack3, ctmchinack0
  );

`include "cxctm_constants.v"

  //----------------------------------------------------------------------------
  // INPUTS
  //----------------------------------------------------------------------------
  input                        ctmresetn;    // Reset
  input                        ctmclk;       // Clock
  input                        ctmclken;     // Clock Enable

  input                        cisbypass1;   // Sync bypass for port 1
  input                        cisbypass2;   // Sync bypass for port 2
  input                        cisbypass3;   // Sync bypass for port 3
  input                        cisbypass0;   // Sync bypass for port 0

  input [ECTCHANNELWIDTH-1:0]  cihsbypass1;  // Handshaking bypass port 1
  input [ECTCHANNELWIDTH-1:0]  cihsbypass2;  // Handshaking bypass port 2
  input [ECTCHANNELWIDTH-1:0]  cihsbypass3;  // Handshaking bypass port 3
  input [ECTCHANNELWIDTH-1:0]  cihsbypass0;  // Handshaking bypass port 0

  input [ECTCHANNELWIDTH-1:0]  ctmchin1;     // Channel In port 1
  input [ECTCHANNELWIDTH-1:0]  ctmchin2;     // Channel In port 2
  input [ECTCHANNELWIDTH-1:0]  ctmchin3;     // Channel In port 3
  input [ECTCHANNELWIDTH-1:0]  ctmchin0;     // Channel In port 0

  input [ECTCHANNELWIDTH-1:0]  ctmchoutack1; // Channel Out ACK port 1
  input [ECTCHANNELWIDTH-1:0]  ctmchoutack2; // Channel Out ACK port 2
  input [ECTCHANNELWIDTH-1:0]  ctmchoutack3; // Channel Out ACK port 3
  input [ECTCHANNELWIDTH-1:0]  ctmchoutack0; // Channel Out ACK port 0


  //----------------------------------------------------------------------------
  // OUTPUTS
  //----------------------------------------------------------------------------
  output [ECTCHANNELWIDTH-1:0] ctmchout1;       // Channel OUT port 1
  output [ECTCHANNELWIDTH-1:0] ctmchout2;       // Channel OUT port 2
  output [ECTCHANNELWIDTH-1:0] ctmchout3;       // Channel OUT port 3
  output [ECTCHANNELWIDTH-1:0] ctmchout0;       // Channel OUT port 0

  output [ECTCHANNELWIDTH-1:0] ctmchinack1;     // Channel IN ACK port 1
  output [ECTCHANNELWIDTH-1:0] ctmchinack2;     // Channel IN ACK port 2
  output [ECTCHANNELWIDTH-1:0] ctmchinack3;     // Channel IN ACK port 3
  output [ECTCHANNELWIDTH-1:0] ctmchinack0;     // Channel IN ACK port 0

  //----------------------------------------------------------------------------
  // WIRES
  //----------------------------------------------------------------------------

  wire [ECTCHANNELWIDTH-1:0]         ctm_chin_1_sync_2;
  wire [ECTCHANNELWIDTH-1:0]         ctm_chin_2_sync_2;
  wire [ECTCHANNELWIDTH-1:0]         ctm_chin_3_sync_2;
  wire [ECTCHANNELWIDTH-1:0]         ctm_chin_0_sync_2;

  wire [ECTCHANNELWIDTH-1:0]         ctm_chout_ack_1_sync_2;
  wire [ECTCHANNELWIDTH-1:0]         ctm_chout_ack_2_sync_2;
  wire [ECTCHANNELWIDTH-1:0]         ctm_chout_ack_3_sync_2;
  wire [ECTCHANNELWIDTH-1:0]         ctm_chout_ack_0_sync_2;

  cxctm_sync_channel u_cxctm_sync_channel_0
    (// Outputs
     .ctm_chin_sync_2                    (ctm_chin_0_sync_2[ECTCHANNELWIDTH-1:0]),
     .ctm_chout_ack_sync_2               (ctm_chout_ack_0_sync_2[ECTCHANNELWIDTH-1:0]),
     // Inputs
     .ctmresetn                          (ctmresetn),
     .ctmclk                             (ctmclk),
     .ctmclken                           (ctmclken),
     .ctmchin                            (ctmchin0[ECTCHANNELWIDTH-1:0]),
     .ctmchoutack                        (ctmchoutack0[ECTCHANNELWIDTH-1:0]));

  cxctm_sync_channel u_cxctm_sync_channel_1
    (// Outputs
     .ctm_chin_sync_2                    (ctm_chin_1_sync_2[ECTCHANNELWIDTH-1:0]),
     .ctm_chout_ack_sync_2               (ctm_chout_ack_1_sync_2[ECTCHANNELWIDTH-1:0]),
     // Inputs
     .ctmresetn                          (ctmresetn),
     .ctmclk                             (ctmclk),
     .ctmclken                           (ctmclken),
     .ctmchin                            (ctmchin1[ECTCHANNELWIDTH-1:0]),
     .ctmchoutack                        (ctmchoutack1[ECTCHANNELWIDTH-1:0]));

  cxctm_sync_channel u_cxctm_sync_channel_2
    (// Outputs
     .ctm_chin_sync_2                    (ctm_chin_2_sync_2[ECTCHANNELWIDTH-1:0]),
     .ctm_chout_ack_sync_2               (ctm_chout_ack_2_sync_2[ECTCHANNELWIDTH-1:0]),
     // Inputs
     .ctmresetn                          (ctmresetn),
     .ctmclk                             (ctmclk),
     .ctmclken                           (ctmclken),
     .ctmchin                            (ctmchin2[ECTCHANNELWIDTH-1:0]),
     .ctmchoutack                        (ctmchoutack2[ECTCHANNELWIDTH-1:0]));

  cxctm_sync_channel u_cxctm_sync_channel_3
    (// Outputs
     .ctm_chin_sync_2                    (ctm_chin_3_sync_2[ECTCHANNELWIDTH-1:0]),
     .ctm_chout_ack_sync_2               (ctm_chout_ack_3_sync_2[ECTCHANNELWIDTH-1:0]),
     // Inputs
     .ctmresetn                          (ctmresetn),
     .ctmclk                             (ctmclk),
     .ctmclken                           (ctmclken),
     .ctmchin                            (ctmchin3[ECTCHANNELWIDTH-1:0]),
     .ctmchoutack                        (ctmchoutack3[ECTCHANNELWIDTH-1:0]));

  cxctm_bridge u_cxctm_bridge
    (/*AUTOINST*/
     // Outputs
     .ctmchout1                          (ctmchout1[ECTCHANNELWIDTH-1:0]),
     .ctmchout2                          (ctmchout2[ECTCHANNELWIDTH-1:0]),
     .ctmchout3                          (ctmchout3[ECTCHANNELWIDTH-1:0]),
     .ctmchout0                          (ctmchout0[ECTCHANNELWIDTH-1:0]),
     .ctmchinack1                        (ctmchinack1[ECTCHANNELWIDTH-1:0]),
     .ctmchinack2                        (ctmchinack2[ECTCHANNELWIDTH-1:0]),
     .ctmchinack3                        (ctmchinack3[ECTCHANNELWIDTH-1:0]),
     .ctmchinack0                        (ctmchinack0[ECTCHANNELWIDTH-1:0]),
     // Inputs
     .ctmresetn                          (ctmresetn),
     .ctmclk                             (ctmclk),
     .ctmclken                           (ctmclken),
     .cisbypass1                         (cisbypass1),
     .cisbypass2                         (cisbypass2),
     .cisbypass3                         (cisbypass3),
     .cisbypass0                         (cisbypass0),
     .cihsbypass1                        (cihsbypass1[ECTCHANNELWIDTH-1:0]),
     .cihsbypass2                        (cihsbypass2[ECTCHANNELWIDTH-1:0]),
     .cihsbypass3                        (cihsbypass3[ECTCHANNELWIDTH-1:0]),
     .cihsbypass0                        (cihsbypass0[ECTCHANNELWIDTH-1:0]),
     .ctmchin1                           (ctmchin1[ECTCHANNELWIDTH-1:0]),
     .ctmchin2                           (ctmchin2[ECTCHANNELWIDTH-1:0]),
     .ctmchin3                           (ctmchin3[ECTCHANNELWIDTH-1:0]),
     .ctmchin0                           (ctmchin0[ECTCHANNELWIDTH-1:0]),
     .ctmchoutack1                       (ctmchoutack1[ECTCHANNELWIDTH-1:0]),
     .ctmchoutack2                       (ctmchoutack2[ECTCHANNELWIDTH-1:0]),
     .ctmchoutack3                       (ctmchoutack3[ECTCHANNELWIDTH-1:0]),
     .ctmchoutack0                       (ctmchoutack0[ECTCHANNELWIDTH-1:0]),
     .ctm_chin_1_sync_2                  (ctm_chin_1_sync_2[ECTCHANNELWIDTH-1:0]),
     .ctm_chin_2_sync_2                  (ctm_chin_2_sync_2[ECTCHANNELWIDTH-1:0]),
     .ctm_chin_3_sync_2                  (ctm_chin_3_sync_2[ECTCHANNELWIDTH-1:0]),
     .ctm_chin_0_sync_2                  (ctm_chin_0_sync_2[ECTCHANNELWIDTH-1:0]),
     .ctm_chout_ack_1_sync_2             (ctm_chout_ack_1_sync_2[ECTCHANNELWIDTH-1:0]),
     .ctm_chout_ack_2_sync_2             (ctm_chout_ack_2_sync_2[ECTCHANNELWIDTH-1:0]),
     .ctm_chout_ack_3_sync_2             (ctm_chout_ack_3_sync_2[ECTCHANNELWIDTH-1:0]),
     .ctm_chout_ack_0_sync_2             (ctm_chout_ack_0_sync_2[ECTCHANNELWIDTH-1:0]));

endmodule // cxctm
