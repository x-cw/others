$GP3_RTL/coresight/rtl/top/coresight_wrapper.v
$GP3_RTL/coresight/rtl/top/dap_wrapper.v
$GP3_RTL/coresight/rtl/top/trace_wrapper.v
$GP3_RTL/coresight/rtl/top/debug_reg/debug_reg.v
$GP3_RTL/coresight/rtl/top/etr_usermge.v
$GP3_RTL/coresight/rtl/top/atb_slice_sync.v
$GP3_RTL/coresight/rtl/top/ts_gen_wrapper.v
$GP3_RTL/coresight/rtl/top/atb_formatter/pkt2atb.v
$GP3_RTL/coresight/rtl/top/atb_formatter/atb_formatter.v
$GP3_RTL/coresight/rtl/top/apb1to2.v
$GP3_RTL/top/rtl/ip_common_reg/ip_common_reg.v
$GP3_RTL/coresight/memory_wrapper/mem_sp_for_fpga.v
$GP3_RTL/coresight/memory_wrapper/ss5_coresight_sp_64x256_wrapper.v
-f $GP3_RTL/interleaver/rtl/dut.f
-f $GP3_RTL/common/common_ip.lst
-f $GP3_RTL/filelist_lib.lst
