// +FHDR----------------------------------------------------------------------------
// Project Name  : virtural_prj
// Author        : lidh
// Email         : lidh@innosilicon.com.cn
// Create On     : 2024/12/29 21:09
// Last Modified : 2024/12/29 21:09
// File Name     : ./top/etr_usermge.v
// Description   :
// 
// Copyright (c) 2024 Innosilicon.
// ALL RIGHTS RESERVED
// 
// ---------------------------------------------------------------------------------
// Modification History:
// Date         By              Version                 Change Description
// ---------------------------------------------------------------------------------
// 2024/12/29   lidh            1.0                     Original
// 
// -FHDR----------------------------------------------------------------------------
`timescale 1ns/1ps

module etr_usermge(
    input clk,
    input rstn,
    input etr_axi_awvalid,
    input etr_axi_awready,
    input etr_axi_bvalid,
    input etr_axi_bready,
    input [31:0] etr_id_ctrl,
    output reg [5:0] etr_axi_awid,
    output [5:0] etr_axi_arid,
    input  [5:0] etr_axi_bid,
    input  [5:0] etr_axi_rid
);

//----------------------
//  variable define
//----------------------
reg [5:0] next_etr_axi_awid;
//reg [5:0] etr_axi_awid;
reg [63:0] flag;
wire [63:0] inver_flag;
wire [63:0] flag_minus_1;
reg [63:0] only_1bit_1_flag;
reg [5:0] bit_loc;
reg aw_request;
wire b_response;
reg state;
reg next_state;

//----------------------
//  arid logic 
//----------------------

assign etr_axi_arid = 6'd0;

//----------------------
//  awid logic  
//----------------------

//aw request FSM
always @ (posedge clk or negedge rstn) begin
    if (!rstn) 
        state <=1'b0;
    else 
        state <= next_state;
end

always @ (*) begin
    case (state) 
        1'b0: begin 
            if (etr_axi_awvalid & etr_axi_awready)
                next_state = 1'b0;
            else if (etr_axi_awvalid)
                next_state = 1'b1;
            else 
                next_state = 1'b0;
        end
        1'b1 : begin 
            if (etr_axi_awready)
                next_state = 1'b0;
            else 
                next_state = 1'b1;
        end
        default: next_state = 1'b0;
    endcase
end


always @ (*) begin
    if (etr_axi_awvalid & etr_axi_awready & ~state) begin   //in idle, awvalid and awready, need output awid
        aw_request = 1'b1;
    end else if (~state & next_state)  begin  //in idle to wait, need output awid
        aw_request = 1'b1;
    end else 
        aw_request = 1'b0;   //other time, dont need update awid
end

//b response
assign b_response =  etr_axi_bvalid & etr_axi_bready;


//output awid
always @ (*) begin
    if (aw_request  & b_response) begin             //awid output and bid input
        etr_axi_awid = etr_axi_bid;
    end else if (aw_request ) begin                //only awid output 
        etr_axi_awid = bit_loc;
    end else begin
        etr_axi_awid = next_etr_axi_awid;
    end
end

always @ (posedge clk or negedge rstn) begin
    if (!rstn) begin
        next_etr_axi_awid <=6'd0;
    end else if (aw_request  & b_response) begin  
        next_etr_axi_awid <= etr_axi_bid;
    end else if (aw_request) begin                
        next_etr_axi_awid <= bit_loc;
    end
end



//find the lowest 0 in flag, which index can be awid
assign inver_flag = ~flag;  
assign flag_minus_1 = inver_flag - 64'h1;
integer j;
always @ (*) begin
    only_1bit_1_flag = 64'd0;
    for (j=0; j<64; j=j+1) begin
        only_1bit_1_flag[j] = inver_flag[j] & (~flag_minus_1[j]);
    end
end

integer i;
always @ (*) begin
    bit_loc = 0;
    for (i=0; i<64; i=i+1) begin
        if (only_1bit_1_flag[i] == 1) 
            bit_loc = i;
    end
end

// flag which means the id can be used
always @ (posedge clk or negedge rstn) begin
    if (!rstn) begin
        flag <=6'd0;
    end else if (aw_request & ~b_response) begin
        flag <= flag | only_1bit_1_flag;
    end else if (b_response & ~aw_request) begin
        flag[etr_axi_bid] <= 1'b0;
    end
end


endmodule
// Local Variables:
// verilog-library-directories:("./" ) 
// verilog-auto-inst-param-value:t
// End:
