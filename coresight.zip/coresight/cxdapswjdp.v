// ----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//        (C) COPYRIGHT 2004-2015 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//      Checked In          : $Date: 2014-01-15 13:06:56 +0000 (Wed, 15 Jan 2014) $
//      Revision            : $Revision: 38665 $
//      Release             : CoreSight-SoC-TM100-r3p2-00rel0
//
// ----------------------------------------------------------------------------
//  Purpose : DAP SW/jtag-DP top level.
// The SWJ-DP is used to connect an external (serial) interface to the internal
// debug access bus. As a transfer across an asynchronous boundary is
// inefficient, the serial interfaces reside in separate clock domains to the
// DAP APB interface.
//
// A multiplexor is used to control the inputs to the DAP side from either the
// jtag serial engine, or the SerialWire serial engine. The multiplexor selects
// jtag by default from reset, but will switch to Serial Wire once a specific
// 16-bit sequence is detected on tms
//
// Synchronisation blocks are used to double-register the control signals.
// ----------------------------------------------------------------------------

module cxdapswjdp #(
   parameter IRLEN8 = 0
  )
  (// Outputs
  output wire         swdo,         // SW Data Out
  output wire         swdoen,       // SW Data Out Enable
  output wire         tdo,          // jtag TAP Data Out
  output wire         ntdoen,       // tdo enable
  output wire  [15:2] dapcaddr,     // DAP Address
  output wire         dapwrite,     // DAP Bus write
  output wire         dapenable,    // DAP Enable Transaction
  output wire         dapabort,     // DAP abort
  output wire         dapsel,       // DAP transaction select
  output wire  [31:0] dapwdata,     // DAP write Data
  output wire         cdbgpwrupreq, // Debug Power Domain up request
  output wire         csyspwrupreq, // System Power Domain up request
  output wire         cdbgrstreq,   // Debug reset request to reset controller
  output wire         jtagnsw,      // jtag/not Serial Wire Mode
  output wire         jtagtop,      // jtag-DP TAP controller in one of four top states
                                    // (TLR, rti, Sel-DR, Sel-IR)

  // Inputs
  input wire        ntrst,          // jtag TAP Reset
  input wire        npotrst,        // jtag/Serial Wire Power on reset
  input wire        swclktck,       // SW/jtag Clock
  input wire        swditms,        // SW Debug Data In / jtag Test Mode Select
  input wire        tdi,            // jtag TAP Data In / Alternative input function
  input wire        dapresetn,      // DAP Reset
  input wire        dapclk,         // DAP Clock
  input wire        dapclken,       // DAP Clock Enable
  input wire [31:0] daprdata,       // DAP read Data
  input wire        dapready,       // DAP Data bus Ready
  input wire        dapslverr,      // AP slave error response
  input wire        cdbgpwrupack,   // Debug Power Domain up acknowledge
  input wire        csyspwrupack,   // System Power Domain up acknowledge
  input wire        cdbgrstack,     // Debug reset acknowledge to reset controller
  input wire [31:0] targetid,       // Target ID for SW multidrop selection
  input wire  [3:0] instanceid      // Instance ID for SW multidrop selection
  );

// --------------------------------------------------------------------------
// Wire Declarations
// --------------------------------------------------------------------------
  wire [31:24]  dapaddr_31to24; // DAP address bits [31:24]
  wire [7:2]    dapaddr_7to2;   // DAP address bits [7:2]
  wire          jtagsel;        // jtag select
  wire          busreq;
  wire          busreq_c;
  wire          busack;
  wire          busack_c;
  wire          bus_write;
  wire          bus_write_c;
  wire          busabort;
  wire          busabort_c;
  wire  [31:24] busaddr_31to24;
  wire  [7:2]   busaddr_7to2;
  wire   [31:0] busrdata;
  wire   [31:0] busrdata_c;
  wire   [31:0] bus_wdata;
  wire   [31:0] bus_wdata_c;
  wire          buscmp;
  wire          buscmp_c;
  wire          buserr;
  wire          buserr_c;
  wire   [11:0] busendcnt;
  wire   [11:0] busendcnt_c;
  wire    [1:0] busmode;
  wire    [1:0] busmode_c;
  wire    [3:0] busmask;
  wire    [3:0] busmask_c;
  wire   [11:0] bus_trn_cnt;
  wire   [11:0] bus_trn_cnt_c;
  wire          swclktckn;

//-----------------------------------------------------------------------------
//
// Main body of code
// =================
//
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// SWCLKTCK clock domain
//-----------------------------------------------------------------------------
  cxdapswjdp_swclktck #(.IRLEN8(IRLEN8)) u_cxdapswjdp_swclktck
  (
    // Outputs
    .jtagsel                            (jtagsel),
    .swdo                               (swdo),
    .swdoen                             (swdoen),
    .tdo                                (tdo),
    .ntdoen                             (ntdoen),
    .jtagtop                            (jtagtop),
    .busreq                             (busreq),
    .bus_write                          (bus_write),
    .busaddr_31to24                     (busaddr_31to24),
    .busaddr_7to2                       (busaddr_7to2),
    .busabort                           (busabort),
    .bus_wdata                          (bus_wdata[31:0]),
    .busmode                            (busmode[1:0]),
    .busmask                            (busmask[3:0]),
    .bus_trn_cnt                        (bus_trn_cnt[11:0]),
    .cdbgpwrupreq                       (cdbgpwrupreq),
    .csyspwrupreq                       (csyspwrupreq),
    .cdbgrstreq                         (cdbgrstreq),

    // Inputs
    .ntrst                              (ntrst),
    .swclktck                           (swclktck),
    .swclktckn                          (swclktckn),
    .swditms                            (swditms),
    .npotrst                            (npotrst),
    .targetid                           (targetid[31:0]),
    .instanceid                         (instanceid[3:0]),
    .buscmp_c                           (buscmp_c),
    .buserr_c                           (buserr_c),
    .busendcnt_c                        (busendcnt_c[11:0]),
    .tdi                                (tdi),
    .busrdata_c                         (busrdata_c[31:0]),
    .busack_c                           (busack_c),
    .cdbgpwrupack                       (cdbgpwrupack),
    .csyspwrupack                       (csyspwrupack),
    .cdbgrstack                         (cdbgrstack)
  );

//-----------------------------------------------------------------------------
// dapclk clock domain
//-----------------------------------------------------------------------------
  cxdapswjdp_dapclk u_cxdapswjdp_dapclk
  (
    // Outputs
    .dapsel                             (dapsel),
    .dapenable                          (dapenable),
    .dapwrite                           (dapwrite),
    .dapabort                           (dapabort),
    .dapaddr_31to24                     (dapaddr_31to24),
    .dapaddr_7to2                       (dapaddr_7to2),
    .dapwdata                           (dapwdata[31:0]),
    .busack                             (busack),
    .busrdata                           (busrdata[31:0]),
    .buscmp                             (buscmp),
    .buserr                             (buserr),
    .busendcnt                          (busendcnt[11:0]),

    // Inputs
    .dapresetn                          (dapresetn),
    .dapclk                             (dapclk),
    .dapclken                           (dapclken),
    .daprdata                           (daprdata[31:0]),
    .dapready                           (dapready),
    .dapslverr                          (dapslverr),
    .bus_write_c                        (bus_write_c),
    .busaddr_31to24                     (busaddr_31to24),
    .busaddr_7to2                       (busaddr_7to2),
    .bus_wdata_c                        (bus_wdata_c[31:0]),
    .busmode_c                          (busmode_c[1:0]),
    .busmask_c                          (busmask_c[3:0]),
    .bus_trn_cnt_c                      (bus_trn_cnt_c[11:0]),
    .busreq_c                           (busreq_c),
    .busabort_c                         (busabort_c)
  );

//-----------------------------------------------------------------------------
// Generate compressed DAP address by dropping bits that are always 0.
//-----------------------------------------------------------------------------
  assign dapcaddr = {dapaddr_31to24, dapaddr_7to2};

//-----------------------------------------------------------------------------
// Clock inverter cell
//-----------------------------------------------------------------------------
  cxdapswjdp_clk_inverter u_cxdapswjdp_clk_inverter
  (
    .clk  (swclktck),
    .clkn (swclktckn)
  );


  assign jtagnsw       = jtagsel;
  assign busreq_c      = busreq;
  assign busack_c      = busack;
  assign bus_write_c   = bus_write;
  assign busabort_c    = busabort;
  assign busrdata_c    = busrdata;
  assign bus_wdata_c   = bus_wdata;
  assign buscmp_c      = buscmp;
  assign buserr_c      = buserr;
  assign busendcnt_c   = busendcnt;
  assign busmode_c     = busmode;
  assign busmask_c     = busmask;
  assign bus_trn_cnt_c = bus_trn_cnt;

endmodule
