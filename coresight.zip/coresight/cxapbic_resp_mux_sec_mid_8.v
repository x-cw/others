//-----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2012-2015 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//    Checked In : $Date: 2014-06-25 08:59:36 +0100 (Wed, 25 Jun 2014) $
//    Revision   : $Revision: 39630 $
//    Release    : CoreSight-SoC-TM100-r3p2-00rel0
//
//----------------------------------------------------------------------------
// Verilog-2001 (IEEE Std 1364-2001)
//----------------------------------------------------------------------------
// Purpose : cxapbic - Mux for responses from Master interfaces
//   This block implements muxes to select between responses from multiple
// Master interfaces. The selection is based on which Master interface
// is addressed by the current access. Read data from the internal ROM table
// is also routed through this block.
//   To help synthesis timing, the registered version of the pselm* signals
// (pselm*_reg) is used as the select inputs to the muxes.
//----------------------------------------------------------------------------
module cxapbic_resp_mux_sec_mid_8
  (
  // Select inputs for Response muxes
  input wire pselm0_reg,
  input wire pselm1_reg,
  input wire pselm2_reg,
  input wire pselm3_reg,
  input wire pselm4_reg,
  input wire pselm5_reg,
  input wire pselm6_reg,
  input wire pselm7_reg,
  input wire psel_rom_table_reg,

  // Responses from Master interfaces
  input wire preadym0,
  input wire pslverrm0,
  input wire [31:0] prdatam0,
    
  input wire preadym1,
  input wire pslverrm1,
  input wire [31:0] prdatam1,
    
  input wire preadym2,
  input wire pslverrm2,
  input wire [31:0] prdatam2,
    
  input wire preadym3,
  input wire pslverrm3,
  input wire [31:0] prdatam3,
    
  input wire preadym4,
  input wire pslverrm4,
  input wire [31:0] prdatam4,
    
  input wire preadym5,
  input wire pslverrm5,
  input wire [31:0] prdatam5,
    
  input wire preadym6,
  input wire pslverrm6,
  input wire [31:0] prdatam6,
    
  input wire preadym7,
  input wire pslverrm7,
  input wire [31:0] prdatam7,
    
  // Read data from ROM internal to the APB Interconnect
  input wire [31:0] rom_data,

  // Muxed responses
  output wire preadym,
  output wire pslverrm,
  output wire [31:0] prdatam
  );

//-----------------------------------------------------------------------------
//
//  Main body of code
//  =================
//
//-----------------------------------------------------------------------------
// Data mux
assign prdatam =
         ({32{psel_rom_table_reg}} & rom_data) | 
         ({32{pselm7_reg }} & prdatam7) | 
         ({32{pselm6_reg }} & prdatam6) | 
         ({32{pselm5_reg }} & prdatam5) | 
         ({32{pselm4_reg }} & prdatam4) | 
         ({32{pselm3_reg }} & prdatam3) | 
         ({32{pselm2_reg }} & prdatam2) | 
         ({32{pselm1_reg }} & prdatam1) | 
         ({32{pselm0_reg }} & prdatam0);

// pready mux
// No wait states for ROM access
assign preadym = psel_rom_table_reg |
         (pselm7_reg  & preadym7) | 
         (pselm6_reg  & preadym6) | 
         (pselm5_reg  & preadym5) | 
         (pselm4_reg  & preadym4) | 
         (pselm3_reg  & preadym3) | 
         (pselm2_reg  & preadym2) | 
         (pselm1_reg  & preadym1) | 
         (pselm0_reg  & preadym0);

// pslverrm mux
// No error returned on ROM access
assign pslverrm = 
         (pselm7_reg  & pslverrm7) | 
         (pselm6_reg  & pslverrm6) | 
         (pselm5_reg  & pslverrm5) | 
         (pselm4_reg  & pslverrm4) | 
         (pselm3_reg  & pslverrm3) | 
         (pselm2_reg  & pslverrm2) | 
         (pselm1_reg  & pslverrm1) | 
         (pselm0_reg  & pslverrm0);

endmodule // cxapbic_resp_mux_sec_mid_8

//-- END OF FILE --------------------------------------------------------------
