//-----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2009-2010 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//    Checked In :  2010-06-17 18:14:07 +0530 (Thu, 17 Jun 2010) 
//    Revision   :  8217 
//    Release    : TM961-BU-50000-r0p0-00rel0
//
//-----------------------------------------------------------------------------
// Purpose: CXTMC registers
//-----------------------------------------------------------------------------

module cxtmc_regfile
  //---------------------------------------------------------------------------
  // Configurability
  //---------------------------------------------------------------------------
  #(parameter CXTMC_ATBM_AXIM_CFG = 0,        // TMC configuration
    parameter CXTMC_MEM_SIZE = 31'h00000100,  // Trace memory size in 32-bit 
                                              //   words
    parameter CXTMC_WBUFFER_DEPTH = 1,        // Write Buffer Depth
    parameter CXTMC_WB_DATA_WIDTH = 64,       // Width of trace memory databus
                                              //  and write buffer databus
    parameter CXTMC_AXI_DATA_WIDTH = 64,      // AXI Databus width
    parameter CXTMC_MEM_BYTE_ADDR_WIDTH = 10, // Width of byte-address pointer
                                              //   for trace memory 
    parameter CXTMC_TRG_WIDTH = 8,            // Width of Trigger Counter
    parameter CXTMC_ATBYTES_WIDTH = 2,        // Width of ATBYTESS input
    parameter CXTMC_ITATBDATA0_WIDTH = 5,     // Width of it_atb_data_0 input
    parameter CXTMC_FILL_LEVEL_WIDTH = 9)     // Width of fill-level signals

  //---------------------------------------------------------------------------
  // Port Declarations
  //---------------------------------------------------------------------------
  (
  // Inputs
  input wire         cxtmc_clk,            
  // Gated clock

  input wire         RESETn,               
  // asynchronous reset

  input wire         apb_addr31,         
  // APB internal vs external access select, registered    

  input wire  [11:2] apb_addr,           
  // APB address, registered

  input wire  [31:0] apb_wdata,          
  // APB write data, registered

  input wire         pseldbg_r,
  // APB PSEL, registered

  input wire         pwritedbg_r,          
  // Registered version of PWRITEDBG

  input wire         apb_valid,            
  // APB request valid

  input wire         auth_status_dbgen,    
  // Invasive debug enable

  input wire         auth_status_spiden,   
  // Secure invasive debug enable

  //---------------------------------------------------------------------------
  // Event interfaces
  //---------------------------------------------------------------------------
  input wire                                  flushin_reg,
  // Registered version of FLUSHIN input to TMC - used in this module for 
  // integration register read

  input wire                                  trigin_reg,
  // Registered version of TRIGIN input to TMC - used in this module for 
  // integration register read

  input wire                                  FULL,
  // FULL output from TMC - used in this module for status register read

  output reg                                  ACQCOMP,
  // Acquisition Complete output

  //---------------------------------------------------------------------------
  // ATB Slave interface
  //---------------------------------------------------------------------------
  input wire                                  af_ready_reg,
  // Registered version of AFREADYS input to TMC - used in this module for 
  // integration register read

  input wire                                  atvalids_p1,
  // ATVALIDS input to TMC - used in this module for integration register read

  input wire [CXTMC_ATBYTES_WIDTH-1:0]        atbytess_p1,
  // ATBYTESS input to TMC - used in this module for integration register read

  input wire [6:0]                            atids_p1,
  // ATIDS input to TMC - used in this module for integration register read

  input wire                                  fl_in_prog,
  // Indication that flush is in progress

  //---------------------------------------------------------------------------
  // Inputs from sub-modules in TMC
  //---------------------------------------------------------------------------
  input wire                                  ft_stopped,
  // Formatter stopped

  input wire                                  flush_man_clr,
  // Pulse indicating completion of software-initiated flush

  input wire                                  trace_mem_empty,
  // Trace memory empty

  input wire                                  wb_empty,
  // Write Buffer empty

  input wire                                  wb_ready,
  // Acknowledgement for RWD writes - Asserted when the Write Buffer can accept
  // data

  input wire                                  unformatter_empty,
  // Unformatter pipeline empty

  input wire                                  triggered,
  // Trigger event detected

  input wire  [31:0]                          rrd,
  // RAM Read Data

  input wire                                  rrd_rd_ack,
  // Pulse indicating availability of data on rrd input

  input wire  [CXTMC_MEM_BYTE_ADDR_WIDTH-1:0] rrp,
  // RAM Read Pointer

  input wire  [CXTMC_MEM_BYTE_ADDR_WIDTH-1:0] rwp,
  // RAM Write Pointer

  input wire  [CXTMC_TRG_WIDTH-1:0]           trg,
  // Current value of Trigger counter

  input wire  [CXTMC_FILL_LEVEL_WIDTH-1:0]    lat_buf_level,
  // Max Fill level of trace memory since last read of LBUFLEVEL register

  input wire  [CXTMC_FILL_LEVEL_WIDTH-1:0]   c_buf_level,
  // Current fill level of trace memory (ETF config only)

  input wire                                 mem_err,
  // Memory error has occured (ETR config only)

  input wire                                  axi_intf_ready,
  // No outstanding AXI transfers

  input wire                                  sg_idle,
  // Scatter-Gather block inactive

  //---------------------------------------------------------------------------
  // Outputs to sub-modules in TMC
  //---------------------------------------------------------------------------
  // clock generation
  output wire        tmc_clk_req,          
  // clock request

  output wire [31:0] read_data,            
  // read data for APB i/f  

  output wire        apb_ready,            
  // Acknowledgement for completion of APB access

  output wire        apb_err,              
  // Error response to be returned on the APB

  output wire [30:0]                           rsz_masked,
  // RSZ register - contains trace memory size in ETR config
  // Masked for alignment with AXI data width

  output wire                                 trg_wr_en,
  // Write enable for TRG register

  output wire                                 rrp_wr_en,
  // Write enable for RRP register

  output wire                                 rrp_hi_wr_en,
  // Write enable for RRPHI register

  output wire                                 rwp_wr_en,
  // Write enable for RWP register

  output wire                                 rwp_hi_wr_en,
  // Write enable for RWPHI register

  output wire                                 rwd_wr_req,
  // Signal to indicate APB write to RWD - held till wb_ready is asserted
  // in ETB/ETF configurations; Pulse in ETR configuration.

  output wire                                 lat_buf_level_rd_done,
  // Read done for LBUFLEVEL register

  output wire                                 rrd_rd_req,
  // Pulse to indicate APB read from RRD register

  output wire                                 ptr_clr,
  // Pulse to clear trace memory pointers

  output wire                                 ctl_trace_capt_en_1_0,
  // Pulse to clear fill level registers

  output wire                                 apbreadfifo_clr,
  // Pulse to clear unread data in APB read FIFO

  output reg                                  ffcr_flush_man,
  // FFCR bit related to flush on manual request

  output wire                                 ffcr_stop_on_trig_evt_masked,
  // FFCR StopOnTrigEvt bit masked for error conditions

  output reg                                  ffcr_stop_on_fl,
  // FFCR StopOnFl bit 
  
  output wire                                 ffcr_trig_on_fl_masked,
  // FFCR TrigOnFl bit masked for error conditions
    
  output wire                                 ffcr_trig_on_trig_evt_masked,
  // FFCR TrigOnTrigEvt bit masked for error conditions

  output wire                                 ffcr_trig_on_trigin_masked,
  // FFCR TrigOnTrigIn bit masked for error conditions

  output wire                                 ffcr_flsh_on_trig_evt_masked,
  // FFCR FOnTrigEvt bit masked for error conditions

  output reg                                  ffcr_flsh_on_flshin,
  // FFCR FOnFlIn bit

  output reg                                  ffcr_en_trig_ins,
  // FFCR EnTI bit

  output wire                                 ffcr_en_formatting_masked,
  // FFCR EnFt bit masked for error conditions

  output wire                                 circ_buf_mode,
  // Set if TMC is programmed for Circular buffer mode

  output wire                                 sw_fifo_mode,
  // TMC programmed for Software FIFO mode

  output wire                                 hw_fifo_mode,
  // TMC programmed for HW-read-FIFO mode 

  output wire [3:0]                           axictl_wr_burst_len,
  // AXICTL register bits related to write burst length

  output wire                                 axictl_sg_mode,
  // AXICTL register bit related to mode of operation

  output wire [3:0]                           axictl_cache_ctrl,
  // AXICTL register bits related to cache control

  output wire [1:0]                           axictl_prot_ctrl,
  // AXICTL register bits related to write protection

  output wire [31:0]                          dba_lo,
  // AXI Data Buffer Low Address

  output wire [7:0]                           dba_hi,
  // AXI Data Buffer High Address

  output reg                                  ctl_trace_capt_en,
  // CTL register

  output wire                                 tmc_disabled,
  // TMC disabled

  output wire                                 tmc_abort,
  // TraceCaptEn cleared while TMC active in FIFO modes or with Drain in 
  // progress

  output reg  [4:0]                           pscr,
  // PSCR register

  output reg [CXTMC_FILL_LEVEL_WIDTH-2:0]     buf_wm,
  // Buffer water mark register

  output wire                                 unformatter_en,
  // Enable unformatter logic

  output wire                                 unformatter_stop,
  // Empty the internal pipelines in the unformatter

  output wire                                 mem_err_clr,
  // Pulse to clear mem_err in AXI interface

  output reg                                  tmc_ready,
  // Status register bit

  output reg                                  it_ctrl,
  // Integration Mode Control

  output wire                                 it_atb_m_data_0_wr_en,
  // Write enable for ITATBMDATA0 register

  output wire                                 it_atb_m_ctr_1_wr_en,
  // Write enable for ITATBMCTR1 register

  output wire                                 it_atb_m_ctr_0_wr_en,
  // Write enable for ITATBMCTR0 register

  output wire                                 it_misc_op_0_wr_en,
  // Write enable for ITMISCOP0 register

  output wire                                 it_atb_ctr_2_wr_en,
  // Write enable for ITATBCTR2 register

  input  wire [CXTMC_ITATBDATA0_WIDTH-1:0]    it_atb_data_0,
  // Bits from ATDATAS for ITATBDATA0 register

  input  wire                                 it_atb_m_ctr_2_syncreqm,
  // SYNCREQM input to TMC 

  input  wire                                 it_atb_m_ctr_2_afvalidm,
  // AFVALIDM input to TMC 

  input  wire                                 it_atb_m_ctr_2_atreadym
  // ATREADYM input to TMC 
  );
  
  //---------------------------------------------------------------------------
  // Constant definitions
  //---------------------------------------------------------------------------
`include "cxtmc_constants.v"

//-----------------------------------------------------------------------------
// TMC Register addresses
//-----------------------------------------------------------------------------
  localparam CXTMC_RSZ            = 10'h001; // TMC RAM Size register, RSZ
  localparam CXTMC_STS            = 10'h003; // TMC Status register, STS
  localparam CXTMC_RRD            = 10'h004; // TMC RAM Read Data register, RRD
  localparam CXTMC_RRP            = 10'h005; // TMC RAM Read Pointer Register,
                                             //   RRP
  localparam CXTMC_RWP            = 10'h006; // TMC RAM Write Pointer Register,
                                             //   RWP
  localparam CXTMC_TRG            = 10'h007; // TMC Trigger Counter Register,
                                             //   TRG
  localparam CXTMC_CTL            = 10'h008; // TMC Control Register, CTL
  localparam CXTMC_RWD            = 10'h009; // TMC RAM Write Data Register, 
                                             //   RWD
  localparam CXTMC_MODE           = 10'h00A; // TMC MODE Register
  localparam CXTMC_LBUF_LEVEL     = 10'h00B; // TMC LBUFLEVEL Register
  localparam CXTMC_CBUF_LEVEL     = 10'h00C; // TMC CBUFLEVEL Register
                                             //   (ETF config only)
  localparam CXTMC_BUF_WM         = 10'h00D; // TMC BUFWM Register
  localparam CXTMC_RRP_HI         = 10'h00E; // TMC RRPHI Register
  localparam CXTMC_RWP_HI         = 10'h00F; // TMC RWPHI Register
  localparam CXTMC_AXI_CTL        = 10'h044; // TMC AXICTL Register
                                             //   (ETR config only)
  localparam CXTMC_DBA_LO         = 10'h046; // TMC DBALO Register
                                             //   (ETR config only)
  localparam CXTMC_DBA_HI         = 10'h047; // TMC DBAHI Register
                                             //   (ETR config only)
  localparam CXTMC_FFSR           = 10'h0C0; // TMC FFSR
  localparam CXTMC_FFCR           = 10'h0C1; // TMC FFCR
  localparam CXTMC_PSCR           = 10'h0C2; // TMC PSCR
  localparam CXTMC_IT_ATBM_DATA_0 = 10'h3B4; // Integration Register
  localparam CXTMC_IT_ATBM_CTR_2  = 10'h3B5; // Integration Register
  localparam CXTMC_IT_ATBM_CTR_1  = 10'h3B6; // Integration Register
  localparam CXTMC_IT_ATBM_CTR_0  = 10'h3B7; // Integration Register
  localparam CXTMC_IT_MISC_OP_0   = 10'h3B8; // Integration Register
  localparam CXTMC_IT_TR_FL_IN    = 10'h3BA; // Integration Register
  localparam CXTMC_IT_ATB_DATA_0  = 10'h3BB; // Integration Register
  localparam CXTMC_IT_ATB_CTR_2   = 10'h3BC; // Integration Register
  localparam CXTMC_IT_ATB_CTR_1   = 10'h3BD; // Integration Register
  localparam CXTMC_IT_ATB_CTR_0   = 10'h3BE; // Integration Register
  localparam CXTMC_IT_CTRL        = 10'h3C0; // Integration control register
  localparam CXTMC_CLAIMSET       = 10'h3E8; // Claim tag set register
  localparam CXTMC_CLAIMCLR       = 10'h3E9; // Claim tag clear register
  localparam CXTMC_LOCKACCESS     = 10'h3EC; // Lock access register
  localparam CXTMC_LOCKSTATUS     = 10'h3ED; // Lock status register
  localparam CXTMC_AUTHSTATUS     = 10'h3EE; // Authentication status register
  localparam CXTMC_DEVICEID       = 10'h3F2; // Device identification register
  localparam CXTMC_DEVICETYPE     = 10'h3F3; // Device type register
  localparam CXTMC_PERIPH_ID_4    = 10'h3F4; // Peripheral ID4 register
  localparam CXTMC_PERIPH_ID_5    = 10'h3F5; // Peripheral ID5 register
  localparam CXTMC_PERIPH_ID_6    = 10'h3F6; // Peripheral ID6 register
  localparam CXTMC_PERIPH_ID_7    = 10'h3F7; // Peripheral ID7 register
  localparam CXTMC_PERIPH_ID_0    = 10'h3F8; // Peripheral ID0 register
  localparam CXTMC_PERIPH_ID_1    = 10'h3F9; // Peripheral ID1 register
  localparam CXTMC_PERIPH_ID_2    = 10'h3FA; // Peripheral ID2 register
  localparam CXTMC_COMP_ID_0      = 10'h3FC; // Component ID0 register
  localparam CXTMC_COMP_ID_1      = 10'h3FD; // Component ID1 register
  localparam CXTMC_COMP_ID_2      = 10'h3FE; // Component ID2 register
  localparam CXTMC_COMP_ID_3      = 10'h3FF; // Component ID3 register

//-----------------------------------------------------------------------------
// TMC Register read values for read-only fields
//-----------------------------------------------------------------------------
  localparam CXTMC_CLAIMSET_VAL           = 4'hF;     // Claim Tag Size
  localparam CXTMC_LOCKSTATUS_8BIT_VAL    = 1'b0;     // Lock Access Not 8-bit
  localparam CXTMC_LOCKSTATUS_PRESENT_VAL = 1'b1;     // Lock Access Present
  localparam CXTMC_AUTHSTATUS_NSID_VAL    = 1'b0;     // - Non-Secure Invasive
  localparam CXTMC_AUTHSTATUS_NSNID_VAL   = 1'b0;     // - Non-Secure
                                                      //     Non-Invasive
  localparam CXTMC_AUTHSTATUS_SID_VAL     = 1'b0;     // - Secure Invasive
  localparam CXTMC_AUTHSTATUS_SNID_VAL    = 1'b0;     // - Secure Non-Invasive
  localparam CXTMC_DEVID_WBUF_DEPTH       =           // Write buffer depth 
             (CXTMC_WBUFFER_DEPTH == 1) ? 4'b0000 :   // 1 entry
             (CXTMC_WBUFFER_DEPTH == 2) ? 4'b0001 :   // 2 entries
             (CXTMC_WBUFFER_DEPTH == 4) ? 4'b0010 :   // 4 entries
             (CXTMC_WBUFFER_DEPTH == 8) ? 4'b0011 :   // 8 entries
             (CXTMC_WBUFFER_DEPTH == 16) ? 4'b0100 :  // 16 entries
                                           4'b0101;   // 32 entries
  localparam CXTMC_DEVID_MEMWIDTH         = 
             (CXTMC_WB_DATA_WIDTH == 32)  ? 3'b010 :  // 32-bit mem datawidth
                                                      //  (AXI datawidth in ETR
                                                      //   config)
             (CXTMC_WB_DATA_WIDTH == 64)  ? 3'b011 :  // 64-bit mem  datawidth
             (CXTMC_WB_DATA_WIDTH == 128) ? 3'b100 :  // 128-bit mem  datawidth
                                      3'b101;         // 256-bit mem  datawidth
  localparam CXTMC_DEVID_CONFIGTYPE       = 
       (CXTMC_ATBM_AXIM_CFG == CXTMC_CFG_ETB) ?
         2'b00 :                                      // TMC configured as ETB
       (CXTMC_ATBM_AXIM_CFG == CXTMC_CFG_ETR) ?
         2'b01 :                                      // TMC configured as ETR
         2'b10;                                       // TMC configured as ETF
  localparam CXTMC_DEVID_CLK_SCHEME       = 1'b0;     // Trace memory operates
                                                      // synchronous to cxtmc_clk
  localparam CXTMC_DEVID_ATB_PORT_COUNT   = 5'b00000; // No multiplexing on
                                                      // ATB input
  localparam CXTMC_DEVTYPE_VAL            =
               (CXTMC_ATBM_AXIM_CFG != CXTMC_CFG_ETF) ?  
                  8'h21 :                             // Device Type reg-ETB/ETR
                  8'h32;                              // Device Type reg- ETF
  localparam CXTMC_PERIPHID4_VAL          = 8'h04;    // Peripheral ID4 reg
  localparam CXTMC_PERIPHID5_VAL          = 8'h00;    // Peripheral ID5 reg 
  localparam CXTMC_PERIPHID6_VAL          = 8'h00;    // Peripheral ID6 reg
  localparam CXTMC_PERIPHID7_VAL          = 8'h00;    // Peripheral ID7 reg
  localparam CXTMC_PERIPHID0_VAL          = 8'h61;    // Peripheral ID0 reg
  localparam CXTMC_PERIPHID1_VAL          = 8'hB9;    // Peripheral ID1 reg
  localparam CXTMC_PERIPHID2_VAL          = 8'h0B;    // Peripheral ID2 reg
  localparam CXTMC_COMPID0_VAL            = 8'h0D;    // Component ID0 reg
  localparam CXTMC_COMPID1_VAL            = 8'h90;    // Component ID1 reg
  localparam CXTMC_COMPID2_VAL            = 8'h05;    // Component ID2 reg
  localparam CXTMC_COMPID3_VAL            = 8'hB1;    // Component ID3 reg
  localparam CXTMC_PSCR_RST_VAL           = 5'h00;    // PSCR register
  
  localparam CXTMC_WBUFFER_DEPTH_BIN      =           // Binary representation
               (CXTMC_WBUFFER_DEPTH == 4)  ? 4'b0011 :// of parameter used for
               (CXTMC_WBUFFER_DEPTH == 8)  ? 4'b0111 :// comparison with burst
                                                      // length programmed
                                             4'b1111; // 16/32 deep write buffer

// In the ETR configuration, the size of the trace memory is programmed into the
// RSZ register. The programmed value represents the trace memory size in 
// 32-bit words. As the width of the AXI trace memory changes to 64/128 bits,
// the value programmed in the RSZ register is to be right-shifted by a
// suitable number of bits to determine the depth of the trace memory. The
// CXTMC_RSZ_LSB local parameter determines the number of bits by which this
// right shift must happen.
  localparam CXTMC_RSZ_LSB                =
               (CXTMC_WB_DATA_WIDTH == 32) ? 0 :
               (CXTMC_WB_DATA_WIDTH == 64) ? 1 :
                                             2;       // 128 bits wide databus

// In the ETR configuration, the reset value of RSZ register corresponds
// to 4KB memory size
  localparam CXTMC_RSZ_RST_VAL = 31'h00000400;
  
  //---------------------------------------------------------------------------
  // Wires
  //---------------------------------------------------------------------------
  wire        reg_wr_en;            
  // Device unlocked and register write detected 

  wire        nxt_dev_unlocked;     
  // D-input of dev_unlocked

  wire [3:0]   nxt_claim_tag;   
  // D-input of Claim Tag register

  wire         nxt_rrd_hold;        
  // D-input of rrd_hold

  wire        drain_buffer_en;      
  // Enable draining of trace data through ATB Master port

  wire        rwd_wr_acc;           
  // RWD register accessed

  wire        nxt_rwd_wr_en;        
  // D-input of rwd_wr_en

  wire        nxt_rwd_hold;         
  // D-input of rwd_hold

  wire         nxt_ffcr_f_on_man;   
  // D-input of ffcr_flush_man
 
  wire        rrd_rd_valid;         
  // Indicates an RRD read for which data is to be fetched from memory

  wire        rrd_rd_err;         
  // RRD register read cannot be serviced

  wire        acqcomp_func;         
  // ACQCOMP in functional mode (ie when TMC is not in Integration test mode)

  wire        tmc_enabled;          
  // If TraceCaptEn is cleared with TMCReady still 0, the tmc_enabled signal is
  // used to ensure that ACQCOMP tracks TMCReady till TMCReady is 1, but
  // not beyond that point.

  wire        trace_mem_empty_sts;  
  // Empty bit in the STS register

  wire        triggered_sts;        
  // Triggered bit in the STS register

  wire        nxt_acqcomp;          
  // D-input of ACQCOMP

  wire        nxt_rrd_rd_valid_rd_start;
  // D-input of rrd_rd_valid_rd_start;

  wire [30:0] rsz;
  // RSZ register raw

  wire rrd_rd_valid_mode_decode;
  // Mode-agnostic consolidated validator for RRD reads

  wire swf_rrd_rd_valid;
  // Validator for RRD reads when in SWF mode

  wire cbm_rrd_rd_valid;
  // Validator for RRD reads when in Circular buffer mode

// Address decodes for registers
  wire rsz_sel;
  wire sts_sel;
  wire rrd_sel;
  wire rrp_sel;
  wire rwp_sel;
  wire trg_sel;
  wire ctl_sel;
  wire rwd_sel;
  wire mode_sel;
  wire lat_buf_level_sel;
  wire c_buf_level_sel;
  wire buf_wm_sel;
  wire rrp_hi_sel;
  wire rwp_hi_sel;
  wire ffsr_sel;
  wire ffcr_sel;
  wire pscr_sel;
  wire it_misc_op_0_sel;
  wire it_tr_flin_sel;
  wire it_atb_data_0_sel;
  wire it_atb_ctr_2_sel;
  wire it_atb_ctr_1_sel;
  wire it_atb_ctr_0_sel;
  wire it_ctrl_sel;
  wire claim_tag_set_sel;
  wire claim_tag_clr_sel;
  wire lock_acc_sel;
  wire lock_status_sel;
  wire auth_status_sel;
  wire device_id_sel;
  wire device_type_sel;
  wire periph_id_0_sel;
  wire periph_id_1_sel;
  wire periph_id_2_sel;
  wire periph_id_4_sel;
  wire periph_id_5_sel;
  wire periph_id_6_sel;
  wire periph_id_7_sel;
  wire comp_id_0_sel;
  wire comp_id_1_sel;
  wire comp_id_2_sel;
  wire comp_id_3_sel;

// Write enables for registers
  wire rsz_wr_en;
  wire ctl_wr_en;
  wire mode_wr_en;
  wire buf_wm_wr_en;
  wire axi_ctl_wr_en;
  wire dba_hi_wr_en;
  wire dba_lo_wr_en;
  wire ffcr_wr_en;
  wire ffcr_wr_en_bits01;   
  // Write enable for FFCR[1:0] bits - these bits can be changed only when 
  // TraceCaptEn=0 and TMCReady=1

  wire ffcr_f_on_man_wr_en; 
  // Writes to FOnMan field in FFCR can occur from two sources - APB and 
  // Formatter control logic

  wire pscr_wr_en;
  wire it_ctrl_wr_en;
  wire claim_tag_wr_en;
  wire lock_access_wr_en;
  wire acqcomp_clk_en;
  wire reg_write;          
  // APB write detect

  wire apb_ready_wait_set;
  wire nxt_apb_ready_wait;
  wire        reg_read;            
  // APB read - asserted during Access phase of APB read transfer

  wire reg_read_det; 

// Read Enables for registers
  wire rsz_rd_en;
  wire sts_rd_en;
  wire rrp_rd_en;
  wire rwp_rd_en;
  wire trg_rd_en;
  wire ctl_rd_en;
  wire mode_rd_en;
  wire c_buf_level_rd_en;
  wire lat_buf_level_rd_en;
  wire buf_wm_rd_en;
  wire rrp_hi_rd_en;
  wire rwp_hi_rd_en;
  wire axi_ctl_rd_en;
  wire dba_lo_rd_en;
  wire dba_hi_rd_en;
  wire ffsr_rd_en;
  wire ffcr_rd_en;
  wire pscr_rd_en;
  wire it_atb_m_ctr_2_rd_en;
  wire it_tr_flin_rd_en;
  wire it_atb_data_0_rd_en;
  wire it_atb_ctr_1_rd_en;
  wire it_atb_ctr_0_rd_en;
  wire it_ctrl_rd_en;
  wire claim_tag_set_rd_en;
  wire claim_tag_clr_rd_en;
  wire lock_status_rd_en;
  wire auth_status_rd_en;
  wire device_id_rd_en;
  wire device_type_rd_en;
  wire periph_id_0_rd_en;
  wire periph_id_1_rd_en;
  wire periph_id_2_rd_en;
  wire periph_id_4_rd_en;
  wire periph_id_5_rd_en;
  wire periph_id_6_rd_en;
  wire periph_id_7_rd_en;
  wire comp_id_0_rd_en;
  wire comp_id_1_rd_en;
  wire comp_id_2_rd_en;
  wire comp_id_3_rd_en;

// Read data for registers
  wire [31:0] rsz_rd_data;
  wire [31:0] sts_rd_data;
  wire [31:0] rrp_rd_data;
  wire [31:0] rwp_rd_data;
  wire [31:0] trg_rd_data;
  wire [31:0] ctl_rd_data;
  wire [31:0] mode_rd_data;
  wire [31:0] buf_wm_rd_data;
  wire [31:0] rrp_hi_rd_data;
  wire [31:0] rwp_hi_rd_data;
  wire [31:0] axi_ctl_rd_data;
  wire [31:0] dba_lo_rd_data;
  wire [31:0] dba_hi_rd_data;
  wire [31:0] lat_buf_level_rd_data;
  wire [31:0] c_buf_level_rd_data;
  wire [31:0] ffsr_rd_data;
  wire [31:0] ffcr_rd_data;
  wire [31:0] pscr_rd_data;
  wire [31:0] it_tr_flin_rd_data;
  wire [31:0] it_atb_m_ctr_2_rd_data;
  wire [31:0] it_atb_data_0_rd_data;
  wire [31:0] it_atb_ctr_1_rd_data;
  wire [31:0] it_atb_ctr_0_rd_data;
  wire [31:0] it_ctrl_rd_data;
  wire [31:0] claim_tag_set_rd_data;
  wire [31:0] claim_tag_clr_rd_data;
  wire [31:0] lock_status_rd_data;
  wire [31:0] auth_status_rd_data;
  wire [31:0] device_id_rd_data;
  wire [31:0] device_type_rd_data;
  wire [31:0] periph_id_0_rd_data;
  wire [31:0] periph_id_1_rd_data;
  wire [31:0] periph_id_2_rd_data;
  wire [31:0] periph_id_4_rd_data;
  wire [31:0] periph_id_5_rd_data;
  wire [31:0] periph_id_6_rd_data;
  wire [31:0] periph_id_7_rd_data;
  wire [31:0] comp_id_0_rd_data;
  wire [31:0] comp_id_1_rd_data;
  wire [31:0] comp_id_2_rd_data;
  wire [31:0] comp_id_3_rd_data;

  
  //---------------------------------------------------------------------------
  // Registers
  //---------------------------------------------------------------------------
  reg        dev_unlocked;        
  // Writes to TMC registers allowed

  reg        ctl_trace_capt_en_reg;   
  // One clock delayed version of ctl_trace_capt_en

  reg [1:0]  mode;   
  // Mode register

  reg        ffcr_stop_on_trig_evt; 
  // StopOnTrigEvt bit in FFCR register

  reg        ffcr_trig_on_fl;     
  // TrigOnFl bit in FFCR register

  reg        ffcr_trig_on_trig_evt; 
  // TrigOnTrigEvt bit in FFCR register

  reg        ffcr_trig_on_trigin; 
  // TrigOnTrigIn bit in FFCR register

  reg        ffcr_flsh_on_trig_evt;
  // FOnTrigEvt bit in FFCR register

  reg        ffcr_en_formatting;  
  // EnFt bit in FFCR register

  reg [3:0]  claim_tag;       
  // Claim Tag register

  reg        rrd_hold;            
  // Insert wait cycles on APB reads from RRD

  reg        rwd_wr_en;           
  // RWD write detection

  reg        rwd_hold;            
  // Insert wait cycles on APB writes to RWD

  reg        tmc_enabled_hold;    
  // Used to remember the fact that TraceCaptEn has gone low, but TMCReady has 
  // not yet gone high.

  reg        circ_buf_mode_reg;   
  // If the TMC is in Circular buffer mode and if TraceCaptEn is cleared before
  // TMCReady goes high, remember that the TMC was in Circular buffer mode till
  // TMCReady goes high, but not beyond that point.

  reg        sw_fifo_mode_reg;    
  // If the TMC is in SW-FIFO mode and if TraceCaptEn is cleared before 
  // TMCReady goes high, remember that the TMC was in SW-FIFO mode till 
  // TMCReady goes high, but not beyond that point.

  reg        tmc_abort_reg;       
  // Registered version of tmc_abort

  reg        apb_valid_reg;       
  // Delayed version of apb_valid - used to detect a rising edge

  reg        apb_ready_wait;
  reg        rrd_rd_valid_rd_start;
  // Store the value of rrd_rd_valid at the start of a read access so that a
  // change in its status during a read access does not affect the on-going 
  // read access.
  
  reg        drain_in_prog;      
  // DrainBuffer bit has been set and memory drain is in progress

  //---------------------------------------------------------------------------
  //
  // Main body of code
  // =================
  //
  //---------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// Address decodes for registers
//-----------------------------------------------------------------------------
  assign rsz_sel           = (apb_addr == CXTMC_RSZ);
  assign sts_sel           = (apb_addr == CXTMC_STS);
  assign rrd_sel           = (apb_addr == CXTMC_RRD);
  assign rrp_sel           = (apb_addr == CXTMC_RRP);
  assign rwp_sel           = (apb_addr == CXTMC_RWP);
  assign trg_sel           = (apb_addr == CXTMC_TRG);
  assign ctl_sel           = (apb_addr == CXTMC_CTL);
  assign rwd_sel           = (apb_addr == CXTMC_RWD);
  assign mode_sel          = (apb_addr == CXTMC_MODE);
  assign lat_buf_level_sel = (apb_addr == CXTMC_LBUF_LEVEL);
  assign c_buf_level_sel   = (apb_addr == CXTMC_CBUF_LEVEL);
  assign buf_wm_sel        = (apb_addr == CXTMC_BUF_WM);
  assign rrp_hi_sel        = (apb_addr == CXTMC_RRP_HI);
  assign rwp_hi_sel        = (apb_addr == CXTMC_RWP_HI);
  assign ffsr_sel          = (apb_addr == CXTMC_FFSR);
  assign ffcr_sel          = (apb_addr == CXTMC_FFCR);
  assign pscr_sel          = (apb_addr == CXTMC_PSCR);
  assign it_misc_op_0_sel  = (apb_addr == CXTMC_IT_MISC_OP_0);
  assign it_tr_flin_sel    = (apb_addr == CXTMC_IT_TR_FL_IN);
  assign it_atb_data_0_sel = (apb_addr == CXTMC_IT_ATB_DATA_0);
  assign it_atb_ctr_2_sel  = (apb_addr == CXTMC_IT_ATB_CTR_2);
  assign it_atb_ctr_1_sel  = (apb_addr == CXTMC_IT_ATB_CTR_1);
  assign it_atb_ctr_0_sel  = (apb_addr == CXTMC_IT_ATB_CTR_0);
  assign it_ctrl_sel       = (apb_addr == CXTMC_IT_CTRL);
  assign claim_tag_set_sel = (apb_addr == CXTMC_CLAIMSET);
  assign claim_tag_clr_sel = (apb_addr == CXTMC_CLAIMCLR);
  assign lock_acc_sel      = (apb_addr == CXTMC_LOCKACCESS);
  assign lock_status_sel   = (apb_addr == CXTMC_LOCKSTATUS);
  assign auth_status_sel   = (apb_addr == CXTMC_AUTHSTATUS);
  assign device_id_sel     = (apb_addr == CXTMC_DEVICEID);
  assign device_type_sel   = (apb_addr == CXTMC_DEVICETYPE);
  assign periph_id_0_sel   = (apb_addr == CXTMC_PERIPH_ID_0);
  assign periph_id_1_sel   = (apb_addr == CXTMC_PERIPH_ID_1);
  assign periph_id_2_sel   = (apb_addr == CXTMC_PERIPH_ID_2);
  assign periph_id_4_sel   = (apb_addr == CXTMC_PERIPH_ID_4);
  assign periph_id_5_sel   = (apb_addr == CXTMC_PERIPH_ID_5);
  assign periph_id_6_sel   = (apb_addr == CXTMC_PERIPH_ID_6);
  assign periph_id_7_sel   = (apb_addr == CXTMC_PERIPH_ID_7);
  assign comp_id_0_sel     = (apb_addr == CXTMC_COMP_ID_0);
  assign comp_id_1_sel     = (apb_addr == CXTMC_COMP_ID_1);
  assign comp_id_2_sel     = (apb_addr == CXTMC_COMP_ID_2);
  assign comp_id_3_sel     = (apb_addr == CXTMC_COMP_ID_3);

  //---------------------------------------------------------------------------
  // Clock is requested when the TMC is enabled or it is busy or there is
  // APB access. For reads from RRD or writes to RWD, memory accesses are
  // required, hence clock to the TMC is enabled on APB accesses. In the
  // Integration test mode, clock is enabled to allow capture of external
  // inputs.
  //---------------------------------------------------------------------------
  assign tmc_clk_req = pseldbg_r | ctl_trace_capt_en | it_ctrl |
                       ~ACQCOMP | ~tmc_ready;
  //---------------------------------------------------------------------------
  // Generate a delayed version of apb_valid to detect a rising edge
  //---------------------------------------------------------------------------
  always @(posedge cxtmc_clk or negedge RESETn)
  begin
    if (!RESETn)
      apb_valid_reg  <= 1'b0;
    else
      apb_valid_reg  <= apb_valid;
  end

  assign reg_write = pwritedbg_r & (apb_valid & ~apb_valid_reg); 
  assign reg_read  = ~pwritedbg_r & apb_valid;
  assign reg_read_det  = ~pwritedbg_r & (apb_valid & ~apb_valid_reg);

  //---------------------------------------------------------------------------
  // Generation of apb_ready.
  // For RRD and RWD accesses, apb_ready is asserted only after an 
  // acknowledgement is received. For other registers, writes are with no
  // wait cycles, but reads are with one wait cycle
  //---------------------------------------------------------------------------
  assign apb_ready = (nxt_rrd_hold || nxt_rwd_hold) ? 
                     apb_ready_wait : apb_valid;

  // apb_ready_wait once set, will remain asserted till apb_valid goes low
  assign nxt_apb_ready_wait = apb_ready_wait_set |
                              (apb_ready_wait & apb_valid);

  assign apb_ready_wait_set = (nxt_rwd_hold & wb_ready) | 
                              (nxt_rrd_hold & rrd_rd_ack);

  always @(posedge cxtmc_clk or negedge RESETn)
  begin : p_apb_ready_wait
    if (!RESETn)
      apb_ready_wait <= 1'b0;
    else
      apb_ready_wait <= nxt_apb_ready_wait;
   end // block: p_apb_ready_wait

//-----------------------------------------------------------------------------
// Writes to the LOCKACCESS register are allowed only when PADDRDBG31 is low. 
// For external debuggers (PADDRDBG31 = 1), no lock mechanism is necessary. 
// Unlock the device if 32'hC5ACCE55 is written to the LOCKACCESS register.
//-----------------------------------------------------------------------------
  assign lock_access_wr_en = reg_write & lock_acc_sel & ~apb_addr31;
  assign nxt_dev_unlocked = (apb_wdata == 32'hC5ACCE55);

//-----------------------------------------------------------------------------
// Sequential block for writing into the lock access register.
// Lock Access register    : Offset 0xFB0 ( W )
//-----------------------------------------------------------------------------
  always @(posedge cxtmc_clk or negedge RESETn)
  begin : p_dev_unlocked
    if (!RESETn)
      dev_unlocked <= 1'b0;
    else if(lock_access_wr_en)
      dev_unlocked <= nxt_dev_unlocked;
  end // block: p_dev_unlocked

//-----------------------------------------------------------------------------
// Register Writes are allowed only if the device is unlocked or PADDRDBG31 is 
// asserted. External debugger accesses (PADDRDBG31 = 1), are not subject to
// lock checks.
//-----------------------------------------------------------------------------
  assign reg_wr_en = reg_write & (dev_unlocked | apb_addr31);

generate
  if (CXTMC_ATBM_AXIM_CFG == CXTMC_CFG_ETR)
    begin:p_rsz
      reg [30:0] rsz_etr;             // RSZ register

      //-----------------------------------------------------------------------
      // RSZ register - write-able only in ETR configuration
      //-----------------------------------------------------------------------
      assign rsz_wr_en = reg_wr_en & rsz_sel & tmc_ready & ~ctl_trace_capt_en;

      always @(posedge cxtmc_clk or negedge RESETn)
        begin : p_rsz_etr
          if (!RESETn)
            rsz_etr <= CXTMC_RSZ_RST_VAL;
          else if (rsz_wr_en)
            rsz_etr <= apb_wdata[30:0];
        end // p_rsz_etr

      // Zero-padding for RSZ reads
      assign rsz_rd_data = {1'b0, rsz_etr};
      assign rsz         = rsz_etr;
    end
  else
    begin
      assign rsz         = CXTMC_MEM_SIZE[30:0];
      assign rsz_rd_data = {1'b0, rsz};
    end
endgenerate

//-----------------------------------------------------------------------------
// Mask the programmed RSZ value to align with AXI data width
//-----------------------------------------------------------------------------
generate
  if ((CXTMC_ATBM_AXIM_CFG == CXTMC_CFG_ETR) && 
      (CXTMC_AXI_DATA_WIDTH == 32))
      assign rsz_masked = rsz;
  else if ((CXTMC_ATBM_AXIM_CFG == CXTMC_CFG_ETR) &&
           (CXTMC_AXI_DATA_WIDTH == 64))
      assign rsz_masked = {rsz[30:1], 1'b0};
  else if ((CXTMC_ATBM_AXIM_CFG == CXTMC_CFG_ETR) &&
           (CXTMC_AXI_DATA_WIDTH == 128))
      assign rsz_masked = {rsz[30:2], 2'b00};
  else
      assign rsz_masked = rsz;
endgenerate

generate
  if (CXTMC_ATBM_AXIM_CFG == CXTMC_CFG_ETR)
    begin
      //-----------------------------------------------------------------------
      // Memory error status is set when there is an error condition detected
      // on the AXI interface. It is cleared by a write of 1 to this register 
      // bit position or when TraceCaptEn is set (rising edge).
      //-----------------------------------------------------------------------
      assign mem_err_clr  = (reg_wr_en & sts_sel & apb_wdata[5] & tmc_ready)
                            | (ctl_trace_capt_en & ~ctl_trace_capt_en_reg);
    end
  else // ETB/ETF configuration
    assign mem_err_clr = 1'b0;
endgenerate

//-----------------------------------------------------------------------------
// Write enable generation for RRP register. 
// A write to the RRP register is allowed only when the TMC is inactive. Also, 
// the RRP cannot be written when the trace buffer is in the process of being 
// drained following the setting of the DrainBuffer bit (FFCR). In the FIFO 
// modes, the RRP register is read-only, but is cleared when Trace capture is 
// enabled after being disabled.
//-----------------------------------------------------------------------------
assign rrp_wr_en = reg_wr_en & rrp_sel & tmc_ready & ~ctl_trace_capt_en;

generate
  if (CXTMC_ATBM_AXIM_CFG == CXTMC_CFG_ETR)
//-----------------------------------------------------------------------------
// The RRPHI register is applicable in ETR configuration only
//-----------------------------------------------------------------------------
    assign rrp_hi_wr_en = reg_wr_en & rrp_hi_sel & tmc_ready & 
                          ~ctl_trace_capt_en;
  else
    assign rrp_hi_wr_en = 1'b0;
endgenerate

//-----------------------------------------------------------------------------
// Write enable generation for RWP register. 
// A write to the RWP register is allowed only when the TMC is inactive. Also, 
// the RWP cannot be written when the trace buffer is in the process of being 
// drained following the setting of the DrainBuffer bit (FFCR). In the FIFO 
// modes, the RWP register is read-only, but is cleared when Trace capture is 
// enabled after being disabled.
//-----------------------------------------------------------------------------
assign rwp_wr_en = reg_wr_en & rwp_sel & tmc_ready & ~ctl_trace_capt_en;

generate
  if (CXTMC_ATBM_AXIM_CFG == CXTMC_CFG_ETR)
//-----------------------------------------------------------------------------
// The RWPHI register is applicable in ETR configuration only
//-----------------------------------------------------------------------------
    assign rwp_hi_wr_en = reg_wr_en & rwp_hi_sel & tmc_ready & 
                          ~ctl_trace_capt_en;
  else
    assign rwp_hi_wr_en = 1'b0;
endgenerate

//-----------------------------------------------------------------------------
// Clear the pointers when the TMC is enabled after being disabled.
// This output signal is used in the Memory interface as follows:
// If the TMC is in one of the FIFO modes when enabled, the pointers in the
// Memory interface and the FULL flag are cleared. In Circular buffer mode 
// the pointers are setup by the debugger through writes to the RRP and RWP 
// registers before the TMC is enabled, so they are not cleared. The FULL flag
// is cleared when the TMC is enabled in Circular buffer mode.
// The falling edge of ctl_trace_capt_en is used to clear fill level registers
// in the memory interface/AXI interface.
//-----------------------------------------------------------------------------
assign ptr_clr = ctl_trace_capt_en & ~ctl_trace_capt_en_reg;
assign ctl_trace_capt_en_1_0 = ctl_trace_capt_en_reg & ~ctl_trace_capt_en;

//-----------------------------------------------------------------------------
// Write enable generation for TRG register - updated only when the TMC is
// inactive. The format control block will update the register only in
// circular buffer mode.  
//-----------------------------------------------------------------------------
assign trg_wr_en = reg_wr_en & trg_sel & tmc_ready & ~ctl_trace_capt_en;

//-----------------------------------------------------------------------------
// CTL register
//-----------------------------------------------------------------------------
  assign ctl_wr_en = reg_wr_en & ctl_sel;

  always @(posedge cxtmc_clk or negedge RESETn)
    begin : p_ctl
      if (!RESETn)
        ctl_trace_capt_en <= 1'b0;
      else if(ctl_wr_en)
        ctl_trace_capt_en <= apb_wdata[0];
    end // block: p_ctl

//-----------------------------------------------------------------------------
// Registered version of ctl_trace_capt_en - used to detect an edge on 
// ctl_trace_capt_en
//-----------------------------------------------------------------------------
  always @(posedge cxtmc_clk or negedge RESETn)
    begin : p_ctl_reg
      if (!RESETn)
        ctl_trace_capt_en_reg <= 1'b0;
      else
        ctl_trace_capt_en_reg <= ctl_trace_capt_en;
    end // block: p_ctl_reg

//-----------------------------------------------------------------------------
// RWD register
// A write to the RWD register is allowed only when the formatter is inactive.
// When an APB write is initiated to this register, the rwd_wr_req output is 
// asserted to initiate a memory write. If the Write buffer is unable to accept 
// write data, wait cycles are inserted on the APB.
// The rwd_wr_en pulse is registered to meet synthesis timing.
// If a memory error has occurred on a previous transfer, then the RWD write
// is ignored. 
// The rwd_wr_acc signal is used to return PSLVERRDBG if a memory error has
// occurred.
// Note that ft_stopped is used instead of tmc_ready. This is because tmc_ready
// also means the write buffer is empty, but in cases where multiple APB
// writes are needed per memory word, the write buffer becomes non-empty
// after the first data is written to it. If tmc_ready is used, that would
// inhibit further writes to the write buffer, which would be left waiting
// for the rest of the memory word to be written from the APB.
//-----------------------------------------------------------------------------
assign rwd_wr_acc = reg_wr_en & rwd_sel;
assign nxt_rwd_wr_en = rwd_wr_acc & ft_stopped & ~mem_err & ~ctl_trace_capt_en;

  always @(posedge cxtmc_clk or negedge RESETn)
    begin : p_rwd_wr_en
      if (!RESETn)
        rwd_wr_en <= 1'b0;
      else
        rwd_wr_en <= nxt_rwd_wr_en;
    end // block: p_rwd_wr_en

generate
  if (CXTMC_ATBM_AXIM_CFG == CXTMC_CFG_ETR)
    // rwd_wr_req is a pulse in the ETR configuration to ensure data read/write
    // coherency on the AXI trace memory. This avoids extra logic on the
    // write buffer block.
    assign rwd_wr_req = rwd_wr_en;
  else // ETB/ETF configurations
    // Hold the write enable request to the Write Buffer till it is accepted. 
    // Also, wait cycles are inserted on the APB till the write is accepted by 
    // the Write Buffer
    assign rwd_wr_req = rwd_wr_en | (rwd_hold & ~apb_ready_wait);
endgenerate

//-----------------------------------------------------------------------------
// Wait cycle insertion for RWD writes
// Set the rwd_hold signal if there is a valid write access to RWD. Hold this 
// signal till the Write Buffer has accepted the data written (wb_ready is high)
// If the acknowledgement is received before a valid clock edge qualified by 
// PCLKENDBG has occurred, then stretch the acknowledgement. 
//-----------------------------------------------------------------------------
assign nxt_rwd_hold = nxt_rwd_wr_en |
                      (rwd_hold & apb_valid);
  
  // rwd_hold flop 
  always @(posedge cxtmc_clk or negedge RESETn)
  begin : p_rwd_hold
    if (!RESETn)
      rwd_hold <= 1'b0;
    else
      rwd_hold <= nxt_rwd_hold;
   end // block: p_rwd_hold

//-----------------------------------------------------------------------------
// MODE register
//-----------------------------------------------------------------------------
  assign mode_wr_en = reg_wr_en & mode_sel & tmc_ready & ~ctl_trace_capt_en;

  always @(posedge cxtmc_clk or negedge RESETn)
    begin : p_mode
      if (!RESETn)
        mode <= 2'b00;
      else if (mode_wr_en)
        mode <= apb_wdata[1:0];
    end // block: p_mode

generate
  if (CXTMC_ATBM_AXIM_CFG == CXTMC_CFG_ETF)
    begin:p_etf
      reg hw_fifo_mode_reg;  // If the TMC is in HW-FIFO mode and 
                             // if TraceCaptEn is cleared before TMCReady
                             // goes high, remember that the TMC was in 
                             // HW-FIFO mode till TMCReady goes 
                             // high, but not beyond that point. 

      //-----------------------------------------------------------------------
      // Enable TMC operation in HW-FIFO mode when TraceCaptEn is high and the 
      // MODE register is programmed for this mode. If the TMC is disabled 
      // while in HW FIFO mode, trace data if any present in the trace memory 
      // is lost. The fact that the TMC is enabled in HW-FIFO mode is 
      // remembered till the TMC is disabled and the internal pipelines are 
      // flushed.
      //-----------------------------------------------------------------------
      assign hw_fifo_mode = (mode[1] &
                             ctl_trace_capt_en & ~ctl_trace_capt_en_reg) |
                            (hw_fifo_mode_reg &
                              ~(tmc_ready & ~ctl_trace_capt_en));

      //-----------------------------------------------------------------------
      // Clocked process for hw_fifo_mode_reg
      //-----------------------------------------------------------------------
      always @(posedge cxtmc_clk or negedge RESETn)
        begin : p_hwf_mode_reg
          if (!RESETn)
            hw_fifo_mode_reg <= 1'b0;
          else
            hw_fifo_mode_reg <= hw_fifo_mode;
        end // block: p_hwf_mode_reg
    end
  else
    assign hw_fifo_mode = 1'b0;
endgenerate

//-----------------------------------------------------------------------------
// Decode MODE register
// In the ETF configuration, the MODE register has an extra bit.
// The MODE register settings are valid only when TraceCaptEn bit is 1.
// It is possible that trace capture stopping is initiated by first clearing 
// TraceCaptEn. In this case, the TMC continues in the mode last programmed
// till TMCReady is asserted ie. the fact that the TMC is enabled in a given 
// mode is remembered till the TMC is disabled and the internal pipelines are 
// flushed. The MODE bits are not allowed to be changed in the duration till 
// TMCReady is asserted.
//-----------------------------------------------------------------------------
generate
  if (CXTMC_ATBM_AXIM_CFG == CXTMC_CFG_ETF) // ETF configuration
    begin
      assign circ_buf_mode = ((mode == 2'b00) &
                              ctl_trace_capt_en & ~ctl_trace_capt_en_reg) |
                             (circ_buf_mode_reg &
                             ~(tmc_ready & ~ctl_trace_capt_en));
      assign sw_fifo_mode  = ((mode == 2'b01) &
                              ctl_trace_capt_en & ~ctl_trace_capt_en_reg) |
                             (sw_fifo_mode_reg &
                             ~(tmc_ready & ~ctl_trace_capt_en));

    end
  else
    begin
      assign circ_buf_mode = (~mode[0] & ctl_trace_capt_en &
                              ~ctl_trace_capt_en_reg) |
                             (circ_buf_mode_reg &
                             ~(tmc_ready & ~ctl_trace_capt_en));
      assign sw_fifo_mode  = (mode[0] & ctl_trace_capt_en &
                              ~ctl_trace_capt_en_reg) |
                             (sw_fifo_mode_reg &
                             ~(tmc_ready & ~ctl_trace_capt_en));

    end
endgenerate

  always @(posedge cxtmc_clk or negedge RESETn)
    begin : p_circ_buf_mode_reg
      if (!RESETn)
        circ_buf_mode_reg <= 1'b0;
      else
        circ_buf_mode_reg <= circ_buf_mode;
    end // block: p_circ_buf_mode_reg

  always @(posedge cxtmc_clk or negedge RESETn)
    begin : p_swf_mode_reg
      if (!RESETn)
        sw_fifo_mode_reg <= 1'b0;
      else
        sw_fifo_mode_reg <= sw_fifo_mode;
    end // block: p_swf_mode_reg

generate
  if (CXTMC_ATBM_AXIM_CFG == CXTMC_CFG_ETF) // ETF configuration
    begin
//-----------------------------------------------------------------------------
// Enable the unformatter logic if
// - the TMC is configured for hardware-read-FIFO mode OR
// - the DrainBuffer bit in FFCR is set in Circular-Buffer mode
// If unformatter_en goes low, the unformatter discards data in its internal 
// pipelines and asserts unformatter_empty. 
//
// If the formatter has stopped and the trace memory has been read out fully,
// assert the unformatter_stop output. This drains the internal pipelines in 
// the unformatter through the ATB master interface. The two-cycle delaying
// of trace_mem_empty is to account for the 2-cycle latency between the issue
// of a memory read command and the availability of read data for sampling.
// The ptr_clr signal is used to account for the initial latency in
// the formatter going active.
// It is guaranteed that the formatter, once stopped, will not go active
// unless there is a low-to-high transition on TraceCaptEn.
//-----------------------------------------------------------------------------
      reg trace_mem_empty_reg1; // 1-cycle delayed version of trace_mem_empty
      reg trace_mem_empty_reg2; // 2-cycle delayed version of trace_mem_empty

      assign unformatter_en   = (hw_fifo_mode & ctl_trace_capt_en & ~ptr_clr) |
                                drain_buffer_en;
      assign unformatter_stop = unformatter_en & ft_stopped &
                                trace_mem_empty & trace_mem_empty_reg1 &
                                trace_mem_empty_reg2;

      always @(posedge cxtmc_clk or negedge RESETn)
        begin : p_trace_mem_empty
          if (!RESETn)
            begin
              trace_mem_empty_reg1 <= 1'b0;
              trace_mem_empty_reg2 <= 1'b0;
            end
          else
            begin
              trace_mem_empty_reg1 <= trace_mem_empty;
              trace_mem_empty_reg2 <= trace_mem_empty_reg1;
            end
        end // block: p_trace_mem_empty
    end
  else
    begin
      assign unformatter_en   = 1'b0;
      assign unformatter_stop = 1'b0;
    end
endgenerate

//-----------------------------------------------------------------------------
// BUFWM register
// In the ETR configuration, this register is 30 bits wide.
//-----------------------------------------------------------------------------
assign buf_wm_wr_en = reg_wr_en & buf_wm_sel & tmc_ready & ~ctl_trace_capt_en;

always @(posedge cxtmc_clk or negedge RESETn)
  begin : p_buf_wm
    if (!RESETn)
      buf_wm <= {CXTMC_FILL_LEVEL_WIDTH-1{1'b0}};
    else if(buf_wm_wr_en)
      buf_wm <= apb_wdata[CXTMC_FILL_LEVEL_WIDTH-2:0];
  end // block: p_buf_wm

generate
  if (CXTMC_ATBM_AXIM_CFG == CXTMC_CFG_ETR)
    begin:p_etr
      wire axi_ctl_sel;       // Address decode for AXICTL register
      wire dba_lo_sel;        // Address decode for DBALO register
      wire dba_hi_sel;        // Address decode for DBAHI register
      wire[30-CXTMC_RSZ_LSB:0] rsz_in_axi_datawords;
                              // RSZ register value right-shifted and 1 
                              // subtracted to compare with the programmed
                              // write burst length
      reg [31:0] dba_lo_etr;  // DBALO register
      reg [7:0]  dba_hi_etr;  // DBAHI register
      reg [5:0]  axi_ctl_bits_5_to_0;  // AXICTL register - bits [5:0]
      reg [4:0]  axi_ctl_bits_11_to_7; // AXICTL register - bits [11:7]
      wire [11:0] axi_ctl;             // AXICTL register bits concatenated

      assign axi_ctl_sel = (apb_addr == CXTMC_AXI_CTL);

      //-----------------------------------------------------------------------
      // AXICTL register
      //-----------------------------------------------------------------------
      assign axi_ctl_wr_en = reg_wr_en & axi_ctl_sel & tmc_ready & 
                             ~ctl_trace_capt_en;

      always @(posedge cxtmc_clk or negedge RESETn)
        begin : p_axi_ctl
          if (!RESETn)
            begin
              axi_ctl_bits_5_to_0  <= 6'b000000;
              axi_ctl_bits_11_to_7 <= 5'b00000;
            end
          else if (axi_ctl_wr_en)
            begin
              axi_ctl_bits_5_to_0  <= apb_wdata[5:0];
              axi_ctl_bits_11_to_7 <= apb_wdata[11:7];
            end
        end // p_axi_ctl     

        assign axi_ctl = {axi_ctl_bits_11_to_7, 1'b0, axi_ctl_bits_5_to_0};

      //-----------------------------------------------------------------------
      // Bit assignments in the AXICTL register
      //-----------------------------------------------------------------------
      assign axictl_sg_mode = axi_ctl[7] & tmc_enabled;

      // To comply with AXI protocol, if CacheCtrlBit1 is 0, then CacheCtrlBit2 
      // and CacheCtrlBit3 must also be 0. 
      assign axictl_cache_ctrl = {axi_ctl[5] & axi_ctl[3],
                                  axi_ctl[4] & axi_ctl[3],
                                  axi_ctl[3:2]};
      assign axictl_prot_ctrl  = axi_ctl[1:0];

      //-----------------------------------------------------------------------
      // Burst length.
      // When the TMC is disabled, the burst length defaults to 0 (1 beat).
      // When the TMC is enabled, the burst length that takes effect is the 
      // least of the following items:
      // 1. Programmed burst length
      // 2. Write buffer depth
      // 3. Number of AXI data words in the trace memory (with 1 subtracted to
      //    match the encoding of burst length)
      // In scatter-gather operation, RSZ is ignored in the comparison.
      //-----------------------------------------------------------------------
      assign rsz_in_axi_datawords = rsz[30:CXTMC_RSZ_LSB] -
                                    {{(31-CXTMC_RSZ_LSB-1){1'b0}}, 1'b1};
      assign axictl_wr_burst_len =
              tmc_disabled ? 4'h0 :
              axictl_sg_mode ? 
              ((axi_ctl[11:8] < CXTMC_WBUFFER_DEPTH_BIN) ?
                axi_ctl[11:8] : CXTMC_WBUFFER_DEPTH_BIN) :
 
              ((({{(31-CXTMC_RSZ_LSB-4){1'b0}}, axi_ctl[11:8]} <=
                rsz_in_axi_datawords) &&
               (axi_ctl[11:8] <= CXTMC_WBUFFER_DEPTH_BIN)) ?
                 axi_ctl[11:8] :
              ((CXTMC_WBUFFER_DEPTH_BIN <= axi_ctl[11:8]) &&
               ({{(31-CXTMC_RSZ_LSB-4){1'b0}}, CXTMC_WBUFFER_DEPTH_BIN} <=
                rsz_in_axi_datawords)) ?
                 CXTMC_WBUFFER_DEPTH_BIN :
                 rsz_in_axi_datawords[3:0]);

      //-----------------------------------------------------------------------
      // DBALO, DBAHI registers
      //-----------------------------------------------------------------------
      assign dba_lo_sel   = (apb_addr == CXTMC_DBA_LO);
      assign dba_hi_sel   = (apb_addr == CXTMC_DBA_HI);
      assign dba_lo_wr_en = reg_wr_en & dba_lo_sel & tmc_ready &
                            ~ctl_trace_capt_en;
      assign dba_hi_wr_en = reg_wr_en & dba_hi_sel & tmc_ready &
                            ~ctl_trace_capt_en;

      always @(posedge cxtmc_clk or negedge RESETn)
        begin : p_dba_lo_etr
          if (!RESETn)
            dba_lo_etr <= 32'h00000000;
          else if (dba_lo_wr_en)
            dba_lo_etr <= apb_wdata;
        end // p_dba_lo_etr     

      always @(posedge cxtmc_clk or negedge RESETn)
        begin : p_dba_hi_etr
          if (!RESETn)
            dba_hi_etr <= 8'h00;
          else if (dba_hi_wr_en)
            dba_hi_etr <= apb_wdata[7:0];
        end // p_dba_hi_etr     

      assign dba_lo = dba_lo_etr;
      assign dba_hi = dba_hi_etr;

      //-----------------------------------------------------------------------
      // Read enables and read data for ETR-specific registers
      //-----------------------------------------------------------------------
      assign rrp_hi_rd_en    = reg_read & rrp_hi_sel;
      assign rwp_hi_rd_en    = reg_read & rwp_hi_sel;
      assign axi_ctl_rd_en   = reg_read & axi_ctl_sel;
      assign dba_lo_rd_en    = reg_read & dba_lo_sel;
      assign dba_hi_rd_en    = reg_read & dba_hi_sel;
      assign dba_lo_rd_data  = dba_lo_etr;
      assign dba_hi_rd_data  = {{24{1'b0}}, dba_hi_etr};
      assign axi_ctl_rd_data = {{20{1'b0}}, axi_ctl};
      assign rrp_hi_rd_data  = {{24{1'b0}}, rrp[39:32]};
      assign rwp_hi_rd_data  = {{24{1'b0}}, rwp[39:32]};
    end
  else
    begin
      assign axictl_wr_burst_len  = 4'h0;
      assign axictl_sg_mode       = 1'b0;
      assign axictl_cache_ctrl    = 4'h0;
      assign axictl_prot_ctrl     = 2'b00;
      assign dba_lo      = 32'h00000000;
      assign dba_hi      = 8'h00;
      assign rrp_hi_rd_en             = 1'b0;
      assign rwp_hi_rd_en             = 1'b0;
      assign axi_ctl_rd_en            = 1'b0;
      assign dba_lo_rd_en             = 1'b0;
      assign dba_hi_rd_en             = 1'b0;
      assign dba_lo_rd_data           = 32'h00000000;
      assign dba_hi_rd_data           = 32'h00000000;
      assign axi_ctl_rd_data          = 32'h00000000;
      assign rrp_hi_rd_data           = 32'h00000000;
      assign rwp_hi_rd_data           = 32'h00000000;
    end
endgenerate

//-----------------------------------------------------------------------------
// FFCR register
// FFCR[14] - DrainBuffer   - drain_buffer_en (reads return 0)
//      13  - StopOnTrigEvt - ffcr_stop_on_trig_evt
//      12  - StopOnFl      - ffcr_stop_on_fl
//      11  - Reserved    
//      10  - TrigOnFl      - ffcr_trig_on_fl
//       9  - TrigOnTrigEvt - ffcr_trig_on_trig_evt
//       8  - TrigOnTrigIn  - ffcr_trig_on_trigin
//       7  - Reserved
//       6  - FlushMan      - ffcr_flush_man
//       5  - FOnTrigEvt    - ffcr_flsh_on_trig_evt
//       4  - FOnFlIn       - ffcr_flsh_on_flshin
//       3  - Reserved
//       2  - Reserved
//       1  - EnTI          - ffcr_en_trig_ins
//  FFCR[0] - EnFt          - ffcr_en_formatting
// The EnTI and EnFt bits are allowed to be changed only when TraceCaptEn=0
// and TMCReady=1.
//-----------------------------------------------------------------------------
  assign ffcr_wr_en        = reg_wr_en & ffcr_sel;
  assign ffcr_wr_en_bits01 = reg_wr_en & ffcr_sel & tmc_ready & 
                             ~ctl_trace_capt_en;

  always @(posedge cxtmc_clk or negedge RESETn)
    begin : p_ffcr
      if (!RESETn)
        begin
          ffcr_stop_on_trig_evt <= 1'b0;
          ffcr_stop_on_fl       <= 1'b0;
          ffcr_trig_on_fl       <= 1'b0;
          ffcr_trig_on_trig_evt <= 1'b0;
          ffcr_trig_on_trigin   <= 1'b0;
          ffcr_flsh_on_trig_evt <= 1'b0;
          ffcr_flsh_on_flshin   <= 1'b0;
        end
      else if (ffcr_wr_en)
        begin
          ffcr_stop_on_trig_evt <= apb_wdata[13];
          ffcr_stop_on_fl       <= apb_wdata[12];
          ffcr_trig_on_fl       <= apb_wdata[10];
          ffcr_trig_on_trig_evt <= apb_wdata[9];
          ffcr_trig_on_trigin   <= apb_wdata[8];
          ffcr_flsh_on_trig_evt <= apb_wdata[5];
          ffcr_flsh_on_flshin   <= apb_wdata[4];
        end
  end // p_ffcr

  always @(posedge cxtmc_clk or negedge RESETn)
    begin : p_ffcr_ften_trig
      if (!RESETn)
        begin
          ffcr_en_trig_ins   <= 1'b0;
          ffcr_en_formatting <= 1'b0;
        end
      else if (ffcr_wr_en_bits01)
        begin
          ffcr_en_trig_ins   <= apb_wdata[1];
          ffcr_en_formatting <= apb_wdata[0];
        end
  end // p_ffcr_ften_trig

//-----------------------------------------------------------------------------
// FFCR outputs to other TMC sub-modules
// StopOnTrigEvt, FOnTrigEvt and TrigOnTrigEvt bits are functional only in 
// Circular Buffer mode.
// The TrigOnFl, TrigOnTrigEvt and TrigOnTrigIn bits is allowed to take effect 
// only if formatting is enabled and Trigger Insertion is enabled.
// For backwards-compatibility with earlier versions of the ETB, if the EnTI 
// bit is set, formatting is enabled even if the EnFt bit is not set. 
// The EnFt bit can be 0 only in Circular Buffer mode.
//-----------------------------------------------------------------------------
  assign ffcr_stop_on_trig_evt_masked = circ_buf_mode & ffcr_stop_on_trig_evt;
  assign ffcr_trig_on_fl_masked       = ffcr_trig_on_fl &
                                        ffcr_en_trig_ins;
  assign ffcr_trig_on_trig_evt_masked = circ_buf_mode & ffcr_en_trig_ins
                                        & ffcr_trig_on_trig_evt;
  assign ffcr_trig_on_trigin_masked   = ffcr_trig_on_trigin &
                                        ffcr_en_trig_ins;
  assign ffcr_flsh_on_trig_evt_masked = circ_buf_mode & ffcr_flsh_on_trig_evt;
  assign ffcr_en_formatting_masked = ~circ_buf_mode | ffcr_en_formatting |
                                      ffcr_en_trig_ins;

//-----------------------------------------------------------------------------
// FFCR - FOnMan - Once set by a register write, clear FOnMan bit only after 
// the flush request has been serviced. 
//-----------------------------------------------------------------------------
  assign ffcr_f_on_man_wr_en = ffcr_wr_en | flush_man_clr;
  assign  nxt_ffcr_f_on_man  = ~flush_man_clr &
                               (ffcr_flush_man | (ffcr_wr_en &
                                apb_wdata[6] & ctl_trace_capt_en));

  always @(posedge cxtmc_clk or negedge RESETn)
    begin : p_ffcr_flush_man
      if (!RESETn)
        ffcr_flush_man <= 1'b0;
      else if (ffcr_f_on_man_wr_en)
        ffcr_flush_man <=  nxt_ffcr_f_on_man;
  end // p_ffcr_flush_man

generate
  if (CXTMC_ATBM_AXIM_CFG == CXTMC_CFG_ETF) // ETF configuration
    begin
      reg  drain_buffer_reg;   // DrainBuffer bit in FFCR
      wire  nxt_drain_buffer;  // D-input of drain_buffer_reg

      //-----------------------------------------------------------------------
      // If the DrainBuffer bit is set, allow draining of the trace data 
      // through the ATB master interface till the formatter has stopped and
      // the trace memory has been drained by the unformatter.
      // If TraceCaptEn is cleared while draining is in progress, the TMC
      // aborts the drain process.
      //-----------------------------------------------------------------------
      assign nxt_drain_buffer = (ffcr_wr_en & apb_wdata[14] & tmc_ready
                                 & ctl_trace_capt_en & circ_buf_mode &
                                 ffcr_en_formatting_masked) |
                                (drain_buffer_reg &
                                 ~(~ctl_trace_capt_en | (unformatter_empty &
                                                     trace_mem_empty)));

      always @(posedge cxtmc_clk or negedge RESETn)
        begin : p_drain_buffer
          if (!RESETn)
            drain_buffer_reg <= 1'b0;
          else
            drain_buffer_reg <=  nxt_drain_buffer;
        end // p_drain_buffer
      assign drain_buffer_en = drain_buffer_reg;
    end
  else
    assign drain_buffer_en = 1'b0;
endgenerate

//-----------------------------------------------------------------------------
// PSCR 
//-----------------------------------------------------------------------------
  assign pscr_wr_en = reg_wr_en & pscr_sel & tmc_ready & ~ctl_trace_capt_en;

  always @(posedge cxtmc_clk or negedge RESETn)
    begin : p_pscr
      if (!RESETn)
        pscr <= CXTMC_PSCR_RST_VAL;
      else if (pscr_wr_en)
        pscr <= apb_wdata[4:0];
  end // p_pscr     

//-----------------------------------------------------------------------------
// Write enables for Integration test registers ITATBMCTR0, ITATBMCTR1 and
// ITATBMDATA0
//-----------------------------------------------------------------------------
generate
  if (CXTMC_ATBM_AXIM_CFG == CXTMC_CFG_ETF)
    begin
      wire it_atb_m_ctr_0_sel; // Address decode for ITATBMCTR0 register
      wire it_atb_m_ctr_1_sel; // Address decode for ITATBMCTR1 register
      wire it_atb_m_data_0_sel; // Address decode for ITATBMDATA0 register
      assign it_atb_m_ctr_0_sel = (apb_addr == CXTMC_IT_ATBM_CTR_0);
      assign it_atb_m_ctr_1_sel = (apb_addr == CXTMC_IT_ATBM_CTR_1);
      assign it_atb_m_data_0_sel = (apb_addr == CXTMC_IT_ATBM_DATA_0);
      assign it_atb_m_ctr_0_wr_en = reg_wr_en & it_atb_m_ctr_0_sel &
                                     it_ctrl & tmc_ready & ~ctl_trace_capt_en;
      assign it_atb_m_ctr_1_wr_en = reg_wr_en & it_atb_m_ctr_1_sel &
                                     it_ctrl & tmc_ready & ~ctl_trace_capt_en;
      assign it_atb_m_data_0_wr_en = reg_wr_en & it_atb_m_data_0_sel &
                                     it_ctrl & tmc_ready & ~ctl_trace_capt_en;
    end
  else
    begin
      assign it_atb_m_ctr_0_wr_en  = 1'b0;
      assign it_atb_m_ctr_1_wr_en  = 1'b0;
      assign it_atb_m_data_0_wr_en = 1'b0;
    end
endgenerate

//-----------------------------------------------------------------------------
// Write enables for Integration test registers ITMISCOP0 and ITATBCTR2
//-----------------------------------------------------------------------------
  assign it_misc_op_0_wr_en   = reg_wr_en & it_misc_op_0_sel &
                                     it_ctrl & tmc_ready & ~ctl_trace_capt_en;
  assign it_atb_ctr_2_wr_en   = reg_wr_en & it_atb_ctr_2_sel &
                                     it_ctrl & tmc_ready & ~ctl_trace_capt_en;

//-----------------------------------------------------------------------------
// ITCTRL - Integration Mode Control Register.
// When set, the device is in integration mode to enable topology detection
// or integration testing to be carried out. At reset ITCTRL is disabled
//-----------------------------------------------------------------------------
  assign it_ctrl_wr_en = reg_wr_en & it_ctrl_sel & tmc_ready & 
                         ~ctl_trace_capt_en;

  always @(posedge cxtmc_clk or negedge RESETn)
    begin : p_it_ctrl
      if (!RESETn)
        it_ctrl <= 1'b0;
      else if (it_ctrl_wr_en)
        it_ctrl <= apb_wdata[0];
    end // p_it_ctrl

//-----------------------------------------------------------------------------
// Claim tag
// Used by software tools when about to begin an access session to the TMC
// Setting bits indicates to any other interrogating tools that this device
// is being programmed or has been programmed.
//
// Accessed using two registers:
// 0xFA0 - Claim Tag Set
//       - Read:  0 - claim bit not implemented, 1 - claim bit implemented
//       - Write: 0 - no effect, 1 - set claim bit
//
// 0xFA1 - Claim Tag Clear
//       - Read:  Current value of claim bit
//       - Write: 0 - no effect, 1 - clear claim bit
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
// The claim_tag_wr_en is the enable signal for writing into the claim tag
// register.The enable signal is set when either the claim set or claim
// claim clear registers is written.
//-----------------------------------------------------------------------------
  assign claim_tag_wr_en = reg_wr_en &
                           (claim_tag_set_sel | claim_tag_clr_sel);

//-----------------------------------------------------------------------------
// Logic for the  nxt_claim_tag value.
// Writing '0' has no effect on the Claim Tag Set register or the Claim Tag
// Clear register. 
//-----------------------------------------------------------------------------
  assign  nxt_claim_tag = claim_tag_set_sel ?
                              (claim_tag | apb_wdata[3:0]):
                              (claim_tag & ~apb_wdata[3:0]);

//-----------------------------------------------------------------------------
// Sequential block for writing into the claim tag register.
// Claim tag set register     : Offset 0xFA0 ( R/W )
// Claim tag clear register   : Offset 0xFA4 ( R/W )
//-----------------------------------------------------------------------------
  always @(posedge cxtmc_clk or negedge RESETn)
  begin : p_claim_tag_wr
    if (!RESETn)
      claim_tag <= {4{1'b0}};
    else if(claim_tag_wr_en)
      claim_tag <=  nxt_claim_tag;
   end // block: p_claim_tag_wr

//-----------------------------------------------------------------------------
// Read enables for registers
//-----------------------------------------------------------------------------
// RSZ register
assign rsz_rd_en = reg_read & rsz_sel;

// STS register
assign sts_rd_en = reg_read & sts_sel;

//-----------------------------------------------------------------------------
// RRD register
// Send out a read request pulse (rrd_rd_req) when an APB read request is 
// initiated to RRD. If the RRD read request cannot be serviced, return 
// 32'hFFFFFFFF (assert rrd_rd_err for the read data mux).
//
// RRD accesses change the state of the TMC, so they are allowed only when the
// device is unlocked.
//
// In Circular buffer mode, RRD reads are allowed only when the formatter has
// stopped and the trace memory is not empty. Also, in ETF configuration,
// in this mode, RRD reads are disallowed if the DrainBuffer bit in FFCR
// register has been set and draining of trace data is in progress through 
// the ATB Master port.
// In Software-read-FIFO mode, RRD reads are allowed only when the trace FIFO
// is non-empty.
// In Hardware-read-FIFO mode, RRD reads are not allowed - trace data can be
// drained out only through the ATB master interface. 
// If an error has occurred on AXI system memory, mem_err input is set. In 
// this case, all accesses to RRD return 32'hFFFFFFFF with an error on 
// PSLVERRDBG. Note that mem_err can occur only in the ETR configuration.
//-----------------------------------------------------------------------------
assign rrd_rd_valid = (dev_unlocked | apb_addr31) & ~mem_err &
                      (tmc_disabled | 
                       (ctl_trace_capt_en & rrd_rd_valid_mode_decode));

assign rrd_rd_valid_mode_decode = (sw_fifo_mode & swf_rrd_rd_valid) | 
                                  (circ_buf_mode & cbm_rrd_rd_valid);
assign swf_rrd_rd_valid = ~trace_mem_empty;
assign cbm_rrd_rd_valid = ~(trace_mem_empty | (~tmc_ready) | drain_buffer_en);


assign nxt_rrd_rd_valid_rd_start = reg_read_det ? rrd_rd_valid : 
                                                  rrd_rd_valid_rd_start;

  // Store the value of rrd_rd_valid at the start of a read access so that a
  // change in its status during a read access does not affect the on-going
  // read access.
  always @(posedge cxtmc_clk or negedge RESETn)
  begin : p_rrd_valid_start
    if (!RESETn)
      rrd_rd_valid_rd_start <= 1'b0;
    else
      rrd_rd_valid_rd_start <= nxt_rrd_rd_valid_rd_start;
   end // block: p_rrd_valid_start

assign rrd_rd_err  = reg_read & rrd_sel & ~nxt_rrd_rd_valid_rd_start;
assign rrd_rd_req = reg_read_det & rrd_sel & nxt_rrd_rd_valid_rd_start;

assign  nxt_rrd_hold = rrd_rd_req |
                       (rrd_hold & apb_valid);

  // rrd_hold flop
  always @(posedge cxtmc_clk or negedge RESETn)
  begin : p_rrd_hold
    if (!RESETn)
      rrd_hold <= 1'b0;
    else
      rrd_hold <=  nxt_rrd_hold;
   end // block: p_rrd_hold


// RRP register
assign rrp_rd_en = reg_read & rrp_sel;

// RWP register
assign rwp_rd_en = reg_read & rwp_sel;

// TRG register
assign trg_rd_en = reg_read & trg_sel;

// CTL register
assign ctl_rd_en = reg_read & ctl_sel;

// MODE register
assign mode_rd_en = reg_read & mode_sel;

// LBUFLEVEL register
// LBUFLEVEL register reads alter internal state since the value returned
// is the max fill level since the last read occurred to this register.
// Reads to this register are hence lock-controlled.
assign lat_buf_level_rd_en = reg_read & lat_buf_level_sel &
                             (dev_unlocked | apb_addr31);

// lat_buf_level_rd_done is asserted for one clock duration when the
// LBUFLEVEL register is read.
assign lat_buf_level_rd_done = lat_buf_level_sel & ~pwritedbg_r &
                               ~apb_valid & apb_valid_reg;

// CBUFLEVEL register
assign c_buf_level_rd_en = reg_read & c_buf_level_sel;

// BUFWM register
assign buf_wm_rd_en = reg_read & buf_wm_sel;

// FFSR register
assign ffsr_rd_en = reg_read & ffsr_sel;

// FFCR register
assign ffcr_rd_en = reg_read & ffcr_sel;

// PSCR register
assign pscr_rd_en = reg_read & pscr_sel;

// ITATBMCTR2 register
generate
  if (CXTMC_ATBM_AXIM_CFG == CXTMC_CFG_ETF)
    begin
      wire it_atb_m_ctr_2_sel; // Address decode for ITATBMCTR2 register
      assign it_atb_m_ctr_2_sel = (apb_addr == CXTMC_IT_ATBM_CTR_2);
      assign it_atb_m_ctr_2_rd_en = reg_read & it_atb_m_ctr_2_sel;
    end
  else
    assign it_atb_m_ctr_2_rd_en = 1'b0;
endgenerate

// ITTRFLIN register
assign it_tr_flin_rd_en = reg_read & it_tr_flin_sel;

// ITATBDATA0 register
assign it_atb_data_0_rd_en = reg_read & it_atb_data_0_sel;

// ITATBCTR1 register
assign it_atb_ctr_1_rd_en = reg_read & it_atb_ctr_1_sel;

// ITATBCTR0 register
assign it_atb_ctr_0_rd_en = reg_read & it_atb_ctr_0_sel;

// ITCTRL register
assign it_ctrl_rd_en = reg_read & it_ctrl_sel;

// CLAIMSET register
assign claim_tag_set_rd_en = reg_read & claim_tag_set_sel;

// CLAIMCLR register
assign claim_tag_clr_rd_en = reg_read & claim_tag_clr_sel;

// LOCKSTATUS register
// Mask out the lock status on accesses with PADDRDBG31=='1'
// The OR-of-ANDs gives the appearance of no lock-access mechanism present
assign lock_status_rd_en = reg_read & lock_status_sel & ~apb_addr31;

// AUTHSTATUS register
assign auth_status_rd_en = reg_read & auth_status_sel;

// DEVID register
assign device_id_rd_en = reg_read & device_id_sel;

// DEVTYPE register
assign device_type_rd_en = reg_read & device_type_sel;

// PERIPHIDx registers
assign periph_id_0_rd_en = reg_read & periph_id_0_sel;
assign periph_id_1_rd_en = reg_read & periph_id_1_sel;
assign periph_id_2_rd_en = reg_read & periph_id_2_sel;
assign periph_id_4_rd_en = reg_read & periph_id_4_sel;
assign periph_id_5_rd_en = reg_read & periph_id_5_sel;
assign periph_id_6_rd_en = reg_read & periph_id_6_sel;
assign periph_id_7_rd_en = reg_read & periph_id_7_sel;

// COMPIDx registers
assign comp_id_0_rd_en = reg_read & comp_id_0_sel;
assign comp_id_1_rd_en = reg_read & comp_id_1_sel;
assign comp_id_2_rd_en = reg_read & comp_id_2_sel;
assign comp_id_3_rd_en = reg_read & comp_id_3_sel;

//-----------------------------------------------------------------------------
// Read data zero-padding for registers
//-----------------------------------------------------------------------------
// STS register
// The status bits TMCReady and FtEmpty are functionally same
// The Empty bit in the STS register is valid only when TraceCaptEn is 1.
assign trace_mem_empty_sts = ctl_trace_capt_en ? trace_mem_empty : 1'b0;
// When the TMC is starting up after being enabled, the triggered input is
// masked. This is to account for the latency in initialising the triggered
// status bit after trace capture is enabled.
assign triggered_sts       = triggered & ~ptr_clr;
assign sts_rd_data = {{26{1'b0}}, mem_err, trace_mem_empty_sts, ACQCOMP,
                       tmc_ready, triggered_sts, FULL};

wire nxt_tmc_ready;   // D-input of tmc_ready
generate
  if (CXTMC_ATBM_AXIM_CFG == CXTMC_CFG_ETF)
    // In the ETF configuration, TMCReady status bit is set only after the
    // formatter, the Write Buffer and the Unformatter are all empty.
    // If TMC operation is aborted, do not check for trace_mem_empty since
    // trace data is discarded.
    assign nxt_tmc_ready = tmc_abort ?
                             (unformatter_empty & wb_empty &
                              ft_stopped & ~ptr_clr) :
                           drain_buffer_en ?
                             (unformatter_empty & trace_mem_empty) :
                           hw_fifo_mode ?
                             (ft_stopped & ~ptr_clr & wb_empty &
                              trace_mem_empty & unformatter_empty) :
                           (sw_fifo_mode | circ_buf_mode) ?
                              (ft_stopped & wb_empty & ~ptr_clr) : 1'b1;

  else if (CXTMC_ATBM_AXIM_CFG == CXTMC_CFG_ETR)
    // In the ETR configuration, TMCReady must be asserted only after the AXI 
    // interface receives responses for all outstanding transfers and the
    // Scatter-gather block is idle
    assign nxt_tmc_ready = ft_stopped & wb_empty & axi_intf_ready &
                           sg_idle & (~ptr_clr);
  else // CXTMC_CFG_ETB
    assign nxt_tmc_ready = ft_stopped & wb_empty & ~ptr_clr;
endgenerate

// Clock tmc_ready to ensure timing - wb_empty is asserted one clock before
// the write to memory completes.
  always @(posedge cxtmc_clk or negedge RESETn)
    begin : p_tmc_ready
      if (!RESETn)
        begin
          tmc_ready       <= 1'b1;
        end
      else
        begin
          tmc_ready       <= nxt_tmc_ready;
        end
    end // block: p_tmc_ready

// RRP register
// 32-bits wide in ETR configuration
generate
  if ((CXTMC_ATBM_AXIM_CFG == CXTMC_CFG_ETR) || 
      (CXTMC_MEM_BYTE_ADDR_WIDTH == 32))
    assign rrp_rd_data = rrp[31:0];
  else
    assign rrp_rd_data = {{(32-CXTMC_MEM_BYTE_ADDR_WIDTH){1'b0}}, rrp};
endgenerate

// RWP register
// 32-bits wide in ETR configuration
generate
  if ((CXTMC_ATBM_AXIM_CFG == CXTMC_CFG_ETR) || 
      (CXTMC_MEM_BYTE_ADDR_WIDTH == 32))
    assign rwp_rd_data = rwp[31:0];
  else
    assign rwp_rd_data = {{32-CXTMC_MEM_BYTE_ADDR_WIDTH{1'b0}}, rwp};
endgenerate

// TRG register
generate
  if (CXTMC_ATBM_AXIM_CFG == CXTMC_CFG_ETR)
    assign trg_rd_data = trg;
  else
    assign trg_rd_data = {{32-CXTMC_TRG_WIDTH{1'b0}}, trg};
endgenerate

// CTL register
assign ctl_rd_data = {{31{1'b0}}, ctl_trace_capt_en};

// MODE register
assign mode_rd_data = {{30{1'b0}}, mode};

// LBUFLEVEL register
// LBUFLEVEL register returns the fill level of the trace memory in
// terms of 32-bit words. The register needs an extra MSBit to 
// represent the maximum fill level when full.
// If the TMC is programmed for Scatter-Gather operation in ETR configuration,
// the LBUFLEVEL register returns 0 on reads
    assign lat_buf_level_rd_data = {{32-CXTMC_FILL_LEVEL_WIDTH{1'b0}},
                                     lat_buf_level};

// CBUFLEVEL register
// If the TMC is programmed for Scatter-Gather operation in ETR configuration,
// the CBUFLEVEL register returns 0 on reads
    assign c_buf_level_rd_data = {{32-CXTMC_FILL_LEVEL_WIDTH{1'b0}},
                                   c_buf_level};

// BUFWM register
assign buf_wm_rd_data = {{32-CXTMC_FILL_LEVEL_WIDTH+1{1'b0}}, buf_wm};

// FFSR register
// FtStopped and ACQCOMP are of identical behaviour
assign ffsr_rd_data = {{30{1'b0}}, ACQCOMP, fl_in_prog};

// FFCR register
assign ffcr_rd_data = {{18{1'b0}}, ffcr_stop_on_trig_evt, ffcr_stop_on_fl,
                      1'b0, ffcr_trig_on_fl, ffcr_trig_on_trig_evt,
                      ffcr_trig_on_trigin, 1'b0, ffcr_flush_man,
                      ffcr_flsh_on_trig_evt, ffcr_flsh_on_flshin,
                      2'b00, ffcr_en_trig_ins, ffcr_en_formatting};

// PSCR register
assign pscr_rd_data = {{27{1'b0}}, pscr};

// ITATBMCTR2 register
generate
  if (CXTMC_ATBM_AXIM_CFG == CXTMC_CFG_ETF)
    begin
      reg        it_atb_m_ctr_2_syncreqm_reg;
                                  // Registered version of SYNCREQM input
      reg        it_atb_m_ctr_2_afvalidm_reg;
                                  // Registered version of AFVALIDM input
      reg        it_atb_m_ctr_2_atreadym_reg;
                                  // Registered version of ATREADYM input

//-----------------------------------------------------------------------------
// Sampling SYNCREQM, AFVALIDM and ATREADYM for integration register reads
// Sampling helps ease timing through APB read mux from these inputs 
//-----------------------------------------------------------------------------
      always @(posedge cxtmc_clk or negedge RESETn)
      begin : p_it_atbm_ctr2_reg
        if (!RESETn)
          begin
            it_atb_m_ctr_2_syncreqm_reg <= 1'b0;
            it_atb_m_ctr_2_afvalidm_reg <= 1'b0;
            it_atb_m_ctr_2_atreadym_reg <= 1'b0;
          end
        else
          begin
            it_atb_m_ctr_2_syncreqm_reg <= it_atb_m_ctr_2_syncreqm;
            it_atb_m_ctr_2_afvalidm_reg <= it_atb_m_ctr_2_afvalidm;
            it_atb_m_ctr_2_atreadym_reg <= it_atb_m_ctr_2_atreadym;
          end
      end // block: p_it_atbm_ctr2_reg

      assign it_atb_m_ctr_2_rd_data = {{29{1'b0}},
                                      it_atb_m_ctr_2_syncreqm_reg,
                                      it_atb_m_ctr_2_afvalidm_reg,
                                      it_atb_m_ctr_2_atreadym_reg};
    end
  else
    assign it_atb_m_ctr_2_rd_data = 32'h00000000;
endgenerate

// ITTRFLIN register
assign it_tr_flin_rd_data = {{30{1'b0}}, flushin_reg, trigin_reg};

// ITATBDATA0 register
assign it_atb_data_0_rd_data = {{32-CXTMC_ITATBDATA0_WIDTH{1'b0}},
                                 it_atb_data_0};

// ITATBCTR1 register
assign it_atb_ctr_1_rd_data = {{25{1'b0}}, atids_p1};

// ITATBCTR0 register
assign it_atb_ctr_0_rd_data = {{24-CXTMC_ATBYTES_WIDTH{1'b0}}, atbytess_p1,
                               {6{1'b0}}, af_ready_reg, atvalids_p1};

// ITCTRL register
assign it_ctrl_rd_data = {{31{1'b0}}, it_ctrl};

// CLAIMSET register
assign claim_tag_set_rd_data = {{28{1'b0}}, CXTMC_CLAIMSET_VAL};

// CLAIMCLR register
assign claim_tag_clr_rd_data = {{28{1'b0}}, claim_tag};

// LOCKSTATUS register
assign lock_status_rd_data = {{29{1'b0}},
                              CXTMC_LOCKSTATUS_8BIT_VAL,
                              ~dev_unlocked,
                              CXTMC_LOCKSTATUS_PRESENT_VAL};

// AUTHSTATUS register
generate
  if (CXTMC_ATBM_AXIM_CFG == CXTMC_CFG_ETR)
    // In the ETR configuration, the trace buffer is implemented on system
    // memory. TMC accesses to system memory are controlled by the DBGEN
    // and SPIDEN inputs.
    assign auth_status_rd_data = {{24{1'b0}},
                                  CXTMC_AUTHSTATUS_SNID_VAL,  1'b0,
                                  1'b1,
                                    (auth_status_dbgen & auth_status_spiden),
                                  CXTMC_AUTHSTATUS_NSNID_VAL, 1'b0,
                                  1'b1, auth_status_dbgen};
  else
    assign auth_status_rd_data = {{24{1'b0}},
                                  CXTMC_AUTHSTATUS_SNID_VAL,  1'b0,
                                  CXTMC_AUTHSTATUS_SID_VAL,   1'b0,
                                  CXTMC_AUTHSTATUS_NSNID_VAL, 1'b0,
                                  CXTMC_AUTHSTATUS_NSID_VAL,  1'b0};
endgenerate

// DEVID register
assign device_id_rd_data = {{17{1'b0}},
                            CXTMC_DEVID_WBUF_DEPTH,
                            CXTMC_DEVID_MEMWIDTH,
                            CXTMC_DEVID_CONFIGTYPE,
                            CXTMC_DEVID_CLK_SCHEME,
                            CXTMC_DEVID_ATB_PORT_COUNT};

// DEVTYPE register
assign device_type_rd_data = {{24{1'b0}}, CXTMC_DEVTYPE_VAL};

// PERIPHIDx registers
assign periph_id_0_rd_data = {{24{1'b0}}, CXTMC_PERIPHID0_VAL};
assign periph_id_1_rd_data = {{24{1'b0}}, CXTMC_PERIPHID1_VAL};
assign periph_id_2_rd_data = {{24{1'b0}}, CXTMC_PERIPHID2_VAL};
assign periph_id_4_rd_data = {{24{1'b0}}, CXTMC_PERIPHID4_VAL};
assign periph_id_5_rd_data = {{24{1'b0}}, CXTMC_PERIPHID5_VAL};
assign periph_id_6_rd_data = {{24{1'b0}}, CXTMC_PERIPHID6_VAL};
assign periph_id_7_rd_data = {{24{1'b0}}, CXTMC_PERIPHID7_VAL};

// COMPIDx registers
assign comp_id_0_rd_data = {{24{1'b0}}, CXTMC_COMPID0_VAL};
assign comp_id_1_rd_data = {{24{1'b0}}, CXTMC_COMPID1_VAL};
assign comp_id_2_rd_data = {{24{1'b0}}, CXTMC_COMPID2_VAL};
assign comp_id_3_rd_data = {{24{1'b0}}, CXTMC_COMPID3_VAL};

//-----------------------------------------------------------------------------
// Read data mux
//-----------------------------------------------------------------------------
  assign read_data   = (
                        ({32{rsz_rd_en}} & rsz_rd_data) |
                        ({32{sts_rd_en}} & sts_rd_data) |
                        ({32{rrd_hold}} & rrd) |
                        // rrd_rd_err indicates an RRD read that cannot be
                        //   serviced
                        ({32{rrd_rd_err}} & 32'hFFFFFFFF) |
                        ({32{rrp_rd_en}} & rrp_rd_data) |
                        ({32{rwp_rd_en}} & rwp_rd_data) |
                        ({32{trg_rd_en}} & trg_rd_data) |
                        ({32{ctl_rd_en}} & ctl_rd_data) |
                        ({32{mode_rd_en}} & mode_rd_data) |
                        ({32{lat_buf_level_rd_en}} & lat_buf_level_rd_data) |
                        ({32{c_buf_level_rd_en}} & c_buf_level_rd_data) |
                        ({32{buf_wm_rd_en}} & buf_wm_rd_data) |
                        ({32{rrp_hi_rd_en}} & rrp_hi_rd_data) |
                        ({32{rwp_hi_rd_en}} & rwp_hi_rd_data) |
                        ({32{axi_ctl_rd_en}} & axi_ctl_rd_data) |
                        ({32{dba_lo_rd_en}} & dba_lo_rd_data) |
                        ({32{dba_hi_rd_en}} & dba_hi_rd_data) |
                        ({32{ffsr_rd_en}} & ffsr_rd_data) |
                        ({32{ffcr_rd_en}} & ffcr_rd_data) |
                        ({32{pscr_rd_en}} & pscr_rd_data) |
                        ({32{it_atb_m_ctr_2_rd_en}} & it_atb_m_ctr_2_rd_data) |
                        ({32{it_tr_flin_rd_en}} & it_tr_flin_rd_data) |
                        ({32{it_atb_data_0_rd_en}} & it_atb_data_0_rd_data) |
                        ({32{it_atb_ctr_1_rd_en}} & it_atb_ctr_1_rd_data) |
                        ({32{it_atb_ctr_0_rd_en}} & it_atb_ctr_0_rd_data) |
                        ({32{it_ctrl_rd_en}} & it_ctrl_rd_data) |
                        ({32{claim_tag_set_rd_en}} & claim_tag_set_rd_data) |
                        ({32{claim_tag_clr_rd_en}} & claim_tag_clr_rd_data) |
                        ({32{lock_status_rd_en}} & lock_status_rd_data) |
                        ({32{auth_status_rd_en}} & auth_status_rd_data) |
                        ({32{device_id_rd_en}} & device_id_rd_data) |
                        ({32{device_type_rd_en}} & device_type_rd_data) |
                        ({32{periph_id_0_rd_en}} & periph_id_0_rd_data) |
                        ({32{periph_id_1_rd_en}} & periph_id_1_rd_data) |
                        ({32{periph_id_2_rd_en}} & periph_id_2_rd_data) |
                        ({32{periph_id_4_rd_en}} & periph_id_4_rd_data) |
                        ({32{periph_id_5_rd_en}} & periph_id_5_rd_data) |
                        ({32{periph_id_6_rd_en}} & periph_id_6_rd_data) |
                        ({32{periph_id_7_rd_en}} & periph_id_7_rd_data) |
                        ({32{comp_id_0_rd_en}} & comp_id_0_rd_data) |
                        ({32{comp_id_1_rd_en}} & comp_id_1_rd_data) |
                        ({32{comp_id_2_rd_en}} & comp_id_2_rd_data) |
                        ({32{comp_id_3_rd_en}} & comp_id_3_rd_data)
                       );

//-----------------------------------------------------------------------------
// In the Integration test mode, the ACQCOMP output is directly controlled by 
// writes to the ITMISCOP0 register. In the functional mode, the ACQCOMP output
// is controlled by TMCReady and TraceCaptEn.
//-----------------------------------------------------------------------------
assign nxt_acqcomp = it_ctrl ? (it_misc_op_0_wr_en ? apb_wdata[0] :
                                                         ACQCOMP) :
                                   acqcomp_func;

assign acqcomp_clk_en = ~it_ctrl | it_misc_op_0_wr_en;

//-----------------------------------------------------------------------------
// ACQCOMP output
//-----------------------------------------------------------------------------
  always @(posedge cxtmc_clk or negedge RESETn)
  begin : p_acqcomp
    if (!RESETn)
      ACQCOMP <= 1'b1;
    else if (acqcomp_clk_en)
      ACQCOMP <= nxt_acqcomp;
  end // block: p_acqcomp

//-----------------------------------------------------------------------------
// In the functional mode of operation, ACQCOMP behaviour is as follows:
// - Default value is 1
// - When TraceCaptEn is set, acqcomp_func reflects the value of TMCReady.
//   However, acqcomp_func is not affected during drain (in ETF config) or
//   during RRD reads after captured trace has been written to memory (in ETR
//   config).
// - When TraceCaptEn is cleared, acqcomp_func reflects the value of TMCReady
//   till TMCReady goes high. 
// In the ETB config, ACQCOMP must follow TMCReady in the window from the
// setting of TraceCaptEn till the occurrence of the condition (TMCReady &
// ~TraceCaptEn).
//-----------------------------------------------------------------------------
generate
  if (CXTMC_ATBM_AXIM_CFG == CXTMC_CFG_ETF) // ETF configuration
    begin
      wire nxt_drain_in_prog; // D-input of drain_in_prog

      assign acqcomp_func = tmc_enabled ? (tmc_ready | drain_in_prog) : 1'b1;
      //------------------------------------------------------------------------
      // If DrainBuffer bit has been set, this is remembered till TMCReady is 
      // returned so that ACQCOMP can be unaffected by TMCReady in this 
      // duration.
      //------------------------------------------------------------------------
      assign nxt_drain_in_prog = drain_buffer_en | 
                                 (drain_in_prog & ~tmc_ready); 

      always @(posedge cxtmc_clk or negedge RESETn)
      begin : p_drain_in_prog
        if (!RESETn)
          drain_in_prog <= 1'b0;
        else
          drain_in_prog <= nxt_drain_in_prog;
      end // block: p_drain_in_prog
    end
  else if (CXTMC_ATBM_AXIM_CFG == CXTMC_CFG_ETR) // ETR configuration
    begin
      wire nxt_tmc_writes_done; // D-input of tmc_writes_done
      reg  tmc_writes_done;     // To generate ACQCOMP, check whether all
                                // trace captured has been written to memory

      //------------------------------------------------------------------------
      // Once trace capture is enabled, pull tmc_writes_done low. Wait for
      // tmc_ready to go high to pull tmc_writes_done high again.
      // Further changes in tmc_ready due to any RRD reads do not affect
      // tmc_writes_done and hence ACQCOMP.
      //------------------------------------------------------------------------
      assign nxt_tmc_writes_done = 
               ~(ctl_trace_capt_en & ~ctl_trace_capt_en_reg) &
                (tmc_writes_done | tmc_ready);
     
      always @(posedge cxtmc_clk or negedge RESETn)
        begin : p_tmc_writes_done_etr
          if (!RESETn)
            begin
              tmc_writes_done <= 1'b1;
            end
          else
            begin
              tmc_writes_done <= nxt_tmc_writes_done;
            end
        end // block: p_tmc_writes_done_etr

      assign acqcomp_func = tmc_writes_done;
    end
  else // ETB configuration
    assign acqcomp_func = (tmc_enabled) ? tmc_ready : 1'b1;
endgenerate
    
assign tmc_enabled  = (ctl_trace_capt_en & ~ctl_trace_capt_en_reg) |
                      (tmc_enabled_hold & ~(tmc_ready & ~ctl_trace_capt_en));

  always @(posedge cxtmc_clk or negedge RESETn)
  begin : p_tmc_enabled_hold
    if (!RESETn)
      tmc_enabled_hold <= 1'b0;
    else
      tmc_enabled_hold <= tmc_enabled;
  end // block: p_tmc_enabled_hold


//-----------------------------------------------------------------------------
// TMC is considered disabled when TraceCaptEn=0 and TMCReady=1. If 
// TraceCaptEn is written 0, the TMC drains its internal pipelines before
// asserting TMCReady.
// The tmc_disabled signal is cleared when TraceCaptEn is set and is held until
// the condition TraceCaptEn=0 and TMCReady=1 occurs.
//-----------------------------------------------------------------------------
assign tmc_disabled = ~tmc_enabled;

//-----------------------------------------------------------------------------
// If the TMC is enabled in HW-FIFO mode or SW-FIFO mode and TraceCaptEn is
// cleared by a software write, the TMC drains trace data in its pipeline
// and then stops. During this phase, the FIFO is overwritten even if it is 
// full (leading to data corruption) so as to bring the TMC to its 
// quiescent state as gracefully and quickly as possible.
// In Circular buffer mode, it is legal to clear TraceCaptEn even if TMCReady
// is 0 (legacy Circular-buffer mode operation).
//-----------------------------------------------------------------------------
assign tmc_abort = (~ctl_trace_capt_en & ctl_trace_capt_en_reg &
                   (sw_fifo_mode | hw_fifo_mode | drain_buffer_en)) |
                   (tmc_abort_reg & ~tmc_ready);

  always @(posedge cxtmc_clk or negedge RESETn)
  begin : p_tmc_abort_reg
    if (!RESETn)
      tmc_abort_reg <= 1'b0;
    else
      tmc_abort_reg <= tmc_abort;
  end // block: p_tmc_abort_reg

//-----------------------------------------------------------------------------
// If there is unread data in the APB read FIFO, it is discarded when 
// trace capture is enabled or RRP/RRPHI registers are written to.
// When TraceCaptEn bit is cleared, any unread data in the APB read FIFO is
// discarded unless the TMC is in Circular buffer mode.
//-----------------------------------------------------------------------------
assign apbreadfifo_clr = ptr_clr | rrp_wr_en | rrp_hi_wr_en | 
                         (ctl_trace_capt_en_1_0 & ~circ_buf_mode_reg);

//-----------------------------------------------------------------------------
// Error response on the APB
// In the ETB/ETF configurations, no error response is returned on the APB.
// In the ETR configuration, error response could occur if a read/write
// transfer response on the AXI indicates an error has occurred.
// Once the AXI interface has asserted mem_err, all accesses to RRD and RWD
// return error on PSLVERRDBG. This includes acesses that are in progress,
// where the mem_err could be the result of a response to an earlier
// transfer.
//-----------------------------------------------------------------------------
generate
  if (CXTMC_ATBM_AXIM_CFG == CXTMC_CFG_ETR) // ETR configuration
    assign apb_err = mem_err & apb_valid & (rrd_sel | rwd_sel);
  else
    assign apb_err = 1'b0;
endgenerate

`ifdef ARM_ASSERT_ON
//-----------------------------------------------------------------------------
// OVL Assertions
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// Only one read enable must be asserted at a time
//-----------------------------------------------------------------------------
  assert_zero_one_hot #(`OVL_ERROR, 39, `OVL_ASSERT,
    "OVL Message : cxtmc_apbif - Multiple register read enables asserted at the same time")
      uzovl_cxtmc_apbif_rd_en
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   ({rsz_rd_en, sts_rd_en, rrp_rd_en, rwp_rd_en, trg_rd_en,
                        ctl_rd_en, mode_rd_en, lat_buf_level_rd_en,
                        c_buf_level_rd_en, buf_wm_rd_en,
                        axi_ctl_rd_en, dba_lo_rd_en, dba_hi_rd_en, ffsr_rd_en,
                        ffcr_rd_en,
                        pscr_rd_en, it_atb_m_ctr_2_rd_en, it_tr_flin_rd_en,
                        it_atb_data_0_rd_en, it_atb_ctr_1_rd_en,
                        it_atb_ctr_0_rd_en, it_ctrl_rd_en, claim_tag_set_rd_en,
                        claim_tag_clr_rd_en, lock_status_rd_en,
                        auth_status_rd_en, device_id_rd_en, device_type_rd_en,
                        periph_id_0_rd_en, periph_id_1_rd_en,
                        periph_id_2_rd_en, 
                        periph_id_4_rd_en, periph_id_5_rd_en,
                        periph_id_6_rd_en, periph_id_7_rd_en,
                        comp_id_0_rd_en, comp_id_1_rd_en, comp_id_2_rd_en,
                        comp_id_3_rd_en})
        );

//-----------------------------------------------------------------------------
// Only one write enable must be asserted at a time
//-----------------------------------------------------------------------------
generate
  if (CXTMC_ATBM_AXIM_CFG == CXTMC_CFG_ETB)
    assert_zero_one_hot #(`OVL_ERROR, 15, `OVL_ASSERT,
    "OVL Message : cxtmc_apbif - Multiple register write enables asserted at the same time")
      uzovl_cxtmc_apbif_wr_en_etb
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   ({rrp_wr_en, rwp_wr_en, rwd_wr_acc, trg_wr_en, ctl_wr_en,
                        rwd_wr_en, mode_wr_en, buf_wm_wr_en, ffcr_wr_en,
                        pscr_wr_en, it_misc_op_0_wr_en, it_atb_ctr_2_wr_en,
                        it_ctrl_wr_en, claim_tag_wr_en, lock_access_wr_en})
        );
  else if (CXTMC_ATBM_AXIM_CFG == CXTMC_CFG_ETR)
    assert_zero_one_hot #(`OVL_ERROR, 22, `OVL_ASSERT,
    "OVL Message : cxtmc_apbif - Multiple register write enables asserted at the same time")
      uzovl_cxtmc_apbif_wr_en_etr
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   ({rrp_wr_en, rwp_wr_en, rwd_wr_acc, trg_wr_en, ctl_wr_en,
                        rwd_wr_en, mode_wr_en, buf_wm_wr_en, ffcr_wr_en,
                        pscr_wr_en, it_misc_op_0_wr_en, it_atb_ctr_2_wr_en,
                        it_ctrl_wr_en, claim_tag_wr_en, lock_access_wr_en,
                        rsz_wr_en, mem_err_clr, axi_ctl_wr_en,
                        dba_lo_wr_en, dba_hi_wr_en, rrp_hi_wr_en,
                        rwp_hi_wr_en
                        })
        );
  else // ETF configuration
    assert_zero_one_hot #(`OVL_ERROR, 18, `OVL_ASSERT,
    "OVL Message : cxtmc_apbif - Multiple register write enables asserted at the same time")
      uzovl_cxtmc_apbif_wr_en_etf
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   ({rrp_wr_en, rwp_wr_en, rwd_wr_acc, trg_wr_en, ctl_wr_en,
                        rwd_wr_en, mode_wr_en, buf_wm_wr_en, ffcr_wr_en,
                        pscr_wr_en, it_misc_op_0_wr_en, it_atb_ctr_2_wr_en,
                        it_ctrl_wr_en, claim_tag_wr_en, lock_access_wr_en,
                        it_atb_m_data_0_wr_en, it_atb_m_ctr_1_wr_en,
                        it_atb_m_ctr_0_wr_en})
        );
endgenerate

//-----------------------------------------------------------------------------
// Control registers must not change when formatter is active
//-----------------------------------------------------------------------------
  assert_never #(`OVL_WARNING, `OVL_ASSERT,
   "OVL Message : cxtmc_apbif - It is illegal to change the programmed control settings when the formatter is active")
      uzovl_cxtmc_apbif_reg
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   (ctl_trace_capt_en & (mode_wr_en | ffcr_wr_en_bits01))
        );

//-----------------------------------------------------------------------------
// RRD read enables (rrd_rd_err and rrd_rd_req) - both must not be asserted 
// at the same time
//-----------------------------------------------------------------------------
  assert_zero_one_hot #(`OVL_ERROR, 2, `OVL_ASSERT,
    "OVL Message : cxtmc_apbif - Both read enables for RRD high at same time")
      uzovl_cxtmc_apbif_rrd_rd
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   ({rrd_rd_err, rrd_rd_req})
        );

//-----------------------------------------------------------------------------
// PSCR register programmed value must be in the allowed range : 0x0, 0x7-0x1B
//-----------------------------------------------------------------------------
  assert_never #(`OVL_WARNING, `OVL_ASSERT,
   "OVL Message : cxtmc_apbif - TMC programmed with illegal PSCR value")
      uzovl_cxtmc_apbif_pscr
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   (~((~ctl_trace_capt_en) ||
                         (pscr == 5'b00000) ||
                         (pscr >= 5'b00111) ||
                         (pscr <= 5'b11011)))
        );

  // DrainBuffer bit must not be set when formatting is disabled
  assert_never #(`OVL_WARNING, `OVL_ASSERT,
   "OVL Message : cxtmc_apbif - DrainBuffer bit must not be set when formatting is disabled")
      uzovl_cxtmc_apbif_drain_fmt_dis
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   (ctl_trace_capt_en & drain_buffer_en & 
                       ~ffcr_en_formatting_masked)
        );

//-----------------------------------------------------------------------------
// When the TMC is enabled, one of the mode-signals must be set.
//-----------------------------------------------------------------------------
  assert_zero_one_hot #(`OVL_ERROR, 3, `OVL_ASSERT,
    "OVL Message : cxtmc_apbif - When the TMC is enabled, only one of the mode-signals must be set.")
      uzovl_cxtmc_apbif_mode
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   ({circ_buf_mode, sw_fifo_mode, hw_fifo_mode})
        );

  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxtmc_apbif - When the TMC is enabled, a mode select signal must be asserted")
      uzovl_cxtmc_apbif_mode1
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   (tmc_enabled &
                       ~(circ_buf_mode | sw_fifo_mode | hw_fifo_mode))
        );

  assert_never #(`OVL_WARNING, `OVL_ASSERT,
   "OVL Message : cxtmc_regfile - When the TMC is in abort, ptr_clr wont happen")
      uzovl_cxtmc_regfile_abort_ptr_clr
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   (tmc_abort & ptr_clr)
        );

  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxtmc_regfile - Trace Mem Empty and Ptr Clr cant happen together")
      uzovl_cxtmc_regfile_mem_empty_ptr_clr
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   (trace_mem_empty & ptr_clr)
        );

//-----------------------------------------------------------------------------
// In ETB/ETF configurations, if trace_mem_empty is high, wb_ready is also high
// and so wb_empty cannot be low.
//-----------------------------------------------------------------------------
generate
  if (CXTMC_ATBM_AXIM_CFG != CXTMC_CFG_ETR) // ETB/ETF
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxtmc_regfile - In ETB/ETF configuration, Trace Mem Empty high and wb_empty low cant happen together when TMC is enabled")
      uzovl_cxtmc_regfile_mem_empty_wb_empty
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   (trace_mem_empty & ~wb_empty & tmc_enabled)
        );
endgenerate

generate
  if (CXTMC_ATBM_AXIM_CFG == CXTMC_CFG_ETF)
    begin
//-----------------------------------------------------------------------------
// In ETF configuration, if trace_mem_empty is low, unformatter_empty is also 
// low.
//-----------------------------------------------------------------------------
    assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxtmc_regfile - In ETF configuration, Trace Mem Not Empty and unformatter_empty cant happen together when TMC is enabled")
      uzovl_cxtmc_regfile_mem_not_empty_unf_empty
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   (~trace_mem_empty & unformatter_empty & unformatter_en &
                       tmc_enabled)
        );
    end
endgenerate

generate
  if (CXTMC_ATBM_AXIM_CFG == CXTMC_CFG_ETB)
//-----------------------------------------------------------------------------
// In ETB configuration, once TMCReady and ACQCOMP have gone high at the
// end of a trace capture cycle, they must both remain high
//-----------------------------------------------------------------------------
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxtmc_apbif - In the ETB configuration, once TMCReady and ACQCOMP have gone high at the end of a trace capture cycle, they must both remain high till the start of a trace capture cycle.")
      uzovl_cxtmc_apbif_mode1
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   (tmc_disabled & ~tmc_ready & ACQCOMP)
        );
endgenerate

generate
  if (CXTMC_ATBM_AXIM_CFG == CXTMC_CFG_ETF)
//-----------------------------------------------------------------------------
// In ETF configuration, ft_stopped cant happen when wb_empty is low and 
// tmc_abort is high.
//-----------------------------------------------------------------------------
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxtmc_apbif - In the ETF configuration, ft_stopped cant happen when wb_empty is low and tmc_abort is high.")
      uzovl_cxtmc_apbif_etf_wb_empty
        (
         .clk         (cxtmc_clk),
         .reset_n     (RESETn),
         .test_expr   (tmc_abort && !wb_empty && ft_stopped)
        );             
endgenerate


`endif

endmodule // cxtmc_regfile
