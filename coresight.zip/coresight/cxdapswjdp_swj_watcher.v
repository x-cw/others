//-----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2004-2015 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//    Checked In : $Date: 2014-11-12 12:04:32 +0000 (Wed, 12 Nov 2014) $
//    Revision   : $Revision: 40495 $
//    Release    : CoreSight-SoC-TM100-r3p2-00rel0
//-----------------------------------------------------------------------------
//
// ----------------------------------------------------------------------------
//  Purpose : Dual Serial Wire / jtag Switching control Block.
//  Manages switching between jtag, Serial Wire and dormant modes.
//  Starts up in jtag mode from reset.
// ----------------------------------------------------------------------------


module cxdapswjdp_swj_watcher
  (
  // Outputs
  jtagsel, swdsel, jtagtlrreq, wireresetreq, safetms,
  // Inputs
  swclktck, swditms, npotrst, wirereset, jtagstate
  );

`include "cxdapswjdp_swj_dp_constants.v"
`include "cxdapswjdp_jtag_dp_constants.v"

  // Serial Wire / jtag inputs
  input         swclktck;       // Serial Wire dbgclk / jtag tck input
  input         swditms;        // Serial Wire Data In / jtag tms
  input         npotrst;        // Power on Reset

  // DP status inputs

  input         wirereset;      // SW-DP in line reset
  input [3:0]   jtagstate;      // jtag-DP TAP controller state

  // Multiplexer switching control

  output        jtagsel;        // Select jtag
  output        swdsel;         // Select Serial Wire
  output        jtagtlrreq;     // Request TAP Reset
  output        wireresetreq;   // Request serial wire reset
  output        safetms;        // Data in for SW-DP / jtag-DP

// -----------------------------------------------------------------------------
// Signal declarations
// -----------------------------------------------------------------------------


  reg  [9:0]    next_state;      // next state of mode select state machine
  wire [9:0]    state;           // Mode select state machine state
  reg  [9:0]    state_cdc_check; // Mode select state machine state

  wire          jtagsel;         // jtag selected
  wire          swdsel;          // SWD selected
  reg           swdi_tms_sync1;  // Double-synchronised version of input
  wire          swdi_tms_sync3;  // Triple-synchronised version of input
  wire          safetms;         // SWDITMS when not searching for dormant
                                 // exit code
  reg           swdi_safetms_sync1;  // Registered version of safetms for use in FSM
  wire          safe_tms_int;    // SWDITMS - Internal version

  reg           jtagtlrreq;
  reg           wireresetreq;
  reg           wireresetreq_temp;

  // Decode of jtag state machine
  wire          tap_tlr;

// -----------------------------------------------------------------------------
// Explicit instantiations to assist implementation
// -----------------------------------------------------------------------------

  // Add an extra cycle of pipelining.  The below double-synchronizer
  // can be replaced by a triple-synchronizer if this stage of pipelining
  // is removed to compensate.
  always @ (posedge swclktck or negedge npotrst)
    begin
      if (!npotrst)
        swdi_tms_sync1 <= 1'b0;
      else
        swdi_tms_sync1 <= swditms;
    end

  // Double-synchronise input
  cxdapswjdp_dp_sync  u_swdi_tms
   (
    .clk        (swclktck),
    .resetn     (npotrst),
    .sync_di    (swdi_tms_sync1),// use swditms if 3 stage DFF is used

    .sync_do    (swdi_tms_sync3)
   );

  // OR gate to isolate SWDITMS from other logic when in dormant state.
  // This gate should be preserved during implementation if the design
  // might be used in a system where the SWDITMS pin might be shared by
  // another function with a different clock, used when in dormant state.
  // Under such circumstances it is theoretically possible that the OR gate
  // might otherwise be merged with other logic, and that the alternative
  // function might generate metastability.

  // Most implementations can ignore this, because most implementations
  // will either provide a dedicated pin for SWDITMS or provide switching
  // outside of dapswjdp.v.

  cxdapswjdp_dp_or u_safe_tms
   (
    .in_a (swditms),
    .in_b (state[7]),
    .out_y (safe_tms_int)
    );
  assign safetms = safe_tms_int;

  // Register the safetms to be used in the watcher state machine
  // This is used in the statemachine to avoid metastability in dormant mode
  always @ (posedge swclktck or negedge npotrst)
    begin
      if (!npotrst)
        swdi_safetms_sync1 <= 1'b0;
      else
        swdi_safetms_sync1 <= safetms;
    end


// -----------------------------------------------------------------------------
// watcher implementation
// -----------------------------------------------------------------------------

  // TAP state machine decode
  assign        tap_tlr = (jtagstate == JTAGDP_TLR);

  // next state logic for Mode Select state Machine
  // Refer to the state machine diagram

  always @(safe_tms_int or swdi_tms_sync3 or swdi_safetms_sync1 or state or
           jtagstate or tap_tlr or wirereset)

    begin: p_swjwatcher_state
      // Do not generate any reset requests by default
      jtagtlrreq = 1'b0;
      wireresetreq_temp = 1'b0;

      casez (state) // Using wild cards and default, so assertion against x is included

        // --- jtag states ---

        // Retiming cycles
        SWJ_JFROMS :
          begin
            next_state = SWJ_JRST;
            jtagtlrreq = 1'b1; // Generate TAP reset on entry to jtag
          end
        SWJ_JFROMD : next_state = tap_tlr ? SWJ_JRST : SWJ_JSLP;

        // Watch for jtag to SWD select pattern - 0x79E7 (MSB first)

        SWJ_JRST    : next_state = ~swdi_safetms_sync1 ? SWJ_J2SSEQ1 : SWJ_JRST; // TLR
        SWJ_J2SSEQ1 : next_state = swdi_safetms_sync1 ? SWJ_J2SSEQ2 : SWJ_JSLP; // rti
        // Go to JZBS0 on zero because it takes us into Capture-DR
        SWJ_J2SSEQ2 : next_state = swdi_safetms_sync1 ? SWJ_J2SSEQ3 : SWJ_JZBS0; // SDR
        SWJ_J2SSEQ3 : next_state = swdi_safetms_sync1 ? SWJ_J2SSEQ4 : SWJ_JSLP; // SIR
        SWJ_J2SSEQ4 : next_state = swdi_safetms_sync1 ? SWJ_J2SSEQ5 : SWJ_JSLP; // TLR
        SWJ_J2SSEQ5 : next_state = ~swdi_safetms_sync1 ? SWJ_J2SSEQ6 : SWJ_JSLP; // TLR
        SWJ_J2SSEQ6 : next_state = ~swdi_safetms_sync1 ? SWJ_J2SSEQ7 : SWJ_JSLP; // rti
        SWJ_J2SSEQ7 : next_state = swdi_safetms_sync1 ? SWJ_J2SSEQ8 : SWJ_JSLP; // rti
        // Go to JZBS0 on zero because it takes us into Capture-DR
        SWJ_J2SSEQ8 : next_state = swdi_safetms_sync1 ? SWJ_J2SSEQ9 : SWJ_JZBS0; // SDR
        SWJ_J2SSEQ9 : next_state = swdi_safetms_sync1 ? SWJ_J2SSEQ10 : SWJ_JSLP; // SIR
        SWJ_J2SSEQ10 : next_state = swdi_safetms_sync1 ? SWJ_J2SSEQ11 : SWJ_JSLP; // TLR
        SWJ_J2SSEQ11 : next_state = ~swdi_safetms_sync1 ? SWJ_J2SSEQ12 : SWJ_JSLP; // rti
        SWJ_J2SSEQ12 : next_state = ~swdi_safetms_sync1 ? SWJ_J2SSEQ13 : SWJ_JSLP; // rti
        // Go to JZBS0 on zero because it takes us into Capture-DR
        SWJ_J2SSEQ13 : next_state = swdi_safetms_sync1 ? SWJ_J2SSEQ14 : SWJ_JZBS0; // SDR
        // Bits 15 and 16 covered here; followed by retiming cycle
        SWJ_J2SSEQ14 : next_state = (swdi_safetms_sync1 & safe_tms_int) ? SWJ_SFROMJD : SWJ_JSLP; // SIR, TLR

        //jtag selected - sleeping state - remain here until TAP goes to Test-Logic-Reset
        SWJ_JSLP :
          case (jtagstate)
            JTAGDP_TLR : next_state = SWJ_JRST;
            JTAGDP_CDR : next_state = SWJ_JZBS0;
            default : next_state = SWJ_JSLP;
          endcase
        // Look for 1149.7 zero-bit scan level 6
        SWJ_JZBS0 :
          case (jtagstate)
            JTAGDP_TLR : next_state = SWJ_JRST;
            JTAGDP_SIR : next_state = SWJ_JSLP;
            JTAGDP_SHD : next_state = SWJ_JSLP;
            JTAGDP_CDR : next_state = SWJ_JZBS1;
            default : next_state = SWJ_JZBS0;
          endcase
        SWJ_JZBS1 :
          case (jtagstate)
            JTAGDP_TLR : next_state = SWJ_JRST;
            JTAGDP_SIR : next_state = SWJ_JSLP;
            JTAGDP_SHD : next_state = SWJ_JLOCKN;
            JTAGDP_CDR : next_state = SWJ_JZBS2;
            default : next_state = SWJ_JZBS1;
          endcase
        SWJ_JZBS2 :
          case (jtagstate)
            JTAGDP_TLR : next_state = SWJ_JRST;
            JTAGDP_SIR : next_state = SWJ_JSLP;
            JTAGDP_SHD : next_state = SWJ_JLOCKN;
            JTAGDP_CDR : next_state = SWJ_JZBS3;
            default : next_state = SWJ_JZBS2;
          endcase
        SWJ_JZBS3 :
          case (jtagstate)
            JTAGDP_TLR : next_state = SWJ_JRST;
            JTAGDP_SIR : next_state = SWJ_JSLP;
            JTAGDP_SHD : next_state = SWJ_JLOCKN;
            JTAGDP_CDR : next_state = SWJ_JZBS4;
            default : next_state = SWJ_JZBS3;
          endcase
        SWJ_JZBS4 :
          case (jtagstate)
            JTAGDP_TLR : next_state = SWJ_JRST;
            JTAGDP_SIR : next_state = SWJ_JSLP;
            JTAGDP_SHD : next_state = SWJ_JLOCKN;
            JTAGDP_CDR : next_state = SWJ_JZBS5;
            default : next_state = SWJ_JZBS4;
          endcase
        SWJ_JZBS5 :
          case (jtagstate)
            JTAGDP_TLR : next_state = SWJ_JRST;
            JTAGDP_SIR : next_state = SWJ_JSLP;
            JTAGDP_SHD : next_state = SWJ_JLOCKN;
            JTAGDP_CDR : next_state = SWJ_JZBS6;
            default : next_state = SWJ_JZBS5;
          endcase
        SWJ_JZBS6 :
          case (jtagstate)
            JTAGDP_TLR : next_state = SWJ_JRST;
            JTAGDP_SIR : next_state = SWJ_JSLP;
            JTAGDP_SHD : next_state = SWJ_JLOCK6;
            JTAGDP_CDR : next_state = SWJ_JLOCKN;
            default : next_state = SWJ_JZBS6;
          endcase
        SWJ_JLOCKN :
          case (jtagstate)
            JTAGDP_TLR : next_state = SWJ_JRST;
            JTAGDP_SIR : next_state = SWJ_JSLP;
            default : next_state = SWJ_JLOCKN;
          endcase
        // Look for Update-DR/IR transitioning to rti to catch jtag clock in time
        SWJ_JLOCK6 :
          case (jtagstate)
            JTAGDP_TLR : next_state = SWJ_JRST;
            JTAGDP_SIR : next_state = SWJ_JSLP;
            JTAGDP_UDR,
            JTAGDP_UIR : next_state = ~safe_tms_int ? SWJ_DFROMJS : SWJ_JLOCK6;
            default : next_state = SWJ_JLOCK6;
          endcase

        // --- SWD states ---

        // Retiming cycle
        SWJ_SFROMJD :
          begin
            next_state = SWJ_SRST;
            wireresetreq_temp = 1'b1; // Generate wire reset on entry to SWD
          end

        // Watch for SWD to jtag select pattern - 0x3CE7 (MSB first),
        // and SWD to Dormant select pattern - 0x3DC7 (MSB first)

        SWJ_SRST : next_state = ~swdi_safetms_sync1 ? SWJ_SSEQ1 : SWJ_SRST;
        SWJ_SSEQ1 : next_state = ~swdi_safetms_sync1 ? SWJ_SSEQ2 : SWJ_SSLP;
        SWJ_SSEQ2 : next_state = swdi_safetms_sync1 ? SWJ_SSEQ3 : SWJ_SSLP;
        SWJ_SSEQ3 : next_state = swdi_safetms_sync1 ? SWJ_SSEQ4 : SWJ_SSLP;
        SWJ_SSEQ4 : next_state = swdi_safetms_sync1 ? SWJ_SSEQ5 : SWJ_SSLP;
        SWJ_SSEQ5 : next_state = swdi_safetms_sync1 ? SWJ_SSEQ6 : SWJ_SSLP;
        SWJ_SSEQ6 : next_state = ~swdi_safetms_sync1 ? SWJ_SSEQ7 : SWJ_SSLP;
        SWJ_SSEQ7 : next_state = ~swdi_safetms_sync1 ? SWJ_S2JSEQ8 : SWJ_S2DSEQ8;
        // jtag select branch
        SWJ_S2JSEQ8 : next_state = swdi_safetms_sync1 ? SWJ_S2JSEQ9 : SWJ_SSLP;
        SWJ_S2JSEQ9 : next_state = swdi_safetms_sync1 ? SWJ_S2JSEQ10 : SWJ_SSLP;
        SWJ_S2JSEQ10 : next_state = swdi_safetms_sync1 ? SWJ_S2JSEQ11 : SWJ_SSLP;
        SWJ_S2JSEQ11 : next_state = ~swdi_safetms_sync1 ? SWJ_S2JSEQ12 : SWJ_SSLP;
        SWJ_S2JSEQ12 : next_state = ~swdi_safetms_sync1 ? SWJ_S2JSEQ13 : SWJ_SSLP;
        SWJ_S2JSEQ13 : next_state = swdi_safetms_sync1 ? SWJ_S2JSEQ14 : SWJ_SSLP;
        // Bits 15 and 16 covered here; followed by retiming cycle
        SWJ_S2JSEQ14 : next_state = (swdi_safetms_sync1 & safe_tms_int) ? SWJ_JFROMS : SWJ_SSLP;

        // Dormant select branch
        SWJ_S2DSEQ8 : next_state = swdi_safetms_sync1 ? SWJ_S2DSEQ9 : SWJ_SSLP;
        SWJ_S2DSEQ9 : next_state = swdi_safetms_sync1 ? SWJ_S2DSEQ10 : SWJ_SSLP;
        SWJ_S2DSEQ10 : next_state = ~swdi_safetms_sync1 ? SWJ_S2DSEQ11 : SWJ_SSLP;
        SWJ_S2DSEQ11 : next_state = ~swdi_safetms_sync1 ? SWJ_S2DSEQ12 : SWJ_SSLP;
        SWJ_S2DSEQ12 : next_state = ~swdi_safetms_sync1 ? SWJ_S2DSEQ13 : SWJ_SSLP;
        SWJ_S2DSEQ13 : next_state = swdi_safetms_sync1 ? SWJ_S2DSEQ14 : SWJ_SSLP;
        // Bits 15 and 16 covered here; followed by retiming cycle
        SWJ_S2DSEQ14 : next_state = (swdi_safetms_sync1 & safe_tms_int) ? SWJ_DFROMJS : SWJ_SSLP;

        // Serial Wire selected - sleeping state - remain here until SW-DP goes to line reset
        SWJ_SSLP : next_state = wirereset ? SWJ_SRST : SWJ_SSLP;

        // --- Dormant states ---

        // Retiming cycle
        SWJ_DFROMJS : next_state = SWJ_DSLP;

        // Watch for Dormant to jtag select pattern - 0x49CF9046A9B4A16197F5BBC745703D98 (MSB first)
        // The first bit is looked for explicitly; the remaining bits come from an LFSR

        // First use two of the closing padding cycles to switch to a
        // triple-registered version of the input.  This ensures safety when
        // the input is completely asynchronous during dormant state.
        SWJ_DSLP : next_state = SWJ_DSYNC1;
        SWJ_DSYNC1 : next_state = SWJ_DSEQ0;

        SWJ_DSEQX : // Dormant LFSR state
          case (state)
            SWJ_DSEQ0 : // wait for first bit of LFSR sequence (0)
              next_state = (~swdi_tms_sync3) ? SWJ_DSEQ1 : SWJ_DSEQ0;
            SWJ_DSEQ127 : // Received 127th bit in Dormant to jtag Select sequence
              next_state = (~swdi_tms_sync3) ? SWJ_DSYNC2 : SWJ_DSEQ0;
            default : // Any other state transition is calculated by the LFSR
              next_state = (swdi_tms_sync3 == state[0]) ?
                          {SWJ_DSEQPREFIX,
                           (state[6] ^ state[3] ^ state[1] ^ state[0]),
                           state[6:1]} :
                          SWJ_DSEQ0;
          endcase

        SWJ_DSYNC2 : next_state = SWJ_DSYNC3;
        SWJ_DSYNC3 : next_state = SWJ_DSEL0;

        // Completed 128-bit exit sequence and 4 padding cycles
        // (offset by two for the synchroniser)
        // Now searching for:
        //   0101 0000 -> jtag
        //   0101 1000 -> SWD
        //   00x0 00x -> 1149.7 zebra code detection
        SWJ_DSEL0 : next_state = ~swdi_safetms_sync1 ? SWJ_DSEL1 : SWJ_DSLP;
        SWJ_DSEL1 : next_state = ~swdi_safetms_sync1 ? SWJ_DSELJ2 : SWJ_DSELA2;

        SWJ_DSELA2 : next_state = ~swdi_safetms_sync1 ? SWJ_DSELA3 : SWJ_DSLP;
        SWJ_DSELA3 : next_state = swdi_safetms_sync1 ? SWJ_DSELA4 : SWJ_DSLP;
        SWJ_DSELA4 : next_state = ~swdi_safetms_sync1 ? SWJ_DSELAJ5 : SWJ_DSELAS5;

        SWJ_DSELAJ5 : next_state = ~swdi_safetms_sync1 ? SWJ_DSELAJ6 : SWJ_DSLP;
        // Covers bits 7 and 8 of sequence; followed by retiming cycle
        SWJ_DSELAJ6 : next_state = (~swdi_safetms_sync1 & ~safe_tms_int) ? SWJ_JFROMD : SWJ_DSLP;

        SWJ_DSELAS5 : next_state = ~swdi_safetms_sync1 ? SWJ_DSELAS6 : SWJ_DSLP;
        // Covers bits 7 and 8 of sequence; followed by retiming cycle
        SWJ_DSELAS6 : next_state = (~swdi_safetms_sync1 & ~safe_tms_int) ? SWJ_SFROMJD : SWJ_DSLP;

        SWJ_DSELJ2 : next_state = SWJ_DSELJ3;
        SWJ_DSELJ3 : next_state = ~swdi_safetms_sync1 ? SWJ_DSELJ4 : SWJ_DSLP;
        SWJ_DSELJ4 : next_state = ~swdi_safetms_sync1 ? SWJ_DSELJ5 : SWJ_DSLP;
        SWJ_DSELJ5 : next_state = ~swdi_safetms_sync1 ? SWJ_DSELJ6 : SWJ_DSLP;
        SWJ_DSELJ6 : next_state = SWJ_DSELJ7;

        // Two paths to zebra detection: '0' or '1 xxxxxxxx xxxxxxxx xxxxxxxx x'
        SWJ_DSELJ7 : next_state = ~swdi_safetms_sync1 ? SWJ_DSELJ8 : SWJ_DSKIP0;
        SWJ_DSELJ8 : next_state = SWJ_DZEB;

        SWJ_DSKIPX :
          case (state)
            SWJ_DSKIP24 : next_state = SWJ_DZEB;
            default : next_state = {SWJ_DSKIPPREFIX, (state[4:0] + 5'b00001)};
          endcase

        // Zebra code detector
        SWJ_DZEB : next_state = ~swdi_safetms_sync1 ? SWJ_DZEB0 : SWJ_DZEB1;
        SWJ_DZEB0 : next_state = ~swdi_safetms_sync1 ? SWJ_JFROMD : SWJ_DZEB1;
        SWJ_DZEB1 : next_state = swdi_safetms_sync1 ? SWJ_DZEBX1 : SWJ_DZEB0;
        SWJ_DZEBX1 :
          begin
            next_state = SWJ_DSLP;
            jtagtlrreq = 1'b1; // Generate TAP reset as per 1149.7 specification
          end

        // Unused encodings
        default     : next_state = SWJ_JRST;

      endcase
      // assign the output from the internal temp signal after the state machine
      // evaluation in order to not generate a delta time glitch on the output.
      wireresetreq = wireresetreq_temp;
    end // block: p_swjwatcher_state

   // Registers for main watcher state machine
  always @ (posedge swclktck or negedge npotrst)
    begin : p_stateseq
      if (!npotrst)
         state_cdc_check  <= SWJ_JRST;
      else
         state_cdc_check  <= next_state;
    end

  // jtag or SWD mode depends on state of watcher state machine
  // Relies on state encoding not being modified
  // Based upon single-register states for provable CDC safety
  // state[9:8] 00/11/01 -> jtag/SWD/Dormant

  assign jtagsel = ~state[8];
  assign swdsel = state[9];

`ifdef ARM_ASSERT_ON

  // Ensure next_state never goes unknown
  assert_never_unknown #(`OVL_ERROR, 10, `OVL_ASSERT, "SWJ watcher state machine next state must not be x")
    uovl_swjdp_nextstate(
                         .clk       (swclktck),
                         .reset_n   (npotrst),
                         .qualifier (1'b1),
                         .test_expr (next_state)
                         );

  // Ensure state never goes unknown
  assert_never_unknown #(`OVL_ERROR, 10, `OVL_ASSERT, "SWJ watcher state machine state must not be x")
    uovl_swjdp_state(
                     .clk       (swclktck),
                     .reset_n   (npotrst),
                     .qualifier (1'b1),
                     .test_expr (state)
                     );

  // Ensure jtag state machine is always parked in TLR or rti
  assert_never #(`OVL_ERROR, `OVL_ASSERT, "jtag-DP deselected but not left in TLR or rti.")
    uovl_jtag_state(
                    .clk       (swclktck),
                    .reset_n   (npotrst),
                    .test_expr (~jtagsel &
                                (jtagstate != JTAGDP_TLR) &
                                (jtagstate != JTAGDP_RTI))
                    );

`endif

`ifdef ARM_CDC_ON
  cdc_connect #(9,0) u_cdc_state(
                                .clk_launch(swclktck),
                                .clk_capture(cxdapswjdp.u_cxdapswjdp_dapclk.u_cxdapswjdp_sw_dp_apb_if.dapclk),
                                .d_in(state_cdc_check),
                                .d_out_async(state)
                                );
`else
        assign state = state_cdc_check;
`endif
  endmodule
