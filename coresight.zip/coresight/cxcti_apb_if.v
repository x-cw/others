//-----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2003-2015 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//    Checked In : $Date: 2014-10-08 14:51:24 +0100 (Wed, 08 Oct 2014) $
//    Revision   : $Revision: 40194 $
//    Release    : CoreSight-SoC-TM100-r3p2-00rel0
//
//----------------------------------------------------------------------------
//      Purpose             : CTI APB Interface Module
// --=========================================================================--

module cxcti_apb_if
  (
  // Inputs
  presetdbgn, pclkdbg, pclkendbg, ctiapbsbypass, penabledbg, pseldbg,
  paddrdbg, pwritedbg, ctack, ct_rdata, cp_rdata,
  // Outputs
  preadydbg, prdatadbg, ct_req, cp_req
  );

`include "cxcti_constants.v"

  //----------------------------------------------------------------------------
  // INPUTS
  //----------------------------------------------------------------------------
  // System controls
  input                        presetdbgn;    // Reset
  input                        pclkdbg;       // pclkdbg
  input                        pclkendbg;     // pclkendbg
  input                        ctiapbsbypass; // APB synchronisation bypass

  // APB inputs
  input                        penabledbg;    // penabledbg
  input                        pseldbg;       // pseldbg
  input [11:2]                 paddrdbg;      // Address
  input                        pwritedbg;     // Write control

  // Transfer control inputs
  input                        ctack;         // Transfer acknowledge from

  // register block
  input [7:0]                  ct_rdata;       // Read data from register CTCLK
  input [19:0]                 cp_rdata;       // Read data from register pclkdbg

  //----------------------------------------------------------------------------
  // OUTPUTS
  //----------------------------------------------------------------------------
  output                       preadydbg;     // Device ready
  output [31:0]                prdatadbg;     // Read data output

  // information (user/privileged)
  output                       ct_req;        // Transfer request
                                              // CTCLK domain
  output                       cp_req;        // Transfer request
                                              // pclkdbg domain

  //----------------------------------------------------------------------------
  // WIRES AND REGS
  //----------------------------------------------------------------------------
  wire                         tran_valid;
  wire                         rd_valid;
  wire                         wr_valid;
  wire                         p_reg_addr;
  wire                         p_rd_valid;
  wire                         c_rd_valid;
  wire                         p_wr_valid;
  wire                         c_wr_valid;
  wire                         p_tran_valid;
  wire                         c_tran_valid;
  wire                         ct_req_n;
  wire                         ct_req;
  wire                         ct_req_int;
  reg                          ctreq_cdc_check;
  reg                          reg_ctiapbsbypass;
  wire                         ctack_corrupt;
  wire                         ct_ack_sync_2;
  wire                         ct_ack_synced;
  wire                         c_tran_ack;
  wire                         new_preadydbg;
  reg                          preadydbg_int;
  wire                         preadydbg;
  reg                          last_ct_ack_synced;
  wire                         prdatadbg_en;
  wire [19:0]                  new_prdatadbg;
  wire [31:0]                  prdatadbg;
  reg  [19:0]                  prdatadbg_int;

  //----------------------------------------------------------------------------
  //
  // MAIN CODE
  //
  //----------------------------------------------------------------------------

  //----------------------------------------------------------------------------
  // Determine if a transfer request is valid
  //----------------------------------------------------------------------------
  assign    tran_valid   = ~penabledbg & pseldbg;

  //----------------------------------------------------------------------------
  // Generate indication of bus access requests
  //----------------------------------------------------------------------------
  assign    rd_valid = tran_valid & (~pwritedbg); // Read
  assign    wr_valid = tran_valid & (pwritedbg);  // Write

  //----------------------------------------------------------------------------
  // Detect whether or not the transfer is addressed to the control registers
  // in the pclkdbg domain
  //----------------------------------------------------------------------------
  assign    p_reg_addr = (
                        (paddrdbg == CXCTI_COMPONID0_ADD) |
                        (paddrdbg == CXCTI_COMPONID1_ADD) |
                        (paddrdbg == CXCTI_COMPONID2_ADD) |
                        (paddrdbg == CXCTI_COMPONID3_ADD) |
                        (paddrdbg == CXCTI_PERIPHID0_ADD) |
                        (paddrdbg == CXCTI_PERIPHID1_ADD) |
                        (paddrdbg == CXCTI_PERIPHID2_ADD) |
                        (paddrdbg == CXCTI_PERIPHID3_ADD) |
                        (paddrdbg == CXCTI_PERIPHID4_ADD) |
                        (paddrdbg == CXCTI_PERIPHID5_ADD) |
                        (paddrdbg == CXCTI_PERIPHID6_ADD) |
                        (paddrdbg == CXCTI_PERIPHID7_ADD) |
                        (paddrdbg == CXCTI_LOCKSTATUS_ADD) |
                        (paddrdbg == CXCTI_LOCKACCESS_ADD) |
                        (paddrdbg == CXCTI_CLAIMSET_ADD) |
                        (paddrdbg == CXCTI_CLAIMCLR_ADD) |
                        (paddrdbg == CXCTI_DEVID_ADD) |
                        (paddrdbg == CXCTI_DEVTYPE_ADD));

  assign    p_rd_valid = rd_valid & p_reg_addr;
  assign    c_rd_valid = rd_valid & ~p_reg_addr;
  assign    p_wr_valid = wr_valid & p_reg_addr;
  assign    c_wr_valid = wr_valid & ~p_reg_addr;

  assign    p_tran_valid = pclkendbg & (p_rd_valid | p_wr_valid);
  assign    c_tran_valid = pclkendbg & (c_rd_valid | c_wr_valid);

  assign    cp_req = p_tran_valid;

  //----------------------------------------------------------------------------
  // Generate ct_req (toggle ct_req if there is a request)
  //----------------------------------------------------------------------------
  // Register ct_req output
  assign      ct_req_n = ~ct_req_int;

  always @(posedge pclkdbg or negedge presetdbgn)
    begin
      if (!presetdbgn)
        ctreq_cdc_check   <= 1'b0;
      else if (c_tran_valid)
        ctreq_cdc_check   <= ct_req_n ;
    end

  //----------------------------------------------------------------------------
  // Register sync bypass control
  //----------------------------------------------------------------------------

  always @(posedge pclkdbg or negedge presetdbgn)
    begin
      if (!presetdbgn)
        reg_ctiapbsbypass <= 1'b0;
      else if (pclkendbg)
        reg_ctiapbsbypass <= ctiapbsbypass;
    end

  //----------------------------------------------------------------------------
  // Sync ctack inputs
  //----------------------------------------------------------------------------
`ifdef ARM_CDC_CHECK
  // Test component to corrupt ctack going into synchroniser
  cx_cdc_corrupt_gry u_cdc_corrupt_ctack (
      .clk    (pclkdbg),
      .resetn (presetdbgn),
      .sync   (1'b0),
      .d_async(ctack),
      .q_async(ctack_corrupt)
    );
`else
  assign ctack_corrupt   = ctack;
`endif

  cx_en_sync u_ct_ack_sync
    (
     .clk     (pclkdbg),
     .resetn  (presetdbgn),
     .clken   (pclkendbg),
     .sync_di (ctack_corrupt),
     .sync_do (ct_ack_sync_2)
     );

  //----------------------------------------------------------------------------
  // Sync MUX
  //----------------------------------------------------------------------------
  cx_comb_mux2 u_sync_ack_mux
    (
    .din1_async (ct_ack_sync_2),
    .din2_async (ctack),
    .sel        (reg_ctiapbsbypass),
    .dout_async (ct_ack_synced)
    );

  assign c_tran_ack    = (ct_ack_synced == ct_req_int);

  //----------------------------------------------------------------------------
  // Generate preadydbg
  //----------------------------------------------------------------------------
  assign new_preadydbg = ((preadydbg_int & ~c_tran_valid) |
                         (~preadydbg_int & c_tran_ack));

  always @(posedge pclkdbg or negedge presetdbgn)
    begin
      if (!presetdbgn)
        preadydbg_int <= {1'b0};
      else if (pclkendbg)
        preadydbg_int <= new_preadydbg;
    end

  assign preadydbg = preadydbg_int;

  //----------------------------------------------------------------------------
  // prdatadbg generation.
  // Store last state of ctack for sample enable generation
  //----------------------------------------------------------------------------
  always @(posedge pclkdbg or negedge presetdbgn)
    begin
      if (!presetdbgn)
        last_ct_ack_synced <= 1'b0;
      else if (pclkendbg)
        last_ct_ack_synced <= ct_ack_synced;
    end

  //----------------------------------------------------------------------------
  // Generate sampling control for ct_rdata
  // If thransfer is to the CTCLK domain, data will be sampled when the ack
  // comes from that clock domain.
  // If the transfer is to the PLCK domain, data will be ready in the current
  // clock cycle.
  //----------------------------------------------------------------------------
  assign prdatadbg_en = pclkendbg & ~pwritedbg &
                        ( ( (ct_ack_synced ^ last_ct_ack_synced) &
                           (!(ct_ack_synced ^ ct_req_int)       ) )  |
                         (p_tran_valid                          ) );

  //----------------------------------------------------------------------------
  // Next state of sampled data
  //----------------------------------------------------------------------------
  assign new_prdatadbg = p_reg_addr ?
                           cp_rdata :
                           {{12{1'b0}},ct_rdata[7:0]};

  //----------------------------------------------------------------------------
  // Sample read data
  //----------------------------------------------------------------------------
  always @(posedge pclkdbg or negedge presetdbgn)
    begin
      if (!presetdbgn)
        prdatadbg_int <= {20{1'b0}};
      else if (prdatadbg_en)
        prdatadbg_int <= new_prdatadbg;
    end
  assign prdatadbg = {{12{1'b0}}, prdatadbg_int};

`ifdef ARM_CDC_ON
        cdc_connect u_cdc_ctreq(
                .clk_launch(pclkdbg),
                .clk_capture(cxcti.u_cxcti_reg_c.u_ct_req_sync.clk),
                .d_in(ctreq_cdc_check),
                .d_out_async(ct_req_int)
                );
`else
        assign ct_req_int = ctreq_cdc_check;
`endif
  assign ct_req = ct_req_int;

endmodule
