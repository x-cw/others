//-----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2010-2015 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//      Checked In          : $Date: 2014-06-25 08:42:22 +0100 (Wed, 25 Jun 2014) $
//
//      Revision            : $Revision: 39629 $
//
//      Release Information : CoreSight-SoC-TM100-r3p2-00rel0
//-----------------------------------------------------------------------------
//  Purpose             : Output Registers with Flop Testing.
//                        If input to register is metastable X is driven
//-----------------------------------------------------------------------------

module cxatbasyncbridge_dff  (
  // Inputs
  clk,
  clken,
  nreset,
  din,
  // Outputs
  dout
  );

  // Configurable parameter
  // Default value is 32
  parameter BUS_WIDTH = 32;

  // Inputs
  input wire                 clk;              // Clock
  input wire                 clken;            // Clock enable
  input wire                 nreset;           // Reset
  input wire [BUS_WIDTH-1:0] din;              // Input to Flop

  // Outputs
  output reg [BUS_WIDTH-1:0] dout;             // Output from Flop


  // ---------------------------------------------------------------------------
  // Main body of code
  // =================
  // ---------------------------------------------------------------------------

  `ifdef ASYNC_TEST
  // ---------------------------------------------------------------------------
  // Block for Asynchronous Flop Simulation and Testing
  // ---------------------------------------------------------------------------
     integer  i;
     wire [BUS_WIDTH-1:0] din_delayed;
     assign #(`SYNC_DELAY/2) din_delayed[BUS_WIDTH-1:0] = din[BUS_WIDTH-1:0];
  `endif

  always @(posedge clk or negedge nreset)
    begin
      if (!nreset)
            dout[BUS_WIDTH-1:0] <= {BUS_WIDTH{1'b0}};
      else if (clken)
        begin
  `ifdef ASYNC_TEST
  // ---------------------------------------------------------------------------
  // Block for Asynchronous Flop Simulation and Testing
  // ---------------------------------------------------------------------------
     for (i = 0; i < BUS_WIDTH; i = i+1)
     begin
        if (din[i] != din_delayed[i])
                begin
          dout[i] <= 1'bx;
                //$display($time," ns : Input to Output Register metastable!!! - Driving 'X' \n");
                end
        else
            dout[i] <= din[i];
     end
  `else
            dout[BUS_WIDTH-1:0] <= din[BUS_WIDTH-1:0];
  `endif
        end
    end

endmodule // cxatbasyncbridge_dff
