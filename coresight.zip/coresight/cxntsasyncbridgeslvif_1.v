
//-----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2012-2015 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//  Version and Release Control Information:
//
//  File Name           : cxntsasyncbridgeslvif_xmlcfg.v.xsl
//
//  Checked In          : $Date: 2015-02-16 14:55:41 +0000 (Mon, 16 Feb 2015) $
//
//  File Revision       : $Revision: 41661 $
//
//  Release Information : CoreSight-SoC-TM100-r3p2-00rel0
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// Abstract : CoreSight NTAB - Slave Inteface
//-----------------------------------------------------------------------------
//
// cxntsasyncbridge - CoreSight NTAB (Narrow Timestamp Asynchronous Bridge)
// Slave interface
//-----------------------------------------------------------------------------

module cxntsasyncbridgeslvif_1 (

  // Clock and Reset
  input wire clks,
  input wire resetsn,

  // Slave Interface
  input wire [6:0] tsbits,
  input wire [1:0] tssyncs,
  output wire tssyncreadys,

  // AXI-C Low Power Interface
  input wire csysreq,
  output wire csysack,
  output wire cactive,

  // Master Interface
  input wire [3:0] rd_ptr_gry_s,
  output wire [3:0] wr_ptr_gry_s,
  
  output wire [8:0] encd_data0_s, // Encoded Data0
  output wire [8:0] encd_data1_s, // Encoded Data1
  output wire [8:0] encd_data2_s, // Encoded Data2
  output wire lp_req_s,
  input wire lp_ack_s

  );

//------------------------------------------------------------------------------
// Constant definitions
//------------------------------------------------------------------------------
  localparam PWRUP    = 3'b001;
  localparam PWRWAIT  = 3'b010;
  localparam PWRDN    = 3'b100;
  localparam PWRUNUS0 = 3'b000;
  localparam PWRUNUS1 = 3'b011;
  localparam PWRUNUS2 = 3'b101;
  localparam PWRUNUS3 = 3'b110;
  localparam PWRUNUS4 = 3'b111;

  // Parameter to set timestamp accuracy threshold
  localparam THRESHOLD = 8;

//----------------------------------------------------------------------------
// Wires
//----------------------------------------------------------------------------
  wire [8:0] enc_data;
  wire enc_data_rg_en;
  wire enc_data_vld;
  wire async_fifo_full;
  wire wr_req;
  
  wire wr_en_0; // Data Interface0
  wire wr_en_1; // Data Interface1
  wire wr_en_2; // Data Interface2
  wire lp_ack_s_corrupt_async;
  wire lp_ack_s_sync;
  wire pwr_lp_wait;
  wire [3:0] rd_ptr_gry_s_corrupt_async;
  wire [3:0] rd_ptr_gry_s_sync;
  wire roll_over;
  wire tsbitvalids;
  wire [6:0] tsbit_stky_gt;
  wire [6:0] tsbit_stky_next;
  wire tsbit_stky_en;
  wire tsbits_rg_en;
  wire tssyncs_rg_en;
  wire csysack_next;
  wire lp_req_s_en;
  wire clock_stop;

//----------------------------------------------------------------------------
// Registers
//----------------------------------------------------------------------------
  reg [3:0] incr_ptr_gry;
  reg [3:0] gry_to_bin;
  reg [3:0] rd_ptr_gry_s_to_bin;
  reg [2:0] lp_fsm_next;
  reg [2:0] lp_fsm;
  reg [8:0] enc_data_rg_next;
  reg [8:0] enc_data_rg;
  reg [6:0] tsbit_stky;
  reg [6:0] tsbits_rg_next;
  reg [6:0] tsbits_rg;
  reg [1:0] tssyncs_rg_next;
  reg [1:0] tssyncs_rg;
  reg [3:0] wr_ptr_gry_s_next;
  reg [3:0] wr_ptr_gry_s_q;
  reg       gen_resync_pck;
  reg       lp_req_s_next;
  reg       lp_req_s_q;
  reg       csysack_q;
  reg  clock_stop_rg;
  
  reg [8:0] enc_data0; // Encoded Data0
  reg [8:0] enc_data1; // Encoded Data1
  reg [8:0] enc_data2; // Encoded Data2

//============================================================================
//
// Main body of code
//
//============================================================================

//----------------------------------------------------------------------------
// Low Power Ack synchronization
//----------------------------------------------------------------------------

  // Test component to corrupt Low Power Ack going into synchroniser
  cx_cdc_corrupt_gry #(1) u_cdc_corrupt_lp_ack_s
  (
      .clk       (clks),
      .resetn    (resetsn),
      .sync      (1'b0),
      .d_async   (lp_ack_s),
      .q_async   (lp_ack_s_corrupt_async)
  );

  // Synchroniser to bring the Low Power Ack into the clock domain
  cx_sync u_cdc_sync_lp_ack_s
  (
      .clk       (clks),
      .resetn    (resetsn),
      .sync_di   (lp_ack_s_corrupt_async),
      .sync_do   (lp_ack_s_sync)
  );

//----------------------------------------------------------------------------
// Low Power FSM (one-hot encoded)
// It has 3 states : PWRUP, PWRWAIT, PWRDN
// In PWRUP state all normal transactions are allowed
// IF there is a low-power entry request on csysreq then FSM enters PWRWAIT
// It sends a lp_req to master interface and once it receives lp_ack
// it enters PWRDN state.
// During PWRWAIT and PWRDN states tssyncreadys is asserted high.
// Data is no longer stored in the FIFO. Pointers will be reset.
// When low-power exit request is received on csysreq, the FSM goes back to
// PWRUP state and fifo will be ready to store data.
//----------------------------------------------------------------------------

  always @(*)
    begin
      gen_resync_pck = 1'b0;

      case (lp_fsm)
        PWRUP : lp_fsm_next = (!csysreq) ? PWRWAIT : lp_fsm;
        PWRWAIT  : lp_fsm_next = (!lp_ack_s_sync) ? PWRDN : lp_fsm;
        PWRDN : begin
          lp_fsm_next = (csysreq && lp_ack_s_sync) ? PWRUP : lp_fsm;
          gen_resync_pck = csysreq;
        end
        PWRUNUS0,
        PWRUNUS1,
        PWRUNUS2,
        PWRUNUS3,
        PWRUNUS4 : lp_fsm_next = lp_fsm;
        default : lp_fsm_next = {3{1'bx}};
      endcase
    end

  always @(posedge clks or negedge resetsn)
    begin
      if (!resetsn)
        lp_fsm <= PWRDN;
      else
        lp_fsm <= lp_fsm_next;
    end

  assign csysack_next = ~lp_fsm_next[2];

  always @(posedge clks or negedge resetsn)
    begin
      if (!resetsn)
        csysack_q <= 1'b0;
      else
        csysack_q <= csysack_next;
    end

  assign cactive = 1'b0;

  assign csysack = csysack_q;

  always @(*)
    begin
      lp_req_s_next = lp_req_s_q;

      if (!csysreq) begin
        if (lp_req_s_q) begin
          lp_req_s_next = ~((tssyncs_rg == 2'b00) & (enc_data_rg[8:7] == 2'b00));
        end
      end else if (!lp_req_s_q) begin
        lp_req_s_next = csysreq;
      end
    end

  assign lp_req_s_en = (lp_req_s_q != lp_req_s_next);

  always @(posedge clks or negedge resetsn)
    begin
      if (!resetsn)
        lp_req_s_q <= 1'b1;
      else if (lp_req_s_en)
        lp_req_s_q <= lp_req_s_next;
    end

  assign lp_req_s = lp_req_s_q;

//----------------------------------------------------------------------------
// Register tsbits and tssyncs to meet input timing requirements
// External path will have larger timing budget
//----------------------------------------------------------------------------

  // Addition of threshold check for master clock very slow or stopped
  assign clock_stop = (tsbits_rg > THRESHOLD) & (tsbit_stky > THRESHOLD);

  // clock_stop_rg needs to latch so that it forces tssyncreadys high while the master is blocked
  always @(posedge clks or negedge resetsn)
    begin
      if (!resetsn)
        clock_stop_rg <= 1'b0;
      else if (clock_stop)
        clock_stop_rg <= 1'b1;
      else if (!async_fifo_full)
        clock_stop_rg <= 1'b0;
    end

  always @(*)
    begin
      if (csysreq && csysack_q) begin
        tsbits_rg_next = tsbits;
      end else if (async_fifo_full) begin
        tsbits_rg_next = tsbits_rg;
      end else begin
        tsbits_rg_next = {7{1'b0}};
      end
    end

  assign tsbits_rg_en = (tsbits_rg != tsbits_rg_next);

  always @(posedge clks or negedge resetsn)
    begin
      if (!resetsn)
        tsbits_rg <= {7{1'b0}};
      else if (tsbits_rg_en)
        tsbits_rg <= tsbits_rg_next;
    end

  always @(*)
    begin
      if (csysreq && csysack_q) begin
        if (async_fifo_full) begin
          tssyncs_rg_next = clock_stop ? 2'b00 : tssyncs_rg;
        end else begin
          tssyncs_rg_next = tssyncs;
        end
      end else begin
        tssyncs_rg_next = {2{async_fifo_full}} & tssyncs_rg;
      end
    end

  assign tssyncs_rg_en = ((tssyncs_rg != tssyncs_rg_next));

  always @(posedge clks or negedge resetsn)
    begin
      if (!resetsn)
        tssyncs_rg <= {2{1'b0}};
      else if (tssyncs_rg_en)
        tssyncs_rg <= tssyncs_rg_next;
    end

//----------------------------------------------------------------------------
// Monitors data on the Narrow time stamp interface
// Generates a write request only when data is valid on either the Encoded
// timestamp channel or the Synchronization channel
//----------------------------------------------------------------------------

  assign tsbit_stky_gt = clock_stop ?
                           {7{1'b1}} :
                           (tsbits_rg > tsbit_stky) ? tsbits_rg : tsbit_stky;

  assign tsbit_stky_next = (async_fifo_full) ?
                             tsbit_stky_gt :
                                {7{1'b0}};

  assign tsbit_stky_en = (tsbit_stky != tsbit_stky_next);

  always @(posedge clks or negedge resetsn)
    begin
      if (!resetsn)
        tsbit_stky <= {7{1'b0}};
      else if (tsbit_stky_en)
        tsbit_stky <= tsbit_stky_next;
    end

  assign tsbitvalids = (tsbits_rg != {7{1'b0}}) | (tsbit_stky != {7{1'b0}});

  assign enc_data = (tsbitvalids | (|tssyncs_rg)) ?
                     {tssyncs_rg,tsbit_stky_gt} :
                       {9{1'b0}};

  assign pwr_lp_wait = lp_fsm[0] | lp_fsm[1];

  always @(*)
  begin
    enc_data_rg_next = enc_data_rg;

    case (pwr_lp_wait)
      1'b0 : enc_data_rg_next = gen_resync_pck ? {{2{1'b0}},{7{1'b1}}} : {9{1'b0}};
      1'b1 : begin
        case (async_fifo_full)
          1'b0 : enc_data_rg_next = enc_data;
          1'b1 : enc_data_rg_next = enc_data_rg;
          default : enc_data_rg_next = {9{1'bx}};
        endcase
      end
      default : enc_data_rg_next = {9{1'bx}};
    endcase
  end

  assign enc_data_rg_en = (gen_resync_pck |
                           tsbitvalids |
                          (|tssyncs_rg) |
                          (|enc_data_rg[8:7]) |
                          (enc_data_rg[6:0] != {7{1'b0}}));

  always @(posedge clks or negedge resetsn)
    begin
      if (!resetsn)
        enc_data_rg <= {9{1'b0}};
      else if (enc_data_rg_en)
        enc_data_rg <= enc_data_rg_next;
    end

  assign enc_data_vld = ((|enc_data_rg[8:7]) |
                         (enc_data_rg[6:0] != {7{1'b0}}));

//----------------------------------------------------------------------------
// Read pointer generation
//----------------------------------------------------------------------------

  // Test component to corrupt Read Pointer going into synchroniser
  cx_cdc_corrupt_gry #(4) u_cdc_corrupt_rd_ptr_gry_s
  (
      .clk       (clks),
      .resetn    (resetsn),
      .sync      (1'b0),
      .d_async   (rd_ptr_gry_s),
      .q_async   (rd_ptr_gry_s_corrupt_async)
  );

  // Synchroniser to bring the Read Pointer into the clock domain
  cx_sync u_cdc_sync_rd_ptr_gry_s0
  (
      .clk       (clks),
      .resetn    (resetsn),
      .sync_di   (rd_ptr_gry_s_corrupt_async[0]),
      .sync_do   (rd_ptr_gry_s_sync[0])
  );
  cx_sync u_cdc_sync_rd_ptr_gry_s1
  (
      .clk       (clks),
      .resetn    (resetsn),
      .sync_di   (rd_ptr_gry_s_corrupt_async[1]),
      .sync_do   (rd_ptr_gry_s_sync[1])
  );
  cx_sync u_cdc_sync_rd_ptr_gry_s2
  (
      .clk       (clks),
      .resetn    (resetsn),
      .sync_di   (rd_ptr_gry_s_corrupt_async[2]),
      .sync_do   (rd_ptr_gry_s_sync[2])
  );
  cx_sync u_cdc_sync_rd_ptr_gry_s3
  (
      .clk       (clks),
      .resetn    (resetsn),
      .sync_di   (rd_ptr_gry_s_corrupt_async[3]),
      .sync_do   (rd_ptr_gry_s_sync[3])
  );

//------------------------------------------------------------------------------
// generate binary sequence given a grey sequence of read pointer
//------------------------------------------------------------------------------
  always @(*)
    begin

    rd_ptr_gry_s_to_bin = 4'd0;

    case (rd_ptr_gry_s_sync)
    4'd0 : rd_ptr_gry_s_to_bin = 4'd0;
    4'd1 : rd_ptr_gry_s_to_bin = 4'd1;

    4'd3 : rd_ptr_gry_s_to_bin = 4'd2;
    4'd7 : rd_ptr_gry_s_to_bin = 4'd0;
    4'd6 : rd_ptr_gry_s_to_bin = 4'd1;
    4'd4 : rd_ptr_gry_s_to_bin = 4'd2;

    4'd2,
    4'd5,
    4'd8,
    4'd9,
    4'd10,
    4'd11,
    4'd12,
    4'd13,
    4'd14,
    4'd15 : rd_ptr_gry_s_to_bin = {4{1'b0}};

    default : rd_ptr_gry_s_to_bin = {4{1'bx}};
    endcase
  end

//----------------------------------------------------------------------------
// Control logic generates write pointer and determines if the FIFO is full
//----------------------------------------------------------------------------



  assign roll_over = wr_ptr_gry_s_q[2] ^ rd_ptr_gry_s_sync[2];


  assign async_fifo_full = ((gry_to_bin == rd_ptr_gry_s_to_bin) & roll_over);

  // Add term to make ready line high if the FIFO is stalled
  // due to master clock stopping
  assign tssyncreadys = (lp_fsm[0]) ?
                          ~(async_fifo_full)
                           | (async_fifo_full & tsbit_stky == 7'h7f & clock_stop_rg) :
                         1'b1;

//----------------------------------------------------------------------------
// Write pointer generation including binary to grey conversion
//----------------------------------------------------------------------------

//------------------------------------------------------------------------------
// increments in grey sequence
//------------------------------------------------------------------------------
  always @(*)
    begin
    incr_ptr_gry = wr_ptr_gry_s_q;

    case (wr_ptr_gry_s_q)
      4'd0 : incr_ptr_gry = 4'd1;
      4'd1 : incr_ptr_gry = 4'd3;

      4'd3 : incr_ptr_gry = 4'd7;
      4'd7 : incr_ptr_gry = 4'd6;
      4'd6 : incr_ptr_gry = 4'd4;
      4'd4 : incr_ptr_gry = 4'd0;

      4'd2,
      4'd5,
      4'd8,
      4'd9,
      4'd10,
      4'd11,
      4'd12,
      4'd13,
      4'd14,
      4'd15 : incr_ptr_gry = {4{1'b0}};

      default : incr_ptr_gry = {4{1'bx}};
    endcase
    end

  assign wr_req = ~async_fifo_full & enc_data_vld;

  always @(*)
  begin
    wr_ptr_gry_s_next = wr_ptr_gry_s_q;

    if (pwr_lp_wait) begin
      if (~async_fifo_full && wr_req) begin
        wr_ptr_gry_s_next = incr_ptr_gry;
      end
    end else if (~lp_ack_s_sync) begin
      wr_ptr_gry_s_next = 4'd0;
    end
  end

  always @(posedge clks or negedge resetsn)
    begin
      if (!resetsn)
        wr_ptr_gry_s_q <= {4{1'b0}};
      else
        wr_ptr_gry_s_q <= wr_ptr_gry_s_next;
    end

  assign wr_ptr_gry_s = wr_ptr_gry_s_q;

//----------------------------------------------------------------------------
// Data storage and write enable generation
//----------------------------------------------------------------------------

//------------------------------------------------------------------------------
// generate binary sequence given a grey sequence
//------------------------------------------------------------------------------
  always @(*)
    begin

    gry_to_bin = 4'd0;

    case (wr_ptr_gry_s_q)
    4'd0 : gry_to_bin = 4'd0;
    4'd1 : gry_to_bin = 4'd1;

    4'd3 : gry_to_bin = 4'd2;
    4'd7 : gry_to_bin = 4'd0;
    4'd6 : gry_to_bin = 4'd1;
    4'd4 : gry_to_bin = 4'd2;

    4'd2,
    4'd5,
    4'd8,
    4'd9,
    4'd10,
    4'd11,
    4'd12,
    4'd13,
    4'd14,
    4'd15 : gry_to_bin = {4{1'b0}};

    default : gry_to_bin = {4{1'bx}};
    endcase
  end

  
  // Data Interface0
  assign wr_en_0 = wr_req & (gry_to_bin == 4'd0);

  always @(posedge clks or negedge resetsn)
    begin : p_enc_data_rg0
      if (!resetsn)
        enc_data0 <= {9{1'b0}};
      else if (wr_en_0)
        enc_data0 <= enc_data_rg;
    end

  // Data Interface1
  assign wr_en_1 = wr_req & (gry_to_bin == 4'd1);

  always @(posedge clks or negedge resetsn)
    begin : p_enc_data_rg1
      if (!resetsn)
        enc_data1 <= {9{1'b0}};
      else if (wr_en_1)
        enc_data1 <= enc_data_rg;
    end

  // Data Interface2
  assign wr_en_2 = wr_req & (gry_to_bin == 4'd2);

  always @(posedge clks or negedge resetsn)
    begin : p_enc_data_rg2
      if (!resetsn)
        enc_data2 <= {9{1'b0}};
      else if (wr_en_2)
        enc_data2 <= enc_data_rg;
    end
  assign encd_data0_s = enc_data0;
  assign encd_data1_s = enc_data1;
  assign encd_data2_s = enc_data2;


//----------------------------------------------------------------------------
// ASSERTIONS
//----------------------------------------------------------------------------

`ifdef ARM_ASSERT_ON

//-----------------------------------------------------------------------------
// When the async-bridge is full new TSBIT packets have to be discarded if it is
// less than last highest TSBIT packet. If it is greater than the previous highest
// packet, then this packet should replace it.
//-----------------------------------------------------------------------------
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxntsasyncbridge - FIFO FULL : TSBIT value updated when current value is less than stored value")
      uzovl_cxntsasyncbridge_fifo_full
        (
         .clk         (clks),
         .reset_n     (resetsn),
         .test_expr   ((tsbit_stky_next < tsbit_stky) &
                        async_fifo_full &
                        tsbit_stky_en)
        );

//-----------------------------------------------------------------------------
// Ensure that write-pointer is reset only when master interface acknowledges
// that it has read all the words in the fifo
//-----------------------------------------------------------------------------
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxntsasyncbridge - After csysreq is asserted - Write pointer reset before all words have been read")
      uzovl_cxntsasyncbridge_fifo_sysreq_slv
        (
         .clk         (clks),
         .reset_n     (resetsn),
         .test_expr   ((wr_ptr_gry_s_next != wr_ptr_gry_s_q) &
                       (wr_ptr_gry_s_next != incr_ptr_gry) &
                       (wr_ptr_gry_s_next == 4'd0) &
                        lp_ack_s_sync &
                        ~lp_req_s_q)
        );

//-----------------------------------------------------------------------------
// Low-Power FSM should not enter any of the unused states
// PWRUNUS0,PWRUNUS1,PWRUNUS2,PWRUNUS3,PWRUNUS4
//-----------------------------------------------------------------------------
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxntsasyncbridge - LP-FSM : Entered illegal state")
      uzovl_cxntsasyncbridge_lp_fsm_illegal
        (
         .clk         (clks),
         .reset_n     (resetsn),
         .test_expr   ((lp_fsm == PWRUNUS0) ||
                       (lp_fsm == PWRUNUS1) ||
                       (lp_fsm == PWRUNUS2) ||
                       (lp_fsm == PWRUNUS3) ||
                       (lp_fsm == PWRUNUS4))
        );

`endif // ARM_ASSERT_ON

endmodule
