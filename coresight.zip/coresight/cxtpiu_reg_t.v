//-----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2004-2015 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//    Checked In : $Date: 2014-08-14 16:01:35 +0100 (Thu, 14 Aug 2014) $
//    Revision   : $Revision: 39945 $
//    Release    : CoreSight-SoC-TM100-r3p2-00rel0
//-----------------------------------------------------------------------------
//  Purpose             : traceclkin domain register module for the TPIU block.
//                      : Contains control registers for TracePort logic
//-----------------------------------------------------------------------------

module cxtpiu_reg_t  (
  // Inputs
  traceclkin, tresetn, pwritedbg, paddrdbg31, device_un_locked,
  rd_wr_req_t_sync, paddrdbg, pwdatadbg, pattern_done,
  // Outputs
  rd_wr_ack_t, reg_update, pattern_counter_reg, form_sync_counter_reg,
  curr_patt_sel_reg, curr_patt_mode_reg, curr_port_sel_reg, read_data_t
  );

`include "cxtpiu_constants.v"

  // Inputs
  input         traceclkin;       // Traceclkin clock
  input         tresetn;          // Traceclkin asychronous reset active low
  input         pwritedbg;        // APB Write/!Read signal
  input         paddrdbg31;       // APB address marker to bypass lock access
  input         device_un_locked; // Allow Writes on paddrdbg==0
  input         rd_wr_req_t_sync; // Read/Write request from the APB interface
  input [11:2]  paddrdbg;         // APB Address bus
  input [31:0]  pwdatadbg;        // APB Write data bus
  input         pattern_done;     // Signal from the PattGen to de-activate patterns

  // Outputs
  output        rd_wr_ack_t;          // Return response for rd_wr_req_t signal
  output        reg_update;           // Pulse to force update of the counter registers
  output [7:0]  pattern_counter_reg;  // Test pattern repeat register
  output [11:0] form_sync_counter_reg;// Formatter synchronization register
  output [3:0]  curr_patt_sel_reg;    // Selected test pattern register
  output [1:0]  curr_patt_mode_reg;   // Current test pattern mode register
  output [31:0] curr_port_sel_reg;    // Current port size register
  output [31:0] read_data_t;          // Read data bus to the APB interface

  // ---------------------------------------------------------------------------
  //
  //                            Register Module
  //                            ===============
  //
  // ---------------------------------------------------------------------------
  //
  //
  // Overview
  // ========
  // traceclkin domain register block for the TPIU module.
  //
  // ---------------------------------------------------------------------------

  // ---------------------------------------------------------------------------
  // Internal signal declarations
  // ---------------------------------------------------------------------------
  wire          cur_port_size_wr_en;
  wire          cur_port_size_rd_en;
  wire          cur_test_sel_mode_wr_en;
  wire          cur_test_mode_wr_en;
  wire          cur_test_mode_rd_en;
  wire          test_pat_rep_wr_en;
  wire          test_pat_rep_rd_en;
  wire          form_sync_wr_en;
  wire          form_sync_rd_en;

  wire          reg_write;
  wire          reg_read;

  wire [31:0]   test_pat_rep_rd_data;
  wire [31:0]   form_sync_rd_data;
  wire [31:0]   cur_test_mode_rd_data;
  wire [31:0]   cur_port_size_rd_data;
  wire          nxt_reg_update;
  wire [1:0]    nxt_test_mode_reg;

  wire          rd_wr_ack_t;
  wire          rd_wr_ack_t_int;
  reg           rdwrackt_cdc_check;
  wire [7:0]    pattern_counter_reg;
  wire [7:0]    pattern_counter_reg_int;
  reg  [7:0]    patterncounterreg_cdc_check;
  wire [11:0]   form_sync_counter_reg;
  wire [11:0]   form_sync_counter_reg_int;
  reg  [11:0]   form_sync_counter_reg_cdc_check;
  wire [3:0]    curr_patt_sel_reg;
  wire [3:0]    curr_patt_sel_reg_int;
  reg  [3:0]    currpattselreg_cdc_check;
  wire [1:0]    curr_patt_mode_reg;
  wire [1:0]    curr_patt_mode_reg_int;
  reg  [1:0]    currpattmodereg_cdc_check;
  wire [31:0]   curr_port_sel_reg;
  wire [31:0]   curr_port_sel_reg_int;
  reg  [31:0]   currportselreg_cdc_check;

  reg           reg_update;

  wire          pattern_mode_rd_bit_0_reg_en;
  wire          pattern_mode_rd_bit_0_reg;
  reg           patternmoderdbit0reg_cdc_check;


  // ---------------------------------------------------------------------------
  //
  // Main body of code
  // =================
  //
  // ---------------------------------------------------------------------------

  // ---------------------------------------------------------------------------
  // Sequential block for the generation of the RdWrAckReg signal.
  // ---------------------------------------------------------------------------
  always @(posedge traceclkin or negedge tresetn)
  begin : p_rdwrack
    if (!tresetn)
       rdwrackt_cdc_check  <= 1'b0;
    else
       rdwrackt_cdc_check  <= rd_wr_req_t_sync;
  end // block: p_rdwrack

  // ---------------------------------------------------------------------------
  // Assigning the ValidRdWr signal
  // ---------------------------------------------------------------------------
  // Set write strobe at the end of the write
  assign reg_write  = (rd_wr_req_t_sync & ~rd_wr_ack_t_int & pwritedbg
                      & (device_un_locked | paddrdbg31));
  assign reg_read   = rd_wr_req_t_sync & ~pwritedbg;

  // ---------------------------------------------------------------------------
  // Current port size control register   : Offset 0x004 ( R/W )
  // ---------------------------------------------------------------------------
  always @(posedge traceclkin or negedge tresetn)
    begin : s_curportsizewr
      if (!tresetn)
         currportselreg_cdc_check  <= 32'h00000001;
      else
        if (cur_port_size_wr_en)
           currportselreg_cdc_check  <= pwdatadbg[31:0];
    end // block: s_curportsizewr

  assign cur_port_size_wr_en   = reg_write & (paddrdbg == CXTPIU_CURPORTSIZE_ADD);
  assign cur_port_size_rd_en   = reg_read & (paddrdbg == CXTPIU_CURPORTSIZE_ADD);
  assign cur_port_size_rd_data = curr_port_sel_reg_int;

  // ---------------------------------------------------------------------------
  // Current test mode register   : Offset 0x204 ( R/W )
  // ---------------------------------------------------------------------------
  // Selected Patterns (walking 1's, walking 0's, AA/55, 00/FF)
  always @(posedge traceclkin or negedge tresetn)
    begin : s_curtestpattwr
      if (!tresetn)
         currpattselreg_cdc_check   <= 4'b0000;
      else
        if (cur_test_sel_mode_wr_en)
           currpattselreg_cdc_check   <= pwdatadbg[3:0];
    end // block: s_curtestmodewr

  // Mode register (timed/continuous/off)
  always @(posedge traceclkin or negedge tresetn)
    begin : s_curtestmodewr
      if (!tresetn)
         currpattmodereg_cdc_check  <= 2'b00;
      else
        if (cur_test_mode_wr_en)
           currpattmodereg_cdc_check  <= nxt_test_mode_reg;
    end // block: s_curtestmodewr

  // Update the read register fot Pattern Mode bit0 at the start of
  // every access.This bit requires a seperate read register as it
  // state could change during a read.
  assign pattern_mode_rd_bit_0_reg_en  = (rd_wr_req_t_sync & ~rd_wr_ack_t_int);

  always @(posedge traceclkin)
    if (pattern_mode_rd_bit_0_reg_en)
      patternmoderdbit0reg_cdc_check <= curr_patt_mode_reg_int[0];

  // update the register value on writes and when the pattern completes
  assign cur_test_sel_mode_wr_en = reg_write & (paddrdbg == CXTPIU_CURTEST_ADD);
  assign cur_test_mode_wr_en    = cur_test_sel_mode_wr_en | pattern_done;
  assign cur_test_mode_rd_en    = reg_read & (paddrdbg == CXTPIU_CURTEST_ADD);
  assign nxt_test_mode_reg     = cur_test_sel_mode_wr_en ?
                              pwdatadbg[17:16] :
                              {curr_patt_mode_reg_int[1], 1'b0};
  assign cur_test_mode_rd_data  = {{14{1'b0}}, curr_patt_mode_reg_int[1], pattern_mode_rd_bit_0_reg,
                               {12{1'b0}}, curr_patt_sel_reg_int};

  // ---------------------------------------------------------------------------
  // Current test pattern register   : Offset 0x208 ( R/W )
  // ---------------------------------------------------------------------------
  always @(posedge traceclkin or negedge tresetn)
    begin : s_curtestpatwr
      if (!tresetn)
        patterncounterreg_cdc_check  <= {8{1'b0}};
      else
        if (test_pat_rep_wr_en)
           patterncounterreg_cdc_check  <= pwdatadbg[7:0];
    end // block: s_CurTestPat

  assign test_pat_rep_wr_en   = reg_write & (paddrdbg == CXTPIU_TESTREP_ADD);
  assign test_pat_rep_rd_en   = reg_read & (paddrdbg == CXTPIU_TESTREP_ADD);
  assign test_pat_rep_rd_data = {{24{1'b0}},pattern_counter_reg_int};

  // ---------------------------------------------------------------------------
  // Formatter synchronization register   : Offset 0x308 ( R/W )
  // ---------------------------------------------------------------------------
  always @(posedge traceclkin or negedge tresetn)
    begin : s_formsync
      if (!tresetn)
         form_sync_counter_reg_cdc_check  <= 12'h040;
      else
        if (form_sync_wr_en)
           form_sync_counter_reg_cdc_check  <= pwdatadbg[11:0];
    end // block: s_formsync

  assign form_sync_wr_en   = reg_write & (paddrdbg == CXTPIU_FORMSYNC_ADD);
  assign form_sync_rd_en   = reg_read  & (paddrdbg == CXTPIU_FORMSYNC_ADD);
  assign form_sync_rd_data = {{20{1'b0}},form_sync_counter_reg_int};

  // ---------------------------------------------------------------------------
  // Read Data Mux
  // ---------------------------------------------------------------------------
  assign read_data_t = (
                      ({32{cur_port_size_rd_en}} & cur_port_size_rd_data) |
                      ({32{cur_test_mode_rd_en}} & cur_test_mode_rd_data) |
                      ({32{test_pat_rep_rd_en}}  & test_pat_rep_rd_data)  |
                      ({32{form_sync_rd_en}}    & form_sync_rd_data)
                     );

  // Create an update pulse to allow counters to be re-started dynamically
  assign nxt_reg_update = ( form_sync_wr_en       |
                          test_pat_rep_wr_en     |
                          cur_test_sel_mode_wr_en |
                          cur_port_size_wr_en    );

  // Register update strobe - used to reload counters.
  always @(posedge traceclkin or negedge tresetn)
    if (!tresetn)
      reg_update <= 1'b0;
    else
      reg_update <= nxt_reg_update;


`ifdef ARM_CDC_ON
        cdc_connect #(1,0) u_cdc_currpattmodereg(
                .clk_launch(traceclkin),
                .clk_capture(cxtpiu.u_cxtpiu_apb_if.pclkdbg),
                .d_in(currpattmodereg_cdc_check),
                .d_out_async(curr_patt_mode_reg_int)
                );
`else
        assign curr_patt_mode_reg_int = currpattmodereg_cdc_check;
`endif
assign curr_patt_mode_reg = curr_patt_mode_reg_int;
`ifdef ARM_CDC_ON
        cdc_connect #(3,0) u_cdc_currpattselreg(
                .clk_launch(traceclkin),
                .clk_capture(cxtpiu.u_cxtpiu_apb_if.pclkdbg),
                .d_in(currpattselreg_cdc_check),
                .d_out_async(curr_patt_sel_reg_int)
                );
`else
        assign curr_patt_sel_reg_int = currpattselreg_cdc_check;
`endif
assign curr_patt_sel_reg = curr_patt_sel_reg_int;
`ifdef ARM_CDC_ON
        cdc_connect #(31,0) u_cdc_currportselreg(
                .clk_launch(traceclkin),
                .clk_capture(cxtpiu.u_cxtpiu_apb_if.pclkdbg),
                .d_in(currportselreg_cdc_check),
                .d_out_async(curr_port_sel_reg_int)
                );
`else
        assign curr_port_sel_reg_int = currportselreg_cdc_check;
`endif
assign curr_port_sel_reg = curr_port_sel_reg_int;
`ifdef ARM_CDC_ON
        cdc_connect #(11,0) u_cdc_formsynccounterreg(
                .clk_launch(traceclkin),
                .clk_capture(cxtpiu.u_cxtpiu_apb_if.pclkdbg),
                .d_in(form_sync_counter_reg_cdc_check),
                .d_out_async(form_sync_counter_reg_int)
                );
`else
        assign form_sync_counter_reg_int = form_sync_counter_reg_cdc_check;
`endif
assign form_sync_counter_reg = form_sync_counter_reg_int;
`ifdef ARM_CDC_ON
        cdc_connect #(7,0) u_cdc_patterncounterreg(
                .clk_launch(traceclkin),
                .clk_capture(cxtpiu.u_cxtpiu_apb_if.pclkdbg),
                .d_in(patterncounterreg_cdc_check),
                .d_out_async(pattern_counter_reg_int)
                );
`else
        assign pattern_counter_reg_int = patterncounterreg_cdc_check;
`endif
assign pattern_counter_reg = pattern_counter_reg_int;
`ifdef ARM_CDC_ON
        cdc_connect u_cdc_rdwrackt(
                .clk_launch(traceclkin),
                .clk_capture(cxtpiu.u_cxtpiu_apb_sync.u_rd_wr_ack_t.clk),
                .d_in(rdwrackt_cdc_check),
                .d_out_async(rd_wr_ack_t_int)
                );
`else
        assign rd_wr_ack_t_int = rdwrackt_cdc_check;
`endif
assign rd_wr_ack_t = rd_wr_ack_t_int;

`ifdef ARM_CDC_ON
        cdc_connect u_cdc_patternmoderdbit0reg(
                .clk_launch(traceclkin),
                .clk_capture(cxtpiu.u_cxtpiu_apb_if.pclkdbg),
                .d_in(patternmoderdbit0reg_cdc_check),
                .d_out_async(pattern_mode_rd_bit_0_reg)
                );
`else
        assign pattern_mode_rd_bit_0_reg = patternmoderdbit0reg_cdc_check;
`endif

endmodule // cxtpiu_reg_t
