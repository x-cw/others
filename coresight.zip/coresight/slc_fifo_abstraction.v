module slc_fifo_abstraction(/*autoarg*/
   // Outputs
   rd_data,
   // Inputs
   wr_clk, wr_en, wr_addr, wr_data, wr_strb, rd_clk, rd_en, rd_addr
   );
parameter FIFO_WORD = 16, FIFO_WIDTH = 32;
parameter FIFO_LOG2WORD = 4;
parameter MEM_BIT_EN = 0;
parameter PORT_TYPE = "NONE";  //SINGLE for 1port; DUALD for 2data1clock DUALC for 2data2clk
parameter MEM_WITH_FLOPS = 8192;

input wire wr_clk;
input wire wr_en;
input wire [FIFO_LOG2WORD-1:0] wr_addr;
input wire [FIFO_WIDTH-1:0] wr_data;
input wire [FIFO_WIDTH-1:0] wr_strb;

input wire rd_clk;
input wire rd_en;
input wire [FIFO_LOG2WORD-1:0] rd_addr;
output wire [FIFO_WIDTH-1:0] rd_data;

generate
if (PORT_TYPE == "SINGLE") begin : fifo_slc_single_port //for 1 data port
  if(FIFO_WIDTH * FIFO_WORD > MEM_WITH_FLOPS) begin 
    if (FIFO_WORD == 256 && FIFO_WIDTH == 256)
    begin: D256xW256 
    `ifdef SS8LPP
         codec_slc_256x256_wrapper #(.ADDR_BITS(8),.RAM_WIDTH(256))codec_slc_afifo_inst(
               // Outputs
            .QB (rd_data[255:0]),
            // Inputs
            .AB(rd_addr), 
            .AA(wr_addr), 
         //   .BWEB(wr_strb), 
            .CLKR(rd_clk), 
            .CLKW(wr_clk), 
            .DA(wr_data[255:0]), 
            .REB(~rd_en), 
            .WEB(~wr_en), 
            .RMA(4'b0100), 
            .WMDA(1'b0), 
            .RMB(4'b0100), 
            .TEST_RNMA(1'b0),
            .TEST1A(1'b0), 
            .TEST1B(1'b0), 
            .TESTRWM(1'b0)
         );
    `elsif SS14LPP
  initial assert (0) else
            $fatal("MEMORY %dx%d requested but not built",FIFO_WORD,FIFO_WIDTH);
         mem_model_not_defined #(
                                 .MEM_WORDS(FIFO_WORD),
                                 .MEM_WIDTH(FIFO_WIDTH)
                                 ) mem();
    `elsif TSMC12FFC
  initial assert (0) else
            $fatal("MEMORY %dx%d requested but not built",FIFO_WORD,FIFO_WIDTH);
               mem_model_not_defined #(
                                 .MEM_WORDS(FIFO_WORD),
                                 .MEM_WIDTH(FIFO_WIDTH)
                                 ) mem();
    `else
  initial assert (0) else
            $fatal("MEMORY %dx%d requested but not built",FIFO_WORD,FIFO_WIDTH);
         mem_model_not_defined #(
                                 .MEM_WORDS(FIFO_WORD),
                                 .MEM_WIDTH(FIFO_WIDTH)
                                 ) mem();
    `endif
    end      
    else if ( FIFO_WORD == 32 && FIFO_WIDTH == 290) begin : D32xW290
  initial assert (0) else
            $fatal("MEMORY %dx%d requested but not built",FIFO_WORD,FIFO_WIDTH);
                     mem_model_not_defined #(
                                   .MEM_WORDS(FIFO_WORD),
                                   .MEM_WIDTH(FIFO_WIDTH)
                                   ) mem();

    end
    else begin : mismatch_width_words
  initial assert (0) else
            $fatal("MEMORY %dx%d requested but not built",FIFO_WORD,FIFO_WIDTH);
                mem_model_not_defined #(
                                   .MEM_WORDS(FIFO_WORD),
                                   .MEM_WIDTH(FIFO_WIDTH)
                                   ) mem();
    end
  end else begin 
        mem_1r1w_flops
          #(.MEM_WORDS(FIFO_WORD), .MEM_WIDTH(FIFO_WIDTH), .MEM_BIT_EN(MEM_BIT_EN), .L2_MEM_WORDS(FIFO_LOG2WORD)) 
          ram (
          .wr_clk(wr_clk),
          .wr_en(wr_en),
          .wr_addr(wr_addr),
          .bit_en_internal(wr_strb),
          .din(wr_data),
          .rd_clk(rd_clk),
          .rd_en(rd_en),
          .rd_addr(rd_addr),
          .dout_internal(rd_data)
          );
  end
end
else if (PORT_TYPE == "DUALD") begin : fifo_slc_dual_port //for 2data ports and 1 clock port
  if(FIFO_WIDTH * FIFO_WORD > MEM_WITH_FLOPS) begin 
    if (FIFO_WORD == 256 && FIFO_WIDTH == 256)
    begin : D256xW256
    `ifdef SS8LPP
         codec_slc_256x256_wrapper #(.ADDR_BITS(8),.RAM_WIDTH(256))codec_slc_afifo_inst(
               // Outputs
            .QB (rd_data[255:0]),
            // Inputs
            .AB(rd_addr), 
            .AA(wr_addr), 
         //   .BWEB(wr_strb), 
            .CLKR(rd_clk), 
            .CLKW(wr_clk), 
            .DA(wr_data[255:0]), 
            .REB(~rd_en), 
            .WEB(~wr_en), 
            .RMA(4'b0100), 
            .WMDA(1'b0), 
            .RMB(4'b0100), 
            .TEST_RNMA(1'b0),
            .TEST1A(1'b0), 
            .TEST1B(1'b0), 
            .TESTRWM(1'b0)
            );
    `elsif TSMC12FFC
  initial assert (0) else
            $fatal("MEMORY %dx%d requested but not built",FIFO_WORD,FIFO_WIDTH);
                mem_model_not_defined #(
                                   .MEM_WORDS(FIFO_WORD),
                                   .MEM_WIDTH(FIFO_WIDTH)
                                   ) mem();

    `else
  initial assert (0) else
            $fatal("MEMORY %dx%d requested but not built",FIFO_WORD,FIFO_WIDTH);
                mem_model_not_defined #(
                                   .MEM_WORDS(FIFO_WORD),
                                   .MEM_WIDTH(FIFO_WIDTH)
                                   ) mem();

    `endif
    end      
    else if ( FIFO_WORD == 32 && FIFO_WIDTH == 290) begin : D32xW290
  initial assert (0) else
            $fatal("MEMORY %dx%d requested but not built",FIFO_WORD,FIFO_WIDTH);
                      mem_model_not_defined #(
                                    .MEM_WORDS(FIFO_WORD),
                                    .MEM_WIDTH(FIFO_WIDTH)
                                    ) mem();

    end
    else begin 
  initial assert (0) else
            $fatal("MEMORY %dx%d requested but not built",FIFO_WORD,FIFO_WIDTH);
                     mem_model_not_defined #(
                                   .MEM_WORDS(FIFO_WORD),
                                   .MEM_WIDTH(FIFO_WIDTH)
                                   ) mem();
    end
  end else begin 
        mem_1r1w_flops
          #(.MEM_WORDS(FIFO_WORD), .MEM_WIDTH(FIFO_WIDTH), .MEM_BIT_EN(MEM_BIT_EN), .L2_MEM_WORDS(FIFO_LOG2WORD)) 
          ram (
          .wr_clk(wr_clk),
          .wr_en(wr_en),
          .wr_addr(wr_addr),
          .bit_en_internal(wr_strb),
          .din(wr_data),
          .rd_clk(rd_clk),
          .rd_en(rd_en),
          .rd_addr(rd_addr),
          .dout_internal(rd_data)
          );
  end
end
else if (PORT_TYPE == "DUALC") begin : fifo_slc_dual_data_clk_port  //for 2data ports and 2 clock ports
  if(FIFO_WIDTH * FIFO_WORD > MEM_WITH_FLOPS) begin
    if (FIFO_WORD == 256 && FIFO_WIDTH == 256)
    begin : D256xW256
    `ifdef SS8LPP
         codec_slc_256x256_wrapper #(.ADDR_BITS(8),.RAM_WIDTH(256))codec_slc_afifo_inst(
               // Outputs
            .QB (rd_data[255:0]),
            // Inputs
            .AB(rd_addr), 
            .AA(wr_addr), 
         //   .BWEB(wr_strb), 
            .CLKR(rd_clk), 
            .CLKW(wr_clk), 
            .DA(wr_data[255:0]), 
            .REB(~rd_en), 
            .WEB(~wr_en), 
            .RMA(4'b0100), 
            .WMDA(1'b0), 
            .RMB(4'b0100), 
            .TEST_RNMA(1'b0),
            .TEST1A(1'b0), 
            .TEST1B(1'b0), 
            .TESTRWM(1'b0)
            );
         `elsif TSMC12FFC
         `else
         `endif
    end      
    else if ( FIFO_WORD == 32 && FIFO_WIDTH == 290) begin:D32xW290 
  initial assert (0) else
            $fatal("MEMORY %dx%d requested but not built",FIFO_WORD,FIFO_WIDTH);
                       mem_model_not_defined #(
                                    .MEM_WORDS(FIFO_WORD),
                                    .MEM_WIDTH(FIFO_WIDTH)
                                    ) mem();

    end
    else begin 
  initial assert (0) else
            $fatal("MEMORY %dx%d requested but not built",FIFO_WORD,FIFO_WIDTH);
                           mem_model_not_defined #(
                                    .MEM_WORDS(FIFO_WORD),
                                    .MEM_WIDTH(FIFO_WIDTH)
                                    ) mem();

    end
  end else begin 
        mem_1r1w_flops
          #(.MEM_WORDS(FIFO_WORD), .MEM_WIDTH(FIFO_WIDTH), .MEM_BIT_EN(MEM_BIT_EN), .L2_MEM_WORDS(FIFO_LOG2WORD)) 
          ram (
          .wr_clk(wr_clk),
          .wr_en(wr_en),
          .wr_addr(wr_addr),
          .bit_en_internal(wr_strb),
          .din(wr_data),
          .rd_clk(rd_clk),
          .rd_en(rd_en),
          .rd_addr(rd_addr),
          .dout_internal(rd_data)
          );
  end
end
else begin 
  initial assert (0) else
            $fatal("MEMORY %dx%d requested but not built",FIFO_WORD,FIFO_WIDTH);

                       mem_model_not_defined #(
                                   .MEM_WORDS(FIFO_WORD),
                                   .MEM_WIDTH(FIFO_WIDTH)
                                   ) mem();

end
endgenerate

endmodule
