//-----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2009-2010 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//    Checked In :  2010-05-25 19:42:46 +0530 (Tue, 25 May 2010) 
//    Revision   :  7768 
//    Release    : TM961-BU-50000-r0p0-00rel0
//
//-----------------------------------------------------------------------------
// Purpose: TMC APB Slave Interface
//-----------------------------------------------------------------------------

module cxtmc_apbslvif  
  #(
  parameter CXTMC_ATBM_AXIM_CFG = 0 // TMC configuration
  )

  (
  // Inputs
  input wire         CLK,            
  // clock

  input wire         PCLKENDBG,      
  // clock enable

  input wire         RESETn,         
  // reset

  input wire         PSELDBG,        
  // APB slave select

  input wire         PENABLEDBG,     
  // APB enable

  input wire         PWRITEDBG,      
  // APB write

  input wire  [11:2] PADDRDBG,       
  // APB address

  input wire         PADDRDBG31,     
  // APB address bit 31

  input wire  [31:0] PWDATADBG,      
  // APB write data

  output reg         PREADYDBG,
  // APB ready

  output reg  [31:0] PRDATADBG,
  // APB read data

  output wire        PSLVERRDBG,
  // APB error response

  // Authentication interface 
  input wire         DBGEN,
  input wire         SPIDEN,

  // Low Power interface - enables a reset controller to get the AXI 
  // interface to a stable state before reseting either the TMC or the AXI 
  // interconnect
  input  wire        CSYSREQ,
  output wire        CSYSACK,
  output wire        CACTIVE,

  // Inputs
  input wire  [31:0] read_data,      
  // read data

  input wire         apb_ready,      
  // Acknowledgement for completion of APB access

  input wire         apb_err,        
  // Error response to be returned on the APB

  input wire         axi_intf_pend,
  // On-going transfers on the AXI interface - used to assert CSYSACK

  // Outputs
  output reg         apb_valid,      
  // APB request valid

  output wire [11:2] apb_addr,     
  // registered APB address

  output wire        apb_addr31,   
  // registered APB PADDRDBG31

  output reg  [31:0] apb_wdata,    
  // registered APB write data

  output reg         pseldbg_r,      
  // registered APB PSEL

  output reg         pwritedbg_r,
  // registered APB write 

  output wire        dbgen_reg,
  // Registered DBGEN

  output wire        spiden_reg,
  // Registered SPIDEN

  output wire        csysreq_reg
  // Clocked version of CSYSREQ - registered to minimise load on input port
  );

  //---------------------------------------------------------------------------
  // Constant definitions
  //---------------------------------------------------------------------------
`include "cxtmc_constants.v"

  localparam PERIPHID3_ADDR      = 12'hFEC;    // Peripheral ID3 register            
  localparam PERIPHID3_CUSTOM    = 4'h0;       // Peripheral ID3 value
  localparam PERIPHID3_REVAND    = 4'h0;       // Peripheral ID3 value
  localparam CXTMC_RWD            = 10'h009;   // TMC RAM Write Data Register, 
                                               //   RWD

  //----------------------------------------------------------------------------
  // Wires
  //----------------------------------------------------------------------------
  wire        nxt_apb_valid;
  wire        nxt_preadydbg; 
  wire [31:0] nxt_prdatadbg;
  wire [31:0] periphid3_rd_data;
  wire        periphid3_sel;  
  wire        pready_no_wait;
  wire        pready_wait;
  wire        periph_id_3_rd_en;
  wire        nxt_csysack;

  //---------------------------------------------------------------------------
  // Registers
  //---------------------------------------------------------------------------
  reg [11:2]  paddrdbg_r;
  reg [3:0]   revand_reg;
  reg         paddrdbg31_r;
  reg         dbgen_reg_etr;
  reg         spiden_reg_etr;
  reg         csysreq_reg_etr;
  reg         csysack_etr;


  //---------------------------------------------------------------------------
  //
  // Main body of code
  // =================
  //
  //---------------------------------------------------------------------------

  // APB registered address and write data
  always @(posedge CLK)
  begin
    if (PCLKENDBG)
    begin
      pwritedbg_r       <= PWRITEDBG;
      paddrdbg_r[11:2]  <= PADDRDBG[11:2];
      paddrdbg31_r      <= PADDRDBG31;
      apb_wdata[31:0] <= PWDATADBG[31:0];
    end
  end

// Register PSELDBG - used in generation of tmc_clk_req in cxtmc_regfile module
  always @(posedge CLK or negedge RESETn)
  begin
    if (!RESETn)
      pseldbg_r  <= 1'b0;
    else if(PCLKENDBG)
      pseldbg_r  <= PSELDBG;
  end

  assign nxt_prdatadbg[31:0] = (periph_id_3_rd_en) ?
                                 periphid3_rd_data[31:0] :
                               (~pwritedbg_r & apb_valid & apb_ready) ?
                                 read_data[31:0] : PRDATADBG;

  // APB read data  
  always @(posedge CLK or negedge RESETn)
  begin
    if (!RESETn)
      PRDATADBG[31:0]  <= 32'h00000000;
    else if(PCLKENDBG)
      PRDATADBG[31:0]  <= nxt_prdatadbg[31:0];
  end

  //---------------------------------------------------------------------------
  // Peripheral ID3 Register (PID3)
  //---------------------------------------------------------------------------
  assign periphid3_sel           = (apb_addr[11:2] == PERIPHID3_ADDR[11:2]);
  assign periph_id_3_rd_en       = ~pwritedbg_r & periphid3_sel;
  assign periphid3_rd_data[31:0] = {{24{1'b0}},             // 31:8
                                    revand_reg[3:0],        // 7:4
                                    PERIPHID3_CUSTOM[3:0]   // 3:0
                                   };

  //---------------------------------------------------------------------------
  // The Rev-And data (bits 7:4) are driven from a register so that it
  // can be easily changed in the netlist.
  //---------------------------------------------------------------------------
  always @(posedge CLK)
    begin
      if(PCLKENDBG)
        revand_reg[3:0] <= PERIPHID3_REVAND[3:0];
    end

  // transaction is valid on internal interface
  //  - as soon as registered APB first phase is set 
  //  - until ready is returned 
  assign nxt_apb_valid = (~PENABLEDBG & PSELDBG) |
                         (apb_valid & ~apb_ready);

  always @(posedge CLK or negedge RESETn)
  begin
    if (!RESETn)
      apb_valid  <= 1'b0;
    else if(PCLKENDBG)
      apb_valid  <= nxt_apb_valid;
  end

  // PREADY is sampled with PCLKENDBG
  // PREADY is retured when after valid transaction is acknowledged with 
  // ready on handshaked internal interface
  assign nxt_preadydbg =  (!PSELDBG) ? 1'b0 :
                          ((PADDRDBG == CXTMC_RWD) || (!PWRITEDBG)) ? 
                            pready_wait : pready_no_wait;

  assign pready_no_wait = ~PENABLEDBG;

  assign pready_wait = apb_valid & apb_ready;

  always @(posedge CLK or negedge RESETn)
  begin
    if (!RESETn)
      PREADYDBG  <= 1'b0;
    else if(PCLKENDBG)
      PREADYDBG  <= nxt_preadydbg;
  end

//-----------------------------------------------------------------------------
// Error response on the APB
// In the ETB/ETF configurations, PSLVERRDBG is returned 0 for all APB 
// accesses.
//-----------------------------------------------------------------------------
generate
  if (CXTMC_ATBM_AXIM_CFG == CXTMC_CFG_ETR) // ETR configuration
    begin
      reg  pslverrdbg_etr;       // PSLVERRDBG in ETR configuration

      always @(posedge CLK or negedge RESETn)
      begin : p_pslverrdbg
        if (!RESETn)
          pslverrdbg_etr <= 1'b0;
        else if(PCLKENDBG)
          pslverrdbg_etr <= apb_err;
      end // block: p_pslverrdbg

      assign PSLVERRDBG = pslverrdbg_etr;
    end
  else // ETB/ETF configuration
    assign PSLVERRDBG = 1'b0;
endgenerate

//-----------------------------------------------------------------------------
// Prevent toggle on the internal address bus when the device is not
// selected.
//-----------------------------------------------------------------------------
assign apb_addr = paddrdbg_r & {10{pseldbg_r}};
assign apb_addr31 = paddrdbg31_r & pseldbg_r;

generate
  if (CXTMC_ATBM_AXIM_CFG == CXTMC_CFG_ETR) // ETR configuration
    begin
//-----------------------------------------------------------------------------
// Clocked process for registering in Authentication interface inputs for 
// timing purposes.
// Registered on free-running clock to ensure authentication setting changes
// are detected without delay. 
//-----------------------------------------------------------------------------
      always @(posedge CLK or negedge RESETn)
      begin : p_auth
        if (!RESETn)
          begin
            dbgen_reg_etr  <= 1'b0;
            spiden_reg_etr <= 1'b0;
          end
        else
          begin
            dbgen_reg_etr  <= DBGEN;
            spiden_reg_etr <= SPIDEN;
          end
      end // block: p_auth
      assign dbgen_reg  = dbgen_reg_etr;
      assign spiden_reg = spiden_reg_etr;

//----------------------------------------------------------------------------
// When CSYSREQ is asserted, wait for any pending AXI transfers to complete
// before issuing CSYSACK. Once CSYSACK is issued, it remains low till 
// CSYSREQ is asserted.
//----------------------------------------------------------------------------
      assign nxt_csysack = csysreq_reg | axi_intf_pend;

//----------------------------------------------------------------------------
// Clocked process for Low power signals
//----------------------------------------------------------------------------
      always @(posedge CLK or negedge RESETn)
      begin : p_lpi
        if (!RESETn)
          begin
            csysack_etr     <= 1'b0;
            csysreq_reg_etr <= 1'b0;
          end
        else
          begin
            csysack_etr     <= nxt_csysack;
            csysreq_reg_etr <= CSYSREQ;
          end
      end // block: p_lpi
      assign csysreq_reg = csysreq_reg_etr;
      assign CSYSACK     = csysack_etr;
    end
  else // ETB/ETF configurations
    begin
      assign dbgen_reg   = 1'b0;
      assign spiden_reg  = 1'b0;
      assign CSYSACK     = 1'b0;
      assign csysreq_reg = 1'b0;
    end
endgenerate

//----------------------------------------------------------------------------
// CACTIVE output is tied low since the TMC never refuses a Low Power
// request.
//----------------------------------------------------------------------------
assign CACTIVE = 1'b0;


`ifdef ARM_ASSERT_ON
//-----------------------------------------------------------------------------
// OVL Assertions
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// APB outputs must change only on a clock edge when PCLKEN is asserted
//-----------------------------------------------------------------------------
  reg        del_preadydbg;  // One-clock delayed version of PREADYDBG
  reg        del_pslverrdbg; // One-clock delayed version of PSLVERRDBG
  reg        del_pclkendbg;  // One-clock delayed version of PCLKENDBG

  always @(posedge CLK or negedge RESETn)
  begin : p_pclken
    if (!RESETn)
      begin
        del_preadydbg  <= 1'b0;
        del_pslverrdbg <= 1'b0;
        del_pclkendbg  <= 1'b0;
      end
    else
      begin
        del_preadydbg  <= PREADYDBG;
        del_pslverrdbg <= PSLVERRDBG;
        del_pclkendbg  <= PCLKENDBG;
      end
  end // block: p_pclken

  // PREADYDBG check
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxtmc_apbslvif - PREADYDBG output changing on a clock edge when PCLKEN is not asserted")
      uzovl_cxtmc_apbif_preadydbg
        (
         .clk         (CLK),
         .reset_n     (RESETn),
         .test_expr   ((PREADYDBG != del_preadydbg) & ~del_pclkendbg)
        );

  // PSLVERRDBG check
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxtmc_apbslvif - PSLVERRDBG output changing on a clock edge when PCLKEN is not asserted")
      uzovl_cxtmc_apbif_pslverrdbg
        (
         .clk         (CLK),
         .reset_n     (RESETn),
         .test_expr   ((PSLVERRDBG != del_pslverrdbg) & ~del_pclkendbg)
        );

  // If CSYSREQ is low, there must be no rising edge on axi_intf_pend
reg axi_intf_pend_reg;
reg csysreq_reg_2;

  always @(posedge CLK or negedge RESETn)
  begin : p_axi_pend_reg
    if (!RESETn)
      begin
        axi_intf_pend_reg <= 1'b0;
        csysreq_reg_2     <= 1'b0;
      end
    else
      begin
        axi_intf_pend_reg <= axi_intf_pend;
        csysreq_reg_2     <= csysreq_reg;
      end
  end // block: p_axi_pend_reg

  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxtmc_apbslvif - If CSYSREQ is low, there must be no rising edge on axi_intf_pend")
      uzovl_cxtmc_apbif_csysreq_axi_intf_pend
        (
         .clk         (CLK),
         .reset_n     (RESETn),
         .test_expr   (~csysreq_reg_2 & axi_intf_pend & ~axi_intf_pend_reg)
        );

`endif

endmodule // cxtmc_apbslvif
