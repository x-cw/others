`include "../general/general.vh"


module gp_fifo_sync 
  #(parameter
    ENABLE_INIT_INPUT=0,
    FIFO_WIDTH=0,
    FIFO_WORDS=0,
    AFULL_THRESH=0,
    AEMPTY_THRESH=0,
    FULL_FLOP = 0,
    
    L2_FIFO_WORDS=log2(FIFO_WORDS)
    ) (
       input wire                    clk,
       input wire                    reset_n,
       
       input wire                    init,
       
       //read
       input wire                    rd_en,
       output wire [FIFO_WIDTH-1:0]   dout,
       
       //write
       input wire                    wr_en,
       input wire [FIFO_WIDTH-1:0]   din,
       
       //status
       output wire                   aempty,
       output reg                    afull, 
       output wire                   empty,
       output reg                    full,
       output reg                    overflow,
       output reg                    underflow,
       output wire [L2_FIFO_WORDS:0] valid_entries
       );

`include "../general/misc.vh"
  
  localparam
    MEM_WORDS=FIFO_WORDS,
    MEM_WIDTH=FIFO_WIDTH,
    LOG2WORDS=L2_FIFO_WORDS,
    L2_MEM_WORDS=log2(MEM_WORDS);


  reg  [L2_FIFO_WORDS-1:0] wr_addr;    // write address for fifo RAM
  reg  [L2_FIFO_WORDS-1:0] rd_addr;    // read address for fifo RAM
  wire fifo_ctl_empty;             // fifo empty from point-of-view of gp_fifo_ctl
  wire [L2_FIFO_WORDS:0] fifo_valid_entries; // number of entries from point-of-view of gp_fifo_ctl
  
  // signals for what will actually go to the fifo ctl/ram
  wire actual_wr_en;
  wire actual_rd_en;
  reg flopped_full ;
  wire do_xfr;                   // reading fifo reg at next clock
  wire ld_fiforeg;               // transfer data to fifo reg
  reg fiforeg_valid;             // fifo reg output is valid (matches next read address data)
  reg actual_rd_en_dly;
  wire [FIFO_WIDTH-1:0] dout_tmp; 
  reg [FIFO_WIDTH-1:0] actual_rdata; 
    


  assign actual_wr_en  = wr_en;

  assign do_xfr = fiforeg_valid && rd_en;  // read fifo reg whenever xmt/rcv both ready
  // update fifo reg when have fifo data, and register is either empty, or about to empty (be read)
  assign ld_fiforeg = !fifo_ctl_empty && (!fiforeg_valid || do_xfr);

  always @(posedge clk, negedge reset_n) begin
    // asynchronous clear JK flop
    if (!reset_n)   fiforeg_valid <= 1'b0;
    else begin
      if(init)
       fiforeg_valid <= 1'b0;
      else if (ld_fiforeg)  fiforeg_valid <= 1'b1; // loading fifo reg, so will be valid
      else if (do_xfr) fiforeg_valid <= 1'b0; // reading, but not refilling
    end
  end  
  
  assign empty = ~fiforeg_valid;
  assign actual_rd_en = ld_fiforeg;  // read fifo toput read pointer data into fifo reg
  assign valid_entries = fifo_valid_entries + (empty ? 1'b0 : 1'b1);

  wire [LOG2WORDS-1:0] wr_addr_p1 = wr_addr + 1'b1;
  wire [LOG2WORDS-1:0] rd_addr_p1 = rd_addr + 1'b1;

  always @(posedge clk, negedge reset_n) begin
    if (!reset_n)  wr_addr <= 0;
    else if(init)     wr_addr <= 0;
    else if (wr_en)   wr_addr <= (wr_addr_p1 == FIFO_WORDS) ? 0 : wr_addr_p1;
  end

  always @(posedge clk, negedge reset_n) begin
    if (!reset_n)  rd_addr <= 0;
    else if(init)     rd_addr <= 0;
    else if (actual_rd_en)   rd_addr <= (rd_addr_p1 == FIFO_WORDS) ? 0 : rd_addr_p1;
  end

      // with common read/write clock flag generation is simplified, and can use all fifo words
      reg [LOG2WORDS:0] valid_cnt; // number of entries used (extra bit so can count up to MEM_WORDS)
      wire [LOG2WORDS:0] valid_cnt_p1 = valid_cnt + 1;
      wire [LOG2WORDS:0] valid_cnt_m1 = valid_cnt - 1;
      
      always @(posedge clk, negedge reset_n) begin
        if (!reset_n)          valid_cnt <= 0;
        else if(init)         valid_cnt <= 0; 
        else if (wr_en && !actual_rd_en) valid_cnt <= valid_cnt_p1;
        else if (!wr_en && actual_rd_en) valid_cnt <= valid_cnt_m1;
      end

      if (FULL_FLOP) begin: full_flop
        always @(posedge clk, negedge reset_n) begin
          if (!reset_n)          flopped_full <= 0;
          else if(init)         flopped_full <= 0;
          else if (wr_en && !actual_rd_en) flopped_full <= (valid_cnt_p1 == MEM_WORDS);
          else if (!wr_en && actual_rd_en) flopped_full <= (valid_cnt_m1 == MEM_WORDS);
          else                      flopped_full <= (valid_cnt == MEM_WORDS); // redundant, but adds resiliancy
        end
        assign full = flopped_full ;
      end
      else begin: not_full_flop
        assign full = (valid_cnt >= MEM_WORDS);
      end

      if (AFULL_THRESH == MEM_WORDS) begin: afull_thresh_words
        assign afull = full;
      end else begin: not_afull_thres_words
        assign afull  = (valid_cnt >= AFULL_THRESH);
      end
      assign fifo_ctl_empty  = (valid_cnt == 0);
      if (AEMPTY_THRESH == 0) begin: aempty_thresh_zero
        assign aempty = fifo_ctl_empty;
      end else begin: not_aempty_thresh_zero
        assign aempty = (valid_cnt <= AEMPTY_THRESH);
      end
      
      assign fifo_valid_entries = valid_cnt;

  // under and over flow flag generation
  always @(posedge clk, negedge reset_n) begin
    if (!reset_n)        overflow <= 1'b0;
    else if(init)       overflow <= 1'b0;
    else if (wr_en && full) overflow <= 1'b1;
  end
  
  always @(posedge clk, negedge reset_n) begin
    if (!reset_n)         underflow <= 1'b0;
    else if(init)        underflow <= 1'b0;
    else if (rd_en && empty) underflow <= 1'b1;
  end
  

  /*mem_1r1w_sync auto_template "\(.*\)" (
   .MEM_BIT_EN(0),
   .MEM_FAST(0),
   .\(^[A-Z].*\)(\1),
   .clk(clk),
   .bit_en({@"vl-width"{1'b1}}),
   .\(.*\)(@_\1),
   );*/
  
  mem_1r1w_sync #(/*autoinstparam*/
             // Parameters
             .MEM_WORDS                 (MEM_WORDS),             // Templated
             .MEM_WIDTH                 (MEM_WIDTH),             // Templated
             .L2_MEM_WORDS              (L2_MEM_WORDS))          // Templated
  fifo(/*autoinst*/
       // Outputs
       .dout                            (dout_tmp),             // Templated
       // Inputs
       .clk                             (clk),           // Templated
       .din                             (din),              // Templated
       .rd_addr                         (rd_addr),          // Templated
       .rd_en                           (actual_rd_en),            // Templated
       .wr_addr                         (wr_addr),          // Templated
       .wr_en                           (actual_wr_en));           // Templated
  
  always @(posedge clk, negedge reset_n) begin
    if (!reset_n)         actual_rd_en_dly <= 1'b0;
    else                     actual_rd_en_dly <= actual_rd_en;
  end

 always @(posedge clk, negedge reset_n) begin
    if (!reset_n)         actual_rdata <= {(FIFO_WIDTH){1'b0}};
    else if (actual_rd_en_dly) actual_rdata <= dout_tmp;
  end
assign dout = actual_rd_en_dly ? dout_tmp : actual_rdata;
//assign dout = dout_tmp;//actual_rdata;
 

endmodule
// Local Variables:
// verilog-library-flags:("-y ../memories")
// End:
