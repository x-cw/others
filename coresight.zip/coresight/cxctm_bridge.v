//--========================================================================
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2012-2015 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//    Checked In : $Date: 2014-08-14 16:01:35 +0100 (Thu, 14 Aug 2014) $
//    Revision   : $Revision: 39945 $
//    Release    : CoreSight-SoC-TM100-r3p2-00rel0
//
//-----------------------------------------------------------------------------
// Purpose :
//           ECT Channel Interconnect Module
// This module contains the interconnection logic (effectively original CSCTM.v
// but without the synchronisers)
// --=========================================================================--

module cxctm_bridge
  (
  // Inputs
  ctmresetn, ctmclk, ctmclken, cisbypass1, cisbypass2, cisbypass3,
  cisbypass0, cihsbypass1, cihsbypass2, cihsbypass3, cihsbypass0,
  ctmchin1, ctmchin2, ctmchin3, ctmchin0, ctmchoutack1, ctmchoutack2,
  ctmchoutack3, ctmchoutack0, ctm_chin_1_sync_2, ctm_chin_2_sync_2,
  ctm_chin_3_sync_2, ctm_chin_0_sync_2, ctm_chout_ack_1_sync_2, ctm_chout_ack_2_sync_2,
  ctm_chout_ack_3_sync_2, ctm_chout_ack_0_sync_2,
  // Outputs
  ctmchout1, ctmchout2, ctmchout3, ctmchout0, ctmchinack1,
  ctmchinack2, ctmchinack3, ctmchinack0
  );

`include "cxctm_constants.v"

  input                        ctmresetn;    // Reset
  input                        ctmclk;       // Clock
  input                        ctmclken;     // Clock Enable

  input                        cisbypass1;   // Sync bypass for port 1
  input                        cisbypass2;   // Sync bypass for port 2
  input                        cisbypass3;   // Sync bypass for port 3
  input                        cisbypass0;   // Sync bypass for port 0

  input [ECTCHANNELWIDTH-1:0]  cihsbypass1;  // Handshaking bypass port 1
  input [ECTCHANNELWIDTH-1:0]  cihsbypass2;  // Handshaking bypass port 2
  input [ECTCHANNELWIDTH-1:0]  cihsbypass3;  // Handshaking bypass port 3
  input [ECTCHANNELWIDTH-1:0]  cihsbypass0;  // Handshaking bypass port 0

  input [ECTCHANNELWIDTH-1:0]  ctmchin1;        // Channel In port 1
  input [ECTCHANNELWIDTH-1:0]  ctmchin2;        // Channel In port 2
  input [ECTCHANNELWIDTH-1:0]  ctmchin3;        // Channel In port 3
  input [ECTCHANNELWIDTH-1:0]  ctmchin0;        // Channel In port 0

  input [ECTCHANNELWIDTH-1:0]  ctmchoutack1;    // Channel Out ACK port 1
  input [ECTCHANNELWIDTH-1:0]  ctmchoutack2;    // Channel Out ACK port 2
  input [ECTCHANNELWIDTH-1:0]  ctmchoutack3;    // Channel Out ACK port 3
  input [ECTCHANNELWIDTH-1:0]  ctmchoutack0;    // Channel Out ACK port 0

  input [ECTCHANNELWIDTH-1:0]  ctm_chin_1_sync_2;  // Synchronised CHIN for port 1
  input [ECTCHANNELWIDTH-1:0]  ctm_chin_2_sync_2;  // Synchronised CHIN for port 2
  input [ECTCHANNELWIDTH-1:0]  ctm_chin_3_sync_2;  // Synchronised CHIN for port 3
  input [ECTCHANNELWIDTH-1:0]  ctm_chin_0_sync_2;  // Synchronised CHIN for port 0

  input [ECTCHANNELWIDTH-1:0]  ctm_chout_ack_1_sync_2; // Synced CHOUTACK on port 1
  input [ECTCHANNELWIDTH-1:0]  ctm_chout_ack_2_sync_2; // Synced CHOUTACK on port 2
  input [ECTCHANNELWIDTH-1:0]  ctm_chout_ack_3_sync_2; // Synced CHOUTACK on port 3
  input [ECTCHANNELWIDTH-1:0]  ctm_chout_ack_0_sync_2; // Synced CHOUTACK on port 0

  //----------------------------------------------------------------------------
  // OUTPUTS
  //----------------------------------------------------------------------------
  output [ECTCHANNELWIDTH-1:0] ctmchout1;       // Channel OUT port 1
  output [ECTCHANNELWIDTH-1:0] ctmchout2;       // Channel OUT port 2
  output [ECTCHANNELWIDTH-1:0] ctmchout3;       // Channel OUT port 3
  output [ECTCHANNELWIDTH-1:0] ctmchout0;       // Channel OUT port 0

  output [ECTCHANNELWIDTH-1:0] ctmchinack1;     // Channel IN ACK port 1
  output [ECTCHANNELWIDTH-1:0] ctmchinack2;     // Channel IN ACK port 2
  output [ECTCHANNELWIDTH-1:0] ctmchinack3;     // Channel IN ACK port 3
  output [ECTCHANNELWIDTH-1:0] ctmchinack0;     // Channel IN ACK port 0


  //----------------------------------------------------------------------------
  // WIRES AND REGS
  //----------------------------------------------------------------------------

  // Sync Bypass mux output
  wire [ECTCHANNELWIDTH-1:0]   ctm_chin_1_synced; // for port 1
  wire [ECTCHANNELWIDTH-1:0]   ctm_chin_2_synced; // for port 2
  wire [ECTCHANNELWIDTH-1:0]   ctm_chin_3_synced; // for port 3
  wire [ECTCHANNELWIDTH-1:0]   ctm_chin_0_synced; // for port 0

  // Next state of Channel IN ACK output
  wire [ECTCHANNELWIDTH-1:0]   nxt_chin_ack_1;    // for port 1
  wire [ECTCHANNELWIDTH-1:0]   nxt_chin_ack_2;    // for port 2
  wire [ECTCHANNELWIDTH-1:0]   nxt_chin_ack_3;    // for port 3
  wire [ECTCHANNELWIDTH-1:0]   nxt_chin_ack_0;    // for port 0

  // Channel IN ACK output
  reg [ECTCHANNELWIDTH-1:0]    ctmchinack1;       // for port 1
  reg [ECTCHANNELWIDTH-1:0]    ctmchinack2;       // for port 2
  reg [ECTCHANNELWIDTH-1:0]    ctmchinack3;       // for port 3
  reg [ECTCHANNELWIDTH-1:0]    ctmchinack0;       // for port 0

  // Or product of channel events
  wire [ECTCHANNELWIDTH-1:0]   ctmor1;            // for port 1
  wire [ECTCHANNELWIDTH-1:0]   ctmor2;            // for port 2
  wire [ECTCHANNELWIDTH-1:0]   ctmor3;            // for port 3
  wire [ECTCHANNELWIDTH-1:0]   ctmor0;            // for port 0

  // Sync Bypass mux output for CHOUTACK
  wire [ECTCHANNELWIDTH-1:0]   ctm_chout_ack_1_synced;// for port 1
  wire [ECTCHANNELWIDTH-1:0]   ctm_chout_ack_2_synced;// for port 2
  wire [ECTCHANNELWIDTH-1:0]   ctm_chout_ack_3_synced;// for port 3
  wire [ECTCHANNELWIDTH-1:0]   ctm_chout_ack_0_synced;// for port 0

  // Next state of channel output holder
  wire [ECTCHANNELWIDTH-1:0]   nxt_chout_holder_1;   // for port 1
  wire [ECTCHANNELWIDTH-1:0]   nxt_chout_holder_2;   // for port 2
  wire [ECTCHANNELWIDTH-1:0]   nxt_chout_holder_3;   // for port 3
  wire [ECTCHANNELWIDTH-1:0]   nxt_chout_holder_0;   // for port 0

  // Channel output holders
  // - hold event active until interfacing
  //   device acknowledged.
  reg [ECTCHANNELWIDTH-1:0]    choutholder1;         // for port 1
  reg [ECTCHANNELWIDTH-1:0]    choutholder2;         // for port 2
  reg [ECTCHANNELWIDTH-1:0]    choutholder3;         // for port 3
  reg [ECTCHANNELWIDTH-1:0]    choutholder0;         // for port 0

  //----------------------------------------------------------------------------
  //
  // MAIN CODE
  //
  //----------------------------------------------------------------------------

  //----------------------------------------------------------------------------
  // CHANNEL IN
  //----------------------------------------------------------------------------

  // Channel input sync bypass mux
  assign ctm_chin_1_synced = (cisbypass1==1'b1) ? ctmchin1 : ctm_chin_1_sync_2;
  assign ctm_chin_2_synced = (cisbypass2==1'b1) ? ctmchin2 : ctm_chin_2_sync_2;
  assign ctm_chin_3_synced = (cisbypass3==1'b1) ? ctmchin3 : ctm_chin_3_sync_2;
  assign ctm_chin_0_synced = (cisbypass0==1'b1) ? ctmchin0 : ctm_chin_0_sync_2;

  //----------------------------------------------------------------------------
  // CHANNEL IN ACK
  //----------------------------------------------------------------------------
  // Channel input ACK (bitwise operation)
  // Note: If need to disable ACK output for H/S bypass, the code below
  // can be modified as NxtCHINACKx = CTMCHINxSynced & (~(CIHSBYPASSx))

  assign nxt_chin_ack_1 = ctm_chin_1_synced;

  // Generate input acknowledge
  always @(posedge ctmclk or negedge ctmresetn)
    begin
      if (!ctmresetn)
        begin
          ctmchinack1 <= {ECTCHANNELWIDTH{1'b1}};
        end
      else if (ctmclken)
        begin
          ctmchinack1 <= nxt_chin_ack_1;
        end
    end

  assign nxt_chin_ack_2 = ctm_chin_2_synced;

  // Generate input acknowledge
  always @(posedge ctmclk or negedge ctmresetn)
    begin
      if (!ctmresetn)
        begin
          ctmchinack2 <= {ECTCHANNELWIDTH{1'b1}};
        end
      else if (ctmclken)
        begin
          ctmchinack2 <= nxt_chin_ack_2;
        end
    end

  assign nxt_chin_ack_3 = ctm_chin_3_synced;

  // Generate input acknowledge
  always @(posedge ctmclk or negedge ctmresetn)
    begin
      if (!ctmresetn)
        begin
          ctmchinack3 <= {ECTCHANNELWIDTH{1'b1}};
        end
      else if (ctmclken)
        begin
          ctmchinack3 <= nxt_chin_ack_3;
        end
    end

  assign nxt_chin_ack_0 = ctm_chin_0_synced;

  // Generate input acknowledge
  always @(posedge ctmclk or negedge ctmresetn)
    begin
      if (!ctmresetn)
        begin
          ctmchinack0 <= {ECTCHANNELWIDTH{1'b1}};
        end
      else if (ctmclken)
        begin
          ctmchinack0 <= nxt_chin_ack_0;
        end
    end

  //----------------------------------------------------------------------------
  // OR GATES
  //----------------------------------------------------------------------------
  // OR stage to combine channel events
  assign ctmor1   = ctm_chin_0_synced | ctm_chin_2_synced | ctm_chin_3_synced;
  assign ctmor2   = ctm_chin_0_synced | ctm_chin_1_synced | ctm_chin_3_synced;
  assign ctmor3   = ctm_chin_0_synced | ctm_chin_1_synced | ctm_chin_2_synced;
  assign ctmor0   = ctm_chin_1_synced | ctm_chin_2_synced | ctm_chin_3_synced;


  //----------------------------------------------------------------------------
  // CHANNEL OUT ACK
  //----------------------------------------------------------------------------

  // Channel output ACK sync bypass mux
  assign ctm_chout_ack_1_synced = (cisbypass1==1'b1) ?
                                  ctmchoutack1 : ctm_chout_ack_1_sync_2;

  // Channel output ACK sync bypass mux
  assign ctm_chout_ack_2_synced = (cisbypass2==1'b1) ?
                                  ctmchoutack2 : ctm_chout_ack_2_sync_2;

  // Channel output ACK sync bypass mux
  assign ctm_chout_ack_3_synced = (cisbypass3==1'b1) ?
                                  ctmchoutack3 : ctm_chout_ack_3_sync_2;

  // Channel output ACK sync bypass mux
  assign ctm_chout_ack_0_synced = (cisbypass0==1'b1) ?
                                  ctmchoutack0 : ctm_chout_ack_0_sync_2;

  //----------------------------------------------------------------------------
  // CHANNEL OUT
  //----------------------------------------------------------------------------
  // Channel output
  // Set on an incoming cross trigger signal, cleared on ACK (or Auto-ACK on
  //   H/S Bypass)

  assign nxt_chout_holder_1 = (ctmor1 | (choutholder1 &
                                      ~(ctm_chout_ack_1_synced | cihsbypass1)));

  assign nxt_chout_holder_2 = (ctmor2 | (choutholder2 &
                                      ~(ctm_chout_ack_2_synced | cihsbypass2)));

  assign nxt_chout_holder_3 = (ctmor3 | (choutholder3 &
                                      ~(ctm_chout_ack_3_synced | cihsbypass3)));

  assign nxt_chout_holder_0 = (ctmor0 | (choutholder0 &
                                      ~(ctm_chout_ack_0_synced | cihsbypass0)));


  // Output holder registers
  always @(posedge ctmclk or negedge ctmresetn)
    begin
      if (!ctmresetn)
        begin
          choutholder1 <= {ECTCHANNELWIDTH{1'b0}};
        end
      else if (ctmclken)
        begin
          choutholder1 <= nxt_chout_holder_1;
        end
    end

  always @(posedge ctmclk or negedge ctmresetn)
    begin
      if (!ctmresetn)
        begin
          choutholder2 <= {ECTCHANNELWIDTH{1'b0}};
        end
      else if (ctmclken)
        begin
          choutholder2 <= nxt_chout_holder_2;
        end
    end

  always @(posedge ctmclk or negedge ctmresetn)
    begin
      if (!ctmresetn)
        begin
          choutholder3 <= {ECTCHANNELWIDTH{1'b0}};
        end
      else if (ctmclken)
        begin
          choutholder3 <= nxt_chout_holder_3;
        end
    end

  always @(posedge ctmclk or negedge ctmresetn)
    begin
      if (!ctmresetn)
        begin
          choutholder0 <= {ECTCHANNELWIDTH{1'b0}};
        end
      else if (ctmclken)
        begin
          choutholder0 <= nxt_chout_holder_0;
        end
    end

  // Connect holding register to higher level
  assign ctmchout1   = choutholder1;
  assign ctmchout2   = choutholder2;
  assign ctmchout3   = choutholder3;
  assign ctmchout0   = choutholder0;

endmodule // cxctm_bridge
