//-----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2004-2015 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//
//      Checked In          : $Date: 2014-10-20 14:48:21 +0100 (Mon, 20 Oct 2014) $
//
//      Revision            : $Revision: 40301 $
//
//      Release Information : CoreSight-SoC-TM100-r3p2-00rel0
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// Abstract : double-flop synchronizer with enable. Reset to 0
//-----------------------------------------------------------------------------

module cx_en_sync (
  clk,
  resetn,
  clken,
  sync_di,
  sync_do
  );

input  clk;
input  resetn;
input  clken;
input  sync_di;

output reg sync_do;

reg  sync_reg;
wire sync_di_i;

`ifdef ARM_CDC_ON

  cdc_random_en #(.WIDTH(1)) u_rand_en (
                           .din   (sync_di),
                           .dout  (sync_di_i),
                           .resetn(resetn));
`else

  assign sync_di_i = sync_di;

`endif


always @ (posedge clk or negedge resetn)
  begin
    if (~resetn)
      begin
        sync_reg  <= 1'b0;
        sync_do   <= 1'b0;
      end
    else if (clken)
      begin
        sync_reg  <= sync_di_i;
        sync_do   <= sync_reg;
      end
  end

endmodule // cx_en_sync
