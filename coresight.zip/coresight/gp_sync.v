/* GP_SYNC - Copyright (C) 2008 Immediasemi Corp.
  Revision history:                                                                              100
    mm/dd/2008 <name>           <description>
    04/21/2008 John Iler        original

  General purpose synchronizer.
*/
`include "../general/general.vh"

module gp_sync 
  #(parameter
    BITS = 1,      // bit width of 'din' and 'dout'
    RANDOMIZE_BITS_TOGETHER = 0, // if set, then randomized latency applied identically to all bits
    ASSERT_FOR_FAST_CHANGES = 1
  )
  (
    input wire clk,             // synchronizing clock
    input wire reset_n,         // general reset
  
    input wire [BITS-1:0] din,  // data to be synchronized
    output reg [BITS-1:0] dout /* synthesis syn_allow_retiming=0 */ // synchronized data
  );

  reg [BITS-1:0] dmid /* synthesis syn_allow_retiming=0 */ ;    // output of first sync flop
  
  always @(posedge clk, negedge reset_n) begin
    if (!reset_n) begin
      // may not be strictly necessary, but may reduce required 'reset' clock cycles
      dout <= 0;
      dmid <= 0;
    end
    else begin
      dout <= dmid;
      dmid <= din;
    end
  end
    
endmodule
