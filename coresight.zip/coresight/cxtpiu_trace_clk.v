//-----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2004-2015 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//    Checked In : $Date: 2014-06-25 08:42:22 +0100 (Wed, 25 Jun 2014) $
//    Revision   : $Revision: 39629 $
//    Release    : CoreSight-SoC-TM100-r3p2-00rel0
//-----------------------------------------------------------------------------
//  Purpose             : Generates the exported half-rate clock that enables
//                        suitable sampling of tracedata/tracectl signals.
//  **NOTE**
//  Previously traceclk was generated from a negative-edge register (or a
// positive-edge with an inverted clock). However to simplify tools flow, this
// has been changed to just a positive edge register that requires a timing
// path fixup during layout to move the data edges of traceclk to align with the
// centre of data on tracedata/tracectl.
//-----------------------------------------------------------------------------

module cxtpiu_trace_clk (
  // Inputs
  traceclkin, tresetn,
  // Outputs
  traceclk
  );

  input          traceclkin; // clock source
  input          tresetn;    // Reset
  output         traceclk;   // Exported Clock (traceclkin/2)

  wire           traceclk;
  reg            traceclk_int;
  wire           nxt_traceclk;

  assign         nxt_traceclk = ~traceclk_int;

  // Exported clock register
  always @(posedge traceclkin or negedge tresetn)
    if (!tresetn)
      traceclk_int <= 1'b0;
    else
      traceclk_int <= nxt_traceclk;

  assign traceclk = traceclk_int;

endmodule // cxtpiu_trace_clk
