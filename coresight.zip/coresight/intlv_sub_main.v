//+FHDR*************************************************************************
// 
//   Copyright (c) 2025 Innosilicon. Ltd.  All rights reserved. 
// 
//   THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF INNOSILICON
//   The copyright notice above does not evidence any actual or intended
//   publication of such source code.
// 
//************************************************************************
//    Module name: intlv_sub_main.v
//    Create by  : chenqw
//    Email      : chenqw@innosilicon.com.cn
//    Create time: 2025-01-22
//************************************************************************
//    Description: modify by fangxn for new structure
//-FHDR*************************************************************************

module intlv_sub_main  #(
    parameter    IDW        =   8,                      // the width of awid/arid
    parameter    ADDRW      =   51,                     // the width of awaddr/araddr
    parameter    LENW       =   4,                      // the width of awlen/arlen
    parameter    USERW      =   10,
    parameter    ATOPW      =   6,
    parameter    WXP        =   IDW+ADDRW+LENW+3+2+3+4+4+USERW+ATOPW+1,
    parameter    ST1_SW     =   51,
    parameter    ST2_SW     =   23, 
    parameter    SLICE_0    =   1,                      // 2'd0: bypass 2'd1: forward  2'd2:backward 2'd3 full
    parameter    SLICE_1    =   1,
    parameter    SLICE_2    =   1
)(

    input   wire        [IDW-1:0]       upstrm_id,
    input   wire        [ADDRW-1:0]     upstrm_addr,
    input   wire        [LENW-1:0]      upstrm_len,
    input   wire        [2:0]           upstrm_size,
    input   wire        [1:0]           upstrm_burst,
    input   wire        [2:0]           upstrm_prot,
    input   wire        [3:0]           upstrm_cache,
    input   wire        [3:0]           upstrm_qos,
    input   wire        [USERW-1:0]     upstrm_user,
    input   wire        [ATOPW-1:0]     upstrm_atop,
    input   wire                        upstrm_lock,

    output  wire        [IDW-1:0]       downstrm_id,
    output  wire        [ADDRW-1:0]     downstrm_addr,
    output  wire        [LENW-1:0]      downstrm_len,
    output  wire        [2:0]           downstrm_size,
    output  wire        [1:0]           downstrm_burst,
    output  wire        [2:0]           downstrm_prot,
    output  wire        [3:0]           downstrm_cache,
    output  wire        [3:0]           downstrm_qos,
    output  wire        [USERW-1:0]     downstrm_user,
    output  wire        [ATOPW-1:0]     downstrm_atop,
    output  wire                        downstrm_lock,

    input   wire        [79:0]          bank_damage, 

    input   wire    [6:0]   ddr_intlv_bankid_0,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_1,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_2,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_3,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_4,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_5,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_6,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_7,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_8,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_9,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_10,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_11,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_12,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_13,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_14,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_15,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_16,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_17,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_18,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_19,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_20,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_21,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_22,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_23,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_24,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_25,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_26,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_27,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_28,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_29,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_30,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_31,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_32,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_33,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_34,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_35,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_36,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_37,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_38,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_39,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_40,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_41,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_42,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_43,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_44,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_45,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_46,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_47,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_48,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_49,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_50,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_51,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_52,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_53,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_54,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_55,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_56,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_57,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_58,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_59,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_60,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_61,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_62,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_63,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_64,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_65,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_66,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_67,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_68,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_69,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_70,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_71,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_72,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_73,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_74,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_75,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_76,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_77,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_78,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_79,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    
    input   wire    [6:0]   buf_intlv_bankid_0,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_1,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_2,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_3,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_4,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_5,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_6,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_7,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_8,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_9,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_10,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_11,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_12,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_13,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_14,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_15,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_16,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_17,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_18,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_19,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_20,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_21,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_22,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_23,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_24,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_25,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_26,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_27,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_28,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_29,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_30,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_31,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_32,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_33,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_34,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_35,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_36,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_37,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_38,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_39,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_40,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_41,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_42,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_43,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_44,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_45,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_46,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_47,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_48,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_49,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_50,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_51,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_52,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_53,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_54,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_55,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_56,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_57,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_58,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_59,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_60,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_61,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_62,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_63,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_64,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_65,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_66,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_67,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_68,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_69,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_70,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_71,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_72,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_73,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_74,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_75,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_76,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_77,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_78,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_79,     //bankid_offset_in buf intlv after considering bank damage and bufc damage


/*autoinput*/
// Beginning of automatic inputs (from unused autoinst inputs)
input [6:0]             bank_num,               // To intlv_stage_2_inst of intlv_stage_2.v
input [3:0]             bankid_sel_0_0,         // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             bankid_sel_0_1,         // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             bankid_sel_0_2,         // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             bankid_sel_0_3,         // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             bankid_sel_0_4,         // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             bankid_sel_0_5,         // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             bankid_sel_0_6,         // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             bankid_sel_0_7,         // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             bankid_sel_1_0,         // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             bankid_sel_1_1,         // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             bankid_sel_1_2,         // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             bankid_sel_1_3,         // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             bankid_sel_1_4,         // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             bankid_sel_1_5,         // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             bankid_sel_1_6,         // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             bankid_sel_1_7,         // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             bankid_sel_2_0,         // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             bankid_sel_2_1,         // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             bankid_sel_2_2,         // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             bankid_sel_2_3,         // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             bankid_sel_2_4,         // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             bankid_sel_2_5,         // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             bankid_sel_2_6,         // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             bankid_sel_2_7,         // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             bankid_sel_3_0,         // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             bankid_sel_3_1,         // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             bankid_sel_3_2,         // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             bankid_sel_3_3,         // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             bankid_sel_3_4,         // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             bankid_sel_3_5,         // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             bankid_sel_3_6,         // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             bankid_sel_3_7,         // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             bankid_sel_4_0,         // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             bankid_sel_4_1,         // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             bankid_sel_4_2,         // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             bankid_sel_4_3,         // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             bankid_sel_4_4,         // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             bankid_sel_4_5,         // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             bankid_sel_4_6,         // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             bankid_sel_4_7,         // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             bankid_sel_5_0,         // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             bankid_sel_5_1,         // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             bankid_sel_5_2,         // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             bankid_sel_5_3,         // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             bankid_sel_5_4,         // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             bankid_sel_5_5,         // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             bankid_sel_5_6,         // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             bankid_sel_5_7,         // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             bankid_sel_6_0,         // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             bankid_sel_6_1,         // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             bankid_sel_6_2,         // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             bankid_sel_6_3,         // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             bankid_sel_6_4,         // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             bankid_sel_6_5,         // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             bankid_sel_6_6,         // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             bankid_sel_6_7,         // To intlv_stage_1_inst of intlv_stage_1.v
input                   clk,                    // To intlv_slice_0 of intlv_slice.v, ...
input [6:0]             ddrch_num,              // To intlv_stage_2_inst of intlv_stage_2.v
input                   downstrm_ready,         // To intlv_slice_2 of intlv_slice.v
input                   rst_n,                  // To intlv_slice_0 of intlv_slice.v, ...
input [35:0]            scenario_ddr_cfghash,   // To intlv_stage_1_inst of intlv_stage_1.v
input [35:0]            scenario_ddr_lnhash,    // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             scenario_l2c_lnhash,    // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             setid_sel_0_0,          // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             setid_sel_0_1,          // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             setid_sel_0_2,          // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             setid_sel_0_3,          // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             setid_sel_0_4,          // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             setid_sel_0_5,          // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             setid_sel_0_6,          // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             setid_sel_0_7,          // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             setid_sel_1_0,          // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             setid_sel_1_1,          // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             setid_sel_1_2,          // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             setid_sel_1_3,          // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             setid_sel_1_4,          // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             setid_sel_1_5,          // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             setid_sel_1_6,          // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             setid_sel_1_7,          // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             setid_sel_2_0,          // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             setid_sel_2_1,          // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             setid_sel_2_2,          // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             setid_sel_2_3,          // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             setid_sel_2_4,          // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             setid_sel_2_5,          // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             setid_sel_2_6,          // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             setid_sel_2_7,          // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             setid_sel_3_0,          // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             setid_sel_3_1,          // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             setid_sel_3_2,          // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             setid_sel_3_3,          // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             setid_sel_3_4,          // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             setid_sel_3_5,          // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             setid_sel_3_6,          // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             setid_sel_3_7,          // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             setid_sel_4_0,          // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             setid_sel_4_1,          // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             setid_sel_4_2,          // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             setid_sel_4_3,          // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             setid_sel_4_4,          // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             setid_sel_4_5,          // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             setid_sel_4_6,          // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             setid_sel_4_7,          // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             setid_sel_5_0,          // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             setid_sel_5_1,          // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             setid_sel_5_2,          // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             setid_sel_5_3,          // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             setid_sel_5_4,          // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             setid_sel_5_5,          // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             setid_sel_5_6,          // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             setid_sel_5_7,          // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             setid_sel_6_0,          // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             setid_sel_6_1,          // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             setid_sel_6_2,          // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             setid_sel_6_3,          // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             setid_sel_6_4,          // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             setid_sel_6_5,          // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             setid_sel_6_6,          // To intlv_stage_1_inst of intlv_stage_1.v
input [3:0]             setid_sel_6_7,          // To intlv_stage_1_inst of intlv_stage_1.v
input                   upstrm_valid,           // To intlv_slice_0 of intlv_slice.v
// End of automatics
/*autooutput*/
// Beginning of automatic outputs (from unused autoinst outputs)
//output [WXP:0]          downstrm_payload,       // From intlv_slice_2 of intlv_slice.v
output                  downstrm_valid,         // From intlv_slice_2 of intlv_slice.v
output                  upstrm_ready            // From intlv_slice_0 of intlv_slice.v
// End of automatics
);

/*autowire*/
// Beginning of automatic wires (for undeclared instantiated-module outputs)
wire [WXP-1:0]                   slice0_payload_o;       // From intlv_slice_0 of intlv_slice.v
wire                             slice0_ready_i;         // From intlv_slice_1 of intlv_slice.v
wire                             slice0_valid_o;         // From intlv_slice_0 of intlv_slice.v
wire [ST1_SW+WXP-1:0]            slice1_payload_i;       // From intlv_stage_1_inst of intlv_stage_1.v
wire [ST1_SW+WXP-1:0]            slice1_payload_o;      // From intlv_slice_1 of intlv_slice.v
wire                             slice1_ready_i;         // From intlv_slice_2 of intlv_slice.v
wire                             slice1_valid_o;         // From intlv_slice_1 of intlv_slice.v
wire                             slice2_ready_i;
wire                             slice2_valid_o;  
wire [ST1_SW+ST2_SW+WXP-29-1:0]  slice2_payload_o;
wire [WXP-1:0]                   slice2_payload_i;



// End of automatics

wire    [WXP-1:0]     slice0_payload_i;
wire    [WXP-1:0]     downstrm_payload;

assign  slice0_payload_i = {upstrm_id,upstrm_len,upstrm_size,upstrm_burst,upstrm_prot,upstrm_cache,upstrm_qos,upstrm_atop,upstrm_lock,upstrm_user,upstrm_addr};


intlv_slice #(
    .PLD_W  (WXP),
    .TMO    (SLICE_0)
) intlv_slice_0 (
    /*autoinst*/
                 // Outputs
                 .ready_o               (upstrm_ready),          // Templated
                 .valid_o               (slice0_valid_o),        // Templated
                 .payload_o             (slice0_payload_o[WXP-1:0]), // Templated
                 // Inputs
                 .aclk_i                (clk),                   // Templated
                 .aresetn_i             (rst_n),                 // Templated
                 .ready_i               (slice0_ready_i),        // Templated
                 .valid_i               (upstrm_valid),          // Templated
                 .payload_i             (slice0_payload_i[WXP-1:0])); // Templated


intlv_stage_1  #(
    .IDW     (IDW), 
    .ADDRW   (ADDRW), 
    .LENW    (LENW), 
    .USERW   (USERW),    
    .ATOPW   (ATOPW),
    .WXP     (WXP),
    .ST1_SW  (ST1_SW)
) intlv_stage_1_inst (
    /*autoinst*/
                      // Outputs
                      .slice_payload_o  (slice1_payload_i[ST1_SW+WXP-1:0]), // Templated
                      // Inputs
                      .clk              (clk),
                      .rst_n            (rst_n),
                      .scenario_ddr_lnhash(scenario_ddr_lnhash[35:0]),
                      .scenario_ddr_cfghash(scenario_ddr_cfghash[35:0]),
                      .scenario_l2c_lnhash(scenario_l2c_lnhash[3:0]),
                      .ddrch_num        (ddrch_num[6:0]),
                      .bank_num         (bank_num[6:0]),
                      .bankid_sel_0_0   (bankid_sel_0_0[3:0]),
                      .bankid_sel_0_1   (bankid_sel_0_1[3:0]),
                      .bankid_sel_0_2   (bankid_sel_0_2[3:0]),
                      .bankid_sel_0_3   (bankid_sel_0_3[3:0]),
                      .bankid_sel_0_4   (bankid_sel_0_4[3:0]),
                      .bankid_sel_0_5   (bankid_sel_0_5[3:0]),
                      .bankid_sel_0_6   (bankid_sel_0_6[3:0]),
                      .bankid_sel_0_7   (bankid_sel_0_7[3:0]),
                      .bankid_sel_1_0   (bankid_sel_1_0[3:0]),
                      .bankid_sel_1_1   (bankid_sel_1_1[3:0]),
                      .bankid_sel_1_2   (bankid_sel_1_2[3:0]),
                      .bankid_sel_1_3   (bankid_sel_1_3[3:0]),
                      .bankid_sel_1_4   (bankid_sel_1_4[3:0]),
                      .bankid_sel_1_5   (bankid_sel_1_5[3:0]),
                      .bankid_sel_1_6   (bankid_sel_1_6[3:0]),
                      .bankid_sel_1_7   (bankid_sel_1_7[3:0]),
                      .bankid_sel_2_0   (bankid_sel_2_0[3:0]),
                      .bankid_sel_2_1   (bankid_sel_2_1[3:0]),
                      .bankid_sel_2_2   (bankid_sel_2_2[3:0]),
                      .bankid_sel_2_3   (bankid_sel_2_3[3:0]),
                      .bankid_sel_2_4   (bankid_sel_2_4[3:0]),
                      .bankid_sel_2_5   (bankid_sel_2_5[3:0]),
                      .bankid_sel_2_6   (bankid_sel_2_6[3:0]),
                      .bankid_sel_2_7   (bankid_sel_2_7[3:0]),
                      .bankid_sel_3_0   (bankid_sel_3_0[3:0]),
                      .bankid_sel_3_1   (bankid_sel_3_1[3:0]),
                      .bankid_sel_3_2   (bankid_sel_3_2[3:0]),
                      .bankid_sel_3_3   (bankid_sel_3_3[3:0]),
                      .bankid_sel_3_4   (bankid_sel_3_4[3:0]),
                      .bankid_sel_3_5   (bankid_sel_3_5[3:0]),
                      .bankid_sel_3_6   (bankid_sel_3_6[3:0]),
                      .bankid_sel_3_7   (bankid_sel_3_7[3:0]),
                      .bankid_sel_4_0   (bankid_sel_4_0[3:0]),
                      .bankid_sel_4_1   (bankid_sel_4_1[3:0]),
                      .bankid_sel_4_2   (bankid_sel_4_2[3:0]),
                      .bankid_sel_4_3   (bankid_sel_4_3[3:0]),
                      .bankid_sel_4_4   (bankid_sel_4_4[3:0]),
                      .bankid_sel_4_5   (bankid_sel_4_5[3:0]),
                      .bankid_sel_4_6   (bankid_sel_4_6[3:0]),
                      .bankid_sel_4_7   (bankid_sel_4_7[3:0]),
                      .bankid_sel_5_0   (bankid_sel_5_0[3:0]),
                      .bankid_sel_5_1   (bankid_sel_5_1[3:0]),
                      .bankid_sel_5_2   (bankid_sel_5_2[3:0]),
                      .bankid_sel_5_3   (bankid_sel_5_3[3:0]),
                      .bankid_sel_5_4   (bankid_sel_5_4[3:0]),
                      .bankid_sel_5_5   (bankid_sel_5_5[3:0]),
                      .bankid_sel_5_6   (bankid_sel_5_6[3:0]),
                      .bankid_sel_5_7   (bankid_sel_5_7[3:0]),
                      .bankid_sel_6_0   (bankid_sel_6_0[3:0]),
                      .bankid_sel_6_1   (bankid_sel_6_1[3:0]),
                      .bankid_sel_6_2   (bankid_sel_6_2[3:0]),
                      .bankid_sel_6_3   (bankid_sel_6_3[3:0]),
                      .bankid_sel_6_4   (bankid_sel_6_4[3:0]),
                      .bankid_sel_6_5   (bankid_sel_6_5[3:0]),
                      .bankid_sel_6_6   (bankid_sel_6_6[3:0]),
                      .bankid_sel_6_7   (bankid_sel_6_7[3:0]),
                      .setid_sel_0_0    (setid_sel_0_0[3:0]),
                      .setid_sel_0_1    (setid_sel_0_1[3:0]),
                      .setid_sel_0_2    (setid_sel_0_2[3:0]),
                      .setid_sel_0_3    (setid_sel_0_3[3:0]),
                      .setid_sel_0_4    (setid_sel_0_4[3:0]),
                      .setid_sel_0_5    (setid_sel_0_5[3:0]),
                      .setid_sel_0_6    (setid_sel_0_6[3:0]),
                      .setid_sel_0_7    (setid_sel_0_7[3:0]),
                      .setid_sel_1_0    (setid_sel_1_0[3:0]),
                      .setid_sel_1_1    (setid_sel_1_1[3:0]),
                      .setid_sel_1_2    (setid_sel_1_2[3:0]),
                      .setid_sel_1_3    (setid_sel_1_3[3:0]),
                      .setid_sel_1_4    (setid_sel_1_4[3:0]),
                      .setid_sel_1_5    (setid_sel_1_5[3:0]),
                      .setid_sel_1_6    (setid_sel_1_6[3:0]),
                      .setid_sel_1_7    (setid_sel_1_7[3:0]),
                      .setid_sel_2_0    (setid_sel_2_0[3:0]),
                      .setid_sel_2_1    (setid_sel_2_1[3:0]),
                      .setid_sel_2_2    (setid_sel_2_2[3:0]),
                      .setid_sel_2_3    (setid_sel_2_3[3:0]),
                      .setid_sel_2_4    (setid_sel_2_4[3:0]),
                      .setid_sel_2_5    (setid_sel_2_5[3:0]),
                      .setid_sel_2_6    (setid_sel_2_6[3:0]),
                      .setid_sel_2_7    (setid_sel_2_7[3:0]),
                      .setid_sel_3_0    (setid_sel_3_0[3:0]),
                      .setid_sel_3_1    (setid_sel_3_1[3:0]),
                      .setid_sel_3_2    (setid_sel_3_2[3:0]),
                      .setid_sel_3_3    (setid_sel_3_3[3:0]),
                      .setid_sel_3_4    (setid_sel_3_4[3:0]),
                      .setid_sel_3_5    (setid_sel_3_5[3:0]),
                      .setid_sel_3_6    (setid_sel_3_6[3:0]),
                      .setid_sel_3_7    (setid_sel_3_7[3:0]),
                      .setid_sel_4_0    (setid_sel_4_0[3:0]),
                      .setid_sel_4_1    (setid_sel_4_1[3:0]),
                      .setid_sel_4_2    (setid_sel_4_2[3:0]),
                      .setid_sel_4_3    (setid_sel_4_3[3:0]),
                      .setid_sel_4_4    (setid_sel_4_4[3:0]),
                      .setid_sel_4_5    (setid_sel_4_5[3:0]),
                      .setid_sel_4_6    (setid_sel_4_6[3:0]),
                      .setid_sel_4_7    (setid_sel_4_7[3:0]),
                      .setid_sel_5_0    (setid_sel_5_0[3:0]),
                      .setid_sel_5_1    (setid_sel_5_1[3:0]),
                      .setid_sel_5_2    (setid_sel_5_2[3:0]),
                      .setid_sel_5_3    (setid_sel_5_3[3:0]),
                      .setid_sel_5_4    (setid_sel_5_4[3:0]),
                      .setid_sel_5_5    (setid_sel_5_5[3:0]),
                      .setid_sel_5_6    (setid_sel_5_6[3:0]),
                      .setid_sel_5_7    (setid_sel_5_7[3:0]),
                      .setid_sel_6_0    (setid_sel_6_0[3:0]),
                      .setid_sel_6_1    (setid_sel_6_1[3:0]),
                      .setid_sel_6_2    (setid_sel_6_2[3:0]),
                      .setid_sel_6_3    (setid_sel_6_3[3:0]),
                      .setid_sel_6_4    (setid_sel_6_4[3:0]),
                      .setid_sel_6_5    (setid_sel_6_5[3:0]),
                      .setid_sel_6_6    (setid_sel_6_6[3:0]),
                      .setid_sel_6_7    (setid_sel_6_7[3:0]),
                      .slice_payload_i  (slice0_payload_o[WXP-1:0])); // Templated


intlv_slice #(
    .PLD_W  (ST1_SW+WXP),
    .TMO    (SLICE_1)
) intlv_slice_1 (
    /*autoinst*/
                 // Outputs
                 .ready_o               (slice0_ready_i),        // Templated
                 .valid_o               (slice1_valid_o),        // Templated
                 .payload_o             (slice1_payload_o), // Templated
                 // Inputs
                 .aclk_i                (clk),                   // Templated
                 .aresetn_i             (rst_n),                 // Templated
                 .ready_i               (slice1_ready_i),        // Templated
                 .valid_i               (slice0_valid_o),        // Templated
                 .payload_i             (slice1_payload_i)); // Templated

intlv_stage_2  #(
    .IDW    (IDW           ), 
    .ADDRW  (ADDRW         ), 
    .WXP0   (ST1_SW+WXP-29 ),
    .WXP    (ST1_SW+WXP    ), 
    .ST2_SW (ST2_SW)       
) intlv_stage_2_inst (
    /*autoinst*/
                      // Outputs
                      .slice_payload_o  (slice2_payload_o), // Templated
                      // Inputs
                      .clk              (clk),
                      .rst_n            (rst_n),
                      .i_up_valid       (slice1_valid_o     ),
                      .o_up_ready       (slice1_ready_i     ),
                      .o_down_valid     (slice2_valid_o     ),
                      .i_down_ready     (slice2_ready_i     ),

                       .slice_payload_i  (slice1_payload_o)); // Templated

intlv_stage_3  #(
    .IDW   (IDW), 
    .ADDRW (ADDRW), 
    .WXP0  (WXP  ),
    .WXP   (ST1_SW+ST2_SW+WXP-29) 
) intlv_stage_3_inst (
                      .clk                   (clk                                     ),
                      .rst_n                 (rst_n                                   ),
                      .scenario_ddr_lnhash   (scenario_ddr_lnhash[35:0]               ),
                      .scenario_ddr_cfghash  (scenario_ddr_cfghash[35:0]              ),
                      .scenario_l2c_lnhash   (scenario_l2c_lnhash[3:0]                ),
                      .ddr_intlv_bankid_0    (ddr_intlv_bankid_0                      ), 
                      .ddr_intlv_bankid_1    (ddr_intlv_bankid_1                      ), 
                      .ddr_intlv_bankid_2    (ddr_intlv_bankid_2                      ), 
                      .ddr_intlv_bankid_3    (ddr_intlv_bankid_3                      ), 
                      .ddr_intlv_bankid_4    (ddr_intlv_bankid_4                      ), 
                      .ddr_intlv_bankid_5    (ddr_intlv_bankid_5                      ), 
                      .ddr_intlv_bankid_6    (ddr_intlv_bankid_6                      ), 
                      .ddr_intlv_bankid_7    (ddr_intlv_bankid_7                      ), 
                      .ddr_intlv_bankid_8    (ddr_intlv_bankid_8                      ), 
                      .ddr_intlv_bankid_9    (ddr_intlv_bankid_9                      ), 
                      .ddr_intlv_bankid_10   (ddr_intlv_bankid_10                     ), 
                      .ddr_intlv_bankid_11   (ddr_intlv_bankid_11                     ), 
                      .ddr_intlv_bankid_12   (ddr_intlv_bankid_12                     ), 
                      .ddr_intlv_bankid_13   (ddr_intlv_bankid_13                     ), 
                      .ddr_intlv_bankid_14   (ddr_intlv_bankid_14                     ), 
                      .ddr_intlv_bankid_15   (ddr_intlv_bankid_15                     ), 
                      .ddr_intlv_bankid_16   (ddr_intlv_bankid_16                     ), 
                      .ddr_intlv_bankid_17   (ddr_intlv_bankid_17                     ), 
                      .ddr_intlv_bankid_18   (ddr_intlv_bankid_18                     ), 
                      .ddr_intlv_bankid_19   (ddr_intlv_bankid_19                     ), 
                      .ddr_intlv_bankid_20   (ddr_intlv_bankid_20                     ), 
                      .ddr_intlv_bankid_21   (ddr_intlv_bankid_21                     ), 
                      .ddr_intlv_bankid_22   (ddr_intlv_bankid_22                     ), 
                      .ddr_intlv_bankid_23   (ddr_intlv_bankid_23                     ), 
                      .ddr_intlv_bankid_24   (ddr_intlv_bankid_24                     ), 
                      .ddr_intlv_bankid_25   (ddr_intlv_bankid_25                     ), 
                      .ddr_intlv_bankid_26   (ddr_intlv_bankid_26                     ), 
                      .ddr_intlv_bankid_27   (ddr_intlv_bankid_27                     ), 
                      .ddr_intlv_bankid_28   (ddr_intlv_bankid_28                     ), 
                      .ddr_intlv_bankid_29   (ddr_intlv_bankid_29                     ), 
                      .ddr_intlv_bankid_30   (ddr_intlv_bankid_30                     ), 
                      .ddr_intlv_bankid_31   (ddr_intlv_bankid_31                     ), 
                      .ddr_intlv_bankid_32   (ddr_intlv_bankid_32                     ), 
                      .ddr_intlv_bankid_33   (ddr_intlv_bankid_33                     ), 
                      .ddr_intlv_bankid_34   (ddr_intlv_bankid_34                     ), 
                      .ddr_intlv_bankid_35   (ddr_intlv_bankid_35                     ), 
                      .ddr_intlv_bankid_36   (ddr_intlv_bankid_36                     ), 
                      .ddr_intlv_bankid_37   (ddr_intlv_bankid_37                     ), 
                      .ddr_intlv_bankid_38   (ddr_intlv_bankid_38                     ), 
                      .ddr_intlv_bankid_39   (ddr_intlv_bankid_39                     ), 
                      .ddr_intlv_bankid_40   (ddr_intlv_bankid_40                     ), 
                      .ddr_intlv_bankid_41   (ddr_intlv_bankid_41                     ), 
                      .ddr_intlv_bankid_42   (ddr_intlv_bankid_42                     ), 
                      .ddr_intlv_bankid_43   (ddr_intlv_bankid_43                     ), 
                      .ddr_intlv_bankid_44   (ddr_intlv_bankid_44                     ), 
                      .ddr_intlv_bankid_45   (ddr_intlv_bankid_45                     ), 
                      .ddr_intlv_bankid_46   (ddr_intlv_bankid_46                     ), 
                      .ddr_intlv_bankid_47   (ddr_intlv_bankid_47                     ), 
                      .ddr_intlv_bankid_48   (ddr_intlv_bankid_48                     ), 
                      .ddr_intlv_bankid_49   (ddr_intlv_bankid_49                     ), 
                      .ddr_intlv_bankid_50   (ddr_intlv_bankid_50                     ), 
                      .ddr_intlv_bankid_51   (ddr_intlv_bankid_51                     ), 
                      .ddr_intlv_bankid_52   (ddr_intlv_bankid_52                     ), 
                      .ddr_intlv_bankid_53   (ddr_intlv_bankid_53                     ), 
                      .ddr_intlv_bankid_54   (ddr_intlv_bankid_54                     ), 
                      .ddr_intlv_bankid_55   (ddr_intlv_bankid_55                     ), 
                      .ddr_intlv_bankid_56   (ddr_intlv_bankid_56                     ), 
                      .ddr_intlv_bankid_57   (ddr_intlv_bankid_57                     ), 
                      .ddr_intlv_bankid_58   (ddr_intlv_bankid_58                     ), 
                      .ddr_intlv_bankid_59   (ddr_intlv_bankid_59                     ), 
                      .ddr_intlv_bankid_60   (ddr_intlv_bankid_60                     ), 
                      .ddr_intlv_bankid_61   (ddr_intlv_bankid_61                     ), 
                      .ddr_intlv_bankid_62   (ddr_intlv_bankid_62                     ), 
                      .ddr_intlv_bankid_63   (ddr_intlv_bankid_63                     ), 
                      .ddr_intlv_bankid_64   (ddr_intlv_bankid_64                     ), 
                      .ddr_intlv_bankid_65   (ddr_intlv_bankid_65                     ), 
                      .ddr_intlv_bankid_66   (ddr_intlv_bankid_66                     ), 
                      .ddr_intlv_bankid_67   (ddr_intlv_bankid_67                     ), 
                      .ddr_intlv_bankid_68   (ddr_intlv_bankid_68                     ), 
                      .ddr_intlv_bankid_69   (ddr_intlv_bankid_69                     ), 
                      .ddr_intlv_bankid_70   (ddr_intlv_bankid_70                     ), 
                      .ddr_intlv_bankid_71   (ddr_intlv_bankid_71                     ), 
                      .ddr_intlv_bankid_72   (ddr_intlv_bankid_72                     ), 
                      .ddr_intlv_bankid_73   (ddr_intlv_bankid_73                     ), 
                      .ddr_intlv_bankid_74   (ddr_intlv_bankid_74                     ), 
                      .ddr_intlv_bankid_75   (ddr_intlv_bankid_75                     ), 
                      .ddr_intlv_bankid_76   (ddr_intlv_bankid_76                     ), 
                      .ddr_intlv_bankid_77   (ddr_intlv_bankid_77                     ), 
                      .ddr_intlv_bankid_78   (ddr_intlv_bankid_78                     ), 
                      .ddr_intlv_bankid_79   (ddr_intlv_bankid_79                     ), 
                                             
                      .buf_intlv_bankid_0    (buf_intlv_bankid_0                      ), 
                      .buf_intlv_bankid_1    (buf_intlv_bankid_1                      ), 
                      .buf_intlv_bankid_2    (buf_intlv_bankid_2                      ), 
                      .buf_intlv_bankid_3    (buf_intlv_bankid_3                      ), 
                      .buf_intlv_bankid_4    (buf_intlv_bankid_4                      ), 
                      .buf_intlv_bankid_5    (buf_intlv_bankid_5                      ), 
                      .buf_intlv_bankid_6    (buf_intlv_bankid_6                      ), 
                      .buf_intlv_bankid_7    (buf_intlv_bankid_7                      ), 
                      .buf_intlv_bankid_8    (buf_intlv_bankid_8                      ), 
                      .buf_intlv_bankid_9    (buf_intlv_bankid_9                      ), 
                      .buf_intlv_bankid_10   (buf_intlv_bankid_10                     ), 
                      .buf_intlv_bankid_11   (buf_intlv_bankid_11                     ), 
                      .buf_intlv_bankid_12   (buf_intlv_bankid_12                     ), 
                      .buf_intlv_bankid_13   (buf_intlv_bankid_13                     ), 
                      .buf_intlv_bankid_14   (buf_intlv_bankid_14                     ), 
                      .buf_intlv_bankid_15   (buf_intlv_bankid_15                     ), 
                      .buf_intlv_bankid_16   (buf_intlv_bankid_16                     ), 
                      .buf_intlv_bankid_17   (buf_intlv_bankid_17                     ), 
                      .buf_intlv_bankid_18   (buf_intlv_bankid_18                     ), 
                      .buf_intlv_bankid_19   (buf_intlv_bankid_19                     ), 
                      .buf_intlv_bankid_20   (buf_intlv_bankid_20                     ), 
                      .buf_intlv_bankid_21   (buf_intlv_bankid_21                     ), 
                      .buf_intlv_bankid_22   (buf_intlv_bankid_22                     ), 
                      .buf_intlv_bankid_23   (buf_intlv_bankid_23                     ), 
                      .buf_intlv_bankid_24   (buf_intlv_bankid_24                     ), 
                      .buf_intlv_bankid_25   (buf_intlv_bankid_25                     ), 
                      .buf_intlv_bankid_26   (buf_intlv_bankid_26                     ), 
                      .buf_intlv_bankid_27   (buf_intlv_bankid_27                     ), 
                      .buf_intlv_bankid_28   (buf_intlv_bankid_28                     ), 
                      .buf_intlv_bankid_29   (buf_intlv_bankid_29                     ), 
                      .buf_intlv_bankid_30   (buf_intlv_bankid_30                     ), 
                      .buf_intlv_bankid_31   (buf_intlv_bankid_31                     ), 
                      .buf_intlv_bankid_32   (buf_intlv_bankid_32                     ), 
                      .buf_intlv_bankid_33   (buf_intlv_bankid_33                     ), 
                      .buf_intlv_bankid_34   (buf_intlv_bankid_34                     ), 
                      .buf_intlv_bankid_35   (buf_intlv_bankid_35                     ), 
                      .buf_intlv_bankid_36   (buf_intlv_bankid_36                     ), 
                      .buf_intlv_bankid_37   (buf_intlv_bankid_37                     ), 
                      .buf_intlv_bankid_38   (buf_intlv_bankid_38                     ), 
                      .buf_intlv_bankid_39   (buf_intlv_bankid_39                     ), 
                      .buf_intlv_bankid_40   (buf_intlv_bankid_40                     ), 
                      .buf_intlv_bankid_41   (buf_intlv_bankid_41                     ), 
                      .buf_intlv_bankid_42   (buf_intlv_bankid_42                     ), 
                      .buf_intlv_bankid_43   (buf_intlv_bankid_43                     ), 
                      .buf_intlv_bankid_44   (buf_intlv_bankid_44                     ), 
                      .buf_intlv_bankid_45   (buf_intlv_bankid_45                     ), 
                      .buf_intlv_bankid_46   (buf_intlv_bankid_46                     ), 
                      .buf_intlv_bankid_47   (buf_intlv_bankid_47                     ), 
                      .buf_intlv_bankid_48   (buf_intlv_bankid_48                     ), 
                      .buf_intlv_bankid_49   (buf_intlv_bankid_49                     ), 
                      .buf_intlv_bankid_50   (buf_intlv_bankid_50                     ), 
                      .buf_intlv_bankid_51   (buf_intlv_bankid_51                     ), 
                      .buf_intlv_bankid_52   (buf_intlv_bankid_52                     ), 
                      .buf_intlv_bankid_53   (buf_intlv_bankid_53                     ), 
                      .buf_intlv_bankid_54   (buf_intlv_bankid_54                     ), 
                      .buf_intlv_bankid_55   (buf_intlv_bankid_55                     ), 
                      .buf_intlv_bankid_56   (buf_intlv_bankid_56                     ), 
                      .buf_intlv_bankid_57   (buf_intlv_bankid_57                     ), 
                      .buf_intlv_bankid_58   (buf_intlv_bankid_58                     ), 
                      .buf_intlv_bankid_59   (buf_intlv_bankid_59                     ), 
                      .buf_intlv_bankid_60   (buf_intlv_bankid_60                     ), 
                      .buf_intlv_bankid_61   (buf_intlv_bankid_61                     ), 
                      .buf_intlv_bankid_62   (buf_intlv_bankid_62                     ), 
                      .buf_intlv_bankid_63   (buf_intlv_bankid_63                     ), 
                      .buf_intlv_bankid_64   (buf_intlv_bankid_64                     ), 
                      .buf_intlv_bankid_65   (buf_intlv_bankid_65                     ), 
                      .buf_intlv_bankid_66   (buf_intlv_bankid_66                     ), 
                      .buf_intlv_bankid_67   (buf_intlv_bankid_67                     ), 
                      .buf_intlv_bankid_68   (buf_intlv_bankid_68                     ), 
                      .buf_intlv_bankid_69   (buf_intlv_bankid_69                     ), 
                      .buf_intlv_bankid_70   (buf_intlv_bankid_70                     ), 
                      .buf_intlv_bankid_71   (buf_intlv_bankid_71                     ), 
                      .buf_intlv_bankid_72   (buf_intlv_bankid_72                     ), 
                      .buf_intlv_bankid_73   (buf_intlv_bankid_73                     ), 
                      .buf_intlv_bankid_74   (buf_intlv_bankid_74                     ), 
                      .buf_intlv_bankid_75   (buf_intlv_bankid_75                     ), 
                      .buf_intlv_bankid_76   (buf_intlv_bankid_76                     ), 
                      .buf_intlv_bankid_77   (buf_intlv_bankid_77                     ), 
                      .buf_intlv_bankid_78   (buf_intlv_bankid_78                     ), 
                      .buf_intlv_bankid_79   (buf_intlv_bankid_79                     ), 

                      .slice_payload_i       (slice2_payload_o                        ),
                      .slice_payload_o       (slice2_payload_i                        ),
                      .bank_damage           (bank_damage                             )); 


        intlv_slice #(
           .PLD_W  (WXP),
           .TMO    (SLICE_2)
        ) intlv_slice_2 (
                        .ready_o               (slice2_ready_i),          // Templated
                        .valid_o               (downstrm_valid),          // Templated
                        .payload_o             (downstrm_payload[WXP-1:0]), // Templated
                        // Inputs
                        .aclk_i                (clk),                      // Templated
                        .aresetn_i             (rst_n),                    // Templated
                        .ready_i               (downstrm_ready),           // Templated
                        .valid_i               (slice2_valid_o),         // Templated
                        .payload_i             (slice2_payload_i[WXP-1:0])); // Templated


assign downstrm_addr    =   downstrm_payload[ADDRW-1:0]; 
assign downstrm_user    =   downstrm_payload[ADDRW+USERW-1:ADDRW];
assign downstrm_lock    =   downstrm_payload[ADDRW+USERW+1-1:ADDRW+USERW];
assign downstrm_atop    =   downstrm_payload[ADDRW+USERW+1+ATOPW-1:ADDRW+USERW+1];          
assign downstrm_qos     =   downstrm_payload[ADDRW+USERW+1+ATOPW+4-1:ADDRW+USERW+1+ATOPW];
assign downstrm_cache   =   downstrm_payload[ADDRW+USERW+1+ATOPW+4+4-1:ADDRW+USERW+1+ATOPW+4];
assign downstrm_prot    =   downstrm_payload[ADDRW+USERW+1+ATOPW+4+4+3-1:ADDRW+USERW+1+ATOPW+4+4];
assign downstrm_burst   =   downstrm_payload[ADDRW+USERW+1+ATOPW+4+4+3+2-1:ADDRW+USERW+1+ATOPW+4+4+3];
assign downstrm_size    =   downstrm_payload[ADDRW+USERW+1+ATOPW+4+4+3+2+3-1:ADDRW+USERW+1+ATOPW+4+4+3+2];
assign downstrm_len     =   downstrm_payload[ADDRW+USERW+1+ATOPW+4+4+3+2+3+LENW-1:ADDRW+USERW+1+ATOPW+4+4+3+2+3];
assign downstrm_id      =   downstrm_payload[ADDRW+USERW+1+ATOPW+4+4+3+2+3+LENW+IDW-1:ADDRW+USERW+1+ATOPW+4+4+3+2+3+LENW];
              
endmodule

// Local Variables:
// verilog-library-directories:("./") 
// verilog-auto-inst-param-value:t
// End:
