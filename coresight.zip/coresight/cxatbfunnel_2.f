+incdir+$GP3_RTL/coresight/rtl/coresight_component/trace_module/cxatbfunnel_2/verilog
$GP3_RTL/coresight/rtl/coresight_component/trace_module/cxatbfunnel_2/verilog/cxatbfunnel_2.v
$GP3_RTL/coresight/rtl/coresight_component/trace_module/cxatbfunnel_2/verilog/cxatbfunnel_apb_if_2.v
$GP3_RTL/coresight/rtl/coresight_component/trace_module/cxatbfunnel_2/verilog/cxatbfunnel_arbiter_2.v
$GP3_RTL/coresight/rtl/coresight_component/trace_module/cxatbfunnel_2/verilog/cxatbfunnel_reg_blk_2.v
