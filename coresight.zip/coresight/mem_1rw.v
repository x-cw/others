`include "../general/general.vh"

module mem_1rw
  #( parameter
     MEM_BIT_EN=0,
     MEM_WORDS=0,
     MEM_WIDTH=0,
     MEM_FAST=0, //use std vt instead of high vt

     L2_MEM_WORDS=log2(MEM_WORDS)
     ) (
        input wire [MEM_WIDTH-1:0]    din,
        input wire [MEM_WIDTH-1:0]    bit_en,
        input wire [L2_MEM_WORDS-1:0] addr,
        input wire                    clk,
        input wire                    c_en, //chip enable
        input wire                    wr_en,

        output wire [MEM_WIDTH-1:0]   dout
        );


`include "../general/misc.vh"

  //leda off NTL_CON12
  //really driven - but b/c rams are black boxed - leda doesn't know that
  wire [MEM_WIDTH-1:0] dout_internal;
  //leda on NTL_CON12

  wire [MEM_WIDTH-1:0] bit_en_internal;
  
  generate if (MEM_BIT_EN) begin: yes_bit_en
    assign bit_en_internal=bit_en;
  end else begin: no_bit_en
    assign bit_en_internal={MEM_WIDTH{1'b1}};
  end endgenerate
  
//`ifdef SYNTHESIS
  assign dout=dout_internal;
//`else
//  
//  reg c_en_last;
//  reg wr_en_last;
//  reg [L2_MEM_WORDS-1:0] addr_last;
//  always @(posedge clk) begin
//    wr_en_last<=wr_en;
//    c_en_last<=c_en;
//    addr_last<=addr;
//  end
//
//  assign dout= (c_en_last && ~wr_en_last && addr_last>= MEM_WORDS) ?  {MEM_WIDTH{1'bx}} :
//               dout_internal;
//  
// `ifdef MEMORY_CHECK_ENABLES
//
//  reg c_en_at_reset;
//  initial begin
//    #10;
//    c_en_at_reset=c_en;
//    c_en_assert_at_reset: assert (c_en_at_reset==0) else
//      $warning("c_en assert at reset.");
//  end
//
//  
//  c_en_not_used_on_rd: assert property (@(posedge clk)
//                                        disable iff(c_en_at_reset==1)
//                                        (wr_en==0 && $stable(addr) && $stable(bit_en) && !$isunknown(addr))[*3] |-> (c_en==0 || $past(c_en,1)==0 || $past(c_en,2)==0))
//    else $warning("c_en not getting deasserted when there is no read activity");
//
//  c_en_not_used_on_wr: assert property (@(posedge clk)
//                                        wr_en==1[*2] |-> addr!=$past(addr,1) || bit_en!=$past(bit_en,1))
//    else $warning("writing to the same address in multiple clocks");
// `endif
  
//  params_not_defined: assert property (@(posedge c_en) L2_MEM_WORDS!=0 && MEM_WIDTH!=0) else
//    $fatal(0,"addr_bits or ram_width = 0");
//
//  clk_not_defined: assert property (@(posedge c_en) c_en==1 |-> clk===1'b1 || clk===1'b0) else
//    $fatal(0,"clock not defined");


//`endif  

`ifdef FPGA

  
  /*mem_1r1w_flops auto_template (
   ..*addr(addr[]),
   ..*clk(clk),
   .rd_en(c_en),
   .wr_en(c_en &&  wr_en),
   );*/
  
  mem_1r1w_flops
    #(/*autoinstparam*/
      // Parameters
      .MEM_WORDS                        (MEM_WORDS),
      .MEM_WIDTH                        (MEM_WIDTH),
      .MEM_BIT_EN                       (MEM_BIT_EN),
      .L2_MEM_WORDS                     (L2_MEM_WORDS))
  mem(/*autoinst*/
      // Outputs
      .dout_internal                    (dout_internal[MEM_WIDTH-1:0]),
      // Inputs
      .din                              (din[MEM_WIDTH-1:0]),
      .rd_addr                          (addr[L2_MEM_WORDS-1:0]), // Templated
      .rd_clk                           (clk),                   // Templated
      .rd_en                            (c_en),                  // Templated
      .wr_addr                          (addr[L2_MEM_WORDS-1:0]), // Templated
      .wr_clk                           (clk),                   // Templated
      .wr_en                            (c_en &&  wr_en),        // Templated
      .bit_en_internal                  (bit_en_internal[MEM_WIDTH-1:0]));

//`include "../memories/isi_mem_wrapper_include.vh"

//`ifndef SYNTHESIS
 // VCS coverage off
 // Backdoor Access Interface:
// always @(dv_bd_wr) begin
//   mem.dv_bd_wr_addr = dv_bd_wr_addr;
//   mem.dv_bd_wr_bit_en = dv_bd_wr_bit_en;
//   mem.dv_bd_din = dv_bd_din;
//   ->mem.dv_bd_wr;
//   @(mem.dv_bd_wr_ack);
//   ->dv_bd_wr_ack;
// end
// always @(dv_bd_rd) begin
//   mem.dv_bd_rd_addr = dv_bd_rd_addr;
//   ->mem.dv_bd_rd;
//   @(mem.dv_bd_rd_ack);
//   dv_bd_dout = mem.dv_bd_dout;
//   ->dv_bd_rd_ack;
// end
 // VCS coverage on
//`endif

  


`else


  localparam OFFSET=1000;
  localparam MEMORY=MEM_WORDS * OFFSET + MEM_WIDTH;
  
  generate
    
    //if (MEM_WORDS * MEM_WIDTH < 2048*4) begin: flops
    if (MEM_WORDS * MEM_WIDTH <= 1024 * 4) begin: flops

//`ifndef SYNTHESIS
 // VCS coverage off
 // Backdoor Access Interface:
// always @(dv_bd_wr) begin
//   flops.dv_bd_wr_addr = dv_bd_wr_addr;
//   flops.dv_bd_wr_bit_en = dv_bd_wr_bit_en;
//   flops.dv_bd_din = dv_bd_din;
//   ->flops.dv_bd_wr;
//   @(flops.dv_bd_wr_ack);
//   ->dv_bd_wr_ack;
// end
// always @(dv_bd_rd) begin
//   flops.dv_bd_rd_addr = dv_bd_rd_addr;
//   ->flops.dv_bd_rd;
//   @(flops.dv_bd_rd_ack);
//   dv_bd_dout = flops.dv_bd_dout;
//   ->dv_bd_rd_ack;
// end
 // VCS coverage on
//`endif

      mem_1r1w_flops
        #(/*autoinstparam*/
          // Parameters
          .MEM_WORDS                    (MEM_WORDS),
          .MEM_WIDTH                    (MEM_WIDTH),
          .MEM_BIT_EN                   (MEM_BIT_EN),
          .L2_MEM_WORDS                 (L2_MEM_WORDS))
      flops(/*autoinst*/
            // Outputs
            .dout_internal              (dout_internal[MEM_WIDTH-1:0]),
            // Inputs
            .din                        (din[MEM_WIDTH-1:0]),
            .rd_addr                    (addr[L2_MEM_WORDS-1:0]), // Templated
            .rd_clk                     (clk),                   // Templated
            .rd_en                      (c_en),                  // Templated
            .wr_addr                    (addr[L2_MEM_WORDS-1:0]), // Templated
            .wr_clk                     (clk),                   // Templated
            .wr_en                      (c_en &&  wr_en),        // Templated
            .bit_en_internal            (bit_en_internal[MEM_WIDTH-1:0]));
    end else begin: rams
      /*
       //MEMORY_AUTO_LINES_BEGIN
        mem_104x32_1rw_ben0_rf_1 auto_template
        mem_1024x10_1rw_ben0_ra_8 auto_template
        mem_11520x32_1rw_ben0_ra_32 auto_template
        mem_12288x32_1rw_ben0_ra_32 auto_template
        mem_128x16_1rw_ben0_rf_2 auto_template
        mem_128x42_1rw_ben1_rf_1 auto_template
        mem_128x64_1rw_ben0_rf_1 auto_template
        mem_128x72_1rw_ben0_rf_1 auto_template
        mem_1344x10_1rw_ben0_ra_8 auto_template
        mem_1312x24_1rw_ben0_ra_4 auto_template
        mem_14848x32_1rw_ben1_ra_32 auto_template
        mem_15616x32_1rw_ben1_ra_32 auto_template
        mem_16384x32_1rw_ben1_ra_32 auto_template
        mem_1920x10_1rw_ben0_ra_8 auto_template
        mem_1920x16_1rw_ben0_ra_8 auto_template
        mem_1920x8_1rw_ben0_ra_8 auto_template
        mem_1984x23_1rw_ben0_ra_8 auto_template
        mem_2048x32_1rw_ben1_ra_4 auto_template
        mem_256x8_1rw_ben0_ra_4 auto_template
        mem_2624x10_1rw_ben0_ra_8 auto_template
        mem_304x54_1rw_ben0_rf_2 auto_template
        mem_3072x32_1rw_ben1_ra_8 auto_template
        mem_3200x32_1rw_ben1_ra_8 auto_template
        mem_32x64_1rw_ben0_rf_1 auto_template
        mem_32x72_1rw_ben0_rf_1 auto_template
        mem_3904x32_1rw_ben1_ra_8 auto_template
        mem_416x22_1rw_ben0_ra_4 auto_template
        mem_4096x32_1rw_ben0_ra_8 auto_template
        mem_4096x35_1rw_ben0_ra_8 auto_template
        mem_4480x32_1rw_ben1_ra_16 auto_template
        mem_4864x16_1rw_ben0_ra_16 auto_template
        mem_4864x32_1rw_ben1_ra_16 auto_template
        mem_512x19_1rw_ben0_ra_4 auto_template
        mem_64x64_1rw_ben0_rf_1 auto_template
        mem_7296x32_1rw_ben1_ra_16 auto_template
        mem_768x4_1rw_ben0_ra_8 auto_template
        mem_72x64_1rw_ben0_rf_1 auto_template
        mem_7680x16_1rw_ben0_ra_16 auto_template
        mem_7808x22_1rw_ben0_ra_16 auto_template
        mem_7936x32_1rw_ben1_ra_16 auto_template
        mem_800x22_1rw_ben0_ra_4 auto_template
        mem_960x10_1rw_ben0_ra_8 auto_template
        mem_960x16_1rw_ben0_ra_4 auto_template
        (.Q(dout_internal[]),
        .CLK(clk),
        .CEN(~c_en),
        .WEN(~wr_en),
        .BWEN(~bit_en_internal[]),
        .A(addr[]),
        .D(din[]),
        );

       //MEMORY_AUTO_LINES_END
       */
      
      //leda off

      case(MEMORY)
        //MEMORY_CASE_LINES_BEGIN
//`ifndef MEMORY_SCAN
        //('d100 * OFFSET + 'd32): begin: mem_100x32
        //  `include "../memories/isi_mem_wrapper_include.vh"
        //  localparam Bits=32,Add_Width=7,Wen_Width=32;
        //  localparam Word_Width=Bits;
        //  localparam Addr_Depth=Add_Width;
        //  mem_104x32_1rw_ben0_rf_1 mem(/*autoinst*/
        //                               // Outputs
        //                               .Q               (dout_internal[Bits-1:0]), // Templated
        //                               // Inputs
        //                               .CLK             (clk),           // Templated
        //                               .CEN             (~c_en),         // Templated
        //                               .WEN             (~wr_en),        // Templated
        //                               .A               (addr[Add_Width-1:0]), // Templated
        //                               .D               (din[Bits-1:0])); // Templated
        //end

        ('d1024 * OFFSET + 'd48): begin: mem_1024x48
          localparam Bits=48,Add_Width=10;
          localparam Word_Width=Bits;
          localparam Addr_Depth=Add_Width;   
          spram_1024x48_wrap mem(///*autoinst*/
                                       // Outputs
                                       .Q               (dout_internal[Bits-1:0]), // Templated
                                       // Inputs
                                       .CLK             (clk),           // Templated
                                       .REB             (1'b0),         // Templated
                                       .WEB             (~wr_en),        // Templated
                                       .AA              (addr[Add_Width-1:0]), // Templated
                                       .D               (din[Bits-1:0]));// Templated
        end

        ('d32 * OFFSET + 'd512): begin: mem_32x512
          localparam Bits=512,Add_Width=5;
          localparam Word_Width=Bits;
          localparam Addr_Depth=Add_Width;   
          spram_32x512_wrap mem(///*autoinst*/
                                       // Outputs
                                       .Q               (dout_internal[Bits-1:0]), // Templated
                                       // Inputs
                                       .CLK             (clk),           // Templated
                                       .CEB             (~c_en),         // Templated
                                       .WEB             (~wr_en),        // Templated
                                       .A               (addr[Add_Width-1:0]), // Templated
                                       .D               (din[Bits-1:0]));// Templated
        end

//        ('d2592 * OFFSET + 'd16): begin: mem_2592x16
//          localparam Bits=16,Add_Width=12;
//          localparam Word_Width=Bits;
//          localparam Addr_Depth=Add_Width;   
//          mem_2592x16_1rw_wrapper mem(/*autoinst*/
//                                       // Outputs
//                                       .Q               (dout_internal[Bits-1:0]), // Templated
//                                       // Inputs
//                                       .CK              (clk),           // Templated
//                                       .CEB             (c_en),         // Templated
//                                       .WEB             (wr_en),        // Templated
//                                       .A               (addr[Add_Width-1:0]), // Templated
//                                       .D               (din[Bits-1:0]));// Templated
//        end
//
//        ('d2592 * OFFSET + 'd10): begin: mem_2592x10
//          localparam Bits=10,Add_Width=12;
//          localparam Word_Width=Bits;
//          localparam Addr_Depth=Add_Width;   
//          mem_2592x10_1rw_wrapper mem(/*autoinst*/
//                                       // Outputs
//                                       .Q               (dout_internal[Bits-1:0]), // Templated
//                                       // Inputs
//                                       .CK              (clk),           // Templated
//                                       .CEB             (c_en),         // Templated
//                                       .WEB             (wr_en),        // Templated
//                                       .A               (addr[Add_Width-1:0]), // Templated
//                                       .D               (din[Bits-1:0]));// Templated
//        end
//
//        ('d1296 * OFFSET + 'd10): begin: mem_1296x10
//          localparam Bits=10,Add_Width=11;
//          localparam Word_Width=Bits;
//          localparam Addr_Depth=Add_Width;   
//          mem_1296x10_1rw_wrapper mem(/*autoinst*/
//                                       // Outputs
//                                       .Q               (dout_internal[Bits-1:0]), // Templated
//                                       // Inputs
//                                       .CK              (clk),           // Templated
//                                       .CEB             (c_en),         // Templated
//                                       .WEB             (wr_en),        // Templated
//                                       .A               (addr[Add_Width-1:0]), // Templated
//                                       .D               (din[Bits-1:0]));// Templated
//        end
//
//        ('d1024 * OFFSET + 'd10): begin: mem_1024x10
//          localparam Bits=10,Add_Width=10;
//          localparam Word_Width=Bits;
//          localparam Addr_Depth=Add_Width;   
//          mem_1024x10_1rw_wrapper mem(/*autoinst*/
//                                       // Outputs
//                                       .Q               (dout_internal[Bits-1:0]), // Templated
//                                       // Inputs
//                                       .CK              (clk),           // Templated
//                                       .CEB             (c_en),         // Templated
//                                       .WEB             (wr_en),        // Templated
//                                       .A               (addr[Add_Width-1:0]), // Templated
//                                       .D               (din[Bits-1:0]));// Templated
//        end
//
//        ('d800 * OFFSET + 'd22): begin: mem_800x22
//          localparam Bits=22,Add_Width=10;
//          localparam Word_Width=Bits;
//          localparam Addr_Depth=Add_Width;   
//          mem_800x22_1rw_wrapper mem(/*autoinst*/
//                                       // Outputs
//                                       .Q               (dout_internal[Bits-1:0]), // Templated
//                                       // Inputs
//                                       .CK              (clk),           // Templated
//                                       .CEB             (c_en),         // Templated
//                                       .WEB             (wr_en),        // Templated
//                                       .A               (addr[Add_Width-1:0]), // Templated
//                                       .D               (din[Bits-1:0]));// Templated
//        end
//
//        ('d400 * OFFSET + 'd22): begin: mem_400x22
//          localparam Bits=22,Add_Width=9;
//          localparam Word_Width=Bits;
//          localparam Addr_Depth=Add_Width;   
//          mem_400x22_1rw_wrapper mem(/*autoinst*/
//                                       // Outputs
//                                       .Q               (dout_internal[Bits-1:0]), // Templated
//                                       // Inputs
//                                       .CK              (clk),           // Templated
//                                       .CEB             (c_en),         // Templated
//                                       .WEB             (wr_en),        // Templated
//                                       .A               (addr[Add_Width-1:0]), // Templated
//                                       .D               (din[Bits-1:0]));// Templated
//        end
//
//        ('d100 * OFFSET + 'd32): begin: mem_100x32
//          localparam Bits=32,Add_Width=7;
//          localparam Word_Width=Bits;
//          localparam Addr_Depth=Add_Width;   
//          mem_100x32_1rw_wrapper mem(/*autoinst*/
//                                       // Outputs
//                                       .Q               (dout_internal[Bits-1:0]), // Templated
//                                       // Inputs
//                                       .CK              (clk),           // Templated
//                                       .CEB             (c_en),         // Templated
//                                       .WEB             (wr_en),        // Templated
//                                       .A               (addr[Add_Width-1:0]), // Templated
//                                       .D               (din[Bits-1:0]));// Templated
//        end
//
//        ('d1944 * OFFSET + 'd23): begin: mem_1944x23
//          localparam Bits=23,Add_Width=11;
//          localparam Word_Width=Bits;
//          localparam Addr_Depth=Add_Width;   
//          mem_1944x23_1rw_wrapper mem(/*autoinst*/
//                                       // Outputs
//                                       .Q               (dout_internal[Bits-1:0]), // Templated
//                                       // Inputs
//                                       .CK              (clk),           // Templated
//                                       .CEB             (c_en),         // Templated
//                                       .WEB             (wr_en),        // Templated
//                                       .A               (addr[Add_Width-1:0]), // Templated
//                                       .D               (din[Bits-1:0]));// Templated
//        end
//
//        ('d7680 * OFFSET + 'd16): begin: mem_7680x16
//          localparam Bits=16,Add_Width=13;
//          localparam Word_Width=Bits;
//          localparam Addr_Depth=Add_Width;   
//          mem_7680x16_1rw_wrapper mem(/*autoinst*/
//                                       // Outputs
//                                       .Q               (dout_internal[Bits-1:0]), // Templated
//                                       // Inputs
//                                       .CK              (clk),           // Templated
//                                       .CEB             (c_en),         // Templated
//                                       .WEB             (wr_en),        // Templated
//                                       .A               (addr[Add_Width-1:0]), // Templated
//                                       .D               (din[Bits-1:0]));// Templated
//        end
//
//        ('d4800 * OFFSET + 'd16): begin: mem_4800x16
//          localparam Bits=16,Add_Width=13;
//          localparam Word_Width=Bits;
//          localparam Addr_Depth=Add_Width;   
//          mem_4800x16_1rw_wrapper mem(/*autoinst*/
//                                       // Outputs
//                                       .Q               (dout_internal[Bits-1:0]), // Templated
//                                       // Inputs
//                                       .CK              (clk),           // Templated
//                                       .CEB             (c_en),         // Templated
//                                       .WEB             (wr_en),        // Templated
//                                       .A               (addr[Add_Width-1:0]), // Templated
//                                       .D               (din[Bits-1:0]));// Templated
//        end
//
//        ('d297 * OFFSET + 'd54): begin: mem_297x54
//          localparam Bits=54,Add_Width=9;
//          localparam Word_Width=Bits;
//          localparam Addr_Depth=Add_Width;   
//          mem_297x54_1rw_wrapper mem(/*autoinst*/
//                                       // Outputs
//                                       .Q               (dout_internal[Bits-1:0]), // Templated
//                                       // Inputs
//                                       .CK              (clk),           // Templated
//                                       .CEB             (c_en),         // Templated
//                                       .WEB             (wr_en),        // Templated
//                                       .A               (addr[Add_Width-1:0]), // Templated
//                                       .D               (din[Bits-1:0]));// Templated
//        end
//
//        ('d960 * OFFSET + 'd16): begin: mem_960x16
//          localparam Bits=16,Add_Width=10;
//          localparam Word_Width=Bits;
//          localparam Addr_Depth=Add_Width;   
//          mem_960x16_1rw_wrapper mem(/*autoinst*/
//                                       // Outputs
//                                       .Q               (dout_internal[Bits-1:0]), // Templated
//                                       // Inputs
//                                       .CK              (clk),           // Templated
//                                       .CEB             (c_en),         // Templated
//                                       .WEB             (wr_en),        // Templated
//                                       .A               (addr[Add_Width-1:0]), // Templated
//                                       .D               (din[Bits-1:0]));// Templated
//        end
//
//        ('d1920 * OFFSET + 'd10): begin: mem_1920x10
//          localparam Bits=10,Add_Width=11;
//          localparam Word_Width=Bits;
//          localparam Addr_Depth=Add_Width;   
//          mem_1920x10_1rw_wrapper mem(/*autoinst*/
//                                       // Outputs
//                                       .Q               (dout_internal[Bits-1:0]), // Templated
//                                       // Inputs
//                                       .CK              (clk),           // Templated
//                                       .CEB             (c_en),         // Templated
//                                       .WEB             (wr_en),        // Templated
//                                       .A               (addr[Add_Width-1:0]), // Templated
//                                       .D               (din[Bits-1:0]));// Templated
//        end
//
//        ('d960 * OFFSET + 'd10): begin: mem_960x10
//          localparam Bits=10,Add_Width=10;
//          localparam Word_Width=Bits;
//          localparam Addr_Depth=Add_Width;   
//          mem_1024x10_1rw_wrapper mem(/*autoinst*/
//                                       // Outputs
//                                       .Q               (dout_internal[Bits-1:0]), // Templated
//                                       // Inputs
//                                       .CK              (clk),           // Templated
//                                       .CEB             (c_en),         // Templated
//                                       .WEB             (wr_en),        // Templated
//                                       .A               (addr[Add_Width-1:0]), // Templated
//                                       .D               (din[Bits-1:0]));// Templated
//        end
//
//        ('d4800 * OFFSET + 'd32): begin: mem_4800x32
//          localparam Bits=32,Add_Width=13,Wen_Width=32;
//          localparam Word_Width=Bits;
//          localparam Addr_Depth=Add_Width;   
//          mem_4800x32_1rw_wrapper mem(/*autoinst*/
//                                       // Outputs
//                                       .Q               (dout_internal[Bits-1:0]), // Templated
//                                       // Inputs
//                                       .CK              (clk),           // Templated
//                                       .CEB             (c_en),         // Templated
//                                       .WEB             (wr_en),        // Templated
//                                       .BWEB            (bit_en_internal[Wen_Width-1:0]), // Templated
//                                       .A               (addr[Add_Width-1:0]), // Templated
//                                       .D               (din[Bits-1:0]));// Templated
//        end
//
//        ('d6528 * OFFSET + 'd32): begin: mem_6528x32
//          localparam Bits=32,Add_Width=13,Wen_Width=32;
//          localparam Word_Width=Bits;
//          localparam Addr_Depth=Add_Width;   
//          mem_6528x32_1rw_wrapper mem(/*autoinst*/
//                                       // Outputs
//                                       .Q               (dout_internal[Bits-1:0]), // Templated
//                                       // Inputs
//                                       .CK              (clk),           // Templated
//                                       .CEB             (c_en),         // Templated
//                                       .WEB             (wr_en),        // Templated
//                                       .BWEB            (bit_en_internal[Wen_Width-1:0]), // Templated
//                                       .A               (addr[Add_Width-1:0]), // Templated
//                                       .D               (din[Bits-1:0]));// Templated
//        end
//
//        ('d7200 * OFFSET + 'd32): begin: mem_7200x32
//          localparam Bits=32,Add_Width=13,Wen_Width=32;
//          localparam Word_Width=Bits;
//          localparam Addr_Depth=Add_Width;   
//          mem_7200x32_1rw_wrapper mem(/*autoinst*/
//                                       // Outputs
//                                       .Q               (dout_internal[Bits-1:0]), // Templated
//                                       // Inputs
//                                       .CK              (clk),           // Templated
//                                       .CEB             (c_en),         // Templated
//                                       .WEB             (wr_en),        // Templated
//                                       .BWEB            (bit_en_internal[Wen_Width-1:0]), // Templated
//                                       .A               (addr[Add_Width-1:0]), // Templated
//                                       .D               (din[Bits-1:0]));// Templated
//        end
//
//        ('d11712 * OFFSET + 'd32): begin: mem_11712x32
//          localparam Bits=32,Add_Width=14,Wen_Width=32;
//          localparam Word_Width=Bits;
//          localparam Addr_Depth=Add_Width;   
//          mem_11712x32_1rw_wrapper mem(/*autoinst*/
//                                       // Outputs
//                                       .Q               (dout_internal[Bits-1:0]), // Templated
//                                       // Inputs
//                                       .CK              (clk),           // Templated
//                                       .CEB             (c_en),         // Templated
//                                       .WEB             (wr_en),        // Templated
//                                       .BWEB            (bit_en_internal[Wen_Width-1:0]), // Templated
//                                       .A               (addr[Add_Width-1:0]), // Templated
//                                       .D               (din[Bits-1:0]));// Templated
//        end
//
//        ('d16320 * OFFSET + 'd32): begin: mem_16320x32
//          localparam Bits=32,Add_Width=14,Wen_Width=32;
//          localparam Word_Width=Bits;
//          localparam Addr_Depth=Add_Width;   
//          mem_16320x32_1rw_wrapper mem(/*autoinst*/
//                                       // Outputs
//                                       .Q               (dout_internal[Bits-1:0]), // Templated
//                                       // Inputs
//                                       .CK              (clk),           // Templated
//                                       .CEB             (c_en),         // Templated
//                                       .WEB             (wr_en),        // Templated
//                                       .BWEB            (bit_en_internal[Wen_Width-1:0]), // Templated
//                                       .A               (addr[Add_Width-1:0]), // Templated
//                                       .D               (din[Bits-1:0]));// Templated
//        end
//
//        ('d16384 * OFFSET + 'd32): begin: mem_16384x32
//          localparam Bits=32,Add_Width=14,Wen_Width=32;
//          localparam Word_Width=Bits;
//          localparam Addr_Depth=Add_Width;   
//          mem_16320x32_1rw_wrapper mem(/*autoinst*/
//                                       // Outputs
//                                       .Q               (dout_internal[Bits-1:0]), // Templated
//                                       // Inputs
//                                       .CK              (clk),           // Templated
//                                       .CEB             (c_en),         // Templated
//                                       .WEB             (wr_en),        // Templated
//                                       .BWEB            (bit_en_internal[Wen_Width-1:0]), // Templated
//                                       .A               (addr[Add_Width-1:0]), // Templated
//                                       .D               (din[Bits-1:0]));// Templated
//        end
//
//        ('d6816 * OFFSET + 'd32): begin: mem_6816x32
//          localparam Bits=32,Add_Width=13,Wen_Width=32;
//          localparam Word_Width=Bits;
//          localparam Addr_Depth=Add_Width;   
//          mem_6816x32_1rw_wrapper mem(/*autoinst*/
//                                       // Outputs
//                                       .Q               (dout_internal[Bits-1:0]), // Templated
//                                       // Inputs
//                                       .CK              (clk),           // Templated
//                                       .CEB             (c_en),         // Templated
//                                       .WEB             (wr_en),        // Templated
//                                       .BWEB            (bit_en_internal[Wen_Width-1:0]), // Templated
//                                       .A               (addr[Add_Width-1:0]), // Templated
//                                       .D               (din[Bits-1:0]));// Templated
//        end
//
//        ('d3056 * OFFSET + 'd32): begin: mem_3056x32
//          localparam Bits=32,Add_Width=12,Wen_Width=32;
//          localparam Word_Width=Bits;
//          localparam Addr_Depth=Add_Width;   
//          mem_3056x32_1rw_wrapper mem(/*autoinst*/
//                                       // Outputs
//                                       .Q               (dout_internal[Bits-1:0]), // Templated
//                                       // Inputs
//                                       .CK              (clk),           // Templated
//                                       .CEB             (c_en),         // Templated
//                                       .WEB             (wr_en),        // Templated
//                                       .BWEB            (bit_en_internal[Wen_Width-1:0]), // Templated
//                                       .A               (addr[Add_Width-1:0]), // Templated
//                                       .D               (din[Bits-1:0]));// Templated
//        end
//
//        ('d720 * OFFSET + 'd4): begin: mem_720x4
//          localparam Bits=4,Add_Width=10;
//          localparam Word_Width=Bits;
//          localparam Addr_Depth=Add_Width;   
//          mem_720x4_1rw_wrapper mem(/*autoinst*/
//                                       // Outputs
//                                       .Q               (dout_internal[Bits-1:0]), // Templated
//                                       // Inputs
//                                       .CK              (clk),           // Templated
//                                       .CEB             (c_en),         // Templated
//                                       .WEB             (wr_en),        // Templated
//                                       .A               (addr[Add_Width-1:0]), // Templated
//                                       .D               (din[Bits-1:0]));// Templated
//        end
//
//        ('d7712 * OFFSET + 'd22): begin: mem_7712x22
//          localparam Bits=22,Add_Width=13;
//          localparam Word_Width=Bits;
//          localparam Addr_Depth=Add_Width;   
//          mem_7712x22_1rw_wrapper mem(/*autoinst*/
//                                       // Outputs
//                                       .Q               (dout_internal[Bits-1:0]), // Templated
//                                       // Inputs
//                                       .CK              (clk),           // Templated
//                                       .CEB             (c_en),         // Templated
//                                       .WEB             (wr_en),        // Templated
//                                       .A               (addr[Add_Width-1:0]), // Templated
//                                       .D               (din[Bits-1:0]));// Templated
//        end
//
//        ('d3852 * OFFSET + 'd32): begin: mem_3852x32
//          localparam Bits=32,Add_Width=12,Wen_Width=32;
//          localparam Word_Width=Bits;
//          localparam Addr_Depth=Add_Width;   
//          mem_3852x32_1rw_wrapper mem(/*autoinst*/
//                                       // Outputs
//                                       .Q               (dout_internal[Bits-1:0]), // Templated
//                                       // Inputs
//                                       .CK              (clk),           // Templated
//                                       .CEB             (c_en),         // Templated
//                                       .WEB             (wr_en),        // Templated
//                                       .BWEB            (bit_en_internal[Wen_Width-1:0]), // Templated
//                                       .A               (addr[Add_Width-1:0]), // Templated
//                                       .D               (din[Bits-1:0]));// Templated
//        end
//
//        ('d256 * OFFSET + 'd8): begin: mem_256x8
//          localparam Bits=8,Add_Width=8;
//          localparam Word_Width=Bits;
//          localparam Addr_Depth=Add_Width;   
//          mem_256x8_1rw_wrapper mem(/*autoinst*/
//                                       // Outputs
//                                       .Q               (dout_internal[Bits-1:0]), // Templated
//                                       // Inputs
//                                       .CK              (clk),           // Templated
//                                       .CEB             (c_en),         // Templated
//                                       .WEB             (wr_en),        // Templated
//                                       .A               (addr[Add_Width-1:0]), // Templated
//                                       .D               (din[Bits-1:0]));// Templated
//        end
//
//        ('d1920 * OFFSET + 'd8): begin: mem_1920x8
//          localparam Bits=8,Add_Width=11;
//          localparam Word_Width=Bits;
//          localparam Addr_Depth=Add_Width;   
//          mem_1920x8_1rw_wrapper mem(/*autoinst*/
//                                       // Outputs
//                                       .Q               (dout_internal[Bits-1:0]), // Templated
//                                       // Inputs
//                                       .CK              (clk),           // Templated
//                                       .CEB             (c_en),         // Templated
//                                       .WEB             (wr_en),        // Templated
//                                       .A               (addr[Add_Width-1:0]), // Templated
//                                       .D               (din[Bits-1:0]));// Templated
//        end
//
//        ('d1024 * OFFSET + 'd16): begin: mem_1024x16
//          localparam Bits=16,Add_Width=10;
//          localparam Word_Width=Bits;
//          localparam Addr_Depth=Add_Width;   
//          mem_1024x16_1rw_wrapper mem(/*autoinst*/
//                                       // Outputs
//                                       .Q               (dout_internal[Bits-1:0]), // Templated
//                                       // Inputs
//                                       .CK              (clk),           // Templated
//                                       .CEB             (c_en),         // Templated
//                                       .WEB             (wr_en),        // Templated
//                                       .A               (addr[Add_Width-1:0]), // Templated
//                                       .D               (din[Bits-1:0]));// Templated
//        end
//
//        ('d2048 * OFFSET + 'd16): begin: mem_2048x16
//          localparam Bits=16,Add_Width=11;
//          localparam Word_Width=Bits;
//          localparam Addr_Depth=Add_Width;   
//          mem_2048x16_1rw_wrapper mem(/*autoinst*/
//                                       // Outputs
//                                       .Q               (dout_internal[Bits-1:0]), // Templated
//                                       // Inputs
//                                       .CK              (clk),           // Templated
//                                       .CEB             (c_en),         // Templated
//                                       .WEB             (wr_en),        // Templated
//                                       .A               (addr[Add_Width-1:0]), // Templated
//                                       .D               (din[Bits-1:0]));// Templated
//        end
//
//        ('d960 * OFFSET + 'd32): begin: mem_960x32
//          localparam Bits=32,Add_Width=10;
//          localparam Word_Width=Bits;
//          localparam Addr_Depth=Add_Width;   
//          mem_960x32_1rw_wrapper mem(/*autoinst*/
//                                       // Outputs
//                                       .Q               (dout_internal[Bits-1:0]), // Templated
//                                       // Inputs
//                                       .CK              (clk),           // Templated
//                                       .CEB             (c_en),         // Templated
//                                       .WEB             (wr_en),        // Templated
//                                       .A               (addr[Add_Width-1:0]), // Templated
//                                       .D               (din[Bits-1:0]));// Templated
//        end
//
//        ('d10 * OFFSET + 'd260): begin: mem_10x260
//          //TODO: `include "../memories/isi_mem_wrapper_include.vh"
//          mem_1r1w_flops #(/*autoinstparam*/
//                           // Parameters
//                           .MEM_WORDS           (MEM_WORDS),
//                           .MEM_WIDTH           (MEM_WIDTH),
//                           .MEM_BIT_EN          (MEM_BIT_EN),
//                           .L2_MEM_WORDS        (L2_MEM_WORDS))
//            mem(/*autoinst*/
//                // Outputs
//                .dout_internal          (dout_internal[MEM_WIDTH-1:0]),
//                // Inputs
//                .din                    (din[MEM_WIDTH-1:0]),
//                .rd_addr                (addr[L2_MEM_WORDS-1:0]), // Templated
//                .rd_clk                 (clk),                   // Templated
//                .rd_en                  (c_en),                  // Templated
//                .wr_addr                (addr[L2_MEM_WORDS-1:0]), // Templated
//                .wr_clk                 (clk),                   // Templated
//                .wr_en                  (c_en &&  wr_en),        // Templated
//                .bit_en_internal        (bit_en_internal[MEM_WIDTH-1:0]));
//        end
//
//        ('d28 * OFFSET + 'd78): begin: mem_28x78
//          //TODO: `include "../memories/isi_mem_wrapper_include.vh"
//          mem_1r1w_flops #(/*autoinstparam*/
//                           // Parameters
//                           .MEM_WORDS           (MEM_WORDS),
//                           .MEM_WIDTH           (MEM_WIDTH),
//                           .MEM_BIT_EN          (MEM_BIT_EN),
//                           .L2_MEM_WORDS        (L2_MEM_WORDS))
//            mem(/*autoinst*/
//                // Outputs
//                .dout_internal          (dout_internal[MEM_WIDTH-1:0]),
//                // Inputs
//                .din                    (din[MEM_WIDTH-1:0]),
//                .rd_addr                (addr[L2_MEM_WORDS-1:0]), // Templated
//                .rd_clk                 (clk),                   // Templated
//                .rd_en                  (c_en),                  // Templated
//                .wr_addr                (addr[L2_MEM_WORDS-1:0]), // Templated
//                .wr_clk                 (clk),                   // Templated
//                .wr_en                  (c_en &&  wr_en),        // Templated
//                .bit_en_internal        (bit_en_internal[MEM_WIDTH-1:0]));
//        end
//
//`endif
        //MEMORY_CASE_LINES_END

        default: begin: mem_UNDEFxUNDEF
`ifdef MEM_NOT_FATAL_IF_NOT_DEFINED
          initial
            mem_model_not_defined: assert (0) else
              $warning("MEMORY 1rw %dx%d requested but not built",MEM_WORDS,MEM_WIDTH);
          
          mem_1r1w_flops
            #(/*autoinstparam*/
              // Parameters
              .MEM_WORDS                (MEM_WORDS),
              .MEM_WIDTH                (MEM_WIDTH),
              .MEM_BIT_EN               (MEM_BIT_EN),
              .L2_MEM_WORDS             (L2_MEM_WORDS))
          flops(/*autoinst*/
                // Outputs
                .dout_internal          (dout_internal[MEM_WIDTH-1:0]),
                // Inputs
                .din                    (din[MEM_WIDTH-1:0]),
                .rd_addr                (addr[L2_MEM_WORDS-1:0]), // Templated
                .rd_clk                 (clk),                   // Templated
                .rd_en                  (c_en),                  // Templated
                .wr_addr                (addr[L2_MEM_WORDS-1:0]), // Templated
                .wr_clk                 (clk),                   // Templated
                .wr_en                  (c_en &&  wr_en),        // Templated
                .bit_en_internal        (bit_en_internal[MEM_WIDTH-1:0]));
          
`else
          mem_model_not_defined #(
                                  .MEM_WORDS(MEM_WORDS),
                                  .MEM_WIDTH(MEM_WIDTH)
                                  ) mem();
`endif
        end
      endcase
      //leda on
    end
  endgenerate
`endif
    
endmodule 
//MEMORY_MEMDIR_BEGIN
// Local Variables:
// verilog-library-flags:("-y /asic/techlibs/smic55/memories/20140701")
// End:
//MEMORY_MEMDIR_END
