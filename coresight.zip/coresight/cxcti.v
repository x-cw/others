//-----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2003-2015 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//    Checked In : $Date: 2014-10-08 14:51:24 +0100 (Wed, 08 Oct 2014) $
//    Revision   : $Revision: 40194 $
//    Release    : CoreSight-SoC-TM100-r3p2-00rel0
//
// -----------------------------------------------------------------------------
//      Purpose             : Cross Trigger Interface Top Level
// -----------------------------------------------------------------------------

module cxcti
  (
  // Inputs
  cticlk, cticlken, ctiresetn, pclkdbg, pclkendbg, presetdbgn,
  ctiapbsbypass, cisbypass, tisbypassin, tisbypassack, cihsbypass,
  tihsbypass, dbgen, niden, penabledbg, pseldbg, paddrdbg,
  paddrdbg31, pwritedbg, pwdatadbg, ctitrigin, ctitrigoutack,
  ctichin, ctichoutack, tinidensel, todbgensel,
  // Outputs
  preadydbg, prdatadbg, ctitrigout, ctitriginack, ctichout,
  ctichinack, asicctl
  );

`include "cxcti_constants.v"

  //----------------------------------------------------------------------------
  // INPUTS
  //----------------------------------------------------------------------------

  // Systems inputs
  input                              cticlk;        // Clock
  input                              cticlken;      // Clock Enable
  input                              ctiresetn;     // Reset

  input                              pclkdbg;       // APB clock
  input                              pclkendbg;     // APB clock enable
  input                              presetdbgn;    // APB reset

  // Sync By pass control
  input                              ctiapbsbypass; // between APB and CTI clock

  input                              cisbypass;     // Channel interface sync bypass
  // (CTI to CTM)
  input [CSSOC_ECTTRIGGERWIDTH-1:0]  tisbypassin;   // Trigger In Sync bypass
  input [CSSOC_ECTTRIGGERWIDTH-1:0]  tisbypassack;  // Trigger Out ACK Sync bypass

  // Handshaking bypass
  input [CSSOC_ECTCHANNELWIDTH-1:0]  cihsbypass;    // Channel interface H/S bypass
  input [CSSOC_ECTTRIGGERWIDTH-1:0]  tihsbypass;    // Trigger interface H/S bypass

  // General control
  input                              dbgen;         // Invasive Debug enable
  input                              niden;         // Non-invasive debug enable

  // APB inputs
  input                              penabledbg;    // penabledbg
  input                              pseldbg;       // pseldbg
  input [11:2]                       paddrdbg;      // Address
  input                              paddrdbg31;    // APB dual mem-map
  input                              pwritedbg;     // Write control
  input [31:0]                       pwdatadbg;     // Write data


  // Trigger interface Inputs
  input [CSSOC_ECTTRIGGERWIDTH-1:0]  ctitrigin;     // Trigger In
  input [CSSOC_ECTTRIGGERWIDTH-1:0]  ctitrigoutack; // Trigger Out acknowledge

  // Channel interface Inputs
  input [CSSOC_ECTCHANNELWIDTH-1:0]  ctichin;       // Channel In
  input [CSSOC_ECTCHANNELWIDTH-1:0]  ctichoutack;   // Channel Out acknowledge

  // Masking Debug Enable Signals
  input [CSSOC_ECTTRIGGERWIDTH-1:0]  tinidensel;    // Mask when niden is LOW
  input [CSSOC_ECTTRIGGERWIDTH-1:0]  todbgensel;    // Mask when dbgen is LOW


  //----------------------------------------------------------------------------
  // OUTPUTS
  //----------------------------------------------------------------------------

  // APB outputs
  output                             preadydbg;     // preadydbg
  output [31:0]                      prdatadbg;     // read data

  // Trigger Interface Outputs
  output [CSSOC_ECTTRIGGERWIDTH-1:0] ctitrigout;    // Trigger Out
  output [CSSOC_ECTTRIGGERWIDTH-1:0] ctitriginack;  // Trigger In acknowledge

  // Channel interface Outputs
  output [CSSOC_ECTCHANNELWIDTH-1:0] ctichout;      // Channel Out
  output [CSSOC_ECTCHANNELWIDTH-1:0] ctichinack;    // Channel In acknowledge

  output [7:0]                       asicctl;       // External mux control

  //----------------------------------------------------------------------------
  // WIRES AND REGS
  //----------------------------------------------------------------------------
  wire [CSSOC_ECTCHANNELWIDTH-1:0] app_trigger;           // From u_cxcti_reg_c of cxcti_reg_c.v
  wire [19:0]                      cp_rdata;              // From uCSCtiRegP of cxcti_reg_p.v
  wire                             cp_req;                // From u_cxcti_apb_if of cxcti_apb_if.v
  wire                             ctack;                 // From u_cxcti_reg_c of cxcti_reg_c.v
  wire [CSSOC_ECTCHANNELWIDTH-1:0] ctiinen0;              // From u_cxcti_reg_c of cxcti_reg_c.v
  wire [CSSOC_ECTCHANNELWIDTH-1:0] ctiinen1;              // From u_cxcti_reg_c of cxcti_reg_c.v
  wire [CSSOC_ECTCHANNELWIDTH-1:0] ctiinen2;              // From u_cxcti_reg_c of cxcti_reg_c.v
  wire [CSSOC_ECTCHANNELWIDTH-1:0] ctiinen3;              // From u_cxcti_reg_c of cxcti_reg_c.v
  wire [CSSOC_ECTCHANNELWIDTH-1:0] ctiinen4;              // From u_cxcti_reg_c of cxcti_reg_c.v
  wire [CSSOC_ECTCHANNELWIDTH-1:0] ctiinen5;              // From u_cxcti_reg_c of cxcti_reg_c.v
  wire [CSSOC_ECTCHANNELWIDTH-1:0] ctiinen6;              // From u_cxcti_reg_c of cxcti_reg_c.v
  wire [CSSOC_ECTCHANNELWIDTH-1:0] ctiinen7;              // From u_cxcti_reg_c of cxcti_reg_c.v
  wire [CSSOC_ECTCHANNELWIDTH-1:0] ctiouten0;             // From u_cxcti_reg_c of cxcti_reg_c.v
  wire [CSSOC_ECTCHANNELWIDTH-1:0] ctiouten1;             // From u_cxcti_reg_c of cxcti_reg_c.v
  wire [CSSOC_ECTCHANNELWIDTH-1:0] ctiouten2;             // From u_cxcti_reg_c of cxcti_reg_c.v
  wire [CSSOC_ECTCHANNELWIDTH-1:0] ctiouten3;             // From u_cxcti_reg_c of cxcti_reg_c.v
  wire [CSSOC_ECTCHANNELWIDTH-1:0] ctiouten4;             // From u_cxcti_reg_c of cxcti_reg_c.v
  wire [CSSOC_ECTCHANNELWIDTH-1:0] ctiouten5;             // From u_cxcti_reg_c of cxcti_reg_c.v
  wire [CSSOC_ECTCHANNELWIDTH-1:0] ctiouten6;             // From u_cxcti_reg_c of cxcti_reg_c.v
  wire [CSSOC_ECTCHANNELWIDTH-1:0] ctiouten7;             // From u_cxcti_reg_c of cxcti_reg_c.v
  wire [7:0]                       ct_rdata;              // From u_cxcti_reg_c of cxcti_reg_c.v
  wire                             ct_req;                // From u_cxcti_apb_if of cxcti_apb_if.v
  wire [CSSOC_ECTCHANNELWIDTH-1:0] ch_out_enable;         // From u_cxcti_reg_c of cxcti_reg_c.v
  wire                             cti_control;           // From u_cxcti_reg_c of cxcti_reg_c.v
  wire [CSSOC_ECTTRIGGERWIDTH-1:0] cti_int_ack;           // From u_cxcti_reg_c of cxcti_reg_c.v
  wire                             dbgen_sync_2;          // From uCSCtiTI of cxcti_ti.v
  wire                             device_un_locked;      // From uCSCtiRegP of cxcti_reg_p.v
  wire                             itchin_ack_en;         // From u_cxcti_reg_c of cxcti_reg_c.v
  wire [CSSOC_ECTCHANNELWIDTH-1:0] itchin_r_data;         // From u_cxcti_ci of cxcti_c_i.v
  wire [CSSOC_ECTCHANNELWIDTH-1:0] itchout_ack_r_data;    // From u_cxcti_ci of cxcti_c_i.v
  wire                             itch_out_en;           // From u_cxcti_reg_c of cxcti_reg_c.v
  wire                             iten;                  // From u_cxcti_reg_c of cxcti_reg_c.v
  wire                             it_triginack_en;       // From u_cxcti_reg_c of cxcti_reg_c.v
  wire [CSSOC_ECTTRIGGERWIDTH-1:0] it_trigin_r_data;      // From uCSCtiTI of cxcti_ti.v
  wire [CSSOC_ECTTRIGGERWIDTH-1:0] it_trigout_ack_r_data; // From uCSCtiTI of cxcti_ti.v
  wire                             it_trigout_en;         // From u_cxcti_reg_c of cxcti_reg_c.v
  wire                             internal_niden;        // From uCSCtiTI of cxcti_ti.v
  wire [CSSOC_ECTCHANNELWIDTH-1:0] map_ch_in;             // From u_cxcti_ci of cxcti_c_i.v
  wire [CSSOC_ECTCHANNELWIDTH-1:0] map_ch_out;            // From uCSCtiMapper of cxcti_mapper.v
  wire [CSSOC_ECTTRIGGERWIDTH-1:0] map_trig_in;           // From uCSCtiTI of cxcti_ti.v
  wire [CSSOC_ECTTRIGGERWIDTH-1:0] map_trig_out;          // From uCSCtiMapper of cxcti_mapper.v
  wire [CSSOC_ECTCHANNELWIDTH-1:0] reg_ch_in_status;      // From u_cxcti_ci of cxcti_c_i.v
  wire [CSSOC_ECTCHANNELWIDTH-1:0] reg_ch_out_status;     // From u_cxcti_ci of cxcti_c_i.v
  wire [CSSOC_ECTTRIGGERWIDTH-1:0] reg_trig_in_status;    // From uCSCtiTI of cxcti_ti.v
  wire [CSSOC_ECTTRIGGERWIDTH-1:0] reg_trig_out_status;   // From uCSCtiTI of cxcti_ti.v

  //----------------------------------------------------------------------------
  //
  // MAIN CODE
  //
  //----------------------------------------------------------------------------

  // APB Interface unit
  cxcti_apb_if u_cxcti_apb_if
    (
     // Outputs
     .preadydbg                         (preadydbg),
     .prdatadbg                         (prdatadbg[31:0]),
     .ct_req                            (ct_req),
     .cp_req                            (cp_req),
     // Inputs
     .presetdbgn                        (presetdbgn),
     .pclkdbg                           (pclkdbg),
     .pclkendbg                         (pclkendbg),
     .ctiapbsbypass                     (ctiapbsbypass),
     .penabledbg                        (penabledbg),
     .pseldbg                           (pseldbg),
     .paddrdbg                          (paddrdbg[11:2]),
     .pwritedbg                         (pwritedbg),
     .ctack                             (ctack),
     .ct_rdata                          (ct_rdata[7:0]),
     .cp_rdata                          (cp_rdata[19:0]));

  // Register block
  cxcti_reg_p u_cxcti_reg_p
    (
     // Outputs
     .cp_rdata                          (cp_rdata[19:0]),
     .device_un_locked                  (device_un_locked),
     // Inputs
     .presetdbgn                        (presetdbgn),
     .pclkdbg                           (pclkdbg),
     .pclkendbg                         (pclkendbg),
     .paddrdbg                          (paddrdbg[11:2]),
     .pwritedbg                         (pwritedbg),
     .pwdatadbg                         (pwdatadbg[31:0]),
     .cp_req                            (cp_req),
     .paddrdbg31                        (paddrdbg31));

  // Register block
  cxcti_reg_c u_cxcti_reg_c
    (
     // Outputs
     .ctack                             (ctack),
     .ct_rdata                          (ct_rdata[7:0]),
     .ctiinen0                          (ctiinen0[CSSOC_ECTCHANNELWIDTH-1:0]),
     .ctiouten0                         (ctiouten0[CSSOC_ECTCHANNELWIDTH-1:0]),
     .ctiinen1                          (ctiinen1[CSSOC_ECTCHANNELWIDTH-1:0]),
     .ctiouten1                         (ctiouten1[CSSOC_ECTCHANNELWIDTH-1:0]),
     .ctiinen2                          (ctiinen2[CSSOC_ECTCHANNELWIDTH-1:0]),
     .ctiouten2                         (ctiouten2[CSSOC_ECTCHANNELWIDTH-1:0]),
     .ctiinen3                          (ctiinen3[CSSOC_ECTCHANNELWIDTH-1:0]),
     .ctiouten3                         (ctiouten3[CSSOC_ECTCHANNELWIDTH-1:0]),
     .ctiinen4                          (ctiinen4[CSSOC_ECTCHANNELWIDTH-1:0]),
     .ctiouten4                         (ctiouten4[CSSOC_ECTCHANNELWIDTH-1:0]),
     .ctiinen5                          (ctiinen5[CSSOC_ECTCHANNELWIDTH-1:0]),
     .ctiouten5                         (ctiouten5[CSSOC_ECTCHANNELWIDTH-1:0]),
     .ctiinen6                          (ctiinen6[CSSOC_ECTCHANNELWIDTH-1:0]),
     .ctiouten6                         (ctiouten6[CSSOC_ECTCHANNELWIDTH-1:0]),
     .ctiinen7                          (ctiinen7[CSSOC_ECTCHANNELWIDTH-1:0]),
     .ctiouten7                         (ctiouten7[CSSOC_ECTCHANNELWIDTH-1:0]),
     .app_trigger                       (app_trigger[CSSOC_ECTCHANNELWIDTH-1:0]),
     .cti_int_ack                       (cti_int_ack[CSSOC_ECTTRIGGERWIDTH-1:0]),
     .cti_control                       (cti_control),
     .ch_out_enable                     (ch_out_enable[CSSOC_ECTCHANNELWIDTH-1:0]),
     .asicctl                           (asicctl[7:0]),
     .iten                              (iten),
     .itchin_ack_en                     (itchin_ack_en),
     .it_triginack_en                   (it_triginack_en),
     .itch_out_en                       (itch_out_en),
     .it_trigout_en                     (it_trigout_en),
     // Inputs
     .cticlk                            (cticlk),
     .cticlken                          (cticlken),
     .ctiresetn                         (ctiresetn),
     .ctiapbsbypass                     (ctiapbsbypass),
     .paddrdbg                          (paddrdbg[11:2]),
     .pwritedbg                         (pwritedbg),
     .pwdatadbg                         (pwdatadbg[7:0]),
     .ct_req                            (ct_req),
     .paddrdbg31                        (paddrdbg31),
     .device_un_locked                  (device_un_locked),
     .reg_trig_in_status                (reg_trig_in_status[CSSOC_ECTTRIGGERWIDTH-1:0]),
     .reg_trig_out_status               (reg_trig_out_status[CSSOC_ECTTRIGGERWIDTH-1:0]),
     .reg_ch_in_status                  (reg_ch_in_status[CSSOC_ECTCHANNELWIDTH-1:0]),
     .reg_ch_out_status                 (reg_ch_out_status[CSSOC_ECTCHANNELWIDTH-1:0]),
     .internal_niden                    (internal_niden),
     .dbgen_sync_2                      (dbgen_sync_2),
     .itchout_ack_r_data                (itchout_ack_r_data[CSSOC_ECTCHANNELWIDTH-1:0]),
     .it_trigout_ack_r_data             (it_trigout_ack_r_data[CSSOC_ECTTRIGGERWIDTH-1:0]),
     .itchin_r_data                     (itchin_r_data[CSSOC_ECTCHANNELWIDTH-1:0]),
     .it_trigin_r_data                  (it_trigin_r_data[CSSOC_ECTTRIGGERWIDTH-1:0]));

  // Trigger I/F
  cxcti_ti u_cxcti_ti
    (
     // Outputs
     .ctitrigout                        (ctitrigout[CSSOC_ECTTRIGGERWIDTH-1:0]),
     .map_trig_in                       (map_trig_in[CSSOC_ECTTRIGGERWIDTH-1:0]),
     .ctitriginack                      (ctitriginack[CSSOC_ECTTRIGGERWIDTH-1:0]),
     .reg_trig_in_status                (reg_trig_in_status[CSSOC_ECTTRIGGERWIDTH-1:0]),
     .reg_trig_out_status               (reg_trig_out_status[CSSOC_ECTTRIGGERWIDTH-1:0]),
     .it_trigout_ack_r_data             (it_trigout_ack_r_data[CSSOC_ECTTRIGGERWIDTH-1:0]),
     .it_trigin_r_data                  (it_trigin_r_data[CSSOC_ECTTRIGGERWIDTH-1:0]),
     .internal_niden                    (internal_niden),
     .dbgen_sync_2                      (dbgen_sync_2),
     // Inputs
     .cticlk                            (cticlk),
     .cticlken                          (cticlken),
     .ctiresetn                         (ctiresetn),
     .tisbypassin                       (tisbypassin[CSSOC_ECTTRIGGERWIDTH-1:0]),
     .tisbypassack                      (tisbypassack[CSSOC_ECTTRIGGERWIDTH-1:0]),
     .tihsbypass                        (tihsbypass[CSSOC_ECTTRIGGERWIDTH-1:0]),
     .ctitrigin                         (ctitrigin[CSSOC_ECTTRIGGERWIDTH-1:0]),
     .map_trig_out                      (map_trig_out[CSSOC_ECTTRIGGERWIDTH-1:0]),
     .ctitrigoutack                     (ctitrigoutack[CSSOC_ECTTRIGGERWIDTH-1:0]),
     .cti_int_ack                       (cti_int_ack[CSSOC_ECTTRIGGERWIDTH-1:0]),
     .iten                              (iten),
     .dbgen                             (dbgen),
     .niden                             (niden),
     .tinidensel                        (tinidensel[CSSOC_ECTTRIGGERWIDTH-1:0]),
     .todbgensel                        (todbgensel[CSSOC_ECTTRIGGERWIDTH-1:0]),
     .pwdatadbg                         (pwdatadbg[CSSOC_ECTTRIGGERWIDTH-1:0]),
     .it_triginack_en                   (it_triginack_en),
     .it_trigout_en                     (it_trigout_en));

  // Trigger to Channel and Channel to trigger mapping logic
  cxcti_mapper u_cxcti_mapper
    (
     // Outputs
     .map_trig_out                      (map_trig_out[CSSOC_ECTTRIGGERWIDTH-1:0]),
     .map_ch_out                        (map_ch_out[CSSOC_ECTCHANNELWIDTH-1:0]),
     // Inputs
     .cti_control                       (cti_control),
     .ctiinen0                          (ctiinen0[CSSOC_ECTCHANNELWIDTH-1:0]),
     .ctiouten0                         (ctiouten0[CSSOC_ECTCHANNELWIDTH-1:0]),
     .ctiinen1                          (ctiinen1[CSSOC_ECTCHANNELWIDTH-1:0]),
     .ctiouten1                         (ctiouten1[CSSOC_ECTCHANNELWIDTH-1:0]),
     .ctiinen2                          (ctiinen2[CSSOC_ECTCHANNELWIDTH-1:0]),
     .ctiouten2                         (ctiouten2[CSSOC_ECTCHANNELWIDTH-1:0]),
     .ctiinen3                          (ctiinen3[CSSOC_ECTCHANNELWIDTH-1:0]),
     .ctiouten3                         (ctiouten3[CSSOC_ECTCHANNELWIDTH-1:0]),
     .ctiinen4                          (ctiinen4[CSSOC_ECTCHANNELWIDTH-1:0]),
     .ctiouten4                         (ctiouten4[CSSOC_ECTCHANNELWIDTH-1:0]),
     .ctiinen5                          (ctiinen5[CSSOC_ECTCHANNELWIDTH-1:0]),
     .ctiouten5                         (ctiouten5[CSSOC_ECTCHANNELWIDTH-1:0]),
     .ctiinen6                          (ctiinen6[CSSOC_ECTCHANNELWIDTH-1:0]),
     .ctiouten6                         (ctiouten6[CSSOC_ECTCHANNELWIDTH-1:0]),
     .ctiinen7                          (ctiinen7[CSSOC_ECTCHANNELWIDTH-1:0]),
     .ctiouten7                         (ctiouten7[CSSOC_ECTCHANNELWIDTH-1:0]),
     .app_trigger                       (app_trigger[CSSOC_ECTCHANNELWIDTH-1:0]),
     .map_trig_in                       (map_trig_in[CSSOC_ECTTRIGGERWIDTH-1:0]),
     .map_ch_in                         (map_ch_in[CSSOC_ECTCHANNELWIDTH-1:0]));

  // Channel interface
  cxcti_ci u_cxcti_ci
    (
     // Outputs
     .ctichout                          (ctichout[CSSOC_ECTCHANNELWIDTH-1:0]),
     .map_ch_in                         (map_ch_in[CSSOC_ECTCHANNELWIDTH-1:0]),
     .ctichinack                        (ctichinack[CSSOC_ECTCHANNELWIDTH-1:0]),
     .reg_ch_in_status                  (reg_ch_in_status[CSSOC_ECTCHANNELWIDTH-1:0]),
     .reg_ch_out_status                 (reg_ch_out_status[CSSOC_ECTCHANNELWIDTH-1:0]),
     .itchout_ack_r_data                (itchout_ack_r_data[CSSOC_ECTCHANNELWIDTH-1:0]),
     .itchin_r_data                     (itchin_r_data[CSSOC_ECTCHANNELWIDTH-1:0]),
     // Inputs
     .cticlk                            (cticlk),
     .cticlken                          (cticlken),
     .ctiresetn                         (ctiresetn),
     .cti_control                       (cti_control),
     .cisbypass                         (cisbypass),
     .cihsbypass                        (cihsbypass[CSSOC_ECTCHANNELWIDTH-1:0]),
     .ctichin                           (ctichin[CSSOC_ECTCHANNELWIDTH-1:0]),
     .ctichoutack                       (ctichoutack[CSSOC_ECTCHANNELWIDTH-1:0]),
     .map_ch_out                        (map_ch_out[CSSOC_ECTCHANNELWIDTH-1:0]),
     .ch_out_enable                     (ch_out_enable[CSSOC_ECTCHANNELWIDTH-1:0]),
     .iten                              (iten),
     .itchin_ack_en                     (itchin_ack_en),
     .itch_out_en                       (itch_out_en),
     .pwdatadbg                         (pwdatadbg[CSSOC_ECTCHANNELWIDTH-1:0]));

endmodule
