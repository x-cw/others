//-----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//  
//            (C) COPYRIGHT 2009-2010 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//  Checked In   :  2010-06-20 10:52:32 +0530 (Sun, 20 Jun 2010) 
//  Revision     :  8288 
//  Release      : TM961-BU-50000-r0p0-00rel0
//
//-----------------------------------------------------------------------------
// Purpose : CoreSight Trace Memory Controller (CXTMC) - Top Level Block
//-----------------------------------------------------------------------------
//
// CXTMC - CoreSight Trace Memory Controller
// -----------------------------------------
//
// The CoreSight Trace Memory Controller is a CoreSight AMBA Trace Bus (ATB) 
// device that enables buffering of trace data. Optionally, the trace data can
// be formatted and triggers can be inserted in the trace stream by the 
// TMC. 
// In the ETB (Embedded Trace Buffer) and ETF (Embedded Trace FIFO) 
// configurations, the TMC uses local memory (SRAM) as trace buffer. In the
// ETR (Embedded Trace Router) configuration, system memory is used to store 
// trace data through an AXI master interface.
//
// CXTMC.v
// -------
//
// CXTMC.v provides the instantiations of all modules for the CoreSight TMC.
//
// Instantiated blocks
// -------------------
//
// cxtmc_apbslvif.v        - APB Slave Interface
// cxtmc_regfile.v         - Register block
// cxtmc_apbreadfifo.v     - FIFO for data read from trace memory (ETB, ETR 
//                           configurations only)
// cxtmc_memif.v           - Memory Interface (ETB, ETF configurations only)
// cxtmc_format_control.v  - Formatter Control logic
// cxtmc_formatter.v       - ATB Frame formatter
// cxtmc_wrbuffer.v        - Stores and forwards trace data from the Formatter/
//                           APB interface to the Memory interface/AXI
// cxtmc_unformatter.v     - ATB Unformatter (ETF configuration only)
// cxtmc_unf_data_mux.v    - Data mux - instantiated by cxtmc_unformatter
// cxtmc_sync_req.v        - ATB Synchronisation request generator
// cxtmc_axi_if.v          - AXI Master Interface (ETR configuration only)
// cxtmc_etr_sg.v          - Scatter-Gather control logic (ETR configuration 
//                           only)
// cxtmc_clk_module.v      - Clock control block
// cxtmc_clk_gate.v        - Clock gate - instantiated by cxtmc_clk_module
//
//-----------------------------------------------------------------------------
module CXTMC_ETB
(
  CLK,
  RESETn,

  // ATB Slave interface
  ATVALIDS,
  ATIDS,
  ATBYTESS,
  ATDATAS,
  AFREADYS,
  ATREADYS,
  AFVALIDS,

  // Debug APB Slave interface
  PCLKENDBG,
  PSELDBG,
  PENABLEDBG,
  PWRITEDBG,
  PADDRDBG31,
  PADDRDBG,
  PWDATADBG,
  PREADYDBG,
  PSLVERRDBG,
  PRDATADBG,

  // SRAM interface
  MEMQ,
  MEMCEN,
  MEMADDR,
  MEMWEN,
  MEMD,

  // Event interfaces
  // External request to insert trigger in trace stream
  TRIGIN,

  // External request to initiate flush on ATB slave interface
  FLUSHIN,

  // Synchronisation request on ATB slave interface
  SYNCREQS,

  // Trace memory full or write pointer wrapped around (CB mode)
  FULL,

  // Trace acquisition complete
  ACQCOMP,

  // Test interfaces
  // Test mode - forces clock to be switched on
  DFTTESTMODE,

  // Clock disable DFT control
  DFTCLKDISABLE
  );

//-----------------------------------------------------------------------------
// Constant Functions
//-----------------------------------------------------------------------------
// 'mem_depth' argument is in 32-bit words
// This function is separate from cxtmc_log2 function to stay within the
// maximum allowed unsigned integer value
function integer cxtmc_mem_byte_addr_width_calc (input integer mem_depth);
  integer i;
  begin
    cxtmc_mem_byte_addr_width_calc = 2; // Initialisation
    for(i = mem_depth; i > 1; i = i >> 1)
      cxtmc_mem_byte_addr_width_calc = cxtmc_mem_byte_addr_width_calc + 1;
  end
endfunction

//-----------------------------------------------------------------------------
// Local Parameters
//-----------------------------------------------------------------------------
`include "cxtmc_constants.v"

localparam CXTMC_ATBM_AXIM_CFG = 0;  // TMC configuration
                                      // Valid Values: 0 (ETB), 1 (ETR) and
                                      // 2 (ETF)
// --------------------------------------------------------------------------
localparam CXTMC_WBUFFER_DEPTH = 1;  // Write Buffer Depth
                                      // Valid Values:
                                      // ETB/ETF configurations - 1
                                      // ETR configuration - 4, 8, 16 and 32
// --------------------------------------------------------------------------
localparam CXTMC_MEM_SIZE = 31'h00000200; // Size of external SRAM in 32-bit
                                           // words in ETB/ETF configs
                                           // Valid values:
                                           // 31'h00000080 (512 Bytes)
                                           // 31'h00000100 (1 KBytes)
                                           // 31'h00000200 (2 KBytes)
                                           // 31'h00000400 (4 KBytes)
                                           // 31'h00000800 (8 KBytes)
                                           // 31'h00001000 (16 KBytes)
                                           // 31'h00002000 (32 KBytes)
                                           // 31'h00004000 (64 KBytes)
                                           // 31'h00008000 (128 KBytes)
                                           // 31'h00010000 (256 KBytes)
                                           // 31'h00020000 (512 KBytes)
                                           // 31'h00040000 (1 MBytes)
                                           // 31'h00080000 (2 MBytes)
                                           // 31'h00100000 (4 MBytes)
                                           // 31'h00200000 (8 MBytes)
                                           // 31'h00400000 (16 MBytes)
                                           // 31'h00800000 (32 MBytes)
                                           // 31'h01000000 (64 MBytes)
                                           // 31'h02000000 (128 MBytes)
                                           // 31'h04000000 (256 MBytes)
                                           // 31'h08000000 (512 MBytes)
                                           // 31'h10000000 (1 GBytes)
                                           // 31'h20000000 (2 GBytes)
                                           // 31'h40000000 (4 GBytes)
// --------------------------------------------------------------------------
localparam CXTMC_ATB_DATA_WIDTH = 128; // Width of the databus on the
                                           // ATB Slave interface and the
                                           // ATB Mater interface (ETF config)
                                           // Valid values: 32, 64 and 128
// --------------------------------------------------------------------------

// ATBYTES width
localparam CXTMC_ATBYTES_WIDTH = (CXTMC_ATB_DATA_WIDTH == 32) ? 2 :
                                 (CXTMC_ATB_DATA_WIDTH == 64) ? 3 :
                                                                4;
                                                                // 128-bit ATB 

// Width of the AXI databus is the same as the ATB datawidth
localparam CXTMC_AXI_DATA_WIDTH = CXTMC_ATB_DATA_WIDTH;

// Address width of SRAM memory
// Depth = log2[Size(in_bytes)/Width(in_bytes)]
// Width of SRAM interface databus is twice the ATB datawidth
// Multiplication by 4 is done last so as to keep the numerical results
// within allowed range for unsigned integers
// In the ETR configuration where the memory size is programmable (rather than
// parameterisable), this parameter is determined by CXTMC_AXI_DATA_WIDTH
// Trace memory size is restricted to a max of 4GB. However, the pointers are 
// 40bits wide since the trace memory can be located anywhere in the system
// address space (but with start address aligned to a 4KB address boundary).
localparam CXTMC_MEM_ADDR_WIDTH =  (CXTMC_ATBM_AXIM_CFG == CXTMC_CFG_ETR) ?
                                     ((CXTMC_AXI_DATA_WIDTH == 32) ? 38 :
                                      (CXTMC_AXI_DATA_WIDTH == 64) ? 37 : 36) :
                                     cxtmc_log2(4*((CXTMC_MEM_SIZE)/
                                       (CXTMC_ATB_DATA_WIDTH*2/8)));

// Width of RRP and RWP registers (includes higher order 8 bits in ETR case)
localparam CXTMC_MEM_BYTE_ADDR_WIDTH = (CXTMC_ATBM_AXIM_CFG == CXTMC_CFG_ETR) ?
                                       40 :
                                cxtmc_mem_byte_addr_width_calc(CXTMC_MEM_SIZE);

// Width of write databus in Write Buffer
localparam CXTMC_WB_DATA_WIDTH = (CXTMC_ATBM_AXIM_CFG ==
                                  CXTMC_CFG_ETR) ?
                                    CXTMC_ATB_DATA_WIDTH :
                                    2*CXTMC_ATB_DATA_WIDTH;

// Width of pointers in write buffer
localparam CXTMC_WB_PTR_WIDTH = (CXTMC_WBUFFER_DEPTH == 1) ? 1 :
                                cxtmc_log2(CXTMC_WBUFFER_DEPTH);

// The TRG counter counts the number of 32-bit words written to trace memory
// after a trigger event has occurred. In ETR configuration, this counter is
// always 32-bits wide independent of the size system memory used for trace.
localparam CXTMC_TRG_WIDTH = (CXTMC_ATBM_AXIM_CFG ==
                               CXTMC_CFG_ETR) ? 32 :
                               cxtmc_log2(CXTMC_MEM_SIZE);

// The ITATBDATA0 register requires a few specific bits from ATDATAS
localparam CXTMC_ITATBDATA0_WIDTH = (CXTMC_ATB_DATA_WIDTH == 32) ? 5 :
                                    (CXTMC_ATB_DATA_WIDTH == 64) ? 9 :
                                                                   17;

// The LBUFLEVEL, CBUFLEVEL and BUFWM registers have widths that are
// dependent on CXTMC_MEM_SIZE for ETB/ETF configurations. For the ETR
// configuration, this defaults to a max 4GB trace mem size
// regardless of the value programmed into the RSZ register
// Since the LBUFLEVEL, CBUFLEVEL and BUFWM registers represent levels in
// terms of 32-bit words, they require 2 bits less than the number of bits
// needed to represent the memory address in bytes. Also, the fill levels
// need to be able to return a full value that needs an extra bit.
localparam CXTMC_FILL_LEVEL_WIDTH = (CXTMC_ATBM_AXIM_CFG == CXTMC_CFG_ETR) ?
                                      31 :
                                      CXTMC_MEM_BYTE_ADDR_WIDTH-1;

//-----------------------------------------------------------------------------
// Port direction and width declarations
//-----------------------------------------------------------------------------
  input                                   CLK;
  input                                   RESETn;

  // ATB Slave interface
  input                                   ATVALIDS;
  input  [6:0]                            ATIDS;
  input  [1:0]                            ATBYTESS;
  input  [CXTMC_ATB_DATA_WIDTH-1:0]       ATDATAS;
  input                                   AFREADYS;
  output                                  ATREADYS;
  output                                  AFVALIDS;

  // Debug APB Slave interface
  input                                   PCLKENDBG;
  input                                   PSELDBG;
  input                                   PENABLEDBG;
  input                                   PWRITEDBG;
  input                                   PADDRDBG31;
  input  [11:2]                           PADDRDBG;
  input  [31:0]                           PWDATADBG;
  output                                  PREADYDBG;
  output                                  PSLVERRDBG;
  output [31:0]                           PRDATADBG;

  // SRAM interface
  input  [2*CXTMC_ATB_DATA_WIDTH-1:0]     MEMQ;
  output                                  MEMCEN;
  output [CXTMC_MEM_ADDR_WIDTH-1:0]       MEMADDR;
  output                                  MEMWEN;
  output [2*CXTMC_ATB_DATA_WIDTH-1:0]     MEMD;

  // Event interfaces
  // External request to insert trigger in trace stream
  input                                   TRIGIN;

  // External request to initiate flush on ATB slave interface
  input                                   FLUSHIN;

  // Synchronisation request on ATB slave interface
  output                                  SYNCREQS;

  // Trace memory full or write pointer wrapped around (CB mode)
  output                                  FULL;

  // Trace acquisition complete
  output                                  ACQCOMP;

  // Test interfaces
  // Test mode - forces clock to be switched on
  input                                   DFTTESTMODE;

  // Clock disable DFT control
  input                                   DFTCLKDISABLE;

//-----------------------------------------------------------------------------
// Wire declarations for top-level ports
//-----------------------------------------------------------------------------
  wire                                    CLK;
  wire                                    RESETn;

  // ATB Master interface
  wire                                    ATREADYM;
  wire                                    AFVALIDM;
  wire                                    ATVALIDM;
  wire   [6:0]                            ATIDM;
  wire   [CXTMC_ATBYTES_WIDTH-1:0]        ATBYTESM;
  wire   [CXTMC_ATB_DATA_WIDTH-1:0]       ATDATAM;
  wire                                    AFREADYM;

  // ATB Slave interface
  wire                                    ATVALIDS;
  wire   [6:0]                            ATIDS;
  wire   [1:0]                            ATBYTESS;
  wire   [CXTMC_ATB_DATA_WIDTH-1:0]       ATDATAS;
  wire                                    AFREADYS;
  wire                                    ATREADYS;
  wire                                    AFVALIDS;

  // Debug APB Slave interface
  wire                                    PCLKENDBG;
  wire                                    PSELDBG;
  wire                                    PENABLEDBG;
  wire                                    PWRITEDBG;
  wire                                    PADDRDBG31;
  wire   [11:2]                           PADDRDBG;
  wire   [31:0]                           PWDATADBG;
  wire                                    PREADYDBG;
  wire                                    PSLVERRDBG;
  wire   [31:0]                           PRDATADBG;
  // SRAM interface
  wire   [2*CXTMC_ATB_DATA_WIDTH-1:0]     MEMQ;
  wire                                    MEMCEN;
  wire   [CXTMC_MEM_ADDR_WIDTH-1:0]       MEMADDR;
  wire                                    MEMWEN;
  wire   [2*CXTMC_ATB_DATA_WIDTH-1:0]     MEMD;

  // AR Channel
  wire                                    ARREADYM;
  wire   [39:0]                           ARADDRM;
  wire   [3:0]                            ARLENM;
  wire   [2:0]                            ARSIZEM;
  wire   [1:0]                            ARBURSTM;
  wire   [1:0]                            ARLOCKM;
  wire   [3:0]                            ARCACHEM;
  wire   [2:0]                            ARPROTM;
  wire                                    ARVALIDM;

  // R Channel
  wire   [CXTMC_AXI_DATA_WIDTH-1:0]       RDATAM;
  wire   [1:0]                            RRESPM;
  wire                                    RLASTM;
  wire                                    RVALIDM;
  wire                                    RREADYM;

  // AW Channel
  wire                                    AWREADYM;
  wire   [39:0]                           AWADDRM;
  wire   [3:0]                            AWLENM;
  wire   [2:0]                            AWSIZEM;
  wire   [1:0]                            AWBURSTM;
  wire   [1:0]                            AWLOCKM;
  wire   [3:0]                            AWCACHEM;
  wire   [2:0]                            AWPROTM;
  wire                                    AWVALIDM;

  // W Channel
  wire                                    WREADYM;
  wire   [CXTMC_AXI_DATA_WIDTH-1:0]       WDATAM;
  wire   [(CXTMC_AXI_DATA_WIDTH/8)-1:0]   WSTRBM;
  wire                                    WLASTM;
  wire                                    WVALIDM;

  // B Channel
  wire   [1:0]                            BRESPM;
  wire                                    BVALIDM;
  wire                                    BREADYM;

  // Authentication Interface
  wire                                    DBGEN;
  wire                                    SPIDEN;

  // AXI Low Power interface
  wire                                    CACTIVE;
  wire                                    CSYSREQ;
  wire                                    CSYSACK;
  // Event interfaces
  // External request to insert trigger in trace stream
  wire                                    TRIGIN;

  // External request to initiate flush on ATB slave interface
  wire                                    FLUSHIN;

  // Synchronisation request on ATB master interface
  wire                                    SYNCREQM;

  // Synchronisation request on ATB slave interface
  wire                                    SYNCREQS; // From SYNC generator

  // Trace memory full or write pointer wrapped around (CB mode)
  wire                                    FULL;

  // Trace acquisition complete
  wire                                    ACQCOMP;

  // Test interfaces
  // Test mode - forces clock to be switched on
  wire                                    DFTTESTMODE;

  // Clock disable DFT control
  wire                                    DFTCLKDISABLE;

  // --------------------------------------------------------------------------
  // Global Nets
  // --------------------------------------------------------------------------
  wire                                   ffcr_flush_man;
  wire                                   ctl_trace_capt_en;
  wire                                   ctl_trace_capt_en_0_1;
  wire                                   ft_running_p0;
  wire                                   tmc_disabled;
  wire                                   apb_read_fifo_rrp_en;
  wire                                   unformatter_en;
  wire                                   unformatter_stop;
  wire                                   ptr_clr;
  wire                                   ctl_trace_capt_en_1_0;
  wire                                   apbreadfifo_clr;
  wire                                   flush_man_clr;
  wire                                   trace_mem_empty;
  wire                                   triggered;
  wire [31:0]                            rrd;
  wire                                   rrd_rd_ack;
  wire [CXTMC_MEM_BYTE_ADDR_WIDTH-1:0]   rrp;
  wire [CXTMC_MEM_BYTE_ADDR_WIDTH-1:0]   rwp;
  wire                                   unformatter_empty;
  wire                                   lat_buf_level_rd_done;
  wire [CXTMC_FILL_LEVEL_WIDTH-1:0]      lat_buf_level;
  wire [CXTMC_FILL_LEVEL_WIDTH-1:0]      c_buf_level;
  wire                                   mem_err;
  wire                                   mem_err_pt;
  wire                                   mem_err_clr;
  wire [30:0]                            rsz_masked;
  wire                                   axi_intf_ready;
  wire                                   ft_stop_req;
  wire                                   ft_trig_req;
  wire                                   it_ctrl;
  wire                                   ft_data_valid;
  wire                                   ft_trig_ack;
  wire                                   trig_id_detect;
  wire [CXTMC_ATB_DATA_WIDTH-1:0]        ft_data;
  wire                                   rb_req_ready;
  wire                                   rb_rdata_valid;
  wire                                   rrd_rd_req;
  wire                                   rb_req_valid;
  wire [CXTMC_WB_DATA_WIDTH-1:0]         rb_data;
  wire                                   wb_req_ready;
  wire                                   wb_req_valid;
  wire                                   wb_ready;
  wire                                   rrp_wr_en;
  wire                                   rwp_wr_en;
  wire                                   circ_buf_mode;
  wire                                   sw_fifo_mode;
  wire                                   hw_fifo_mode;
  wire                                   trg_wr_en;
  wire                                   ft_stopped;
  wire [CXTMC_WB_DATA_WIDTH-1:0]         wb_data;
  wire [CXTMC_TRG_WIDTH-1:0]             trg;
  wire                                   nxt_wb_ready;
  wire                                   rwd_wr_req;
  wire                                   it_atb_ctr_2_wr_en;
  wire                                   it_atb_m_ctr_0_wr_en;
  wire [CXTMC_FILL_LEVEL_WIDTH-2:0]      buf_wm;
  wire [3:0]                             axictl_wr_burst_len;
  wire [CXTMC_ITATBDATA0_WIDTH-1:0]      it_atb_data_0;
  wire                                   it_misc_op_0_wr_en;
  wire                                   it_atb_m_ctr_2_syncreqm;
  wire                                   it_atb_m_ctr_2_afvalidm;
  wire                                   it_atb_m_ctr_2_atreadym;
  wire                                   it_atb_m_data_0_wr_en;
  wire                                   it_atb_m_ctr_1_wr_en;
  wire                                   rrp_hi_wr_en;
  wire                                   rwp_hi_wr_en;
  wire                                   auth_status_dbgen;
  wire                                   auth_status_spiden;
  wire                                   af_ready_reg;
  wire                                   trigin_reg;
  wire                                   flushin_reg;
  wire                                   axictl_sg_mode;
  wire [3:0]                             axictl_cache_ctrl;
  wire [1:0]                             axictl_prot_ctrl;
  wire [31:0]                            dba_lo;
  wire [7:0]                             dba_hi;
  wire [4:0]                             pscr;
  wire                                   wb_empty;
  wire                                   tmc_abort;
  wire [6:0]                             atids_p1;
  wire                                   atvalids_p1;
  wire [(CXTMC_ATBYTES_WIDTH-1):0]       atbytess_p1;
  wire                                   ffcr_stop_on_trig_evt_masked;
  wire                                   ffcr_stop_on_fl;
  wire                                   ffcr_trig_on_fl_masked;
  wire                                   ffcr_trig_on_trig_evt_masked;
  wire                                   ffcr_trig_on_trigin_masked;
  wire                                   ffcr_flsh_on_trig_evt_masked;
  wire                                   ffcr_flsh_on_flshin;
  wire                                   ffcr_en_trig_ins;
  wire                                   ffcr_en_formatting_masked;
  wire                                   ft_flush_ack;
  wire                                   wb_flush_ack;
  wire                                   mem_flush_ack;
  wire                                   atbm_flush_valid;
  wire                                   ft_flush_req;
  wire                                   wb_flush_req;
  wire                                   mem_flush_req;
  wire                                   atbm_flush_ready;
  wire                                   fl_in_prog;
  wire                                   pscr_ctr_decr_pulse;
  wire                                   trg_ctr_decr_pulse;
  wire                                   pt_valid;
  wire [39:0]                            pt_addr;
  wire                                   sg_idle;
  wire                                   dba_w_valid;
  wire [27:0]                            dba_w_addr;
  wire                                   dba_w_last;
  wire                                   dba_r_valid;
  wire [27:0]                            dba_r_addr;
  wire                                   pt_ready;
  wire [27:0]                            pt_data_hi;
  wire [1:0]                             pt_data_lo;
  wire                                   dba_w_ready;
  wire                                   dba_r_ready;
  wire                                   tmc_ready;
  wire                                   axi_w_ch_beat_done;
  wire [CXTMC_WB_PTR_WIDTH:0]            wb_fill_level;
  wire                                   cxtmc_clk;
  wire                                   apb_addr31;
  wire [11:2]                            apb_addr;
  wire [31:0]                            apb_wdata;
  wire                                   pwritedbg_r;
  wire                                   apb_valid;
  wire                                   tmc_clk_req;
  wire [31:0]                            read_data;
  wire                                   apb_ready;
  wire                                   apb_err;
  wire                                   mem_wr;
  wire                                   dbgen_reg;
  wire                                   spiden_reg;
  wire                                   pseldbg_r;
  wire                                   axi_intf_pend;
  wire                                   csysreq_reg;
  wire                                   outstanding_wreq_cnt_eq0;

  // --------------------------------------------------------------------------
  // 
  // Main body of code
  // =================
  //
  // --------------------------------------------------------------------------
  // --------------------------------------------------------------------------
  // Configuration-specific tie-offs
  // --------------------------------------------------------------------------
  generate
    if (CXTMC_ATBM_AXIM_CFG == CXTMC_CFG_ETR)
      begin
        assign auth_status_dbgen   = DBGEN;
        assign auth_status_spiden  = SPIDEN;
      end
    else
      begin
        assign auth_status_dbgen   = 1'b0;
        assign auth_status_spiden  = 1'b0;
      end
  endgenerate
  generate
    if (CXTMC_ATBM_AXIM_CFG == CXTMC_CFG_ETF)
      begin
        assign it_atb_m_ctr_2_syncreqm = SYNCREQM;
        assign it_atb_m_ctr_2_afvalidm = AFVALIDM;
        assign it_atb_m_ctr_2_atreadym = ATREADYM;
      end
    else
      begin
        assign it_atb_m_ctr_2_syncreqm = 1'b0;
        assign it_atb_m_ctr_2_afvalidm = 1'b0;
        assign it_atb_m_ctr_2_atreadym = 1'b0;
      end
  endgenerate

  cxtmc_clk_module
  u_cxtmc_clk_module
  (
  .CLK                             (CLK),
  .tmc_clk_req                     (tmc_clk_req),
  .DFTTESTMODE                     (DFTTESTMODE),
  .DFTCLKDISABLE                   (DFTCLKDISABLE),
  .cxtmc_clk                       (cxtmc_clk)
  );

  cxtmc_apbslvif
  #(.CXTMC_ATBM_AXIM_CFG           (CXTMC_ATBM_AXIM_CFG)
   )
  u_cxtmc_apbslvif
  (
  // APB interface
  .CLK                             (CLK),
  .PCLKENDBG                       (PCLKENDBG),
  .RESETn                          (RESETn),
  .PSELDBG                         (PSELDBG),
  .PENABLEDBG                      (PENABLEDBG),
  .PWRITEDBG                       (PWRITEDBG),
  .PADDRDBG                        (PADDRDBG),
  .PADDRDBG31                      (PADDRDBG31),
  .PWDATADBG                       (PWDATADBG),
  .PREADYDBG                       (PREADYDBG),
  .PRDATADBG                       (PRDATADBG),
  .PSLVERRDBG                      (PSLVERRDBG),

  // Authentication interface
  .DBGEN                           (DBGEN),
  .SPIDEN                          (SPIDEN),

  // Low Power interface
  .CSYSREQ                         (CSYSREQ),
  .CSYSACK                         (CSYSACK),
  .CACTIVE                         (CACTIVE),

  .read_data                       (read_data),
  .apb_ready                       (apb_ready),
  .apb_err                         (apb_err),

  .axi_intf_pend                   (axi_intf_pend),
  .apb_valid                       (apb_valid),
  .apb_addr                        (apb_addr),
  .apb_addr31                      (apb_addr31),
  .apb_wdata                       (apb_wdata),
  .pseldbg_r                       (pseldbg_r),
  .pwritedbg_r                     (pwritedbg_r),
  .dbgen_reg                       (dbgen_reg),
  .spiden_reg                      (spiden_reg),
  .csysreq_reg                     (csysreq_reg)
  );

  cxtmc_regfile
  #(.CXTMC_ATBM_AXIM_CFG           (CXTMC_ATBM_AXIM_CFG),
    .CXTMC_MEM_SIZE                (CXTMC_MEM_SIZE),
    .CXTMC_WBUFFER_DEPTH           (CXTMC_WBUFFER_DEPTH),
    .CXTMC_WB_DATA_WIDTH           (CXTMC_WB_DATA_WIDTH),
    .CXTMC_AXI_DATA_WIDTH          (CXTMC_AXI_DATA_WIDTH),
    .CXTMC_MEM_BYTE_ADDR_WIDTH     (CXTMC_MEM_BYTE_ADDR_WIDTH),
    .CXTMC_TRG_WIDTH               (CXTMC_TRG_WIDTH),
    .CXTMC_ATBYTES_WIDTH           (CXTMC_ATBYTES_WIDTH),
    .CXTMC_ITATBDATA0_WIDTH        (CXTMC_ITATBDATA0_WIDTH),
    .CXTMC_FILL_LEVEL_WIDTH        (CXTMC_FILL_LEVEL_WIDTH)
   )
  u_cxtmc_regfile
  (
    .cxtmc_clk                     (cxtmc_clk),
    .RESETn                        (RESETn),
    .apb_addr31                    (apb_addr31),
    .apb_addr                      (apb_addr),
    .apb_wdata                     (apb_wdata),
    .pseldbg_r                     (pseldbg_r),
    .pwritedbg_r                   (pwritedbg_r),
    .apb_valid                     (apb_valid),

    .auth_status_dbgen             (auth_status_dbgen),
    .auth_status_spiden            (auth_status_spiden),
    .flushin_reg                   (flushin_reg),
    .trigin_reg                    (trigin_reg),
    .FULL                          (FULL),
    .ACQCOMP                       (ACQCOMP),
    .af_ready_reg                  (af_ready_reg),
    .atvalids_p1                   (atvalids_p1),
    .atbytess_p1                   (atbytess_p1),
    .atids_p1                      (atids_p1),
    .ft_stopped                    (ft_stopped),
    .flush_man_clr                 (flush_man_clr),
    .fl_in_prog                    (fl_in_prog),
    .trace_mem_empty               (trace_mem_empty),
    .wb_empty                      (wb_empty),
    .wb_ready                      (wb_ready),
    .unformatter_empty             (unformatter_empty),
    .triggered                     (triggered),
    .rrd                           (rrd),
    .rrd_rd_ack                    (rrd_rd_ack),
    .rrp                           (rrp),
    .rwp                           (rwp),
    .trg                           (trg),
    .lat_buf_level                 (lat_buf_level),
    .c_buf_level                   (c_buf_level),
    .mem_err                       (mem_err),
    .axi_intf_ready                (axi_intf_ready),
    .sg_idle                       (sg_idle),
    .tmc_clk_req                   (tmc_clk_req),
    .read_data                     (read_data),
    .apb_ready                     (apb_ready),
    .apb_err                       (apb_err),

    .rsz_masked                    (rsz_masked),
    .trg_wr_en                     (trg_wr_en),
    .rrp_wr_en                     (rrp_wr_en),
    .rrp_hi_wr_en                  (rrp_hi_wr_en),
    .rwp_wr_en                     (rwp_wr_en),
    .rwp_hi_wr_en                  (rwp_hi_wr_en),
    .rwd_wr_req                    (rwd_wr_req),
    .lat_buf_level_rd_done         (lat_buf_level_rd_done),
    .rrd_rd_req                    (rrd_rd_req),
    .ptr_clr                       (ptr_clr),
    .ctl_trace_capt_en_1_0         (ctl_trace_capt_en_1_0),
    .apbreadfifo_clr               (apbreadfifo_clr),
    .ffcr_flush_man                (ffcr_flush_man),
    .ffcr_stop_on_trig_evt_masked  (ffcr_stop_on_trig_evt_masked),
    .ffcr_stop_on_fl               (ffcr_stop_on_fl),
    .ffcr_trig_on_fl_masked        (ffcr_trig_on_fl_masked),
    .ffcr_trig_on_trig_evt_masked  (ffcr_trig_on_trig_evt_masked),
    .ffcr_trig_on_trigin_masked    (ffcr_trig_on_trigin_masked),
    .ffcr_flsh_on_trig_evt_masked  (ffcr_flsh_on_trig_evt_masked),
    .ffcr_flsh_on_flshin           (ffcr_flsh_on_flshin),
    .ffcr_en_trig_ins              (ffcr_en_trig_ins),
    .ffcr_en_formatting_masked     (ffcr_en_formatting_masked),
    .circ_buf_mode                 (circ_buf_mode),
    .sw_fifo_mode                  (sw_fifo_mode),
    .hw_fifo_mode                  (hw_fifo_mode),
    .mem_err_clr                   (mem_err_clr),
    .axictl_wr_burst_len           (axictl_wr_burst_len),
    .axictl_sg_mode                (axictl_sg_mode),
    .axictl_cache_ctrl             (axictl_cache_ctrl),
    .axictl_prot_ctrl              (axictl_prot_ctrl),
    .dba_lo                        (dba_lo),
    .dba_hi                        (dba_hi),
    .ctl_trace_capt_en             (ctl_trace_capt_en),
    .tmc_disabled                  (tmc_disabled),
    .tmc_abort                     (tmc_abort),
    .tmc_ready                     (tmc_ready),
    .pscr                          (pscr),
    .buf_wm                        (buf_wm),
    .unformatter_en                (unformatter_en),
    .unformatter_stop              (unformatter_stop),
    .it_ctrl                       (it_ctrl),
    .it_atb_m_data_0_wr_en         (it_atb_m_data_0_wr_en),
    .it_atb_m_ctr_1_wr_en          (it_atb_m_ctr_1_wr_en),
    .it_atb_m_ctr_0_wr_en          (it_atb_m_ctr_0_wr_en),
    .it_misc_op_0_wr_en            (it_misc_op_0_wr_en),
    .it_atb_ctr_2_wr_en            (it_atb_ctr_2_wr_en),
    .it_atb_data_0                 (it_atb_data_0),
    .it_atb_m_ctr_2_syncreqm       (it_atb_m_ctr_2_syncreqm),
    .it_atb_m_ctr_2_afvalidm       (it_atb_m_ctr_2_afvalidm),
    .it_atb_m_ctr_2_atreadym       (it_atb_m_ctr_2_atreadym)
    );

  cxtmc_wrbuffer
  #(.CXTMC_ATB_DATA_WIDTH          (CXTMC_ATB_DATA_WIDTH),
    .CXTMC_WBUFFER_DEPTH           (CXTMC_WBUFFER_DEPTH),
    .CXTMC_ATBM_AXIM_CFG           (CXTMC_ATBM_AXIM_CFG),
    .CXTMC_WB_PTR_WIDTH            (CXTMC_WB_PTR_WIDTH),
    .CXTMC_WB_DATA_WIDTH           (CXTMC_WB_DATA_WIDTH)
  )
  u_cxtmc_wrbuffer
  (
  .cxtmc_clk                        (cxtmc_clk),
  .RESETn                           (RESETn),
  .ft_data                          (ft_data),
  .apb_wdata                        (apb_wdata),
  .ft_data_valid                    (ft_data_valid),
  .rwd_wr_req                       (rwd_wr_req),
  .wb_req_ready                     (wb_req_ready),
  .wb_flush_req                     (wb_flush_req),
  .tmc_disabled                     (tmc_disabled),
  .ptr_clr                          (ptr_clr),

  .wb_empty                         (wb_empty),
  .wb_ready                         (wb_ready),
  .nxt_wb_ready                     (nxt_wb_ready),
  .wb_req_valid                     (wb_req_valid),
  .wb_fill_level                    (wb_fill_level),
  .wb_data                          (wb_data),
  .wb_flush_ack                     (wb_flush_ack)
  );

  // --------------------------------------------------------------------------
  // Formatter
  // --------------------------------------------------------------------------
  cxtmc_formatter
  #(
    .CXTMC_ATB_DATA_WIDTH      (CXTMC_ATB_DATA_WIDTH),
    .CXTMC_ATBYTES_WIDTH       (CXTMC_ATBYTES_WIDTH),
    .CXTMC_ITATBDATA0_WIDTH    (CXTMC_ITATBDATA0_WIDTH)
  )
  u_cxtmc_formatter
  (
    .cxtmc_clk                                (cxtmc_clk),
    .RESETn                                   (RESETn),
    .ATVALIDS                                 (ATVALIDS),
    .ATBYTESS                                 (ATBYTESS),
    .ATIDS                                    (ATIDS),
    .ATDATAS                                  (ATDATAS),
    .ffcr_en_formatting_masked                (ffcr_en_formatting_masked),
    .ctl_trace_capt_en_0_1                    (ctl_trace_capt_en_0_1),
    .wb_ready                                 (wb_ready),
    .nxt_wb_ready                             (nxt_wb_ready),
    .ft_trig_req                              (ft_trig_req),
    .ft_stop_req                              (ft_stop_req),
    .it_ctrl                                  (it_ctrl),
    .it_atb_ctr_2_wr_en                       (it_atb_ctr_2_wr_en),
    .apb_wdata                                (apb_wdata),
    .ft_flush_req                             (ft_flush_req),
    .ATREADYS                                 (ATREADYS),
    .ft_running_p0                            (ft_running_p0),
    .ft_data_valid                            (ft_data_valid),
    .ft_trig_ack                              (ft_trig_ack),
    .ft_stopped                               (ft_stopped),
    .ft_data                                  (ft_data),
    .trig_id_detect                           (trig_id_detect),
    .it_atb_data_0                            (it_atb_data_0),
    .atids_p1                                 (atids_p1),
    .atvalids_p1                              (atvalids_p1),
    .atbytess_p1                              (atbytess_p1),
    .ft_flush_ack                             (ft_flush_ack)
   );

  // --------------------------------------------------------------------------
  // Formatter Control logic
  // --------------------------------------------------------------------------
  cxtmc_format_control
  #(
    .CXTMC_TRG_WIDTH           (CXTMC_TRG_WIDTH),
    .CXTMC_ATBM_AXIM_CFG       (CXTMC_ATBM_AXIM_CFG),
    .CXTMC_ATB_DATA_WIDTH      (CXTMC_ATB_DATA_WIDTH)
  )
  u_cxtmc_format_control
  (
    .cxtmc_clk                                 (cxtmc_clk),
    .RESETn                                    (RESETn),
    .apb_wdata                                 (apb_wdata),
    .AFREADYS                                  (AFREADYS),
    .TRIGIN                                    (TRIGIN),
    .FLUSHIN                                   (FLUSHIN),
    .circ_buf_mode                             (circ_buf_mode),
    .ctl_trace_capt_en                         (ctl_trace_capt_en),
    .ffcr_stop_on_trig_evt_masked              (ffcr_stop_on_trig_evt_masked),
    .ffcr_stop_on_fl                           (ffcr_stop_on_fl),
    .ffcr_trig_on_fl_masked                    (ffcr_trig_on_fl_masked),
    .ffcr_trig_on_trig_evt_masked              (ffcr_trig_on_trig_evt_masked),
    .ffcr_trig_on_trigin_masked                (ffcr_trig_on_trigin_masked),
    .ffcr_flsh_on_trig_evt_masked              (ffcr_flsh_on_trig_evt_masked),
    .ffcr_flsh_on_flshin                       (ffcr_flsh_on_flshin),
    .ffcr_en_trig_ins                          (ffcr_en_trig_ins),
    .ffcr_flush_man                            (ffcr_flush_man),
    .trg_ctr_decr_pulse                        (trg_ctr_decr_pulse),
    .ft_stopped                                (ft_stopped),
    .ft_trig_ack                               (ft_trig_ack),
    .trig_id_detect                            (trig_id_detect),
    .trg_wr_en                                 (trg_wr_en),
    .it_ctrl                                   (it_ctrl),
    .it_atb_ctr_2_wr_en                        (it_atb_ctr_2_wr_en),
    .ft_flush_ack                              (ft_flush_ack),
    .wb_flush_ack                              (wb_flush_ack),
    .mem_flush_ack                             (mem_flush_ack),
    .sw_fifo_mode                              (sw_fifo_mode),
    .hw_fifo_mode                              (hw_fifo_mode),
    .atbm_flush_valid                          (atbm_flush_valid),
    .mem_err                                   (mem_err),
    .trace_mem_empty                           (trace_mem_empty),


    .AFVALIDS                                  (AFVALIDS),
    .af_ready_reg                              (af_ready_reg),
    .trigin_reg                                (trigin_reg),
    .flushin_reg                               (flushin_reg),
    .triggered                                 (triggered),
    .trg                                       (trg),
    .flush_man_clr                             (flush_man_clr),
    .ft_trig_req                               (ft_trig_req),
    .ft_stop_req                               (ft_stop_req),
    .ft_flush_req                              (ft_flush_req),
    .wb_flush_req                              (wb_flush_req),
    .mem_flush_req                             (mem_flush_req),
    .atbm_flush_ready                          (atbm_flush_ready),
    .ctl_trace_capt_en_0_1                     (ctl_trace_capt_en_0_1),
    .fl_in_prog                                (fl_in_prog)
  );

generate
  if ((CXTMC_ATBM_AXIM_CFG == CXTMC_CFG_ETB) ||
      (CXTMC_ATBM_AXIM_CFG == CXTMC_CFG_ETF))
   begin : u_cxtmc_memif_block
  // --------------------------------------------------------------------------
  // Memory interface (local SRAM interface)
  // --------------------------------------------------------------------------
  cxtmc_memif
  #(.CXTMC_ATBM_AXIM_CFG           (CXTMC_ATBM_AXIM_CFG),
    .CXTMC_MEM_SIZE                (CXTMC_MEM_SIZE),
    .CXTMC_ATB_DATA_WIDTH          (CXTMC_ATB_DATA_WIDTH),
    .CXTMC_MEM_ADDR_WIDTH          (CXTMC_MEM_ADDR_WIDTH),
    .CXTMC_MEM_BYTE_ADDR_WIDTH     (CXTMC_MEM_BYTE_ADDR_WIDTH),
    .CXTMC_WB_DATA_WIDTH           (CXTMC_WB_DATA_WIDTH),
    .CXTMC_FILL_LEVEL_WIDTH        (CXTMC_FILL_LEVEL_WIDTH)
   )
  u_cxtmc_memif
  (
    .cxtmc_clk                     (cxtmc_clk),
    .RESETn                        (RESETn),
    .MEMQ                          (MEMQ),
    .wb_data                       (wb_data),
    .wb_req_valid                  (wb_req_valid),
    .rb_req_valid                  (rb_req_valid),
    .rrp_wr_en                     (rrp_wr_en),
    .rwp_wr_en                     (rwp_wr_en),
    .apb_wdata                     (apb_wdata),
    .circ_buf_mode                 (circ_buf_mode),
    .unformatter_en                (unformatter_en),
    .unformatter_empty             (unformatter_empty),
    .apb_read_fifo_rrp_en          (apb_read_fifo_rrp_en),
    .ptr_clr                       (ptr_clr),
    .ctl_trace_capt_en_1_0         (ctl_trace_capt_en_1_0),
    .ctl_trace_capt_en             (ctl_trace_capt_en),
    .tmc_disabled                  (tmc_disabled),
    .tmc_abort                     (tmc_abort),
    .lat_buf_level_rd_done         (lat_buf_level_rd_done),
    .buf_wm                        (buf_wm),
    .it_misc_op_0_wr_en            (it_misc_op_0_wr_en),
    .it_ctrl                       (it_ctrl),
    .mem_flush_req                 (mem_flush_req),

    .MEMCEN                        (MEMCEN),
    .MEMWEN                        (MEMWEN),
    .MEMADDR                       (MEMADDR),
    .MEMD                          (MEMD),
    .rb_data                       (rb_data),
    .rb_rdata_valid                (rb_rdata_valid),
    .wb_req_ready                  (wb_req_ready),
    .rb_req_ready                  (rb_req_ready),
    .rrp                           (rrp),
    .rwp                           (rwp),
    .lat_buf_level                 (lat_buf_level),
    .c_buf_level                   (c_buf_level),
    .trace_mem_empty               (trace_mem_empty),
    .FULL                          (FULL),
    .mem_flush_ack                 (mem_flush_ack),
    .mem_wr                        (mem_wr)
  );
   end
endgenerate

generate
  if (CXTMC_ATBM_AXIM_CFG == CXTMC_CFG_ETR)
    begin : u_cxtmc_axi_if_block

      cxtmc_axi_if
      #(
        .CXTMC_AXI_DATA_WIDTH      (CXTMC_AXI_DATA_WIDTH),
        .CXTMC_MEM_ADDR_WIDTH      (CXTMC_MEM_ADDR_WIDTH),
        .CXTMC_MEM_BYTE_ADDR_WIDTH (CXTMC_MEM_BYTE_ADDR_WIDTH),
        .CXTMC_WBUFFER_DEPTH       (CXTMC_WBUFFER_DEPTH),
        .CXTMC_WB_DATA_WIDTH       (CXTMC_WB_DATA_WIDTH),
        .CXTMC_FILL_LEVEL_WIDTH    (CXTMC_FILL_LEVEL_WIDTH),
        .CXTMC_WB_PTR_WIDTH        (CXTMC_WB_PTR_WIDTH)
      )
      u_cxtmc_axi_if
      (
        // Clock
        .cxtmc_clk                    (cxtmc_clk),

        // Reset
        .RESETn                       (RESETn),

        // AR Channel
        .ARREADYM                     (ARREADYM),
        .ARADDRM                      (ARADDRM),
        .ARLENM                       (ARLENM),
        .ARSIZEM                      (ARSIZEM),
        .ARBURSTM                     (ARBURSTM),
        .ARLOCKM                      (ARLOCKM),
        .ARCACHEM                     (ARCACHEM),
        .ARPROTM                      (ARPROTM),
        .ARVALIDM                     (ARVALIDM),

        // R Channel
        .RDATAM                       (RDATAM),
        .RRESPM                       (RRESPM),
        .RLASTM                       (RLASTM),
        .RVALIDM                      (RVALIDM),
        .RREADYM                      (RREADYM),

        // AW Channel
        .AWREADYM                     (AWREADYM),
        .AWADDRM                      (AWADDRM),
        .AWLENM                       (AWLENM),
        .AWSIZEM                      (AWSIZEM),
        .AWBURSTM                     (AWBURSTM),
        .AWLOCKM                      (AWLOCKM),
        .AWCACHEM                     (AWCACHEM),
        .AWPROTM                      (AWPROTM),
        .AWVALIDM                     (AWVALIDM),

        // W Channel
        .WREADYM                      (WREADYM),
        .WDATAM                       (WDATAM),
        .WSTRBM                       (WSTRBM),
        .WLASTM                       (WLASTM),
        .WVALIDM                      (WVALIDM),

        // B Channel
        .BRESPM                        (BRESPM),
        .BVALIDM                       (BVALIDM),
        .BREADYM                       (BREADYM),

        // Authentication Interface
        .dbgen_reg                     (dbgen_reg),
        .spiden_reg                    (spiden_reg),

        .wb_data                       (wb_data),
        .wb_req_valid                  (wb_req_valid),
        .wb_flush_req                  (wb_flush_req),
        .wb_flush_ack                  (wb_flush_ack),
        .ft_stopped                    (ft_stopped),
        .wb_fill_level                 (wb_fill_level),
        .rb_req_valid                  (rb_req_valid),
        .rrp_wr_en                     (rrp_wr_en),
        .rrp_hi_wr_en                  (rrp_hi_wr_en),
        .rwp_wr_en                     (rwp_wr_en),
        .rwp_hi_wr_en                  (rwp_hi_wr_en),
        .apb_wdata                     (apb_wdata),
        .circ_buf_mode                 (circ_buf_mode),
        .apb_read_fifo_rrp_en          (apb_read_fifo_rrp_en),
        .ptr_clr                       (ptr_clr),
        .ctl_trace_capt_en_1_0         (ctl_trace_capt_en_1_0),
        .ctl_trace_capt_en             (ctl_trace_capt_en),
        .tmc_disabled                  (tmc_disabled),
        .tmc_abort                     (tmc_abort),
        .lat_buf_level_rd_done         (lat_buf_level_rd_done),
        .buf_wm                        (buf_wm),
        .it_misc_op_0_wr_en            (it_misc_op_0_wr_en),
        .it_ctrl                       (it_ctrl),
        .mem_flush_req                 (mem_flush_req),
        .rsz_masked                    (rsz_masked),
        .axictl_wr_burst_len           (axictl_wr_burst_len),
        .axictl_sg_mode                (axictl_sg_mode),
        .axictl_cache_ctrl             (axictl_cache_ctrl),
        .axictl_prot_ctrl              (axictl_prot_ctrl),
        .dba_lo                        (dba_lo),
        .dba_hi                        (dba_hi),
        .mem_err_clr                   (mem_err_clr),
        .mem_err_pt                    (mem_err_pt),
        .pt_valid                      (pt_valid),
        .pt_addr                       (pt_addr),
        .dba_w_valid                   (dba_w_valid),
        .dba_w_addr                    (dba_w_addr),
        .dba_w_last                    (dba_w_last),
        .dba_r_valid                   (dba_r_valid),
        .dba_r_addr                    (dba_r_addr),
        .csysreq_reg                   (csysreq_reg),
        .CSYSACK                       (CSYSACK),
        .rb_data                       (rb_data),
        .rb_rdata_valid                (rb_rdata_valid),
        .wb_req_ready                  (wb_req_ready),
        .rb_req_ready                  (rb_req_ready),
        .rrp                           (rrp),
        .rwp                           (rwp),
        .lat_buf_level                 (lat_buf_level),
        .c_buf_level                   (c_buf_level),
        .trace_mem_empty               (trace_mem_empty),
        .FULL                          (FULL),
        .mem_flush_ack                 (mem_flush_ack),
        .mem_err                       (mem_err),
        .axi_intf_ready                (axi_intf_ready),
        .pt_ready                      (pt_ready),
        .pt_data_hi                    (pt_data_hi),
        .pt_data_lo                    (pt_data_lo),
        .dba_w_ready                   (dba_w_ready),
        .dba_r_ready                   (dba_r_ready),
        .axi_w_ch_beat_done            (axi_w_ch_beat_done),
        .axi_intf_pend                 (axi_intf_pend),
        .outstanding_wreq_cnt_eq0      (outstanding_wreq_cnt_eq0)
  );
    end
  else
    begin
      assign axi_intf_ready = 1'b1;
      assign mem_err        = 1'b0;
      assign axi_intf_pend  = 1'b0;
    end
endgenerate

generate
  if (CXTMC_ATBM_AXIM_CFG == CXTMC_CFG_ETR)
    begin : u_cxtmc_etr_sg_block
  // --------------------------------------------------------------------------
  // Scatter Gather Block
  // --------------------------------------------------------------------------
    cxtmc_etr_sg
       u_cxtmc_etr_sg (
                       .cxtmc_clk             (cxtmc_clk),
                       .RESETn                (RESETn),
                       .axictl_sg_mode        (axictl_sg_mode),
                       .ctl_trace_capt_en     (ctl_trace_capt_en),
                       .ctl_trace_capt_en_0_1 (ctl_trace_capt_en_0_1),
                       .tmc_ready             (tmc_ready),
                       .mem_err               (mem_err),
                       .dba_lo                (dba_lo),
                       .dba_hi                (dba_hi),
                       .dba_w_ready           (dba_w_ready),
                       .dba_r_ready           (dba_r_ready),
                       .pt_ready              (pt_ready),
                       .pt_data_hi            (pt_data_hi),
                       .pt_data_lo            (pt_data_lo),
                       .mem_err_pt            (mem_err_pt),
                       .dba_w_valid           (dba_w_valid),
                       .dba_r_valid           (dba_r_valid),
                       .dba_w_addr            (dba_w_addr),
                       .dba_w_last            (dba_w_last),
                       .dba_r_addr            (dba_r_addr),
                       .pt_addr               (pt_addr),
                       .sg_idle               (sg_idle),
                       .pt_valid              (pt_valid)
                      );
    end
  else
    begin
      assign sg_idle = 1'b0;
    end
endgenerate

generate
  if ((CXTMC_ATBM_AXIM_CFG == CXTMC_CFG_ETB) ||
      (CXTMC_ATBM_AXIM_CFG == CXTMC_CFG_ETR))
  // --------------------------------------------------------------------------
  // APB Read FIFO
  // --------------------------------------------------------------------------
  cxtmc_apbreadfifo
  #(
    .CXTMC_ATBM_AXIM_CFG           (CXTMC_ATBM_AXIM_CFG),
    .CXTMC_ATB_DATA_WIDTH          (CXTMC_ATB_DATA_WIDTH),
    .CXTMC_WB_DATA_WIDTH           (CXTMC_WB_DATA_WIDTH)
  )
  u_cxtmc_apbreadfifo
  (
  .cxtmc_clk            (cxtmc_clk),
  .RESETn               (RESETn),
  .rb_req_ready         (rb_req_ready),
  .rb_rdata_valid       (rb_rdata_valid),
  .rb_data              (rb_data),
  .rrd_rd_req           (rrd_rd_req),
  .apbreadfifo_clr      (apbreadfifo_clr),

  .apb_read_fifo_rrp_en (apb_read_fifo_rrp_en),
  .rb_req_valid         (rb_req_valid),
  .rrd_rd_ack           (rrd_rd_ack),
  .rrd                  (rrd)
  );
endgenerate

generate
  if (CXTMC_ATBM_AXIM_CFG == CXTMC_CFG_ETF)
  begin : u_cxtmc_unformatter_block
  // --------------------------------------------------------------------------
  // Unformatter
  // --------------------------------------------------------------------------
  cxtmc_unformatter
  #(
    .CXTMC_ATB_DATA_WIDTH (CXTMC_ATB_DATA_WIDTH),
    .CXTMC_ATBYTES_WIDTH  (CXTMC_ATBYTES_WIDTH)
  )
  u_cxtmc_unformatter
  (
   .cxtmc_clk             (cxtmc_clk),
   .RESETn                (RESETn),
   .rb_req_ready          (rb_req_ready),
   .rb_rdata_valid        (rb_rdata_valid),
   .rb_data               (rb_data),
   .ATREADYM              (ATREADYM),
   .AFVALIDM              (AFVALIDM),
   .atbm_flush_ready      (atbm_flush_ready),
   .unformatter_en        (unformatter_en),
   .apbreadfifo_clr       (apbreadfifo_clr),
   .unformatter_stop      (unformatter_stop),
   .hw_fifo_mode          (hw_fifo_mode),
   .rrd_rd_req            (rrd_rd_req),
   .it_ctrl               (it_ctrl),
   .it_atb_m_ctr_0_wr_en  (it_atb_m_ctr_0_wr_en),
   .it_atb_m_ctr_1_wr_en  (it_atb_m_ctr_1_wr_en),
   .it_atb_m_data_0_wr_en (it_atb_m_data_0_wr_en),
   .apb_wdata_16to0       (apb_wdata[16:0]),

   .rb_req_valid          (rb_req_valid),
   .apb_read_fifo_rrp_en  (apb_read_fifo_rrp_en),
   .unformatter_empty     (unformatter_empty),
   .rrd_rd_ack            (rrd_rd_ack),
   .rrd                   (rrd),
   .ATVALIDM              (ATVALIDM),
   .ATIDM                 (ATIDM),
   .ATBYTESM              (ATBYTESM),
   .ATDATAM               (ATDATAM),
   .atbm_flush_valid      (atbm_flush_valid),
   .AFREADYM              (AFREADYM)
  );
   end
  else begin
    assign unformatter_empty = 1'b1;
    assign atbm_flush_valid  = 1'b0;
  end
endgenerate

generate
  if (CXTMC_ATBM_AXIM_CFG == CXTMC_CFG_ETR)
    begin
      assign pscr_ctr_decr_pulse = axi_w_ch_beat_done;
      assign trg_ctr_decr_pulse = axi_w_ch_beat_done;
    end
  else
    begin
      assign pscr_ctr_decr_pulse = mem_wr;
      assign trg_ctr_decr_pulse = ft_data_valid;
    end
endgenerate


  // --------------------------------------------------------------------------
  // ATB Synchronisation request generator
  // --------------------------------------------------------------------------

  cxtmc_sync_req
  #(
    .CXTMC_ATB_DATA_WIDTH (CXTMC_ATB_DATA_WIDTH),
    .CXTMC_ATBM_AXIM_CFG  (CXTMC_ATBM_AXIM_CFG))
   u_cxtmc_sync_req
  (
   .cxtmc_clk             (cxtmc_clk),
   .RESETn                (RESETn),
   .it_ctrl               (it_ctrl),
   .it_atb_ctr_2_wr_en    (it_atb_ctr_2_wr_en),
   .apb_wdata_bit2        (apb_wdata[2]),
   .SYNCREQM              (SYNCREQM),
   .pscr                  (pscr),
   .pscr_ctr_decr_pulse   (pscr_ctr_decr_pulse),
   .ctl_trace_capt_en     (ctl_trace_capt_en),
   .ctl_trace_capt_en_0_1 (ctl_trace_capt_en_0_1),
   .ft_running_p0         (ft_running_p0),
   .SYNCREQS              (SYNCREQS)
  );

`ifdef ARM_ASSERT_ON
//-----------------------------------------------------------------------------
// OVL Assertions
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
// Check for legal values of CXTMC_ATBM_AXIM_CFG parameter
//-----------------------------------------------------------------------------
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxtmc - Value of parameter CXTMC_ATBM_AXIM_CFG is illegal")
      uzovl_cxtmc_param_chk_atbm_axim_cfg
        (
         .clk         (CLK),
         .reset_n     (RESETn),
         .test_expr   ((CXTMC_ATBM_AXIM_CFG != CXTMC_CFG_ETB) &amp;&amp;
                       (CXTMC_ATBM_AXIM_CFG != CXTMC_CFG_ETR) &amp;&amp;
                       (CXTMC_ATBM_AXIM_CFG != CXTMC_CFG_ETF))
        );

//-----------------------------------------------------------------------------
// Check for legal values of CXTMC_WBUFFER_DEPTH parameter
// ETB/ETF configurations - 1
// ETR configuration - 4, 8, 16 and 32
//-----------------------------------------------------------------------------
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxtmc - Illegal combination of parameters CXTMC_ATBM_AXIM_CFG and CXTMC_WBUFFER_DEPTH")
      uzovl_cxtmc_param_chk_wbuf
        (
         .clk         (CLK),
         .reset_n     (RESETn),
         .test_expr   (((CXTMC_ATBM_AXIM_CFG == CXTMC_CFG_ETR) &amp;&amp;
                        (CXTMC_WBUFFER_DEPTH != 4) &amp;&amp;
                        (CXTMC_WBUFFER_DEPTH != 8) &amp;&amp;
                        (CXTMC_WBUFFER_DEPTH != 16) &amp;&amp;
                        (CXTMC_WBUFFER_DEPTH != 32)) ||
                       ((CXTMC_ATBM_AXIM_CFG != CXTMC_CFG_ETR) &amp;&amp;
                        (CXTMC_WBUFFER_DEPTH != 1)))
        );

generate
  if (CXTMC_ATBM_AXIM_CFG != CXTMC_CFG_ETR)
//-----------------------------------------------------------------------------
// Check for legal values of CXTMC_MEM_SIZE parameter in ETB/ETF configurations
//-----------------------------------------------------------------------------
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxtmc - Illegal value for parameter CXTMC_ATBM_AXIM_CFG")
      uzovl_cxtmc_param_chk_mem_size
        (
         .clk         (CLK),
         .reset_n     (RESETn),
         .test_expr   (((CXTMC_ATBM_AXIM_CFG == CXTMC_CFG_ETB) ||
                        (CXTMC_ATBM_AXIM_CFG == CXTMC_CFG_ETF)) &amp;&amp;
                       ((CXTMC_MEM_SIZE != 31'h00000080) &amp;&amp;
                        (CXTMC_MEM_SIZE != 31'h00000100) &amp;&amp;
                        (CXTMC_MEM_SIZE != 31'h00000200) &amp;&amp;
                        (CXTMC_MEM_SIZE != 31'h00000400) &amp;&amp;
                        (CXTMC_MEM_SIZE != 31'h00000800) &amp;&amp;
                        (CXTMC_MEM_SIZE != 31'h00001000) &amp;&amp;
                        (CXTMC_MEM_SIZE != 31'h00002000) &amp;&amp;
                        (CXTMC_MEM_SIZE != 31'h00004000) &amp;&amp;
                        (CXTMC_MEM_SIZE != 31'h00008000) &amp;&amp;
                        (CXTMC_MEM_SIZE != 31'h00010000) &amp;&amp;
                        (CXTMC_MEM_SIZE != 31'h00020000) &amp;&amp;
                        (CXTMC_MEM_SIZE != 31'h00040000) &amp;&amp;
                        (CXTMC_MEM_SIZE != 31'h00080000) &amp;&amp;
                        (CXTMC_MEM_SIZE != 31'h00100000) &amp;&amp;
                        (CXTMC_MEM_SIZE != 31'h00200000) &amp;&amp;
                        (CXTMC_MEM_SIZE != 31'h00400000) &amp;&amp;
                        (CXTMC_MEM_SIZE != 31'h00800000) &amp;&amp;
                        (CXTMC_MEM_SIZE != 31'h01000000) &amp;&amp;
                        (CXTMC_MEM_SIZE != 31'h02000000) &amp;&amp;
                        (CXTMC_MEM_SIZE != 31'h04000000) &amp;&amp;
                        (CXTMC_MEM_SIZE != 31'h08000000) &amp;&amp;
                        (CXTMC_MEM_SIZE != 31'h10000000) &amp;&amp;
                        (CXTMC_MEM_SIZE != 31'h20000000) &amp;&amp;
                        (CXTMC_MEM_SIZE != 31'h40000000)))
        );

endgenerate

//-----------------------------------------------------------------------------
// Check for legal values of CXTMC_ATB_DATA_WIDTH parameter
// Valid values: 32, 64 and 128
//-----------------------------------------------------------------------------
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxtmc - Illegal value for parameter CXTMC_ATB_DATA_WIDTH")
      uzovl_cxtmc_param_chk_atb_data_width
        (
         .clk         (CLK),
         .reset_n     (RESETn),
         .test_expr   ((CXTMC_ATB_DATA_WIDTH != 32) &amp;&amp;
                       (CXTMC_ATB_DATA_WIDTH != 64) &amp;&amp;
                       (CXTMC_ATB_DATA_WIDTH != 128))
        );

//-----------------------------------------------------------------------------
// When the TMC is disabled, RWD writes that access the trace memory (ie. the
// last of the multiple RWD writes required to make a full data word that
// matches the width of the AXI data bus) must be completed on the APB
// only after the corresponding AXI write has received a response on the
// B Channel.
//-----------------------------------------------------------------------------

// Check for last of the required number of RWD writes to make a full AXI 
// data word
wire assert_wrbuffer_apb_wren_msb;

// Check for the first of the required number of RWD writes to make a full AXI
// data word
wire assert_wrbuffer_apb_wren_0;

generate
  if (CXTMC_WB_DATA_WIDTH == 32)
    begin
      assign assert_wrbuffer_apb_wren_msb = 1'b1;
      assign assert_wrbuffer_apb_wren_0 = 1'b1;
    end
  else // CXTMC_WB_DATA_WIDTH != 32
    begin
      localparam WB_APB_WIDTH_RATIO = CXTMC_WB_DATA_WIDTH/32;
      assign assert_wrbuffer_apb_wren_msb = 
               u_cxtmc_wrbuffer.apb_wren[WB_APB_WIDTH_RATIO-1];
      assign assert_wrbuffer_apb_wren_0 = u_cxtmc_wrbuffer.apb_wren[0];
    end
endgenerate

generate
  if ((CXTMC_ATBM_AXIM_CFG == CXTMC_CFG_ETR) &amp;&amp;
      (CXTMC_WB_DATA_WIDTH != 32))
    begin
      wire nxt_last_wr_in_prog; // D-input of last_wr_in_prog
      reg  last_wr_in_prog;     // Last of the required number of APB writes
                                //  in progress. This signal is cleared when the
                                //  BVALIDM for this access is detected. 

      assign nxt_last_wr_in_prog = (tmc_disabled &amp;&amp;
               assert_wrbuffer_apb_wren_msb &amp;&amp;
               rwd_wr_req &amp;&amp; ~mem_err) |
               (last_wr_in_prog &amp;&amp; (~(BVALIDM | mem_err)));

      always @(posedge cxtmc_clk or negedge RESETn)
        begin : p_last_wr_in_prog
          if (!RESETn)
            last_wr_in_prog &lt;= 1&#39;b0;
          else
            last_wr_in_prog &lt;= nxt_last_wr_in_prog;
        end // p_last_wr_in_prog

  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxtmc - RWD writes when the TMC is disabled must be completed on the APB only after a response has been received on the B Channel.")
      uzovl_cxtmc_rwd_bvalid_chk_00
        (
         .clk         (CLK),
         .reset_n     (RESETn),
         .test_expr   (tmc_disabled &amp;&amp; 
                     assert_wrbuffer_apb_wren_msb &amp;&amp; 
                     last_wr_in_prog &amp;&amp; PREADYDBG)
        );

  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxtmc - When the TMC is disabled and the first of multiple RWD writes to make an AXI data word is initiated, there must be no AXI writes to which responses are outstanding on the B Channel.")
      uzovl_cxtmc_rwd_bvalid_chk_01
        (
         .clk         (CLK),
         .reset_n     (RESETn),
         .test_expr   (tmc_disabled &amp;&amp;
                       assert_wrbuffer_apb_wren_0 &amp;&amp; 
                       rwd_wr_req &amp;&amp; 
                       ~outstanding_wreq_cnt_eq0)
        );

    end
endgenerate

`endif // ARM_ASSERT_ON

endmodule // CXTMC
