// --------------------------------------------------------------------------
//  The confidential and proprietary information contained in this file may
//  only be used by a person authorised under and to the extent permitted
//  by a subsisting licensing agreement from ARM Limited.
//
//                (C) COPYRIGHT 2004-2015 ARM Limited.
//                    ALL RIGHTS RESERVED
//
//  This entire notice must be reproduced on all copies of this file
//  and copies of this file may only be made by a person if such person is
//  permitted to do so under the terms of a subsisting license agreement
//  from ARM Limited.
//
//    Checked In : $Date: 2014-08-14 16:01:35 +0100 (Thu, 14 Aug 2014) $
//    Revision   : $Revision: 39945 $
//    Release    : CoreSight-SoC-TM100-r3p2-00rel0
// ----------------------------------------------------------------------------
//  Purpose : DAP SW-DP dbgclk Synchronisers
// ----------------------------------------------------------------------------

module cxdapswjdp_sw_dp_sync
  (
   //Inputs
   dbgresetn, dbgclk,
   busack, cdbgpwrupack, csyspwrupack, cdbgrstack,

   //Outputs
   busack_t, cdbgpwrupack_s, csyspwrupack_s, cdbgrstack_s
   );

// --------------------------------------------------------------------------
// Port Definitions
// --------------------------------------------------------------------------
  input         dbgresetn;      // synchroniser reset
  input         dbgclk;         // synchroniser clock
  input         busack;         // synchroniser input
  input         cdbgpwrupack;   // synchroniser input
  input         csyspwrupack;   // synchroniser input
  input         cdbgrstack;     // synchroniser input

  output        busack_t;        // synchroniser output
  output        cdbgpwrupack_s;  // synchroniser output
  output        csyspwrupack_s;  // synchroniser output
  output        cdbgrstack_s;    // synchroniser output

// ----------------------------------------------------------------------------
// Variable definitions
// ----------------------------------------------------------------------------
  wire busack_corrupt;
  wire cdbgpwrupack_corrupt;
  wire csyspwrupack_corrupt;
  wire cdbgrstack_corrupt;

// ----------------------------------------------------------------------------
// Corrupters
// ----------------------------------------------------------------------------

`ifdef ARM_CDC_CHECK
  // Test component to corrupt busack going into synchroniser
  cx_cdc_corrupt_gry u_cdc_corrupt_busack (
      .clk    (dbgclk),
      .resetn (dbgresetn),
      .sync   (1'b0),
      .d_async(busack),
      .q_async(busack_corrupt)
    );

  // Test component to corrupt cdbgpwrupack going into synchroniser
  cx_cdc_corrupt_gry u_cdc_corrupt_cdbgpwrupack (
      .clk    (dbgclk),
      .resetn (dbgresetn),
      .sync   (1'b0),
      .d_async(cdbgpwrupack),
      .q_async(cdbgpwrupack_corrupt)
    );

  // Test component to corrupt csyspwrupack going into synchroniser
  cx_cdc_corrupt_gry u_cdc_corrupt_csyspwrupack (
      .clk    (dbgclk),
      .resetn (dbgresetn),
      .sync   (1'b0),
      .d_async(csyspwrupack),
      .q_async(csyspwrupack_corrupt)
    );

  // Test component to corrupt cdbgrstack going into synchroniser
  cx_cdc_corrupt_gry u_cdc_corrupt_cdbgrstack (
      .clk    (dbgclk),
      .resetn (dbgresetn),
      .sync   (1'b0),
      .d_async(cdbgrstack),
      .q_async(cdbgrstack_corrupt)
    );
`else
  assign busack_corrupt       = busack;
  assign cdbgpwrupack_corrupt = cdbgpwrupack;
  assign csyspwrupack_corrupt = csyspwrupack;
  assign cdbgrstack_corrupt   = cdbgrstack;
`endif


// --------------------------------------------------------------------------
// synchronisers
// --------------------------------------------------------------------------

  cx_sync  u_sync_bus_ack
   (
    .resetn       (dbgresetn),
    .clk          (dbgclk),
    .sync_di      (busack_corrupt),

    .sync_do      (busack_t)
   );


  cx_sync  u_cdbgpwrupack
   (
    .resetn       (dbgresetn),
    .clk          (dbgclk),
    .sync_di      (cdbgpwrupack_corrupt),

    .sync_do      (cdbgpwrupack_s)
   );


  cx_sync  u_csyspwrupack
   (
    .resetn       (dbgresetn),
    .clk          (dbgclk),
    .sync_di      (csyspwrupack_corrupt),

    .sync_do      (csyspwrupack_s)
   );


  cx_sync  u_cdbgrstack
   (
    .resetn       (dbgresetn),
    .clk          (dbgclk),
    .sync_di      (cdbgrstack_corrupt),

    .sync_do      (cdbgrstack_s)
   );

endmodule
