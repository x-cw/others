/* GP_FIFO_CTL.V - Copyright (C) 2008 Immediasemi Corp.
  Revision history:                                                                              100
    04/18/2008 John Iler        original
    
  General purpose parameterizable sync and async fifo.
    
  ?? modify valid entry, aempty, afull output by gp_fifo_out_ctl
*/
`include "../general/general.vh"

module gp_fifo_ctl (rd_reset_n, rd_clk, rd_en, wr_reset_n, wr_clk, wr_en, 
  afull, aempty, empty, full, rd_addr, valid_entries, wr_addr);
  /* General purpose parameterized feature fifo.  Handles sync/async on read/write ports. 
    Will work with any relative read/write port clock speeds.  This controller must be paired
    with a synchronous 2 port RAM.  The RAM and this controller must be connected as follows.
    
                    WR_SYNC=1 ->   wr_clk    wr_en
                    WR_SYNC=0 ->   wr_str_n     1
                                      |         |
                   +-------------+    |         |   +----------+
                   | gp_fifo_ctl |    |         |   | sync RAM |
                   |             |    |         |   |          |
            afull<-|       wr_clk|<---+------------>|wr_clk    |
             full<-|        wr_en|<-------------+-->|wr_en     |<-data_in
           aempty<-|      wr_addr|----------------->|wr_addr   |
            empty<-|             |                  |          |
    valid_entries<-|      rd_addr|----------------->|rd_addr   |
                   |        rd_en|<-------------+-->|rd_en     |->data_out
            reset->|       rd_clk|<---+------------>|rd_clk    |
                   |             |    |         |   |          |
                   +-------------+    |         |   +----------+
                                      |         |
                     RD_SYNC=1 ->   rd_clk    rd_en
                     RD_SYNC=0 ->  rd_str_n     1
  */
  parameter LOG2WORDS = 0; // log base 2 of number of entries = # address bits
  parameter WR_SYNC = 1;   // 1: write port is synchronous, 0: asynchronous
  `define WORDS (2**LOG2WORDS)     // number of fifo entries
  parameter AFULL_THRESH = `WORDS; // min # of valid entries that triggers 'almost full' flag
  parameter RD_SYNC = 1;          // 1: read port is synchronous, 0: asynchronous
  parameter AEMPTY_THRESH = 0;    // max # of valid entries that triggers 'almost empty' flag
  parameter SAME_SYNC = (RD_SYNC && WR_SYNC); 
    // 1: if WR_SYNC and RD_SYNC, indicates wr_clk is same as rd_clk, 0: separate rd/wr clks
  parameter FULL_FLOP = 0 ;
  parameter VALID_ENTRIES_SYNC_RD_CLK = 0; // 0=valid_entries sync to wr_clk, 1=sync to rd_clk
  
  input wire rd_reset_n;
  input wire wr_reset_n;
  
  input wire wr_clk;                   // write port clock or async strobe_n
  input wire wr_en;                    // if WR_SYNC indicates valid 'wr_data', else ignored
  output reg [LOG2WORDS-1:0] wr_addr;  // write address for fifo RAM
  output wire full;                    // fifo is full (WORDS entries if SAME_SYNC, else WORDS-1)
  output wire afull;                   // almost full - fifo has has >= AFULL_THRESH valid entries
  
  input wire rd_clk;                   // read port clock or async strobe_n
  input wire rd_en;                    // if RD_SYNC reading on 'rd_data' this rd_clk, else ignored
  output reg [LOG2WORDS-1:0] rd_addr;  // read address for fifo RAM
  output wire empty;                   // fifo has no valid entries
  output wire aempty;                  // almost empty - fifo has <= AEMPTY_THRESH valid entries

  output wire [LOG2WORDS:0] valid_entries; // number of filled entries (extra bit to get up to totally full size)

  `include "../general/misc.vh"   // gray code conversion functions

  function [31:0] gray_code_inc(
    input reg [31:0] gray_in, // number to be incremented
    input integer num_bits    // number of bits actually being used in gray_in (and output)
    );
    /* Gray code incrementer.  Returns next gray code after input.  For a description of gray code
    math operations see:
      http://www.cs.auckland.ac.nz/CDMTCS//researchreports/304bob.pdf
    Gray code is used so transfers for rd/wr pointers between clock domains will not produce
    erroneous values due to bit skew.  It is better to count in gray code rather than count in
    binary and convert to gray code.  If do the later, then must register after conversion to avoid
    glitches.

    Incrementing theory:
    To generate gray code, start with all 0's.  At each number, increment the least significant bit
      that will lead to a new number.
    
    G = gray code number
    P = Gn xor Gn-1 xor ... G0  parity of gray code number (1=odd, 0=even)
    i = bit number
    C1   = Gi-1                                 for i=1
    Ci   = Gi-1 and (not Gi-2) and ... (not G0) for i>1 and not == msb
    Cmsb =          (not Gi-2) and ... (not G0) for i=msb  (is incorrectly same as Ci in 304bob.pdf)
    let S = G+1
    S0 = P xnor G0
    Si = (P and Ci) xor Gi  for i>0  (is incorrectly given as P xor Ci xor Gi in 304bob.pdf)
    
    In general, the next bit to switch (s) is:
      if P=0, s=0
      if P=1, s such that Cs=1 and Ci=0 for i<s (in practice, only one Ci=1 anyway)
    */
    reg parity;
    reg [31:0] grayp1; // incremented value (gray plus 1)
    reg carry;         // Ci from above
    reg low_bits_zero; // same as ~| gray_in[bit-2:0] (which does not compile since nonconstant)
    integer bit_iter;
    
    begin
      parity = ^gray_in; 
      grayp1 = 0;
      low_bits_zero = 1;
      // Move [0] outside of loop to prevent bogus negative index warning from Xilinx synthesis
      // Also special case for single bit (always toggle)
      grayp1[0] = ((num_bits == 1) ? 0 : parity) ~^ gray_in[0];
      for (bit_iter = 1; bit_iter < num_bits; bit_iter = bit_iter + 1) begin
        // create carry (Ci from above)
        if (bit_iter == (num_bits - 1)) carry =                        low_bits_zero;
        else                            carry = gray_in[bit_iter-1] && low_bits_zero;
        grayp1[bit_iter] = (parity && carry) ^ gray_in[bit_iter];
        low_bits_zero    = low_bits_zero & !gray_in[bit_iter-1];
      end

      gray_code_inc = grayp1;    
    end
  endfunction // gray_code_inc

  // write pointer
  wire [LOG2WORDS-1:0] wr_addr_p1 = gray_code_inc(wr_addr, LOG2WORDS); // next address to write
  always @(posedge wr_clk, negedge wr_reset_n) begin
    if (!wr_reset_n)  wr_addr <= 0;
    else if (wr_en)   wr_addr <= wr_addr_p1;
    //?? temporary, do not advance wr ptr if full (overwrite last write, but do not screw up pointers
    // else if (wr_en && !full) wr_addr <= wr_addr_p1;
  end
  
  // read pointer
  wire [LOG2WORDS-1:0] rd_addr_p1 = gray_code_inc(rd_addr, LOG2WORDS); // next address to read
  always @(posedge rd_clk, negedge rd_reset_n) begin
    if (!rd_reset_n)  rd_addr <= 0;
    else if (rd_en)   rd_addr <= rd_addr_p1;
  end
  
  // Flag generation requires both read and write pointers.  If they using different clocks,
  // then must synchronize across domains.  If a port is asynchronous (no free running clock),
  // then pass directly, as there is no way to synchronize (cannot synchronize to strobe, since 
  // may not get another).
  // A side effect is that one of the fifo words cannot be used, since rdptr=wrptr indicates
  // empty.  Cannot also mean full, even with extra state, since may receive many clocks in one
  // domain and not in other, so can go from full to empty in one wr_clk, which would be missed.
  // If both ports are synchronous, with same clock, then can maintain single 'valid word'
  // counter, which allows use of all fifo entries.

  reg flopped_full ;

  generate
    if (SAME_SYNC && WR_SYNC && RD_SYNC) begin: flagsameclk
      // with common read/write clock flag generation is simplified, and can use all fifo words
      reg [LOG2WORDS:0] valid_cnt; // number of entries used (extra bit so can count up to WORDS)
      wire [LOG2WORDS:0] valid_cnt_p1 = valid_cnt + 1;
      wire [LOG2WORDS:0] valid_cnt_m1 = valid_cnt - 1;
      
      always @(posedge wr_clk, negedge wr_reset_n) begin
        if (!wr_reset_n)          valid_cnt <= 0;
        else if (wr_en && !rd_en) valid_cnt <= valid_cnt_p1;
        else if (!wr_en && rd_en) valid_cnt <= valid_cnt_m1;
      end

      if (FULL_FLOP) begin: full_flop
        always @(posedge wr_clk, negedge wr_reset_n) begin
          if (!wr_reset_n)          flopped_full <= 0;
          else if (wr_en && !rd_en) flopped_full <= (valid_cnt_p1 == `WORDS);
          else if (!wr_en && rd_en) flopped_full <= (valid_cnt_m1 == `WORDS);
          else                      flopped_full <= (valid_cnt == `WORDS); // redundant, but adds resiliancy
        end
        assign full = flopped_full ;
      end
      else begin: not_full_flop
        assign full = (valid_cnt == `WORDS);
      end

      if (AFULL_THRESH == `WORDS) begin: afull_thresh_words
        assign afull = full;
      end else begin: not_afull_thres_words
        assign afull  = (valid_cnt >= AFULL_THRESH);
      end
      assign empty  = (valid_cnt == 0);
      if (AEMPTY_THRESH == 0) begin: aempty_thresh_zero
        assign aempty = empty;
      end else begin: not_aempty_thresh_zero
        assign aempty = (valid_cnt <= AEMPTY_THRESH);
      end
      
      assign valid_entries = valid_cnt;
    end
    else begin: flagnotsameclk
      // read and write ports are not using a common clock

      // write related flags
      wire [LOG2WORDS-1:0] rd_addr_sync;   // read ptr synced into wr_clk domain
      if (WR_SYNC) begin: wr_sync
        gp_sync #(.BITS(LOG2WORDS), .RANDOMIZE_BITS_TOGETHER(1)) 
        rps(.clk(wr_clk), .reset_n(wr_reset_n), .din(rd_addr), .dout(rd_addr_sync));
      end else begin: not_wr_sync
        assign rd_addr_sync = rd_addr;
      end
      
      if (FULL_FLOP) begin: full_flop
        always @(posedge wr_clk, negedge wr_reset_n) begin
          if (!wr_reset_n)  flopped_full <= 0;
          else              flopped_full <= (rd_addr_sync == (wr_en ? (gray_code_inc(wr_addr_p1, LOG2WORDS)) : wr_addr_p1));
        end
        assign full = flopped_full ;
      end
      else begin: not_full_flop
        assign full = (wr_addr_p1 == rd_addr_sync);
      end
      wire [LOG2WORDS:0] valid_entries_rd_clk;
      wire [LOG2WORDS:0] valid_entries_wr_clk;
      //?? improve speed (maybe size) by replacing operation in gray code domain
      assign afull = (valid_entries_wr_clk >= AFULL_THRESH);
  
      // read related flags
      wire [LOG2WORDS-1:0] wr_addr_sync;   // write ptr synced into rd_clk domain
      if (RD_SYNC) begin: rd_sync
        gp_sync #(.BITS(LOG2WORDS), .RANDOMIZE_BITS_TOGETHER(1)) 
        wps(.clk(rd_clk), .reset_n(rd_reset_n), .din(wr_addr), .dout(wr_addr_sync));
      end else begin: not_rd_sync
        assign wr_addr_sync = wr_addr;
      end
      
      assign empty = (wr_addr_sync == rd_addr);
      //?? improve speed (maybe size) by replacing operation in gray code domain
      wire [LOG2WORDS-1:0] wr_addr_sync_binary = gray_to_binary(wr_addr_sync, LOG2WORDS);
      wire [LOG2WORDS-1:0] rd_addr_binary      = gray_to_binary(rd_addr, LOG2WORDS);
      wire [LOG2WORDS-1:0] wr_rd_delta         = wr_addr_sync_binary - rd_addr_binary;
      //assign aempty = ((wr_addr_sync_binary - rd_addr_binary) <= AEMPTY_THRESH);
      assign aempty = (wr_rd_delta <= AEMPTY_THRESH);

      //?? improve speed (maybe size) by replacing operation in gray code domain
      wire [LOG2WORDS-1:0] wr_addr_binary      = gray_to_binary(wr_addr, LOG2WORDS);
      wire [LOG2WORDS-1:0] rd_addr_sync_binary = gray_to_binary(rd_addr_sync, LOG2WORDS);
      // limit bit range to ensure proper wraparound subtraction
      assign valid_entries_rd_clk = {1'b0, wr_addr_sync_binary[LOG2WORDS-1:0] - rd_addr_binary[LOG2WORDS-1:0]};
      assign valid_entries_wr_clk = {1'b0, wr_addr_binary[LOG2WORDS-1:0] - rd_addr_sync_binary[LOG2WORDS-1:0]};
      if (VALID_ENTRIES_SYNC_RD_CLK) begin: valid_entries_rd_clk2
        assign valid_entries = valid_entries_rd_clk;
      end else begin: valid_entries_wr_clk2
        assign valid_entries = valid_entries_wr_clk;
      end
    end
  endgenerate

  //`ifdef SIMULATING
  //// assertions to verify proper operation
  //ovl_proposition #(.msg("fifo WORDS = 0")) ovl1(wr_reset_n, 1'b1, `WORDS != 0,);
  //ovl_proposition #(.msg("inconsistant fifo SYNC settings")) 
  //  ovl2(wr_reset_n, 1'b1, !SAME_SYNC || (RD_SYNC && WR_SYNC),);
  //`endif
 
  `undef WORDS
endmodule // gp_fifo_ctl
