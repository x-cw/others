//-----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2004-2013 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//    Checked In : $Date: 2013-09-06 16:05:05 +0100 (Fri, 06 Sep 2013) $
//    Revision   : $Revision: 37058 $
//    Release    : CoreSight-SoC-TM100-r3p1-00rel0
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// Abstract:
// Explicit OR gate.  This module should be preserved during implementation
// to ensure that an input whose timing is potentially unsafe does not
// to other logic and cause metastability.
//-----------------------------------------------------------------------------


module cxdapswjdp_dp_or (
  in_a,
  in_b,
  out_y
  );

  input in_a;
  input in_b;

  output out_y;

  assign out_y = in_a | in_b;

endmodule
