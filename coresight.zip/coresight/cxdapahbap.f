+incdir+$GP3_RTL/coresight/rtl/coresight_component/debug_module/cxdapahbap/verilog
$GP3_RTL/coresight/rtl/coresight_component/debug_module/cxdapahbap/verilog/cxdapahbap.v
$GP3_RTL/coresight/rtl/coresight_component/debug_module/cxdapahbap/verilog/cxdapahbap_dap_sync.v
$GP3_RTL/coresight/rtl/coresight_component/debug_module/cxdapahbap/verilog/cxdapahbap_constants.v
$GP3_RTL/coresight/rtl/coresight_component/debug_module/cxdapahbap/verilog/cxdapahbap_mst.v
$GP3_RTL/coresight/rtl/coresight_component/debug_module/cxdapahbap/verilog/cxdapahbap_slv.v
$GP3_RTL/coresight/rtl/coresight_component/debug_module/cxdapahbap/verilog/cxdapahbap_ahb_sync.v
