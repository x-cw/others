//-----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2004-2015 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//    Checked In : $Date: 2014-06-25 08:42:22 +0100 (Wed, 25 Jun 2014) $
//    Revision   : $Revision: 39629 $
//    Release    : CoreSight-SoC-TM100-r3p2-00rel0
//-----------------------------------------------------------------------------
//  Purpose             : Trace Pattern generator block. Used to establish pin
//                        timing and voltage characteristics using known data.
//                        Cycles through a variety of actual patterns, walking
//                        bits, alternating bits.
//-----------------------------------------------------------------------------

module cxtpiu_trace_pattern (
  // Inputs
  traceclkin, tresetn, pattern_complete, reg_update, curr_port_sel_reg,
  curr_patt_sel_reg, curr_patt_mode_reg,
  // Outputs
  gen_data, trace_pattern, pattern_done
  );

  // ---------------------------------------------------------------------------
  // Inputs and Outputs
  // ---------------------------------------------------------------------------

  // Clock and Reset
  input            traceclkin;         // Clock
  input            tresetn;            // Reset

  // Interface to Bridge
  output [31:0]    gen_data;           // The currently selected pattern
  input            pattern_complete;   // Marker from the Counter within the bridge
                                       // to shift to the next pattern
  //Interface to Bridge and TraceOut
  output           trace_pattern;      // Indicates when a pattern is running

  // Programming values
  input            reg_update;         // Registers update occured
  input [31:0]     curr_port_sel_reg;  // One-hot encoding of the current port width
  input [3:0]      curr_patt_sel_reg;  // Pattern Gen. select register
  input [1:0]      curr_patt_mode_reg; // Pattern Gen. Mode register
  output           pattern_done;       // All selected patterns done

  // ---------------------------------------------------------------------------
  // Internal signals
  // ---------------------------------------------------------------------------
  // Pattern Generator Control
  wire             nxt_pat_bit_3;
  wire             nxt_pat_bit_2;
  wire             nxt_pat_bit_1;
  wire             nxt_pat_bit_0;
  wire [3:0]       nxt_pattern_sel;
  wire             next_pattern_en;
  reg [3:0]        pattern_sel;
  wire             pattern_done;
  reg              pattern_complete_reg;
  wire             next_pattern_restart;
  reg              pattern_restart;

  // Pattern 0
  wire           restart_0;
  wire [31:0]    gen_data_0;
  wire           gen_data_0_r_en;
  reg [31:0]     gen_data_0_reg;

  // Pattern 1
  wire [31:0]    gen_data_1;

  // Pattern 2
  wire           restart_2;
  wire [31:0]    gen_data_2;
  wire           gen_data_2_r_en;
  reg            gen_data_2_reg;

  // Pattern 3
  wire [31:0]    gen_data_3;

  // Pattern Mux
  wire           nxt_running;
  reg            running;    // Pattern Generator in operation
  wire           running_en;

  // ---------------------------------------------------------------------------
  // Selection Control Logic
  // ---------------------------------------------------------------------------

  // if running formatter
  assign         trace_pattern = running;

  // ---------------------------------------------------------------------------
  // Pattern Generator Control
  // ---------------------------------------------------------------------------

  //curr_patt_sel_reg [3:0]
  // Each bit represents a selected mode that is run until the Counter reaches
  // zero, at which point the next enabled pattern is selected. This is then
  // repeated for all chosen patterns. If the timed mode is chosen then on
  // reaching the last pattern, the Pattern Generator stops. If continuous mode
  // is enabled then the cycle of pattern selection is continued.
  //curr_patt_mode_reg [1:0]
  // There are two modes - continuous (bit 1) where the selected patterns are
  // repeated and timed (0) where all the selected patterns are run through once

  // Each enabled pattern is selected if the previous pattern was selected or
  // the one before that was and the last wasn't, etc.
  // so [1] is set if enabled AND [2] was running -or-
  //                              [3] was but not [2] -or-
  //                              [0] but not [3] and not [2] -or-
  //                              [1] but not [0] and not [3] and not [2] -or-
  //                            None were running and this is the lowest enabled

  assign nxt_pat_bit_3 = (pattern_sel[0]                             | // last
                         (pattern_sel[1] & ~curr_patt_sel_reg[0]    )| // last but one
                         (pattern_sel[2] & ~(curr_patt_sel_reg[0]|
                                            curr_patt_sel_reg[1])  ) | // last but two
                         (pattern_sel[3] & ~(curr_patt_sel_reg[0]|
                                            curr_patt_sel_reg[1]|
                                            curr_patt_sel_reg[2])  )|  // no other on
                         (~(|pattern_sel[3:0]))                  );    // Nothing on

  assign nxt_pat_bit_2 = (pattern_sel[3]                          |    // last
                         (pattern_sel[0] & ~curr_patt_sel_reg[3]    )| // last but one
                         (pattern_sel[1] & ~(curr_patt_sel_reg[3]|
                                            curr_patt_sel_reg[0])  )|  // last but two
                         (pattern_sel[2] & ~(curr_patt_sel_reg[3]|
                                            curr_patt_sel_reg[0]|
                                            curr_patt_sel_reg[1])  )|  //no other on
                         (~(|pattern_sel[3:0]) & ~curr_patt_sel_reg[3]));//Nothing on

  assign nxt_pat_bit_1 = (pattern_sel[2]                          |
                       (pattern_sel[3] & ~curr_patt_sel_reg[2]    )|
                       (pattern_sel[0] & ~(curr_patt_sel_reg[2]|
                                          curr_patt_sel_reg[3])  )|
                       (pattern_sel[1] & ~(curr_patt_sel_reg[2]|
                                          curr_patt_sel_reg[3]|
                                          curr_patt_sel_reg[0])  )|
                       (~(|pattern_sel[3:0]) & ~curr_patt_sel_reg[3]
                                           & ~curr_patt_sel_reg[2]));

  assign nxt_pat_bit_0 = (pattern_sel[1]                          |
                       (pattern_sel[2] & ~curr_patt_sel_reg[1]    )|
                       (pattern_sel[3] & ~(curr_patt_sel_reg[1]|
                                          curr_patt_sel_reg[2])  )|
                       (pattern_sel[0] & ~(curr_patt_sel_reg[1]|
                                          curr_patt_sel_reg[2]|
                                          curr_patt_sel_reg[3])  )|
                       (~(|pattern_sel[3:0]) & ~curr_patt_sel_reg[3]
                                           & ~curr_patt_sel_reg[2]
                                           & ~curr_patt_sel_reg[1]));

  assign nxt_pattern_sel = ~nxt_running ? 4'b0000 :
                                      { (curr_patt_sel_reg[3] & nxt_pat_bit_3),
                                        (curr_patt_sel_reg[2] & nxt_pat_bit_2),
                                        (curr_patt_sel_reg[1] & nxt_pat_bit_1),
                                        (curr_patt_sel_reg[0] & nxt_pat_bit_0) };

  // Update the selection on a Register update or when the counter hits zero to
  // shift to the next pattern
  assign next_pattern_en = (pattern_complete_reg | reg_update);

  // Track the currently selected pattern and use the same format as the
  // Register setting (just one-hot)
  always @(posedge traceclkin or negedge tresetn)
    if (!tresetn)
      pattern_sel <= 4'b0000;
    else
      if (next_pattern_en)
        pattern_sel <= nxt_pattern_sel;

  // Indicate the pattern completion one cycle before the counter reaches
  // zero (to counter some register delays in the system)
  assign pattern_done = (pattern_complete &
                        ((pattern_sel[3] & ~(|curr_patt_sel_reg[2:0])) |
                         (pattern_sel[2] & ~(|curr_patt_sel_reg[1:0])) |
                         (pattern_sel[1] & ~curr_patt_sel_reg[0]) |
                         pattern_sel[0]) );
  // Generate a restart for patterns:
  // restart on pattern completion (changing to the next pattern) and if the
  // registers are re-written
  assign next_pattern_restart = ( (pattern_complete_reg & |(nxt_pattern_sel ^ pattern_sel)) |
                                reg_update);

  always @(posedge traceclkin or negedge tresetn)
    if (!tresetn)
      begin
        pattern_complete_reg <= 1'b0;
        pattern_restart     <= 1'b0;
      end
    else
      begin
        pattern_complete_reg <= pattern_complete;
        pattern_restart     <= next_pattern_restart;
      end

  // ---------------------------------------------------------------------------
  // Pattern 0: Walking Ones
  // ---------------------------------------------------------------------------
  // All bits will be zero expect for a single bit set starting at [0] and going
  // up to the current port width. Upon reaching the port width, the pattern
  // repeats.

  assign restart_0 = ( (|(gen_data_0_reg[31:0] & curr_port_sel_reg[31:0])) |
                      pattern_restart                                );

  assign gen_data_0 = restart_0 ? 32'h00000001 :
                               {gen_data_0_reg[30:0],gen_data_0_reg[31]};

  assign gen_data_0_r_en = (running | restart_0);

  // Walking ones register, reused for walking zeros
  always @(posedge traceclkin or negedge tresetn)
    if (!tresetn)
      gen_data_0_reg <= 32'b0;
    else
      if (gen_data_0_r_en)
        gen_data_0_reg <= gen_data_0;

  // ---------------------------------------------------------------------------
  // Pattern 1: Walking Zeros
  // ---------------------------------------------------------------------------
  // This uses Pattern#0 and inverts the data to create all bits set except for
  // a single clear bit.

  assign gen_data_1 = ~gen_data_0[31:0];

  // ---------------------------------------------------------------------------
  // Pattern 2: Alternating 55/AA
  // ---------------------------------------------------------------------------
  // This is a pattern that repeats around the values 55 and AA (effectively odd
  // bits are changing 0-1-0-1 while even bits are changing 1-0-1-0).
  // It is coded as 16 multiples of a two bit values.

  assign restart_2 = pattern_restart;

  assign gen_data_2 = {16{ restart_2 ? 2'b01 : {~gen_data_2_reg, gen_data_2_reg} }};

  assign gen_data_2_r_en = (running | restart_2);

  //div-2 counter that effectively creates alternating bits
  // used for AA/55 and 00/FF patterns
  always @(posedge traceclkin or negedge tresetn)
    if (!tresetn)
      gen_data_2_reg <= 1'b0;
    else
      if (gen_data_2_r_en)
        gen_data_2_reg <= gen_data_2[1];

  // ---------------------------------------------------------------------------
  // Pattern 3: Alternating 00/FF
  // ---------------------------------------------------------------------------
  // All bits are set to 1 and then cleared to zero every cycle.
  // This re-uses the alternating bit engine of Pattern#2.

  assign gen_data_3 = {32{ restart_2 ? 1'b1 : gen_data_2_reg }};

  // ---------------------------------------------------------------------------
  // Pattern Mux
  // ---------------------------------------------------------------------------

  assign nxt_running = (|curr_patt_mode_reg[1:0]);
  assign running_en  = (nxt_running | running);

  assign gen_data = pattern_sel[3] ? gen_data_3 :
                     ( {32{  pattern_sel[2]}}                                   & gen_data_2) |
                     (({32{(~pattern_sel[2] &  pattern_sel[1])}}                 & gen_data_1) |
                      ({32{(~pattern_sel[2] & ~pattern_sel[1] & pattern_sel[0])}} & gen_data_0));

  // Enable term for patterns to bypass rotation within the
  // Serialiser (cxtpiu_trace_out)
  always @(posedge traceclkin or negedge tresetn)
    if (!tresetn)
      running <= 1'b0;
    else
      if (running_en)
        running <= nxt_running;


endmodule // cxtpiu_trace_pattern
