//+FHDR*************************************************************************
// 
//   Copyright (c) 2024 Innosilicon. Ltd.  All rights reserved. 
// 
//   THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF INNOSILICON
//   The copyright notice above does not evidence any actual or intended
//   publication of such source code.
// 
//************************************************************************
//    Module name: intlv_ctrl_center.v
//    Create by  : fangxn
//    Email      : fangxn@fantasyxpu.com
//    Create time: 2025-07-15
//************************************************************************
//    Description: 
//-FHDR*************************************************************************

module intlv_ctrl_center (
     //ddr intlv config signal
    input   wire    [3:0]   ddr_channel_size,       //capacity per ddr channel
                                                    //4'd0: 0.5GBytes
                                                    //4'd1: 0.75GBytes
                                                    //4'd2: 1GBytes
                                                    //4'd3: 1.5GBytes
                                                    //4'd4: 2GBytes
                                                    //4'd5: 3GBytes
                                                    //4'd6: 4GBytes
                                                    //4'd7: 6GBytes
                                                    //4'd8: 8GBytes(default)
    input   wire        [1:0]           ddr_intlv_mode,         // 2'd0: linear mode 2'd1: linear hash 2'd2: cfg hash(default)  2'd3: reserved
    input   wire        [79:0]          ddrch_damage,           // one-hot code for ddr channel damage infomation 1'b0:ddr channel not damage  (default)   1'b1: ddr channel damage
    input   wire                        ecc_mode,               // 1'b0: ecc off(default);    1'b1: ecc on
        // buffer intlv 
    input   wire                        buffer_mode,            // 1'b0: 25%(5MBytes)  1'b1: 50%(10MBytes) (default)
    input   wire                        buffer_intlv_mode,      // 1'b0: linear mode    1'b1: linear hash
    input   wire        [79:0]          bank_damage,            // one-hot code for bank damage infomation 1'b0:bank not damage  (default)   1'b1: bank damage
        
    // scenario static config signal
    output  wire        [35:0]          scenario_ddr_lnhash,    // one-hot code to indicate which scenario is valid, verify assert
                                                                // [35:0]: ddr_intlv linear hash, only one of them can be valid

    output  wire        [35:0]          scenario_ddr_cfghash,   // one-hot code to indicate which scenario is valid, verify assert
                                                                // [35:0]: ddr_intlv config hash, only one of them can be valid

    output  wire        [3:0]           scenario_l2c_lnhash,    // one-hot code to indicate which scenario is valid, verify assert
                                                                // [3:0]: buffer linear hash, only one of them can be valid

    output  wire        [6:0]           ddrch_num,              // the number of ddr channel available
    output  wire        [6:0]           bank_num               // the number of bank available 
);

genvar              i;
wire    [39:0]      bank_damage_merge;
wire    [79:0]      bank_damage_copy;
wire    [79:0]      ddrch_damage_tol;
wire    [6:0]       ddr_intlv_bankid [0:79];

wire    [39:0]      ddrch_damage_merge;
reg     [79:0]      ddrch_damage_copy;
wire    [6:0]       buf_intlv_bankid [0:79];
wire    [79:0]      buf_damage_tol;

//// ddr damage and ddr channel calculate
generate for (i=0; i<40; i=i+1) begin
    assign  bank_damage_merge[i]        =   bank_damage[2*i] & bank_damage[2*i+1];
    assign  bank_damage_copy[2*i]       =   bank_damage_merge[i];
    assign  bank_damage_copy[2*i+1]     =   bank_damage_merge[i];

    if(i == 0) begin
        assign ddr_intlv_bankid[i]     =   {6'd0, ddrch_damage_tol[0]};
    end else begin
        assign ddr_intlv_bankid[2*i]   =   ddr_intlv_bankid[2*i-1] + {6'd0, ddrch_damage_tol[2*i]};
    end
    assign ddr_intlv_bankid[2*i+1]     =   ddr_intlv_bankid[2*i] + {6'd0, ddrch_damage_tol[2*i+1]};
end
endgenerate

assign  ddrch_damage_tol    =   bank_damage_copy | ddrch_damage;
assign  ddrch_num           =   7'd79 - ddr_intlv_bankid[79];    // actual ddrch number available = "ddrch_num" + 1

////// bank damage calculate
//generate for (i=0; i<80; i=i+1) begin
//    if(i == 0) begin
//        assign buf_intlv_bankid[i]   =   {6'd0, bank_damage[0]};
//    end else begin
//        assign buf_intlv_bankid[i]   =   buf_intlv_bankid[i-1] + {6'd0, bank_damage[i]};
//    end
//end
//endgenerate

// buffer damage and ddr channel calculate
generate for (i=0; i<40; i=i+1) begin
    assign  ddrch_damage_merge[i]            =   ddrch_damage[2*i] & ddrch_damage[2*i+1];

    always@(*) begin
        ddrch_damage_copy[2*i] = '0;
        ddrch_damage_copy[2*i+1] = '0;
        if(bank_damage[2*i+1:2*i] == 2'b00) begin
            ddrch_damage_copy[2*i]       =   ddrch_damage[2*i];
            ddrch_damage_copy[2*i+1]     =   ddrch_damage[2*i+1];
        end else begin
            ddrch_damage_copy[2*i]       =   ddrch_damage_merge[i];
            ddrch_damage_copy[2*i+1]     =   ddrch_damage_merge[i];
        end
    end

    if(i == 0) begin
        assign buf_intlv_bankid[i]     =   {6'd0, buf_damage_tol[0]};
    end else begin
        assign buf_intlv_bankid[2*i]   =   buf_intlv_bankid[2*i-1] + {6'd0, buf_damage_tol[2*i]};
    end
    assign buf_intlv_bankid[2*i+1]     =   buf_intlv_bankid[2*i] + {6'd0, buf_damage_tol[2*i+1]};
end
endgenerate

assign  buf_damage_tol    =   ddrch_damage_copy | bank_damage;
assign  bank_num          =   7'd79 - buf_intlv_bankid[79];    // actual ddrch number available = "ddrch_num" + 1


//// -----------------scenario generate----------------------------
///DDRC Linear Hash
assign  scenario_ddr_lnhash[0]   =   (ddr_channel_size == 4'd8)  && (ddr_intlv_mode == 2'd1) && (ddrch_num == 7'd79) && (ecc_mode == 1'b0 );   // 8g-ddrch,    nodam, lihash,noecc
assign  scenario_ddr_lnhash[1]   =   (ddr_channel_size == 4'd7)  && (ddr_intlv_mode == 2'd1) && (ddrch_num == 7'd79) && (ecc_mode == 1'b0 );   // 6g-ddrch,    nodam, lihash,noecc
assign  scenario_ddr_lnhash[2]   =   (ddr_channel_size == 4'd6)  && (ddr_intlv_mode == 2'd1) && (ddrch_num == 7'd79) && (ecc_mode == 1'b0 );   // 4g-ddrch,    nodam, lihash,noecc
assign  scenario_ddr_lnhash[3]   =   (ddr_channel_size == 4'd5)  && (ddr_intlv_mode == 2'd1) && (ddrch_num == 7'd79) && (ecc_mode == 1'b0 );   // 3g-ddrch,    nodam, lihash,noecc
assign  scenario_ddr_lnhash[4]   =   (ddr_channel_size == 4'd4)  && (ddr_intlv_mode == 2'd1) && (ddrch_num == 7'd79) && (ecc_mode == 1'b0 );   // 2g-ddrch,    nodam, lihash,noecc
assign  scenario_ddr_lnhash[5]   =   (ddr_channel_size == 4'd3)  && (ddr_intlv_mode == 2'd1) && (ddrch_num == 7'd79) && (ecc_mode == 1'b0 );   // 1.5g-ddrch,  nodam, lihash,noecc
assign  scenario_ddr_lnhash[6]   =   (ddr_channel_size == 4'd2)  && (ddr_intlv_mode == 2'd1) && (ddrch_num == 7'd79) && (ecc_mode == 1'b0 );   // 1g-ddrch,    nodam, lihash,noecc
assign  scenario_ddr_lnhash[7]   =   (ddr_channel_size == 4'd1)  && (ddr_intlv_mode == 2'd1) && (ddrch_num == 7'd79) && (ecc_mode == 1'b0 );   // 0.75g-ddrch, nodam, lihash,noecc
assign  scenario_ddr_lnhash[8]   =   (ddr_channel_size == 4'd0)  && (ddr_intlv_mode == 2'd1) && (ddrch_num == 7'd79) && (ecc_mode == 1'b0 );   // 0.5g-ddrch,  nodam, lihash,noecc

assign  scenario_ddr_lnhash[9]   =   (ddr_channel_size == 4'd8)  && (ddr_intlv_mode == 2'd1) && (ddrch_num == 7'd79) && (ecc_mode == 1'b1 );   // 8g-ddrch,    nodam, lihash,ecc
assign  scenario_ddr_lnhash[10]  =   (ddr_channel_size == 4'd7)  && (ddr_intlv_mode == 2'd1) && (ddrch_num == 7'd79) && (ecc_mode == 1'b1 );   // 6g-ddrch,    nodam, lihash,ecc
assign  scenario_ddr_lnhash[11]  =   (ddr_channel_size == 4'd6)  && (ddr_intlv_mode == 2'd1) && (ddrch_num == 7'd79) && (ecc_mode == 1'b1 );   // 4g-ddrch,    nodam, lihash,ecc
assign  scenario_ddr_lnhash[12]  =   (ddr_channel_size == 4'd5)  && (ddr_intlv_mode == 2'd1) && (ddrch_num == 7'd79) && (ecc_mode == 1'b1 );   // 3g-ddrch,    nodam, lihash,ecc
assign  scenario_ddr_lnhash[13]  =   (ddr_channel_size == 4'd4)  && (ddr_intlv_mode == 2'd1) && (ddrch_num == 7'd79) && (ecc_mode == 1'b1 );   // 2g-ddrch,    nodam, lihash,ecc
assign  scenario_ddr_lnhash[14]  =   (ddr_channel_size == 4'd3)  && (ddr_intlv_mode == 2'd1) && (ddrch_num == 7'd79) && (ecc_mode == 1'b1 );   // 1.5g-ddrch,  nodam, lihash,ecc
assign  scenario_ddr_lnhash[15]  =   (ddr_channel_size == 4'd2)  && (ddr_intlv_mode == 2'd1) && (ddrch_num == 7'd79) && (ecc_mode == 1'b1 );   // 1g-ddrch,    nodam, lihash,ecc
assign  scenario_ddr_lnhash[16]  =   (ddr_channel_size == 4'd1)  && (ddr_intlv_mode == 2'd1) && (ddrch_num == 7'd79) && (ecc_mode == 1'b1 );   // 0.75g-ddrch, nodam, lihash,ecc
assign  scenario_ddr_lnhash[17]  =   (ddr_channel_size == 4'd0)  && (ddr_intlv_mode == 2'd1) && (ddrch_num == 7'd79) && (ecc_mode == 1'b1 );   // 0.5g-ddrch,  nodam, lihash,ecc

assign  scenario_ddr_lnhash[18]  =   (ddr_channel_size == 4'd8)  && (ddr_intlv_mode == 2'd1) && (ddrch_num != 7'd79) && (ecc_mode == 1'b0 );   // 8g-ddrch,    dam, lihash,noecc
assign  scenario_ddr_lnhash[19]  =   (ddr_channel_size == 4'd7)  && (ddr_intlv_mode == 2'd1) && (ddrch_num != 7'd79) && (ecc_mode == 1'b0 );   // 6g-ddrch,    dam, lihash,noecc
assign  scenario_ddr_lnhash[20]  =   (ddr_channel_size == 4'd6)  && (ddr_intlv_mode == 2'd1) && (ddrch_num != 7'd79) && (ecc_mode == 1'b0 );   // 4g-ddrch,    dam, lihash,noecc
assign  scenario_ddr_lnhash[21]  =   (ddr_channel_size == 4'd5)  && (ddr_intlv_mode == 2'd1) && (ddrch_num != 7'd79) && (ecc_mode == 1'b0 );   // 3g-ddrch,    dam, lihash,noecc
assign  scenario_ddr_lnhash[22]  =   (ddr_channel_size == 4'd4)  && (ddr_intlv_mode == 2'd1) && (ddrch_num != 7'd79) && (ecc_mode == 1'b0 );   // 2g-ddrch,    dam, lihash,noecc
assign  scenario_ddr_lnhash[23]  =   (ddr_channel_size == 4'd3)  && (ddr_intlv_mode == 2'd1) && (ddrch_num != 7'd79) && (ecc_mode == 1'b0 );   // 1.5g-ddrch,  dam, lihash,noecc
assign  scenario_ddr_lnhash[24]  =   (ddr_channel_size == 4'd2)  && (ddr_intlv_mode == 2'd1) && (ddrch_num != 7'd79) && (ecc_mode == 1'b0 );   // 1g-ddrch,    dam, lihash,noecc
assign  scenario_ddr_lnhash[25]  =   (ddr_channel_size == 4'd1)  && (ddr_intlv_mode == 2'd1) && (ddrch_num != 7'd79) && (ecc_mode == 1'b0 );   // 0.75g-ddrch, dam, lihash,noecc
assign  scenario_ddr_lnhash[26]  =   (ddr_channel_size == 4'd0)  && (ddr_intlv_mode == 2'd1) && (ddrch_num != 7'd79) && (ecc_mode == 1'b0 );   // 0.5g-ddrch,  dam, lihash,noecc

assign  scenario_ddr_lnhash[27]  =   (ddr_channel_size == 4'd8)  && (ddr_intlv_mode == 2'd1) && (ddrch_num != 7'd79) && (ecc_mode == 1'b1 );   // 8g-ddrch,    dam, lihash,ecc
assign  scenario_ddr_lnhash[28]  =   (ddr_channel_size == 4'd7)  && (ddr_intlv_mode == 2'd1) && (ddrch_num != 7'd79) && (ecc_mode == 1'b1 );   // 6g-ddrch,    dam, lihash,ecc
assign  scenario_ddr_lnhash[29]  =   (ddr_channel_size == 4'd6)  && (ddr_intlv_mode == 2'd1) && (ddrch_num != 7'd79) && (ecc_mode == 1'b1 );   // 4g-ddrch,    dam, lihash,ecc
assign  scenario_ddr_lnhash[30]  =   (ddr_channel_size == 4'd5)  && (ddr_intlv_mode == 2'd1) && (ddrch_num != 7'd79) && (ecc_mode == 1'b1 );   // 3g-ddrch,    dam, lihash,ecc
assign  scenario_ddr_lnhash[31]  =   (ddr_channel_size == 4'd4)  && (ddr_intlv_mode == 2'd1) && (ddrch_num != 7'd79) && (ecc_mode == 1'b1 );   // 2g-ddrch,    dam, lihash,ecc
assign  scenario_ddr_lnhash[32]  =   (ddr_channel_size == 4'd3)  && (ddr_intlv_mode == 2'd1) && (ddrch_num != 7'd79) && (ecc_mode == 1'b1 );   // 1.5g-ddrch,  dam, lihash,ecc
assign  scenario_ddr_lnhash[33]  =   (ddr_channel_size == 4'd2)  && (ddr_intlv_mode == 2'd1) && (ddrch_num != 7'd79) && (ecc_mode == 1'b1 );   // 1g-ddrch,    dam, lihash,ecc
assign  scenario_ddr_lnhash[34]  =   (ddr_channel_size == 4'd1)  && (ddr_intlv_mode == 2'd1) && (ddrch_num != 7'd79) && (ecc_mode == 1'b1 );   // 0.75g-ddrch, dam, lihash,ecc
assign  scenario_ddr_lnhash[35]  =   (ddr_channel_size == 4'd0)  && (ddr_intlv_mode == 2'd1) && (ddrch_num != 7'd79) && (ecc_mode == 1'b1 );   // 0.5g-ddrch,  dam, lihash,ecc

///DDRC cfg Hash
assign  scenario_ddr_cfghash[0]  =   (ddr_channel_size == 4'd8)  && (ddr_intlv_mode == 2'd2) && (ddrch_num == 7'd79) && (ecc_mode == 1'b0 );   // 8g-ddrch,    nodam, cfghash,noecc
assign  scenario_ddr_cfghash[1]  =   (ddr_channel_size == 4'd7)  && (ddr_intlv_mode == 2'd2) && (ddrch_num == 7'd79) && (ecc_mode == 1'b0 );   // 6g-ddrch,    nodam, cfghash,noecc
assign  scenario_ddr_cfghash[2]  =   (ddr_channel_size == 4'd6)  && (ddr_intlv_mode == 2'd2) && (ddrch_num == 7'd79) && (ecc_mode == 1'b0 );   // 4g-ddrch,    nodam, cfghash,noecc
assign  scenario_ddr_cfghash[3]  =   (ddr_channel_size == 4'd5)  && (ddr_intlv_mode == 2'd2) && (ddrch_num == 7'd79) && (ecc_mode == 1'b0 );   // 3g-ddrch,    nodam, cfghash,noecc
assign  scenario_ddr_cfghash[4]  =   (ddr_channel_size == 4'd4)  && (ddr_intlv_mode == 2'd2) && (ddrch_num == 7'd79) && (ecc_mode == 1'b0 );   // 2g-ddrch,    nodam, cfghash,noecc
assign  scenario_ddr_cfghash[5]  =   (ddr_channel_size == 4'd3)  && (ddr_intlv_mode == 2'd2) && (ddrch_num == 7'd79) && (ecc_mode == 1'b0 );   // 1.5g-ddrch,  nodam, cfghash,noecc
assign  scenario_ddr_cfghash[6]  =   (ddr_channel_size == 4'd2)  && (ddr_intlv_mode == 2'd2) && (ddrch_num == 7'd79) && (ecc_mode == 1'b0 );   // 1g-ddrch,    nodam, cfghash,noecc
assign  scenario_ddr_cfghash[7]  =   (ddr_channel_size == 4'd1)  && (ddr_intlv_mode == 2'd2) && (ddrch_num == 7'd79) && (ecc_mode == 1'b0 );   // 0.75g-ddrch, nodam, cfghash,noecc
assign  scenario_ddr_cfghash[8]  =   (ddr_channel_size == 4'd0)  && (ddr_intlv_mode == 2'd2) && (ddrch_num == 7'd79) && (ecc_mode == 1'b0 );   // 0.5g-ddrch,  nodam, cfghash,noecc

assign  scenario_ddr_cfghash[9]   =   (ddr_channel_size == 4'd8)  && (ddr_intlv_mode == 2'd2) && (ddrch_num == 7'd79) && (ecc_mode == 1'b1 );   // 8g-ddrch,    nodam, cfghash,ecc
assign  scenario_ddr_cfghash[10]  =   (ddr_channel_size == 4'd7)  && (ddr_intlv_mode == 2'd2) && (ddrch_num == 7'd79) && (ecc_mode == 1'b1 );   // 6g-ddrch,    nodam, cfghash,ecc
assign  scenario_ddr_cfghash[11]  =   (ddr_channel_size == 4'd6)  && (ddr_intlv_mode == 2'd2) && (ddrch_num == 7'd79) && (ecc_mode == 1'b1 );   // 4g-ddrch,    nodam, cfghash,ecc
assign  scenario_ddr_cfghash[12]  =   (ddr_channel_size == 4'd5)  && (ddr_intlv_mode == 2'd2) && (ddrch_num == 7'd79) && (ecc_mode == 1'b1 );   // 3g-ddrch,    nodam, cfghash,ecc
assign  scenario_ddr_cfghash[13]  =   (ddr_channel_size == 4'd4)  && (ddr_intlv_mode == 2'd2) && (ddrch_num == 7'd79) && (ecc_mode == 1'b1 );   // 2g-ddrch,    nodam, cfghash,ecc
assign  scenario_ddr_cfghash[14]  =   (ddr_channel_size == 4'd3)  && (ddr_intlv_mode == 2'd2) && (ddrch_num == 7'd79) && (ecc_mode == 1'b1 );   // 1.5g-ddrch,  nodam, cfghash,ecc
assign  scenario_ddr_cfghash[15]  =   (ddr_channel_size == 4'd2)  && (ddr_intlv_mode == 2'd2) && (ddrch_num == 7'd79) && (ecc_mode == 1'b1 );   // 1g-ddrch,    nodam, cfghash,ecc
assign  scenario_ddr_cfghash[16]  =   (ddr_channel_size == 4'd1)  && (ddr_intlv_mode == 2'd2) && (ddrch_num == 7'd79) && (ecc_mode == 1'b1 );   // 0.75g-ddrch, nodam, cfghash,ecc
assign  scenario_ddr_cfghash[17]  =   (ddr_channel_size == 4'd0)  && (ddr_intlv_mode == 2'd2) && (ddrch_num == 7'd79) && (ecc_mode == 1'b1 );   // 0.5g-ddrch,  nodam, cfghash,ecc

assign  scenario_ddr_cfghash[18]  =   (ddr_channel_size == 4'd8)  && (ddr_intlv_mode == 2'd2) && (ddrch_num != 7'd79) && (ecc_mode == 1'b0 );   // 8g-ddrch,    dam, cfghash,noecc
assign  scenario_ddr_cfghash[19]  =   (ddr_channel_size == 4'd7)  && (ddr_intlv_mode == 2'd2) && (ddrch_num != 7'd79) && (ecc_mode == 1'b0 );   // 6g-ddrch,    dam, cfghash,noecc
assign  scenario_ddr_cfghash[20]  =   (ddr_channel_size == 4'd6)  && (ddr_intlv_mode == 2'd2) && (ddrch_num != 7'd79) && (ecc_mode == 1'b0 );   // 4g-ddrch,    dam, cfghash,noecc
assign  scenario_ddr_cfghash[21]  =   (ddr_channel_size == 4'd5)  && (ddr_intlv_mode == 2'd2) && (ddrch_num != 7'd79) && (ecc_mode == 1'b0 );   // 3g-ddrch,    dam, cfghash,noecc
assign  scenario_ddr_cfghash[22]  =   (ddr_channel_size == 4'd4)  && (ddr_intlv_mode == 2'd2) && (ddrch_num != 7'd79) && (ecc_mode == 1'b0 );   // 2g-ddrch,    dam, cfghash,noecc
assign  scenario_ddr_cfghash[23]  =   (ddr_channel_size == 4'd3)  && (ddr_intlv_mode == 2'd2) && (ddrch_num != 7'd79) && (ecc_mode == 1'b0 );   // 1.5g-ddrch,  dam, cfghash,noecc
assign  scenario_ddr_cfghash[24]  =   (ddr_channel_size == 4'd2)  && (ddr_intlv_mode == 2'd2) && (ddrch_num != 7'd79) && (ecc_mode == 1'b0 );   // 1g-ddrch,    dam, cfghash,noecc
assign  scenario_ddr_cfghash[25]  =   (ddr_channel_size == 4'd1)  && (ddr_intlv_mode == 2'd2) && (ddrch_num != 7'd79) && (ecc_mode == 1'b0 );   // 0.75g-ddrch, dam, cfghash,noecc
assign  scenario_ddr_cfghash[26]  =   (ddr_channel_size == 4'd0)  && (ddr_intlv_mode == 2'd2) && (ddrch_num != 7'd79) && (ecc_mode == 1'b0 );   // 0.5g-ddrch,  dam, cfghash,noecc

assign  scenario_ddr_cfghash[27]  =   (ddr_channel_size == 4'd8)  && (ddr_intlv_mode == 2'd2) && (ddrch_num != 7'd79) && (ecc_mode == 1'b1 );   // 8g-ddrch,    dam, cfghash,ecc
assign  scenario_ddr_cfghash[28]  =   (ddr_channel_size == 4'd7)  && (ddr_intlv_mode == 2'd2) && (ddrch_num != 7'd79) && (ecc_mode == 1'b1 );   // 6g-ddrch,    dam, cfghash,ecc
assign  scenario_ddr_cfghash[29]  =   (ddr_channel_size == 4'd6)  && (ddr_intlv_mode == 2'd2) && (ddrch_num != 7'd79) && (ecc_mode == 1'b1 );   // 4g-ddrch,    dam, cfghash,ecc
assign  scenario_ddr_cfghash[30]  =   (ddr_channel_size == 4'd5)  && (ddr_intlv_mode == 2'd2) && (ddrch_num != 7'd79) && (ecc_mode == 1'b1 );   // 3g-ddrch,    dam, cfghash,ecc
assign  scenario_ddr_cfghash[31]  =   (ddr_channel_size == 4'd4)  && (ddr_intlv_mode == 2'd2) && (ddrch_num != 7'd79) && (ecc_mode == 1'b1 );   // 2g-ddrch,    dam, cfghash,ecc
assign  scenario_ddr_cfghash[32]  =   (ddr_channel_size == 4'd3)  && (ddr_intlv_mode == 2'd2) && (ddrch_num != 7'd79) && (ecc_mode == 1'b1 );   // 1.5g-ddrch,  dam, cfghash,ecc
assign  scenario_ddr_cfghash[33]  =   (ddr_channel_size == 4'd2)  && (ddr_intlv_mode == 2'd2) && (ddrch_num != 7'd79) && (ecc_mode == 1'b1 );   // 1g-ddrch,    dam, cfghash,ecc
assign  scenario_ddr_cfghash[34]  =   (ddr_channel_size == 4'd1)  && (ddr_intlv_mode == 2'd2) && (ddrch_num != 7'd79) && (ecc_mode == 1'b1 );   // 0.75g-ddrch, dam, cfghash,ecc
assign  scenario_ddr_cfghash[35]  =   (ddr_channel_size == 4'd0)  && (ddr_intlv_mode == 2'd2) && (ddrch_num != 7'd79) && (ecc_mode == 1'b1 );   // 0.5g-ddrch,  dam, cfghash,ecc

///L2C Linear Hash
assign  scenario_l2c_lnhash[0]    =   (buffer_mode == 1'b1) && (bank_num == 7'd79) && (buffer_intlv_mode == 1'b1);   // 50% buffer_mode,nodam,lihash(default)
assign  scenario_l2c_lnhash[1]    =   (buffer_mode == 1'b0) && (bank_num == 7'd79) && (buffer_intlv_mode == 1'b1);   // 25% buffer_mode,nodam,lihash
assign  scenario_l2c_lnhash[2]    =   (buffer_mode == 1'b1) && (bank_num != 7'd79) && (buffer_intlv_mode == 1'b1);   // 50% buffer_mode,dam,lihash
assign  scenario_l2c_lnhash[3]    =   (buffer_mode == 1'b0) && (bank_num != 7'd79) && (buffer_intlv_mode == 1'b1);   // 25% buffer_mode,dam,lihash

endmodule

// Local Variables:
// verilog-library-directories:("./") 
// verilog-auto-inst-param-value:t
// End:
