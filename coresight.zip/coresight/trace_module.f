-f $GP3_RTL/coresight/rtl/coresight_component/trace_module/cxatbfunnel_2/cxatbfunnel_2.f
-f $GP3_RTL/coresight/rtl/coresight_component/trace_module/cxatbfunnel_8_pro/cxatbfunnel_8_pro.f
-f $GP3_RTL/coresight/rtl/coresight_component/trace_module/cxatbfunnel_2_pro/cxatbfunnel_2_pro.f
-f $GP3_RTL/coresight/rtl/coresight_component/trace_module/cxatbfunnel_5_pro/cxatbfunnel_5_pro.f
-f $GP3_RTL/coresight/rtl/coresight_component/trace_module/cxatbfunnel_7_pro/cxatbfunnel_7_pro.f
-f $GP3_RTL/coresight/rtl/coresight_component/trace_module/cxatbfunnel_6_pro/cxatbfunnel_6_pro.f
-f $GP3_RTL/coresight/rtl/coresight_component/trace_module/cxatbfunnel_3_noprogram/cxatbfunnel_3_noprogram.f
-f $GP3_RTL/coresight/rtl/coresight_component/trace_module/cxatbfunnel_4_pro/cxatbfunnel_4_pro.f
$GP3_RTL/coresight/rtl/coresight_component/trace_module/cxatbreplicator_1/cxatbreplicator_1.v    
$GP3_RTL/coresight/rtl/coresight_component/trace_module/cxatbreplicator_1/cxatbreplicator_128.v    
$GP3_RTL/coresight/rtl/coresight_component/trace_module/cxatbdownsizer_128_32/cxatbdownsizer.v    
$GP3_RTL/coresight/rtl/coresight_component/trace_module/cxatbupsizer_64_128/cxatbupsizer_64_128.v    
-f $GP3_RTL/coresight/rtl/coresight_component/trace_module/cxetb_cxetf/cxetb_cxetf.f    
-f $GP3_RTL/coresight/rtl/coresight_component/trace_module/cxtpiu/cxtpiu.f
-f $GP3_RTL/coresight/rtl/coresight_component/trace_module/cxatbasyncbridge/cxatbasyncbridge_1.f
-f $GP3_RTL/coresight/rtl/coresight_component/trace_module/cxatbasyncbridge_mst/cxatbasyncbridge_mst.f
-f $GP3_RTL/coresight/rtl/coresight_component/trace_module/cxatbasyncbridge_slv/cxatbasyncbridge_slv.f
-f $GP3_RTL/coresight/rtl/coresight_component/trace_module/cxatbsyncbridge_fullpipe_2/cxatbasyncbridge_fullpipe2_full.f
