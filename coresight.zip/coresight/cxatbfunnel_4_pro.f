$GP3_RTL/coresight/rtl/coresight_component/trace_module/cxatbfunnel_4_pro/verilog/cxatbfunnel_4_pro.v
$GP3_RTL/coresight/rtl/coresight_component/trace_module/cxatbfunnel_4_pro/verilog/cxatbfunnel_apb_if_4_pro.v
$GP3_RTL/coresight/rtl/coresight_component/trace_module/cxatbfunnel_4_pro/verilog/cxatbfunnel_arbiter_4_pro.v
$GP3_RTL/coresight/rtl/coresight_component/trace_module/cxatbfunnel_4_pro/verilog/cxatbfunnel_reg_blk_4_pro.v
