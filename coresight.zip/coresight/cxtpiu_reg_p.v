//-----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2004-2015 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//    Checked In : $Date: 2014-08-14 16:01:35 +0100 (Thu, 14 Aug 2014) $
//    Revision   : $Revision: 39945 $
//    Release    : CoreSight-SoC-TM100-r3p2-00rel0
//-----------------------------------------------------------------------------
//  Purpose             : PCLK domain register module for the TPIU block.
//                      : Contains Management registers, other static registers
//                        and the formatter/flush control register
//-----------------------------------------------------------------------------

module cxtpiu_reg_p  (
  // Inputs
  pclkdbg, pclkendbg, presetdbgn, pwritedbg, rd_wr_req, paddrdbg,
  paddrdbg31, pwdatadbg, ffcr_f_on_man_reg, trg_running, triggered,
  tpmaxdatasize,
  // Outputs
  ffcr_stop_reg, ffcr_trig_reg, ffcr_flsh_reg, ffcr_ften_reg, read_data_p,
  itc_r_reg, device_un_locked
  );

`include "cxtpiu_constants.v"

  // Inputs
  input         pclkdbg;          // APB clock
  input         pclkendbg;        // APB clock enable
  input         presetdbgn;       // APB asychronous reset active low
  input         pwritedbg;        // APB Write/!Read signal
  input         rd_wr_req;        // Register read signal from the APB interface
  input [11:2]  paddrdbg;         // APB Address bus
  input         paddrdbg31;       // APB address marker to bypass lock access
  input [31:0]  pwdatadbg;        // APB Write data bus
  input         ffcr_f_on_man_reg;// FFCR FOnMan register
  input         trg_running;      // Indicate Trigger Counter in operation
  input         triggered;        // Set on trigger_event
  input [4:0]   tpmaxdatasize;    // Input from external tie-off

  // Outputs
  output [1:0]  ffcr_stop_reg;    // Formatter stop control register
  output [2:0]  ffcr_trig_reg;    // Formatter trigger control register
  output [1:0]  ffcr_flsh_reg;    // Formatter flush control register
  output [1:0]  ffcr_ften_reg;    // Formatter format enable register
  output [31:0] read_data_p;      // Read data bus to the APB interface
  output        itc_r_reg;        // Integration mode control register
  output        device_un_locked; // Passed back to all blocks to mask Writes

  // ---------------------------------------------------------------------------
  //                            Register Module
  //                            ===============
  // ---------------------------------------------------------------------------
  //
  // Overview
  // ========
  // pclkdbg domain register block for the TPIU module.
  // Contains:
  //  All CS Management Registers
  //  Supported Port Size Register
  //  Supported Test Modes Register
  //  Formatter & Flush Control Register
  //  Supported Trigger Counter Modes Register
  //  Integration registers
  // ---------------------------------------------------------------------------

  // ---------------------------------------------------------------------------
  // Internal wire declarations
  // ---------------------------------------------------------------------------

  // Global Read/Write Enables
  wire          reg_write;    // masked Write with lock access
  wire          raw_reg_write;// unmasked reg_write
  wire          reg_read;

  // Formatter & Flush Control
  wire          fm_fl_ctl_wr_en;
  wire          fm_fl_ctl_rd_en;
  wire [31:0]   fm_fl_ctl_rd_data;
  wire [1:0]    ffcr_ften_reg;
  wire [1:0]    ffcr_ften_reg_int;
  reg  [1:0]    ffcrftenreg_cdc_check;
  wire [1:0]    ffcr_flsh_reg;
  reg  [1:0]    ffcr_flsh_reg_int; // Internal version of ffcr_flsh_reg
  wire [2:0]    ffcr_trig_reg;
  reg  [2:0]    ffcr_trig_reg_int; // Internal version of ffcr_trig_reg
  wire [1:0]    ffcr_stop_reg;
  reg  [1:0]    ffcr_stop_reg_int; // Internal version of ffcr_stop_reg

  // Supported Port Sizes
  wire [30:0]   tp_present_dec;
  wire          sup_port_size_rd_en;
  wire [31:0]   sup_port_size_rd_data;

  // Supported Trigger Modes
  wire          sup_trig_count_rd_en;
  wire [31:0]   sup_trig_count_rd_data;

  // Supported Test Modes
  wire          sup_test_mode_rd_en;
  wire [31:0]   sup_test_mode_rd_data;

  // Integration Mode Control
  wire          itc_r_reg;
  reg           itc_r_reg_int;
  wire          itc_r_wr_en;
  wire          itc_r_rd_en;
  wire [31:0]   itc_r_rd_data;

  // Claim Tag
  wire          claim_tag_wr_en;
  wire          claim_set_rd_en;
  wire          claim_clr_rd_en;
  reg  [3:0]    claim_tag_reg;
  wire [3:0]    next_claim_tag_reg;
  wire [31:0]   claim_set_rd_data;
  wire [31:0]   claim_clr_rd_data;

  // Lock Access
  wire          device_un_locked;
  wire          device_un_locked_int;
  reg           deviceunlocked_cdc_check;
  wire          lock_access_wr_en;
  wire          next_locked;

  // Lock Status
  wire          sw_lck_sts_rd_en;
  wire [31:0]   sw_lck_sts_rd_data;

  // Device ID
  wire          dev_id_rd_en;
  wire [31:0]   dev_id_rd_data;

  // Device Type
  wire          dev_type_rd_en;
  wire [31:0]   dev_type_rd_data;

  // Peripheral Information
  wire          periph_id_0_rd_en;
  wire          periph_id_1_rd_en;
  wire          periph_id_2_rd_en;
  wire          periph_id_3_rd_en;
  wire          periph_id_4_rd_en;
  wire [31:0]   periph_id_0_rd_data;
  wire [31:0]   periph_id_1_rd_data;
  wire [31:0]   periph_id_2_rd_data;
  wire [31:0]   periph_id_3_rd_data;
  wire [31:0]   periph_id_4_rd_data;

  reg [3:0]     periph_id_3_rev_and_reg; // Register for Rev-And data

  // Component Identifiers
  wire          comp_id_0_rd_en;
  wire          comp_id_1_rd_en;
  wire          comp_id_2_rd_en;
  wire          comp_id_3_rd_en;
  wire [31:0]   comp_id_0_rd_data;
  wire [31:0]   comp_id_1_rd_data;
  wire [31:0]   comp_id_2_rd_data;
  wire [31:0]   comp_id_3_rd_data;

  // ---------------------------------------------------------------------------
  // Main body of code
  // =================
  // ---------------------------------------------------------------------------

  // ---------------------------------------------------------------------------
  // Assigning the reg_write and reg_read signals.
  // ---------------------------------------------------------------------------

  // This is the masked version of the write enable
  assign reg_write     = rd_wr_req & pwritedbg & (device_un_locked_int | paddrdbg31);
  assign reg_read      = rd_wr_req & ~pwritedbg;

  // create a special non-masked write enable for writing to the lock access
  // register
  assign raw_reg_write  = rd_wr_req & pwritedbg;

  // ---------------------------------------------------------------------------
  // Supported port sizes register : Offset 0x000 ( R )
  // ---------------------------------------------------------------------------
  // Decode the external tie-off that indicates the maximum number of data
  // pins available for tracedata. (Also mask with 'define)
  assign tp_present_dec = {(tpmaxdatasize == 5'b11111),
                         (tpmaxdatasize == 5'b11110),
                         (tpmaxdatasize == 5'b11101),
                         (tpmaxdatasize == 5'b11100),
                         (tpmaxdatasize == 5'b11011),
                         (tpmaxdatasize == 5'b11010),
                         (tpmaxdatasize == 5'b11001),
                         (tpmaxdatasize == 5'b11000),
                         (tpmaxdatasize == 5'b10111),
                         (tpmaxdatasize == 5'b10110),
                         (tpmaxdatasize == 5'b10101),
                         (tpmaxdatasize == 5'b10100),
                         (tpmaxdatasize == 5'b10011),
                         (tpmaxdatasize == 5'b10010),
                         (tpmaxdatasize == 5'b10001),
                         (tpmaxdatasize == 5'b10000),
                         (tpmaxdatasize == 5'b01111),
                         (tpmaxdatasize == 5'b01110),
                         (tpmaxdatasize == 5'b01101),
                         (tpmaxdatasize == 5'b01100),
                         (tpmaxdatasize == 5'b01011),
                         (tpmaxdatasize == 5'b01010),
                         (tpmaxdatasize == 5'b01001),
                         (tpmaxdatasize == 5'b01000),
                         (tpmaxdatasize == 5'b00111),
                         (tpmaxdatasize == 5'b00110),
                         (tpmaxdatasize == 5'b00101),
                         (tpmaxdatasize == 5'b00100),
                         (tpmaxdatasize == 5'b00011),
                         (tpmaxdatasize == 5'b00010),
                         (tpmaxdatasize == 5'b00001)};

  assign sup_port_size_rd_en    = reg_read & (paddrdbg == CXTPIU_SUPPORTSIZE_ADD);
  // mask in tie-offs
  assign sup_port_size_rd_data  = (CXTPIU_SUPPORTSIZE_VAL &
                               {tp_present_dec[30],
                                |tp_present_dec[30:29],
                                |tp_present_dec[30:28],
                                |tp_present_dec[30:27],
                                |tp_present_dec[30:26],
                                |tp_present_dec[30:25],
                                |tp_present_dec[30:24],
                                |tp_present_dec[30:23],
                                |tp_present_dec[30:22],
                                |tp_present_dec[30:21],
                                |tp_present_dec[30:20],
                                |tp_present_dec[30:19],
                                |tp_present_dec[30:18],
                                |tp_present_dec[30:17],
                                |tp_present_dec[30:16],
                                |tp_present_dec[30:15],
                                |tp_present_dec[30:14],
                                |tp_present_dec[30:13],
                                |tp_present_dec[30:12],
                                |tp_present_dec[30:11],
                                |tp_present_dec[30:10],
                                |tp_present_dec[30:9],
                                |tp_present_dec[30:8],
                                |tp_present_dec[30:7],
                                |tp_present_dec[30:6],
                                |tp_present_dec[30:5],
                                |tp_present_dec[30:4],
                                |tp_present_dec[30:3],
                                |tp_present_dec[30:2],
                                |tp_present_dec[30:1],
                                |tp_present_dec[30:0],
                                1'b1}); // |tp_present_dec[31:0] always true !

  // ---------------------------------------------------------------------------
  // Supported Trigger Counter Modes: Offset 0x100 ( R )
  // ---------------------------------------------------------------------------
  assign sup_trig_count_rd_en   = reg_read & (paddrdbg == CXTPIU_SUPTRIG_ADD);
  assign sup_trig_count_rd_data = {{14{1'b0}}, trg_running, triggered,
                               {7{1'b0}},CXTPIU_SUPTRIG_VAL};

  // ---------------------------------------------------------------------------
  // Supported test modes register : Offset 0x200 ( R )
  // ---------------------------------------------------------------------------
  assign sup_test_mode_rd_en    = reg_read & (paddrdbg == CXTPIU_SUPTEST_ADD);
  assign sup_test_mode_rd_data  = {{12{1'b0}},CXTPIU_SUPTEST_VAL};

  // ---------------------------------------------------------------------------
  // Formatter and Flush control register: Offset 0x304 ( R/W )
  // ---------------------------------------------------------------------------
  // Controls the formatting and flushing within the ATB formatter.
  // [13] StopTrig - Stop the formatter once a trigger event has been observed.
  // [12] StopFl   - Stop the formatter once a flush has completed.
  // [10] TrigFl   - Indicate a trigger on flush completion.
  //  [9] TrigEvt  - Indicate a trigger on a trigger event.
  //  [8] TrigIn   - Indicate a trigger on trigin being asserted
  //* [6] FOnMan   - Manually generate a flush. Cleared when flush completed.
  //  [5] FOnTrig  - Generate flush via trigger event.
  //  [4] FOnFlIn  - Generate a flush via flushin interface.
  //  [1] EnFCont  - Enable continuous formatting.
  //  [0] EnFTC    - Enable / disable formatting.
  //
  //*[6] FOnMan has moved to RegA, as it needs to be cleared when a flush
  // completes

  always @(posedge pclkdbg or negedge presetdbgn)
    begin : s_fmffcrctlwr
      if (!presetdbgn)
        begin
           ffcrftenreg_cdc_check  <= 2'b00;
          ffcr_flsh_reg_int <= 2'b00;
          ffcr_trig_reg_int <= 3'b000;
          ffcr_stop_reg_int <= 2'b00;
        end
      else
        if(fm_fl_ctl_wr_en)
          begin
             ffcrftenreg_cdc_check  <= pwdatadbg[1:0];
            ffcr_flsh_reg_int <= pwdatadbg[5:4];
            ffcr_trig_reg_int <= pwdatadbg[10:8];
            ffcr_stop_reg_int <= pwdatadbg[13:12];
          end
    end // block: s_fmffcrctlwr
  assign ffcr_trig_reg = ffcr_trig_reg_int;
  assign ffcr_stop_reg = ffcr_stop_reg_int;
  assign ffcr_flsh_reg = ffcr_flsh_reg_int;

  assign fm_fl_ctl_wr_en    = pclkendbg & reg_write & (paddrdbg == CXTPIU_FFCR_ADD);
  assign fm_fl_ctl_rd_en    = reg_read  & (paddrdbg == CXTPIU_FFCR_ADD);
  assign fm_fl_ctl_rd_data  = {{18{1'b0}}, ffcr_stop_reg_int,
                           1'b0, ffcr_trig_reg_int,
                           1'b0, ffcr_f_on_man_reg, ffcr_flsh_reg_int,
                           2'b00, ffcr_ften_reg_int};

  // ---------------------------------------------------------------------------
  // CoreSight Management Registers
  //

  // ---------------------------------------------------------------------------
  // Integration Mode Control register    : Offset 0xF00 ( RW )
  // ---------------------------------------------------------------------------
  always @(posedge pclkdbg or negedge presetdbgn)
    if (!presetdbgn)
      itc_r_reg_int <= 1'b0;
    else
      if (itc_r_wr_en)
        itc_r_reg_int <= pwdatadbg[0];
  assign itc_r_reg = itc_r_reg_int;

  assign itc_r_wr_en   = pclkendbg & reg_write & (paddrdbg == CXTPIU_ITCTRL_ADD);
  assign itc_r_rd_en   = reg_read & (paddrdbg == CXTPIU_ITCTRL_ADD);
  assign itc_r_rd_data = { {31{1'b0}}, itc_r_reg_int};

  // ---------------------------------------------------------------------------
  // Claim Tag register      : Offset 0xFA0 ( RW )
  //                         : Offset 0xFA4 ( RW )
  // ---------------------------------------------------------------------------
  always @(posedge pclkdbg or negedge presetdbgn)
    if (!presetdbgn)
      claim_tag_reg <= 4'h0;
    else
      if (claim_tag_wr_en)
        claim_tag_reg <= next_claim_tag_reg;

  // Set location is ORed with current value to set bits;
  // Clear location is ANDed with current value to clear bits (invert mask)
  assign claim_tag_wr_en     = (pclkendbg & reg_write &
                             ( (paddrdbg == CXTPIU_CLAIMSET_ADD) |
                               (paddrdbg == CXTPIU_CLAIMCLR_ADD) ) );
  assign next_claim_tag_reg  = (paddrdbg == CXTPIU_CLAIMSET_ADD) ?
                              (claim_tag_reg |  pwdatadbg[3:0]) :
                              (claim_tag_reg & ~pwdatadbg[3:0]) ;


  assign claim_set_rd_en     = reg_read & (paddrdbg == CXTPIU_CLAIMSET_ADD);
  assign claim_clr_rd_en     = reg_read & (paddrdbg == CXTPIU_CLAIMCLR_ADD);
  assign claim_set_rd_data   = {{28{1'b0}}, CXTPIU_CLAIMSET_VAL};
  assign claim_clr_rd_data   = {{28{1'b0}}, claim_tag_reg[3:0]};

  // ---------------------------------------------------------------------------
  // Lock Access register    : Offset 0xFB0 ( W )
  // ---------------------------------------------------------------------------
  // Modifications are ignored for paddrdbg31==1

  // Device is locked from reset
  always @(posedge pclkdbg or negedge presetdbgn)
    if (!presetdbgn)
       deviceunlocked_cdc_check  <= 1'b0;
    else
      if (lock_access_wr_en)
         deviceunlocked_cdc_check  <= next_locked;

  assign lock_access_wr_en = (pclkendbg & raw_reg_write & ~paddrdbg31
                           & (paddrdbg == CXTPIU_LOCKACCESS_ADD) );
  assign next_locked     = (pwdatadbg == 32'hC5ACCE55);

  // ---------------------------------------------------------------------------
  // Lock Status register    : Offset 0xFB4 ( R )
  // ---------------------------------------------------------------------------
  // This either reads as zero for paddrdbg31==1 or present for paddrdbg31==0

  // paddrdbg31 == 0
  assign sw_lck_sts_rd_en   = (reg_read & (paddrdbg == CXTPIU_LOCKSTATUS_ADD)
                           & ~paddrdbg31);

  assign sw_lck_sts_rd_data = { {29{1'b0}},
                              CXTPIU_LOCKSTATUS_8BIT_VAL,
                              ~device_un_locked_int,
                              CXTPIU_LOCKSTATUS_PRESENT_VAL};

  // ---------------------------------------------------------------------------
  // Authentication Status register: Offset 0xFB8 ( R )
  // Not implemented in this component and hence RAZ
  // ---------------------------------------------------------------------------

  // ---------------------------------------------------------------------------
  // Device Identity register: Offset 0xFC8 ( R )
  // ---------------------------------------------------------------------------
  assign dev_id_rd_en        = reg_read & (paddrdbg == CXTPIU_DEVID_ADD);
  assign dev_id_rd_data      = CXTPIU_DEVID_VAL;

  // ---------------------------------------------------------------------------
  // Device Type register    : Offset 0xFCC ( R )
  // ---------------------------------------------------------------------------
  assign dev_type_rd_en      = reg_read & (paddrdbg == CXTPIU_DEVTYPE_ADD);
  assign dev_type_rd_data    = {{24{1'b0}},CXTPIU_DEVTYPE_VAL};

  // ---------------------------------------------------------------------------
  // Peripheral ID4 register : Offset 0xFD0 ( R )
  // ---------------------------------------------------------------------------
  assign periph_id_4_rd_en    = reg_read & (paddrdbg == CXTPIU_PERIPHID4_ADD);
  assign periph_id_4_rd_data  = {{24{1'b0}},CXTPIU_PERIPHID4_VAL};

  // ---------------------------------------------------------------------------
  // Peripheral ID5 register : Offset 0xFD4 ( R )
  // Peripheral ID6 register : Offset 0xFD8 ( R )
  // Peripheral ID7 register : Offset 0xFDC ( R )
  // These registers are reserved and RAZ
  // ---------------------------------------------------------------------------

  // ---------------------------------------------------------------------------
  // Peripheral ID0 register : Offset 0xFE0 ( R )
  // ---------------------------------------------------------------------------
  assign periph_id_0_rd_en    = reg_read & (paddrdbg == CXTPIU_PERIPHID0_ADD);
  assign periph_id_0_rd_data  = {{24{1'b0}},CXTPIU_PERIPHID0_VAL};

  // ---------------------------------------------------------------------------
  // Peripheral ID1 register : Offset 0xFE4 ( R )
  // ---------------------------------------------------------------------------
  assign periph_id_1_rd_en    = reg_read & (paddrdbg == CXTPIU_PERIPHID1_ADD);
  assign periph_id_1_rd_data  = {{24{1'b0}},CXTPIU_PERIPHID1_VAL};

  // ---------------------------------------------------------------------------
  // Peripheral ID2 register : Offset 0xFE8 ( R )
  // ---------------------------------------------------------------------------
  assign periph_id_2_rd_en    = reg_read & (paddrdbg == CXTPIU_PERIPHID2_ADD);
  assign periph_id_2_rd_data  = {{24{1'b0}},CXTPIU_PERIPHID2_VAL};

  // ---------------------------------------------------------------------------
  // Peripheral ID3 register : Offset 0xFEC ( R )
  // ---------------------------------------------------------------------------
  assign periph_id_3_rd_en    = reg_read & (paddrdbg == CXTPIU_PERIPHID3_ADD);
  assign periph_id_3_rd_data  = {{24{1'b0}}, periph_id_3_rev_and_reg[3:0],
                            CXTPIU_PERIPHID3_CUSTOM_VAL };

  // The Rev-And data (bits 7:4) should be driven from a register so that it
  // can be easily changed in the netlist.
  //
  // No Reset is required because this register cannot be read in the first
  // cycle after reset.
  always @(posedge pclkdbg)
    begin
      periph_id_3_rev_and_reg[3:0] <= CXTPIU_PERIPHID3_REVAND_VAL;
    end

  // ---------------------------------------------------------------------------
  // Component ID0 register : Offset 0xFF0 ( R )
  // ---------------------------------------------------------------------------
  assign comp_id_0_rd_en    = reg_read & (paddrdbg == CXTPIU_COMPONID0_ADD);
  assign comp_id_0_rd_data  = {{24{1'b0}},CXTPIU_COMPONID0_VAL};

  // ---------------------------------------------------------------------------
  // Component ID1 register : Offset 0xFF4 ( R )
  // ---------------------------------------------------------------------------
  assign comp_id_1_rd_en    = reg_read & (paddrdbg == CXTPIU_COMPONID1_ADD);
  assign comp_id_1_rd_data  = {{24{1'b0}},CXTPIU_COMPONID1_VAL};

  // ---------------------------------------------------------------------------
  // Component ID2 register : Offset 0xFF8 ( R )
  // ---------------------------------------------------------------------------
  assign comp_id_2_rd_en    = reg_read & (paddrdbg == CXTPIU_COMPONID2_ADD);
  assign comp_id_2_rd_data  = {{24{1'b0}},CXTPIU_COMPONID2_VAL};

  // ---------------------------------------------------------------------------
  // Component ID3 register : Offset 0xFFC ( R )
  // ---------------------------------------------------------------------------
  assign comp_id_3_rd_en    = reg_read & (paddrdbg == CXTPIU_COMPONID3_ADD);
  assign comp_id_3_rd_data  = {{24{1'b0}},CXTPIU_COMPONID3_VAL};

  // ---------------------------------------------------------------------------
  // The read data is driven out from the register module.
  // ---------------------------------------------------------------------------
  assign read_data_p = (
                      ({32{sup_port_size_rd_en}} & sup_port_size_rd_data) |
                      ({32{sup_trig_count_rd_en}}& sup_trig_count_rd_data)|
                      ({32{sup_test_mode_rd_en}} & sup_test_mode_rd_data) |
                      ({32{fm_fl_ctl_rd_en}}     & fm_fl_ctl_rd_data)     |
                      ({32{itc_r_rd_en}}        & itc_r_rd_data)        |
                      ({32{claim_set_rd_en}}    & claim_set_rd_data)    |
                      ({32{claim_clr_rd_en}}    & claim_clr_rd_data)    |
                      ({32{sw_lck_sts_rd_en}}    & sw_lck_sts_rd_data)    |
                      ({32{dev_id_rd_en}}       & dev_id_rd_data)       |
                      ({32{dev_type_rd_en}}     & dev_type_rd_data)     |
                      ({32{periph_id_0_rd_en}}   & periph_id_0_rd_data)   |
                      ({32{periph_id_1_rd_en}}   & periph_id_1_rd_data)   |
                      ({32{periph_id_2_rd_en}}   & periph_id_2_rd_data)   |
                      ({32{periph_id_3_rd_en}}   & periph_id_3_rd_data)   |
                      ({32{periph_id_4_rd_en}}   & periph_id_4_rd_data)   |
                      ({32{comp_id_0_rd_en}}     & comp_id_0_rd_data)     |
                      ({32{comp_id_1_rd_en}}     & comp_id_1_rd_data)     |
                      ({32{comp_id_2_rd_en}}     & comp_id_2_rd_data)     |
                      ({32{comp_id_3_rd_en}}     & comp_id_3_rd_data)
                     );

`ifdef ARM_CDC_ON
        cdc_connect #(1,0) u_cdc_ffcrftenreg(
                .clk_launch(pclkdbg),
                .clk_capture(cxtpiu.u_cxtpiu_trace_sync.u_ffcr_ften_reg_0.clk),
                .d_in(ffcrftenreg_cdc_check),
                .d_out_async(ffcr_ften_reg_int)
                );
`else
        assign ffcr_ften_reg_int = ffcrftenreg_cdc_check;
`endif
assign ffcr_ften_reg = ffcr_ften_reg_int;

`ifdef ARM_CDC_ON
        cdc_connect u_cdc_deviceunlocked(
                .clk_launch(pclkdbg),
                .clk_capture(cxtpiu.u_cxtpiu_reg_t.traceclkin),
                .d_in(deviceunlocked_cdc_check),
                .d_out_async(device_un_locked_int)
                );
`else
        assign device_un_locked_int = deviceunlocked_cdc_check;
`endif
assign device_un_locked = device_un_locked_int;
endmodule // cxtpiu_reg_p
