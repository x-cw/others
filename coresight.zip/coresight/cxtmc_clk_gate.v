//-----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2009, 2010 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//      SVN Information
//
//      Checked In          :  2010-05-05 09:27:56 +0100 (Wed, 05 May 2010) 
//
//      Revision            :  7505 
//
//      Release Information : TM961-BU-50000-r0p1-00rel0
//-----------------------------------------------------------------------------
//      Purpose:
//      Gated-clock cell model
//-----------------------------------------------------------------------------

module cxtmc_clk_gate (
  // Inputs
  input wire  CLK,           // free running clock
  input wire  clk_enable_i,  // clock enable

  // Outputs
  output wire clk_o          // gated clock
  );

`ifdef FPGA

  assign clk_o = CLK & clk_enable_i;

`else

  //----------------------------------------------------------------------------
  // Latch
  //----------------------------------------------------------------------------
  reg clk_en_lat;

  always @ (CLK or clk_enable_i)
    begin
      if (~CLK)
        clk_en_lat <= clk_enable_i;
    end

  //----------------------------------------------------------------------------
  // Output assignment
  //----------------------------------------------------------------------------
  assign clk_o = CLK & clk_en_lat;

`endif

endmodule
