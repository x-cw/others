//-----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2010-2013 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//  Version and Release Control Information:
//
//  Checked In          : $Date: 2011-07-12 17:44:35 +0530 (Tue, 12 Jul 2011) $
//
//  File Revision       : $Revision: 18204 $
//
//  Release Information : CoreSight-SoC-TM100-r3p1-00rel0
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// Abstract : CoreSight Time Stamp Generator - APB Register Block
//-----------------------------------------------------------------------------
//
// cxtsgenregblk - Register block with APB interface
//-----------------------------------------------------------------------------

module cxtsgenregblk (

  // Clock and Reset
  input wire         clk,
  input wire         resetn,

  // Halt on debug
  input wire         hltdbg,

  // Up-Counter interface
  output wire        enablecnt,
  output wire [63:0] newcnt,
  output wire        newcntwren,
  input wire [31:0]  currcntl,
  input wire [31:0]  currcntu,

  // APB Read interface
  input wire         pselread,      // APB select line
  input wire         penableread,   // APB enable line
  input wire         pwriteread,    // Write/Read control line
  input wire  [9:0]  paddrread,     // APB address line to select register
  output wire        preadyread,    // APB transfer completion indication
  output wire        pslverrread,   // APB response
  output wire [31:0] prdataread,    // APB read data line

  // APB Control interface
  input wire         pselctrl,      // APB select line
  input wire         penablectrl,   // APB enable line
  input wire         pwritectrl,    // Write/Read control line
  input wire  [9:0]  paddrctrl,     // APB address line to select register
  input wire  [31:0] pwdatactrl,    // APB data line
  output reg         preadyctrl,    // APB transfer completion indication
  output wire        pslverrctrl,   // APB response
  output wire [31:0] prdatactrl     // APB read data line

  );

//-----------------------------------------------------------------------------
// Local parameters definitions
//-----------------------------------------------------------------------------
  localparam TSG_CTRL_CNTCR     = 10'h000; // Counter control register
  localparam TSG_CTRL_CNTSR     = 10'h001; // Counter status register
  localparam TSG_CTRL_CNTCVL    = 10'h002; // Current value of counter[31:0]
  localparam TSG_CTRL_CNTCVU    = 10'h003; // Current value of counter[63:32]
  localparam TSG_CTRL_CNTFID0   = 10'h008; // Base Frequency ID

  localparam TSG_READ_CNTCVL    = 10'h000; // Current value of counter[31:0]
  localparam TSG_READ_CNTCVU    = 10'h001; // Current value of counter[63:32]

  localparam CSR_PERIPH_ID_4    = 10'h3F4; // Peripheral ID4 register
  localparam CSR_PERIPH_ID_5    = 10'h3F5; // Peripheral ID5 register
  localparam CSR_PERIPH_ID_6    = 10'h3F6; // Peripheral ID6 register
  localparam CSR_PERIPH_ID_7    = 10'h3F7; // Peripheral ID7 register
  localparam CSR_PERIPH_ID_0    = 10'h3F8; // Peripheral ID0 register
  localparam CSR_PERIPH_ID_1    = 10'h3F9; // Peripheral ID1 register
  localparam CSR_PERIPH_ID_2    = 10'h3FA; // Peripheral ID2 register
  localparam CSR_PERIPH_ID_3    = 10'h3FB; // Peripheral ID3 register
  localparam CSR_COMP_ID_0      = 10'h3FC; // Component ID0 register
  localparam CSR_COMP_ID_1      = 10'h3FD; // Component ID1 register
  localparam CSR_COMP_ID_2      = 10'h3FE; // Component ID2 register
  localparam CSR_COMP_ID_3      = 10'h3FF; // Component ID3 register

//-----------------------------------------------------------------------------
// Values for read-only fields
//-----------------------------------------------------------------------------
  localparam CSR_PERIPHID4_VAL  = 8'h04;    // Peripheral ID4 reg
  localparam CSR_PERIPHID5_VAL  = 8'h00;    // Peripheral ID5 reg
  localparam CSR_PERIPHID6_VAL  = 8'h00;    // Peripheral ID6 reg
  localparam CSR_PERIPHID7_VAL  = 8'h00;    // Peripheral ID7 reg
  localparam CSR_PERIPHID0_VAL  = 8'h01;    // Peripheral ID0 reg
  localparam CSR_PERIPHID1_VAL  = 8'hB1;    // Peripheral ID1 reg
  localparam CSR_PERIPHID2_VAL  = 8'h1B;    // Peripheral ID2 reg
  localparam PERIPHID3_CUSTOM   = 4'h0;     // Peripheral ID3 value
  localparam PERIPHID3_REVAND   = 4'h0;     // Peripheral ID3 value
  localparam CSR_COMPID0_VAL    = 8'h0D;    // Component ID0 reg
  localparam CSR_COMPID1_VAL    = 8'hF0;    // Component ID1 reg
  localparam CSR_COMPID2_VAL    = 8'h05;    // Component ID2 reg
  localparam CSR_COMPID3_VAL    = 8'hB1;    // Component ID3 reg

//----------------------------------------------------------------------------
// Wires
//----------------------------------------------------------------------------
  wire        preadyctrl_nxt;
  wire        apb_ctrl_nxt;
  wire [31:0] read_data;
  wire        cntcr_sel;
  wire        cntsr_sel;
  wire        cntcvl_sel;
  wire        cntcvu_sel;
  wire        cntfid0_sel;
  wire        periph_id_0_sel;
  wire        periph_id_1_sel;
  wire        periph_id_2_sel;
  wire        periph_id_3_sel;
  wire        periph_id_4_sel;
  wire        periph_id_5_sel;
  wire        periph_id_6_sel;
  wire        periph_id_7_sel;
  wire        comp_id_0_sel;
  wire        comp_id_1_sel;
  wire        comp_id_2_sel;
  wire        comp_id_3_sel;
  wire        reg_read_read;
  wire        reg_read;
  wire        reg_write;
  wire        en_cnt_reg_nxt;
  wire        en_hlt_dbg_reg_nxt;
  wire        hltdbg_reg_en;
  wire        dbg_hltd_reg_nxt;
  wire        dbg_hltd_reg_en;
  wire        newcntl_reg_en;
  wire        newcntl_vld_reg_nxt;
  wire [31:0] cntfid0_reg_nxt;
  wire        reg_read_ctrl;
  wire        cntcr_rd_en;
  wire        cntsr_rd_en;
  wire        cntcvl_rd_en;
  wire        cntcvu_rd_en;
  wire        cntfid0_rd_en;
  wire        periph_id_0_rd_en;
  wire        periph_id_1_rd_en;
  wire        periph_id_2_rd_en;
  wire        periph_id_3_rd_en;
  wire        periph_id_4_rd_en;
  wire        periph_id_5_rd_en;
  wire        periph_id_6_rd_en;
  wire        periph_id_7_rd_en;
  wire        comp_id_0_rd_en;
  wire        comp_id_1_rd_en;
  wire        comp_id_2_rd_en;
  wire        comp_id_3_rd_en;
  wire [31:0] cntcr_rd_data;
  wire [31:0] cntsr_rd_data;
  wire [31:0] cntcvl_rd_data;
  wire [31:0] cntcvu_rd_data;
  wire [31:0] cntfid0_rd_data;
  wire [31:0] periph_id_0_rd_data;
  wire [31:0] periph_id_1_rd_data;
  wire [31:0] periph_id_2_rd_data;
  wire [31:0] periph_id_4_rd_data;
  wire [31:0] periph_id_3_rd_data;
  wire [31:0] periph_id_5_rd_data;
  wire [31:0] periph_id_6_rd_data;
  wire [31:0] periph_id_7_rd_data;
  wire [31:0] comp_id_0_rd_data;
  wire [31:0] comp_id_1_rd_data;
  wire [31:0] comp_id_2_rd_data;
  wire [31:0] comp_id_3_rd_data;

  wire [9:0]  apb_addr;
  wire        preadyread_nxt;
  wire        apb_read_new_nxt;
  wire        newcntwren_int;

//------------------------------------------------------------------------------
// Reg declarations
//------------------------------------------------------------------------------

  reg [9:0]  paddrctrl_reg;
  reg [3:0]  revand_reg;
  reg        apb_ctrl_new;
  reg [31:0] apb_wdata;
  reg        pwritectrl_reg;
  reg        en_cnt_reg;
  reg        en_hlt_dbg_reg;
  reg        hltdbg_reg;
  reg        dbg_hltd_reg;
  reg [31:0] newcntl_reg;
  reg        newcntl_vld_reg;
  reg [31:0] cntfid0_reg;

  reg [9:0]  paddrread_reg;
  reg        apb_read_new;

  reg [31:0] prdata;
  reg        preadyread_q;

//============================================================================
//
// Main body of code
//
//============================================================================

//-----------------------------------------------------------------------------
// Control inteface
// APB registered address, write data and psel
//-----------------------------------------------------------------------------
  always @(posedge clk or negedge resetn)
    begin
      if (!resetn) begin
        pwritectrl_reg <= 1'b0;
        paddrctrl_reg  <= {10{1'b0}};
        apb_wdata      <= {32{1'b0}};
      end else if (pselctrl) begin
        pwritectrl_reg <= pwritectrl;
        paddrctrl_reg  <= paddrctrl;
        apb_wdata      <= pwdatactrl;
      end
    end

//-----------------------------------------------------------------------------
// Ready is generated in response to a valid read/write access
//-----------------------------------------------------------------------------
  assign preadyctrl_nxt = ~(pselctrl & ~penablectrl & ~pwritectrl);

  always @(posedge clk or negedge resetn)
    begin
      if (!resetn)
        preadyctrl  <= 1'b1;
      else if (pselctrl)
        preadyctrl  <= preadyctrl_nxt;
    end

  assign pslverrctrl = 1'b0;

//-----------------------------------------------------------------------------
// transaction is valid on internal interface
//  - as soon as registered APB first phase is set
//-----------------------------------------------------------------------------
  assign apb_ctrl_nxt = (pselctrl & ~penablectrl);

  always @(posedge clk or negedge resetn)
    begin
      if (!resetn)
        apb_ctrl_new  <= 1'b0;
      else if (pselctrl)
        apb_ctrl_new  <= apb_ctrl_nxt;
    end

//-----------------------------------------------------------------------------
// Read only inteface
// APB registered address and psel
//-----------------------------------------------------------------------------
  always @(posedge clk or negedge resetn)
    begin
      if (!resetn) begin
        paddrread_reg  <= {10{1'b0}};
      end else if (pselread) begin
        paddrread_reg  <= paddrread;
      end
    end

//-----------------------------------------------------------------------------
// Ready is generated in response to a valid read only access on the read
// interface. Control interface has a higher priority over read-only interface.
// If the requests coincide then ready will be pulled low till control interface
// completes its transaction and then read-only interface will be serviced.
// Since APB is a two cycle interface,there is a cycle gap between two consective
// transactions and hence both the interfaces will be serviced which avoids
// read-only interface from waiting for an extended duration
//-----------------------------------------------------------------------------
  assign preadyread_nxt = preadyread_q ? ~(pselread & ~penableread & ~pwriteread) :
                            ~apb_ctrl_new;

  always @(posedge clk or negedge resetn)
    begin
      if (!resetn)
        preadyread_q  <= 1'b1;
      else if (pselread)
        preadyread_q  <= preadyread_nxt;
    end

  assign preadyread = preadyread_q;

  assign pslverrread = 1'b0;

//-----------------------------------------------------------------------------
// Transaction on the control interface is prioritized over read only interface
// If request on read only interface coincides with the control interface then
// the transaction on the read interface is extended until the control interface
// completes.
//-----------------------------------------------------------------------------
  assign apb_read_new_nxt = apb_read_new ? apb_ctrl_new :
                              pselread & (~penableread & ~pwriteread);

  always @(posedge clk or negedge resetn)
    begin
      if (!resetn)
        apb_read_new  <= 1'b0;
      else if (pselread)
        apb_read_new  <= apb_read_new_nxt;
    end

//-----------------------------------------------------------------------------
// Prevent toggle on the internal address bus when the device is not
// selected.
//-----------------------------------------------------------------------------
  assign apb_addr = apb_ctrl_new ? paddrctrl_reg : paddrread_reg;

  assign cntcr_sel   = ((apb_addr == TSG_CTRL_CNTCR) & apb_ctrl_new);
  assign cntsr_sel   = ((apb_addr == TSG_CTRL_CNTSR) & apb_ctrl_new);

  assign cntcvl_sel  = ((apb_addr == TSG_CTRL_CNTCVL) & apb_ctrl_new) |
                       ((apb_addr == TSG_READ_CNTCVL) &
                        ~apb_ctrl_new &
                         apb_read_new);
  assign cntcvu_sel  = ((apb_addr == TSG_CTRL_CNTCVU) & apb_ctrl_new) |
                       ((apb_addr == TSG_READ_CNTCVU) &
                        ~apb_ctrl_new &
                         apb_read_new);
  assign cntfid0_sel = ((apb_addr == TSG_CTRL_CNTFID0) & apb_ctrl_new);

  assign periph_id_0_sel = (apb_addr == CSR_PERIPH_ID_0);
  assign periph_id_1_sel = (apb_addr == CSR_PERIPH_ID_1);
  assign periph_id_2_sel = (apb_addr == CSR_PERIPH_ID_2);
  assign periph_id_3_sel = (apb_addr == CSR_PERIPH_ID_3);
  assign periph_id_4_sel = (apb_addr == CSR_PERIPH_ID_4);
  assign periph_id_5_sel = (apb_addr == CSR_PERIPH_ID_5);
  assign periph_id_6_sel = (apb_addr == CSR_PERIPH_ID_6);
  assign periph_id_7_sel = (apb_addr == CSR_PERIPH_ID_7);
  assign comp_id_0_sel   = (apb_addr == CSR_COMP_ID_0);
  assign comp_id_1_sel   = (apb_addr == CSR_COMP_ID_1);
  assign comp_id_2_sel   = (apb_addr == CSR_COMP_ID_2);
  assign comp_id_3_sel   = (apb_addr == CSR_COMP_ID_3);

//-----------------------------------------------------------------------------
// Register write being requested on the control interface
//-----------------------------------------------------------------------------
  assign reg_write = pwritectrl_reg & apb_ctrl_new;

//-----------------------------------------------------------------------------
// Counter control register will be visible only when pselctrl is asserted
//-----------------------------------------------------------------------------
  assign en_cnt_reg_nxt = cntcr_sel ? apb_wdata[0] : en_cnt_reg;

  always @(posedge clk or negedge resetn)
    begin
      if (!resetn)
        en_cnt_reg  <= 1'b0;
      else if (reg_write)
        en_cnt_reg  <= en_cnt_reg_nxt;
    end

  assign en_hlt_dbg_reg_nxt = cntcr_sel ? apb_wdata[1] : en_hlt_dbg_reg;

  always @(posedge clk or negedge resetn)
    begin
      if (!resetn)
        en_hlt_dbg_reg  <= 1'b0;
      else if (reg_write)
        en_hlt_dbg_reg  <= en_hlt_dbg_reg_nxt;
    end

//-----------------------------------------------------------------------------
// Register hltdbg input
//-----------------------------------------------------------------------------
  assign hltdbg_reg_en = hltdbg_reg ^ hltdbg;

  always @(posedge clk or negedge resetn)
    begin
      if (!resetn)
        hltdbg_reg  <= 1'b0;
      else if (hltdbg_reg_en)
        hltdbg_reg  <= hltdbg;
    end

  assign dbg_hltd_reg_nxt = en_hlt_dbg_reg & (hltdbg_reg | (newcntwren_int & hltdbg));

  assign dbg_hltd_reg_en = (dbg_hltd_reg_nxt ^ dbg_hltd_reg);

  always @(posedge clk or negedge resetn)
    begin
      if (!resetn)
        dbg_hltd_reg  <= 1'b0;
      else if (dbg_hltd_reg_en)
        dbg_hltd_reg  <= dbg_hltd_reg_nxt;
    end

//-----------------------------------------------------------------------------
// Up Counter interface
//-----------------------------------------------------------------------------
  assign enablecnt = ~((hltdbg_reg | (newcntwren_int & hltdbg)) & en_hlt_dbg_reg) & en_cnt_reg;

  assign newcntl_reg_en = (reg_write & cntcvl_sel);

  always @(posedge clk or negedge resetn)
    begin
      if (!resetn)
        newcntl_reg  <= {32{1'b0}};
      else if (newcntl_reg_en)
        newcntl_reg  <= apb_wdata;
    end

  assign newcnt = {apb_wdata, newcntl_reg};

  assign newcntl_vld_reg_nxt = newcntl_vld_reg ? ~cntcvu_sel :
                                cntcvl_sel;

  always @(posedge clk or negedge resetn)
    begin
      if (!resetn)
        newcntl_vld_reg  <= 1'b0;
      else if (reg_write)
        newcntl_vld_reg  <= newcntl_vld_reg_nxt;
    end

  assign newcntwren_int = reg_write & cntcvu_sel & newcntl_vld_reg;

  assign newcntwren = newcntwren_int;

//-----------------------------------------------------------------------------
// Base frequency ID register
//-----------------------------------------------------------------------------
  assign cntfid0_reg_nxt = cntfid0_sel ? apb_wdata : cntfid0_reg;

  always @(posedge clk or negedge resetn)
    begin
      if (!resetn)
        cntfid0_reg  <= {32{1'b0}};
      else if (reg_write)
        cntfid0_reg  <= cntfid0_reg_nxt;
    end

//-----------------------------------------------------------------------------
// read requests on control interface
//-----------------------------------------------------------------------------
  assign reg_read_ctrl  = ~pwritectrl_reg & apb_ctrl_new;

//-----------------------------------------------------------------------------
// Read requests on read-only interface. This request will be serviced only
// when control interface requests have completed
//-----------------------------------------------------------------------------
  assign reg_read_read  = ~apb_ctrl_new & apb_read_new;

  assign reg_read = reg_read_ctrl | reg_read_read;

//-----------------------------------------------------------------------------
// TSG registers
//-----------------------------------------------------------------------------
  assign cntcr_rd_en   = reg_read & cntcr_sel;
  assign cntsr_rd_en   = reg_read & cntsr_sel;
  assign cntcvl_rd_en  = reg_read & cntcvl_sel;
  assign cntcvu_rd_en  = reg_read & cntcvu_sel;
  assign cntfid0_rd_en = reg_read & cntfid0_sel;

//-----------------------------------------------------------------------------
// PERIPHIDx registers
//-----------------------------------------------------------------------------
  assign periph_id_0_rd_en = reg_read & periph_id_0_sel;
  assign periph_id_1_rd_en = reg_read & periph_id_1_sel;
  assign periph_id_2_rd_en = reg_read & periph_id_2_sel;
  assign periph_id_3_rd_en = reg_read & periph_id_3_sel;
  assign periph_id_4_rd_en = reg_read & periph_id_4_sel;
  assign periph_id_5_rd_en = reg_read & periph_id_5_sel;
  assign periph_id_6_rd_en = reg_read & periph_id_6_sel;
  assign periph_id_7_rd_en = reg_read & periph_id_7_sel;

//-----------------------------------------------------------------------------
// COMPIDx registers
//-----------------------------------------------------------------------------
  assign comp_id_0_rd_en = reg_read & comp_id_0_sel;
  assign comp_id_1_rd_en = reg_read & comp_id_1_sel;
  assign comp_id_2_rd_en = reg_read & comp_id_2_sel;
  assign comp_id_3_rd_en = reg_read & comp_id_3_sel;

//-----------------------------------------------------------------------------
// TSG registers
//-----------------------------------------------------------------------------
  assign cntcr_rd_data   = {{30{1'b0}}, en_hlt_dbg_reg, en_cnt_reg};
  assign cntsr_rd_data   = {{30{1'b0}}, dbg_hltd_reg, 1'b0};
  assign cntcvl_rd_data  = {currcntl};
  assign cntcvu_rd_data  = {currcntu};
  assign cntfid0_rd_data = {cntfid0_reg};

//-----------------------------------------------------------------------------
// PERIPHIDx registers
//-----------------------------------------------------------------------------
  assign periph_id_0_rd_data = {{24{1'b0}}, CSR_PERIPHID0_VAL};
  assign periph_id_1_rd_data = {{24{1'b0}}, CSR_PERIPHID1_VAL};
  assign periph_id_2_rd_data = {{24{1'b0}}, CSR_PERIPHID2_VAL};

//---------------------------------------------------------------------------
// Peripheral ID3 Register (PID3)
//---------------------------------------------------------------------------
  assign periph_id_3_rd_data[31:0] = {{24{1'b0}},           // 31:8
                                      revand_reg[3:0],      // 7:4
                                      PERIPHID3_CUSTOM[3:0] // 3:0
                                      };

//---------------------------------------------------------------------------
// The Rev-And data (bits 7:4) are driven from a register so that it
// can be easily changed in the netlist.
//---------------------------------------------------------------------------
  always @(posedge clk or negedge resetn)
    begin
      if (!resetn)
        revand_reg[3:0] <= PERIPHID3_REVAND[3:0];
      else
        revand_reg[3:0] <= PERIPHID3_REVAND[3:0];
    end

  assign periph_id_4_rd_data = {{24{1'b0}}, CSR_PERIPHID4_VAL};
  assign periph_id_5_rd_data = {{24{1'b0}}, CSR_PERIPHID5_VAL};
  assign periph_id_6_rd_data = {{24{1'b0}}, CSR_PERIPHID6_VAL};
  assign periph_id_7_rd_data = {{24{1'b0}}, CSR_PERIPHID7_VAL};

//---------------------------------------------------------------------------
// COMPIDx registers
//---------------------------------------------------------------------------
  assign comp_id_0_rd_data = {{24{1'b0}}, CSR_COMPID0_VAL};
  assign comp_id_1_rd_data = {{24{1'b0}}, CSR_COMPID1_VAL};
  assign comp_id_2_rd_data = {{24{1'b0}}, CSR_COMPID2_VAL};
  assign comp_id_3_rd_data = {{24{1'b0}}, CSR_COMPID3_VAL};

//-----------------------------------------------------------------------------
// Read data mux
//-----------------------------------------------------------------------------
  assign read_data = (
                      ({32{cntcr_rd_en}} & cntcr_rd_data) |
                      ({32{cntsr_rd_en}} & cntsr_rd_data) |
                      ({32{cntcvl_rd_en}} & cntcvl_rd_data) |
                      ({32{cntcvu_rd_en}} & cntcvu_rd_data) |
                      ({32{cntfid0_rd_en}} & cntfid0_rd_data) |
                      ({32{periph_id_0_rd_en}} & periph_id_0_rd_data) |
                      ({32{periph_id_1_rd_en}} & periph_id_1_rd_data) |
                      ({32{periph_id_2_rd_en}} & periph_id_2_rd_data) |
                      ({32{periph_id_3_rd_en}} & periph_id_3_rd_data) |
                      ({32{periph_id_4_rd_en}} & periph_id_4_rd_data) |
                      ({32{periph_id_5_rd_en}} & periph_id_5_rd_data) |
                      ({32{periph_id_6_rd_en}} & periph_id_6_rd_data) |
                      ({32{periph_id_7_rd_en}} & periph_id_7_rd_data) |
                      ({32{comp_id_0_rd_en}}   & comp_id_0_rd_data) |
                      ({32{comp_id_1_rd_en}}   & comp_id_1_rd_data) |
                      ({32{comp_id_2_rd_en}}   & comp_id_2_rd_data) |
                      ({32{comp_id_3_rd_en}}   & comp_id_3_rd_data)
                     );

//-----------------------------------------------------------------------------
// APB read data
//-----------------------------------------------------------------------------
  always @(posedge clk or negedge resetn)
    begin
      if (!resetn)
        prdata  <= {32{1'b0}};
      else if (reg_read)
        prdata  <= read_data;
    end

  assign prdatactrl = prdata;

  assign prdataread = prdata;

//----------------------------------------------------------------------------
// ASSERTIONS
//----------------------------------------------------------------------------

`ifdef ARM_ASSERT_ON

//-----------------------------------------------------------------------------
// Check if read-only interface gets higher priority than control interface
//-----------------------------------------------------------------------------
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxtsgenregblk - Read only interface getting higher priority over control interface")
      uzovl_cxtsgenregblk_incorrect_priority_chk
        (
         .clk         (clk),
         .reset_n     (resetn),
         .test_expr   (reg_read_read && apb_ctrl_new)
        );

`endif // ARM_ASSERT_ON

endmodule
