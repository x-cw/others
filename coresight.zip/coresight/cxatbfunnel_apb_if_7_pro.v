//------------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2003-2015 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//  Version and Release Control Information:
//
//  File Name           : cxatbfunnel_apb_if_xmlcfg.v.xsl
//
//  Checked In          : $Date: 2011-04-12 20:43:59 +0530 (Tue, 12 Apr 2011) $
//
//  File Revision       : $Revision: 15638 $
//
//  Release Information : CoreSight-SoC-TM100-r3p2-00rel0
//------------------------------------------------------------------------------
// Verilog-2001 (IEEE Std 1364-2001)
//----------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Abstract : CoreSight Trace Funnel (cxatbfunnel) - APB Interface Module
//------------------------------------------------------------------------------
//
// cxatbfunnel - CoreSight Trace Funnel
// -------------------------------------
//
// CoreSight AMBA Trace Bus (ATB) trace link device used to combine multiple
// trace sources into a single bus.
//
// cxatbfunnel_apb_if.v
// ----------------
//
// cxatbfunnel_apb_if.v provides the debug APB interface for programming the
// registers in the Trace Funnel.
//
// Instantiated blocks
// -------------------
// None
//------------------------------------------------------------------------------

module cxatbfunnel_apb_if_7_pro
  (
  // Inputs
  input wire         clk,
  input wire         pclkendbg,
  input wire         resetn,
  input wire         pseldbg,
  input wire         penabledbg,
  input wire         pwritedbg,
  input wire  [11:2] paddrdbg,
  input wire  [31:0] pwdatadbg,
  input wire  [31:0] read_data,

  // Outputs
  output reg         preadydbg,
  output wire [31:0] prdatadbg,
  output reg         reg_write,
  output wire        reg_read,
  output reg  [9:0]  reg_addr,
  output reg  [31:0] write_data
  );

  //----------------------------------------------------------------------------
  // Wires
  //----------------------------------------------------------------------------
  wire          next_reg_write;
  wire          next_preadydbg;
  wire          slave_select;
  wire          apb_clk_en;
  reg [2:0]     prdatadbg_23_21;
  reg [2:0]     prdatadbg_20_18;
  reg           prdatadbg_17;
  reg [1:0]     prdatadbg_16_15;
  reg [2:0]     prdatadbg_14_12;
  reg [3:0]     prdatadbg_11_8;
  reg           prdatadbg_7;
  reg [6:0]     prdatadbg_6_0;

  //---------------------------------------------------------------------------
  //
  // Main body of code
  // =================
  //
  //---------------------------------------------------------------------------

  //---------------------------------------------------------------------------
  // Sequential block for latching the interface signals.
  //---------------------------------------------------------------------------
  always @(posedge clk or negedge resetn)
    begin : p_apb_if
      if (!resetn)
        begin
          reg_addr   <= {10{1'b0}};
          write_data <= {32{1'b0}};
        end // if (!resetn)
      else
        if(apb_clk_en)
          begin
            reg_addr   <= paddrdbg;
            write_data <= pwdatadbg[31:0];
          end // if (apb_clk_en)
    end // block: p_apb_if

  //---------------------------------------------------------------------------
  // Sequential block for latching reg_write and reg_read signals.
  //---------------------------------------------------------------------------
  always @(posedge clk or negedge resetn)
    begin : p_reg_wr
      if (!resetn)
        begin
          reg_write  <= 1'b0;
        end // if (!resetn)
      else
        if(pclkendbg)
          begin
            reg_write  <= next_reg_write;
          end // if (pclkendbg)
    end // block: p_reg_wr


  //---------------------------------------------------------------------------
  // Bits 6:0 , 11:8 always exist and hence registered before driving prdatadbg
  //---------------------------------------------------------------------------
  always @(posedge clk or negedge resetn)
    begin : p_reg_prdata
      if (!resetn)
        begin
          prdatadbg_6_0 <= {7{1'b0}};
          prdatadbg_11_8 <= {4{1'b0}};
        end // if (!resetn)
      else
        if(pclkendbg)
          begin
            prdatadbg_6_0  <= read_data[6:0];
            prdatadbg_11_8 <= read_data[11:8];
          end // if (pclkendbg)
    end // block: p_reg_prdata

  //---------------------------------------------------------------------------
  // Bit [7] always exist eventhough has different fixed value in
  // coresight management registers and hence registered before driving prdatadbg
  //---------------------------------------------------------------------------
  always @(posedge clk or negedge resetn)
    begin
      if (!resetn)
        begin
          prdatadbg_7 <= 1'b0;
        end // if (!resetn)
      else
        if(pclkendbg)
          begin
            prdatadbg_7  <= read_data[7];
          end // if (pclkendbg)
    end

  //---------------------------------------------------------------------------
  // Bits [14:12] are registered only when the corresponding register bits exist
  //---------------------------------------------------------------------------
  
  always @(posedge clk or negedge resetn)
    begin
      if (!resetn)
        begin
          prdatadbg_14_12 <= {3{1'b0}};
        end // if (!resetn)
      else
        if(pclkendbg)
          begin
            prdatadbg_14_12  <= read_data[14:12];
          end // if (pclkendbg)
    end

  //---------------------------------------------------------------------------
  // Bits [16:15] are registered only when the corresponding register bits exist
  //---------------------------------------------------------------------------
  
  always @(posedge clk or negedge resetn)
    begin
      if (!resetn)
        begin
          prdatadbg_16_15 <= {2{1'b0}};
        end // if (!resetn)
      else
        if(pclkendbg)
          begin
            prdatadbg_16_15  <= read_data[16:15];
          end // if (pclkendbg)
    end

  //---------------------------------------------------------------------------
  // Bit [17] is registered only when the corresponding register bits exist
  //---------------------------------------------------------------------------
  
  always @(posedge clk or negedge resetn)
    begin
      if (!resetn)
        begin
          prdatadbg_17 <= 1'b0;
        end // if (!resetn)
      else
        if(pclkendbg)
          begin
            prdatadbg_17  <= read_data[17];
          end // if (pclkendbg)
    end

  //---------------------------------------------------------------------------
  // Bits 20:18  are registered only when the corresponding register bits exist
  //---------------------------------------------------------------------------
  
  always @(posedge clk or negedge resetn)
    begin
      if (!resetn)
        begin
          prdatadbg_20_18 <= 3'b0;
        end // if (!resetn)
      else
        if(pclkendbg)
          begin
            prdatadbg_20_18  <= read_data[20:18];
          end // if (pclkendbg)
    end

  //---------------------------------------------------------------------------
  // Bits 23:21  are registered only when the corresponding register bits exist
  //---------------------------------------------------------------------------
  
  always @*
    prdatadbg_23_21  = read_data[23:21];

  //---------------------------------------------------------------------------
  // Unused Bits  are directly assigned
  //---------------------------------------------------------------------------

  assign prdatadbg = {read_data[31:24],
                      prdatadbg_23_21,
                      prdatadbg_20_18,
                      prdatadbg_17,
                      prdatadbg_16_15,
                      prdatadbg_14_12,
                      prdatadbg_11_8,
                      prdatadbg_7,
                      prdatadbg_6_0};


  //---------------------------------------------------------------------------
  // Logic for next_reg_write signal.This indicates a register write request to
  // the register interface.
  //---------------------------------------------------------------------------
  assign next_reg_write = slave_select & pwritedbg;

  //---------------------------------------------------------------------------
  // Logic for reg_read signal.This indicates a register read request to
  // the register interface.
  //---------------------------------------------------------------------------
  assign reg_read = pseldbg & ~pwritedbg;

  //---------------------------------------------------------------------------
  // Logic for slave_select signal.SlaveSelect indicates that the Trace Funnel
  // block is accessed for register transactions.
  //---------------------------------------------------------------------------
  assign slave_select = pseldbg & ~penabledbg;

  //---------------------------------------------------------------------------
  // apb_clk_en indicates the clock enable term for the APB interface signals.
  //---------------------------------------------------------------------------
  assign apb_clk_en = slave_select & pclkendbg;

  //---------------------------------------------------------------------------
  // The APB is held for one clock for read accesses. preadydbg is driven high
  // at other times.
  //---------------------------------------------------------------------------
  assign next_preadydbg = ~(slave_select & ~pwritedbg);
  always @(posedge clk or negedge resetn)
  begin
    if (!resetn)
      begin
        preadydbg <= 1'b1;
      end // if (!resetn)
    else
      if(pclkendbg)
        begin
          preadydbg  <= next_preadydbg;
        end // if (pclkendbg)
  end


endmodule // cxatbfunnel_apb_if
