//------------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2003-2015 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//------------------------------------------------------------------------------
// Version and Release Control Information:
//
// File Revision       : $Revision: 39629 $
// File Date           : $Date: 2014-06-25 08:42:22 +0100 (Wed, 25 Jun 2014) $
// Release Information : CoreSight-SoC-TM100-r3p2-00rel0
//------------------------------------------------------------------------------
//  Purpose : CDC four-input multiplexer.  May be connected on a CDC path.
//
//  Implementations should replace this with a cell that is known to be
//  glitch-free while unselected inputs change.
//
//  The select input must be driven from a register in the receiving clock
//  domain.
// ----------------------------------------------------------------------------

module cxntsasyncbridge_cdc_comb_mux4 (din1_async, din2_async, din3_async,
                      din4_async, sel, dout_async);

  // ------------------------------------------------------
  // port declaration
  // ------------------------------------------------------
  input   din1_async; // May be connected to an asynchronous input
  input   din2_async; // May be connected to an asynchronous input
  input   din3_async; // May be connected to an asynchronous input
  input   din4_async; // May be connected to an asynchronous input
  input  [1:0]       sel;
  output  dout_async;

  // ------------------------------------------------------
  // reg/wire declarations
  // ------------------------------------------------------
  reg  muxout;
  wire  dout_async;

  always @(din1_async or din2_async or din3_async or din4_async or sel)
    case (sel)
      2'b00 : muxout = din1_async;
      2'b01 : muxout = din2_async;
      2'b10 : muxout = din3_async;
      2'b11 : muxout = din4_async;
      default : muxout = 1'bx;
    endcase

`ifdef ARM_CDC_CHECK
  assign dout_async = ((sel[0] === 1'bz) || (sel[1] === 1'bz)) ?
                      {1'bz} : muxout;
`else
  assign dout_async = muxout;
`endif

endmodule
