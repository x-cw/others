//+FHDR*************************************************************************
// 
//   Copyright (c) 2025 Innosilicon. Ltd.  All rights reserved. 
// 
//   THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF INNOSILICON
//   The copyright notice above does not evidence any actual or intended
//   publication of such source code.
// 
//************************************************************************
//    Module name: intlv_stage_1.v
//    Create by  : chenqw
//    Email      : chenqw@innosilicon.com.cn
//    Create time: 2025-01-02
//    modify     : modify for new GP3 structure by fangxn
//************************************************************************
//    Description: 
//-FHDR*************************************************************************
module intlv_stage_1  #(
    parameter    IDW        =   8,                      // the width of awid/arid
    parameter    ADDRW      =   51,                     // the width of awaddr/araddr
    parameter    LENW       =   4,                      // the width of awlen/arlen
    parameter    USERW      =   10,
    parameter    ATOPW      =   6,
    parameter    WXP        =   IDW+ADDRW+LENW+3+2+3+4+4+USERW+ATOPW+1,
    parameter    ST1_SW     =   97
)(
    // clock and reset, used for debug logic 
    input   wire                            clk,
    input   wire                            rst_n,

    // scenario static config signal
    input   wire        [35:0]          scenario_ddr_lnhash,    // one-hot code to indicate which scenario is valid, verify assert
                                                                // [35:0]: ddr_intlv linear hash, only one of them can be valid

    input   wire        [35:0]          scenario_ddr_cfghash,   // one-hot code to indicate which scenario is valid, verify assert
                                                                // [35:0]: ddr_intlv config hash, only one of them can be valid

    input   wire        [3:0]           scenario_l2c_lnhash,    // one-hot code to indicate which scenario is valid, verify assert
                                                                // [3:0]: buffer linear hash, only one of them can be valid
    input   wire        [6:0]           ddrch_num,              // the number of ddr channel available
    input   wire        [6:0]           bank_num,               // the number of bank available


    input   wire        [3:0]   bankid_sel_0_0,                 //put pa[value(bankid_sel_0_0)] at bankid_sel_0_0 position
                                                                //4'dx: PA[22+x]
                                                                //4'd0: PA[22]
                                                                //4'd1: PA[23]
                                                                //4'd2: PA[24]
                                                                //4'd3: PA[25]
                                                                //4'd4: PA[26]
                                                                //4'd5: PA[27]
                                                                //4'd6: PA[28]
                                                                //4'd7: PA[29]
                                                                //4'd8: 1'b0
                                                                //4'd9-15: reserved
    input   wire        [3:0]   bankid_sel_0_1,
    input   wire        [3:0]   bankid_sel_0_2,
    input   wire        [3:0]   bankid_sel_0_3,
    input   wire        [3:0]   bankid_sel_0_4,
    input   wire        [3:0]   bankid_sel_0_5,
    input   wire        [3:0]   bankid_sel_0_6,
    input   wire        [3:0]   bankid_sel_0_7,
    input   wire        [3:0]   bankid_sel_1_0,
    input   wire        [3:0]   bankid_sel_1_1,
    input   wire        [3:0]   bankid_sel_1_2,
    input   wire        [3:0]   bankid_sel_1_3,
    input   wire        [3:0]   bankid_sel_1_4,
    input   wire        [3:0]   bankid_sel_1_5,
    input   wire        [3:0]   bankid_sel_1_6,
    input   wire        [3:0]   bankid_sel_1_7,
    input   wire        [3:0]   bankid_sel_2_0,
    input   wire        [3:0]   bankid_sel_2_1,
    input   wire        [3:0]   bankid_sel_2_2,
    input   wire        [3:0]   bankid_sel_2_3,
    input   wire        [3:0]   bankid_sel_2_4,
    input   wire        [3:0]   bankid_sel_2_5,
    input   wire        [3:0]   bankid_sel_2_6,
    input   wire        [3:0]   bankid_sel_2_7,
    input   wire        [3:0]   bankid_sel_3_0,
    input   wire        [3:0]   bankid_sel_3_1,
    input   wire        [3:0]   bankid_sel_3_2,
    input   wire        [3:0]   bankid_sel_3_3,
    input   wire        [3:0]   bankid_sel_3_4,
    input   wire        [3:0]   bankid_sel_3_5,
    input   wire        [3:0]   bankid_sel_3_6,
    input   wire        [3:0]   bankid_sel_3_7,
    input   wire        [3:0]   bankid_sel_4_0,
    input   wire        [3:0]   bankid_sel_4_1,
    input   wire        [3:0]   bankid_sel_4_2,
    input   wire        [3:0]   bankid_sel_4_3,
    input   wire        [3:0]   bankid_sel_4_4,
    input   wire        [3:0]   bankid_sel_4_5,
    input   wire        [3:0]   bankid_sel_4_6,
    input   wire        [3:0]   bankid_sel_4_7,
    input   wire        [3:0]   bankid_sel_5_0,
    input   wire        [3:0]   bankid_sel_5_1,
    input   wire        [3:0]   bankid_sel_5_2,
    input   wire        [3:0]   bankid_sel_5_3,
    input   wire        [3:0]   bankid_sel_5_4,
    input   wire        [3:0]   bankid_sel_5_5,
    input   wire        [3:0]   bankid_sel_5_6,
    input   wire        [3:0]   bankid_sel_5_7,
    input   wire        [3:0]   bankid_sel_6_0,
    input   wire        [3:0]   bankid_sel_6_1,
    input   wire        [3:0]   bankid_sel_6_2,
    input   wire        [3:0]   bankid_sel_6_3,
    input   wire        [3:0]   bankid_sel_6_4,
    input   wire        [3:0]   bankid_sel_6_5,
    input   wire        [3:0]   bankid_sel_6_6,
    input   wire        [3:0]   bankid_sel_6_7,
    
    input   wire        [3:0]   setid_sel_0_0,          //put pa[value(setid_sel_0_0)] at setid_sel_0_0 position          
                                                        //4'dx: PA[22+x]
                                                        //4'd0: PA[22]
                                                        //4'd1: PA[23]
                                                        //4'd2: PA[24]
                                                        //4'd3: PA[25]
                                                        //4'd4: PA[26]
                                                        //4'd5: PA[27]
                                                        //4'd6: PA[28]
                                                        //4'd7: PA[29]
                                                        //4'd8: 1'b0
                                                        //4'd9-15: reserved
    
    input   wire        [3:0]   setid_sel_0_1,
    input   wire        [3:0]   setid_sel_0_2,
    input   wire        [3:0]   setid_sel_0_3,
    input   wire        [3:0]   setid_sel_0_4,
    input   wire        [3:0]   setid_sel_0_5,
    input   wire        [3:0]   setid_sel_0_6,
    input   wire        [3:0]   setid_sel_0_7,
    input   wire        [3:0]   setid_sel_1_0,
    input   wire        [3:0]   setid_sel_1_1,
    input   wire        [3:0]   setid_sel_1_2,
    input   wire        [3:0]   setid_sel_1_3,
    input   wire        [3:0]   setid_sel_1_4,
    input   wire        [3:0]   setid_sel_1_5,
    input   wire        [3:0]   setid_sel_1_6,
    input   wire        [3:0]   setid_sel_1_7,
    input   wire        [3:0]   setid_sel_2_0,
    input   wire        [3:0]   setid_sel_2_1,
    input   wire        [3:0]   setid_sel_2_2,
    input   wire        [3:0]   setid_sel_2_3,
    input   wire        [3:0]   setid_sel_2_4,
    input   wire        [3:0]   setid_sel_2_5,
    input   wire        [3:0]   setid_sel_2_6,
    input   wire        [3:0]   setid_sel_2_7,
    input   wire        [3:0]   setid_sel_3_0,
    input   wire        [3:0]   setid_sel_3_1,
    input   wire        [3:0]   setid_sel_3_2,
    input   wire        [3:0]   setid_sel_3_3,
    input   wire        [3:0]   setid_sel_3_4,
    input   wire        [3:0]   setid_sel_3_5,
    input   wire        [3:0]   setid_sel_3_6,
    input   wire        [3:0]   setid_sel_3_7,
    input   wire        [3:0]   setid_sel_4_0,
    input   wire        [3:0]   setid_sel_4_1,
    input   wire        [3:0]   setid_sel_4_2,
    input   wire        [3:0]   setid_sel_4_3,
    input   wire        [3:0]   setid_sel_4_4,
    input   wire        [3:0]   setid_sel_4_5,
    input   wire        [3:0]   setid_sel_4_6,
    input   wire        [3:0]   setid_sel_4_7,
    input   wire        [3:0]   setid_sel_5_0,
    input   wire        [3:0]   setid_sel_5_1,
    input   wire        [3:0]   setid_sel_5_2,
    input   wire        [3:0]   setid_sel_5_3,
    input   wire        [3:0]   setid_sel_5_4,
    input   wire        [3:0]   setid_sel_5_5,
    input   wire        [3:0]   setid_sel_5_6,
    input   wire        [3:0]   setid_sel_5_7,
    input   wire        [3:0]   setid_sel_6_0,
    input   wire        [3:0]   setid_sel_6_1,
    input   wire        [3:0]   setid_sel_6_2,
    input   wire        [3:0]   setid_sel_6_3,
    input   wire        [3:0]   setid_sel_6_4,
    input   wire        [3:0]   setid_sel_6_5,
    input   wire        [3:0]   setid_sel_6_6,
    input   wire        [3:0]   setid_sel_6_7,

    // slice payload in
    input   wire        [WXP-1:0]           slice_payload_i,
    // slice payload out
    output  wire        [ST1_SW+WXP-1:0]    slice_payload_o
);

////////////////////TBD/////////////////////////////////
localparam  LOCAL_DDR_BASE_ADDR         =       51'h0_0200_0000_0000;           // 640G
localparam  LOCAL_DDR_MAX_ADDR          =       51'h0_02A0_0000_0000;           
localparam  LOCAL_L2B_BASE_ADDR         =       51'h0_0000_2800_0000;           // 10M
localparam  LOCAL_L2B_MAX_ADDR          =       51'h0_0000_28A0_0000;   

// axi_payload extracted
wire    [ADDRW-1:0]         axi_addr;
wire    [ADDRW-1:0]         rebuild_axi_addr;
wire    [11:8]              new_axi_bit;

wire                        axi_user_9bit;           
wire                        gp3_req_hit_local_ddr;              // the flag assert when request's address hits local ddr space
wire                        gp3_req_hit_local_l2b;              // the flag assert when request's address hits local l2 buffer space

wire    [35:0]              scenario_ddr_lnhash_flag;
wire    [35:0]              scenario_ddr_cfghash_flag;
wire    [3:0]               scenario_l2c_lnhash_flag;


wire    [5:0]               ecc_div_dividend;
wire    [2:0]               ecc_div7_rem;
wire    [2:0]               div_quo_noused;
wire    [2:0]               ecc_div7_quo;

wire    [7:0]               bankid0_selbit;                               
wire    [7:0]               bankid1_selbit;
wire    [7:0]               bankid2_selbit;
wire    [7:0]               bankid3_selbit;
wire    [7:0]               bankid4_selbit;
wire    [7:0]               bankid5_selbit;
wire    [7:0]               bankid6_selbit;

wire    [7:0]               setid0_selbit;                               
wire    [7:0]               setid1_selbit;
wire    [7:0]               setid2_selbit;
wire    [7:0]               setid3_selbit;
wire    [7:0]               setid4_selbit;
wire    [7:0]               setid5_selbit;
wire    [7:0]               setid6_selbit;

wire    [6:0]               bank_cir_in_cfghash;
wire    [6:0]               set_cir_in_cfghash;
wire    [6:0]               tmpbankid;
wire    [6:0]               tmpsetid;
wire    [39:0]              ecc_epa_addr;

wire    [9:0]               div5_dividend;
wire    [17:0]              div80_dividend;
wire    [21:0]              div80miusn_dividend;
wire    [6:0]               div80miusn_divisor;

wire                        div5_arb_flag      ;
wire                        div80_arb_flag     ;
wire    [21:0]              dividend_all       ;
wire    [6:0]               divisor_all        ;


///////////////////////////////////logic code//////////////////////////////////////////////
assign  axi_addr                =   slice_payload_i[ADDRW-1:0];
assign  axi_user_9bit           =   gp3_req_hit_local_l2b;        // user change

assign  gp3_req_hit_local_ddr   =   (axi_addr >= LOCAL_DDR_BASE_ADDR) && (axi_addr < LOCAL_DDR_MAX_ADDR);
assign  gp3_req_hit_local_l2b   =   (axi_addr >= LOCAL_L2B_BASE_ADDR) && (axi_addr < LOCAL_L2B_MAX_ADDR);

assign  scenario_ddr_lnhash_flag  =   scenario_ddr_lnhash  & {36{gp3_req_hit_local_ddr}};           // scenario of ddr interleaving
assign  scenario_ddr_cfghash_flag =   scenario_ddr_cfghash & {36{gp3_req_hit_local_ddr}};           // scenario of ddr interleaving
assign  scenario_l2c_lnhash_flag  =   scenario_l2c_lnhash  & {4{gp3_req_hit_local_l2b}};            // scenario of l2 buffer interleaving

///////////////////////new addr calculation for opt/////////////////////////////////////
assign  new_axi_bit[8]   = axi_addr[8]  ^ axi_addr[12] ^ axi_addr[16] ^ axi_addr[20];
assign  new_axi_bit[9]   = axi_addr[9]  ^ axi_addr[13] ^ axi_addr[17] ^ axi_addr[21];
assign  new_axi_bit[10]  = axi_addr[10] ^ axi_addr[14] ^ axi_addr[18] ^ axi_addr[22];
assign  new_axi_bit[11]  = axi_addr[11] ^ axi_addr[15] ^ axi_addr[19] ^ axi_addr[23];

assign  rebuild_axi_addr = (|{scenario_ddr_lnhash_flag,scenario_ddr_cfghash_flag}) ? {axi_addr[ADDRW-1:12],new_axi_bit[11:8],axi_addr[7:0]} : axi_addr;


////ecc pre handle
assign  ecc_div_dividend        =   scenario_ddr_lnhash_flag[9]  || scenario_ddr_cfghash_flag[9]    ? axi_addr[39:34] : 
                                    scenario_ddr_lnhash_flag[11] || scenario_ddr_cfghash_flag[11]   ? axi_addr[38:33] :          
                                    scenario_ddr_lnhash_flag[13] || scenario_ddr_cfghash_flag[13]   ? axi_addr[37:32] :
                                    scenario_ddr_lnhash_flag[15] || scenario_ddr_cfghash_flag[15]   ? axi_addr[36:31] :
                                    scenario_ddr_lnhash_flag[17] || scenario_ddr_cfghash_flag[17]   ? axi_addr[35:30] :6'd0;


// calculate tmpbankid and tmpsetid in cfghash
assign  bankid0_selbit[0] = (bankid_sel_0_0 >= 4'd8 ) ? 1'b0 : axi_addr[bankid_sel_0_0+5'd22];
assign  bankid0_selbit[1] = (bankid_sel_0_1 >= 4'd8 ) ? 1'b0 : axi_addr[bankid_sel_0_1+5'd22];
assign  bankid0_selbit[2] = (bankid_sel_0_2 >= 4'd8 ) ? 1'b0 : axi_addr[bankid_sel_0_2+5'd22];
assign  bankid0_selbit[3] = (bankid_sel_0_3 >= 4'd8 ) ? 1'b0 : axi_addr[bankid_sel_0_3+5'd22];
assign  bankid0_selbit[4] = (bankid_sel_0_4 >= 4'd8 ) ? 1'b0 : axi_addr[bankid_sel_0_4+5'd22];
assign  bankid0_selbit[5] = (bankid_sel_0_5 >= 4'd8 ) ? 1'b0 : axi_addr[bankid_sel_0_5+5'd22];
assign  bankid0_selbit[6] = (bankid_sel_0_6 >= 4'd8 ) ? 1'b0 : axi_addr[bankid_sel_0_6+5'd22];
assign  bankid0_selbit[7] = (bankid_sel_0_7 >= 4'd8 ) ? 1'b0 : axi_addr[bankid_sel_0_7+5'd22];

assign  bankid1_selbit[0] = (bankid_sel_1_0 >= 4'd8 ) ? 1'b0 : axi_addr[bankid_sel_1_0+5'd22];
assign  bankid1_selbit[1] = (bankid_sel_1_1 >= 4'd8 ) ? 1'b0 : axi_addr[bankid_sel_1_1+5'd22];
assign  bankid1_selbit[2] = (bankid_sel_1_2 >= 4'd8 ) ? 1'b0 : axi_addr[bankid_sel_1_2+5'd22];
assign  bankid1_selbit[3] = (bankid_sel_1_3 >= 4'd8 ) ? 1'b0 : axi_addr[bankid_sel_1_3+5'd22];
assign  bankid1_selbit[4] = (bankid_sel_1_4 >= 4'd8 ) ? 1'b0 : axi_addr[bankid_sel_1_4+5'd22];
assign  bankid1_selbit[5] = (bankid_sel_1_5 >= 4'd8 ) ? 1'b0 : axi_addr[bankid_sel_1_5+5'd22];
assign  bankid1_selbit[6] = (bankid_sel_1_6 >= 4'd8 ) ? 1'b0 : axi_addr[bankid_sel_1_6+5'd22];
assign  bankid1_selbit[7] = (bankid_sel_1_7 >= 4'd8 ) ? 1'b0 : axi_addr[bankid_sel_1_7+5'd22];

assign  bankid2_selbit[0] = (bankid_sel_2_0 >= 4'd8 ) ? 1'b0 : axi_addr[bankid_sel_2_0+5'd22];
assign  bankid2_selbit[1] = (bankid_sel_2_1 >= 4'd8 ) ? 1'b0 : axi_addr[bankid_sel_2_1+5'd22];
assign  bankid2_selbit[2] = (bankid_sel_2_2 >= 4'd8 ) ? 1'b0 : axi_addr[bankid_sel_2_2+5'd22];
assign  bankid2_selbit[3] = (bankid_sel_2_3 >= 4'd8 ) ? 1'b0 : axi_addr[bankid_sel_2_3+5'd22];
assign  bankid2_selbit[4] = (bankid_sel_2_4 >= 4'd8 ) ? 1'b0 : axi_addr[bankid_sel_2_4+5'd22];
assign  bankid2_selbit[5] = (bankid_sel_2_5 >= 4'd8 ) ? 1'b0 : axi_addr[bankid_sel_2_5+5'd22];
assign  bankid2_selbit[6] = (bankid_sel_2_6 >= 4'd8 ) ? 1'b0 : axi_addr[bankid_sel_2_6+5'd22];
assign  bankid2_selbit[7] = (bankid_sel_2_7 >= 4'd8 ) ? 1'b0 : axi_addr[bankid_sel_2_7+5'd22];

assign  bankid3_selbit[0] = (bankid_sel_3_0 >= 4'd8 ) ? 1'b0 : axi_addr[bankid_sel_3_0+5'd22];
assign  bankid3_selbit[1] = (bankid_sel_3_1 >= 4'd8 ) ? 1'b0 : axi_addr[bankid_sel_3_1+5'd22];
assign  bankid3_selbit[2] = (bankid_sel_3_2 >= 4'd8 ) ? 1'b0 : axi_addr[bankid_sel_3_2+5'd22];
assign  bankid3_selbit[3] = (bankid_sel_3_3 >= 4'd8 ) ? 1'b0 : axi_addr[bankid_sel_3_3+5'd22];
assign  bankid3_selbit[4] = (bankid_sel_3_4 >= 4'd8 ) ? 1'b0 : axi_addr[bankid_sel_3_4+5'd22];
assign  bankid3_selbit[5] = (bankid_sel_3_5 >= 4'd8 ) ? 1'b0 : axi_addr[bankid_sel_3_5+5'd22];
assign  bankid3_selbit[6] = (bankid_sel_3_6 >= 4'd8 ) ? 1'b0 : axi_addr[bankid_sel_3_6+5'd22];
assign  bankid3_selbit[7] = (bankid_sel_3_7 >= 4'd8 ) ? 1'b0 : axi_addr[bankid_sel_3_7+5'd22];

assign  bankid4_selbit[0] = (bankid_sel_4_0 >= 4'd8 ) ? 1'b0 : axi_addr[bankid_sel_4_0+5'd22];
assign  bankid4_selbit[1] = (bankid_sel_4_1 >= 4'd8 ) ? 1'b0 : axi_addr[bankid_sel_4_1+5'd22];
assign  bankid4_selbit[2] = (bankid_sel_4_2 >= 4'd8 ) ? 1'b0 : axi_addr[bankid_sel_4_2+5'd22];
assign  bankid4_selbit[3] = (bankid_sel_4_3 >= 4'd8 ) ? 1'b0 : axi_addr[bankid_sel_4_3+5'd22];
assign  bankid4_selbit[4] = (bankid_sel_4_4 >= 4'd8 ) ? 1'b0 : axi_addr[bankid_sel_4_4+5'd22];
assign  bankid4_selbit[5] = (bankid_sel_4_5 >= 4'd8 ) ? 1'b0 : axi_addr[bankid_sel_4_5+5'd22];
assign  bankid4_selbit[6] = (bankid_sel_4_6 >= 4'd8 ) ? 1'b0 : axi_addr[bankid_sel_4_6+5'd22];
assign  bankid4_selbit[7] = (bankid_sel_4_7 >= 4'd8 ) ? 1'b0 : axi_addr[bankid_sel_4_7+5'd22];

assign  bankid5_selbit[0] = (bankid_sel_5_0 >= 4'd8 ) ? 1'b0 : axi_addr[bankid_sel_5_0+5'd22];
assign  bankid5_selbit[1] = (bankid_sel_5_1 >= 4'd8 ) ? 1'b0 : axi_addr[bankid_sel_5_1+5'd22];
assign  bankid5_selbit[2] = (bankid_sel_5_2 >= 4'd8 ) ? 1'b0 : axi_addr[bankid_sel_5_2+5'd22];
assign  bankid5_selbit[3] = (bankid_sel_5_3 >= 4'd8 ) ? 1'b0 : axi_addr[bankid_sel_5_3+5'd22];
assign  bankid5_selbit[4] = (bankid_sel_5_4 >= 4'd8 ) ? 1'b0 : axi_addr[bankid_sel_5_4+5'd22];
assign  bankid5_selbit[5] = (bankid_sel_5_5 >= 4'd8 ) ? 1'b0 : axi_addr[bankid_sel_5_5+5'd22];
assign  bankid5_selbit[6] = (bankid_sel_5_6 >= 4'd8 ) ? 1'b0 : axi_addr[bankid_sel_5_6+5'd22];
assign  bankid5_selbit[7] = (bankid_sel_5_7 >= 4'd8 ) ? 1'b0 : axi_addr[bankid_sel_5_7+5'd22];

assign  bankid6_selbit[0] = (bankid_sel_6_0 >= 4'd8 ) ? 1'b0 : axi_addr[bankid_sel_6_0+5'd22];
assign  bankid6_selbit[1] = (bankid_sel_6_1 >= 4'd8 ) ? 1'b0 : axi_addr[bankid_sel_6_1+5'd22];
assign  bankid6_selbit[2] = (bankid_sel_6_2 >= 4'd8 ) ? 1'b0 : axi_addr[bankid_sel_6_2+5'd22];
assign  bankid6_selbit[3] = (bankid_sel_6_3 >= 4'd8 ) ? 1'b0 : axi_addr[bankid_sel_6_3+5'd22];
assign  bankid6_selbit[4] = (bankid_sel_6_4 >= 4'd8 ) ? 1'b0 : axi_addr[bankid_sel_6_4+5'd22];
assign  bankid6_selbit[5] = (bankid_sel_6_5 >= 4'd8 ) ? 1'b0 : axi_addr[bankid_sel_6_5+5'd22];
assign  bankid6_selbit[6] = (bankid_sel_6_6 >= 4'd8 ) ? 1'b0 : axi_addr[bankid_sel_6_6+5'd22];
assign  bankid6_selbit[7] = (bankid_sel_6_7 >= 4'd8 ) ? 1'b0 : axi_addr[bankid_sel_6_7+5'd22];

//////tmp setid gen
assign  setid0_selbit[0] = (setid_sel_0_0 >= 4'd8 ) ? 1'b0 : axi_addr[setid_sel_0_0+5'd22];
assign  setid0_selbit[1] = (setid_sel_0_1 >= 4'd8 ) ? 1'b0 : axi_addr[setid_sel_0_1+5'd22];
assign  setid0_selbit[2] = (setid_sel_0_2 >= 4'd8 ) ? 1'b0 : axi_addr[setid_sel_0_2+5'd22];
assign  setid0_selbit[3] = (setid_sel_0_3 >= 4'd8 ) ? 1'b0 : axi_addr[setid_sel_0_3+5'd22];
assign  setid0_selbit[4] = (setid_sel_0_4 >= 4'd8 ) ? 1'b0 : axi_addr[setid_sel_0_4+5'd22];
assign  setid0_selbit[5] = (setid_sel_0_5 >= 4'd8 ) ? 1'b0 : axi_addr[setid_sel_0_5+5'd22];
assign  setid0_selbit[6] = (setid_sel_0_6 >= 4'd8 ) ? 1'b0 : axi_addr[setid_sel_0_6+5'd22];
assign  setid0_selbit[7] = (setid_sel_0_7 >= 4'd8 ) ? 1'b0 : axi_addr[setid_sel_0_7+5'd22];

assign  setid1_selbit[0] = (setid_sel_1_0 >= 4'd8 ) ? 1'b0 : axi_addr[setid_sel_1_0+5'd22];
assign  setid1_selbit[1] = (setid_sel_1_1 >= 4'd8 ) ? 1'b0 : axi_addr[setid_sel_1_1+5'd22];
assign  setid1_selbit[2] = (setid_sel_1_2 >= 4'd8 ) ? 1'b0 : axi_addr[setid_sel_1_2+5'd22];
assign  setid1_selbit[3] = (setid_sel_1_3 >= 4'd8 ) ? 1'b0 : axi_addr[setid_sel_1_3+5'd22];
assign  setid1_selbit[4] = (setid_sel_1_4 >= 4'd8 ) ? 1'b0 : axi_addr[setid_sel_1_4+5'd22];
assign  setid1_selbit[5] = (setid_sel_1_5 >= 4'd8 ) ? 1'b0 : axi_addr[setid_sel_1_5+5'd22];
assign  setid1_selbit[6] = (setid_sel_1_6 >= 4'd8 ) ? 1'b0 : axi_addr[setid_sel_1_6+5'd22];
assign  setid1_selbit[7] = (setid_sel_1_7 >= 4'd8 ) ? 1'b0 : axi_addr[setid_sel_1_7+5'd22];

assign  setid2_selbit[0] = (setid_sel_2_0 >= 4'd8 ) ? 1'b0 : axi_addr[setid_sel_2_0+5'd22];
assign  setid2_selbit[1] = (setid_sel_2_1 >= 4'd8 ) ? 1'b0 : axi_addr[setid_sel_2_1+5'd22];
assign  setid2_selbit[2] = (setid_sel_2_2 >= 4'd8 ) ? 1'b0 : axi_addr[setid_sel_2_2+5'd22];
assign  setid2_selbit[3] = (setid_sel_2_3 >= 4'd8 ) ? 1'b0 : axi_addr[setid_sel_2_3+5'd22];
assign  setid2_selbit[4] = (setid_sel_2_4 >= 4'd8 ) ? 1'b0 : axi_addr[setid_sel_2_4+5'd22];
assign  setid2_selbit[5] = (setid_sel_2_5 >= 4'd8 ) ? 1'b0 : axi_addr[setid_sel_2_5+5'd22];
assign  setid2_selbit[6] = (setid_sel_2_6 >= 4'd8 ) ? 1'b0 : axi_addr[setid_sel_2_6+5'd22];
assign  setid2_selbit[7] = (setid_sel_2_7 >= 4'd8 ) ? 1'b0 : axi_addr[setid_sel_2_7+5'd22];

assign  setid3_selbit[0] = (setid_sel_3_0 >= 4'd8 ) ? 1'b0 : axi_addr[setid_sel_3_0+5'd22];
assign  setid3_selbit[1] = (setid_sel_3_1 >= 4'd8 ) ? 1'b0 : axi_addr[setid_sel_3_1+5'd22];
assign  setid3_selbit[2] = (setid_sel_3_2 >= 4'd8 ) ? 1'b0 : axi_addr[setid_sel_3_2+5'd22];
assign  setid3_selbit[3] = (setid_sel_3_3 >= 4'd8 ) ? 1'b0 : axi_addr[setid_sel_3_3+5'd22];
assign  setid3_selbit[4] = (setid_sel_3_4 >= 4'd8 ) ? 1'b0 : axi_addr[setid_sel_3_4+5'd22];
assign  setid3_selbit[5] = (setid_sel_3_5 >= 4'd8 ) ? 1'b0 : axi_addr[setid_sel_3_5+5'd22];
assign  setid3_selbit[6] = (setid_sel_3_6 >= 4'd8 ) ? 1'b0 : axi_addr[setid_sel_3_6+5'd22];
assign  setid3_selbit[7] = (setid_sel_3_7 >= 4'd8 ) ? 1'b0 : axi_addr[setid_sel_3_7+5'd22];

assign  setid4_selbit[0] = (setid_sel_4_0 >= 4'd8 ) ? 1'b0 : axi_addr[setid_sel_4_0+5'd22];
assign  setid4_selbit[1] = (setid_sel_4_1 >= 4'd8 ) ? 1'b0 : axi_addr[setid_sel_4_1+5'd22];
assign  setid4_selbit[2] = (setid_sel_4_2 >= 4'd8 ) ? 1'b0 : axi_addr[setid_sel_4_2+5'd22];
assign  setid4_selbit[3] = (setid_sel_4_3 >= 4'd8 ) ? 1'b0 : axi_addr[setid_sel_4_3+5'd22];
assign  setid4_selbit[4] = (setid_sel_4_4 >= 4'd8 ) ? 1'b0 : axi_addr[setid_sel_4_4+5'd22];
assign  setid4_selbit[5] = (setid_sel_4_5 >= 4'd8 ) ? 1'b0 : axi_addr[setid_sel_4_5+5'd22];
assign  setid4_selbit[6] = (setid_sel_4_6 >= 4'd8 ) ? 1'b0 : axi_addr[setid_sel_4_6+5'd22];
assign  setid4_selbit[7] = (setid_sel_4_7 >= 4'd8 ) ? 1'b0 : axi_addr[setid_sel_4_7+5'd22];

assign  setid5_selbit[0] = (setid_sel_5_0 >= 4'd8 ) ? 1'b0 : axi_addr[setid_sel_5_0+5'd22];
assign  setid5_selbit[1] = (setid_sel_5_1 >= 4'd8 ) ? 1'b0 : axi_addr[setid_sel_5_1+5'd22];
assign  setid5_selbit[2] = (setid_sel_5_2 >= 4'd8 ) ? 1'b0 : axi_addr[setid_sel_5_2+5'd22];
assign  setid5_selbit[3] = (setid_sel_5_3 >= 4'd8 ) ? 1'b0 : axi_addr[setid_sel_5_3+5'd22];
assign  setid5_selbit[4] = (setid_sel_5_4 >= 4'd8 ) ? 1'b0 : axi_addr[setid_sel_5_4+5'd22];
assign  setid5_selbit[5] = (setid_sel_5_5 >= 4'd8 ) ? 1'b0 : axi_addr[setid_sel_5_5+5'd22];
assign  setid5_selbit[6] = (setid_sel_5_6 >= 4'd8 ) ? 1'b0 : axi_addr[setid_sel_5_6+5'd22];
assign  setid5_selbit[7] = (setid_sel_5_7 >= 4'd8 ) ? 1'b0 : axi_addr[setid_sel_5_7+5'd22];

assign  setid6_selbit[0] = (setid_sel_6_0 >= 4'd8 ) ? 1'b0 : axi_addr[setid_sel_6_0+5'd22];
assign  setid6_selbit[1] = (setid_sel_6_1 >= 4'd8 ) ? 1'b0 : axi_addr[setid_sel_6_1+5'd22];
assign  setid6_selbit[2] = (setid_sel_6_2 >= 4'd8 ) ? 1'b0 : axi_addr[setid_sel_6_2+5'd22];
assign  setid6_selbit[3] = (setid_sel_6_3 >= 4'd8 ) ? 1'b0 : axi_addr[setid_sel_6_3+5'd22];
assign  setid6_selbit[4] = (setid_sel_6_4 >= 4'd8 ) ? 1'b0 : axi_addr[setid_sel_6_4+5'd22];
assign  setid6_selbit[5] = (setid_sel_6_5 >= 4'd8 ) ? 1'b0 : axi_addr[setid_sel_6_5+5'd22];
assign  setid6_selbit[6] = (setid_sel_6_6 >= 4'd8 ) ? 1'b0 : axi_addr[setid_sel_6_6+5'd22];
assign  setid6_selbit[7] = (setid_sel_6_7 >= 4'd8 ) ? 1'b0 : axi_addr[setid_sel_6_7+5'd22];

//assign  bank_cir_in_cfghash[0] = (^bankid0_selbit) ^ axi_addr[8] ; 
//assign  bank_cir_in_cfghash[1] = (^bankid1_selbit) ^ axi_addr[9] ;
//assign  bank_cir_in_cfghash[2] = (^bankid2_selbit) ^ axi_addr[10];
//assign  bank_cir_in_cfghash[3] = (^bankid3_selbit) ^ axi_addr[11];

assign  bank_cir_in_cfghash[0] = (^bankid0_selbit) ^ new_axi_bit[8] ; 
assign  bank_cir_in_cfghash[1] = (^bankid1_selbit) ^ new_axi_bit[9] ;
assign  bank_cir_in_cfghash[2] = (^bankid2_selbit) ^ new_axi_bit[10];
assign  bank_cir_in_cfghash[3] = (^bankid3_selbit) ^ new_axi_bit[11];
assign  bank_cir_in_cfghash[4] = (^bankid4_selbit) ^ axi_addr[12];
assign  bank_cir_in_cfghash[5] = (^bankid5_selbit) ^ axi_addr[13];
assign  bank_cir_in_cfghash[6] = (^bankid6_selbit) ^ axi_addr[14];

///set_id_cir
assign  set_cir_in_cfghash[0] = (^setid0_selbit) ^ axi_addr[15]; 
assign  set_cir_in_cfghash[1] = (^setid1_selbit) ^ axi_addr[16];
assign  set_cir_in_cfghash[2] = (^setid2_selbit) ^ axi_addr[17];
assign  set_cir_in_cfghash[3] = (^setid3_selbit) ^ axi_addr[18];
assign  set_cir_in_cfghash[4] = (^setid4_selbit) ^ axi_addr[19];
assign  set_cir_in_cfghash[5] = (^setid5_selbit) ^ axi_addr[20];
assign  set_cir_in_cfghash[6] = (^setid6_selbit) ^ axi_addr[21];

////get cfg hash tmpbankid and tmpsetid
assign  tmpbankid  =  bank_cir_in_cfghash;
assign  tmpsetid   =  set_cir_in_cfghash ;

`ifdef PAL_INTLV_DIV
    assign  {div_quo_noused,ecc_div7_quo}   =    ecc_div_dividend / 3'd7;
    assign  ecc_div7_rem                    =    ecc_div_dividend % 3'd7;
`else 
    DW_div #(
        .a_width    (6),
        .b_width    (3),
        .tc_mode    (0),
        .rem_mode   (1)
    ) u_ECC_DW_div0(
        .a              (ecc_div_dividend), 
        .b              (3'd7        ), 
        .quotient       ({div_quo_noused,ecc_div7_quo}), 
        .remainder      (ecc_div7_rem), 
        .divide_by_0    ()
    );

`endif


///////////////////////////////////////get stage2 dividend and divisor//////////////////////////////////////////////////
//////////////////////EPA DATA/////////////////////////////////////////////////////////////////////////////
assign  ecc_epa_addr     =   scenario_ddr_lnhash_flag[9]  || scenario_ddr_cfghash_flag[9]    ? {ecc_div7_quo,ecc_div7_rem,rebuild_axi_addr[33:0]} : 
                             scenario_ddr_lnhash_flag[11] || scenario_ddr_cfghash_flag[11]   ? {1'd0,ecc_div7_quo,ecc_div7_rem,rebuild_axi_addr[32:0]} :          
                             scenario_ddr_lnhash_flag[13] || scenario_ddr_cfghash_flag[13]   ? {2'd0,ecc_div7_quo,ecc_div7_rem,rebuild_axi_addr[31:0]} :
                             scenario_ddr_lnhash_flag[15] || scenario_ddr_cfghash_flag[15]   ? {3'd0,ecc_div7_quo,ecc_div7_rem,rebuild_axi_addr[30:0]} :
                             scenario_ddr_lnhash_flag[17] || scenario_ddr_cfghash_flag[17]   ? {4'd0,ecc_div7_quo,ecc_div7_rem,rebuild_axi_addr[29:0]} :40'd0;



////////////////////////calculate div5 mode dividend////////////////////////////////////////////
assign  div5_dividend        =   scenario_ddr_lnhash_flag[0]  ? {rebuild_axi_addr[39:37],rebuild_axi_addr[18:12]} : 
                                 scenario_ddr_lnhash_flag[2]  ? {rebuild_axi_addr[38:36],rebuild_axi_addr[18:12]} : 
                                 scenario_ddr_lnhash_flag[4]  ? {rebuild_axi_addr[37:35],rebuild_axi_addr[18:12]} :
                                 scenario_ddr_lnhash_flag[6]  ? {rebuild_axi_addr[36:34],rebuild_axi_addr[18:12]} :
                                 scenario_ddr_lnhash_flag[8]  ? {rebuild_axi_addr[35:33],rebuild_axi_addr[18:12]} :
                                 scenario_ddr_lnhash_flag[9]  ? {ecc_epa_addr[39:37],ecc_epa_addr[18:12]} :
                                 scenario_ddr_lnhash_flag[11] ? {ecc_epa_addr[38:36],ecc_epa_addr[18:12]} :
                                 scenario_ddr_lnhash_flag[13] ? {ecc_epa_addr[37:35],ecc_epa_addr[18:12]} :
                                 scenario_ddr_lnhash_flag[15] ? {ecc_epa_addr[36:34],ecc_epa_addr[18:12]} :
                                 scenario_ddr_lnhash_flag[17] ? {ecc_epa_addr[35:33],ecc_epa_addr[18:12]} :
                                 scenario_ddr_cfghash_flag[0] ? {rebuild_axi_addr[39:37],tmpsetid[3:0],tmpbankid[6:4]}:
                                 scenario_ddr_cfghash_flag[2] ? {rebuild_axi_addr[38:36],tmpsetid[3:0],tmpbankid[6:4]}:
                                 scenario_ddr_cfghash_flag[4] ? {rebuild_axi_addr[37:35],tmpsetid[3:0],tmpbankid[6:4]}:
                                 scenario_ddr_cfghash_flag[6] ? {rebuild_axi_addr[36:34],tmpsetid[3:0],tmpbankid[6:4]}:
                                 scenario_ddr_cfghash_flag[8] ? {rebuild_axi_addr[35:33],tmpsetid[3:0],tmpbankid[6:4]}:
                                 scenario_ddr_cfghash_flag[9] ? {ecc_epa_addr[39:37],tmpsetid[3:0],tmpbankid[6:4]}:
                                 scenario_ddr_cfghash_flag[11]? {ecc_epa_addr[38:36],tmpsetid[3:0],tmpbankid[6:4]}:
                                 scenario_ddr_cfghash_flag[13]? {ecc_epa_addr[37:35],tmpsetid[3:0],tmpbankid[6:4]}:
                                 scenario_ddr_cfghash_flag[15]? {ecc_epa_addr[36:34],tmpsetid[3:0],tmpbankid[6:4]}:
                                 scenario_ddr_cfghash_flag[17]? {ecc_epa_addr[35:33],tmpsetid[3:0],tmpbankid[6:4]}:
                                 scenario_l2c_lnhash_flag[0]  ? {4'd0,rebuild_axi_addr[23:21],rebuild_axi_addr[14:12]} :
                                 scenario_l2c_lnhash_flag[1]  ? {4'd0,rebuild_axi_addr[22:20],rebuild_axi_addr[14:12]} :10'd0;
                                 
////////////////////////calculate div80 mode dividend////////////////////////////////////////////
assign  div80_dividend        =  scenario_ddr_lnhash_flag[1]   ? {3'd0,rebuild_axi_addr[38:35],rebuild_axi_addr[18:8]}               : 
                                 scenario_ddr_lnhash_flag[3]   ? {3'd0,rebuild_axi_addr[37:34],rebuild_axi_addr[18:8]}               : 
                                 scenario_ddr_lnhash_flag[5]   ? {3'd0,rebuild_axi_addr[36:33],rebuild_axi_addr[18:8]}               :
                                 scenario_ddr_lnhash_flag[7]   ? {3'd0,rebuild_axi_addr[35:32],rebuild_axi_addr[18:8]}               :
                                 scenario_ddr_lnhash_flag[10]  ? {rebuild_axi_addr[38:32],rebuild_axi_addr[18:8]}                    :
                                 scenario_ddr_lnhash_flag[12]  ? {rebuild_axi_addr[37:31],rebuild_axi_addr[18:8]}                    :
                                 scenario_ddr_lnhash_flag[14]  ? {rebuild_axi_addr[36:30],rebuild_axi_addr[18:8]}                    :
                                 scenario_ddr_lnhash_flag[16]  ? {rebuild_axi_addr[35:29],rebuild_axi_addr[18:8]}                    :
                                 scenario_ddr_cfghash_flag[1]  ? {3'd0,rebuild_axi_addr[38:35],tmpsetid[3:0],tmpbankid[6:0]}     :
                                 scenario_ddr_cfghash_flag[3]  ? {3'd0,rebuild_axi_addr[37:34],tmpsetid[3:0],tmpbankid[6:0]}     :                                 
                                 scenario_ddr_cfghash_flag[5]  ? {3'd0,rebuild_axi_addr[36:33],tmpsetid[3:0],tmpbankid[6:0]}     :                                 
                                 scenario_ddr_cfghash_flag[7]  ? {3'd0,rebuild_axi_addr[35:32],tmpsetid[3:0],tmpbankid[6:0]}     :                                 
                                 scenario_ddr_cfghash_flag[10] ? {rebuild_axi_addr[38:32],tmpsetid[3:0],tmpbankid[6:0]}          :                                 
                                 scenario_ddr_cfghash_flag[12] ? {rebuild_axi_addr[37:31],tmpsetid[3:0],tmpbankid[6:0]}          :                                  
                                 scenario_ddr_cfghash_flag[14] ? {rebuild_axi_addr[36:30],tmpsetid[3:0],tmpbankid[6:0]}          :                                  
                                 scenario_ddr_cfghash_flag[16] ? {rebuild_axi_addr[35:29],tmpsetid[3:0],tmpbankid[6:0]}          : 18'd0;

////////////////////////calculate div80 mode dividend////////////////////////////////////////////
assign  div80miusn_dividend   =  scenario_ddr_lnhash_flag[18]   ? {4'd0,rebuild_axi_addr[39:33],rebuild_axi_addr[18:8]} : 
                                 scenario_ddr_lnhash_flag[19]   ? {3'd0,rebuild_axi_addr[38:31],rebuild_axi_addr[18:8]} : 
                                 scenario_ddr_lnhash_flag[20]   ? {4'd0,rebuild_axi_addr[38:32],rebuild_axi_addr[18:8]} :
                                 scenario_ddr_lnhash_flag[21]   ? {3'd0,rebuild_axi_addr[37:30],rebuild_axi_addr[18:8]} :
                                 scenario_ddr_lnhash_flag[22]   ? {4'd0,rebuild_axi_addr[37:31],rebuild_axi_addr[18:8]} :
                                 scenario_ddr_lnhash_flag[23]   ? {3'd0,rebuild_axi_addr[36:29],rebuild_axi_addr[18:8]} :
                                 scenario_ddr_lnhash_flag[24]   ? {4'd0,rebuild_axi_addr[36:30],rebuild_axi_addr[18:8]} :
                                 scenario_ddr_lnhash_flag[25]   ? {3'd0,rebuild_axi_addr[35:28],rebuild_axi_addr[18:8]} :
                                 scenario_ddr_lnhash_flag[26]   ? {4'd0,rebuild_axi_addr[35:29],rebuild_axi_addr[18:8]} :
                                 scenario_ddr_lnhash_flag[27]   ? {1'd0,rebuild_axi_addr[39:30],rebuild_axi_addr[18:8]} :
                                 scenario_ddr_lnhash_flag[28]   ? {rebuild_axi_addr[38:28],rebuild_axi_addr[18:8]} :
                                 scenario_ddr_lnhash_flag[29]   ? {1'd0,rebuild_axi_addr[38:29],rebuild_axi_addr[18:8]} :
                                 scenario_ddr_lnhash_flag[30]   ? {rebuild_axi_addr[37:27],rebuild_axi_addr[18:8]} :
                                 scenario_ddr_lnhash_flag[31]   ? {1'd0,rebuild_axi_addr[37:28],rebuild_axi_addr[18:8]} :
                                 scenario_ddr_lnhash_flag[32]   ? {rebuild_axi_addr[36:26],rebuild_axi_addr[18:8]} :
                                 scenario_ddr_lnhash_flag[33]   ? {1'd0,rebuild_axi_addr[36:27],rebuild_axi_addr[18:8]} :
                                 scenario_ddr_lnhash_flag[34]   ? {rebuild_axi_addr[35:25],rebuild_axi_addr[18:8]} :
                                 scenario_ddr_lnhash_flag[35]   ? {1'd0,rebuild_axi_addr[35:26],rebuild_axi_addr[18:8]} :
                                 scenario_ddr_cfghash_flag[18]  ? {4'd0,rebuild_axi_addr[39:33],tmpsetid[3:0],tmpbankid[6:0]} : 
                                 scenario_ddr_cfghash_flag[19]  ? {3'd0,rebuild_axi_addr[38:31],tmpsetid[3:0],tmpbankid[6:0]} : 
                                 scenario_ddr_cfghash_flag[20]  ? {4'd0,rebuild_axi_addr[38:32],tmpsetid[3:0],tmpbankid[6:0]} :
                                 scenario_ddr_cfghash_flag[21]  ? {3'd0,rebuild_axi_addr[37:30],tmpsetid[3:0],tmpbankid[6:0]} :
                                 scenario_ddr_cfghash_flag[22]  ? {4'd0,rebuild_axi_addr[37:31],tmpsetid[3:0],tmpbankid[6:0]} :
                                 scenario_ddr_cfghash_flag[23]  ? {3'd0,rebuild_axi_addr[36:29],tmpsetid[3:0],tmpbankid[6:0]} :
                                 scenario_ddr_cfghash_flag[24]  ? {4'd0,rebuild_axi_addr[36:30],tmpsetid[3:0],tmpbankid[6:0]} :
                                 scenario_ddr_cfghash_flag[25]  ? {3'd0,rebuild_axi_addr[35:28],tmpsetid[3:0],tmpbankid[6:0]} :
                                 scenario_ddr_cfghash_flag[26]  ? {4'd0,rebuild_axi_addr[35:29],tmpsetid[3:0],tmpbankid[6:0]} :
                                 scenario_ddr_cfghash_flag[27]  ? {1'd0,rebuild_axi_addr[39:30],tmpsetid[3:0],tmpbankid[6:0]} :
                                 scenario_ddr_cfghash_flag[28]  ? {rebuild_axi_addr[38:28],tmpsetid[3:0],tmpbankid[6:0]} :
                                 scenario_ddr_cfghash_flag[29]  ? {1'd0,rebuild_axi_addr[38:29],tmpsetid[3:0],tmpbankid[6:0]} :
                                 scenario_ddr_cfghash_flag[30]  ? {rebuild_axi_addr[37:27],tmpsetid[3:0],tmpbankid[6:0]} :
                                 scenario_ddr_cfghash_flag[31]  ? {1'd0,rebuild_axi_addr[37:28],tmpsetid[3:0],tmpbankid[6:0]} :
                                 scenario_ddr_cfghash_flag[32]  ? {rebuild_axi_addr[36:26],tmpsetid[3:0],tmpbankid[6:0]} :
                                 scenario_ddr_cfghash_flag[33]  ? {1'd0,rebuild_axi_addr[36:27],tmpsetid[3:0],tmpbankid[6:0]} :
                                 scenario_ddr_cfghash_flag[34]  ? {rebuild_axi_addr[35:25],tmpsetid[3:0],tmpbankid[6:0]} :
                                 scenario_ddr_cfghash_flag[35]  ? {1'd0,rebuild_axi_addr[35:26],tmpsetid[3:0],tmpbankid[6:0]} :
                                 scenario_l2c_lnhash_flag[2]    ? {8'd0,rebuild_axi_addr[23:17],rebuild_axi_addr[14:8]}  :
                                 scenario_l2c_lnhash_flag[3]    ? {8'd0,rebuild_axi_addr[22:16],rebuild_axi_addr[14:8]}  :22'd0;

assign div80miusn_divisor   =   |{scenario_ddr_lnhash_flag[35:18], scenario_ddr_cfghash_flag[35:18]}? ddrch_num+7'd1:bank_num+7'd1;

//////////////////////////////////////integrate all dividend and divisor to save area///////////////////////////////////////////////////
assign div5_arb_flag  = |{scenario_ddr_lnhash_flag[0]  , scenario_ddr_lnhash_flag[2]  , scenario_ddr_lnhash_flag[4]  , scenario_ddr_lnhash_flag[6]  , 
                          scenario_ddr_lnhash_flag[8]  , scenario_ddr_lnhash_flag[9]  , scenario_ddr_lnhash_flag[11] , scenario_ddr_lnhash_flag[13] , 
                          scenario_ddr_lnhash_flag[15] , scenario_ddr_lnhash_flag[17] , scenario_ddr_cfghash_flag[0] , scenario_ddr_cfghash_flag[2] , 
                          scenario_ddr_cfghash_flag[4] , scenario_ddr_cfghash_flag[6] , scenario_ddr_cfghash_flag[8] , scenario_ddr_cfghash_flag[9] , 
                          scenario_ddr_cfghash_flag[11], scenario_ddr_cfghash_flag[13], scenario_ddr_cfghash_flag[15], scenario_ddr_cfghash_flag[17], 
                          scenario_l2c_lnhash_flag[0]  , scenario_l2c_lnhash_flag[1]};

assign div80_arb_flag = |{scenario_ddr_lnhash_flag[1] ,scenario_ddr_lnhash_flag[3]   ,scenario_ddr_lnhash_flag[5]   ,scenario_ddr_lnhash_flag[7]  ,
                          scenario_ddr_lnhash_flag[10],scenario_ddr_lnhash_flag[12]  ,scenario_ddr_lnhash_flag[14]  ,scenario_ddr_lnhash_flag[16] ,
                          scenario_ddr_cfghash_flag[1],scenario_ddr_cfghash_flag[3]  ,scenario_ddr_cfghash_flag[5]  ,scenario_ddr_cfghash_flag[7] ,                          
                          scenario_ddr_cfghash_flag[10],scenario_ddr_cfghash_flag[12],scenario_ddr_cfghash_flag[14] ,scenario_ddr_cfghash_flag[16]}; 



assign dividend_all =  div5_arb_flag  ? {12'd0,div5_dividend}  : 
                       div80_arb_flag ? {4'd0,div80_dividend}  : div80miusn_dividend;

assign divisor_all  =  div5_arb_flag  ? {4'd0,3'd5}  : 
                       div80_arb_flag ? 7'd80        : div80miusn_divisor;


assign  slice_payload_o = {dividend_all
                          ,divisor_all
                          ,gp3_req_hit_local_ddr
                          ,gp3_req_hit_local_l2b
                          ,ecc_div7_quo
                          ,ecc_div7_rem
                          ,tmpbankid
                          ,tmpsetid
                          ,slice_payload_i[WXP-1:ADDRW+11-1],axi_user_9bit,slice_payload_i[ADDRW+9-1:ADDRW],rebuild_axi_addr[ADDRW-1:0]};
endmodule
