//-----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2012-2015 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//  Checked In          : $Date: 2014-06-25 08:59:36 +0100 (Wed, 25 Jun 2014) $
//  Revision            : $Revision: 39630 $
//  Release             : CoreSight-SoC-TM100-r3p2-00rel0
//
//  ----------------------------------------------------------------------------
//  Purpose             : DAPBUS Interconnect Address Decoder
//
//  --========================================================================--

module cxdapbusic_decoder_3ap
  (
  // Inputs

  // Slave interface
  input  wire [7:0]  dapcaddrs_15to8,
  input  wire        dapsels,
    
  output wire        dapselm2,
  output wire        dapselm1,
  output wire        dapselm0,
  output wire        dapseldef
  );

//-----------------------------------------------------------------------------
//
// Main body of code
// =================
//
//-----------------------------------------------------------------------------

// Address Decode

    
  assign dapselm2 =  dapsels & (dapcaddrs_15to8[7:0] == 8'd2);
        
  assign dapselm1 =  dapsels & (dapcaddrs_15to8[7:0] == 8'd1);
        
  assign dapselm0 =  dapsels & (dapcaddrs_15to8[7:0] == 8'd0);
        

  assign dapseldef = dapsels & (dapcaddrs_15to8[7:0] > 8'd2);

endmodule // cxdapbusic_decoder_3ap
