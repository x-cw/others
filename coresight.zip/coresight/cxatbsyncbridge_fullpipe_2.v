//-----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2010-2015 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//  Version and Release Control Information:
//
//  File Revision       : $Revision: 39630 $
//  File Date           : $Date: 2014-06-25 08:59:36 +0100 (Wed, 25 Jun 2014) $
//
//  Release Information : CoreSight-SoC-TM100-r3p2-00rel0
//-----------------------------------------------------------------------------

//----------------------------------------------------------------------------
//
//
//  Overview
// ==========
//
// This component instantiates Full or Forward or Reverse type register slices
// depending on the configuration
//
//----------------------------------------------------------------------------



//------------------------------------------------------------------------------
// Module Declaration
//------------------------------------------------------------------------------
module cxatbsyncbridge_fullpipe_2
  (
  //----------------------------------------------------------------------------
  // port definitions
  //----------------------------------------------------------------------------

 // Slave Port

  input              clk,          // ATB Bus clock

  input              clkens,       // ATB slaveport clock enable
  
  input              clkenm,       // ATB master port clock enable
  
  input              resetn,       // ATB Bus reset
  input              atvalids,     // ATB Bus transfer valid slave
  input [6:0]        atids,        // ATB Bus id slave

  input [1:0]        atbytess,
  input [32-1:0]   atdatas,    // ATB Bus data slave
  input              afreadys,     // ATB Bus flush ready slave

  // Master Port

  input              atreadym,     // ATB Bus transfer ready master
  input              afvalidm,     // ATB Bus flush valid master
  input              syncreqm,     // Synchronization request



  //----------------------------------------------------------------------------
  // OUTPUTS
  //----------------------------------------------------------------------------

  // Slave Port
  output            atreadys,   // ATB Bus transfer ready slave
  output            afvalids,   // ATB Bus flush valid slave
  // Master Port
  output            atvalidm,   // ATB Bus transfer valid master
  output [6:0]      atidm,      // ATB Bus id master

  output [1:0]      atbytesm,
              // ATB byte select master

  output [32-1:0]  atdatam,      // ATB Bus data master
  output            afreadym,    // ATB Bus flush ready master
  output            syncreqs     // Synchronization request

);



  //----------------------------------------------------------------------------
  // parameters
  //----------------------------------------------------------------------------

  // calculated parameters (do not alter)

  localparam ATB_BYTES_WIDTH = 2;
  localparam FIFO_DEPTH = 2;
  localparam LPI_PRESENT= 0;
  localparam ATB_DATA_WIDTH = 32;


  //----------------------------------------------------------------------------
  // internal signals declarations
  //----------------------------------------------------------------------------


  //----------------------------------------------------------------------------
  // start of code
  //----------------------------------------------------------------------------



  cxatbsyncbridge_full
    #(.ATB_DATA_WIDTH (ATB_DATA_WIDTH),
      .ATB_BYTES_WIDTH(ATB_BYTES_WIDTH),
      .FIFO_DEPTH     (FIFO_DEPTH),
      .LPI_PRESENT    (LPI_PRESENT))
  u_full_bridge (
   .clk         (clk),        // ATB Bus clock

   .clkens      (clkens),     // ATB Bus clock enable for slave port
   .resetn      (resetn),     // ATB Bus reset
   .atvalids    (atvalids),   // ATB Bus transfer valid slave
   .atids       (atids),      // ATB Bus id slave
   .atbytess    (atbytess),   // ATB Bus bytes slave
   .atdatas     (atdatas),    // ATB Bus data slave
   .afreadys    (afreadys),   // ATB Bus flush ready slave

   .clkenm      (clkenm),     // ATB Bus clock enable for master port
   .atreadym    (atreadym),   // ATB Bus transfer ready master
   .afvalidm    (afvalidm),   // ATB Bus flush valid master
   .syncreqm    (syncreqm),   // Synchronization request
   .csysreq     (1'b1),    // Power down request

//  ------------------------------------------------------------
//  Outputs
//  ------------------------------------------------------------

  .csysack      (),    // Power down Acknowledge
  .cactive      (),    // Power down Acknowledge
  .atreadys     (atreadys),     // ATB Bus transfer ready slave
  .afvalids     (afvalids),     // ATB Bus flush valid slave

  .atvalidm     (atvalidm),     // ATB Bus transfer valid master
  .atidm        (atidm),        // ATB Bus id master
  .atbytesm     (atbytesm),     // ATB Bus bytes master
  .atdatam      (atdatam),      // ATB Bus data master
  .afreadym     (afreadym),     // ATB Bus flush ready master
  .syncreqs     (syncreqs)      // Synchronization request
  );



`ifdef ARM_ASSERT_ON
  //----------------------------------------------------------------------------
  // OVL Assertions
  //----------------------------------------------------------------------------

  //----------------------------------------------------------------------------
  // LPI can be present only with a Full type bridge
  //----------------------------------------------------------------------------

  localparam full_bridge = 1'b1;
  localparam lpi_choice  = 1'b0;

  assert_never #(`OVL_ERROR, `OVL_ASSERT,
    "OVL Message : Configuration error: LPI can be present only with a Full type bridge")
      uzovl_cxatbsyncbridge_lpi_with_full_type_bridge
        (
         .clk         (clk),
         .reset_n     (resetn),
         .test_expr   (lpi_choice & ~full_bridge)
        );

  //----------------------------------------------------------------------------
  // FIFO depth can be only in powers of 2 with a maximum of 256
  //----------------------------------------------------------------------------

  assert_never #(`OVL_ERROR, `OVL_ASSERT,
    "OVL Message : Configuration error: FIFO depth can be only in powers of 2 with a maximum of 256")
      uzovl_cxatbsyncbridge_fifo_depth
        (
         .clk         (clk),
         .reset_n     (resetn),
         .test_expr   (FIFO_DEPTH != 2  &
                       FIFO_DEPTH != 4  &
                       FIFO_DEPTH != 8  &
                       FIFO_DEPTH != 16 &
                       FIFO_DEPTH != 32 &
                       FIFO_DEPTH != 64 &
                       FIFO_DEPTH != 128&
                       FIFO_DEPTH != 256)
        );


`endif
endmodule // cxatbsyncbridge
