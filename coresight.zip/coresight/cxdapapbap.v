//-----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2003-2015 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//    Checked In : $Date: 2014-10-06 16:04:52 +0100 (Mon, 06 Oct 2014) $
//    Revision   : $Revision: 40175 $
//    Release    : CoreSight-SoC-TM100-r3p2-00rel0
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// Abstract : Debug Access Port APB Access Port (cxdapapbap) - Top Level Block
//-----------------------------------------------------------------------------
//
// cxdapapbap - Debug Access Port APB Access Port
// ----------------------------------------------
//
// Debug Access Port APB Access Port component provides an APB interface to a
// System On Chip (SOC).
//
// cxdapapbap.v
// ------------
//
// cxdapapbap.v provides the instantiations of all modules for the dapapbap.
//
// Instantiated blocks
// -------------------
//
// cxdapapbap_apb_if.v   - APB Master Interface Module
// cxdapapbap_dap_if.v   - DAP Slave  Interface Module
//-----------------------------------------------------------------------------

module cxdapapbap (
  input wire        dapclk,         // DAP clock
  input wire        dapclken,       // DAP clock enable
  input wire        dapresetn,      // DAP asynchrnous reset active low

  input wire        dapsel,         // DAP select
  input wire        dapenable,      // DAP enable
  input wire        dapwrite,       // DAP write or read
  input wire        dapabort,       // DAP abort
  input wire  [7:2] dapcaddr,       // DAP compressed address bus
  input wire [31:0] dapwdata,       // DAP write data bus

  input wire        pready,         // APB slave ready
  input wire        pslverr,        // APB slave error
  input wire [31:0] prdata,         // APB read data bus

  input wire        deviceen,       // Device enable

  input wire [31:0] rombaseaddr,    // APB ROM Base address, tie-off

  // Outputs
  output wire        dapready,       // DAP slave ready
  output wire        dapslverr,      // DAP slave error
  output wire [31:0] daprdata,       // DAP read data bus

  output wire        psel,           // APB select
  output wire        penable,        // APB enable
  output wire        pwrite,         // APB write or read
  output wire [31:2] paddr,          // APB address bus
  output wire [31:0] pwdata,         // APB write data bus

  output wire        pdbgswen        // Enable software access to Debug APB
  );


  wire [7:2]            dapaddr;                // Address bus with filter to avoid
                                                //  X-propagation
  wire [29:0]           paddr_ap;               // Address bus output before being
                                                //  mapped to paddr[31:2]


  // Beginning of automatic wires (for undeclared instantiated-module outputs)
  wire                  apb_rd_wr;              // From u_dapapbap_dap_if of cxdapapbap_dap_if.v
  wire                  apb_tr_done;            // From u_dapapbap_apb_if of cxdapapbap_apb_if.v
  wire                  apb_tr_in_prog;         // From u_dapapbap_apb_if of cxdapapbap_apb_if.v
  wire                  apb_tr_req;             // From u_dapapbap_dap_if of cxdapapbap_dap_if.v
  wire                  psel_int;
  // End of automatics

  //---------------------------------------------------------------------------
  // DAP Slave Interface Module.
  // This module intefaces to the DAP side of the APB-AP block.
  //---------------------------------------------------------------------------
  cxdapapbap_dap_if u_cxdapapbap_dap_if
    (
     // Outputs
     .dapready                          (dapready),
     .dapslverr                         (dapslverr),
     .daprdata                          (daprdata[31:0]),
     .apb_rd_wr                         (apb_rd_wr),
     .apb_tr_req                        (apb_tr_req),
     .paddr_ap                          (paddr_ap[29:0]),
     .pdbgswen                          (pdbgswen),
     // Inputs
     .dapclk                            (dapclk),
     .dapclken                          (dapclken),
     .dapresetn                         (dapresetn),
     .dapsel                            (dapsel),
     .dapenable                         (dapenable),
     .dapwrite                          (dapwrite),
     .dapabort                          (dapabort),
     .dapaddr                           (dapaddr[7:2]),
     .dapwdata_31to2                    (dapwdata[31:2]),
     .deviceen                          (deviceen),
     .apb_tr_done                       (apb_tr_done),
     .apb_tr_in_prog                    (apb_tr_in_prog),
     .pslverr                           (pslverr),
     .prdata                            (prdata[31:0]),
     .apb_rom_addr                      (rombaseaddr[31:0]));

  //---------------------------------------------------------------------------
  // APB Master Interface Module.
  // This module intefaces to the APB side of the APB-AP block.
  //---------------------------------------------------------------------------
  cxdapapbap_apb_if u_cxdapapbap_apb_if
    (
     // Outputs
     .psel                              (psel_int),
     .penable                           (penable),
     .pwrite                            (pwrite),
     .pwdata                            (pwdata[31:0]),
     .apb_tr_done                       (apb_tr_done),
     // Inputs
     .dapclk                            (dapclk),
     .dapclken                          (dapclken),
     .dapresetn                         (dapresetn),
     .pready                            (pready),
     .apb_rd_wr                         (apb_rd_wr),
     .apb_tr_req                        (apb_tr_req),
     .dapwdata                          (dapwdata[31:0]));

  assign apb_tr_in_prog = psel_int;
  assign psel           = psel_int;

//-----------------------------------------------------------------------------
// Map PADDR[29:0] from the APB-AP core to paddr[31:2] of the wrapper.
// All APB accesses are 32-bit accesses.
//-----------------------------------------------------------------------------
assign paddr = paddr_ap;

//-----------------------------------------------------------------------------
// Map dapcaddr to dapaddr
//-----------------------------------------------------------------------------
  assign dapaddr = dapcaddr;

`ifdef ARM_ASSERT_ON
  //----------------------------------------------------------------------------
  // OVL Assertions
  //----------------------------------------------------------------------------

  wire   hs_start;            // Handshake start
  wire   hs_end;              // Handshake end
  reg    apb_tr_req_del;        // Delayed APB transfer request

  assign hs_start = (apb_tr_req ^ apb_tr_req_del);
  assign hs_end   = apb_tr_done | dapabort;

  //----------------------------------------------------------------------------
  // Register transfer request for edge detection
  //----------------------------------------------------------------------------
  always @ (negedge dapresetn or posedge dapclk)
    if (!dapresetn)
      apb_tr_req_del <= 1'b0;
    else
      if(dapclken)
        apb_tr_req_del <= apb_tr_req;

  //----------------------------------------------------------------------------
  // dapsel should remain stable for the duration of handshake.
  //----------------------------------------------------------------------------
  assert_win_unchange #(`OVL_ERROR, 1, `OVL_ASSERT,
    "OVL Message : dapapbap - dapsel not static for handshake duration")
      dapapbap_sel
        (
         .clk         (dapclk),
         .reset_n     (dapresetn),
         .start_event (hs_start),
         .test_expr   (dapsel),
         .end_event   (hs_end)
        );

  //----------------------------------------------------------------------------
  // dapwrite should remain stable for the duration of handshake.
  //----------------------------------------------------------------------------
  assert_win_unchange #(`OVL_ERROR, 1, `OVL_ASSERT,
    "OVL Message : dapapbap - dapwrite not static for handshake duration")
      dapapbap_write
        (
         .clk         (dapclk),
         .reset_n     (dapresetn),
         .start_event (hs_start),
         .test_expr   (dapwrite),
         .end_event   (hs_end)
        );

  //----------------------------------------------------------------------------
  // dapaddr should remain stable for the duration of handshake.
  //----------------------------------------------------------------------------
  assert_win_unchange #(`OVL_ERROR, 6, `OVL_ASSERT,
    "OVL Message : dapapbap - dapaddr not static for handshake duration")
      dapapbap_addr
        (
         .clk         (dapclk),
         .reset_n     (dapresetn),
         .start_event (hs_start),
         .test_expr   (dapaddr),
         .end_event   (hs_end)
        );

  //----------------------------------------------------------------------------
  // dapwdata should remain stable for the duration of handshake.
  //----------------------------------------------------------------------------
  assert_win_unchange #(`OVL_ERROR, 32, `OVL_ASSERT,
    "OVL Message : dapapbap - dapwdata not static for handshake duration")
      dapapbap_wdata
        (
         .clk         (dapclk),
         .reset_n     (dapresetn),
         .start_event (hs_start),
         .test_expr   (dapwdata),
         .end_event   (hs_end)
        );

`endif

endmodule // cxdapapbap
