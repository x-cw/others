// +FHDR----------------------------------------------------------------------------
// Project Name  : virtural_prj
// Author        : lidh
// Email         : lidh@innosilicon.com.cn
// Create On     : 2024/12/27 13:47
// Last Modified : 2025/03/03 13:42
// File Name     : dap_wrapper.v
// Description   :
// 
// Copyright (c) 2024 Innosilicon.
// ALL RIGHTS RESERVED
// 
// ---------------------------------------------------------------------------------
// Modification History:
// Date         By              Version                 Change Description
// ---------------------------------------------------------------------------------
// 2024/12/27   lidh            1.0                     Original
// 
// -FHDR----------------------------------------------------------------------------
`timescale 1ns/1ps

module dap_wrapper (
//internal used signal
output jtag_scr1_tck,
output apbap_dbgswen,

/*autoinput*/
// Beginning of automatic inputs (from unused autoinst inputs)
input [31:0]            apb1to2_prdatam1,       // To apb1to2_u0 of apb1to2.v
input                   apb1to2_preadym1,       // To apb1to2_u0 of apb1to2.v
input                   apb1to2_pslverrm1,      // To apb1to2_u0 of apb1to2.v
input [31:0]            apbic_prdatam1,         // To cx_apbic_u0 of cxapbic_top_13.v
input [31:0]            apbic_prdatam10,        // To cx_apbic_u0 of cxapbic_top_13.v
input [31:0]            apbic_prdatam11,        // To cx_apbic_u0 of cxapbic_top_13.v
input [31:0]            apbic_prdatam12,        // To cx_apbic_u0 of cxapbic_top_13.v
input [31:0]            apbic_prdatam2,         // To cx_apbic_u0 of cxapbic_top_13.v
input [31:0]            apbic_prdatam3,         // To cx_apbic_u0 of cxapbic_top_13.v
input [31:0]            apbic_prdatam4,         // To cx_apbic_u0 of cxapbic_top_13.v
input [31:0]            apbic_prdatam5,         // To cx_apbic_u0 of cxapbic_top_13.v
input [31:0]            apbic_prdatam6,         // To cx_apbic_u0 of cxapbic_top_13.v
input [31:0]            apbic_prdatam7,         // To cx_apbic_u0 of cxapbic_top_13.v
input [31:0]            apbic_prdatam8,         // To cx_apbic_u0 of cxapbic_top_13.v
input [31:0]            apbic_prdatam9,         // To cx_apbic_u0 of cxapbic_top_13.v
input                   apbic_preadym1,         // To cx_apbic_u0 of cxapbic_top_13.v
input                   apbic_preadym10,        // To cx_apbic_u0 of cxapbic_top_13.v
input                   apbic_preadym11,        // To cx_apbic_u0 of cxapbic_top_13.v
input                   apbic_preadym12,        // To cx_apbic_u0 of cxapbic_top_13.v
input                   apbic_preadym2,         // To cx_apbic_u0 of cxapbic_top_13.v
input                   apbic_preadym3,         // To cx_apbic_u0 of cxapbic_top_13.v
input                   apbic_preadym4,         // To cx_apbic_u0 of cxapbic_top_13.v
input                   apbic_preadym5,         // To cx_apbic_u0 of cxapbic_top_13.v
input                   apbic_preadym6,         // To cx_apbic_u0 of cxapbic_top_13.v
input                   apbic_preadym7,         // To cx_apbic_u0 of cxapbic_top_13.v
input                   apbic_preadym8,         // To cx_apbic_u0 of cxapbic_top_13.v
input                   apbic_preadym9,         // To cx_apbic_u0 of cxapbic_top_13.v
input                   apbic_pslverrm1,        // To cx_apbic_u0 of cxapbic_top_13.v
input                   apbic_pslverrm10,       // To cx_apbic_u0 of cxapbic_top_13.v
input                   apbic_pslverrm11,       // To cx_apbic_u0 of cxapbic_top_13.v
input                   apbic_pslverrm12,       // To cx_apbic_u0 of cxapbic_top_13.v
input                   apbic_pslverrm2,        // To cx_apbic_u0 of cxapbic_top_13.v
input                   apbic_pslverrm3,        // To cx_apbic_u0 of cxapbic_top_13.v
input                   apbic_pslverrm4,        // To cx_apbic_u0 of cxapbic_top_13.v
input                   apbic_pslverrm5,        // To cx_apbic_u0 of cxapbic_top_13.v
input                   apbic_pslverrm6,        // To cx_apbic_u0 of cxapbic_top_13.v
input                   apbic_pslverrm7,        // To cx_apbic_u0 of cxapbic_top_13.v
input                   apbic_pslverrm8,        // To cx_apbic_u0 of cxapbic_top_13.v
input                   apbic_pslverrm9,        // To cx_apbic_u0 of cxapbic_top_13.v
input                   axiap_arready,          // To cx_axiap_u0 of cxdapaxiap_1.v
input                   axiap_awready,          // To cx_axiap_u0 of cxdapaxiap_1.v
input [1:0]             axiap_bresp,            // To cx_axiap_u0 of cxdapaxiap_1.v
input                   axiap_bvalid,           // To cx_axiap_u0 of cxdapaxiap_1.v
input [31:0]            axiap_rdata,            // To cx_axiap_u0 of cxdapaxiap_1.v
input                   axiap_rlast,            // To cx_axiap_u0 of cxdapaxiap_1.v
input [1:0]             axiap_rresp,            // To cx_axiap_u0 of cxdapaxiap_1.v
input                   axiap_rvalid,           // To cx_axiap_u0 of cxdapaxiap_1.v
input                   axiap_wready,           // To cx_axiap_u0 of cxdapaxiap_1.v
input                   cs_jtag_ntrst,          // To cx_swjdp_u0 of cxdapswjdp.v
input                   cs_jtag_tck,            // To cx_swjdp_u0 of cxdapswjdp.v
input                   cs_jtag_tdi,            // To cx_swjdp_u0 of cxdapswjdp.v
input                   cs_jtag_tms,            // To cx_swjdp_u0 of cxdapswjdp.v
input                   dbg_clk,                // To cx_swjdp_u0 of cxdapswjdp.v, ...
input                   dbg_rstn,               // To cx_swjdp_u0 of cxdapswjdp.v, ...
input                   jtag_scr1_tdo,          // To cxdapjtagap_u0 of cxdapjtagap.v
input [16:2]            swdbg_paddr,            // To cx_apbic_u0 of cxapbic_top_13.v
input                   swdbg_penable,          // To cx_apbic_u0 of cxapbic_top_13.v
input                   swdbg_psel,             // To cx_apbic_u0 of cxapbic_top_13.v
input [31:0]            swdbg_pwdata,           // To cx_apbic_u0 of cxapbic_top_13.v
input                   swdbg_pwrite,           // To cx_apbic_u0 of cxapbic_top_13.v
input                   swjdp_npotrst,          // To cx_swjdp_u0 of cxdapswjdp.v
// End of automatics
/*autooutput*/
// Beginning of automatic outputs (from unused autoinst outputs)
output [11:0]           apb1to2_paddrm1,        // From apb1to2_u0 of apb1to2.v
output                  apb1to2_penablem1,      // From apb1to2_u0 of apb1to2.v
output                  apb1to2_pselm1,         // From apb1to2_u0 of apb1to2.v
output [31:0]           apb1to2_pwdatam1,       // From apb1to2_u0 of apb1to2.v
output                  apb1to2_pwritem1,       // From apb1to2_u0 of apb1to2.v
output                  apbic_paddr31m1,        // From cx_apbic_u0 of cxapbic_top_13.v
output                  apbic_paddr31m10,       // From cx_apbic_u0 of cxapbic_top_13.v
output                  apbic_paddr31m11,       // From cx_apbic_u0 of cxapbic_top_13.v
output                  apbic_paddr31m12,       // From cx_apbic_u0 of cxapbic_top_13.v
output                  apbic_paddr31m2,        // From cx_apbic_u0 of cxapbic_top_13.v
output                  apbic_paddr31m3,        // From cx_apbic_u0 of cxapbic_top_13.v
output                  apbic_paddr31m4,        // From cx_apbic_u0 of cxapbic_top_13.v
output                  apbic_paddr31m5,        // From cx_apbic_u0 of cxapbic_top_13.v
output                  apbic_paddr31m6,        // From cx_apbic_u0 of cxapbic_top_13.v
output                  apbic_paddr31m7,        // From cx_apbic_u0 of cxapbic_top_13.v
output                  apbic_paddr31m8,        // From cx_apbic_u0 of cxapbic_top_13.v
output                  apbic_paddr31m9,        // From cx_apbic_u0 of cxapbic_top_13.v
output [11:2]           apbic_paddrm1,          // From cx_apbic_u0 of cxapbic_top_13.v
output [11:2]           apbic_paddrm10,         // From cx_apbic_u0 of cxapbic_top_13.v
output [11:2]           apbic_paddrm11,         // From cx_apbic_u0 of cxapbic_top_13.v
output [15:2]           apbic_paddrm12,         // From cx_apbic_u0 of cxapbic_top_13.v
output [11:2]           apbic_paddrm2,          // From cx_apbic_u0 of cxapbic_top_13.v
output [11:2]           apbic_paddrm3,          // From cx_apbic_u0 of cxapbic_top_13.v
output [11:2]           apbic_paddrm4,          // From cx_apbic_u0 of cxapbic_top_13.v
output [11:2]           apbic_paddrm5,          // From cx_apbic_u0 of cxapbic_top_13.v
output [11:2]           apbic_paddrm6,          // From cx_apbic_u0 of cxapbic_top_13.v
output [11:2]           apbic_paddrm7,          // From cx_apbic_u0 of cxapbic_top_13.v
output [11:2]           apbic_paddrm8,          // From cx_apbic_u0 of cxapbic_top_13.v
output [11:2]           apbic_paddrm9,          // From cx_apbic_u0 of cxapbic_top_13.v
output                  apbic_penablem1,        // From cx_apbic_u0 of cxapbic_top_13.v
output                  apbic_penablem10,       // From cx_apbic_u0 of cxapbic_top_13.v
output                  apbic_penablem11,       // From cx_apbic_u0 of cxapbic_top_13.v
output                  apbic_penablem12,       // From cx_apbic_u0 of cxapbic_top_13.v
output                  apbic_penablem2,        // From cx_apbic_u0 of cxapbic_top_13.v
output                  apbic_penablem3,        // From cx_apbic_u0 of cxapbic_top_13.v
output                  apbic_penablem4,        // From cx_apbic_u0 of cxapbic_top_13.v
output                  apbic_penablem5,        // From cx_apbic_u0 of cxapbic_top_13.v
output                  apbic_penablem6,        // From cx_apbic_u0 of cxapbic_top_13.v
output                  apbic_penablem7,        // From cx_apbic_u0 of cxapbic_top_13.v
output                  apbic_penablem8,        // From cx_apbic_u0 of cxapbic_top_13.v
output                  apbic_penablem9,        // From cx_apbic_u0 of cxapbic_top_13.v
output                  apbic_pselm1,           // From cx_apbic_u0 of cxapbic_top_13.v
output                  apbic_pselm10,          // From cx_apbic_u0 of cxapbic_top_13.v
output                  apbic_pselm11,          // From cx_apbic_u0 of cxapbic_top_13.v
output                  apbic_pselm12,          // From cx_apbic_u0 of cxapbic_top_13.v
output                  apbic_pselm2,           // From cx_apbic_u0 of cxapbic_top_13.v
output                  apbic_pselm3,           // From cx_apbic_u0 of cxapbic_top_13.v
output                  apbic_pselm4,           // From cx_apbic_u0 of cxapbic_top_13.v
output                  apbic_pselm5,           // From cx_apbic_u0 of cxapbic_top_13.v
output                  apbic_pselm6,           // From cx_apbic_u0 of cxapbic_top_13.v
output                  apbic_pselm7,           // From cx_apbic_u0 of cxapbic_top_13.v
output                  apbic_pselm8,           // From cx_apbic_u0 of cxapbic_top_13.v
output                  apbic_pselm9,           // From cx_apbic_u0 of cxapbic_top_13.v
output [31:0]           apbic_pwdatam1,         // From cx_apbic_u0 of cxapbic_top_13.v
output [31:0]           apbic_pwdatam10,        // From cx_apbic_u0 of cxapbic_top_13.v
output [31:0]           apbic_pwdatam11,        // From cx_apbic_u0 of cxapbic_top_13.v
output [31:0]           apbic_pwdatam12,        // From cx_apbic_u0 of cxapbic_top_13.v
output [31:0]           apbic_pwdatam2,         // From cx_apbic_u0 of cxapbic_top_13.v
output [31:0]           apbic_pwdatam3,         // From cx_apbic_u0 of cxapbic_top_13.v
output [31:0]           apbic_pwdatam4,         // From cx_apbic_u0 of cxapbic_top_13.v
output [31:0]           apbic_pwdatam5,         // From cx_apbic_u0 of cxapbic_top_13.v
output [31:0]           apbic_pwdatam6,         // From cx_apbic_u0 of cxapbic_top_13.v
output [31:0]           apbic_pwdatam7,         // From cx_apbic_u0 of cxapbic_top_13.v
output [31:0]           apbic_pwdatam8,         // From cx_apbic_u0 of cxapbic_top_13.v
output [31:0]           apbic_pwdatam9,         // From cx_apbic_u0 of cxapbic_top_13.v
output                  apbic_pwritem1,         // From cx_apbic_u0 of cxapbic_top_13.v
output                  apbic_pwritem10,        // From cx_apbic_u0 of cxapbic_top_13.v
output                  apbic_pwritem11,        // From cx_apbic_u0 of cxapbic_top_13.v
output                  apbic_pwritem12,        // From cx_apbic_u0 of cxapbic_top_13.v
output                  apbic_pwritem2,         // From cx_apbic_u0 of cxapbic_top_13.v
output                  apbic_pwritem3,         // From cx_apbic_u0 of cxapbic_top_13.v
output                  apbic_pwritem4,         // From cx_apbic_u0 of cxapbic_top_13.v
output                  apbic_pwritem5,         // From cx_apbic_u0 of cxapbic_top_13.v
output                  apbic_pwritem6,         // From cx_apbic_u0 of cxapbic_top_13.v
output                  apbic_pwritem7,         // From cx_apbic_u0 of cxapbic_top_13.v
output                  apbic_pwritem8,         // From cx_apbic_u0 of cxapbic_top_13.v
output                  apbic_pwritem9,         // From cx_apbic_u0 of cxapbic_top_13.v
output [31:0]           atb_formatter_btm_pcie_r0_fr_reg,// From debug_reg_u0 of debug_reg.v
output [31:0]           atb_formatter_btm_pcie_r1_fr_reg,// From debug_reg_u0 of debug_reg.v
output [31:0]           atb_formatter_ctrl_scp_fr_reg,// From debug_reg_u0 of debug_reg.v
output [31:0]           atb_formatter_up_ualink0_fr_reg,// From debug_reg_u0 of debug_reg.v
output [31:0]           atb_formatter_up_ualink1_fr_reg,// From debug_reg_u0 of debug_reg.v
output [31:0]           atb_formatter_vpu0_jpeg0_fr_reg,// From debug_reg_u0 of debug_reg.v
output [31:0]           atb_formatter_vpu0_jpeg1_fr_reg,// From debug_reg_u0 of debug_reg.v
output [31:0]           atb_formatter_vpu0_vdec_fr_reg,// From debug_reg_u0 of debug_reg.v
output [31:0]           atb_formatter_vpu1_jpeg0_fr_reg,// From debug_reg_u0 of debug_reg.v
output [31:0]           atb_formatter_vpu1_jpeg1_fr_reg,// From debug_reg_u0 of debug_reg.v
output [31:0]           atb_formatter_vpu1_vdec_fr_reg,// From debug_reg_u0 of debug_reg.v
output [63:0]           axiap_araddr,           // From cx_axiap_u0 of cxdapaxiap_1.v
output [1:0]            axiap_arburst,          // From cx_axiap_u0 of cxdapaxiap_1.v
output [3:0]            axiap_arcache,          // From cx_axiap_u0 of cxdapaxiap_1.v
output [7:0]            axiap_arlen,            // From cx_axiap_u0 of cxdapaxiap_1.v
output [2:0]            axiap_arprot,           // From cx_axiap_u0 of cxdapaxiap_1.v
output [2:0]            axiap_arsize,           // From cx_axiap_u0 of cxdapaxiap_1.v
output [31:0]           axiap_aruser_fr_reg,    // From debug_reg_u0 of debug_reg.v
output                  axiap_arvalid,          // From cx_axiap_u0 of cxdapaxiap_1.v
output [63:0]           axiap_awaddr,           // From cx_axiap_u0 of cxdapaxiap_1.v
output [1:0]            axiap_awburst,          // From cx_axiap_u0 of cxdapaxiap_1.v
output [3:0]            axiap_awcache,          // From cx_axiap_u0 of cxdapaxiap_1.v
output [7:0]            axiap_awlen,            // From cx_axiap_u0 of cxdapaxiap_1.v
output [2:0]            axiap_awprot,           // From cx_axiap_u0 of cxdapaxiap_1.v
output [2:0]            axiap_awsize,           // From cx_axiap_u0 of cxdapaxiap_1.v
output [31:0]           axiap_awuser_fr_reg,    // From debug_reg_u0 of debug_reg.v
output                  axiap_awvalid,          // From cx_axiap_u0 of cxdapaxiap_1.v
output                  axiap_bready,           // From cx_axiap_u0 of cxdapaxiap_1.v
output                  axiap_rready,           // From cx_axiap_u0 of cxdapaxiap_1.v
output [31:0]           axiap_wdata,            // From cx_axiap_u0 of cxdapaxiap_1.v
output                  axiap_wlast,            // From cx_axiap_u0 of cxdapaxiap_1.v
output [3:0]            axiap_wstrb,            // From cx_axiap_u0 of cxdapaxiap_1.v
output                  axiap_wvalid,           // From cx_axiap_u0 of cxdapaxiap_1.v
output                  cs_jtag_ntdoen,         // From cx_swjdp_u0 of cxdapswjdp.v
output                  cs_jtag_tdo,            // From cx_swjdp_u0 of cxdapswjdp.v
output [10:0]           etr_addr_h11_fr_reg,    // From debug_reg_u0 of debug_reg.v
output [3:0]            etr_arqos_fr_reg,       // From debug_reg_u0 of debug_reg.v
output [15:0]           etr_aruser_fr_reg,      // From debug_reg_u0 of debug_reg.v
output [3:0]            etr_awqos_fr_reg,       // From debug_reg_u0 of debug_reg.v
output [15:0]           etr_awuser_fr_reg,      // From debug_reg_u0 of debug_reg.v
output                  jtag_scr1_tdi,          // From cxdapjtagap_u0 of cxdapjtagap.v
output                  jtag_scr1_tms,          // From cxdapjtagap_u0 of cxdapjtagap.v
output                  jtag_scr1_trst_n,       // From cxdapjtagap_u0 of cxdapjtagap.v
output [1:0]            reg_coresight_clk_sel,  // From debug_reg_u0 of debug_reg.v
output [2:0]            reg_coresight_freqdiv,  // From debug_reg_u0 of debug_reg.v
output [31:0]           swdbg_prdata,           // From cx_apbic_u0 of cxapbic_top_13.v
output                  swdbg_pready,           // From cx_apbic_u0 of cxapbic_top_13.v
output                  swdbg_pslverr           // From cx_apbic_u0 of cxapbic_top_13.v
// End of automatics
);
/*autowire*/
// Beginning of automatic wires (for undeclared instantiated-module outputs)
wire [11:0]             apb1to2_paddrm0;        // From apb1to2_u0 of apb1to2.v
wire                    apb1to2_penablem0;      // From apb1to2_u0 of apb1to2.v
wire [31:0]             apb1to2_prdatam0;       // From debug_reg_u0 of debug_reg.v
wire                    apb1to2_preadym0;       // From debug_reg_u0 of debug_reg.v
wire                    apb1to2_pselm0;         // From apb1to2_u0 of apb1to2.v
wire                    apb1to2_pslverrm0;      // From debug_reg_u0 of debug_reg.v
wire [31:0]             apb1to2_pwdatam0;       // From apb1to2_u0 of apb1to2.v
wire                    apb1to2_pwritem0;       // From apb1to2_u0 of apb1to2.v
wire [31:2]             apbap_paddr;            // From cx_apbap_u0 of cxdapapbap.v
wire                    apbap_penable;          // From cx_apbap_u0 of cxdapapbap.v
wire [31:0]             apbap_prdata;           // From cx_apbic_u0 of cxapbic_top_13.v
wire                    apbap_pready;           // From cx_apbic_u0 of cxapbic_top_13.v
wire                    apbap_psel;             // From cx_apbap_u0 of cxdapapbap.v
wire                    apbap_pslverr;          // From cx_apbic_u0 of cxapbic_top_13.v
wire [31:0]             apbap_pwdata;           // From cx_apbap_u0 of cxdapapbap.v
wire                    apbap_pwrite;           // From cx_apbap_u0 of cxdapapbap.v
wire [11:2]             apbic_paddrm0;          // From cx_apbic_u0 of cxapbic_top_13.v
wire                    apbic_penablem0;        // From cx_apbic_u0 of cxapbic_top_13.v
wire [31:0]             apbic_prdatam0;         // From apb1to2_u0 of apb1to2.v
wire                    apbic_preadym0;         // From apb1to2_u0 of apb1to2.v
wire                    apbic_pselm0;           // From cx_apbic_u0 of cxapbic_top_13.v
wire                    apbic_pslverrm0;        // From apb1to2_u0 of apb1to2.v
wire [31:0]             apbic_pwdatam0;         // From cx_apbic_u0 of cxapbic_top_13.v
wire                    apbic_pwritem0;         // From cx_apbic_u0 of cxapbic_top_13.v
wire                    dapabort_apbap;         // From cx_dapbus_u0 of cxdapbusic_3ap.v
wire                    dapabort_axiap;         // From cx_dapbus_u0 of cxdapbusic_3ap.v
wire                    dapabort_jtagap;        // From cx_dapbus_u0 of cxdapbusic_3ap.v
wire [7:2]              dapcaddr_apbap;         // From cx_dapbus_u0 of cxdapbusic_3ap.v
wire [7:2]              dapcaddr_axiap;         // From cx_dapbus_u0 of cxdapbusic_3ap.v
wire [7:2]              dapcaddr_jtagap;        // From cx_dapbus_u0 of cxdapbusic_3ap.v
wire                    dapenable_apbap;        // From cx_dapbus_u0 of cxdapbusic_3ap.v
wire                    dapenable_axiap;        // From cx_dapbus_u0 of cxdapbusic_3ap.v
wire                    dapenable_jtagap;       // From cx_dapbus_u0 of cxdapbusic_3ap.v
wire [31:0]             daprdata_apbap;         // From cx_apbap_u0 of cxdapapbap.v
wire [31:0]             daprdata_axiap;         // From cx_axiap_u0 of cxdapaxiap_1.v
wire [31:0]             daprdata_jtagap;        // From cxdapjtagap_u0 of cxdapjtagap.v
wire                    dapready_apbap;         // From cx_apbap_u0 of cxdapapbap.v
wire                    dapready_axiap;         // From cx_axiap_u0 of cxdapaxiap_1.v
wire                    dapready_jtagap;        // From cxdapjtagap_u0 of cxdapjtagap.v
wire                    dapsel_apbap;           // From cx_dapbus_u0 of cxdapbusic_3ap.v
wire                    dapsel_axiap;           // From cx_dapbus_u0 of cxdapbusic_3ap.v
wire                    dapsel_jtagap;          // From cx_dapbus_u0 of cxdapbusic_3ap.v
wire                    dapslverr_apbap;        // From cx_apbap_u0 of cxdapapbap.v
wire                    dapslverr_axiap;        // From cx_axiap_u0 of cxdapaxiap_1.v
wire [31:0]             dapwdata_apbap;         // From cx_dapbus_u0 of cxdapbusic_3ap.v
wire [31:0]             dapwdata_axiap;         // From cx_dapbus_u0 of cxdapbusic_3ap.v
wire [31:0]             dapwdata_jtagap;        // From cx_dapbus_u0 of cxdapbusic_3ap.v
wire                    dapwrite_apbap;         // From cx_dapbus_u0 of cxdapbusic_3ap.v
wire                    dapwrite_axiap;         // From cx_dapbus_u0 of cxdapbusic_3ap.v
wire                    dapwrite_jtagap;        // From cx_dapbus_u0 of cxdapbusic_3ap.v
wire                    swjdp_cdbgpwrupreq;     // From cx_swjdp_u0 of cxdapswjdp.v
wire                    swjdp_csyspwrupreq;     // From cx_swjdp_u0 of cxdapswjdp.v
wire                    swjdp_dapabort;         // From cx_swjdp_u0 of cxdapswjdp.v
wire [15:2]             swjdp_dapcaddr;         // From cx_swjdp_u0 of cxdapswjdp.v
wire                    swjdp_dapenable;        // From cx_swjdp_u0 of cxdapswjdp.v
wire [31:0]             swjdp_daprdata;         // From cx_dapbus_u0 of cxdapbusic_3ap.v
wire                    swjdp_dapready;         // From cx_dapbus_u0 of cxdapbusic_3ap.v
wire                    swjdp_dapsel;           // From cx_swjdp_u0 of cxdapswjdp.v
wire                    swjdp_dapslverr;        // From cx_dapbus_u0 of cxdapbusic_3ap.v
wire [31:0]             swjdp_dapwdata;         // From cx_swjdp_u0 of cxdapswjdp.v
wire                    swjdp_dapwrite;         // From cx_swjdp_u0 of cxdapswjdp.v
wire [6:0]              unused_jtag_tck;        // From cxdapjtagap_u0 of cxdapjtagap.v
wire [6:0]              unused_jtag_tdi;        // From cxdapjtagap_u0 of cxdapjtagap.v
wire [6:0]              unused_jtag_tms;        // From cxdapjtagap_u0 of cxdapjtagap.v
wire [6:0]              unused_jtag_trst_n;     // From cxdapjtagap_u0 of cxdapjtagap.v
// End of automatics

/* cxdapswjdp auto_template (
    //clk and resetn
    .dapresetn                (dbg_rstn),
    .dapclk                   (dbg_clk),
    .dapclken                 (1'b1),  

    .npotrst                  (swjdp_npotrst),  //power on resetn

    .targetid                 (32'h04500041),
    .instanceid               (4'h0),

    .swclktck                 (cs_jtag_tck),
    .swditms                  (cs_jtag_tms),
    .tdi                      (cs_jtag_tdi),
    .tdo                      (cs_jtag_tdo),
    .ntrst                    (cs_jtag_ntrst),
    .ntdoen                   (cs_jtag_ntdoen),
    .swdo                     (),
    .swdoen                   (),    

    .\(dap\)\(.*\)            (swjdp_\1\2[]),
    
    .cdbgpwrupreq             (swjdp_cdbgpwrupreq),
    .csyspwrupreq             (swjdp_csyspwrupreq),
    .cdbgrstreq               (),
    .cdbgpwrupack             (swjdp_cdbgpwrupreq),
    .csyspwrupack             (swjdp_csyspwrupreq),
    .cdbgrstack               (1'b0),

    .jtagnsw                  (),
    .jtagtop                  (),
    );
*/

cxdapswjdp #(.IRLEN8(0))
cx_swjdp_u0 (
/*autoinst*/
             // Outputs
             .swdo                      (),                      // Templated
             .swdoen                    (),                      // Templated
             .tdo                       (cs_jtag_tdo),           // Templated
             .ntdoen                    (cs_jtag_ntdoen),        // Templated
             .dapcaddr                  (swjdp_dapcaddr[15:2]),  // Templated
             .dapwrite                  (swjdp_dapwrite),        // Templated
             .dapenable                 (swjdp_dapenable),       // Templated
             .dapabort                  (swjdp_dapabort),        // Templated
             .dapsel                    (swjdp_dapsel),          // Templated
             .dapwdata                  (swjdp_dapwdata[31:0]),  // Templated
             .cdbgpwrupreq              (swjdp_cdbgpwrupreq),    // Templated
             .csyspwrupreq              (swjdp_csyspwrupreq),    // Templated
             .cdbgrstreq                (),                      // Templated
             .jtagnsw                   (),                      // Templated
             .jtagtop                   (),                      // Templated
             // Inputs
             .ntrst                     (cs_jtag_ntrst),         // Templated
             .npotrst                   (swjdp_npotrst),         // Templated
             .swclktck                  (cs_jtag_tck),           // Templated
             .swditms                   (cs_jtag_tms),           // Templated
             .tdi                       (cs_jtag_tdi),           // Templated
             .dapresetn                 (dbg_rstn),              // Templated
             .dapclk                    (dbg_clk),               // Templated
             .dapclken                  (1'b1),                  // Templated
             .daprdata                  (swjdp_daprdata[31:0]),  // Templated
             .dapready                  (swjdp_dapready),        // Templated
             .dapslverr                 (swjdp_dapslverr),       // Templated
             .cdbgpwrupack              (swjdp_cdbgpwrupreq),    // Templated
             .csyspwrupack              (swjdp_csyspwrupreq),    // Templated
             .cdbgrstack                (1'b0),                  // Templated
             .targetid                  (32'h04500041),          // Templated
             .instanceid                (4'h0));                         // Templated

/* cxdapbusic_3ap auto_template (
    .\(.*\)s    (swjdp_\1[]),
    .\(.*\)m0   (\1_axiap[]),
    .\(.*\)m1   (\1_apbap[]),

    .dapslverrm2    (1'b0),      
    .\(.*\)m2       (\1_jtagap[]),
)
*/

cxdapbusic_3ap 
cx_dapbus_u0 (
/*autoinst*/
              // Outputs
              .dapcaddrm2               (dapcaddr_jtagap[7:2]),  // Templated
              .dapselm2                 (dapsel_jtagap),         // Templated
              .dapenablem2              (dapenable_jtagap),      // Templated
              .dapwritem2               (dapwrite_jtagap),       // Templated
              .dapwdatam2               (dapwdata_jtagap[31:0]), // Templated
              .dapabortm2               (dapabort_jtagap),       // Templated
              .dapcaddrm1               (dapcaddr_apbap[7:2]),   // Templated
              .dapselm1                 (dapsel_apbap),          // Templated
              .dapenablem1              (dapenable_apbap),       // Templated
              .dapwritem1               (dapwrite_apbap),        // Templated
              .dapwdatam1               (dapwdata_apbap[31:0]),  // Templated
              .dapabortm1               (dapabort_apbap),        // Templated
              .dapcaddrm0               (dapcaddr_axiap[7:2]),   // Templated
              .dapselm0                 (dapsel_axiap),          // Templated
              .dapenablem0              (dapenable_axiap),       // Templated
              .dapwritem0               (dapwrite_axiap),        // Templated
              .dapwdatam0               (dapwdata_axiap[31:0]),  // Templated
              .dapabortm0               (dapabort_axiap),        // Templated
              .daprdatas                (swjdp_daprdata[31:0]),  // Templated
              .dapreadys                (swjdp_dapready),        // Templated
              .dapslverrs               (swjdp_dapslverr),       // Templated
              // Inputs
              .daprdatam2               (daprdata_jtagap[31:0]), // Templated
              .dapreadym2               (dapready_jtagap),       // Templated
              .dapslverrm2              (1'b0),                  // Templated
              .daprdatam1               (daprdata_apbap[31:0]),  // Templated
              .dapreadym1               (dapready_apbap),        // Templated
              .dapslverrm1              (dapslverr_apbap),       // Templated
              .daprdatam0               (daprdata_axiap[31:0]),  // Templated
              .dapreadym0               (dapready_axiap),        // Templated
              .dapslverrm0              (dapslverr_axiap),       // Templated
              .dapcaddrs                (swjdp_dapcaddr[15:2]),  // Templated
              .dapsels                  (swjdp_dapsel),          // Templated
              .dapenables               (swjdp_dapenable),       // Templated
              .dapwrites                (swjdp_dapwrite),        // Templated
              .dapwdatas                (swjdp_dapwdata[31:0]),  // Templated
              .dapaborts                (swjdp_dapabort));       // Templated


/* cxdapaxiap_1 auto_template (
    .clk            (dbg_clk),
    .resetn         (dbg_rstn),

    .\(dap.*\)      (\1_axiap[]),
    
    .dbgen          (1'b1),
    .spiden         (1'b1),
    
    .a.*domain      (),
    .a.*snoop       (),
    .a.*bar         (),
    .a.*lock        (),

    .rombaseaddru   (32'h0000_0000),
    .rombaseaddrl   (32'h0000_0002),

    .\(.*\)         (axiap_\1[]),
);
*/

cxdapaxiap_1 
cx_axiap_u0 (
/*autoinst*/
             // Outputs
             .daprdata                  (daprdata_axiap[31:0]),  // Templated
             .dapready                  (dapready_axiap),        // Templated
             .dapslverr                 (dapslverr_axiap),       // Templated
             .awaddr                    (axiap_awaddr[63:0]),    // Templated
             .awlen                     (axiap_awlen[7:0]),      // Templated
             .awsize                    (axiap_awsize[2:0]),     // Templated
             .awburst                   (axiap_awburst[1:0]),    // Templated
             .awlock                    (),                      // Templated
             .awcache                   (axiap_awcache[3:0]),    // Templated
             .awprot                    (axiap_awprot[2:0]),     // Templated
             .awvalid                   (axiap_awvalid),         // Templated
             .wdata                     (axiap_wdata[31:0]),     // Templated
             .wstrb                     (axiap_wstrb[3:0]),      // Templated
             .wlast                     (axiap_wlast),           // Templated
             .wvalid                    (axiap_wvalid),          // Templated
             .bready                    (axiap_bready),          // Templated
             .araddr                    (axiap_araddr[63:0]),    // Templated
             .arlen                     (axiap_arlen[7:0]),      // Templated
             .arsize                    (axiap_arsize[2:0]),     // Templated
             .arburst                   (axiap_arburst[1:0]),    // Templated
             .arlock                    (),                      // Templated
             .arcache                   (axiap_arcache[3:0]),    // Templated
             .arprot                    (axiap_arprot[2:0]),     // Templated
             .arvalid                   (axiap_arvalid),         // Templated
             .rready                    (axiap_rready),          // Templated
             .awdomain                  (),                      // Templated
             .awsnoop                   (),                      // Templated
             .awbar                     (),                      // Templated
             .ardomain                  (),                      // Templated
             .arsnoop                   (),                      // Templated
             .arbar                     (),                      // Templated
             // Inputs
             .clk                       (dbg_clk),               // Templated
             .resetn                    (dbg_rstn),              // Templated
             .dapcaddr                  (dapcaddr_axiap[7:2]),   // Templated
             .dapsel                    (dapsel_axiap),          // Templated
             .dapenable                 (dapenable_axiap),       // Templated
             .dapwrite                  (dapwrite_axiap),        // Templated
             .dapwdata                  (dapwdata_axiap[31:0]),  // Templated
             .dapabort                  (dapabort_axiap),        // Templated
             .dbgen                     (1'b1),                  // Templated
             .spiden                    (1'b1),                  // Templated
             .awready                   (axiap_awready),         // Templated
             .wready                    (axiap_wready),          // Templated
             .bresp                     (axiap_bresp[1:0]),      // Templated
             .bvalid                    (axiap_bvalid),          // Templated
             .arready                   (axiap_arready),         // Templated
             .rdata                     (axiap_rdata[31:0]),     // Templated
             .rresp                     (axiap_rresp[1:0]),      // Templated
             .rlast                     (axiap_rlast),           // Templated
             .rvalid                    (axiap_rvalid),          // Templated
             .rombaseaddru              (32'h0000_0000),         // Templated
             .rombaseaddrl              (32'h0000_0002));        // Templated





/* cxdapapbap auto_template (
    .dapclk         (dbg_clk),
    .dapclken       (1'b1),
    .dapresetn      (dbg_rstn),
    
    .\(dap.*\)      (\1_apbap[]),
    
    .deviceen       (1'b1),
    .rombaseaddr    (32'h0000_0003),
    .pdbgswen       (apbap_dbgswen),

    .\(p.*\)        (apbap_\1[]),  
);
*/

cxdapapbap 
cx_apbap_u0 (
/*autoinst*/
             // Outputs
             .dapready                  (dapready_apbap),        // Templated
             .dapslverr                 (dapslverr_apbap),       // Templated
             .daprdata                  (daprdata_apbap[31:0]),  // Templated
             .psel                      (apbap_psel),            // Templated
             .penable                   (apbap_penable),         // Templated
             .pwrite                    (apbap_pwrite),          // Templated
             .paddr                     (apbap_paddr[31:2]),     // Templated
             .pwdata                    (apbap_pwdata[31:0]),    // Templated
             .pdbgswen                  (apbap_dbgswen),         // Templated
             // Inputs
             .dapclk                    (dbg_clk),               // Templated
             .dapclken                  (1'b1),                  // Templated
             .dapresetn                 (dbg_rstn),              // Templated
             .dapsel                    (dapsel_apbap),          // Templated
             .dapenable                 (dapenable_apbap),       // Templated
             .dapwrite                  (dapwrite_apbap),        // Templated
             .dapabort                  (dapabort_apbap),        // Templated
             .dapcaddr                  (dapcaddr_apbap[7:2]),   // Templated
             .dapwdata                  (dapwdata_apbap[31:0]),  // Templated
             .pready                    (apbap_pready),          // Templated
             .pslverr                   (apbap_pslverr),         // Templated
             .prdata                    (apbap_prdata[31:0]),    // Templated
             .deviceen                  (1'b1),                  // Templated
             .rombaseaddr               (32'h0000_0003));        // Templated




/* cxapbic_top_13 auto_template (
  .clk              (dbg_clk),
  .resetn           (dbg_rstn),
    
  .targetid         (32'h0),
  .dbgswen          (apbap_dbgswen),

  .paddrs0          (apbap_paddr[16:2]),
  .paddr31s0        (apbap_paddr[31]),  
  .\(.*\)s0         (apbap_\1[]),

  .paddrs1          (swdbg_paddr[16:2]),
  .\(.*\)s1         (swdbg_\1[]),
   
  .paddr31m0        (),
  .\(.*\)           (apbic_\1[]),
);
*/

cxapbic_top_13
cx_apbic_u0 (
/*autoinst*/
             // Outputs
             .prdatas0                  (apbap_prdata[31:0]),    // Templated
             .preadys0                  (apbap_pready),          // Templated
             .pslverrs0                 (apbap_pslverr),         // Templated
             .prdatas1                  (swdbg_prdata[31:0]),    // Templated
             .preadys1                  (swdbg_pready),          // Templated
             .pslverrs1                 (swdbg_pslverr),         // Templated
             .paddrm0                   (apbic_paddrm0[(12+0)-1:2]), // Templated
             .paddr31m0                 (),                      // Templated
             .pselm0                    (apbic_pselm0),          // Templated
             .penablem0                 (apbic_penablem0),       // Templated
             .pwritem0                  (apbic_pwritem0),        // Templated
             .pwdatam0                  (apbic_pwdatam0[31:0]),  // Templated
             .paddrm1                   (apbic_paddrm1[(12+0)-1:2]), // Templated
             .paddr31m1                 (apbic_paddr31m1),       // Templated
             .pselm1                    (apbic_pselm1),          // Templated
             .penablem1                 (apbic_penablem1),       // Templated
             .pwritem1                  (apbic_pwritem1),        // Templated
             .pwdatam1                  (apbic_pwdatam1[31:0]),  // Templated
             .paddrm2                   (apbic_paddrm2[(12+0)-1:2]), // Templated
             .paddr31m2                 (apbic_paddr31m2),       // Templated
             .pselm2                    (apbic_pselm2),          // Templated
             .penablem2                 (apbic_penablem2),       // Templated
             .pwritem2                  (apbic_pwritem2),        // Templated
             .pwdatam2                  (apbic_pwdatam2[31:0]),  // Templated
             .paddrm3                   (apbic_paddrm3[(12+0)-1:2]), // Templated
             .paddr31m3                 (apbic_paddr31m3),       // Templated
             .pselm3                    (apbic_pselm3),          // Templated
             .penablem3                 (apbic_penablem3),       // Templated
             .pwritem3                  (apbic_pwritem3),        // Templated
             .pwdatam3                  (apbic_pwdatam3[31:0]),  // Templated
             .paddrm4                   (apbic_paddrm4[(12+0)-1:2]), // Templated
             .paddr31m4                 (apbic_paddr31m4),       // Templated
             .pselm4                    (apbic_pselm4),          // Templated
             .penablem4                 (apbic_penablem4),       // Templated
             .pwritem4                  (apbic_pwritem4),        // Templated
             .pwdatam4                  (apbic_pwdatam4[31:0]),  // Templated
             .paddrm5                   (apbic_paddrm5[(12+0)-1:2]), // Templated
             .paddr31m5                 (apbic_paddr31m5),       // Templated
             .pselm5                    (apbic_pselm5),          // Templated
             .penablem5                 (apbic_penablem5),       // Templated
             .pwritem5                  (apbic_pwritem5),        // Templated
             .pwdatam5                  (apbic_pwdatam5[31:0]),  // Templated
             .paddrm6                   (apbic_paddrm6[(12+0)-1:2]), // Templated
             .paddr31m6                 (apbic_paddr31m6),       // Templated
             .pselm6                    (apbic_pselm6),          // Templated
             .penablem6                 (apbic_penablem6),       // Templated
             .pwritem6                  (apbic_pwritem6),        // Templated
             .pwdatam6                  (apbic_pwdatam6[31:0]),  // Templated
             .paddrm7                   (apbic_paddrm7[(12+0)-1:2]), // Templated
             .paddr31m7                 (apbic_paddr31m7),       // Templated
             .pselm7                    (apbic_pselm7),          // Templated
             .penablem7                 (apbic_penablem7),       // Templated
             .pwritem7                  (apbic_pwritem7),        // Templated
             .pwdatam7                  (apbic_pwdatam7[31:0]),  // Templated
             .paddrm8                   (apbic_paddrm8[(12+0)-1:2]), // Templated
             .paddr31m8                 (apbic_paddr31m8),       // Templated
             .pselm8                    (apbic_pselm8),          // Templated
             .penablem8                 (apbic_penablem8),       // Templated
             .pwritem8                  (apbic_pwritem8),        // Templated
             .pwdatam8                  (apbic_pwdatam8[31:0]),  // Templated
             .paddrm9                   (apbic_paddrm9[(12+0)-1:2]), // Templated
             .paddr31m9                 (apbic_paddr31m9),       // Templated
             .pselm9                    (apbic_pselm9),          // Templated
             .penablem9                 (apbic_penablem9),       // Templated
             .pwritem9                  (apbic_pwritem9),        // Templated
             .pwdatam9                  (apbic_pwdatam9[31:0]),  // Templated
             .paddrm10                  (apbic_paddrm10[(12+0)-1:2]), // Templated
             .paddr31m10                (apbic_paddr31m10),      // Templated
             .pselm10                   (apbic_pselm10),         // Templated
             .penablem10                (apbic_penablem10),      // Templated
             .pwritem10                 (apbic_pwritem10),       // Templated
             .pwdatam10                 (apbic_pwdatam10[31:0]), // Templated
             .paddrm11                  (apbic_paddrm11[(12+0)-1:2]), // Templated
             .paddr31m11                (apbic_paddr31m11),      // Templated
             .pselm11                   (apbic_pselm11),         // Templated
             .penablem11                (apbic_penablem11),      // Templated
             .pwritem11                 (apbic_pwritem11),       // Templated
             .pwdatam11                 (apbic_pwdatam11[31:0]), // Templated
             .paddrm12                  (apbic_paddrm12[(12+4)-1:2]), // Templated
             .paddr31m12                (apbic_paddr31m12),      // Templated
             .pselm12                   (apbic_pselm12),         // Templated
             .penablem12                (apbic_penablem12),      // Templated
             .pwritem12                 (apbic_pwritem12),       // Templated
             .pwdatam12                 (apbic_pwdatam12[31:0]), // Templated
             // Inputs
             .clk                       (dbg_clk),               // Templated
             .resetn                    (dbg_rstn),              // Templated
             .paddrs0                   (apbap_paddr[16:2]),     // Templated
             .psels0                    (apbap_psel),            // Templated
             .penables0                 (apbap_penable),         // Templated
             .pwrites0                  (apbap_pwrite),          // Templated
             .pwdatas0                  (apbap_pwdata[31:0]),    // Templated
             .paddrs1                   (swdbg_paddr[16:2]),     // Templated
             .psels1                    (swdbg_psel),            // Templated
             .penables1                 (swdbg_penable),         // Templated
             .pwrites1                  (swdbg_pwrite),          // Templated
             .pwdatas1                  (swdbg_pwdata[31:0]),    // Templated
             .prdatam0                  (apbic_prdatam0[31:0]),  // Templated
             .preadym0                  (apbic_preadym0),        // Templated
             .pslverrm0                 (apbic_pslverrm0),       // Templated
             .prdatam1                  (apbic_prdatam1[31:0]),  // Templated
             .preadym1                  (apbic_preadym1),        // Templated
             .pslverrm1                 (apbic_pslverrm1),       // Templated
             .prdatam2                  (apbic_prdatam2[31:0]),  // Templated
             .preadym2                  (apbic_preadym2),        // Templated
             .pslverrm2                 (apbic_pslverrm2),       // Templated
             .prdatam3                  (apbic_prdatam3[31:0]),  // Templated
             .preadym3                  (apbic_preadym3),        // Templated
             .pslverrm3                 (apbic_pslverrm3),       // Templated
             .prdatam4                  (apbic_prdatam4[31:0]),  // Templated
             .preadym4                  (apbic_preadym4),        // Templated
             .pslverrm4                 (apbic_pslverrm4),       // Templated
             .prdatam5                  (apbic_prdatam5[31:0]),  // Templated
             .preadym5                  (apbic_preadym5),        // Templated
             .pslverrm5                 (apbic_pslverrm5),       // Templated
             .prdatam6                  (apbic_prdatam6[31:0]),  // Templated
             .preadym6                  (apbic_preadym6),        // Templated
             .pslverrm6                 (apbic_pslverrm6),       // Templated
             .prdatam7                  (apbic_prdatam7[31:0]),  // Templated
             .preadym7                  (apbic_preadym7),        // Templated
             .pslverrm7                 (apbic_pslverrm7),       // Templated
             .prdatam8                  (apbic_prdatam8[31:0]),  // Templated
             .preadym8                  (apbic_preadym8),        // Templated
             .pslverrm8                 (apbic_pslverrm8),       // Templated
             .prdatam9                  (apbic_prdatam9[31:0]),  // Templated
             .preadym9                  (apbic_preadym9),        // Templated
             .pslverrm9                 (apbic_pslverrm9),       // Templated
             .prdatam10                 (apbic_prdatam10[31:0]), // Templated
             .preadym10                 (apbic_preadym10),       // Templated
             .pslverrm10                (apbic_pslverrm10),      // Templated
             .prdatam11                 (apbic_prdatam11[31:0]), // Templated
             .preadym11                 (apbic_preadym11),       // Templated
             .pslverrm11                (apbic_pslverrm11),      // Templated
             .prdatam12                 (apbic_prdatam12[31:0]), // Templated
             .preadym12                 (apbic_preadym12),       // Templated
             .pslverrm12                (apbic_pslverrm12),      // Templated
             .targetid                  (32'h0),                 // Templated
             .paddr31s0                 (apbap_paddr[31]),       // Templated
             .dbgswen                   (apbap_dbgswen));        // Templated





/* cxdapjtagap auto_template (
    .dapclk         (dbg_clk),
    .dapclken       (1'b1),
    .dapresetn      (dbg_rstn),
    
    .\(dap.*\)      (\1_jtagap[]),
  
//jtag interface
    .csrtck         ({unused_jtag_tck[6:0],jtag_scr1_tck}),

    .cstdo          ({7'd0,jtag_scr1_tdo}),
    .cs\(.*\)       ({unused_jtag_\1[6:0],jtag_scr1_\1}),
    .ncstrst        ({unused_jtag_trst_n[6:0],jtag_scr1_trst_n}),

    .nsrstout       (),

//other interface
    .srstconnected  (8'h0),
    .portconnected  (8'h1),
    .portenabled    (8'h1),

);
*/

cxdapjtagap
cxdapjtagap_u0 (/*autoinst*/
                // Outputs
                .dapready               (dapready_jtagap),       // Templated
                .daprdata               (daprdata_jtagap[31:0]), // Templated
                .nsrstout               (),                      // Templated
                .ncstrst                ({unused_jtag_trst_n[6:0],jtag_scr1_trst_n}), // Templated
                .cstck                  ({unused_jtag_tck[6:0],jtag_scr1_tck}), // Templated
                .cstdi                  ({unused_jtag_tdi[6:0],jtag_scr1_tdi}), // Templated
                .cstms                  ({unused_jtag_tms[6:0],jtag_scr1_tms}), // Templated
                // Inputs
                .dapclk                 (dbg_clk),               // Templated
                .dapclken               (1'b1),                  // Templated
                .dapresetn              (dbg_rstn),              // Templated
                .dapsel                 (dapsel_jtagap),         // Templated
                .dapenable              (dapenable_jtagap),      // Templated
                .dapwrite               (dapwrite_jtagap),       // Templated
                .dapabort               (dapabort_jtagap),       // Templated
                .dapcaddr               (dapcaddr_jtagap[7:2]),  // Templated
                .dapwdata               (dapwdata_jtagap[31:0]), // Templated
                .csrtck                 ({unused_jtag_tck[6:0],jtag_scr1_tck}), // Templated
                .srstconnected          (8'h0),                  // Templated
                .portconnected          (8'h1),                  // Templated
                .portenabled            (8'h1),                  // Templated
                .cstdo                  ({7'd0,jtag_scr1_tdo}));         // Templated

/* apb1to2 auto_template (
    .paddrs   ({apbic_paddrm0[11:2],2'd0}),
    .\(p.*\)s      (apbic_\1m0[]),
    .\(p.*m.\)      (apb1to2_\1[]),
);
*/
apb1to2 apb1to2_u0 (/*autoinst*/
                    // Outputs
                    .prdatas            (apbic_prdatam0[31:0]),  // Templated
                    .preadys            (apbic_preadym0),        // Templated
                    .pslverrs           (apbic_pslverrm0),       // Templated
                    .paddrm0            (apb1to2_paddrm0[11:0]), // Templated
                    .pselm0             (apb1to2_pselm0),        // Templated
                    .penablem0          (apb1to2_penablem0),     // Templated
                    .pwritem0           (apb1to2_pwritem0),      // Templated
                    .pwdatam0           (apb1to2_pwdatam0[31:0]), // Templated
                    .paddrm1            (apb1to2_paddrm1[11:0]), // Templated
                    .pselm1             (apb1to2_pselm1),        // Templated
                    .penablem1          (apb1to2_penablem1),     // Templated
                    .pwritem1           (apb1to2_pwritem1),      // Templated
                    .pwdatam1           (apb1to2_pwdatam1[31:0]), // Templated
                    // Inputs
                    .paddrs             ({apbic_paddrm0[11:2],2'd0}), // Templated
                    .psels              (apbic_pselm0),          // Templated
                    .penables           (apbic_penablem0),       // Templated
                    .pwrites            (apbic_pwritem0),        // Templated
                    .pwdatas            (apbic_pwdatam0[31:0]),  // Templated
                    .prdatam0           (apb1to2_prdatam0[31:0]), // Templated
                    .preadym0           (apb1to2_preadym0),      // Templated
                    .pslverrm0          (apb1to2_pslverrm0),     // Templated
                    .prdatam1           (apb1to2_prdatam1[31:0]), // Templated
                    .preadym1           (apb1to2_preadym1),      // Templated
                    .pslverrm1          (apb1to2_pslverrm1));    // Templated

/* debug_reg auto_template (
    .pclk    (dbg_clk),
    .presetn (dbg_rstn),

    .paddr   ({20'd0,apb1to2_paddrm0[11:2],2'd0}),
    .\(p.*\)      (apb1to2_\1m0[]),
);
*/

debug_reg debug_reg_u0 (/*autoinst*/
                        // Outputs
                        .prdata         (apb1to2_prdatam0[31:0]), // Templated
                        .pready         (apb1to2_preadym0),      // Templated
                        .pslverr        (apb1to2_pslverrm0),     // Templated
                        .axiap_awuser_fr_reg(axiap_awuser_fr_reg[31:0]),
                        .axiap_aruser_fr_reg(axiap_aruser_fr_reg[31:0]),
                        .etr_awqos_fr_reg(etr_awqos_fr_reg[3:0]),
                        .etr_awuser_fr_reg(etr_awuser_fr_reg[15:0]),
                        .etr_arqos_fr_reg(etr_arqos_fr_reg[3:0]),
                        .etr_aruser_fr_reg(etr_aruser_fr_reg[15:0]),
                        .etr_addr_h11_fr_reg(etr_addr_h11_fr_reg[10:0]),
                        .atb_formatter_btm_pcie_r0_fr_reg(atb_formatter_btm_pcie_r0_fr_reg[31:0]),
                        .atb_formatter_btm_pcie_r1_fr_reg(atb_formatter_btm_pcie_r1_fr_reg[31:0]),
                        .atb_formatter_up_ualink0_fr_reg(atb_formatter_up_ualink0_fr_reg[31:0]),
                        .atb_formatter_up_ualink1_fr_reg(atb_formatter_up_ualink1_fr_reg[31:0]),
                        .atb_formatter_ctrl_scp_fr_reg(atb_formatter_ctrl_scp_fr_reg[31:0]),
                        .atb_formatter_vpu0_vdec_fr_reg(atb_formatter_vpu0_vdec_fr_reg[31:0]),
                        .atb_formatter_vpu0_jpeg0_fr_reg(atb_formatter_vpu0_jpeg0_fr_reg[31:0]),
                        .atb_formatter_vpu0_jpeg1_fr_reg(atb_formatter_vpu0_jpeg1_fr_reg[31:0]),
                        .atb_formatter_vpu1_vdec_fr_reg(atb_formatter_vpu1_vdec_fr_reg[31:0]),
                        .atb_formatter_vpu1_jpeg0_fr_reg(atb_formatter_vpu1_jpeg0_fr_reg[31:0]),
                        .atb_formatter_vpu1_jpeg1_fr_reg(atb_formatter_vpu1_jpeg1_fr_reg[31:0]),
                        .reg_coresight_clk_sel(reg_coresight_clk_sel[1:0]),
                        .reg_coresight_freqdiv(reg_coresight_freqdiv[2:0]),
                        // Inputs
                        .pclk           (dbg_clk),               // Templated
                        .presetn        (dbg_rstn),              // Templated
                        .paddr          ({20'd0,apb1to2_paddrm0[11:2],2'd0}), // Templated
                        .psel           (apb1to2_pselm0),        // Templated
                        .penable        (apb1to2_penablem0),     // Templated
                        .pwrite         (apb1to2_pwritem0),      // Templated
                        .pwdata         (apb1to2_pwdatam0[31:0])); // Templated


endmodule
// Local Variables:
// verilog-library-directories:("./"  "./debug_reg/" "../coresight_component/debug_module/cxapbic_top_15/verilog/" "../coresight_component/debug_module/cxapbic_top_13/verilog/" "../coresight_component/debug_module/cxapbmux/" "../coresight_component/debug_module/cxdapahbap/verilog/" "../coresight_component/debug_module/cxdapapbap/verilog/" "../coresight_component/debug_module/cxdapaxiap_1/verilog/" "../coresight_component/debug_module/cxdapbusic_3ap/verilog/" "../coresight_component/debug_module/cxdapjtagap/verilog/" "../coresight_component/debug_module/cxdapswjdp/verilog/" ) 
// verilog-auto-inst-param-value:t
// verilog-auto-output-ignore-regexp:"\\(unused.*\\)"
// End:
