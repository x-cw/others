$GP3_RTL/coresight/rtl/coresight_component/trace_module/cxatbfunnel_6_pro/verilog/cxatbfunnel_6_pro.v
$GP3_RTL/coresight/rtl/coresight_component/trace_module/cxatbfunnel_6_pro/verilog/cxatbfunnel_apb_if_6_pro.v
$GP3_RTL/coresight/rtl/coresight_component/trace_module/cxatbfunnel_6_pro/verilog/cxatbfunnel_arbiter_6_pro.v
$GP3_RTL/coresight/rtl/coresight_component/trace_module/cxatbfunnel_6_pro/verilog/cxatbfunnel_reg_blk_6_pro.v
