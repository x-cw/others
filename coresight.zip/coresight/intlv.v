//+FHDR*************************************************************************
// 
//   Copyright (c) 2024 Innosilicon. Ltd.  All rights reserved. 
// 
//   THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF INNOSILICON
//   The copyright notice above does not evidence any actual or intended
//   publication of such source code.
// 
//************************************************************************
//    Module name: intlv.v
//    Create by  : fangxn
//    Email      : fangxn@innosilicon.com.cn
//    Create time: 2025-07-24
//************************************************************************
//    Description: 
//-FHDR*************************************************************************

module intlv #(
    parameter    IDW        =   8,                      // the width of awid/arid
    parameter    ADDRW      =   51,                     // the width of awaddr/araddr
    parameter    LENW       =   4,                      // the width of awlen/arlen
    parameter    USERW      =   10,
    parameter    ATOPW      =   6,
    parameter    SLICE_0    =   1,                      // 2'd0: bypass 2'd1: forward  2'd2:backward 2'd3 full
    parameter    SLICE_1    =   1,
    parameter    SLICE_2    =   1,
    parameter    SLICE_3    =   1
)(    
    //clk&rstn signal
    input   wire            clk,
    input   wire            rstn,   
    
    //ddr intlv config signal
    input   wire    [3:0]   ddr_channel_size,       //capacity per ddr channel
                                                    //4'd0: 0.5GBytes
                                                    //4'd1: 0.75GBytes
                                                    //4'd2: 1GBytes
                                                    //4'd3: 1.5GBytes
                                                    //4'd4: 2GBytes
                                                    //4'd5: 3GBytes
                                                    //4'd6: 4GBytes
                                                    //4'd7: 6GBytes
                                                    //4'd8: 8GBytes(default)
    
    input   wire    [1:0]   ddr_intlv_mode,          //2'd0: Linear mode(bypass mode)
                                                    //2'd1: Linear hash mode
                                                    //2'd2: cfg hash mode(default)
                                                    //2'd3: reserved
    
    
    input   wire            ecc_mode,               //1'b0: ecc off(default),    1'b1: ecc on     
    input   wire    [79:0]  ddrch_damage,           //one-hot code for ddr channel damage infomation 1'b0:ddr channel not damage(default)   1'b1: ddr channel damage
    input   wire    [79:0]  bank_damage,            //one-hot code for ddr channel damage infomation 1'b0:ddr channel not damage(default)   1'b1: ddr channel damage
    
    
    input   wire    [3:0]   bankid_sel_0_0,         //put pa[value(bankid_sel_0_0)] at bankid_sel_0_0 position
                                                    //4'dx: PA[22+x]
                                                    //4'd0: PA[22]
                                                    //4'd1: PA[23]
                                                    //4'd2: PA[24]
                                                    //4'd3: PA[25]
                                                    //4'd4: PA[26]
                                                    //4'd5: PA[27]
                                                    //4'd6: PA[28]
                                                    //4'd7: PA[29]
                                                    //4'd8: 1'b0
                                                    //4'd9-15: reserved
    input   wire    [3:0]   bankid_sel_0_1,
    input   wire    [3:0]   bankid_sel_0_2,
    input   wire    [3:0]   bankid_sel_0_3,
    input   wire    [3:0]   bankid_sel_0_4,
    input   wire    [3:0]   bankid_sel_0_5,
    input   wire    [3:0]   bankid_sel_0_6,
    input   wire    [3:0]   bankid_sel_0_7,
    input   wire    [3:0]   bankid_sel_1_0,
    input   wire    [3:0]   bankid_sel_1_1,
    input   wire    [3:0]   bankid_sel_1_2,
    input   wire    [3:0]   bankid_sel_1_3,
    input   wire    [3:0]   bankid_sel_1_4,
    input   wire    [3:0]   bankid_sel_1_5,
    input   wire    [3:0]   bankid_sel_1_6,
    input   wire    [3:0]   bankid_sel_1_7,
    input   wire    [3:0]   bankid_sel_2_0,
    input   wire    [3:0]   bankid_sel_2_1,
    input   wire    [3:0]   bankid_sel_2_2,
    input   wire    [3:0]   bankid_sel_2_3,
    input   wire    [3:0]   bankid_sel_2_4,
    input   wire    [3:0]   bankid_sel_2_5,
    input   wire    [3:0]   bankid_sel_2_6,
    input   wire    [3:0]   bankid_sel_2_7,
    input   wire    [3:0]   bankid_sel_3_0,
    input   wire    [3:0]   bankid_sel_3_1,
    input   wire    [3:0]   bankid_sel_3_2,
    input   wire    [3:0]   bankid_sel_3_3,
    input   wire    [3:0]   bankid_sel_3_4,
    input   wire    [3:0]   bankid_sel_3_5,
    input   wire    [3:0]   bankid_sel_3_6,
    input   wire    [3:0]   bankid_sel_3_7,
    input   wire    [3:0]   bankid_sel_4_0,
    input   wire    [3:0]   bankid_sel_4_1,
    input   wire    [3:0]   bankid_sel_4_2,
    input   wire    [3:0]   bankid_sel_4_3,
    input   wire    [3:0]   bankid_sel_4_4,
    input   wire    [3:0]   bankid_sel_4_5,
    input   wire    [3:0]   bankid_sel_4_6,
    input   wire    [3:0]   bankid_sel_4_7,
    input   wire    [3:0]   bankid_sel_5_0,
    input   wire    [3:0]   bankid_sel_5_1,
    input   wire    [3:0]   bankid_sel_5_2,
    input   wire    [3:0]   bankid_sel_5_3,
    input   wire    [3:0]   bankid_sel_5_4,
    input   wire    [3:0]   bankid_sel_5_5,
    input   wire    [3:0]   bankid_sel_5_6,
    input   wire    [3:0]   bankid_sel_5_7,
    input   wire    [3:0]   bankid_sel_6_0,
    input   wire    [3:0]   bankid_sel_6_1,
    input   wire    [3:0]   bankid_sel_6_2,
    input   wire    [3:0]   bankid_sel_6_3,
    input   wire    [3:0]   bankid_sel_6_4,
    input   wire    [3:0]   bankid_sel_6_5,
    input   wire    [3:0]   bankid_sel_6_6,
    input   wire    [3:0]   bankid_sel_6_7,
    
    input   wire    [3:0]   setid_sel_0_0,          //put pa[value(setid_sel_0_0)] at setid_sel_0_0 position          
                                                    //4'dx: PA[22+x]
                                                    //4'd0: PA[22]
                                                    //4'd1: PA[23]
                                                    //4'd2: PA[24]
                                                    //4'd3: PA[25]
                                                    //4'd4: PA[26]
                                                    //4'd5: PA[27]
                                                    //4'd6: PA[28]
                                                    //4'd7: PA[29]
                                                    //4'd8: 1'b0
                                                    //4'd9-15: reserved
    
    input   wire    [3:0]   setid_sel_0_1,
    input   wire    [3:0]   setid_sel_0_2,
    input   wire    [3:0]   setid_sel_0_3,
    input   wire    [3:0]   setid_sel_0_4,
    input   wire    [3:0]   setid_sel_0_5,
    input   wire    [3:0]   setid_sel_0_6,
    input   wire    [3:0]   setid_sel_0_7,
    input   wire    [3:0]   setid_sel_1_0,
    input   wire    [3:0]   setid_sel_1_1,
    input   wire    [3:0]   setid_sel_1_2,
    input   wire    [3:0]   setid_sel_1_3,
    input   wire    [3:0]   setid_sel_1_4,
    input   wire    [3:0]   setid_sel_1_5,
    input   wire    [3:0]   setid_sel_1_6,
    input   wire    [3:0]   setid_sel_1_7,
    input   wire    [3:0]   setid_sel_2_0,
    input   wire    [3:0]   setid_sel_2_1,
    input   wire    [3:0]   setid_sel_2_2,
    input   wire    [3:0]   setid_sel_2_3,
    input   wire    [3:0]   setid_sel_2_4,
    input   wire    [3:0]   setid_sel_2_5,
    input   wire    [3:0]   setid_sel_2_6,
    input   wire    [3:0]   setid_sel_2_7,
    input   wire    [3:0]   setid_sel_3_0,
    input   wire    [3:0]   setid_sel_3_1,
    input   wire    [3:0]   setid_sel_3_2,
    input   wire    [3:0]   setid_sel_3_3,
    input   wire    [3:0]   setid_sel_3_4,
    input   wire    [3:0]   setid_sel_3_5,
    input   wire    [3:0]   setid_sel_3_6,
    input   wire    [3:0]   setid_sel_3_7,
    input   wire    [3:0]   setid_sel_4_0,
    input   wire    [3:0]   setid_sel_4_1,
    input   wire    [3:0]   setid_sel_4_2,
    input   wire    [3:0]   setid_sel_4_3,
    input   wire    [3:0]   setid_sel_4_4,
    input   wire    [3:0]   setid_sel_4_5,
    input   wire    [3:0]   setid_sel_4_6,
    input   wire    [3:0]   setid_sel_4_7,
    input   wire    [3:0]   setid_sel_5_0,
    input   wire    [3:0]   setid_sel_5_1,
    input   wire    [3:0]   setid_sel_5_2,
    input   wire    [3:0]   setid_sel_5_3,
    input   wire    [3:0]   setid_sel_5_4,
    input   wire    [3:0]   setid_sel_5_5,
    input   wire    [3:0]   setid_sel_5_6,
    input   wire    [3:0]   setid_sel_5_7,
    input   wire    [3:0]   setid_sel_6_0,
    input   wire    [3:0]   setid_sel_6_1,
    input   wire    [3:0]   setid_sel_6_2,
    input   wire    [3:0]   setid_sel_6_3,
    input   wire    [3:0]   setid_sel_6_4,
    input   wire    [3:0]   setid_sel_6_5,
    input   wire    [3:0]   setid_sel_6_6,
    input   wire    [3:0]   setid_sel_6_7,
    
    
    //buffer intlv config signal
    input   wire            buffer_mode,            //1'b0: 25%(5MBytes)    1'b1: 50%(10MBytes) (default)
    input   wire            buffer_intlv_mode,      // 1'b0: linear mode    1'b1: linear hash
    
    input   wire    [6:0]   ddr_intlv_bankid_0,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_1,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_2,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_3,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_4,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_5,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_6,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_7,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_8,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_9,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_10,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_11,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_12,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_13,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_14,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_15,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_16,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_17,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_18,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_19,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_20,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_21,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_22,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_23,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_24,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_25,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_26,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_27,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_28,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_29,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_30,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_31,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_32,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_33,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_34,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_35,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_36,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_37,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_38,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_39,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_40,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_41,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_42,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_43,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_44,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_45,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_46,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_47,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_48,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_49,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_50,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_51,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_52,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_53,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_54,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_55,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_56,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_57,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_58,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_59,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_60,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_61,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_62,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_63,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_64,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_65,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_66,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_67,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_68,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_69,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_70,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_71,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_72,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_73,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_74,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_75,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_76,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_77,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_78,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    input   wire    [6:0]   ddr_intlv_bankid_79,     //bankid_offset_in ddr intlv after considering bank damage and ddrc damage
    
    input   wire    [6:0]   buf_intlv_bankid_0,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_1,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_2,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_3,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_4,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_5,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_6,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_7,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_8,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_9,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_10,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_11,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_12,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_13,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_14,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_15,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_16,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_17,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_18,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_19,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_20,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_21,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_22,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_23,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_24,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_25,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_26,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_27,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_28,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_29,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_30,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_31,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_32,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_33,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_34,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_35,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_36,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_37,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_38,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_39,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_40,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_41,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_42,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_43,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_44,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_45,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_46,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_47,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_48,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_49,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_50,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_51,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_52,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_53,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_54,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_55,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_56,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_57,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_58,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_59,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_60,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_61,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_62,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_63,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_64,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_65,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_66,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_67,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_68,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_69,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_70,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_71,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_72,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_73,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_74,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_75,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_76,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_77,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_78,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    input   wire    [6:0]   buf_intlv_bankid_79,     //bankid_offset_in buf intlv after considering bank damage and bufc damage
    
    //  AXI  upstream signal
    input   wire                    upstrm_awvalid,
    output  wire                    upstrm_awready,
    input   wire    [IDW-1:0]       upstrm_awid,
    input   wire    [ADDRW-1:0]     upstrm_awaddr,
    input   wire    [LENW-1:0]      upstrm_awlen,
    input   wire    [2:0]           upstrm_awsize,
    input   wire    [1:0]           upstrm_awburst,
    input   wire    [2:0]           upstrm_awprot,
    input   wire    [3:0]           upstrm_awcache,
    input   wire    [3:0]           upstrm_awqos,
    input   wire    [USERW-1:0]     upstrm_awuser,
    input   wire    [ATOPW-1:0]     upstrm_awatop,
    input   wire                    upstrm_awlock,
    
    input   wire                    upstrm_arvalid,
    output  wire                    upstrm_arready,
    input   wire    [IDW-1:0]       upstrm_arid,
    input   wire    [ADDRW-1:0]     upstrm_araddr,
    input   wire    [LENW-1:0]      upstrm_arlen,
    input   wire    [2:0]           upstrm_arsize,
    input   wire    [1:0]           upstrm_arburst,
    input   wire    [2:0]           upstrm_arprot,
    input   wire    [3:0]           upstrm_arcache,
    input   wire    [3:0]           upstrm_arqos,
    input   wire    [USERW-1:0]     upstrm_aruser,
    input   wire                    upstrm_arlock,
    
    //  AXI  downstream signal
    output  wire                    downstrm_awvalid,
    input   wire                    downstrm_awready,
    output  wire    [IDW-1:0]       downstrm_awid,
    output  wire    [ADDRW-1:0]     downstrm_awaddr,
    output  wire    [LENW-1:0]      downstrm_awlen,
    output  wire    [2:0]           downstrm_awsize,
    output  wire    [1:0]           downstrm_awburst,
    output  wire    [2:0]           downstrm_awprot,
    output  wire    [3:0]           downstrm_awcache,
    output  wire    [3:0]           downstrm_awqos,
    output  wire    [USERW-1:0]     downstrm_awuser,
    output  wire    [ATOPW-1:0]     downstrm_awatop,
    output  wire                    downstrm_awlock,
    
    output  wire                    downstrm_arvalid,
    input   wire                    downstrm_arready,
    output  wire    [IDW-1:0]       downstrm_arid,
    output  wire    [ADDRW-1:0]     downstrm_araddr,
    output  wire    [LENW-1:0]      downstrm_arlen,
    output  wire    [2:0]           downstrm_arsize,
    output  wire    [1:0]           downstrm_arburst,
    output  wire    [2:0]           downstrm_arprot,    
    output  wire    [3:0]           downstrm_arcache,
    output  wire    [3:0]           downstrm_arqos,
    output  wire    [USERW-1:0]     downstrm_aruser,
    output  wire                    downstrm_arlock,
    
    //debug signal
    output  wire    [31:0]          debug_0,
    output  wire    [31:0]          debug_1,
    output  wire    [31:0]          debug_2,
    output  wire    [31:0]          debug_3
    );


/*autowire*/
// Beginning of automatic wires (for undeclared instantiated-module outputs)
wire [6:0]              bank_num;               // From intlv_ctrl_center_inst of intlv_ctrl_center.v
wire [6:0]              ddrch_num;              // From intlv_ctrl_center_inst of intlv_ctrl_center.v
wire [35:0]             scenario_ddr_cfghash;   // From intlv_ctrl_center_inst of intlv_ctrl_center.v
wire [35:0]             scenario_ddr_lnhash;    // From intlv_ctrl_center_inst of intlv_ctrl_center.v
wire [3:0]              scenario_l2c_lnhash;    // From intlv_ctrl_center_inst of intlv_ctrl_center.v
// End of automatics

/*intlv_ctrl_center auto_template (
); */

intlv_ctrl_center intlv_ctrl_center_inst(
    /*autoinst*/
                                         // Outputs
                                         .scenario_ddr_lnhash   (scenario_ddr_lnhash[35:0]),
                                         .scenario_ddr_cfghash  (scenario_ddr_cfghash[35:0]),
                                         .scenario_l2c_lnhash   (scenario_l2c_lnhash[3:0]),
                                         .ddrch_num             (ddrch_num[6:0]),
                                         .bank_num              (bank_num[6:0]),
                                         // Inputs
                                         .ddr_channel_size      (ddr_channel_size[3:0]),
                                         .ddr_intlv_mode        (ddr_intlv_mode[1:0]),
                                         .ddrch_damage          (ddrch_damage[79:0]),
                                         .ecc_mode              (ecc_mode),
                                         .buffer_mode           (buffer_mode),
                                         .buffer_intlv_mode     (buffer_intlv_mode),
                                         .bank_damage           (bank_damage[79:0]));
    

/*intlv_sub_main auto_template "intlv_sub_main_\(.*\)"(
    .\(.*strm_\)\(.*\)      (\1@\2[]),
    .\(debug.*\)            (\1_@[]),
);*/

intlv_sub_main #(
    .IDW    (IDW    ),                              
    .ADDRW  (ADDRW  ),                             
    .LENW   (LENW   ),                              
    .USERW  (USERW  ),                              
    .ATOPW  (ATOPW  ),                              
    .SLICE_0(SLICE_0),                              
    .SLICE_1(SLICE_1),                              
    .SLICE_2(SLICE_2)
)intlv_sub_main_aw(
    /*autoinst*/
                   // Outputs
                   .downstrm_id         (downstrm_awid[IDW-1:0]), // Templated
                   .downstrm_addr       (downstrm_awaddr[ADDRW-1:0]), // Templated
                   .downstrm_len        (downstrm_awlen[LENW-1:0]), // Templated
                   .downstrm_size       (downstrm_awsize[2:0]),  // Templated
                   .downstrm_burst      (downstrm_awburst[1:0]), // Templated
                   .downstrm_prot       (downstrm_awprot[2:0]),  // Templated
                   .downstrm_cache      (downstrm_awcache[3:0]), // Templated
                   .downstrm_qos        (downstrm_awqos[3:0]),   // Templated
                   .downstrm_user       (downstrm_awuser[USERW-1:0]), // Templated
                   .downstrm_atop       (downstrm_awatop[ATOPW-1:0]), // Templated
                   .downstrm_lock       (downstrm_awlock),       // Templated
                   .downstrm_valid      (downstrm_awvalid),      // Templated
                   .upstrm_ready        (upstrm_awready),        // Templated
                   // Inputs
                   .upstrm_id           (upstrm_awid[IDW-1:0]),  // Templated
                   .upstrm_addr         (upstrm_awaddr[ADDRW-1:0]), // Templated
                   .upstrm_len          (upstrm_awlen[LENW-1:0]), // Templated
                   .upstrm_size         (upstrm_awsize[2:0]),    // Templated
                   .upstrm_burst        (upstrm_awburst[1:0]),   // Templated
                   .upstrm_prot         (upstrm_awprot[2:0]),    // Templated
                   .upstrm_cache        (upstrm_awcache[3:0]),   // Templated
                   .upstrm_qos          (upstrm_awqos[3:0]),     // Templated
                   .upstrm_user         (upstrm_awuser[USERW-1:0]), // Templated
                   .upstrm_atop         (upstrm_awatop[ATOPW-1:0]), // Templated
                   .upstrm_lock         (upstrm_awlock),         // Templated
                   .bank_damage         (bank_damage[79:0]),
                   .ddr_intlv_bankid_0  (ddr_intlv_bankid_0[6:0]),
                   .ddr_intlv_bankid_1  (ddr_intlv_bankid_1[6:0]),
                   .ddr_intlv_bankid_2  (ddr_intlv_bankid_2[6:0]),
                   .ddr_intlv_bankid_3  (ddr_intlv_bankid_3[6:0]),
                   .ddr_intlv_bankid_4  (ddr_intlv_bankid_4[6:0]),
                   .ddr_intlv_bankid_5  (ddr_intlv_bankid_5[6:0]),
                   .ddr_intlv_bankid_6  (ddr_intlv_bankid_6[6:0]),
                   .ddr_intlv_bankid_7  (ddr_intlv_bankid_7[6:0]),
                   .ddr_intlv_bankid_8  (ddr_intlv_bankid_8[6:0]),
                   .ddr_intlv_bankid_9  (ddr_intlv_bankid_9[6:0]),
                   .ddr_intlv_bankid_10 (ddr_intlv_bankid_10[6:0]),
                   .ddr_intlv_bankid_11 (ddr_intlv_bankid_11[6:0]),
                   .ddr_intlv_bankid_12 (ddr_intlv_bankid_12[6:0]),
                   .ddr_intlv_bankid_13 (ddr_intlv_bankid_13[6:0]),
                   .ddr_intlv_bankid_14 (ddr_intlv_bankid_14[6:0]),
                   .ddr_intlv_bankid_15 (ddr_intlv_bankid_15[6:0]),
                   .ddr_intlv_bankid_16 (ddr_intlv_bankid_16[6:0]),
                   .ddr_intlv_bankid_17 (ddr_intlv_bankid_17[6:0]),
                   .ddr_intlv_bankid_18 (ddr_intlv_bankid_18[6:0]),
                   .ddr_intlv_bankid_19 (ddr_intlv_bankid_19[6:0]),
                   .ddr_intlv_bankid_20 (ddr_intlv_bankid_20[6:0]),
                   .ddr_intlv_bankid_21 (ddr_intlv_bankid_21[6:0]),
                   .ddr_intlv_bankid_22 (ddr_intlv_bankid_22[6:0]),
                   .ddr_intlv_bankid_23 (ddr_intlv_bankid_23[6:0]),
                   .ddr_intlv_bankid_24 (ddr_intlv_bankid_24[6:0]),
                   .ddr_intlv_bankid_25 (ddr_intlv_bankid_25[6:0]),
                   .ddr_intlv_bankid_26 (ddr_intlv_bankid_26[6:0]),
                   .ddr_intlv_bankid_27 (ddr_intlv_bankid_27[6:0]),
                   .ddr_intlv_bankid_28 (ddr_intlv_bankid_28[6:0]),
                   .ddr_intlv_bankid_29 (ddr_intlv_bankid_29[6:0]),
                   .ddr_intlv_bankid_30 (ddr_intlv_bankid_30[6:0]),
                   .ddr_intlv_bankid_31 (ddr_intlv_bankid_31[6:0]),
                   .ddr_intlv_bankid_32 (ddr_intlv_bankid_32[6:0]),
                   .ddr_intlv_bankid_33 (ddr_intlv_bankid_33[6:0]),
                   .ddr_intlv_bankid_34 (ddr_intlv_bankid_34[6:0]),
                   .ddr_intlv_bankid_35 (ddr_intlv_bankid_35[6:0]),
                   .ddr_intlv_bankid_36 (ddr_intlv_bankid_36[6:0]),
                   .ddr_intlv_bankid_37 (ddr_intlv_bankid_37[6:0]),
                   .ddr_intlv_bankid_38 (ddr_intlv_bankid_38[6:0]),
                   .ddr_intlv_bankid_39 (ddr_intlv_bankid_39[6:0]),
                   .ddr_intlv_bankid_40 (ddr_intlv_bankid_40[6:0]),
                   .ddr_intlv_bankid_41 (ddr_intlv_bankid_41[6:0]),
                   .ddr_intlv_bankid_42 (ddr_intlv_bankid_42[6:0]),
                   .ddr_intlv_bankid_43 (ddr_intlv_bankid_43[6:0]),
                   .ddr_intlv_bankid_44 (ddr_intlv_bankid_44[6:0]),
                   .ddr_intlv_bankid_45 (ddr_intlv_bankid_45[6:0]),
                   .ddr_intlv_bankid_46 (ddr_intlv_bankid_46[6:0]),
                   .ddr_intlv_bankid_47 (ddr_intlv_bankid_47[6:0]),
                   .ddr_intlv_bankid_48 (ddr_intlv_bankid_48[6:0]),
                   .ddr_intlv_bankid_49 (ddr_intlv_bankid_49[6:0]),
                   .ddr_intlv_bankid_50 (ddr_intlv_bankid_50[6:0]),
                   .ddr_intlv_bankid_51 (ddr_intlv_bankid_51[6:0]),
                   .ddr_intlv_bankid_52 (ddr_intlv_bankid_52[6:0]),
                   .ddr_intlv_bankid_53 (ddr_intlv_bankid_53[6:0]),
                   .ddr_intlv_bankid_54 (ddr_intlv_bankid_54[6:0]),
                   .ddr_intlv_bankid_55 (ddr_intlv_bankid_55[6:0]),
                   .ddr_intlv_bankid_56 (ddr_intlv_bankid_56[6:0]),
                   .ddr_intlv_bankid_57 (ddr_intlv_bankid_57[6:0]),
                   .ddr_intlv_bankid_58 (ddr_intlv_bankid_58[6:0]),
                   .ddr_intlv_bankid_59 (ddr_intlv_bankid_59[6:0]),
                   .ddr_intlv_bankid_60 (ddr_intlv_bankid_60[6:0]),
                   .ddr_intlv_bankid_61 (ddr_intlv_bankid_61[6:0]),
                   .ddr_intlv_bankid_62 (ddr_intlv_bankid_62[6:0]),
                   .ddr_intlv_bankid_63 (ddr_intlv_bankid_63[6:0]),
                   .ddr_intlv_bankid_64 (ddr_intlv_bankid_64[6:0]),
                   .ddr_intlv_bankid_65 (ddr_intlv_bankid_65[6:0]),
                   .ddr_intlv_bankid_66 (ddr_intlv_bankid_66[6:0]),
                   .ddr_intlv_bankid_67 (ddr_intlv_bankid_67[6:0]),
                   .ddr_intlv_bankid_68 (ddr_intlv_bankid_68[6:0]),
                   .ddr_intlv_bankid_69 (ddr_intlv_bankid_69[6:0]),
                   .ddr_intlv_bankid_70 (ddr_intlv_bankid_70[6:0]),
                   .ddr_intlv_bankid_71 (ddr_intlv_bankid_71[6:0]),
                   .ddr_intlv_bankid_72 (ddr_intlv_bankid_72[6:0]),
                   .ddr_intlv_bankid_73 (ddr_intlv_bankid_73[6:0]),
                   .ddr_intlv_bankid_74 (ddr_intlv_bankid_74[6:0]),
                   .ddr_intlv_bankid_75 (ddr_intlv_bankid_75[6:0]),
                   .ddr_intlv_bankid_76 (ddr_intlv_bankid_76[6:0]),
                   .ddr_intlv_bankid_77 (ddr_intlv_bankid_77[6:0]),
                   .ddr_intlv_bankid_78 (ddr_intlv_bankid_78[6:0]),
                   .ddr_intlv_bankid_79 (ddr_intlv_bankid_79[6:0]),
                   .buf_intlv_bankid_0  (buf_intlv_bankid_0[6:0]),
                   .buf_intlv_bankid_1  (buf_intlv_bankid_1[6:0]),
                   .buf_intlv_bankid_2  (buf_intlv_bankid_2[6:0]),
                   .buf_intlv_bankid_3  (buf_intlv_bankid_3[6:0]),
                   .buf_intlv_bankid_4  (buf_intlv_bankid_4[6:0]),
                   .buf_intlv_bankid_5  (buf_intlv_bankid_5[6:0]),
                   .buf_intlv_bankid_6  (buf_intlv_bankid_6[6:0]),
                   .buf_intlv_bankid_7  (buf_intlv_bankid_7[6:0]),
                   .buf_intlv_bankid_8  (buf_intlv_bankid_8[6:0]),
                   .buf_intlv_bankid_9  (buf_intlv_bankid_9[6:0]),
                   .buf_intlv_bankid_10 (buf_intlv_bankid_10[6:0]),
                   .buf_intlv_bankid_11 (buf_intlv_bankid_11[6:0]),
                   .buf_intlv_bankid_12 (buf_intlv_bankid_12[6:0]),
                   .buf_intlv_bankid_13 (buf_intlv_bankid_13[6:0]),
                   .buf_intlv_bankid_14 (buf_intlv_bankid_14[6:0]),
                   .buf_intlv_bankid_15 (buf_intlv_bankid_15[6:0]),
                   .buf_intlv_bankid_16 (buf_intlv_bankid_16[6:0]),
                   .buf_intlv_bankid_17 (buf_intlv_bankid_17[6:0]),
                   .buf_intlv_bankid_18 (buf_intlv_bankid_18[6:0]),
                   .buf_intlv_bankid_19 (buf_intlv_bankid_19[6:0]),
                   .buf_intlv_bankid_20 (buf_intlv_bankid_20[6:0]),
                   .buf_intlv_bankid_21 (buf_intlv_bankid_21[6:0]),
                   .buf_intlv_bankid_22 (buf_intlv_bankid_22[6:0]),
                   .buf_intlv_bankid_23 (buf_intlv_bankid_23[6:0]),
                   .buf_intlv_bankid_24 (buf_intlv_bankid_24[6:0]),
                   .buf_intlv_bankid_25 (buf_intlv_bankid_25[6:0]),
                   .buf_intlv_bankid_26 (buf_intlv_bankid_26[6:0]),
                   .buf_intlv_bankid_27 (buf_intlv_bankid_27[6:0]),
                   .buf_intlv_bankid_28 (buf_intlv_bankid_28[6:0]),
                   .buf_intlv_bankid_29 (buf_intlv_bankid_29[6:0]),
                   .buf_intlv_bankid_30 (buf_intlv_bankid_30[6:0]),
                   .buf_intlv_bankid_31 (buf_intlv_bankid_31[6:0]),
                   .buf_intlv_bankid_32 (buf_intlv_bankid_32[6:0]),
                   .buf_intlv_bankid_33 (buf_intlv_bankid_33[6:0]),
                   .buf_intlv_bankid_34 (buf_intlv_bankid_34[6:0]),
                   .buf_intlv_bankid_35 (buf_intlv_bankid_35[6:0]),
                   .buf_intlv_bankid_36 (buf_intlv_bankid_36[6:0]),
                   .buf_intlv_bankid_37 (buf_intlv_bankid_37[6:0]),
                   .buf_intlv_bankid_38 (buf_intlv_bankid_38[6:0]),
                   .buf_intlv_bankid_39 (buf_intlv_bankid_39[6:0]),
                   .buf_intlv_bankid_40 (buf_intlv_bankid_40[6:0]),
                   .buf_intlv_bankid_41 (buf_intlv_bankid_41[6:0]),
                   .buf_intlv_bankid_42 (buf_intlv_bankid_42[6:0]),
                   .buf_intlv_bankid_43 (buf_intlv_bankid_43[6:0]),
                   .buf_intlv_bankid_44 (buf_intlv_bankid_44[6:0]),
                   .buf_intlv_bankid_45 (buf_intlv_bankid_45[6:0]),
                   .buf_intlv_bankid_46 (buf_intlv_bankid_46[6:0]),
                   .buf_intlv_bankid_47 (buf_intlv_bankid_47[6:0]),
                   .buf_intlv_bankid_48 (buf_intlv_bankid_48[6:0]),
                   .buf_intlv_bankid_49 (buf_intlv_bankid_49[6:0]),
                   .buf_intlv_bankid_50 (buf_intlv_bankid_50[6:0]),
                   .buf_intlv_bankid_51 (buf_intlv_bankid_51[6:0]),
                   .buf_intlv_bankid_52 (buf_intlv_bankid_52[6:0]),
                   .buf_intlv_bankid_53 (buf_intlv_bankid_53[6:0]),
                   .buf_intlv_bankid_54 (buf_intlv_bankid_54[6:0]),
                   .buf_intlv_bankid_55 (buf_intlv_bankid_55[6:0]),
                   .buf_intlv_bankid_56 (buf_intlv_bankid_56[6:0]),
                   .buf_intlv_bankid_57 (buf_intlv_bankid_57[6:0]),
                   .buf_intlv_bankid_58 (buf_intlv_bankid_58[6:0]),
                   .buf_intlv_bankid_59 (buf_intlv_bankid_59[6:0]),
                   .buf_intlv_bankid_60 (buf_intlv_bankid_60[6:0]),
                   .buf_intlv_bankid_61 (buf_intlv_bankid_61[6:0]),
                   .buf_intlv_bankid_62 (buf_intlv_bankid_62[6:0]),
                   .buf_intlv_bankid_63 (buf_intlv_bankid_63[6:0]),
                   .buf_intlv_bankid_64 (buf_intlv_bankid_64[6:0]),
                   .buf_intlv_bankid_65 (buf_intlv_bankid_65[6:0]),
                   .buf_intlv_bankid_66 (buf_intlv_bankid_66[6:0]),
                   .buf_intlv_bankid_67 (buf_intlv_bankid_67[6:0]),
                   .buf_intlv_bankid_68 (buf_intlv_bankid_68[6:0]),
                   .buf_intlv_bankid_69 (buf_intlv_bankid_69[6:0]),
                   .buf_intlv_bankid_70 (buf_intlv_bankid_70[6:0]),
                   .buf_intlv_bankid_71 (buf_intlv_bankid_71[6:0]),
                   .buf_intlv_bankid_72 (buf_intlv_bankid_72[6:0]),
                   .buf_intlv_bankid_73 (buf_intlv_bankid_73[6:0]),
                   .buf_intlv_bankid_74 (buf_intlv_bankid_74[6:0]),
                   .buf_intlv_bankid_75 (buf_intlv_bankid_75[6:0]),
                   .buf_intlv_bankid_76 (buf_intlv_bankid_76[6:0]),
                   .buf_intlv_bankid_77 (buf_intlv_bankid_77[6:0]),
                   .buf_intlv_bankid_78 (buf_intlv_bankid_78[6:0]),
                   .buf_intlv_bankid_79 (buf_intlv_bankid_79[6:0]),
                   .bank_num            (bank_num[6:0]),
                   .bankid_sel_0_0      (bankid_sel_0_0[3:0]),
                   .bankid_sel_0_1      (bankid_sel_0_1[3:0]),
                   .bankid_sel_0_2      (bankid_sel_0_2[3:0]),
                   .bankid_sel_0_3      (bankid_sel_0_3[3:0]),
                   .bankid_sel_0_4      (bankid_sel_0_4[3:0]),
                   .bankid_sel_0_5      (bankid_sel_0_5[3:0]),
                   .bankid_sel_0_6      (bankid_sel_0_6[3:0]),
                   .bankid_sel_0_7      (bankid_sel_0_7[3:0]),
                   .bankid_sel_1_0      (bankid_sel_1_0[3:0]),
                   .bankid_sel_1_1      (bankid_sel_1_1[3:0]),
                   .bankid_sel_1_2      (bankid_sel_1_2[3:0]),
                   .bankid_sel_1_3      (bankid_sel_1_3[3:0]),
                   .bankid_sel_1_4      (bankid_sel_1_4[3:0]),
                   .bankid_sel_1_5      (bankid_sel_1_5[3:0]),
                   .bankid_sel_1_6      (bankid_sel_1_6[3:0]),
                   .bankid_sel_1_7      (bankid_sel_1_7[3:0]),
                   .bankid_sel_2_0      (bankid_sel_2_0[3:0]),
                   .bankid_sel_2_1      (bankid_sel_2_1[3:0]),
                   .bankid_sel_2_2      (bankid_sel_2_2[3:0]),
                   .bankid_sel_2_3      (bankid_sel_2_3[3:0]),
                   .bankid_sel_2_4      (bankid_sel_2_4[3:0]),
                   .bankid_sel_2_5      (bankid_sel_2_5[3:0]),
                   .bankid_sel_2_6      (bankid_sel_2_6[3:0]),
                   .bankid_sel_2_7      (bankid_sel_2_7[3:0]),
                   .bankid_sel_3_0      (bankid_sel_3_0[3:0]),
                   .bankid_sel_3_1      (bankid_sel_3_1[3:0]),
                   .bankid_sel_3_2      (bankid_sel_3_2[3:0]),
                   .bankid_sel_3_3      (bankid_sel_3_3[3:0]),
                   .bankid_sel_3_4      (bankid_sel_3_4[3:0]),
                   .bankid_sel_3_5      (bankid_sel_3_5[3:0]),
                   .bankid_sel_3_6      (bankid_sel_3_6[3:0]),
                   .bankid_sel_3_7      (bankid_sel_3_7[3:0]),
                   .bankid_sel_4_0      (bankid_sel_4_0[3:0]),
                   .bankid_sel_4_1      (bankid_sel_4_1[3:0]),
                   .bankid_sel_4_2      (bankid_sel_4_2[3:0]),
                   .bankid_sel_4_3      (bankid_sel_4_3[3:0]),
                   .bankid_sel_4_4      (bankid_sel_4_4[3:0]),
                   .bankid_sel_4_5      (bankid_sel_4_5[3:0]),
                   .bankid_sel_4_6      (bankid_sel_4_6[3:0]),
                   .bankid_sel_4_7      (bankid_sel_4_7[3:0]),
                   .bankid_sel_5_0      (bankid_sel_5_0[3:0]),
                   .bankid_sel_5_1      (bankid_sel_5_1[3:0]),
                   .bankid_sel_5_2      (bankid_sel_5_2[3:0]),
                   .bankid_sel_5_3      (bankid_sel_5_3[3:0]),
                   .bankid_sel_5_4      (bankid_sel_5_4[3:0]),
                   .bankid_sel_5_5      (bankid_sel_5_5[3:0]),
                   .bankid_sel_5_6      (bankid_sel_5_6[3:0]),
                   .bankid_sel_5_7      (bankid_sel_5_7[3:0]),
                   .bankid_sel_6_0      (bankid_sel_6_0[3:0]),
                   .bankid_sel_6_1      (bankid_sel_6_1[3:0]),
                   .bankid_sel_6_2      (bankid_sel_6_2[3:0]),
                   .bankid_sel_6_3      (bankid_sel_6_3[3:0]),
                   .bankid_sel_6_4      (bankid_sel_6_4[3:0]),
                   .bankid_sel_6_5      (bankid_sel_6_5[3:0]),
                   .bankid_sel_6_6      (bankid_sel_6_6[3:0]),
                   .bankid_sel_6_7      (bankid_sel_6_7[3:0]),
                   .clk                 (clk),
                   .ddrch_num           (ddrch_num[6:0]),
                   .downstrm_ready      (downstrm_awready),      // Templated
                   .rst_n               (rstn),
                   .scenario_ddr_cfghash(scenario_ddr_cfghash[35:0]),
                   .scenario_ddr_lnhash (scenario_ddr_lnhash[35:0]),
                   .scenario_l2c_lnhash (scenario_l2c_lnhash[3:0]),
                   .setid_sel_0_0       (setid_sel_0_0[3:0]),
                   .setid_sel_0_1       (setid_sel_0_1[3:0]),
                   .setid_sel_0_2       (setid_sel_0_2[3:0]),
                   .setid_sel_0_3       (setid_sel_0_3[3:0]),
                   .setid_sel_0_4       (setid_sel_0_4[3:0]),
                   .setid_sel_0_5       (setid_sel_0_5[3:0]),
                   .setid_sel_0_6       (setid_sel_0_6[3:0]),
                   .setid_sel_0_7       (setid_sel_0_7[3:0]),
                   .setid_sel_1_0       (setid_sel_1_0[3:0]),
                   .setid_sel_1_1       (setid_sel_1_1[3:0]),
                   .setid_sel_1_2       (setid_sel_1_2[3:0]),
                   .setid_sel_1_3       (setid_sel_1_3[3:0]),
                   .setid_sel_1_4       (setid_sel_1_4[3:0]),
                   .setid_sel_1_5       (setid_sel_1_5[3:0]),
                   .setid_sel_1_6       (setid_sel_1_6[3:0]),
                   .setid_sel_1_7       (setid_sel_1_7[3:0]),
                   .setid_sel_2_0       (setid_sel_2_0[3:0]),
                   .setid_sel_2_1       (setid_sel_2_1[3:0]),
                   .setid_sel_2_2       (setid_sel_2_2[3:0]),
                   .setid_sel_2_3       (setid_sel_2_3[3:0]),
                   .setid_sel_2_4       (setid_sel_2_4[3:0]),
                   .setid_sel_2_5       (setid_sel_2_5[3:0]),
                   .setid_sel_2_6       (setid_sel_2_6[3:0]),
                   .setid_sel_2_7       (setid_sel_2_7[3:0]),
                   .setid_sel_3_0       (setid_sel_3_0[3:0]),
                   .setid_sel_3_1       (setid_sel_3_1[3:0]),
                   .setid_sel_3_2       (setid_sel_3_2[3:0]),
                   .setid_sel_3_3       (setid_sel_3_3[3:0]),
                   .setid_sel_3_4       (setid_sel_3_4[3:0]),
                   .setid_sel_3_5       (setid_sel_3_5[3:0]),
                   .setid_sel_3_6       (setid_sel_3_6[3:0]),
                   .setid_sel_3_7       (setid_sel_3_7[3:0]),
                   .setid_sel_4_0       (setid_sel_4_0[3:0]),
                   .setid_sel_4_1       (setid_sel_4_1[3:0]),
                   .setid_sel_4_2       (setid_sel_4_2[3:0]),
                   .setid_sel_4_3       (setid_sel_4_3[3:0]),
                   .setid_sel_4_4       (setid_sel_4_4[3:0]),
                   .setid_sel_4_5       (setid_sel_4_5[3:0]),
                   .setid_sel_4_6       (setid_sel_4_6[3:0]),
                   .setid_sel_4_7       (setid_sel_4_7[3:0]),
                   .setid_sel_5_0       (setid_sel_5_0[3:0]),
                   .setid_sel_5_1       (setid_sel_5_1[3:0]),
                   .setid_sel_5_2       (setid_sel_5_2[3:0]),
                   .setid_sel_5_3       (setid_sel_5_3[3:0]),
                   .setid_sel_5_4       (setid_sel_5_4[3:0]),
                   .setid_sel_5_5       (setid_sel_5_5[3:0]),
                   .setid_sel_5_6       (setid_sel_5_6[3:0]),
                   .setid_sel_5_7       (setid_sel_5_7[3:0]),
                   .setid_sel_6_0       (setid_sel_6_0[3:0]),
                   .setid_sel_6_1       (setid_sel_6_1[3:0]),
                   .setid_sel_6_2       (setid_sel_6_2[3:0]),
                   .setid_sel_6_3       (setid_sel_6_3[3:0]),
                   .setid_sel_6_4       (setid_sel_6_4[3:0]),
                   .setid_sel_6_5       (setid_sel_6_5[3:0]),
                   .setid_sel_6_6       (setid_sel_6_6[3:0]),
                   .setid_sel_6_7       (setid_sel_6_7[3:0]),
                   .upstrm_valid        (upstrm_awvalid));       // Templated

/*intlv_sub_main auto_template "intlv_sub_main_\(.*\)"(
    .upstrm_atop            ({ATOPW{1'b0}}),
    .downstrm_atop          (),
    .\(.*strm_\)\(.*\)      (\1@\2[]),
    .\(debug.*\)            (\1_@[]),
);*/

intlv_sub_main #(
    .IDW    (IDW    ),                              
    .ADDRW  (ADDRW  ),                             
    .LENW   (LENW   ),                              
    .USERW  (USERW  ),                              
    .ATOPW  (ATOPW  ),                              
    .SLICE_0(SLICE_0),                              
    .SLICE_1(SLICE_1),                              
    .SLICE_2(SLICE_2)                              
)intlv_sub_main_ar(
    /*autoinst*/
                   // Outputs
                   .downstrm_id         (downstrm_arid[IDW-1:0]), // Templated
                   .downstrm_addr       (downstrm_araddr[ADDRW-1:0]), // Templated
                   .downstrm_len        (downstrm_arlen[LENW-1:0]), // Templated
                   .downstrm_size       (downstrm_arsize[2:0]),  // Templated
                   .downstrm_burst      (downstrm_arburst[1:0]), // Templated
                   .downstrm_prot       (downstrm_arprot[2:0]),  // Templated
                   .downstrm_cache      (downstrm_arcache[3:0]), // Templated
                   .downstrm_qos        (downstrm_arqos[3:0]),   // Templated
                   .downstrm_user       (downstrm_aruser[USERW-1:0]), // Templated
                   .downstrm_atop       (),                      // Templated
                   .downstrm_lock       (downstrm_arlock),       // Templated
                   .downstrm_valid      (downstrm_arvalid),      // Templated
                   .upstrm_ready        (upstrm_arready),        // Templated
                   // Inputs
                   .upstrm_id           (upstrm_arid[IDW-1:0]),  // Templated
                   .upstrm_addr         (upstrm_araddr[ADDRW-1:0]), // Templated
                   .upstrm_len          (upstrm_arlen[LENW-1:0]), // Templated
                   .upstrm_size         (upstrm_arsize[2:0]),    // Templated
                   .upstrm_burst        (upstrm_arburst[1:0]),   // Templated
                   .upstrm_prot         (upstrm_arprot[2:0]),    // Templated
                   .upstrm_cache        (upstrm_arcache[3:0]),   // Templated
                   .upstrm_qos          (upstrm_arqos[3:0]),     // Templated
                   .upstrm_user         (upstrm_aruser[USERW-1:0]), // Templated
                   .upstrm_atop         ({ATOPW{1'b0}}),         // Templated
                   .upstrm_lock         (upstrm_arlock),         // Templated
                   .bank_damage         (bank_damage[79:0]),
                   .ddr_intlv_bankid_0  (ddr_intlv_bankid_0[6:0]),
                   .ddr_intlv_bankid_1  (ddr_intlv_bankid_1[6:0]),
                   .ddr_intlv_bankid_2  (ddr_intlv_bankid_2[6:0]),
                   .ddr_intlv_bankid_3  (ddr_intlv_bankid_3[6:0]),
                   .ddr_intlv_bankid_4  (ddr_intlv_bankid_4[6:0]),
                   .ddr_intlv_bankid_5  (ddr_intlv_bankid_5[6:0]),
                   .ddr_intlv_bankid_6  (ddr_intlv_bankid_6[6:0]),
                   .ddr_intlv_bankid_7  (ddr_intlv_bankid_7[6:0]),
                   .ddr_intlv_bankid_8  (ddr_intlv_bankid_8[6:0]),
                   .ddr_intlv_bankid_9  (ddr_intlv_bankid_9[6:0]),
                   .ddr_intlv_bankid_10 (ddr_intlv_bankid_10[6:0]),
                   .ddr_intlv_bankid_11 (ddr_intlv_bankid_11[6:0]),
                   .ddr_intlv_bankid_12 (ddr_intlv_bankid_12[6:0]),
                   .ddr_intlv_bankid_13 (ddr_intlv_bankid_13[6:0]),
                   .ddr_intlv_bankid_14 (ddr_intlv_bankid_14[6:0]),
                   .ddr_intlv_bankid_15 (ddr_intlv_bankid_15[6:0]),
                   .ddr_intlv_bankid_16 (ddr_intlv_bankid_16[6:0]),
                   .ddr_intlv_bankid_17 (ddr_intlv_bankid_17[6:0]),
                   .ddr_intlv_bankid_18 (ddr_intlv_bankid_18[6:0]),
                   .ddr_intlv_bankid_19 (ddr_intlv_bankid_19[6:0]),
                   .ddr_intlv_bankid_20 (ddr_intlv_bankid_20[6:0]),
                   .ddr_intlv_bankid_21 (ddr_intlv_bankid_21[6:0]),
                   .ddr_intlv_bankid_22 (ddr_intlv_bankid_22[6:0]),
                   .ddr_intlv_bankid_23 (ddr_intlv_bankid_23[6:0]),
                   .ddr_intlv_bankid_24 (ddr_intlv_bankid_24[6:0]),
                   .ddr_intlv_bankid_25 (ddr_intlv_bankid_25[6:0]),
                   .ddr_intlv_bankid_26 (ddr_intlv_bankid_26[6:0]),
                   .ddr_intlv_bankid_27 (ddr_intlv_bankid_27[6:0]),
                   .ddr_intlv_bankid_28 (ddr_intlv_bankid_28[6:0]),
                   .ddr_intlv_bankid_29 (ddr_intlv_bankid_29[6:0]),
                   .ddr_intlv_bankid_30 (ddr_intlv_bankid_30[6:0]),
                   .ddr_intlv_bankid_31 (ddr_intlv_bankid_31[6:0]),
                   .ddr_intlv_bankid_32 (ddr_intlv_bankid_32[6:0]),
                   .ddr_intlv_bankid_33 (ddr_intlv_bankid_33[6:0]),
                   .ddr_intlv_bankid_34 (ddr_intlv_bankid_34[6:0]),
                   .ddr_intlv_bankid_35 (ddr_intlv_bankid_35[6:0]),
                   .ddr_intlv_bankid_36 (ddr_intlv_bankid_36[6:0]),
                   .ddr_intlv_bankid_37 (ddr_intlv_bankid_37[6:0]),
                   .ddr_intlv_bankid_38 (ddr_intlv_bankid_38[6:0]),
                   .ddr_intlv_bankid_39 (ddr_intlv_bankid_39[6:0]),
                   .ddr_intlv_bankid_40 (ddr_intlv_bankid_40[6:0]),
                   .ddr_intlv_bankid_41 (ddr_intlv_bankid_41[6:0]),
                   .ddr_intlv_bankid_42 (ddr_intlv_bankid_42[6:0]),
                   .ddr_intlv_bankid_43 (ddr_intlv_bankid_43[6:0]),
                   .ddr_intlv_bankid_44 (ddr_intlv_bankid_44[6:0]),
                   .ddr_intlv_bankid_45 (ddr_intlv_bankid_45[6:0]),
                   .ddr_intlv_bankid_46 (ddr_intlv_bankid_46[6:0]),
                   .ddr_intlv_bankid_47 (ddr_intlv_bankid_47[6:0]),
                   .ddr_intlv_bankid_48 (ddr_intlv_bankid_48[6:0]),
                   .ddr_intlv_bankid_49 (ddr_intlv_bankid_49[6:0]),
                   .ddr_intlv_bankid_50 (ddr_intlv_bankid_50[6:0]),
                   .ddr_intlv_bankid_51 (ddr_intlv_bankid_51[6:0]),
                   .ddr_intlv_bankid_52 (ddr_intlv_bankid_52[6:0]),
                   .ddr_intlv_bankid_53 (ddr_intlv_bankid_53[6:0]),
                   .ddr_intlv_bankid_54 (ddr_intlv_bankid_54[6:0]),
                   .ddr_intlv_bankid_55 (ddr_intlv_bankid_55[6:0]),
                   .ddr_intlv_bankid_56 (ddr_intlv_bankid_56[6:0]),
                   .ddr_intlv_bankid_57 (ddr_intlv_bankid_57[6:0]),
                   .ddr_intlv_bankid_58 (ddr_intlv_bankid_58[6:0]),
                   .ddr_intlv_bankid_59 (ddr_intlv_bankid_59[6:0]),
                   .ddr_intlv_bankid_60 (ddr_intlv_bankid_60[6:0]),
                   .ddr_intlv_bankid_61 (ddr_intlv_bankid_61[6:0]),
                   .ddr_intlv_bankid_62 (ddr_intlv_bankid_62[6:0]),
                   .ddr_intlv_bankid_63 (ddr_intlv_bankid_63[6:0]),
                   .ddr_intlv_bankid_64 (ddr_intlv_bankid_64[6:0]),
                   .ddr_intlv_bankid_65 (ddr_intlv_bankid_65[6:0]),
                   .ddr_intlv_bankid_66 (ddr_intlv_bankid_66[6:0]),
                   .ddr_intlv_bankid_67 (ddr_intlv_bankid_67[6:0]),
                   .ddr_intlv_bankid_68 (ddr_intlv_bankid_68[6:0]),
                   .ddr_intlv_bankid_69 (ddr_intlv_bankid_69[6:0]),
                   .ddr_intlv_bankid_70 (ddr_intlv_bankid_70[6:0]),
                   .ddr_intlv_bankid_71 (ddr_intlv_bankid_71[6:0]),
                   .ddr_intlv_bankid_72 (ddr_intlv_bankid_72[6:0]),
                   .ddr_intlv_bankid_73 (ddr_intlv_bankid_73[6:0]),
                   .ddr_intlv_bankid_74 (ddr_intlv_bankid_74[6:0]),
                   .ddr_intlv_bankid_75 (ddr_intlv_bankid_75[6:0]),
                   .ddr_intlv_bankid_76 (ddr_intlv_bankid_76[6:0]),
                   .ddr_intlv_bankid_77 (ddr_intlv_bankid_77[6:0]),
                   .ddr_intlv_bankid_78 (ddr_intlv_bankid_78[6:0]),
                   .ddr_intlv_bankid_79 (ddr_intlv_bankid_79[6:0]),
                   .buf_intlv_bankid_0  (buf_intlv_bankid_0[6:0]),
                   .buf_intlv_bankid_1  (buf_intlv_bankid_1[6:0]),
                   .buf_intlv_bankid_2  (buf_intlv_bankid_2[6:0]),
                   .buf_intlv_bankid_3  (buf_intlv_bankid_3[6:0]),
                   .buf_intlv_bankid_4  (buf_intlv_bankid_4[6:0]),
                   .buf_intlv_bankid_5  (buf_intlv_bankid_5[6:0]),
                   .buf_intlv_bankid_6  (buf_intlv_bankid_6[6:0]),
                   .buf_intlv_bankid_7  (buf_intlv_bankid_7[6:0]),
                   .buf_intlv_bankid_8  (buf_intlv_bankid_8[6:0]),
                   .buf_intlv_bankid_9  (buf_intlv_bankid_9[6:0]),
                   .buf_intlv_bankid_10 (buf_intlv_bankid_10[6:0]),
                   .buf_intlv_bankid_11 (buf_intlv_bankid_11[6:0]),
                   .buf_intlv_bankid_12 (buf_intlv_bankid_12[6:0]),
                   .buf_intlv_bankid_13 (buf_intlv_bankid_13[6:0]),
                   .buf_intlv_bankid_14 (buf_intlv_bankid_14[6:0]),
                   .buf_intlv_bankid_15 (buf_intlv_bankid_15[6:0]),
                   .buf_intlv_bankid_16 (buf_intlv_bankid_16[6:0]),
                   .buf_intlv_bankid_17 (buf_intlv_bankid_17[6:0]),
                   .buf_intlv_bankid_18 (buf_intlv_bankid_18[6:0]),
                   .buf_intlv_bankid_19 (buf_intlv_bankid_19[6:0]),
                   .buf_intlv_bankid_20 (buf_intlv_bankid_20[6:0]),
                   .buf_intlv_bankid_21 (buf_intlv_bankid_21[6:0]),
                   .buf_intlv_bankid_22 (buf_intlv_bankid_22[6:0]),
                   .buf_intlv_bankid_23 (buf_intlv_bankid_23[6:0]),
                   .buf_intlv_bankid_24 (buf_intlv_bankid_24[6:0]),
                   .buf_intlv_bankid_25 (buf_intlv_bankid_25[6:0]),
                   .buf_intlv_bankid_26 (buf_intlv_bankid_26[6:0]),
                   .buf_intlv_bankid_27 (buf_intlv_bankid_27[6:0]),
                   .buf_intlv_bankid_28 (buf_intlv_bankid_28[6:0]),
                   .buf_intlv_bankid_29 (buf_intlv_bankid_29[6:0]),
                   .buf_intlv_bankid_30 (buf_intlv_bankid_30[6:0]),
                   .buf_intlv_bankid_31 (buf_intlv_bankid_31[6:0]),
                   .buf_intlv_bankid_32 (buf_intlv_bankid_32[6:0]),
                   .buf_intlv_bankid_33 (buf_intlv_bankid_33[6:0]),
                   .buf_intlv_bankid_34 (buf_intlv_bankid_34[6:0]),
                   .buf_intlv_bankid_35 (buf_intlv_bankid_35[6:0]),
                   .buf_intlv_bankid_36 (buf_intlv_bankid_36[6:0]),
                   .buf_intlv_bankid_37 (buf_intlv_bankid_37[6:0]),
                   .buf_intlv_bankid_38 (buf_intlv_bankid_38[6:0]),
                   .buf_intlv_bankid_39 (buf_intlv_bankid_39[6:0]),
                   .buf_intlv_bankid_40 (buf_intlv_bankid_40[6:0]),
                   .buf_intlv_bankid_41 (buf_intlv_bankid_41[6:0]),
                   .buf_intlv_bankid_42 (buf_intlv_bankid_42[6:0]),
                   .buf_intlv_bankid_43 (buf_intlv_bankid_43[6:0]),
                   .buf_intlv_bankid_44 (buf_intlv_bankid_44[6:0]),
                   .buf_intlv_bankid_45 (buf_intlv_bankid_45[6:0]),
                   .buf_intlv_bankid_46 (buf_intlv_bankid_46[6:0]),
                   .buf_intlv_bankid_47 (buf_intlv_bankid_47[6:0]),
                   .buf_intlv_bankid_48 (buf_intlv_bankid_48[6:0]),
                   .buf_intlv_bankid_49 (buf_intlv_bankid_49[6:0]),
                   .buf_intlv_bankid_50 (buf_intlv_bankid_50[6:0]),
                   .buf_intlv_bankid_51 (buf_intlv_bankid_51[6:0]),
                   .buf_intlv_bankid_52 (buf_intlv_bankid_52[6:0]),
                   .buf_intlv_bankid_53 (buf_intlv_bankid_53[6:0]),
                   .buf_intlv_bankid_54 (buf_intlv_bankid_54[6:0]),
                   .buf_intlv_bankid_55 (buf_intlv_bankid_55[6:0]),
                   .buf_intlv_bankid_56 (buf_intlv_bankid_56[6:0]),
                   .buf_intlv_bankid_57 (buf_intlv_bankid_57[6:0]),
                   .buf_intlv_bankid_58 (buf_intlv_bankid_58[6:0]),
                   .buf_intlv_bankid_59 (buf_intlv_bankid_59[6:0]),
                   .buf_intlv_bankid_60 (buf_intlv_bankid_60[6:0]),
                   .buf_intlv_bankid_61 (buf_intlv_bankid_61[6:0]),
                   .buf_intlv_bankid_62 (buf_intlv_bankid_62[6:0]),
                   .buf_intlv_bankid_63 (buf_intlv_bankid_63[6:0]),
                   .buf_intlv_bankid_64 (buf_intlv_bankid_64[6:0]),
                   .buf_intlv_bankid_65 (buf_intlv_bankid_65[6:0]),
                   .buf_intlv_bankid_66 (buf_intlv_bankid_66[6:0]),
                   .buf_intlv_bankid_67 (buf_intlv_bankid_67[6:0]),
                   .buf_intlv_bankid_68 (buf_intlv_bankid_68[6:0]),
                   .buf_intlv_bankid_69 (buf_intlv_bankid_69[6:0]),
                   .buf_intlv_bankid_70 (buf_intlv_bankid_70[6:0]),
                   .buf_intlv_bankid_71 (buf_intlv_bankid_71[6:0]),
                   .buf_intlv_bankid_72 (buf_intlv_bankid_72[6:0]),
                   .buf_intlv_bankid_73 (buf_intlv_bankid_73[6:0]),
                   .buf_intlv_bankid_74 (buf_intlv_bankid_74[6:0]),
                   .buf_intlv_bankid_75 (buf_intlv_bankid_75[6:0]),
                   .buf_intlv_bankid_76 (buf_intlv_bankid_76[6:0]),
                   .buf_intlv_bankid_77 (buf_intlv_bankid_77[6:0]),
                   .buf_intlv_bankid_78 (buf_intlv_bankid_78[6:0]),
                   .buf_intlv_bankid_79 (buf_intlv_bankid_79[6:0]),
                   .bank_num            (bank_num[6:0]),
                   .bankid_sel_0_0      (bankid_sel_0_0[3:0]),
                   .bankid_sel_0_1      (bankid_sel_0_1[3:0]),
                   .bankid_sel_0_2      (bankid_sel_0_2[3:0]),
                   .bankid_sel_0_3      (bankid_sel_0_3[3:0]),
                   .bankid_sel_0_4      (bankid_sel_0_4[3:0]),
                   .bankid_sel_0_5      (bankid_sel_0_5[3:0]),
                   .bankid_sel_0_6      (bankid_sel_0_6[3:0]),
                   .bankid_sel_0_7      (bankid_sel_0_7[3:0]),
                   .bankid_sel_1_0      (bankid_sel_1_0[3:0]),
                   .bankid_sel_1_1      (bankid_sel_1_1[3:0]),
                   .bankid_sel_1_2      (bankid_sel_1_2[3:0]),
                   .bankid_sel_1_3      (bankid_sel_1_3[3:0]),
                   .bankid_sel_1_4      (bankid_sel_1_4[3:0]),
                   .bankid_sel_1_5      (bankid_sel_1_5[3:0]),
                   .bankid_sel_1_6      (bankid_sel_1_6[3:0]),
                   .bankid_sel_1_7      (bankid_sel_1_7[3:0]),
                   .bankid_sel_2_0      (bankid_sel_2_0[3:0]),
                   .bankid_sel_2_1      (bankid_sel_2_1[3:0]),
                   .bankid_sel_2_2      (bankid_sel_2_2[3:0]),
                   .bankid_sel_2_3      (bankid_sel_2_3[3:0]),
                   .bankid_sel_2_4      (bankid_sel_2_4[3:0]),
                   .bankid_sel_2_5      (bankid_sel_2_5[3:0]),
                   .bankid_sel_2_6      (bankid_sel_2_6[3:0]),
                   .bankid_sel_2_7      (bankid_sel_2_7[3:0]),
                   .bankid_sel_3_0      (bankid_sel_3_0[3:0]),
                   .bankid_sel_3_1      (bankid_sel_3_1[3:0]),
                   .bankid_sel_3_2      (bankid_sel_3_2[3:0]),
                   .bankid_sel_3_3      (bankid_sel_3_3[3:0]),
                   .bankid_sel_3_4      (bankid_sel_3_4[3:0]),
                   .bankid_sel_3_5      (bankid_sel_3_5[3:0]),
                   .bankid_sel_3_6      (bankid_sel_3_6[3:0]),
                   .bankid_sel_3_7      (bankid_sel_3_7[3:0]),
                   .bankid_sel_4_0      (bankid_sel_4_0[3:0]),
                   .bankid_sel_4_1      (bankid_sel_4_1[3:0]),
                   .bankid_sel_4_2      (bankid_sel_4_2[3:0]),
                   .bankid_sel_4_3      (bankid_sel_4_3[3:0]),
                   .bankid_sel_4_4      (bankid_sel_4_4[3:0]),
                   .bankid_sel_4_5      (bankid_sel_4_5[3:0]),
                   .bankid_sel_4_6      (bankid_sel_4_6[3:0]),
                   .bankid_sel_4_7      (bankid_sel_4_7[3:0]),
                   .bankid_sel_5_0      (bankid_sel_5_0[3:0]),
                   .bankid_sel_5_1      (bankid_sel_5_1[3:0]),
                   .bankid_sel_5_2      (bankid_sel_5_2[3:0]),
                   .bankid_sel_5_3      (bankid_sel_5_3[3:0]),
                   .bankid_sel_5_4      (bankid_sel_5_4[3:0]),
                   .bankid_sel_5_5      (bankid_sel_5_5[3:0]),
                   .bankid_sel_5_6      (bankid_sel_5_6[3:0]),
                   .bankid_sel_5_7      (bankid_sel_5_7[3:0]),
                   .bankid_sel_6_0      (bankid_sel_6_0[3:0]),
                   .bankid_sel_6_1      (bankid_sel_6_1[3:0]),
                   .bankid_sel_6_2      (bankid_sel_6_2[3:0]),
                   .bankid_sel_6_3      (bankid_sel_6_3[3:0]),
                   .bankid_sel_6_4      (bankid_sel_6_4[3:0]),
                   .bankid_sel_6_5      (bankid_sel_6_5[3:0]),
                   .bankid_sel_6_6      (bankid_sel_6_6[3:0]),
                   .bankid_sel_6_7      (bankid_sel_6_7[3:0]),
                   .clk                 (clk),
                   .ddrch_num           (ddrch_num[6:0]),
                   .downstrm_ready      (downstrm_arready),      // Templated
                   .rst_n               (rstn),
                   .scenario_ddr_cfghash(scenario_ddr_cfghash[35:0]),
                   .scenario_ddr_lnhash (scenario_ddr_lnhash[35:0]),
                   .scenario_l2c_lnhash (scenario_l2c_lnhash[3:0]),
                   .setid_sel_0_0       (setid_sel_0_0[3:0]),
                   .setid_sel_0_1       (setid_sel_0_1[3:0]),
                   .setid_sel_0_2       (setid_sel_0_2[3:0]),
                   .setid_sel_0_3       (setid_sel_0_3[3:0]),
                   .setid_sel_0_4       (setid_sel_0_4[3:0]),
                   .setid_sel_0_5       (setid_sel_0_5[3:0]),
                   .setid_sel_0_6       (setid_sel_0_6[3:0]),
                   .setid_sel_0_7       (setid_sel_0_7[3:0]),
                   .setid_sel_1_0       (setid_sel_1_0[3:0]),
                   .setid_sel_1_1       (setid_sel_1_1[3:0]),
                   .setid_sel_1_2       (setid_sel_1_2[3:0]),
                   .setid_sel_1_3       (setid_sel_1_3[3:0]),
                   .setid_sel_1_4       (setid_sel_1_4[3:0]),
                   .setid_sel_1_5       (setid_sel_1_5[3:0]),
                   .setid_sel_1_6       (setid_sel_1_6[3:0]),
                   .setid_sel_1_7       (setid_sel_1_7[3:0]),
                   .setid_sel_2_0       (setid_sel_2_0[3:0]),
                   .setid_sel_2_1       (setid_sel_2_1[3:0]),
                   .setid_sel_2_2       (setid_sel_2_2[3:0]),
                   .setid_sel_2_3       (setid_sel_2_3[3:0]),
                   .setid_sel_2_4       (setid_sel_2_4[3:0]),
                   .setid_sel_2_5       (setid_sel_2_5[3:0]),
                   .setid_sel_2_6       (setid_sel_2_6[3:0]),
                   .setid_sel_2_7       (setid_sel_2_7[3:0]),
                   .setid_sel_3_0       (setid_sel_3_0[3:0]),
                   .setid_sel_3_1       (setid_sel_3_1[3:0]),
                   .setid_sel_3_2       (setid_sel_3_2[3:0]),
                   .setid_sel_3_3       (setid_sel_3_3[3:0]),
                   .setid_sel_3_4       (setid_sel_3_4[3:0]),
                   .setid_sel_3_5       (setid_sel_3_5[3:0]),
                   .setid_sel_3_6       (setid_sel_3_6[3:0]),
                   .setid_sel_3_7       (setid_sel_3_7[3:0]),
                   .setid_sel_4_0       (setid_sel_4_0[3:0]),
                   .setid_sel_4_1       (setid_sel_4_1[3:0]),
                   .setid_sel_4_2       (setid_sel_4_2[3:0]),
                   .setid_sel_4_3       (setid_sel_4_3[3:0]),
                   .setid_sel_4_4       (setid_sel_4_4[3:0]),
                   .setid_sel_4_5       (setid_sel_4_5[3:0]),
                   .setid_sel_4_6       (setid_sel_4_6[3:0]),
                   .setid_sel_4_7       (setid_sel_4_7[3:0]),
                   .setid_sel_5_0       (setid_sel_5_0[3:0]),
                   .setid_sel_5_1       (setid_sel_5_1[3:0]),
                   .setid_sel_5_2       (setid_sel_5_2[3:0]),
                   .setid_sel_5_3       (setid_sel_5_3[3:0]),
                   .setid_sel_5_4       (setid_sel_5_4[3:0]),
                   .setid_sel_5_5       (setid_sel_5_5[3:0]),
                   .setid_sel_5_6       (setid_sel_5_6[3:0]),
                   .setid_sel_5_7       (setid_sel_5_7[3:0]),
                   .setid_sel_6_0       (setid_sel_6_0[3:0]),
                   .setid_sel_6_1       (setid_sel_6_1[3:0]),
                   .setid_sel_6_2       (setid_sel_6_2[3:0]),
                   .setid_sel_6_3       (setid_sel_6_3[3:0]),
                   .setid_sel_6_4       (setid_sel_6_4[3:0]),
                   .setid_sel_6_5       (setid_sel_6_5[3:0]),
                   .setid_sel_6_6       (setid_sel_6_6[3:0]),
                   .setid_sel_6_7       (setid_sel_6_7[3:0]),
                   .upstrm_valid        (upstrm_arvalid));       // Templated

assign  debug_0 =    32'd0;
assign  debug_1 =    32'd0;
assign  debug_2 =    32'd0;
assign  debug_3 =    32'd0;

endmodule

// Local Variables:
// verilog-library-directories:("./") 
// verilog-auto-inst-param-value:t
// End:
