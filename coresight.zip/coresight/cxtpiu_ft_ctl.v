//-----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2004-2015 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//    Checked In : $Date: 2014-08-14 16:01:35 +0100 (Thu, 14 Aug 2014) $
//    Revision   : $Revision: 39945 $
//    Release    : CoreSight-SoC-TM100-r3p2-00rel0
//-----------------------------------------------------------------------------
// Abstract : CoreSight Trace Port Interface (cxtpiu) - Formatter Control
//-----------------------------------------------------------------------------
//
// cxtpiu - CoreSight Trace Port Interface Unit
// --------------------------------------------
//
// CoreSight AMBA Trace Bus (ATB) sink device to store trace data in dedicated
// on chip 32-bit Trace RAM.
//
// cxtpiu_ft_ctl.v
// -------------
//
// cxtpiu_ft_ctl.v provides the formatter control logic for the cxtpiu.
//
// Instantiated blocks
// -------------------
//
// None
//
//-----------------------------------------------------------------------------

module cxtpiu_ft_ctl (
  // Inputs
  atclk, atclken, atresetn, afreadys, trigin_sync, flushin_sync,
  ffcr_stop_reg, ffcr_trig_reg, ffcr_flsh_reg, ffcr_f_on_man_reg, ffcr_ften_reg,
  trg_count_off, trg_one, itc_r_reg, it_tr_fl_in_ack_reg, it_atb_ctr_2_afv_reg,
  ft_stopped, ft_trig_ack, trig_port_done_sync,
  // Outputs
  afvalids, triginack, flushinack, trig_in_detect, trig_port, f_on_man_clr,
  ft_enable, ft_trig_req, ft_stop_req, f_on_man_active, afready_reg
  );

  //---------------------------------------------------------------------------
  // Inputs
  //---------------------------------------------------------------------------

  input         atclk;                // ATB clock
  input         atclken;              // Enable term for atclk domain
  input         atresetn;             // Reset for the atclk domain
  input         afreadys;             // Data flush compelete
  input         trigin_sync;          // Trigger input (syncd)
  input         flushin_sync;         // Flush input
  input [1:0]   ffcr_stop_reg;        // FFCR stop control register
  input [2:0]   ffcr_trig_reg;        // FFCR trigger control register
  input [1:0]   ffcr_flsh_reg;        // FFCR flush control register
  input         ffcr_f_on_man_reg;    // FFCR FOnMan register
  input [1:0]   ffcr_ften_reg;        // FFCR format enable register
  input         trg_count_off;        // Trigger counter disabled (zero)
  input         trg_one;              // Trigger cnt change from 1 to 0
  input         itc_r_reg;            // Integration mode control reg
  input [1:0]   it_tr_fl_in_ack_reg;  // Integration triginack=0 flushinack=1 reg
  input         it_atb_ctr_2_afv_reg; // Integration afvalids
  input         ft_stopped;           // Formatter stopped
  input         ft_trig_ack;          // Trigger acknowledgement
  input         trig_port_done_sync;  // Acknowledgement of Trigger indication

  //---------------------------------------------------------------------------
  // Outputs
  //---------------------------------------------------------------------------

  output        afvalids;        // Flush data
  output        triginack;       // Trigger input acknowledgement
  output        flushinack;      // Flush input acknowledgement
  output        trig_in_detect;  // Trigger detected on trigin
  output        trig_port;       // Indicate Trigger via tracectl
  output        f_on_man_clr;    // Clear FOnMan bit in FFCR
  output        ft_enable;       // Enable formatting
  output        ft_trig_req;     // Trigger request
  output        ft_stop_req;     // Stop request
  output        f_on_man_active; // Manual flush in progress
  output        afready_reg;     // Integration afreadys

  //---------------------------------------------------------------------------
  // Signals
  //---------------------------------------------------------------------------

  // Registered afreadys
  wire          afready_reg_qual;
  wire          afready_reg;
  reg           afready_reg_int;

  // Formatter enable
  wire          ft_enable;

  // Trigger Enable Event generation
  reg           trigin_reg_2;
  wire          trig_in_detect;      // Trigger detected on trigin input
  wire          trig_in_detect_int;  // Internal version of trig_in_detect
  wire          trigger_event;       // Trigger event has occurred
  wire          t_on_flush_detect;
  wire          t_on_trig_evt_detect;
  wire          t_on_trig_in_detect;
  wire          nxt_trigin_ack;
  reg           triginack;

  // Trigger request generation Embedding or tracectl (where applicable)
  wire          nxt_trig_req;
  wire          trig_req_en;
  wire          trig_ack;
  reg           trig_req;
  wire          nxt_trig_port;
  wire          trig_port;
  reg           trigport_cdc_check;

  // Formatter flush request generation
  wire          f_on_man_detect;
  reg           f_on_man_reg;
  wire          f_on_trig_detect;
  wire          f_on_fl_in_detect;
  wire          nxt_f_on_man_clr;
  reg           f_on_man_clr;
  wire          flushinack;
  reg           flushinack_int;
  wire          nxt_flushin_ack;
  wire          f_on_man_active;      //Active = Flushing now
  wire          f_on_man_active_int;  // Internal version of f_on_man_active
  wire          f_on_trig_active;
  wire          f_on_fl_in_active;
  reg           f_on_man_active_reg;
  reg           f_on_trig_active_reg;
  reg           f_on_fl_in_active_reg;
  wire          nxt_f_on_man_pend;    // Pending for current flush to complete
  wire          nxt_f_on_trig_pend;
  wire          nxt_f_on_fl_in_pend;
  reg           f_on_man_pend;
  reg           f_on_trig_pend;
  reg           f_on_fl_in_pend;
  wire          f_on_man_ready;       // Pending flush to be serviced (to be Active)
  wire          f_on_trig_ready;
  wire          f_on_fl_in_ready;
  wire          nxt_afvalids;         // Next state of afvalids ATB flush data request
  wire          afvalids;
  reg           afvalids_int;
  reg           afvalid_reg;

  // Formatter stop request generation
  wire          st_on_trig_detect;
  wire          st_on_fl_detect;
  wire          st_on_trig_active;  // Stopping
  wire          st_on_fl_active;
  reg           st_on_trig_active_reg;
  reg           st_on_fl_active_reg;
  reg           trig_ack_reg;
  wire          nxt_st_trig_pend;  // Pending stop to be sent Active
  wire          nxt_st_fl_pend;
  reg           st_trig_pend;
  reg           st_fl_pend;
  wire          st_trig_ready;     // Ready to stop
  wire          st_fl_ready;
  wire          nxt_ft_stop_req;   // Stop request made (active)
  wire          ft_stop_req;
  reg           ft_stop_req_int;

  // --------------------------------------------------------------------------
  //  Main body of code
  //  =================
  // --------------------------------------------------------------------------

  // Register afreadys (timing path issue)
  assign afready_reg_qual = afready_reg_int & afvalid_reg;

  // Register Flush Ack
  always @(posedge atclk or negedge atresetn)
    begin : p_ctlseq_afrdy
      if (!atresetn)
        afready_reg_int <= 1'b0;
      else if (atclken)
        afready_reg_int <= afreadys;
    end // p_ctlseq_afrdy
    assign afready_reg = afready_reg_int;

  // --------------------------------------------------------------------------
  // Formatter enable
  //
  // ATB data formatting and source ID embedding only needs to be enabled when
  // in Normal or Continuous mode, i.e. if FfcrFtEnReg is 2'b11, 2'b10, 2'b01
  // --------------------------------------------------------------------------

  assign ft_enable = |ffcr_ften_reg;

  // --------------------------------------------------------------------------
  // Trigger Enable Event generation
  //
  // These are one-shot events that mark a 'Trigger' (a marker in time of an
  // event occuring within the system).
  // They can be based upon Flush completion, Countdowns after an event or an
  // external pin. Each dependant upon the enable settings.
  // --------------------------------------------------------------------------

  // ffcr_trig_reg
  // [2] TrigFl
  // [1] TrigEvt
  // [0] TrigIn

  // Trigger event generation
  //
  // Occurs when trigger counter @0 and prev @0 with trigin rising
  // Occurs when trigger counter @0 and prev @1 (trg_one from CSEtbRegA)

  // Double register trigin to support asynchronous trigin timing

  // Trigger event registers
  always @(posedge atclk or negedge atresetn)
    begin : p_ctlseq_triggerevent
      if (!atresetn)
        trigin_reg_2 <= 1'b0;
      else if (atclken)
        trigin_reg_2 <= trigin_sync;
    end // p_ctlseq_triggerevent

  // Trigger edge detection from the trigin port
  assign trig_in_detect_int = trigin_sync & ~trigin_reg_2;
  assign trig_in_detect = trig_in_detect_int;
  // Indicate that a trigger event has occurred.
  assign trigger_event = (trig_in_detect_int & trg_count_off) | trg_one;

  // ffcr_trig_reg[2] = TrigFl. Generate a trigger when a flush completes
  // When this bit is set a trigger will be generated when a flush completes
  // A flush completes when afreadys is HIGH, only when afvalids is HIGH
  assign t_on_flush_detect = ffcr_trig_reg[2] & afready_reg_qual;

  // ffcr_trig_reg[1] = TrigEvt. Generate a trigger when a trigger event occurs
  // When this bit is set a trigger will be generated on a trigger event
  assign t_on_trig_evt_detect = ffcr_trig_reg[1] & trigger_event;

  // ffcr_trig_reg[0] = TrigIn. Generate trigger when trigin changes from 0 to 1
  // If this bit is set a trigger will be generated on a trigin rising edge
  //reg    TOnTrigInDetectReg;
  assign t_on_trig_in_detect = ffcr_trig_reg[0] & trig_in_detect_int;

  // Output triginack
  //
  // Integration mode support also provided
  assign nxt_trigin_ack = itc_r_reg ? it_tr_fl_in_ack_reg[0] : trigin_sync;

  // Register Trigger Ack
  always @(posedge atclk or negedge atresetn)
    begin : p_ctlreq_track
      if (!atresetn)
        triginack <= 1'b0;
      else if (atclken)
        triginack <= nxt_trigin_ack;
    end // p_CtlSeq_TrAck


  // --------------------------------------------------------------------------
  // Trigger request generation Embedding or tracectl (where applicable)
  //
  // trig_req operates on a 4-phase handshake scheme with trig_ack to allow reuse
  // for both Embedding and tracectl which may be in different clock domains
  //
  // A trigger request to the ATB formatter can only be generated when
  // ft_stopped is LOW. The trigger request input will be held HIGH until a
  // ft_trig_ack is observed.
  //
  // Unlike flushes, trigger requests are not pended
  // if another is in progress. While a trigger is in progress, any further
  // requests to report a trigger are ignored, as a trigger is already being
  // inserted into the trace stream
  // --------------------------------------------------------------------------

  // Setting conditions:
  // 1/Trig on Flush, 2/Trig on TrigEvent, 3/Trig on TrigIn
  // When:
  //  Formatter is not stopped
  // AND
  //  Ack is LOW (required for 4-phase HS)
  // [trig_req can only clear when the Ack comes back high]
  assign nxt_trig_req = (// Trigger conditions
                       (t_on_flush_detect | t_on_trig_evt_detect | t_on_trig_in_detect) &
                       // Formatter Stopped and Ack LOW
                       (~ft_stop_req_int & ~ft_stopped & ~trig_ack));

  // Use a clock gate term to hold the reg once set and re-enable to clear
  assign trig_req_en = (// set terms:
                      t_on_flush_detect | t_on_trig_evt_detect | t_on_trig_in_detect |
                      // Clear term:
                      trig_ack) & atclken;

  // Trigger Acknowledge can come from the formatter (when embedding) or the
  // Syncronised ack from TraceOut
  assign trig_ack = ffcr_ften_reg[1] ? ft_trig_ack : trig_port_done_sync;

  // Output appropriate requests to the different blocks according to the
  // setting of the formatter enable bit
  // -Trigger request to Formatter
  assign ft_trig_req = trig_req & ffcr_ften_reg[1];

  // -Trigger request to TraceOut port
  assign nxt_trig_port  = trig_req & ~ffcr_ften_reg[1];

  always @(posedge atclk or negedge atresetn)
    if (!atresetn)
       trigport_cdc_check  <= 1'b0;
    else if (atclken)
       trigport_cdc_check  <= nxt_trig_port;

  // trig_req HS machine
  always @(posedge atclk or negedge atresetn)
    begin : p_ctlseq_trigreq
      if (!atresetn)
        trig_req <= 1'b0;
      else if (trig_req_en)
        trig_req <= nxt_trig_req;
    end // p_ctlseq_trigreq

  // --------------------------------------------------------------------------
  // Formatter flush request generation
  //
  // Flush generation is independent of the status of StopReq as it may be
  // necessary to invoke a flush from a trace capture disabled CSETB in the
  // same system as a TPIU, which may itself be fully operational.
  // --------------------------------------------------------------------------

  // ffcr_flsh_reg[2] = FOnMan. Manually generate a flush of the system.
  // *Now* ffcr_f_on_man_reg = FOnMan.
  // When this bit is set a flush will be generated. This bit is cleared when
  // the flush has been serviced (afreadys is HIGH)
  assign f_on_man_detect = ffcr_f_on_man_reg & ~f_on_man_reg;

  // Manual Flush Request
  always @(posedge atclk or negedge atresetn)
    begin : p_ctlseq_fonmanedge
      if (!atresetn)
        f_on_man_reg <= 1'b0;
      else if (atclken)
        f_on_man_reg <= ffcr_f_on_man_reg;
    end // p_ctlseq_fonmanedge

  // ffcr_flsh_reg[1] = FOnTrig. Generate flush via a trigger event.
  // When this bit is set a flush will be generated when a trigger event occurs
  // Cannot be initiated when ft_stopped is HIGH
  assign f_on_trig_detect = ffcr_flsh_reg[1] & trigger_event & ~ft_stopped;

  // ffcr_flsh_reg[0] = FlOnFlIn. Generate a flush via the flushin interface.
  // When this bit is set the flushin interface is used.
  // Cannot be initiated when ft_stopped is HIGH
  assign f_on_fl_in_detect = ffcr_flsh_reg[0] & flushin_sync & ~flushinack_int
                                                      & ~ft_stopped;

  // Reset ffcr_f_on_man_reg when when AFREADY is returned HIGH on manual flush
  assign nxt_f_on_man_clr =  ~f_on_man_active_int & f_on_man_active_reg;

  // Manual Flush completion
  always @(posedge atclk or negedge atresetn)
    begin : p_ctlreq_fonman
      if (!atresetn)
        f_on_man_clr  <= 1'b0;
      else if (atclken)
        f_on_man_clr  <= nxt_f_on_man_clr;
    end // p_CtlSeq_FOnMan

  // Output flushinack
  // Integration mode support also provided
  assign nxt_flushin_ack =  itc_r_reg ? it_tr_fl_in_ack_reg[1] : flushin_sync;

  // external pin Flush requests
  always @(posedge atclk or negedge atresetn)
    begin : p_ctlseq_flin
      if (!atresetn)
        flushinack_int  <= 1'b0;
      else if (atclken)
        flushinack_int  <= nxt_flushin_ack;
    end // p_ctlseq_flin
  assign flushinack = flushinack_int;

  // Active FOnMan if FOnTrig and FOnFlIn not already active
  // Otherwise activate if a FOnMan is pending and ready (allowed to start)
  assign f_on_man_active_int =    // Activate (flushing now) if the higher priority
                           // FOnFlIn or FOnTrig aren't about to start and
                           // FOnMan is detected, or prev flush not in progress
                           (f_on_man_detect & ~(f_on_fl_in_active | f_on_trig_active)
                            & ~afvalids_int)
                         | // Hold if this is the current flush in progress
                           (f_on_man_active_reg & afvalids_int & ~afready_reg_qual)
                         | // Activate if a FOnMan has been pended
                           (f_on_man_pend & f_on_man_ready);
  assign f_on_man_active = f_on_man_active_int;

  // Active FOnTrig if FOnMan and FOnFlIn not already active
  // Otherwise activate if a FOnTrigIn is pending and ready (allowed to start)
  assign f_on_trig_active =   // Activate (flushing now) if the higher priority
                           // FOnFlIn isn't about to start and FOnTrig detected
                           // or previous flush is not in progress
                           (f_on_trig_detect & ~f_on_fl_in_active & ~afvalids_int)
                         | // Hold if this is the current flush in progress
                           (f_on_trig_active_reg & afvalids_int & ~afready_reg_qual)
                         | // Activate if a FOnTrig has been pended
                           (f_on_trig_pend & f_on_trig_ready);

  // Active FOnFlIn if FOnTrig and FOnFlIn not already active
  // Otherwise activate if a FOnFlIn is pending and ready (allowed to start)
  assign f_on_fl_in_active =   // Activate (flushing now) if FOnFlIn detected
                           // or previous flush is not in progress
                           (f_on_fl_in_detect & ~afvalids_int)
                         | // Hold if this is the current flush in progress
                           (f_on_fl_in_active_reg & afvalids_int & ~afready_reg_qual)
                         | // Activate if a FOnFlIn has been pended
                           (f_on_fl_in_pend & f_on_fl_in_ready);

  // Flush request sources currently running
  always @(posedge atclk or negedge atresetn)
    begin : p_ctlseq_flactive
      if (!atresetn)
        begin
          f_on_man_active_reg  <= 1'b0;
          f_on_trig_active_reg <= 1'b0;
          f_on_fl_in_active_reg <= 1'b0;
        end
      else if (atclken)
        begin
          f_on_man_active_reg  <= f_on_man_active_int;
          f_on_trig_active_reg <= f_on_trig_active;
          f_on_fl_in_active_reg <= f_on_fl_in_active;
        end
    end // p_ctlseq_flactive

  // Pend a FOnMan if another flush is already active and FOnManDetected
  // hold until FOnMan becomes active again
  assign nxt_f_on_man_pend  =   // Pend FOnMan if flush active & FOnMan detected
                            (f_on_man_detect & (f_on_fl_in_active | f_on_trig_active))
                          | // Hold f_on_man_pend until FOnMan is active again
                            (f_on_man_pend & ~f_on_man_active_int);

  // Pend a FOnTrig if another flush is already active and FOnTrigDetected
  // hold until FOnTrig becomes active again
  assign nxt_f_on_trig_pend =   // Pend FOnTrig if flush active & FOnTrig detected
                            (f_on_trig_detect & (f_on_fl_in_active | f_on_man_active_int))
                          | // Hold f_on_trig_pend until FOnTrig is active again
                            (f_on_trig_pend & ~f_on_trig_active);

  // Pend a FOnFlIn if another flush is already active and FOnFlInDetected
  // hold until FOnFlIn becomes active again
  assign nxt_f_on_fl_in_pend =   // Pend FOnFlIn if flush active & FOnFlIn detected
                            (f_on_fl_in_detect & (f_on_trig_active | f_on_man_active_int))
                          | // Hold FOnFlInPen until FOnFlIn is active again
                            (f_on_fl_in_pend & ~f_on_fl_in_active);

  // Flush request sources, awaiting service
  always @(posedge atclk or negedge atresetn)
    begin : p_ctlseq_flpend
      if (!atresetn)
        begin
          f_on_man_pend  <= 1'b0;
          f_on_trig_pend <= 1'b0;
          f_on_fl_in_pend <= 1'b0;
        end
      else if (atclken)
        begin
          f_on_man_pend  <= nxt_f_on_man_pend;
          f_on_trig_pend <= nxt_f_on_trig_pend;
          f_on_fl_in_pend <= nxt_f_on_fl_in_pend;
        end
    end // p_ctlseq_flpend

  // Pending transactions are prioritised for servicing
  //
  // A pending FOnFlIn can be serviced after afreadys has been returned HIGH
  assign f_on_fl_in_ready = f_on_fl_in_pend & afready_reg_qual;
  // A pending FOnTrig can be serviced if there is no pending FOnFlIn
  assign f_on_trig_ready = f_on_trig_pend & afready_reg_qual & ~f_on_fl_in_pend;
  // A pending FOnMan can be serviced if there is no pending FOnFlIn or FOnTrig
  assign f_on_man_ready  = f_on_man_pend & afready_reg_qual
                                   & ~(f_on_fl_in_pend | f_on_trig_pend);

  // Generate afvalids output
  //
  // Integration mode support also provided
  assign nxt_afvalids = itc_r_reg ? it_atb_ctr_2_afv_reg
                               : (f_on_man_active_int | f_on_trig_active | f_on_fl_in_active)
                                                       & ~(afreadys & afvalids_int);

  // Flush request signal (to be exported)
  always @(posedge atclk or negedge atresetn)
    begin : p_ctlseq_afvalids
      if (!atresetn)
        begin
          afvalids_int   <= 1'b0;
          afvalid_reg <= 1'b0;
        end
      else if (atclken)
        begin
          afvalids_int   <= nxt_afvalids;
          afvalid_reg <= afvalids_int;
        end
    end // p_ctlseq_afvalids
  assign afvalids = afvalids_int;

  // --------------------------------------------------------------------------
  // Formatter stop request generation
  //
  // Stop requests to the formatter can only be asserted when a trigger request
  // is not in operation. If a trigger request is in operation the stop must
  // pend until the trigger acknowledgement is received from the formatter.
  // When a stop is generated, ft_stop_req must stay HIGH until the formatter
  // is permitted to begin capturing data again.
  // --------------------------------------------------------------------------

  // ffcr_stop_reg[1] = StopTrig. Generate a stop request when a trigger event has
  // been detected in bypass or normal mode.
  // Wait for trig_ack when in continuous mode to ensure trigger inserted into
  // the the trace stream.
  assign st_on_trig_detect =   // Normal and bypass mode
                            (~ffcr_ften_reg[1] & ffcr_stop_reg[1] & trigger_event)
                          | // Continuous mode
                            (ffcr_ften_reg[1] & ffcr_stop_reg[1] & trigger_event);

  // ffcr_stop_reg[0] =  StopFl. Generate a stop request when a afreadys is HIGH
  assign st_on_fl_detect = ffcr_stop_reg[0] & afready_reg_qual;

  // Stop request activation
  // Stop requests must stay HIGH until the relevant ffcr_stop_reg bits
  // (StopFl, StopTrig) are reset LOW again once a stop request has been
  // invoked.

  // Activate stop on trigger event
  assign st_on_trig_active =   // Stop if StOnTrig HIGH and trig_req LOW
                            (st_on_trig_detect & ~nxt_trig_req)
                          | // Hold until StopTrig reg goes LOW
                            (st_on_trig_active_reg & ffcr_stop_reg[1])
                            // Activate if a StOnTrig has been pended
                          | (st_trig_pend & st_trig_ready);

  // Activate stop on flush completion
  assign st_on_fl_active =     // Stop if StOnFl HIGH and trig_req LOW
                            (st_on_fl_detect & ~nxt_trig_req)
                          | // Hold until StopFl reg goes LOW
                            (st_on_fl_active_reg & ffcr_stop_reg[0])
                          | // Activate if a StOnFl has been pended
                            (st_fl_pend & st_fl_ready);

  // Trigger insertion currently running
  always @(posedge atclk or negedge atresetn)
    begin : p_ctlseq_stactive
      if (!atresetn)
        begin
          st_on_trig_active_reg <= 1'b0;
          st_on_fl_active_reg   <= 1'b0;
        end
      else if (atclken)
        begin
          st_on_trig_active_reg <= st_on_trig_active;
          st_on_fl_active_reg   <= st_on_fl_active;
        end
    end // p_ctlseq_stactive

  // Trigger Acknowledgement
  always @(posedge atclk or negedge atresetn)
    begin : p_ctlseq_trickack
      if (!atresetn)
        trig_ack_reg <= 1'b0;
      else if (atclken)
        trig_ack_reg <= trig_ack;
    end // p_CtlSeq_TrigAck

  // Pend a StOnTrigEvt if trig_req is HIGH
  assign nxt_st_trig_pend =   // Stop on trigger event detected during trigger
                           (st_on_trig_detect & nxt_trig_req)
                         | // Hold until trig_ack is observed
                           (st_trig_pend & ~trig_ack_reg);

  // Pend a StOnFlush if trig_req is HIGH
  assign nxt_st_fl_pend =   // Stop on flush detected during trigger
                           (st_on_fl_detect & nxt_trig_req)
                         | // Hold until trig_ack is observed
                           (st_fl_pend & ~trig_ack_reg);

  // Stopping reasons awaiting service
  always @(posedge atclk or negedge atresetn)
    begin : p_ctlseq_stoppend
      if (!atresetn)
        begin
          st_trig_pend <= 1'b0;
          st_fl_pend   <= 1'b0;
        end
      else if (atclken)
        begin
          st_trig_pend <= nxt_st_trig_pend;
          st_fl_pend   <= nxt_st_fl_pend;
        end
    end // p_ctlseq_stoppend

  // Indicate when a pending stop is ready to start
  //
  // A pending stop on trigger event is ready to be actioned
  assign st_trig_ready = st_trig_pend & trig_ack_reg;
  // A pending stop of flush completion is ready to be actioned
  assign st_fl_ready   = st_fl_pend & trig_ack_reg;

  // FtStopRequest is registered, to delay by a cycle for the situation where
  // StopTrig is initiated. A trigger must be insterted before ft_stop_req goes
  // HIGH;
  assign nxt_ft_stop_req = st_on_trig_active | st_on_fl_active;

  // Stop request to Formatter
  always @(posedge atclk or negedge atresetn)
    begin : p_ctlseq_stopreq
      if (!atresetn)
        ft_stop_req_int <= 1'b1;
      else if (atclken)
        ft_stop_req_int <= nxt_ft_stop_req;
    end // p_ctlseq_stopreq
  assign ft_stop_req = ft_stop_req_int;

`ifdef ARM_ASSERT_ON

  // --------------------------------------------------------------------------
  // ASSERTIONS
  // --------------------------------------------------------------------------

  // Ensure that only one flush is active at a time
  assert_zero_one_hot #(`OVL_ERROR, 3, `OVL_ASSERT,
     "OVL:CSTPIU_FActive_z1hot   - multiple flushes active at the same time")
  csetb_factive_z1hot
    (
     .clk        (atclk),
     .reset_n    (atresetn),
     .test_expr  ({f_on_man_active_int, f_on_trig_active, f_on_fl_in_active})
     );

`endif

`ifdef ARM_CDC_ON
        cdc_connect u_cdc_trigport(
                .clk_launch(atclk),
                .clk_capture(cxtpiu.u_cxtpiu_trace_sync.u_trig_port.clk),
                .d_in(trigport_cdc_check),
                .d_out_async(trig_port)
                );
`else
        assign trig_port = trigport_cdc_check;
`endif
endmodule
