-f $GP3_RTL/coresight/rtl/coresight_component/timestamp_module/cxntsasyncbridge/cxntsasyncbridge.f
-f $GP3_RTL/coresight/rtl/coresight_component/timestamp_module/cxntsasyncbridge_mst/verilog/cxntsasyncbridge_mst.f
-f $GP3_RTL/coresight/rtl/coresight_component/timestamp_module/cxntsasyncbridge_slv/verilog/cxntsasyncbridge_slv.f
$GP3_RTL/coresight/rtl/coresight_component/timestamp_module/cxntsreplicator_1/verilog/cxntsreplicator_1.v
$GP3_RTL/coresight/rtl/coresight_component/timestamp_module/cxntsreplicator_6/verilog/cxntsreplicator_6.v
$GP3_RTL/coresight/rtl/coresight_component/timestamp_module/cxntsreplicator_5/verilog/cxntsreplicator_5.v
$GP3_RTL/coresight/rtl/coresight_component/timestamp_module/cxntsreplicator_4/verilog/cxntsreplicator_4.v
$GP3_RTL/coresight/rtl/coresight_component/timestamp_module/cxntsreplicator_10/verilog/cxntsreplicator_10.v
$GP3_RTL/coresight/rtl/coresight_component/timestamp_module/cxntsreplicator_16/verilog/cxntsreplicator_16.v
$GP3_RTL/coresight/rtl/coresight_component/timestamp_module/cxntsreplicator_12/verilog/cxntsreplicator_12.v
$GP3_RTL/coresight/rtl/coresight_component/timestamp_module/cxntsreplicator_11/verilog/cxntsreplicator_11.v
$GP3_RTL/coresight/rtl/coresight_component/timestamp_module/cxtsd/verilog/cxtsd.v
$GP3_RTL/coresight/rtl/coresight_component/timestamp_module/cxtse/verilog/cxtse.v
-f $GP3_RTL/coresight/rtl/coresight_component/timestamp_module/cxtsgen/cxtsgen.f
