//--========================================================================
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2010-2015 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//  Version and Release Control Information:
//
//  Checked In          : $Date: 2014-08-15 12:05:28 +0100 (Fri, 15 Aug 2014) $
//
//  File Revision       : $Revision: 39947 $
//
//  Release Information : CoreSight-SoC-TM100-r3p2-00rel0
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// Abstract : Debug Access Port AXI Access Port (cxdapaxiap) - constants
//-----------------------------------------------------------------------------
localparam RDY        = 3'b000;
localparam BRR        = 3'b001;
localparam BRR_RESP   = 3'b010;
localparam WR_CMD     = 3'b011;
localparam WR_DT      = 3'b100;
localparam WRITE_RESP = 3'b101;
localparam RD_CMD     = 3'b110;
localparam READ_RESP  = 3'b111;

localparam AXIAP_BYTE      = 2'b00;
localparam AXIAP_HALF_WORD = 2'b01;
localparam AXIAP_WORD      = 2'b10;
localparam AXIAP_DWORD     = 2'b11;
