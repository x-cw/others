
//-----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2011-2015 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//  Version and Release Control Information:
//
//  File Name           : cxntsasyncbridge_xmlcfg.v.xsl
//
//  Checked In          : $Date: 2015-02-16 14:55:41 +0000 (Mon, 16 Feb 2015) $
//
//  File Revision       : $Revision: 41661 $
//
//  Release Information : CoreSight-SoC-TM100-r3p2-00rel0
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// Abstract : CoreSight NTAB - Top Level Block
//-----------------------------------------------------------------------------
//
// cxntsasyncbridge - CoreSight NTAB (Narrow Timestamp Asynchronous Bridge)
//-----------------------------------------------------------------------------

module cxntsasyncbridge_mst (


  // Clock and Reset
  input wire clkm,
  input wire resetmn,

  // Async Bridge Data Hand Shake
  output wire [3:0] rd_ptr_gry_m,
  input wire [3:0] wr_ptr_gry_m,
  input wire [8:0] encd_data0_m,
  input wire [8:0] encd_data1_m,
  input wire [8:0] encd_data2_m,


  // Async Bridge Low Power Hand Shake
  input wire lp_req_m,
  output wire lp_ack_m,

  // Master Interface
  output wire [6:0] tsbitm,
  output wire [1:0] tssyncm,
  input wire tssyncreadym

  );

//----------------------------------------------------------------------------
// Wires
//----------------------------------------------------------------------------


//============================================================================
//
// Main body of code
//
//============================================================================



cxntsasyncbridgemstif_mst
  u_mstif (

  // Clock and Reset
  .clkm (clkm),
  .resetmn (resetmn),

  // Slave Interface
  .tsbitm (tsbitm),
  .tssyncm (tssyncm),
  .tssyncreadym (tssyncreadym),

  // Slave Interface
  .rd_ptr_gry_m (rd_ptr_gry_m),
  .wr_ptr_gry_m (wr_ptr_gry_m),

  .encd_data0_m  (encd_data0_m),
  .encd_data1_m  (encd_data1_m),
  .encd_data2_m  (encd_data2_m),


  .lp_req_m (lp_req_m),
  .lp_ack_m (lp_ack_m)

  );


//----------------------------------------------------------------------------
// CDC Checks
//----------------------------------------------------------------------------



endmodule
