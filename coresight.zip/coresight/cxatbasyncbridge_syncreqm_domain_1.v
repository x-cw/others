// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2010-2013 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//  Version and Release Control Information:
//
//  Checked In          : $Date: 2011-06-05 16:48:18 +0530 (Sun, 05 Jun 2011) $
//
//  Revision		: $Revision: 17078 $
//
//  Release Information : CoreSight-SoC-TM100-r3p1-00rel0
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// Abstract : CoreSight ATB syncreqm domain
//-----------------------------------------------------------------------------
//
// cxatbasyncbridge_syncreqm_domain - CoreSight ATB syncreqm domain
// ----------------------------------------------------------------------------
//
//-----------------------------------------------------------------------------

module cxatbasyncbridge_syncreqm_domain_1 (
  // Inputs
  clkm,
  resetmn,
  clkenm,
  syncreqs_ack_async,
  syncreqm,
  // Outputs
  syncreqs_req_async
  );

  // Inputs
  input wire         clkm;
  input wire         resetmn;
  input wire         clkenm;
  input wire         syncreqs_ack_async;
  input wire         syncreqm;
  // Outputs
  output wire        syncreqs_req_async;



//------------------------------------------------------------------------------
// Constants definitions
//------------------------------------------------------------------------------


  //----------------------------------------------------------------------------
  // Wires
  //----------------------------------------------------------------------------
  wire        nxt_events_hold;         // D-input of events_hold register
  wire        events_valid;            // EVENTS gated with ongoing sync info
  wire        syncreqs_ack_sync;       // Intermediate signal from cdc block
  wire        syncreqs_ack_corrupt_async; // Intermediate cdc signals
  wire        syncreqs_req_async_int;

  //----------------------------------------------------------------------------
  // Registers
  //----------------------------------------------------------------------------

  //============================================================================
  //
  // Main body of code
  // =================
  //
  //============================================================================
  
assign nxt_events_hold = (syncreqs_req_async_int | events_valid) & ~syncreqs_ack_sync;  


assign events_valid = syncreqm & ~(syncreqs_req_async_int | syncreqs_ack_sync) ;


  //----------------------------------------------------------------------------
  // Outgoing Req
  //----------------------------------------------------------------------------

  cxatbasyncbridge_syncreq_cdc_launch_gry #(1) u_cdc_launch_req
  (
      .clk       (clkm),
      .resetn    (resetmn),
      .enable    (clkenm),
      .in_cdc    (nxt_events_hold),
      .out_async (syncreqs_req_async_int)
  );

  assign syncreqs_req_async = syncreqs_req_async_int;

  //----------------------------------------------------------------------------
  // Incoming Ack
  //----------------------------------------------------------------------------

  // Test component to corrupt ack going into synchroniser
  cxatbasyncbridge_syncreq_cdc_corrupt_gry #(1) u_cdc_corrupt_ack
  (
      .clk       (clkm),
      .resetn    (resetmn),
      .sync      (1'b0), // no sync flop
      .d_async   (syncreqs_ack_async),
      .q_async   (syncreqs_ack_corrupt_async)
  );

  // Synchroniser to bring the ack into the clock domain
  cx_en_sync u_cdc_sync_ack
  (
      .clk     (clkm),
      .resetn  (resetmn),
      .clken   (clkenm), // double flop
      .sync_di (syncreqs_ack_corrupt_async),
      .sync_do (syncreqs_ack_sync)
  );
endmodule
