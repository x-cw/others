//------------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited.
//
//            (C) COPYRIGHT 2003-2015 ARM Limited.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited.
//
//  Version and Release Control Information:
//
//  File Name           : cxatbfunnel_arbiter_xmlcfg.v.xsl
//
//  Checked In          : $Date: 2015-02-16 14:55:41 +0000 (Mon, 16 Feb 2015) $
//
//  File Revision       : $Revision: 41661 $
//
//  Release Information : CoreSight-SoC-TM100-r3p2-00rel0
//------------------------------------------------------------------------------
// Verilog-2001 (IEEE Std 1364-2001)
//----------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Abstract : CoreSight Trace Funnel (cxatbfunnel_arbiter) - Arbiter Block
//------------------------------------------------------------------------------
//
// cxatbfunnel - CoreSight Trace Funnel
// -------------------------------------
//
// CoreSight AMBA Trace Bus (ATB) trace link device used to combine multiple
// trace sources into a single bus.
//
// cxatbfunnel_arbiter.v
// ------------------
//
// cxatbfunnel_arbiter.v provides the arbitration logic among the different
// slave ports of the Trace Funnel.
//
// Instantiated blocks
// -------------------
// None
//------------------------------------------------------------------------------

module cxatbfunnel_arbiter_6_pro
  #(parameter CXFUNNEL_ATB_DATA_WIDTH = 128,
    parameter CXFUNNEL_ATBYTES_WIDTH = 4)
  (
  // Inputs
  input wire                                clk,
  input wire                                resetn,
  //-------------------------------------------------------------------------------
  // ATB Master port input signals
  //-------------------------------------------------------------------------------
  input wire                                atreadym,
  input wire                                afvalidm,
  input wire                                syncreqm,
  //-------------------------------------------------------------------------------
  // ATB Slave port input signals
  //-------------------------------------------------------------------------------
  input wire                                atvalids0,
  input wire                                afreadys0,
  input wire                        [6:0]   atids0,
  input wire                        [128-1:0] atdatas0,
  
  input wire                        [3:0]   atbytess0,
  input wire                                atvalids1,
  input wire                                afreadys1,
  input wire                        [6:0]   atids1,
  input wire                        [128-1:0] atdatas1,
  
  input wire                        [3:0]   atbytess1,
  input wire                                atvalids2,
  input wire                                afreadys2,
  input wire                        [6:0]   atids2,
  input wire                        [128-1:0] atdatas2,
  
  input wire                        [3:0]   atbytess2,
  input wire                                atvalids3,
  input wire                                afreadys3,
  input wire                        [6:0]   atids3,
  input wire                        [128-1:0] atdatas3,
  
  input wire                        [3:0]   atbytess3,
  input wire                                atvalids4,
  input wire                                afreadys4,
  input wire                        [6:0]   atids4,
  input wire                        [128-1:0] atdatas4,
  
  input wire                        [3:0]   atbytess4,
  input wire                                atvalids5,
  input wire                                afreadys5,
  input wire                        [6:0]   atids5,
  input wire                        [128-1:0] atdatas5,
  
  input wire                        [3:0]   atbytess5,


  //-------------------------------------------------------------------------------
  //  Min hold time value from the register block
  //-------------------------------------------------------------------------------
  input wire                        [3:0]  min_hold_time,

  //-------------------------------------------------------------------------------
  //  Port enable and priortiy bits from the register block
  //-------------------------------------------------------------------------------

  input wire                               en_port_0,
  input wire                        [2:0]  pri_port_0,
  input wire                               en_port_1,
  input wire                        [2:0]  pri_port_1,

  input wire                               en_port_2,
  input wire                        [2:0]  pri_port_2,
  input wire                               en_port_3,
  input wire                        [2:0]  pri_port_3,
  input wire                               en_port_4,
  input wire                        [2:0]  pri_port_4,
  input wire                               en_port_5,
  input wire                        [2:0]  pri_port_5,

  //-------------------------------------------------------------------------------
  //  Integration register values  from the register block
  //-------------------------------------------------------------------------------
  
  input wire                        [16:0] it_atb_data_0_wr_reg,
  input wire                               itc_reg,
  input wire                        [1:0]  it_atb_ctr_2_wr_reg,
  input wire                        [6:0]  it_atb_ctr_1_wr_reg,
  input wire [CXFUNNEL_ATBYTES_WIDTH+1:0]  it_atb_ctr_0_wr_reg,
  // Outputs
  //-------------------------------------------------------------------------------
  //  Integration register values for read to the register block
  //-------------------------------------------------------------------------------

  output wire                        [16:0]it_atb_data_0_rd_reg,
  output wire                        [1:0] it_atb_ctr_2_rd_reg,
  output wire                        [6:0] it_atb_ctr_1_rd_reg,
  output wire [CXFUNNEL_ATBYTES_WIDTH+1:0] it_atb_ctr_0_rd_reg,

  //-------------------------------------------------------------------------------
  //  ATB Master port outputs
  //-------------------------------------------------------------------------------
  output wire                              afreadym,
  output wire                              atvalidm,
  output wire [CXFUNNEL_ATBYTES_WIDTH-1:0] atbytesm,
  output wire                        [6:0] atidm,
  output wire                        [128-1:0] atdatam,


  //-------------------------------------------------------------------------------
  //  ATB Slave port outputs
  //-------------------------------------------------------------------------------

  output wire                              atreadys2,
  output wire                              afvalids2,
  output wire                              syncreqs2,

  output wire                              atreadys3,
  output wire                              afvalids3,
  output wire                              syncreqs3,

  output wire                              atreadys4,
  output wire                              afvalids4,
  output wire                              syncreqs4,

  output wire                              atreadys5,
  output wire                              afvalids5,
  output wire                              syncreqs5,

  output wire                              atreadys0,
  output wire                              afvalids0,
  output wire                              syncreqs0,
  output wire                              atreadys1,
  output wire                              afvalids1,
  output wire                              syncreqs1
  );


  //----------------------------------------------------------------------------
  // Wires
  //----------------------------------------------------------------------------
  wire          ctr_sel_1;            // Control for the new value of Hold counter
  wire          ctr_sel_2;            // Control for the new value of Hold counter
  wire          ctr_sel_3;            // Control for the new value of Hold counter
  wire          hold_time_rst;        // Reset the hold time
  wire          funnel_flush;         // Flush status of funnel
  wire          switch_allowed;       // Signal to indicate a new arbitartion start
  wire          sel_port_unchanged;   // Port selection not changed after the arbitration


  wire          set_port_0;
  wire          sel_port_0;     // Signal to select port 0 after arbitration
  reg           sel_port_0_reg; // registered version of sel_port_0
  wire          val_port_0;     // Signal to indicate Port 0 has a valid data
  wire          next_fl_port_0; // Port 0 flush status before registering
  wire          fl_port_0_en;   // Enable to load the value of fl_port_0
  reg           fl_port_0;      // Port0 flush status
  wire          fl_ack_0;       // Set when the  flush completes on slave port 0
  // Programmed port priority extended with Mask bit and Flush completion status
  wire [4:0]    e_pri_port_0;   // Programmed port priority extended with Mask bit and
  wire          port_0_flsed;   // Indicates flush status on port 0
  wire          iafvalids0;     // afvalids of port 0

  wire          set_port_1;
  wire          sel_port_1;     // Signal to select port 1 after arbitration
  reg           sel_port_1_reg; // registered version of sel_port_1
  wire          val_port_1;     // Signal to indicate Port 1 has a valid data
  wire          next_fl_port_1; // Port 1 flush status before registering
  wire          fl_port_1_en;   // Enable to load the value of fl_port_1
  reg           fl_port_1;      // Port1 flush status
  wire          fl_ack_1;       // Set when the  flush completes on slave port 1
  // Programmed port priority extended with Mask bit and Flush completion status
  wire [4:0]    e_pri_port_1;   // Programmed port priority extended with Mask bit and
  wire          port_1_flsed;   // Indicates flush status on port 1
  wire          iafvalids1;     // afvalids of port 1

  wire          set_port_2;
  wire          sel_port_2;     // Signal to select port 2 after arbitration
  reg           sel_port_2_reg; // registered version of sel_port_2
  wire          val_port_2;     // Signal to indicate Port 2 has a valid data
  wire          next_fl_port_2; // Port 2 flush status before registering
  wire          fl_port_2_en;   // Enable to load the value of fl_port_2
  reg           fl_port_2;      // Port2 flush status
  wire          fl_ack_2;       // Set when the  flush completes on slave port 2
  // Programmed port priority extended with Mask bit and Flush completion status
  wire [4:0]    e_pri_port_2;   // Programmed port priority extended with Mask bit and
  wire          port_2_flsed;   // Indicates flush status on port 2
  wire          iafvalids2;     // afvalids of port 2

  wire          set_port_3;
  wire          sel_port_3;     // Signal to select port 3 after arbitration
  reg           sel_port_3_reg; // registered version of sel_port_3
  wire          val_port_3;     // Signal to indicate Port 3 has a valid data
  wire          next_fl_port_3; // Port 3 flush status before registering
  wire          fl_port_3_en;   // Enable to load the value of fl_port_3
  reg           fl_port_3;      // Port3 flush status
  wire          fl_ack_3;       // Set when the  flush completes on slave port 3
  // Programmed port priority extended with Mask bit and Flush completion status
  wire [4:0]    e_pri_port_3;   // Programmed port priority extended with Mask bit and
  wire          port_3_flsed;   // Indicates flush status on port 3
  wire          iafvalids3;     // afvalids of port 3

  wire          set_port_4;
  wire          sel_port_4;     // Signal to select port 4 after arbitration
  reg           sel_port_4_reg; // registered version of sel_port_4
  wire          val_port_4;     // Signal to indicate Port 4 has a valid data
  wire          next_fl_port_4; // Port 4 flush status before registering
  wire          fl_port_4_en;   // Enable to load the value of fl_port_4
  reg           fl_port_4;      // Port4 flush status
  wire          fl_ack_4;       // Set when the  flush completes on slave port 4
  // Programmed port priority extended with Mask bit and Flush completion status
  wire [4:0]    e_pri_port_4;   // Programmed port priority extended with Mask bit and
  wire          port_4_flsed;   // Indicates flush status on port 4
  wire          iafvalids4;     // afvalids of port 4

  wire          set_port_5;
  wire          sel_port_5;     // Signal to select port 5 after arbitration
  reg           sel_port_5_reg; // registered version of sel_port_5
  wire          val_port_5;     // Signal to indicate Port 5 has a valid data
  wire          next_fl_port_5; // Port 5 flush status before registering
  wire          fl_port_5_en;   // Enable to load the value of fl_port_5
  reg           fl_port_5;      // Port5 flush status
  wire          fl_ack_5;       // Set when the  flush completes on slave port 5
  // Programmed port priority extended with Mask bit and Flush completion status
  wire [4:0]    e_pri_port_5;   // Programmed port priority extended with Mask bit and
  wire          port_5_flsed;   // Indicates flush status on port 5
  wire          iafvalids5;     // afvalids of port 5


  wire          comp_0_1;
  wire          comp_0_2;
  wire          comp_1_2;
  wire          comp_0_3;
  wire          comp_1_3;
  wire          comp_2_3;
  wire          comp_0_4;
  wire          comp_1_4;
  wire          comp_2_4;
  wire          comp_3_4;
  wire          comp_0_5;
  wire          comp_1_5;
  wire          comp_2_5;
  wire          comp_3_5;
  wire          comp_4_5;
  wire          eq_pri_0_1;
  wire          eq_pri_0_2;
  wire          eq_pri_1_2;
  wire          eq_pri_0_3;
  wire          eq_pri_1_3;
  wire          eq_pri_2_3;
  wire          eq_pri_0_4;
  wire          eq_pri_1_4;
  wire          eq_pri_2_4;
  wire          eq_pri_3_4;
  wire          eq_pri_0_5;
  wire          eq_pri_1_5;
  wire          eq_pri_2_5;
  wire          eq_pri_3_5;
  wire          eq_pri_4_5;

  //------------------------------------------------------------------------
  // Bandwidth sharing mask
  //------------------------------------------------------------------------

  wire          next_bws_mask_0;
  wire          clr_bws_mask_0;
  wire          bws_mask_ctrl_0;
  reg           bws_mask_0;       // bandwidth sharing mask register

  wire          next_bws_mask_1;
  wire          clr_bws_mask_1;
  wire          bws_mask_ctrl_1;
  reg           bws_mask_1;       // bandwidth sharing mask register

  wire          next_bws_mask_2;
  wire          clr_bws_mask_2;
  wire          bws_mask_ctrl_2;
  reg           bws_mask_2;       // bandwidth sharing mask register

  wire          next_bws_mask_3;
  wire          clr_bws_mask_3;
  wire          bws_mask_ctrl_3;
  reg           bws_mask_3;       // bandwidth sharing mask register

  wire          next_bws_mask_4;
  wire          clr_bws_mask_4;
  wire          bws_mask_ctrl_4;
  reg           bws_mask_4;       // bandwidth sharing mask register

  wire          next_bws_mask_5;
  wire          clr_bws_mask_5;
  wire          bws_mask_ctrl_5;
  reg           bws_mask_5;       // bandwidth sharing mask register

  wire          atid_changed;

  wire  [CXFUNNEL_ATB_DATA_WIDTH-1 :0] iatdatam;

// Intregration mode signals
  reg           itc_reg_del;
  wire          it_mode_start;
  wire  [CXFUNNEL_ATB_DATA_WIDTH-1 :0] it_atdatam;
  //----------------------------------------------------------------------------
  // Registers
  //----------------------------------------------------------------------------
  reg           atvalidm_reg;
  reg           atreadym_reg;
  reg [3:0]     next_hold_ctr;
  reg [3:0]     hold_ctr;


// Registered versions of atidm
  reg [6:0]     atidm_reg;

// Internal signals
  wire [6:0]    iatidm;
  wire          iafvalidm;
  wire          iatreadym;
  wire          iatvalidm;
  wire  [CXFUNNEL_ATBYTES_WIDTH-1:0]        iatbytesm;




  //----------------------------------------------------------------------------
  //
  // Main body of code
  // =================
  //
  //----------------------------------------------------------------------------

  //----------------------------------------------------------------------------
  // Extending Programmed Port Priority with Mask bit and Flush completion
  // status. Ports which have completed flush are of lesser priority than the
  // ones which are yet to complete flush. Among ports with the same programmed
  // priority, ports with the Mask bit cleared have higher priority.
  //----------------------------------------------------------------------------

  assign e_pri_port_0 = {port_0_flsed,
                         pri_port_0,
                         bws_mask_0};


  assign e_pri_port_1 = {port_1_flsed,
                         pri_port_1,
                         bws_mask_1};


  assign e_pri_port_2 = {port_2_flsed,
                         pri_port_2,
                         bws_mask_2};


  assign e_pri_port_3 = {port_3_flsed,
                         pri_port_3,
                         bws_mask_3};


  assign e_pri_port_4 = {port_4_flsed,
                         pri_port_4,
                         bws_mask_4};


  assign e_pri_port_5 = {port_5_flsed,
                         pri_port_5,
                         bws_mask_5};



  //----------------------------------------------------------------------------
  // Comparators for selecting the slave port.These comparators are used for
  // comparing the values programmed in the priority control against each slave
  // port.The slave port which has been programmed with the least value in the
  // priority control register shall be selected as part of the arbitration
  // scheme provided the slave port has valid trace data,its enable bit is set
  // in the funnel control register and it has not been flushed after receiving
  // an AFREADY.
  //----------------------------------------------------------------------------

    //------------------------------------------------------------------------
    // comp_0_2 to comp_1_2 are comparators for comparing the value of the
    // slave port2 against the values of slave port0 to slave port1.
    //------------------------------------------------------------------------
    assign comp_0_2 = e_pri_port_0 > e_pri_port_2;
    assign comp_1_2 = e_pri_port_1 > e_pri_port_2;
    //----------------------------------------------------------------------
    // Logic for val_port_2 signal.This signal indicates that port2 is
    // enabled in the funnel control register and has valid trace data.
    //----------------------------------------------------------------------
    assign val_port_2 = en_port_2 & atvalids2;
    //----------------------------------------------------------------------
    // Logic for generating the set_port_2 signal.This signal indicates that
    // the slave port0 can be selected as part of the arbitaration scheme
    // because the other slave ports do not have valid trace data or the
    // priority values programmed against each slave port are greater than
    // slave port2 and the slave port3 has valid trace data.
    //----------------------------------------------------------------------
    assign set_port_2 =  (~(val_port_0 & ~comp_0_2) &
                          ~(val_port_1 & ~comp_1_2) &
                          
                          ~(val_port_3 &  comp_2_3) &
                          ~(val_port_4 &  comp_2_4) &
                          ~(val_port_5 &  comp_2_5) &
                           (val_port_2 &  switch_allowed));
    //------------------------------------------------------------------------
    // comp_0_3 to comp_2_3 are comparators for comparing the value of the
    // slave port3 against the values of slave port0 to slave port2.
    //------------------------------------------------------------------------
    assign comp_0_3 = e_pri_port_0 > e_pri_port_3;
    assign comp_1_3 = e_pri_port_1 > e_pri_port_3;
    assign comp_2_3 = e_pri_port_2 > e_pri_port_3;

    //----------------------------------------------------------------------
    // Logic for val_port_3 signal.This signal indicates that port3 is
    // enabled in the funnel control register and has valid trace data.
    //----------------------------------------------------------------------
    assign val_port_3 = en_port_3 & atvalids3;

    //----------------------------------------------------------------------
    // Logic for generating the set_port_3 signal.This signal indicates that
    // the slave port0 can be selected as part of the arbitaration scheme
    // because the other slave ports do not have valid trace data or the
    // priority values programmed against each slave port are greater than
    // slave port3 and the slave port1 has valid trace data.
    //----------------------------------------------------------------------
    assign set_port_3 =  (~(val_port_0 & ~comp_0_3) &
                          ~(val_port_1 & ~comp_1_3) &
                          ~(val_port_2 & ~comp_2_3) &
                          
                          ~(val_port_4 &  comp_3_4) &
                          ~(val_port_5 &  comp_3_5) & 
                           (val_port_3 &  switch_allowed)); 
    //------------------------------------------------------------------------
    // comp_0_4 to comp_3_4 are comparators for comparing the value of the
    // slave port4 against the values of slave port0 to slave port3.
    //------------------------------------------------------------------------
    assign comp_0_4 = e_pri_port_0 > e_pri_port_4;
    assign comp_1_4 = e_pri_port_1 > e_pri_port_4;
    assign comp_2_4 = e_pri_port_2 > e_pri_port_4;
    assign comp_3_4 = e_pri_port_3 > e_pri_port_4;

    //----------------------------------------------------------------------
    // Logic for val_port_4 signal.This signal indicates that port4 is
    // enabled in the funnel control register and has valid trace data.
    //----------------------------------------------------------------------
    assign val_port_4 = en_port_4 & atvalids4;

    //----------------------------------------------------------------------
    // Logic for generating the set_port_4 signal.This signal indicates that
    // the slave port0 can be selected as part of the arbitaration scheme
    // because the other slave ports do not have valid trace data or the
    // priority values programmed against each slave port are greater than
    // slave port4 and the slave port4 has valid trace data.
    //----------------------------------------------------------------------
    assign set_port_4 =  (~(val_port_0 & ~comp_0_4) &
                          ~(val_port_1 & ~comp_1_4) &
                          ~(val_port_2 & ~comp_2_4) &
                          ~(val_port_3 & ~comp_3_4) &
                          
                          ~(val_port_5 &  comp_4_5) &
                           (val_port_4 & switch_allowed));
    //------------------------------------------------------------------------
    // comp_0_5 to comp_4_5 are comparators for comparing the value of the
    // slave port5 against the values of slave port0 to slave port4.
    //------------------------------------------------------------------------
    assign comp_0_5 = e_pri_port_0 > e_pri_port_5;
    assign comp_1_5 = e_pri_port_1 > e_pri_port_5;
    assign comp_2_5 = e_pri_port_2 > e_pri_port_5;
    assign comp_3_5 = e_pri_port_3 > e_pri_port_5;
    assign comp_4_5 = e_pri_port_4 > e_pri_port_5;

    //----------------------------------------------------------------------
    // Logic for val_port_5 signal.This signal indicates that port5 is
    // enabled in the funnel control register and has valid trace data.
    //----------------------------------------------------------------------
    assign val_port_5 = en_port_5 & atvalids5;

    //----------------------------------------------------------------------
    // Logic for generating the set_port_5 signal.This signal indicates that
    // the slave port0 can be selected as part of the arbitaration scheme
    // because the other slave ports do not have valid trace data or the
    // priority values programmed against each slave port are greater than
    // slave port5 and the slave port5 has valid trace data.
    //----------------------------------------------------------------------
    assign set_port_5 =  (~(val_port_0 & ~comp_0_5) &
                          ~(val_port_1 & ~comp_1_5) &
                          ~(val_port_2 & ~comp_2_5) &
                          ~(val_port_3 & ~comp_3_5) &
                          ~(val_port_4 & ~comp_4_5) &
                          
                           (val_port_5 &  switch_allowed));
  //----------------------------------------------------------------------------
  // comp_0_1 is comparator for comparing the value of the slave port0 against
  // the value of slave port1.
  //----------------------------------------------------------------------------
  assign comp_0_1 = e_pri_port_0 > e_pri_port_1;


  //----------------------------------------------------------------------------
  // Logic for val_port_0 signal.This signal indicates that port0 is enabled in
  // the funnel control register and has valid trace data.
  //----------------------------------------------------------------------------
  assign val_port_0 = en_port_0 & atvalids0;

  //----------------------------------------------------------------------------
  // Logic for generating the set_port_0 signal.This signal indicates that the
  // slave port0 can be selected as part of the arbitaration scheme because the
  // the other slave ports do not have valid trace data or the priority values
  // programmed against each slave port are greater than slave port0 and the
  // slave port0 has valid trace data.
  //----------------------------------------------------------------------------
  assign set_port_0 =  (~(val_port_1 & comp_0_1) &
                      ~(val_port_2 & comp_0_2) &
                      ~(val_port_3 & comp_0_3) &
                      ~(val_port_4 & comp_0_4) &
                      ~(val_port_5 & comp_0_5) &
                      (val_port_0 & switch_allowed));

  //----------------------------------------------------------------------------
  // Logic for val_port_1 signal.This signal indicates that port1 is enabled in
  // the funnel control register and has valid trace data.
  //----------------------------------------------------------------------------
  assign val_port_1 = en_port_1 & atvalids1;

  //----------------------------------------------------------------------------
  // Logic for generating the set_port_1 signal.This signal indicates that the
  // slave port0 can be selected as part of the arbitaration scheme because the
  // the other slave ports do not have valid trace data or the priority values
  // programmed against each slave port are greater than slave port1 and the
  // slave port1 has valid trace data.
  //----------------------------------------------------------------------------
  assign set_port_1 =  (~(val_port_0 & ~comp_0_1) &
                      ~(val_port_2 &  comp_1_2) &
                      ~(val_port_3 &  comp_1_3) &
                      ~(val_port_4 &  comp_1_4) &
                      ~(val_port_5 &  comp_1_5) &
                       (val_port_1 &  switch_allowed));


  //----------------------------------------------------------------------------
  // Logic for generating slave port select signals sel_port_0 to sel_port_7.If
  // sel_port_0 is set,it indicates that the slave port0 is currently selected
  // as part of the arbitration scheme.If sel_port_1 is set,it indicates that
  // the slave port1 is selected as part of the arbitration scheme and so on.
  //----------------------------------------------------------------------------
  assign sel_port_0 = set_port_0 | (sel_port_0_reg & ~switch_allowed);
  assign sel_port_1 = set_port_1 | (sel_port_1_reg & ~switch_allowed);
  assign sel_port_2 = set_port_2 | (sel_port_2_reg & ~switch_allowed);
  assign sel_port_3 = set_port_3 | (sel_port_3_reg & ~switch_allowed);
  assign sel_port_4 = set_port_4 | (sel_port_4_reg & ~switch_allowed);
  assign sel_port_5 = set_port_5 | (sel_port_5_reg & ~switch_allowed);

  //----------------------------------------------------------------------------
  // Mask for Bandwidth sharing among ports of same programmed priority.
  // If a port is selected, its mask bit is set for the next cycle.
  // If a port is disabled after its mask has been set, its mask information is
  // cleared.
  //----------------------------------------------------------------------------

  assign next_bws_mask_0 = set_port_0 |
                           (bws_mask_0 & en_port_0 & ~clr_bws_mask_0);
  assign next_bws_mask_1 = set_port_1 |
                           (bws_mask_1 & en_port_1 & ~clr_bws_mask_1);
  assign next_bws_mask_2 = set_port_2 |
                           (bws_mask_2 & en_port_2 & ~clr_bws_mask_2);
  assign next_bws_mask_3 = set_port_3 |
                           (bws_mask_3 & en_port_3 & ~clr_bws_mask_3);
  assign next_bws_mask_4 = set_port_4 |
                           (bws_mask_4 & en_port_4 & ~clr_bws_mask_4);
  assign next_bws_mask_5 = set_port_5 |
                           (bws_mask_5 & en_port_5 & ~clr_bws_mask_5);

  //----------------------------------------------------------------------------
  // Sequential block for bws_mask_0 to bws_mask_7 signals
  //----------------------------------------------------------------------------
  always @(posedge clk or negedge resetn)
    begin : p_bws_mask
      if(!resetn)
        begin

          bws_mask_0 <= 1'b0;
          bws_mask_1 <= 1'b0;
          bws_mask_2 <= 1'b0;
          bws_mask_3 <= 1'b0;
          bws_mask_4 <= 1'b0;
          bws_mask_5 <= 1'b0;
        end // if (!resetn)
      else
        begin

          bws_mask_0 <= next_bws_mask_0;
          bws_mask_1 <= next_bws_mask_1;
          bws_mask_2 <= next_bws_mask_2;
          bws_mask_3 <= next_bws_mask_3;
          bws_mask_4 <= next_bws_mask_4;
          bws_mask_5 <= next_bws_mask_5;
        end // else
    end // block: p_bws_mask

  //----------------------------------------------------------------------------
  // When a source is selected and its mask bit is already set, all other mask
  // bits for sources at that programmed priority level are cleared.
  //----------------------------------------------------------------------------

  assign bws_mask_ctrl_0 = bws_mask_0 & set_port_0;
  assign bws_mask_ctrl_1 = bws_mask_1 & set_port_1;
  assign bws_mask_ctrl_2 = bws_mask_2 & set_port_2;
  assign bws_mask_ctrl_3 = bws_mask_3 & set_port_3;
  assign bws_mask_ctrl_4 = bws_mask_4 & set_port_4;
  assign bws_mask_ctrl_5 = bws_mask_5 & set_port_5;

  //----------------------------------------------------------------------------
  // Check whether Port 0 and Port 1 have the same programmed priority
  //----------------------------------------------------------------------------
  assign eq_pri_0_1 = (pri_port_0 == pri_port_1);

  
  //----------------------------------------------------------------------
  // Checking for ports with equal priority programmed as for port 2
  //----------------------------------------------------------------------
  assign eq_pri_0_2 = (pri_port_0 == pri_port_2);
  assign eq_pri_1_2 = (pri_port_1 == pri_port_2); 
  //----------------------------------------------------------------------
  // Checking for ports with equal priority programmed as for port 3
  //----------------------------------------------------------------------
  assign eq_pri_0_3 = (pri_port_0 == pri_port_3);
  assign eq_pri_1_3 = (pri_port_1 == pri_port_3);
  assign eq_pri_2_3 = (pri_port_2 == pri_port_3);
  //----------------------------------------------------------------------
  // Checking for ports with equal priority programmed as for port 4
  //----------------------------------------------------------------------
  assign eq_pri_0_4 = (pri_port_0 == pri_port_4);
  assign eq_pri_1_4 = (pri_port_1 == pri_port_4);
  assign eq_pri_2_4 = (pri_port_2 == pri_port_4);
  assign eq_pri_3_4 = (pri_port_3 == pri_port_4);
  //----------------------------------------------------------------------
  // Checking for ports with equal priority programmed as for port 5
  //----------------------------------------------------------------------
  assign eq_pri_0_5 = (pri_port_0 == pri_port_5);
  assign eq_pri_1_5 = (pri_port_1 == pri_port_5);
  assign eq_pri_2_5 = (pri_port_2 == pri_port_5);
  assign eq_pri_3_5 = (pri_port_3 == pri_port_5);
  assign eq_pri_4_5 = (pri_port_4 == pri_port_5);

  //----------------------------------------------------------------------------
  // Clearing signal for bws_mask_0. When a source is selected and its mask bit
  // is set, all other mask bits for sources at that priority level are cleared.
  // For each port, check with each of the other ports that are of the same
  // programmed priority.
  //----------------------------------------------------------------------------

  assign clr_bws_mask_0 = (eq_pri_0_1 & bws_mask_ctrl_1) |
                       (eq_pri_0_2 & bws_mask_ctrl_2) |
                       (eq_pri_0_3 & bws_mask_ctrl_3) |
                       (eq_pri_0_4 & bws_mask_ctrl_4) |
                       (eq_pri_0_5 & bws_mask_ctrl_5) ;

  //----------------------------------------------------------------------------
  // Clearing signal for bws_mask_1. When a source is selected and its mask bit
  // is set, all other mask bits for sources at that priority level are cleared.
  // For each port, check with each of the other ports that are of the same
  // programmed priority.
  //----------------------------------------------------------------------------
  assign clr_bws_mask_1 = (eq_pri_0_1 & bws_mask_ctrl_0)  |
                       (eq_pri_1_2 & bws_mask_ctrl_2) |
                       (eq_pri_1_3 & bws_mask_ctrl_3) |
                       (eq_pri_1_4 & bws_mask_ctrl_4) |
                       (eq_pri_1_5 & bws_mask_ctrl_5);

  //----------------------------------------------------------------------------
  // Clearing signal for bws_mask_2. When a source is selected and its mask bit
  // is set, all other mask bits for sources at that priority level are cleared.
  // For each port, check with each of the other ports that are of the same
  // programmed priority.
  //----------------------------------------------------------------------------
  assign clr_bws_mask_2 = (eq_pri_0_2 & bws_mask_ctrl_0) |
                       (eq_pri_1_2 & bws_mask_ctrl_1) |
                       (eq_pri_2_3 & bws_mask_ctrl_3) |
                       (eq_pri_2_4 & bws_mask_ctrl_4) |
                       (eq_pri_2_5 & bws_mask_ctrl_5);

  //----------------------------------------------------------------------------
  // Clearing signal for bws_mask_3. When a source is selected and its mask bit
  // is set, all other mask bits for sources at that priority level are cleared.
  // For each port, check with each of the other ports that are of the same
  // programmed priority.
  //----------------------------------------------------------------------------
  assign clr_bws_mask_3 = (eq_pri_0_3 & bws_mask_ctrl_0) |
                       (eq_pri_1_3 & bws_mask_ctrl_1) |
                       (eq_pri_2_3 & bws_mask_ctrl_2) |
                       (eq_pri_3_4 & bws_mask_ctrl_4) |
                       (eq_pri_3_5 & bws_mask_ctrl_5);

  //----------------------------------------------------------------------------
  // Clearing signal for bws_mask_4. When a source is selected and its mask bit
  // is set, all other mask bits for sources at that priority level are cleared.
  // For each port, check with each of the other ports that are of the same
  // programmed priority.
  //----------------------------------------------------------------------------
  assign clr_bws_mask_4 = (eq_pri_0_4 & bws_mask_ctrl_0) |
                       (eq_pri_1_4 & bws_mask_ctrl_1) |
                       (eq_pri_2_4 & bws_mask_ctrl_2) |
                       (eq_pri_3_4 & bws_mask_ctrl_3) |
                       (eq_pri_4_5 & bws_mask_ctrl_5);

  //----------------------------------------------------------------------------
  // Clearing signal for bws_mask_5. When a source is selected and its mask bit
  // is set, all other mask bits for sources at that priority level are cleared.
  // For each port, check with each of the other ports that are of the same
  // programmed priority.
  //----------------------------------------------------------------------------
  assign clr_bws_mask_5 = (eq_pri_0_5 & bws_mask_ctrl_0) |
                       (eq_pri_1_5 & bws_mask_ctrl_1) |
                       (eq_pri_2_5 & bws_mask_ctrl_2) |
                       (eq_pri_3_5 & bws_mask_ctrl_3) |
                       (eq_pri_4_5 & bws_mask_ctrl_4);



  //----------------------------------------------------------------------------
  // Logic for generating ATREADY for the respective slave ports.
  //----------------------------------------------------------------------------
  assign atreadys0 = (iatreadym & (sel_port_0 | itc_reg)) | ~en_port_0;
  assign atreadys1 = (iatreadym & (sel_port_1 | itc_reg)) | ~en_port_1;
  assign atreadys2 = (iatreadym & (sel_port_2 | itc_reg)) | ~en_port_2;
  assign atreadys3 = (iatreadym & (sel_port_3 | itc_reg)) | ~en_port_3;
  assign atreadys4 = (iatreadym & (sel_port_4 | itc_reg)) | ~en_port_4;
  assign atreadys5 = (iatreadym & (sel_port_5 | itc_reg)) | ~en_port_5;

  //----------------------------------------------------------------------------
  // Sequential block for latching signals sel_port_0 to sel_port_7.
  //----------------------------------------------------------------------------
  always @(posedge clk or negedge resetn)
    begin : p_sel_port
      if(!resetn)
        begin

          sel_port_0_reg <= 1'b0;
          sel_port_1_reg <= 1'b0;
          sel_port_2_reg <= 1'b0;
          sel_port_3_reg <= 1'b0;
          sel_port_4_reg <= 1'b0;
          sel_port_5_reg <= 1'b0;
        end // if (!resetn)
      else
        begin

          sel_port_0_reg <= sel_port_0;
          sel_port_1_reg <= sel_port_1;
          sel_port_2_reg <= sel_port_2;
          sel_port_3_reg <= sel_port_3;
          sel_port_4_reg <= sel_port_4;
          sel_port_5_reg <= sel_port_5;
        end // else
    end // block: p_sel_port

  //----------------------------------------------------------------------------
  // Logic for thw switch_allowed signal.This signal indicates to the arbiter
  // whether it can switch to another slave port either because the minimum
  // hold time is achieved (hold_ctr equals to zero) for the current slave port
  // OR because the current slave port does not have minimum hold number of
  // valid transactions on the trace bus (hold_time_rst)
  // OR because ATID in the current trace stream has changed (atid_changed).
  //----------------------------------------------------------------------------
  assign switch_allowed = (hold_time_rst & atreadym_reg)  |
                         ((hold_ctr == 4'b0000) &
                          ((atreadym_reg & atvalidm_reg) | ~atvalidm_reg)) |
                         atid_changed;

  //----------------------------------------------------------------------------
  // hold_time_rst indicates that the hold time for a slave port is completed
  // because that corresponding slave port did not have valid trace data for
  // minimum hold number of valid ATB transactions OR the port has completed
  // flush.
  //----------------------------------------------------------------------------
  assign hold_time_rst = ((sel_port_0_reg & (~val_port_0 | (iafvalids0 & afreadys0))) |
                    (sel_port_1_reg & (~val_port_1 | (iafvalids1 & afreadys1))) |
                    (sel_port_2_reg & (~val_port_2 | (iafvalids2 & afreadys2)))  |
                    (sel_port_3_reg & (~val_port_3 | (iafvalids3 & afreadys3))) |
                    (sel_port_4_reg & (~val_port_4 | (iafvalids4 & afreadys4))) |
                    (sel_port_5_reg & (~val_port_5 | (iafvalids5 & afreadys5))) 
                    );

  //----------------------------------------------------------------------------
  // ATID change detection. ATID is defined only when ATVALID is HIGH.
  // ATID from the selected slave port is muxed onto atidm, so the registered
  // version of atidm is used to detect the ATID value of the
  // previously-selected slave.
  //----------------------------------------------------------------------------
  assign atid_changed = ((sel_port_0_reg & (atids0 != atidm_reg) & atvalids0) |
                        (sel_port_1_reg & (atids1 != atidm_reg) & atvalids1) |
                        (sel_port_2_reg & (atids2 != atidm_reg) & atvalids2) |
                        (sel_port_3_reg & (atids3 != atidm_reg) & atvalids3) |
                        (sel_port_4_reg & (atids4 != atidm_reg) & atvalids4) |
                        (sel_port_5_reg & (atids5 != atidm_reg) & atvalids5));

  //----------------------------------------------------------------------------
  // sel_port_unchanged indicates the current slave port which is selected is
  // not changed.
  //----------------------------------------------------------------------------
  assign sel_port_unchanged = ((sel_port_0 & sel_port_0_reg) |
                             (sel_port_1 & sel_port_1_reg) |
                             (sel_port_2 & sel_port_2_reg) |
                             (sel_port_3 & sel_port_3_reg) |
                             (sel_port_4 & sel_port_4_reg) |
                             (sel_port_5 & sel_port_5_reg));

  //----------------------------------------------------------------------------
  // ctr_sel_1,ctr_sel_2 and ctr_sel_3 are the control signals for next_hold_ctr
  //----------------------------------------------------------------------------
  assign ctr_sel_1 =  sel_port_unchanged  |
                     ~(sel_port_0 |
                       sel_port_1 |
                       sel_port_2 |
                       sel_port_3 |
                       sel_port_4 |
                       sel_port_5);
  assign ctr_sel_2 = ~(iatreadym & iatvalidm);
  assign ctr_sel_3 = (hold_ctr != 4'b0000);

  //----------------------------------------------------------------------------
  // Combinational logic for the next_hold_ctr.For each valid transaction on the
  // master port of the Trace Funnel the hold counter decrements by one.If the
  // arbiter selects a new slave port and if there is a valid transcation on
  // the master port,the hold counter is loaded with the min_hold_time value.If
  // a slave port does not have valid trace data for minimum hold number of
  // transactions,the hold counter is reset to zero.
  //----------------------------------------------------------------------------
  always @*
    begin : p_next_hold_ctr
      case(ctr_sel_1)
        1'b0 : next_hold_ctr = min_hold_time + {3'b000,ctr_sel_2};
        1'b1 :
          case(ctr_sel_2)
            1'b0    : next_hold_ctr = ({4{ctr_sel_3}} & (hold_ctr - 4'b0001));
            1'b1    : next_hold_ctr = {4{iatvalidm}} & hold_ctr;
            default : next_hold_ctr = 4'bxxxx;
          endcase // case(ctr_sel_2)
        default : next_hold_ctr = 4'bxxxx;
      endcase // case(ctr_sel_1)
    end // block: p_next_hold_ctr

  //----------------------------------------------------------------------------
  // Sequential block for latching the minimum hold counter.
  //----------------------------------------------------------------------------
  always @(posedge clk or negedge resetn)
    begin : p_hold_ctr
      if(!resetn)
        hold_ctr  <= {4{1'b0}};
      else
        hold_ctr  <= next_hold_ctr;
    end // block: p_hold_ctr

  //----------------------------------------------------------------------------
  // Sequential block for latching the atreadym.
  //----------------------------------------------------------------------------
  always @(posedge clk or negedge resetn)
    begin : p_atreadym_reg
      if(!resetn)
        begin
          atreadym_reg <= 1'b0;
          atvalidm_reg <= 1'b0;
        end
      else
        begin
          atreadym_reg <= iatreadym;
          atvalidm_reg <= iatvalidm;
        end
    end // block: p_atreadym_reg

  //----------------------------------------------------------------------------
  // Sequential block for latching ATIDM
  //----------------------------------------------------------------------------
  always @(posedge clk or negedge resetn)
    begin : p_atid
      if(!resetn)
        atidm_reg <= 7'b0000000;
      else
        atidm_reg <= iatidm;
    end // block: p_atid

  //----------------------------------------------------------------------------
  // Combinational block for driving the ATVALIDM onto the output port of the
  // Trace Funnel.
  //----------------------------------------------------------------------------
  assign iatvalidm = ((sel_port_0 & atvalids0) | (sel_port_1 & atvalids1) |
                     (sel_port_2 & atvalids2) |
                     (sel_port_3 & atvalids3) |
                     (sel_port_4 & atvalids4) |
                     (sel_port_5 & atvalids5));


  assign atvalidm = itc_reg ? it_atb_ctr_0_wr_reg[0] : iatvalidm;
  assign it_atb_ctr_0_rd_reg[0] = iatvalidm;


  //----------------------------------------------------------------------------
  // Combinational block for driving the ATBYTESM onto the output port of the
  // Trace Funnel.
  //----------------------------------------------------------------------------
  assign iatbytesm = (({CXFUNNEL_ATBYTES_WIDTH{sel_port_0}} & atbytess0) |
                     ({CXFUNNEL_ATBYTES_WIDTH{sel_port_1}} & atbytess1) |
                     ({CXFUNNEL_ATBYTES_WIDTH{sel_port_2}} & atbytess2) |
                     ({CXFUNNEL_ATBYTES_WIDTH{sel_port_3}} & atbytess3) |
                     ({CXFUNNEL_ATBYTES_WIDTH{sel_port_4}} & atbytess4) |
                     ({CXFUNNEL_ATBYTES_WIDTH{sel_port_5}} & atbytess5));
  assign atbytesm = itc_reg ? it_atb_ctr_0_wr_reg[CXFUNNEL_ATBYTES_WIDTH+1:2] : iatbytesm;
  assign it_atb_ctr_0_rd_reg[CXFUNNEL_ATBYTES_WIDTH+1:2] = iatbytesm;


  //----------------------------------------------------------------------------
  // Combinational block for driving the ATIDM onto the output port of the
  // Trace Funnel.
  //----------------------------------------------------------------------------
  assign iatidm = (({7{sel_port_0}} & atids0) |
                  ({7{sel_port_1}} & atids1) |
                  ({7{sel_port_2}} & atids2) |
                  ({7{sel_port_3}} & atids3) |
                  ({7{sel_port_4}} & atids4) |
                  ({7{sel_port_5}} & atids5));


  assign atidm = itc_reg ? it_atb_ctr_1_wr_reg : iatidm;
  assign it_atb_ctr_1_rd_reg = iatidm;


  //----------------------------------------------------------------------------
  // Combinational block for driving the ATDATAM onto the output port of the
  // Trace Funnel.
  //----------------------------------------------------------------------------
  assign iatdatam = (({CXFUNNEL_ATB_DATA_WIDTH{sel_port_0}} & atdatas0) |
                    ({CXFUNNEL_ATB_DATA_WIDTH{sel_port_1}} & atdatas1) |
                    ({CXFUNNEL_ATB_DATA_WIDTH{sel_port_2}} & atdatas2) |
                    ({CXFUNNEL_ATB_DATA_WIDTH{sel_port_3}} & atdatas3) |
                    ({CXFUNNEL_ATB_DATA_WIDTH{sel_port_4}} & atdatas4) |
                    ({CXFUNNEL_ATB_DATA_WIDTH{sel_port_5}} & atdatas5));

  //----------------------------------------------------------------------------
  // In integration mode, the atdatam will have the byte boundaries driven by the
  // integration test register
  //----------------------------------------------------------------------------

  assign it_atdatam = { it_atb_data_0_wr_reg[16],iatdatam[126:120],
                       it_atb_data_0_wr_reg[15],iatdatam[118:112],
                       it_atb_data_0_wr_reg[14],iatdatam[110:104],
                       it_atb_data_0_wr_reg[13],iatdatam[102:96],
                       it_atb_data_0_wr_reg[12],iatdatam[94:88],
                       it_atb_data_0_wr_reg[11],iatdatam[86:80],
                       it_atb_data_0_wr_reg[10],iatdatam[78:72],
                       it_atb_data_0_wr_reg[9],iatdatam[70:64], it_atb_data_0_wr_reg[8],iatdatam[62:56],
                       it_atb_data_0_wr_reg[7],iatdatam[54:48],
                       it_atb_data_0_wr_reg[6],iatdatam[46:40],
                       it_atb_data_0_wr_reg[5],iatdatam[38:32], it_atb_data_0_wr_reg[4],iatdatam[30:24],
                       it_atb_data_0_wr_reg[3],iatdatam[22:16], it_atb_data_0_wr_reg[2],iatdatam[14:8],
                       it_atb_data_0_wr_reg[1],iatdatam[6:1],it_atb_data_0_wr_reg[0]};

  //----------------------------------------------------------------------------
  // In integration mode, the atdatam will have the byte boundaries driven by the
  // integration test register
  // In normal driven by the slave port data
  //----------------------------------------------------------------------------
  assign atdatam = itc_reg ? it_atdatam : iatdatam;
  //----------------------------------------------------------------------------
  // Integration test Data 0 register read data
  // In integration mode, the register read will return the atdatam byte boubdary values
  //----------------------------------------------------------------------------

  assign it_atb_data_0_rd_reg = {
                                 iatdatam[127],
                                 iatdatam[119],
                                 iatdatam[111],
                                 iatdatam[103],
                                 iatdatam[95],
                                 iatdatam[87],
                                 iatdatam[79],
                                 iatdatam[71],
                                 iatdatam[63],
                                 iatdatam[55],
                                 iatdatam[47],
                                 iatdatam[39],
                                 iatdatam[31],
                                 iatdatam[23],
                                 iatdatam[15],
                                 iatdatam[7],
                                 iatdatam[0]  };


  //----------------------------------------------------------------------------
  // Integration test for afvalidm
  //----------------------------------------------------------------------------
  assign it_atb_ctr_2_rd_reg[1] = afvalidm;
  assign iafvalidm = itc_reg ? it_atb_ctr_2_wr_reg[1] : afvalidm;


  //----------------------------------------------------------------------------
  // Logic for generating the AFVALID signals for different slave ports.The
  // AFVALID for all the slave ports is driven high at the same time when the
  // master port drives AFVALID.The AFVALID is driven low when the slave port
  // drives AFREADY high.
  //----------------------------------------------------------------------------

  assign iafvalids0 = ~fl_port_0  & iafvalidm & en_port_0;
  assign iafvalids1 = ~fl_port_1  & iafvalidm & en_port_1;
  assign iafvalids2 = ~fl_port_2  & iafvalidm & en_port_2;
  assign iafvalids3 = ~fl_port_3  & iafvalidm & en_port_3;
  assign iafvalids4 = ~fl_port_4  & iafvalidm & en_port_4;
  assign iafvalids5 = ~fl_port_5  & iafvalidm & en_port_5;
  assign afvalids0 = iafvalids0;
  assign afvalids1 = iafvalids1;
  assign afvalids2 = iafvalids2;
  assign afvalids3 = iafvalids3;
  assign afvalids4 = iafvalids4;
  assign afvalids5 = iafvalids5;
  //----------------------------------------------------------------------------
  // ITCRegDel is the latched version of ITCReg.
  //----------------------------------------------------------------------------
  always @(posedge clk or negedge resetn)
    if (!resetn)
      itc_reg_del <= 1'b0;
    else
      itc_reg_del <= itc_reg;

  //----------------------------------------------------------------------------
  // ItModeSt indicates that the integration mode has started.
  //----------------------------------------------------------------------------
  assign it_mode_start = itc_reg & ~itc_reg_del;


  //----------------------------------------------------------------------------
  // Generation of fl_port_0 signal
  // This signal is set when the port is flushed and reset when the flush is acknowledged (funnel_flush is high)
  //----------------------------------------------------------------------------

  assign next_fl_port_0 = ~(funnel_flush | itc_reg);
  assign fl_port_0_en = ((iafvalidm & (afreadys0 | ~en_port_0)) | funnel_flush  |it_mode_start );
  assign port_0_flsed = fl_port_0 | (iafvalids0 & afreadys0);
  always @(posedge clk or negedge resetn)
    begin : p_fl_port_0
      if(!resetn)
        fl_port_0 <= 1'b0;
      else
        if(fl_port_0_en)
          fl_port_0 <= next_fl_port_0;
    end // block: p_fl_port_0
  //----------------------------------------------------------------------------
  // Generation of fl_port_1 signal
  // This signal is set when the port is flushed and reset when the flush is acknowledged (funnel_flush is high)
  //----------------------------------------------------------------------------

  assign next_fl_port_1 = ~(funnel_flush | itc_reg);
  assign fl_port_1_en = ((iafvalidm & (afreadys1 | ~en_port_1)) | funnel_flush  |it_mode_start );
  assign port_1_flsed = fl_port_1 | (iafvalids1 & afreadys1);
  always @(posedge clk or negedge resetn)
    begin : p_fl_port_1
      if(!resetn)
        fl_port_1 <= 1'b0;
      else
        if(fl_port_1_en)
          fl_port_1 <= next_fl_port_1;
    end // block: p_fl_port_1
  //----------------------------------------------------------------------------
  // Generation of fl_port_2 signal
  // This signal is set when the port is flushed and reset when the flush is acknowledged (funnel_flush is high)
  //----------------------------------------------------------------------------

  assign next_fl_port_2 = ~(funnel_flush | itc_reg);
  assign fl_port_2_en = ((iafvalidm & (afreadys2 | ~en_port_2)) | funnel_flush  |it_mode_start );
  assign port_2_flsed = fl_port_2 | (iafvalids2 & afreadys2);
  always @(posedge clk or negedge resetn)
    begin : p_fl_port_2
      if(!resetn)
        fl_port_2 <= 1'b0;
      else
        if(fl_port_2_en)
          fl_port_2 <= next_fl_port_2;
    end // block: p_fl_port_2
  //----------------------------------------------------------------------------
  // Generation of fl_port_3 signal
  // This signal is set when the port is flushed and reset when the flush is acknowledged (funnel_flush is high)
  //----------------------------------------------------------------------------

  assign next_fl_port_3 = ~(funnel_flush | itc_reg);
  assign fl_port_3_en = ((iafvalidm & (afreadys3 | ~en_port_3)) | funnel_flush  |it_mode_start );
  assign port_3_flsed = fl_port_3 | (iafvalids3 & afreadys3);
  always @(posedge clk or negedge resetn)
    begin : p_fl_port_3
      if(!resetn)
        fl_port_3 <= 1'b0;
      else
        if(fl_port_3_en)
          fl_port_3 <= next_fl_port_3;
    end // block: p_fl_port_3
  //----------------------------------------------------------------------------
  // Generation of fl_port_4 signal
  // This signal is set when the port is flushed and reset when the flush is acknowledged (funnel_flush is high)
  //----------------------------------------------------------------------------

  assign next_fl_port_4 = ~(funnel_flush | itc_reg);
  assign fl_port_4_en = ((iafvalidm & (afreadys4 | ~en_port_4)) | funnel_flush  |it_mode_start );
  assign port_4_flsed = fl_port_4 | (iafvalids4 & afreadys4);
  always @(posedge clk or negedge resetn)
    begin : p_fl_port_4
      if(!resetn)
        fl_port_4 <= 1'b0;
      else
        if(fl_port_4_en)
          fl_port_4 <= next_fl_port_4;
    end // block: p_fl_port_4
  //----------------------------------------------------------------------------
  // Generation of fl_port_5 signal
  // This signal is set when the port is flushed and reset when the flush is acknowledged (funnel_flush is high)
  //----------------------------------------------------------------------------

  assign next_fl_port_5 = ~(funnel_flush | itc_reg);
  assign fl_port_5_en = ((iafvalidm & (afreadys5 | ~en_port_5)) | funnel_flush  |it_mode_start );
  assign port_5_flsed = fl_port_5 | (iafvalids5 & afreadys5);
  always @(posedge clk or negedge resetn)
    begin : p_fl_port_5
      if(!resetn)
        fl_port_5 <= 1'b0;
      else
        if(fl_port_5_en)
          fl_port_5 <= next_fl_port_5;
    end // block: p_fl_port_5


  //----------------------------------------------------------------------------
  // Generation of flush acknowledge signal for each slave port
  //----------------------------------------------------------------------------

  assign fl_ack_0 = iafvalidm & (afreadys0 | ~en_port_0);
  assign fl_ack_1 = iafvalidm & (afreadys1 | ~en_port_1);
  assign fl_ack_2 = iafvalidm & (afreadys2 | ~en_port_2);
  assign fl_ack_3 = iafvalidm & (afreadys3 | ~en_port_3);
  assign fl_ack_4 = iafvalidm & (afreadys4 | ~en_port_4);
  assign fl_ack_5 = iafvalidm & (afreadys5 | ~en_port_5);

  //----------------------------------------------------------------------------
  // Logic for generating the funnel_flush signal.FunnelFlush signal indicates
  // that all the slave ports have been flushed.In the integration mode,the
  // funnel_flush is asserted from one of the AFREADY signals.In the normal
  // mode,the funnel_flush is only asserted after all the slave ports have been
  // flushed and there is no pending transaction on the master port of the
  // Trace Funnel.
  //----------------------------------------------------------------------------
  assign funnel_flush = itc_reg ?
                          ((afreadys0 & en_port_0) |
                           (afreadys1 & en_port_1) |
                           (afreadys2 & en_port_2) |
                           (afreadys3 & en_port_3) |
                           (afreadys4 & en_port_4) |
                           (afreadys5 & en_port_5))
                         : ((fl_port_0 | fl_ack_0 ) &
                            (fl_port_1  | fl_ack_1 ) &
                            (fl_port_2  | fl_ack_2 ) &
                            (fl_port_3  | fl_ack_3 ) &
                            (fl_port_4  | fl_ack_4 ) &
                            (fl_port_5  | fl_ack_5 ) &
                            ((iatvalidm & iatreadym) | ~iatvalidm));

  // Add a register to allow afreadym to be driven high when block is in reset but
  // follow mission mode logic after release of reset

  reg rst_state;
  always @(posedge clk or negedge resetn)
    begin : p_rst_state
      if (!resetn)
        rst_state <= 1'b1;
      else
        rst_state <= 1'b0;
    end


  //----------------------------------------------------------------------------
  // atreadym integration test
  // The write to atreadys on enabled slave is propagated from atreadym
  //----------------------------------------------------------------------------
  assign it_atb_ctr_2_rd_reg[0] = atreadym;
  assign iatreadym = itc_reg ? it_atb_ctr_2_wr_reg[0] : atreadym;

  //----------------------------------------------------------------------------
  // funnel_flush is driven as AFREADYM.
  // In integration test mode AFREADYM is driven by the Integration test register
  //----------------------------------------------------------------------------

  assign afreadym = rst_state | (itc_reg ? it_atb_ctr_0_wr_reg[1]: funnel_flush);

  assign it_atb_ctr_0_rd_reg[1] = funnel_flush;

  //----------------------------------------------------------------------------
  // syncreqm is routed to all enabled slaves - SYNCREQ can be seen as
  // an independant channel i.e. it's not related to the current ATB
  // transaction, so we do not take Arbiter selection into account.
  //----------------------------------------------------------------------------

  assign syncreqs0 = en_port_0 & syncreqm;
  assign syncreqs1 = en_port_1 & syncreqm;
  assign syncreqs2 = en_port_2 & syncreqm;
  assign syncreqs3 = en_port_3 & syncreqm;
  assign syncreqs4 = en_port_4 & syncreqm;
  assign syncreqs5 = en_port_5 & syncreqm;

`ifdef ARM_ASSERT_ON
  //----------------------------------------------------------------------------
  // OVL Assertions
  //----------------------------------------------------------------------------

  //----------------------------------------------------------------------------
  // Select signals should be mutually exclusive.
  //----------------------------------------------------------------------------
  assert_zero_one_hot #(`OVL_ERROR, 6, `OVL_ASSERT,
    "OVL Message : cxatbfunnel_arbiter - Select signals should be exclusive")
      uzovl_cxatbfunnel_sel
        (
         .clk         (clk),
         .reset_n     (resetn),
         .test_expr   ({sel_port_0,sel_port_1,
                        sel_port_2,
                        sel_port_3,
                        sel_port_4,
                        sel_port_5})
        );

  //----------------------------------------------------------------------------
  // ATREADY for all the slave ports should not be high at the same time.
  //----------------------------------------------------------------------------
  assert_zero_one_hot #(`OVL_ERROR, 6, `OVL_ASSERT,
    "OVL Message : cxatbfunnel_arbiter - atreadys of two ports high at same time")
      uzovl_cxatbfunnel_atready
        (
         .clk         (clk),
         .reset_n     (resetn),
         .test_expr   ({(atreadys0 & en_port_0 & ~itc_reg),(atreadys1 & en_port_1 & ~itc_reg),
                        (atreadys2 & en_port_2 & ~itc_reg),
                        (atreadys3 & en_port_3 & ~itc_reg),
                        (atreadys4 & en_port_4 & ~itc_reg),
                        (atreadys5 & en_port_5 & ~itc_reg)})
        );


  //----------------------------------------------------------------------------
  // afvalids0 should not be asserted when en_port_0 is low.
  //----------------------------------------------------------------------------
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
    "OVL Message : cxatbfunnel_arbiter - afvalids0 asserted when port disabled")
      uzovl_cxatbfunnel_afvalid_s0
        (
         .clk         (clk),
         .reset_n     (resetn),
         .test_expr   (afvalids0 & ~en_port_0)
        );


  //----------------------------------------------------------------------------
  // afvalids1 should not be asserted when en_port_1 is low.
  //----------------------------------------------------------------------------
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
    "OVL Message : cxatbfunnel_arbiter - afvalids1 asserted when port disabled")
      uzovl_cxatbfunnel_afvalid_s1
        (
         .clk         (clk),
         .reset_n     (resetn),
         .test_expr   (afvalids1 & ~en_port_1)
        );


  //----------------------------------------------------------------------------
  // afvalids2 should not be asserted when en_port_2 is low.
  //----------------------------------------------------------------------------
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
    "OVL Message : cxatbfunnel_arbiter - afvalids2 asserted when port disabled")
      uzovl_cxatbfunnel_afvalid_s2
        (
         .clk         (clk),
         .reset_n     (resetn),
         .test_expr   (afvalids2 & ~en_port_2)
        );


  //----------------------------------------------------------------------------
  // afvalids3 should not be asserted when en_port_3 is low.
  //----------------------------------------------------------------------------
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
    "OVL Message : cxatbfunnel_arbiter - afvalids3 asserted when port disabled")
      uzovl_cxatbfunnel_afvalid_s3
        (
         .clk         (clk),
         .reset_n     (resetn),
         .test_expr   (afvalids3 & ~en_port_3)
        );


  //----------------------------------------------------------------------------
  // afvalids4 should not be asserted when en_port_4 is low.
  //----------------------------------------------------------------------------
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
    "OVL Message : cxatbfunnel_arbiter - afvalids4 asserted when port disabled")
      uzovl_cxatbfunnel_afvalid_s4
        (
         .clk         (clk),
         .reset_n     (resetn),
         .test_expr   (afvalids4 & ~en_port_4)
        );


  //----------------------------------------------------------------------------
  // afvalids5 should not be asserted when en_port_5 is low.
  //----------------------------------------------------------------------------
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
    "OVL Message : cxatbfunnel_arbiter - afvalids5 asserted when port disabled")
      uzovl_cxatbfunnel_afvalid_s5
        (
         .clk         (clk),
         .reset_n     (resetn),
         .test_expr   (afvalids5 & ~en_port_5)
        );


  //----------------------------------------------------------------------------
  // atreadys0 should be asserted when en_port_0 is low.
  //----------------------------------------------------------------------------
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxatbfunnel_arbiter - atreadys0 not asserted when port disabled")
      uzovl_cxatbfunnel_atready_s0
        (
         .clk         (clk),
         .reset_n     (resetn),
         .test_expr   (~(atreadys0 | en_port_0))
        );

  //----------------------------------------------------------------------------
  // atreadys1 should be asserted when en_port_1 is low.
  //----------------------------------------------------------------------------
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxatbfunnel_arbiter - atreadys1 not asserted when port disabled")
      uzovl_cxatbfunnel_atready_s1
        (
         .clk         (clk),
         .reset_n     (resetn),
         .test_expr   (~(atreadys1 | en_port_1))
        );

  //----------------------------------------------------------------------------
  // atreadys2 should be asserted when en_port_2 is low.
  //----------------------------------------------------------------------------
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxatbfunnel_arbiter - atreadys2 not asserted when port disabled")
      uzovl_cxatbfunnel_atready_s2
        (
         .clk         (clk),
         .reset_n     (resetn),
         .test_expr   (~(atreadys2 | en_port_2))
        );

  //----------------------------------------------------------------------------
  // atreadys3 should be asserted when en_port_3 is low.
  //----------------------------------------------------------------------------
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxatbfunnel_arbiter - atreadys3 not asserted when port disabled")
      uzovl_cxatbfunnel_atready_s3
        (
         .clk         (clk),
         .reset_n     (resetn),
         .test_expr   (~(atreadys3 | en_port_3))
        );

  //----------------------------------------------------------------------------
  // atreadys4 should be asserted when en_port_4 is low.
  //----------------------------------------------------------------------------
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxatbfunnel_arbiter - atreadys4 not asserted when port disabled")
      uzovl_cxatbfunnel_atready_s4
        (
         .clk         (clk),
         .reset_n     (resetn),
         .test_expr   (~(atreadys4 | en_port_4))
        );

  //----------------------------------------------------------------------------
  // atreadys5 should be asserted when en_port_5 is low.
  //----------------------------------------------------------------------------
  assert_never #(`OVL_ERROR, `OVL_ASSERT,
   "OVL Message : cxatbfunnel_arbiter - atreadys5 not asserted when port disabled")
      uzovl_cxatbfunnel_atready_s5
        (
         .clk         (clk),
         .reset_n     (resetn),
         .test_expr   (~(atreadys5 | en_port_5))
        );


`endif

endmodule // cxatbfunnel_arbiter
