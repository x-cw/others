//-----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited or its affiliates.
//
// (C) COPYRIGHT 2015-2016 ARM Limited or its affiliates.
// ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited or its affiliates.
//
// Checked In :  2016-02-10 15:33:14 +0000 (Wed, 10 Feb 2016)
// Revision : 206653
//
// Release Information : PL405-r3p0-00eac0
//
//-----------------------------------------------------------------------------
// Verilog-2001 (IEEE Std 1364-2001)
//-----------------------------------------------------------------------------
// File: adb400_r3_axi4_slv.v
//-----------------------------------------------------------------------------
// Purpose : Slave half of protocol/qvn config specific bridge
//-----------------------------------------------------------------------------


module adb400_r3_axi4_slv_err_rsp
  #(parameter
      ADDR_WIDTH          = 40,
      DATA_WIDTH          = 128,
      ID_WIDTH          = 8,
      USER_WIDTH        = 12,
      LEN_WIDTH           = 4,      
      AW_FIFO_DEPTH       = 6,
      W_FIFO_DEPTH        = 6,
      B_FIFO_DEPTH        = 6,
      AR_FIFO_DEPTH       = 6,
      R_FIFO_DEPTH        = 6,
      RD_OSTD_NUM         = 256, // read outstanding number
      WR_OSTD_NUM         = 256  // write outstanding number  
  )
  (
    // Configuration inputs

    input  wire                 pwrq_permit_deny_sar_i,

    // Global signals
    input  wire                      aclks,
    input  wire                      aresetns,
    input  wire                      dft_test_mode,
    // Power state control
    input  wire                      pwrqreqns_i,
    output wire                      pwrqacceptns_o,
    output wire                      pwrqdenys_o,
    // global  Power state
    input wire                     ppu_st_pwron,
    input wire                     reg_err_rsp_en,

    //debug
    output wire  [31:0]              adb_debug_monitor,

    // Power requirement
    output wire                      pwrqactives_o,



    // AW channel signalling
    input  wire                      awvalids,
    output wire                      awreadys,
    input  wire [((USER_WIDTH>0)?(USER_WIDTH-1):0):0] awusers,
    input  wire [((ID_WIDTH>0)?(ID_WIDTH-1):0):0] awids,
    input  wire [ADDR_WIDTH-1:0]     awaddrs,
    //input  wire [3:0]                awregions,
    input  wire [LEN_WIDTH-1:0]                awlens,
    input  wire [2:0]                awsizes,
    input  wire [1:0]                awbursts,
    input  wire                      awlocks,
    input  wire [3:0]                awcaches,
    input  wire [2:0]                awprots,
    input  wire [3:0]                awqoss,

    // W channel signalling
    input  wire                      wvalids,
    output wire                      wreadys,
    input  wire [((USER_WIDTH>0)?(USER_WIDTH-1):0):0] wusers,
    input  wire [DATA_WIDTH-1:0]     wdatas,
    input  wire [(DATA_WIDTH/8)-1:0] wstrbs,
    input  wire                      wlasts,

    // B channel signalling
    output wire                      bvalids,
    input  wire                      breadys,
    output wire [((USER_WIDTH>0)?(USER_WIDTH-1):0):0] busers,
    output wire [((ID_WIDTH>0)?(ID_WIDTH-1):0):0] bids,
    output wire [1:0]                bresps,

    // AR channel signalling
    input  wire                      arvalids,
    output wire                      arreadys,
    input  wire [((USER_WIDTH>0)?(USER_WIDTH-1):0):0] arusers,
    input  wire [((ID_WIDTH>0)?(ID_WIDTH-1):0):0] arids,
    input  wire [ADDR_WIDTH-1:0]     araddrs,
    //input  wire [3:0]                arregions,
    input  wire [LEN_WIDTH-1:0]                arlens,
    input  wire [2:0]                arsizes,
    input  wire [1:0]                arbursts,
    input  wire                      arlocks,
    input  wire [3:0]                arcaches,
    input  wire [2:0]                arprots,
    input  wire [3:0]                arqoss,

    // R channel signalling
    output wire                      rvalids,
    input  wire                      rreadys,
    output wire [((USER_WIDTH>0)?(USER_WIDTH-1):0):0] rusers,
    output wire [((ID_WIDTH>0)?(ID_WIDTH-1):0):0] rids,
    output wire [DATA_WIDTH-1:0]     rdatas,
    output wire [1:0]                rresps,
    output wire                      rlasts,



    //
    // Asynchronous interfaces
    //

    // Cross-domain power state control
    output wire                   slvmustacceptreqn_async,
    output wire                   slvcandenyreqn_async,
    input  wire                   slvacceptn_async,
    input  wire                   slvdeny_async,

    // Cross-domain wakeup
    output wire                   si_to_mi_wakeup_async,
    input  wire                   mi_to_si_wakeup_async,


    // add
    input wire [AW_FIFO_DEPTH-1:0] aw_rd_ptr_sync,
    input wire [W_FIFO_DEPTH-1:0]  w_rd_ptr_sync,
    output wire [B_FIFO_DEPTH-1:0]  b_rd_ptr_sync,
    input wire [AR_FIFO_DEPTH-1:0] ar_rd_ptr_sync,
    output wire [R_FIFO_DEPTH-1:0]  r_rd_ptr_sync,


    // AW channel signalling
    output wire [AW_FIFO_DEPTH-1:0] aw_wr_ptr_async,
    input  wire [AW_FIFO_DEPTH-1:0] aw_rd_ptr_async,
    //output wire [((aw_payload_width_fn(USER_WIDTH,ID_WIDTH,ADDR_WIDTH)+0)*AW_FIFO_DEPTH)-1:0] aw_payld_async,
    output wire [(((USER_WIDTH+ID_WIDTH+ADDR_WIDTH+29)+0))-1:0] aw_payld_async,

    // W channel signalling
    output wire [ W_FIFO_DEPTH-1:0]  w_wr_ptr_async,
    input  wire [ W_FIFO_DEPTH-1:0]  w_rd_ptr_async,
    //output wire [((w_payload_width_fn(USER_WIDTH,ID_WIDTH,DATA_WIDTH)+0)* W_FIFO_DEPTH)-1:0] w_payld_async,
    output wire [(((USER_WIDTH+DATA_WIDTH+DATA_WIDTH/8+1)+0))-1:0] w_payld_async,

    // B channel signalling
    input  wire [ B_FIFO_DEPTH-1:0]  b_wr_ptr_async,
    output wire [ B_FIFO_DEPTH-1:0]  b_rd_ptr_async,
    //input  wire [(b_payload_width_fn(USER_WIDTH,ID_WIDTH)* B_FIFO_DEPTH)-1:0] b_payld_async,
    input  wire [((USER_WIDTH+ID_WIDTH+2))-1:0] b_payld_async,

    // AR channel signalling
    output wire [AR_FIFO_DEPTH-1:0] ar_wr_ptr_async,
    input  wire [AR_FIFO_DEPTH-1:0] ar_rd_ptr_async,
    //output wire [((ar_payload_width_fn(USER_WIDTH,ID_WIDTH,ADDR_WIDTH)+0)*AR_FIFO_DEPTH)-1:0] ar_payld_async,
    output wire [(((USER_WIDTH+ID_WIDTH+ADDR_WIDTH+29)+0))-1:0] ar_payld_async,

    // R channel signalling
    input  wire [ R_FIFO_DEPTH-1:0]  r_wr_ptr_async,
    output wire [ R_FIFO_DEPTH-1:0]  r_rd_ptr_async,
    //input  wire [(r_payload_width_fn(USER_WIDTH,ID_WIDTH,DATA_WIDTH)* R_FIFO_DEPTH)-1:0] r_payld_async,
    input  wire [((USER_WIDTH+ID_WIDTH+DATA_WIDTH+3))-1:0] r_payld_async


  );



    // AW channel signalling
      wire                      awvalids_i;
      wire                      awreadys_i;
      wire [((USER_WIDTH>0)?(USER_WIDTH-1):0):0] awusers_i;
      wire [((ID_WIDTH>0)?(ID_WIDTH-1):0):0] awids_i;
      wire [ADDR_WIDTH-1:0]     awaddrs_i;
      wire [3:0]                awregions_i;
      wire [LEN_WIDTH-1:0]                awlens_i;
      wire [2:0]                awsizes_i;
      wire [1:0]                awbursts_i;
      wire                      awlocks_i;
      wire [3:0]                awcaches_i;
      wire [2:0]                awprots_i;
      wire [3:0]                awqoss_i;

    // W channel signalling
      wire                      wvalids_i;
      wire                      wreadys_i;
      wire [((USER_WIDTH>0)?(USER_WIDTH-1):0):0] wusers_i;
      wire [DATA_WIDTH-1:0]     wdatas_i;
      wire [(DATA_WIDTH/8)-1:0] wstrbs_i;
      wire                      wlasts_i;

    // B channel signalling
     wire                      bvalids_i;
     wire                      breadys_i;
     wire [((USER_WIDTH>0)?(USER_WIDTH-1):0):0] busers_i;
     wire [((ID_WIDTH>0)?(ID_WIDTH-1):0):0] bids_i;
     wire [1:0]                bresps_i;

    // AR channel signalling
      wire                      arvalids_i;
      wire                      arreadys_i;
      wire [((USER_WIDTH>0)?(USER_WIDTH-1):0):0] arusers_i;
      wire [((ID_WIDTH>0)?(ID_WIDTH-1):0):0] arids_i;
      wire [ADDR_WIDTH-1:0]     araddrs_i;
      wire [3:0]                arregions_i;
      wire [LEN_WIDTH-1:0]                arlens_i;
      wire [2:0]                arsizes_i;
      wire [1:0]                arbursts_i;
      wire                      arlocks_i;
      wire [3:0]                arcaches_i;
      wire [2:0]                arprots_i;
      wire [3:0]                arqoss_i;

    // R channel signalling
     wire                      rvalids_i;
     wire                      rreadys_i;
     wire [((USER_WIDTH>0)?(USER_WIDTH-1):0):0] rusers_i;
     wire [((ID_WIDTH>0)?(ID_WIDTH-1):0):0] rids_i;
     wire [DATA_WIDTH-1:0]     rdatas_i;
     wire [1:0]                rresps_i;
     wire                      rlasts_i;


     // err_rsp
    // AW channel signalling
      wire                      awvalids_dummy;
      wire                      awreadys_dummy;
      wire [((USER_WIDTH>0)?(USER_WIDTH-1):0):0] awusers_dummy;
      wire [((ID_WIDTH>0)?(ID_WIDTH-1):0):0] awids_dummy;
      wire [ADDR_WIDTH-1:0]     awaddrs_dummy;
      wire [3:0]                awregions_dummy;
      wire [LEN_WIDTH-1:0]                awlens_dummy;
      wire [2:0]                awsizes_dummy;
      wire [1:0]                awbursts_dummy;
      wire                      awlocks_dummy;
      wire [3:0]                awcaches_dummy;
      wire [2:0]                awprots_dummy;
      wire [3:0]                awqoss_dummy;

    // W channel signalling
      wire                      wvalids_dummy;
      wire                      wreadys_dummy;
      wire [((USER_WIDTH>0)?(USER_WIDTH-1):0):0] wusers_dummy;
      wire [DATA_WIDTH-1:0]     wdatas_dummy;
      wire [(DATA_WIDTH/8)-1:0] wstrbs_dummy;
      wire                      wlasts_dummy;

    // B channel signalling
     wire                      bvalids_dummy;
     wire                      breadys_dummy;
     wire [((USER_WIDTH>0)?(USER_WIDTH-1):0):0] busers_dummy;
     wire [((ID_WIDTH>0)?(ID_WIDTH-1):0):0] bids_dummy;
     wire [1:0]                bresps_dummy;

    // AR channel signalling
      wire                      arvalids_dummy;
      wire                      arreadys_dummy;
      wire [((USER_WIDTH>0)?(USER_WIDTH-1):0):0] arusers_dummy;
      wire [((ID_WIDTH>0)?(ID_WIDTH-1):0):0] arids_dummy;
      wire [ADDR_WIDTH-1:0]     araddrs_dummy;
      wire [3:0]                arregions_dummy;
      wire [LEN_WIDTH-1:0]                arlens_dummy;
      wire [2:0]                arsizes_dummy;
      wire [1:0]                arbursts_dummy;
      wire                      arlocks_dummy;
      wire [3:0]                arcaches_dummy;
      wire [2:0]                arprots_dummy;
      wire [3:0]                arqoss_dummy;

    // R channel signalling
     wire                      rvalids_dummy;
     wire                      rreadys_dummy;
     wire [((USER_WIDTH>0)?(USER_WIDTH-1):0):0] rusers_dummy;
     wire [((ID_WIDTH>0)?(ID_WIDTH-1):0):0] rids_dummy;
     wire [DATA_WIDTH-1:0]     rdatas_dummy;
     wire [1:0]                rresps_dummy;
     wire                      rlasts_dummy;



//



/*autowire*/
// Beginning of automatic wires (for undeclared instantiated-module outputs)
wire [31:0]             adb_debug_monitor_o;    // From adb400_r3_axi4_slv_u of adb400_r3_axi4_slv.v
wire                    pwrqacceptn_o_dummy;    // From dummy_adb_axi4_u of dummy_adb_axi4.v
// End of automatics

    // Debug signalling
    wire                      dftrstdisables;
    assign dftrstdisables = 1'b0;

wire ppu_st_pwron_ss;
wire adb_mux_sel;
wire pwrqreqns_i_ss;
wire reg_err_rsp_en_ss;

  adb400_r3_syncn
    #(
      .LEVELS           (2)
    )
    u_syncn_st_pwron
    (
      .aclk    (aclks),
      .aresetn (aresetns),
      .din     (ppu_st_pwron),
      .dout    (ppu_st_pwron_ss)
    );

  adb400_r3_syncn
    #(
      .LEVELS           (2)
    )
    u_syncn_pwrqreqn
    (
      .aclk    (aclks),
      .aresetn (aresetns),
      .din     (pwrqreqns_i),
      .dout    (pwrqreqns_i_ss)
    );

  adb400_r3_syncn
    #(
      .LEVELS           (2)
    )
    u_syncn_err_rsp
    (
      .aclk    (aclks),
      .aresetn (aresetns),
      .din     (reg_err_rsp_en),
      .dout    (reg_err_rsp_en_ss)
    );

wire [3:0]                awregions;
wire [3:0]                arregions;

assign arregions = 4'h0;
assign awregions = 4'h0;



assign  awusers_i    = awusers     ;
assign  awids_i      = awids       ;
assign  awaddrs_i    = awaddrs     ;
assign  awregions_i  = awregions   ;
assign  awlens_i     = awlens      ;
assign  awsizes_i    = awsizes     ;
assign  awbursts_i   = awbursts    ;
assign  awlocks_i    = awlocks     ;
assign  awcaches_i   = awcaches    ;
assign  awprots_i    = awprots     ;
assign  awqoss_i     = awqoss      ;
assign  wusers_i     = wusers      ;
assign  wdatas_i     = wdatas      ;
assign  wstrbs_i     = wstrbs      ;
assign  arusers_i    = arusers     ;
assign  arids_i      = arids       ;
assign  araddrs_i    = araddrs     ;
assign  arregions_i  = arregions   ;
assign  arlens_i     = arlens      ;
assign  arsizes_i    = arsizes     ;
assign  arbursts_i   = arbursts    ;
assign  arlocks_i    = arlocks     ;
assign  arcaches_i   = arcaches    ;
assign  arprots_i    = arprots     ;
assign  arqoss_i     = arqoss      ;





assign  awusers_dummy    = awusers     ;
assign  awids_dummy      = awids       ;
assign  awaddrs_dummy    = awaddrs     ;
assign  awregions_dummy  = awregions   ;
assign  awlens_dummy     = awlens      ;
assign  awsizes_dummy    = awsizes     ;
assign  awbursts_dummy   = awbursts    ;
assign  awlocks_dummy    = awlocks     ;
assign  awcaches_dummy   = awcaches    ;
assign  awprots_dummy    = awprots     ;
assign  awqoss_dummy     = awqoss      ;
assign  wusers_dummy     = wusers      ;
assign  wdatas_dummy     = wdatas      ;
assign  wstrbs_dummy     = wstrbs      ;
assign  arusers_dummy    = arusers     ;
assign  arids_dummy      = arids       ;
assign  araddrs_dummy    = araddrs     ;
assign  arregions_dummy  = arregions   ;
assign  arlens_dummy     = arlens      ;
assign  arsizes_dummy    = arsizes     ;
assign  arbursts_dummy   = arbursts    ;
assign  arlocks_dummy    = arlocks     ;
assign  arcaches_dummy   = arcaches    ;
assign  arprots_dummy    = arprots     ;
assign  arqoss_dummy     = arqoss      ;



assign  awvalids_dummy   = (adb_mux_sel)? 1'b0 : awvalids    ;
assign  wvalids_dummy    = (adb_mux_sel)? 1'b0 : wvalids     ;
assign  wlasts_dummy     = (adb_mux_sel)? 1'b0 : wlasts      ;
assign  breadys_dummy    = (adb_mux_sel)? 1'b1 : breadys     ;
assign  arvalids_dummy   = (adb_mux_sel)? 1'b0 : arvalids    ;
assign  rreadys_dummy    = (adb_mux_sel)? 1'b1 : rreadys     ;

assign  awvalids_i   = (adb_mux_sel)?  awvalids : 1'b0   ;
assign  wvalids_i    = (adb_mux_sel)?  wvalids  : 1'b0   ;
assign  wlasts_i     = (adb_mux_sel)?  wlasts   : 1'b0   ;
assign  breadys_i    = (adb_mux_sel)?  breadys  : 1'b1   ;
assign  arvalids_i   = (adb_mux_sel)?  arvalids : 1'b0   ;
assign  rreadys_i    = (adb_mux_sel)?  rreadys  : 1'b1   ;


       
assign  awreadys     = (adb_mux_sel)? awreadys_i    : awreadys_dummy   ;
assign  wreadys      = (adb_mux_sel)? wreadys_i     : wreadys_dummy    ;
assign  bvalids      = (adb_mux_sel)? bvalids_i     : bvalids_dummy    ;
assign  bids         = (adb_mux_sel)? bids_i        : bids_dummy       ;
assign  busers       = (adb_mux_sel)? busers_i      : busers_dummy    ;
assign  bresps       = (adb_mux_sel)? bresps_i      : bresps_dummy     ;
assign  arreadys     = (adb_mux_sel)? arreadys_i    : arreadys_dummy   ;
assign  rvalids      = (adb_mux_sel)? rvalids_i     : rvalids_dummy    ;
assign  rids         = (adb_mux_sel)? rids_i        : rids_dummy       ;
assign  rusers       = (adb_mux_sel)? rusers_i      : rusers_dummy     ;
assign  rdatas       = (adb_mux_sel)? rdatas_i      : rdatas_dummy     ;
assign  rresps       = (adb_mux_sel)? rresps_i      : rresps_dummy     ;
assign  rlasts       = (adb_mux_sel)? rlasts_i      : rlasts_dummy     ;


// global power up or ADB power up -> select ADB
// global power down and ADB power down -> select dummy ADB
assign adb_mux_sel = reg_err_rsp_en_ss ? ppu_st_pwron_ss | pwrqacceptns_o : 1'b1;


reg pwrqreqns;
always @(posedge aclks or negedge aresetns)
if (! aresetns)
  pwrqreqns <=1'b0;
else if(pwrqreqns_i_ss & ~pwrqacceptns_o & pwrqacceptn_o_dummy) //wait dummy power off,than power up ADB 
  pwrqreqns <=1'b0;
else 
  pwrqreqns <=pwrqreqns_i_ss;

wire pwrqreqns_adb;
wire pwrqreqns_dummy_adb;
assign pwrqreqns_adb        = reg_err_rsp_en_ss ? pwrqreqns : pwrqreqns_i_ss;
assign pwrqreqns_dummy_adb = reg_err_rsp_en_ss ? ~pwrqreqns_i_ss : 1'b0;





//--------------------debug---------------------------

reg power_down_access;
always @(posedge aclks or negedge aresetns)
if (! aresetns)
  power_down_access <= 1'b0;
else if ( awvalids_dummy | arvalids_dummy )
  power_down_access <= 1'b1;

assign adb_debug_monitor = {adb_debug_monitor_o[31:23],power_down_access,adb_debug_monitor_o[21:0]};




//-----------------------------------------------








/*adb400_r3_axi4_slv auto_template (
.\(.*async\)    (\1),
.\(.*sync\)     (\1),

 .pwrqreqns_i                           (pwrqreqns_adb ),
 .adb_debug_monitor_o                   (adb_debug_monitor_o[]),
.\(pwr.*\)      (\1),
 .aclks                                 (aclks),               
 .aresetns                              (aresetns),
 .dft_test_mode                         (dft_test_mode),
 .dftrstdisables                        (dftrstdisables),
.\(.*\)         (\1_i),


);

*/

adb400_r3_axi4_slv
 #(/*autoi nstparam*/
   // Parameters
   .ADDR_WIDTH                          (ADDR_WIDTH),
   .DATA_WIDTH                          (DATA_WIDTH),
   .ID_WIDTH                            (ID_WIDTH),
   .USER_WIDTH                          (USER_WIDTH),
   .LEN_WIDTH                           (LEN_WIDTH),
   .AW_FIFO_DEPTH                       (AW_FIFO_DEPTH),
   .W_FIFO_DEPTH                        (W_FIFO_DEPTH),
   .B_FIFO_DEPTH                        (B_FIFO_DEPTH),
   .AR_FIFO_DEPTH                       (AR_FIFO_DEPTH),
   .R_FIFO_DEPTH                        (R_FIFO_DEPTH),
   .RD_OSTD_NUM                         (RD_OSTD_NUM),
   .WR_OSTD_NUM                         (WR_OSTD_NUM)  
 
 )
adb400_r3_axi4_slv_u
(/*autoinst*/
 // Outputs
 .pwrqacceptns_o                        (pwrqacceptns_o),        // Templated
 .pwrqdenys_o                           (pwrqdenys_o),           // Templated
 .pwrqactives_o                         (pwrqactives_o),         // Templated
 .adb_debug_monitor_o                   (adb_debug_monitor_o[31:0]), // Templated
 .awreadys                              (awreadys_i),            // Templated
 .wreadys                               (wreadys_i),             // Templated
 .bvalids                               (bvalids_i),             // Templated
 .busers                                (busers_i),              // Templated
 .bids                                  (bids_i),                // Templated
 .bresps                                (bresps_i),              // Templated
 .arreadys                              (arreadys_i),            // Templated
 .rvalids                               (rvalids_i),             // Templated
 .rusers                                (rusers_i),              // Templated
 .rids                                  (rids_i),                // Templated
 .rdatas                                (rdatas_i),              // Templated
 .rresps                                (rresps_i),              // Templated
 .rlasts                                (rlasts_i),              // Templated
 .slvmustacceptreqn_async               (slvmustacceptreqn_async), // Templated
 .slvcandenyreqn_async                  (slvcandenyreqn_async),  // Templated
 .si_to_mi_wakeup_async                 (si_to_mi_wakeup_async), // Templated
 .b_rd_ptr_sync                         (b_rd_ptr_sync),         // Templated
 .r_rd_ptr_sync                         (r_rd_ptr_sync),         // Templated
 .aw_wr_ptr_async                       (aw_wr_ptr_async),       // Templated
 .aw_payld_async                        (aw_payld_async),        // Templated
 .w_wr_ptr_async                        (w_wr_ptr_async),        // Templated
 .w_payld_async                         (w_payld_async),         // Templated
 .b_rd_ptr_async                        (b_rd_ptr_async),        // Templated
 .ar_wr_ptr_async                       (ar_wr_ptr_async),       // Templated
 .ar_payld_async                        (ar_payld_async),        // Templated
 .r_rd_ptr_async                        (r_rd_ptr_async),        // Templated
 // Inputs
 .pwrq_permit_deny_sar_i                (pwrq_permit_deny_sar_i), // Templated
 .aclks                                 (aclks),                 // Templated
 .aresetns                              (aresetns),              // Templated
 .dft_test_mode                         (dft_test_mode),         // Templated
 .pwrqreqns_i                           (pwrqreqns_adb ),        // Templated
 .awvalids                              (awvalids_i),            // Templated
 .awusers                               (awusers_i),             // Templated
 .awids                                 (awids_i),               // Templated
 .awaddrs                               (awaddrs_i),             // Templated
 .awregions                             (awregions_i),           // Templated
 .awlens                                (awlens_i),              // Templated
 .awsizes                               (awsizes_i),             // Templated
 .awbursts                              (awbursts_i),            // Templated
 .awlocks                               (awlocks_i),             // Templated
 .awcaches                              (awcaches_i),            // Templated
 .awprots                               (awprots_i),             // Templated
 .awqoss                                (awqoss_i),              // Templated
 .wvalids                               (wvalids_i),             // Templated
 .wusers                                (wusers_i),              // Templated
 .wdatas                                (wdatas_i),              // Templated
 .wstrbs                                (wstrbs_i),              // Templated
 .wlasts                                (wlasts_i),              // Templated
 .breadys                               (breadys_i),             // Templated
 .arvalids                              (arvalids_i),            // Templated
 .arusers                               (arusers_i),             // Templated
 .arids                                 (arids_i),               // Templated
 .araddrs                               (araddrs_i),             // Templated
 .arregions                             (arregions_i),           // Templated
 .arlens                                (arlens_i),              // Templated
 .arsizes                               (arsizes_i),             // Templated
 .arbursts                              (arbursts_i),            // Templated
 .arlocks                               (arlocks_i),             // Templated
 .arcaches                              (arcaches_i),            // Templated
 .arprots                               (arprots_i),             // Templated
 .arqoss                                (arqoss_i),              // Templated
 .rreadys                               (rreadys_i),             // Templated
 .slvacceptn_async                      (slvacceptn_async),      // Templated
 .slvdeny_async                         (slvdeny_async),         // Templated
 .mi_to_si_wakeup_async                 (mi_to_si_wakeup_async), // Templated
 .aw_rd_ptr_sync                        (aw_rd_ptr_sync),        // Templated
 .w_rd_ptr_sync                         (w_rd_ptr_sync),         // Templated
 .ar_rd_ptr_sync                        (ar_rd_ptr_sync),        // Templated
 .aw_rd_ptr_async                       (aw_rd_ptr_async),       // Templated
 .w_rd_ptr_async                        (w_rd_ptr_async),        // Templated
 .b_wr_ptr_async                        (b_wr_ptr_async),        // Templated
 .b_payld_async                         (b_payld_async),         // Templated
 .ar_rd_ptr_async                       (ar_rd_ptr_async),       // Templated
 .r_wr_ptr_async                        (r_wr_ptr_async),        // Templated
 .r_payld_async                         (r_payld_async),         // Templated
 .dftrstdisables                        (dftrstdisables));       // Templated














/*dummy_adb_axi4 auto_template (
  .pwrq_permit_deny_sar_i                (1'b0),
  .pwrqdeny_o                            (),
 .pwrqactive_o                          (),  
  .pwrqreqn_i                            (pwrqreqns_dummy_adb), 
 .pwrqacceptn_o                         (pwrqacceptn_o_dummy),   

 .aclk                                 (aclks),               
 .aresetn                              (aresetns),
 .dft_test_mode                         (dft_test_mode),
 .dftrstdisable                        (dftrstdisables),
.\(.*s\)         (\1_dummy),
//.\(.*\)m         (\1s_rp),

);
*/
dummy_adb_axi4
    #(
      .ADDR_WIDTH       (ADDR_WIDTH),
      .DATA_WIDTH       (DATA_WIDTH),
      .ID_WIDTH         (ID_WIDTH),
      .USER_WIDTH       (USER_WIDTH),
      .LEN_WIDTH        (LEN_WIDTH),
      .MAX_RD           (RD_OSTD_NUM - 1 ),
      .MAX_WR           (WR_OSTD_NUM - 1 )      
    
    )
dummy_adb_axi4_u
(/*autoinst*/
 // Outputs
 .pwrqacceptn_o                         (pwrqacceptn_o_dummy),   // Templated
 .pwrqdeny_o                            (),                      // Templated
 .pwrqactive_o                          (),                      // Templated
 .awreadys                              (awreadys_dummy),        // Templated
 .wreadys                               (wreadys_dummy),         // Templated
 .bvalids                               (bvalids_dummy),         // Templated
 .busers                                (busers_dummy),          // Templated
 .bids                                  (bids_dummy),            // Templated
 .bresps                                (bresps_dummy),          // Templated
 .arreadys                              (arreadys_dummy),        // Templated
 .rvalids                               (rvalids_dummy),         // Templated
 .rusers                                (rusers_dummy),          // Templated
 .rids                                  (rids_dummy),            // Templated
 .rdatas                                (rdatas_dummy),          // Templated
 .rresps                                (rresps_dummy),          // Templated
 .rlasts                                (rlasts_dummy),          // Templated
 // Inputs
 .pwrq_permit_deny_sar_i                (1'b0),                  // Templated
 .aclk                                  (aclks),                 // Templated
 .aresetn                               (aresetns),              // Templated
 .dft_test_mode                         (dft_test_mode),         // Templated
 .pwrqreqn_i                            (pwrqreqns_dummy_adb),   // Templated
 .awvalids                              (awvalids_dummy),        // Templated
 .awusers                               (awusers_dummy),         // Templated
 .awids                                 (awids_dummy),           // Templated
 .awaddrs                               (awaddrs_dummy),         // Templated
 .awregions                             (awregions_dummy),       // Templated
 .awlens                                (awlens_dummy),          // Templated
 .awsizes                               (awsizes_dummy),         // Templated
 .awbursts                              (awbursts_dummy),        // Templated
 .awlocks                               (awlocks_dummy),         // Templated
 .awcaches                              (awcaches_dummy),        // Templated
 .awprots                               (awprots_dummy),         // Templated
 .awqoss                                (awqoss_dummy),          // Templated
 .wvalids                               (wvalids_dummy),         // Templated
 .wusers                                (wusers_dummy),          // Templated
 .wdatas                                (wdatas_dummy),          // Templated
 .wstrbs                                (wstrbs_dummy),          // Templated
 .wlasts                                (wlasts_dummy),          // Templated
 .breadys                               (breadys_dummy),         // Templated
 .arvalids                              (arvalids_dummy),        // Templated
 .arusers                               (arusers_dummy),         // Templated
 .arids                                 (arids_dummy),           // Templated
 .araddrs                               (araddrs_dummy),         // Templated
 .arregions                             (arregions_dummy),       // Templated
 .arlens                                (arlens_dummy),          // Templated
 .arsizes                               (arsizes_dummy),         // Templated
 .arbursts                              (arbursts_dummy),        // Templated
 .arlocks                               (arlocks_dummy),         // Templated
 .arcaches                              (arcaches_dummy),        // Templated
 .arprots                               (arprots_dummy),         // Templated
 .arqoss                                (arqoss_dummy),          // Templated
 .rreadys                               (rreadys_dummy),         // Templated
 .dftrstdisable                         (dftrstdisables));       // Templated










endmodule
// Local Variables:
// verilog-library-directories:("./" "../*/verilog" "./dw_axi") 
// verilog-auto-inst-param-value:t
// End:
