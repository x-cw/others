//-----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited or its affiliates.
//
// (C) COPYRIGHT 2015-2016 ARM Limited or its affiliates.
// ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited or its affiliates.
//
// Checked In :  2016-02-07 15:48:44 +0000 (Sun, 07 Feb 2016)
// Revision : 206511
//
// Release Information : PL405-r3p0-00eac0
//
//-----------------------------------------------------------------------------
// Verilog-2001 (IEEE Std 1364-2001)
//-----------------------------------------------------------------------------
// File: adb400_r3_bas_slv.v
//-----------------------------------------------------------------------------
// Purpose : Slave side of bridge with bi-directional AXI4-Stream interfaces.
//-----------------------------------------------------------------------------

module adb400_r3_apb_slv_err_rsp
  #(parameter

      ADDR_WIDTH        = 32, 
      DATA_WIDTH        = 32, 
      USER_WIDTH        = 10, 
      FW_FIFO_DEPTH     = 2,
      RV_FIFO_DEPTH     = 2 


  )
  (
    // Configuration inputs
    input  wire                                             pwrq_permit_deny_sar_i,

    // Power state control
    input  wire                                             pwrqreqns_i,
    output wire                                             pwrqacceptns_o,
    output wire                                             pwrqdenys_o,
    output wire                                             pwrqactives_o,

    input wire                                               ppu_st_pwron,
    input wire                                               reg_err_rsp_en,

    // Global signals
    input  wire                                             pclks,
    input  wire                                             presetns,


    input  wire                                             dft_test_mode,



    // APB3
    input  wire                                             psels,
    input  wire                                             penables,
    input  wire                                             pwrites,
    input  wire  [ADDR_WIDTH-1:0]                           paddrs,
    input  wire  [DATA_WIDTH-1:0]                           pwdatas,
    input  wire  [USER_WIDTH-1:0]                           pusers,
    output  wire                                            preadys,
    output  wire [DATA_WIDTH-1:0]                           prdatas,
    output  wire                                            pslverrs,

    //debug
    output wire  [31:0]              adb_debug_monitor,


    // Async interfaces 

    output wire                                             slvmustacceptreqn_async,
    output wire                                             slvcandenyreqn_async,
    input  wire                                             slvacceptn_async,
    input  wire                                             slvdeny_async,

    output wire                                             si_to_mi_wakeup_async,
    input  wire                                             mi_to_si_wakeup_async,

    // add
    input wire [FW_FIFO_DEPTH-1:0]fw_rd_ptr_sync,
    output wire [RV_FIFO_DEPTH-1:0]rv_rd_ptr_sync,  

    output wire [FW_FIFO_DEPTH-1:0]                         fw_wr_ptr_async,
    input  wire [FW_FIFO_DEPTH-1:0]                         fw_rd_ptr_async,
    //output wire [((payload_width_fn(FW_LAST_WIDTH,FW_DATA_WIDTH,FW_STRB_WIDTH,FW_KEEP_WIDTH,FW_ID_WIDTH,FW_DEST_WIDTH,FW_USER_WIDTH)>0)?
    //              ((payload_width_fn(FW_LAST_WIDTH,FW_DATA_WIDTH,FW_STRB_WIDTH,FW_KEEP_WIDTH,FW_ID_WIDTH,FW_DEST_WIDTH,FW_USER_WIDTH)*FW_FIFO_DEPTH)-1):0):0]              fw_payld_async,     
    output wire [(DATA_WIDTH + ADDR_WIDTH + USER_WIDTH + 1)-1:0]                                     fw_payld_async,

    input  wire [RV_FIFO_DEPTH-1:0]                         rv_wr_ptr_async,
    output wire [RV_FIFO_DEPTH-1:0]                         rv_rd_ptr_async,
    //   input  wire [((payload_width_fn(RV_LAST_WIDTH,RV_DATA_WIDTH,RV_STRB_WIDTH,RV_KEEP_WIDTH,RV_ID_WIDTH,RV_DEST_WIDTH, RV_USER_WIDTH)>0)?
    //              ((payload_width_fn(RV_LAST_WIDTH,RV_DATA_WIDTH,RV_STRB_WIDTH,RV_KEEP_WIDTH,RV_ID_WIDTH,RV_DEST_WIDTH,RV_USER_WIDTH)*RV_FIFO_DEPTH)-1):0):0]                rv_payld_async      
    input  wire [(DATA_WIDTH  + 1)-1:0]                                     rv_payld_async 

  );


/*autowire*/
// Beginning of automatic wires (for undeclared instantiated-module outputs)
wire [31:0]             adb_debug_monitor_o;    // From adb400_r3_apb_slv_u of adb400_r3_apb_slv.v
// End of automatics


     wire                                             psels_i;
     wire                                             penables_i;
     wire                                             pwrites_i;
     wire  [ADDR_WIDTH-1:0]                           paddrs_i;
     wire  [DATA_WIDTH-1:0]                           pwdatas_i;
     wire  [USER_WIDTH-1:0]                           pusers_i;
     wire                                            preadys_i;
     wire [DATA_WIDTH-1:0]                           prdatas_i;
     wire                                            pslverrs_i;

     wire                                             psels_dummy;
     wire                                             penables_dummy;
     wire                                             pwrites_dummy;
     wire  [ADDR_WIDTH-1:0]                           paddrs_dummy;
     wire  [DATA_WIDTH-1:0]                           pwdatas_dummy;
     wire  [USER_WIDTH-1:0]                           pusers_dummy;
     wire                                            preadys_dummy;
     wire [DATA_WIDTH-1:0]                           prdatas_dummy;
     wire                                            pslverrs_dummy;

     wire ppu_st_pwron_ss;
     wire adb_mux_sel;
     wire pwrqreqns_i_ss;
     //wire pwrqreqns_t;
     //wire preadys_dummy;
     wire pwrqacceptns_o_dummy;
     wire reg_err_rsp_en_ss;

     wire                                             dftrstdisables;

     assign dftrstdisables = 1'b0;

  adb400_r3_syncn
    #(
      .LEVELS           (2)
    )
    u_syncn_st_pwron
    (
      .aclk    (pclks),
      .aresetn (presetns),
      .din     (ppu_st_pwron),
      .dout    (ppu_st_pwron_ss)
    );

  adb400_r3_syncn
    #(
      .LEVELS           (2)
    )
    u0_syncn_pwrqreqn
    (
      .aclk    (pclks),
      .aresetn (presetns),
      .din     (pwrqreqns_i),
      .dout    (pwrqreqns_i_ss)
    );


  adb400_r3_syncn
    #(
      .LEVELS           (2)
    )
    u_syncn_st_err_rsp_en
    (
      .aclk    (pclks),
      .aresetn (presetns),
      .din     (reg_err_rsp_en),
      .dout    (reg_err_rsp_en_ss)
    );


    reg [4:0]adb_mux_sel_s;
    //wire enable_sticky;
    //reg preadys_dummy_r;
    //always @(posedge pclks or negedge presetns)
    //if (! presetns)
    //  preadys_dummy_r <=1'b0;
    //else 
    //  preadys_dummy_r <=preadys_dummy;
    
    
    //assign enable_sticky = ~preadys_dummy & preadys_dummy_r & pwrqacceptns_o_dummy ;
    
    //wire apb_enable;
    //reg apb_enable_r;
    //always @(posedge pclks or negedge presetns)
    //if (! presetns)
    //  apb_enable_r <= 1'b0;
    //else
    //  apb_enable_r <= apb_enable;
    //
    //assign apb_enable = psels & penables;
    //
    //// enable_sticky happen at dummy_adb poweron -> adb poweron,
    //// and at pre and curr are enable 
    //assign enable_sticky = adb_mux_sel & ~adb_mux_sel_s & apb_enable & apb_enable_r;
    
    
    
    
    
    // global power up ,or ADB power up and dummy power down -> select ADB
    // global power down and ADB power down -> select dummy ADB
    // ~preadys_dummy & pwrqacceptns_o_dummy : ADB swicth to dummy at ~preadys_dummy
    assign adb_mux_sel = reg_err_rsp_en_ss ? (ppu_st_pwron_ss | pwrqacceptns_o | (~pwrqacceptns_o_dummy | (~preadys_dummy & pwrqacceptns_o_dummy))) : 1'b1;
    
    
    //assign sticky = (pwrqreqns_i_ss & ~pwrqreqns_i_sss) & (psels_i & penables);
    //assign ready_t = ~(pwrqreqns_i_ss & ~pwrqacceptns_o) | sticky;


    assign  psels_i    = (adb_mux_sel)? psels    : 1'b0;
    //assign  penables_i = (adb_mux_sel)? penables & ~enable_sticky : 1'b0;
    assign  penables_i = (adb_mux_sel)? penables : 1'b0;
    assign  pwrites_i  = (adb_mux_sel)? pwrites  : 1'b0;
    assign  paddrs_i   = (adb_mux_sel)? paddrs   : {ADDR_WIDTH{1'b0}};
    assign  pwdatas_i  = (adb_mux_sel)? pwdatas  : {DATA_WIDTH{1'b0}};
    assign  pusers_i   = (adb_mux_sel)? pusers   : {USER_WIDTH{1'b0}};

    assign  psels_dummy    = (adb_mux_sel)? 1'b0 : psels;
    assign  penables_dummy = (adb_mux_sel)? 1'b0 : penables;
    assign  pwrites_dummy  = (adb_mux_sel)? 1'b0               : pwrites  ;
    assign  paddrs_dummy   = (adb_mux_sel)? {ADDR_WIDTH{1'b0}} : paddrs   ;
    assign  pwdatas_dummy  = (adb_mux_sel)? {DATA_WIDTH{1'b0}} : pwdatas  ;
    assign  pusers_dummy   = (adb_mux_sel)? {USER_WIDTH{1'b0}} : pusers   ;


    assign   preadys  = (adb_mux_sel)? preadys_i:  preadys_dummy;
    assign   prdatas  = (adb_mux_sel)? prdatas_i:  prdatas_dummy ;
    assign   pslverrs = (adb_mux_sel)? pslverrs_i: pslverrs_dummy;

    reg pwrqreqns;
    wire pwrqreqns_adb;
    wire pwrqreqns_dummy_adb;
    always @(posedge pclks or negedge presetns)
    if (! presetns)
      pwrqreqns <=1'b0;
    else if(pwrqreqns_i_ss & ~pwrqacceptns_o & pwrqacceptns_o_dummy) //wait dummy power off,than power up ADB
      pwrqreqns <=1'b0;
    else 
      pwrqreqns <=pwrqreqns_i_ss;
    
    assign pwrqreqns_adb        = reg_err_rsp_en_ss ? pwrqreqns : pwrqreqns_i_ss;
    assign pwrqreqns_dummy_adb = reg_err_rsp_en_ss ? ~pwrqreqns_i_ss : 1'b0;
    
    
    always @(posedge pclks or negedge presetns)
      if (! presetns) 
      adb_mux_sel_s <= 5'd0;
    else 
      adb_mux_sel_s <= {adb_mux_sel_s[3:0],adb_mux_sel};
    
    
    wire force_resetn_4cycle;
    assign force_resetn_4cycle= ~(adb_mux_sel_s[4] & ~adb_mux_sel_s[0]);
    
    wire presetns_i;
    assign presetns_i = dft_test_mode? presetns: force_resetn_4cycle & presetns;


//--------------------debug---------------------------

reg power_down_access;
always @(posedge pclks or negedge presetns)
if (! presetns)
  power_down_access <= 1'b0;
else if ( psels_dummy & penables_dummy )
  power_down_access <= 1'b1;


assign adb_debug_monitor = {adb_debug_monitor_o[31:11],power_down_access,adb_debug_monitor_o[9:0]};




//-----------------------------------------------


/*adb400_r3_apb_slv auto_template (
.\(.*async\)    (\1),
.\(.*sync\)     (\1),
 .pwrqreqns_i        (pwrqreqns_adb),
.\(pwrq.*\)      (\1),
 .pclks                                 (pclks),               
 .presetns                              (presetns_i),
 .dft_test_mode                         (dft_test_mode),
 .dftrstdisables                        (dftrstdisables),

  .adb_debug_monitor_o                   (adb_debug_monitor_o[]),

.\(.*\)         (\1_i),

);
*/
              

adb400_r3_apb_slv
#(/*autoinst param*/
                        // Parameters
                        .ADDR_WIDTH     (ADDR_WIDTH),
                        .DATA_WIDTH     (DATA_WIDTH),
                        .USER_WIDTH     (USER_WIDTH),
                        .FW_FIFO_DEPTH  (FW_FIFO_DEPTH),
                        .RV_FIFO_DEPTH  (RV_FIFO_DEPTH))
                    
adb400_r3_apb_slv_u(/*autoinst*/
                    // Outputs
                    .pwrqacceptns_o     (pwrqacceptns_o),        // Templated
                    .pwrqdenys_o        (pwrqdenys_o),           // Templated
                    .pwrqactives_o      (pwrqactives_o),         // Templated
                    .preadys            (preadys_i),             // Templated
                    .prdatas            (prdatas_i),             // Templated
                    .pslverrs           (pslverrs_i),            // Templated
                    .adb_debug_monitor_o(adb_debug_monitor_o[31:0]), // Templated
                    .slvmustacceptreqn_async(slvmustacceptreqn_async), // Templated
                    .slvcandenyreqn_async(slvcandenyreqn_async), // Templated
                    .si_to_mi_wakeup_async(si_to_mi_wakeup_async), // Templated
                    .rv_rd_ptr_sync     (rv_rd_ptr_sync),        // Templated
                    .fw_wr_ptr_async    (fw_wr_ptr_async),       // Templated
                    .fw_payld_async     (fw_payld_async),        // Templated
                    .rv_rd_ptr_async    (rv_rd_ptr_async),       // Templated
                    // Inputs
                    .pwrq_permit_deny_sar_i(pwrq_permit_deny_sar_i), // Templated
                    .pwrqreqns_i        (pwrqreqns_adb),         // Templated
                    .pclks              (pclks),                 // Templated
                    .presetns           (presetns_i),            // Templated
                    .dftrstdisables     (dftrstdisables),        // Templated
                    .dft_test_mode      (dft_test_mode),         // Templated
                    .psels              (psels_i),               // Templated
                    .penables           (penables_i),            // Templated
                    .pwrites            (pwrites_i),             // Templated
                    .paddrs             (paddrs_i),              // Templated
                    .pwdatas            (pwdatas_i),             // Templated
                    .pusers             (pusers_i),              // Templated
                    .slvacceptn_async   (slvacceptn_async),      // Templated
                    .slvdeny_async      (slvdeny_async),         // Templated
                    .mi_to_si_wakeup_async(mi_to_si_wakeup_async), // Templated
                    .fw_rd_ptr_sync     (fw_rd_ptr_sync),        // Templated
                    .fw_rd_ptr_async    (fw_rd_ptr_async),       // Templated
                    .rv_wr_ptr_async    (rv_wr_ptr_async),       // Templated
                    .rv_payld_async     (rv_payld_async));       // Templated       // Templated       // Templated       // Templated       // Templated       // Templated       // Templated,






/*dummy_apb3_adb auto_template (
  .pwrq_permit_deny_sar_i                (1'b0),
  .pwrqdeny_o                            (),
  .pwrqactive_o                          (),  
  .pwrqreqn_i                            (pwrqreqns_dummy_adb), 
  .pwrqacceptn_o                         (pwrqacceptns_o_dummy),   

 .pclks                                 (pclks),               
 .presetns                              (presetns),
 .dft_test_mode                         (dft_test_mode),
 .dftrstdisables                        (dftrstdisables),
.\(.*\)         (\1_dummy),

);
*/
dummy_apb3_adb
#(/*autoinst param*/
                        // Parameters
                        .ADDR_WIDTH     (ADDR_WIDTH),
                        .DATA_WIDTH     (DATA_WIDTH),
                        .USER_WIDTH     (USER_WIDTH),
                        .FW_FIFO_DEPTH  (FW_FIFO_DEPTH),
                        .RV_FIFO_DEPTH  (RV_FIFO_DEPTH))

dummy_apb3_adb_u
(/*autoinst*/
 // Outputs
 .pwrqacceptn_o                         (pwrqacceptns_o_dummy),  // Templated
 .pwrqdeny_o                            (),                      // Templated
 .pwrqactive_o                          (),                      // Templated
 .preadys                               (preadys_dummy),         // Templated
 .prdatas                               (prdatas_dummy),         // Templated
 .pslverrs                              (pslverrs_dummy),        // Templated
 // Inputs
 .pwrq_permit_deny_sar_i                (1'b0),                  // Templated
 .pwrqreqn_i                            (pwrqreqns_dummy_adb),   // Templated
 .pclks                                 (pclks),                 // Templated
 .presetns                              (presetns),              // Templated
 .dftrstdisables                        (dftrstdisables),        // Templated
 .dft_test_mode                         (dft_test_mode),         // Templated
 .psels                                 (psels_dummy),           // Templated
 .penables                              (penables_dummy),        // Templated
 .pwrites                               (pwrites_dummy),         // Templated
 .paddrs                                (paddrs_dummy),          // Templated
 .pwdatas                               (pwdatas_dummy),         // Templated
 .pusers                                (pusers_dummy));                 // Templated


endmodule
// Local Variables:
// verilog-library-directories:( "../*/verilog" "./") 
// verilog-auto-inst-param-value:t
// End:
