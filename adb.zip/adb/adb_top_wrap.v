// +FHDR----------------------------------------------------------------------------
// Project Name  : IC_Design
// Author        : xucw
// Email         : xucw@innosilicon.com.cn
// Create On     : 2024/02/28 18:44
// Last Modified : 2024/02/28 18:44
// File Name     : top.v
// Description   :
// 
// Copyright (c) 2024 Innosilicon.
// ALL RIGHTS RESERVED
// 
// ---------------------------------------------------------------------------------
// Modification History:
// Date         By              Version                 Change Description
// ---------------------------------------------------------------------------------
// 2024/02/28   xucw            1.0                     Original
// 
// -FHDR----------------------------------------------------------------------------

module adb_top_wrap(
/*autoarg*/
   // Outputs
   bas_trvvalids, bas_trvreadym, bas_trvlasts, bas_trvkeeps,
   bas_trvdatas, bas_tfwvalidm, bas_tfwreadys, bas_tfwlastm,
   bas_tfwkeepm, bas_tfwdatam, bas_pwrqdenys_o, bas_pwrqactives_o,
   bas_pwrqacceptns_o, bas_adb_slv_debug_monitor,
   bas_adb_mst_debug_monitor, axi5_err_rsp_wvalidm,
   axi5_err_rsp_wuserm, axi5_err_rsp_wstrbm, axi5_err_rsp_wreadys,
   axi5_err_rsp_wlastm, axi5_err_rsp_wdatam, axi5_err_rsp_rvalids,
   axi5_err_rsp_rusers, axi5_err_rsp_rresps, axi5_err_rsp_rreadym,
   axi5_err_rsp_rlasts, axi5_err_rsp_rids, axi5_err_rsp_rdatas,
   axi5_err_rsp_pwrqdenys_o, axi5_err_rsp_pwrqactives_o,
   axi5_err_rsp_pwrqacceptns_o, axi5_err_rsp_bvalids,
   axi5_err_rsp_busers, axi5_err_rsp_bresps, axi5_err_rsp_breadym,
   axi5_err_rsp_bids, axi5_err_rsp_awvalidm, axi5_err_rsp_awuserm,
   axi5_err_rsp_awsizem, axi5_err_rsp_awreadys, axi5_err_rsp_awqosm,
   axi5_err_rsp_awprotm, axi5_err_rsp_awlockm, axi5_err_rsp_awlenm,
   axi5_err_rsp_awidm, axi5_err_rsp_awcachem, axi5_err_rsp_awburstm,
   axi5_err_rsp_awatopm, axi5_err_rsp_awaddrm, axi5_err_rsp_arvalidm,
   axi5_err_rsp_aruserm, axi5_err_rsp_arsizem, axi5_err_rsp_arreadys,
   axi5_err_rsp_arqosm, axi5_err_rsp_arprotm, axi5_err_rsp_arlockm,
   axi5_err_rsp_arlenm, axi5_err_rsp_aridm, axi5_err_rsp_arcachem,
   axi5_err_rsp_arburstm, axi5_err_rsp_araddrm,
   axi5_err_rsp_adb_slv_debug_monitor,
   axi5_err_rsp_adb_mst_debug_monitor, axi4_err_rsp_wvalidm,
   axi4_err_rsp_wuserm, axi4_err_rsp_wstrbm, axi4_err_rsp_wreadys,
   axi4_err_rsp_wlastm, axi4_err_rsp_wdatam, axi4_err_rsp_rvalids,
   axi4_err_rsp_rusers, axi4_err_rsp_rresps, axi4_err_rsp_rreadym,
   axi4_err_rsp_rlasts, axi4_err_rsp_rids, axi4_err_rsp_rdatas,
   axi4_err_rsp_pwrqdenys_o, axi4_err_rsp_pwrqactives_o,
   axi4_err_rsp_pwrqacceptns_o, axi4_err_rsp_bvalids,
   axi4_err_rsp_busers, axi4_err_rsp_bresps, axi4_err_rsp_breadym,
   axi4_err_rsp_bids, axi4_err_rsp_awvalidm, axi4_err_rsp_awuserm,
   axi4_err_rsp_awsizem, axi4_err_rsp_awreadys, axi4_err_rsp_awqosm,
   axi4_err_rsp_awprotm, axi4_err_rsp_awlockm, axi4_err_rsp_awlenm,
   axi4_err_rsp_awidm, axi4_err_rsp_awcachem, axi4_err_rsp_awburstm,
   axi4_err_rsp_awaddrm, axi4_err_rsp_arvalidm, axi4_err_rsp_aruserm,
   axi4_err_rsp_arsizem, axi4_err_rsp_arreadys, axi4_err_rsp_arqosm,
   axi4_err_rsp_arprotm, axi4_err_rsp_arlockm, axi4_err_rsp_arlenm,
   axi4_err_rsp_aridm, axi4_err_rsp_arcachem, axi4_err_rsp_arburstm,
   axi4_err_rsp_araddrm, axi4_err_rsp_adb_slv_debug_monitor,
   axi4_err_rsp_adb_mst_debug_monitor, apb_err_rsp_pwrqdenys_o,
   apb_err_rsp_pwrqactives_o, apb_err_rsp_pwrqacceptns_o,
   apb_err_rsp_pwritem, apb_err_rsp_pwdatam, apb_err_rsp_puserm,
   apb_err_rsp_pslverrs, apb_err_rsp_pselm, apb_err_rsp_preadys,
   apb_err_rsp_prdatas, apb_err_rsp_penablem, apb_err_rsp_paddrm,
   apb_err_rsp_adb_slv_debug_monitor,
   apb_err_rsp_adb_mst_debug_monitor,
   // Inputs
   bas_trvvalidm, bas_trvreadys, bas_trvlastm, bas_trvkeepm,
   bas_trvdatam, bas_tfwvalids, bas_tfwreadym, bas_tfwlasts,
   bas_tfwkeeps, bas_tfwdatas, bas_pwrqreqns_i,
   bas_pwrq_permit_deny_sar_i, bas_dft_test_mode, bas_aresetns,
   bas_aresetnm, bas_aclks, bas_aclkm, axi5_err_rsp_wvalids,
   axi5_err_rsp_wusers, axi5_err_rsp_wstrbs, axi5_err_rsp_wreadym,
   axi5_err_rsp_wlasts, axi5_err_rsp_wdatas, axi5_err_rsp_rvalidm,
   axi5_err_rsp_ruserm, axi5_err_rsp_rrespm, axi5_err_rsp_rreadys,
   axi5_err_rsp_rlastm, axi5_err_rsp_ridm,
   axi5_err_rsp_reg_err_rsp_en, axi5_err_rsp_rdatam,
   axi5_err_rsp_pwrqreqns_i, axi5_err_rsp_pwrq_permit_deny_sar_i,
   axi5_err_rsp_ppu_st_pwron, axi5_err_rsp_dft_test_mode,
   axi5_err_rsp_bvalidm, axi5_err_rsp_buserm, axi5_err_rsp_brespm,
   axi5_err_rsp_breadys, axi5_err_rsp_bidm, axi5_err_rsp_awvalids,
   axi5_err_rsp_awusers, axi5_err_rsp_awsizes, axi5_err_rsp_awreadym,
   axi5_err_rsp_awqoss, axi5_err_rsp_awprots, axi5_err_rsp_awlocks,
   axi5_err_rsp_awlens, axi5_err_rsp_awids, axi5_err_rsp_awcaches,
   axi5_err_rsp_awbursts, axi5_err_rsp_awatops, axi5_err_rsp_awaddrs,
   axi5_err_rsp_arvalids, axi5_err_rsp_arusers, axi5_err_rsp_arsizes,
   axi5_err_rsp_arreadym, axi5_err_rsp_arqoss, axi5_err_rsp_arprots,
   axi5_err_rsp_arlocks, axi5_err_rsp_arlens, axi5_err_rsp_arids,
   axi5_err_rsp_aresetns, axi5_err_rsp_aresetnm,
   axi5_err_rsp_arcaches, axi5_err_rsp_arbursts, axi5_err_rsp_araddrs,
   axi5_err_rsp_aclks, axi5_err_rsp_aclkm, axi4_err_rsp_wvalids,
   axi4_err_rsp_wusers, axi4_err_rsp_wstrbs, axi4_err_rsp_wreadym,
   axi4_err_rsp_wlasts, axi4_err_rsp_wdatas, axi4_err_rsp_rvalidm,
   axi4_err_rsp_ruserm, axi4_err_rsp_rrespm, axi4_err_rsp_rreadys,
   axi4_err_rsp_rlastm, axi4_err_rsp_ridm,
   axi4_err_rsp_reg_err_rsp_en, axi4_err_rsp_rdatam,
   axi4_err_rsp_pwrqreqns_i, axi4_err_rsp_pwrq_permit_deny_sar_i,
   axi4_err_rsp_ppu_st_pwron, axi4_err_rsp_dft_test_mode,
   axi4_err_rsp_bvalidm, axi4_err_rsp_buserm, axi4_err_rsp_brespm,
   axi4_err_rsp_breadys, axi4_err_rsp_bidm, axi4_err_rsp_awvalids,
   axi4_err_rsp_awusers, axi4_err_rsp_awsizes, axi4_err_rsp_awreadym,
   axi4_err_rsp_awqoss, axi4_err_rsp_awprots, axi4_err_rsp_awlocks,
   axi4_err_rsp_awlens, axi4_err_rsp_awids, axi4_err_rsp_awcaches,
   axi4_err_rsp_awbursts, axi4_err_rsp_awaddrs, axi4_err_rsp_arvalids,
   axi4_err_rsp_arusers, axi4_err_rsp_arsizes, axi4_err_rsp_arreadym,
   axi4_err_rsp_arqoss, axi4_err_rsp_arprots, axi4_err_rsp_arlocks,
   axi4_err_rsp_arlens, axi4_err_rsp_arids, axi4_err_rsp_aresetns,
   axi4_err_rsp_aresetnm, axi4_err_rsp_arcaches,
   axi4_err_rsp_arbursts, axi4_err_rsp_araddrs, axi4_err_rsp_aclks,
   axi4_err_rsp_aclkm, apb_err_rsp_reg_err_rsp_en,
   apb_err_rsp_pwrqreqns_i, apb_err_rsp_pwrq_permit_deny_sar_i,
   apb_err_rsp_pwrites, apb_err_rsp_pwdatas, apb_err_rsp_pusers,
   apb_err_rsp_pslverrm, apb_err_rsp_psels, apb_err_rsp_presetns,
   apb_err_rsp_presetnm, apb_err_rsp_preadym, apb_err_rsp_prdatam,
   apb_err_rsp_ppu_st_pwron, apb_err_rsp_penables, apb_err_rsp_pclks,
   apb_err_rsp_pclkm, apb_err_rsp_paddrs, apb_err_rsp_dft_test_mode
   );
/*autoinput*/
// Beginning of automatic inputs (from unused autoinst inputs)
input                   apb_err_rsp_dft_test_mode;// To adb400_r3_apb_err_rsp_u of adb400_r3_apb_err_rsp.v
input [31:0]            apb_err_rsp_paddrs;     // To adb400_r3_apb_err_rsp_u of adb400_r3_apb_err_rsp.v
input                   apb_err_rsp_pclkm;      // To adb400_r3_apb_err_rsp_u of adb400_r3_apb_err_rsp.v
input                   apb_err_rsp_pclks;      // To adb400_r3_apb_err_rsp_u of adb400_r3_apb_err_rsp.v
input                   apb_err_rsp_penables;   // To adb400_r3_apb_err_rsp_u of adb400_r3_apb_err_rsp.v
input                   apb_err_rsp_ppu_st_pwron;// To adb400_r3_apb_err_rsp_u of adb400_r3_apb_err_rsp.v
input [31:0]            apb_err_rsp_prdatam;    // To adb400_r3_apb_err_rsp_u of adb400_r3_apb_err_rsp.v
input                   apb_err_rsp_preadym;    // To adb400_r3_apb_err_rsp_u of adb400_r3_apb_err_rsp.v
input                   apb_err_rsp_presetnm;   // To adb400_r3_apb_err_rsp_u of adb400_r3_apb_err_rsp.v
input                   apb_err_rsp_presetns;   // To adb400_r3_apb_err_rsp_u of adb400_r3_apb_err_rsp.v
input                   apb_err_rsp_psels;      // To adb400_r3_apb_err_rsp_u of adb400_r3_apb_err_rsp.v
input                   apb_err_rsp_pslverrm;   // To adb400_r3_apb_err_rsp_u of adb400_r3_apb_err_rsp.v
input [11:0]            apb_err_rsp_pusers;     // To adb400_r3_apb_err_rsp_u of adb400_r3_apb_err_rsp.v
input [31:0]            apb_err_rsp_pwdatas;    // To adb400_r3_apb_err_rsp_u of adb400_r3_apb_err_rsp.v
input                   apb_err_rsp_pwrites;    // To adb400_r3_apb_err_rsp_u of adb400_r3_apb_err_rsp.v
input                   apb_err_rsp_pwrq_permit_deny_sar_i;// To adb400_r3_apb_err_rsp_u of adb400_r3_apb_err_rsp.v
input                   apb_err_rsp_pwrqreqns_i;// To adb400_r3_apb_err_rsp_u of adb400_r3_apb_err_rsp.v
input                   apb_err_rsp_reg_err_rsp_en;// To adb400_r3_apb_err_rsp_u of adb400_r3_apb_err_rsp.v
input                   axi4_err_rsp_aclkm;     // To adb400_r3_axi4_err_rsp_u of adb400_r3_axi4_err_rsp.v
input                   axi4_err_rsp_aclks;     // To adb400_r3_axi4_err_rsp_u of adb400_r3_axi4_err_rsp.v
input [48:0]            axi4_err_rsp_araddrs;   // To adb400_r3_axi4_err_rsp_u of adb400_r3_axi4_err_rsp.v
input [1:0]             axi4_err_rsp_arbursts;  // To adb400_r3_axi4_err_rsp_u of adb400_r3_axi4_err_rsp.v
input [3:0]             axi4_err_rsp_arcaches;  // To adb400_r3_axi4_err_rsp_u of adb400_r3_axi4_err_rsp.v
input                   axi4_err_rsp_aresetnm;  // To adb400_r3_axi4_err_rsp_u of adb400_r3_axi4_err_rsp.v
input                   axi4_err_rsp_aresetns;  // To adb400_r3_axi4_err_rsp_u of adb400_r3_axi4_err_rsp.v
input [((8>0)?(7):0):0] axi4_err_rsp_arids;     // To adb400_r3_axi4_err_rsp_u of adb400_r3_axi4_err_rsp.v
input [3:0]             axi4_err_rsp_arlens;    // To adb400_r3_axi4_err_rsp_u of adb400_r3_axi4_err_rsp.v
input                   axi4_err_rsp_arlocks;   // To adb400_r3_axi4_err_rsp_u of adb400_r3_axi4_err_rsp.v
input [2:0]             axi4_err_rsp_arprots;   // To adb400_r3_axi4_err_rsp_u of adb400_r3_axi4_err_rsp.v
input [3:0]             axi4_err_rsp_arqoss;    // To adb400_r3_axi4_err_rsp_u of adb400_r3_axi4_err_rsp.v
input                   axi4_err_rsp_arreadym;  // To adb400_r3_axi4_err_rsp_u of adb400_r3_axi4_err_rsp.v
input [2:0]             axi4_err_rsp_arsizes;   // To adb400_r3_axi4_err_rsp_u of adb400_r3_axi4_err_rsp.v
input [((12>0)?(11):0):0] axi4_err_rsp_arusers; // To adb400_r3_axi4_err_rsp_u of adb400_r3_axi4_err_rsp.v
input                   axi4_err_rsp_arvalids;  // To adb400_r3_axi4_err_rsp_u of adb400_r3_axi4_err_rsp.v
input [48:0]            axi4_err_rsp_awaddrs;   // To adb400_r3_axi4_err_rsp_u of adb400_r3_axi4_err_rsp.v
input [1:0]             axi4_err_rsp_awbursts;  // To adb400_r3_axi4_err_rsp_u of adb400_r3_axi4_err_rsp.v
input [3:0]             axi4_err_rsp_awcaches;  // To adb400_r3_axi4_err_rsp_u of adb400_r3_axi4_err_rsp.v
input [((8>0)?(7):0):0] axi4_err_rsp_awids;     // To adb400_r3_axi4_err_rsp_u of adb400_r3_axi4_err_rsp.v
input [3:0]             axi4_err_rsp_awlens;    // To adb400_r3_axi4_err_rsp_u of adb400_r3_axi4_err_rsp.v
input                   axi4_err_rsp_awlocks;   // To adb400_r3_axi4_err_rsp_u of adb400_r3_axi4_err_rsp.v
input [2:0]             axi4_err_rsp_awprots;   // To adb400_r3_axi4_err_rsp_u of adb400_r3_axi4_err_rsp.v
input [3:0]             axi4_err_rsp_awqoss;    // To adb400_r3_axi4_err_rsp_u of adb400_r3_axi4_err_rsp.v
input                   axi4_err_rsp_awreadym;  // To adb400_r3_axi4_err_rsp_u of adb400_r3_axi4_err_rsp.v
input [2:0]             axi4_err_rsp_awsizes;   // To adb400_r3_axi4_err_rsp_u of adb400_r3_axi4_err_rsp.v
input [((12>0)?(11):0):0] axi4_err_rsp_awusers; // To adb400_r3_axi4_err_rsp_u of adb400_r3_axi4_err_rsp.v
input                   axi4_err_rsp_awvalids;  // To adb400_r3_axi4_err_rsp_u of adb400_r3_axi4_err_rsp.v
input [((8>0)?(7):0):0] axi4_err_rsp_bidm;      // To adb400_r3_axi4_err_rsp_u of adb400_r3_axi4_err_rsp.v
input                   axi4_err_rsp_breadys;   // To adb400_r3_axi4_err_rsp_u of adb400_r3_axi4_err_rsp.v
input [1:0]             axi4_err_rsp_brespm;    // To adb400_r3_axi4_err_rsp_u of adb400_r3_axi4_err_rsp.v
input [((12>0)?(11):0):0] axi4_err_rsp_buserm;  // To adb400_r3_axi4_err_rsp_u of adb400_r3_axi4_err_rsp.v
input                   axi4_err_rsp_bvalidm;   // To adb400_r3_axi4_err_rsp_u of adb400_r3_axi4_err_rsp.v
input                   axi4_err_rsp_dft_test_mode;// To adb400_r3_axi4_err_rsp_u of adb400_r3_axi4_err_rsp.v
input                   axi4_err_rsp_ppu_st_pwron;// To adb400_r3_axi4_err_rsp_u of adb400_r3_axi4_err_rsp.v
input                   axi4_err_rsp_pwrq_permit_deny_sar_i;// To adb400_r3_axi4_err_rsp_u of adb400_r3_axi4_err_rsp.v
input                   axi4_err_rsp_pwrqreqns_i;// To adb400_r3_axi4_err_rsp_u of adb400_r3_axi4_err_rsp.v
input [511:0]           axi4_err_rsp_rdatam;    // To adb400_r3_axi4_err_rsp_u of adb400_r3_axi4_err_rsp.v
input                   axi4_err_rsp_reg_err_rsp_en;// To adb400_r3_axi4_err_rsp_u of adb400_r3_axi4_err_rsp.v
input [((8>0)?(7):0):0] axi4_err_rsp_ridm;      // To adb400_r3_axi4_err_rsp_u of adb400_r3_axi4_err_rsp.v
input                   axi4_err_rsp_rlastm;    // To adb400_r3_axi4_err_rsp_u of adb400_r3_axi4_err_rsp.v
input                   axi4_err_rsp_rreadys;   // To adb400_r3_axi4_err_rsp_u of adb400_r3_axi4_err_rsp.v
input [1:0]             axi4_err_rsp_rrespm;    // To adb400_r3_axi4_err_rsp_u of adb400_r3_axi4_err_rsp.v
input [((12>0)?(11):0):0] axi4_err_rsp_ruserm;  // To adb400_r3_axi4_err_rsp_u of adb400_r3_axi4_err_rsp.v
input                   axi4_err_rsp_rvalidm;   // To adb400_r3_axi4_err_rsp_u of adb400_r3_axi4_err_rsp.v
input [511:0]           axi4_err_rsp_wdatas;    // To adb400_r3_axi4_err_rsp_u of adb400_r3_axi4_err_rsp.v
input                   axi4_err_rsp_wlasts;    // To adb400_r3_axi4_err_rsp_u of adb400_r3_axi4_err_rsp.v
input                   axi4_err_rsp_wreadym;   // To adb400_r3_axi4_err_rsp_u of adb400_r3_axi4_err_rsp.v
input [63:0]            axi4_err_rsp_wstrbs;    // To adb400_r3_axi4_err_rsp_u of adb400_r3_axi4_err_rsp.v
input [((12>0)?(11):0):0] axi4_err_rsp_wusers;  // To adb400_r3_axi4_err_rsp_u of adb400_r3_axi4_err_rsp.v
input                   axi4_err_rsp_wvalids;   // To adb400_r3_axi4_err_rsp_u of adb400_r3_axi4_err_rsp.v
input                   axi5_err_rsp_aclkm;     // To adb400_r3_axi5_err_rsp_u of adb400_r3_axi5_err_rsp.v
input                   axi5_err_rsp_aclks;     // To adb400_r3_axi5_err_rsp_u of adb400_r3_axi5_err_rsp.v
input [48:0]            axi5_err_rsp_araddrs;   // To adb400_r3_axi5_err_rsp_u of adb400_r3_axi5_err_rsp.v
input [1:0]             axi5_err_rsp_arbursts;  // To adb400_r3_axi5_err_rsp_u of adb400_r3_axi5_err_rsp.v
input [3:0]             axi5_err_rsp_arcaches;  // To adb400_r3_axi5_err_rsp_u of adb400_r3_axi5_err_rsp.v
input                   axi5_err_rsp_aresetnm;  // To adb400_r3_axi5_err_rsp_u of adb400_r3_axi5_err_rsp.v
input                   axi5_err_rsp_aresetns;  // To adb400_r3_axi5_err_rsp_u of adb400_r3_axi5_err_rsp.v
input [((8>0)?(7):0):0] axi5_err_rsp_arids;     // To adb400_r3_axi5_err_rsp_u of adb400_r3_axi5_err_rsp.v
input [3:0]             axi5_err_rsp_arlens;    // To adb400_r3_axi5_err_rsp_u of adb400_r3_axi5_err_rsp.v
input                   axi5_err_rsp_arlocks;   // To adb400_r3_axi5_err_rsp_u of adb400_r3_axi5_err_rsp.v
input [2:0]             axi5_err_rsp_arprots;   // To adb400_r3_axi5_err_rsp_u of adb400_r3_axi5_err_rsp.v
input [3:0]             axi5_err_rsp_arqoss;    // To adb400_r3_axi5_err_rsp_u of adb400_r3_axi5_err_rsp.v
input                   axi5_err_rsp_arreadym;  // To adb400_r3_axi5_err_rsp_u of adb400_r3_axi5_err_rsp.v
input [2:0]             axi5_err_rsp_arsizes;   // To adb400_r3_axi5_err_rsp_u of adb400_r3_axi5_err_rsp.v
input [((12>0)?(11):0):0] axi5_err_rsp_arusers; // To adb400_r3_axi5_err_rsp_u of adb400_r3_axi5_err_rsp.v
input                   axi5_err_rsp_arvalids;  // To adb400_r3_axi5_err_rsp_u of adb400_r3_axi5_err_rsp.v
input [48:0]            axi5_err_rsp_awaddrs;   // To adb400_r3_axi5_err_rsp_u of adb400_r3_axi5_err_rsp.v
input [5:0]             axi5_err_rsp_awatops;   // To adb400_r3_axi5_err_rsp_u of adb400_r3_axi5_err_rsp.v
input [1:0]             axi5_err_rsp_awbursts;  // To adb400_r3_axi5_err_rsp_u of adb400_r3_axi5_err_rsp.v
input [3:0]             axi5_err_rsp_awcaches;  // To adb400_r3_axi5_err_rsp_u of adb400_r3_axi5_err_rsp.v
input [((8>0)?(7):0):0] axi5_err_rsp_awids;     // To adb400_r3_axi5_err_rsp_u of adb400_r3_axi5_err_rsp.v
input [3:0]             axi5_err_rsp_awlens;    // To adb400_r3_axi5_err_rsp_u of adb400_r3_axi5_err_rsp.v
input                   axi5_err_rsp_awlocks;   // To adb400_r3_axi5_err_rsp_u of adb400_r3_axi5_err_rsp.v
input [2:0]             axi5_err_rsp_awprots;   // To adb400_r3_axi5_err_rsp_u of adb400_r3_axi5_err_rsp.v
input [3:0]             axi5_err_rsp_awqoss;    // To adb400_r3_axi5_err_rsp_u of adb400_r3_axi5_err_rsp.v
input                   axi5_err_rsp_awreadym;  // To adb400_r3_axi5_err_rsp_u of adb400_r3_axi5_err_rsp.v
input [2:0]             axi5_err_rsp_awsizes;   // To adb400_r3_axi5_err_rsp_u of adb400_r3_axi5_err_rsp.v
input [((12>0)?(11):0):0] axi5_err_rsp_awusers; // To adb400_r3_axi5_err_rsp_u of adb400_r3_axi5_err_rsp.v
input                   axi5_err_rsp_awvalids;  // To adb400_r3_axi5_err_rsp_u of adb400_r3_axi5_err_rsp.v
input [((8>0)?(7):0):0] axi5_err_rsp_bidm;      // To adb400_r3_axi5_err_rsp_u of adb400_r3_axi5_err_rsp.v
input                   axi5_err_rsp_breadys;   // To adb400_r3_axi5_err_rsp_u of adb400_r3_axi5_err_rsp.v
input [1:0]             axi5_err_rsp_brespm;    // To adb400_r3_axi5_err_rsp_u of adb400_r3_axi5_err_rsp.v
input [((12>0)?(11):0):0] axi5_err_rsp_buserm;  // To adb400_r3_axi5_err_rsp_u of adb400_r3_axi5_err_rsp.v
input                   axi5_err_rsp_bvalidm;   // To adb400_r3_axi5_err_rsp_u of adb400_r3_axi5_err_rsp.v
input                   axi5_err_rsp_dft_test_mode;// To adb400_r3_axi5_err_rsp_u of adb400_r3_axi5_err_rsp.v
input                   axi5_err_rsp_ppu_st_pwron;// To adb400_r3_axi5_err_rsp_u of adb400_r3_axi5_err_rsp.v
input                   axi5_err_rsp_pwrq_permit_deny_sar_i;// To adb400_r3_axi5_err_rsp_u of adb400_r3_axi5_err_rsp.v
input                   axi5_err_rsp_pwrqreqns_i;// To adb400_r3_axi5_err_rsp_u of adb400_r3_axi5_err_rsp.v
input [511:0]           axi5_err_rsp_rdatam;    // To adb400_r3_axi5_err_rsp_u of adb400_r3_axi5_err_rsp.v
input                   axi5_err_rsp_reg_err_rsp_en;// To adb400_r3_axi5_err_rsp_u of adb400_r3_axi5_err_rsp.v
input [((8>0)?(7):0):0] axi5_err_rsp_ridm;      // To adb400_r3_axi5_err_rsp_u of adb400_r3_axi5_err_rsp.v
input                   axi5_err_rsp_rlastm;    // To adb400_r3_axi5_err_rsp_u of adb400_r3_axi5_err_rsp.v
input                   axi5_err_rsp_rreadys;   // To adb400_r3_axi5_err_rsp_u of adb400_r3_axi5_err_rsp.v
input [1:0]             axi5_err_rsp_rrespm;    // To adb400_r3_axi5_err_rsp_u of adb400_r3_axi5_err_rsp.v
input [((12>0)?(11):0):0] axi5_err_rsp_ruserm;  // To adb400_r3_axi5_err_rsp_u of adb400_r3_axi5_err_rsp.v
input                   axi5_err_rsp_rvalidm;   // To adb400_r3_axi5_err_rsp_u of adb400_r3_axi5_err_rsp.v
input [511:0]           axi5_err_rsp_wdatas;    // To adb400_r3_axi5_err_rsp_u of adb400_r3_axi5_err_rsp.v
input                   axi5_err_rsp_wlasts;    // To adb400_r3_axi5_err_rsp_u of adb400_r3_axi5_err_rsp.v
input                   axi5_err_rsp_wreadym;   // To adb400_r3_axi5_err_rsp_u of adb400_r3_axi5_err_rsp.v
input [63:0]            axi5_err_rsp_wstrbs;    // To adb400_r3_axi5_err_rsp_u of adb400_r3_axi5_err_rsp.v
input [((12>0)?(11):0):0] axi5_err_rsp_wusers;  // To adb400_r3_axi5_err_rsp_u of adb400_r3_axi5_err_rsp.v
input                   axi5_err_rsp_wvalids;   // To adb400_r3_axi5_err_rsp_u of adb400_r3_axi5_err_rsp.v
input                   bas_aclkm;              // To adb400_r3_bas_u of adb400_r3_bas.v
input                   bas_aclks;              // To adb400_r3_bas_u of adb400_r3_bas.v
input                   bas_aresetnm;           // To adb400_r3_bas_u of adb400_r3_bas.v
input                   bas_aresetns;           // To adb400_r3_bas_u of adb400_r3_bas.v
input                   bas_dft_test_mode;      // To adb400_r3_bas_u of adb400_r3_bas.v
input                   bas_pwrq_permit_deny_sar_i;// To adb400_r3_bas_u of adb400_r3_bas.v
input                   bas_pwrqreqns_i;        // To adb400_r3_bas_u of adb400_r3_bas.v
input [((160>0)?(159):0):0] bas_tfwdatas;       // To adb400_r3_bas_u of adb400_r3_bas.v
input [((20>0)?(19):0):0] bas_tfwkeeps;         // To adb400_r3_bas_u of adb400_r3_bas.v
input                   bas_tfwlasts;           // To adb400_r3_bas_u of adb400_r3_bas.v
input                   bas_tfwreadym;          // To adb400_r3_bas_u of adb400_r3_bas.v
input                   bas_tfwvalids;          // To adb400_r3_bas_u of adb400_r3_bas.v
input [((160>0)?(159):0):0] bas_trvdatam;       // To adb400_r3_bas_u of adb400_r3_bas.v
input [((20>0)?(19):0):0] bas_trvkeepm;         // To adb400_r3_bas_u of adb400_r3_bas.v
input                   bas_trvlastm;           // To adb400_r3_bas_u of adb400_r3_bas.v
input                   bas_trvreadys;          // To adb400_r3_bas_u of adb400_r3_bas.v
input                   bas_trvvalidm;          // To adb400_r3_bas_u of adb400_r3_bas.v
// End of automatics
/*autooutput*/
// Beginning of automatic outputs (from unused autoinst outputs)
output [31:0]           apb_err_rsp_adb_mst_debug_monitor;// From adb400_r3_apb_err_rsp_u of adb400_r3_apb_err_rsp.v
output [31:0]           apb_err_rsp_adb_slv_debug_monitor;// From adb400_r3_apb_err_rsp_u of adb400_r3_apb_err_rsp.v
output [31:0]           apb_err_rsp_paddrm;     // From adb400_r3_apb_err_rsp_u of adb400_r3_apb_err_rsp.v
output                  apb_err_rsp_penablem;   // From adb400_r3_apb_err_rsp_u of adb400_r3_apb_err_rsp.v
output [31:0]           apb_err_rsp_prdatas;    // From adb400_r3_apb_err_rsp_u of adb400_r3_apb_err_rsp.v
output                  apb_err_rsp_preadys;    // From adb400_r3_apb_err_rsp_u of adb400_r3_apb_err_rsp.v
output                  apb_err_rsp_pselm;      // From adb400_r3_apb_err_rsp_u of adb400_r3_apb_err_rsp.v
output                  apb_err_rsp_pslverrs;   // From adb400_r3_apb_err_rsp_u of adb400_r3_apb_err_rsp.v
output [11:0]           apb_err_rsp_puserm;     // From adb400_r3_apb_err_rsp_u of adb400_r3_apb_err_rsp.v
output [31:0]           apb_err_rsp_pwdatam;    // From adb400_r3_apb_err_rsp_u of adb400_r3_apb_err_rsp.v
output                  apb_err_rsp_pwritem;    // From adb400_r3_apb_err_rsp_u of adb400_r3_apb_err_rsp.v
output                  apb_err_rsp_pwrqacceptns_o;// From adb400_r3_apb_err_rsp_u of adb400_r3_apb_err_rsp.v
output                  apb_err_rsp_pwrqactives_o;// From adb400_r3_apb_err_rsp_u of adb400_r3_apb_err_rsp.v
output                  apb_err_rsp_pwrqdenys_o;// From adb400_r3_apb_err_rsp_u of adb400_r3_apb_err_rsp.v
output [31:0]           axi4_err_rsp_adb_mst_debug_monitor;// From adb400_r3_axi4_err_rsp_u of adb400_r3_axi4_err_rsp.v
output [31:0]           axi4_err_rsp_adb_slv_debug_monitor;// From adb400_r3_axi4_err_rsp_u of adb400_r3_axi4_err_rsp.v
output [48:0]           axi4_err_rsp_araddrm;   // From adb400_r3_axi4_err_rsp_u of adb400_r3_axi4_err_rsp.v
output [1:0]            axi4_err_rsp_arburstm;  // From adb400_r3_axi4_err_rsp_u of adb400_r3_axi4_err_rsp.v
output [3:0]            axi4_err_rsp_arcachem;  // From adb400_r3_axi4_err_rsp_u of adb400_r3_axi4_err_rsp.v
output [((8>0)?(7):0):0] axi4_err_rsp_aridm;    // From adb400_r3_axi4_err_rsp_u of adb400_r3_axi4_err_rsp.v
output [3:0]            axi4_err_rsp_arlenm;    // From adb400_r3_axi4_err_rsp_u of adb400_r3_axi4_err_rsp.v
output                  axi4_err_rsp_arlockm;   // From adb400_r3_axi4_err_rsp_u of adb400_r3_axi4_err_rsp.v
output [2:0]            axi4_err_rsp_arprotm;   // From adb400_r3_axi4_err_rsp_u of adb400_r3_axi4_err_rsp.v
output [3:0]            axi4_err_rsp_arqosm;    // From adb400_r3_axi4_err_rsp_u of adb400_r3_axi4_err_rsp.v
output                  axi4_err_rsp_arreadys;  // From adb400_r3_axi4_err_rsp_u of adb400_r3_axi4_err_rsp.v
output [2:0]            axi4_err_rsp_arsizem;   // From adb400_r3_axi4_err_rsp_u of adb400_r3_axi4_err_rsp.v
output [((12>0)?(11):0):0] axi4_err_rsp_aruserm;// From adb400_r3_axi4_err_rsp_u of adb400_r3_axi4_err_rsp.v
output                  axi4_err_rsp_arvalidm;  // From adb400_r3_axi4_err_rsp_u of adb400_r3_axi4_err_rsp.v
output [48:0]           axi4_err_rsp_awaddrm;   // From adb400_r3_axi4_err_rsp_u of adb400_r3_axi4_err_rsp.v
output [1:0]            axi4_err_rsp_awburstm;  // From adb400_r3_axi4_err_rsp_u of adb400_r3_axi4_err_rsp.v
output [3:0]            axi4_err_rsp_awcachem;  // From adb400_r3_axi4_err_rsp_u of adb400_r3_axi4_err_rsp.v
output [((8>0)?(7):0):0] axi4_err_rsp_awidm;    // From adb400_r3_axi4_err_rsp_u of adb400_r3_axi4_err_rsp.v
output [3:0]            axi4_err_rsp_awlenm;    // From adb400_r3_axi4_err_rsp_u of adb400_r3_axi4_err_rsp.v
output                  axi4_err_rsp_awlockm;   // From adb400_r3_axi4_err_rsp_u of adb400_r3_axi4_err_rsp.v
output [2:0]            axi4_err_rsp_awprotm;   // From adb400_r3_axi4_err_rsp_u of adb400_r3_axi4_err_rsp.v
output [3:0]            axi4_err_rsp_awqosm;    // From adb400_r3_axi4_err_rsp_u of adb400_r3_axi4_err_rsp.v
output                  axi4_err_rsp_awreadys;  // From adb400_r3_axi4_err_rsp_u of adb400_r3_axi4_err_rsp.v
output [2:0]            axi4_err_rsp_awsizem;   // From adb400_r3_axi4_err_rsp_u of adb400_r3_axi4_err_rsp.v
output [((12>0)?(11):0):0] axi4_err_rsp_awuserm;// From adb400_r3_axi4_err_rsp_u of adb400_r3_axi4_err_rsp.v
output                  axi4_err_rsp_awvalidm;  // From adb400_r3_axi4_err_rsp_u of adb400_r3_axi4_err_rsp.v
output [((8>0)?(7):0):0] axi4_err_rsp_bids;     // From adb400_r3_axi4_err_rsp_u of adb400_r3_axi4_err_rsp.v
output                  axi4_err_rsp_breadym;   // From adb400_r3_axi4_err_rsp_u of adb400_r3_axi4_err_rsp.v
output [1:0]            axi4_err_rsp_bresps;    // From adb400_r3_axi4_err_rsp_u of adb400_r3_axi4_err_rsp.v
output [((12>0)?(11):0):0] axi4_err_rsp_busers; // From adb400_r3_axi4_err_rsp_u of adb400_r3_axi4_err_rsp.v
output                  axi4_err_rsp_bvalids;   // From adb400_r3_axi4_err_rsp_u of adb400_r3_axi4_err_rsp.v
output                  axi4_err_rsp_pwrqacceptns_o;// From adb400_r3_axi4_err_rsp_u of adb400_r3_axi4_err_rsp.v
output                  axi4_err_rsp_pwrqactives_o;// From adb400_r3_axi4_err_rsp_u of adb400_r3_axi4_err_rsp.v
output                  axi4_err_rsp_pwrqdenys_o;// From adb400_r3_axi4_err_rsp_u of adb400_r3_axi4_err_rsp.v
output [511:0]          axi4_err_rsp_rdatas;    // From adb400_r3_axi4_err_rsp_u of adb400_r3_axi4_err_rsp.v
output [((8>0)?(7):0):0] axi4_err_rsp_rids;     // From adb400_r3_axi4_err_rsp_u of adb400_r3_axi4_err_rsp.v
output                  axi4_err_rsp_rlasts;    // From adb400_r3_axi4_err_rsp_u of adb400_r3_axi4_err_rsp.v
output                  axi4_err_rsp_rreadym;   // From adb400_r3_axi4_err_rsp_u of adb400_r3_axi4_err_rsp.v
output [1:0]            axi4_err_rsp_rresps;    // From adb400_r3_axi4_err_rsp_u of adb400_r3_axi4_err_rsp.v
output [((12>0)?(11):0):0] axi4_err_rsp_rusers; // From adb400_r3_axi4_err_rsp_u of adb400_r3_axi4_err_rsp.v
output                  axi4_err_rsp_rvalids;   // From adb400_r3_axi4_err_rsp_u of adb400_r3_axi4_err_rsp.v
output [511:0]          axi4_err_rsp_wdatam;    // From adb400_r3_axi4_err_rsp_u of adb400_r3_axi4_err_rsp.v
output                  axi4_err_rsp_wlastm;    // From adb400_r3_axi4_err_rsp_u of adb400_r3_axi4_err_rsp.v
output                  axi4_err_rsp_wreadys;   // From adb400_r3_axi4_err_rsp_u of adb400_r3_axi4_err_rsp.v
output [63:0]           axi4_err_rsp_wstrbm;    // From adb400_r3_axi4_err_rsp_u of adb400_r3_axi4_err_rsp.v
output [((12>0)?(11):0):0] axi4_err_rsp_wuserm; // From adb400_r3_axi4_err_rsp_u of adb400_r3_axi4_err_rsp.v
output                  axi4_err_rsp_wvalidm;   // From adb400_r3_axi4_err_rsp_u of adb400_r3_axi4_err_rsp.v
output [31:0]           axi5_err_rsp_adb_mst_debug_monitor;// From adb400_r3_axi5_err_rsp_u of adb400_r3_axi5_err_rsp.v
output [31:0]           axi5_err_rsp_adb_slv_debug_monitor;// From adb400_r3_axi5_err_rsp_u of adb400_r3_axi5_err_rsp.v
output [48:0]           axi5_err_rsp_araddrm;   // From adb400_r3_axi5_err_rsp_u of adb400_r3_axi5_err_rsp.v
output [1:0]            axi5_err_rsp_arburstm;  // From adb400_r3_axi5_err_rsp_u of adb400_r3_axi5_err_rsp.v
output [3:0]            axi5_err_rsp_arcachem;  // From adb400_r3_axi5_err_rsp_u of adb400_r3_axi5_err_rsp.v
output [((8>0)?(7):0):0] axi5_err_rsp_aridm;    // From adb400_r3_axi5_err_rsp_u of adb400_r3_axi5_err_rsp.v
output [3:0]            axi5_err_rsp_arlenm;    // From adb400_r3_axi5_err_rsp_u of adb400_r3_axi5_err_rsp.v
output                  axi5_err_rsp_arlockm;   // From adb400_r3_axi5_err_rsp_u of adb400_r3_axi5_err_rsp.v
output [2:0]            axi5_err_rsp_arprotm;   // From adb400_r3_axi5_err_rsp_u of adb400_r3_axi5_err_rsp.v
output [3:0]            axi5_err_rsp_arqosm;    // From adb400_r3_axi5_err_rsp_u of adb400_r3_axi5_err_rsp.v
output                  axi5_err_rsp_arreadys;  // From adb400_r3_axi5_err_rsp_u of adb400_r3_axi5_err_rsp.v
output [2:0]            axi5_err_rsp_arsizem;   // From adb400_r3_axi5_err_rsp_u of adb400_r3_axi5_err_rsp.v
output [((12>0)?(11):0):0] axi5_err_rsp_aruserm;// From adb400_r3_axi5_err_rsp_u of adb400_r3_axi5_err_rsp.v
output                  axi5_err_rsp_arvalidm;  // From adb400_r3_axi5_err_rsp_u of adb400_r3_axi5_err_rsp.v
output [48:0]           axi5_err_rsp_awaddrm;   // From adb400_r3_axi5_err_rsp_u of adb400_r3_axi5_err_rsp.v
output [5:0]            axi5_err_rsp_awatopm;   // From adb400_r3_axi5_err_rsp_u of adb400_r3_axi5_err_rsp.v
output [1:0]            axi5_err_rsp_awburstm;  // From adb400_r3_axi5_err_rsp_u of adb400_r3_axi5_err_rsp.v
output [3:0]            axi5_err_rsp_awcachem;  // From adb400_r3_axi5_err_rsp_u of adb400_r3_axi5_err_rsp.v
output [((8>0)?(7):0):0] axi5_err_rsp_awidm;    // From adb400_r3_axi5_err_rsp_u of adb400_r3_axi5_err_rsp.v
output [3:0]            axi5_err_rsp_awlenm;    // From adb400_r3_axi5_err_rsp_u of adb400_r3_axi5_err_rsp.v
output                  axi5_err_rsp_awlockm;   // From adb400_r3_axi5_err_rsp_u of adb400_r3_axi5_err_rsp.v
output [2:0]            axi5_err_rsp_awprotm;   // From adb400_r3_axi5_err_rsp_u of adb400_r3_axi5_err_rsp.v
output [3:0]            axi5_err_rsp_awqosm;    // From adb400_r3_axi5_err_rsp_u of adb400_r3_axi5_err_rsp.v
output                  axi5_err_rsp_awreadys;  // From adb400_r3_axi5_err_rsp_u of adb400_r3_axi5_err_rsp.v
output [2:0]            axi5_err_rsp_awsizem;   // From adb400_r3_axi5_err_rsp_u of adb400_r3_axi5_err_rsp.v
output [((12>0)?(11):0):0] axi5_err_rsp_awuserm;// From adb400_r3_axi5_err_rsp_u of adb400_r3_axi5_err_rsp.v
output                  axi5_err_rsp_awvalidm;  // From adb400_r3_axi5_err_rsp_u of adb400_r3_axi5_err_rsp.v
output [((8>0)?(7):0):0] axi5_err_rsp_bids;     // From adb400_r3_axi5_err_rsp_u of adb400_r3_axi5_err_rsp.v
output                  axi5_err_rsp_breadym;   // From adb400_r3_axi5_err_rsp_u of adb400_r3_axi5_err_rsp.v
output [1:0]            axi5_err_rsp_bresps;    // From adb400_r3_axi5_err_rsp_u of adb400_r3_axi5_err_rsp.v
output [((12>0)?(11):0):0] axi5_err_rsp_busers; // From adb400_r3_axi5_err_rsp_u of adb400_r3_axi5_err_rsp.v
output                  axi5_err_rsp_bvalids;   // From adb400_r3_axi5_err_rsp_u of adb400_r3_axi5_err_rsp.v
output                  axi5_err_rsp_pwrqacceptns_o;// From adb400_r3_axi5_err_rsp_u of adb400_r3_axi5_err_rsp.v
output                  axi5_err_rsp_pwrqactives_o;// From adb400_r3_axi5_err_rsp_u of adb400_r3_axi5_err_rsp.v
output                  axi5_err_rsp_pwrqdenys_o;// From adb400_r3_axi5_err_rsp_u of adb400_r3_axi5_err_rsp.v
output [511:0]          axi5_err_rsp_rdatas;    // From adb400_r3_axi5_err_rsp_u of adb400_r3_axi5_err_rsp.v
output [((8>0)?(7):0):0] axi5_err_rsp_rids;     // From adb400_r3_axi5_err_rsp_u of adb400_r3_axi5_err_rsp.v
output                  axi5_err_rsp_rlasts;    // From adb400_r3_axi5_err_rsp_u of adb400_r3_axi5_err_rsp.v
output                  axi5_err_rsp_rreadym;   // From adb400_r3_axi5_err_rsp_u of adb400_r3_axi5_err_rsp.v
output [1:0]            axi5_err_rsp_rresps;    // From adb400_r3_axi5_err_rsp_u of adb400_r3_axi5_err_rsp.v
output [((12>0)?(11):0):0] axi5_err_rsp_rusers; // From adb400_r3_axi5_err_rsp_u of adb400_r3_axi5_err_rsp.v
output                  axi5_err_rsp_rvalids;   // From adb400_r3_axi5_err_rsp_u of adb400_r3_axi5_err_rsp.v
output [511:0]          axi5_err_rsp_wdatam;    // From adb400_r3_axi5_err_rsp_u of adb400_r3_axi5_err_rsp.v
output                  axi5_err_rsp_wlastm;    // From adb400_r3_axi5_err_rsp_u of adb400_r3_axi5_err_rsp.v
output                  axi5_err_rsp_wreadys;   // From adb400_r3_axi5_err_rsp_u of adb400_r3_axi5_err_rsp.v
output [63:0]           axi5_err_rsp_wstrbm;    // From adb400_r3_axi5_err_rsp_u of adb400_r3_axi5_err_rsp.v
output [((12>0)?(11):0):0] axi5_err_rsp_wuserm; // From adb400_r3_axi5_err_rsp_u of adb400_r3_axi5_err_rsp.v
output                  axi5_err_rsp_wvalidm;   // From adb400_r3_axi5_err_rsp_u of adb400_r3_axi5_err_rsp.v
output [31:0]           bas_adb_mst_debug_monitor;// From adb400_r3_bas_u of adb400_r3_bas.v
output [31:0]           bas_adb_slv_debug_monitor;// From adb400_r3_bas_u of adb400_r3_bas.v
output                  bas_pwrqacceptns_o;     // From adb400_r3_bas_u of adb400_r3_bas.v
output                  bas_pwrqactives_o;      // From adb400_r3_bas_u of adb400_r3_bas.v
output                  bas_pwrqdenys_o;        // From adb400_r3_bas_u of adb400_r3_bas.v
output [((160>0)?(159):0):0] bas_tfwdatam;      // From adb400_r3_bas_u of adb400_r3_bas.v
output [((20>0)?(19):0):0] bas_tfwkeepm;        // From adb400_r3_bas_u of adb400_r3_bas.v
output                  bas_tfwlastm;           // From adb400_r3_bas_u of adb400_r3_bas.v
output                  bas_tfwreadys;          // From adb400_r3_bas_u of adb400_r3_bas.v
output                  bas_tfwvalidm;          // From adb400_r3_bas_u of adb400_r3_bas.v
output [((160>0)?(159):0):0] bas_trvdatas;      // From adb400_r3_bas_u of adb400_r3_bas.v
output [((20>0)?(19):0):0] bas_trvkeeps;        // From adb400_r3_bas_u of adb400_r3_bas.v
output                  bas_trvlasts;           // From adb400_r3_bas_u of adb400_r3_bas.v
output                  bas_trvreadym;          // From adb400_r3_bas_u of adb400_r3_bas.v
output                  bas_trvvalids;          // From adb400_r3_bas_u of adb400_r3_bas.v
// End of automatics



/*adb400_r3_bas auto_template "adb400_r3_\(.*\)_u"(
.\(.*\) (@_\1[]),
);
*/
               

adb400_r3_bas
#(/*autoinst param*/
                    // Parameters
                    .DATA_WIDTH      (160),
                    .FW_FIFO_DEPTH   (6),
                    .RV_FIFO_DEPTH   (6))
adb400_r3_bas_u(/*autoinst*/
                // Outputs
                .pwrqacceptns_o         (bas_pwrqacceptns_o),    // Templated
                .pwrqdenys_o            (bas_pwrqdenys_o),       // Templated
                .pwrqactives_o          (bas_pwrqactives_o),     // Templated
                .tfwreadys              (bas_tfwreadys),         // Templated
                .trvvalids              (bas_trvvalids),         // Templated
                .trvdatas               (bas_trvdatas[((160>0)?(159):0):0]), // Templated
                .trvkeeps               (bas_trvkeeps[((20>0)?(19):0):0]), // Templated
                .trvlasts               (bas_trvlasts),          // Templated
                .adb_slv_debug_monitor  (bas_adb_slv_debug_monitor[31:0]), // Templated
                .adb_mst_debug_monitor  (bas_adb_mst_debug_monitor[31:0]), // Templated
                .tfwvalidm              (bas_tfwvalidm),         // Templated
                .tfwdatam               (bas_tfwdatam[((160>0)?(159):0):0]), // Templated
                .tfwkeepm               (bas_tfwkeepm[((20>0)?(19):0):0]), // Templated
                .tfwlastm               (bas_tfwlastm),          // Templated
                .trvreadym              (bas_trvreadym),         // Templated
                // Inputs
                .pwrq_permit_deny_sar_i (bas_pwrq_permit_deny_sar_i), // Templated
                .pwrqreqns_i            (bas_pwrqreqns_i),       // Templated
                .aclks                  (bas_aclks),             // Templated
                .aresetns               (bas_aresetns),          // Templated
                .dft_test_mode          (bas_dft_test_mode),     // Templated
                .tfwvalids              (bas_tfwvalids),         // Templated
                .tfwdatas               (bas_tfwdatas[((160>0)?(159):0):0]), // Templated
                .tfwkeeps               (bas_tfwkeeps[((20>0)?(19):0):0]), // Templated
                .tfwlasts               (bas_tfwlasts),          // Templated
                .trvreadys              (bas_trvreadys),         // Templated
                .aclkm                  (bas_aclkm),             // Templated
                .aresetnm               (bas_aresetnm),          // Templated
                .tfwreadym              (bas_tfwreadym),         // Templated
                .trvvalidm              (bas_trvvalidm),         // Templated
                .trvdatam               (bas_trvdatam[((160>0)?(159):0):0]), // Templated
                .trvkeepm               (bas_trvkeepm[((20>0)?(19):0):0]), // Templated
                .trvlastm               (bas_trvlastm));                 // Templated


               

/*adb400_r3_axi4_err_rsp auto_template "adb400_r3_\(.*\)_u"(
.\(.*\) (@_\1[]),
);
*/
        

adb400_r3_axi4_err_rsp
#(/*autoinst param*/
                         // Parameters
                         .ADDR_WIDTH            (49),
                         .DATA_WIDTH            (512),
                         .ID_WIDTH            (8),
                         .USER_WIDTH          (12),
                         .LEN_WIDTH             (4),//TODO
                         .AW_FIFO_DEPTH         (6),
                         .W_FIFO_DEPTH          (6),
                         .B_FIFO_DEPTH          (6),
                         .AR_FIFO_DEPTH         (6),
                         .R_FIFO_DEPTH          (6),
                         .RD_OSTD_NUM           (1024),
                         .WR_OSTD_NUM           (1024)                        
                       
                       )

adb400_r3_axi4_err_rsp_u(/*autoinst*/
                         // Outputs
                         .pwrqacceptns_o        (axi4_err_rsp_pwrqacceptns_o), // Templated
                         .pwrqdenys_o           (axi4_err_rsp_pwrqdenys_o), // Templated
                         .pwrqactives_o         (axi4_err_rsp_pwrqactives_o), // Templated
                         .awreadys              (axi4_err_rsp_awreadys), // Templated
                         .wreadys               (axi4_err_rsp_wreadys), // Templated
                         .bvalids               (axi4_err_rsp_bvalids), // Templated
                         .bids                  (axi4_err_rsp_bids[((8>0)?(7):0):0]), // Templated
                         .bresps                (axi4_err_rsp_bresps[1:0]), // Templated
                         .busers                (axi4_err_rsp_busers[((12>0)?(11):0):0]), // Templated
                         .arreadys              (axi4_err_rsp_arreadys), // Templated
                         .rvalids               (axi4_err_rsp_rvalids), // Templated
                         .rids                  (axi4_err_rsp_rids[((8>0)?(7):0):0]), // Templated
                         .rdatas                (axi4_err_rsp_rdatas[511:0]), // Templated
                         .rresps                (axi4_err_rsp_rresps[1:0]), // Templated
                         .rlasts                (axi4_err_rsp_rlasts), // Templated
                         .rusers                (axi4_err_rsp_rusers[((12>0)?(11):0):0]), // Templated
                         .adb_slv_debug_monitor (axi4_err_rsp_adb_slv_debug_monitor[31:0]), // Templated
                         .adb_mst_debug_monitor (axi4_err_rsp_adb_mst_debug_monitor[31:0]), // Templated
                         .awvalidm              (axi4_err_rsp_awvalidm), // Templated
                         .awidm                 (axi4_err_rsp_awidm[((8>0)?(7):0):0]), // Templated
                         .awaddrm               (axi4_err_rsp_awaddrm[48:0]), // Templated
                         .awlenm                (axi4_err_rsp_awlenm[3:0]), // Templated
                         .awsizem               (axi4_err_rsp_awsizem[2:0]), // Templated
                         .awburstm              (axi4_err_rsp_awburstm[1:0]), // Templated
                         .awlockm               (axi4_err_rsp_awlockm), // Templated
                         .awcachem              (axi4_err_rsp_awcachem[3:0]), // Templated
                         .awprotm               (axi4_err_rsp_awprotm[2:0]), // Templated
                         .awqosm                (axi4_err_rsp_awqosm[3:0]), // Templated
                         .awuserm               (axi4_err_rsp_awuserm[((12>0)?(11):0):0]), // Templated
                         .wvalidm               (axi4_err_rsp_wvalidm), // Templated
                         .wdatam                (axi4_err_rsp_wdatam[511:0]), // Templated
                         .wstrbm                (axi4_err_rsp_wstrbm[63:0]), // Templated
                         .wlastm                (axi4_err_rsp_wlastm), // Templated
                         .wuserm                (axi4_err_rsp_wuserm[((12>0)?(11):0):0]), // Templated
                         .breadym               (axi4_err_rsp_breadym), // Templated
                         .arvalidm              (axi4_err_rsp_arvalidm), // Templated
                         .aridm                 (axi4_err_rsp_aridm[((8>0)?(7):0):0]), // Templated
                         .araddrm               (axi4_err_rsp_araddrm[48:0]), // Templated
                         .arlenm                (axi4_err_rsp_arlenm[3:0]), // Templated
                         .arsizem               (axi4_err_rsp_arsizem[2:0]), // Templated
                         .arburstm              (axi4_err_rsp_arburstm[1:0]), // Templated
                         .arlockm               (axi4_err_rsp_arlockm), // Templated
                         .arcachem              (axi4_err_rsp_arcachem[3:0]), // Templated
                         .arprotm               (axi4_err_rsp_arprotm[2:0]), // Templated
                         .arqosm                (axi4_err_rsp_arqosm[3:0]), // Templated
                         .aruserm               (axi4_err_rsp_aruserm[((12>0)?(11):0):0]), // Templated
                         .rreadym               (axi4_err_rsp_rreadym), // Templated
                         // Inputs
                         .pwrq_permit_deny_sar_i(axi4_err_rsp_pwrq_permit_deny_sar_i), // Templated
                         .aclks                 (axi4_err_rsp_aclks), // Templated
                         .aresetns              (axi4_err_rsp_aresetns), // Templated
                         .dft_test_mode         (axi4_err_rsp_dft_test_mode), // Templated
                         .pwrqreqns_i           (axi4_err_rsp_pwrqreqns_i), // Templated
                         .ppu_st_pwron          (axi4_err_rsp_ppu_st_pwron), // Templated
                         .reg_err_rsp_en        (axi4_err_rsp_reg_err_rsp_en), // Templated
                         .awvalids              (axi4_err_rsp_awvalids), // Templated
                         .awids                 (axi4_err_rsp_awids[((8>0)?(7):0):0]), // Templated
                         .awaddrs               (axi4_err_rsp_awaddrs[48:0]), // Templated
                         .awlens                (axi4_err_rsp_awlens[3:0]), // Templated
                         .awsizes               (axi4_err_rsp_awsizes[2:0]), // Templated
                         .awbursts              (axi4_err_rsp_awbursts[1:0]), // Templated
                         .awlocks               (axi4_err_rsp_awlocks), // Templated
                         .awcaches              (axi4_err_rsp_awcaches[3:0]), // Templated
                         .awprots               (axi4_err_rsp_awprots[2:0]), // Templated
                         .awqoss                (axi4_err_rsp_awqoss[3:0]), // Templated
                         .awusers               (axi4_err_rsp_awusers[((12>0)?(11):0):0]), // Templated
                         .wvalids               (axi4_err_rsp_wvalids), // Templated
                         .wdatas                (axi4_err_rsp_wdatas[511:0]), // Templated
                         .wstrbs                (axi4_err_rsp_wstrbs[63:0]), // Templated
                         .wlasts                (axi4_err_rsp_wlasts), // Templated
                         .wusers                (axi4_err_rsp_wusers[((12>0)?(11):0):0]), // Templated
                         .breadys               (axi4_err_rsp_breadys), // Templated
                         .arvalids              (axi4_err_rsp_arvalids), // Templated
                         .arids                 (axi4_err_rsp_arids[((8>0)?(7):0):0]), // Templated
                         .araddrs               (axi4_err_rsp_araddrs[48:0]), // Templated
                         .arlens                (axi4_err_rsp_arlens[3:0]), // Templated
                         .arsizes               (axi4_err_rsp_arsizes[2:0]), // Templated
                         .arbursts              (axi4_err_rsp_arbursts[1:0]), // Templated
                         .arlocks               (axi4_err_rsp_arlocks), // Templated
                         .arcaches              (axi4_err_rsp_arcaches[3:0]), // Templated
                         .arprots               (axi4_err_rsp_arprots[2:0]), // Templated
                         .arqoss                (axi4_err_rsp_arqoss[3:0]), // Templated
                         .arusers               (axi4_err_rsp_arusers[((12>0)?(11):0):0]), // Templated
                         .rreadys               (axi4_err_rsp_rreadys), // Templated
                         .aclkm                 (axi4_err_rsp_aclkm), // Templated
                         .aresetnm              (axi4_err_rsp_aresetnm), // Templated
                         .awreadym              (axi4_err_rsp_awreadym), // Templated
                         .wreadym               (axi4_err_rsp_wreadym), // Templated
                         .bvalidm               (axi4_err_rsp_bvalidm), // Templated
                         .bidm                  (axi4_err_rsp_bidm[((8>0)?(7):0):0]), // Templated
                         .brespm                (axi4_err_rsp_brespm[1:0]), // Templated
                         .buserm                (axi4_err_rsp_buserm[((12>0)?(11):0):0]), // Templated
                         .arreadym              (axi4_err_rsp_arreadym), // Templated
                         .rvalidm               (axi4_err_rsp_rvalidm), // Templated
                         .ridm                  (axi4_err_rsp_ridm[((8>0)?(7):0):0]), // Templated
                         .rdatam                (axi4_err_rsp_rdatam[511:0]), // Templated
                         .rrespm                (axi4_err_rsp_rrespm[1:0]), // Templated
                         .rlastm                (axi4_err_rsp_rlastm), // Templated
                         .ruserm                (axi4_err_rsp_ruserm[((12>0)?(11):0):0])); // Templated



/*adb400_r3_axi5_err_rsp auto_template "adb400_r3_\(.*\)_u"(
.\(.*\) (@_\1[]),
);
*/
        

adb400_r3_axi5_err_rsp
#(/*autoinst param*/
                         // Parameters
                         .ADDR_WIDTH            (49),
                         .DATA_WIDTH            (512),
                         .ID_WIDTH            (8),
                         .USER_WIDTH          (12),
                         .LEN_WIDTH             (4),//TODO
                         .AW_FIFO_DEPTH         (6),
                         .W_FIFO_DEPTH          (6),
                         .B_FIFO_DEPTH          (6),
                         .AR_FIFO_DEPTH         (6),
                         .R_FIFO_DEPTH          (6),
                         .RD_OSTD_NUM           (1024),
                         .WR_OSTD_NUM           (1024)                          
                       
                       )

adb400_r3_axi5_err_rsp_u(/*autoinst*/
                         // Outputs
                         .pwrqacceptns_o        (axi5_err_rsp_pwrqacceptns_o), // Templated
                         .pwrqdenys_o           (axi5_err_rsp_pwrqdenys_o), // Templated
                         .pwrqactives_o         (axi5_err_rsp_pwrqactives_o), // Templated
                         .awreadys              (axi5_err_rsp_awreadys), // Templated
                         .wreadys               (axi5_err_rsp_wreadys), // Templated
                         .bvalids               (axi5_err_rsp_bvalids), // Templated
                         .bids                  (axi5_err_rsp_bids[((8>0)?(7):0):0]), // Templated
                         .bresps                (axi5_err_rsp_bresps[1:0]), // Templated
                         .busers                (axi5_err_rsp_busers[((12>0)?(11):0):0]), // Templated
                         .arreadys              (axi5_err_rsp_arreadys), // Templated
                         .rvalids               (axi5_err_rsp_rvalids), // Templated
                         .rids                  (axi5_err_rsp_rids[((8>0)?(7):0):0]), // Templated
                         .rdatas                (axi5_err_rsp_rdatas[511:0]), // Templated
                         .rresps                (axi5_err_rsp_rresps[1:0]), // Templated
                         .rlasts                (axi5_err_rsp_rlasts), // Templated
                         .rusers                (axi5_err_rsp_rusers[((12>0)?(11):0):0]), // Templated
                         .adb_slv_debug_monitor (axi5_err_rsp_adb_slv_debug_monitor[31:0]), // Templated
                         .adb_mst_debug_monitor (axi5_err_rsp_adb_mst_debug_monitor[31:0]), // Templated
                         .awvalidm              (axi5_err_rsp_awvalidm), // Templated
                         .awidm                 (axi5_err_rsp_awidm[((8>0)?(7):0):0]), // Templated
                         .awaddrm               (axi5_err_rsp_awaddrm[48:0]), // Templated
                         .awlenm                (axi5_err_rsp_awlenm[3:0]), // Templated
                         .awsizem               (axi5_err_rsp_awsizem[2:0]), // Templated
                         .awburstm              (axi5_err_rsp_awburstm[1:0]), // Templated
                         .awlockm               (axi5_err_rsp_awlockm), // Templated
                         .awcachem              (axi5_err_rsp_awcachem[3:0]), // Templated
                         .awprotm               (axi5_err_rsp_awprotm[2:0]), // Templated
                         .awqosm                (axi5_err_rsp_awqosm[3:0]), // Templated
                         .awuserm               (axi5_err_rsp_awuserm[((12>0)?(11):0):0]), // Templated
                         .awatopm               (axi5_err_rsp_awatopm[5:0]), // Templated
                         .wvalidm               (axi5_err_rsp_wvalidm), // Templated
                         .wdatam                (axi5_err_rsp_wdatam[511:0]), // Templated
                         .wstrbm                (axi5_err_rsp_wstrbm[63:0]), // Templated
                         .wlastm                (axi5_err_rsp_wlastm), // Templated
                         .wuserm                (axi5_err_rsp_wuserm[((12>0)?(11):0):0]), // Templated
                         .breadym               (axi5_err_rsp_breadym), // Templated
                         .arvalidm              (axi5_err_rsp_arvalidm), // Templated
                         .aridm                 (axi5_err_rsp_aridm[((8>0)?(7):0):0]), // Templated
                         .araddrm               (axi5_err_rsp_araddrm[48:0]), // Templated
                         .arlenm                (axi5_err_rsp_arlenm[3:0]), // Templated
                         .arsizem               (axi5_err_rsp_arsizem[2:0]), // Templated
                         .arburstm              (axi5_err_rsp_arburstm[1:0]), // Templated
                         .arlockm               (axi5_err_rsp_arlockm), // Templated
                         .arcachem              (axi5_err_rsp_arcachem[3:0]), // Templated
                         .arprotm               (axi5_err_rsp_arprotm[2:0]), // Templated
                         .arqosm                (axi5_err_rsp_arqosm[3:0]), // Templated
                         .aruserm               (axi5_err_rsp_aruserm[((12>0)?(11):0):0]), // Templated
                         .rreadym               (axi5_err_rsp_rreadym), // Templated
                         // Inputs
                         .pwrq_permit_deny_sar_i(axi5_err_rsp_pwrq_permit_deny_sar_i), // Templated
                         .aclks                 (axi5_err_rsp_aclks), // Templated
                         .aresetns              (axi5_err_rsp_aresetns), // Templated
                         .dft_test_mode         (axi5_err_rsp_dft_test_mode), // Templated
                         .pwrqreqns_i           (axi5_err_rsp_pwrqreqns_i), // Templated
                         .ppu_st_pwron          (axi5_err_rsp_ppu_st_pwron), // Templated
                         .reg_err_rsp_en        (axi5_err_rsp_reg_err_rsp_en), // Templated
                         .awvalids              (axi5_err_rsp_awvalids), // Templated
                         .awids                 (axi5_err_rsp_awids[((8>0)?(7):0):0]), // Templated
                         .awaddrs               (axi5_err_rsp_awaddrs[48:0]), // Templated
                         .awlens                (axi5_err_rsp_awlens[3:0]), // Templated
                         .awsizes               (axi5_err_rsp_awsizes[2:0]), // Templated
                         .awbursts              (axi5_err_rsp_awbursts[1:0]), // Templated
                         .awlocks               (axi5_err_rsp_awlocks), // Templated
                         .awcaches              (axi5_err_rsp_awcaches[3:0]), // Templated
                         .awprots               (axi5_err_rsp_awprots[2:0]), // Templated
                         .awqoss                (axi5_err_rsp_awqoss[3:0]), // Templated
                         .awusers               (axi5_err_rsp_awusers[((12>0)?(11):0):0]), // Templated
                         .awatops               (axi5_err_rsp_awatops[5:0]), // Templated
                         .wvalids               (axi5_err_rsp_wvalids), // Templated
                         .wdatas                (axi5_err_rsp_wdatas[511:0]), // Templated
                         .wstrbs                (axi5_err_rsp_wstrbs[63:0]), // Templated
                         .wlasts                (axi5_err_rsp_wlasts), // Templated
                         .wusers                (axi5_err_rsp_wusers[((12>0)?(11):0):0]), // Templated
                         .breadys               (axi5_err_rsp_breadys), // Templated
                         .arvalids              (axi5_err_rsp_arvalids), // Templated
                         .arids                 (axi5_err_rsp_arids[((8>0)?(7):0):0]), // Templated
                         .araddrs               (axi5_err_rsp_araddrs[48:0]), // Templated
                         .arlens                (axi5_err_rsp_arlens[3:0]), // Templated
                         .arsizes               (axi5_err_rsp_arsizes[2:0]), // Templated
                         .arbursts              (axi5_err_rsp_arbursts[1:0]), // Templated
                         .arlocks               (axi5_err_rsp_arlocks), // Templated
                         .arcaches              (axi5_err_rsp_arcaches[3:0]), // Templated
                         .arprots               (axi5_err_rsp_arprots[2:0]), // Templated
                         .arqoss                (axi5_err_rsp_arqoss[3:0]), // Templated
                         .arusers               (axi5_err_rsp_arusers[((12>0)?(11):0):0]), // Templated
                         .rreadys               (axi5_err_rsp_rreadys), // Templated
                         .aclkm                 (axi5_err_rsp_aclkm), // Templated
                         .aresetnm              (axi5_err_rsp_aresetnm), // Templated
                         .awreadym              (axi5_err_rsp_awreadym), // Templated
                         .wreadym               (axi5_err_rsp_wreadym), // Templated
                         .bvalidm               (axi5_err_rsp_bvalidm), // Templated
                         .bidm                  (axi5_err_rsp_bidm[((8>0)?(7):0):0]), // Templated
                         .brespm                (axi5_err_rsp_brespm[1:0]), // Templated
                         .buserm                (axi5_err_rsp_buserm[((12>0)?(11):0):0]), // Templated
                         .arreadym              (axi5_err_rsp_arreadym), // Templated
                         .rvalidm               (axi5_err_rsp_rvalidm), // Templated
                         .ridm                  (axi5_err_rsp_ridm[((8>0)?(7):0):0]), // Templated
                         .rdatam                (axi5_err_rsp_rdatam[511:0]), // Templated
                         .rrespm                (axi5_err_rsp_rrespm[1:0]), // Templated
                         .rlastm                (axi5_err_rsp_rlastm), // Templated
                         .ruserm                (axi5_err_rsp_ruserm[((12>0)?(11):0):0])); // Templated








/*adb400_r3_apb_err_rsp auto_template "adb400_r3_\(.*\)_u"(
.\(.*\) (@_\1[]),
);
*/
              

adb400_r3_apb_err_rsp
#(/*autoinst param*/
                        // Parameters
                        .ADDR_WIDTH     (32),
                        .DATA_WIDTH     (32),
                        .USER_WIDTH     (12),
                        .FW_FIFO_DEPTH  (2),
                        .RV_FIFO_DEPTH  (2))
                    
adb400_r3_apb_err_rsp_u(/*autoinst*/
                        // Outputs
                        .pwrqacceptns_o (apb_err_rsp_pwrqacceptns_o), // Templated
                        .pwrqdenys_o    (apb_err_rsp_pwrqdenys_o), // Templated
                        .pwrqactives_o  (apb_err_rsp_pwrqactives_o), // Templated
                        .adb_slv_debug_monitor(apb_err_rsp_adb_slv_debug_monitor[31:0]), // Templated
                        .adb_mst_debug_monitor(apb_err_rsp_adb_mst_debug_monitor[31:0]), // Templated
                        .preadys        (apb_err_rsp_preadys),   // Templated
                        .prdatas        (apb_err_rsp_prdatas[31:0]), // Templated
                        .pslverrs       (apb_err_rsp_pslverrs),  // Templated
                        .pselm          (apb_err_rsp_pselm),     // Templated
                        .penablem       (apb_err_rsp_penablem),  // Templated
                        .pwritem        (apb_err_rsp_pwritem),   // Templated
                        .paddrm         (apb_err_rsp_paddrm[31:0]), // Templated
                        .pwdatam        (apb_err_rsp_pwdatam[31:0]), // Templated
                        .puserm         (apb_err_rsp_puserm[11:0]), // Templated
                        // Inputs
                        .pwrq_permit_deny_sar_i(apb_err_rsp_pwrq_permit_deny_sar_i), // Templated
                        .pwrqreqns_i    (apb_err_rsp_pwrqreqns_i), // Templated
                        .reg_err_rsp_en (apb_err_rsp_reg_err_rsp_en), // Templated
                        .ppu_st_pwron   (apb_err_rsp_ppu_st_pwron), // Templated
                        .pclks          (apb_err_rsp_pclks),     // Templated
                        .presetns       (apb_err_rsp_presetns),  // Templated
                        .dft_test_mode  (apb_err_rsp_dft_test_mode), // Templated
                        .psels          (apb_err_rsp_psels),     // Templated
                        .penables       (apb_err_rsp_penables),  // Templated
                        .pwrites        (apb_err_rsp_pwrites),   // Templated
                        .paddrs         (apb_err_rsp_paddrs[31:0]), // Templated
                        .pwdatas        (apb_err_rsp_pwdatas[31:0]), // Templated
                        .pusers         (apb_err_rsp_pusers[11:0]), // Templated
                        .pclkm          (apb_err_rsp_pclkm),     // Templated
                        .presetnm       (apb_err_rsp_presetnm),  // Templated
                        .preadym        (apb_err_rsp_preadym),   // Templated
                        .prdatam        (apb_err_rsp_prdatam[31:0]), // Templated
                        .pslverrm       (apb_err_rsp_pslverrm));         // Templated


endmodule
// Local Variables:
// verilog-library-directories:("./*/verilog/" "./adb_err_rsp") 
// verilog-auto-inst-param-value:t
// End:
