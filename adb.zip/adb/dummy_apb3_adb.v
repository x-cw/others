//-----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited or its affiliates.
//
// (C) COPYRIGHT 2015-2016 ARM Limited or its affiliates.
// ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited or its affiliates.
//
// Checked In :  2016-02-07 15:48:44 +0000 (Sun, 07 Feb 2016)
// Revision : 206511
//
// Release Information : PL405-r3p0-00eac0
//
//-----------------------------------------------------------------------------
// Verilog-2001 (IEEE Std 1364-2001)
//-----------------------------------------------------------------------------
// File: adb400_r3_bas_slv.v
//-----------------------------------------------------------------------------
// Purpose : Slave side of bridge with bi-directional AXI4-Stream interfaces.
//-----------------------------------------------------------------------------

module dummy_apb3_adb
  #(parameter

      ADDR_WIDTH        = 32, 
      DATA_WIDTH        = 32, 
      USER_WIDTH        = 10, 
      FW_FIFO_DEPTH     = 6,
      RV_FIFO_DEPTH     = 6 


  )
  (
    // Configuration inputs
    input  wire                                             pwrq_permit_deny_sar_i,

    // Power state control
    input  wire                                             pwrqreqn_i,
    output wire                                             pwrqacceptn_o,
    output wire                                             pwrqdeny_o,

    //
    // Synchronous interfaces
    //

    // Global signals
    input  wire                                             pclks,
    input  wire                                             presetns,
    input  wire                                             dftrstdisables,

    input  wire                                             dft_test_mode,

    output wire                                             pwrqactive_o,



    // APB3

    input  wire                                             psels,
    input  wire                                             penables,
    input  wire                                             pwrites,
    input  wire  [ADDR_WIDTH-1:0]                           paddrs,
    input  wire  [DATA_WIDTH-1:0]                           pwdatas,
    input  wire  [USER_WIDTH-1:0]                           pusers,
    output  wire                                            preadys,
    output  wire [DATA_WIDTH-1:0]                           prdatas,
    output  wire                                            pslverrs 





  );


//--------------------add -----------------------------
     localparam FW_DATA_WIDTH     = DATA_WIDTH + ADDR_WIDTH + USER_WIDTH + 1;
     localparam FW_ID_WIDTH       = 1  ;
     localparam FW_DEST_WIDTH     = 1;
     localparam FW_USER_WIDTH     = 1;

     localparam RV_DATA_WIDTH     = DATA_WIDTH + 1;
     localparam RV_ID_WIDTH       = FW_ID_WIDTH;
     localparam RV_DEST_WIDTH     = FW_DEST_WIDTH;
     localparam RV_USER_WIDTH     = FW_USER_WIDTH;

     localparam RV_OPREG          = 1;

     localparam SI_SYNC_LEVELS    = 2;

     // If they are overridden is should only be to 0.

     // These are generally derived from DATA width.
    // localparam FW_STRB_WIDTH     = (FW_DATA_WIDTH/8);
    // localparam FW_KEEP_WIDTH     = (FW_DATA_WIDTH/8);
    // localparam RV_STRB_WIDTH     = (RV_DATA_WIDTH/8);
    // localparam RV_KEEP_WIDTH     = (RV_DATA_WIDTH/8);
     
     localparam FW_STRB_WIDTH     = 1;
     localparam FW_KEEP_WIDTH     = 1;
     localparam RV_STRB_WIDTH     = 1;
     localparam RV_KEEP_WIDTH     = 1;


     // Normally present; but can be removed
     localparam FW_LAST_WIDTH     = 1;
     localparam RV_LAST_WIDTH     = 1;


    // Clock control
    wire                                             clkqreqns_i;
    wire                                             clkqacceptns_o;
    wire                                             clkqdenys_o;

    // Clock requirement
    wire                                             clkqactives_o;


    // Wake-up
    wire                                             wakeups_i;
    wire                                             wakeups_o;



    // FW channel signalling
    wire                                             fwvalid;
    wire                                             fwready;
  wire   fwready_int;
  wire   fwvalid_int;

    reg write_read_en;



  wire internal_reset_n;
  wire presetns_ss;






  adb400_r3_syncn
    #(
      .LEVELS           (2)
    )
    u_syncn_aresetn
    (
      .aclk    (pclks),
      .aresetn (presetns),
      .din     (1'b1),
      .dout    (presetns_ss)
    );

  wire resetn_unforced = dft_test_mode ? presetns: (dftrstdisables | presetns_ss);
  wire resetn_forced   = dft_test_mode ? presetns: (dftrstdisables | (presetns_ss & internal_reset_n)); // to reset upstrm , dnstrm or slice in non-vf




   // apb to axi-stream

   //assign preadys = (pwrites)? tfwreadys :  trvvalids;
   assign preadys = fwready ;
   //assign preadys = 1'b1;
   assign prdatas = {DATA_WIDTH{1'b0}};
   assign pslverrs = 1'b1;



   //assign trvreadys = psels & penables;
   //assign trvreadys = ~pwrites;
   //assign trvreadys = 1'b1;


   assign fwvalid =  write_read_en;


   always@(posedge pclks or negedge resetn_unforced)
   if(!resetn_unforced)
     write_read_en <= 1'd0;
   else if(psels & ~penables) 
     write_read_en <= 1'b1;
   else if (fwready)
     write_read_en <= 1'd0;


   assign fwready_int = 1'b1;

  // ----------------------------------------------------------------------------
  // pwr and clk status machine, fence and stall logic
  // ----------------------------------------------------------------------------




  reg  initiator_quiescentn_q;
  reg  initiator_quiescent_and_stalledn_q;



  wire initiator_fence_n;
  wire responder_fence_n;
  wire inner_fence_n;
  wire outer_fence_n;

  dummy_adb_st_ctrl
    #(
      .SYNC_LEVELS (2)
    )
  u_st_ctrl
    (
      .aclk                   (pclks),
      .aresetn                (resetn_unforced),

      .pwrq_permit_deny_i     (pwrq_permit_deny_sar_i),

      .clkqreqn_i             (1'b1),
      .clkqacceptn_o          (),
      .clkqdeny_o             (),
      .clkqactive_o           (),
      .pwrqreqn_i             (pwrqreqn_i),
      .pwrqacceptn_o          (pwrqacceptn_o),
      .pwrqdeny_o             (pwrqdeny_o),
      .pwrqactive_o           (pwrqactive_o),

      .wakeup_i               (1'b0),
      .wakeup_o               (),
      .wakeup_sync_i          (1'b0),

      //.slvmustacceptreqn_o    (),
      //.slvcandenyreqn_o       (),
      //.slvacceptn_async_i     (slvacceptn_async),
      //.slvdeny_async_i        (slvdeny_async),

      //.wakeup_async_o         (si_to_mi_wakeup_async),
      //.wakeup_async_i         (mi_to_si_wakeup_async),

      .ar_dvm_multipart_quiescent_i  (1'b1),
      .ac_dvm_multipart_quiescent_i  (1'b1),
      .dvm_sync_complete_quiescent_i (1'b1),
      .initiator_quiescent_i  (~initiator_quiescentn_q),
      .responder_quiescent_i  (1'b1),
      .initiator_quiescent_and_stalled_i (~initiator_quiescent_and_stalledn_q),
      .responder_quiescent_and_stalled_i (1'b1),

      .initiator_fencen_o     (initiator_fence_n),   
      .responder_fencen_o     (responder_fence_n),   
      .inner_fencen_o         (inner_fence_n),       
      .outer_fencen_o         (outer_fence_n),       
      .internal_resetn_o      (internal_reset_n)     
    );


  //---------------------------------------------------------------------------
  // Apply the Q channel outer fence and the quiescence-enforcer fence
  // to the bare interfaces before using them everywhere else
  //---------------------------------------------------------------------------

//  reg    fw_hndshk_sticky_q;
  wire stall_n_flag;
  reg stall_n;

  assign   fwvalid_int  = (outer_fence_n & stall_n & initiator_fence_n  & fwvalid);

  //assign fwready      = (outer_fence_n & (initiator_fence_n | fw_hndshk_sticky_q) & fwready_int);
  assign fwready      = (outer_fence_n & stall_n &   fwready_int);




  assign stall_n_flag = ~initiator_quiescent_and_stalledn_q & ~initiator_fence_n & fwvalid;
  always @(posedge pclks or negedge resetn_forced)
    begin 
      if (! resetn_forced)
        stall_n <= 1'b1;
      else if (stall_n_flag)
        stall_n <= 1'b0;
      else if (outer_fence_n)
        stall_n <= 1'b1;
    end

//  wire fw_hndshk_sticky_nxt = (fwvalid_int & ~fwready_int);
//  wire fw_hndshk_sticky_upd_en = 1'b1;
//  always @(posedge pclks or negedge resetn_forced)
//    begin : p_hndshk_sticky_fw
//      if (! resetn_forced)
//        fw_hndshk_sticky_q <= 1'b0;
//      else if (fw_hndshk_sticky_upd_en)
//        fw_hndshk_sticky_q <= fw_hndshk_sticky_nxt;
//    end




  //---------------------------------------------------------------------------
  // Signals for all the channel components to use to indicate their non-emptiness
  //---------------------------------------------------------------------------

  //wire fw_chan_cactive;


  //--------------------------------------------------------------------
  // Combine the activity indicators
  //--------------------------------------------------------------------

  // Must avoid a chan_cactive *alone* causing quiescentn to go high
  // as that would only happen in the reset phase, which we want to avoid.
  
  // Predeclared above

  wire initiator_quiescentn_nxt    = (// Drive high because of a new transfer
                                      (fwvalid_int & fwready_int) 
                                      // Keep high till the transfer has completely left the channel
                                      //| (initiator_quiescentn_q & fw_chan_cactive)
                                     );
  wire initiator_quiescentn_upd_en = (initiator_quiescentn_q | initiator_quiescentn_nxt);

  always @(posedge pclks or negedge resetn_forced)
    begin : p_initiator_quiescentn
      if (! resetn_forced)
        initiator_quiescentn_q <= 1'b0;
      else if (initiator_quiescentn_upd_en)
        initiator_quiescentn_q <= initiator_quiescentn_nxt;
    end

  // Predeclared above
  wire initiator_quiescent_and_stalledn_nxt    = (// Drive high because of a new transfer
                                                  (fwvalid_int & fwready_int) |
                                                  // The channel is not stalled
                                                  initiator_fence_n 
                                                  // Keep high till the transfer has completely left the channel
                                                 // | (initiator_quiescent_and_stalledn_q & fw_chan_cactive)
                                                 );
  wire initiator_quiescent_and_stalledn_upd_en = (initiator_quiescent_and_stalledn_q | initiator_quiescent_and_stalledn_nxt);

  always @(posedge pclks or negedge resetn_forced)
    begin : p_initiator_quiescent_and_stalledn
      if (! resetn_forced)
        initiator_quiescent_and_stalledn_q <= 1'b0;
      else if (initiator_quiescent_and_stalledn_upd_en)
        initiator_quiescent_and_stalledn_q <= initiator_quiescent_and_stalledn_nxt;
    end






endmodule
