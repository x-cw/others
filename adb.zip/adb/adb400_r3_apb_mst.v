//-----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited or its affiliates.
//
// (C) COPYRIGHT 2015-2016 ARM Limited or its affiliates.
// ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited or its affiliates.
//
// Checked In :  2016-02-07 15:48:44 +0000 (Sun, 07 Feb 2016)
// Revision : 206511
//
// Release Information : PL405-r3p0-00eac0
//
//-----------------------------------------------------------------------------
// Verilog-2001 (IEEE Std 1364-2001)
//-----------------------------------------------------------------------------
// File: adb400_r3_bas_mst.v
//-----------------------------------------------------------------------------
// Purpose : Master side of bridge with bi-directional AXI4-Stream interfaces.
//-----------------------------------------------------------------------------

module adb400_r3_apb_mst
  #(parameter
      ADDR_WIDTH        = 32, 
      DATA_WIDTH        = 32, 
      USER_WIDTH        = 10, 

      FW_FIFO_DEPTH     = 2,
      RV_FIFO_DEPTH     = 2 


  )
  (
    //
    // Synchronous interfaces
    //

    // Global signals
    input  wire                                             pclkm,
    input  wire                                             presetnm,

    input  wire                                             dft_test_mode,



    // Power requirement
    //output wire                                             pwrqactivem_o,

    //// Wake-up
    //input  wire                                             wakeupm_i,
    //output wire                                             wakeupm_o,


    // debug
    output wire  [31:0]           adb_debug_monitor,


    // APB3
    output  reg                                             pselm,
    output  reg                                             penablem,
    output  wire                                             pwritem,
    output  wire  [ADDR_WIDTH-1:0]                           paddrm,
    output  wire  [DATA_WIDTH-1:0]                           pwdatam,
    output  wire  [USER_WIDTH-1:0]                           puserm,
    input  wire                                            preadym,
    input  wire [DATA_WIDTH-1:0]                           prdatam,
    input  wire                                            pslverrm,







    // Async interfaces 

    input  wire                                             slvmustacceptreqn_async,
    input  wire                                             slvcandenyreqn_async,
    output wire                                             slvacceptn_async,
    output wire                                             slvdeny_async,

    input  wire                                             si_to_mi_wakeup_async,
    output wire                                             mi_to_si_wakeup_async,


    // add
    output wire [FW_FIFO_DEPTH-1:0]fw_rd_ptr_sync,
    input wire [RV_FIFO_DEPTH-1:0]rv_rd_ptr_sync,

    input  wire [FW_FIFO_DEPTH-1:0]                         fw_wr_ptr_async,
    output wire [FW_FIFO_DEPTH-1:0]                         fw_rd_ptr_async,
    input wire [(DATA_WIDTH + ADDR_WIDTH + USER_WIDTH + 1)-1:0]                                     fw_payld_async, 

    output wire [RV_FIFO_DEPTH-1:0]                         rv_wr_ptr_async,
    input  wire [RV_FIFO_DEPTH-1:0]                         rv_rd_ptr_async,
    output  wire [(DATA_WIDTH +  1)-1:0]                                     rv_payld_async   

   );



    localparam FW_OPREG          = 1;
    localparam MI_SYNC_LEVELS    = 2;

    localparam IDLE_S = 2'b00;
    localparam SETUP_S = 2'b01;
    localparam ENABLE_S = 2'b10;
    localparam EXIT_S = 2'b11;



    wire tfwvalidm;
    wire tfwreadym;
    wire[(DATA_WIDTH + ADDR_WIDTH + USER_WIDTH + 1)-1:0] tfwpayldm;
               
    wire trvvalidm;
    wire trvreadym;
    wire[(DATA_WIDTH +  1)-1:0] trvpayldm;


    // Clock control
    wire                                             clkqreqnm_i;
    wire                                             clkqacceptnm_o;
    wire                                             clkqdenym_o;

    // Clock requirement
    wire                                             clkqactivem_o;

    wire                                             pwrqactivem_o;

    // Wake-up
    wire                                             wakeupm_i;
    wire                                             wakeupm_o;


     wire                                             dftrstdisablem;

    reg [1:0] apb_cs;
    reg [1:0] apb_ns;

    reg read_valid;
    reg [((DATA_WIDTH +  1)-1):0 ] read_data;


    assign    dftrstdisablem = 1'b0;
    assign    clkqreqnm_i =1'b1;
    assign    wakeupm_i = 1'b0;   



    wire resetn_unforced;
    assign resetn_unforced = dft_test_mode? presetnm: (dftrstdisablem | presetnm);




   //assign tfwreadym =  (pwritem)? pselm & penablem & preadym : read_valid;
   assign tfwreadym =   pselm & penablem & preadym;
   assign {paddrm,pwdatam,puserm,pwritem} = tfwpayldm;
   assign trvpayldm = read_data;
   assign trvvalidm = read_valid;

   always@(posedge pclkm or negedge resetn_unforced)
   if(!resetn_unforced)
     read_valid <= 1'd0;
//   else if(~pwritem & pselm & penablem & preadym) 
   else if( pselm & penablem & preadym) 
     read_valid <= 1'b1;
   else if (trvreadym)
     read_valid <= 1'd0;

   always@(posedge pclkm or negedge resetn_unforced)
   if(!resetn_unforced)
     read_data <= {(DATA_WIDTH + 1){1'd0}};
//   else if(~pwritem & pselm & penablem & preadym) 
   else if( pselm & penablem & preadym) 
     read_data <= {prdatam,pslverrm};
   else if (trvreadym)
     read_data <= {(DATA_WIDTH + 1){1'd0}};



   always@(posedge pclkm or negedge resetn_unforced)
   if(!resetn_unforced)
     apb_cs <= 2'd0;
   else
     apb_cs <= apb_ns;

   always@(*)
    case(apb_cs)
      IDLE_S:  
            if(tfwvalidm)
              apb_ns = SETUP_S;
            else
              apb_ns = IDLE_S;
      SETUP_S:
              apb_ns = ENABLE_S;
      ENABLE_S:  
            if(preadym)
              apb_ns = EXIT_S;
            else
              apb_ns = ENABLE_S;
      EXIT_S:  
              apb_ns = IDLE_S;
      default: apb_ns = IDLE_S;
    endcase 


   always@(posedge pclkm or negedge resetn_unforced)
   if(!resetn_unforced)
     pselm <= 1'b0;
   else if (apb_ns == SETUP_S || apb_ns == ENABLE_S)
     pselm <= 1'b1;
   else
     pselm <= 1'b0;


   always@(posedge pclkm or negedge resetn_unforced)
   if(!resetn_unforced)
     penablem <= 1'b0;
   else if ( apb_ns == ENABLE_S)
     penablem <= 1'b1;
   else
     penablem <= 1'b0;













  adb400_r3_mst_transport_f1r1_apb
    #(
      .FW_FIFO_DEPTH       (FW_FIFO_DEPTH),
      .RV_FIFO_DEPTH       (RV_FIFO_DEPTH),
      .FW_OPREG            (FW_OPREG),
      .SYNC_LEVELS         (MI_SYNC_LEVELS),
      .FW_PAYLOAD_WIDTH    (DATA_WIDTH + ADDR_WIDTH + USER_WIDTH + 1),
      .RV_PAYLOAD_WIDTH    (DATA_WIDTH +  1)
    )
  u_mst
    (
      .aclk                    (pclkm),
      .aresetn                 (presetnm),
      .dft_test_mode                 (dft_test_mode),
      .dftrstdisable           (dftrstdisablem),


      .adb_debug_monitor_o     (adb_debug_monitor),

      .clkqreqn_i              (clkqreqnm_i),
      .clkqacceptn_o           (clkqacceptnm_o),
      .clkqdeny_o              (clkqdenym_o),
      .clkqactive_o            (clkqactivem_o),
      .pwrqactive_o            (pwrqactivem_o),
      .wakeup_i                (wakeupm_i),
      .wakeup_o                (wakeupm_o),

      .fwvalid                 (tfwvalidm),
      .fwready                 (tfwreadym),
      .fw_payld                (tfwpayldm),

      .rvvalid                 (trvvalidm),
      .rvready                 (trvreadym),
      .rv_payld                (trvpayldm),

      .slvmustacceptreqn_async (slvmustacceptreqn_async),
      .slvcandenyreqn_async    (slvcandenyreqn_async),
      .slvacceptn_async        (slvacceptn_async),
      .slvdeny_async           (slvdeny_async),

      .si_to_mi_wakeup_async   (si_to_mi_wakeup_async),
      .mi_to_si_wakeup_async   (mi_to_si_wakeup_async),


      .fw_rd_ptr_sync          (fw_rd_ptr_sync), 
      .rv_rd_ptr_sync          (rv_rd_ptr_sync),       


      .fw_wr_ptr_async         (fw_wr_ptr_async),
      .fw_rd_ptr_async         (fw_rd_ptr_async),
      .fw_payld_async          (fw_payld_async),
     
      .rv_wr_ptr_async         (rv_wr_ptr_async),
      .rv_rd_ptr_async         (rv_rd_ptr_async),
      .rv_payld_async          (rv_payld_async)
    );





endmodule
