// +FHDR----------------------------------------------------------------------------
// Project Name  : IC_Design
// Author        : xucw
// Email         : xucw@innosilicon.com.cn
// Create On     : 2024/12/12 10:49
// Last Modified : 2024/12/12 10:49
// File Name     : adb_debug_monitor.v
// Description   :
// 
// Copyright (c) 2024 Innosilicon.
// ALL RIGHTS RESERVED
// 
// ---------------------------------------------------------------------------------
// Modification History:
// Date         By              Version                 Change Description
// ---------------------------------------------------------------------------------
// 2024/12/12   xucw            1.0                     Original
// 
// -FHDR----------------------------------------------------------------------------

module adb_debug_monitor
  #(
    parameter       DEPTH       = 4,
                    SYNC_LEVELS = 2,
                    INST_IN_SLV = 1

  )
(
    input             aclk,
    input             aresetn,
    
    input wire  [3:0] pwrq_ctrl_state,


    // W channel signalling
    input wire [DEPTH-1:0] fw_wr_ptr_async,
    input  wire [DEPTH-1:0] fw_rd_ptr_async,

    // r channel signalling
    input wire [ DEPTH-1:0]  rv_wr_ptr_async,
    input  wire [ DEPTH-1:0]  rv_rd_ptr_async,



    output reg [ 32-1:0]  adb_debug_monitor_o  

);

wire [31:0] adb_debug_monitor;
wire fw_fifo_full;
wire rv_fifo_full;
wire fw_fifo_empty;
wire rv_fifo_empty;

wire fw_ptr_error;
wire rv_ptr_error;

 



  // ----------------------------------------------------------------------
  //  monitor logic
  // ----------------------------------------------------------------------


genvar j;

generate
  if (INST_IN_SLV==0)

    begin: monitor_master
        wire [DEPTH-1:0] fw_wr_ptr_async_s;
        wire [DEPTH-1:0] rv_rd_ptr_async_s;  

        wire is_power_down_reset; 
        wire all_ptr_async_is_zero;
        // ----------------------------------------------------------------------
        // sync input signals
        // ----------------------------------------------------------------------
      
        for (j=0; j<DEPTH ; j=j+1)
          begin : fw_g_j
            adb400_r3_syncn
              #(
                .LEVELS (SYNC_LEVELS)
              )
              u_syncn_fw_wr_ptr_async
              (
                .aclk    (aclk),
                .aresetn (aresetn),
                .din     (fw_wr_ptr_async[j]),
                .dout    (fw_wr_ptr_async_s[j])
              );
          end
      
        for (j=0; j<DEPTH ; j=j+1)
          begin : rv_g_j
            adb400_r3_syncn
              #(
                .LEVELS (SYNC_LEVELS)
              )
              u_syncn_rv_rd_ptr_async
              (
                .aclk    (aclk),
                .aresetn (aresetn),
                .din     (rv_rd_ptr_async[j]),
                .dout    (rv_rd_ptr_async_s[j])
              );
          end
      
      
      
      
      
        // ----------------------------------------------------------------------
        // fifo full/empty
        // ----------------------------------------------------------------------
      
      
      
      assign fw_fifo_full = &(fw_wr_ptr_async_s ^ fw_rd_ptr_async);
      assign rv_fifo_full = &(rv_wr_ptr_async^ rv_rd_ptr_async_s);
      
      
      assign fw_fifo_empty = ~( |(fw_wr_ptr_async_s ^ fw_rd_ptr_async));
      assign rv_fifo_empty = ~( |(rv_wr_ptr_async^ rv_rd_ptr_async_s) );
      
      
      

      
        // ----------------------------------------------------------------------
        // exception case
        // ----------------------------------------------------------------------
      
       // STM is at ST_STOPPED or ST_READY_RESET
 
        assign is_power_down_reset = (pwrq_ctrl_state[2:0]==3'b0) | (pwrq_ctrl_state[2:0]==3'd7) ;

        assign all_ptr_async_is_zero = (fw_wr_ptr_async_s=={DEPTH{1'b0}}) & (rv_rd_ptr_async_s=={DEPTH{1'b0}});



          //reg rv_ptr_error_r; 
          //always @(posedge aclk or negedge aresetn)
          // if (!aresetn)
          //   rv_ptr_error_r <= 1'b0;
          // else if ( (~rv_fifo_empty) & ~initiator_quiescentn_q)
          //   rv_ptr_error_r <= 1'b1;

          //assign rv_ptr_error = rv_ptr_error_r;

          //assign  fw_ptr_error = 1'b0;
          



          //----------------fw-------------------------
         reg [DEPTH-1:0] fw_wr_ptr_async_ss;
         always @(posedge aclk or negedge aresetn)
           if (!aresetn)
             fw_wr_ptr_async_ss <= {DEPTH{1'b0}};
           else 
             fw_wr_ptr_async_ss <= fw_wr_ptr_async_s;
           
        

         //wire [DEPTH-1:0]  fw_ptr_d;
         //wire fw_ptr_is_multibit_diff;
         //assign fw_ptr_d = (fw_wr_ptr_async_ss ^ fw_wr_ptr_async_s);
         //assign fw_ptr_is_multibit_diff = |((fw_ptr_d - 1'b1) & fw_ptr_d);
        
         wire fw_ptr_abnomal_to_zero = (fw_wr_ptr_async_s=={DEPTH{1'b0}}) & ( ~ ( (fw_wr_ptr_async_ss=={DEPTH-1{1'b0}})
                                                                                | (fw_wr_ptr_async_ss=={1'b1,{DEPTH-1{1'b0}}}) 
                                                                                | (fw_wr_ptr_async_ss=={2'b11,{DEPTH-2{1'b0}}}) 
                                                                                ) );

         reg fw_ptr_error_r; 
         always @(posedge aclk or negedge aresetn)
           if (!aresetn)
             fw_ptr_error_r <= 1'b0;
           else if ( ~is_power_down_reset & all_ptr_async_is_zero & fw_ptr_abnomal_to_zero)
             fw_ptr_error_r <= 1'b1;
        
         assign fw_ptr_error = fw_ptr_error_r;
        
        
        
        
          //----------------rv-------------------------
         reg [DEPTH-1:0] rv_rd_ptr_async_ss;
         always @(posedge aclk or negedge aresetn)
           if (!aresetn)
             rv_rd_ptr_async_ss <= {DEPTH{1'b0}};
           else 
             rv_rd_ptr_async_ss <= rv_rd_ptr_async_s;
           
        
         //wire [DEPTH-1:0]  rv_ptr_d;
         //wire rv_ptr_is_multibit_diff;
         //assign rv_ptr_d = (rv_rd_ptr_async_ss ^ rv_rd_ptr_async_s);
         //assign rv_ptr_is_multibit_diff = |((rv_ptr_d - 1'b1) & rv_ptr_d);
        
         wire rv_ptr_abnomal_to_zero = (rv_rd_ptr_async_s=={DEPTH{1'b0}}) & ( ~ ( (rv_rd_ptr_async_ss=={DEPTH-1{1'b0}})
                                                                              | (rv_rd_ptr_async_ss=={1'b1,{DEPTH-1{1'b0}}}) 
                                                                              | (rv_rd_ptr_async_ss=={2'b11,{DEPTH-2{1'b0}}}) 
                                                                              ) );

         reg rv_ptr_error_r; 
         always @(posedge aclk or negedge aresetn)
           if (!aresetn)
             rv_ptr_error_r <= 1'b0;
           else if ( ~is_power_down_reset & all_ptr_async_is_zero & rv_ptr_abnomal_to_zero)
             rv_ptr_error_r <= 1'b1;
        
         assign rv_ptr_error = rv_ptr_error_r;






          end







  else // inst in adb slave


    begin: monitor_slave



         wire [DEPTH-1:0] fw_rd_ptr_async_s;
         wire [DEPTH-1:0] rv_wr_ptr_async_s;  
        wire is_power_down_reset; 
        wire all_ptr_async_is_zero;

        // ----------------------------------------------------------------------
        // sync input signals
        // ----------------------------------------------------------------------
      

        for (j=0; j<DEPTH ; j=j+1)
          begin : fw_g_j
            adb400_r3_syncn
              #(
                .LEVELS (SYNC_LEVELS)
              )
              u_syncn_fw_rd_ptr_async
              (
                .aclk    (aclk),
                .aresetn (aresetn),
                .din     (fw_rd_ptr_async[j]),
                .dout    (fw_rd_ptr_async_s[j])
              );
          end
      
        for (j=0; j<DEPTH ; j=j+1)
          begin : rv_g_j
            adb400_r3_syncn
              #(
                .LEVELS (SYNC_LEVELS)
              )
              u_syncn_rv_wr_ptr_async
              (
                .aclk    (aclk),
                .aresetn (aresetn),
                .din     (rv_wr_ptr_async[j]),
                .dout    (rv_wr_ptr_async_s[j])
              );
          end
      
      
      
      
      
        // ----------------------------------------------------------------------
        // fifo full/empty
        // ----------------------------------------------------------------------
      
      
      
      assign fw_fifo_full = &(fw_wr_ptr_async ^ fw_rd_ptr_async_s);
      assign rv_fifo_full = &(rv_wr_ptr_async_s^ rv_rd_ptr_async);
      
      
      assign fw_fifo_empty = ~( |(fw_wr_ptr_async ^ fw_rd_ptr_async_s));
      assign rv_fifo_empty = ~( |(rv_wr_ptr_async_s^ rv_rd_ptr_async) );
      
      
      
      
      
      

        // ----------------------------------------------------------------------
        // exception case
        // ----------------------------------------------------------------------

        // STM is at ST_P_STOPPED or ST_P_EXIT or ST_P_REQUEST_RESET
        assign is_power_down_reset = (pwrq_ctrl_state==4'b0) | (pwrq_ctrl_state==4'b1) | (pwrq_ctrl_state==4'd9);  

        assign all_ptr_async_is_zero = (fw_rd_ptr_async_s=={DEPTH{1'b0}}) & (rv_wr_ptr_async_s=={DEPTH{1'b0}});


        // reg fw_ptr_error_r; 
         // always @(posedge aclk or negedge aresetn)
         //   if (!aresetn)
         //     fw_ptr_error_r <= 1'b0;
         //   else if ( (~fw_fifo_empty) & ~initiator_quiescentn_q)
         //     fw_ptr_error_r <= 1'b1;
         // 
         // assign fw_ptr_error = fw_ptr_error_r;
         //
         // assign rv_ptr_error = 0;


          //----------------fw-------------------------
         reg [DEPTH-1:0] fw_rd_ptr_async_ss;
         always @(posedge aclk or negedge aresetn)
           if (!aresetn)
             fw_rd_ptr_async_ss <= {DEPTH{1'b0}};
           else 
             fw_rd_ptr_async_ss <= fw_rd_ptr_async_s;
           
        
         //wire [DEPTH-1:0]  fw_ptr_d;
         //wire fw_ptr_is_multibit_diff;
         //assign fw_ptr_d = (fw_rd_ptr_async_ss ^ fw_rd_ptr_async_s);
         //assign fw_ptr_is_multibit_diff = |((fw_ptr_d - 1'b1) & fw_ptr_d);
        
         wire fw_ptr_abnomal_to_zero = (fw_rd_ptr_async_s=={DEPTH{1'b0}}) & ( ~ ( (fw_rd_ptr_async_ss=={DEPTH-1{1'b0}})
                                                                                | (fw_rd_ptr_async_ss=={1'b1,{DEPTH-1{1'b0}}}) 
                                                                                | (fw_rd_ptr_async_ss=={2'b11,{DEPTH-2{1'b0}}}) 
                                                                                ) );
         
         reg fw_ptr_error_r; 
         always @(posedge aclk or negedge aresetn)
           if (!aresetn)
             fw_ptr_error_r <= 1'b0;
           else if ( ~is_power_down_reset & all_ptr_async_is_zero & fw_ptr_abnomal_to_zero)
             fw_ptr_error_r <= 1'b1;
        
         assign fw_ptr_error = fw_ptr_error_r;
        
        
        
        
          //----------------rv-------------------------
         reg [DEPTH-1:0] rv_wr_ptr_async_ss;
         always @(posedge aclk or negedge aresetn)
           if (!aresetn)
             rv_wr_ptr_async_ss <= {DEPTH{1'b0}};
           else 
             rv_wr_ptr_async_ss <= rv_wr_ptr_async_s;
           
        
         //wire [DEPTH-1:0]  rv_ptr_d;
         //wire rv_ptr_is_multibit_diff;
         //assign rv_ptr_d = (rv_wr_ptr_async_ss ^ rv_wr_ptr_async_s);
         //assign rv_ptr_is_multibit_diff = |((rv_ptr_d - 1'b1) & rv_ptr_d);
        
         wire rv_ptr_abnomal_to_zero = (rv_wr_ptr_async_s=={DEPTH{1'b0}}) & ( ~ ( (rv_wr_ptr_async_ss=={DEPTH-1{1'b0}})
                                                                                | (rv_wr_ptr_async_ss=={1'b1,{DEPTH-1{1'b0}}}) 
                                                                                | (rv_wr_ptr_async_ss=={2'b11,{DEPTH-2{1'b0}}}) 
                                                                                ) );

         reg rv_ptr_error_r; 
         always @(posedge aclk or negedge aresetn)
           if (!aresetn)
             rv_ptr_error_r <= 1'b0;
           else if ( ~is_power_down_reset & all_ptr_async_is_zero & rv_ptr_abnomal_to_zero)
             rv_ptr_error_r <= 1'b1;
        
         assign rv_ptr_error = rv_ptr_error_r;




     end

endgenerate





  // ----------------------------------------------------------------------
  // collect monitor signals
  // ----------------------------------------------------------------------


always @(posedge aclk or negedge aresetn)
if (!aresetn)
  adb_debug_monitor_o <= 32'h30;
else
  adb_debug_monitor_o <= adb_debug_monitor;


assign adb_debug_monitor = {
  22'd0,
  fw_ptr_error,           // bit[ 9], 1bit
  rv_ptr_error,           // bit[ 8], 1bit
  fw_fifo_full,           // bit[ 7], 1bit
  rv_fifo_full,           // bit[ 6], 1bit
  fw_fifo_empty,          // bit[ 5], 1bit
  rv_fifo_empty,          // bit[ 4], 1bit
  pwrq_ctrl_state         // bit[3:0], 4bit, the ctrl status of power Qchannel state machine
  };






endmodule
// Local Variables:
// verilog-library-directories:("./" ) 
// verilog-auto-inst-param-value:t
// End:
