//-----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited or its affiliates.
//
// (C) COPYRIGHT 2011-2016 ARM Limited or its affiliates.
// ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited or its affiliates.
//
// Checked In :  2016-02-12 14:23:46 +0000 (Fri, 12 Feb 2016)
// Revision : 206763
//
// Release Information : PL405-r3p0-00eac0
//
//-----------------------------------------------------------------------------
// Verilog-2001 (IEEE Std 1364-2001)
//-----------------------------------------------------------------------------
// File: adb400_r3_mst_transport_f1r1.v
//-----------------------------------------------------------------------------
// Purpose : Master interface half of a 2-channel transport bridge (i.e. no
//           protocol). This is wrapped in an additional layer to
//           provide specific parameters setting and remove unused ports.
//-----------------------------------------------------------------------------

module adb400_r3_mst_transport_f1r1_apb
  #(parameter
      FW_FIFO_DEPTH       = 6,
      RV_FIFO_DEPTH       = 6,
      FW_OPREG            = 1,
      SYNC_LEVELS         = 2,
      FW_PAYLOAD_WIDTH    = 1,
      RV_PAYLOAD_WIDTH    = 1
  )
  (
    // Global signals
    input  wire                   aclk,
    input  wire                   aresetn,
    input  wire                   dftrstdisable,
    input  wire                   dft_test_mode,
    // Clock control
    input  wire                   clkqreqn_i,
    output wire                   clkqacceptn_o,
    output wire                   clkqdeny_o,

    // Clock requirement
    output wire                   clkqactive_o,

    // Power requirement
    output wire                   pwrqactive_o,

    // Wake-up
    input  wire                   wakeup_i,
    output wire                   wakeup_o,


    // debug
    output wire  [31:0]           adb_debug_monitor_o,

    //
    // Synchronous interfaces
    //

    // FW channel signalling
    output wire fwvalid,
    input  wire fwready,
    output wire [((FW_PAYLOAD_WIDTH>0)?(FW_PAYLOAD_WIDTH-1):0):0] fw_payld,

    // RV channel signalling
    input  wire rvvalid,
    output wire rvready,
    input  wire [((RV_PAYLOAD_WIDTH>0)?(RV_PAYLOAD_WIDTH-1):0):0] rv_payld,

    //
    // Asynchronous interfaces
    //

    // Cross-domain power state control
    input  wire                   slvmustacceptreqn_async,
    input  wire                   slvcandenyreqn_async,
    output wire                   slvacceptn_async,
    output wire                   slvdeny_async,

    // Cross-domain wakeup
    input  wire                   si_to_mi_wakeup_async,
    output wire                   mi_to_si_wakeup_async,

    // FW channel signalling
    input  wire [FW_FIFO_DEPTH-1:0] fw_wr_ptr_async,
    output wire [FW_FIFO_DEPTH-1:0] fw_rd_ptr_async,
    //input  wire [((FW_PAYLOAD_WIDTH>0)?((FW_PAYLOAD_WIDTH*FW_FIFO_DEPTH)-1):0):0] fw_payld_async,
    input  wire [((FW_PAYLOAD_WIDTH>0)?((FW_PAYLOAD_WIDTH)-1):0):0] fw_payld_async,
    output wire [FW_FIFO_DEPTH-1:0] fw_rd_ptr_sync,

    // B channel signalling
    output wire [RV_FIFO_DEPTH-1:0] rv_wr_ptr_async,
    input  wire [RV_FIFO_DEPTH-1:0] rv_rd_ptr_async,
    input wire [RV_FIFO_DEPTH-1:0] rv_rd_ptr_sync,

    //output wire [((RV_PAYLOAD_WIDTH>0)?((RV_PAYLOAD_WIDTH*RV_FIFO_DEPTH)-1):0):0] rv_payld_async
    output wire [((RV_PAYLOAD_WIDTH>0)?((RV_PAYLOAD_WIDTH)-1):0):0] rv_payld_async
  );






  // ----------------------------------------------------------------------------
  // Reset Synchroniser
  // ----------------------------------------------------------------------------

  wire aresetn_ss;
  wire internal_reset_n;

  adb400_r3_syncn
    #(
      .LEVELS           (SYNC_LEVELS)
    )
    u_syncn_aresetn
    (
      .aclk    (aclk),
      .aresetn (aresetn),
      .din     (1'b1),
      .dout    (aresetn_ss)
    );

  wire resetn_unforced = dft_test_mode? aresetn: (dftrstdisable | aresetn_ss);
  wire resetn_forced   = dft_test_mode? aresetn: (dftrstdisable | (aresetn_ss & internal_reset_n));


  // ----------------------------------------------------------------------
  // debug 
  // ----------------------------------------------------------------------

    wire  [3:0] pwrq_ctrl_state;
  reg  initiator_quiescentn_q;
  reg  responder_quiescentn_q;

    adb_debug_monitor
      #(
        .DEPTH         (FW_FIFO_DEPTH),
        .SYNC_LEVELS   (SYNC_LEVELS  ),
        .INST_IN_SLV   (0) 
    
      )
    adb_debug_monitor_u
    (
        .aclk                    (aclk           ),
        .aresetn                 (resetn_forced        ),

    
        .pwrq_ctrl_state         (pwrq_ctrl_state),
        .fw_wr_ptr_async         (fw_wr_ptr_async),
        .fw_rd_ptr_async         (fw_rd_ptr_async),
        .rv_wr_ptr_async         (rv_wr_ptr_async),
        .rv_rd_ptr_async         (rv_rd_ptr_async), 
    
        .adb_debug_monitor_o     (adb_debug_monitor_o   ) 
    
    );

  //---------------------------------------------------------------------------
  // Control the fences, draining, and the MI side, plus interface to the 
  // upstream Q channels
  //---------------------------------------------------------------------------


  reg  initiator_quiescent_and_stalledn_q;
  reg  responder_quiescent_and_stalledn_q;


  wire wakeup_local;

  wire initiator_fence_n;
  wire responder_fence_n;
  wire inner_fence_n;
  wire outer_fence_n;

  adb400_r3_mi_ctrl
    #(
      .SYNC_LEVELS (SYNC_LEVELS)
    )
  u_mi_ctrl
    (
      .aclk                   (aclk),
      .aresetn                (resetn_unforced),

      .clkqreqn_i             (clkqreqn_i),
      .clkqacceptn_o          (clkqacceptn_o),
      .clkqdeny_o             (clkqdeny_o),
      .clkqactive_o           (clkqactive_o),

      .pwrqactive_o           (pwrqactive_o),


      .pwrq_ctrl_state        (pwrq_ctrl_state),

      .wakeup_i               (wakeup_i),
      .wakeup_o               (wakeup_o),
      .wakeup_sync_i          (wakeup_local),

      .slvmustacceptreqn_async_i (slvmustacceptreqn_async),
      .slvcandenyreqn_async_i (slvcandenyreqn_async),
      .slvacceptn_o           (slvacceptn_async),
      .slvdeny_o              (slvdeny_async),

      .wakeup_async_i         (si_to_mi_wakeup_async),
      .wakeup_async_o         (mi_to_si_wakeup_async),

      .ar_dvm_multipart_quiescent_i (1'b1),
      .ac_dvm_multipart_quiescent_i (1'b1),
      .dvm_sync_complete_quiescent_i (1'b1),
      .initiator_quiescent_i  (~initiator_quiescentn_q),
      .responder_quiescent_i  (~responder_quiescentn_q),
      .initiator_quiescent_and_stalled_i  (~initiator_quiescent_and_stalledn_q),
      .responder_quiescent_and_stalled_i  (~responder_quiescent_and_stalledn_q),

      .initiator_fencen_o     (initiator_fence_n),   
      .responder_fencen_o     (responder_fence_n),
      .inner_fencen_o         (inner_fence_n),       
      .outer_fencen_o         (outer_fence_n),       
      .internal_resetn_o      (internal_reset_n)     
    );


  //---------------------------------------------------------------------------
  // Apply the Q channel outer fence and the quiescence-enforcer fence
  // to the bare interfaces before using them everywhere else
  //---------------------------------------------------------------------------

  reg    fw_hndshk_sticky_q;

  wire   fwvalid_int;
  assign fwvalid      = (outer_fence_n & (responder_fence_n | fw_hndshk_sticky_q) & fwvalid_int);
  wire   fwready_int  = (outer_fence_n & (responder_fence_n | fw_hndshk_sticky_q) & fwready);

  reg    rv_hndshk_sticky_q;

  wire   rvvalid_int  = (outer_fence_n & (initiator_fence_n | rv_hndshk_sticky_q) & rvvalid);
  wire   rvready_int;
  assign rvready      = (outer_fence_n & (initiator_fence_n | rv_hndshk_sticky_q) & rvready_int);

  wire fw_hndshk_sticky_nxt = (fwvalid_int & ~fwready_int);
  wire fw_hndshk_sticky_upd_en = 1'b1;
  always @(posedge aclk or negedge resetn_forced)
    begin : p_hndshk_sticky_fw
      if (! resetn_forced)
        fw_hndshk_sticky_q <= 1'b0;
      else if (fw_hndshk_sticky_upd_en)
        fw_hndshk_sticky_q <= fw_hndshk_sticky_nxt;
    end

  wire rv_hndshk_sticky_nxt = (rvvalid_int & ~rvready_int);
  wire rv_hndshk_sticky_upd_en = 1'b1;
  always @(posedge aclk or negedge resetn_forced)
    begin : p_hndshk_sticky_rv
      if (! resetn_forced)
        rv_hndshk_sticky_q <= 1'b0;
      else if (rv_hndshk_sticky_upd_en)
        rv_hndshk_sticky_q <= rv_hndshk_sticky_nxt;
    end


  //---------------------------------------------------------------------------
  // Signals for all the channel components to use to indicate their non-emptiness
  //---------------------------------------------------------------------------

  wire fw_chan_cactive;
  wire fw_reg_cactive;
  wire rv_chan_cactive;
  wire fwvalid_reg;

  //--------------------------------------------------------------------
  // Combine the activity indicators
  //--------------------------------------------------------------------

  // Must avoid a chan_cactive *alone* causing quiescentn to go high
  // as that would only happen in the reset phase, which we want to avoid.
  
  // Predeclared above
  //reg  initiator_quiescentn_q;
  wire initiator_quiescentn_nxt    = (// Drive high because of a new transfer
                                      (rvvalid_int & rvready_int) |
                                      // Keep high till the transfer has completely left the channel
                                      (initiator_quiescentn_q & rv_chan_cactive)
                                     );
  wire initiator_quiescentn_upd_en = (initiator_quiescentn_q | initiator_quiescentn_nxt);

  always @(posedge aclk or negedge resetn_forced)
    begin : p_initiator_quiescentn
      if (! resetn_forced)
        initiator_quiescentn_q <= 1'b0;
      else if (initiator_quiescentn_upd_en)
        initiator_quiescentn_q <= initiator_quiescentn_nxt;
    end

  // Predeclared above
  //reg  initiator_quiescent_and_stalledn_q;
  wire initiator_quiescent_and_stalledn_nxt    = (// Drive high because of a new transfer
                                                  (rvvalid_int & rvready_int) |
                                                  // The channel is not stalled
                                                  initiator_fence_n |
                                                  // Keep high till the transfer has completely left the channel
                                                  (initiator_quiescent_and_stalledn_q & rv_chan_cactive)
                                                 );
  wire initiator_quiescent_and_stalledn_upd_en = (initiator_quiescent_and_stalledn_q | initiator_quiescent_and_stalledn_nxt);

  always @(posedge aclk or negedge resetn_forced)
    begin : p_initiator_quiescent_and_stalledn
      if (! resetn_forced)
        initiator_quiescent_and_stalledn_q <= 1'b0;
      else if (initiator_quiescent_and_stalledn_upd_en)
        initiator_quiescent_and_stalledn_q <= initiator_quiescent_and_stalledn_nxt;
    end

  // Predeclared above
  //reg  responder_quiescentn_q;
  wire responder_quiescentn_nxt    = (// Drive high because of a new transfer
                                      fwvalid_reg |
                                      // Keep high till the transfer has completely left the channel
                                      (responder_quiescentn_q & (fw_chan_cactive | fw_reg_cactive))
                                     );
  wire responder_quiescentn_upd_en = (responder_quiescentn_q | responder_quiescentn_nxt);

  always @(posedge aclk or negedge resetn_forced)
    begin : p_responder_quiescentn
      if (! resetn_forced)
        responder_quiescentn_q <= 1'b0;
      else if (responder_quiescentn_upd_en)
        responder_quiescentn_q <= responder_quiescentn_nxt;
    end

  // Predeclared above
  //reg  responder_quiescent_and_stalledn_q;
  wire responder_quiescent_and_stalledn_nxt    = (// Drive high because of a new transfer
                                                  fwvalid_reg |
                                                  // The channel is not stalled
                                                  responder_fence_n |
                                                  // Keep high till the transfer has completely left the channel
                                                  (responder_quiescent_and_stalledn_q & (fw_chan_cactive | fw_reg_cactive))
                                                 );
  wire responder_quiescent_and_stalledn_upd_en = (responder_quiescent_and_stalledn_q | responder_quiescent_and_stalledn_nxt);

  always @(posedge aclk or negedge resetn_forced)
    begin : p_responder_quiescent_and_stalledn
      if (! resetn_forced)
        responder_quiescent_and_stalledn_q <= 1'b0;
      else if (responder_quiescent_and_stalledn_upd_en)
        responder_quiescent_and_stalledn_q <= responder_quiescent_and_stalledn_nxt;
    end


  //--------------------------------------------------------------------
  // The upstream and downstream channel half instances.
  //--------------------------------------------------------------------

  // FW channel

  // Predeclared above
  //wire                            fwvalid_reg;
  wire                            fwready_reg;
  wire [((FW_PAYLOAD_WIDTH>0)?(FW_PAYLOAD_WIDTH-1):0):0]     fw_payld_reg;

  wire fwvalid_chan;
  assign fwvalid_reg = (fwvalid_chan & inner_fence_n);

  assign wakeup_local = (fwvalid_reg | fwvalid_int);

  adb400_r3_dnstrm_payld_1d
    #(
      .WIDTH            (FW_PAYLOAD_WIDTH),
      .DEPTH            (FW_FIFO_DEPTH),
      .SYNC_LEVELS      (SYNC_LEVELS),
      .CACTIVE_OUTPUT   (1)
    )
  u_dnstrm_fw
    (
      .aclk      (aclk),
      .aresetn   (resetn_forced),
      .cactive   (fw_chan_cactive),

      .dst_valid (fwvalid_chan),
      .dst_ready (fwready_reg),
      .dst_payld (fw_payld_reg),
           .rd_ptr_sync (fw_rd_ptr_sync),     
      .wr_ptr_async    (fw_wr_ptr_async),
      .rd_ptr_async    (fw_rd_ptr_async),
      .payld_async     (fw_payld_async)
    );

  generate
    if ((FW_OPREG==0) || (FW_PAYLOAD_WIDTH==0))
      begin : g_no_fw_opreg
        assign fwvalid_int = fwvalid_reg;
        assign fwready_reg = fwready_int;
        assign fw_payld    = fw_payld_reg;

        assign fw_reg_cactive = 1'b0;
      end
    else
      begin : g_fw_opreg
        assign fw_reg_cactive = fwvalid_int;

        adb400_r3_ful_regd_slice
          #(.PAYLD_WIDTH(FW_PAYLOAD_WIDTH))
        u_fw_opreg
          (
           .aclk      (aclk),
           .aresetn   (resetn_forced),
           .valid_src (fwvalid_reg),
           .ready_src (fwready_reg),
           .payld_src (fw_payld_reg),
           .valid_dst (fwvalid_int),
           .ready_dst (fwready_int),
           .payld_dst (fw_payld)
          );
      end
  endgenerate

  // RV channel

  adb400_r3_upstrm_payld_1d
    #(
      .WIDTH            (RV_PAYLOAD_WIDTH),
      .DEPTH            (RV_FIFO_DEPTH),
      .SYNC_LEVELS      (SYNC_LEVELS),
      .CACTIVE_OUTPUT   (1)
    )
  u_upstrm_rv
    (
      .aclk      (aclk),
      .aresetn   (resetn_forced),
      .cactive   (rv_chan_cactive),
  
      .src_valid (rvvalid_int),
      .src_ready (rvready_int),
      .src_payld (rv_payld),
           .rd_ptr_sync (rv_rd_ptr_sync),     
      .wr_ptr_async    (rv_wr_ptr_async),
      .rd_ptr_async    (rv_rd_ptr_async),
      .payld_async     (rv_payld_async)
    );


endmodule
