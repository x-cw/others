//-----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited or its affiliates.
//
// (C) COPYRIGHT 2015-2016 ARM Limited or its affiliates.
// ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited or its affiliates.
//
// Checked In :  2016-02-10 15:33:14 +0000 (Wed, 10 Feb 2016)
// Revision : 206653
//
// Release Information : PL405-r3p0-00eac0
//
//-----------------------------------------------------------------------------
// Verilog-2001 (IEEE Std 1364-2001)
//-----------------------------------------------------------------------------
// File: mas_axi_vir.v
//-----------------------------------------------------------------------------
// Purpose : monitor and stall for axi virtual transction
//-----------------------------------------------------------------------------


module dummy_adb_axi5
  #(parameter
      ADDR_WIDTH          = 40,
      DATA_WIDTH          = 128,
      ID_WIDTH          = 4,
      USER_WIDTH        = 4,
      LEN_WIDTH           = 4  ,     
      MAX_RD              = 255,
      MAX_WR              = 255

  )
  (
    // Configuration inputs

    input  wire                 pwrq_permit_deny_sar_i,

    // Global signals
    input  wire                      aclk,
    input  wire                      aresetn,
    //input  wire                      force_vf_reset,// add
    input  wire                      dft_test_mode,

    // Power state control
    input  wire                      pwrqreqn_i,
    output wire                      pwrqacceptn_o,
    output wire                      pwrqdeny_o,


    // Power requirement
    output wire                      pwrqactive_o,

    // upstream
    // AW channel signalling
      input wire                      awvalids,
      output wire                      awreadys,
      input wire [((USER_WIDTH>0)?(USER_WIDTH-1):0):0] awusers,
      input wire [((ID_WIDTH>0)?(ID_WIDTH-1):0):0] awids,
      input wire [ADDR_WIDTH-1:0]     awaddrs,
      input wire [3:0]                awregions,
      input wire [LEN_WIDTH-1:0]                awlens,
      input wire [2:0]                awsizes,
      input wire [1:0]                awbursts,
      input wire                      awlocks,
      input wire [3:0]                awcaches,
      input wire [2:0]                awprots,
      input wire [3:0]                awqoss,
      input wire [5:0]                awatops,
    // W channel signalling
      input wire                      wvalids,
      output wire                      wreadys,
      input wire [((USER_WIDTH>0)?(USER_WIDTH-1):0):0] wusers,
      input wire [DATA_WIDTH-1:0]     wdatas,
      input wire [(DATA_WIDTH/8)-1:0] wstrbs,
      input wire                      wlasts,

    // B channel signalling
     output wire                      bvalids,
     input wire                      breadys,
     output wire [((USER_WIDTH>0)?(USER_WIDTH-1):0):0] busers,
     output wire [((ID_WIDTH>0)?(ID_WIDTH-1):0):0] bids,
     output wire [1:0]                bresps,

    // AR channel signalling
      input wire                      arvalids,
      output wire                      arreadys,
      input wire [((USER_WIDTH>0)?(USER_WIDTH-1):0):0] arusers,
      input wire [((ID_WIDTH>0)?(ID_WIDTH-1):0):0] arids,
      input wire [ADDR_WIDTH-1:0]     araddrs,
      input wire [3:0]                arregions,
      input wire [LEN_WIDTH-1:0]                arlens,
      input wire [2:0]                arsizes,
      input wire [1:0]                arbursts,
      input wire                      arlocks,
      input wire [3:0]                arcaches,
      input wire [2:0]                arprots,
      input wire [3:0]                arqoss,

    // R channel signalling
     output wire                      rvalids,
     input wire                      rreadys,
     output wire [((USER_WIDTH>0)?(USER_WIDTH-1):0):0] rusers,
     output wire [((ID_WIDTH>0)?(ID_WIDTH-1):0):0] rids,
     output wire [DATA_WIDTH-1:0]     rdatas,
     output wire [1:0]                rresps,
     output wire                      rlasts,







    // Debug signalling
    input  wire                      dftrstdisable
  );

  localparam AW_VN = 0;
  localparam AR_VN = 0;


  localparam SYNC_LEVELS      = 2;


`include "adb400_r3_functions.v"



  localparam CD_FIFO_DEPTH =0;
  localparam AC_FIFO_DEPTH =0;

  localparam AW_FIFO_DEPTH =4;
  localparam W_FIFO_DEPTH  =6; 
  localparam AR_FIFO_DEPTH =4;

  //localparam MAX_RD              = 511;
  //localparam MAX_WR              = 255;
  localparam MAX_SN              = 255;


   localparam AW_QVN_DEPTH        = AW_FIFO_DEPTH; // Only used if AW_VN>0
   localparam W_QVN_DEPTH         = W_FIFO_DEPTH;  // Only used if AW_VN>0
   localparam AR_QVN_DEPTH        = AR_FIFO_DEPTH; // Only used if AR_VN>0



  localparam PROTOCOL_CHANNELS = ((CD_FIFO_DEPTH==0)?((AC_FIFO_DEPTH==0)?5:7):10);


  // ----------------------------------------------------------------------
  // Some limits on types of transactions from the ACE Specification
  // ----------------------------------------------------------------------

  // Maximum number of barriers
  localparam MAX_BARRIERS          = 256; // From the ACE spec C8.4.1

  // Maximum number of parts in a multipart DVM message
  localparam MAX_MULTIPART_DVM_PARTS = 2; // Not specified, but implied

  // ----------------------------------------------------------------------
  // Some minimum values for the max-OT limits required for forward progress
  // ----------------------------------------------------------------------

  // In an ACE variant, we must permit >MAX_BARRIERS writes to be
  // outstanding so AW->X counters must be sized to cope with that.
  // Because the registering in the code means it si not possible to achieve
  // the maximum number unless the last two are back-to-back, make this +2 instead of +1
  localparam MIN_WR_OT_COUNT = ((PROTOCOL_CHANNELS<10) ? 1 : (MAX_BARRIERS+2));

  // In an ACE variant, it is possible (but wrong) that a master needs to
  // have issued all MAX_BARRIER_COUNT AR barriers before it issues the 
  // MAX_BARRIER_COUNT'th AW barrier, ahead of its post-max-barriers WB.
  //
  // An ACE-Lite+DVM slave (e.g. an interconnect) might require all parts of
  // a multipart DVM before it can give any response
  localparam MIN_RD_OT_COUNT = ((PROTOCOL_CHANNELS<10) ? ((PROTOCOL_CHANNELS<7) ? 1 : MAX_MULTIPART_DVM_PARTS) : (MAX_BARRIERS+2));

  // An ACE-Lite+DVM master might require all parts of amultipart DVM before
  // it can give any response.
  localparam MIN_SN_OT_COUNT = MAX_MULTIPART_DVM_PARTS;

  // ----------------------------------------------------------------------
  // Resultant counter widths
  // ----------------------------------------------------------------------

  // Work out the maximum of the architecturally-required value and the specified
  // value, find the width required for that, and then get that width's maximum

  localparam WR_OT_WIDTH = clogb2((MIN_WR_OT_COUNT>MAX_WR) ? MIN_WR_OT_COUNT : MAX_WR);
  localparam RD_OT_WIDTH = clogb2((MIN_RD_OT_COUNT>MAX_RD) ? MIN_RD_OT_COUNT : MAX_RD);
  localparam SN_OT_WIDTH = clogb2((MIN_SN_OT_COUNT>MAX_SN) ? MIN_SN_OT_COUNT : MAX_SN);


    // downstream
    // AW channel signalling
    wire                      awvalidm;
    wire                      awreadym;
    wire  [5:0]                awatopm;
    wire [((ID_WIDTH>0)?(ID_WIDTH-1):0):0] awidm;
    wire [LEN_WIDTH-1:0]                awlenm;

    // W channel signalling
    wire                      wvalidm;
     wire                      wreadym;
    wire                      wlastm;

    // B channel signalling
     wire                      bvalidm;
    wire                      breadym;
    wire [((USER_WIDTH>0)?(USER_WIDTH-1):0):0] buserm;
    wire [((ID_WIDTH>0)?(ID_WIDTH-1):0):0] bidm;
    wire [1:0]                brespm;

    // AR channel signalling
    wire                      arvalidm;
     wire                      arreadym;
    wire [((ID_WIDTH>0)?(ID_WIDTH-1):0):0] aridm;
    wire [LEN_WIDTH-1:0]                arlenm;
    // R channel signalling
     wire                      rvalidm;
    wire                      rreadym;
    wire [((USER_WIDTH>0)?(USER_WIDTH-1):0):0] ruserm;
    wire [((ID_WIDTH>0)?(ID_WIDTH-1):0):0] ridm;
    wire [DATA_WIDTH-1:0]     rdatam;
    wire [1:0]                rrespm;
    wire                      rlastm;


  // ----------------------------------------------------------------------------
  // Reset Synchroniser
  // ----------------------------------------------------------------------------

  wire internal_reset_n;
  wire aresetn_ss;



  adb400_r3_syncn
    #(
      .LEVELS           (SYNC_LEVELS)
    )
    u_syncn_aresetn
    (
      .aclk    (aclk),
      .aresetn (aresetn),
      .din     (1'b1),
      .dout    (aresetn_ss)
    );

  wire resetn_unforced = dft_test_mode ? aresetn: (dftrstdisable | aresetn_ss);
  wire resetn_forced   = dft_test_mode ? aresetn: (dftrstdisable | (aresetn_ss & internal_reset_n)); // to reset upstrm , dnstrm or slice in non-vf









  // ----------------------------------------------------------------------------
  // pwr and clk status machine, fence and stall logic
  // ----------------------------------------------------------------------------

  wire  stall_aw_n;
  wire  stall_w_n;
  wire  stall_b_n;
  wire  stall_ar_n;
  wire  stall_ac_n;
  // Register static configuration input
 // wire pwrq_permit_deny;
// 
//  adb400_r3_sar
//    #(.WIDTH(1))
//  u_sar_pwrq_permit_deny
//    (
//      .aclk     (aclk),
//      .aresetn  (resetn_unforced),
//      .sample_i (pwrq_permit_deny_sar_i),
//      .sample_o (pwrq_permit_deny)
//    );

 // wire wakeup_local;

  wire read_write_quiescent;
  wire snoop_quiescent;
  wire ar_dvm_multipart_quiescent;
  wire ac_dvm_multipart_quiescent;
  wire dvm_sync_complete_quiescent;
  wire read_write_quiescent_and_stalled;
  wire snoop_quiescent_and_stalled;

  wire initiator_fence_n;
  wire responder_fence_n;
  wire inner_fence_n;
  wire outer_fence_n;

  dummy_adb_st_ctrl
    #(
      .SYNC_LEVELS (SYNC_LEVELS)
    )
  u_st_ctrl
    (
      .aclk                   (aclk),
      .aresetn                (resetn_unforced),

      .pwrq_permit_deny_i     (pwrq_permit_deny_sar_i),

      .clkqreqn_i             (1'b1),
      .clkqacceptn_o          (),
      .clkqdeny_o             (),
      .clkqactive_o           (),
      .pwrqreqn_i             (pwrqreqn_i),
      .pwrqacceptn_o          (pwrqacceptn_o),
      .pwrqdeny_o             (pwrqdeny_o),
      .pwrqactive_o           (pwrqactive_o),

      .wakeup_i               (1'b0),
      .wakeup_o               (),
      .wakeup_sync_i          (1'b0),

      //.slvmustacceptreqn_o    (),
      //.slvcandenyreqn_o       (),
      //.slvacceptn_async_i     (slvacceptn_async),
      //.slvdeny_async_i        (slvdeny_async),

      //.wakeup_async_o         (si_to_mi_wakeup_async),
      //.wakeup_async_i         (mi_to_si_wakeup_async),

      .ar_dvm_multipart_quiescent_i  (1'b1),
      .ac_dvm_multipart_quiescent_i  (1'b1),
      .dvm_sync_complete_quiescent_i (1'b1),
      .initiator_quiescent_i  (read_write_quiescent),
      .responder_quiescent_i  (snoop_quiescent),
      .initiator_quiescent_and_stalled_i (read_write_quiescent_and_stalled),
      .responder_quiescent_and_stalled_i (snoop_quiescent_and_stalled),

      .initiator_fencen_o     (initiator_fence_n),   
      .responder_fencen_o     (responder_fence_n),   
      .inner_fencen_o         (inner_fence_n),       
      .outer_fencen_o         (outer_fence_n),       
      .internal_resetn_o      (internal_reset_n)     
    );



    

 // ------------------fence and stall output-------------------------
    
  assign   awvalidm        =  ( (outer_fence_n &  stall_aw_n ) & awvalids);
  assign   awreadys        = (outer_fence_n & ( stall_aw_n ) & awreadym);
  assign   awidm           = awids    ;
  assign   awlenm          = awlens   ;
  assign   awatopm         = awatops  ;


  assign   wvalidm         =  ( (outer_fence_n & stall_w_n  )  & wvalids);
  assign   wreadys         = ( (outer_fence_n & stall_w_n  )   & wreadym);
  assign   wlastm          = wlasts;

  assign   bvalids         =  ( (outer_fence_n & stall_b_n ) & bvalidm);
  assign   breadym         =  ( (outer_fence_n & stall_b_n ) & breadys);
  assign   busers          = buserm;
  assign   bids            = bidm  ;
  assign   bresps          = brespm;

  assign   arvalidm        =  ( (outer_fence_n & stall_ar_n ) & arvalids);
  assign   arreadys        =  ( (outer_fence_n & stall_ar_n ) & arreadym);
  assign   aridm           = arids    ;
  assign   arlenm          = arlens   ;

  assign   rvalids         =  ( outer_fence_n  & rvalidm);
  assign   rreadym         =  ( outer_fence_n  & rreadys);
  assign   rusers          = ruserm;
  assign   rids            = ridm  ;
  assign   rdatas          = rdatam;
  assign   rresps          = rrespm ;
  assign   rlasts          = rlastm;


  // ----------------------------------------------------------------------------
  // axi transction detect logic
  // ----------------------------------------------------------------------------







  adb_protocol_quiescent_dummy_axi5
    #(
      .PROTOCOL_CHANNELS (PROTOCOL_CHANNELS),
      .AR_VN             (AR_VN),
      .AW_VN             (AW_VN),
      .AR_QVN_DEPTH      (AR_QVN_DEPTH),
      .AW_QVN_DEPTH      (AW_QVN_DEPTH),
      .W_QVN_DEPTH       (W_QVN_DEPTH),
      .RD_OT_WIDTH       (RD_OT_WIDTH),
      .WR_OT_WIDTH       (WR_OT_WIDTH),
      .SN_OT_WIDTH       (SN_OT_WIDTH)
    )
  u_protocol_quiescent_axi5
    (
      .aclk    (aclk),
      .aresetn (resetn_forced),

      .dvm_sync_complete_quiescent_o (),
      .read_write_quiescent_o (read_write_quiescent),
      .snoop_quiescent_o      (snoop_quiescent),
      .read_write_quiescent_and_stalled_o (read_write_quiescent_and_stalled),
      .snoop_quiescent_and_stalled_o (snoop_quiescent_and_stalled),

      .force_read_write_quiescence_n_i (initiator_fence_n),
      .force_snoop_quiescence_n_i      (responder_fence_n),
      .stall_ar_n_o           (stall_ar_n),
      .stall_aw_n_o           (stall_aw_n),
      .stall_w_n_o            (stall_w_n),
      .stall_b_n_o            (stall_b_n),
      .stall_ac_n_o           (stall_ac_n),

      .arvalid_i              (arvalidm),
      .arready_i              (arreadym),
      .rvalid_i               (rvalidm),
      .rready_i               (rreadym),
      .rlast_i                (rlastm),
      .awvalid_i              (awvalidm),
      .awready_i              (awreadym),
      .awatop_i               (awatopm),
      .awbar_i                (1'b0),
      .wvalid_i               (wvalidm),
      .wready_i               (wreadym),
      .wlast_i                (wlastm),
      .bvalid_i               (bvalidm),
      .bready_i               (breadym),
      .ar_dvm_sync_i          (1'b0),
      .ar_dvm_complete_i      (1'b0),
      .acvalid_i              (1'b0),
      .acready_i              (1'b0),
      .ac_dvm_sync_i          (1'b0),
      .ac_dvm_complete_i      (1'b0),
      .crvalid_i              (1'b0),
      .crready_i              (1'b0),
      .aw_evict_i             (1'b0),
      .cr_pass_data_i         (1'b0),
      .cdvalid_i              (1'b0),
      .cdready_i              (1'b0),
      .cdlast_i               (1'b0),
      .rack_i                 (1'b0),
      .wack_i                 (1'b0),
      .arbar_i                (1'b0),
      .varvalid_i             (1'b0),
      .varready_i             (1'b0),
      .arvnpid_i              (1'b0),
      .vawvalid_i             (1'b0),
      .vawready_i             (1'b0),
      .awvnpid_i              (1'b0),
      .vwvalid_i              (1'b0),
      .vwready_i              (1'b0),
      .wvnpid_i               (1'b0),
      .stall_var_n_o          (),
      .stall_vaw_n_o          (),
      .stall_vw_n_o           ()
    );










  wire awvalidm_t;
  reg awreadym_t;
  wire [ID_WIDTH-1:0] awidm_t;
  wire [LEN_WIDTH-1:0] awlenm_t;

  wire wvalidm_t;
  reg wreadym_t;
  wire wlastm_t;

  reg bvalidm_t;
  wire breadym_t;
  reg [ID_WIDTH-1:0] bidm_t;
  wire [1:0] brespm_t;
  wire [USER_WIDTH-1:0] buserm_t;

  wire arvalidm_t;
  reg arreadym_t;
  wire [ID_WIDTH-1:0] aridm_t;
  wire [LEN_WIDTH-1:0] arlenm_t;

  reg rvalidm_t;
  wire rreadym_t;
  wire rlastm_t;
  reg [ID_WIDTH-1:0] ridm_t;
  wire [1:0] rrespm_t;
  wire [USER_WIDTH-1:0] ruserm_t;
  wire [DATA_WIDTH-1:0] rdatam_t;



  //-----------------------------------------------------
  //-----------------------------------------------------
  // axi atomic process logic
  //-----------------------------------------------------
  //-----------------------------------------------------

  wire [ID_WIDTH-1:0]aridm_at;
  wire [LEN_WIDTH-1:0]arlenm_at;
  wire arvalidm_at;

  
  // copy aw_atomic
  assign arvalidm_at = awvalidm  & awatopm[5];
  assign aridm_at =  (awvalidm & awatopm[5]) ? awidm : {ID_WIDTH{1'b0}} ;
  assign arlenm_at = (awvalidm & awatopm[5] & awatopm[4] & awatopm[0]) ? (awlenm >>1) : ( (awvalidm & awatopm[5]) ? awlenm : {LEN_WIDTH{1'b0}} );


  wire aw_atomic_start;
  assign aw_atomic_start = arvalidm_at & awreadym;

  // aw_atomic and ar is coming at the same timing, arbitrate to aw_atomic
  wire ar_aw_is_conflict;
  assign ar_aw_is_conflict = aw_atomic_start  & arvalidm & arreadym;


  //------------------------- atomic ar---------------------------

  // register atomic arid 
  reg [ID_WIDTH-1:0]aridm_at_r;
  always @(posedge aclk or negedge resetn_forced)
  if (! resetn_forced)
    aridm_at_r <= {ID_WIDTH{1'b0}};  
  else if (aw_atomic_start )
    aridm_at_r <= aridm_at;

  // register atomic arlen 
  reg  [LEN_WIDTH-1:0] arlenm_at_r;
  always @(posedge aclk or negedge resetn_forced)
  if (! resetn_forced)
    arlenm_at_r <= {LEN_WIDTH{1'b0}};
  else if (aw_atomic_start )
    arlenm_at_r <= arlenm_at;


  reg arvalidm_at_r;
  always @(posedge aclk or negedge resetn_forced)
  if (! resetn_forced)
    arvalidm_at_r<=1'b0;
  else if (aw_atomic_start)
    arvalidm_at_r <=1'b1;
  else if ( arreadym_t)
    arvalidm_at_r <= 1'b0;



  reg send_ar_at;
  always @(posedge aclk or negedge resetn_forced)
  if (! resetn_forced)
   send_ar_at  <=1'b0;
  else if ( arvalidm_at_r & arreadym_t)
   send_ar_at  <=1'b1;
  else if (rvalidm & rreadym & rlastm )
   send_ar_at  <=1'b0; 


 wire doing_atomic;
 assign doing_atomic =  send_ar_at | arvalidm_at_r;




  reg doing_atomic_r;
  always @(posedge aclk or negedge resetn_forced)
  if (! resetn_forced)
   doing_atomic_r  <=1'b0;
  else 
   doing_atomic_r<=doing_atomic;





  //------------------------- conflict no-atomic ar---------------------------

  wire send_ar_cf_nat_end;

  reg processing_conflict;
  always @(posedge aclk or negedge resetn_forced)
  if (! resetn_forced)
    processing_conflict <= 1'b0;
  else if (ar_aw_is_conflict )
    processing_conflict <= 1'b1;
  else if (send_ar_cf_nat_end)
    processing_conflict <= 1'b0;


  wire start_send_ar_cf_nat;
  assign start_send_ar_cf_nat = processing_conflict & ~doing_atomic & doing_atomic_r;





  // register conflict no-atomic arid 
  reg [ID_WIDTH-1:0]aridm_cf_nat;
  always @(posedge aclk or negedge resetn_forced)
  if (! resetn_forced)
    aridm_cf_nat <= {ID_WIDTH{1'b0}};  
  else if (ar_aw_is_conflict )
    aridm_cf_nat <= aridm;

  // register conflict no-atomic arlen 
  reg  [LEN_WIDTH-1:0] arlenm_cf_nat;
  always @(posedge aclk or negedge resetn_forced)
  if (! resetn_forced)
    arlenm_cf_nat <= {LEN_WIDTH{1'b0}};
  else if (ar_aw_is_conflict )
    arlenm_cf_nat <= arlenm;


  reg arvalidm_cf_nat;
  always @(posedge aclk or negedge resetn_forced)
  if (! resetn_forced)
    arvalidm_cf_nat<=1'b0;
  else if (start_send_ar_cf_nat)
    arvalidm_cf_nat <=1'b1;
  else if ( arreadym_t)
    arvalidm_cf_nat <= 1'b0;


 // reg arvalidm_n;
 // wire arvalidm_n_nxt;
 // always @(posedge aclk or negedge resetn_forced)
 // if (! resetn_forced)
 //   arvalidm_n<=1'b0;
 // else 
 //   arvalidm_n <= arvalidm_n_nxt;

 // assign  arvalidm_n_nxt = start_send_ar_rp_n ? ~arreadym_t  : arvalidm_n & ~arreadym_t;

  reg send_ar_cf_nat;
  always @(posedge aclk or negedge resetn_forced)
  if (! resetn_forced)
    send_ar_cf_nat <= 1'b0;
  else if (arvalidm_cf_nat & arreadym_t)
    send_ar_cf_nat <= 1'b1;
  else if (rvalidm & rreadym & rlastm )
    send_ar_cf_nat <= 1'b0;

  wire doing_ar_cf_nat;
 assign doing_ar_cf_nat = send_ar_cf_nat | start_send_ar_cf_nat | arvalidm_cf_nat ;

 assign send_ar_cf_nat_end = rvalidm & rreadym & rlastm & send_ar_cf_nat;


  //------------------------- no-conflict and no-atomic ar---------------------------
  wire atomic_fence_aw_n;
  wire atomic_fence_ar_n;
  assign atomic_fence_aw_n = ~ doing_ar_cf_nat & ~doing_atomic ;
  assign atomic_fence_ar_n = ~ doing_ar_cf_nat & ~doing_atomic ;

  wire  arvalidm_ncf_nat;
  assign arvalidm_ncf_nat = arvalidm & atomic_fence_ar_n & ~aw_atomic_start;






  //------------------------- to error respond logic---------------------------

  assign arvalidm_t = arvalidm_at_r  | arvalidm_cf_nat | arvalidm_ncf_nat;
  assign arreadym   =  arreadym_t & atomic_fence_ar_n;
  assign aridm_t    = (doing_atomic) ? aridm_at_r : ( ({ID_WIDTH{arvalidm_at_r}} & aridm_at_r) | ({ID_WIDTH{arvalidm_ncf_nat}} & aridm) | ({ID_WIDTH{arvalidm_cf_nat}} & aridm_cf_nat) );
  assign arlenm_t   = (doing_atomic) ? arlenm_at_r : ( ({LEN_WIDTH{arvalidm_at_r}} & arlenm_at_r) | ({LEN_WIDTH{arvalidm_ncf_nat}} & arlenm) | ({LEN_WIDTH{arvalidm_cf_nat}} & arlenm_cf_nat) );


  assign rvalidm = rvalidm_t ;
  assign rreadym_t = rreadym ;
  assign rlastm = rlastm_t ;
  assign ridm    = ridm_t    ;
  assign rrespm  = rrespm_t  ;
  assign ruserm  = ruserm_t  ;
  assign rdatam  = rdatam_t  ;



  assign awvalidm_t = awvalidm &  atomic_fence_aw_n;
  assign awreadym   = awreadym_t & atomic_fence_aw_n;
  assign awidm_t    = awidm;
  assign awlenm_t   = awlenm;

  assign wvalidm_t = wvalidm ;
  assign wreadym   = wreadym_t ;
  assign wlastm_t  = wlastm  ;

  assign bvalidm = bvalidm_t;
  assign breadym_t = breadym;
  assign bidm    = bidm_t   ;
  assign brespm  = brespm_t ;
  assign buserm  = buserm_t ;









  //-----------------------------------------------------
  //-----------------------------------------------------
  // axi error respond ctrl logic
  //-----------------------------------------------------
  //-----------------------------------------------------

  
  //------------------- aw ~ b--------------------------

  // ensure aw leading w
  always @(posedge aclk or negedge resetn_forced)
  if (! resetn_forced)
   wreadym_t  <=1'b0;
  else if (awvalidm_t & awreadym_t)
   wreadym_t  <=1'b1;
  else if (wvalidm_t & wlastm_t)
   wreadym_t  <=1'b0;

  // unsupport outstanding 
  always @(posedge aclk or negedge resetn_forced)
  if (! resetn_forced)
   awreadym_t  <=1'b1;
  else if (bvalidm_t & breadym_t)
   awreadym_t  <=1'b1; 
  else if (awvalidm_t)
   awreadym_t  <=1'b0;


  // register awid 
  always @(posedge aclk or negedge resetn_forced)
  if (! resetn_forced)
    bidm_t <= {ID_WIDTH{1'b0}};
  else if (awvalidm_t & awreadym_t)
    bidm_t <= awidm_t;

  // output b channel
  always @(posedge aclk or negedge resetn_forced)
  if (! resetn_forced)
    bvalidm_t <= 1'b0;
  else if (wvalidm_t & wreadym_t & wlastm_t)
    bvalidm_t <= 1'b1;
  else if (breadym_t)
    bvalidm_t <= 1'b0;



  assign brespm_t = (bvalidm_t ) ? 2'd3 : 2'd0;

  assign buserm_t = {USER_WIDTH{1'b0}};






  //------------------- ar ~ r--------------------------

  // unsupport outstanding 
  always @(posedge aclk or negedge resetn_forced)
  if (! resetn_forced)
   arreadym_t  <=1'b1;
  else if (rvalidm_t & rreadym_t & rlastm_t )
   arreadym_t  <=1'b1; 
  else if (arvalidm_t)
   arreadym_t  <=1'b0;


  // register arid 
  always @(posedge aclk or negedge resetn_forced)
  if (! resetn_forced)
    ridm_t <= {ID_WIDTH{1'b0}};
  else if (arvalidm_t & arreadym_t)
    ridm_t <= aridm_t;

  // register arlen 
  reg  [LEN_WIDTH-1:0] arlenm_t_r;
  always @(posedge aclk or negedge resetn_forced)
  if (! resetn_forced)
    arlenm_t_r <= {LEN_WIDTH{1'b0}};
  else if (arvalidm_t & arreadym_t)
    arlenm_t_r <= arlenm_t;


  // rsp r num counter
  reg [LEN_WIDTH-1:0] count_r;
  always @(posedge aclk or negedge resetn_forced)
  if (! resetn_forced)
    count_r <= {LEN_WIDTH{1'b0}};
  else if( (count_r >= arlenm_t_r) & rvalidm_t & rreadym_t )
    count_r <= {LEN_WIDTH{1'b0}};
  else if(rvalidm_t & rreadym_t)
    count_r <= count_r + 1'b1;

  // output r channel
  always @(posedge aclk or negedge resetn_forced)
  if (! resetn_forced)
    rvalidm_t <= 1'b0;
  else if (arvalidm_t & arreadym_t)
    rvalidm_t <= 1'b1;
  else if ((count_r >= arlenm_t_r) & rreadym_t )  
    rvalidm_t <= 1'b0;

  reg rlastm_r;
  always @(posedge aclk or negedge resetn_forced)
  if (! resetn_forced)
    rlastm_r <= 1'b0;
  else if (rvalidm_t & rreadym_t & (count_r == arlenm_t_r-1))
    rlastm_r <= 1'b1;
  else  if (rreadym_t)
    rlastm_r <= 1'b0;

  assign rlastm_t = (arlenm_t_r=={LEN_WIDTH{1'b0}})? rvalidm_t   : rlastm_r;

  assign rrespm_t = (rvalidm_t ) ? 2'd3 : 2'd0;

  assign ruserm_t = {USER_WIDTH{1'b0}};
  assign rdatam_t = {DATA_WIDTH{1'b0}};











endmodule
