//-----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited or its affiliates.
//
// (C) COPYRIGHT 2015-2016 ARM Limited or its affiliates.
// ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited or its affiliates.
//
// Checked In :  2016-02-07 15:48:44 +0000 (Sun, 07 Feb 2016)
// Revision : 206511
//
// Release Information : PL405-r3p0-00eac0
//
//-----------------------------------------------------------------------------
// Verilog-2001 (IEEE Std 1364-2001)
//-----------------------------------------------------------------------------
// File: adb400_r3_bas_slv.v
//-----------------------------------------------------------------------------
// Purpose : Slave side of bridge with bi-directional AXI4-Stream interfaces.
//-----------------------------------------------------------------------------

module adb400_r3_apb_slv
  #(parameter

      ADDR_WIDTH        = 32, 
      DATA_WIDTH        = 32, 
      USER_WIDTH        = 10, 
      FW_FIFO_DEPTH     = 6,
      RV_FIFO_DEPTH     = 6 


  )
  (
    // Configuration inputs
    input  wire                                             pwrq_permit_deny_sar_i,

    // Power state control
    input  wire                                             pwrqreqns_i,
    output wire                                             pwrqacceptns_o,
    output wire                                             pwrqdenys_o,

    //
    // Synchronous interfaces
    //

    // Global signals
    input  wire                                             pclks,
    input  wire                                             presetns,
    input  wire                                             dftrstdisables,

    input  wire                                             dft_test_mode,


    // Power requirement
    output wire                                             pwrqactives_o,



    // APB3
    input  wire                                             psels,
    input  wire                                             penables,
    input  wire                                             pwrites,
    input  wire  [ADDR_WIDTH-1:0]                           paddrs,
    input  wire  [DATA_WIDTH-1:0]                           pwdatas,
    input  wire  [USER_WIDTH-1:0]                           pusers,
    output  wire                                            preadys,
    output  wire [DATA_WIDTH-1:0]                           prdatas,
    output  wire                                            pslverrs,

    // debug
    output wire  [31:0]                                     adb_debug_monitor_o,


    // Async interfaces 

    output wire                                             slvmustacceptreqn_async,
    output wire                                             slvcandenyreqn_async,
    input  wire                                             slvacceptn_async,
    input  wire                                             slvdeny_async,

    output wire                                             si_to_mi_wakeup_async,
    input  wire                                             mi_to_si_wakeup_async,

    // add
    input wire [FW_FIFO_DEPTH-1:0]fw_rd_ptr_sync,
    output wire [RV_FIFO_DEPTH-1:0]rv_rd_ptr_sync,  

    output wire [FW_FIFO_DEPTH-1:0]                         fw_wr_ptr_async,
    input  wire [FW_FIFO_DEPTH-1:0]                         fw_rd_ptr_async,
    output wire [(DATA_WIDTH + ADDR_WIDTH + USER_WIDTH + 1)-1:0]                                     fw_payld_async,

    input  wire [RV_FIFO_DEPTH-1:0]                         rv_wr_ptr_async,
    output wire [RV_FIFO_DEPTH-1:0]                         rv_rd_ptr_async,
    input  wire [(DATA_WIDTH  + 1)-1:0]                                     rv_payld_async 

  );




     localparam RV_OPREG          = 1;
     localparam SI_SYNC_LEVELS    = 2;



    // Clock control
    wire                                             clkqreqns_i;
    wire                                             clkqacceptns_o;
    wire                                             clkqdenys_o;

    // Clock requirement
    wire                                             clkqactives_o;


    // Wake-up
    wire                                             wakeups_i;
    wire                                             wakeups_o;






  wire [(DATA_WIDTH + ADDR_WIDTH + USER_WIDTH + 1) -1 :0] tfwpaylds;
  wire tfwvalids;
  wire tfwreadys;

  wire [(DATA_WIDTH  + 1)-1:0] trvpaylds;
  wire trvvalids;
  wire trvreadys;



   reg write_read_en;




  wire resetn_unforced;
  assign resetn_unforced = dft_test_mode? presetns: (dftrstdisables | presetns);




    assign    clkqreqns_i =1'b1;
    assign    wakeups_i =1'b0;

   // apb to axi-stream
   assign tfwpaylds  = {paddrs,pwdatas,pusers,pwrites};

   //assign preadys = (pwrites)? tfwreadys :  trvvalids;
   assign preadys =   trvvalids;
   //assign preadys = tfwreadys ;
   //assign preadys = 1'b1;

   assign {prdatas,pslverrs}  = trvpaylds;
   //assign trvreadys = psels & penables;
   //assign trvreadys = ~pwrites;
   assign trvreadys = 1'b1;


   assign tfwvalids =  write_read_en;


   always@(posedge pclks or negedge resetn_unforced)
   if(!resetn_unforced)
     write_read_en <= 1'd0;
   else if(psels & ~penables) 
     write_read_en <= 1'b1;
   else if (tfwreadys)
     write_read_en <= 1'd0;









  adb400_r3_slv_transport_f1r1_apb
    #(
      .FW_FIFO_DEPTH       (FW_FIFO_DEPTH),
      .RV_FIFO_DEPTH       (RV_FIFO_DEPTH),
      .RV_OPREG            (RV_OPREG),
      .SYNC_LEVELS         (SI_SYNC_LEVELS),
      .FW_PAYLOAD_WIDTH    (DATA_WIDTH + ADDR_WIDTH + USER_WIDTH + 1),
      .RV_PAYLOAD_WIDTH    (DATA_WIDTH  + 1)
    )
  u_slv
    (
      .pwrq_permit_deny_sar_i  (pwrq_permit_deny_sar_i),

      .pwrqreqn_i              (pwrqreqns_i),
      .pwrqacceptn_o           (pwrqacceptns_o),
      .pwrqdeny_o              (pwrqdenys_o),

      .aclk                    (pclks),
      .aresetn                 (presetns),
      .dft_test_mode                 (dft_test_mode),
      .dftrstdisable           (dftrstdisables),

      .adb_debug_monitor_o     (adb_debug_monitor_o),

      .clkqreqn_i              (clkqreqns_i),
      .clkqacceptn_o           (clkqacceptns_o),
      .clkqdeny_o              (clkqdenys_o),
      .clkqactive_o            (clkqactives_o),
      .pwrqactive_o            (pwrqactives_o),
      .wakeup_i                (wakeups_i),
      .wakeup_o                (wakeups_o),

      .fwvalid                 (tfwvalids),
      .fwready                 (tfwreadys),
      .fw_payld                (tfwpaylds),

      .rvvalid                 (trvvalids),
      .rvready                 (trvreadys),
      .rv_payld                (trvpaylds),

      .slvmustacceptreqn_async (slvmustacceptreqn_async),
      .slvcandenyreqn_async    (slvcandenyreqn_async),
      .slvacceptn_async        (slvacceptn_async),
      .slvdeny_async           (slvdeny_async),

      .si_to_mi_wakeup_async   (si_to_mi_wakeup_async),
      .mi_to_si_wakeup_async   (mi_to_si_wakeup_async),

      .fw_rd_ptr_sync          (fw_rd_ptr_sync), 
      .rv_rd_ptr_sync          (rv_rd_ptr_sync), 

      .fw_wr_ptr_async         (fw_wr_ptr_async),
      .fw_rd_ptr_async         (fw_rd_ptr_async),
      .fw_payld_async          (fw_payld_async),
     
      .rv_wr_ptr_async         (rv_wr_ptr_async),
      .rv_rd_ptr_async         (rv_rd_ptr_async),
      .rv_payld_async          (rv_payld_async)
    );

endmodule
