//-----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited or its affiliates.
//
// (C) COPYRIGHT 2015-2016 ARM Limited or its affiliates.
// ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited or its affiliates.
//
// Checked In :  2016-02-07 15:48:44 +0000 (Sun, 07 Feb 2016)
// Revision : 206511
//
// Release Information : PL405-r3p0-00eac0
//
//-----------------------------------------------------------------------------
// Verilog-2001 (IEEE Std 1364-2001)
//-----------------------------------------------------------------------------
// File: adb400_r3_bas.v
//-----------------------------------------------------------------------------
// Purpose : Domain bridge with bi-directional AXI4-Stream interfaces.
//-----------------------------------------------------------------------------

module adb400_r3_apb_err_rsp
  #(parameter
      ADDR_WIDTH        = 32, 
      DATA_WIDTH        = 32, 
      USER_WIDTH        = 10, 


      FW_FIFO_DEPTH     = 6,
      RV_FIFO_DEPTH     = 6 

  )
  (
    //
    // 'SI' side
    //

    // Configuration inputs
    input  wire                   pwrq_permit_deny_sar_i,

    // Power state control
    input  wire                   pwrqreqns_i,
    output wire                   pwrqacceptns_o,
    output wire                   pwrqdenys_o,
    output wire                   pwrqactives_o,

    input wire                     reg_err_rsp_en,
    input wire                     ppu_st_pwron,
    // Global signals
    input  wire                   pclks,
    input  wire                   presetns,
    input  wire                   dft_test_mode,

    //debug
    output  wire   [31:0]          adb_slv_debug_monitor,
    output  wire   [31:0]          adb_mst_debug_monitor,




    // APB3
    input  wire                                             psels,
    input  wire                                             penables,
    input  wire                                             pwrites,
    input  wire  [ADDR_WIDTH-1:0]                           paddrs,
    input  wire  [DATA_WIDTH-1:0]                           pwdatas,
    input  wire  [USER_WIDTH-1:0]                           pusers,
    output  wire                                            preadys,
    output  wire [DATA_WIDTH-1:0]                           prdatas,
    output  wire                                            pslverrs,

    //
    // 'MI' side
    //

    // Global signals
    input  wire                   pclkm,
    input  wire                   presetnm,


    // Power requirement





    // APB3
    output  wire                                             pselm,
    output  wire                                             penablem,
    output  wire                                             pwritem,
    output  wire  [ADDR_WIDTH-1:0]                           paddrm,
    output  wire  [DATA_WIDTH-1:0]                           pwdatam,
    output  wire  [USER_WIDTH-1:0]                           puserm,
    input  wire                                            preadym,
    input  wire [DATA_WIDTH-1:0]                           prdatam,
    input  wire                                            pslverrm

   );

  //
  // Wires between interfaces
  //
    // add
     wire [FW_FIFO_DEPTH-1:0]fw_rd_ptr_sync;
    wire [RV_FIFO_DEPTH-1:0]rv_rd_ptr_sync;

  wire [FW_FIFO_DEPTH-1:0] fw_wr_ptr_async;
  wire [FW_FIFO_DEPTH-1:0] fw_rd_ptr_async;
  //wire [((FW_PAYLOAD_WIDTH>0)?((FW_PAYLOAD_WIDTH*FW_FIFO_DEPTH)-1):0):0] fw_payld_async;
  wire [(DATA_WIDTH + ADDR_WIDTH + USER_WIDTH + 1-1) :0] fw_payld_async;

  wire [RV_FIFO_DEPTH-1:0] rv_wr_ptr_async;
  wire [RV_FIFO_DEPTH-1:0] rv_rd_ptr_async;
  //wire [((RV_PAYLOAD_WIDTH>0)?((RV_PAYLOAD_WIDTH*RV_FIFO_DEPTH)-1):0):0] rv_payld_async;
  wire [(DATA_WIDTH + 1-1) :0] rv_payld_async;

  wire                     slvmustacceptreqn_async;
  wire                     slvcandenyreqn_async;
  wire                     slvacceptn_async;
  wire                     slvdeny_async;

  wire                     si_to_mi_wakeup_async;
  wire                     mi_to_si_wakeup_async;

  adb400_r3_apb_slv_err_rsp
    #(

      .ADDR_WIDTH        (ADDR_WIDTH), 
      .DATA_WIDTH        (DATA_WIDTH), 
      .USER_WIDTH        (USER_WIDTH), 


      .FW_FIFO_DEPTH       (FW_FIFO_DEPTH),
      .RV_FIFO_DEPTH       (RV_FIFO_DEPTH) 

    )
  u_slv
    (
      .pwrq_permit_deny_sar_i  (pwrq_permit_deny_sar_i),

      .pwrqreqns_i             (pwrqreqns_i),
      .pwrqacceptns_o          (pwrqacceptns_o),
      .pwrqdenys_o             (pwrqdenys_o),

      .pclks                   (pclks),
      .presetns                (presetns),

      .dft_test_mode                 (dft_test_mode),

      .reg_err_rsp_en         (reg_err_rsp_en),

      .adb_debug_monitor     (adb_slv_debug_monitor),


    .ppu_st_pwron            (ppu_st_pwron),
      //.clkqreqns_i             (clkqreqns_i),
      //.clkqacceptns_o          (clkqacceptns_o),
      //.clkqdenys_o             (clkqdenys_o),
      //.clkqactives_o           (clkqactives_o),
      .pwrqactives_o           (pwrqactives_o),
      //.wakeups_i               (wakeups_i),
      //.wakeups_o               (wakeups_o),

      //.tfwvalids               (tfwvalids),
      //.tfwreadys               (tfwreadys),
      //.tfwdatas                (tfwdatas),
      //.tfwstrbs                (tfwstrbs),
      //.tfwkeeps                (tfwkeeps),
      //.tfwlasts                (tfwlasts),
      //.tfwids                  (tfwids),
      //.tfwdests                (tfwdests),
      //.tfwusers                (tfwusers),

      //.trvvalids               (trvvalids),
      //.trvreadys               (trvreadys),
      //.trvdatas                (trvdatas),
      //.trvstrbs                (trvstrbs),
      //.trvkeeps                (trvkeeps),
      //.trvlasts                (trvlasts),
      //.trvids                  (trvids),
      //.trvdests                (trvdests),
      //.trvusers                (trvusers),


    .psels (psels),
    .penables (penables),
    .pwrites (pwrites),
    .paddrs (paddrs),
    .pwdatas (pwdatas),
    .pusers (pusers),
    .preadys (preadys),
    .prdatas (prdatas),
    .pslverrs (pslverrs),


      .slvmustacceptreqn_async (slvmustacceptreqn_async),
      .slvcandenyreqn_async    (slvcandenyreqn_async),
      .slvacceptn_async        (slvacceptn_async),
      .slvdeny_async           (slvdeny_async),

      .si_to_mi_wakeup_async   (si_to_mi_wakeup_async),
      .mi_to_si_wakeup_async   (mi_to_si_wakeup_async),

      .fw_rd_ptr_sync          (fw_rd_ptr_sync), 
      .rv_rd_ptr_sync          (rv_rd_ptr_sync), 


      .fw_wr_ptr_async         (fw_wr_ptr_async),
      .fw_rd_ptr_async         (fw_rd_ptr_async),
      .fw_payld_async          (fw_payld_async),
     
      .rv_wr_ptr_async         (rv_wr_ptr_async),
      .rv_rd_ptr_async         (rv_rd_ptr_async),
      .rv_payld_async          (rv_payld_async)
    );

  adb400_r3_apb_mst
    #(
      .ADDR_WIDTH        (ADDR_WIDTH), 
      .DATA_WIDTH        (DATA_WIDTH), 
      .USER_WIDTH        (USER_WIDTH), 


      .FW_FIFO_DEPTH       (FW_FIFO_DEPTH),
      .RV_FIFO_DEPTH       (RV_FIFO_DEPTH) 
    )
  u_mst
    (
      .pclkm                   (pclkm),
      .presetnm                (presetnm),

      .dft_test_mode                 (dft_test_mode),


      .adb_debug_monitor     (adb_mst_debug_monitor),

      //.clkqreqnm_i             (clkqreqnm_i),
      //.clkqacceptnm_o          (clkqacceptnm_o),
      //.clkqdenym_o             (clkqdenym_o),
      //.clkqactivem_o           (clkqactivem_o),
      //.pwrqactivem_o           (pwrqactivem_o),
      //.wakeupm_i               (wakeupm_i),
      //.wakeupm_o               (wakeupm_o),

      //.tfwvalidm               (tfwvalidm),
      //.tfwreadym               (tfwreadym),
      //.tfwdatam                (tfwdatam),
      //.tfwstrbm                (tfwstrbm),
      //.tfwkeepm                (tfwkeepm),
      //.tfwlastm                (tfwlastm),
      //.tfwidm                  (tfwidm),
      //.tfwdestm                (tfwdestm),
      //.tfwuserm                (tfwuserm),

      //.trvvalidm               (trvvalidm),
      //.trvreadym               (trvreadym),
      //.trvdatam                (trvdatam),
      //.trvstrbm                (trvstrbm),
      //.trvkeepm                (trvkeepm),
      //.trvlastm                (trvlastm),
      //.trvidm                  (trvidm),
      //.trvdestm                (trvdestm),
      //.trvuserm                (trvuserm),

    .pselm (pselm),
    .penablem (penablem),
    .pwritem (pwritem),
    .paddrm (paddrm),
    .pwdatam (pwdatam),
    .puserm (puserm),
    .preadym (preadym),
    .prdatam (prdatam),
    .pslverrm (pslverrm),

      .slvmustacceptreqn_async (slvmustacceptreqn_async),
      .slvcandenyreqn_async    (slvcandenyreqn_async),
      .slvacceptn_async        (slvacceptn_async),
      .slvdeny_async           (slvdeny_async),

      .si_to_mi_wakeup_async   (si_to_mi_wakeup_async),
      .mi_to_si_wakeup_async   (mi_to_si_wakeup_async),

      .fw_rd_ptr_sync          (fw_rd_ptr_sync), 
      .rv_rd_ptr_sync          (rv_rd_ptr_sync), 


      .fw_wr_ptr_async    (fw_wr_ptr_async),
      .fw_rd_ptr_async    (fw_rd_ptr_async),
      .fw_payld_async     (fw_payld_async),
     
      .rv_wr_ptr_async    (rv_wr_ptr_async),
      .rv_rd_ptr_async    (rv_rd_ptr_async),
      .rv_payld_async     (rv_payld_async)
    );

endmodule
