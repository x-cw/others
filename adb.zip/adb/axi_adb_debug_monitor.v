// +FHDR----------------------------------------------------------------------------
// Project Name  : IC_Design
// Author        : xucw
// Email         : xucw@innosilicon.com.cn
// Create On     : 2024/12/12 10:49
// Last Modified : 2024/12/12 10:49
// File Name     : adb_debug_monitor.v
// Description   :
// 
// Copyright (c) 2024 Innosilicon.
// ALL RIGHTS RESERVED
// 
// ---------------------------------------------------------------------------------
// Modification History:
// Date         By              Version                 Change Description
// ---------------------------------------------------------------------------------
// 2024/12/12   xucw            1.0                     Original
// 
// -FHDR----------------------------------------------------------------------------

module axi_adb_debug_monitor
  #(
    parameter       AW_FIFO_DEPTH       = 4,
                    W_FIFO_DEPTH        = 6,
                    B_FIFO_DEPTH        = 2,
                    AR_FIFO_DEPTH       = 4,
                    R_FIFO_DEPTH        = 6,
                    SYNC_LEVELS         = 2,
                    INST_IN_SLV         = 1                    

  )
(
    input             aclk,
    input             aresetn,
    
    input wire  [3:0] pwrq_ctrl_state,
    input wire        count_aw_to_wend_ez_q,
    input wire        count_aw_to_wlast_ez_q,
    input wire        count_ar_to_rend_ez_q,


    // AW channel signalling
    input wire [AW_FIFO_DEPTH-1:0] aw_wr_ptr_async,
    input  wire [AW_FIFO_DEPTH-1:0] aw_rd_ptr_async,

    // W channel signalling
    input wire [ W_FIFO_DEPTH-1:0]  w_wr_ptr_async,
    input  wire [ W_FIFO_DEPTH-1:0]  w_rd_ptr_async,

    // B channel signalling
    input  wire [ B_FIFO_DEPTH-1:0]  b_wr_ptr_async,
    input wire [ B_FIFO_DEPTH-1:0]  b_rd_ptr_async,

    // AR channel signalling
    input wire [AR_FIFO_DEPTH-1:0] ar_wr_ptr_async,
    input  wire [AR_FIFO_DEPTH-1:0] ar_rd_ptr_async,

    // R channel signalling
    input  wire [ R_FIFO_DEPTH-1:0]  r_wr_ptr_async,
    input wire [ R_FIFO_DEPTH-1:0]  r_rd_ptr_async, 

    output reg [ 32-1:0]  adb_debug_monitor_o  

);

wire [31:0] adb_debug_monitor;
wire aw_fifo_full;
wire w_fifo_full;
wire b_fifo_full;
wire ar_fifo_full;
wire r_fifo_full;
wire aw_fifo_empty;
wire w_fifo_empty;
wire b_fifo_empty;
wire ar_fifo_empty;
wire r_fifo_empty;


wire aw_ptr_error;
wire w_ptr_error;
wire b_ptr_error;
wire ar_ptr_error;
wire r_ptr_error;









  // ----------------------------------------------------------------------
  //  monitor logic
  // ----------------------------------------------------------------------

genvar j;

generate
  if (INST_IN_SLV==0)

    begin: monitor_master



          wire [AW_FIFO_DEPTH-1:0] aw_wr_ptr_async_s;
          wire [ W_FIFO_DEPTH-1:0]  w_wr_ptr_async_s;
          wire [ B_FIFO_DEPTH-1:0]  b_rd_ptr_async_s;
          wire [AR_FIFO_DEPTH-1:0] ar_wr_ptr_async_s;
          wire [ R_FIFO_DEPTH-1:0]  r_rd_ptr_async_s;
          wire is_power_down_reset;
          wire all_ptr_async_is_zero;
          // ----------------------------------------------------------------------
          // sync input signals
          // ----------------------------------------------------------------------
        
        
          for (j=0; j<AW_FIFO_DEPTH ; j=j+1)
            begin : aw_g_j
              adb400_r3_syncn
                #(
                  .LEVELS (SYNC_LEVELS)
                )
                u_syncn_aw_wr_ptr_async
                (
                  .aclk    (aclk),
                  .aresetn (aresetn),
                  .din     (aw_wr_ptr_async[j]),
                  .dout    (aw_wr_ptr_async_s[j])
                );
            end
        
          for (j=0; j<W_FIFO_DEPTH ; j=j+1)
            begin : w_g_j
              adb400_r3_syncn
                #(
                  .LEVELS (SYNC_LEVELS)
                )
                u_syncn_w_wr_ptr_async
                (
                  .aclk    (aclk),
                  .aresetn (aresetn),
                  .din     (w_wr_ptr_async[j]),
                  .dout    (w_wr_ptr_async_s[j])
                );
            end
        
          for (j=0; j<B_FIFO_DEPTH ; j=j+1)
            begin : b_g_j
              adb400_r3_syncn
                #(
                  .LEVELS (SYNC_LEVELS)
                )
                u_syncn_b_rd_ptr_async
                (
                  .aclk    (aclk),
                  .aresetn (aresetn),
                  .din     (b_rd_ptr_async[j]),
                  .dout    (b_rd_ptr_async_s[j])
                );
            end
        
        
          for (j=0; j<AR_FIFO_DEPTH ; j=j+1)
            begin : ar_g_j
              adb400_r3_syncn
                #(
                  .LEVELS (SYNC_LEVELS)
                )
                u_syncn_ar_wr_ptr_async
                (
                  .aclk    (aclk),
                  .aresetn (aresetn),
                  .din     (ar_wr_ptr_async[j]),
                  .dout    (ar_wr_ptr_async_s[j])
                );
            end
        
          for (j=0; j<R_FIFO_DEPTH ; j=j+1)
            begin : r_g_j
              adb400_r3_syncn
                #(
                  .LEVELS (SYNC_LEVELS)
                )
                u_syncn_r_rd_ptr_async
                (
                  .aclk    (aclk),
                  .aresetn (aresetn),
                  .din     (r_rd_ptr_async[j]),
                  .dout    (r_rd_ptr_async_s[j])
                );
            end
        
        
        
        
          // ----------------------------------------------------------------------
          // fifo full/empty
          // ----------------------------------------------------------------------
        
        
        
        assign aw_fifo_full = &(aw_wr_ptr_async_s ^ aw_rd_ptr_async);
        assign w_fifo_full  = &(w_wr_ptr_async_s  ^ w_rd_ptr_async);
        assign b_fifo_full  = &(b_wr_ptr_async^ b_rd_ptr_async_s);
        assign ar_fifo_full = &(ar_wr_ptr_async_s ^ ar_rd_ptr_async);
        assign r_fifo_full  = &(r_wr_ptr_async^ r_rd_ptr_async_s);
        
        
        assign aw_fifo_empty = ~( |(aw_wr_ptr_async_s ^ aw_rd_ptr_async));
        assign w_fifo_empty  = ~( |(w_wr_ptr_async_s  ^ w_rd_ptr_async) );
        assign b_fifo_empty  = ~( |(b_wr_ptr_async^ b_rd_ptr_async_s)   );
        assign ar_fifo_empty = ~( |(ar_wr_ptr_async_s ^ ar_rd_ptr_async));
        assign r_fifo_empty  = ~( |(r_wr_ptr_async^ r_rd_ptr_async_s)   );
        
        
        
        // ----------------------------------------------------------------------
        // exception case
        // ----------------------------------------------------------------------
        

        // STM is at ST_STOPPED or ST_READY_RESET
  
        assign is_power_down_reset = (pwrq_ctrl_state[2:0]==3'b0) | (pwrq_ctrl_state[2:0]==3'd7) ;

        assign all_ptr_async_is_zero = (aw_wr_ptr_async_s=={AW_FIFO_DEPTH{1'b0}}) 
                                     & (w_wr_ptr_async_s=={W_FIFO_DEPTH{1'b0}}) 
                                     & (b_rd_ptr_async_s=={B_FIFO_DEPTH{1'b0}}) 
                                     & (ar_wr_ptr_async_s=={AR_FIFO_DEPTH{1'b0}}) 
                                     & (r_rd_ptr_async_s=={R_FIFO_DEPTH{1'b0}});

       //// always @(posedge aclk or negedge aresetn)
       //// if (!aresetn)
       ////   aw_ptr_error <= 1'b0;
       //// else if ( (~aw_fifo_empty) & count_aw_to_wend_ez_q)
       ////   aw_ptr_error <= 1'b1;
       //assign aw_ptr_error = 1'b0;

       // reg b_ptr_error_r;
       // always @(posedge aclk or negedge aresetn)
       // if (!aresetn)
       //   b_ptr_error_r <= 1'b0;
       // else if ( (~b_fifo_empty) & read_write_quiescent & ~is_power_down_reset)
       //   b_ptr_error_r <= 1'b1;
       //   
       // assign b_ptr_error = b_ptr_error_r;        
       // 
       // 
       //// always @(posedge aclk or negedge aresetn)
       //// if (!aresetn)
       ////   ar_ptr_error <= 1'b0;
       //// else if ( (~ar_fifo_empty) & count_ar_to_rend_ez_q)
       ////   ar_ptr_error <= 1'b1;
       //assign  ar_ptr_error = 1'b0;
       // 
       //reg r_ptr_error_r;
       // always @(posedge aclk or negedge aresetn)
       // if (!aresetn)
       //   r_ptr_error_r <= 1'b0;
       // else if ( (~r_fifo_empty) & read_write_quiescent & ~is_power_down_reset)
       //   r_ptr_error_r <= 1'b1;

       // assign r_ptr_error = r_ptr_error_r;



          //----------------aw-------------------------
         reg [AW_FIFO_DEPTH-1:0] aw_wr_ptr_async_ss;
         always @(posedge aclk or negedge aresetn)
           if (!aresetn)
             aw_wr_ptr_async_ss <= {AW_FIFO_DEPTH{1'b0}};
           else 
             aw_wr_ptr_async_ss <= aw_wr_ptr_async_s;
           
        
        // wire [AW_FIFO_DEPTH-1:0]  aw_ptr_d;
        // wire aw_ptr_is_multibit_diff;
        // assign aw_ptr_d = (aw_wr_ptr_async_ss ^ aw_wr_ptr_async_s);
        // assign aw_ptr_is_multibit_diff = (|((aw_ptr_d - 1'b1) & aw_ptr_d)) & (aw_wr_ptr_async_s=={AW_FIFO_DEPTH{1'b0}});
        
         wire aw_ptr_abnomal_to_zero = (aw_wr_ptr_async_s=={AW_FIFO_DEPTH{1'b0}}) & ( ~ ( (aw_wr_ptr_async_ss=={AW_FIFO_DEPTH-1{1'b0}})
                                                                                        | (aw_wr_ptr_async_ss=={1'b1,{AW_FIFO_DEPTH-1{1'b0}}}) 
                                                                                        | (aw_wr_ptr_async_ss=={2'b11,{AW_FIFO_DEPTH-2{1'b0}}}) 
                                                                                        ) );
         
         reg aw_ptr_error_r; 
         always @(posedge aclk or negedge aresetn)
           if (!aresetn)
             aw_ptr_error_r <= 1'b0;
           else if ( ~is_power_down_reset & count_aw_to_wend_ez_q & all_ptr_async_is_zero & aw_ptr_abnomal_to_zero)
             aw_ptr_error_r <= 1'b1;
        
         assign aw_ptr_error = aw_ptr_error_r;
        

          //----------------w-------------------------
         reg [W_FIFO_DEPTH-1:0] w_wr_ptr_async_ss;
         always @(posedge aclk or negedge aresetn)
           if (!aresetn)
             w_wr_ptr_async_ss <= {W_FIFO_DEPTH{1'b0}};
           else 
             w_wr_ptr_async_ss <= w_wr_ptr_async_s;
           
        
         //wire [W_FIFO_DEPTH-1:0]  w_ptr_d;
         //wire w_ptr_is_multibit_diff;
         //assign w_ptr_d = (w_wr_ptr_async_ss ^ w_wr_ptr_async_s );
         //assign w_ptr_is_multibit_diff = (|((w_ptr_d - 1'b1) & w_ptr_d)) & (w_wr_ptr_async_s=={W_FIFO_DEPTH{1'b0}});
        
         wire w_ptr_abnomal_to_zero = (w_wr_ptr_async_s=={W_FIFO_DEPTH{1'b0}}) & ( ~ ( (w_wr_ptr_async_ss=={W_FIFO_DEPTH-1{1'b0}})
                                                                                     | (w_wr_ptr_async_ss=={1'b1,{W_FIFO_DEPTH-1{1'b0}}}) 
                                                                                     | (w_wr_ptr_async_ss=={2'b11,{W_FIFO_DEPTH-2{1'b0}}}) 
                                                                                     ) );

         reg w_ptr_error_r; 
         always @(posedge aclk or negedge aresetn)
           if (!aresetn)
             w_ptr_error_r <= 1'b0;
           else if ( ~is_power_down_reset & count_aw_to_wend_ez_q & all_ptr_async_is_zero & w_ptr_abnomal_to_zero)
             w_ptr_error_r <= 1'b1;
        
         assign w_ptr_error = w_ptr_error_r;

        
                
          //----------------b-------------------------
         reg [B_FIFO_DEPTH-1:0] b_rd_ptr_async_ss;
         always @(posedge aclk or negedge aresetn)
           if (!aresetn)
             b_rd_ptr_async_ss <= {B_FIFO_DEPTH{1'b0}};
           else 
             b_rd_ptr_async_ss <= b_rd_ptr_async_s;
           
        
         //wire [B_FIFO_DEPTH-1:0]  b_ptr_d;
         //wire b_ptr_is_multibit_diff;
         //assign b_ptr_d = (b_rd_ptr_async_ss ^ b_rd_ptr_async_s );
         //assign b_ptr_is_multibit_diff = (|((b_ptr_d - 1'b1) & b_ptr_d)) & (b_rd_ptr_async_s=={B_FIFO_DEPTH{1'b0}});
        
         wire b_ptr_abnomal_to_zero = (b_rd_ptr_async_s=={B_FIFO_DEPTH{1'b0}}) & ( ~ ( (b_rd_ptr_async_ss=={B_FIFO_DEPTH-1{1'b0}})
                                                                                     | (b_rd_ptr_async_ss=={1'b1,{B_FIFO_DEPTH-1{1'b0}}}) 
                                                                                     | (b_rd_ptr_async_ss=={2'b11,{B_FIFO_DEPTH-2{1'b0}}}) 
                                                                                     ) );


         reg b_ptr_error_r; 
         always @(posedge aclk or negedge aresetn)
           if (!aresetn)
             b_ptr_error_r <= 1'b0;
           else if ( ~is_power_down_reset & count_aw_to_wend_ez_q & all_ptr_async_is_zero & b_ptr_abnomal_to_zero)
             b_ptr_error_r <= 1'b1;
        
         assign b_ptr_error = b_ptr_error_r;


          //----------------ar-------------------------
         reg [AR_FIFO_DEPTH-1:0] ar_wr_ptr_async_ss;
         always @(posedge aclk or negedge aresetn)
           if (!aresetn)
             ar_wr_ptr_async_ss <= {AR_FIFO_DEPTH{1'b0}};
           else 
             ar_wr_ptr_async_ss <= ar_wr_ptr_async_s;
           
        
         //wire [AR_FIFO_DEPTH-1:0]  ar_ptr_d;
         //wire ar_ptr_is_multibit_diff;
         //assign ar_ptr_d = (ar_wr_ptr_async_ss ^ ar_wr_ptr_async_s);
         //assign ar_ptr_is_multibit_diff = (|((ar_ptr_d - 1'b1) & ar_ptr_d)) & (ar_wr_ptr_async_s=={AR_FIFO_DEPTH{1'b0}});
        
         wire ar_ptr_abnomal_to_zero = (ar_wr_ptr_async_s=={AR_FIFO_DEPTH{1'b0}}) & ( ~ ( (ar_wr_ptr_async_ss=={AR_FIFO_DEPTH-1{1'b0}})
                                                                                        | (ar_wr_ptr_async_ss=={1'b1,{AR_FIFO_DEPTH-1{1'b0}}}) 
                                                                                        | (ar_wr_ptr_async_ss=={2'b11,{AR_FIFO_DEPTH-2{1'b0}}}) 
                                                                                        ) );

         reg ar_ptr_error_r; 
         always @(posedge aclk or negedge aresetn)
           if (!aresetn)
             ar_ptr_error_r <= 1'b0;
           else if ( ~is_power_down_reset & count_ar_to_rend_ez_q & all_ptr_async_is_zero & ar_ptr_abnomal_to_zero)
             ar_ptr_error_r <= 1'b1;
        
         assign ar_ptr_error = ar_ptr_error_r;


          //----------------r-------------------------
         reg [R_FIFO_DEPTH-1:0] r_rd_ptr_async_ss;
         always @(posedge aclk or negedge aresetn)
           if (!aresetn)
             r_rd_ptr_async_ss <= {R_FIFO_DEPTH{1'b0}};
           else 
             r_rd_ptr_async_ss <= r_rd_ptr_async_s;
           
        
         //wire [R_FIFO_DEPTH-1:0]  r_ptr_d;
         //wire r_ptr_is_multibit_diff;
         //assign r_ptr_d = (r_rd_ptr_async_ss ^ r_rd_ptr_async_s);
         //assign r_ptr_is_multibit_diff = (|((r_ptr_d - 1'b1) & r_ptr_d)) & (r_rd_ptr_async_s=={R_FIFO_DEPTH{1'b0}});
        
         wire r_ptr_abnomal_to_zero = (r_rd_ptr_async_s=={R_FIFO_DEPTH{1'b0}}) & ( ~ ( (r_rd_ptr_async_ss=={R_FIFO_DEPTH-1{1'b0}})
                                                                                     | (r_rd_ptr_async_ss=={1'b1,{R_FIFO_DEPTH-1{1'b0}}}) 
                                                                                     | (r_rd_ptr_async_ss=={2'b11,{R_FIFO_DEPTH-2{1'b0}}}) 
                                                                                     ) );


         reg r_ptr_error_r; 
         always @(posedge aclk or negedge aresetn)
           if (!aresetn)
             r_ptr_error_r <= 1'b0;
           else if ( ~is_power_down_reset & count_ar_to_rend_ez_q & all_ptr_async_is_zero & r_ptr_abnomal_to_zero)
             r_ptr_error_r <= 1'b1;
        
         assign r_ptr_error = r_ptr_error_r;




      end









      
else // inst in adb slave


    begin: monitor_slave

          wire [AW_FIFO_DEPTH-1:0] aw_rd_ptr_async_s;
          wire [ W_FIFO_DEPTH-1:0]  w_rd_ptr_async_s;
          wire [ B_FIFO_DEPTH-1:0]  b_wr_ptr_async_s;
          wire [AR_FIFO_DEPTH-1:0] ar_rd_ptr_async_s;
          wire [ R_FIFO_DEPTH-1:0]  r_wr_ptr_async_s;
          wire is_power_down_reset;
          wire all_ptr_async_is_zero;
          // ----------------------------------------------------------------------
          // sync input signals
          // ----------------------------------------------------------------------
        
        
          for (j=0; j<AW_FIFO_DEPTH ; j=j+1)
            begin : aw_g_j
              adb400_r3_syncn
                #(
                  .LEVELS (SYNC_LEVELS)
                )
                u_syncn_aw_rd_ptr_async
                (
                  .aclk    (aclk),
                  .aresetn (aresetn),
                  .din     (aw_rd_ptr_async[j]),
                  .dout    (aw_rd_ptr_async_s[j])
                );
            end
        
          for (j=0; j<W_FIFO_DEPTH ; j=j+1)
            begin : w_g_j
              adb400_r3_syncn
                #(
                  .LEVELS (SYNC_LEVELS)
                )
                u_syncn_w_rd_ptr_async
                (
                  .aclk    (aclk),
                  .aresetn (aresetn),
                  .din     (w_rd_ptr_async[j]),
                  .dout    (w_rd_ptr_async_s[j])
                );
            end
        
          for (j=0; j<B_FIFO_DEPTH ; j=j+1)
            begin : b_g_j
              adb400_r3_syncn
                #(
                  .LEVELS (SYNC_LEVELS)
                )
                u_syncn_b_wr_ptr_async
                (
                  .aclk    (aclk),
                  .aresetn (aresetn),
                  .din     (b_wr_ptr_async[j]),
                  .dout    (b_wr_ptr_async_s[j])
                );
            end
        
        
          for (j=0; j<AR_FIFO_DEPTH ; j=j+1)
            begin : ar_g_j
              adb400_r3_syncn
                #(
                  .LEVELS (SYNC_LEVELS)
                )
                u_syncn_ar_rd_ptr_async
                (
                  .aclk    (aclk),
                  .aresetn (aresetn),
                  .din     (ar_rd_ptr_async[j]),
                  .dout    (ar_rd_ptr_async_s[j])
                );
            end
        
          for (j=0; j<R_FIFO_DEPTH ; j=j+1)
            begin : r_g_j
              adb400_r3_syncn
                #(
                  .LEVELS (SYNC_LEVELS)
                )
                u_syncn_r_wr_ptr_async
                (
                  .aclk    (aclk),
                  .aresetn (aresetn),
                  .din     (r_wr_ptr_async[j]),
                  .dout    (r_wr_ptr_async_s[j])
                );
            end
        
        
        
        
          // ----------------------------------------------------------------------
          // fifo full/empty
          // ----------------------------------------------------------------------
        
        
        
        assign aw_fifo_full = &(aw_wr_ptr_async ^ aw_rd_ptr_async_s);
        assign w_fifo_full  = &(w_wr_ptr_async  ^ w_rd_ptr_async_s);
        assign b_fifo_full  = &(b_wr_ptr_async_s^ b_rd_ptr_async);
        assign ar_fifo_full = &(ar_wr_ptr_async ^ ar_rd_ptr_async_s);
        assign r_fifo_full  = &(r_wr_ptr_async_s^ r_rd_ptr_async);
        
        
        assign aw_fifo_empty = ~( |(aw_wr_ptr_async ^ aw_rd_ptr_async_s));
        assign w_fifo_empty  = ~( |(w_wr_ptr_async  ^ w_rd_ptr_async_s) );
        assign b_fifo_empty  = ~( |(b_wr_ptr_async_s^ b_rd_ptr_async)   );
        assign ar_fifo_empty = ~( |(ar_wr_ptr_async ^ ar_rd_ptr_async_s));
        assign r_fifo_empty  = ~( |(r_wr_ptr_async_s^ r_rd_ptr_async)   );
        
        
        
          // ----------------------------------------------------------------------
          // exception case
          // ----------------------------------------------------------------------


        // STM is at ST_P_STOPPED or ST_P_EXIT or ST_P_REQUEST_RESET
        assign is_power_down_reset = (pwrq_ctrl_state==4'b0) | (pwrq_ctrl_state==4'b1) | (pwrq_ctrl_state==4'd9);

        assign all_ptr_async_is_zero = (aw_rd_ptr_async_s=={AW_FIFO_DEPTH{1'b0}}) 
                                     & (w_rd_ptr_async_s=={W_FIFO_DEPTH{1'b0}}) 
                                     & (b_wr_ptr_async_s=={B_FIFO_DEPTH{1'b0}}) 
                                     & (ar_rd_ptr_async_s=={AR_FIFO_DEPTH{1'b0}}) 
                                     & (r_wr_ptr_async_s=={R_FIFO_DEPTH{1'b0}});
      //  reg aw_ptr_error_r; 
      //  always @(posedge aclk or negedge aresetn)
      //  if (!aresetn)
      //    aw_ptr_error_r <= 1'b0;
      //  else if ( (~aw_fifo_empty) & count_aw_to_wend_ez_q & ~is_power_down_reset)
      //    aw_ptr_error_r <= 1'b1;
      //  
      //  assign aw_ptr_error = aw_ptr_error_r;

      // // always @(posedge aclk or negedge aresetn)
      // // if (!aresetn)
      // //   b_ptr_error <= 1'b0;
      // // else if ( (~b_fifo_empty) & count_aw_to_wend_ez_q)
      // //   b_ptr_error <= 1'b1;
      // assign b_ptr_error = 1'b0; 
      //  
      //  reg ar_ptr_error_r;
      //  always @(posedge aclk or negedge aresetn)
      //  if (!aresetn)
      //    ar_ptr_error_r <= 1'b0;
      //  else if ( (~ar_fifo_empty) & count_ar_to_rend_ez_q & ~is_power_down_reset)
      //    ar_ptr_error_r <= 1'b1;
      //  
      //  assign ar_ptr_error = ar_ptr_error_r;
      //  
      // // always @(posedge aclk or negedge aresetn)
      // // if (!aresetn)
      // //   r_ptr_error <= 1'b0;
      // // else if ( (~r_fifo_empty) & count_ar_to_rend_ez_q)
      // //   r_ptr_error <= 1'b1;
      // assign r_ptr_error = 1'b0;



          //----------------aw-------------------------
         reg [AW_FIFO_DEPTH-1:0] aw_rd_ptr_async_ss;
         always @(posedge aclk or negedge aresetn)
           if (!aresetn)
             aw_rd_ptr_async_ss <= {AW_FIFO_DEPTH{1'b0}};
           else 
             aw_rd_ptr_async_ss <= aw_rd_ptr_async_s;
           
        
         //wire [AW_FIFO_DEPTH-1:0]  aw_ptr_d;
         //wire aw_ptr_is_multibit_diff;
         //assign aw_ptr_d = (aw_rd_ptr_async_ss ^ aw_rd_ptr_async_s);
         //assign aw_ptr_is_multibit_diff = (|((aw_ptr_d - 1'b1) & aw_ptr_d)) & (aw_rd_ptr_async_s=={AW_FIFO_DEPTH{1'b0}});
        
         wire aw_ptr_abnomal_to_zero = (aw_rd_ptr_async_s=={AW_FIFO_DEPTH{1'b0}}) & ( ~ ( (aw_rd_ptr_async_ss=={AW_FIFO_DEPTH-1{1'b0}})
                                                                                        | (aw_rd_ptr_async_ss=={1'b1,{AW_FIFO_DEPTH-1{1'b0}}}) 
                                                                                        | (aw_rd_ptr_async_ss=={2'b11,{AW_FIFO_DEPTH-2{1'b0}}}) 
                                                                                        ) );


         reg aw_ptr_error_r; 
         always @(posedge aclk or negedge aresetn)
           if (!aresetn)
             aw_ptr_error_r <= 1'b0;
           else if ( ~is_power_down_reset & count_aw_to_wend_ez_q & all_ptr_async_is_zero & aw_ptr_abnomal_to_zero)
             aw_ptr_error_r <= 1'b1;
        
         assign aw_ptr_error = aw_ptr_error_r;
        

          //----------------w-------------------------
         reg [W_FIFO_DEPTH-1:0] w_rd_ptr_async_ss;
         always @(posedge aclk or negedge aresetn)
           if (!aresetn)
             w_rd_ptr_async_ss <= {W_FIFO_DEPTH{1'b0}};
           else 
             w_rd_ptr_async_ss <= w_rd_ptr_async_s;
           
        
         //wire [W_FIFO_DEPTH-1:0]  w_ptr_d;
         //wire w_ptr_is_multibit_diff;
         //assign w_ptr_d = (w_rd_ptr_async_ss ^ w_rd_ptr_async_s);
         //assign w_ptr_is_multibit_diff = (|((w_ptr_d - 1'b1) & w_ptr_d)) & (w_rd_ptr_async_s=={W_FIFO_DEPTH{1'b0}});
        
         wire w_ptr_abnomal_to_zero = (w_rd_ptr_async_s=={W_FIFO_DEPTH{1'b0}}) & ( ~ ( (w_rd_ptr_async_ss=={W_FIFO_DEPTH-1{1'b0}})
                                                                                     | (w_rd_ptr_async_ss=={1'b1,{W_FIFO_DEPTH-1{1'b0}}}) 
                                                                                     | (w_rd_ptr_async_ss=={2'b11,{W_FIFO_DEPTH-2{1'b0}}}) 
                                                                                     ) );


         reg w_ptr_error_r; 
         always @(posedge aclk or negedge aresetn)
           if (!aresetn)
             w_ptr_error_r <= 1'b0;
           else if (~is_power_down_reset & count_aw_to_wend_ez_q & all_ptr_async_is_zero & w_ptr_abnomal_to_zero)
             w_ptr_error_r <= 1'b1;
        
         assign w_ptr_error = w_ptr_error_r;

        
                
          //----------------b-------------------------
         reg [B_FIFO_DEPTH-1:0] b_wr_ptr_async_ss;
         always @(posedge aclk or negedge aresetn)
           if (!aresetn)
             b_wr_ptr_async_ss <= {B_FIFO_DEPTH{1'b0}};
           else 
             b_wr_ptr_async_ss <= b_wr_ptr_async_s;
           
        
         //wire [B_FIFO_DEPTH-1:0]  b_ptr_d;
         //wire b_ptr_is_multibit_diff;
         //assign b_ptr_d = (b_wr_ptr_async_ss ^ b_wr_ptr_async_s);
         //assign b_ptr_is_multibit_diff = (|((b_ptr_d - 1'b1) & b_ptr_d)) & (b_wr_ptr_async_s=={B_FIFO_DEPTH{1'b0}});
        
         wire b_ptr_abnomal_to_zero = (b_wr_ptr_async_s=={B_FIFO_DEPTH{1'b0}}) & ( ~ ( (b_wr_ptr_async_ss=={B_FIFO_DEPTH-1{1'b0}})
                                                                                     | (b_wr_ptr_async_ss=={1'b1,{B_FIFO_DEPTH-1{1'b0}}}) 
                                                                                     | (b_wr_ptr_async_ss=={2'b11,{B_FIFO_DEPTH-2{1'b0}}}) 
                                                                                     ) );


         reg b_ptr_error_r; 
         always @(posedge aclk or negedge aresetn)
           if (!aresetn)
             b_ptr_error_r <= 1'b0;
           else if ( ~is_power_down_reset & count_aw_to_wend_ez_q & all_ptr_async_is_zero & b_ptr_abnomal_to_zero)
             b_ptr_error_r <= 1'b1;
        
         assign b_ptr_error = b_ptr_error_r;


          //----------------ar-------------------------
         reg [AR_FIFO_DEPTH-1:0] ar_rd_ptr_async_ss;
         always @(posedge aclk or negedge aresetn)
           if (!aresetn)
             ar_rd_ptr_async_ss <= {AR_FIFO_DEPTH{1'b0}};
           else 
             ar_rd_ptr_async_ss <= ar_rd_ptr_async_s;
           
        
         //wire [AR_FIFO_DEPTH-1:0]  ar_ptr_d;
         //wire ar_ptr_is_multibit_diff;
         //assign ar_ptr_d = (ar_rd_ptr_async_ss ^ ar_rd_ptr_async_s);
         //assign ar_ptr_is_multibit_diff = (|((ar_ptr_d - 1'b1) & ar_ptr_d)) & (ar_rd_ptr_async_s=={AR_FIFO_DEPTH{1'b0}});
        
         wire ar_ptr_abnomal_to_zero = (ar_rd_ptr_async_s=={AR_FIFO_DEPTH{1'b0}}) & ( ~ ( (ar_rd_ptr_async_ss=={AR_FIFO_DEPTH-1{1'b0}}) 
                                                                                        | (ar_rd_ptr_async_ss=={1'b1, {AR_FIFO_DEPTH-1{1'b0}}}) 
                                                                                        | (ar_rd_ptr_async_ss=={2'b11,{AR_FIFO_DEPTH-2{1'b0}}}) 
                                                                                        ) );

         reg ar_ptr_error_r; 
         always @(posedge aclk or negedge aresetn)
           if (!aresetn)
             ar_ptr_error_r <= 1'b0;
           else if ( ~is_power_down_reset & count_ar_to_rend_ez_q & all_ptr_async_is_zero & ar_ptr_abnomal_to_zero)
             ar_ptr_error_r <= 1'b1;
        
         assign ar_ptr_error = ar_ptr_error_r;


          //----------------r-------------------------
         reg [R_FIFO_DEPTH-1:0] r_wr_ptr_async_ss;
         always @(posedge aclk or negedge aresetn)
           if (!aresetn)
             r_wr_ptr_async_ss <= {R_FIFO_DEPTH{1'b0}};
           else 
             r_wr_ptr_async_ss <= r_wr_ptr_async_s;
           
        
         //wire [R_FIFO_DEPTH-1:0]  r_ptr_d;
         //wire r_ptr_is_multibit_diff;
         //assign r_ptr_d = (r_wr_ptr_async_ss ^ r_wr_ptr_async_s);
         //assign r_ptr_is_multibit_diff = (|((r_ptr_d - 1'b1) & r_ptr_d)) & (r_wr_ptr_async_s=={R_FIFO_DEPTH{1'b0}});
        
         wire r_ptr_abnomal_to_zero = (r_wr_ptr_async_s=={R_FIFO_DEPTH{1'b0}}) & ( ~ ( (r_wr_ptr_async_ss=={R_FIFO_DEPTH-1{1'b0}}) 
                                                                                     | (r_wr_ptr_async_ss=={1'b1, {R_FIFO_DEPTH-1{1'b0}}}) 
                                                                                     | (r_wr_ptr_async_ss=={2'b11,{R_FIFO_DEPTH-2{1'b0}}}) 
                                                                                     ) );

         
         reg r_ptr_error_r; 
         always @(posedge aclk or negedge aresetn)
           if (!aresetn)
             r_ptr_error_r <= 1'b0;
           else if ( ~is_power_down_reset & count_ar_to_rend_ez_q & all_ptr_async_is_zero & r_ptr_abnomal_to_zero)
             r_ptr_error_r <= 1'b1;
        
         assign r_ptr_error = r_ptr_error_r;




     end
endgenerate






  // ----------------------------------------------------------------------
  // collect monitor signals
  // ----------------------------------------------------------------------


always @(posedge aclk or negedge aresetn)
if (!aresetn)
  adb_debug_monitor_o <= 32'h38_01f0;
else
  adb_debug_monitor_o <= adb_debug_monitor;


assign adb_debug_monitor = {
  10'd0,
  count_ar_to_rend_ez_q,  // bit[21], 1bit, ar->rlast counter is 0
  count_aw_to_wlast_ez_q, // bit[20], 1bit, aw->wlast counter is 0
  count_aw_to_wend_ez_q,  // bit[19], 1bit, aw->b     counter is 0  
  aw_ptr_error,           // bit[18], 1bit
  w_ptr_error,            // bit[17], 1bit
  b_ptr_error,            // bit[16], 1bit
  ar_ptr_error,           // bit[15], 1bit
  r_ptr_error,            // bit[14], 1bit
  aw_fifo_full,           // bit[13], 1bit
  w_fifo_full,            // bit[12], 1bit
  b_fifo_full,            // bit[11], 1bit
  ar_fifo_full,           // bit[10], 1bit
  r_fifo_full,            // bit[ 9], 1bit  
  aw_fifo_empty,          // bit[ 8], 1bit
  w_fifo_empty,           // bit[ 7], 1bit
  b_fifo_empty,           // bit[ 6], 1bit
  ar_fifo_empty,          // bit[ 5], 1bit
  r_fifo_empty,           // bit[ 4], 1bit
  pwrq_ctrl_state         // bit[3:0], 4bit, the ctrl status of power Qchannel state machine

  };









endmodule
// Local Variables:
// verilog-library-directories:("./" ) 
// verilog-auto-inst-param-value:t
// End:
