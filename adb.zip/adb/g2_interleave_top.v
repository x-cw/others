// +FHDR----------------------------------------------------------------------------
// Copyright (c) 2026, Innosilicon, Inc. Confidential Proprietary
// PROJECT NAME  : xxx
// DEPARTMENT    : Digtal Frontend SOC
// AUTHOR        : chenm
// EMAIL         : chenm@innosilicon.com.cn
// CREATE ON     : 2026/02/27 17:38
// FILE NAME     : g2_interleave_top.v
// DESCRIPTION   :          
//         
// Copyright (c) 2026 Innosilicon.
// ALL RIGHTS RESERVED
// 
// ---------------------------------------------------------------------------------
// Modification History:
// Date         By              Version                 Change Description
// ---------------------------------------------------------------------------------
// 2026/02/27   chenm           1.0                     Original
// 
// -FHDR----------------------------------------------------------------------------

`timescale 1ns/1ps

module g2_interleave_top#(
    parameter SLICE_NUM = 2  ,
    parameter ID_W      = 13 ,
    parameter USER_W    = 16 ,
    parameter LEN_W     = 4  ,
    parameter DATA_W    = 256,
    parameter ADDR_W    = 49
)(
    input                   clk                   ,
    input                   rstn                  ,
    input                   test_mode             ,
    input [3:0]             reg_ddr_channel_size       , // To sync_inst of intlv_reg_sync.v
    input                   reg_interleave_hash_enable , // To sync_inst of intlv_reg_sync.v
    input  [     ID_W-1:0] awid_m                 ,
    input  [   ADDR_W-1:0] awaddr_m               ,
    input  [    LEN_W-1:0] awlen_m                ,
    input  [          2:0] awsize_m               ,
    input  [          1:0] awburst_m              ,
    input                  awlock_m               ,
    input  [          3:0] awcache_m              ,
    input  [          2:0] awprot_m               ,
    input                  awvalid_m              ,
    input                  awready_s              ,
    input  [((USER_W>0)?(USER_W-1):0):0] awuser_m ,
    input  [        4-1:0] awqos_m                ,
    output [     ID_W-1:0] awid_s                 ,
    output [   ADDR_W-1:0] awaddr_s               ,
    output [    LEN_W-1:0] awlen_s                ,
    output [          2:0] awsize_s               ,
    output [          1:0] awburst_s              ,
    output                 awlock_s               ,
    output [          3:0] awcache_s              ,
    output [          2:0] awprot_s               ,
    output                 awvalid_s              ,
    output                 awready_m              ,
    output [((USER_W>0)?(USER_W-1):0):0] awuser_s ,
    output [        4-1:0] awqos_s                ,

    input  [ DATA_W  -1:0] wdata_m                ,
    input  [ DATA_W/8-1:0] wstrb_m                ,
    input                  wlast_m                ,
    input                  wvalid_m               ,
    input                  wready_s               ,
    output [ DATA_W  -1:0] wdata_s                ,
    output [ DATA_W/8-1:0] wstrb_s                ,
    output                 wlast_s                ,
    output                 wvalid_s               ,
    output                 wready_m               ,

    input  [     ID_W-1:0] bid_s                  ,
    input  [          1:0] bresp_s                ,
    input                  bvalid_s               ,
    input                  bready_m               ,
    input  [((USER_W>0)?(USER_W-1):0):0] buser_s  ,
    output [     ID_W-1:0] bid_m                  ,
    output [          1:0] bresp_m                ,
    output                 bvalid_m               ,
    output                 bready_s               ,
    output [((USER_W>0)?(USER_W-1):0):0] buser_m  ,

    input  [     ID_W-1:0] arid_m                 ,
    input  [   ADDR_W-1:0] araddr_m               ,
    input  [    LEN_W-1:0] arlen_m                ,
    input  [          2:0] arsize_m               ,
    input  [          1:0] arburst_m              ,
    input                  arlock_m               ,
    input  [          3:0] arcache_m              ,
    input  [          2:0] arprot_m               ,
    input                  arvalid_m              ,
    input                  arready_s              ,
    input  [((USER_W>0)?(USER_W-1):0):0] aruser_m ,
    input  [        4-1:0] arqos_m                ,
    output [     ID_W-1:0] arid_s                 ,
    output [   ADDR_W-1:0] araddr_s               ,
    output [    LEN_W-1:0] arlen_s                ,
    output [          2:0] arsize_s               ,
    output [          1:0] arburst_s              ,
    output                 arlock_s               ,
    output [          3:0] arcache_s              ,
    output [          2:0] arprot_s               ,
    output                 arvalid_s              ,
    output                 arready_m              ,
    output [((USER_W>0)?(USER_W-1):0):0] aruser_s ,
    output [        4-1:0] arqos_s                ,

    input  [     ID_W-1:0] rid_s                  ,
    input  [   DATA_W-1:0] rdata_s                ,
    input  [          1:0] rresp_s                ,
    input                  rlast_s                ,
    input                  rvalid_s               ,
    input                  rready_m               ,
    input  [((USER_W>0)?(USER_W-1):0):0] ruser_s  ,
    output [     ID_W-1:0] rid_m                  ,
    output [   DATA_W-1:0] rdata_m                ,
    output [          1:0] rresp_m                ,
    output                 rlast_m                ,
    output                 rvalid_m               ,
    output                 rready_s               ,
    output [((USER_W>0)?(USER_W-1):0):0] ruser_m
);
    parameter HASH_PLD_W = ID_W+ADDR_W+LEN_W+3+2+1+4+3+USER_W+4+33+1;

    /*autoinput*/
    /*autooutput*/
    /*autowire*/
    // Beginning of automatic wires (for undeclared instantiated-module outputs)
    wire [HASH_PLD_W-1:0] ar_hash_paylod;       // From ar_hash of intlv_addr_hash.v
    wire                ar_hash_ready;          // From ar_level_sel of intlv_level_sel.v
    wire                ar_hash_valid;          // From ar_hash of intlv_addr_hash.v
    wire [HASH_PLD_W-1:0] aw_hash_paylod;       // From aw_hash of intlv_addr_hash.v
    wire                aw_hash_ready;          // From aw_level_sel of intlv_level_sel.v
    wire                aw_hash_valid;          // From aw_hash of intlv_addr_hash.v
    // End of automatics


/*intlv_addr_hash auto_template "\(.*\)_hash" (
    .req_\(.*\)           (@\1_m[]),
    .\(hash_.*\)          (@_\1[]),
    .reg_sync_\(.*\)    (reg_\1[]),
);*/

intlv_addr_hash#(
    .HASH_PLD_W (HASH_PLD_W),
    .ID_W       (ID_W      ),
    .USER_W     (USER_W    ),
    .LEN_W      (LEN_W     ),
    .ADDR_W     (ADDR_W    ))
    aw_hash(/*autoinst*/
            // Outputs
            .req_ready                  (awready_m),             // Templated
            .hash_paylod                (aw_hash_paylod[HASH_PLD_W-1:0]), // Templated
            .hash_valid                 (aw_hash_valid),         // Templated
            // Inputs
            .clk                        (clk),
            .rstn                       (rstn),
            .test_mode                  (test_mode),
            .reg_sync_interleave_hash_enable(reg_interleave_hash_enable), // Templated
            .reg_sync_ddr_channel_size  (reg_ddr_channel_size[3:0]), // Templated
            .req_id                     (awid_m[ID_W-1:0]),      // Templated
            .req_addr                   (awaddr_m[ADDR_W-1:0]),  // Templated
            .req_len                    (awlen_m[LEN_W-1:0]),    // Templated
            .req_size                   (awsize_m[2:0]),         // Templated
            .req_burst                  (awburst_m[1:0]),        // Templated
            .req_lock                   (awlock_m),              // Templated
            .req_cache                  (awcache_m[3:0]),        // Templated
            .req_prot                   (awprot_m[2:0]),         // Templated
            .req_user                   (awuser_m[((USER_W>0)?(USER_W-1):0):0]), // Templated
            .req_qos                    (awqos_m[3:0]),          // Templated
            .req_valid                  (awvalid_m),             // Templated
            .hash_ready                 (aw_hash_ready));        // Templated

intlv_addr_hash#(
    .HASH_PLD_W (HASH_PLD_W),
    .ID_W       (ID_W      ),
    .USER_W     (USER_W    ),
    .LEN_W      (LEN_W     ),
    .ADDR_W     (ADDR_W    ))
    ar_hash(/*autoinst*/
            // Outputs
            .req_ready                  (arready_m),             // Templated
            .hash_paylod                (ar_hash_paylod[HASH_PLD_W-1:0]), // Templated
            .hash_valid                 (ar_hash_valid),         // Templated
            // Inputs
            .clk                        (clk),
            .rstn                       (rstn),
            .test_mode                  (test_mode),
            .reg_sync_interleave_hash_enable(reg_interleave_hash_enable), // Templated
            .reg_sync_ddr_channel_size  (reg_ddr_channel_size[3:0]), // Templated
            .req_id                     (arid_m[ID_W-1:0]),      // Templated
            .req_addr                   (araddr_m[ADDR_W-1:0]),  // Templated
            .req_len                    (arlen_m[LEN_W-1:0]),    // Templated
            .req_size                   (arsize_m[2:0]),         // Templated
            .req_burst                  (arburst_m[1:0]),        // Templated
            .req_lock                   (arlock_m),              // Templated
            .req_cache                  (arcache_m[3:0]),        // Templated
            .req_prot                   (arprot_m[2:0]),         // Templated
            .req_user                   (aruser_m[((USER_W>0)?(USER_W-1):0):0]), // Templated
            .req_qos                    (arqos_m[3:0]),          // Templated
            .req_valid                  (arvalid_m),             // Templated
            .hash_ready                 (ar_hash_ready));        // Templated

/*intlv_level_sel auto_template "\(.*\)_level_sel" (
    .req_\(.*\)           (@\1_s[]),
    .\(hash_.*\)          (@_\1[]),    
    .reg_sync_\(.*\)    (reg_\1[]),
);*/

intlv_level_sel#(
    .HASH_PLD_W (HASH_PLD_W),
    .ID_W       (ID_W      ),
    .USER_W     (USER_W    ),
    .LEN_W      (LEN_W     ),
    .ADDR_W     (ADDR_W    ))
    aw_level_sel(/*autoinst*/
                 // Outputs
                 .req_id                (awid_s[ID_W-1:0]),      // Templated
                 .req_addr              (awaddr_s[ADDR_W-1:0]),  // Templated
                 .req_len               (awlen_s[LEN_W-1:0]),    // Templated
                 .req_size              (awsize_s[2:0]),         // Templated
                 .req_burst             (awburst_s[1:0]),        // Templated
                 .req_lock              (awlock_s),              // Templated
                 .req_cache             (awcache_s[3:0]),        // Templated
                 .req_prot              (awprot_s[2:0]),         // Templated
                 .req_user              (awuser_s[((USER_W>0)?(USER_W-1):0):0]), // Templated
                 .req_qos               (awqos_s[3:0]),          // Templated
                 .req_valid             (awvalid_s),             // Templated
                 .hash_ready            (aw_hash_ready),         // Templated
                 // Inputs
                 .clk                   (clk),
                 .rstn                  (rstn),
                 .test_mode             (test_mode),
                 .req_ready             (awready_s),             // Templated
                 .reg_sync_interleave_hash_enable(reg_interleave_hash_enable), // Templated
                 .reg_sync_ddr_channel_size(reg_ddr_channel_size[3:0]), // Templated
                 .hash_paylod           (aw_hash_paylod[HASH_PLD_W-1:0]), // Templated
                 .hash_valid            (aw_hash_valid));        // Templated

intlv_level_sel#(
    .HASH_PLD_W (HASH_PLD_W),
    .ID_W       (ID_W      ),
    .USER_W     (USER_W    ),
    .LEN_W      (LEN_W     ),
    .ADDR_W     (ADDR_W    ))
    ar_level_sel(/*autoinst*/
                 // Outputs
                 .req_id                (arid_s[ID_W-1:0]),      // Templated
                 .req_addr              (araddr_s[ADDR_W-1:0]),  // Templated
                 .req_len               (arlen_s[LEN_W-1:0]),    // Templated
                 .req_size              (arsize_s[2:0]),         // Templated
                 .req_burst             (arburst_s[1:0]),        // Templated
                 .req_lock              (arlock_s),              // Templated
                 .req_cache             (arcache_s[3:0]),        // Templated
                 .req_prot              (arprot_s[2:0]),         // Templated
                 .req_user              (aruser_s[((USER_W>0)?(USER_W-1):0):0]), // Templated
                 .req_qos               (arqos_s[3:0]),          // Templated
                 .req_valid             (arvalid_s),             // Templated
                 .hash_ready            (ar_hash_ready),         // Templated
                 // Inputs
                 .clk                   (clk),
                 .rstn                  (rstn),
                 .test_mode             (test_mode),
                 .req_ready             (arready_s),             // Templated
                 .reg_sync_interleave_hash_enable(reg_interleave_hash_enable), // Templated
                 .reg_sync_ddr_channel_size(reg_ddr_channel_size[3:0]), // Templated
                 .hash_paylod           (ar_hash_paylod[HASH_PLD_W-1:0]), // Templated
                 .hash_valid            (ar_hash_valid));        // Templated


parameter W_WIDTH = DATA_W + DATA_W/8 + 1;
genvar i;
generate 
  if(SLICE_NUM == 0)begin:pass_through


    assign wready_m   = wready_s  ;
    assign wdata_s    = wdata_m     ;
    assign wstrb_s    = wstrb_m     ;
    assign wlast_s    = wlast_m     ;
    assign wvalid_s   = wvalid_m    ;
    
  end else begin:gen_slice

    // w channel slice

    wire [DATA_W  -1:0] t_wdata_m     [0:SLICE_NUM-1];
    wire [DATA_W/8-1:0] t_wstrb_m     [0:SLICE_NUM-1];
    wire                t_wlast_m     [0:SLICE_NUM-1];
    wire                t_wvalid_m    [0:SLICE_NUM-1];
    wire                t_wready_s    [0:SLICE_NUM-1];
    wire [DATA_W  -1:0] t_wdata_s     [0:SLICE_NUM-1];
    wire [DATA_W/8-1:0] t_wstrb_s     [0:SLICE_NUM-1];
    wire                t_wlast_s     [0:SLICE_NUM-1];
    wire                t_wvalid_s    [0:SLICE_NUM-1];
    wire                t_wready_m    [0:SLICE_NUM-1];

    assign wready_m  = t_wready_m [0];

    assign t_wdata_m [0] = wdata_m                    ;
    assign t_wstrb_m [0] = wstrb_m                    ;
    assign t_wlast_m [0] = wlast_m                    ;
    assign t_wvalid_m[0] = wvalid_m                   ;
    assign t_wready_s [SLICE_NUM-1] = wready_s ;
    assign wdata_s       = t_wdata_s [SLICE_NUM-1];
    assign wstrb_s       = t_wstrb_s [SLICE_NUM-1];
    assign wlast_s       = t_wlast_s [SLICE_NUM-1];
    assign wvalid_s      = t_wvalid_s[SLICE_NUM-1];
    
    for(i=0;i<SLICE_NUM;i=i+1)begin:wchannel_slice
            if(i > 0) begin
                assign t_wdata_m    [ i   ] = t_wdata_s    [ i-1 ];
                assign t_wstrb_m    [ i   ] = t_wstrb_s    [ i-1 ];
                assign t_wlast_m    [ i   ] = t_wlast_s    [ i-1 ];
                assign t_wvalid_m   [ i   ] = t_wvalid_s   [ i-1 ];
                assign t_wready_s   [ i-1 ] = t_wready_m   [ i   ];
            end
            intlv_axi256_rs_axi_rs_tpi #(
                .TMO    ( 1     ),
                .PLD_W  ( W_WIDTH )
             ) w_inst (
                .aclk_i           ( clk       ),
                .aresetn_i        ( rstn     ),
                .test_mode        ( test_mode    ),
                .valid_i          ( t_wvalid_m[i]),
                .ready_i          ( t_wready_s[i]),
                .payload_i        ({t_wdata_m [i] ,
                                    t_wstrb_m [i] ,
                                    t_wlast_m [i] 
                                  }),
                .valid_o          ( t_wvalid_s[i]),
                .ready_o          ( t_wready_m[i]),
                .payload_o        ({t_wdata_s [i] ,
                                    t_wstrb_s [i] ,
                                    t_wlast_s [i] 
                                  })
            );
        end
  end 
endgenerate

    assign  bid_m     =   bid_s    ;
    assign  bresp_m   =   bresp_s  ;
    assign  bvalid_m  =   bvalid_s ;
    assign  bready_s  =   bready_m ;
    assign  buser_m   =   buser_s  ;

    assign  rid_m     =    rid_s    ;
    assign  rdata_m   =    rdata_s  ;
    assign  rresp_m   =    rresp_s  ;
    assign  rlast_m   =    rlast_s  ;
    assign  rvalid_m  =    rvalid_s ;
    assign  rready_s  =    rready_m ;
    assign  ruser_m   =    ruser_s  ;

endmodule
// Local Variables:
// verilog-library-directories:("-y ./ -y ../")
// verilog-auto-inst-param-value:t
// End:
