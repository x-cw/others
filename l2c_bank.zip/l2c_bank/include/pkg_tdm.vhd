
-- #==========================================================================#
-- |                                                                          |
-- |  Copyright (c) 2022, Fantasy Technologies Limited and/or its         |
-- |  affiliated group companies ("Fantasy"). All rights reserved.        |
-- |  No part of this content, either material or conceptual may be copied    |
-- |  or distributed, transmitted, transcribed, stored in a retrieval system  |
-- |  or translated into any human or computer language in any form by any    |
-- |  means, electronic, mechanical manual, or otherwise, or disclosed to     |
-- |  third parties without the express written permission of Fantasy.    |
-- |                                                                          |
-- #==========================================================================#



library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
library work;





package pkg_tdm is


   ----------------------------------------------------------------------------------------------------------------------------------
   --   Enumerators
   ----------------------------------------------------------------------------------------------------------------------------------
   attribute enum_encoding : string;

   type t_e_tdm_pds_type is (
      OBJECT , -- 0
      ENDTILE  -- 1
   );
   attribute enum_encoding of t_e_tdm_pds_type : type is "0 1";
   constant E_TDM_PDS_TYPE_OBJECT  : std_logic_vector(0 downto 0) := "0";
   constant E_TDM_PDS_TYPE_ENDTILE : std_logic_vector(0 downto 0) := "1";

   function to_slv(i : t_e_tdm_pds_type ) return std_logic_vector;
   function to_t_e_tdm_pds_type(i : std_logic_vector(0 downto 0)) return t_e_tdm_pds_type;

   type t_e_tdm_fe_be_type is (
      NORMAL_KICK   , -- 00
      NULL_CONTEXT  , -- 01
      END_KICK_FENCE, -- 10
      BARRIER_FENCE   -- 11
   );
   attribute enum_encoding of t_e_tdm_fe_be_type : type is "00 01 10 11";
   constant E_TDM_FE_BE_TYPE_NORMAL_KICK    : std_logic_vector(1 downto 0) := "00";
   constant E_TDM_FE_BE_TYPE_NULL_CONTEXT   : std_logic_vector(1 downto 0) := "01";
   constant E_TDM_FE_BE_TYPE_END_KICK_FENCE : std_logic_vector(1 downto 0) := "10";
   constant E_TDM_FE_BE_TYPE_BARRIER_FENCE  : std_logic_vector(1 downto 0) := "11";

   function to_slv(i : t_e_tdm_fe_be_type ) return std_logic_vector;
   function to_t_e_tdm_fe_be_type(i : std_logic_vector(1 downto 0)) return t_e_tdm_fe_be_type;

   type t_e_tdm_dma_cmd_type is (
      CMD_STREAM_LOAD  , -- 00
      CMD_CONTEXT_LOAD , -- 01
      CMD_CONTEXT_STORE  -- 10
   );
   attribute enum_encoding of t_e_tdm_dma_cmd_type : type is "00 01 10";
   constant E_TDM_DMA_CMD_TYPE_CMD_STREAM_LOAD   : std_logic_vector(1 downto 0) := "00";
   constant E_TDM_DMA_CMD_TYPE_CMD_CONTEXT_LOAD  : std_logic_vector(1 downto 0) := "01";
   constant E_TDM_DMA_CMD_TYPE_CMD_CONTEXT_STORE : std_logic_vector(1 downto 0) := "10";

   function to_slv(i : t_e_tdm_dma_cmd_type ) return std_logic_vector;
   function to_t_e_tdm_dma_cmd_type(i : std_logic_vector(1 downto 0)) return t_e_tdm_dma_cmd_type;

   type t_e_tdm_bif_tag_type is (
      CTL_STREAM, -- 00
      CTX_HEADER, -- 01
      CTX_BUFFER  -- 10
   );
   attribute enum_encoding of t_e_tdm_bif_tag_type : type is "00 01 10";
   constant E_TDM_BIF_TAG_TYPE_CTL_STREAM : std_logic_vector(1 downto 0) := "00";
   constant E_TDM_BIF_TAG_TYPE_CTX_HEADER : std_logic_vector(1 downto 0) := "01";
   constant E_TDM_BIF_TAG_TYPE_CTX_BUFFER : std_logic_vector(1 downto 0) := "10";

   function to_slv(i : t_e_tdm_bif_tag_type ) return std_logic_vector;
   function to_t_e_tdm_bif_tag_type(i : std_logic_vector(1 downto 0)) return t_e_tdm_bif_tag_type;
end package pkg_tdm;

package body pkg_tdm is

   -- conversion function for e_tdm_pds_type enumerator
   function to_slv(i : t_e_tdm_pds_type ) return std_logic_vector is
      variable ret : std_logic_vector(0 downto 0);
   begin
      case i is
         when OBJECT  => ret := E_TDM_PDS_TYPE_OBJECT;
         when others  => ret := E_TDM_PDS_TYPE_ENDTILE;
      end case;
      return ret;
   end function;
   -- conversion function for e_tdm_pds_type enumerator
   function to_t_e_tdm_pds_type(i : std_logic_vector(0 downto 0)) return t_e_tdm_pds_type is
      variable ret : t_e_tdm_pds_type;
   begin
      case i is
         when E_TDM_PDS_TYPE_OBJECT  => ret := OBJECT;
         when others                 => ret := ENDTILE;
      end case;
      return ret;
   end function;

   -- conversion function for e_tdm_fe_be_type enumerator
   function to_slv(i : t_e_tdm_fe_be_type ) return std_logic_vector is
      variable ret : std_logic_vector(1 downto 0);
   begin
      case i is
         when NORMAL_KICK    => ret := E_TDM_FE_BE_TYPE_NORMAL_KICK;
         when NULL_CONTEXT   => ret := E_TDM_FE_BE_TYPE_NULL_CONTEXT;
         when END_KICK_FENCE => ret := E_TDM_FE_BE_TYPE_END_KICK_FENCE;
         when others         => ret := E_TDM_FE_BE_TYPE_BARRIER_FENCE;
      end case;
      return ret;
   end function;
   -- conversion function for e_tdm_fe_be_type enumerator
   function to_t_e_tdm_fe_be_type(i : std_logic_vector(1 downto 0)) return t_e_tdm_fe_be_type is
      variable ret : t_e_tdm_fe_be_type;
   begin
      case i is
         when E_TDM_FE_BE_TYPE_NORMAL_KICK    => ret := NORMAL_KICK;
         when E_TDM_FE_BE_TYPE_NULL_CONTEXT   => ret := NULL_CONTEXT;
         when E_TDM_FE_BE_TYPE_END_KICK_FENCE => ret := END_KICK_FENCE;
         when others                          => ret := BARRIER_FENCE;
      end case;
      return ret;
   end function;

   -- conversion function for e_tdm_dma_cmd_type enumerator
   function to_slv(i : t_e_tdm_dma_cmd_type ) return std_logic_vector is
      variable ret : std_logic_vector(1 downto 0);
   begin
      case i is
         when CMD_STREAM_LOAD   => ret := E_TDM_DMA_CMD_TYPE_CMD_STREAM_LOAD;
         when CMD_CONTEXT_LOAD  => ret := E_TDM_DMA_CMD_TYPE_CMD_CONTEXT_LOAD;
         when others            => ret := E_TDM_DMA_CMD_TYPE_CMD_CONTEXT_STORE;
      end case;
      return ret;
   end function;
   -- conversion function for e_tdm_dma_cmd_type enumerator
   function to_t_e_tdm_dma_cmd_type(i : std_logic_vector(1 downto 0)) return t_e_tdm_dma_cmd_type is
      variable ret : t_e_tdm_dma_cmd_type;
   begin
      case i is
         when E_TDM_DMA_CMD_TYPE_CMD_STREAM_LOAD   => ret := CMD_STREAM_LOAD;
         when E_TDM_DMA_CMD_TYPE_CMD_CONTEXT_LOAD  => ret := CMD_CONTEXT_LOAD;
         when others                               => ret := CMD_CONTEXT_STORE;
      end case;
      return ret;
   end function;

   -- conversion function for e_tdm_bif_tag_type enumerator
   function to_slv(i : t_e_tdm_bif_tag_type ) return std_logic_vector is
      variable ret : std_logic_vector(1 downto 0);
   begin
      case i is
         when CTL_STREAM => ret := E_TDM_BIF_TAG_TYPE_CTL_STREAM;
         when CTX_HEADER => ret := E_TDM_BIF_TAG_TYPE_CTX_HEADER;
         when others     => ret := E_TDM_BIF_TAG_TYPE_CTX_BUFFER;
      end case;
      return ret;
   end function;
   -- conversion function for e_tdm_bif_tag_type enumerator
   function to_t_e_tdm_bif_tag_type(i : std_logic_vector(1 downto 0)) return t_e_tdm_bif_tag_type is
      variable ret : t_e_tdm_bif_tag_type;
   begin
      case i is
         when E_TDM_BIF_TAG_TYPE_CTL_STREAM => ret := CTL_STREAM;
         when E_TDM_BIF_TAG_TYPE_CTX_HEADER => ret := CTX_HEADER;
         when others                        => ret := CTX_BUFFER;
      end case;
      return ret;
   end function;

end package body pkg_tdm;