
-- #==========================================================================#
-- |                                                                          |
-- |  Copyright (c) 2022, Fantasy Technologies Limited and/or its         |
-- |  affiliated group companies ("Fantasy"). All rights reserved.        |
-- |  No part of this content, either material or conceptual may be copied    |
-- |  or distributed, transmitted, transcribed, stored in a retrieval system  |
-- |  or translated into any human or computer language in any form by any    |
-- |  means, electronic, mechanical manual, or otherwise, or disclosed to     |
-- |  third parties without the express written permission of Fantasy.    |
-- |                                                                          |
-- #==========================================================================#



library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
library work;





package pkg_soc is

   constant AXIBUS_SOCIF_TAGIDS_WIDTH       : natural                                       := 6;
   constant AXIBUS_SOCIF_XPU_TAGIDS_WIDTH   : natural                                       := 6;
   constant SINGLE_CLOCK_DOMAIN             : natural                                       := 1;
   constant FB_CDC_CYUV_CTRL                : natural                                       := 0;
   constant MSS_SIZE_ADJUSTMENT             : natural                                       := 3;     -- by luqj at 20230222, for 8M mss bank, 1 -> 3
   constant TB_MULTICORE                    : natural                                       := 90;
   constant TB_AXI_ACE_COHERENCY_MODE       : natural                                       := 3;
--   constant DDR_EXPAND_ENABLE               : natural                                       := 1;     -- by luqj at 20240110, for ddr expand

   
   --SERIES_ID.PRODUCT_ID.RELEASE_ID   
   --0.0.0 IMG ORIGIN
   --1.0.0 GP1
   --1.1.0 GP2
   --2.0.0 G3_10SPC_3CU
   --2.1.0 G3_2SPC_3CU
   constant SERIES_ID             : std_logic_vector(15 downto 0)                 := B"0000000000000001";
   constant PRODUCT_ID             : std_logic_vector(15 downto 0)                 := B"0000000000000011";
   constant RELEASE_ID             : std_logic_vector(31 downto 0)                 := B"00000000000000000000000000000000";

end package pkg_soc;

package body pkg_soc is

end package body pkg_soc;
