/*

 * #==========================================================================#
 * |                                                                          |
 * |  Copyright (c) 2022, Fantasy Technologies Limited and/or its         |
 * |  affiliated group companies ("Fantasy"). All rights reserved.        |
 * |  No part of this content, either material or conceptual may be copied    |
 * |  or distributed, transmitted, transcribed, stored in a retrieval system  |
 * |  or translated into any human or computer language in any form by any    |
 * |  means, electronic, mechanical manual, or otherwise, or disclosed to     |
 * |  third parties without the express written permission of Fantasy.    |
 * |                                                                          |
 * #==========================================================================#

 */


package pkg_multicore_;




   localparam int                 GPU_CORE_ID_WIDTH                                  = 3;
   localparam int                 GPU_PRIMARY_CORE_ID_WIDTH                          = 24;
   localparam int                 GPU_COUNT_WIDTH                                    = 4;
   localparam int                 GPU_OFFSET_WIDTH                                   = 3;







endpackage
