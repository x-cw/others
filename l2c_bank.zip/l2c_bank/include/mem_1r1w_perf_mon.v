// +FHDR-----------------------------------------------------------------------
// Copyright (c) 2022, Innosilicon, Inc. Confidential Proprietary
// PROJECT NAME  : 
// BLOCK   NAME  : mem_1r1w_perf_mon 
// DEPARTMENT    : Front-End Department
// AUTHOR        : Liushi
// EMAIL         : lius@innosilicon.com.cn
// ----------------------------------------------------------------------------
// Release History
// VERSION  DATE        AUTHOR    DESCRIPTION
// 1.0      202503    Liushi  First initial
//
// Description   : 
// ----------------------------------------------------------------------------
// Others For More Information:
//
// -FHDR-----------------------------------------------------------------------
module mem_1r1w_perf_mon
  #( parameter
     MEM_WORDS=0,
     MEM_WIDTH=0,
     L2_MEM_WORDS= $clog2(MEM_WORDS)
     ) (
        input wire [MEM_WIDTH-1:0]    din,
        input wire [L2_MEM_WORDS-1:0] rd_addr,
        input wire                    rd_clk,
        input wire                    rd_en,

        input wire [L2_MEM_WORDS-1:0] wr_addr,
        input wire                    wr_clk,
        input wire                    wr_en,

        output wire [MEM_WIDTH-1:0]   dout
        );

  localparam MEM_BIT_EN=0;

  
`ifndef GPU_SYNTHESIS
  wire [MEM_WIDTH-1:0] dout_internal;
  wire [MEM_WIDTH-1:0] bit_en_internal={MEM_WIDTH{1'b1}};
//using register flop as memory------------
  assign dout=dout_internal;

  mem_1r1w_flops
    #(/*autoinstparam*/
      // Parameters
      .MEM_WORDS                        (MEM_WORDS),
      .MEM_WIDTH                        (MEM_WIDTH),
      .MEM_BIT_EN                       (MEM_BIT_EN),
      .L2_MEM_WORDS                     (L2_MEM_WORDS))
  flops(/*autoinst*/
        // Outputs
        .dout_internal                  (dout_internal[MEM_WIDTH-1:0]),
        // Inputs
        .din                            (din[MEM_WIDTH-1:0]),
        .rd_addr                        (rd_addr[L2_MEM_WORDS-1:0]),
        .rd_clk                         (rd_clk),
        .rd_en                          (rd_en),
        .wr_addr                        (wr_addr[L2_MEM_WORDS-1:0]),
        .wr_clk                         (wr_clk),
        .wr_en                          (wr_en),
        .bit_en_internal                (bit_en_internal[MEM_WIDTH-1:0]));
`else
  generate
//using fundary memory----------
    if(MEM_WORDS == 64)
      begin:perf_mon_32x64
        perf_mon_32x64_mem_wrapper perf_mon_32x64_mem_wrapper_u(
          .wclk(wr_clk),
          .wen(wr_en),
          .waddr(wr_addr),
          .wdata(din),
          .rclk(rd_clk),
          .ren(rd_en),
          .raddr(rd_addr),
          .rdata(dout)
         );
      end
    else if(MEM_WORDS == 128)
      begin:perf_mon_32x128
        perf_mon_32x128_mem_wrapper perf_mon_32x128_mem_wrapper_u(
          .wclk(wr_clk),
          .wen(wr_en),
          .waddr(wr_addr),
          .wdata(din),
          .rclk(rd_clk),
          .ren(rd_en),
          .raddr(rd_addr),
          .rdata(dout)
        );
      end
  endgenerate
`endif
  
endmodule 

