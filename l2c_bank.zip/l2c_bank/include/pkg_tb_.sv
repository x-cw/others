/*

 * #==========================================================================#
 * |                                                                          |
 * |  Copyright (c) 2022, Fantasy Technologies Limited and/or its         |
 * |  affiliated group companies ("Fantasy"). All rights reserved.        |
 * |  No part of this content, either material or conceptual may be copied    |
 * |  or distributed, transmitted, transcribed, stored in a retrieval system  |
 * |  or translated into any human or computer language in any form by any    |
 * |  means, electronic, mechanical manual, or otherwise, or disclosed to     |
 * |  third parties without the express written permission of Fantasy.    |
 * |                                                                          |
 * #==========================================================================#

 */


package pkg_tb_;




   localparam int                 NO_OF_OFFSETS                                      = 14;
   localparam int                 MAX_LATENCY                                        = 16383;
   localparam int                 MAX_LATENCY_LOG2                                   = 14;
   localparam int                 MAX_LIMIT_BITS                                     = 10;
   localparam int                 REORDERING_MODE                                    = 4;


   localparam                     BUS_STIM_INFILE                                    = "../infiles/current";
   localparam                     BUS_STIM_OUTFILE                                   = "../outfiles";
   localparam                     BUS_STIM_CONFIG                                    = "pdump.json.dpi";






   localparam int                 BUS_STIM_MAX_THREADS                               = 64;
   localparam int                 BUS_STIM_WRITE_ACC                                 = 0;
   localparam int                 BUS_STIM_QOS                                       = 14;
   localparam int                 BUS_STIM_SPLITTER_PIPELINE                         = 1;
   localparam int                 USER_WIDTH                                         = 9;//modified for 16chn virtualization by lifz
   localparam int                 AXI_DDR_RID_BITS                                   = 9;
   localparam int                 AXI_DDR_WID_BITS                                   = 9;
   localparam int                 CPU_TAG_BUS_WIDTH                                  = 7;  //6->7, by luqj at 20231008
   localparam int                 CPU_USER_BUS_WIDTH                                 = 8;
   localparam int                 GPU_TB_MEM_WIDTH_RATIO                             = 1;
   localparam int                 MEM_ADAPTER_RID_BITS                               = 7;  //6->7, by luqj at 20231008
   localparam int                 MEM_ADAPTER_WID_BITS                               = 7;  //6->7, by luqj at 20231008
   localparam int                 NUM_GPU_MEMBUS                                     = 4;
   localparam int                 NUM_GPU_MASTERS                                    = 4;
   localparam int                 NUM_NOC_MASTERS                                    = 5;
   localparam int                 NUM_NOC_SLAVES                                     = 4;
   localparam int                 NUM_MEM_PORTS                                      = 4;
   localparam logic [47 : 0]      GC_UPPER_LIMIT                                    = 48'h800001000000;
   localparam logic [47 : 0]      EMU_UPPER_LIMIT                                    = 48'h800001004000;
   localparam logic [8 : 0]       ACECACHE_UNIQUE_AXUSER                             = 9'h1FF;//modified for 16chn virtualization by lifz
   localparam int                 TB_MEM_DATA_BUS_WIDTH                              = 256;
   localparam int                 LOCAL_MEM_DATA_WIDTH                               = 256;
   localparam int                 TB_MEM_DATA_BUS_WIDTH_DIV8                         = 32;
   localparam int                 TB_MEM_ADDR_BUS_WIDTH                              = 40;
   localparam int                 LOCAL_MEM_ADDR_WIDTH                               = 40;
   localparam int                 CPU_ADDR_BUS_WIDTH                                 = 48;
   localparam int                 ACECACHE_ADDR_WIDTH                                = 40;
   localparam int                 BUS_STIM_MEM_ADDR_WIDTH                            = 48;
   localparam int                 BUS_STIM_WIDTH                                     = 256;
   localparam int                 CPU_DATA_BUS_WIDTH                                 = 256;
   localparam int                 BUS_STIM_MEM_DATA_WIDTH                            = 256;
   localparam int                 REGBANK_BUS_WIDTH                                  = 64;
   localparam int                 TB_WDATA_SPLIT_FIFO_DEPTH                          = 128;







endpackage
