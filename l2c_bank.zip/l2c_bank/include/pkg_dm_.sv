/*

 * #==========================================================================#
 * |                                                                          |
 * |  Copyright (c) 2022, Fantasy Technologies Limited and/or its         |
 * |  affiliated group companies ("Fantasy"). All rights reserved.        |
 * |  No part of this content, either material or conceptual may be copied    |
 * |  or distributed, transmitted, transcribed, stored in a retrieval system  |
 * |  or translated into any human or computer language in any form by any    |
 * |  means, electronic, mechanical manual, or otherwise, or disclosed to     |
 * |  third parties without the express written permission of Fantasy.    |
 * |                                                                          |
 * #==========================================================================#

 */


package pkg_dm_;

   localparam int                 DATAMASTER_BITS                                    = 3;
   localparam int                 NUM_DATAMASTERS                                    = 6;

   localparam int                 CPC0                                               = 0;
   localparam int                 CPC1                                               = 1;
   localparam int                 CPC2                                               = 2;
   localparam int                 CPC3                                               = 3;
   localparam logic [2 : 0]       SLV_CPC0                                           = 3'b000;
   localparam logic [2 : 0]       SLV_CPC1                                           = 3'b001;
   localparam logic [2 : 0]       SLV_CPC2                                           = 3'b010;
   localparam logic [2 : 0]       SLV_CPC3                                           = 3'b011;

// Keep old constant to solve lint error
   localparam int                 VTXDM                                              = 0;
   localparam int                 PXLDM                                              = 1;
   localparam int                 CMPDM                                              = 2;
   localparam int                 RAYDM                                              = 3;
   localparam int                 TESSDM                                             = 4;
   localparam int                 FSTRDM                                             = 5;
   localparam logic [2 : 0]       SLV_VTXDM                                          = 3'b000;
   localparam logic [2 : 0]       SLV_PXLDM                                          = 3'b001;
   localparam logic [2 : 0]       SLV_CMPDM                                          = 3'b010;
   localparam logic [2 : 0]       SLV_RAYDM                                          = 3'b011;
   localparam logic [2 : 0]       SLV_TESSDM                                         = 3'b100;
   localparam logic [2 : 0]       SLV_FSTRDM                                         = 3'b101;

   //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
   //   Enumerators
   //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//   typedef enum logic [2 : 0] {
//      E_DATA_MASTER_VERTEX     = 3'b000,
//      E_DATA_MASTER_PIXEL      = 3'b001,
//      E_DATA_MASTER_COMPUTE    = 3'b010,
//      E_DATA_MASTER_RAY        = 3'b011,
//      E_DATA_MASTER_DOMAIN     = 3'b100,
//      E_DATA_MASTER_FASTRENDER = 3'b101 
//   } t_e_data_master;

endpackage
