
-- #==========================================================================#
-- |                                                                          |
-- |  Copyright (c) 2022, Fantasy Technologies Limited and/or its         |
-- |  affiliated group companies ("Fantasy"). All rights reserved.        |
-- |  No part of this content, either material or conceptual may be copied    |
-- |  or distributed, transmitted, transcribed, stored in a retrieval system  |
-- |  or translated into any human or computer language in any form by any    |
-- |  means, electronic, mechanical manual, or otherwise, or disclosed to     |
-- |  third parties without the express written permission of Fantasy.    |
-- |                                                                          |
-- #==========================================================================#



library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
library work;





package pkg_tb is

   constant NO_OF_OFFSETS                   : natural                                       := 14;
   constant MAX_LATENCY                     : natural                                       := 16383;
   constant MAX_LATENCY_LOG2                : natural                                       := 14;
   constant MAX_LIMIT_BITS                  : natural                                       := 10;
   constant REORDERING_MODE                 : natural                                       := 4;
   constant BUS_STIM_INFILE                 : string                                        := "../infiles/current";
   constant BUS_STIM_OUTFILE                : string                                        := "../outfiles";
   constant BUS_STIM_CONFIG                 : string                                        := "pdump.json.dpi";
   constant BUS_STIM_MAX_THREADS            : natural                                       := 64;
   constant BUS_STIM_WRITE_ACC              : natural                                       := 0;
   constant BUS_STIM_QOS                    : natural                                       := 14;
   constant BUS_STIM_SPLITTER_PIPELINE      : natural                                       := 1;
   constant USER_WIDTH                      : natural                                       := 9;--modified for 16chn virtualization by lifz
   constant AXI_DDR_RID_BITS                : natural                                       := 9;
   constant AXI_DDR_WID_BITS                : natural                                       := 9;
   constant CPU_TAG_BUS_WIDTH               : natural                                       := 7;  -- 6->7, by luqj at 20231008
   constant CPU_USER_BUS_WIDTH              : natural                                       := 8;
   constant GPU_TB_MEM_WIDTH_RATIO          : natural                                       := 1;
   constant MEM_ADAPTER_RID_BITS            : natural                                       := 7;  -- 6->7, by luqj at 20231008
   constant MEM_ADAPTER_WID_BITS            : natural                                       := 7;  -- 6->7, by luqj at 20231008
   constant NUM_GPU_MEMBUS                  : natural                                       := 4;
   constant NUM_GPU_MASTERS                 : natural                                       := 4;
   constant NUM_NOC_MASTERS                 : natural                                       := 5;
   constant NUM_NOC_SLAVES                  : natural                                       := 4;
   constant NUM_MEM_PORTS                   : natural                                       := 4;
   constant GC_UPPER_LIMIT                 : std_logic_vector(47 downto 0)                 := X"800001000000";
   constant EMU_UPPER_LIMIT                 : std_logic_vector(47 downto 0)                 := X"800001004000";
   constant ACECACHE_UNIQUE_AXUSER          : std_logic_vector(8 downto 0)                  := "111111111";--modified for 16chn virtualization by lifz
   constant TB_MEM_DATA_BUS_WIDTH           : natural                                       := 256;
   constant LOCAL_MEM_DATA_WIDTH            : natural                                       := 256;
   constant TB_MEM_DATA_BUS_WIDTH_DIV8      : natural                                       := 32;
   constant TB_MEM_ADDR_BUS_WIDTH           : natural                                       := 40;
   constant LOCAL_MEM_ADDR_WIDTH            : natural                                       := 40;
   constant CPU_ADDR_BUS_WIDTH              : natural                                       := 48;
   constant ACECACHE_ADDR_WIDTH             : natural                                       := 40;
   constant BUS_STIM_MEM_ADDR_WIDTH         : natural                                       := 48;
   constant BUS_STIM_WIDTH                  : natural                                       := 256;
   constant CPU_DATA_BUS_WIDTH              : natural                                       := 256;
   constant BUS_STIM_MEM_DATA_WIDTH         : natural                                       := 256;
   constant REGBANK_BUS_WIDTH               : natural                                       := 64;
   constant TB_WDATA_SPLIT_FIFO_DEPTH       : natural                                       := 128;


end package pkg_tb;

package body pkg_tb is

end package body pkg_tb;
