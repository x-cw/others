
-- #==========================================================================#
-- |                                                                          |
-- |  Copyright (c) 2022, Fantasy Technologies Limited and/or its         |
-- |  affiliated group companies ("Fantasy"). All rights reserved.        |
-- |  No part of this content, either material or conceptual may be copied    |
-- |  or distributed, transmitted, transcribed, stored in a retrieval system  |
-- |  or translated into any human or computer language in any form by any    |
-- |  means, electronic, mechanical manual, or otherwise, or disclosed to     |
-- |  third parties without the express written permission of Fantasy.    |
-- |                                                                          |
-- #==========================================================================#



library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
library work;





package pkg_tessellation is

   constant NUM_CONCURRENT_HS_PER_SPC       : natural                                       := 48; --ori: 32
   constant TESS_SYNC_ID_BITS               : natural                                       := 6; -- oir: 5
   constant MAX_HS_SPILL_IDS                : natural                                       := 60; --ori: 40
   constant MAX_HS_SPILL_ID_BITS            : natural                                       := 6;
   constant MAX_HS_TASKS_PER_CLUSTER        : natural                                       := 16;
   constant MAX_HS_TASKS_PER_SPC            : natural                                       := 48; --ori: 32


end package pkg_tessellation;

package body pkg_tessellation is

end package body pkg_tessellation;