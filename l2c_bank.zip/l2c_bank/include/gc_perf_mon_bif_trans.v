// +FHDR-----------------------------------------------------------------------
// Copyright (c) 2022, Innosilicon, Inc. Confidential Proprietary
// PROJECT NAME  : 
// BLOCK   NAME  : gc_perf_monitor_bif 
// DEPARTMENT    : Front-End Department
// AUTHOR        : Liushi
// EMAIL         : lius@innosilicon.com.cn
// ----------------------------------------------------------------------------
// Release History
// VERSION  DATE        AUTHOR    DESCRIPTION
// 1.0      20241016    Liushi  First initial
//
// Description   : 
// ----------------------------------------------------------------------------
// Others For More Information:
//
// -FHDR-----------------------------------------------------------------------
module gc_perf_mon_bif_trans(
/*AUTOARG*/
   // Outputs
   obuf_data_ready, perf_mon_bif_cmd_valid,
   perf_mon_bif_cmd_operation, perf_mon_bif_cmd_persistence,
   perf_mon_bif_cmd_ctxt_pasid, perf_mon_bif_cmd_l1_policy,
   perf_mon_bif_cmd_l2_policy, perf_mon_bif_cmd_l2_prefetch_size,
   perf_mon_bif_cmd_vaddress, perf_mon_bif_cmd_burst_length,
   perf_mon_bif_cmd_tag_sb, perf_mon_bif_write_valid,
   perf_mon_bif_write_mask, perf_mon_bif_write_data,
   perf_mon_bif_rtn_enable, perf_mon_bif_rtn_credit,
   bif_cmd_data_atv_cnt, fence_end,
   // Inputs
   clk, rst_n, clear, memory_base_addr, addr_offset_r_sft6,
   burst_data_num, obuf_data_valid, obuf_rdata,
   reg_bif_cmd_persistence, reg_bif_cmd_ctxt_pasid,
   reg_bif_cmd_l1_policy, reg_bif_cmd_l2_policy,
   reg_bif_cmd_l2_prefetch_size, reg_fence_interval,
   perf_mon_bif_cmd_enable, perf_mon_bif_write_enable,
   perf_mon_bif_rtn_valid, perf_mon_bif_rtn_fence,
   perf_mon_bif_rtn_data, perf_mon_bif_rtn_tag_sb,
   perf_mon_bif_fence_times, dump_ok_num, overflow_cnt,
   fence_times_cal_over_r1, perf_mon_last_dump_times
   );


  input              clk;
  input              rst_n;
  //control signals--------
  input              clear;
  input [41:0]       memory_base_addr;
  input [25:0]       addr_offset_r_sft6;
  input [2:0]        burst_data_num;
  input [31:0]       dump_ok_num;
  input [6:0]        overflow_cnt;
  input              fence_times_cal_over_r1;
  input [5:0]        perf_mon_last_dump_times;
  output reg [6:0]   bif_cmd_data_atv_cnt;
  output             fence_end;
  //----------------------------
  //----valid/ready with obuf-----------
  input              obuf_data_valid;
  output             obuf_data_ready;
  input [511:0]      obuf_rdata;
  //----------------------------------
  //bif control registers-----------
  input [1:0]        reg_bif_cmd_persistence;
  input [5:0]        reg_bif_cmd_ctxt_pasid;
  input [1:0]        reg_bif_cmd_l1_policy;
  input              reg_bif_cmd_l2_policy;
  input              reg_bif_cmd_l2_prefetch_size;
  input [5:0]        reg_fence_interval;
  //-------------------------------
  //BIF interface---------------
  output  reg        perf_mon_bif_cmd_valid;
  input              perf_mon_bif_cmd_enable;
  output reg [3:0]   perf_mon_bif_cmd_operation;
  output [1:0]       perf_mon_bif_cmd_persistence;
  output [5:0]       perf_mon_bif_cmd_ctxt_pasid;
  output [1:0]       perf_mon_bif_cmd_l1_policy;
  output             perf_mon_bif_cmd_l2_policy;
  output             perf_mon_bif_cmd_l2_prefetch_size;
  output reg [41:0]  perf_mon_bif_cmd_vaddress;
  output [1:0]       perf_mon_bif_cmd_burst_length;
  output [6:0]       perf_mon_bif_cmd_tag_sb;
  output reg         perf_mon_bif_write_valid;
  input              perf_mon_bif_write_enable;
  output [63:0]      perf_mon_bif_write_mask;
  output [511:0]     perf_mon_bif_write_data;
  input              perf_mon_bif_rtn_valid;
  output             perf_mon_bif_rtn_enable;
  output reg         perf_mon_bif_rtn_credit;
  input              perf_mon_bif_rtn_fence;
  input  [511:0]     perf_mon_bif_rtn_data;
  input  [6:0]       perf_mon_bif_rtn_tag_sb;
  input  [23:0]      perf_mon_bif_fence_times;
  //----------------------------
  
  reg                obuf_data_valid_d0;
  reg                cmd_data_start;
  reg                cmd_fence_start;
  wire               bif_data_start;
  reg [1:0]          wdata_cnt;
  wire               data_last;
  wire [6:0]         fence_interval;
  reg                operation_4_trigger;
  reg                cmd_data_start_d0;
  wire               fence;
  reg                fence_r;
  reg                data_last_r0;
  reg                data_last_r1;
  reg                fence_end;
  reg [15:0]         fence_cnt;
  reg [11:0]         data_last_cnt;
  reg [11:0]         cmd_data_cnt;
  reg                fence_lock;
  reg                fence_lock_d0;
  wire               fence_lock_neg;
  
  assign  fence_interval = {1'b0,reg_fence_interval} + 1;
  
  //generate bif command-----
  always @(posedge clk or negedge rst_n)begin
    if(~rst_n)begin
      obuf_data_valid_d0 <= 1'b0;
      cmd_data_start_d0 <= 1'b0;
    end
    else begin
      obuf_data_valid_d0 <= obuf_data_valid;
      cmd_data_start_d0  <= cmd_data_start;
    end
  end

  always @(posedge clk or negedge rst_n)begin
    if(~rst_n)
      operation_4_trigger <= 1'b0;
    else if(cmd_data_start)
      operation_4_trigger <= 1'b0;
    else if(!obuf_data_valid_d0 && obuf_data_valid)
      operation_4_trigger <= 1'b1;
  end

  always @(posedge clk or negedge rst_n)begin
    if(~rst_n)
      cmd_data_start <= 1'b0;
    else if(operation_4_trigger && (!cmd_fence_start)&&(!fence_r)) //if fence hankshake not success,wait for fence handshake then send store command.
      cmd_data_start <= 1'b1;
    else 
      cmd_data_start <= 1'b0;
  end
  
  always @(posedge clk or negedge rst_n)begin
    if(~rst_n)
      perf_mon_bif_cmd_valid <= 1'b0;
    else if(clear)
      perf_mon_bif_cmd_valid <= 1'b0;
    else if(perf_mon_bif_cmd_valid && perf_mon_bif_cmd_enable)
      perf_mon_bif_cmd_valid <= 1'b0;
    else if((!cmd_data_start && cmd_data_start_d0) || cmd_fence_start)
      perf_mon_bif_cmd_valid <= 1'b1;
  end

  always @(posedge clk or negedge rst_n)begin
    if(~rst_n)
      perf_mon_bif_cmd_vaddress  <= {42{1'b0}};
    else if(!cmd_data_start_d0 && cmd_data_start)
      perf_mon_bif_cmd_vaddress  <= memory_base_addr + {10'b0,dump_ok_num}*{16'b0,addr_offset_r_sft6};//before cmd_data_start,the dump_ok_num is stable for every dump address caculate
  end

  //generate bif data-----------
  assign bif_data_start = perf_mon_bif_cmd_valid && perf_mon_bif_cmd_enable && (perf_mon_bif_cmd_operation == 4'd4);
  
  always @(posedge clk or negedge rst_n)begin
    if(~rst_n)
      perf_mon_bif_write_valid <= 1'b0;
    else if(clear)
      perf_mon_bif_write_valid <= 1'b0;
    else if(perf_mon_bif_write_valid & perf_mon_bif_write_enable & data_last)
      perf_mon_bif_write_valid <= 1'b0;
    else if(bif_data_start)
      perf_mon_bif_write_valid <= 1'b1;
  end
  
  always @(posedge clk or negedge rst_n)begin
    if(~rst_n)
      wdata_cnt <= 2'b0;
    else if(clear)
      wdata_cnt <= 2'b0;
    else if(perf_mon_bif_write_valid & perf_mon_bif_write_enable)begin
      if(wdata_cnt == burst_data_num -1'b1)
        wdata_cnt <= 2'b0;
      else
        wdata_cnt <= wdata_cnt + 1'b1;
    end
  end
  
  assign data_last = perf_mon_bif_write_valid && perf_mon_bif_write_enable && (wdata_cnt == burst_data_num -1'b1);//2'b11;
  
  assign obuf_data_ready = perf_mon_bif_write_valid&perf_mon_bif_write_enable;
  
  assign perf_mon_bif_write_data = obuf_rdata;
  
  //generate bif fence command----------------
  always @(posedge clk or negedge rst_n)begin
    if(~rst_n)
       bif_cmd_data_atv_cnt <= 7'b0;
     else if(perf_mon_bif_cmd_valid && perf_mon_bif_cmd_enable && (perf_mon_bif_cmd_operation == 4'd8))
       bif_cmd_data_atv_cnt <= 7'b0;
     else if(data_last)
       bif_cmd_data_atv_cnt <= bif_cmd_data_atv_cnt + 1'b1;
  end

  //assign cmd_fence_start = !cmd_fence_start_tmp_d0 && cmd_fence_start_tmp;
  always @(posedge clk or negedge rst_n)begin
    if(~rst_n)begin
      data_last_r0 <= 1'b0;
      data_last_r1 <= 1'b0;
      fence_r     <= 1'b0;
    end
    else begin
      data_last_r0 <= data_last;
      data_last_r1 <= data_last_r0;
      fence_r     <= fence;
    end
  end

  assign fence = (perf_mon_bif_cmd_valid && perf_mon_bif_cmd_enable && (perf_mon_bif_cmd_operation == 4'd8));

  always @(posedge clk or negedge rst_n)begin
    if(~rst_n)begin
      fence_cnt <= 16'b0;
    end
    else if(fence) begin
      if(fence_cnt == perf_mon_bif_fence_times - 1)
        fence_cnt <= 16'b0;
      else
        fence_cnt <= fence_cnt + 1'b1; 
    end
  end

  always @(posedge clk or negedge rst_n)begin
    if(~rst_n)begin
      fence_end <= 1'b0;
    end
    else if(clear)
      fence_end <= 1'b0;
    else if(fence&&fence_cnt == perf_mon_bif_fence_times - 1) begin
      fence_end <=1'b1;
    end
  end

  always @(posedge clk or negedge rst_n)begin
    if(~rst_n)
      cmd_data_cnt<= 12'b0;
    else if(fence_lock_neg)
      cmd_data_cnt<= 12'b0;
    else if(!cmd_data_start_d0 && cmd_data_start)
      cmd_data_cnt<= cmd_data_cnt+ 1'b1;
  end

  always @(posedge clk or negedge rst_n)begin
    if(~rst_n)
      data_last_cnt<= 12'b0;
    else if(fence_lock_neg)
      data_last_cnt<= 12'b0;
    else if(data_last)
      data_last_cnt<= data_last_cnt + 1'b1;
  end

  always @(posedge clk or negedge rst_n)begin
    if(~rst_n)
      fence_lock <= 1'b0;
    else if(!cmd_data_start_d0 && cmd_data_start)
      fence_lock <= 1'b1;
    else if((cmd_data_cnt >= 12'd1) && (data_last_cnt + {5'b0,overflow_cnt} >= {6'b0,reg_fence_interval})&& data_last && (data_last_cnt == cmd_data_cnt - 1'b1))
      fence_lock <= 1'b0;
    else if(cmd_data_cnt == 12'd0 && (overflow_cnt >= fence_interval))
      fence_lock <= 1'b0;
    else if(fence_times_cal_over_r1)begin
      if((cmd_data_cnt >= 12'd1) && (data_last_cnt + {5'b0,overflow_cnt} >= perf_mon_last_dump_times + 1'b1)&& (data_last_cnt == cmd_data_cnt ))
        fence_lock <= 1'b0;
      else if(cmd_data_cnt == 12'd0 && (overflow_cnt >= perf_mon_last_dump_times + 1'b1))
        fence_lock <= 1'b0;
    end
  end

  always @(posedge clk or negedge rst_n)begin
    if(~rst_n)
      fence_lock_d0 <= 1'b0;
    else
      fence_lock_d0 <= fence_lock;
  end
  
  assign fence_lock_neg = !fence_lock && fence_lock_d0;

  always @(posedge clk or negedge rst_n)begin
    if(~rst_n)
      cmd_fence_start <= 1'b0;
    else if(perf_mon_bif_cmd_valid && perf_mon_bif_cmd_enable && (perf_mon_bif_cmd_operation == 4'd8))begin
      cmd_fence_start <= 1'b0;
    end
    else if(!fence_lock)begin 
    //else if(fence_lock == 1'b0)begin
      if(data_last_r1 && (bif_cmd_data_atv_cnt + overflow_cnt >= fence_interval))
        cmd_fence_start <= 1'b1;
      else if(fence_r && (overflow_cnt >= fence_interval))
        cmd_fence_start <= 1'b1;
      else if(data_last_r1 && fence_times_cal_over_r1 && (bif_cmd_data_atv_cnt + overflow_cnt == perf_mon_last_dump_times + 1'b1))
        cmd_fence_start <= 1'b1;
  //   else if(bif_cmd_data_atv_cnt == 7'b0 && fence_times_cal_over_r1 && (bif_cmd_data_atv_cnt + overflow_cnt == perf_mon_last_dump_times + 1'b1) && (!fence_end)) .
      else if(fence_times_cal_over_r1 && (bif_cmd_data_atv_cnt + overflow_cnt == perf_mon_last_dump_times + 1'b1) && (!fence_end)) 
        cmd_fence_start <= 1'b1;
    end
  end
    
  always @(posedge clk or negedge rst_n)begin
    if(~rst_n)
      perf_mon_bif_cmd_operation  <= 4'b0;
    else if(clear)
      perf_mon_bif_cmd_operation  <= 4'b0;
    else if(perf_mon_bif_cmd_valid & perf_mon_bif_cmd_enable)
      perf_mon_bif_cmd_operation  <= 4'b0;
    else if(cmd_data_start) 
      perf_mon_bif_cmd_operation  <= 4'd4;
    else if(cmd_fence_start) 
      perf_mon_bif_cmd_operation  <= 4'd8;
  end

  //generate some bif control signals----------- 
  
  assign perf_mon_bif_cmd_persistence       = reg_bif_cmd_persistence;
  assign perf_mon_bif_cmd_ctxt_pasid        = reg_bif_cmd_ctxt_pasid;
  assign perf_mon_bif_cmd_l1_policy         = reg_bif_cmd_l1_policy;
  assign perf_mon_bif_cmd_l2_policy         = reg_bif_cmd_l2_policy;
  assign perf_mon_bif_cmd_l2_prefetch_size  = reg_bif_cmd_l2_prefetch_size;
  assign perf_mon_bif_cmd_burst_length      = burst_data_num - 1'b1;
  assign perf_mon_bif_cmd_tag_sb            = 7'b0;
  assign perf_mon_bif_write_mask            = 64'b0;
  assign perf_mon_bif_rtn_enable            = 1'b1;

  always @(posedge clk or negedge rst_n)begin
    if(~rst_n)
      perf_mon_bif_rtn_credit <= 1'b0;
    else if(perf_mon_bif_rtn_valid & perf_mon_bif_rtn_enable & perf_mon_bif_rtn_fence)
      perf_mon_bif_rtn_credit <= 1'b1;
    else
      perf_mon_bif_rtn_credit <= 1'b0;
  end

endmodule
