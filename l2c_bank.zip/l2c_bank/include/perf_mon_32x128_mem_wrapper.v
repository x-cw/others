module perf_mon_32x128_mem_wrapper(
/*AUTOARG*/
   // Outputs
   rdata,
   // Inputs
   wclk, wen, waddr, wdata, rclk, ren, raddr
   );


input wclk;
input wen;
input [6:0] waddr;
input [31:0] wdata;
input  rclk;
input ren;
input [6:0] raddr;
output [31:0] rdata;


wire [1:0] MCSRD = 2'b01;
wire KCS = 1'b0;
wire [1:0] MCSWR = 2'b01;
wire [2:0] ADME = 3'b000;
wire DFTRAM = 1'b0;
wire SE = 1'b0;
wire SI_D_L = 1'b0;
wire SI_D_R = 1'b0;
//wire CRE1 = 1'b0;
//wire CRE2 = 1'b0;
wire CRE = 1'b0;
//wire [2:0] FCA1 = 3'b0;
//wire [2:0] FCA2 = 3'b0;
wire [3:0] FCA = 4'b0;
wire RET = 1'b0;

`ifndef GPU_SYNTHESIS
`else

//ln05lpe_a00_mc_rf2r_hsr_rvt_128x32m1b2c0_GPU_DP_128X32_P32_ID20026 GPU_DP_128X32_P32_ID20026_u(
ln04lpp_s00_mc_rf2r_hsr_lvt_128x32m1b2c0_GPU_DP_128X32_P32_ID20026 GPU_DP_128X32_P32_ID20026_u(
/*AUTOINST*/
                                                                                               // Outputs
                                                                                               .SO_D_R          (),
                                                                                               .DOUT            (rdata),
                                                                                               // Inouts
                                                                                               //.VDDPE           (VDDPE),
                                                                                               //.VDDCE           (VDDCE),
                                                                                               //.VSSE            (VSSE),
                                                                                               // Inputs
                                                                                               .RA              (raddr),
                                                                                               .WA              (waddr),
                                                                                               .DI              (wdata),
                                                                                               .RCK             (rclk),
                                                                                               .WCK             (wclk),
                                                                                               .REN             (~ren),
                                                                                               .WEN             (~wen),
                                                                                               .DFTRAM          (DFTRAM),
                                                                                               .SE              (SE),
                                                                                               .SI_D_R          (SI_D_R),
                                                                                               .MCSRD           (MCSRD),
                                                                                               .KCS             (KCS),
                                                                                               .MCSWR           (MCSWR),
                                                                                               .ADME            (ADME),
                                                                                               .CRE             (CRE),
                                                                                               .FCA             (FCA),
                                                                                               .RET             (RET));

      `endif

endmodule
// Local Variables:
// verilog-library-directories:("." )
// verilog-auto-inst-param-value:t
// End:
