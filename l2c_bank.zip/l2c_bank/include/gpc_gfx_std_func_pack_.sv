/*

 * #==========================================================================#
 * |                                                                          |
 * |  Copyright (c) 2023, Fantasy Technologies Limited and/or its         |
 * |  affiliated group companies ("Fantasy"). All rights reserved.        |
 * |  No part of this content, either material or conceptual may be copied    |
 * |  or distributed, transmitted, transcribed, stored in a retrieval system  |
 * |  or translated into any human or computer language in any form by any    |
 * |  means, electronic, mechanical manual, or otherwise, or disclosed to     |
 * |  third parties without the express written permission of Fantasy.    |
 * |                                                                          |
 * #==========================================================================#

 */

package gpc_gfx_std_func_pack_;

   // clock gate ideal fanout (set in gpc_technology.tcl)
   localparam GPC_CLK_GATE_FANOUT = 32;

   // /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
   // Function Name: gpc_log2_roundup
   // Function Type: synthesisable
   // Function Input Parameters:
   //    d - must be a static value (i.e. not driven by logic)
   // Function Return Value:
   //    log2(d)
   // Function Description:
   //    If d = 1, then 1 will be returned as the result rather than 0
   //    Otherwise calls gpc2_log2 as normal
   // /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
   function automatic integer gpc_log2_roundup(integer d);
      if (d <= 1)                                        // On d = 1, roundup to 1 instead of returning 0
         return 1;
      else
         return $clog2(d);
   endfunction : gpc_log2_roundup

   // given a positive integer, will return the
   // closest powerof2 less than or equal to
   // get_closest_pow2(7) = 4, get_closest_pow2(16) = 16
   function automatic integer get_closest_pow2(integer d);
      integer tmp = 1;
      for (integer COUNT = 0; COUNT < 31; COUNT++) begin // N.B. Synopsys requires static loops.
         if (tmp*2 <= d)
            tmp = tmp*2;
      end
      if (d == 0)
         tmp = 0;

      return tmp;
   endfunction : get_closest_pow2

   // given two positive integers a,b
   // will return ceil(a/b)
   function automatic integer get_ceil_quotient (integer a, integer b);
      if (a % b == 0)
         return a/b;
      else
         return a/b + 1;
   endfunction : get_ceil_quotient

   // /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
   // Function Name: gpc_max
   // Function Type: synthesisable
   // Function Input Parameters:
   //    a,b  - should be static values
   // Function Return Value:
   //    max(a,b)
   // Function Description:
   //    function implementation is trivial. It is intended for use with static values, for example to configure the width of a vector
   //    instantiation.
   //    function should not be driven by logic, as it is preferable to operate on std_logic_vectors in such cases in order to reduce
   //    reliance on optimisation by synthesis tool.
   // /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
   function automatic integer gpc_max(integer a, integer b);
      if (a > b)
         return a;
      else
        return b;
   endfunction : gpc_max
   // /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
   // Function Name: gpc_min
   // Function Type: synthesisable
   // Function Input Parameters:
   //    a,b  - should be static values
   // Function Return Value:
   //    min(a,b)
   // Function Description:
   //    function implementation is trivial. It is intended for use with static values, for example to configure the width of a vector
   //    instantiation.
   //    function should not be driven by logic, as it is preferable to operate on std_logic_vectors in such cases in order to reduce
   //    reliance on optimisation by synthesis tool.
   // /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
   function automatic integer gpc_min(integer a, integer b);
      if (a < b)
        return a;
      else
        return b;
   endfunction : gpc_min


endpackage : gpc_gfx_std_func_pack_
