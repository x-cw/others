module perf_mon_32x64_mem_wrapper(
/*AUTOARG*/
   // Outputs
   rdata,
   // Inputs
   wclk, wen, waddr, wdata, rclk, ren, raddr
   );


input wclk;
input wen;
input [5:0] waddr;
input [31:0] wdata;
input  rclk;
input ren;
input [5:0] raddr;
output [31:0] rdata;


wire [1:0] MCSRD = 2'b01;
wire KCS = 1'b0;
wire [1:0] MCSWR = 2'b01;
wire [1:0] MCSCC = 2'b01;
wire BPE =1'b0;
wire BCE =1'b0;
//wire [2:0] ADME = 3'b100;
wire [2:0] ADME = 3'b110;
wire DFTRAM = 1'b0;
wire SE = 1'b0;
//wire SI_D_L = 1'b0;
wire SI_D_R = 1'b0;
//wire CRE1 = 1'b0;
//wire CRE2 = 1'b0;
wire CRE = 1'b0;
//wire [2:0] FCA1 = 1024'b0;
//wire [2:0] FCA2 = 1024'b0;
wire [3:0] FCA = 4'b0;
wire RET = 1'b0;

`ifndef GPU_SYNTHESIS
`else

ln04lpp_s00_mc_rd2rs_uhsr_lvt_64x32m2b1c0_GPU_DP_64X32_P32_ID20025 GPU_DP_64X32_P32_ID20025_u(
///*AUTOINST*/
                                                                                              // Outputs
                                                                                              .DOUT             (rdata),
                                                                                              .SO_D_R           (),
                                                                                              // Inouts
                                                                                              //.VDDE             (VDDE),
                                                                                              //.VSSE             (VSSE),
                                                                                              // Inputs
                                                                                              .CK               (wclk),
                                                                                              .REN              (~ren),
                                                                                              .WEN              (~wen),
                                                                                              .DI               (wdata),
                                                                                              .RA               (raddr),
                                                                                              .WA               (waddr),
                                                                                              .MCSRD            (MCSRD[1:0]),
                                                                                              .MCSWR            (MCSWR[1:0]),
                                                                                              .MCSCC            (MCSCC[1:0]),
                                                                                              .BPE              (BPE),
                                                                                              .BCE              (BCE),
                                                                                              .SI_D_R           (SI_D_R),
                                                                                              .DFTRAM           (DFTRAM),
                                                                                              .SE               (SE),
                                                                                              .CRE              (CRE),
                                                                                              .FCA              (FCA),
                                                                                              .ADME             (ADME[2:0]));

 `endif

endmodule
// Local Variables:
// verilog-library-directories:("." )
// verilog-auto-inst-param-value:t
// End:
