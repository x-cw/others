//-----------------------------------------------------------------------------
// Purpose : log2 value rounded up calculation
//-----------------------------------------------------------------------------

function integer lib_func_clog2;
  input  [31:0] value;
  reg    [31:0] tmp;
  begin
    tmp = value - 1;
    for (lib_func_clog2 = 0;
         tmp > 0;
         lib_func_clog2 = lib_func_clog2 + 1)
      tmp = tmp >> 1;
  end
endfunction // lib_func_clog2
