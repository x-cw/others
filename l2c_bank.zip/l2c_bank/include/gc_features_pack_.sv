/*

 * #==========================================================================#
 * |                                                                          |
 * |  Copyright (c) 2022, Fantasy Technologies Limited and/or its         |
 * |  affiliated group companies ("Fantasy"). All rights reserved.        |
 * |  No part of this content, either material or conceptual may be copied    |
 * |  or distributed, transmitted, transcribed, stored in a retrieval system  |
 * |  or translated into any human or computer language in any form by any    |
 * |  means, electronic, mechanical manual, or otherwise, or disclosed to     |
 * |  third parties without the express written permission of Fantasy.    |
 * |                                                                          |
 * #==========================================================================#

 */


package gc_features_pack_;

  
   
   localparam logic               AXIBUS                                             = 1;
   localparam logic               AXIBUS_SOCIF                                       = 1;
   localparam int                 AXIBUS_SOCIF_ADDR_WIDTH                            = 32;
   localparam int                 AXIBUS_SOCIF_DATA_WIDTH                            = 32;
   localparam int                 AXIBUS_SOCIF_RD_FIFO_DEPTH                         = 64;
   localparam int                 AXIBUS_SOCIF_RD_FIFO_DEPTH_LOG2                    = 6;
   localparam int                 AXIBUS_SOCIF_RRESP_FIFO_DEPTH                      = 64;
   localparam int                 AXIBUS_SOCIF_TAGSB_WIDTH                           = 4;
   localparam int                 AXIBUS_SOCIF_WRESP_FIFO_DEPTH                      = 64;
   
   localparam int                 BUSWIDTH                                           = 512;
   localparam logic               BUSWIDTH256                                        = 1;
   localparam int                 BUSWIDTH_LOG2                                      = $clog2(BUSWIDTH);
   localparam int                 BUSWIDTH_WIDTH                                     = $clog2(BUSWIDTH);
   
   localparam int                 CFG_PDS_NUM_HS_SPILL_IDS                           = 20;
   
   localparam int                 CFG_CU_AF32COMPLEX_PARALLEL_INSTANCES             = 32;
   localparam int                 CFG_CU_ATTRIBUTE_ALLOC_GRANULARITY_DWORDS         = 2;
   localparam int                 CFG_CU_INTERNAL_DWORDS                            = 2;
   localparam int                 CFG_CU_LOCAL_ALLOC_GRANULARITY_DWORDS             = 16;
   localparam int                 CFG_CU_MAX_TASKS_PER_WORKGROUP                    = 8;
   localparam int                 CFG_CU_MAX_TASKS_PER_WORKGROUP_LOG2               = 3;
   localparam int                 CFG_CU_MAX_TASKS_PER_WORKGROUP_WIDTH              = 3;
   localparam int                 CFG_CU_MEM_US_INSTANCE_WIDTH                      = 8;
   localparam int                 CFG_CU_MEM_US_INSTANCE_WIDTH_LOG2                 = 3;
   localparam int                 CFG_CU_MEM_US_INSTANCE_WIDTH_WIDTH                = 3;
   
   localparam int                 CFG_CU_TAP_PARALLEL_INSTANCES                     = 8;
   localparam int                 CFG_CU_TAP_PARALLEL_INSTANCES_LOG2                = 3;
   localparam int                 CFG_CU_TAP_PARALLEL_INSTANCES_WIDTH               = 3;
   
   localparam int                 CLUSTERS                                           = 32; //GP3:4gpc*4spc*4cu 30; //3spc+2cu: 6; 4spc+2cu: 8; 4spc+3cu: 12
   localparam int                 CLUSTERS_LOG2                                      = 5; //GP3:4gpc*4spc*4cu 5; // 4spc+3cu: 3
   localparam int                 CLUSTERS_PER_PBE                                   = 1;
   localparam int                 CLUSTERS_PER_PBE_LOG2                              = 0;
   localparam int                 CLUSTERS_PER_PBE_WIDTH                             = 1;
   localparam int                 CLUSTERS_WIDTH                                     = 4; //GP3:4gpc*4spc*4cu 4spc+3cu: 3
   localparam logic               COMPUTE                                            = 1;
   localparam logic               COMPUTE_MSS_MMU_AUTO_CACHE_OPS                     = 1;
   
   localparam int                 ECC_RAMS                                           = 0;
   localparam int                 ECC_RAMS_LOG2                                      = 0;
   localparam int                 ECC_RAMS_WIDTH                                     = 1;
   
   localparam int                 FBCDC                                              = 5;
   localparam logic               GPIO                                               = 1;
   localparam logic               GPU                                                = 1;
   localparam logic               GPU_VIRTUALISATION                                 = 1;
   localparam int                 GPU_VIRTUALISATION_NUM_OS                          = 16;
   localparam int                 GPU_VIRTUALISATION_NUM_OS_LOG2                     = 4;
   localparam int                 GPU_VIRTUALISATION_NUM_OS_WIDTH                    = 4;
   
   localparam int                 ISP_SAMPLES_PER_PIXEL                              = 2;
   localparam int                 ISP_SAMPLES_PER_PIXEL_LOG2                         = 1;
   localparam int                 ISP_SAMPLES_PER_PIXEL_WIDTH                        = 1;
   
   localparam int                 MAX_CLUSTERS                                       = 32; //In GP3: 4GPC*4SPC*4CU 48;
   localparam int                 MAX_CLUSTERS_LOG2                                  = 5;
   localparam int                 MAX_CLUSTERS_PER_SPC                               = 4;  //In GP3: 4GPC*4SPC*4CU, 4CU; 3-> 2cu: 2
   localparam int                 MAX_CLUSTERS_PER_SPC_LOG2                          = 2; // 2cu: 1
   localparam int                 MAX_CLUSTERS_PER_SPC_WIDTH                         = 2; // 2cu: 1
   localparam int                 MAX_CLUSTERS_PER_TPU                               = 1;
   localparam int                 MAX_CLUSTERS_PER_TPU_LOG2                          = 0;
   localparam int                 MAX_CLUSTERS_PER_TPU_WIDTH                         = 1;
   localparam int                 MAX_CLUSTERS_WIDTH                                 = 7;
   localparam int                 GPC_WIDTH                                          = 2;
   localparam int                 SPC_WIDTH                                          = 1; 
   localparam int                 MAX_INSTANCES_PER_PDS_TASK                         = 128;
   localparam int                 MAX_INSTANCES_PER_PDS_TASK_LOG2                    = 7;
   localparam int                 MAX_INSTANCES_PER_PDS_TASK_WIDTH                   = 7;
   localparam int                 MAX_MULTISAMPLE                                    = 8;
   localparam int                 MAX_MULTISAMPLE_LOG2                               = 3;
   localparam int                 MAX_MULTISAMPLE_WIDTH                              = 3;
  
   localparam int                 MAX_POUT_PER_TILE                                  = 8;
   localparam int                 MAX_POUT_PER_TILE_LOG2                             = 3;
   localparam int                 MAX_POUT_PER_TILE_WIDTH                            = 3;
   
   localparam int                 MAX_TPU_PER_SPC                                    = 0; //GP3 NO TPU; 2;
   localparam int                 MAX_TPU_PER_SPC_LOG2                               = 1;
   localparam int                 MAX_TPU_PER_SPC_WIDTH                              = 1;
   
   localparam int                 MCUSIZE                                            = 24;
   localparam int                 MCUSIZE_LOG2                                       = 5;
   localparam int                 MCUSIZE_WIDTH                                      = 5;
   
   localparam                     FWP                                               = "MTP219";
   localparam int                 FWP_COREMEM_BANKS                                 = 8;
   localparam int                 FWP_COREMEM_BANKS_LOG2                            = 3;
   localparam int                 FWP_COREMEM_BANKS_WIDTH                           = 3;
   localparam int                 FWP_COREMEM_SIZE                                  = 96;
   localparam int                 FWP_COREMEM_SIZE_LOG2                             = 7;
   localparam int                 FWP_COREMEM_SIZE_WIDTH                            = 7;
   localparam logic               FWP_DMA                                           = 1;
   localparam int                 FWP_DMA_CHANNEL_COUNT                             = 4;
   localparam int                 FWP_DMA_CHANNEL_COUNT_LOG2                        = 2;
   localparam int                 FWP_DMA_CHANNEL_COUNT_WIDTH                       = 2;
   localparam logic               FWP_DMA_REGISTER_PROGRAMMER                       = 1;
   localparam logic               FWP_DMA_WRITE                                     = 1;
   localparam int                 FWP_MTP                                           = 219;
   localparam logic               FWP_MTP219                                        = 1;
   localparam int                 FWP_MTP_LOG2                                      = 8;
   localparam int                 FWP_MTP_WIDTH                                     = 8;
   localparam logic               FWP_REGISTER_UNPACKED_ACCESSES                    = 1;
   localparam logic               MFU                                                = 1;
   localparam int                 MH_CTXT_PASID_WIDTH                                = 6;   // by wuce01 at 20250207. 
   localparam int                 MH_CTXT_PASID_WIDTH_LOG2                           = 3;
   localparam int                 MH_CTXT_PASID_WIDTH_WIDTH                          = 3;
   localparam int                 MH_DEBUG_ID_WIDTH                                  = 32;
   localparam int                 MH_DEBUG_ID_WIDTH_LOG2                             = 5;
   localparam int                 MH_DEBUG_ID_WIDTH_WIDTH                            = 5;
   
   localparam logic               MSAA_2X_FULL_RATE                                  = 1;
   localparam int                 MTP_BGTHREAD                                       = 4;
   localparam logic               MTP_BGTHREAD4                                      = 1;
   localparam int                 MTP_BGTHREAD_LOG2                                  = 2;
   localparam int                 MTP_BGTHREAD_WIDTH                                 = 2;
   localparam int                 MULTICORE_MAX_GPUS                                 = 8;
   localparam int                 MULTICORE_MAX_GPUS_LOG2                            = 3;
   localparam int                 MULTICORE_MAX_GPUS_WIDTH                           = 3;
   
   localparam int                 NUM_AXIBUS_PER_CHEST                               = 2;      // by zhujt at 20240109, for DDR Expand
   localparam int                 NUM_AXIBUS_PER_CHEST_LOG2                          = 1;      // by zhujt at 20240109, for DDR Expand
   localparam int                 NUM_AXIBUS_PER_CHEST_WIDTH                         = 1;      // by zhujt at 20240109, for DDR Expand
   
   localparam int                 NUM_SPC                                            = 8; //GP3: 4GPC*4SPC*4CU; g3: 10SPC*3CU
   localparam int                 NUM_SPC_LOG2                                       = 3; //GP3: 4GPC*4SPC*4CU; g3: 10SPC*3CU 4;
   localparam int                 NUM_SPC_WIDTH                                      = 3; //GP3: 4GPC*4SPC*4CU; g3: 10SPC*3CU 4;
   localparam int                 NUM_TA                                             = 1;
   localparam int                 NUM_TA_LOG2                                        = 0;
   localparam int                 NUM_TA_WIDTH                                       = 1;
   
   localparam int                 REGBANK_ADDR_WIDTH                                 = 17;
   localparam int                 REGBANK_ADDR_WIDTH_LOG2                            = 5;
   localparam int                 REGBANK_ADDR_WIDTH_WIDTH                           = 5;
   
   localparam int                 RESYNC                                             = 4;
   localparam int                 ROGUE                                              = 2;
   localparam logic               RTE                                                = 1;
   
   localparam int                 MSS_SIZE_ADJUSTMENT                                = 3;     // by luqj at 20230222, for 8M mss bank, 0 -> 3
   localparam int                 MSS_SIZE_ADJUSTMENT_LOG2                           = 2;     // by luqj at 20230222, for 8M mss bank, 1 -> 2
   localparam int                 MSS_SIZE_ADJUSTMENT_WIDTH                          = 2;     // by luqj at 20230222, for 8M mss bank, 0 -> 2
   
   localparam int                 SLOTS                                              = 32; //GP3: 4gpc*4spc*4cu, 24->32slot per eu; G3:48;
   localparam int                 SLOTS_LOG2                                         = 5;  //GP3: 4gpc*4spc*4cu, 24->32slot per eu; G3: 6;
   localparam int                 SLOTS_WIDTH                                        = 5;  //GP3: 4gpc*4spc*4cu, 24->32slot per eu; G3: 6;
   localparam logic               SOC_TIMER                                          = 1;
   
   localparam logic               SPC_ARCH_CLOCK_GATING                              = 1;
   localparam int                 SPC_ARCH_CLOCK_GATING_VERSION                      = 2;
   localparam int                 SPC_ARCH_CLOCK_GATING_VERSION_LOG2                 = 1;
   localparam int                 SPC_ARCH_CLOCK_GATING_VERSION_WIDTH                = 1;
   
   localparam int                 TILE_IDS                                           = 12;
   localparam int                 TILE_IDS_2D                                        = 8;
   localparam int                 TILE_IDS_2D_LOG2                                   = 3;
   localparam int                 TILE_IDS_2D_WIDTH                                  = 3;
   localparam int                 TILE_IDS_LOG2                                      = 4;
   localparam int                 TILE_IDS_WIDTH                                     = 4;
   localparam int                 TILE_SIZE_X                                        = 32;
   localparam int                 TILE_SIZE_X_LOG2                                   = 5;
   localparam int                 TILE_SIZE_X_WIDTH                                  = 5;
   localparam int                 TILE_SIZE_Y                                        = 32;
   localparam int                 TILE_SIZE_Y_LOG2                                   = 5;
   localparam int                 TILE_SIZE_Y_WIDTH                                  = 5;
   
   localparam int                 TPU_PARALLEL_INSTANCES                             = 8;
   localparam int                 TPU_PARALLEL_INSTANCES_LOG2                        = 3;
   localparam int                 TPU_PARALLEL_INSTANCES_WIDTH                       = 3;
   
   localparam int                 CU_NUM_TASKS                                      = 64;
   localparam int                 CU_NUM_TASKS_LOG2                                 = 6;
   localparam int                 CU_NUM_TASKS_WIDTH                                = 6;
   localparam int                 CU_OLCHK_USER_MASK_BITS                           = 8;
   localparam int                 CU_OLCHK_USER_MASK_BITS_LOG2                      = 3;
   localparam int                 CU_OLCHK_USER_MASK_BITS_WIDTH                     = 3;
   
   localparam int                 CU_PSB_PARALLEL_INSTANCES                         = 8;
   
   localparam int                 UVB_NUM_TASKS                                      = 64;
   localparam int                 UVB_NUM_TASKS_LOG2                                 = 6;
   localparam int                 UVB_NUM_TASKS_WIDTH                                = 6;
   //localparam int                 MUTEX_BITS                                         = 4;
   //localparam int                 MUTEX_NUM                                          = 16;
   localparam int                 SHARED_ID_BITS                                     = 6;

//CP CE common

localparam                 MMU_TBU_SLOT_ID_WIDTH                           = 6;
localparam                 MMU_PASID_WIDTH                                 = 10;
localparam                 MMU_VFID_WIDTH                                  = 4;
localparam                 MMU_VF_PAS_ID_WIDTH                             = 10;
localparam                 MMU_VPAGE_WIDTH                                 = 36;
localparam                 MMU_TG_WIDTH                                    = 2;
localparam                 MMU_TCU_SLOT_ID_WIDTH                           = 6;
localparam                 MMU_TRANS_SIZE_WIDTH                            = 4;
localparam                 MMU_INVAL_SIZE_WIDTH                            = 4;
localparam                 MMU_PPAGE_WIDTH                                 = 37;
localparam                 MMU_INV_TYPE_WIDTH                              = 2;
localparam                 MMU_TYPE_WIDTH                                  = 2;
localparam                 MMU_TTL_WIDTH                                   = 2;
localparam                 MMU_NUM_WIDTH                                   = 5;
localparam                 MMU_SCALE_WIDTH                                 = 5;
localparam                 MMU_ATTR_WIDTH                                  = 4;
localparam                 MMU_AC_ID_WIDTH                                 = 7;
localparam                 MMU_VF_NUM_WIDTH                                = 4;
localparam                 MMU_VF_HZD_MODE_WIDTH                           = 4;
localparam                 EVENT_ID_BITS                                   = 12;
localparam                 CE_QUEUE_NUM                                    = 8;
localparam                 MMU_LEAF_WIDTH                                  = 1;
localparam                 MMU_CMD_NUM_WIDTH                               = 5;
localparam                 MMU_VPAGE_ADDR_WIDTH                            = 36;
localparam                 MMU_REQ_NUM_WIDTH                               = 10;
localparam                 MMU_PAGE_STRIDE_WIDTH                           = 4;
//end cp ce common

endpackage
