
-- #==========================================================================#
-- |                                                                          |
-- |  Copyright (c) 2022, Fantasy Technologies Limited and/or its         |
-- |  affiliated group companies ("Fantasy"). All rights reserved.        |
-- |  No part of this content, either material or conceptual may be copied    |
-- |  or distributed, transmitted, transcribed, stored in a retrieval system  |
-- |  or translated into any human or computer language in any form by any    |
-- |  means, electronic, mechanical manual, or otherwise, or disclosed to     |
-- |  third parties without the express written permission of Fantasy.    |
-- |                                                                          |
-- #==========================================================================#



library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
library work;





package pkg_mh is




   constant IDLE_RESET_VALUE                : std_logic                                     := '1';
   constant MAX_DFUS                        : natural                                       := 73;
   --lius 20221108
   --#ifdef NUM_SPC_10_12
   --constant JONES_DFU_POSN                  : natural                                       := 12; --3
   constant JONES_DFU_POSN                  : natural                                       := 10; --for 10 spc;
   --#endif NUM_SPC_10_12--
   constant NUM_DFUS                        : natural                                       := 73;
   constant DFU_ID_BITS                     : natural                                       := 7;
   constant MAX_DFU_ID_BITS                 : natural                                       := 7;
   constant NUM_TPU_PER_SPC                 : natural                                       := 3; -- ori: 2
   constant BRIDGE_NUM_TCU_PORTS            : natural                                       := 2; -- ori: 1 modified by wuce01
   constant DFU_ID_VADDR_POSN               : natural                                       := 8;
   constant NUM_REAL_BIFS_PER_SPC           : natural                                       := 2;
   --lius 20221108
   --#ifdef NUM_SPC_10_12
   --constant NUM_BIFS                        : natural                                       := 49; --ori 13
   --constant NUM_REAL_BIFS                   : natural                                       := 25;  --ori 7
   --constant REAL_BIF_NUM_BITS               : natural                                       := 5;  --ori 3
   --constant BIF_NUM_BITS                    : natural                                       := 6;  --ori 4
   --constant BIF_NUM_ROUNDED_UP_BITS         : natural                                       := 6;  --ori 4
   --constant BIF_ID_BITS                     : natural                                       := 9; -- ori 7 =BIF_NUM_BITS+3
   --for 10spc--
   --constant NUM_BIFS                        : natural                                       := 41; --ori 13  4*SPC_NUM+1
   constant NUM_REAL_BIFS                   : natural                                       := 21;  --ori 7  2*SPC_NUM+1
   constant REAL_BIF_NUM_BITS               : natural                                       := 5;  --ori 3
   --constant BIF_NUM_BITS                    : natural                                       := 6;  --ori 4
   constant BIF_NUM_ROUNDED_UP_BITS         : natural                                       := 6;  --ori 4
   constant BIF_ID_BITS                     : natural                                       := 10; -- ori 7 =BIF_NUM_BITS+3 --by luqj at 20230601, 9 -> 10, BIF_NUM_BITS + EXT_REORDERED_ID_BITS, reordered_id: 3->4
   --#endif NUM_SPC_10_12--
   --constant NUM_MSS_MEM_PORTS               : natural                                       := 32;   -- by luqj at 20230207, for 32 mss bank, 4 -> 32
   --constant NUM_CHEST                       : natural                                       := 16; -- equal NUM_MSS_MEM_PORTS/work.gc_features_pack.NUM_AXIBUS_PER_CHEST;
   --constant NUM_CHEST_BITS                  : natural                                       := 4;
   --constant CHEST_NUM_MSS_MEM_PORTS         : natural                                       := NUM_MSS_MEM_PORTS;
   constant CHEST_X1_MEM_PORT_BITS          : natural                                       := 1;
   constant ASC_ADD_SLOTS_TO_CACHELINES     : natural                                       := 44;
   constant ASC_NUM_SLOTS                   : natural                                       := 300;
   constant ASC_NUM_SLOTS_BITS              : natural                                       := 9;
   constant ASC_64B_BURSTLENGTH             : natural                                       := 1;
   constant ASC_128B_BURSTLENGTH            : natural                                       := 3;
   constant ASC_64B_BURSTLENGTH_BITS        : natural                                       := 1;
   constant ASC_128B_BURSTLENGTH_BITS       : natural                                       := 2;
   constant SEQ_NUM_BITS                    : natural                                       := 10;
   constant BIF_DATA_BUS_WIDTH              : natural                                       := 512;
   --constant VADDR_LOW                       : natural                                       := 5;
   constant VADDR_PAGE_OFFSET_WIDTH         : natural                                       := 7;
   constant VHA_INTERNAL_DATA_WIDTH         : natural                                       := 256;
   constant VHA_INTERNAL_DATA_MASK_WIDTH    : natural                                       := 32;
   constant VHA_VADDR_LOW                   : natural                                       := 5;
   constant VHA_RDI_TAG_REUSE               : natural                                       := 1;
   constant VHA_RDI_TAG_REUSE_W             : natural                                       := 1;
   constant REQ_ID_BITS                     : natural                                       := 6;
   constant NUM_L1_BANKS                    : natural                                       := 4;
   constant L1_BANK_BITS                    : natural                                       := 2;
   constant NUM_L1_SETS                     : natural                                       := 8;
   constant L1_SET_BITS                     : natural                                       := 3;
   constant L1_CACHELINE_SIZE               : natural                                       := 512;
   constant NUM_MCU_WAYS                    : natural                                       := 16; --ori:12
   constant NUM_TCU_WAYS                    : natural                                       := 16; --ori:12
   constant L1_MAX_WAY_BITS                 : natural                                       := 4;
   constant VADDR_BITS_FBCDC                : natural                                       := 41;
--   constant VADDR_BITS_NON_FBCDC            : natural                                       := 40;
   constant VADDR_BITS_MCU_L1               : natural                                       := 41;
   constant VADDR_BITS_MSS                  : natural                                       := 41;
   constant VADDR_BITS_MMU                  : natural                                       := 40;
   constant VPAGE_BITS                      : natural                                       := 28;
   constant PM_VPAGE_BITS                   : natural                                       := 20;
   constant PPAGE_BITS                      : natural                                       := 28;
   constant CTXT_RAM_DEPTH                  : natural                                       := 32;

   constant NUM_OS_IDS                      : natural                                       := 16;
   constant OS_ID_BITS                      : natural                                       := 4;
--hanyd add
   constant TCU_ID_BITS                     : natural                                       := 3;
   constant SWIFT0_TCU0_ID                  : natural                                       := 0;
   constant SWIFT0_TCU1_ID                  : natural                                       := 1;
   constant SWIFT1_TCU0_ID                  : natural                                       := 2;
   constant SWIFT1_TCU1_ID                  : natural                                       := 3;
   constant SWIFT2_TCU0_ID                  : natural                                       := 4;
   constant SWIFT2_TCU1_ID                  : natural                                       := 5;
--hanyd end
   constant EXT_REORDERED_ID_BITS           : natural                                       := 4;           -- by luqj at 20230601, for add tcu_id field, 3->4

   constant EXT_REORDERED_SO_SEQ_NUM_ID_BITS: natural                                       := 3;

   
   
   constant JONES_EXT_REORDERED_RPM_ID      : natural                                       := 0;
   constant JONES_EXT_REORDERED_SO_REQ_ID   : natural                                       := 6;
   constant TEXAS0_EXT_REORDERED_MCU_ID     : natural                                       := 0;
   constant TEXAS0_EXT_REORDERED_TCU_ID     : natural                                       := 1;
--hanyd add
   constant TEXAS0_EXT_REORDERED_TCU_ID_0   : natural                                       := 7;
   constant TEXAS0_EXT_REORDERED_TCU_ID_1   : natural                                       := 8;
   constant TEXAS0_EXT_REORDERED_TCU_ID_2   : natural                                       := 9;
   constant TEXAS0_EXT_REORDERED_TCU_ID_3   : natural                                       := 10;
   constant TEXAS0_EXT_REORDERED_TCU_ID_4   : natural                                       := 11;
   constant TEXAS0_EXT_REORDERED_TCU_ID_5   : natural                                       := 12;
--hanyd end
   constant TEXAS0_EXT_REORDERED_TMC_ID     : natural                                       := 13;

   constant TEXAS0_EXT_REORDERED_RAC_ID     : natural                                       := 2;
   constant TEXAS0_EXT_REORDERED_AMC_ID     : natural                                       := 3;
   constant TEXAS0_EXT_REORDERED_SO_REQ_ID  : natural                                       := 6;
   constant TEXAS0_EXT_REORDERED_SO_PBE0_SEQ_NUM_ID: natural                                := 0;
   constant TEXAS0_EXT_REORDERED_SO_VCE_SEQ_NUM_ID: natural                                 := 1;
   constant TEXAS0_EXT_REORDERED_SO_PPP_SEQ_NUM_ID: natural                                 := 2;
   constant TEXAS0_EXT_REORDERED_SO_SHF_SEQ_NUM_ID: natural                                 := 3;
   constant TEXAS0_EXT_REORDERED_SO_VDM_SEQ_NUM_ID: natural                                 := 4;
   constant TEXAS0_EXT_REORDERED_SO_VCE_RTC_SEQ_NUM_ID: natural                             := 5;

   constant TEXAS1_EXT_REORDERED_MCU_ID     : natural                                       := 0;
   constant TEXAS1_EXT_REORDERED_TCU_ID     : natural                                       := 1;
--hanyd add
   constant TEXAS1_EXT_REORDERED_TCU_ID_0     : natural                                     := 7;
   constant TEXAS1_EXT_REORDERED_TCU_ID_1     : natural                                     := 8;
   constant TEXAS1_EXT_REORDERED_TCU_ID_2     : natural                                     := 9;
   constant TEXAS1_EXT_REORDERED_TCU_ID_3     : natural                                     := 10;
   constant TEXAS1_EXT_REORDERED_TCU_ID_4     : natural                                     := 11;
   constant TEXAS1_EXT_REORDERED_TCU_ID_5     : natural                                     := 12;
--hanyd end
   constant TEXAS1_EXT_REORDERED_TMC_ID     : natural                                       := 13;

   constant TEXAS1_EXT_REORDERED_FBA_ID     : natural                                       := 2;
   constant TEXAS1_EXT_REORDERED_SO_REQ_ID  : natural                                       := 6;
   constant TEXAS1_EXT_REORDERED_SO_SHG_SEQ_NUM_ID: natural                                 := 0;
   constant TEXAS1_EXT_REORDERED_SO_PBE1_SEQ_NUM_ID: natural                                := 1;

   constant TCUBRIDGE_EXT_REORDERED_TCU0_ID : natural                                       := 0;
   constant TCUBRIDGE_EXT_REORDERED_TCU1_ID : natural                                       := 1;
   constant TCUBRIDGE_EXT_REORDERED_TCU2_ID : natural                                       := 2;
--hanyd add
   constant TCUBRIDGE_EXT_REORDERED_TCU_ID_0     : natural                                  := 7;
   constant TCUBRIDGE_EXT_REORDERED_TCU_ID_1     : natural                                  := 8;
   constant TCUBRIDGE_EXT_REORDERED_TCU_ID_2     : natural                                  := 9;
   constant TCUBRIDGE_EXT_REORDERED_TCU_ID_3     : natural                                  := 10;
   constant TCUBRIDGE_EXT_REORDERED_TCU_ID_4     : natural                                  := 11;
   constant TCUBRIDGE_EXT_REORDERED_TCU_ID_5     : natural                                  := 12;
--hanyd end
   constant TCUBRIDGE_EXT_REORDERED_TMC_ID       : natural                                  := 13;

   constant MEM_OPERATION_BITS              : natural                                       := 4;
   constant AA_OPERATION_BITS               : natural                                       := 4;
   constant MH_PERSISTENCE_BITS             : natural                                       := 2;
   constant ROBUST_BUFFER_BASE_BITS         : natural                                       := 41;
   constant ROBUST_BUFFER_SIZE_BITS         : natural                                       := 32;





--add by wangzh02 for gp3 fw
   constant BIF_256BIT_DATA_BUS_WIDTH       : natural                                       := 256;
   constant VADDR_256BIT_LOW                : natural                                       := 5;
   constant VADDR_BITS_NON_FBCDC            : natural                                       := 48;
   ----------------------------------------------------------------------------------------------------------------------------------
   --   Enumerators
   ----------------------------------------------------------------------------------------------------------------------------------
   attribute enum_encoding : string;

   type t_mem_operation_enum is (
      MH_LOAD       , -- 0000
      MH_TOUCH      , -- 0001
      MH_STORE      , -- 0100
      MH_ATOMIC32   , -- 0101
      MH_ATOMIC64   , -- 0110
      MH_ATOMICFP32 , -- 1010
      MH_ATOMICTST  , -- 0111
      MH_WR_FENCE   , -- 1000
      MH_BARRIER    , -- 1001
      MH_CCM_EVICT  , -- 1100
      MH_INVAL      , -- 1101
      MH_FLUSH      , -- 1110
      MH_FLUSHINV   -- 1111
   );
   attribute enum_encoding of t_mem_operation_enum : type is "0000 0001 0100 0101 0110 1010 0111 1000 1001 1100 1101 1110 1111";
   constant MEM_OPERATION_ENUM_MH_LOAD       : std_logic_vector(3 downto 0) := "0000";
   constant MEM_OPERATION_ENUM_MH_TOUCH      : std_logic_vector(3 downto 0) := "0001";
   constant MEM_OPERATION_ENUM_MH_STORE      : std_logic_vector(3 downto 0) := "0100";
   constant MEM_OPERATION_ENUM_MH_ATOMIC32   : std_logic_vector(3 downto 0) := "0101";
   constant MEM_OPERATION_ENUM_MH_ATOMIC64   : std_logic_vector(3 downto 0) := "0110";
   constant MEM_OPERATION_ENUM_MH_ATOMICFP32 : std_logic_vector(3 downto 0) := "1010";
   constant MEM_OPERATION_ENUM_MH_ATOMICTST  : std_logic_vector(3 downto 0) := "0111";
   constant MEM_OPERATION_ENUM_MH_WR_FENCE   : std_logic_vector(3 downto 0) := "1000";
   constant MEM_OPERATION_ENUM_MH_BARRIER    : std_logic_vector(3 downto 0) := "1001";
   constant MEM_OPERATION_ENUM_MH_CCM_EVICT  : std_logic_vector(3 downto 0) := "1100";
   constant MEM_OPERATION_ENUM_MH_INVAL      : std_logic_vector(3 downto 0) := "1101";
   constant MEM_OPERATION_ENUM_MH_FLUSH      : std_logic_vector(3 downto 0) := "1110";
   constant MEM_OPERATION_ENUM_MH_FLUSHINV   : std_logic_vector(3 downto 0) := "1111";

   function to_slv(i : t_mem_operation_enum ) return std_logic_vector;
   function to_t_mem_operation_enum(i : std_logic_vector(3 downto 0)) return t_mem_operation_enum;

   type t_atomic_operation_enum is (
      MH_AA_OP_ADD    , -- 0000
      MH_AA_OP_SUB    , -- 0001
      MH_AA_OP_XCHG   , -- 0010
      MH_AA_OP_CMPXCHG, -- 0011
      MH_AA_OP_UMIN   , -- 0100
      MH_AA_OP_IMIN   , -- 0101
      MH_AA_OP_UMAX   , -- 0110
      MH_AA_OP_IMAX   , -- 0111
      MH_AA_OP_AND    , -- 1000
      MH_AA_OP_OR     , -- 1001
      MH_AA_OP_XOR      -- 1010
   );
   attribute enum_encoding of t_atomic_operation_enum : type is "0000 0001 0010 0011 0100 0101 0110 0111 1000 1001 1010";
   constant ATOMIC_OPERATION_ENUM_MH_AA_OP_ADD     : std_logic_vector(3 downto 0) := "0000";
   constant ATOMIC_OPERATION_ENUM_MH_AA_OP_SUB     : std_logic_vector(3 downto 0) := "0001";
   constant ATOMIC_OPERATION_ENUM_MH_AA_OP_XCHG    : std_logic_vector(3 downto 0) := "0010";
   constant ATOMIC_OPERATION_ENUM_MH_AA_OP_CMPXCHG : std_logic_vector(3 downto 0) := "0011";
   constant ATOMIC_OPERATION_ENUM_MH_AA_OP_UMIN    : std_logic_vector(3 downto 0) := "0100";
   constant ATOMIC_OPERATION_ENUM_MH_AA_OP_IMIN    : std_logic_vector(3 downto 0) := "0101";
   constant ATOMIC_OPERATION_ENUM_MH_AA_OP_UMAX    : std_logic_vector(3 downto 0) := "0110";
   constant ATOMIC_OPERATION_ENUM_MH_AA_OP_IMAX    : std_logic_vector(3 downto 0) := "0111";
   constant ATOMIC_OPERATION_ENUM_MH_AA_OP_AND     : std_logic_vector(3 downto 0) := "1000";
   constant ATOMIC_OPERATION_ENUM_MH_AA_OP_OR      : std_logic_vector(3 downto 0) := "1001";
   constant ATOMIC_OPERATION_ENUM_MH_AA_OP_XOR     : std_logic_vector(3 downto 0) := "1010";

   function to_slv(i : t_atomic_operation_enum ) return std_logic_vector;
   function to_t_atomic_operation_enum(i : std_logic_vector(3 downto 0)) return t_atomic_operation_enum;

   type t_mh_mcu_subreq_id_enum is (
      C_PDS   , -- 0
      C_GLOBAL  -- 1
   );
   attribute enum_encoding of t_mh_mcu_subreq_id_enum : type is "0 1";
   constant MH_MCU_SUBREQ_ID_ENUM_C_PDS    : std_logic_vector(0 downto 0) := "0";
   constant MH_MCU_SUBREQ_ID_ENUM_C_GLOBAL : std_logic_vector(0 downto 0) := "1";

   function to_slv(i : t_mh_mcu_subreq_id_enum ) return std_logic_vector;
   function to_t_mh_mcu_subreq_id_enum(i : std_logic_vector(0 downto 0)) return t_mh_mcu_subreq_id_enum;
end package pkg_mh;

package body pkg_mh is

   -- conversion function for mem_operation_enum enumerator
   function to_slv(i : t_mem_operation_enum ) return std_logic_vector is
      variable ret : std_logic_vector(3 downto 0);
   begin
      case i is
         when MH_LOAD       => ret := MEM_OPERATION_ENUM_MH_LOAD;
         when MH_TOUCH      => ret := MEM_OPERATION_ENUM_MH_TOUCH;
         when MH_STORE      => ret := MEM_OPERATION_ENUM_MH_STORE;
         when MH_ATOMIC32   => ret := MEM_OPERATION_ENUM_MH_ATOMIC32;
         when MH_ATOMIC64   => ret := MEM_OPERATION_ENUM_MH_ATOMIC64;
         when MH_ATOMICFP32 => ret := MEM_OPERATION_ENUM_MH_ATOMICFP32;
         when MH_ATOMICTST  => ret := MEM_OPERATION_ENUM_MH_ATOMICTST;
         when MH_WR_FENCE   => ret := MEM_OPERATION_ENUM_MH_WR_FENCE;
         when MH_BARRIER    => ret := MEM_OPERATION_ENUM_MH_BARRIER;
         when MH_CCM_EVICT  => ret := MEM_OPERATION_ENUM_MH_CCM_EVICT;
         when MH_INVAL      => ret := MEM_OPERATION_ENUM_MH_INVAL;
         when MH_FLUSH      => ret := MEM_OPERATION_ENUM_MH_FLUSH;
         when others        => ret := MEM_OPERATION_ENUM_MH_FLUSHINV;
      end case;
      return ret;
   end function;
   -- conversion function for mem_operation_enum enumerator
   function to_t_mem_operation_enum(i : std_logic_vector(3 downto 0)) return t_mem_operation_enum is
      variable ret : t_mem_operation_enum;
   begin
      case i is
         when MEM_OPERATION_ENUM_MH_LOAD      => ret := MH_LOAD;
         when MEM_OPERATION_ENUM_MH_TOUCH     => ret := MH_TOUCH;
         when MEM_OPERATION_ENUM_MH_STORE     => ret := MH_STORE;
         when MEM_OPERATION_ENUM_MH_ATOMIC32  => ret := MH_ATOMIC32;
         when MEM_OPERATION_ENUM_MH_ATOMIC64  => ret := MH_ATOMIC64;
         when MEM_OPERATION_ENUM_MH_ATOMICTST => ret := MH_ATOMICTST;
         when MEM_OPERATION_ENUM_MH_WR_FENCE  => ret := MH_WR_FENCE;
         when MEM_OPERATION_ENUM_MH_BARRIER   => ret := MH_BARRIER;
         when MEM_OPERATION_ENUM_MH_CCM_EVICT => ret := MH_CCM_EVICT;
         when MEM_OPERATION_ENUM_MH_INVAL     => ret := MH_INVAL;
         when MEM_OPERATION_ENUM_MH_FLUSH     => ret := MH_FLUSH;
         when others                          => ret := MH_FLUSHINV;
      end case;
      return ret;
   end function;

   -- conversion function for atomic_operation_enum enumerator
   function to_slv(i : t_atomic_operation_enum ) return std_logic_vector is
      variable ret : std_logic_vector(3 downto 0);
   begin
      case i is
         when MH_AA_OP_ADD     => ret := ATOMIC_OPERATION_ENUM_MH_AA_OP_ADD;
         when MH_AA_OP_SUB     => ret := ATOMIC_OPERATION_ENUM_MH_AA_OP_SUB;
         when MH_AA_OP_XCHG    => ret := ATOMIC_OPERATION_ENUM_MH_AA_OP_XCHG;
         when MH_AA_OP_CMPXCHG => ret := ATOMIC_OPERATION_ENUM_MH_AA_OP_CMPXCHG;
         when MH_AA_OP_UMIN    => ret := ATOMIC_OPERATION_ENUM_MH_AA_OP_UMIN;
         when MH_AA_OP_IMIN    => ret := ATOMIC_OPERATION_ENUM_MH_AA_OP_IMIN;
         when MH_AA_OP_UMAX    => ret := ATOMIC_OPERATION_ENUM_MH_AA_OP_UMAX;
         when MH_AA_OP_IMAX    => ret := ATOMIC_OPERATION_ENUM_MH_AA_OP_IMAX;
         when MH_AA_OP_AND     => ret := ATOMIC_OPERATION_ENUM_MH_AA_OP_AND;
         when MH_AA_OP_OR      => ret := ATOMIC_OPERATION_ENUM_MH_AA_OP_OR;
         when others           => ret := ATOMIC_OPERATION_ENUM_MH_AA_OP_XOR;
      end case;
      return ret;
   end function;
   -- conversion function for atomic_operation_enum enumerator
   function to_t_atomic_operation_enum(i : std_logic_vector(3 downto 0)) return t_atomic_operation_enum is
      variable ret : t_atomic_operation_enum;
   begin
      case i is
         when ATOMIC_OPERATION_ENUM_MH_AA_OP_ADD     => ret := MH_AA_OP_ADD;
         when ATOMIC_OPERATION_ENUM_MH_AA_OP_SUB     => ret := MH_AA_OP_SUB;
         when ATOMIC_OPERATION_ENUM_MH_AA_OP_XCHG    => ret := MH_AA_OP_XCHG;
         when ATOMIC_OPERATION_ENUM_MH_AA_OP_CMPXCHG => ret := MH_AA_OP_CMPXCHG;
         when ATOMIC_OPERATION_ENUM_MH_AA_OP_UMIN    => ret := MH_AA_OP_UMIN;
         when ATOMIC_OPERATION_ENUM_MH_AA_OP_IMIN    => ret := MH_AA_OP_IMIN;
         when ATOMIC_OPERATION_ENUM_MH_AA_OP_UMAX    => ret := MH_AA_OP_UMAX;
         when ATOMIC_OPERATION_ENUM_MH_AA_OP_IMAX    => ret := MH_AA_OP_IMAX;
         when ATOMIC_OPERATION_ENUM_MH_AA_OP_AND     => ret := MH_AA_OP_AND;
         when ATOMIC_OPERATION_ENUM_MH_AA_OP_OR      => ret := MH_AA_OP_OR;
         when others                                 => ret := MH_AA_OP_XOR;
      end case;
      return ret;
   end function;

   -- conversion function for mh_mcu_subreq_id_enum enumerator
   function to_slv(i : t_mh_mcu_subreq_id_enum ) return std_logic_vector is
      variable ret : std_logic_vector(0 downto 0);
   begin
      case i is
         when C_PDS    => ret := MH_MCU_SUBREQ_ID_ENUM_C_PDS;
         when others   => ret := MH_MCU_SUBREQ_ID_ENUM_C_GLOBAL;
      end case;
      return ret;
   end function;
   -- conversion function for mh_mcu_subreq_id_enum enumerator
   function to_t_mh_mcu_subreq_id_enum(i : std_logic_vector(0 downto 0)) return t_mh_mcu_subreq_id_enum is
      variable ret : t_mh_mcu_subreq_id_enum;
   begin
      case i is
         when MH_MCU_SUBREQ_ID_ENUM_C_PDS    => ret := C_PDS;
         when others                         => ret := C_GLOBAL;
      end case;
      return ret;
   end function;

end package body pkg_mh;
