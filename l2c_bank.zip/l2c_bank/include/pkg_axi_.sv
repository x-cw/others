/*

 * #==========================================================================#
 * |                                                                          |
 * |  Copyright (c) 2022, Fantasy Technologies Limited and/or its         |
 * |  affiliated group companies ("Fantasy"). All rights reserved.        |
 * |  No part of this content, either material or conceptual may be copied    |
 * |  or distributed, transmitted, transcribed, stored in a retrieval system  |
 * |  or translated into any human or computer language in any form by any    |
 * |  means, electronic, mechanical manual, or otherwise, or disclosed to     |
 * |  third parties without the express written permission of Fantasy.    |
 * |                                                                          |
 * #==========================================================================#

 */


package pkg_axi_;



   localparam int                 NUM_AXI_IDS           = 224;                    // 7.25,192->224, bif2axi dedicated, if modify, pls notify luoml01
   localparam int                 AXI_ID_BITS           = $clog2(NUM_AXI_IDS);   // 7->8, by for GP3 by luoml01


   localparam int                 AXI_USER_BITS         = 18;                     // 7->14 for GP3 by luoml01
   localparam int                 NUM_AXI_RIDS          = 512;                    // 128->256, for GP3 by luoml01, the 9bit for distiguish the MMU and SPC
   localparam int                 AXI_RID_BITS          = $clog2(NUM_AXI_RIDS);   // 7->8, by for GP3 by luoml01
   localparam int                 NUM_AXI_WIDS          = 256;                    // 64->128, for GP3 by luoml01
   localparam int                 AXI_WID_BITS          = $clog2(NUM_AXI_WIDS);   // 6->7, for GP3 by luoml01
   localparam int                 NUM_CLB_RESERVED_WIDS = 2;
   localparam int                 AXI_BUS_WIDTH         = 512;                    //256->512 for GP3
   localparam int                 ADDR_LOW              = 6;                      //5->6 for GP3
   localparam logic               PROT_SECURE           = 1'b0;
   localparam logic               PROT_NON_SECURE       = 1'b1;
   localparam logic [1 : 0]       INCREMENTING          = 2'b01;
   localparam logic [1 : 0]       WRAPPING              = 2'b10;
   localparam int                 AXI_ADDRESS_WIDTH     = 49;

   localparam int                 AXI_LEN_WIDTH         = 3;
   localparam int                 AXI_SIZE_WIDTH        = 3;
   localparam int                 AXI_BURST_WIDTH       = 2;
   localparam int                 AXI_CACHE_WIDTH       = 4;
   localparam int                 AXI_PROT_WIDTH        = 3;
   localparam int                 AXI_QOS_WIDTH         = 4;
   localparam int                 AXI_RESP_WIDTH        = 2;
   localparam int                 AXI_ATOP_WIDTH        = 6;



   //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
   //   Enumerators
   //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

   typedef enum logic [2 : 0] {
      E_AXI_FEATURE_SUPPORT_TYPE_FULL_ACE_ALL_128B    = 3'b000,
      E_AXI_FEATURE_SUPPORT_TYPE_FULL_ACE_C64B_NC128B = 3'b001,
      E_AXI_FEATURE_SUPPORT_TYPE_FULL_ACE_ALL_64B     = 3'b010,
      E_AXI_FEATURE_SUPPORT_TYPE_ACE_LITE_ALL_128B    = 3'b011,
      E_AXI_FEATURE_SUPPORT_TYPE_ACE_LITE_C64B_NC128B = 3'b100,
      E_AXI_FEATURE_SUPPORT_TYPE_ACE_LITE_ALL_64B     = 3'b101,
      E_AXI_FEATURE_SUPPORT_TYPE_NO_COHERENCY_128B    = 3'b110,
      E_AXI_FEATURE_SUPPORT_TYPE_NO_COHERENCY_64B     = 3'b111 
   } t_e_axi_feature_support_type;



endpackage
