
-- #==========================================================================#
-- |                                                                          |
-- |  Copyright (c) 2022, Fantasy Technologies Limited and/or its         |
-- |  affiliated group companies ("Fantasy"). All rights reserved.        |
-- |  No part of this content, either material or conceptual may be copied    |
-- |  or distributed, transmitted, transcribed, stored in a retrieval system  |
-- |  or translated into any human or computer language in any form by any    |
-- |  means, electronic, mechanical manual, or otherwise, or disclosed to     |
-- |  third parties without the express written permission of Fantasy.    |
-- |                                                                          |
-- #==========================================================================#



library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
library work;





package pkg_rt is

   constant RT_RAYS_PER_MICRO_PKT_COUNT_WIDTH: natural                                       := 4;
   --lius 20221108
   --#ifdef NUM_SPC_10_12
   --constant NUM_RAC_PER_GPU                 : natural                                       := 12; --3
   --constant RT_ASC_NUM_REQ                  : natural                                       := 12; --3
   --for 10spc
   constant NUM_RAC_PER_GPU                 : natural                                       := 10; --3
   --constant RT_ASC_NUM_REQ                  : natural                                       := 10; --3
   constant RT_ASC_NUM_REQ                  : natural                                       := 3;
   --#endif NUM_SPC_10_12--
   --constant RT_ASC_NUM_REQ_BITS             : natural                                       := 4;
   constant RT_ASC_NUM_REQ_BITS             : natural                                       := 2;
   constant RT_BOX_NUM_GEO_IDS              : natural                                       := 64;
   constant RT_BOX_NUM_TRANSFORM_IDS        : natural                                       := 128;
   constant RT_PRIM_NUM_GEO_IDS             : natural                                       := 64;
   constant RT_PRIM_NUM_TRANSFORM_IDS       : natural                                       := 128;
   constant RT_RTS_PDS_UNIFORM_DESC_BASE_WIDTH: natural                                       := 36;
   constant RT_URI_RTS_RESUME_RT_TASK_ID_WIDTH: natural                                       := 10;
   constant RT_URI_RTS_PRIMARY_TASK_ID_WIDTH: natural                                       := 5;
   constant RT_URI_RTS_SECONDARY_TASK_ID_WIDTH: natural                                       := 10;
   constant RT_PCG_PRIMITIVE_DATA_MASK_WIDTH: natural                                       := 2;
   constant RT_PCG_BOXF_CHILD_LIST_LENGTH_WIDTH: natural                                       := 4;
   constant RT_PCG_INSTF_INST_CULL_NASK_WIDTH: natural                                       := 8;
   constant RT_PCG_INSTANCE_CONTRIBUTION_TO_HIT_INDEX_WIDTH: natural                                       := 24;
   constant RT_PCG_PRIMITIVE_INST_DATA_WIDTH: natural                                       := 412;

   ----------------------------------------------------------------------------------------------------------------------------------
   --   Enumerators
   ----------------------------------------------------------------------------------------------------------------------------------
   attribute enum_encoding : string;

   type t_e_rstore_op_type is (
      WRITE           , -- 000
      WRITEANDTRACE   , -- 001
      WRITEANDCALL    , -- 010
      WRITEANDPROCEED , -- 011
      WRITEANDACCEPT  , -- 100
      WRITEANDRESUBMIT  -- 101
   );
   attribute enum_encoding of t_e_rstore_op_type : type is "000 001 010 011 100 101";
   constant E_RSTORE_OP_TYPE_WRITE            : std_logic_vector(2 downto 0) := "000";
   constant E_RSTORE_OP_TYPE_WRITEANDTRACE    : std_logic_vector(2 downto 0) := "001";
   constant E_RSTORE_OP_TYPE_WRITEANDCALL     : std_logic_vector(2 downto 0) := "010";
   constant E_RSTORE_OP_TYPE_WRITEANDPROCEED  : std_logic_vector(2 downto 0) := "011";
   constant E_RSTORE_OP_TYPE_WRITEANDACCEPT   : std_logic_vector(2 downto 0) := "100";
   constant E_RSTORE_OP_TYPE_WRITEANDRESUBMIT : std_logic_vector(2 downto 0) := "101";

   function to_slv(i : t_e_rstore_op_type ) return std_logic_vector;
   function to_t_e_rstore_op_type(i : std_logic_vector(2 downto 0)) return t_e_rstore_op_type;

   type t_e_rstore_space_type is (
      TRACE, -- 00
      QUERY, -- 01
      CALL   -- 10
   );
   attribute enum_encoding of t_e_rstore_space_type : type is "00 01 10";
   constant E_RSTORE_SPACE_TYPE_TRACE : std_logic_vector(1 downto 0) := "00";
   constant E_RSTORE_SPACE_TYPE_QUERY : std_logic_vector(1 downto 0) := "01";
   constant E_RSTORE_SPACE_TYPE_CALL  : std_logic_vector(1 downto 0) := "10";

   function to_slv(i : t_e_rstore_space_type ) return std_logic_vector;
   function to_t_e_rstore_space_type(i : std_logic_vector(1 downto 0)) return t_e_rstore_space_type;

   type t_e_rload_op_type is (
      READ      , -- 00
      ALLOCATE  , -- 01
      DEALLOCATE  -- 10
   );
   attribute enum_encoding of t_e_rload_op_type : type is "00 01 10";
   constant E_RLOAD_OP_TYPE_READ       : std_logic_vector(1 downto 0) := "00";
   constant E_RLOAD_OP_TYPE_ALLOCATE   : std_logic_vector(1 downto 0) := "01";
   constant E_RLOAD_OP_TYPE_DEALLOCATE : std_logic_vector(1 downto 0) := "10";

   function to_slv(i : t_e_rload_op_type ) return std_logic_vector;
   function to_t_e_rload_op_type(i : std_logic_vector(1 downto 0)) return t_e_rload_op_type;

   type t_e_rload_space_type is (
      RID        , -- 000
      PRIMARY    , -- 001
      LAUNCH_SIZE, -- 010
      TRACE      , -- 011
      QUERY      , -- 100
      CALL       , -- 101
      DEBUG        -- 110
   );
   attribute enum_encoding of t_e_rload_space_type : type is "000 001 010 011 100 101 110";
   constant E_RLOAD_SPACE_TYPE_RID         : std_logic_vector(2 downto 0) := "000";
   constant E_RLOAD_SPACE_TYPE_PRIMARY     : std_logic_vector(2 downto 0) := "001";
   constant E_RLOAD_SPACE_TYPE_LAUNCH_SIZE : std_logic_vector(2 downto 0) := "010";
   constant E_RLOAD_SPACE_TYPE_TRACE       : std_logic_vector(2 downto 0) := "011";
   constant E_RLOAD_SPACE_TYPE_QUERY       : std_logic_vector(2 downto 0) := "100";
   constant E_RLOAD_SPACE_TYPE_CALL        : std_logic_vector(2 downto 0) := "101";
   constant E_RLOAD_SPACE_TYPE_DEBUG       : std_logic_vector(2 downto 0) := "110";

   function to_slv(i : t_e_rload_space_type ) return std_logic_vector;
   function to_t_e_rload_space_type(i : std_logic_vector(2 downto 0)) return t_e_rload_space_type;

   type t_e_uri_cu_st_ld_n_type is (
      RLOAD , -- 0
      RSTORE  -- 1
   );
   attribute enum_encoding of t_e_uri_cu_st_ld_n_type : type is "0 1";
   constant E_URI_CU_ST_LD_N_TYPE_RLOAD  : std_logic_vector(0 downto 0) := "0";
   constant E_URI_CU_ST_LD_N_TYPE_RSTORE : std_logic_vector(0 downto 0) := "1";

   function to_slv(i : t_e_uri_cu_st_ld_n_type ) return std_logic_vector;
   function to_t_e_uri_cu_st_ld_n_type(i : std_logic_vector(0 downto 0)) return t_e_uri_cu_st_ld_n_type;

   type t_e_uri_cu_inst_mode_type is (
      SINGLE, -- 0
      MULTI   -- 1
   );
   attribute enum_encoding of t_e_uri_cu_inst_mode_type : type is "0 1";
   constant E_URI_CU_INST_MODE_TYPE_SINGLE : std_logic_vector(0 downto 0) := "0";
   constant E_URI_CU_INST_MODE_TYPE_MULTI  : std_logic_vector(0 downto 0) := "1";

   function to_slv(i : t_e_uri_cu_inst_mode_type ) return std_logic_vector;
   function to_t_e_uri_cu_inst_mode_type(i : std_logic_vector(0 downto 0)) return t_e_uri_cu_inst_mode_type;

   type t_e_flags_dword_type is (
      CULL_MASK_BIT0             , -- 00000
      CULL_MASK_BIT1             , -- 00001
      CULL_MASK_BIT2             , -- 00010
      CULL_MASK_BIT3             , -- 00011
      CULL_MASK_BIT4             , -- 00100
      CULL_MASK_BIT5             , -- 00101
      CULL_MASK_BIT6             , -- 00110
      CULL_MASK_BIT7             , -- 00111
      OPAQUE                     , -- 01000
      NO_OPAQUE                  , -- 01001
      TERMINATE_ON_FIRST_HIT     , -- 01010
      SKIP_CLOSEST_HIT_SHADER    , -- 01011
      CULL_BACK_FACING_TRIANGLES , -- 01100
      CULL_FRONT_FACING_TRIANGLES, -- 01101
      CULL_OPAQUE                , -- 01110
      CULL_NO_OPAQUE             , -- 01111
      SKIP_TRIANGLES             , -- 10000
      SKIPAABBS                  , -- 10001
      STATUS_BIT0                , -- 10010
      STATUS_BIT1                , -- 10011
      NCM_TYPE_BIT0              , -- 10100
      NCM_TYPE_BIT1              , -- 10101
      CM_TYPE_BIT0               , -- 10110
      CM_TYPE_BIT1               , -- 10111
      CM_IS_OPAQUE               , -- 11000
      CD_TYPE_BIT0               , -- 11001
      CD_TYPE_BIT1               , -- 11010
      CD_IS_OPAQUE               , -- 11011
      CD_UPDATED                 , -- 11100
      HIERARCHY_SEARCH_FINISH    , -- 11101
      RAY_QUERY                  , -- 11110
      HIT_KIND                     -- 11111
   );
   attribute enum_encoding of t_e_flags_dword_type : type is "00000 00001 00010 00011 00100 00101 00110 00111 01000 01001 01010 01011 01100 01101 01110 01111 10000 10001 10010 10011 10100 10101 10110 10111 11000 11001 11010 11011 11100 11101 11110 11111";
   constant E_FLAGS_DWORD_TYPE_CULL_MASK_BIT0              : std_logic_vector(4 downto 0) := "00000";
   constant E_FLAGS_DWORD_TYPE_CULL_MASK_BIT1              : std_logic_vector(4 downto 0) := "00001";
   constant E_FLAGS_DWORD_TYPE_CULL_MASK_BIT2              : std_logic_vector(4 downto 0) := "00010";
   constant E_FLAGS_DWORD_TYPE_CULL_MASK_BIT3              : std_logic_vector(4 downto 0) := "00011";
   constant E_FLAGS_DWORD_TYPE_CULL_MASK_BIT4              : std_logic_vector(4 downto 0) := "00100";
   constant E_FLAGS_DWORD_TYPE_CULL_MASK_BIT5              : std_logic_vector(4 downto 0) := "00101";
   constant E_FLAGS_DWORD_TYPE_CULL_MASK_BIT6              : std_logic_vector(4 downto 0) := "00110";
   constant E_FLAGS_DWORD_TYPE_CULL_MASK_BIT7              : std_logic_vector(4 downto 0) := "00111";
   constant E_FLAGS_DWORD_TYPE_OPAQUE                      : std_logic_vector(4 downto 0) := "01000";
   constant E_FLAGS_DWORD_TYPE_NO_OPAQUE                   : std_logic_vector(4 downto 0) := "01001";
   constant E_FLAGS_DWORD_TYPE_TERMINATE_ON_FIRST_HIT      : std_logic_vector(4 downto 0) := "01010";
   constant E_FLAGS_DWORD_TYPE_SKIP_CLOSEST_HIT_SHADER     : std_logic_vector(4 downto 0) := "01011";
   constant E_FLAGS_DWORD_TYPE_CULL_BACK_FACING_TRIANGLES  : std_logic_vector(4 downto 0) := "01100";
   constant E_FLAGS_DWORD_TYPE_CULL_FRONT_FACING_TRIANGLES : std_logic_vector(4 downto 0) := "01101";
   constant E_FLAGS_DWORD_TYPE_CULL_OPAQUE                 : std_logic_vector(4 downto 0) := "01110";
   constant E_FLAGS_DWORD_TYPE_CULL_NO_OPAQUE              : std_logic_vector(4 downto 0) := "01111";
   constant E_FLAGS_DWORD_TYPE_SKIP_TRIANGLES              : std_logic_vector(4 downto 0) := "10000";
   constant E_FLAGS_DWORD_TYPE_SKIPAABBS                   : std_logic_vector(4 downto 0) := "10001";
   constant E_FLAGS_DWORD_TYPE_STATUS_BIT0                 : std_logic_vector(4 downto 0) := "10010";
   constant E_FLAGS_DWORD_TYPE_STATUS_BIT1                 : std_logic_vector(4 downto 0) := "10011";
   constant E_FLAGS_DWORD_TYPE_NCM_TYPE_BIT0               : std_logic_vector(4 downto 0) := "10100";
   constant E_FLAGS_DWORD_TYPE_NCM_TYPE_BIT1               : std_logic_vector(4 downto 0) := "10101";
   constant E_FLAGS_DWORD_TYPE_CM_TYPE_BIT0                : std_logic_vector(4 downto 0) := "10110";
   constant E_FLAGS_DWORD_TYPE_CM_TYPE_BIT1                : std_logic_vector(4 downto 0) := "10111";
   constant E_FLAGS_DWORD_TYPE_CM_IS_OPAQUE                : std_logic_vector(4 downto 0) := "11000";
   constant E_FLAGS_DWORD_TYPE_CD_TYPE_BIT0                : std_logic_vector(4 downto 0) := "11001";
   constant E_FLAGS_DWORD_TYPE_CD_TYPE_BIT1                : std_logic_vector(4 downto 0) := "11010";
   constant E_FLAGS_DWORD_TYPE_CD_IS_OPAQUE                : std_logic_vector(4 downto 0) := "11011";
   constant E_FLAGS_DWORD_TYPE_CD_UPDATED                  : std_logic_vector(4 downto 0) := "11100";
   constant E_FLAGS_DWORD_TYPE_HIERARCHY_SEARCH_FINISH     : std_logic_vector(4 downto 0) := "11101";
   constant E_FLAGS_DWORD_TYPE_RAY_QUERY                   : std_logic_vector(4 downto 0) := "11110";
   constant E_FLAGS_DWORD_TYPE_HIT_KIND                    : std_logic_vector(4 downto 0) := "11111";

   function to_slv(i : t_e_flags_dword_type ) return std_logic_vector;
   function to_t_e_flags_dword_type(i : std_logic_vector(4 downto 0)) return t_e_flags_dword_type;

   type t_e_ray_set_select_type is (
      SEL_PRIMARY  , -- 0
      SEL_SECONDARY  -- 1
   );
   attribute enum_encoding of t_e_ray_set_select_type : type is "0 1";
   constant E_RAY_SET_SELECT_TYPE_SEL_PRIMARY   : std_logic_vector(0 downto 0) := "0";
   constant E_RAY_SET_SELECT_TYPE_SEL_SECONDARY : std_logic_vector(0 downto 0) := "1";

   function to_slv(i : t_e_ray_set_select_type ) return std_logic_vector;
   function to_t_e_ray_set_select_type(i : std_logic_vector(0 downto 0)) return t_e_ray_set_select_type;

   type t_e_rstore_space_trace_type is (
      ORIGIN_X              , -- 0000
      ORIGIN_Y              , -- 0001
      ORIGIN_Z              , -- 0010
      DIRECTION_X           , -- 0011
      DIRECTION_Y           , -- 0100
      DIRECTION_Z           , -- 0101
      ACCELERATION_STRUCTURE, -- 0110
      NCM_T_TMIN            , -- 0111
      CM_T_CD_T             , -- 1000
      FLAGS                 , -- 1001
      SBT_OFFSET            , -- 1010
      SBT_STRIDE            , -- 1011
      MISS_INDEX            , -- 1100
      PAYLOAD_DWORD_0       , -- 1101
      PAYLOAD_DWORD_1       , -- 1110
      PAYLOAD_DWORD_2         -- 1111
   );
   attribute enum_encoding of t_e_rstore_space_trace_type : type is "0000 0001 0010 0011 0100 0101 0110 0111 1000 1001 1010 1011 1100 1101 1110 1111";
   constant E_RSTORE_SPACE_TRACE_TYPE_ORIGIN_X               : std_logic_vector(3 downto 0) := "0000";
   constant E_RSTORE_SPACE_TRACE_TYPE_ORIGIN_Y               : std_logic_vector(3 downto 0) := "0001";
   constant E_RSTORE_SPACE_TRACE_TYPE_ORIGIN_Z               : std_logic_vector(3 downto 0) := "0010";
   constant E_RSTORE_SPACE_TRACE_TYPE_DIRECTION_X            : std_logic_vector(3 downto 0) := "0011";
   constant E_RSTORE_SPACE_TRACE_TYPE_DIRECTION_Y            : std_logic_vector(3 downto 0) := "0100";
   constant E_RSTORE_SPACE_TRACE_TYPE_DIRECTION_Z            : std_logic_vector(3 downto 0) := "0101";
   constant E_RSTORE_SPACE_TRACE_TYPE_ACCELERATION_STRUCTURE : std_logic_vector(3 downto 0) := "0110";
   constant E_RSTORE_SPACE_TRACE_TYPE_NCM_T_TMIN             : std_logic_vector(3 downto 0) := "0111";
   constant E_RSTORE_SPACE_TRACE_TYPE_CM_T_CD_T              : std_logic_vector(3 downto 0) := "1000";
   constant E_RSTORE_SPACE_TRACE_TYPE_FLAGS                  : std_logic_vector(3 downto 0) := "1001";
   constant E_RSTORE_SPACE_TRACE_TYPE_SBT_OFFSET             : std_logic_vector(3 downto 0) := "1010";
   constant E_RSTORE_SPACE_TRACE_TYPE_SBT_STRIDE             : std_logic_vector(3 downto 0) := "1011";
   constant E_RSTORE_SPACE_TRACE_TYPE_MISS_INDEX             : std_logic_vector(3 downto 0) := "1100";
   constant E_RSTORE_SPACE_TRACE_TYPE_PAYLOAD_DWORD_0        : std_logic_vector(3 downto 0) := "1101";
   constant E_RSTORE_SPACE_TRACE_TYPE_PAYLOAD_DWORD_1        : std_logic_vector(3 downto 0) := "1110";
   constant E_RSTORE_SPACE_TRACE_TYPE_PAYLOAD_DWORD_2        : std_logic_vector(3 downto 0) := "1111";

   function to_slv(i : t_e_rstore_space_trace_type ) return std_logic_vector;
   function to_t_e_rstore_space_trace_type(i : std_logic_vector(3 downto 0)) return t_e_rstore_space_trace_type;

   type t_e_rstore_space_query_type is (
      ORIGIN_X              , -- 0000
      ORIGIN_Y              , -- 0001
      ORIGIN_Z              , -- 0010
      DIRECTION_X           , -- 0011
      DIRECTION_Y           , -- 0100
      DIRECTION_Z           , -- 0101
      ACCELERATION_STRUCTURE, -- 0110
      NCM_T                 , -- 0111
      CM_T_CD_T             , -- 1000
      FLAGS                 , -- 1001
      CM_NCM_INSTANCE_INDEX , -- 1010
      CM_NCM_PRIMITIVE_INDEX, -- 1011
      CM_NCM_GEOMETRY_INDEX , -- 1100
      CM_CD_INSTANCE_INDEX  , -- 1101
      CM_CD_PRIMITIVE_INDEX , -- 1110
      CM_CD_GEOMETRY_INDEX    -- 1111
   );
   attribute enum_encoding of t_e_rstore_space_query_type : type is "0000 0001 0010 0011 0100 0101 0110 0111 1000 1001 1010 1011 1100 1101 1110 1111";
   constant E_RSTORE_SPACE_QUERY_TYPE_ORIGIN_X               : std_logic_vector(3 downto 0) := "0000";
   constant E_RSTORE_SPACE_QUERY_TYPE_ORIGIN_Y               : std_logic_vector(3 downto 0) := "0001";
   constant E_RSTORE_SPACE_QUERY_TYPE_ORIGIN_Z               : std_logic_vector(3 downto 0) := "0010";
   constant E_RSTORE_SPACE_QUERY_TYPE_DIRECTION_X            : std_logic_vector(3 downto 0) := "0011";
   constant E_RSTORE_SPACE_QUERY_TYPE_DIRECTION_Y            : std_logic_vector(3 downto 0) := "0100";
   constant E_RSTORE_SPACE_QUERY_TYPE_DIRECTION_Z            : std_logic_vector(3 downto 0) := "0101";
   constant E_RSTORE_SPACE_QUERY_TYPE_ACCELERATION_STRUCTURE : std_logic_vector(3 downto 0) := "0110";
   constant E_RSTORE_SPACE_QUERY_TYPE_NCM_T                  : std_logic_vector(3 downto 0) := "0111";
   constant E_RSTORE_SPACE_QUERY_TYPE_CM_T_CD_T              : std_logic_vector(3 downto 0) := "1000";
   constant E_RSTORE_SPACE_QUERY_TYPE_FLAGS                  : std_logic_vector(3 downto 0) := "1001";
   constant E_RSTORE_SPACE_QUERY_TYPE_CM_NCM_INSTANCE_INDEX  : std_logic_vector(3 downto 0) := "1010";
   constant E_RSTORE_SPACE_QUERY_TYPE_CM_NCM_PRIMITIVE_INDEX : std_logic_vector(3 downto 0) := "1011";
   constant E_RSTORE_SPACE_QUERY_TYPE_CM_NCM_GEOMETRY_INDEX  : std_logic_vector(3 downto 0) := "1100";
   constant E_RSTORE_SPACE_QUERY_TYPE_CM_CD_INSTANCE_INDEX   : std_logic_vector(3 downto 0) := "1101";
   constant E_RSTORE_SPACE_QUERY_TYPE_CM_CD_PRIMITIVE_INDEX  : std_logic_vector(3 downto 0) := "1110";
   constant E_RSTORE_SPACE_QUERY_TYPE_CM_CD_GEOMETRY_INDEX   : std_logic_vector(3 downto 0) := "1111";

   function to_slv(i : t_e_rstore_space_query_type ) return std_logic_vector;
   function to_t_e_rstore_space_query_type(i : std_logic_vector(3 downto 0)) return t_e_rstore_space_query_type;

   type t_e_rstore_space_call_type is (
      MISS_INDEX            , -- 00000
      PAYLOAD_DWORD_0       , -- 00001
      PAYLOAD_DWORD_1       , -- 00010
      PAYLOAD_DWORD_2       , -- 00011
      ORIGIN_X              , -- 00100
      ORIGIN_Y              , -- 00101
      ORIGIN_Z              , -- 00110
      DIRECTION_X           , -- 00111
      DIRECTION_Y           , -- 01000
      DIRECTION_Z           , -- 01001
      NCM_T                 , -- 01010
      CM_T                  , -- 01011
      TMIN                  , -- 01100
      CD_T                  , -- 01101
      ACCELERATION_STRUCTURE, -- 01110
      U                     , -- 01111
      V                       -- 10000
   );
   attribute enum_encoding of t_e_rstore_space_call_type : type is "00000 00001 00010 00011 00100 00101 00110 00111 01000 01001 01010 01011 01100 01101 01110 01111 10000";
   constant E_RSTORE_SPACE_CALL_TYPE_MISS_INDEX             : std_logic_vector(4 downto 0) := "00000";
   constant E_RSTORE_SPACE_CALL_TYPE_PAYLOAD_DWORD_0        : std_logic_vector(4 downto 0) := "00001";
   constant E_RSTORE_SPACE_CALL_TYPE_PAYLOAD_DWORD_1        : std_logic_vector(4 downto 0) := "00010";
   constant E_RSTORE_SPACE_CALL_TYPE_PAYLOAD_DWORD_2        : std_logic_vector(4 downto 0) := "00011";
   constant E_RSTORE_SPACE_CALL_TYPE_ORIGIN_X               : std_logic_vector(4 downto 0) := "00100";
   constant E_RSTORE_SPACE_CALL_TYPE_ORIGIN_Y               : std_logic_vector(4 downto 0) := "00101";
   constant E_RSTORE_SPACE_CALL_TYPE_ORIGIN_Z               : std_logic_vector(4 downto 0) := "00110";
   constant E_RSTORE_SPACE_CALL_TYPE_DIRECTION_X            : std_logic_vector(4 downto 0) := "00111";
   constant E_RSTORE_SPACE_CALL_TYPE_DIRECTION_Y            : std_logic_vector(4 downto 0) := "01000";
   constant E_RSTORE_SPACE_CALL_TYPE_DIRECTION_Z            : std_logic_vector(4 downto 0) := "01001";
   constant E_RSTORE_SPACE_CALL_TYPE_NCM_T                  : std_logic_vector(4 downto 0) := "01010";
   constant E_RSTORE_SPACE_CALL_TYPE_CM_T                   : std_logic_vector(4 downto 0) := "01011";
   constant E_RSTORE_SPACE_CALL_TYPE_TMIN                   : std_logic_vector(4 downto 0) := "01100";
   constant E_RSTORE_SPACE_CALL_TYPE_CD_T                   : std_logic_vector(4 downto 0) := "01101";
   constant E_RSTORE_SPACE_CALL_TYPE_ACCELERATION_STRUCTURE : std_logic_vector(4 downto 0) := "01110";
   constant E_RSTORE_SPACE_CALL_TYPE_U                      : std_logic_vector(4 downto 0) := "01111";
   constant E_RSTORE_SPACE_CALL_TYPE_V                      : std_logic_vector(4 downto 0) := "10000";

   function to_slv(i : t_e_rstore_space_call_type ) return std_logic_vector;
   function to_t_e_rstore_space_call_type(i : std_logic_vector(4 downto 0)) return t_e_rstore_space_call_type;

   type t_e_rload_space_rid_type is (
      RID  -- 0
   );
   attribute enum_encoding of t_e_rload_space_rid_type : type is "0";
   constant E_RLOAD_SPACE_RID_TYPE_RID : std_logic_vector(0 downto 0) := "0";

   function to_slv(i : t_e_rload_space_rid_type ) return std_logic_vector;
   function to_t_e_rload_space_rid_type(i : std_logic_vector(0 downto 0)) return t_e_rload_space_rid_type;

   type t_e_rload_space_primary_type is (
      PAYLOAD_DWORD_0, -- 000
      PAYLOAD_DWORD_1, -- 001
      PAYLOAD_DWORD_2, -- 010
      DWORD3         , -- 011
      LAUNCH_ID_X    , -- 100
      LAUNCH_ID_Y    , -- 101
      LAUNCH_ID_Z      -- 110
   );
   attribute enum_encoding of t_e_rload_space_primary_type : type is "000 001 010 011 100 101 110";
   constant E_RLOAD_SPACE_PRIMARY_TYPE_PAYLOAD_DWORD_0 : std_logic_vector(2 downto 0) := "000";
   constant E_RLOAD_SPACE_PRIMARY_TYPE_PAYLOAD_DWORD_1 : std_logic_vector(2 downto 0) := "001";
   constant E_RLOAD_SPACE_PRIMARY_TYPE_PAYLOAD_DWORD_2 : std_logic_vector(2 downto 0) := "010";
   constant E_RLOAD_SPACE_PRIMARY_TYPE_DWORD3          : std_logic_vector(2 downto 0) := "011";
   constant E_RLOAD_SPACE_PRIMARY_TYPE_LAUNCH_ID_X     : std_logic_vector(2 downto 0) := "100";
   constant E_RLOAD_SPACE_PRIMARY_TYPE_LAUNCH_ID_Y     : std_logic_vector(2 downto 0) := "101";
   constant E_RLOAD_SPACE_PRIMARY_TYPE_LAUNCH_ID_Z     : std_logic_vector(2 downto 0) := "110";

   function to_slv(i : t_e_rload_space_primary_type ) return std_logic_vector;
   function to_t_e_rload_space_primary_type(i : std_logic_vector(2 downto 0)) return t_e_rload_space_primary_type;

   type t_e_rload_space_launch_size_type is (
      LAUNCH_SIZE_X, -- 00
      LAUNCH_SIZE_Y, -- 01
      LAUNCH_SIZE_Z, -- 10
      DWORD3         -- 11
   );
   attribute enum_encoding of t_e_rload_space_launch_size_type : type is "00 01 10 11";
   constant E_RLOAD_SPACE_LAUNCH_SIZE_TYPE_LAUNCH_SIZE_X : std_logic_vector(1 downto 0) := "00";
   constant E_RLOAD_SPACE_LAUNCH_SIZE_TYPE_LAUNCH_SIZE_Y : std_logic_vector(1 downto 0) := "01";
   constant E_RLOAD_SPACE_LAUNCH_SIZE_TYPE_LAUNCH_SIZE_Z : std_logic_vector(1 downto 0) := "10";
   constant E_RLOAD_SPACE_LAUNCH_SIZE_TYPE_DWORD3        : std_logic_vector(1 downto 0) := "11";

   function to_slv(i : t_e_rload_space_launch_size_type ) return std_logic_vector;
   function to_t_e_rload_space_launch_size_type(i : std_logic_vector(1 downto 0)) return t_e_rload_space_launch_size_type;

   type t_e_rload_space_trace_type is (
      ORIGIN_X              , -- 00000
      ORIGIN_Y              , -- 00001
      ORIGIN_Z              , -- 00010
      DIRECTION_X           , -- 00011
      DIRECTION_Y           , -- 00100
      DIRECTION_Z           , -- 00101
      TMIN                  , -- 00110
      CM_T_CD_T             , -- 00111
      FLAGS                 , -- 01000
      U                     , -- 01001
      V                     , -- 01010
      ACCELERATION_STRUCTURE, -- 01011
      CD_INSTANCE_INDEX     , -- 01100
      CD_PRIMITIVE_INDEX    , -- 01101
      CD_GEOMETRY_INDEX     , -- 01110
      DWORD15               , -- 01111
      PAYLOAD_DWORD_0       , -- 10000
      PAYLOAD_DWORD_1       , -- 10001
      PAYLOAD_DWORD_2         -- 10010
   );
   attribute enum_encoding of t_e_rload_space_trace_type : type is "00000 00001 00010 00011 00100 00101 00110 00111 01000 01001 01010 01011 01100 01101 01110 01111 10000 10001 10010";
   constant E_RLOAD_SPACE_TRACE_TYPE_ORIGIN_X               : std_logic_vector(4 downto 0) := "00000";
   constant E_RLOAD_SPACE_TRACE_TYPE_ORIGIN_Y               : std_logic_vector(4 downto 0) := "00001";
   constant E_RLOAD_SPACE_TRACE_TYPE_ORIGIN_Z               : std_logic_vector(4 downto 0) := "00010";
   constant E_RLOAD_SPACE_TRACE_TYPE_DIRECTION_X            : std_logic_vector(4 downto 0) := "00011";
   constant E_RLOAD_SPACE_TRACE_TYPE_DIRECTION_Y            : std_logic_vector(4 downto 0) := "00100";
   constant E_RLOAD_SPACE_TRACE_TYPE_DIRECTION_Z            : std_logic_vector(4 downto 0) := "00101";
   constant E_RLOAD_SPACE_TRACE_TYPE_TMIN                   : std_logic_vector(4 downto 0) := "00110";
   constant E_RLOAD_SPACE_TRACE_TYPE_CM_T_CD_T              : std_logic_vector(4 downto 0) := "00111";
   constant E_RLOAD_SPACE_TRACE_TYPE_FLAGS                  : std_logic_vector(4 downto 0) := "01000";
   constant E_RLOAD_SPACE_TRACE_TYPE_U                      : std_logic_vector(4 downto 0) := "01001";
   constant E_RLOAD_SPACE_TRACE_TYPE_V                      : std_logic_vector(4 downto 0) := "01010";
   constant E_RLOAD_SPACE_TRACE_TYPE_ACCELERATION_STRUCTURE : std_logic_vector(4 downto 0) := "01011";
   constant E_RLOAD_SPACE_TRACE_TYPE_CD_INSTANCE_INDEX      : std_logic_vector(4 downto 0) := "01100";
   constant E_RLOAD_SPACE_TRACE_TYPE_CD_PRIMITIVE_INDEX     : std_logic_vector(4 downto 0) := "01101";
   constant E_RLOAD_SPACE_TRACE_TYPE_CD_GEOMETRY_INDEX      : std_logic_vector(4 downto 0) := "01110";
   constant E_RLOAD_SPACE_TRACE_TYPE_DWORD15                : std_logic_vector(4 downto 0) := "01111";
   constant E_RLOAD_SPACE_TRACE_TYPE_PAYLOAD_DWORD_0        : std_logic_vector(4 downto 0) := "10000";
   constant E_RLOAD_SPACE_TRACE_TYPE_PAYLOAD_DWORD_1        : std_logic_vector(4 downto 0) := "10001";
   constant E_RLOAD_SPACE_TRACE_TYPE_PAYLOAD_DWORD_2        : std_logic_vector(4 downto 0) := "10010";

   function to_slv(i : t_e_rload_space_trace_type ) return std_logic_vector;
   function to_t_e_rload_space_trace_type(i : std_logic_vector(4 downto 0)) return t_e_rload_space_trace_type;

   type t_e_rload_space_query_type is (
      CD_T              , -- 0000
      CM_T              , -- 0001
      FLAGS             , -- 0010
      DWORD3            , -- 0011
      CD_INSTANCE_INDEX , -- 0100
      CD_PRIMITIVE_INDEX, -- 0101
      CD_GEOMETRY_INDEX , -- 0110
      CM_INSTANCE_INDEX , -- 0111
      CM_PRIMITIVE_INDEX, -- 1000
      CM_GEOMETRY_INDEX , -- 1001
      U                 , -- 1010
      V                   -- 1011
   );
   attribute enum_encoding of t_e_rload_space_query_type : type is "0000 0001 0010 0011 0100 0101 0110 0111 1000 1001 1010 1011";
   constant E_RLOAD_SPACE_QUERY_TYPE_CD_T               : std_logic_vector(3 downto 0) := "0000";
   constant E_RLOAD_SPACE_QUERY_TYPE_CM_T               : std_logic_vector(3 downto 0) := "0001";
   constant E_RLOAD_SPACE_QUERY_TYPE_FLAGS              : std_logic_vector(3 downto 0) := "0010";
   constant E_RLOAD_SPACE_QUERY_TYPE_DWORD3             : std_logic_vector(3 downto 0) := "0011";
   constant E_RLOAD_SPACE_QUERY_TYPE_CD_INSTANCE_INDEX  : std_logic_vector(3 downto 0) := "0100";
   constant E_RLOAD_SPACE_QUERY_TYPE_CD_PRIMITIVE_INDEX : std_logic_vector(3 downto 0) := "0101";
   constant E_RLOAD_SPACE_QUERY_TYPE_CD_GEOMETRY_INDEX  : std_logic_vector(3 downto 0) := "0110";
   constant E_RLOAD_SPACE_QUERY_TYPE_CM_INSTANCE_INDEX  : std_logic_vector(3 downto 0) := "0111";
   constant E_RLOAD_SPACE_QUERY_TYPE_CM_PRIMITIVE_INDEX : std_logic_vector(3 downto 0) := "1000";
   constant E_RLOAD_SPACE_QUERY_TYPE_CM_GEOMETRY_INDEX  : std_logic_vector(3 downto 0) := "1001";
   constant E_RLOAD_SPACE_QUERY_TYPE_U                  : std_logic_vector(3 downto 0) := "1010";
   constant E_RLOAD_SPACE_QUERY_TYPE_V                  : std_logic_vector(3 downto 0) := "1011";

   function to_slv(i : t_e_rload_space_query_type ) return std_logic_vector;
   function to_t_e_rload_space_query_type(i : std_logic_vector(3 downto 0)) return t_e_rload_space_query_type;

   type t_e_rload_space_call_type is (
      PAYLOAD_DWORD_0       , -- 00000
      PAYLOAD_DWORD_1       , -- 00001
      PAYLOAD_DWORD_2       , -- 00010
      DWORD3                , -- 00011
      ORIGIN_X              , -- 00100
      ORIGIN_Y              , -- 00101
      ORIGIN_Z              , -- 00110
      DIRECTION_X           , -- 00111
      DIRECTION_Y           , -- 01000
      DIRECTION_Z           , -- 01001
      NCM_T                 , -- 01010
      CM_T                  , -- 01011
      TMIN                  , -- 01100
      CD_T                  , -- 01101
      ACCELERATION_STRUCTURE, -- 01110
      U                     , -- 01111
      V                       -- 10000
   );
   attribute enum_encoding of t_e_rload_space_call_type : type is "00000 00001 00010 00011 00100 00101 00110 00111 01000 01001 01010 01011 01100 01101 01110 01111 10000";
   constant E_RLOAD_SPACE_CALL_TYPE_PAYLOAD_DWORD_0        : std_logic_vector(4 downto 0) := "00000";
   constant E_RLOAD_SPACE_CALL_TYPE_PAYLOAD_DWORD_1        : std_logic_vector(4 downto 0) := "00001";
   constant E_RLOAD_SPACE_CALL_TYPE_PAYLOAD_DWORD_2        : std_logic_vector(4 downto 0) := "00010";
   constant E_RLOAD_SPACE_CALL_TYPE_DWORD3                 : std_logic_vector(4 downto 0) := "00011";
   constant E_RLOAD_SPACE_CALL_TYPE_ORIGIN_X               : std_logic_vector(4 downto 0) := "00100";
   constant E_RLOAD_SPACE_CALL_TYPE_ORIGIN_Y               : std_logic_vector(4 downto 0) := "00101";
   constant E_RLOAD_SPACE_CALL_TYPE_ORIGIN_Z               : std_logic_vector(4 downto 0) := "00110";
   constant E_RLOAD_SPACE_CALL_TYPE_DIRECTION_X            : std_logic_vector(4 downto 0) := "00111";
   constant E_RLOAD_SPACE_CALL_TYPE_DIRECTION_Y            : std_logic_vector(4 downto 0) := "01000";
   constant E_RLOAD_SPACE_CALL_TYPE_DIRECTION_Z            : std_logic_vector(4 downto 0) := "01001";
   constant E_RLOAD_SPACE_CALL_TYPE_NCM_T                  : std_logic_vector(4 downto 0) := "01010";
   constant E_RLOAD_SPACE_CALL_TYPE_CM_T                   : std_logic_vector(4 downto 0) := "01011";
   constant E_RLOAD_SPACE_CALL_TYPE_TMIN                   : std_logic_vector(4 downto 0) := "01100";
   constant E_RLOAD_SPACE_CALL_TYPE_CD_T                   : std_logic_vector(4 downto 0) := "01101";
   constant E_RLOAD_SPACE_CALL_TYPE_ACCELERATION_STRUCTURE : std_logic_vector(4 downto 0) := "01110";
   constant E_RLOAD_SPACE_CALL_TYPE_U                      : std_logic_vector(4 downto 0) := "01111";
   constant E_RLOAD_SPACE_CALL_TYPE_V                      : std_logic_vector(4 downto 0) := "10000";

   function to_slv(i : t_e_rload_space_call_type ) return std_logic_vector;
   function to_t_e_rload_space_call_type(i : std_logic_vector(4 downto 0)) return t_e_rload_space_call_type;

   type t_e_rload_space_debug_type is (
      NCM_T              , -- 0000
      DWORD1             , -- 0001
      DWORD2             , -- 0010
      DWORD3             , -- 0011
      NCM_INSTANCE_INDEX , -- 0100
      NCM_PRIMITIVE_INDEX, -- 0101
      NCM_GEOMETRY_INDEX , -- 0110
      MISS_INDEX         , -- 0111
      SBT_OFFSET         , -- 1000
      SBT_STRIDE         , -- 1001
      DWORD10            , -- 1010
      DWORD11              -- 1011
   );
   attribute enum_encoding of t_e_rload_space_debug_type : type is "0000 0001 0010 0011 0100 0101 0110 0111 1000 1001 1010 1011";
   constant E_RLOAD_SPACE_DEBUG_TYPE_NCM_T               : std_logic_vector(3 downto 0) := "0000";
   constant E_RLOAD_SPACE_DEBUG_TYPE_DWORD1              : std_logic_vector(3 downto 0) := "0001";
   constant E_RLOAD_SPACE_DEBUG_TYPE_DWORD2              : std_logic_vector(3 downto 0) := "0010";
   constant E_RLOAD_SPACE_DEBUG_TYPE_DWORD3              : std_logic_vector(3 downto 0) := "0011";
   constant E_RLOAD_SPACE_DEBUG_TYPE_NCM_INSTANCE_INDEX  : std_logic_vector(3 downto 0) := "0100";
   constant E_RLOAD_SPACE_DEBUG_TYPE_NCM_PRIMITIVE_INDEX : std_logic_vector(3 downto 0) := "0101";
   constant E_RLOAD_SPACE_DEBUG_TYPE_NCM_GEOMETRY_INDEX  : std_logic_vector(3 downto 0) := "0110";
   constant E_RLOAD_SPACE_DEBUG_TYPE_MISS_INDEX          : std_logic_vector(3 downto 0) := "0111";
   constant E_RLOAD_SPACE_DEBUG_TYPE_SBT_OFFSET          : std_logic_vector(3 downto 0) := "1000";
   constant E_RLOAD_SPACE_DEBUG_TYPE_SBT_STRIDE          : std_logic_vector(3 downto 0) := "1001";
   constant E_RLOAD_SPACE_DEBUG_TYPE_DWORD10             : std_logic_vector(3 downto 0) := "1010";
   constant E_RLOAD_SPACE_DEBUG_TYPE_DWORD11             : std_logic_vector(3 downto 0) := "1011";

   function to_slv(i : t_e_rload_space_debug_type ) return std_logic_vector;
   function to_t_e_rload_space_debug_type(i : std_logic_vector(3 downto 0)) return t_e_rload_space_debug_type;

   type t_e_sbt_sel_type is (
      HIT , -- 00
      MISS, -- 01
      CALL, -- 10
      NONE  -- 11
   );
   attribute enum_encoding of t_e_sbt_sel_type : type is "00 01 10 11";
   constant E_SBT_SEL_TYPE_HIT  : std_logic_vector(1 downto 0) := "00";
   constant E_SBT_SEL_TYPE_MISS : std_logic_vector(1 downto 0) := "01";
   constant E_SBT_SEL_TYPE_CALL : std_logic_vector(1 downto 0) := "10";
   constant E_SBT_SEL_TYPE_NONE : std_logic_vector(1 downto 0) := "11";

   function to_slv(i : t_e_sbt_sel_type ) return std_logic_vector;
   function to_t_e_sbt_sel_type(i : std_logic_vector(1 downto 0)) return t_e_sbt_sel_type;

   type t_e_hg_sel_type is (
      TRAVERSE   , -- 0
      CLOSEST_HIT  -- 1
   );
   attribute enum_encoding of t_e_hg_sel_type : type is "0 1";
   constant E_HG_SEL_TYPE_TRAVERSE    : std_logic_vector(0 downto 0) := "0";
   constant E_HG_SEL_TYPE_CLOSEST_HIT : std_logic_vector(0 downto 0) := "1";

   function to_slv(i : t_e_hg_sel_type ) return std_logic_vector;
   function to_t_e_hg_sel_type(i : std_logic_vector(0 downto 0)) return t_e_hg_sel_type;

   type t_e_ray_prog_sel_type is (
      PROG_NULL    , -- 00
      PROG_0       , -- 01
      PROG_1       , -- 10
      PROG_RESERVED  -- 11
   );
   attribute enum_encoding of t_e_ray_prog_sel_type : type is "00 01 10 11";
   constant E_RAY_PROG_SEL_TYPE_PROG_NULL     : std_logic_vector(1 downto 0) := "00";
   constant E_RAY_PROG_SEL_TYPE_PROG_0        : std_logic_vector(1 downto 0) := "01";
   constant E_RAY_PROG_SEL_TYPE_PROG_1        : std_logic_vector(1 downto 0) := "10";
   constant E_RAY_PROG_SEL_TYPE_PROG_RESERVED : std_logic_vector(1 downto 0) := "11";

   function to_slv(i : t_e_ray_prog_sel_type ) return std_logic_vector;
   function to_t_e_ray_prog_sel_type(i : std_logic_vector(1 downto 0)) return t_e_ray_prog_sel_type;

   type t_e_hier_node_type is (
      BOX_BLOCK       , -- 00
      VERTEX_BLOCK    , -- 01
      PROCEDURAL_BLOCK, -- 10
      INSTANCE_BLOCK    -- 11
   );
   attribute enum_encoding of t_e_hier_node_type : type is "00 01 10 11";
   constant E_HIER_NODE_TYPE_BOX_BLOCK        : std_logic_vector(1 downto 0) := "00";
   constant E_HIER_NODE_TYPE_VERTEX_BLOCK     : std_logic_vector(1 downto 0) := "01";
   constant E_HIER_NODE_TYPE_PROCEDURAL_BLOCK : std_logic_vector(1 downto 0) := "10";
   constant E_HIER_NODE_TYPE_INSTANCE_BLOCK   : std_logic_vector(1 downto 0) := "11";

   function to_slv(i : t_e_hier_node_type ) return std_logic_vector;
   function to_t_e_hier_node_type(i : std_logic_vector(1 downto 0)) return t_e_hier_node_type;

   type t_e_leaf_node_type is (
      TREE_BOX           , -- 00
      TRI_LEAF_BOX       , -- 01
      PROCEDURAL_LEAF_BOX, -- 10
      INSTANCE_LEAF_BOX    -- 11
   );
   attribute enum_encoding of t_e_leaf_node_type : type is "00 01 10 11";
   constant E_LEAF_NODE_TYPE_TREE_BOX            : std_logic_vector(1 downto 0) := "00";
   constant E_LEAF_NODE_TYPE_TRI_LEAF_BOX        : std_logic_vector(1 downto 0) := "01";
   constant E_LEAF_NODE_TYPE_PROCEDURAL_LEAF_BOX : std_logic_vector(1 downto 0) := "10";
   constant E_LEAF_NODE_TYPE_INSTANCE_LEAF_BOX   : std_logic_vector(1 downto 0) := "11";

   function to_slv(i : t_e_leaf_node_type ) return std_logic_vector;
   function to_t_e_leaf_node_type(i : std_logic_vector(1 downto 0)) return t_e_leaf_node_type;

   type t_e_serial_flag_type is (
      NORMAL_RAY, -- 0
      SERIAL_RAY  -- 1
   );
   attribute enum_encoding of t_e_serial_flag_type : type is "0 1";
   constant E_SERIAL_FLAG_TYPE_NORMAL_RAY : std_logic_vector(0 downto 0) := "0";
   constant E_SERIAL_FLAG_TYPE_SERIAL_RAY : std_logic_vector(0 downto 0) := "1";

   function to_slv(i : t_e_serial_flag_type ) return std_logic_vector;
   function to_t_e_serial_flag_type(i : std_logic_vector(0 downto 0)) return t_e_serial_flag_type;

   type t_e_hier_dm_type is (
      HIER_GEOM   , -- 00
      HIER_FRAG   , -- 01
      HIER_COMPUTE, -- 10
      HIER_RAY      -- 11
   );
   attribute enum_encoding of t_e_hier_dm_type : type is "00 01 10 11";
   constant E_HIER_DM_TYPE_HIER_GEOM    : std_logic_vector(1 downto 0) := "00";
   constant E_HIER_DM_TYPE_HIER_FRAG    : std_logic_vector(1 downto 0) := "01";
   constant E_HIER_DM_TYPE_HIER_COMPUTE : std_logic_vector(1 downto 0) := "10";
   constant E_HIER_DM_TYPE_HIER_RAY     : std_logic_vector(1 downto 0) := "11";

   function to_slv(i : t_e_hier_dm_type ) return std_logic_vector;
   function to_t_e_hier_dm_type(i : std_logic_vector(1 downto 0)) return t_e_hier_dm_type;

   type t_e_dm_type is (
      GEOM   , -- 00
      FRAG   , -- 01
      COMPUTE, -- 10
      RAY      -- 11
   );
   attribute enum_encoding of t_e_dm_type : type is "00 01 10 11";
   constant E_DM_TYPE_GEOM    : std_logic_vector(1 downto 0) := "00";
   constant E_DM_TYPE_FRAG    : std_logic_vector(1 downto 0) := "01";
   constant E_DM_TYPE_COMPUTE : std_logic_vector(1 downto 0) := "10";
   constant E_DM_TYPE_RAY     : std_logic_vector(1 downto 0) := "11";

   function to_slv(i : t_e_dm_type ) return std_logic_vector;
   function to_t_e_dm_type(i : std_logic_vector(1 downto 0)) return t_e_dm_type;

   type t_e_rce_rts_cmd is (
      SHADER_BINDING_TABLE   , -- 000
      UNIFORM_DESCRIPTOR_BASE, -- 001
      LAUNCH_SIZE            , -- 010
      RAYGEN                 , -- 011
      LIMIT                  , -- 100
      FENCE                    -- 101
   );
   attribute enum_encoding of t_e_rce_rts_cmd : type is "000 001 010 011 100 101";
   constant E_RCE_RTS_CMD_SHADER_BINDING_TABLE    : std_logic_vector(2 downto 0) := "000";
   constant E_RCE_RTS_CMD_UNIFORM_DESCRIPTOR_BASE : std_logic_vector(2 downto 0) := "001";
   constant E_RCE_RTS_CMD_LAUNCH_SIZE             : std_logic_vector(2 downto 0) := "010";
   constant E_RCE_RTS_CMD_RAYGEN                  : std_logic_vector(2 downto 0) := "011";
   constant E_RCE_RTS_CMD_LIMIT                   : std_logic_vector(2 downto 0) := "100";
   constant E_RCE_RTS_CMD_FENCE                   : std_logic_vector(2 downto 0) := "101";

   function to_slv(i : t_e_rce_rts_cmd ) return std_logic_vector;
   function to_t_e_rce_rts_cmd(i : std_logic_vector(2 downto 0)) return t_e_rce_rts_cmd;

   type t_e_box_prim_type is (
      BOX , -- 0
      PRIM  -- 1
   );
   attribute enum_encoding of t_e_box_prim_type : type is "0 1";
   constant E_BOX_PRIM_TYPE_BOX  : std_logic_vector(0 downto 0) := "0";
   constant E_BOX_PRIM_TYPE_PRIM : std_logic_vector(0 downto 0) := "1";

   function to_slv(i : t_e_box_prim_type ) return std_logic_vector;
   function to_t_e_box_prim_type(i : std_logic_vector(0 downto 0)) return t_e_box_prim_type;

   type t_e_prim_type is (
      TRIANGLE       , -- 0
      PROCEDURAL_AABB  -- 1
   );
   attribute enum_encoding of t_e_prim_type : type is "0 1";
   constant E_PRIM_TYPE_TRIANGLE        : std_logic_vector(0 downto 0) := "0";
   constant E_PRIM_TYPE_PROCEDURAL_AABB : std_logic_vector(0 downto 0) := "1";

   function to_slv(i : t_e_prim_type ) return std_logic_vector;
   function to_t_e_prim_type(i : std_logic_vector(0 downto 0)) return t_e_prim_type;

   type t_e_data_type is (
      BLOCK_DATA   , -- 0
      INSTANCE_DATA  -- 1
   );
   attribute enum_encoding of t_e_data_type : type is "0 1";
   constant E_DATA_TYPE_BLOCK_DATA    : std_logic_vector(0 downto 0) := "0";
   constant E_DATA_TYPE_INSTANCE_DATA : std_logic_vector(0 downto 0) := "1";

   function to_slv(i : t_e_data_type ) return std_logic_vector;
   function to_t_e_data_type(i : std_logic_vector(0 downto 0)) return t_e_data_type;

   type t_e_bytes_select_type is (
      MID_BYTES, -- 00
      BOT_BYTES, -- 01
      TOP_BYTES, -- 10
      ALL_BYTES  -- 11
   );
   attribute enum_encoding of t_e_bytes_select_type : type is "00 01 10 11";
   constant E_BYTES_SELECT_TYPE_MID_BYTES : std_logic_vector(1 downto 0) := "00";
   constant E_BYTES_SELECT_TYPE_BOT_BYTES : std_logic_vector(1 downto 0) := "01";
   constant E_BYTES_SELECT_TYPE_TOP_BYTES : std_logic_vector(1 downto 0) := "10";
   constant E_BYTES_SELECT_TYPE_ALL_BYTES : std_logic_vector(1 downto 0) := "11";

   function to_slv(i : t_e_bytes_select_type ) return std_logic_vector;
   function to_t_e_bytes_select_type(i : std_logic_vector(1 downto 0)) return t_e_bytes_select_type;

   type t_e_block_node_type is (
      INVALID_BLOCK             , -- 000
      TLAS_ROOT_BLOCK           , -- 001
      TRIANGLE_BLAS_ROOT_BLOCK  , -- 010
      PROCEDURAL_BLAS_ROOT_BLOCK, -- 011
      BOX_FORMAT_BLOCK          , -- 100
      VERTEX_FORMAT_BLOCK       , -- 101
      PROCEDURAL_FORMAT_BLOCK   , -- 110
      INSTANCE_FORMAT_BLOCK       -- 111
   );
   attribute enum_encoding of t_e_block_node_type : type is "000 001 010 011 100 101 110 111";
   constant E_BLOCK_NODE_TYPE_INVALID_BLOCK              : std_logic_vector(2 downto 0) := "000";
   constant E_BLOCK_NODE_TYPE_TLAS_ROOT_BLOCK            : std_logic_vector(2 downto 0) := "001";
   constant E_BLOCK_NODE_TYPE_TRIANGLE_BLAS_ROOT_BLOCK   : std_logic_vector(2 downto 0) := "010";
   constant E_BLOCK_NODE_TYPE_PROCEDURAL_BLAS_ROOT_BLOCK : std_logic_vector(2 downto 0) := "011";
   constant E_BLOCK_NODE_TYPE_BOX_FORMAT_BLOCK           : std_logic_vector(2 downto 0) := "100";
   constant E_BLOCK_NODE_TYPE_VERTEX_FORMAT_BLOCK        : std_logic_vector(2 downto 0) := "101";
   constant E_BLOCK_NODE_TYPE_PROCEDURAL_FORMAT_BLOCK    : std_logic_vector(2 downto 0) := "110";
   constant E_BLOCK_NODE_TYPE_INSTANCE_FORMAT_BLOCK      : std_logic_vector(2 downto 0) := "111";

   function to_slv(i : t_e_block_node_type ) return std_logic_vector;
   function to_t_e_block_node_type(i : std_logic_vector(2 downto 0)) return t_e_block_node_type;

   type t_e_octant_encoding_type is (
      OC_PPP, -- 000
      OC_PPN, -- 001
      OC_PNP, -- 010
      OC_PNN, -- 011
      OC_NPP, -- 100
      OC_NPN, -- 101
      OC_NNP, -- 110
      OC_NNN  -- 111
   );
   attribute enum_encoding of t_e_octant_encoding_type : type is "000 001 010 011 100 101 110 111";
   constant E_OCTANT_ENCODING_TYPE_OC_PPP : std_logic_vector(2 downto 0) := "000";
   constant E_OCTANT_ENCODING_TYPE_OC_PPN : std_logic_vector(2 downto 0) := "001";
   constant E_OCTANT_ENCODING_TYPE_OC_PNP : std_logic_vector(2 downto 0) := "010";
   constant E_OCTANT_ENCODING_TYPE_OC_PNN : std_logic_vector(2 downto 0) := "011";
   constant E_OCTANT_ENCODING_TYPE_OC_NPP : std_logic_vector(2 downto 0) := "100";
   constant E_OCTANT_ENCODING_TYPE_OC_NPN : std_logic_vector(2 downto 0) := "101";
   constant E_OCTANT_ENCODING_TYPE_OC_NNP : std_logic_vector(2 downto 0) := "110";
   constant E_OCTANT_ENCODING_TYPE_OC_NNN : std_logic_vector(2 downto 0) := "111";

   function to_slv(i : t_e_octant_encoding_type ) return std_logic_vector;
   function to_t_e_octant_encoding_type(i : std_logic_vector(2 downto 0)) return t_e_octant_encoding_type;

   type t_e_set_id_type is (
      SET_ID_COMMITTED   , -- 00
      SET_ID_CANDIDATE   , -- 01
      SET_ID_NONCOMMITTED  -- 10
   );
   attribute enum_encoding of t_e_set_id_type : type is "00 01 10";
   constant E_SET_ID_TYPE_SET_ID_COMMITTED    : std_logic_vector(1 downto 0) := "00";
   constant E_SET_ID_TYPE_SET_ID_CANDIDATE    : std_logic_vector(1 downto 0) := "01";
   constant E_SET_ID_TYPE_SET_ID_NONCOMMITTED : std_logic_vector(1 downto 0) := "10";

   function to_slv(i : t_e_set_id_type ) return std_logic_vector;
   function to_t_e_set_id_type(i : std_logic_vector(1 downto 0)) return t_e_set_id_type;
end package pkg_rt;

package body pkg_rt is

   -- conversion function for e_rstore_op_type enumerator
   function to_slv(i : t_e_rstore_op_type ) return std_logic_vector is
      variable ret : std_logic_vector(2 downto 0);
   begin
      case i is
         when WRITE            => ret := E_RSTORE_OP_TYPE_WRITE;
         when WRITEANDTRACE    => ret := E_RSTORE_OP_TYPE_WRITEANDTRACE;
         when WRITEANDCALL     => ret := E_RSTORE_OP_TYPE_WRITEANDCALL;
         when WRITEANDPROCEED  => ret := E_RSTORE_OP_TYPE_WRITEANDPROCEED;
         when WRITEANDACCEPT   => ret := E_RSTORE_OP_TYPE_WRITEANDACCEPT;
         when others           => ret := E_RSTORE_OP_TYPE_WRITEANDRESUBMIT;
      end case;
      return ret;
   end function;
   -- conversion function for e_rstore_op_type enumerator
   function to_t_e_rstore_op_type(i : std_logic_vector(2 downto 0)) return t_e_rstore_op_type is
      variable ret : t_e_rstore_op_type;
   begin
      case i is
         when E_RSTORE_OP_TYPE_WRITE            => ret := WRITE;
         when E_RSTORE_OP_TYPE_WRITEANDTRACE    => ret := WRITEANDTRACE;
         when E_RSTORE_OP_TYPE_WRITEANDCALL     => ret := WRITEANDCALL;
         when E_RSTORE_OP_TYPE_WRITEANDPROCEED  => ret := WRITEANDPROCEED;
         when E_RSTORE_OP_TYPE_WRITEANDACCEPT   => ret := WRITEANDACCEPT;
         when others                            => ret := WRITEANDRESUBMIT;
      end case;
      return ret;
   end function;

   -- conversion function for e_rstore_space_type enumerator
   function to_slv(i : t_e_rstore_space_type ) return std_logic_vector is
      variable ret : std_logic_vector(1 downto 0);
   begin
      case i is
         when TRACE => ret := E_RSTORE_SPACE_TYPE_TRACE;
         when QUERY => ret := E_RSTORE_SPACE_TYPE_QUERY;
         when others => ret := E_RSTORE_SPACE_TYPE_CALL;
      end case;
      return ret;
   end function;
   -- conversion function for e_rstore_space_type enumerator
   function to_t_e_rstore_space_type(i : std_logic_vector(1 downto 0)) return t_e_rstore_space_type is
      variable ret : t_e_rstore_space_type;
   begin
      case i is
         when E_RSTORE_SPACE_TYPE_TRACE => ret := TRACE;
         when E_RSTORE_SPACE_TYPE_QUERY => ret := QUERY;
         when others                    => ret := CALL;
      end case;
      return ret;
   end function;

   -- conversion function for e_rload_op_type enumerator
   function to_slv(i : t_e_rload_op_type ) return std_logic_vector is
      variable ret : std_logic_vector(1 downto 0);
   begin
      case i is
         when READ       => ret := E_RLOAD_OP_TYPE_READ;
         when ALLOCATE   => ret := E_RLOAD_OP_TYPE_ALLOCATE;
         when others     => ret := E_RLOAD_OP_TYPE_DEALLOCATE;
      end case;
      return ret;
   end function;
   -- conversion function for e_rload_op_type enumerator
   function to_t_e_rload_op_type(i : std_logic_vector(1 downto 0)) return t_e_rload_op_type is
      variable ret : t_e_rload_op_type;
   begin
      case i is
         when E_RLOAD_OP_TYPE_READ       => ret := READ;
         when E_RLOAD_OP_TYPE_ALLOCATE   => ret := ALLOCATE;
         when others                     => ret := DEALLOCATE;
      end case;
      return ret;
   end function;

   -- conversion function for e_rload_space_type enumerator
   function to_slv(i : t_e_rload_space_type ) return std_logic_vector is
      variable ret : std_logic_vector(2 downto 0);
   begin
      case i is
         when RID         => ret := E_RLOAD_SPACE_TYPE_RID;
         when PRIMARY     => ret := E_RLOAD_SPACE_TYPE_PRIMARY;
         when LAUNCH_SIZE => ret := E_RLOAD_SPACE_TYPE_LAUNCH_SIZE;
         when TRACE       => ret := E_RLOAD_SPACE_TYPE_TRACE;
         when QUERY       => ret := E_RLOAD_SPACE_TYPE_QUERY;
         when CALL        => ret := E_RLOAD_SPACE_TYPE_CALL;
         when others      => ret := E_RLOAD_SPACE_TYPE_DEBUG;
      end case;
      return ret;
   end function;
   -- conversion function for e_rload_space_type enumerator
   function to_t_e_rload_space_type(i : std_logic_vector(2 downto 0)) return t_e_rload_space_type is
      variable ret : t_e_rload_space_type;
   begin
      case i is
         when E_RLOAD_SPACE_TYPE_RID         => ret := RID;
         when E_RLOAD_SPACE_TYPE_PRIMARY     => ret := PRIMARY;
         when E_RLOAD_SPACE_TYPE_LAUNCH_SIZE => ret := LAUNCH_SIZE;
         when E_RLOAD_SPACE_TYPE_TRACE       => ret := TRACE;
         when E_RLOAD_SPACE_TYPE_QUERY       => ret := QUERY;
         when E_RLOAD_SPACE_TYPE_CALL        => ret := CALL;
         when others                         => ret := DEBUG;
      end case;
      return ret;
   end function;

   -- conversion function for e_uri_cu_st_ld_n_type enumerator
   function to_slv(i : t_e_uri_cu_st_ld_n_type ) return std_logic_vector is
      variable ret : std_logic_vector(0 downto 0);
   begin
      case i is
         when RLOAD  => ret := E_URI_CU_ST_LD_N_TYPE_RLOAD;
         when others => ret := E_URI_CU_ST_LD_N_TYPE_RSTORE;
      end case;
      return ret;
   end function;
   -- conversion function for e_uri_cu_st_ld_n_type enumerator
   function to_t_e_uri_cu_st_ld_n_type(i : std_logic_vector(0 downto 0)) return t_e_uri_cu_st_ld_n_type is
      variable ret : t_e_uri_cu_st_ld_n_type;
   begin
      case i is
         when E_URI_CU_ST_LD_N_TYPE_RLOAD  => ret := RLOAD;
         when others                        => ret := RSTORE;
      end case;
      return ret;
   end function;

   -- conversion function for e_uri_cu_inst_mode_type enumerator
   function to_slv(i : t_e_uri_cu_inst_mode_type ) return std_logic_vector is
      variable ret : std_logic_vector(0 downto 0);
   begin
      case i is
         when SINGLE => ret := E_URI_CU_INST_MODE_TYPE_SINGLE;
         when others => ret := E_URI_CU_INST_MODE_TYPE_MULTI;
      end case;
      return ret;
   end function;
   -- conversion function for e_uri_cu_inst_mode_type enumerator
   function to_t_e_uri_cu_inst_mode_type(i : std_logic_vector(0 downto 0)) return t_e_uri_cu_inst_mode_type is
      variable ret : t_e_uri_cu_inst_mode_type;
   begin
      case i is
         when E_URI_CU_INST_MODE_TYPE_SINGLE => ret := SINGLE;
         when others                          => ret := MULTI;
      end case;
      return ret;
   end function;

   -- conversion function for e_flags_dword_type enumerator
   function to_slv(i : t_e_flags_dword_type ) return std_logic_vector is
      variable ret : std_logic_vector(4 downto 0);
   begin
      case i is
         when CULL_MASK_BIT0              => ret := E_FLAGS_DWORD_TYPE_CULL_MASK_BIT0;
         when CULL_MASK_BIT1              => ret := E_FLAGS_DWORD_TYPE_CULL_MASK_BIT1;
         when CULL_MASK_BIT2              => ret := E_FLAGS_DWORD_TYPE_CULL_MASK_BIT2;
         when CULL_MASK_BIT3              => ret := E_FLAGS_DWORD_TYPE_CULL_MASK_BIT3;
         when CULL_MASK_BIT4              => ret := E_FLAGS_DWORD_TYPE_CULL_MASK_BIT4;
         when CULL_MASK_BIT5              => ret := E_FLAGS_DWORD_TYPE_CULL_MASK_BIT5;
         when CULL_MASK_BIT6              => ret := E_FLAGS_DWORD_TYPE_CULL_MASK_BIT6;
         when CULL_MASK_BIT7              => ret := E_FLAGS_DWORD_TYPE_CULL_MASK_BIT7;
         when OPAQUE                      => ret := E_FLAGS_DWORD_TYPE_OPAQUE;
         when NO_OPAQUE                   => ret := E_FLAGS_DWORD_TYPE_NO_OPAQUE;
         when TERMINATE_ON_FIRST_HIT      => ret := E_FLAGS_DWORD_TYPE_TERMINATE_ON_FIRST_HIT;
         when SKIP_CLOSEST_HIT_SHADER     => ret := E_FLAGS_DWORD_TYPE_SKIP_CLOSEST_HIT_SHADER;
         when CULL_BACK_FACING_TRIANGLES  => ret := E_FLAGS_DWORD_TYPE_CULL_BACK_FACING_TRIANGLES;
         when CULL_FRONT_FACING_TRIANGLES => ret := E_FLAGS_DWORD_TYPE_CULL_FRONT_FACING_TRIANGLES;
         when CULL_OPAQUE                 => ret := E_FLAGS_DWORD_TYPE_CULL_OPAQUE;
         when CULL_NO_OPAQUE              => ret := E_FLAGS_DWORD_TYPE_CULL_NO_OPAQUE;
         when SKIP_TRIANGLES              => ret := E_FLAGS_DWORD_TYPE_SKIP_TRIANGLES;
         when SKIPAABBS                   => ret := E_FLAGS_DWORD_TYPE_SKIPAABBS;
         when STATUS_BIT0                 => ret := E_FLAGS_DWORD_TYPE_STATUS_BIT0;
         when STATUS_BIT1                 => ret := E_FLAGS_DWORD_TYPE_STATUS_BIT1;
         when NCM_TYPE_BIT0               => ret := E_FLAGS_DWORD_TYPE_NCM_TYPE_BIT0;
         when NCM_TYPE_BIT1               => ret := E_FLAGS_DWORD_TYPE_NCM_TYPE_BIT1;
         when CM_TYPE_BIT0                => ret := E_FLAGS_DWORD_TYPE_CM_TYPE_BIT0;
         when CM_TYPE_BIT1                => ret := E_FLAGS_DWORD_TYPE_CM_TYPE_BIT1;
         when CM_IS_OPAQUE                => ret := E_FLAGS_DWORD_TYPE_CM_IS_OPAQUE;
         when CD_TYPE_BIT0                => ret := E_FLAGS_DWORD_TYPE_CD_TYPE_BIT0;
         when CD_TYPE_BIT1                => ret := E_FLAGS_DWORD_TYPE_CD_TYPE_BIT1;
         when CD_IS_OPAQUE                => ret := E_FLAGS_DWORD_TYPE_CD_IS_OPAQUE;
         when CD_UPDATED                  => ret := E_FLAGS_DWORD_TYPE_CD_UPDATED;
         when HIERARCHY_SEARCH_FINISH     => ret := E_FLAGS_DWORD_TYPE_HIERARCHY_SEARCH_FINISH;
         when RAY_QUERY                   => ret := E_FLAGS_DWORD_TYPE_RAY_QUERY;
         when others                      => ret := E_FLAGS_DWORD_TYPE_HIT_KIND;
      end case;
      return ret;
   end function;
   -- conversion function for e_flags_dword_type enumerator
   function to_t_e_flags_dword_type(i : std_logic_vector(4 downto 0)) return t_e_flags_dword_type is
      variable ret : t_e_flags_dword_type;
   begin
      case i is
         when E_FLAGS_DWORD_TYPE_CULL_MASK_BIT0              => ret := CULL_MASK_BIT0;
         when E_FLAGS_DWORD_TYPE_CULL_MASK_BIT1              => ret := CULL_MASK_BIT1;
         when E_FLAGS_DWORD_TYPE_CULL_MASK_BIT2              => ret := CULL_MASK_BIT2;
         when E_FLAGS_DWORD_TYPE_CULL_MASK_BIT3              => ret := CULL_MASK_BIT3;
         when E_FLAGS_DWORD_TYPE_CULL_MASK_BIT4              => ret := CULL_MASK_BIT4;
         when E_FLAGS_DWORD_TYPE_CULL_MASK_BIT5              => ret := CULL_MASK_BIT5;
         when E_FLAGS_DWORD_TYPE_CULL_MASK_BIT6              => ret := CULL_MASK_BIT6;
         when E_FLAGS_DWORD_TYPE_CULL_MASK_BIT7              => ret := CULL_MASK_BIT7;
         when E_FLAGS_DWORD_TYPE_OPAQUE                      => ret := OPAQUE;
         when E_FLAGS_DWORD_TYPE_NO_OPAQUE                   => ret := NO_OPAQUE;
         when E_FLAGS_DWORD_TYPE_TERMINATE_ON_FIRST_HIT      => ret := TERMINATE_ON_FIRST_HIT;
         when E_FLAGS_DWORD_TYPE_SKIP_CLOSEST_HIT_SHADER     => ret := SKIP_CLOSEST_HIT_SHADER;
         when E_FLAGS_DWORD_TYPE_CULL_BACK_FACING_TRIANGLES  => ret := CULL_BACK_FACING_TRIANGLES;
         when E_FLAGS_DWORD_TYPE_CULL_FRONT_FACING_TRIANGLES => ret := CULL_FRONT_FACING_TRIANGLES;
         when E_FLAGS_DWORD_TYPE_CULL_OPAQUE                 => ret := CULL_OPAQUE;
         when E_FLAGS_DWORD_TYPE_CULL_NO_OPAQUE              => ret := CULL_NO_OPAQUE;
         when E_FLAGS_DWORD_TYPE_SKIP_TRIANGLES              => ret := SKIP_TRIANGLES;
         when E_FLAGS_DWORD_TYPE_SKIPAABBS                   => ret := SKIPAABBS;
         when E_FLAGS_DWORD_TYPE_STATUS_BIT0                 => ret := STATUS_BIT0;
         when E_FLAGS_DWORD_TYPE_STATUS_BIT1                 => ret := STATUS_BIT1;
         when E_FLAGS_DWORD_TYPE_NCM_TYPE_BIT0               => ret := NCM_TYPE_BIT0;
         when E_FLAGS_DWORD_TYPE_NCM_TYPE_BIT1               => ret := NCM_TYPE_BIT1;
         when E_FLAGS_DWORD_TYPE_CM_TYPE_BIT0                => ret := CM_TYPE_BIT0;
         when E_FLAGS_DWORD_TYPE_CM_TYPE_BIT1                => ret := CM_TYPE_BIT1;
         when E_FLAGS_DWORD_TYPE_CM_IS_OPAQUE                => ret := CM_IS_OPAQUE;
         when E_FLAGS_DWORD_TYPE_CD_TYPE_BIT0                => ret := CD_TYPE_BIT0;
         when E_FLAGS_DWORD_TYPE_CD_TYPE_BIT1                => ret := CD_TYPE_BIT1;
         when E_FLAGS_DWORD_TYPE_CD_IS_OPAQUE                => ret := CD_IS_OPAQUE;
         when E_FLAGS_DWORD_TYPE_CD_UPDATED                  => ret := CD_UPDATED;
         when E_FLAGS_DWORD_TYPE_HIERARCHY_SEARCH_FINISH     => ret := HIERARCHY_SEARCH_FINISH;
         when E_FLAGS_DWORD_TYPE_RAY_QUERY                   => ret := RAY_QUERY;
         when others                                         => ret := HIT_KIND;
      end case;
      return ret;
   end function;

   -- conversion function for e_ray_set_select_type enumerator
   function to_slv(i : t_e_ray_set_select_type ) return std_logic_vector is
      variable ret : std_logic_vector(0 downto 0);
   begin
      case i is
         when SEL_PRIMARY   => ret := E_RAY_SET_SELECT_TYPE_SEL_PRIMARY;
         when others        => ret := E_RAY_SET_SELECT_TYPE_SEL_SECONDARY;
      end case;
      return ret;
   end function;
   -- conversion function for e_ray_set_select_type enumerator
   function to_t_e_ray_set_select_type(i : std_logic_vector(0 downto 0)) return t_e_ray_set_select_type is
      variable ret : t_e_ray_set_select_type;
   begin
      case i is
         when E_RAY_SET_SELECT_TYPE_SEL_PRIMARY   => ret := SEL_PRIMARY;
         when others                              => ret := SEL_SECONDARY;
      end case;
      return ret;
   end function;

   -- conversion function for e_rstore_space_trace_type enumerator
   function to_slv(i : t_e_rstore_space_trace_type ) return std_logic_vector is
      variable ret : std_logic_vector(3 downto 0);
   begin
      case i is
         when ORIGIN_X               => ret := E_RSTORE_SPACE_TRACE_TYPE_ORIGIN_X;
         when ORIGIN_Y               => ret := E_RSTORE_SPACE_TRACE_TYPE_ORIGIN_Y;
         when ORIGIN_Z               => ret := E_RSTORE_SPACE_TRACE_TYPE_ORIGIN_Z;
         when DIRECTION_X            => ret := E_RSTORE_SPACE_TRACE_TYPE_DIRECTION_X;
         when DIRECTION_Y            => ret := E_RSTORE_SPACE_TRACE_TYPE_DIRECTION_Y;
         when DIRECTION_Z            => ret := E_RSTORE_SPACE_TRACE_TYPE_DIRECTION_Z;
         when ACCELERATION_STRUCTURE => ret := E_RSTORE_SPACE_TRACE_TYPE_ACCELERATION_STRUCTURE;
         when NCM_T_TMIN             => ret := E_RSTORE_SPACE_TRACE_TYPE_NCM_T_TMIN;
         when CM_T_CD_T              => ret := E_RSTORE_SPACE_TRACE_TYPE_CM_T_CD_T;
         when FLAGS                  => ret := E_RSTORE_SPACE_TRACE_TYPE_FLAGS;
         when SBT_OFFSET             => ret := E_RSTORE_SPACE_TRACE_TYPE_SBT_OFFSET;
         when SBT_STRIDE             => ret := E_RSTORE_SPACE_TRACE_TYPE_SBT_STRIDE;
         when MISS_INDEX             => ret := E_RSTORE_SPACE_TRACE_TYPE_MISS_INDEX;
         when PAYLOAD_DWORD_0        => ret := E_RSTORE_SPACE_TRACE_TYPE_PAYLOAD_DWORD_0;
         when PAYLOAD_DWORD_1        => ret := E_RSTORE_SPACE_TRACE_TYPE_PAYLOAD_DWORD_1;
         when others                 => ret := E_RSTORE_SPACE_TRACE_TYPE_PAYLOAD_DWORD_2;
      end case;
      return ret;
   end function;
   -- conversion function for e_rstore_space_trace_type enumerator
   function to_t_e_rstore_space_trace_type(i : std_logic_vector(3 downto 0)) return t_e_rstore_space_trace_type is
      variable ret : t_e_rstore_space_trace_type;
   begin
      case i is
         when E_RSTORE_SPACE_TRACE_TYPE_ORIGIN_X               => ret := ORIGIN_X;
         when E_RSTORE_SPACE_TRACE_TYPE_ORIGIN_Y               => ret := ORIGIN_Y;
         when E_RSTORE_SPACE_TRACE_TYPE_ORIGIN_Z               => ret := ORIGIN_Z;
         when E_RSTORE_SPACE_TRACE_TYPE_DIRECTION_X            => ret := DIRECTION_X;
         when E_RSTORE_SPACE_TRACE_TYPE_DIRECTION_Y            => ret := DIRECTION_Y;
         when E_RSTORE_SPACE_TRACE_TYPE_DIRECTION_Z            => ret := DIRECTION_Z;
         when E_RSTORE_SPACE_TRACE_TYPE_ACCELERATION_STRUCTURE => ret := ACCELERATION_STRUCTURE;
         when E_RSTORE_SPACE_TRACE_TYPE_NCM_T_TMIN             => ret := NCM_T_TMIN;
         when E_RSTORE_SPACE_TRACE_TYPE_CM_T_CD_T              => ret := CM_T_CD_T;
         when E_RSTORE_SPACE_TRACE_TYPE_FLAGS                  => ret := FLAGS;
         when E_RSTORE_SPACE_TRACE_TYPE_SBT_OFFSET             => ret := SBT_OFFSET;
         when E_RSTORE_SPACE_TRACE_TYPE_SBT_STRIDE             => ret := SBT_STRIDE;
         when E_RSTORE_SPACE_TRACE_TYPE_MISS_INDEX             => ret := MISS_INDEX;
         when E_RSTORE_SPACE_TRACE_TYPE_PAYLOAD_DWORD_0        => ret := PAYLOAD_DWORD_0;
         when E_RSTORE_SPACE_TRACE_TYPE_PAYLOAD_DWORD_1        => ret := PAYLOAD_DWORD_1;
         when others                                           => ret := PAYLOAD_DWORD_2;
      end case;
      return ret;
   end function;

   -- conversion function for e_rstore_space_query_type enumerator
   function to_slv(i : t_e_rstore_space_query_type ) return std_logic_vector is
      variable ret : std_logic_vector(3 downto 0);
   begin
      case i is
         when ORIGIN_X               => ret := E_RSTORE_SPACE_QUERY_TYPE_ORIGIN_X;
         when ORIGIN_Y               => ret := E_RSTORE_SPACE_QUERY_TYPE_ORIGIN_Y;
         when ORIGIN_Z               => ret := E_RSTORE_SPACE_QUERY_TYPE_ORIGIN_Z;
         when DIRECTION_X            => ret := E_RSTORE_SPACE_QUERY_TYPE_DIRECTION_X;
         when DIRECTION_Y            => ret := E_RSTORE_SPACE_QUERY_TYPE_DIRECTION_Y;
         when DIRECTION_Z            => ret := E_RSTORE_SPACE_QUERY_TYPE_DIRECTION_Z;
         when ACCELERATION_STRUCTURE => ret := E_RSTORE_SPACE_QUERY_TYPE_ACCELERATION_STRUCTURE;
         when NCM_T                  => ret := E_RSTORE_SPACE_QUERY_TYPE_NCM_T;
         when CM_T_CD_T              => ret := E_RSTORE_SPACE_QUERY_TYPE_CM_T_CD_T;
         when FLAGS                  => ret := E_RSTORE_SPACE_QUERY_TYPE_FLAGS;
         when CM_NCM_INSTANCE_INDEX  => ret := E_RSTORE_SPACE_QUERY_TYPE_CM_NCM_INSTANCE_INDEX;
         when CM_NCM_PRIMITIVE_INDEX => ret := E_RSTORE_SPACE_QUERY_TYPE_CM_NCM_PRIMITIVE_INDEX;
         when CM_NCM_GEOMETRY_INDEX  => ret := E_RSTORE_SPACE_QUERY_TYPE_CM_NCM_GEOMETRY_INDEX;
         when CM_CD_INSTANCE_INDEX   => ret := E_RSTORE_SPACE_QUERY_TYPE_CM_CD_INSTANCE_INDEX;
         when CM_CD_PRIMITIVE_INDEX  => ret := E_RSTORE_SPACE_QUERY_TYPE_CM_CD_PRIMITIVE_INDEX;
         when others                 => ret := E_RSTORE_SPACE_QUERY_TYPE_CM_CD_GEOMETRY_INDEX;
      end case;
      return ret;
   end function;
   -- conversion function for e_rstore_space_query_type enumerator
   function to_t_e_rstore_space_query_type(i : std_logic_vector(3 downto 0)) return t_e_rstore_space_query_type is
      variable ret : t_e_rstore_space_query_type;
   begin
      case i is
         when E_RSTORE_SPACE_QUERY_TYPE_ORIGIN_X               => ret := ORIGIN_X;
         when E_RSTORE_SPACE_QUERY_TYPE_ORIGIN_Y               => ret := ORIGIN_Y;
         when E_RSTORE_SPACE_QUERY_TYPE_ORIGIN_Z               => ret := ORIGIN_Z;
         when E_RSTORE_SPACE_QUERY_TYPE_DIRECTION_X            => ret := DIRECTION_X;
         when E_RSTORE_SPACE_QUERY_TYPE_DIRECTION_Y            => ret := DIRECTION_Y;
         when E_RSTORE_SPACE_QUERY_TYPE_DIRECTION_Z            => ret := DIRECTION_Z;
         when E_RSTORE_SPACE_QUERY_TYPE_ACCELERATION_STRUCTURE => ret := ACCELERATION_STRUCTURE;
         when E_RSTORE_SPACE_QUERY_TYPE_NCM_T                  => ret := NCM_T;
         when E_RSTORE_SPACE_QUERY_TYPE_CM_T_CD_T              => ret := CM_T_CD_T;
         when E_RSTORE_SPACE_QUERY_TYPE_FLAGS                  => ret := FLAGS;
         when E_RSTORE_SPACE_QUERY_TYPE_CM_NCM_INSTANCE_INDEX  => ret := CM_NCM_INSTANCE_INDEX;
         when E_RSTORE_SPACE_QUERY_TYPE_CM_NCM_PRIMITIVE_INDEX => ret := CM_NCM_PRIMITIVE_INDEX;
         when E_RSTORE_SPACE_QUERY_TYPE_CM_NCM_GEOMETRY_INDEX  => ret := CM_NCM_GEOMETRY_INDEX;
         when E_RSTORE_SPACE_QUERY_TYPE_CM_CD_INSTANCE_INDEX   => ret := CM_CD_INSTANCE_INDEX;
         when E_RSTORE_SPACE_QUERY_TYPE_CM_CD_PRIMITIVE_INDEX  => ret := CM_CD_PRIMITIVE_INDEX;
         when others                                           => ret := CM_CD_GEOMETRY_INDEX;
      end case;
      return ret;
   end function;

   -- conversion function for e_rstore_space_call_type enumerator
   function to_slv(i : t_e_rstore_space_call_type ) return std_logic_vector is
      variable ret : std_logic_vector(4 downto 0);
   begin
      case i is
         when MISS_INDEX             => ret := E_RSTORE_SPACE_CALL_TYPE_MISS_INDEX;
         when PAYLOAD_DWORD_0        => ret := E_RSTORE_SPACE_CALL_TYPE_PAYLOAD_DWORD_0;
         when PAYLOAD_DWORD_1        => ret := E_RSTORE_SPACE_CALL_TYPE_PAYLOAD_DWORD_1;
         when PAYLOAD_DWORD_2        => ret := E_RSTORE_SPACE_CALL_TYPE_PAYLOAD_DWORD_2;
         when ORIGIN_X               => ret := E_RSTORE_SPACE_CALL_TYPE_ORIGIN_X;
         when ORIGIN_Y               => ret := E_RSTORE_SPACE_CALL_TYPE_ORIGIN_Y;
         when ORIGIN_Z               => ret := E_RSTORE_SPACE_CALL_TYPE_ORIGIN_Z;
         when DIRECTION_X            => ret := E_RSTORE_SPACE_CALL_TYPE_DIRECTION_X;
         when DIRECTION_Y            => ret := E_RSTORE_SPACE_CALL_TYPE_DIRECTION_Y;
         when DIRECTION_Z            => ret := E_RSTORE_SPACE_CALL_TYPE_DIRECTION_Z;
         when NCM_T                  => ret := E_RSTORE_SPACE_CALL_TYPE_NCM_T;
         when CM_T                   => ret := E_RSTORE_SPACE_CALL_TYPE_CM_T;
         when TMIN                   => ret := E_RSTORE_SPACE_CALL_TYPE_TMIN;
         when CD_T                   => ret := E_RSTORE_SPACE_CALL_TYPE_CD_T;
         when ACCELERATION_STRUCTURE => ret := E_RSTORE_SPACE_CALL_TYPE_ACCELERATION_STRUCTURE;
         when U                      => ret := E_RSTORE_SPACE_CALL_TYPE_U;
         when others                 => ret := E_RSTORE_SPACE_CALL_TYPE_V;
      end case;
      return ret;
   end function;
   -- conversion function for e_rstore_space_call_type enumerator
   function to_t_e_rstore_space_call_type(i : std_logic_vector(4 downto 0)) return t_e_rstore_space_call_type is
      variable ret : t_e_rstore_space_call_type;
   begin
      case i is
         when E_RSTORE_SPACE_CALL_TYPE_MISS_INDEX             => ret := MISS_INDEX;
         when E_RSTORE_SPACE_CALL_TYPE_PAYLOAD_DWORD_0        => ret := PAYLOAD_DWORD_0;
         when E_RSTORE_SPACE_CALL_TYPE_PAYLOAD_DWORD_1        => ret := PAYLOAD_DWORD_1;
         when E_RSTORE_SPACE_CALL_TYPE_PAYLOAD_DWORD_2        => ret := PAYLOAD_DWORD_2;
         when E_RSTORE_SPACE_CALL_TYPE_ORIGIN_X               => ret := ORIGIN_X;
         when E_RSTORE_SPACE_CALL_TYPE_ORIGIN_Y               => ret := ORIGIN_Y;
         when E_RSTORE_SPACE_CALL_TYPE_ORIGIN_Z               => ret := ORIGIN_Z;
         when E_RSTORE_SPACE_CALL_TYPE_DIRECTION_X            => ret := DIRECTION_X;
         when E_RSTORE_SPACE_CALL_TYPE_DIRECTION_Y            => ret := DIRECTION_Y;
         when E_RSTORE_SPACE_CALL_TYPE_DIRECTION_Z            => ret := DIRECTION_Z;
         when E_RSTORE_SPACE_CALL_TYPE_NCM_T                  => ret := NCM_T;
         when E_RSTORE_SPACE_CALL_TYPE_CM_T                   => ret := CM_T;
         when E_RSTORE_SPACE_CALL_TYPE_TMIN                   => ret := TMIN;
         when E_RSTORE_SPACE_CALL_TYPE_CD_T                   => ret := CD_T;
         when E_RSTORE_SPACE_CALL_TYPE_ACCELERATION_STRUCTURE => ret := ACCELERATION_STRUCTURE;
         when E_RSTORE_SPACE_CALL_TYPE_U                      => ret := U;
         when others                                          => ret := V;
      end case;
      return ret;
   end function;

   -- conversion function for e_rload_space_rid_type enumerator
   function to_slv(i : t_e_rload_space_rid_type ) return std_logic_vector is
      variable ret : std_logic_vector(0 downto 0);
   begin
      case i is
         when others => ret := E_RLOAD_SPACE_RID_TYPE_RID;
      end case;
      return ret;
   end function;
   -- conversion function for e_rload_space_rid_type enumerator
   function to_t_e_rload_space_rid_type(i : std_logic_vector(0 downto 0)) return t_e_rload_space_rid_type is
      variable ret : t_e_rload_space_rid_type;
   begin
      case i is
         when others                     => ret := RID;
      end case;
      return ret;
   end function;

   -- conversion function for e_rload_space_primary_type enumerator
   function to_slv(i : t_e_rload_space_primary_type ) return std_logic_vector is
      variable ret : std_logic_vector(2 downto 0);
   begin
      case i is
         when PAYLOAD_DWORD_0 => ret := E_RLOAD_SPACE_PRIMARY_TYPE_PAYLOAD_DWORD_0;
         when PAYLOAD_DWORD_1 => ret := E_RLOAD_SPACE_PRIMARY_TYPE_PAYLOAD_DWORD_1;
         when PAYLOAD_DWORD_2 => ret := E_RLOAD_SPACE_PRIMARY_TYPE_PAYLOAD_DWORD_2;
         when DWORD3          => ret := E_RLOAD_SPACE_PRIMARY_TYPE_DWORD3;
         when LAUNCH_ID_X     => ret := E_RLOAD_SPACE_PRIMARY_TYPE_LAUNCH_ID_X;
         when LAUNCH_ID_Y     => ret := E_RLOAD_SPACE_PRIMARY_TYPE_LAUNCH_ID_Y;
         when others          => ret := E_RLOAD_SPACE_PRIMARY_TYPE_LAUNCH_ID_Z;
      end case;
      return ret;
   end function;
   -- conversion function for e_rload_space_primary_type enumerator
   function to_t_e_rload_space_primary_type(i : std_logic_vector(2 downto 0)) return t_e_rload_space_primary_type is
      variable ret : t_e_rload_space_primary_type;
   begin
      case i is
         when E_RLOAD_SPACE_PRIMARY_TYPE_PAYLOAD_DWORD_0 => ret := PAYLOAD_DWORD_0;
         when E_RLOAD_SPACE_PRIMARY_TYPE_PAYLOAD_DWORD_1 => ret := PAYLOAD_DWORD_1;
         when E_RLOAD_SPACE_PRIMARY_TYPE_PAYLOAD_DWORD_2 => ret := PAYLOAD_DWORD_2;
         when E_RLOAD_SPACE_PRIMARY_TYPE_DWORD3          => ret := DWORD3;
         when E_RLOAD_SPACE_PRIMARY_TYPE_LAUNCH_ID_X     => ret := LAUNCH_ID_X;
         when E_RLOAD_SPACE_PRIMARY_TYPE_LAUNCH_ID_Y     => ret := LAUNCH_ID_Y;
         when others                                     => ret := LAUNCH_ID_Z;
      end case;
      return ret;
   end function;

   -- conversion function for e_rload_space_launch_size_type enumerator
   function to_slv(i : t_e_rload_space_launch_size_type ) return std_logic_vector is
      variable ret : std_logic_vector(1 downto 0);
   begin
      case i is
         when LAUNCH_SIZE_X => ret := E_RLOAD_SPACE_LAUNCH_SIZE_TYPE_LAUNCH_SIZE_X;
         when LAUNCH_SIZE_Y => ret := E_RLOAD_SPACE_LAUNCH_SIZE_TYPE_LAUNCH_SIZE_Y;
         when LAUNCH_SIZE_Z => ret := E_RLOAD_SPACE_LAUNCH_SIZE_TYPE_LAUNCH_SIZE_Z;
         when others        => ret := E_RLOAD_SPACE_LAUNCH_SIZE_TYPE_DWORD3;
      end case;
      return ret;
   end function;
   -- conversion function for e_rload_space_launch_size_type enumerator
   function to_t_e_rload_space_launch_size_type(i : std_logic_vector(1 downto 0)) return t_e_rload_space_launch_size_type is
      variable ret : t_e_rload_space_launch_size_type;
   begin
      case i is
         when E_RLOAD_SPACE_LAUNCH_SIZE_TYPE_LAUNCH_SIZE_X => ret := LAUNCH_SIZE_X;
         when E_RLOAD_SPACE_LAUNCH_SIZE_TYPE_LAUNCH_SIZE_Y => ret := LAUNCH_SIZE_Y;
         when E_RLOAD_SPACE_LAUNCH_SIZE_TYPE_LAUNCH_SIZE_Z => ret := LAUNCH_SIZE_Z;
         when others                                       => ret := DWORD3;
      end case;
      return ret;
   end function;

   -- conversion function for e_rload_space_trace_type enumerator
   function to_slv(i : t_e_rload_space_trace_type ) return std_logic_vector is
      variable ret : std_logic_vector(4 downto 0);
   begin
      case i is
         when ORIGIN_X               => ret := E_RLOAD_SPACE_TRACE_TYPE_ORIGIN_X;
         when ORIGIN_Y               => ret := E_RLOAD_SPACE_TRACE_TYPE_ORIGIN_Y;
         when ORIGIN_Z               => ret := E_RLOAD_SPACE_TRACE_TYPE_ORIGIN_Z;
         when DIRECTION_X            => ret := E_RLOAD_SPACE_TRACE_TYPE_DIRECTION_X;
         when DIRECTION_Y            => ret := E_RLOAD_SPACE_TRACE_TYPE_DIRECTION_Y;
         when DIRECTION_Z            => ret := E_RLOAD_SPACE_TRACE_TYPE_DIRECTION_Z;
         when TMIN                   => ret := E_RLOAD_SPACE_TRACE_TYPE_TMIN;
         when CM_T_CD_T              => ret := E_RLOAD_SPACE_TRACE_TYPE_CM_T_CD_T;
         when FLAGS                  => ret := E_RLOAD_SPACE_TRACE_TYPE_FLAGS;
         when U                      => ret := E_RLOAD_SPACE_TRACE_TYPE_U;
         when V                      => ret := E_RLOAD_SPACE_TRACE_TYPE_V;
         when ACCELERATION_STRUCTURE => ret := E_RLOAD_SPACE_TRACE_TYPE_ACCELERATION_STRUCTURE;
         when CD_INSTANCE_INDEX      => ret := E_RLOAD_SPACE_TRACE_TYPE_CD_INSTANCE_INDEX;
         when CD_PRIMITIVE_INDEX     => ret := E_RLOAD_SPACE_TRACE_TYPE_CD_PRIMITIVE_INDEX;
         when CD_GEOMETRY_INDEX      => ret := E_RLOAD_SPACE_TRACE_TYPE_CD_GEOMETRY_INDEX;
         when DWORD15                => ret := E_RLOAD_SPACE_TRACE_TYPE_DWORD15;
         when PAYLOAD_DWORD_0        => ret := E_RLOAD_SPACE_TRACE_TYPE_PAYLOAD_DWORD_0;
         when PAYLOAD_DWORD_1        => ret := E_RLOAD_SPACE_TRACE_TYPE_PAYLOAD_DWORD_1;
         when others                 => ret := E_RLOAD_SPACE_TRACE_TYPE_PAYLOAD_DWORD_2;
      end case;
      return ret;
   end function;
   -- conversion function for e_rload_space_trace_type enumerator
   function to_t_e_rload_space_trace_type(i : std_logic_vector(4 downto 0)) return t_e_rload_space_trace_type is
      variable ret : t_e_rload_space_trace_type;
   begin
      case i is
         when E_RLOAD_SPACE_TRACE_TYPE_ORIGIN_X               => ret := ORIGIN_X;
         when E_RLOAD_SPACE_TRACE_TYPE_ORIGIN_Y               => ret := ORIGIN_Y;
         when E_RLOAD_SPACE_TRACE_TYPE_ORIGIN_Z               => ret := ORIGIN_Z;
         when E_RLOAD_SPACE_TRACE_TYPE_DIRECTION_X            => ret := DIRECTION_X;
         when E_RLOAD_SPACE_TRACE_TYPE_DIRECTION_Y            => ret := DIRECTION_Y;
         when E_RLOAD_SPACE_TRACE_TYPE_DIRECTION_Z            => ret := DIRECTION_Z;
         when E_RLOAD_SPACE_TRACE_TYPE_TMIN                   => ret := TMIN;
         when E_RLOAD_SPACE_TRACE_TYPE_CM_T_CD_T              => ret := CM_T_CD_T;
         when E_RLOAD_SPACE_TRACE_TYPE_FLAGS                  => ret := FLAGS;
         when E_RLOAD_SPACE_TRACE_TYPE_U                      => ret := U;
         when E_RLOAD_SPACE_TRACE_TYPE_V                      => ret := V;
         when E_RLOAD_SPACE_TRACE_TYPE_ACCELERATION_STRUCTURE => ret := ACCELERATION_STRUCTURE;
         when E_RLOAD_SPACE_TRACE_TYPE_CD_INSTANCE_INDEX      => ret := CD_INSTANCE_INDEX;
         when E_RLOAD_SPACE_TRACE_TYPE_CD_PRIMITIVE_INDEX     => ret := CD_PRIMITIVE_INDEX;
         when E_RLOAD_SPACE_TRACE_TYPE_CD_GEOMETRY_INDEX      => ret := CD_GEOMETRY_INDEX;
         when E_RLOAD_SPACE_TRACE_TYPE_DWORD15                => ret := DWORD15;
         when E_RLOAD_SPACE_TRACE_TYPE_PAYLOAD_DWORD_0        => ret := PAYLOAD_DWORD_0;
         when E_RLOAD_SPACE_TRACE_TYPE_PAYLOAD_DWORD_1        => ret := PAYLOAD_DWORD_1;
         when others                                          => ret := PAYLOAD_DWORD_2;
      end case;
      return ret;
   end function;

   -- conversion function for e_rload_space_query_type enumerator
   function to_slv(i : t_e_rload_space_query_type ) return std_logic_vector is
      variable ret : std_logic_vector(3 downto 0);
   begin
      case i is
         when CD_T               => ret := E_RLOAD_SPACE_QUERY_TYPE_CD_T;
         when CM_T               => ret := E_RLOAD_SPACE_QUERY_TYPE_CM_T;
         when FLAGS              => ret := E_RLOAD_SPACE_QUERY_TYPE_FLAGS;
         when DWORD3             => ret := E_RLOAD_SPACE_QUERY_TYPE_DWORD3;
         when CD_INSTANCE_INDEX  => ret := E_RLOAD_SPACE_QUERY_TYPE_CD_INSTANCE_INDEX;
         when CD_PRIMITIVE_INDEX => ret := E_RLOAD_SPACE_QUERY_TYPE_CD_PRIMITIVE_INDEX;
         when CD_GEOMETRY_INDEX  => ret := E_RLOAD_SPACE_QUERY_TYPE_CD_GEOMETRY_INDEX;
         when CM_INSTANCE_INDEX  => ret := E_RLOAD_SPACE_QUERY_TYPE_CM_INSTANCE_INDEX;
         when CM_PRIMITIVE_INDEX => ret := E_RLOAD_SPACE_QUERY_TYPE_CM_PRIMITIVE_INDEX;
         when CM_GEOMETRY_INDEX  => ret := E_RLOAD_SPACE_QUERY_TYPE_CM_GEOMETRY_INDEX;
         when U                  => ret := E_RLOAD_SPACE_QUERY_TYPE_U;
         when others             => ret := E_RLOAD_SPACE_QUERY_TYPE_V;
      end case;
      return ret;
   end function;
   -- conversion function for e_rload_space_query_type enumerator
   function to_t_e_rload_space_query_type(i : std_logic_vector(3 downto 0)) return t_e_rload_space_query_type is
      variable ret : t_e_rload_space_query_type;
   begin
      case i is
         when E_RLOAD_SPACE_QUERY_TYPE_CD_T               => ret := CD_T;
         when E_RLOAD_SPACE_QUERY_TYPE_CM_T               => ret := CM_T;
         when E_RLOAD_SPACE_QUERY_TYPE_FLAGS              => ret := FLAGS;
         when E_RLOAD_SPACE_QUERY_TYPE_DWORD3             => ret := DWORD3;
         when E_RLOAD_SPACE_QUERY_TYPE_CD_INSTANCE_INDEX  => ret := CD_INSTANCE_INDEX;
         when E_RLOAD_SPACE_QUERY_TYPE_CD_PRIMITIVE_INDEX => ret := CD_PRIMITIVE_INDEX;
         when E_RLOAD_SPACE_QUERY_TYPE_CD_GEOMETRY_INDEX  => ret := CD_GEOMETRY_INDEX;
         when E_RLOAD_SPACE_QUERY_TYPE_CM_INSTANCE_INDEX  => ret := CM_INSTANCE_INDEX;
         when E_RLOAD_SPACE_QUERY_TYPE_CM_PRIMITIVE_INDEX => ret := CM_PRIMITIVE_INDEX;
         when E_RLOAD_SPACE_QUERY_TYPE_CM_GEOMETRY_INDEX  => ret := CM_GEOMETRY_INDEX;
         when E_RLOAD_SPACE_QUERY_TYPE_U                  => ret := U;
         when others                                      => ret := V;
      end case;
      return ret;
   end function;

   -- conversion function for e_rload_space_call_type enumerator
   function to_slv(i : t_e_rload_space_call_type ) return std_logic_vector is
      variable ret : std_logic_vector(4 downto 0);
   begin
      case i is
         when PAYLOAD_DWORD_0        => ret := E_RLOAD_SPACE_CALL_TYPE_PAYLOAD_DWORD_0;
         when PAYLOAD_DWORD_1        => ret := E_RLOAD_SPACE_CALL_TYPE_PAYLOAD_DWORD_1;
         when PAYLOAD_DWORD_2        => ret := E_RLOAD_SPACE_CALL_TYPE_PAYLOAD_DWORD_2;
         when DWORD3                 => ret := E_RLOAD_SPACE_CALL_TYPE_DWORD3;
         when ORIGIN_X               => ret := E_RLOAD_SPACE_CALL_TYPE_ORIGIN_X;
         when ORIGIN_Y               => ret := E_RLOAD_SPACE_CALL_TYPE_ORIGIN_Y;
         when ORIGIN_Z               => ret := E_RLOAD_SPACE_CALL_TYPE_ORIGIN_Z;
         when DIRECTION_X            => ret := E_RLOAD_SPACE_CALL_TYPE_DIRECTION_X;
         when DIRECTION_Y            => ret := E_RLOAD_SPACE_CALL_TYPE_DIRECTION_Y;
         when DIRECTION_Z            => ret := E_RLOAD_SPACE_CALL_TYPE_DIRECTION_Z;
         when NCM_T                  => ret := E_RLOAD_SPACE_CALL_TYPE_NCM_T;
         when CM_T                   => ret := E_RLOAD_SPACE_CALL_TYPE_CM_T;
         when TMIN                   => ret := E_RLOAD_SPACE_CALL_TYPE_TMIN;
         when CD_T                   => ret := E_RLOAD_SPACE_CALL_TYPE_CD_T;
         when ACCELERATION_STRUCTURE => ret := E_RLOAD_SPACE_CALL_TYPE_ACCELERATION_STRUCTURE;
         when U                      => ret := E_RLOAD_SPACE_CALL_TYPE_U;
         when others                 => ret := E_RLOAD_SPACE_CALL_TYPE_V;
      end case;
      return ret;
   end function;
   -- conversion function for e_rload_space_call_type enumerator
   function to_t_e_rload_space_call_type(i : std_logic_vector(4 downto 0)) return t_e_rload_space_call_type is
      variable ret : t_e_rload_space_call_type;
   begin
      case i is
         when E_RLOAD_SPACE_CALL_TYPE_PAYLOAD_DWORD_0        => ret := PAYLOAD_DWORD_0;
         when E_RLOAD_SPACE_CALL_TYPE_PAYLOAD_DWORD_1        => ret := PAYLOAD_DWORD_1;
         when E_RLOAD_SPACE_CALL_TYPE_PAYLOAD_DWORD_2        => ret := PAYLOAD_DWORD_2;
         when E_RLOAD_SPACE_CALL_TYPE_DWORD3                 => ret := DWORD3;
         when E_RLOAD_SPACE_CALL_TYPE_ORIGIN_X               => ret := ORIGIN_X;
         when E_RLOAD_SPACE_CALL_TYPE_ORIGIN_Y               => ret := ORIGIN_Y;
         when E_RLOAD_SPACE_CALL_TYPE_ORIGIN_Z               => ret := ORIGIN_Z;
         when E_RLOAD_SPACE_CALL_TYPE_DIRECTION_X            => ret := DIRECTION_X;
         when E_RLOAD_SPACE_CALL_TYPE_DIRECTION_Y            => ret := DIRECTION_Y;
         when E_RLOAD_SPACE_CALL_TYPE_DIRECTION_Z            => ret := DIRECTION_Z;
         when E_RLOAD_SPACE_CALL_TYPE_NCM_T                  => ret := NCM_T;
         when E_RLOAD_SPACE_CALL_TYPE_CM_T                   => ret := CM_T;
         when E_RLOAD_SPACE_CALL_TYPE_TMIN                   => ret := TMIN;
         when E_RLOAD_SPACE_CALL_TYPE_CD_T                   => ret := CD_T;
         when E_RLOAD_SPACE_CALL_TYPE_ACCELERATION_STRUCTURE => ret := ACCELERATION_STRUCTURE;
         when E_RLOAD_SPACE_CALL_TYPE_U                      => ret := U;
         when others                                         => ret := V;
      end case;
      return ret;
   end function;

   -- conversion function for e_rload_space_debug_type enumerator
   function to_slv(i : t_e_rload_space_debug_type ) return std_logic_vector is
      variable ret : std_logic_vector(3 downto 0);
   begin
      case i is
         when NCM_T               => ret := E_RLOAD_SPACE_DEBUG_TYPE_NCM_T;
         when DWORD1              => ret := E_RLOAD_SPACE_DEBUG_TYPE_DWORD1;
         when DWORD2              => ret := E_RLOAD_SPACE_DEBUG_TYPE_DWORD2;
         when DWORD3              => ret := E_RLOAD_SPACE_DEBUG_TYPE_DWORD3;
         when NCM_INSTANCE_INDEX  => ret := E_RLOAD_SPACE_DEBUG_TYPE_NCM_INSTANCE_INDEX;
         when NCM_PRIMITIVE_INDEX => ret := E_RLOAD_SPACE_DEBUG_TYPE_NCM_PRIMITIVE_INDEX;
         when NCM_GEOMETRY_INDEX  => ret := E_RLOAD_SPACE_DEBUG_TYPE_NCM_GEOMETRY_INDEX;
         when MISS_INDEX          => ret := E_RLOAD_SPACE_DEBUG_TYPE_MISS_INDEX;
         when SBT_OFFSET          => ret := E_RLOAD_SPACE_DEBUG_TYPE_SBT_OFFSET;
         when SBT_STRIDE          => ret := E_RLOAD_SPACE_DEBUG_TYPE_SBT_STRIDE;
         when DWORD10             => ret := E_RLOAD_SPACE_DEBUG_TYPE_DWORD10;
         when others              => ret := E_RLOAD_SPACE_DEBUG_TYPE_DWORD11;
      end case;
      return ret;
   end function;
   -- conversion function for e_rload_space_debug_type enumerator
   function to_t_e_rload_space_debug_type(i : std_logic_vector(3 downto 0)) return t_e_rload_space_debug_type is
      variable ret : t_e_rload_space_debug_type;
   begin
      case i is
         when E_RLOAD_SPACE_DEBUG_TYPE_NCM_T               => ret := NCM_T;
         when E_RLOAD_SPACE_DEBUG_TYPE_DWORD1              => ret := DWORD1;
         when E_RLOAD_SPACE_DEBUG_TYPE_DWORD2              => ret := DWORD2;
         when E_RLOAD_SPACE_DEBUG_TYPE_DWORD3              => ret := DWORD3;
         when E_RLOAD_SPACE_DEBUG_TYPE_NCM_INSTANCE_INDEX  => ret := NCM_INSTANCE_INDEX;
         when E_RLOAD_SPACE_DEBUG_TYPE_NCM_PRIMITIVE_INDEX => ret := NCM_PRIMITIVE_INDEX;
         when E_RLOAD_SPACE_DEBUG_TYPE_NCM_GEOMETRY_INDEX  => ret := NCM_GEOMETRY_INDEX;
         when E_RLOAD_SPACE_DEBUG_TYPE_MISS_INDEX          => ret := MISS_INDEX;
         when E_RLOAD_SPACE_DEBUG_TYPE_SBT_OFFSET          => ret := SBT_OFFSET;
         when E_RLOAD_SPACE_DEBUG_TYPE_SBT_STRIDE          => ret := SBT_STRIDE;
         when E_RLOAD_SPACE_DEBUG_TYPE_DWORD10             => ret := DWORD10;
         when others                                       => ret := DWORD11;
      end case;
      return ret;
   end function;

   -- conversion function for e_sbt_sel_type enumerator
   function to_slv(i : t_e_sbt_sel_type ) return std_logic_vector is
      variable ret : std_logic_vector(1 downto 0);
   begin
      case i is
         when HIT  => ret := E_SBT_SEL_TYPE_HIT;
         when MISS => ret := E_SBT_SEL_TYPE_MISS;
         when CALL => ret := E_SBT_SEL_TYPE_CALL;
         when others => ret := E_SBT_SEL_TYPE_NONE;
      end case;
      return ret;
   end function;
   -- conversion function for e_sbt_sel_type enumerator
   function to_t_e_sbt_sel_type(i : std_logic_vector(1 downto 0)) return t_e_sbt_sel_type is
      variable ret : t_e_sbt_sel_type;
   begin
      case i is
         when E_SBT_SEL_TYPE_HIT  => ret := HIT;
         when E_SBT_SEL_TYPE_MISS => ret := MISS;
         when E_SBT_SEL_TYPE_CALL => ret := CALL;
         when others              => ret := NONE;
      end case;
      return ret;
   end function;

   -- conversion function for e_hg_sel_type enumerator
   function to_slv(i : t_e_hg_sel_type ) return std_logic_vector is
      variable ret : std_logic_vector(0 downto 0);
   begin
      case i is
         when TRAVERSE    => ret := E_HG_SEL_TYPE_TRAVERSE;
         when others      => ret := E_HG_SEL_TYPE_CLOSEST_HIT;
      end case;
      return ret;
   end function;
   -- conversion function for e_hg_sel_type enumerator
   function to_t_e_hg_sel_type(i : std_logic_vector(0 downto 0)) return t_e_hg_sel_type is
      variable ret : t_e_hg_sel_type;
   begin
      case i is
         when E_HG_SEL_TYPE_TRAVERSE    => ret := TRAVERSE;
         when others                    => ret := CLOSEST_HIT;
      end case;
      return ret;
   end function;

   -- conversion function for e_ray_prog_sel_type enumerator
   function to_slv(i : t_e_ray_prog_sel_type ) return std_logic_vector is
      variable ret : std_logic_vector(1 downto 0);
   begin
      case i is
         when PROG_NULL     => ret := E_RAY_PROG_SEL_TYPE_PROG_NULL;
         when PROG_0        => ret := E_RAY_PROG_SEL_TYPE_PROG_0;
         when PROG_1        => ret := E_RAY_PROG_SEL_TYPE_PROG_1;
         when others        => ret := E_RAY_PROG_SEL_TYPE_PROG_RESERVED;
      end case;
      return ret;
   end function;
   -- conversion function for e_ray_prog_sel_type enumerator
   function to_t_e_ray_prog_sel_type(i : std_logic_vector(1 downto 0)) return t_e_ray_prog_sel_type is
      variable ret : t_e_ray_prog_sel_type;
   begin
      case i is
         when E_RAY_PROG_SEL_TYPE_PROG_NULL     => ret := PROG_NULL;
         when E_RAY_PROG_SEL_TYPE_PROG_0        => ret := PROG_0;
         when E_RAY_PROG_SEL_TYPE_PROG_1        => ret := PROG_1;
         when others                            => ret := PROG_RESERVED;
      end case;
      return ret;
   end function;

   -- conversion function for e_hier_node_type enumerator
   function to_slv(i : t_e_hier_node_type ) return std_logic_vector is
      variable ret : std_logic_vector(1 downto 0);
   begin
      case i is
         when BOX_BLOCK        => ret := E_HIER_NODE_TYPE_BOX_BLOCK;
         when VERTEX_BLOCK     => ret := E_HIER_NODE_TYPE_VERTEX_BLOCK;
         when PROCEDURAL_BLOCK => ret := E_HIER_NODE_TYPE_PROCEDURAL_BLOCK;
         when others           => ret := E_HIER_NODE_TYPE_INSTANCE_BLOCK;
      end case;
      return ret;
   end function;
   -- conversion function for e_hier_node_type enumerator
   function to_t_e_hier_node_type(i : std_logic_vector(1 downto 0)) return t_e_hier_node_type is
      variable ret : t_e_hier_node_type;
   begin
      case i is
         when E_HIER_NODE_TYPE_BOX_BLOCK        => ret := BOX_BLOCK;
         when E_HIER_NODE_TYPE_VERTEX_BLOCK     => ret := VERTEX_BLOCK;
         when E_HIER_NODE_TYPE_PROCEDURAL_BLOCK => ret := PROCEDURAL_BLOCK;
         when others                            => ret := INSTANCE_BLOCK;
      end case;
      return ret;
   end function;

   -- conversion function for e_leaf_node_type enumerator
   function to_slv(i : t_e_leaf_node_type ) return std_logic_vector is
      variable ret : std_logic_vector(1 downto 0);
   begin
      case i is
         when TREE_BOX            => ret := E_LEAF_NODE_TYPE_TREE_BOX;
         when TRI_LEAF_BOX        => ret := E_LEAF_NODE_TYPE_TRI_LEAF_BOX;
         when PROCEDURAL_LEAF_BOX => ret := E_LEAF_NODE_TYPE_PROCEDURAL_LEAF_BOX;
         when others              => ret := E_LEAF_NODE_TYPE_INSTANCE_LEAF_BOX;
      end case;
      return ret;
   end function;
   -- conversion function for e_leaf_node_type enumerator
   function to_t_e_leaf_node_type(i : std_logic_vector(1 downto 0)) return t_e_leaf_node_type is
      variable ret : t_e_leaf_node_type;
   begin
      case i is
         when E_LEAF_NODE_TYPE_TREE_BOX            => ret := TREE_BOX;
         when E_LEAF_NODE_TYPE_TRI_LEAF_BOX        => ret := TRI_LEAF_BOX;
         when E_LEAF_NODE_TYPE_PROCEDURAL_LEAF_BOX => ret := PROCEDURAL_LEAF_BOX;
         when others                               => ret := INSTANCE_LEAF_BOX;
      end case;
      return ret;
   end function;

   -- conversion function for e_serial_flag_type enumerator
   function to_slv(i : t_e_serial_flag_type ) return std_logic_vector is
      variable ret : std_logic_vector(0 downto 0);
   begin
      case i is
         when NORMAL_RAY => ret := E_SERIAL_FLAG_TYPE_NORMAL_RAY;
         when others     => ret := E_SERIAL_FLAG_TYPE_SERIAL_RAY;
      end case;
      return ret;
   end function;
   -- conversion function for e_serial_flag_type enumerator
   function to_t_e_serial_flag_type(i : std_logic_vector(0 downto 0)) return t_e_serial_flag_type is
      variable ret : t_e_serial_flag_type;
   begin
      case i is
         when E_SERIAL_FLAG_TYPE_NORMAL_RAY => ret := NORMAL_RAY;
         when others                        => ret := SERIAL_RAY;
      end case;
      return ret;
   end function;

   -- conversion function for e_hier_dm_type enumerator
   function to_slv(i : t_e_hier_dm_type ) return std_logic_vector is
      variable ret : std_logic_vector(1 downto 0);
   begin
      case i is
         when HIER_GEOM    => ret := E_HIER_DM_TYPE_HIER_GEOM;
         when HIER_FRAG    => ret := E_HIER_DM_TYPE_HIER_FRAG;
         when HIER_COMPUTE => ret := E_HIER_DM_TYPE_HIER_COMPUTE;
         when others       => ret := E_HIER_DM_TYPE_HIER_RAY;
      end case;
      return ret;
   end function;
   -- conversion function for e_hier_dm_type enumerator
   function to_t_e_hier_dm_type(i : std_logic_vector(1 downto 0)) return t_e_hier_dm_type is
      variable ret : t_e_hier_dm_type;
   begin
      case i is
         when E_HIER_DM_TYPE_HIER_GEOM    => ret := HIER_GEOM;
         when E_HIER_DM_TYPE_HIER_FRAG    => ret := HIER_FRAG;
         when E_HIER_DM_TYPE_HIER_COMPUTE => ret := HIER_COMPUTE;
         when others                      => ret := HIER_RAY;
      end case;
      return ret;
   end function;

   -- conversion function for e_dm_type enumerator
   function to_slv(i : t_e_dm_type ) return std_logic_vector is
      variable ret : std_logic_vector(1 downto 0);
   begin
      case i is
         when GEOM    => ret := E_DM_TYPE_GEOM;
         when FRAG    => ret := E_DM_TYPE_FRAG;
         when COMPUTE => ret := E_DM_TYPE_COMPUTE;
         when others  => ret := E_DM_TYPE_RAY;
      end case;
      return ret;
   end function;
   -- conversion function for e_dm_type enumerator
   function to_t_e_dm_type(i : std_logic_vector(1 downto 0)) return t_e_dm_type is
      variable ret : t_e_dm_type;
   begin
      case i is
         when E_DM_TYPE_GEOM    => ret := GEOM;
         when E_DM_TYPE_FRAG    => ret := FRAG;
         when E_DM_TYPE_COMPUTE => ret := COMPUTE;
         when others            => ret := RAY;
      end case;
      return ret;
   end function;

   -- conversion function for e_rce_rts_cmd enumerator
   function to_slv(i : t_e_rce_rts_cmd ) return std_logic_vector is
      variable ret : std_logic_vector(2 downto 0);
   begin
      case i is
         when SHADER_BINDING_TABLE    => ret := E_RCE_RTS_CMD_SHADER_BINDING_TABLE;
         when UNIFORM_DESCRIPTOR_BASE => ret := E_RCE_RTS_CMD_UNIFORM_DESCRIPTOR_BASE;
         when LAUNCH_SIZE             => ret := E_RCE_RTS_CMD_LAUNCH_SIZE;
         when RAYGEN                  => ret := E_RCE_RTS_CMD_RAYGEN;
         when LIMIT                   => ret := E_RCE_RTS_CMD_LIMIT;
         when others                  => ret := E_RCE_RTS_CMD_FENCE;
      end case;
      return ret;
   end function;
   -- conversion function for e_rce_rts_cmd enumerator
   function to_t_e_rce_rts_cmd(i : std_logic_vector(2 downto 0)) return t_e_rce_rts_cmd is
      variable ret : t_e_rce_rts_cmd;
   begin
      case i is
         when E_RCE_RTS_CMD_SHADER_BINDING_TABLE    => ret := SHADER_BINDING_TABLE;
         when E_RCE_RTS_CMD_UNIFORM_DESCRIPTOR_BASE => ret := UNIFORM_DESCRIPTOR_BASE;
         when E_RCE_RTS_CMD_LAUNCH_SIZE             => ret := LAUNCH_SIZE;
         when E_RCE_RTS_CMD_RAYGEN                  => ret := RAYGEN;
         when E_RCE_RTS_CMD_LIMIT                   => ret := LIMIT;
         when others                                => ret := FENCE;
      end case;
      return ret;
   end function;

   -- conversion function for e_box_prim_type enumerator
   function to_slv(i : t_e_box_prim_type ) return std_logic_vector is
      variable ret : std_logic_vector(0 downto 0);
   begin
      case i is
         when BOX  => ret := E_BOX_PRIM_TYPE_BOX;
         when others => ret := E_BOX_PRIM_TYPE_PRIM;
      end case;
      return ret;
   end function;
   -- conversion function for e_box_prim_type enumerator
   function to_t_e_box_prim_type(i : std_logic_vector(0 downto 0)) return t_e_box_prim_type is
      variable ret : t_e_box_prim_type;
   begin
      case i is
         when E_BOX_PRIM_TYPE_BOX  => ret := BOX;
         when others               => ret := PRIM;
      end case;
      return ret;
   end function;

   -- conversion function for e_prim_type enumerator
   function to_slv(i : t_e_prim_type ) return std_logic_vector is
      variable ret : std_logic_vector(0 downto 0);
   begin
      case i is
         when TRIANGLE        => ret := E_PRIM_TYPE_TRIANGLE;
         when others          => ret := E_PRIM_TYPE_PROCEDURAL_AABB;
      end case;
      return ret;
   end function;
   -- conversion function for e_prim_type enumerator
   function to_t_e_prim_type(i : std_logic_vector(0 downto 0)) return t_e_prim_type is
      variable ret : t_e_prim_type;
   begin
      case i is
         when E_PRIM_TYPE_TRIANGLE        => ret := TRIANGLE;
         when others                      => ret := PROCEDURAL_AABB;
      end case;
      return ret;
   end function;

   -- conversion function for e_data_type enumerator
   function to_slv(i : t_e_data_type ) return std_logic_vector is
      variable ret : std_logic_vector(0 downto 0);
   begin
      case i is
         when BLOCK_DATA    => ret := E_DATA_TYPE_BLOCK_DATA;
         when others        => ret := E_DATA_TYPE_INSTANCE_DATA;
      end case;
      return ret;
   end function;
   -- conversion function for e_data_type enumerator
   function to_t_e_data_type(i : std_logic_vector(0 downto 0)) return t_e_data_type is
      variable ret : t_e_data_type;
   begin
      case i is
         when E_DATA_TYPE_BLOCK_DATA    => ret := BLOCK_DATA;
         when others                    => ret := INSTANCE_DATA;
      end case;
      return ret;
   end function;

   -- conversion function for e_bytes_select_type enumerator
   function to_slv(i : t_e_bytes_select_type ) return std_logic_vector is
      variable ret : std_logic_vector(1 downto 0);
   begin
      case i is
         when MID_BYTES => ret := E_BYTES_SELECT_TYPE_MID_BYTES;
         when BOT_BYTES => ret := E_BYTES_SELECT_TYPE_BOT_BYTES;
         when TOP_BYTES => ret := E_BYTES_SELECT_TYPE_TOP_BYTES;
         when others    => ret := E_BYTES_SELECT_TYPE_ALL_BYTES;
      end case;
      return ret;
   end function;
   -- conversion function for e_bytes_select_type enumerator
   function to_t_e_bytes_select_type(i : std_logic_vector(1 downto 0)) return t_e_bytes_select_type is
      variable ret : t_e_bytes_select_type;
   begin
      case i is
         when E_BYTES_SELECT_TYPE_MID_BYTES => ret := MID_BYTES;
         when E_BYTES_SELECT_TYPE_BOT_BYTES => ret := BOT_BYTES;
         when E_BYTES_SELECT_TYPE_TOP_BYTES => ret := TOP_BYTES;
         when others                        => ret := ALL_BYTES;
      end case;
      return ret;
   end function;

   -- conversion function for e_block_node_type enumerator
   function to_slv(i : t_e_block_node_type ) return std_logic_vector is
      variable ret : std_logic_vector(2 downto 0);
   begin
      case i is
         when INVALID_BLOCK              => ret := E_BLOCK_NODE_TYPE_INVALID_BLOCK;
         when TLAS_ROOT_BLOCK            => ret := E_BLOCK_NODE_TYPE_TLAS_ROOT_BLOCK;
         when TRIANGLE_BLAS_ROOT_BLOCK   => ret := E_BLOCK_NODE_TYPE_TRIANGLE_BLAS_ROOT_BLOCK;
         when PROCEDURAL_BLAS_ROOT_BLOCK => ret := E_BLOCK_NODE_TYPE_PROCEDURAL_BLAS_ROOT_BLOCK;
         when BOX_FORMAT_BLOCK           => ret := E_BLOCK_NODE_TYPE_BOX_FORMAT_BLOCK;
         when VERTEX_FORMAT_BLOCK        => ret := E_BLOCK_NODE_TYPE_VERTEX_FORMAT_BLOCK;
         when PROCEDURAL_FORMAT_BLOCK    => ret := E_BLOCK_NODE_TYPE_PROCEDURAL_FORMAT_BLOCK;
         when others                     => ret := E_BLOCK_NODE_TYPE_INSTANCE_FORMAT_BLOCK;
      end case;
      return ret;
   end function;
   -- conversion function for e_block_node_type enumerator
   function to_t_e_block_node_type(i : std_logic_vector(2 downto 0)) return t_e_block_node_type is
      variable ret : t_e_block_node_type;
   begin
      case i is
         when E_BLOCK_NODE_TYPE_INVALID_BLOCK              => ret := INVALID_BLOCK;
         when E_BLOCK_NODE_TYPE_TLAS_ROOT_BLOCK            => ret := TLAS_ROOT_BLOCK;
         when E_BLOCK_NODE_TYPE_TRIANGLE_BLAS_ROOT_BLOCK   => ret := TRIANGLE_BLAS_ROOT_BLOCK;
         when E_BLOCK_NODE_TYPE_PROCEDURAL_BLAS_ROOT_BLOCK => ret := PROCEDURAL_BLAS_ROOT_BLOCK;
         when E_BLOCK_NODE_TYPE_BOX_FORMAT_BLOCK           => ret := BOX_FORMAT_BLOCK;
         when E_BLOCK_NODE_TYPE_VERTEX_FORMAT_BLOCK        => ret := VERTEX_FORMAT_BLOCK;
         when E_BLOCK_NODE_TYPE_PROCEDURAL_FORMAT_BLOCK    => ret := PROCEDURAL_FORMAT_BLOCK;
         when others                                       => ret := INSTANCE_FORMAT_BLOCK;
      end case;
      return ret;
   end function;

   -- conversion function for e_octant_encoding_type enumerator
   function to_slv(i : t_e_octant_encoding_type ) return std_logic_vector is
      variable ret : std_logic_vector(2 downto 0);
   begin
      case i is
         when OC_PPP => ret := E_OCTANT_ENCODING_TYPE_OC_PPP;
         when OC_PPN => ret := E_OCTANT_ENCODING_TYPE_OC_PPN;
         when OC_PNP => ret := E_OCTANT_ENCODING_TYPE_OC_PNP;
         when OC_PNN => ret := E_OCTANT_ENCODING_TYPE_OC_PNN;
         when OC_NPP => ret := E_OCTANT_ENCODING_TYPE_OC_NPP;
         when OC_NPN => ret := E_OCTANT_ENCODING_TYPE_OC_NPN;
         when OC_NNP => ret := E_OCTANT_ENCODING_TYPE_OC_NNP;
         when others => ret := E_OCTANT_ENCODING_TYPE_OC_NNN;
      end case;
      return ret;
   end function;
   -- conversion function for e_octant_encoding_type enumerator
   function to_t_e_octant_encoding_type(i : std_logic_vector(2 downto 0)) return t_e_octant_encoding_type is
      variable ret : t_e_octant_encoding_type;
   begin
      case i is
         when E_OCTANT_ENCODING_TYPE_OC_PPP => ret := OC_PPP;
         when E_OCTANT_ENCODING_TYPE_OC_PPN => ret := OC_PPN;
         when E_OCTANT_ENCODING_TYPE_OC_PNP => ret := OC_PNP;
         when E_OCTANT_ENCODING_TYPE_OC_PNN => ret := OC_PNN;
         when E_OCTANT_ENCODING_TYPE_OC_NPP => ret := OC_NPP;
         when E_OCTANT_ENCODING_TYPE_OC_NPN => ret := OC_NPN;
         when E_OCTANT_ENCODING_TYPE_OC_NNP => ret := OC_NNP;
         when others                        => ret := OC_NNN;
      end case;
      return ret;
   end function;

   -- conversion function for e_set_id_type enumerator
   function to_slv(i : t_e_set_id_type ) return std_logic_vector is
      variable ret : std_logic_vector(1 downto 0);
   begin
      case i is
         when SET_ID_COMMITTED    => ret := E_SET_ID_TYPE_SET_ID_COMMITTED;
         when SET_ID_CANDIDATE    => ret := E_SET_ID_TYPE_SET_ID_CANDIDATE;
         when others              => ret := E_SET_ID_TYPE_SET_ID_NONCOMMITTED;
      end case;
      return ret;
   end function;
   -- conversion function for e_set_id_type enumerator
   function to_t_e_set_id_type(i : std_logic_vector(1 downto 0)) return t_e_set_id_type is
      variable ret : t_e_set_id_type;
   begin
      case i is
         when E_SET_ID_TYPE_SET_ID_COMMITTED    => ret := SET_ID_COMMITTED;
         when E_SET_ID_TYPE_SET_ID_CANDIDATE    => ret := SET_ID_CANDIDATE;
         when others                            => ret := SET_ID_NONCOMMITTED;
      end case;
      return ret;
   end function;

end package body pkg_rt;
