/*

 * #==========================================================================#
 * |                                                                          |
 * |  Copyright (c) 2022, Fantasy Technologies Limited and/or its         |
 * |  affiliated group companies ("Fantasy"). All rights reserved.        |
 * |  No part of this content, either material or conceptual may be copied    |
 * |  or distributed, transmitted, transcribed, stored in a retrieval system  |
 * |  or translated into any human or computer language in any form by any    |
 * |  means, electronic, mechanical manual, or otherwise, or disclosed to     |
 * |  third parties without the express written permission of Fantasy.    |
 * |                                                                          |
 * #==========================================================================#

 */


package pkg_crm_;




   localparam int                 JONES_COMPUTE_DMN                                  = 2;
   localparam int                 JONES_VERTEX_DMN                                   = 2;
   localparam int                 JONES_PIXEL_DMN                                    = 1;
   localparam int                 JONES_SYS_DMN                                      = 2;
   localparam int                 JONES_BIF_DMN                                      = 1;
   localparam int                 JONES_TDM_DMN                                      = 1;
   localparam int                 JONES_PM_DMN                                       = 1;
   localparam int                 JONES_RCE_DMN                                      = 1;
   localparam int                 JONES_ASC_DMN                                      = 1;
   localparam int                 FBCDC_FBCACHE_DMN                                  = 2;
   localparam int                 FBCDC_FBC_DMN                                      = 2;
   localparam int                 FBCDC_FBDC_DMN                                     = 2;
   localparam int                 FBCDC_FBM_DMN                                      = 3;
   localparam int                 TEXAS_BIF_DMN                                      = 2;
   localparam int                 TEXAS_MCU_L1_DMN                                   = 1;
   localparam int                 TEXAS_PDS_DMN                                      = 2;
   localparam int                 TEXAS_PBE_DMN                                      = 1;
   localparam int                 TEXAS_CPC_PIPE_DMN                                 = 1;
   localparam int                 MERCER_CU_DMN                                     = 40;
   localparam int                 MERCER_CU_PIPES_SMP_IDX                           = 0;
   localparam int                 MERCER_CU_PIPES_DMA_IDX                           = 1;
   localparam int                 MERCER_CU_PIPES_EMI_IDX                           = 2;
   localparam int                 MERCER_CU_PIPES_ITR_IDX                           = 3;
   localparam int                 MERCER_CU_PIPES_CPX_IDX                           = 4;
   localparam int                 MERCER_CU_PIPES_MOV_IDX                           = 5;
   localparam int                 MERCER_CU_PIPES_EMIPSB_IDX                        = 6;
   localparam int                 MERCER_CU_PIPES_TPX_IDX                           = 7;
   localparam int                 MERCER_CU_PIPES_PAP_CMN_IDX                       = 8;
   localparam int                 MERCER_CU_PIPES_PAP_FOP_IDX                       = 9;
   localparam int                 MERCER_CU_PIPES_PAP_DOT_IDX                       = 10;
   localparam int                 MERCER_CU_PIPES_SAP_IDX                           = 11;
   localparam int                 MERCER_CU_PIPES_AP_IDX                            = 12;
   localparam int                 MERCER_CU_PIPES_TENSOR_IDX                        = 13;
   localparam int                 MERCER_CU_PIPES_TMA_IDX                           = 14;
   localparam int                 MERCER_CU_PIPES_DMN                               = 15;
   localparam int                 MERCER_ISP_DMN                                     = 1;
   localparam int                 MERCER_MCU_L0_DMN                                  = 2;
   localparam int                 TEXAS_GEOM_SHARED_DMN                              = 3;
   localparam int                 TEXAS_GEOM_TESS_DMN                                = 2;
   localparam int                 TEXAS_GEOM_VERTEX_DMN                              = 7;
   localparam int                 TEXAS_RAST_IPF_CLK_DMN                             = 2;
   localparam int                 TEXAS_RAST_TPF_CLK_DMN                             = 2;
   localparam int                 SWIFT_TCU_DMN                                      = 2;
   localparam int                 SWIFT_CUL2CACHE_DMN                               = 1;
   localparam int                 SWIFT_TPU_DMN                                      = 3;
   localparam int                 SWIFT_YUV_DMN                                      = 1;
   localparam int                 SWIFT_FP_DMN                                       = 1;
   localparam int                 SWIFT_INT_DMN                                      = 1;
   localparam int                 SWIFT_ASTC_DMN                                     = 1;
   localparam int                 SWIFT_TF_DMN                                       = 1;
   localparam int                 SWIFT_TAG_DMN                                      = 1;
   localparam int                 SWIFT_MADD_DMN                                     = 1;
   localparam int                 TIW                                                = 1;
   localparam int                 TOW                                                = 1;
   localparam int                 CRM_WAKEUP_TO_CLKEN_CLK_DELAY                      = 1;
   localparam int                 RAC_RTS_DMN                                        = 1;
   localparam int                 RAC_PCG_DMN                                        = 1;
   localparam int                 RAC_BPS_DMN                                        = 1;
   localparam int                 RAC_RS_DMN                                         = 1;
   localparam int                 RAC_RRC_DMN                                        = 1;
   localparam int                 RAC_URI_DMN                                        = 1;







endpackage
