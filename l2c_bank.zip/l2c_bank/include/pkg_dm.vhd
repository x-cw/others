library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
library work;

package pkg_dm is

   constant DATAMASTER_BITS                 : natural                                       := 3;
   constant NUM_DATAMASTERS                 : natural                                       := 6;
   constant CPC0                            : natural                                       := 0;
   constant CPC1                            : natural                                       := 1;
   constant CPC2                            : natural                                       := 2;
   constant CPC3                            : natural                                       := 3;
   constant SLV_CPC0                        : std_logic_vector(DATAMASTER_BITS-1 downto 0)  := B"000";
   constant SLV_CPC1                        : std_logic_vector(DATAMASTER_BITS-1 downto 0)  := B"001";
   constant SLV_CPC2                        : std_logic_vector(DATAMASTER_BITS-1 downto 0)  := B"010";
   constant SLV_CPC3                        : std_logic_vector(DATAMASTER_BITS-1 downto 0)  := B"011";

-- Keep old constant to solve lint error
   constant VTXDM                           : natural                                       := 0;
   constant PXLDM                           : natural                                       := 1;
   constant CMPDM                           : natural                                       := 2;
   constant RAYDM                           : natural                                       := 3;
   constant TESSDM                          : natural                                       := 4;
   constant FSTRDM                          : natural                                       := 5;
   constant SLV_VTXDM                       : std_logic_vector(2 downto 0)                  := B"000";
   constant SLV_PXLDM                       : std_logic_vector(2 downto 0)                  := B"001";
   constant SLV_CMPDM                       : std_logic_vector(2 downto 0)                  := B"010";
   constant SLV_RAYDM                       : std_logic_vector(2 downto 0)                  := B"011";
   constant SLV_TESSDM                      : std_logic_vector(2 downto 0)                  := B"100";
   constant SLV_FSTRDM                      : std_logic_vector(2 downto 0)                  := B"101";

   ----------------------------------------------------------------------------------------------------------------------------------
   --   Enumerators, Not used in RTL
   ----------------------------------------------------------------------------------------------------------------------------------
--   attribute enum_encoding : string;
--
--   type t_e_data_master is (
--      VERTEX    , -- 000
--      PIXEL     , -- 001
--      COMPUTE   , -- 010
--      RAY       , -- 011
--      DOMAIN    , -- 100
--      FASTRENDER  -- 101
--   );
--   attribute enum_encoding of t_e_data_master : type is "000 001 010 011 100 101";
--   constant E_DATA_MASTER_VERTEX     : std_logic_vector(2 downto 0) := "000";
--   constant E_DATA_MASTER_PIXEL      : std_logic_vector(2 downto 0) := "001";
--   constant E_DATA_MASTER_COMPUTE    : std_logic_vector(2 downto 0) := "010";
--   constant E_DATA_MASTER_RAY        : std_logic_vector(2 downto 0) := "011";
--   constant E_DATA_MASTER_DOMAIN     : std_logic_vector(2 downto 0) := "100";
--   constant E_DATA_MASTER_FASTRENDER : std_logic_vector(2 downto 0) := "101";
--
--   function to_slv(i : t_e_data_master ) return std_logic_vector;
--   function to_t_e_data_master(i : std_logic_vector(2 downto 0)) return t_e_data_master;
end package pkg_dm;

package body pkg_dm is

--   -- conversion function for e_data_master enumerator
--   function to_slv(i : t_e_data_master ) return std_logic_vector is
--      variable ret : std_logic_vector(2 downto 0);
--   begin
--      case i is
--         when VERTEX     => ret := E_DATA_MASTER_VERTEX;
--         when PIXEL      => ret := E_DATA_MASTER_PIXEL;
--         when COMPUTE    => ret := E_DATA_MASTER_COMPUTE;
--         when RAY        => ret := E_DATA_MASTER_RAY;
--         when DOMAIN     => ret := E_DATA_MASTER_DOMAIN;
--         when others     => ret := E_DATA_MASTER_FASTRENDER;
--      end case;
--      return ret;
--   end function;
--   -- conversion function for e_data_master enumerator
--   function to_t_e_data_master(i : std_logic_vector(2 downto 0)) return t_e_data_master is
--      variable ret : t_e_data_master;
--   begin
--      case i is
--         when E_DATA_MASTER_VERTEX     => ret := VERTEX;
--         when E_DATA_MASTER_PIXEL      => ret := PIXEL;
--         when E_DATA_MASTER_COMPUTE    => ret := COMPUTE;
--         when E_DATA_MASTER_RAY        => ret := RAY;
--         when E_DATA_MASTER_DOMAIN     => ret := DOMAIN;
--         when others                   => ret := FASTRENDER;
--      end case;
--      return ret;
--   end function;


end package body pkg_dm;
