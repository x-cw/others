//parameter N=64;

//parameter M_N = 5;
parameter NUM_WIDTH = 8;

parameter M_TMP_0  = 0;
parameter M_TMP_1   = M_TMP_0   + W[0  ];
parameter M_TMP_2   = M_TMP_1   + W[1  ];
parameter M_TMP_3   = M_TMP_2   + W[2  ];
parameter M_TMP_4   = M_TMP_3   + W[3  ];
parameter M_TMP_5   = M_TMP_4   + W[4  ];
parameter M_TMP_6   = M_TMP_5   + W[5  ];
parameter M_TMP_7   = M_TMP_6   + W[6  ];
parameter M_TMP_8   = M_TMP_7   + W[7  ];
parameter M_TMP_9   = M_TMP_8   + W[8  ];
parameter M_TMP_10  = M_TMP_9   + W[9  ];
parameter M_TMP_11  = M_TMP_10  + W[10 ];
parameter M_TMP_12  = M_TMP_11  + W[11 ];
parameter M_TMP_13  = M_TMP_12  + W[12 ];
parameter M_TMP_14  = M_TMP_13  + W[13 ];
parameter M_TMP_15  = M_TMP_14  + W[14 ];
parameter M_TMP_16  = M_TMP_15  + W[15 ];
parameter M_TMP_17  = M_TMP_16  + W[16 ];
parameter M_TMP_18  = M_TMP_17  + W[17 ];
parameter M_TMP_19  = M_TMP_18  + W[18 ];
parameter M_TMP_20  = M_TMP_19  + W[19 ];
parameter M_TMP_21  = M_TMP_20  + W[20 ];
parameter M_TMP_22  = M_TMP_21  + W[21 ];
parameter M_TMP_23  = M_TMP_22  + W[22 ];
parameter M_TMP_24  = M_TMP_23  + W[23 ];
parameter M_TMP_25  = M_TMP_24  + W[24 ];
parameter M_TMP_26  = M_TMP_25  + W[25 ];
parameter M_TMP_27  = M_TMP_26  + W[26 ];
parameter M_TMP_28  = M_TMP_27  + W[27 ];
parameter M_TMP_29  = M_TMP_28  + W[28 ];
parameter M_TMP_30  = M_TMP_29  + W[29 ];
parameter M_TMP_31  = M_TMP_30  + W[30 ];
parameter M_TMP_32  = M_TMP_31  + W[31 ];
parameter M_TMP_33  = M_TMP_32  + W[32 ];
parameter M_TMP_34  = M_TMP_33  + W[33 ];
parameter M_TMP_35  = M_TMP_34  + W[34 ];
parameter M_TMP_36  = M_TMP_35  + W[35 ];
parameter M_TMP_37  = M_TMP_36  + W[36 ];
parameter M_TMP_38  = M_TMP_37  + W[37 ];
parameter M_TMP_39  = M_TMP_38  + W[38 ];
parameter M_TMP_40  = M_TMP_39  + W[39 ];
parameter M_TMP_41  = M_TMP_40  + W[40 ];
parameter M_TMP_42  = M_TMP_41  + W[41 ];
parameter M_TMP_43  = M_TMP_42  + W[42 ];
parameter M_TMP_44  = M_TMP_43  + W[43 ];
parameter M_TMP_45  = M_TMP_44  + W[44 ];
parameter M_TMP_46  = M_TMP_45  + W[45 ];
parameter M_TMP_47  = M_TMP_46  + W[46 ];
parameter M_TMP_48  = M_TMP_47  + W[47 ];
parameter M_TMP_49  = M_TMP_48  + W[48 ];
parameter M_TMP_50  = M_TMP_49  + W[49 ];
parameter M_TMP_51  = M_TMP_50  + W[50 ];
parameter M_TMP_52  = M_TMP_51  + W[51 ];
parameter M_TMP_53  = M_TMP_52  + W[52 ];
parameter M_TMP_54  = M_TMP_53  + W[53 ];
parameter M_TMP_55  = M_TMP_54  + W[54 ];
parameter M_TMP_56  = M_TMP_55  + W[55 ];
parameter M_TMP_57  = M_TMP_56  + W[56 ];
parameter M_TMP_58  = M_TMP_57  + W[57 ];
parameter M_TMP_59  = M_TMP_58  + W[58 ];
parameter M_TMP_60  = M_TMP_59  + W[59 ];
parameter M_TMP_61  = M_TMP_60  + W[60 ];
parameter M_TMP_62  = M_TMP_61  + W[61 ];
parameter M_TMP_63  = M_TMP_62  + W[62 ];

parameter M_TMP_64   = M_TMP_63   + W[63  ];
parameter M_TMP_65   = M_TMP_64   + W[64  ];
parameter M_TMP_66   = M_TMP_65   + W[65  ];
parameter M_TMP_67   = M_TMP_66   + W[66  ];
parameter M_TMP_68   = M_TMP_67   + W[67  ];
parameter M_TMP_69   = M_TMP_68   + W[68  ];
parameter M_TMP_70   = M_TMP_69   + W[69  ];
parameter M_TMP_71   = M_TMP_70   + W[70  ];
parameter M_TMP_72   = M_TMP_71   + W[71  ];
parameter M_TMP_73   = M_TMP_72   + W[72  ];
parameter M_TMP_74   = M_TMP_73   + W[73  ];
parameter M_TMP_75   = M_TMP_74   + W[74  ];
parameter M_TMP_76   = M_TMP_75   + W[75  ];
parameter M_TMP_77   = M_TMP_76   + W[76  ];
parameter M_TMP_78   = M_TMP_77   + W[77  ];
parameter M_TMP_79   = M_TMP_78   + W[78  ];
parameter M_TMP_80   = M_TMP_79   + W[79  ];
parameter M_TMP_81   = M_TMP_80   + W[80  ];
parameter M_TMP_82   = M_TMP_81   + W[81  ];
parameter M_TMP_83   = M_TMP_82   + W[82  ];
parameter M_TMP_84   = M_TMP_83   + W[83  ];
parameter M_TMP_85   = M_TMP_84   + W[84  ];
parameter M_TMP_86   = M_TMP_85   + W[85  ];
parameter M_TMP_87   = M_TMP_86   + W[86  ];
parameter M_TMP_88   = M_TMP_87   + W[87  ];
parameter M_TMP_89   = M_TMP_88   + W[88  ];
parameter M_TMP_90   = M_TMP_89   + W[89  ];
parameter M_TMP_91   = M_TMP_90   + W[90  ];
parameter M_TMP_92   = M_TMP_91   + W[91  ];
parameter M_TMP_93   = M_TMP_92   + W[92  ];
parameter M_TMP_94   = M_TMP_93   + W[93  ];
parameter M_TMP_95   = M_TMP_94   + W[94  ];
parameter M_TMP_96   = M_TMP_95   + W[95  ];
parameter M_TMP_97   = M_TMP_96   + W[96  ];
parameter M_TMP_98   = M_TMP_97   + W[97  ];
parameter M_TMP_99   = M_TMP_98   + W[98  ];
parameter M_TMP_100  = M_TMP_99   + W[99  ];
parameter M_TMP_101  = M_TMP_100  + W[100 ];
parameter M_TMP_102  = M_TMP_101  + W[101 ];
parameter M_TMP_103  = M_TMP_102  + W[102 ];
parameter M_TMP_104  = M_TMP_103  + W[103 ];
parameter M_TMP_105  = M_TMP_104  + W[104 ];
parameter M_TMP_106  = M_TMP_105  + W[105 ];
parameter M_TMP_107  = M_TMP_106  + W[106 ];
parameter M_TMP_108  = M_TMP_107  + W[107 ];
parameter M_TMP_109  = M_TMP_108  + W[108 ];
parameter M_TMP_110  = M_TMP_109  + W[109 ];
parameter M_TMP_111  = M_TMP_110  + W[110 ];
parameter M_TMP_112  = M_TMP_111  + W[111 ];
parameter M_TMP_113  = M_TMP_112  + W[112 ];
parameter M_TMP_114  = M_TMP_113  + W[113 ];
parameter M_TMP_115  = M_TMP_114  + W[114 ];
parameter M_TMP_116  = M_TMP_115  + W[115 ];
parameter M_TMP_117  = M_TMP_116  + W[116 ];
parameter M_TMP_118  = M_TMP_117  + W[117 ];
parameter M_TMP_119  = M_TMP_118  + W[118 ];
parameter M_TMP_120  = M_TMP_119  + W[119 ];
parameter M_TMP_121  = M_TMP_120  + W[120 ];
parameter M_TMP_122  = M_TMP_121  + W[121 ];
parameter M_TMP_123  = M_TMP_122  + W[122 ];
parameter M_TMP_124  = M_TMP_123  + W[123 ];
parameter M_TMP_125  = M_TMP_124  + W[124 ];
parameter M_TMP_126  = M_TMP_125  + W[125 ];
parameter M_TMP_127  = M_TMP_126  + W[126 ];
//parameter M_TOTAL = M_TMP_63 +W[63];
parameter M_TOTAL = M_TMP_127 +W[127];

parameter int M_P[127:0] = {
M_TMP_127,
M_TMP_126,
M_TMP_125,
M_TMP_124,
M_TMP_123,
M_TMP_122,
M_TMP_121,
M_TMP_120,
M_TMP_119,
M_TMP_118,
M_TMP_117,
M_TMP_116,
M_TMP_115,
M_TMP_114,
M_TMP_113,
M_TMP_112,
M_TMP_111,
M_TMP_110,
M_TMP_109,
M_TMP_108,
M_TMP_107,
M_TMP_106,
M_TMP_105,
M_TMP_104,
M_TMP_103,
M_TMP_102,
M_TMP_101,
M_TMP_100,
M_TMP_99 ,
M_TMP_98 ,
M_TMP_97 ,
M_TMP_96 ,
M_TMP_95 ,
M_TMP_94 ,
M_TMP_93 ,
M_TMP_92 ,
M_TMP_91 ,
M_TMP_90 ,
M_TMP_89 ,
M_TMP_88 ,
M_TMP_87 ,
M_TMP_86 ,
M_TMP_85 ,
M_TMP_84 ,
M_TMP_83 ,
M_TMP_82 ,
M_TMP_81 ,
M_TMP_80 ,
M_TMP_79 ,
M_TMP_78 ,
M_TMP_77 ,
M_TMP_76 ,
M_TMP_75 ,
M_TMP_74 ,
M_TMP_73 ,
M_TMP_72 ,
M_TMP_71 ,
M_TMP_70 ,
M_TMP_69 ,
M_TMP_68 ,
M_TMP_67 ,
M_TMP_66 ,
M_TMP_65 ,
M_TMP_64 ,
M_TMP_63,
M_TMP_62,
M_TMP_61,
M_TMP_60,
M_TMP_59,
M_TMP_58,
M_TMP_57,
M_TMP_56,
M_TMP_55,
M_TMP_54,
M_TMP_53,
M_TMP_52,
M_TMP_51,
M_TMP_50,
M_TMP_49,
M_TMP_48,
M_TMP_47,
M_TMP_46,
M_TMP_45,
M_TMP_44,
M_TMP_43,
M_TMP_42,
M_TMP_41,
M_TMP_40,
M_TMP_39,
M_TMP_38,
M_TMP_37,
M_TMP_36,
M_TMP_35,
M_TMP_34,
M_TMP_33,
M_TMP_32,
M_TMP_31,
M_TMP_30,
M_TMP_29,
M_TMP_28,
M_TMP_27,
M_TMP_26,
M_TMP_25,
M_TMP_24,
M_TMP_23,
M_TMP_22,
M_TMP_21,
M_TMP_20,
M_TMP_19,
M_TMP_18,
M_TMP_17,
M_TMP_16,
M_TMP_15,
M_TMP_14,
M_TMP_13,
M_TMP_12,
M_TMP_11,
M_TMP_10,
M_TMP_9 ,
M_TMP_8 ,
M_TMP_7 ,
M_TMP_6 ,
M_TMP_5 ,
M_TMP_4 ,
M_TMP_3 ,
M_TMP_2 ,
M_TMP_1 ,
M_TMP_0 
};

parameter BIF_DATA_WIDTH                   = 512;
//AXI begin
parameter AXI_ADDR_WIDTH                   = 40;
// width of data bus:
//parameter AXI_DATA_WIDTH                   = 64;
parameter AXI_DATA_WIDTH                   = 512;
// binary logarithm of data bus width:
//parameter AXI_DATA_WIDTH_LOG2              = lib_func_clog2(AXI_DATA_WIDTH);
parameter AXI_DATA_WIDTH_LOG2              = $clog2(AXI_DATA_WIDTH);
//20231221 add two bit for add smart layer///////////
parameter AXI_ID_WIDTH                     = 11;
// width of burst length bus:
parameter AXI_LEN_WIDTH                    = 8;
// width of burst size bus:
parameter AXI_SIZE_WIDTH                   = 3;
// width of burst type bus:
parameter AXI_BURST_WIDTH                  = 2;
// width of memory type bus:
parameter AXI_CACHE_WIDTH                  = 4;
// width of protection type bus:
parameter AXI_PROT_WIDTH                   = 3;
// with of quality of service bus:
parameter AXI_QOS_WIDTH                    = 4;
// width of region identifier bus:
parameter AXI_REGION_WIDTH                 = 4;
// width of user signal:
parameter AXI_USER_WIDTH                   = 13;
// width of strobes bus:
parameter AXI_STRB_WIDTH                   = AXI_DATA_WIDTH/8;
// width of response bus:
parameter AXI_RESP_WIDTH                   = 2;

//AXI end
