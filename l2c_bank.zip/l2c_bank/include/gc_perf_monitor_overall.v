// +FHDR-----------------------------------------------------------------------
// Copyright (c) 2022, Innosilicon, Inc. Confidential Proprietary
// PROJECT NAME  : 
// BLOCK   NAME  : gc_perf_monitor_overall 
// DEPARTMENT    : Front-End Department
// AUTHOR        : Liushi
// EMAIL         : lius@innosilicon.com.cn
// ----------------------------------------------------------------------------
// Release History
// VERSION  DATE        AUTHOR    DESCRIPTION
// 1.0      20241018    Liushi  First initial
//
// Description   : 
// ----------------------------------------------------------------------------
// Others For More Information:
//
// -FHDR-----------------------------------------------------------------------
module gc_perf_monitor_overall #(
  parameter M_N = 54 //the number of perf_monitor in system.
)
(
/*AUTOARG*/
   // Outputs
   reg_perf_overall_int_satus, perf_mon_overall_int,
   perf_mon_overall_done, perf_mon_overall_pointer,
   reg_perf_mon_overall_num,perf_mon_interval_end,
   // Inputs
   clk, rst_n, reg_perf_mon_enable, perf_mon_done, perf_mon_fail,
   perf_mon_obuf_overflow, reg_perf_overall_int_mask,
   reg_normal_mode_start, reg_perf_dump_trigger,
   reg_perf_overall_int_clr, perf_mon_bif_fence_times,
   perf_mon_last_dump_times, reg_fence_interval
   );

  input               clk;
  input               rst_n;
  input [M_N-1 :0]    reg_perf_mon_enable;                    //perf_monitor enable
  input [M_N-1 :0]    perf_mon_done;                          //perf_monitor done from every perf_monitor module
  input [M_N-1 :0]    perf_mon_fail;                          //perf monitor fail from every perf monitor module
  input [M_N-1 :0]    perf_mon_obuf_overflow;                 //perf monitor obuf overflow from every perf monitor module
  input [M_N-1 :0]    perf_mon_interval_end;                  //perf monitor last done flag from every perf monitor module
  input [3*M_N :0]    reg_perf_overall_int_mask;              //register control signal interrupt mask 
  input               reg_normal_mode_start;                  //register control signal normal mode start
  input [1:0]         reg_perf_dump_trigger;                  //register control signal:2'b00:NO operation; 2'b01:start to dump in normal mode; 2'b10:start to dump in interval mode 2'b11:stop dumping operation
  input [3*M_N :0]    reg_perf_overall_int_clr;               //register control signal interrupt clear
  input [23:0]        perf_mon_bif_fence_times;               //perf monitor send fence times from every perf monitor module
  input [5:0]         perf_mon_last_dump_times;               //at the last send fence,the last dump times from one perf monitor module
  input [5:0]         reg_fence_interval;                     //the interval of sending fence,eg: reg_fence_interval = 2,dump three times send a fence.
  output [3*M_N :0]   reg_perf_overall_int_satus;             //interrupt status
  output reg          perf_mon_overall_int;                   //interrupt
  output reg          perf_mon_overall_done;                  //all perf_monitors in system dump once successfully
  output [31:0]       perf_mon_overall_pointer;               //indicate all perf monitors dump times
  output [15:0]       reg_perf_mon_overall_num;               //indicate the number of the perf_monitor module

  wire [M_N-1:0]      perf_mon_done_update;
  reg [6:0]           perf_mon_done_cnt [M_N-1:0];
  reg [M_N-1:0]       perf_mon_cnt_high;
  wire                start_pluse;
  reg                 perf_mon_overall_int_done;
  reg [M_N-1:0]       perf_mon_int_done;
  reg [M_N-1:0]       perf_mon_int_fail;
  reg [M_N-1:0]       perf_mon_int_obuf_overflow;
  reg [31:0]          perf_mon_overall_pointer;
  wire                perf_mon_overall_done_temp; 
  wire                all_perf_disable;
  reg  [M_N-1:0]      perf_mon_end;
  wire                perf_mon_overall_end;
  wire                perf_mon_interval_last_done;
  reg [M_N-1 :0]      perf_mon_done_d0;
  wire  [M_N-1:0]     perf_mon_interval_end_update;
  wire                perf_mon_overall_int_pre;
  wire                perf_mon_interval_done;
  wire [M_N-1:0]      perf_mon_cnt_not_one;
  wire                end_cnt_not_one;
  reg                 normal_mode_flag;
  wire [M_N-1:0]      perf_mon_done_mask;
  wire [M_N-1:0]      perf_mon_end_mask;
  wire [M_N-1:0]      perf_mon_fail_mask;
  wire [M_N-1 :0]     perf_mon_obuf_overflow_mask;                 //perf monitor obuf overflow from every perf monitor module
  reg                 session_end;
  reg                 done_cnt_en;

  genvar i;
  
  assign perf_mon_done_update          = done_cnt_en ? (~reg_perf_mon_enable)  | (perf_mon_done) : {{M_N}{1'b0}};//mask perf_monitor's done which is disabled,use bit or |
  assign perf_mon_interval_end_update  = done_cnt_en ? (~reg_perf_mon_enable)  | (perf_mon_interval_end) : {{M_N}{1'b0}};//mask perf_monitor's end which is disabled,use bit or |
  assign start_pluse                   = (reg_normal_mode_start) || (reg_perf_dump_trigger == 2'b10);
  assign all_perf_disable              = &(~reg_perf_mon_enable);

  assign perf_mon_done_mask            = reg_perf_mon_enable & perf_mon_done;
  assign perf_mon_end_mask             = normal_mode_flag ? perf_mon_done_mask : reg_perf_mon_enable & perf_mon_interval_end;

  assign perf_mon_fail_mask            = reg_perf_mon_enable & perf_mon_fail;
  assign perf_mon_obuf_overflow_mask   = reg_perf_mon_enable & perf_mon_obuf_overflow;

  always @(posedge clk or negedge rst_n)begin
    if(~rst_n)
      session_end <= 1'b0;
    else if(start_pluse)
      session_end <= 1'b0;
    else if(perf_mon_overall_done)
      session_end <= 1'b1;
  end

  always @(posedge clk or negedge rst_n)begin
    if(~rst_n)
      done_cnt_en <= 1'b0;
    else if(perf_mon_overall_done || all_perf_disable)
      done_cnt_en <= 1'b0;  
    else if(start_pluse)
      done_cnt_en <= 1'b1;
  end

//generate the normal mode flag-------------
  always @(posedge clk or negedge rst_n)begin
    if(~rst_n)
      normal_mode_flag <= 1'b0;
    else if(reg_perf_dump_trigger == 2'b10 || all_perf_disable)
      normal_mode_flag <= 1'b0;
    else if(reg_normal_mode_start)
      normal_mode_flag <= 1'b1;
  end
  
 //  generate perf_mon_overall_done-------------//
  generate
    for(i=0;i<=M_N -1;i=i+1)begin:gen_interval_done_cnt
      always @(posedge clk or negedge rst_n)begin
        if(~rst_n)
          perf_mon_done_cnt[i] <= 7'b0;
        else if(all_perf_disable || session_end)
          perf_mon_done_cnt[i] <= 7'b0;
        else if(perf_mon_overall_done_temp && done_cnt_en)begin
          if(perf_mon_done_update[i])
            perf_mon_done_cnt[i] <= perf_mon_done_cnt[i];
          else
            perf_mon_done_cnt[i] <= perf_mon_done_cnt[i] - 1'b1;
        end       
        else if(perf_mon_done_update[i] && done_cnt_en && reg_perf_mon_enable[i] )
          perf_mon_done_cnt[i] <= perf_mon_done_cnt[i] + 1'b1;
      end
    end
  endgenerate

  generate
     for(i=0;i<=M_N -1;i=i+1)begin:gen_perf_mon_cnt_high
       assign perf_mon_cnt_high[i] = reg_perf_mon_enable[i] ? (perf_mon_done_cnt[i] != 7'b0) : 1'b1;
     end
  endgenerate

  assign perf_mon_overall_done_temp  = all_perf_disable ? 1'b0 : (&perf_mon_cnt_high) ;
  //if end assert and the perf_mon_overall_done_temp =1 but,have the
  //perf_mon_done_cnt not all become to 0,one of perf_mon done have more one
  //than the other,but its resopnse return quickly than the other perf_mon
  generate
   for(i=0;i<=M_N -1;i=i+1)begin:gen_perf_mon_cnt_not_one
     assign perf_mon_cnt_not_one[i] = (perf_mon_done_cnt[i] != 7'b1)&&(reg_perf_mon_enable[i]);
   end
  endgenerate

  assign end_cnt_not_one = perf_mon_overall_end && perf_mon_overall_done_temp && (|perf_mon_cnt_not_one);

  always @(posedge clk or negedge rst_n)begin
    if(~rst_n)begin
      perf_mon_done_d0 <= {{M_N}{1'b0}};
     // perf_mon_done_d1 <= {{M_N}{1'b0}};
    end
    else begin
      perf_mon_done_d0 <= perf_mon_done_mask;
     // perf_mon_done_d1 <= perf_mon_done_d0;
    end
  end

  assign perf_mon_interval_last_done = perf_mon_overall_done_temp || (|perf_mon_done_d0);//because of one of perf_monitor's done number is more 1 than the others,so can't wait the common last done signal.
  assign perf_mon_interval_done   = perf_mon_overall_end && perf_mon_interval_last_done ;  

  always @(posedge clk or negedge rst_n)begin
    if(~rst_n)
      perf_mon_overall_done <= 1'b0;
    else if(normal_mode_flag)
      perf_mon_overall_done <= perf_mon_overall_done_temp; 
    else
      perf_mon_overall_done <= perf_mon_interval_done;
  end
 
 //generate perf_mon_overall_pointer for indicating the dump times
  always @(posedge clk or negedge rst_n)begin
    if(~rst_n)
      perf_mon_overall_pointer <= 32'd0;
   else if(start_pluse || all_perf_disable || normal_mode_flag)
      perf_mon_overall_pointer <= 32'd0;
   else if(perf_mon_overall_done_temp && !perf_mon_overall_end)
      perf_mon_overall_pointer <= perf_mon_overall_pointer + {26'b0,reg_fence_interval} + 1'b1;
   else if (perf_mon_overall_done_temp && perf_mon_overall_end)begin
      if(end_cnt_not_one)
        perf_mon_overall_pointer <= perf_mon_overall_pointer + {26'b0,reg_fence_interval} + 1'b1;
      else 
        perf_mon_overall_pointer <=  perf_mon_overall_pointer + {26'b0,perf_mon_last_dump_times} + 1'b1; 
    end
   else if(perf_mon_overall_end && (perf_mon_interval_last_done) && (!perf_mon_overall_done_temp))
      perf_mon_overall_pointer <=  perf_mon_overall_pointer ;   
    end
  //generate perf_mon_overall_end
  generate
    for(i=0;i<=M_N -1;i=i+1)begin:gen_interval_end
      always @(posedge clk or negedge rst_n)begin
        if(~rst_n)
          perf_mon_end[i] <= 1'b0;
        else if(session_end || all_perf_disable )
          perf_mon_end[i] <= 1'b0;
        else if(perf_mon_interval_end_update[i])
          perf_mon_end[i] <= 1'b1;
      end
    end
  endgenerate
  assign perf_mon_overall_end = &perf_mon_end;
 
 //--------------------gen interrupt and interrupt status---------------------------------------
  always @(posedge clk or negedge rst_n)begin
    if(~rst_n)
      perf_mon_overall_int_done <= 1'b0;
    else if(reg_perf_overall_int_clr[0])
     perf_mon_overall_int_done <= 1'b0;
    else if(~reg_perf_overall_int_mask[0]&perf_mon_overall_done)
      perf_mon_overall_int_done <= 1'b1;
  end

  generate
    for(i=0;i<=M_N-1;i=i+1)begin:gen_perf_mon_done_int
      always @(posedge clk or negedge rst_n)begin
        if(~rst_n)
          perf_mon_int_done[i] <= 1'b0;
        else if(reg_perf_overall_int_clr[i+1])
          perf_mon_int_done[i] <= 1'b0;
        else if(~reg_perf_overall_int_mask[i+1]&perf_mon_end_mask[i])
          perf_mon_int_done[i] <= 1'b1;
      end
    end
  endgenerate

  generate
    for(i=0;i<=M_N-1;i=i+1)begin:gen_perf_mon_fail_int
      always @(posedge clk or negedge rst_n)begin
        if(~rst_n)
          perf_mon_int_fail[i] <= 1'b0;
        else if(reg_perf_overall_int_clr[i+M_N+1])
          perf_mon_int_fail[i] <= 1'b0;
        else if(~reg_perf_overall_int_mask[i+M_N+1]&perf_mon_fail_mask[i])
          perf_mon_int_fail[i] <= 1'b1;
      end
    end
  endgenerate

  generate
    for(i=0;i<=M_N-1;i=i+1)begin:gen_perf_mon_obuf_overflow_int
      always @(posedge clk or negedge rst_n)begin
        if(~rst_n)
          perf_mon_int_obuf_overflow[i] <= 1'b0;
        else if(reg_perf_overall_int_clr[i+2*M_N+1])
          perf_mon_int_obuf_overflow[i] <= 1'b0;
        else if(~reg_perf_overall_int_mask[i+2*M_N+1]&perf_mon_obuf_overflow_mask[i])
          perf_mon_int_obuf_overflow[i] <= 1'b1;
      end
    end
  endgenerate

  //register output perf_mon_overall_int----------
  always @(posedge clk or negedge rst_n)begin
    if(~rst_n)
      perf_mon_overall_int <= 1'b0;
    else
      perf_mon_overall_int <= perf_mon_overall_int_pre;
  end
  assign perf_mon_overall_int_pre   = perf_mon_overall_int_done | (|perf_mon_int_done)|(|perf_mon_int_fail)|(|perf_mon_int_obuf_overflow);

  assign reg_perf_overall_int_satus = {perf_mon_int_obuf_overflow,perf_mon_int_fail,perf_mon_int_done,perf_mon_overall_int_done};

  //let software know the number of the perf_mon in the system.
  assign reg_perf_mon_overall_num = M_N;

endmodule
