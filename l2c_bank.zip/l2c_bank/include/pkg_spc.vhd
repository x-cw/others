
-- #==========================================================================#
-- |                                                                          |
-- |  Copyright (c) 2022, Fantasy Technologies Limited and/or its         |
-- |  affiliated group companies ("Fantasy"). All rights reserved.        |
-- |  No part of this content, either material or conceptual may be copied    |
-- |  or distributed, transmitted, transcribed, stored in a retrieval system  |
-- |  or translated into any human or computer language in any form by any    |
-- |  means, electronic, mechanical manual, or otherwise, or disclosed to     |
-- |  third parties without the express written permission of Fantasy.    |
-- |                                                                          |
-- #==========================================================================#



library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
library work;





package pkg_spc is

   constant DUST4CONSTANT                   : natural                                       := 1;
   constant MAX_SPC                         : natural                                       := 10;--24;
   constant MAX_SPC_WIDTH                   : natural                                       := 5;--5;


end package pkg_spc;

package body pkg_spc is

end package body pkg_spc;
