
-- #==========================================================================#
-- |                                                                          |
-- |  Copyright (c) 2022, Fantasy Technologies Limited and/or its         |
-- |  affiliated group companies ("Fantasy"). All rights reserved.        |
-- |  No part of this content, either material or conceptual may be copied    |
-- |  or distributed, transmitted, transcribed, stored in a retrieval system  |
-- |  or translated into any human or computer language in any form by any    |
-- |  means, electronic, mechanical manual, or otherwise, or disclosed to     |
-- |  third parties without the express written permission of Fantasy.    |
-- |                                                                          |
-- #==========================================================================#



library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
library work;





package pkg_rogue4 is

   constant RESYNC_BANKS                    : natural                                       := 12;
   constant RESYNC_LOGBANKS                 : natural                                       := 4;
   constant RESYNC_SDEPTH                   : natural                                       := 3;
   constant FLOPSYNC_DEPTH                  : natural                                       := 4;
   constant TILE_ID_BITS                    : natural                                       := 4;
   constant SLOT_BITS                       : natural                                       := 5; --2025.01.17 gp3 modified
   constant NUM_TE_PIPES                    : natural                                       := 2;
   constant NUM_TE_PIPE_BITS                : natural                                       := 1;
   constant TASK_IDS                        : natural                                       := 64;
   constant TASK_ID_BITS                    : natural                                       := 6;
   constant NUM_TASKS                       : natural                                       := 64;
   constant TASK_BITS                       : natural                                       := 6;
   constant NUM_FC                          : natural                                       := 2;
   constant FC_BITS                         : natural                                       := 3;
   constant NUM_TESS_DM                     : natural                                       := 1;
   constant PARTITION_STORE_DWORD_STORAGE   : natural                                       := 32768;
   constant PS_MEM_BANK_DEPTH               : natural                                       := 1024;
   constant MIN_PIXEL_OUTPUT_DWORDS_PER_SAMPLE: natural                                       := 2;
   constant MAX_PIXEL_OUTPUT_DWORDS_PER_SAMPLE: natural                                       := 8;
   constant MAX_SAMPLES_PER_TILE            : natural                                       := 2048;
   constant MAX_PIXELS_PER_TILE             : natural                                       := 1024;
   constant NUM_PARTITIONS                  : natural                                       := 16;
   constant USED_PARTITION_BITS             : natural                                       := 4;
   constant ICTRL_L1CACHE_NUM_TAGS          : natural                                       := 32;
   constant CUC_L1CACHE_NUM_TAGS           : natural                                       := 32;
   constant CUC_L1CACHE_TAG_BITS           : natural                                       := 5;
   constant CUC_L1CACHE_TOP_NUM_TAGS       : natural                                       := 64;
   constant CUC_L1CACHE_TOP_TAG_BITS       : natural                                       := 6;
   constant ICTRL_L1CACHE_TAG_BITS          : natural                                       := 5;
   constant ICTRL_L1CACHE_TOP_NUM_TAGS      : natural                                       := 64;
   constant ICTRL_L1CACHE_TOP_TAG_BITS      : natural                                       := 6;
   constant STM_INSTANCE_MAX                : natural                                       := 4;
   constant STM_INSTANCE_MAX_BITS           : natural                                       := 2;
   constant FSR_FRAG_HEIGHT_BITS            : natural                                       := 2;
   constant FSR_FRAG_WIDTH_BITS             : natural                                       := 2;
   constant MAX_FRAGMENT_SAMPLES            : natural                                       := 16;
   constant MAX_FRAGMENT_SAMPLES_BITS       : natural                                       := 4;
   constant NUM_TE                     : natural                                       := 4;--for mutlti te ,wangbz01,20231228
   constant NUM_TE_BITS                : natural                                       := 2;
   ----------------------------------------------------------------------------------------------------------------------------------
   --   Enumerators
   ----------------------------------------------------------------------------------------------------------------------------------
   attribute enum_encoding : string;

   type t_e_fsr_frag_height_type is (
      X1, -- 00
      X2, -- 01
      X4  -- 10
   );
   attribute enum_encoding of t_e_fsr_frag_height_type : type is "00 01 10";
   constant E_FSR_FRAG_HEIGHT_TYPE_X1 : std_logic_vector(1 downto 0) := "00";
   constant E_FSR_FRAG_HEIGHT_TYPE_X2 : std_logic_vector(1 downto 0) := "01";
   constant E_FSR_FRAG_HEIGHT_TYPE_X4 : std_logic_vector(1 downto 0) := "10";

   function to_slv(i : t_e_fsr_frag_height_type ) return std_logic_vector;
   function to_t_e_fsr_frag_height_type(i : std_logic_vector(1 downto 0)) return t_e_fsr_frag_height_type;

   type t_e_fsr_frag_width_type is (
      X1, -- 00
      X2, -- 01
      X4  -- 10
   );
   attribute enum_encoding of t_e_fsr_frag_width_type : type is "00 01 10";
   constant E_FSR_FRAG_WIDTH_TYPE_X1 : std_logic_vector(1 downto 0) := "00";
   constant E_FSR_FRAG_WIDTH_TYPE_X2 : std_logic_vector(1 downto 0) := "01";
   constant E_FSR_FRAG_WIDTH_TYPE_X4 : std_logic_vector(1 downto 0) := "10";

   function to_slv(i : t_e_fsr_frag_width_type ) return std_logic_vector;
   function to_t_e_fsr_frag_width_type(i : std_logic_vector(1 downto 0)) return t_e_fsr_frag_width_type;
end package pkg_rogue4;

package body pkg_rogue4 is

   -- conversion function for e_fsr_frag_height_type enumerator
   function to_slv(i : t_e_fsr_frag_height_type ) return std_logic_vector is
      variable ret : std_logic_vector(1 downto 0);
   begin
      case i is
         when X1 => ret := E_FSR_FRAG_HEIGHT_TYPE_X1;
         when X2 => ret := E_FSR_FRAG_HEIGHT_TYPE_X2;
         when others => ret := E_FSR_FRAG_HEIGHT_TYPE_X4;
      end case;
      return ret;
   end function;
   -- conversion function for e_fsr_frag_height_type enumerator
   function to_t_e_fsr_frag_height_type(i : std_logic_vector(1 downto 0)) return t_e_fsr_frag_height_type is
      variable ret : t_e_fsr_frag_height_type;
   begin
      case i is
         when E_FSR_FRAG_HEIGHT_TYPE_X1 => ret := X1;
         when E_FSR_FRAG_HEIGHT_TYPE_X2 => ret := X2;
         when others                    => ret := X4;
      end case;
      return ret;
   end function;

   -- conversion function for e_fsr_frag_width_type enumerator
   function to_slv(i : t_e_fsr_frag_width_type ) return std_logic_vector is
      variable ret : std_logic_vector(1 downto 0);
   begin
      case i is
         when X1 => ret := E_FSR_FRAG_WIDTH_TYPE_X1;
         when X2 => ret := E_FSR_FRAG_WIDTH_TYPE_X2;
         when others => ret := E_FSR_FRAG_WIDTH_TYPE_X4;
      end case;
      return ret;
   end function;
   -- conversion function for e_fsr_frag_width_type enumerator
   function to_t_e_fsr_frag_width_type(i : std_logic_vector(1 downto 0)) return t_e_fsr_frag_width_type is
      variable ret : t_e_fsr_frag_width_type;
   begin
      case i is
         when E_FSR_FRAG_WIDTH_TYPE_X1 => ret := X1;
         when E_FSR_FRAG_WIDTH_TYPE_X2 => ret := X2;
         when others                   => ret := X4;
      end case;
      return ret;
   end function;

end package body pkg_rogue4;
