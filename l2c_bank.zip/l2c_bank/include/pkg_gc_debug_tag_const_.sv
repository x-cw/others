/*

 * #==========================================================================#
 * |                                                                          |
 * |  Copyright (c) 2022, Fantasy Technologies Limited and/or its         |
 * |  affiliated group companies ("Fantasy"). All rights reserved.        |
 * |  No part of this content, either material or conceptual may be copied    |
 * |  or distributed, transmitted, transcribed, stored in a retrieval system  |
 * |  or translated into any human or computer language in any form by any    |
 * |  means, electronic, mechanical manual, or otherwise, or disclosed to     |
 * |  third parties without the express written permission of Fantasy.    |
 * |                                                                          |
 * #==========================================================================#

 */


package pkg_gc_debug_tag_const_;




   localparam int                 GC_DEBUG_TAG_VTX_DM_BITS                          = 3;
   localparam int                 GC_DEBUG_TAG_VTX_KICK_BITS                        = 12;
   localparam int                 GC_DEBUG_TAG_VTX_GENERATION_BITS                  = 4;
   localparam int                 GC_DEBUG_TAG_VTX_SPC_BITS                         = 8;
   localparam int                 GC_DEBUG_TAG_VTX_PIM_BITS                         = 32;
   localparam int                 GC_DEBUG_TAG_VTX_OBJECT_BITS                      = 32;
   localparam int                 GC_DEBUG_TAG_VTX_BLOCK_ID_BITS                    = 32;
   localparam int                 GC_DEBUG_TAG_VTX_DATATYPE_BITS                    = 2;
   localparam int                 GC_DEBUG_TAG_VTX_VCECOUNT_BITS                    = 6;
   localparam int                 GC_DEBUG_TAG_VTX_TASK_BITS                        = 32;
   localparam int                 GC_DEBUG_TAG_VTX_INST_0_BITS                      = 7;
   localparam int                 GC_DEBUG_TAG_VTX_INST_1_BITS                      = 7;
   localparam int                 GC_DEBUG_TAG_VTX_BASE_ADDR_BITS                   = 16;
   localparam int                 GC_DEBUG_TAG_VTX_INSTRUCTION_ID_BITS              = 16;
   localparam int                 GC_DEBUG_TAG_VTX_GPU_ID_BITS                      = 3;
   localparam int                 GC_DEBUG_TAG_VTX_BITS                             = 212;
   localparam int                 GC_DEBUG_TAG_TSV_DM_BITS                          = 3;
   localparam int                 GC_DEBUG_TAG_TSV_KICK_BITS                        = 12;
   localparam int                 GC_DEBUG_TAG_TSV_GENERATION_BITS                  = 4;
   localparam int                 GC_DEBUG_TAG_TSV_SPC_BITS                         = 8;
   localparam int                 GC_DEBUG_TAG_TSV_PIM_BITS                         = 32;
   localparam int                 GC_DEBUG_TAG_TSV_OBJECT_BITS                      = 32;
   localparam int                 GC_DEBUG_TAG_TSV_BLOCK_ID_BITS                    = 32;
   localparam int                 GC_DEBUG_TAG_TSV_DATATYPE_BITS                    = 2;
   localparam int                 GC_DEBUG_TAG_TSV_VCECOUNT_BITS                    = 6;
   localparam int                 GC_DEBUG_TAG_TSV_TASK_BITS                        = 32;
   localparam int                 GC_DEBUG_TAG_TSV_INST_0_BITS                      = 7;
   localparam int                 GC_DEBUG_TAG_TSV_INST_1_BITS                      = 7;
   localparam int                 GC_DEBUG_TAG_TSV_BASE_ADDR_BITS                   = 16;
   localparam int                 GC_DEBUG_TAG_TSV_INSTRUCTION_ID_BITS              = 16;
   localparam int                 GC_DEBUG_TAG_TSV_GPU_ID_BITS                      = 3;
   localparam int                 GC_DEBUG_TAG_TSV_BITS                             = 212;
   localparam int                 GC_DEBUG_TAG_CMP_DM_BITS                          = 3;
   localparam int                 GC_DEBUG_TAG_CMP_KICK_BITS                        = 12;
   localparam int                 GC_DEBUG_TAG_CMP_GENERATION_BITS                  = 4;
   localparam int                 GC_DEBUG_TAG_CMP_BLOCK_ID_BITS                    = 32;
   localparam int                 GC_DEBUG_TAG_CMP_GROUP_ID_BITS                    = 32;
   localparam int                 GC_DEBUG_TAG_CMP_TASK_BITS                        = 32;
   localparam int                 GC_DEBUG_TAG_CMP_INST_0_BITS                      = 7;
   localparam int                 GC_DEBUG_TAG_CMP_INST_1_BITS                      = 7;
   localparam int                 GC_DEBUG_TAG_CMP_BASE_ADDR_BITS                   = 16;
   localparam int                 GC_DEBUG_TAG_CMP_INSTRUCTION_ID_BITS              = 16;
   localparam int                 GC_DEBUG_TAG_CMP_GPU_ID_BITS                      = 3;

   localparam int                 GC_DEBUG_TAG_CMP_SUBGROUPID_BITS                  = 3;
   localparam int                 GC_DEBUG_TAG_CMP_TEMPALLOCATED_BITS               = 1 ;
   localparam int                 GC_DEBUG_TAG_CMP_TEMPBASEADDR_BITS                = 9;
   localparam int                 GC_DEBUG_TAG_CMP_ATTRALLOCATED_BITS               = 1;
   localparam int                 GC_DEBUG_TAG_CMP_ATRRBASEADDR_BITS                = 9;
   localparam int                 GC_DEBUG_TAG_CMP_SHAREDBASEADDR_BITS              = 7;
   localparam int                 GC_DEBUG_TAG_CMP_LMSBASEADDR_BITS                 = 10;
   localparam int                 GC_DEBUG_TAG_CMP_CFSBASEADDR_BITS                 = 9;
   localparam int                 GC_DEBUG_TAG_CMP_TASKTYPE_BITS                    = 3;
   localparam int                 GC_DEBUG_TAG_CMP_BITS                             = 216;

   localparam int                 GC_DEBUG_TAG_F2D_DM_BITS                          = 3;
   localparam int                 GC_DEBUG_TAG_F2D_KICK_BITS                        = 12;
   localparam int                 GC_DEBUG_TAG_F2D_BLIT_BITS                        = 16;
   localparam int                 GC_DEBUG_TAG_F2D_TILE_X_BITS                      = 11;
   localparam int                 GC_DEBUG_TAG_F2D_TILE_Y_BITS                      = 11;
   localparam int                 GC_DEBUG_TAG_F2D_GENERATION_BITS                  = 4;
   localparam int                 GC_DEBUG_TAG_F2D_OBJECT_BITS                      = 32;
   localparam int                 GC_DEBUG_TAG_F2D_TASK_BITS                        = 32;
   localparam int                 GC_DEBUG_TAG_F2D_INST_IN_BLOCK_BITS               = 2;
   localparam int                 GC_DEBUG_TAG_F2D_INST_IN_TASK_BITS                = 7;
   localparam int                 GC_DEBUG_TAG_F2D_PHASE_BITS                       = 1;
   localparam int                 GC_DEBUG_TAG_F2D_SAMPLE_BITS                      = 4;
   localparam int                 GC_DEBUG_TAG_F2D_BLOCK_X_0_BITS                   = 4;
   localparam int                 GC_DEBUG_TAG_F2D_BLOCK_Y_0_BITS                   = 4;
   localparam int                 GC_DEBUG_TAG_F2D_BLOCK_X_1_BITS                   = 4;
   localparam int                 GC_DEBUG_TAG_F2D_BLOCK_Y_1_BITS                   = 4;
   localparam int                 GC_DEBUG_TAG_F2D_BASE_ADDR_BITS                   = 16;
   localparam int                 GC_DEBUG_TAG_F2D_INSTRUCTION_ID_BITS              = 16;
   localparam int                 GC_DEBUG_TAG_F2D_BLOCKS_COORDS_BITS               = 256;
   localparam int                 GC_DEBUG_TAG_F2D_GPU_ID_BITS                      = 3;
   localparam int                 GC_DEBUG_TAG_F2D_BITS                             = 440;
   localparam int                 GC_DEBUG_TAG_PXL_DM_BITS                          = 3;
   localparam int                 GC_DEBUG_TAG_PXL_KICK_BITS                        = 12;
   localparam int                 GC_DEBUG_TAG_PXL_TILE_X_BITS                      = 11;
   localparam int                 GC_DEBUG_TAG_PXL_TILE_Y_BITS                      = 11;
   localparam int                 GC_DEBUG_TAG_PXL_GENERATION_BITS                  = 4;
   localparam int                 GC_DEBUG_TAG_PXL_OBJECT_BITS                      = 32;
   localparam int                 GC_DEBUG_TAG_PXL_SUBOBJECT_BITS                   = 2;
   localparam int                 GC_DEBUG_TAG_PXL_TASK_BITS                        = 32;
   localparam int                 GC_DEBUG_TAG_PXL_INST_IN_BLOCK_BITS               = 2;
   localparam int                 GC_DEBUG_TAG_PXL_INST_IN_TASK_BITS                = 7;
   localparam int                 GC_DEBUG_TAG_PXL_PHASE_BITS                       = 1;
   localparam int                 GC_DEBUG_TAG_PXL_SAMPLE_BITS                      = 4;
   localparam int                 GC_DEBUG_TAG_PXL_BLOCK_X_0_BITS                   = 4;
   localparam int                 GC_DEBUG_TAG_PXL_BLOCK_Y_0_BITS                   = 4;
   localparam int                 GC_DEBUG_TAG_PXL_BLOCK_X_1_BITS                   = 4;
   localparam int                 GC_DEBUG_TAG_PXL_BLOCK_Y_1_BITS                   = 4;
   localparam int                 GC_DEBUG_TAG_PXL_PUNCHTHROUGH_BITS                = 1;
   localparam int                 GC_DEBUG_TAG_PXL_BASE_ADDR_BITS                   = 16;
   localparam int                 GC_DEBUG_TAG_PXL_INSTRUCTION_ID_BITS              = 16;
   localparam int                 GC_DEBUG_TAG_PXL_BLOCKS_COORDS_BITS               = 256;
   localparam int                 GC_DEBUG_TAG_PXL_GPU_ID_BITS                      = 3;
   localparam int                 GC_DEBUG_TAG_PXL_BITS                             = 427;
   localparam int                 GC_DEBUG_TAG_RAY_DM_BITS                          = 3;
   localparam int                 GC_DEBUG_TAG_RAY_KICK_BITS                        = 12;
   localparam int                 GC_DEBUG_TAG_RAY_GPU_ID_BITS                      = 3;
   localparam int                 GC_DEBUG_TAG_RAY_GENERATION_BITS                  = 3;
   localparam int                 GC_DEBUG_TAG_RAY_TASK_TYPE_BITS                   = 3;
   localparam int                 GC_DEBUG_TAG_RAY_DISPATCH_ID_BITS                 = 32;
   localparam int                 GC_DEBUG_TAG_RAY_BROADCAST_BITS                   = 1;
   localparam int                 GC_DEBUG_TAG_RAY_GROUP_BITS                       = 8;
   localparam int                 GC_DEBUG_TAG_RAY_SUB_GROUP_BITS                   = 8;
   localparam int                 GC_DEBUG_TAG_RAY_TASK_BITS                        = 32;
   localparam int                 GC_DEBUG_TAG_RAY_INSTANCE_NUM_BITS                = 7;
   localparam int                 GC_DEBUG_TAG_RAY_LAUNCH_ID_X_BITS                 = 16;
   localparam int                 GC_DEBUG_TAG_RAY_LAUNCH_ID_Y_BITS                 = 16;
   localparam int                 GC_DEBUG_TAG_RAY_LAUNCH_ID_Z_BITS                 = 16;
   localparam int                 GC_DEBUG_TAG_RAY_NOT_DETERMINISTIC_BITS           = 1;
   localparam int                 GC_DEBUG_TAG_RAY_BASE_ADDR_BITS                   = 16;
   localparam int                 GC_DEBUG_TAG_RAY_INSTRUCTION_ID_BITS              = 16;
   localparam int                 GC_DEBUG_TAG_RAY_BITS                             = 193;
   localparam int                 GC_DEBUG_TAG_STM_DM_BITS                          = 3;
   localparam int                 GC_DEBUG_TAG_STM_KICK_BITS                        = 12;
   localparam int                 GC_DEBUG_TAG_STM_GENERATION_BITS                  = 4;
   localparam int                 GC_DEBUG_TAG_STM_SPC_BITS                         = 8;
   localparam int                 GC_DEBUG_TAG_STM_PIM_BITS                         = 32;
   localparam int                 GC_DEBUG_TAG_STM_BLOCK_ID_BITS                    = 32;
   localparam int                 GC_DEBUG_TAG_STM_TASK_BITS                        = 32;
   localparam int                 GC_DEBUG_TAG_STM_BASE_ADDR_BITS                   = 16;
   localparam int                 GC_DEBUG_TAG_STM_INSTRUCTION_ID_BITS              = 16;
   localparam int                 GC_DEBUG_TAG_STM_GPU_ID_BITS                      = 3;
   localparam int                 GC_DEBUG_TAG_STM_BITS                             = 158;
   localparam int                 DBGTAG_WIDTH                                       = 440;







endpackage
