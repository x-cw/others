// +FHDR-----------------------------------------------------------------------
// Copyright (c) 2022, Innosilicon, Inc. Confidential Proprietary
// PROJECT NAME  : 
// BLOCK   NAME  : gc_perf_monitor_bif 
// DEPARTMENT    : Front-End Department
// AUTHOR        : Liushi
// EMAIL         : lius@innosilicon.com.cn
// ----------------------------------------------------------------------------
// Release History
// VERSION  DATE        AUTHOR    DESCRIPTION
// 1.0      20241015    Liushi  First initial
//
// Description   : 
// ----------------------------------------------------------------------------
// Others For More Information:
//
// -FHDR-----------------------------------------------------------------------
module gc_perf_monitor_bif
#(
parameter num_id = 0,
parameter N = 64,
parameter W_ADD =0,
parameter int W[127:0]={
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
1,1,1,1,1,1,1,1,
1,1,1,1,1,1,1,1,
1,1,1,1,1,1,1,1,
1,1,1,1,1,1,1,1,
1,1,1,1,1,1,1,1,
1,1,1,1,1,1,1,1,
1,1,1,1,1,1,1,1,
1,1,1,1,1,1,1,1
}
)
(
clk,
rst_n,
perf_event,
reg_perf_dump_trigger,
reg_perf_enable,
reg_perf_time_slot,
reg_perf_base_addr,
reg_perf_space_size,
reg_normal_mode_start,
reg_time_stamp_enable,
time_stamp_low32bit,
time_stamp_high32bit,
//---------bif control registers-----------
reg_bif_cmd_persistence,
reg_bif_cmd_ctxt_pasid,
reg_bif_cmd_gpu_pipe_coherent,
reg_bif_cmd_mss_cache_policy,
reg_fence_interval,
//bif interface
perf_mon_bif_cmd_valid,
perf_mon_bif_cmd_enable,
perf_mon_bif_cmd_operation,
perf_mon_bif_cmd_persistence,
perf_mon_bif_cmd_ctxt_pasid,
perf_mon_bif_cmd_gpu_pipe_coherent,
perf_mon_bif_cmd_mss_cache_policy,
perf_mon_bif_cmd_fbcdc_compress,
perf_mon_bif_cmd_fbcdc_clear,
perf_mon_bif_cmd_fbcdc_onedge,
perf_mon_bif_cmd_vaddress,
perf_mon_bif_cmd_burst_length,
perf_mon_bif_cmd_tag_sb,
perf_mon_bif_write_valid,
perf_mon_bif_write_enable,
perf_mon_bif_write_mask,
perf_mon_bif_write_data,
perf_mon_bif_rtn_valid,
perf_mon_bif_rtn_enable,
perf_mon_bif_rtn_credit,
perf_mon_bif_rtn_fence,
perf_mon_bif_rtn_data,
perf_mon_bif_rtn_tag_sb,
//
perf_mon_done,
perf_mon_fail,
perf_mon_obuf_overflow,
reg_perf_wrap_addr_cnt,
perf_mon_cnt_time_flag,
perf_mon_bif_fence_times,
perf_mon_last_dump_times
);

`include "lib_func_clog2.v"
`include "perf_monitor_config.v"

//clock and reset--------------
input               clk;
input               rst_n;
//input perf_event-------------
input [M_TOTAL-1:0] perf_event;
//---input control registers-------------
input               reg_normal_mode_start;
input [1:0]         reg_perf_dump_trigger;
input               reg_perf_enable;
input [15:0]        reg_perf_time_slot;
input [47:0]        reg_perf_base_addr;
input [21:0]        reg_perf_space_size;
input               reg_time_stamp_enable;
//time stamp from other modules-------------
input [31:0]        time_stamp_low32bit;
input [31:0]        time_stamp_high32bit;
//bif control registers-----------
input [1:0]         reg_bif_cmd_persistence;
input [4:0]         reg_bif_cmd_ctxt_pasid;
input               reg_bif_cmd_gpu_pipe_coherent;
input               reg_bif_cmd_mss_cache_policy;
input [5:0]         reg_fence_interval;
//BIF interface---------------
output              perf_mon_bif_cmd_valid;
input               perf_mon_bif_cmd_enable;
output [3:0]        perf_mon_bif_cmd_operation;
output [1:0]        perf_mon_bif_cmd_persistence;
output [4:0]        perf_mon_bif_cmd_ctxt_pasid;
output              perf_mon_bif_cmd_gpu_pipe_coherent;
output              perf_mon_bif_cmd_mss_cache_policy;
output              perf_mon_bif_cmd_fbcdc_compress;
output              perf_mon_bif_cmd_fbcdc_clear;
output              perf_mon_bif_cmd_fbcdc_onedge;
output [47:0]       perf_mon_bif_cmd_vaddress;
output [3:0]        perf_mon_bif_cmd_burst_length;
output [7:0]        perf_mon_bif_cmd_tag_sb;
output              perf_mon_bif_write_valid;
input               perf_mon_bif_write_enable;
output [31:0]       perf_mon_bif_write_mask;
output [511:0]      perf_mon_bif_write_data;
input               perf_mon_bif_rtn_valid;
output              perf_mon_bif_rtn_enable;
output              perf_mon_bif_rtn_credit;
input               perf_mon_bif_rtn_fence;
input  [511:0]      perf_mon_bif_rtn_data;
input  [6:0]        perf_mon_bif_rtn_tag_sb;

//----dump status--------
output wire         perf_mon_done;
output wire         perf_mon_fail;
output wire         perf_mon_obuf_overflow;
output reg [9:0]    reg_perf_wrap_addr_cnt;
output              perf_mon_cnt_time_flag;
output [23:0]       perf_mon_bif_fence_times;
output [5:0]        perf_mon_last_dump_times;

localparam N_LOG2=lib_func_clog2(N);
localparam OBUF_DEPTH=N/16;


reg                        rd_cold_cnt_en;
wire                       rd_dump_cnt_en;
reg                        rd_dump_cnt_en_d0;
wire                       dpram_rd_en;
reg [N_LOG2-1:0]           dpram_rd_addr;
reg [N_LOG2-1:0]           rd_dump_addr;
reg [N_LOG2-1:0]           rd_dump_addr_d0;
reg [N_LOG2-1:0]           rd_dump_addr_d1;
reg [N_LOG2-1:0]           rd_dump_addr_d2;
reg [N_LOG2-1:0]           rd_dump_addr_d3;
reg                        dpram_wrt_en_pre;
reg                        dpram_wrt_en;
reg [N_LOG2-1:0]           dpram_wrt_addr;
reg [N_LOG2-1:0]           dpram_wrt_addr_pre;
reg [N_LOG2:0]             dpram_wrt_addr_pulse;
reg                        hot_cnt_en;
genvar                     i;
reg [N-1:0]                hot_cnt_clear;
wire [31:0]                dpram_rdata;
reg [31:0]                 dpram_rdata_d0;
reg [31:0]                 rdata_patch32bit;
wire [31:0]                cold_cnt;
reg [31:0]                 dpram_wdata;
wire                       first_cnt_num_cycles_wrt;
wire [31:0]                hot_cnt[N];
wire [25:0]                perf_event_mux[N];
reg [15:0]                 interval_mode_cycles_cnt;
wire [AXI_DATA_WIDTH-1:0]  obuf_rdata;
reg                        obuf_wrten;
reg [AXI_DATA_WIDTH-1:0]   obuf_wdata;
wire                       obuf_empty;
wire [47:0]                memory_base_addr;
reg [3:0]                  rd_dump_cnt_en_d0_cnt;
reg [3:0]                  rd_dump_cnt_en_d0_cnt_d0;
reg [1:0]                  perf_dump_trigger_latch;
reg [1:0]                  fsm_normal_st_r;
reg [1:0]                  fsm_normal_st_nxt;
reg [1:0]                  fsm_interval_st_r;
reg [1:0]                  fsm_interval_st_nxt;
reg                        rd_dump_cnt_en_normal;
reg                        rd_dump_cnt_en_interval;
reg                        rd_dump_cnt_en_normal_d0;
reg                        rd_dump_cnt_en_normal_d1;
reg [N_LOG2-1:0]           rd_dump_cnt_normal;
reg                        obuf_data_valid;
reg [1:0]                  obuf_wrten_cnt;
wire                       obuf_rd_en;
wire                       obuf_data_ready;
wire                       new_session_start;
wire [31:0]                addr_offset;
wire [2:0]                 burst_data_num;
reg [23:0]                 perf_mon_done_cnt;
wire                       obuf_overflow;
wire [19:0]                signal_perf_mon_size;
reg                        interval_mode_cnt_flag;
reg                        new_session_start_d0;
reg                        reg_perf_enable_d0;
wire                       fun_exit;
wire                       clear;
reg [1:0]                  obuf_rd_en_cnt;
reg                        obuf_rd_flag_temp;
reg                        obuf_wrt_in_rd_flag;
wire                       obuf_wrt_en_disable;
wire                       obuf_wrten_true;
reg                        obuf_rd_en_d0;
wire                       obuf_rd_flag;
reg [10:0]                 fence_rep_lack;
reg [23:0]                 perf_mon_done_cnt_temp;
wire                       perf_mon_done_temp;
reg                        perf_mon_done_fake;


localparam FSM_NORMAL_IDLE      = 2'b00;
localparam FSM_NORMAL_CNT       = 2'b01;
localparam FSM_NORMAL_DUMP      = 2'b10;


localparam FSM_INTERVAL_IDLE      = 2'b00;
localparam FSM_INTERVAL_CNT       = 2'b01;
localparam FSM_INTERVAL_DUMP_WAIT = 2'b10;
localparam FSM_INTERVAL_DUMP      = 2'b11;


  always @(posedge clk or negedge rst_n)begin
    if(~rst_n)
      fsm_normal_st_r <= FSM_NORMAL_IDLE;
    else if(fun_exit)
      fsm_normal_st_r <= FSM_NORMAL_IDLE;
    else
      fsm_normal_st_r <= fsm_normal_st_nxt;
  end

  always @(*)begin
    case(fsm_normal_st_r)
      FSM_NORMAL_IDLE:begin
        if(reg_normal_mode_start & reg_perf_enable)
          fsm_normal_st_nxt = FSM_NORMAL_CNT;
        else
          fsm_normal_st_nxt = FSM_NORMAL_IDLE;  
      end
      FSM_NORMAL_CNT:begin
        if(reg_perf_dump_trigger == 2'b01)
          fsm_normal_st_nxt = FSM_NORMAL_DUMP;
        else
          fsm_normal_st_nxt = FSM_NORMAL_CNT;  
      end
      FSM_NORMAL_DUMP:begin
        if(rd_dump_cnt_en_normal && (rd_dump_cnt_normal == N-1))
          fsm_normal_st_nxt = FSM_NORMAL_IDLE;
        else
          fsm_normal_st_nxt = FSM_NORMAL_DUMP;    
      end
      default:fsm_normal_st_nxt = FSM_NORMAL_IDLE;
    endcase
  end


  always @(posedge clk or negedge rst_n)begin
    if(~rst_n)
      fsm_interval_st_r <= FSM_INTERVAL_IDLE;
    else if(fun_exit)
      fsm_interval_st_r <= FSM_INTERVAL_IDLE;
    else
      fsm_interval_st_r <= fsm_interval_st_nxt;
  end

  always @(*)begin
    case(fsm_interval_st_r)
      FSM_INTERVAL_IDLE:begin
        if(reg_perf_dump_trigger == 2'b10)
          fsm_interval_st_nxt = FSM_INTERVAL_CNT;
        else
          fsm_interval_st_nxt = FSM_INTERVAL_IDLE;  
      end
      FSM_INTERVAL_CNT:begin
        if(interval_mode_cycles_cnt == reg_perf_time_slot -1'b1 ||reg_perf_dump_trigger == 2'b11)begin
          if(rd_cold_cnt_en && (dpram_rd_addr==N-1))
            fsm_interval_st_nxt = FSM_INTERVAL_DUMP;
          else
            fsm_interval_st_nxt = FSM_INTERVAL_DUMP_WAIT;
        end
        else
          fsm_interval_st_nxt = FSM_INTERVAL_CNT;  
      end
      FSM_INTERVAL_DUMP_WAIT:begin
        if(rd_cold_cnt_en && (dpram_rd_addr == N-1))
          fsm_interval_st_nxt = FSM_INTERVAL_DUMP;
        else
          fsm_interval_st_nxt = FSM_INTERVAL_DUMP_WAIT;    
      end
      FSM_INTERVAL_DUMP:begin
        if(rd_dump_cnt_en && (dpram_rd_addr == N-1))begin
          if(perf_dump_trigger_latch == 2'b11)
             fsm_interval_st_nxt = FSM_INTERVAL_IDLE;
          else
            fsm_interval_st_nxt = FSM_INTERVAL_CNT;
        end
        else
          fsm_interval_st_nxt = FSM_INTERVAL_DUMP;    
      end
      default:fsm_interval_st_nxt = FSM_INTERVAL_IDLE;
    endcase
  end

 
 always @(posedge clk or negedge rst_n)begin
   if(~rst_n)
     reg_perf_enable_d0 <= 1'b0;
   else
     reg_perf_enable_d0 <= reg_perf_enable;
  end

  assign fun_exit = (!reg_perf_enable) & reg_perf_enable_d0;
  assign clear = fun_exit | new_session_start;

  always @(posedge clk or negedge rst_n)begin
    if(~rst_n)
      rd_cold_cnt_en <= 1'b0;
    else if(clear)
      rd_cold_cnt_en <= 1'b0;
    else if(fsm_normal_st_r == FSM_NORMAL_DUMP ||
    (fsm_interval_st_r == FSM_INTERVAL_DUMP_WAIT && rd_cold_cnt_en && dpram_rd_addr==N-1) ||
    (fsm_interval_st_r == FSM_INTERVAL_CNT && rd_cold_cnt_en && dpram_rd_addr==N-1 && interval_mode_cycles_cnt==reg_perf_time_slot-1'b1)||
    (fsm_interval_st_r==FSM_INTERVAL_DUMP && fsm_interval_st_nxt ==FSM_INTERVAL_IDLE) )
      rd_cold_cnt_en <= 1'b0;      
    else if(fsm_normal_st_r == FSM_NORMAL_CNT || fsm_interval_st_r == FSM_INTERVAL_CNT ||fsm_interval_st_r == FSM_INTERVAL_DUMP && (dpram_rd_addr==N-1) )
      rd_cold_cnt_en <= 1'b1;
  end


  always @(posedge clk or negedge rst_n)begin
    if(~rst_n)
      dpram_wrt_en_pre   <= 1'b0;
    else
      dpram_wrt_en_pre   <= rd_cold_cnt_en;
  end

  always @(posedge clk or negedge rst_n)begin
    if(~rst_n)
      dpram_wrt_addr_pre     <= {N_LOG2{1'b0}};
    else if(clear)
      dpram_wrt_addr_pre    <= {N_LOG2{1'b0}};
    else if(dpram_wrt_en_pre)
      dpram_wrt_addr_pre     <= dpram_wrt_addr_pre + 1'b1;
    else
      dpram_wrt_addr_pre    <= {N_LOG2{1'b0}};
  end

  always @(posedge clk or negedge rst_n)begin
    if(~rst_n)begin
      dpram_wrt_en             <= 1'b0;
      dpram_wrt_addr           <= {N_LOG2{1'b0}};
      rd_dump_cnt_en_normal_d0 <= 1'b0;
      rd_dump_cnt_en_normal_d1 <= 1'b0;
    end
    else begin
      dpram_wrt_en             <= dpram_wrt_en_pre;
      dpram_wrt_addr           <= dpram_wrt_addr_pre;
      rd_dump_cnt_en_normal_d0 <= rd_dump_cnt_en_normal;
      rd_dump_cnt_en_normal_d1 <= rd_dump_cnt_en_normal_d0;
    end
  end

 always @(posedge clk or negedge rst_n)begin
   if(~rst_n)
     dpram_wrt_addr_pulse <= {{N_LOG2+1}{1'b0}};
   else if((!rd_dump_cnt_en_d0&rd_dump_cnt_en) || clear)
     dpram_wrt_addr_pulse <= {{N_LOG2+1}{1'b0}};
   else if(dpram_wrt_addr_pulse == N)
     dpram_wrt_addr_pulse <= dpram_wrt_addr_pulse;
   else if(dpram_wrt_en_pre)
     dpram_wrt_addr_pulse <= dpram_wrt_addr_pulse + 1'b1;
  end
  
  assign first_cnt_num_cycles_wrt = dpram_wrt_en_pre && (dpram_wrt_addr_pulse <= N-1);

  

  assign hot_cnt_en = (rd_cold_cnt_en && (fsm_normal_st_r == FSM_NORMAL_CNT ) ) || 
                      dpram_rd_en && (fsm_interval_st_r == FSM_INTERVAL_CNT || (fsm_interval_st_r == FSM_INTERVAL_DUMP) && (perf_dump_trigger_latch != 2'b11) ||fsm_interval_st_r ==  FSM_INTERVAL_DUMP_WAIT) ;

  assign perf_mon_cnt_time_flag = hot_cnt_en;

  always @(posedge clk or negedge rst_n)begin
    if(~rst_n)
      dpram_wdata  <= 32'b0;
    else if(reg_time_stamp_enable && dpram_wrt_addr_pre=={{N_LOG2}{1'b0}} && dpram_wrt_en_pre)
      dpram_wdata  <= time_stamp_low32bit;
    else if(reg_time_stamp_enable && dpram_wrt_addr_pre== 1 && dpram_wrt_en_pre)
      dpram_wdata  <= time_stamp_high32bit;
    else if(first_cnt_num_cycles_wrt)
      dpram_wdata  <= hot_cnt[dpram_wrt_addr_pre]+{6'b0,perf_event_mux[dpram_wrt_addr_pre]};
    else
      dpram_wdata  <= hot_cnt[dpram_wrt_addr_pre]+{6'b0,perf_event_mux[dpram_wrt_addr_pre]}+cold_cnt;
  end
  
  always @(posedge clk or negedge rst_n)begin
    if(~rst_n)
      rd_dump_cnt_en_normal <= 1'b0;
    else if(fsm_normal_st_r==FSM_NORMAL_DUMP )begin
      if(rd_dump_cnt_en_normal && rd_dump_cnt_normal==N-1)
        rd_dump_cnt_en_normal <= 1'b0;
      else
        rd_dump_cnt_en_normal <= 1'b1;
    end
    else
       rd_dump_cnt_en_normal <= 1'b0; 
  end

  always @(posedge clk or negedge rst_n)begin
    if(~rst_n)
      rd_dump_cnt_normal <= {N_LOG2{1'b0}};
    else if(clear)
      rd_dump_cnt_normal <= {N_LOG2{1'b0}};
    else if(rd_dump_cnt_en_normal)
      rd_dump_cnt_normal <= rd_dump_cnt_normal + 1'b1;
  end

 
 always @(posedge clk or negedge rst_n)begin
    if(~rst_n)
      rd_dump_cnt_en_interval <= 1'b0;
    else if(clear)
      rd_dump_cnt_en_interval <= 1'b0; 
    else if(dpram_rd_addr==N-1 && fsm_interval_st_r == FSM_INTERVAL_DUMP)
      rd_dump_cnt_en_interval <= 1'b0;
    else if((fsm_interval_st_r == FSM_INTERVAL_DUMP_WAIT || (fsm_interval_st_r == FSM_INTERVAL_CNT) && (interval_mode_cycles_cnt == reg_perf_time_slot-1'b1) ) && rd_cold_cnt_en && dpram_rd_addr==N-1)
      rd_dump_cnt_en_interval <= 1'b1;
 end

  assign rd_dump_cnt_en = rd_dump_cnt_en_normal_d1 | rd_dump_cnt_en_interval;
  assign dpram_rd_en   = rd_cold_cnt_en | rd_dump_cnt_en;
  
  always @(posedge clk or negedge rst_n)begin
    if(~rst_n)
      dpram_rd_addr<= {N_LOG2{1'b0}};
    else if(clear)
      dpram_rd_addr<= {N_LOG2{1'b0}};
    else if((fsm_normal_st_r ==FSM_NORMAL_DUMP) && rd_cold_cnt_en)
      dpram_rd_addr<= {N_LOG2{1'b0}};
    else if(fsm_interval_st_r == FSM_INTERVAL_DUMP_WAIT && rd_cold_cnt_en && dpram_rd_addr==N-1)
      dpram_rd_addr<= {N_LOG2{1'b0}};
    else if(dpram_rd_en)
      dpram_rd_addr<= dpram_rd_addr+ 1'b1;
   end

  assign cold_cnt      = dpram_rdata;

 always @(posedge clk or negedge rst_n)begin
    if(~rst_n)
      perf_dump_trigger_latch <= 2'b00;
    else if(clear)
      perf_dump_trigger_latch <= 2'b00;
    else if(|reg_perf_dump_trigger )
      perf_dump_trigger_latch <= reg_perf_dump_trigger; 
 end

  
   always @(posedge clk or negedge rst_n)begin
     if(~rst_n)
       interval_mode_cnt_flag <= 1'b0;
     else if(clear)
       interval_mode_cnt_flag <= 1'b0;
     else if(perf_dump_trigger_latch == 2'b11 && rd_cold_cnt_en && dpram_rd_addr == N-1)
       interval_mode_cnt_flag <= 1'b0;
     else if(fsm_interval_st_r == FSM_INTERVAL_CNT)
       interval_mode_cnt_flag <= 1'b1;
   end

  always @(posedge clk or negedge rst_n)begin
    if(~rst_n)
      interval_mode_cycles_cnt <= 16'b0;
    else if(clear)
      interval_mode_cycles_cnt <= 16'b0;
    else if((interval_mode_cycles_cnt == reg_perf_time_slot -1'b1)||(perf_dump_trigger_latch == 2'b11 && rd_cold_cnt_en && dpram_rd_addr == N-1))
      interval_mode_cycles_cnt <= 16'b0;
    else if(interval_mode_cnt_flag)
      interval_mode_cycles_cnt <= interval_mode_cycles_cnt + 1'b1;
  end


  generate
  if(M_TOTAL==N)begin:EVENT_ALL_ONT_BIT
   always @(posedge clk or negedge rst_n)begin
      if(~rst_n)
        rd_dump_addr <= {{N_LOG2}{1'b0}};
      else if(clear)
        rd_dump_addr <= {{N_LOG2}{1'b0}};
      else if(rd_dump_cnt_en)
        rd_dump_addr <=  rd_dump_addr + 1'b1;
   end
    
    always @(posedge clk or negedge rst_n)begin
      if(~rst_n)begin
        rd_dump_addr_d0    <= {{N_LOG2}{1'b0}}; 
        rd_dump_addr_d1    <= {{N_LOG2}{1'b0}}; 
        rd_dump_addr_d2    <= {{N_LOG2}{1'b0}}; 
        rd_dump_addr_d3    <= {{N_LOG2}{1'b0}}; 
        dpram_rdata_d0     <= 32'b0;
        rd_dump_cnt_en_d0  <= 1'b0;
      end
      else begin
        rd_dump_addr_d0    <= rd_dump_addr; 
        rd_dump_addr_d1    <= rd_dump_addr_d0; 
        rd_dump_addr_d2    <= rd_dump_addr_d1; 
        rd_dump_addr_d3    <= rd_dump_addr_d2; 
        dpram_rdata_d0     <= dpram_rdata;
        rd_dump_cnt_en_d0  <= rd_dump_cnt_en;
      end
   end

   always @(posedge clk or negedge rst_n)begin
      if(~rst_n)
        rdata_patch32bit <= 32'b0;
      else if(rd_dump_addr_d0[0])
        rdata_patch32bit <= {dpram_rdata[15:0],dpram_rdata_d0[15:0]};
   end

  always @(posedge clk or negedge rst_n)begin
   if(~rst_n)
     obuf_wdata <= {{AXI_DATA_WIDTH}{1'b0}};
   else if(rd_dump_addr_d2[0]) 
     obuf_wdata <= {rdata_patch32bit[31:0],obuf_wdata[511:32]};     
  end

  assign obuf_wrten = rd_dump_addr_d3== 6'd31 || rd_dump_addr_d3== 6'd63;
  assign burst_data_num = N*16/512;
 end
 else
 begin:EVENT_NOT_ALL_ONE_BIT
   always @(posedge clk or negedge rst_n)begin
    if(~rst_n)begin
      rd_dump_cnt_en_d0        <= 1'b0;
      rd_dump_cnt_en_d0_cnt_d0 <= 4'b0;
    end
    else begin
      rd_dump_cnt_en_d0        <= rd_dump_cnt_en;
      rd_dump_cnt_en_d0_cnt_d0 <= rd_dump_cnt_en_d0_cnt;
    end
  end
  
  always @(posedge clk or negedge rst_n)begin
    if(~rst_n)
      rd_dump_cnt_en_d0_cnt <= 4'b0;
    else if(clear)
      rd_dump_cnt_en_d0_cnt <= 4'b0;
    else if(rd_dump_cnt_en_d0)
      rd_dump_cnt_en_d0_cnt <= rd_dump_cnt_en_d0_cnt + 1'b1;
  end


 always @(posedge clk or negedge rst_n)begin
   if(~rst_n)
     obuf_wdata <= {{AXI_DATA_WIDTH}{1'b0}};
   else if(rd_dump_cnt_en_d0) 
     obuf_wdata <= {dpram_rdata[31:0],obuf_wdata[511:32]};     
 end

 assign obuf_wrten = rd_dump_cnt_en_d0_cnt_d0 == 4'd15;
 assign burst_data_num = N*32/512;

 end
 endgenerate

 always @(posedge clk or negedge rst_n)begin
   if(~rst_n)
     obuf_rd_en_cnt <= 2'b0;
   else if(obuf_rd_en && (obuf_rd_en_cnt == burst_data_num - 1))
     obuf_rd_en_cnt <= 2'b0;
   else if(obuf_rd_en)
     obuf_rd_en_cnt <= obuf_rd_en_cnt + 1'b1;
 end

 
 always @(posedge clk or negedge rst_n)begin
   if(~rst_n)
     obuf_rd_flag_temp <= 1'b0;
   else if(obuf_rd_en && (obuf_rd_en_cnt == burst_data_num - 1))
     obuf_rd_flag_temp <= 1'b0;
   else if(obuf_rd_en)
     obuf_rd_flag_temp <= 1'b1;
 end
 always @(posedge clk or negedge rst_n)begin
   if(~rst_n)
     obuf_rd_en_d0 <= 1'b0;
   else
     obuf_rd_en_d0 <= obuf_rd_en;
 end

 assign obuf_rd_flag = obuf_rd_flag_temp || (!obuf_rd_en_d0 & obuf_rd_en);
 
 always @(posedge clk or negedge rst_n)begin
   if(~rst_n)
     obuf_wrt_in_rd_flag <= 1'b0;
   else if(obuf_wrten && (obuf_wrten_cnt == burst_data_num - 1))
     obuf_wrt_in_rd_flag <= 1'b0;
   else if(obuf_rd_flag && obuf_wrten )
     obuf_wrt_in_rd_flag <= 1'b1;
 end

 assign obuf_wrt_en_disable = obuf_rd_flag || obuf_wrt_in_rd_flag;
 assign obuf_wrten_true = obuf_wrt_en_disable ? 1'b0 : obuf_wrten;


  //-------------
  //---obuf with axi/bif_trans---------------
  //assign total_valid_data_cycle = 2'd3;//assign total_valid_data_cycle = 2'd1;

  always @(posedge clk or negedge rst_n)begin
   if(~rst_n)
     obuf_wrten_cnt <= 2'b0;
   else if(clear)
     obuf_wrten_cnt <= 2'b0;
   else if(obuf_wrten)begin
     if(obuf_wrten_cnt == (burst_data_num -1'b1))
       obuf_wrten_cnt <= 2'b0;
     else
       obuf_wrten_cnt <= obuf_wrten_cnt + 1'b1;
   end
 end

  always @(posedge clk or negedge rst_n)begin
   if(~rst_n)
     obuf_data_valid <= 1'b0;
   else if(obuf_empty || clear)
     obuf_data_valid <= 1'b0; 
   else if(obuf_wrten_cnt == (burst_data_num -1'b1) && obuf_wrten)
     obuf_data_valid <= 1'b1;
 end

  assign obuf_rd_en = obuf_data_valid&obuf_data_ready;

  assign memory_base_addr = reg_perf_base_addr + num_id*{N,2'b00};
  assign new_session_start = (reg_normal_mode_start || reg_perf_dump_trigger == 2'b10)&reg_perf_enable;
  assign addr_offset = {M_N*N,2'b00}; 
//-----------------------------------------------------------------------------------------
//---------perf_mon dump status---------------------------
 
  assign perf_mon_done_temp = perf_mon_bif_rtn_fence & perf_mon_bif_rtn_valid & perf_mon_bif_rtn_enable;
  assign perf_mon_done = perf_mon_bif_rtn_fence & perf_mon_bif_rtn_valid & perf_mon_bif_rtn_enable &  (!perf_mon_done_fake);


   always @(posedge clk or negedge rst_n)begin
    if(~rst_n)
      new_session_start_d0  <= 1'b0;
    else 
      new_session_start_d0  <= new_session_start;
  end

  always @(posedge clk or negedge rst_n)begin
    if(~rst_n)
      perf_mon_done_cnt <= 24'b0;
    else if(new_session_start_d0)
      perf_mon_done_cnt <= 24'b0;
    else if(perf_mon_done)
      perf_mon_done_cnt <= perf_mon_done_cnt + 1'b1;
  end

 always @(posedge clk or negedge rst_n)begin
    if(~rst_n)
      perf_mon_done_cnt_temp <= 24'b0;
    else if(new_session_start_d0)
      perf_mon_done_cnt_temp <= 24'b0;
    else if(perf_mon_done_temp)
      perf_mon_done_cnt_temp <= perf_mon_done_cnt_temp + 1'b1;
  end

  
  assign perf_mon_fail = (reg_normal_mode_start || reg_perf_dump_trigger==2'b10) && (perf_mon_done_cnt != perf_mon_bif_fence_times);

   always @(posedge clk or negedge rst_n)begin
     if(~rst_n)
       fence_rep_lack <= 11'b0;
     else if((perf_mon_done_cnt_temp == fence_rep_lack) && perf_mon_done_fake)
       fence_rep_lack <= 11'b0;
     else if(perf_mon_fail)
       fence_rep_lack <= perf_mon_bif_fence_times - perf_mon_done_cnt;
   end

   always @(posedge clk or negedge rst_n)begin
     if(~rst_n)
       perf_mon_done_fake <= 1'b0;
     else if((perf_mon_done_cnt_temp == fence_rep_lack) && perf_mon_done_fake)
       perf_mon_done_fake <= 1'b0;
     else if(perf_mon_fail)
       perf_mon_done_fake <= 1'b1;
   end


  assign perf_mon_obuf_overflow = obuf_wrt_in_rd_flag;

  assign signal_perf_mon_size = reg_perf_space_size/M_N;

  always @(posedge clk or negedge rst_n)begin
    if(~rst_n)
      reg_perf_wrap_addr_cnt<= 2'b0;
    else if(clear)
      reg_perf_wrap_addr_cnt<= 2'b0;
    else if(perf_mon_bif_cmd_valid & perf_mon_bif_cmd_enable && (perf_mon_bif_cmd_vaddress + {M_N,8'b0}) >= memory_base_addr+signal_perf_mon_size)
      reg_perf_wrap_addr_cnt<= reg_perf_wrap_addr_cnt+ 1'b1;
  end

//------------------------
//submodule instantation-------------
 generate 
    for(i=0;i<=N-1;i=i+1)begin:gen_hot_cnt_clear
      assign hot_cnt_clear[i] = dpram_wrt_en_pre & dpram_wrt_addr_pre==i;
    end
  endgenerate

  generate 
    for(i=0;i<=N-1;i=i+1)begin:gen_hot_cnt
       hot_counter #(.M(W[i]+W_ADD)) 
       u_hot_counter(
        .clk(clk),
        .rst_n(rst_n),
        .perf_event(perf_event[(M_P[i]+W[i]-1'b1):M_P[i]]),
        .hot_cnt_en(hot_cnt_en),
        .hot_cnt(hot_cnt[i]),
        .clear(hot_cnt_clear[i] |new_session_start),
        .perf_event_o(perf_event_mux[i])
       );
      
     end
  endgenerate

 mem_1r1w_flops
          #(.MEM_WORDS(N), .MEM_WIDTH(32), .MEM_BIT_EN(1'b0), .L2_MEM_WORDS(N_LOG2)) 
          u_gc_perf_mon_ram (
          .wr_clk(clk),
          .wr_en(dpram_wrt_en),
          .wr_addr(dpram_wrt_addr),
          .bit_en_internal({32{1'b0}}),
          .din(dpram_wdata),
          .rd_clk(clk),
          .rd_en(dpram_rd_en),
          .rd_addr(dpram_rd_addr),
          .dout_internal(dpram_rdata)
          );

gp_fifo #(
      .WIDTH(AXI_DATA_WIDTH),
      .FIFO_WORDS(OBUF_DEPTH)//AXI_ID_WIDTH)  
        
     ) u_gc_perf_mon_obuf(
     
       .clk                 (clk),
       .reset_n             (rst_n),
       .init                (clear),
       
       .rd_en               (obuf_rd_en),
       .dout                (obuf_rdata),
    
       .wr_en               (obuf_wrten_true),
       .din                 (obuf_wdata),
       
       .aempty              (),
       .afull               (), 
       .empty               (obuf_empty),
       .full                (),
       .overflow            (obuf_overflow),
       .underflow           (),
       .valid_entries       ()    
     );


  gc_perf_mon_bif_trans u_gc_perf_mon_bif_trans(
  .clk(clk),
  .rst_n(rst_n),
  .memory_base_addr(memory_base_addr),
  .addr_offset(addr_offset),
  .clear(clear),
  .burst_data_num(burst_data_num),
  .perf_dump_trigger_latch(perf_dump_trigger_latch),
  .perf_mon_bif_fence_times(perf_mon_bif_fence_times),
  .perf_mon_last_dump_times(perf_mon_last_dump_times),
  .obuf_data_valid(obuf_data_valid),
  .obuf_data_ready(obuf_data_ready),
  .obuf_rdata(obuf_rdata),
  .reg_bif_cmd_persistence(reg_bif_cmd_persistence),
  .reg_bif_cmd_ctxt_pasid(reg_bif_cmd_ctxt_pasid),
  .reg_bif_cmd_gpu_pipe_coherent(reg_bif_cmd_gpu_pipe_coherent),
  .reg_bif_cmd_mss_cache_policy(reg_bif_cmd_mss_cache_policy),
  .perf_mon_bif_cmd_valid(perf_mon_bif_cmd_valid),
  .perf_mon_bif_cmd_enable(perf_mon_bif_cmd_enable),
  .perf_mon_bif_cmd_operation(perf_mon_bif_cmd_operation),
  .perf_mon_bif_cmd_persistence(perf_mon_bif_cmd_persistence),
  .perf_mon_bif_cmd_ctxt_pasid(perf_mon_bif_cmd_ctxt_pasid),
  .perf_mon_bif_cmd_gpu_pipe_coherent(perf_mon_bif_cmd_gpu_pipe_coherent),
  .perf_mon_bif_cmd_mss_cache_policy(perf_mon_bif_cmd_mss_cache_policy),
  .perf_mon_bif_cmd_fbcdc_compress(perf_mon_bif_cmd_fbcdc_compress),
  .perf_mon_bif_cmd_fbcdc_clear(perf_mon_bif_cmd_fbcdc_clear),
  .perf_mon_bif_cmd_fbcdc_onedge(perf_mon_bif_cmd_fbcdc_onedge),
  .perf_mon_bif_cmd_vaddress(perf_mon_bif_cmd_vaddress),
  .perf_mon_bif_cmd_burst_length(perf_mon_bif_cmd_burst_length),
  .perf_mon_bif_cmd_tag_sb(perf_mon_bif_cmd_tag_sb),
  .perf_mon_bif_write_valid(perf_mon_bif_write_valid),
  .perf_mon_bif_write_enable(perf_mon_bif_write_enable),
  .perf_mon_bif_write_mask(perf_mon_bif_write_mask),
  .perf_mon_bif_write_data(perf_mon_bif_write_data),
  .perf_mon_bif_rtn_valid(perf_mon_bif_rtn_valid),
  .perf_mon_bif_rtn_enable(perf_mon_bif_rtn_enable),
  .perf_mon_bif_rtn_credit(perf_mon_bif_rtn_credit),
  .perf_mon_bif_rtn_fence(perf_mon_bif_rtn_fence),
  .perf_mon_bif_rtn_data(perf_mon_bif_rtn_data),
  .perf_mon_bif_rtn_tag_sb(perf_mon_bif_rtn_tag_sb),
  .reg_fence_interval(reg_fence_interval)
    );


endmodule
