
-- #==========================================================================#
-- |                                                                          |
-- |  Copyright (c) 2022, Fantasy Technologies Limited and/or its         |
-- |  affiliated group companies ("Fantasy"). All rights reserved.        |
-- |  No part of this content, either material or conceptual may be copied    |
-- |  or distributed, transmitted, transcribed, stored in a retrieval system  |
-- |  or translated into any human or computer language in any form by any    |
-- |  means, electronic, mechanical manual, or otherwise, or disclosed to     |
-- |  third parties without the express written permission of Fantasy.    |
-- |                                                                          |
-- #==========================================================================#



library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
library work;





package gc_features_pack is
   
   constant AXIBUS                          : boolean                                       := true;
   constant AXIBUS_SOCIF                    : boolean                                       := true;
   constant AXIBUS_SOCIF_ADDR_WIDTH         : natural                                       := 32;
   constant AXIBUS_SOCIF_DATA_WIDTH         : natural                                       := 32;
   constant AXIBUS_SOCIF_RD_FIFO_DEPTH      : natural                                       := 64;
   constant AXIBUS_SOCIF_RD_FIFO_DEPTH_LOG2 : natural                                       := 6;
   constant AXIBUS_SOCIF_RRESP_FIFO_DEPTH   : natural                                       := 64;
   constant AXIBUS_SOCIF_TAGSB_WIDTH        : natural                                       := 4;
   constant AXIBUS_SOCIF_WRESP_FIFO_DEPTH   : natural                                       := 64;
   
   constant BUSWIDTH                        : natural                                       := 512;
   constant BUSWIDTH256                     : boolean                                       := true;
   constant BUSWIDTH_LOG2                   : natural                                       := 9;
   constant BUSWIDTH_WIDTH                  : natural                                       := 9;
   
   constant CFG_PDS_NUM_HS_SPILL_IDS        : natural                                       := 20;
   
   constant CFG_CU_AF32COMPLEX_PARALLEL_INSTANCES: natural                                       := 32;
   constant CFG_CU_ATTRIBUTE_ALLOC_GRANULARITY_DWORDS: natural                                       := 2;
   constant CFG_CU_INTERNAL_DWORDS         : natural                                       := 2;
   constant CFG_CU_LOCAL_ALLOC_GRANULARITY_DWORDS: natural                                       := 16;
   constant CFG_CU_MAX_TASKS_PER_WORKGROUP : natural                                       := 8;
   constant CFG_CU_MAX_TASKS_PER_WORKGROUP_LOG2: natural                                       := 3;
   constant CFG_CU_MAX_TASKS_PER_WORKGROUP_WIDTH: natural                                       := 3;
   constant CFG_CU_MEM_US_INSTANCE_WIDTH   : natural                                       := 8;
   constant CFG_CU_MEM_US_INSTANCE_WIDTH_LOG2: natural                                       := 3;
   constant CFG_CU_MEM_US_INSTANCE_WIDTH_WIDTH: natural                                       := 3;
   
   constant CFG_CU_TAP_PARALLEL_INSTANCES  : natural                                       := 8;
   constant CFG_CU_TAP_PARALLEL_INSTANCES_LOG2: natural                                       := 3;
   constant CFG_CU_TAP_PARALLEL_INSTANCES_WIDTH: natural                                       := 3;
   
   constant CLUSTERS                        : natural                                       := 32; --GP3:4gpc*4spc*4cu, 64; G3:10SPC*3CU, 30; --ori:6; 4spc+2cu: 8; 4spc+3cu:12
   constant CLUSTERS_LOG2                   : natural                                       := 5; --GP3:4gpc*4spc*4cu, 6; G3:10SPC*3CU, 5 -- 4spc+3cu: 3
   constant CLUSTERS_PER_PBE                : natural                                       := 1;
   constant CLUSTERS_PER_PBE_LOG2           : natural                                       := 0;
   constant CLUSTERS_PER_PBE_WIDTH          : natural                                       := 1;
   constant CLUSTERS_WIDTH                  : natural                                       := 4; --GP3:4gpc*4spc*4cu, 6; G3:10SPC*3CU,5 -- 4spc+3cu: 3
   constant COMPUTE                         : boolean                                       := true;
   constant COMPUTE_MSS_MMU_AUTO_CACHE_OPS  : boolean                                       := true;
   
   constant ECC_RAMS                        : natural                                       := 0;
   constant ECC_RAMS_LOG2                   : natural                                       := 0;
   constant ECC_RAMS_WIDTH                  : natural                                       := 1;
   
   constant FBCDC                           : natural                                       := 5;
   constant GPIO                            : boolean                                       := true;
   constant GPU                             : boolean                                       := true;
   constant GPU_VIRTUALISATION              : boolean                                       := true;
   constant GPU_VIRTUALISATION_NUM_OS       : natural                                       := 16;
   constant GPU_VIRTUALISATION_NUM_OS_LOG2  : natural                                       := 4;
   constant GPU_VIRTUALISATION_NUM_OS_WIDTH : natural                                       := 4;
   
   constant ISP_SAMPLES_PER_PIXEL           : natural                                       := 2;
   constant ISP_SAMPLES_PER_PIXEL_LOG2      : natural                                       := 1;
   constant ISP_SAMPLES_PER_PIXEL_WIDTH     : natural                                       := 1;
   
   
   constant MAX_CLUSTERS                    : natural                                       := 32;--In GP3:4GPC*2SPC*4CU, 32
   constant MAX_CLUSTERS_LOG2               : natural                                       := 5;
   constant MAX_CLUSTERS_PER_SPC            : natural                                       := 4; --In GP3:4GPC*2SPC*4CU,4CU3; G3:3
   constant MAX_CLUSTERS_PER_SPC_LOG2       : natural                                       := 2; -- ori: 1
   constant MAX_CLUSTERS_PER_SPC_WIDTH      : natural                                       := 2; -- ori: 1
   constant MAX_CLUSTERS_PER_TPU            : natural                                       := 1;
   constant MAX_CLUSTERS_PER_TPU_LOG2       : natural                                       := 0;
   constant MAX_CLUSTERS_PER_TPU_WIDTH      : natural                                       := 1;
   constant MAX_CLUSTERS_WIDTH              : natural                                       := 7;
   constant GPC_WIDTH                       : natural                                       := 2;
   constant SPC_WIDTH                       : natural                                       := 1;
   constant MAX_INSTANCES_PER_PDS_TASK      : natural                                       := 128;
   constant MAX_INSTANCES_PER_PDS_TASK_LOG2 : natural                                       := 7;
   constant MAX_INSTANCES_PER_PDS_TASK_WIDTH: natural                                       := 7;
   constant MAX_MULTISAMPLE                 : natural                                       := 8;
   constant MAX_MULTISAMPLE_LOG2            : natural                                       := 3;
   constant MAX_MULTISAMPLE_WIDTH           : natural                                       := 3;
   
   constant MAX_POUT_PER_TILE               : natural                                       := 8;
   constant MAX_POUT_PER_TILE_LOG2          : natural                                       := 3;
   constant MAX_POUT_PER_TILE_WIDTH         : natural                                       := 3;
   
   constant MAX_TPU_PER_SPC                 : natural                                       := 0;--GP3: NO TPU;G3:2;
   constant MAX_TPU_PER_SPC_LOG2            : natural                                       := 1;
   constant MAX_TPU_PER_SPC_WIDTH           : natural                                       := 1;
   
   constant MCUSIZE                         : natural                                       := 24;
   constant MCUSIZE_LOG2                    : natural                                       := 5;
   constant MCUSIZE_WIDTH                   : natural                                       := 5;
   
   constant FWP                            : string                                        := "MTP219";
   constant FWP_COREMEM_BANKS              : natural                                       := 8;
   constant FWP_COREMEM_BANKS_LOG2         : natural                                       := 3;
   constant FWP_COREMEM_BANKS_WIDTH        : natural                                       := 3;
   constant FWP_COREMEM_SIZE               : natural                                       := 96;
   constant FWP_COREMEM_SIZE_LOG2          : natural                                       := 7;
   constant FWP_COREMEM_SIZE_WIDTH         : natural                                       := 7;
   constant FWP_DMA                        : boolean                                       := true;
   constant FWP_DMA_CHANNEL_COUNT          : natural                                       := 4;
   constant FWP_DMA_CHANNEL_COUNT_LOG2     : natural                                       := 2;
   constant FWP_DMA_CHANNEL_COUNT_WIDTH    : natural                                       := 2;
   constant FWP_DMA_REGISTER_PROGRAMMER    : boolean                                       := true;
   constant FWP_DMA_WRITE                  : boolean                                       := true;
   constant FWP_MTP                        : natural                                       := 219;
   constant FWP_MTP219                     : boolean                                       := true;
   constant FWP_MTP_LOG2                   : natural                                       := 8;
   constant FWP_MTP_WIDTH                  : natural                                       := 8;
   constant FWP_REGISTER_UNPACKED_ACCESSES : boolean                                       := true;
   constant MFU                             : boolean                                       := true;
   constant MH_CTXT_PASID_WIDTH             : natural                                       := 6;--by wuchengen 20250207, In GP3: 6; G3:8
   constant MH_CTXT_PASID_WIDTH_LOG2        : natural                                       := 3;
   constant MH_CTXT_PASID_WIDTH_WIDTH       : natural                                       := 3;
   constant MH_DEBUG_ID_WIDTH               : natural                                       := 32;
   constant MH_DEBUG_ID_WIDTH_LOG2          : natural                                       := 5;
   constant MH_DEBUG_ID_WIDTH_WIDTH         : natural                                       := 5;
   
  
   constant MSAA_2X_FULL_RATE               : boolean                                       := true;
   constant MTP_BGTHREAD                    : natural                                       := 4;
   constant MTP_BGTHREAD4                   : boolean                                       := true;
   constant MTP_BGTHREAD_LOG2               : natural                                       := 2;
   constant MTP_BGTHREAD_WIDTH              : natural                                       := 2;
   constant MULTICORE_MAX_GPUS              : natural                                       := 8;
   constant MULTICORE_MAX_GPUS_LOG2         : natural                                       := 3;
   constant MULTICORE_MAX_GPUS_WIDTH        : natural                                       := 3;
   
   constant NUM_AXIBUS_PER_CHEST            : natural                                       := 2;           -- by zhujt at 20240109, for DDR Expand
   constant NUM_AXIBUS_PER_CHEST_LOG2       : natural                                       := 1;           -- by zhujt at 20240109, for DDR Expand
   constant NUM_AXIBUS_PER_CHEST_BITS       : natural                                       := 1;           -- by zhujt at 20240109, for DDR Expand
   
   constant NUM_SPC                         : natural                                       := 8;--GP3: 4GPC*4SPC*4CU; G3:10SPC*3CU,10
   constant NUM_SPC_LOG2                    : natural                                       := 3;--GP3: 4GPC*4SPC*4CU; G3:10SPC*3CU,4
   constant NUM_SPC_WIDTH                   : natural                                       := 3;--GP3: 4GPC*4SPC*4CU; G3:10SPC*3CU,4
   constant NUM_TA                          : natural                                       := 1;
   constant NUM_TA_LOG2                     : natural                                       := 0;
   constant NUM_TA_WIDTH                    : natural                                       := 1;
   
   constant REGBANK_ADDR_WIDTH              : natural                                       := 17;
   constant REGBANK_ADDR_WIDTH_LOG2         : natural                                       := 5;
   constant REGBANK_ADDR_WIDTH_WIDTH        : natural                                       := 5;
   
   constant RESYNC                          : natural                                       := 4;
   constant ROGUE                           : natural                                       := 2;
   constant RTE                             : boolean                                       := true;
   
   constant MSS_SIZE_ADJUSTMENT             : natural                                       := 3;         -- by luqj at 20230222, for 8M mss bank, 0 -> 3
   constant MSS_SIZE_ADJUSTMENT_LOG2        : natural                                       := 2;         -- by luqj at 20230222, for 8M mss bank, 0 -> 2
   constant MSS_SIZE_ADJUSTMENT_WIDTH       : natural                                       := 2;         -- by luqj at 20230222, for 8m MSS BANK, 0 -> 2
   
   constant SLOTS                           : natural                                       := 32;--GP3:4GPC*4SPC*4CU,24->32 slot per EU; G3:48
   constant SLOTS_LOG2                      : natural                                       := 5; --GP3:4GPC*4SPC*4CU,24->32 slot per EU; G3:6
   constant SLOTS_WIDTH                     : natural                                       := 5; --GP3:4GPC*4SPC*4CU,24->32 slot per EU; G3:6
   constant SOC_TIMER                       : boolean                                       := true;
   
   constant SPC_ARCH_CLOCK_GATING           : boolean                                       := true;
   constant SPC_ARCH_CLOCK_GATING_VERSION   : natural                                       := 2;
   constant SPC_ARCH_CLOCK_GATING_VERSION_LOG2: natural                                     := 1;
   constant SPC_ARCH_CLOCK_GATING_VERSION_WIDTH: natural                                    := 1;
   
   constant TILE_IDS                        : natural                                       := 12;
   constant TILE_IDS_2D                     : natural                                       := 8;
   constant TILE_IDS_2D_LOG2                : natural                                       := 3;
   constant TILE_IDS_2D_WIDTH               : natural                                       := 3;
   constant TILE_IDS_LOG2                   : natural                                       := 4;
   constant TILE_IDS_WIDTH                  : natural                                       := 4;
   constant TILE_SIZE_X                     : natural                                       := 32;
   constant TILE_SIZE_X_LOG2                : natural                                       := 5;
   constant TILE_SIZE_X_WIDTH               : natural                                       := 5;
   constant TILE_SIZE_Y                     : natural                                       := 32;
   constant TILE_SIZE_Y_LOG2                : natural                                       := 5;
   constant TILE_SIZE_Y_WIDTH               : natural                                       := 5;
   
   constant TPU_PARALLEL_INSTANCES          : natural                                       := 8;
   constant TPU_PARALLEL_INSTANCES_LOG2     : natural                                       := 3;
   constant TPU_PARALLEL_INSTANCES_WIDTH    : natural                                       := 3;

   constant CU_NUM_TASKS                   : natural                                       := 64; --61->64 for GP3
   constant CU_NUM_TASKS_LOG2              : natural                                       := 6;
   constant CU_NUM_TASKS_WIDTH             : natural                                       := 6;
   constant CU_OLCHK_USER_MASK_BITS        : natural                                       := 8;
   constant CU_OLCHK_USER_MASK_BITS_LOG2   : natural                                       := 3;
   constant CU_OLCHK_USER_MASK_BITS_WIDTH  : natural                                       := 3;
   
   constant CU_PSB_PARALLEL_INSTANCES      : natural                                       := 8;
     
   constant UVB_NUM_TASKS                  : natural                                       := 64;
   constant UVB_NUM_TASKS_LOG2             : natural                                       := 6;
   constant UVB_NUM_TASKS_WIDTH            : natural                                       := 6;
   --constant MUTEX_BITS                     : natural                                       := 4;
   --constant MUTEX_NUM                      : natural                                       := 16;
   
--CP CE common

   constant MMU_TBU_SLOT_ID_WIDTH          : natural                                       := 6;
   constant MMU_PASID_WIDTH                : natural                                       := 10;
   constant MMU_VFID_WIDTH                 : natural                                       := 4;
   constant MMU_VF_PAS_ID_WIDTH            : natural                                       := 10;
   constant MMU_VPAGE_WIDTH                : natural                                       := 36;
   constant MMU_TG_WIDTH                   : natural                                       := 2;
   constant MMU_TCU_SLOT_ID_WIDTH          : natural                                       := 6;
   constant MMU_TRANS_SIZE_WIDTH           : natural                                       := 4;
   constant MMU_INVAL_SIZE_WIDTH           : natural                                       := 4;
   constant MMU_PPAGE_WIDTH                : natural                                       := 37;
   constant MMU_INV_TYPE_WIDTH             : natural                                       := 2;
   constant MMU_TYPE_WIDTH                 : natural                                       := 2;
   constant MMU_TTL_WIDTH                  : natural                                       := 2;
   constant MMU_NUM_WIDTH                  : natural                                       := 5;
   constant MMU_SCALE_WIDTH                : natural                                       := 5;
   constant MMU_ATTR_WIDTH                 : natural                                       := 4;
   constant MMU_AC_ID_WIDTH                : natural                                       := 7;
   constant MMU_VF_NUM_WIDTH               : natural                                       := 4;
   constant MMU_VF_HZD_MODE_WIDTH          : natural                                       := 4;
   constant EVENT_ID_BITS                  : natural                                       := 12;
   constant CE_QUEUE_NUM                   : natural                                       := 8;
   constant MMU_LEAF_WIDTH                 : natural                                       := 1;
   constant MMU_CMD_NUM_WIDTH              : natural                                       := 5;
   constant MMU_VPAGE_ADDR_WIDTH           : natural                                       := 36;
   constant MMU_REQ_NUM_WIDTH              : natural                                       := 10;
   constant MMU_PAGE_STRIDE_WIDTH          : natural                                       := 4;
--end cp ce common


end package gc_features_pack;

package body gc_features_pack is

end package body gc_features_pack;
