
-- #==========================================================================#
-- |                                                                          |
-- |  Copyright (c) 2022, Fantasy Technologies Limited and/or its         |
-- |  affiliated group companies ("Fantasy"). All rights reserved.        |
-- |  No part of this content, either material or conceptual may be copied    |
-- |  or distributed, transmitted, transcribed, stored in a retrieval system  |
-- |  or translated into any human or computer language in any form by any    |
-- |  means, electronic, mechanical manual, or otherwise, or disclosed to     |
-- |  third parties without the express written permission of Fantasy.    |
-- |                                                                          |
-- #==========================================================================#



library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
library work;





package pkg_multicore is

   constant GPU_CORE_ID_WIDTH               : natural                                       := 3;
   constant GPU_PRIMARY_CORE_ID_WIDTH       : natural                                       := 24;
   constant GPU_COUNT_WIDTH                 : natural                                       := 4;
   constant GPU_OFFSET_WIDTH                : natural                                       := 3;


end package pkg_multicore;

package body pkg_multicore is

end package body pkg_multicore;