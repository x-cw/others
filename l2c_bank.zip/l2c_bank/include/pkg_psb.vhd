
-- #==========================================================================#
-- |                                                                          |
-- |  Copyright (c) 2022, Fantasy Technologies Limited and/or its         |
-- |  affiliated group companies ("Fantasy"). All rights reserved.        |
-- |  No part of this content, either material or conceptual may be copied    |
-- |  or distributed, transmitted, transcribed, stored in a retrieval system  |
-- |  or translated into any human or computer language in any form by any    |
-- |  means, electronic, mechanical manual, or otherwise, or disclosed to     |
-- |  third parties without the express written permission of Fantasy.    |
-- |                                                                          |
-- #==========================================================================#



library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
library work;





package pkg_psb is

   constant NUM_CLUSTERS                    : natural                                       := 4; --ori 2
   constant CLUSTER_BITS                    : natural                                       := 2; --ori 1
   constant PSB_NUM_PARTITIONS              : natural                                       := 16;
   constant PSB_PARTITION_BITS              : natural                                       := 4;
   constant PSB_NUM_BANKS                   : natural                                       := 8;
   constant DWORD                           : natural                                       := 32;
   constant PSB_PS_BANK_WIDTH               : natural                                       := 256;
   constant PSB_PS_BANK_ADDR_BITS           : natural                                       := 11; -- ori: 10
   constant PSB_NUM_BANK_BITS               : natural                                       := 3;
   constant PSB_MAX_BLOCK_COUNT             : natural                                       := 32;
   constant PSB_BLOCK_COUNT_BITS            : natural                                       := 5;
   constant PSB_EC_BLOCKS_PER_ENTRY         : natural                                       := 4;
   constant PSB_EC_BLOCKS_PER_ENTRY_BITS    : natural                                       := 2;
   constant PSB_EC_WORD                     : natural                                       := 5;
   constant PSB_EC_DEPTH                    : natural                                       := 512; -- ori: 256
   constant PSB_EC_WIDTH                    : natural                                       := 20;
   constant PSB_EC_ADDR_BITS                : natural                                       := 9; -- ori:8
   constant LK_INDEX_BITS                   : natural                                       := 6; -- ori: 5

   ----------------------------------------------------------------------------------------------------------------------------------
   --   Enumerators
   ----------------------------------------------------------------------------------------------------------------------------------
   attribute enum_encoding : string;

   type t_blend_alu_factor_enum is (
      ZERO                 , -- 0000
      ONE                  , -- 0001
      SRC_ALPHA_SATURATE   , -- 0010
      RESERVED             , -- 0011
      SRC_COLOUR           , -- 0100
      ONEMINUS_SRC_COLOUR  , -- 0101
      SRC_ALPHA            , -- 0110
      ONEMINUS_SRC_ALPHA   , -- 0111
      DST_COLOUR           , -- 1000
      ONEMINUS_DST_COLOUR  , -- 1001
      DST_ALPHA            , -- 1010
      ONEMINUS_DST_ALPHA   , -- 1011
      CONST_COLOUR         , -- 1100
      ONEMINUS_CONST_COLOUR, -- 1101
      CONST_ALPHA          , -- 1110
      ONEMINUS_CONST_ALPHA   -- 1111
   );
   attribute enum_encoding of t_blend_alu_factor_enum : type is "0000 0001 0010 0011 0100 0101 0110 0111 1000 1001 1010 1011 1100 1101 1110 1111";
   constant BLEND_ALU_FACTOR_ENUM_ZERO                  : std_logic_vector(3 downto 0) := "0000";
   constant BLEND_ALU_FACTOR_ENUM_ONE                   : std_logic_vector(3 downto 0) := "0001";
   constant BLEND_ALU_FACTOR_ENUM_SRC_ALPHA_SATURATE    : std_logic_vector(3 downto 0) := "0010";
   constant BLEND_ALU_FACTOR_ENUM_RESERVED              : std_logic_vector(3 downto 0) := "0011";
   constant BLEND_ALU_FACTOR_ENUM_SRC_COLOUR            : std_logic_vector(3 downto 0) := "0100";
   constant BLEND_ALU_FACTOR_ENUM_ONEMINUS_SRC_COLOUR   : std_logic_vector(3 downto 0) := "0101";
   constant BLEND_ALU_FACTOR_ENUM_SRC_ALPHA             : std_logic_vector(3 downto 0) := "0110";
   constant BLEND_ALU_FACTOR_ENUM_ONEMINUS_SRC_ALPHA    : std_logic_vector(3 downto 0) := "0111";
   constant BLEND_ALU_FACTOR_ENUM_DST_COLOUR            : std_logic_vector(3 downto 0) := "1000";
   constant BLEND_ALU_FACTOR_ENUM_ONEMINUS_DST_COLOUR   : std_logic_vector(3 downto 0) := "1001";
   constant BLEND_ALU_FACTOR_ENUM_DST_ALPHA             : std_logic_vector(3 downto 0) := "1010";
   constant BLEND_ALU_FACTOR_ENUM_ONEMINUS_DST_ALPHA    : std_logic_vector(3 downto 0) := "1011";
   constant BLEND_ALU_FACTOR_ENUM_CONST_COLOUR          : std_logic_vector(3 downto 0) := "1100";
   constant BLEND_ALU_FACTOR_ENUM_ONEMINUS_CONST_COLOUR : std_logic_vector(3 downto 0) := "1101";
   constant BLEND_ALU_FACTOR_ENUM_CONST_ALPHA           : std_logic_vector(3 downto 0) := "1110";
   constant BLEND_ALU_FACTOR_ENUM_ONEMINUS_CONST_ALPHA  : std_logic_vector(3 downto 0) := "1111";

   function to_slv(i : t_blend_alu_factor_enum ) return std_logic_vector;
   function to_t_blend_alu_factor_enum(i : std_logic_vector(3 downto 0)) return t_blend_alu_factor_enum;

   type t_blend_alu_blop_enum is (
      BLOP_SUB , -- 000
      BLOP_RSUB, -- 001
      BLOP_MIN , -- 010
      BLOP_MAX , -- 011
      BLOP_ADD   -- 100
   );
   attribute enum_encoding of t_blend_alu_blop_enum : type is "000 001 010 011 100";
   constant BLEND_ALU_BLOP_ENUM_BLOP_SUB  : std_logic_vector(2 downto 0) := "000";
   constant BLEND_ALU_BLOP_ENUM_BLOP_RSUB : std_logic_vector(2 downto 0) := "001";
   constant BLEND_ALU_BLOP_ENUM_BLOP_MIN  : std_logic_vector(2 downto 0) := "010";
   constant BLEND_ALU_BLOP_ENUM_BLOP_MAX  : std_logic_vector(2 downto 0) := "011";
   constant BLEND_ALU_BLOP_ENUM_BLOP_ADD  : std_logic_vector(2 downto 0) := "100";

   function to_slv(i : t_blend_alu_blop_enum ) return std_logic_vector;
   function to_t_blend_alu_blop_enum(i : std_logic_vector(2 downto 0)) return t_blend_alu_blop_enum;

   type t_blend_alu_format_enum is (
      BLOP_FLOAT16, -- 0
      BLOP_USIGN8   -- 1
   );
   attribute enum_encoding of t_blend_alu_format_enum : type is "0 1";
   constant BLEND_ALU_FORMAT_ENUM_BLOP_FLOAT16 : std_logic_vector(0 downto 0) := "0";
   constant BLEND_ALU_FORMAT_ENUM_BLOP_USIGN8  : std_logic_vector(0 downto 0) := "1";

   function to_slv(i : t_blend_alu_format_enum ) return std_logic_vector;
   function to_t_blend_alu_format_enum(i : std_logic_vector(0 downto 0)) return t_blend_alu_format_enum;

   type t_psb_write_format_enum is (
      WR_USIGN8 , -- 00
      WR_SIGN8  , -- 01
      WR_FLOAT16  -- 10
   );
   attribute enum_encoding of t_psb_write_format_enum : type is "00 01 10";
   constant PSB_WRITE_FORMAT_ENUM_WR_USIGN8  : std_logic_vector(1 downto 0) := "00";
   constant PSB_WRITE_FORMAT_ENUM_WR_SIGN8   : std_logic_vector(1 downto 0) := "01";
   constant PSB_WRITE_FORMAT_ENUM_WR_FLOAT16 : std_logic_vector(1 downto 0) := "10";

   function to_slv(i : t_psb_write_format_enum ) return std_logic_vector;
   function to_t_psb_write_format_enum(i : std_logic_vector(1 downto 0)) return t_psb_write_format_enum;
end package pkg_psb;

package body pkg_psb is

   -- conversion function for blend_alu_factor_enum enumerator
   function to_slv(i : t_blend_alu_factor_enum ) return std_logic_vector is
      variable ret : std_logic_vector(3 downto 0);
   begin
      case i is
         when ZERO                  => ret := BLEND_ALU_FACTOR_ENUM_ZERO;
         when ONE                   => ret := BLEND_ALU_FACTOR_ENUM_ONE;
         when SRC_ALPHA_SATURATE    => ret := BLEND_ALU_FACTOR_ENUM_SRC_ALPHA_SATURATE;
         when RESERVED              => ret := BLEND_ALU_FACTOR_ENUM_RESERVED;
         when SRC_COLOUR            => ret := BLEND_ALU_FACTOR_ENUM_SRC_COLOUR;
         when ONEMINUS_SRC_COLOUR   => ret := BLEND_ALU_FACTOR_ENUM_ONEMINUS_SRC_COLOUR;
         when SRC_ALPHA             => ret := BLEND_ALU_FACTOR_ENUM_SRC_ALPHA;
         when ONEMINUS_SRC_ALPHA    => ret := BLEND_ALU_FACTOR_ENUM_ONEMINUS_SRC_ALPHA;
         when DST_COLOUR            => ret := BLEND_ALU_FACTOR_ENUM_DST_COLOUR;
         when ONEMINUS_DST_COLOUR   => ret := BLEND_ALU_FACTOR_ENUM_ONEMINUS_DST_COLOUR;
         when DST_ALPHA             => ret := BLEND_ALU_FACTOR_ENUM_DST_ALPHA;
         when ONEMINUS_DST_ALPHA    => ret := BLEND_ALU_FACTOR_ENUM_ONEMINUS_DST_ALPHA;
         when CONST_COLOUR          => ret := BLEND_ALU_FACTOR_ENUM_CONST_COLOUR;
         when ONEMINUS_CONST_COLOUR => ret := BLEND_ALU_FACTOR_ENUM_ONEMINUS_CONST_COLOUR;
         when CONST_ALPHA           => ret := BLEND_ALU_FACTOR_ENUM_CONST_ALPHA;
         when others                => ret := BLEND_ALU_FACTOR_ENUM_ONEMINUS_CONST_ALPHA;
      end case;
      return ret;
   end function;
   -- conversion function for blend_alu_factor_enum enumerator
   function to_t_blend_alu_factor_enum(i : std_logic_vector(3 downto 0)) return t_blend_alu_factor_enum is
      variable ret : t_blend_alu_factor_enum;
   begin
      case i is
         when BLEND_ALU_FACTOR_ENUM_ZERO                  => ret := ZERO;
         when BLEND_ALU_FACTOR_ENUM_ONE                   => ret := ONE;
         when BLEND_ALU_FACTOR_ENUM_SRC_ALPHA_SATURATE    => ret := SRC_ALPHA_SATURATE;
         when BLEND_ALU_FACTOR_ENUM_RESERVED              => ret := RESERVED;
         when BLEND_ALU_FACTOR_ENUM_SRC_COLOUR            => ret := SRC_COLOUR;
         when BLEND_ALU_FACTOR_ENUM_ONEMINUS_SRC_COLOUR   => ret := ONEMINUS_SRC_COLOUR;
         when BLEND_ALU_FACTOR_ENUM_SRC_ALPHA             => ret := SRC_ALPHA;
         when BLEND_ALU_FACTOR_ENUM_ONEMINUS_SRC_ALPHA    => ret := ONEMINUS_SRC_ALPHA;
         when BLEND_ALU_FACTOR_ENUM_DST_COLOUR            => ret := DST_COLOUR;
         when BLEND_ALU_FACTOR_ENUM_ONEMINUS_DST_COLOUR   => ret := ONEMINUS_DST_COLOUR;
         when BLEND_ALU_FACTOR_ENUM_DST_ALPHA             => ret := DST_ALPHA;
         when BLEND_ALU_FACTOR_ENUM_ONEMINUS_DST_ALPHA    => ret := ONEMINUS_DST_ALPHA;
         when BLEND_ALU_FACTOR_ENUM_CONST_COLOUR          => ret := CONST_COLOUR;
         when BLEND_ALU_FACTOR_ENUM_ONEMINUS_CONST_COLOUR => ret := ONEMINUS_CONST_COLOUR;
         when BLEND_ALU_FACTOR_ENUM_CONST_ALPHA           => ret := CONST_ALPHA;
         when others                                      => ret := ONEMINUS_CONST_ALPHA;
      end case;
      return ret;
   end function;

   -- conversion function for blend_alu_blop_enum enumerator
   function to_slv(i : t_blend_alu_blop_enum ) return std_logic_vector is
      variable ret : std_logic_vector(2 downto 0);
   begin
      case i is
         when BLOP_SUB  => ret := BLEND_ALU_BLOP_ENUM_BLOP_SUB;
         when BLOP_RSUB => ret := BLEND_ALU_BLOP_ENUM_BLOP_RSUB;
         when BLOP_MIN  => ret := BLEND_ALU_BLOP_ENUM_BLOP_MIN;
         when BLOP_MAX  => ret := BLEND_ALU_BLOP_ENUM_BLOP_MAX;
         when others    => ret := BLEND_ALU_BLOP_ENUM_BLOP_ADD;
      end case;
      return ret;
   end function;
   -- conversion function for blend_alu_blop_enum enumerator
   function to_t_blend_alu_blop_enum(i : std_logic_vector(2 downto 0)) return t_blend_alu_blop_enum is
      variable ret : t_blend_alu_blop_enum;
   begin
      case i is
         when BLEND_ALU_BLOP_ENUM_BLOP_SUB  => ret := BLOP_SUB;
         when BLEND_ALU_BLOP_ENUM_BLOP_RSUB => ret := BLOP_RSUB;
         when BLEND_ALU_BLOP_ENUM_BLOP_MIN  => ret := BLOP_MIN;
         when BLEND_ALU_BLOP_ENUM_BLOP_MAX  => ret := BLOP_MAX;
         when others                        => ret := BLOP_ADD;
      end case;
      return ret;
   end function;

   -- conversion function for blend_alu_format_enum enumerator
   function to_slv(i : t_blend_alu_format_enum ) return std_logic_vector is
      variable ret : std_logic_vector(0 downto 0);
   begin
      case i is
         when BLOP_FLOAT16 => ret := BLEND_ALU_FORMAT_ENUM_BLOP_FLOAT16;
         when others       => ret := BLEND_ALU_FORMAT_ENUM_BLOP_USIGN8;
      end case;
      return ret;
   end function;
   -- conversion function for blend_alu_format_enum enumerator
   function to_t_blend_alu_format_enum(i : std_logic_vector(0 downto 0)) return t_blend_alu_format_enum is
      variable ret : t_blend_alu_format_enum;
   begin
      case i is
         when BLEND_ALU_FORMAT_ENUM_BLOP_FLOAT16 => ret := BLOP_FLOAT16;
         when others                             => ret := BLOP_USIGN8;
      end case;
      return ret;
   end function;

   -- conversion function for psb_write_format_enum enumerator
   function to_slv(i : t_psb_write_format_enum ) return std_logic_vector is
      variable ret : std_logic_vector(1 downto 0);
   begin
      case i is
         when WR_USIGN8  => ret := PSB_WRITE_FORMAT_ENUM_WR_USIGN8;
         when WR_SIGN8   => ret := PSB_WRITE_FORMAT_ENUM_WR_SIGN8;
         when others     => ret := PSB_WRITE_FORMAT_ENUM_WR_FLOAT16;
      end case;
      return ret;
   end function;
   -- conversion function for psb_write_format_enum enumerator
   function to_t_psb_write_format_enum(i : std_logic_vector(1 downto 0)) return t_psb_write_format_enum is
      variable ret : t_psb_write_format_enum;
   begin
      case i is
         when PSB_WRITE_FORMAT_ENUM_WR_USIGN8  => ret := WR_USIGN8;
         when PSB_WRITE_FORMAT_ENUM_WR_SIGN8   => ret := WR_SIGN8;
         when others                           => ret := WR_FLOAT16;
      end case;
      return ret;
   end function;

end package body pkg_psb;
