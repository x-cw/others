// +FHDR-----------------------------------------------------------------------
// Copyright (c) 2022, Innosilicon, Inc. Confidential Proprietary
// PROJECT NAME  : 
// BLOCK   NAME  : gc_perf_monitor_bif 
// DEPARTMENT    : Front-End Department
// AUTHOR        : Liushi
// EMAIL         : lius@innosilicon.com.cn
// ----------------------------------------------------------------------------
// Release History
// VERSION  DATE        AUTHOR    DESCRIPTION
// 1.0      20241015    Liushi  First initial
//
// Description   : 
// ----------------------------------------------------------------------------
// Others For More Information:
//
// -FHDR-----------------------------------------------------------------------
//`define GPU_SYNTHESIS
module gc_perf_monitor_top
#(
  parameter N = 64,                // N is the perf_monitor can monitor the number of events,N=64 or N= 128(all event width is 1bit) will be verifed.
  parameter W_ADD =0,              //N=64,the value is 0,when N=128,the value will be 1
  parameter [21:0] M_N = 54,       //the number of perf_monitor in system.
  parameter int W[127:0]={         //every value represent the width of every event,the width from 1 to 6 will be verifed
  32'd0,32'd0,32'd0,32'd0,32'd0,32'd0,32'd0,32'd0,
  32'd0,32'd0,32'd0,32'd0,32'd0,32'd0,32'd0,32'd0,
  32'd0,32'd0,32'd0,32'd0,32'd0,32'd0,32'd0,32'd0,
  32'd0,32'd0,32'd0,32'd0,32'd0,32'd0,32'd0,32'd0,
  32'd0,32'd0,32'd0,32'd0,32'd0,32'd0,32'd0,32'd0,
  32'd0,32'd0,32'd0,32'd0,32'd0,32'd0,32'd0,32'd0,
  32'd0,32'd0,32'd0,32'd0,32'd0,32'd0,32'd0,32'd0,
  32'd0,32'd0,32'd0,32'd0,32'd0,32'd0,32'd0,32'd0,
  32'd1,32'd1,32'd1,32'd1,32'd1,32'd1,32'd1,32'd1,
  32'd1,32'd1,32'd1,32'd1,32'd1,32'd1,32'd1,32'd1,
  32'd1,32'd1,32'd1,32'd1,32'd1,32'd1,32'd1,32'd1,
  32'd1,32'd1,32'd1,32'd1,32'd1,32'd1,32'd1,32'd1,
  32'd1,32'd1,32'd1,32'd1,32'd1,32'd1,32'd1,32'd1,
  32'd1,32'd1,32'd1,32'd1,32'd1,32'd1,32'd1,32'd1,
  32'd1,32'd1,32'd1,32'd1,32'd1,32'd1,32'd1,32'd1,
  32'd1,32'd1,32'd1,32'd1,32'd1,32'd1,32'd1,32'd1
  }
)
(
 /*AUTOARG*/
   // Outputs
   perf_mon_bif_cmd_valid, perf_mon_bif_cmd_operation,
   perf_mon_bif_cmd_persistence, perf_mon_bif_cmd_ctxt_pasid,
   perf_mon_bif_cmd_l1_policy, perf_mon_bif_cmd_l2_policy,
   perf_mon_bif_cmd_l2_prefetch_size, perf_mon_bif_cmd_vaddress,
   perf_mon_bif_cmd_burst_length, perf_mon_bif_cmd_tag_sb,
   perf_mon_bif_write_valid, perf_mon_bif_write_mask,
   perf_mon_bif_write_data, perf_mon_bif_rtn_enable,
   perf_mon_bif_rtn_credit, perf_mon_done, perf_mon_fail,
   perf_mon_obuf_overflow, perf_mon_cnt_time_flag,
   perf_mon_bif_fence_times, perf_mon_last_dump_times,perf_mon_interval_end,
   // Inputs
   clk, rst_n, perf_event, num_id, reg_normal_mode_start,
   reg_perf_dump_trigger, reg_perf_enable, reg_perf_time_slot,
   reg_perf_base_addr, reg_perf_space_size, reg_time_stamp_enable,
   time_stamp_low32bit, time_stamp_high32bit, reg_bif_cmd_persistence,
   reg_bif_cmd_ctxt_pasid, reg_bif_cmd_l1_policy,
   reg_bif_cmd_l2_policy, reg_bif_cmd_l2_prefetch_size,
   reg_fence_interval, perf_mon_bif_cmd_enable,
   perf_mon_bif_write_enable, perf_mon_bif_rtn_valid,
   perf_mon_bif_rtn_fence, perf_mon_bif_rtn_data,
   perf_mon_bif_rtn_tag_sb
   );

  //`include "lib_func_clog2.v"
  `include "perf_monitor_config.v"

  //clock and reset--------------
  input               clk;
  input               rst_n;
  //input perf_event-------------
  input [M_TOTAL-1:0] perf_event;                                   //performance event bus signal coming from perf_clients
  //------------
  input [NUM_WIDTH -1:0] num_id;                                    //reresent the number id of every perf_monitor module in the system
  //---------------
  //---input control registers-------------
  input               reg_normal_mode_start;                        //normal mode start to work,one cycle pulse
  input [1:0]         reg_perf_dump_trigger;                        //2'b00:NO operation; 2'b01:start to dump in normal mode; 2'b10:start to dump in interval mode 2'b11:stop dumping operation in interval mode
  input               reg_perf_enable;                              //perf_monitor is enable or disable
  input [15:0]        reg_perf_time_slot;                           //interval mode dump time slot
  input [41:0]        reg_perf_base_addr;                           //performance counter dump base address
  input [31:0]        reg_perf_space_size;                          //dump performance counter space size
  input               reg_time_stamp_enable;                        //time stamp enable or not
  //time stamp from other modules-------------
  input [31:0]        time_stamp_low32bit;                          //time stamp low 32bit signal
  input [31:0]        time_stamp_high32bit;                         //time stamp high 32bit signal
  //bif control registers-----------
  input [1:0]         reg_bif_cmd_persistence;                      //register signal control bif interface perf_mon_bif_cmd_persistence
  input [5:0]         reg_bif_cmd_ctxt_pasid;                       //register signal control bif interface perf_mon_bif_cmd_ctxt_pasid
  input [1:0]         reg_bif_cmd_l1_policy;                        //register signal control bif interface perf_mon_bif_cmd_l1_policy
  input               reg_bif_cmd_l2_policy;                        //register signal control bif interface perf_mon_bif_cmd_l2_policy
  input               reg_bif_cmd_l2_prefetch_size;                 //register signal control bif interface perf_mon_bif_cmd_l2_prefetch_size
  input [5:0]         reg_fence_interval;                           //the interval of sending fence,eg: reg_fence_interval = 2,dump three times send a fence,max value is 63,dump 64 times send a fence
  //BIF interface---------------
  output              perf_mon_bif_cmd_valid;                       //bif interface cmd valid
  input               perf_mon_bif_cmd_enable;                      //bif interface cmd enable
  output [3:0]        perf_mon_bif_cmd_operation;                   //bif interface cmd operation
  output [1:0]        perf_mon_bif_cmd_persistence;                 //bif interface cmd persistence
  output [5:0]        perf_mon_bif_cmd_ctxt_pasid;                  //bif interface cmd ctxt pasid
  output [1:0]        perf_mon_bif_cmd_l1_policy;                   //bif interface cmd l1 policy
  output              perf_mon_bif_cmd_l2_policy;                   //bif interface cmd l2 policy
  output              perf_mon_bif_cmd_l2_prefetch_size;            //bif interface cmd l2 prefetch_size
  output [41:0]       perf_mon_bif_cmd_vaddress;                    //bif interface cmd vaddress;
  output [1:0]        perf_mon_bif_cmd_burst_length;                //bif interface cmd burst length
  output [6:0]        perf_mon_bif_cmd_tag_sb;                      //bif interface cmd tag sb ,is constant value 0                 
  output              perf_mon_bif_write_valid;                     //bif interface write valid
  input               perf_mon_bif_write_enable;                    //bif interface write enable
  output [63:0]       perf_mon_bif_write_mask;                      //bif interface write mask,is constant value 64'b0
  output [511:0]      perf_mon_bif_write_data;                      //bif interface write data
  input               perf_mon_bif_rtn_valid;                       //bif interface return valid
  output              perf_mon_bif_rtn_enable;                      //bif interface return enable
  output              perf_mon_bif_rtn_credit;                      //bif interface return credit, indicate rtn fence handshake successfully,slave can not use this signal.
  input               perf_mon_bif_rtn_fence;                       //bif interface return fence
  input  [511:0]      perf_mon_bif_rtn_data;                        //bif interface return data,perf_mon have no read request,so not use this signal
  input  [6:0]        perf_mon_bif_rtn_tag_sb;                      //bif interface return tag sb,not use this signal
  //----dump status--------
  output reg          perf_mon_done;                                //dump done, one pulse represent a dump successfully
  output reg          perf_mon_fail;                                //dump fail, one pulse represent dump fail
  output reg          perf_mon_obuf_overflow;                       //obuf overflow 
  output reg          perf_mon_cnt_time_flag;                       //perf_monitor count time period
  output reg [23:0]   perf_mon_bif_fence_times;                     //in interval mode,record the fence times.
  output reg [5:0]    perf_mon_last_dump_times;                     //in interval mode,the last send fence,dump times.
  output reg          perf_mon_interval_end;                        //in interval mode,it assert at the last of perf_mon_done.
  
  //localparam N_LOG2     = lib_func_clog2(N);
  localparam N_LOG2     = $clog2(N);
  localparam OBUF_DEPTH = N/16;
  
  reg                        rd_cold_cnt_en;
  wire                       rd_dump_cnt_en;
  reg                        rd_dump_cnt_en_d0;
  wire                       dpram_rd_en;
  reg [N_LOG2-1:0]           dpram_rd_addr;
  reg [N_LOG2-1:0]           rd_dump_addr;
  reg [N_LOG2-1:0]           rd_dump_addr_d0;
  reg [N_LOG2-1:0]           rd_dump_addr_d1;
  reg [N_LOG2-1:0]           rd_dump_addr_d2;
  reg [N_LOG2-1:0]           rd_dump_addr_d3;
  reg                        dpram_wrt_en_pre;
  reg                        dpram_wrt_en;
  reg [N_LOG2-1:0]           dpram_wrt_addr;
  reg [N_LOG2-1:0]           dpram_wrt_addr_pre;
  reg [N_LOG2:0]             dpram_wrt_addr_plus1;
  reg                        hot_cnt_en;
  genvar                     i;
  reg [N-1:0]                hot_cnt_clear;
  wire [31:0]                dpram_rdata;
  reg [31:0]                 dpram_rdata_d0;
  reg [31:0]                 rdata_patch32bit;
  wire [31:0]                cold_cnt;
  reg [31:0]                 dpram_wdata;
  wire                       first_cnt_num_cycles_wrt;
  wire [31:0]                hot_cnt[N];
  wire [25:0]                perf_event_mux[N];
  reg [15:0]                 interval_mode_cycles_cnt;
  wire [BIF_DATA_WIDTH-1:0]  obuf_rdata;
  reg                        obuf_wrten;
  reg [BIF_DATA_WIDTH-1:0]   obuf_wdata;
  wire                       obuf_empty;
  wire                       obuf_full;
  wire [41:0]                memory_base_addr;
  reg [3:0]                  rd_dump_cnt_en_d0_cnt;
  reg [3:0]                  rd_dump_cnt_en_d0_cnt_d0;
  reg [1:0]                  perf_dump_trigger_latch;
  reg [1:0]                  fsm_normal_st_r;
  reg [1:0]                  fsm_normal_st_nxt;
  reg [1:0]                  fsm_interval_st_r;
  reg [1:0]                  fsm_interval_st_nxt;
  reg                        rd_dump_cnt_en_normal;
  reg                        rd_dump_cnt_en_interval;
  reg                        rd_dump_cnt_en_normal_d0;
  reg                        rd_dump_cnt_en_normal_d1;
  reg [N_LOG2-1:0]           rd_dump_cnt_normal;
  reg                        obuf_data_valid;
  reg [1:0]                  obuf_wrten_cnt;
  wire                       obuf_rd_en;
  wire                       obuf_data_ready;
  wire                       new_session_start;
  wire [31:0]                addr_offset;
  wire [25:0]                addr_offset_r_sft6;
  wire [2:0]                 burst_data_num;
  reg [23:0]                 perf_mon_done_cnt;
  reg                        interval_mode_cnt_flag;
  reg                        reg_perf_enable_d0;
  wire                       fun_exit;
  wire                       clear;
  wire                       obuf_wrten_true;
  reg [4:0]                  rdata_32bit_valid_cnt;
  reg                        rdata_32bit_valid;

  wire [33:0]                module_addr_bais;
  wire [27:0]                module_addr_bais_r_sft6;
  wire [41:0]                space_last_dump_addr;
  reg                        normal_mode_flag;
  
  reg                        obuf_data1_en;
  reg                        obuf_data2_en;
  reg                        obuf_data3_en;
  wire                       obuf_data0_wrt;
  wire                       obuf_data1_wrt;
  wire                       obuf_data2_wrt;
  wire                       obuf_data3_wrt;
  wire                       interval_stop;
  wire                       fence_times_cal_over;

  reg [23:0]                 bif_fence_times_expect;                     
  reg [5:0]                  bif_last_dump_times_expect;     
  reg                        fence_times_cal_over_r;
  reg                        fence_times_cal_over_r1;
  reg [5:0]                  dump_times_interval;
  wire                       fun_start;
  reg [31:0]                 dump_ok_num;//before every cmd_store handshake,record the dump successfully number id for addr calculate 
  reg [41:0]                 addr_pre;
  reg [31:0]                 dump_exp_cnt;
  reg                        perf_mon_fail_pre;
  wire                       perf_mon_done_pre;
  reg [6:0]                  overflow_cnt;
  wire [6:0]                 bif_cmd_data_atv_cnt;
  wire                       fence_end;
  reg [1:0]                  overflow_time;
  wire                       normal_dump;
  wire [41:0]                reg_perf_base_addr_update;
  wire                       fence_not_use_overflow_cnt;
  
  localparam FSM_NORMAL_IDLE        = 2'b00;
  localparam FSM_NORMAL_CNT         = 2'b01;
  localparam FSM_NORMAL_DUMP        = 2'b10;
  
  localparam FSM_INTERVAL_IDLE      = 2'b00;
  localparam FSM_INTERVAL_CNT       = 2'b01;
  localparam FSM_INTERVAL_DUMP_WAIT = 2'b10;
  localparam FSM_INTERVAL_DUMP      = 2'b11;
  
  localparam BURST_NUM_0            = N*16/512; //N=64,in interval mode when all event width is one bit,burst_len=1
  localparam BURST_NUM_1            = N*32/512; //N=64,except the condition that in interval mode when all event width is one bit,burst_len=3
  
 //-------------generate the normal mode fsm state--------------------- 
  always @(posedge clk or negedge rst_n)begin
    if(~rst_n)
      fsm_normal_st_r <= FSM_NORMAL_IDLE;
    else if(fun_exit)
      fsm_normal_st_r <= FSM_NORMAL_IDLE;
    else
      fsm_normal_st_r <= fsm_normal_st_nxt;
  end

  always @(*)begin
    case(fsm_normal_st_r)
      FSM_NORMAL_IDLE:begin
        if(reg_normal_mode_start & reg_perf_enable)
          fsm_normal_st_nxt = FSM_NORMAL_CNT;
        else
          fsm_normal_st_nxt = FSM_NORMAL_IDLE;  
      end
      FSM_NORMAL_CNT:begin
        if(normal_dump && rd_cold_cnt_en && (dpram_rd_addr==N-1))
          fsm_normal_st_nxt = FSM_NORMAL_DUMP;
        else
          fsm_normal_st_nxt = FSM_NORMAL_CNT;  
      end
      FSM_NORMAL_DUMP:begin
        if(rd_dump_cnt_en_normal && (rd_dump_cnt_normal == N-1))
          fsm_normal_st_nxt = FSM_NORMAL_IDLE;
        else
          fsm_normal_st_nxt = FSM_NORMAL_DUMP;    
      end
      default:fsm_normal_st_nxt = FSM_NORMAL_IDLE;
    endcase
  end
  
  //-----------generate the interval mode fsm state---------------------------------
  always @(posedge clk or negedge rst_n)begin
    if(~rst_n)
      fsm_interval_st_r <= FSM_INTERVAL_IDLE;
    else if(fun_exit)
      fsm_interval_st_r <= FSM_INTERVAL_IDLE;
    else
      fsm_interval_st_r <= fsm_interval_st_nxt;
  end
  
  always @(*)begin
    case(fsm_interval_st_r)
      FSM_INTERVAL_IDLE:begin
        if((reg_perf_dump_trigger == 2'b10) && (reg_perf_enable))
          fsm_interval_st_nxt = FSM_INTERVAL_CNT;
        else
          fsm_interval_st_nxt = FSM_INTERVAL_IDLE;  
      end
      FSM_INTERVAL_CNT:begin
        if(interval_mode_cycles_cnt == reg_perf_time_slot -1'b1 || interval_stop)begin
          if(rd_cold_cnt_en && (dpram_rd_addr==N-1))
            fsm_interval_st_nxt = FSM_INTERVAL_DUMP;
          else
            fsm_interval_st_nxt = FSM_INTERVAL_DUMP_WAIT;
        end
        else
          fsm_interval_st_nxt = FSM_INTERVAL_CNT;  
      end
      FSM_INTERVAL_DUMP_WAIT:begin
        if(rd_cold_cnt_en && (dpram_rd_addr == N-1))
          fsm_interval_st_nxt = FSM_INTERVAL_DUMP;
        else
          fsm_interval_st_nxt = FSM_INTERVAL_DUMP_WAIT;    
      end
      FSM_INTERVAL_DUMP:begin
        if(rd_dump_cnt_en && (dpram_rd_addr == N-1))begin
          if(interval_stop)
             fsm_interval_st_nxt = FSM_INTERVAL_IDLE;
          else
            fsm_interval_st_nxt = FSM_INTERVAL_CNT;
        end
        else
          fsm_interval_st_nxt = FSM_INTERVAL_DUMP;    
      end
      default:fsm_interval_st_nxt = FSM_INTERVAL_IDLE;
    endcase
  end
//-------------fsm state end--------------------------------------------
 
  assign normal_dump = reg_perf_dump_trigger == 2'b01 || perf_dump_trigger_latch == 2'b01 ;

  assign interval_stop = reg_perf_dump_trigger == 2'b11 || perf_dump_trigger_latch == 2'b11 ;

  assign reg_perf_base_addr_update = {reg_perf_base_addr[39:0],2'b00};
//generate function exit signal--------------------
  always @(posedge clk or negedge rst_n)begin
    if(~rst_n)
      reg_perf_enable_d0 <= 1'b0;
    else
      reg_perf_enable_d0 <= reg_perf_enable;
  end
  
  assign fun_exit  = (!reg_perf_enable) && reg_perf_enable_d0;
  assign fun_start = (!reg_perf_enable_d0) && reg_perf_enable;
 //generate clear signal when function exit or new session start----------------
  assign clear = fun_start || fun_exit || new_session_start;
 //------------------------------------------------------------------------------
 //-----------generate rd_cold_cnt_en-------------------------
  always @(posedge clk or negedge rst_n)begin
    if(~rst_n)
      rd_cold_cnt_en <= 1'b0;
    else if(clear)
      rd_cold_cnt_en <= 1'b0;
    else if(((fsm_normal_st_r == FSM_NORMAL_CNT)&&(fsm_normal_st_nxt == FSM_NORMAL_DUMP)) ||
           ((fsm_interval_st_r == FSM_INTERVAL_DUMP_WAIT) && rd_cold_cnt_en && (dpram_rd_addr == N-1)) ||
           ((fsm_interval_st_r == FSM_INTERVAL_CNT) && rd_cold_cnt_en && (dpram_rd_addr == N-1) && ( (interval_mode_cycles_cnt == reg_perf_time_slot-1'b1) || (interval_stop) ))||
           ((fsm_interval_st_r == FSM_INTERVAL_DUMP) && (fsm_interval_st_nxt == FSM_INTERVAL_IDLE)) )
      rd_cold_cnt_en <= 1'b0;      
    else if((fsm_normal_st_r == FSM_NORMAL_CNT) || (fsm_interval_st_r == FSM_INTERVAL_CNT) || (fsm_interval_st_r == FSM_INTERVAL_DUMP && (dpram_rd_addr == N-1)) )
      rd_cold_cnt_en <= 1'b1;
  end
  //----------------------------------------------

  //--generate dpram write_en and write addr previous one clock cycle signal
  always @(posedge clk or negedge rst_n)begin
    if(~rst_n)
      dpram_wrt_en_pre   <= 1'b0;
    else
      dpram_wrt_en_pre   <= rd_cold_cnt_en;
  end
  
  always @(posedge clk or negedge rst_n)begin
    if(~rst_n)
      dpram_wrt_addr_pre     <= {N_LOG2{1'b0}};
    else if(clear)
      dpram_wrt_addr_pre     <= {N_LOG2{1'b0}};
    else if(dpram_wrt_en_pre)
      dpram_wrt_addr_pre     <= dpram_wrt_addr_pre + 1'b1;
    else
      dpram_wrt_addr_pre     <= {N_LOG2{1'b0}};
  end
  //------------------
  always @(posedge clk or negedge rst_n)begin
    if(~rst_n)begin
      dpram_wrt_en             <= 1'b0;
      dpram_wrt_addr           <= {N_LOG2{1'b0}};
      rd_dump_cnt_en_normal_d0 <= 1'b0;
      rd_dump_cnt_en_normal_d1 <= 1'b0;
    end
    else begin
      dpram_wrt_en             <= dpram_wrt_en_pre;
      dpram_wrt_addr           <= dpram_wrt_addr_pre;
      rd_dump_cnt_en_normal_d0 <= rd_dump_cnt_en_normal;
      rd_dump_cnt_en_normal_d1 <= rd_dump_cnt_en_normal_d0;
    end
  end
 // generate dpram_wrt_addr_plus1 the first addr from 0 to 63,indicate the
 // first write dpram 64 address space,for the first write dpram,when
 // first_cnt_num_cycles_wrt valid,not write cold_cnt into dpram.because of
 // first dpram rdata is not perf counter historical value.
  always @(posedge clk or negedge rst_n)begin
    if(~rst_n)
      dpram_wrt_addr_plus1 <= {{N_LOG2+1}{1'b0}};
    else if((!rd_dump_cnt_en_d0&rd_dump_cnt_en) || clear)
      dpram_wrt_addr_plus1 <= {{N_LOG2+1}{1'b0}};
    else if(dpram_wrt_addr_plus1 == N)
      dpram_wrt_addr_plus1 <= dpram_wrt_addr_plus1;
    else if(dpram_wrt_en_pre)
      dpram_wrt_addr_plus1 <= dpram_wrt_addr_plus1 + 1'b1;
  end
    
  assign first_cnt_num_cycles_wrt = dpram_wrt_en_pre && (dpram_wrt_addr_plus1 <= N-1);
 //---------------------------------------------------------------------
 
 //------generate hot_cnt_en-----------------------------------------
 //in normal mode when begin to read cold cnt and wait until dpram write _pre
 //=0 hot_cnt_en =1;
 //in interval mode,read cold cnt and dump data hot cnt_en is still 1,when
 //last dump data hot_cnt_en = 0;
  assign hot_cnt_en = ((rd_cold_cnt_en || dpram_wrt_en_pre) && normal_mode_flag ) || 
                       dpram_rd_en && ( (fsm_interval_st_r == FSM_INTERVAL_CNT) || ((fsm_interval_st_r == FSM_INTERVAL_DUMP) && (perf_dump_trigger_latch != 2'b11)) || (fsm_interval_st_r ==  FSM_INTERVAL_DUMP_WAIT)) ;
  

  always @(posedge clk or negedge rst_n)begin
    if(~rst_n)
      perf_mon_cnt_time_flag <= 1'b0;
    else
      perf_mon_cnt_time_flag <= hot_cnt_en;
  end

//--------generate dpram wdata-----------
  always @(posedge clk or negedge rst_n)begin
    if(~rst_n)
      dpram_wdata  <= 32'b0;
    else if(reg_perf_enable)begin
      if(reg_time_stamp_enable && (dpram_wrt_addr_pre == {{N_LOG2}{1'b0}}) && dpram_wrt_en_pre)
        dpram_wdata  <= time_stamp_low32bit;
      else if(reg_time_stamp_enable && (dpram_wrt_addr_pre == {{{N_LOG2-1}{1'b0}},1'b1}) && dpram_wrt_en_pre )
        dpram_wdata  <= time_stamp_high32bit;
      else if (first_cnt_num_cycles_wrt)
        dpram_wdata  <= hot_cnt[dpram_wrt_addr_pre]+{6'b0,perf_event_mux[dpram_wrt_addr_pre]};
      else
        dpram_wdata  <= hot_cnt[dpram_wrt_addr_pre]+{6'b0,perf_event_mux[dpram_wrt_addr_pre]}+cold_cnt;
    end
  end

 //----generate normal mode and interval mode dpram read enable rd address and
 //dpram read data as cold_cnt------------------------------------------------
  always @(posedge clk or negedge rst_n)begin
    if(~rst_n)
      rd_dump_cnt_en_normal <= 1'b0;
    else if(fsm_normal_st_r==FSM_NORMAL_DUMP )begin
      if(rd_dump_cnt_en_normal && (rd_dump_cnt_normal == N-1))
        rd_dump_cnt_en_normal <= 1'b0;
      else
        rd_dump_cnt_en_normal <= 1'b1;
    end
    else
       rd_dump_cnt_en_normal <= 1'b0; 
  end
  
  always @(posedge clk or negedge rst_n)begin
    if(~rst_n)
      rd_dump_cnt_normal <= {N_LOG2{1'b0}};
    else if(clear)
      rd_dump_cnt_normal <= {N_LOG2{1'b0}};
    else if(rd_dump_cnt_en_normal)
      rd_dump_cnt_normal <= rd_dump_cnt_normal + 1'b1;
  end

  always @(posedge clk or negedge rst_n)begin
    if(~rst_n)
      rd_dump_cnt_en_interval <= 1'b0;
    else if(clear)
      rd_dump_cnt_en_interval <= 1'b0; 
    else if((dpram_rd_addr == N-1) && (fsm_interval_st_r == FSM_INTERVAL_DUMP))
      rd_dump_cnt_en_interval <= 1'b0;
    else if(
             (fsm_interval_st_r == FSM_INTERVAL_DUMP_WAIT || (fsm_interval_st_r == FSM_INTERVAL_CNT && (interval_mode_cycles_cnt == reg_perf_time_slot-1'b1 || interval_stop )) ) && 
             (rd_cold_cnt_en && dpram_rd_addr == N-1)
           )
      rd_dump_cnt_en_interval <= 1'b1;
  end

  assign rd_dump_cnt_en = rd_dump_cnt_en_normal_d1 | rd_dump_cnt_en_interval;
  assign dpram_rd_en    = rd_cold_cnt_en | rd_dump_cnt_en;
    
  always @(posedge clk or negedge rst_n)begin
    if(~rst_n)
      dpram_rd_addr<= {N_LOG2{1'b0}};
    else if(clear)
      dpram_rd_addr<= {N_LOG2{1'b0}};
    else if((fsm_normal_st_r ==FSM_NORMAL_DUMP) && rd_cold_cnt_en)
      dpram_rd_addr<= {N_LOG2{1'b0}};
    else if((fsm_interval_st_r == FSM_INTERVAL_DUMP_WAIT) && rd_cold_cnt_en && (dpram_rd_addr==N-1))
      dpram_rd_addr<= {N_LOG2{1'b0}};
    else if(dpram_rd_en)
      dpram_rd_addr<= dpram_rd_addr+ 1'b1;
  end

  assign cold_cnt  = dpram_rdata;
//---------------------------------------------------------------------------------------------------
 
 //latch pulse signal reg_perf_dump_trigger----------------------
  always @(posedge clk or negedge rst_n)begin
    if(~rst_n)
      perf_dump_trigger_latch <= 2'b00;
    else if(clear)
      perf_dump_trigger_latch <= 2'b00;
    else if(|reg_perf_dump_trigger)
      perf_dump_trigger_latch <= reg_perf_dump_trigger; 
  end
  
 // generate the interval_mode_cycles_cnt for counter the timer reach the
 // reg_perf_time_slot---------------------------------------------   
  always @(posedge clk or negedge rst_n)begin
    if(~rst_n)
      interval_mode_cnt_flag <= 1'b0;
    else if(clear)
      interval_mode_cnt_flag <= 1'b0;
    else if((interval_stop) && dpram_rd_en && (dpram_rd_addr == N-1))
      interval_mode_cnt_flag <= 1'b0;
    else if(fsm_interval_st_r == FSM_INTERVAL_CNT)
      interval_mode_cnt_flag <= 1'b1;
  end
  
  always @(posedge clk or negedge rst_n)begin
    if(~rst_n)
      interval_mode_cycles_cnt <= 16'b0;
    else if(clear)
      interval_mode_cycles_cnt <= 16'b0;
    else if((interval_mode_cycles_cnt == reg_perf_time_slot -1'b1)||( (interval_stop) && dpram_rd_en && (dpram_rd_addr == N-1 )))
      interval_mode_cycles_cnt <= 16'b0;
    else if(interval_mode_cnt_flag)
      interval_mode_cycles_cnt <= interval_mode_cycles_cnt + 1'b1;
  end

 //generate normal mode flag signal to distinguish some logic code
  always @(posedge clk or negedge rst_n)begin
    if(~rst_n)
      normal_mode_flag <= 1'b0;
    else if((!reg_perf_enable) || reg_perf_dump_trigger == 2'b10)
      normal_mode_flag <= 1'b0;
    else if(reg_normal_mode_start )
      normal_mode_flag <= 1'b1;
  end
 
 //generate obuf write logic-------------------------------------------------
 //-----if events are all one bit or events are not one bit,read dpram data to
 //obuf,the valid width is different,when all one bit only use 16bit else use
 //32bit so use generate logic to  different two conditions
  generate
    if(M_TOTAL==N )begin:EVENT_ALL_ONT_BIT
      always @(posedge clk or negedge rst_n)begin
         if(~rst_n)
           rd_dump_addr <= {{N_LOG2}{1'b0}};
         else if(clear)
           rd_dump_addr <= {{N_LOG2}{1'b0}};
         else if(rd_dump_cnt_en)
           rd_dump_addr <=  rd_dump_addr + 1'b1;
      end
    
      always @(posedge clk or negedge rst_n)begin
        if(~rst_n)begin
          rd_dump_addr_d0    <= {{N_LOG2}{1'b0}}; 
          rd_dump_addr_d1    <= {{N_LOG2}{1'b0}}; 
          rd_dump_addr_d2    <= {{N_LOG2}{1'b0}}; 
          rd_dump_addr_d3    <= {{N_LOG2}{1'b0}}; 
          dpram_rdata_d0     <= 32'b0;
          rd_dump_cnt_en_d0  <= 1'b0;
        end
        else begin
          rd_dump_addr_d0    <= rd_dump_addr; 
          rd_dump_addr_d1    <= rd_dump_addr_d0; 
          rd_dump_addr_d2    <= rd_dump_addr_d1; 
          rd_dump_addr_d3    <= rd_dump_addr_d2; 
          dpram_rdata_d0     <= dpram_rdata;
          rd_dump_cnt_en_d0  <= rd_dump_cnt_en;
        end
      end
  
      always @(posedge clk or negedge rst_n)begin
        if(~rst_n)
          rdata_patch32bit <= 32'b0;
        else if(( (rd_dump_addr_d0 == 6'd0) && rd_dump_cnt_en_d0) || ( (rd_dump_addr_d0 == 6'd1) && rd_dump_cnt_en_d0) && reg_time_stamp_enable)
          rdata_patch32bit <= dpram_rdata;
        else if(rd_dump_addr_d0[0])
          rdata_patch32bit <= {dpram_rdata[15:0],dpram_rdata_d0[15:0]};
      end
        
      always @(posedge clk or negedge rst_n)begin
        if(~rst_n)
          obuf_wdata <= {{BIF_DATA_WIDTH}{1'b0}};
        else if(normal_mode_flag && rd_dump_cnt_en_d0 )
          obuf_wdata <= {dpram_rdata[31:0],obuf_wdata[511:32]};
        else if((rd_dump_addr_d2[0] && (!reg_time_stamp_enable)) || (reg_time_stamp_enable && rdata_32bit_valid)) 
          obuf_wdata <= {rdata_patch32bit[31:0],obuf_wdata[511:32]};     
      end
  
      always @(posedge clk or negedge rst_n)begin
        if(~rst_n)
          rdata_32bit_valid <= 1'b0;
        else if(clear)
          rdata_32bit_valid <= 1'b0;
        else if(reg_time_stamp_enable && ( ( (rd_dump_addr_d0 == 6'd0) && rd_dump_cnt_en_d0) || ( (rd_dump_addr_d0 == 6'd1) && rd_dump_cnt_en_d0) || ( (rd_dump_addr >= 6'd4) && rd_dump_addr_d2[0] )))
          rdata_32bit_valid <= 1'b1;
        else
          rdata_32bit_valid <= 1'b0;
      end
  
      always @(posedge clk or negedge rst_n)begin
        if(~rst_n)
          rdata_32bit_valid_cnt <= 5'b0;
        else if(clear)
          rdata_32bit_valid_cnt <= 5'b0;
        else if(rdata_32bit_valid_cnt == 5'd16)
          rdata_32bit_valid_cnt <= 5'b0;    
        else if(rdata_32bit_valid && reg_time_stamp_enable)
          rdata_32bit_valid_cnt <= rdata_32bit_valid_cnt + 1;
      end
  
      assign obuf_wrten = normal_mode_flag ? rd_dump_addr_d1[3:0] == 4'hf :
                          (rd_dump_addr_d3== 6'd31 || rd_dump_addr_d3== 6'd63 )&& (!reg_time_stamp_enable) || rdata_32bit_valid_cnt == 5'd16 && reg_time_stamp_enable;
  
      assign burst_data_num = normal_mode_flag ? BURST_NUM_1 : BURST_NUM_0;//N*16/512;
      assign overflow_time = 2'b1;

    end
    else begin:EVENT_NOT_ALL_ONE_BIT
      always @(posedge clk or negedge rst_n)begin
        if(~rst_n)begin
          rd_dump_cnt_en_d0        <= 1'b0;
          rd_dump_cnt_en_d0_cnt_d0 <= 4'b0;
        end
        else begin
          rd_dump_cnt_en_d0        <= rd_dump_cnt_en;
          rd_dump_cnt_en_d0_cnt_d0 <= rd_dump_cnt_en_d0_cnt;
        end
      end
    
      always @(posedge clk or negedge rst_n)begin
        if(~rst_n)
          rd_dump_cnt_en_d0_cnt <= 4'b0;
        else if(clear)
          rd_dump_cnt_en_d0_cnt <= 4'b0;
        else if(rd_dump_cnt_en_d0)
          rd_dump_cnt_en_d0_cnt <= rd_dump_cnt_en_d0_cnt + 1'b1;
      end
    
      always @(posedge clk or negedge rst_n)begin
        if(~rst_n)
          obuf_wdata <= {{BIF_DATA_WIDTH}{1'b0}};
        else if(rd_dump_cnt_en_d0) 
          obuf_wdata <= {dpram_rdata[31:0],obuf_wdata[511:32]};     
      end
    
      assign obuf_wrten = rd_dump_cnt_en_d0_cnt_d0 == 4'd15;
  
      assign burst_data_num = BURST_NUM_1;//N*32/512;
      assign overflow_time = 2'b11;
    
    end
  endgenerate
  // obuf write logic end------------------------------------------

  // obuf read logic-----------------------------------------------
  always @(posedge clk or negedge rst_n)begin
    if(~rst_n)
      obuf_data_valid <= 1'b0;
    else if(obuf_empty || clear)
      obuf_data_valid <= 1'b0; 
    else if(obuf_wrten_cnt == (burst_data_num -1'b1) && obuf_wrten)
      obuf_data_valid <= 1'b1;
  end
  
  assign obuf_rd_en = obuf_data_valid&obuf_data_ready;

  // --some logic about obuf overflow-------------------------------------------------------------
 //keep data write into obuf correct position----------
 //data1 can write into obuf after data0 write into obuf;
 //data2 can write into obuf after data1 write into obuf;
 //data3 can write into obuf after data2 write into obuf;
 
 always @(posedge clk or negedge rst_n)begin
    if(~rst_n)
      obuf_wrten_cnt <= 2'b0;
    else if(clear)
      obuf_wrten_cnt <= 2'b0;
    else if(obuf_wrten)begin
      if(obuf_wrten_cnt == (burst_data_num -1'b1))
        obuf_wrten_cnt <= 2'b0;
      else
        obuf_wrten_cnt <= obuf_wrten_cnt + 1'b1;
    end
  end

  assign obuf_wrten_true =  ((obuf_data0_wrt ||obuf_data1_wrt || obuf_data2_wrt || obuf_data3_wrt )&& (!obuf_full));
 
  assign obuf_data0_wrt = obuf_wrten && (obuf_wrten_cnt == 2'd0) && obuf_empty;
  assign obuf_data1_wrt = obuf_wrten && (obuf_wrten_cnt == 2'd1) && obuf_data1_en;
  assign obuf_data2_wrt = obuf_wrten && (obuf_wrten_cnt == 2'd2) && obuf_data2_en;
  assign obuf_data3_wrt = obuf_wrten && (obuf_wrten_cnt == 2'd3) && obuf_data3_en;

  always @(posedge clk or negedge rst_n)begin
    if(~rst_n)
      obuf_data1_en <= 1'b0;
    else if(obuf_data1_wrt || clear)
      obuf_data1_en <= 1'b0;
    else if(obuf_data0_wrt)
      obuf_data1_en <= 1'b1;
  end
   
  always @(posedge clk or negedge rst_n)begin
    if(~rst_n)
      obuf_data2_en <= 1'b0;
    else if(obuf_data2_wrt || clear)
      obuf_data2_en <= 1'b0;
    else if(obuf_data1_wrt)
      obuf_data2_en <= 1'b1;
  end
  
  always @(posedge clk or negedge rst_n)begin
    if(~rst_n)
      obuf_data3_en <= 1'b0;
    else if(obuf_data3_wrt || clear)
      obuf_data3_en <= 1'b0;
    else if(obuf_data2_wrt)
      obuf_data3_en <= 1'b1;
  end

 //generate write into obuf successfully serial number for generate dump
 //address------ 
  always @(posedge clk or negedge rst_n)begin
    if(~rst_n)
      dump_ok_num <= 32'b0;
    else if(obuf_wrten && obuf_wrten_cnt == 0 && (obuf_wrten_true))
      dump_ok_num <= dump_exp_cnt;//clear to 0 follow wiht signal dump_exp_cnt
  end

  assign space_last_dump_addr = reg_perf_base_addr_update  + {16'b0,reg_perf_space_size[31:6]};

  always @(posedge clk or negedge rst_n)begin
    if(~rst_n)
      dump_exp_cnt <= 32'b0;
    else if(clear)
      dump_exp_cnt <= 32'b0;//clear should return to 0,because of one session may wrap addr or not ,so should use clear signal to clear to 0
    else if(obuf_wrten && obuf_wrten_cnt == 0 )begin
      if((addr_pre + {16'b0,addr_offset_r_sft6})>= space_last_dump_addr)
        dump_exp_cnt <= 32'b0;
      else
        dump_exp_cnt <= dump_exp_cnt + 1'b1;
    end
  end

  always @(posedge clk or negedge rst_n)begin
    if(~rst_n)
      addr_pre <= 42'b0;
    else if(clear)
      addr_pre <= memory_base_addr ;
    else if(obuf_wrten && obuf_wrten_cnt == 0)begin
      if((addr_pre + {16'b0,addr_offset_r_sft6}) >= space_last_dump_addr)
        addr_pre <= memory_base_addr ;
      else
        addr_pre <= addr_pre + {16'b0,addr_offset_r_sft6};
    end
  end

//generate in interval mode,send fence times and the last fence,dump times.
  assign fence_times_cal_over = (perf_dump_trigger_latch == 2'b11 || reg_perf_dump_trigger == 2'b11) && fsm_interval_st_r == FSM_INTERVAL_DUMP && fsm_interval_st_nxt == FSM_INTERVAL_IDLE && reg_perf_enable;

  always @(posedge clk or negedge rst_n)begin
    if(~rst_n)
      fence_times_cal_over_r <= 1'b0;
    else if(fence_end)//should wait last fence handshake ok,clear this signal 
      fence_times_cal_over_r <= 1'b0;
    else if(fence_times_cal_over)begin
      fence_times_cal_over_r <= fence_times_cal_over;
    end
  end

  always @(posedge clk or negedge rst_n)begin
    if(~rst_n)
      dump_times_interval <= 6'd0;
    else if(clear)
      dump_times_interval <= 6'b0;
   else if(fence_times_cal_over)
      dump_times_interval <= 6'b0;
    else if(obuf_wrten_cnt == 0 && obuf_wrten)begin
      if(dump_times_interval == reg_fence_interval )
        dump_times_interval <= 6'b0;
      else   
        dump_times_interval <= dump_times_interval + 1'b1;
    end
  end

  always @(posedge clk or negedge rst_n)begin
    if(~rst_n)
     bif_fence_times_expect <= 24'd0;
    else if(clear)
      bif_fence_times_expect <= 24'b0;
     else if((dump_times_interval == reg_fence_interval && obuf_wrten_cnt == 0 && obuf_wrten) || fence_times_cal_over &&  dump_times_interval != 6'd0)begin
      bif_fence_times_expect <= bif_fence_times_expect + 1;
    end
  end

  always @(posedge clk or negedge rst_n)begin
    if(~rst_n)
      bif_last_dump_times_expect <= 6'd0;
    else if(clear)
      bif_last_dump_times_expect <= 6'b0;
    else if(fence_times_cal_over &&  dump_times_interval != 6'd0)
      bif_last_dump_times_expect <= dump_times_interval - 1;
    else if( fence_times_cal_over &&  dump_times_interval == 6'd0)
      bif_last_dump_times_expect <= reg_fence_interval ;
  end
 
  always @(posedge clk or negedge rst_n)begin
    if(~rst_n)begin
      perf_mon_last_dump_times <= 6'b0;
      perf_mon_bif_fence_times <= 24'b0;
    end
    else if(clear)begin
      perf_mon_last_dump_times <= 6'b0;
      perf_mon_bif_fence_times <= 24'b0;
    end
    else if(normal_mode_flag)begin
     perf_mon_last_dump_times <=  6'b0;
     perf_mon_bif_fence_times <=  24'b1;
    end
    else if(fence_times_cal_over_r)begin  
      perf_mon_last_dump_times <=  bif_last_dump_times_expect;
      perf_mon_bif_fence_times <=  bif_fence_times_expect;
   end
  end

  always @(posedge clk or negedge rst_n)begin
    if(~rst_n)begin
      fence_times_cal_over_r1 <= 1'b0;
    end
    else begin
      fence_times_cal_over_r1 <= fence_times_cal_over_r;
    end
  end

  assign fence_not_use_overflow_cnt = reg_fence_interval == (bif_cmd_data_atv_cnt - 1'b1 );
    //obuf overflow_cnt generate for fence generate use---------------
  always @(posedge clk or negedge rst_n)begin
    if(~rst_n) begin
      overflow_cnt  <= 7'b0;
    end
    else if(fence_end) begin
      overflow_cnt  <= 7'b0;
    end
    else if(perf_mon_bif_cmd_valid && perf_mon_bif_cmd_enable && (perf_mon_bif_cmd_operation == 4'd8) && (!fence_not_use_overflow_cnt)) begin
      if(!obuf_wrten_true && obuf_wrten && obuf_wrten_cnt == overflow_time && overflow_cnt >= ({1'b0,reg_fence_interval} - bif_cmd_data_atv_cnt)) // fence handshake and overflow at the same time
        overflow_cnt <= overflow_cnt + 1'b1 - ({1'b0,reg_fence_interval} + 1'b1 - bif_cmd_data_atv_cnt);
      else if(overflow_cnt >= ({1'b0,reg_fence_interval} + 1'b1 - bif_cmd_data_atv_cnt))
        overflow_cnt <= overflow_cnt - ({1'b0,reg_fence_interval} + 1'b1 - bif_cmd_data_atv_cnt);
     end
    else if(!obuf_wrten_true && obuf_wrten && obuf_wrten_cnt == overflow_time) begin
        overflow_cnt <= overflow_cnt + 1'b1;  
    end
  end

  //---obuf generate end--------------------------------------
 
  //generate dump to memory base address and address offset every dump -------------------
  assign module_addr_bais        =  {26'b0,num_id}*{N,2'b00};
  assign module_addr_bais_r_sft6 = {module_addr_bais[33:6]};
 // assign memory_base_addr = reg_perf_base_addr_update + {8'b0,module_addr_bais};
  assign memory_base_addr        = reg_perf_base_addr_update + {14'b0,module_addr_bais_r_sft6};
  assign addr_offset             = {M_N*N,2'b00};//in interval mode,every dump one time,address offset based last time. 
  assign addr_offset_r_sft6      = addr_offset[31:6]; 

  //new session start flag----------------------
  assign new_session_start = (reg_normal_mode_start || reg_perf_dump_trigger == 2'b10) && reg_perf_enable; 
  //-----------------------------------------------------------------------------------------

  //---------generate perf_mon dump status including "done,fail,overflow and interval mode last done"-------------------------
   
  assign perf_mon_done_pre = (perf_mon_bif_rtn_fence && perf_mon_bif_rtn_valid && perf_mon_bif_rtn_enable && reg_perf_enable);

  always @(posedge clk or negedge rst_n)begin
    if(~rst_n)
      perf_mon_done <= 1'b0;
      else
      perf_mon_done <= perf_mon_done_pre;
  end
  
  always @(posedge clk or negedge rst_n)begin
    if(~rst_n)
      perf_mon_done_cnt <= 24'b0;
    else if(clear)
      perf_mon_done_cnt <= 24'b0;
    else if(perf_mon_done_pre)
      perf_mon_done_cnt <= perf_mon_done_cnt + 1'b1;
  end

  assign perf_mon_fail_pre = (reg_normal_mode_start || reg_perf_dump_trigger == 2'b10) && (perf_mon_done_cnt != perf_mon_bif_fence_times)&&reg_perf_enable ;
  
  always @(posedge clk or negedge rst_n)begin
    if(~rst_n)
      perf_mon_fail <= 1'b0;
    else 
      perf_mon_fail <= perf_mon_fail_pre;
  end

  always @(posedge clk or negedge rst_n)begin
    if(~rst_n)
      perf_mon_obuf_overflow <= 1'b0;
    else if((!obuf_wrten_true && obuf_wrten) && (obuf_wrten_cnt == 2'd0))
      perf_mon_obuf_overflow <= 1'b1;
    else 
      perf_mon_obuf_overflow <= 1'b0;
  end

  always @(posedge clk or negedge rst_n)begin
    if(~rst_n)
      perf_mon_interval_end <= 1'b0;
    else if(normal_mode_flag)
      perf_mon_interval_end <= 1'b0;
    else if((perf_mon_done_pre)&&(perf_mon_done_cnt== perf_mon_bif_fence_times - 1'b1))
     perf_mon_interval_end <= 1'b1;
    else
     perf_mon_interval_end <= 1'b0;
  end

  //------------------------
  //-------submodule instantation-------------
  //1.submodule for N hot_cnt generate-------------
  generate 
    for(i=0;i<=N-1;i=i+1)begin:gen_hot_cnt_clear
      assign hot_cnt_clear[i] = dpram_wrt_en_pre && (dpram_wrt_addr_pre==i);
    end
  endgenerate
  
  generate 
    for(i=0;i<=N-1;i=i+1)begin:gen_hot_cnt
      hot_counter #(.M(W[i]+W_ADD)) 
        u_hot_counter(
         .clk             (clk),
         .rst_n           (rst_n),
         .perf_event      (perf_event[(M_P[i]+W[i]-1'b1):M_P[i]]),
         .hot_cnt_en      (hot_cnt_en),
         .hot_cnt         (hot_cnt[i]),
         .clear           (hot_cnt_clear[i] |new_session_start),
         .perf_event_o    (perf_event_mux[i])
        );
    end
  endgenerate

//--2.submodule dpram module------------------
mem_1r1w_perf_mon
 #(
  .MEM_WORDS(N), 
  .MEM_WIDTH(32), 
  .L2_MEM_WORDS(N_LOG2)) 
  u_gc_perf_mon_ram (
    .wr_clk      (clk),
    .wr_en       (dpram_wrt_en),
    .wr_addr     (dpram_wrt_addr),
    .din         (dpram_wdata),
    .rd_clk      (clk),
    .rd_en       (dpram_rd_en),
    .rd_addr     (dpram_rd_addr),
    .dout        (dpram_rdata)
);

//-----3.submodule obuf---------------------------
//gp_fifo #(
gp_fifo_reg #(
      .FIFO_WIDTH(BIF_DATA_WIDTH),
      .FIFO_WORDS(OBUF_DEPTH)//AXI_ID_WIDTH)  
        
     ) u_gc_perf_mon_obuf(
     
       .clk                 (clk),
       .reset_n             (rst_n),
       .rd_en               (obuf_rd_en),
       .dout                (obuf_rdata),
       .wr_en               (obuf_wrten_true),
       .din                 (obuf_wdata),
       .empty               (obuf_empty),
       .full                (obuf_full)
     );

//------4.submodule bif trans module for send data to memory by bif bus-------
gc_perf_mon_bif_trans u_gc_perf_mon_bif_trans(
 ///*autoinst*/
                                              // Outputs
                                              .obuf_data_ready                      (obuf_data_ready),
                                              .perf_mon_bif_cmd_valid               (perf_mon_bif_cmd_valid),
                                              .perf_mon_bif_cmd_operation           (perf_mon_bif_cmd_operation[3:0]),
                                              .perf_mon_bif_cmd_persistence         (perf_mon_bif_cmd_persistence[1:0]),
                                              .perf_mon_bif_cmd_ctxt_pasid          (perf_mon_bif_cmd_ctxt_pasid[5:0]),
                                              .perf_mon_bif_cmd_l1_policy           (perf_mon_bif_cmd_l1_policy[1:0]),
                                              .perf_mon_bif_cmd_l2_policy           (perf_mon_bif_cmd_l2_policy),
                                              .perf_mon_bif_cmd_l2_prefetch_size    (perf_mon_bif_cmd_l2_prefetch_size),
                                              .perf_mon_bif_cmd_vaddress            (perf_mon_bif_cmd_vaddress[41:0]),
                                              .perf_mon_bif_cmd_burst_length        (perf_mon_bif_cmd_burst_length[1:0]),
                                              .perf_mon_bif_cmd_tag_sb              (perf_mon_bif_cmd_tag_sb[6:0]),
                                              .perf_mon_bif_write_valid             (perf_mon_bif_write_valid),
                                              .perf_mon_bif_write_mask              (perf_mon_bif_write_mask[63:0]),
                                              .perf_mon_bif_write_data              (perf_mon_bif_write_data[511:0]),
                                              .perf_mon_bif_rtn_enable              (perf_mon_bif_rtn_enable),
                                              .perf_mon_bif_rtn_credit              (perf_mon_bif_rtn_credit),
                                              // Inputs
                                              .clk                                  (clk),
                                              .rst_n                                (rst_n),
                                              .clear                                (clear),
                                              .memory_base_addr                     (memory_base_addr[41:0]),
                                              .addr_offset_r_sft6                   (addr_offset_r_sft6[25:0]),
                                              .burst_data_num                       (burst_data_num[2:0]),
                                              .obuf_data_valid                      (obuf_data_valid),
                                              .obuf_rdata                           (obuf_rdata[511:0]),
                                              .reg_bif_cmd_persistence              (reg_bif_cmd_persistence[1:0]),
                                              .reg_bif_cmd_ctxt_pasid               (reg_bif_cmd_ctxt_pasid[5:0]),
                                              .reg_bif_cmd_l1_policy                (reg_bif_cmd_l1_policy[1:0]),
                                              .reg_bif_cmd_l2_policy                (reg_bif_cmd_l2_policy),
                                              .reg_bif_cmd_l2_prefetch_size         (reg_bif_cmd_l2_prefetch_size),
                                              .reg_fence_interval                   (reg_fence_interval[5:0]),
                                              .perf_mon_bif_cmd_enable              (perf_mon_bif_cmd_enable),
                                              .perf_mon_bif_write_enable            (perf_mon_bif_write_enable),
                                              .perf_mon_bif_rtn_valid               (perf_mon_bif_rtn_valid),
                                              .perf_mon_bif_rtn_fence               (perf_mon_bif_rtn_fence),
                                              .perf_mon_bif_rtn_data                (perf_mon_bif_rtn_data[511:0]),
                                              .perf_mon_bif_rtn_tag_sb              (perf_mon_bif_rtn_tag_sb[6:0]),
                                              .dump_ok_num                          (dump_ok_num),
                                              .overflow_cnt                         (overflow_cnt),
                                              .bif_cmd_data_atv_cnt                 (bif_cmd_data_atv_cnt),
                                              .fence_times_cal_over_r1              (fence_times_cal_over_r1),
                                              .perf_mon_bif_fence_times             (perf_mon_bif_fence_times),
                                              .perf_mon_last_dump_times             (perf_mon_last_dump_times),
                                              .fence_end                            (fence_end)
                                               );


endmodule
// Local Variables:
// verilog-library-directories:( "." )
// verilog-auto-inst-param-value:t
// End:

