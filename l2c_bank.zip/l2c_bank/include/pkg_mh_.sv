/*

 * #==========================================================================#
 * |                                                                          |
 * |  Copyright (c) 2022, Fantasy Technologies Limited and/or its         |
 * |  affiliated group companies ("Fantasy"). All rights reserved.        |
 * |  No part of this content, either material or conceptual may be copied    |
 * |  or distributed, transmitted, transcribed, stored in a retrieval system  |
 * |  or translated into any human or computer language in any form by any    |
 * |  means, electronic, mechanical manual, or otherwise, or disclosed to     |
 * |  third parties without the express written permission of Fantasy.    |
 * |                                                                          |
 * #==========================================================================#

 */


package pkg_mh_;




   localparam logic               IDLE_RESET_VALUE                                   = 1'b1;
   localparam int                 MAX_DFUS                                           = 73;
   //#ifdef NUM_SPC_10_12
   localparam int                 JONES_DFU_POSN                                     = 10;//12; //3
   localparam int                 NUM_DFUS                                           = 73;
   localparam int                 DFU_ID_BITS                                        = 7;
   localparam int                 MAX_DFU_ID_BITS                                    = 7;
   localparam int                 NUM_TPU_PER_SPC                                    = 3; //ori: 2
   localparam int                 BRIDGE_NUM_TCU_PORTS                               = 2; //ori: 1 modified by wuce01
   localparam int                 DFU_ID_VADDR_POSN                                  = 8;
   localparam int                 NUM_REAL_BIFS_PER_SPC                              = 2;


   localparam int                 NUM_SPCS_PER_GPC                                   = 2;
   localparam int                 NUM_TTTS_PER_SPC                                   = 2;
   localparam int                 NUM_TTTS_PER_GPC                                   = NUM_TTTS_PER_SPC*NUM_SPCS_PER_GPC;
   localparam int                 NUM_TTTS                                           = NUM_SPCS_PER_GPC*NUM_TTTS_PER_SPC*4;

   localparam int                 NUM_BIFS_PER_TTT                                   = 4;
   localparam int                 NUM_BIFS_PER_SPC                                   = NUM_BIFS_PER_TTT * NUM_TTTS_PER_SPC;
   localparam int                 SPCS_PER_GPC_NUM_BITS                              = $clog2(NUM_SPCS_PER_GPC);
   localparam int                 TTTS_PER_SPC_NUM_BITS                              = $clog2(NUM_TTTS_PER_SPC);
   localparam int                 TTTS_PER_GPC_NUM_BITS                              = $clog2(NUM_TTTS_PER_GPC);
   localparam int                 BIFS_PER_SPC_NUM_BITS                              = $clog2(NUM_BIFS_PER_SPC);
   localparam int                 BIFS_PER_TTT_NUM_BITS                              = $clog2(NUM_BIFS_PER_TTT);
   localparam int                 BIFS_ID_WIDTH_PER_GPC                              = SPCS_PER_GPC_NUM_BITS+TTTS_PER_SPC_NUM_BITS+BIFS_PER_TTT_NUM_BITS;

   localparam int                 NUM_BIFS                                           = 4 * NUM_SPCS_PER_GPC * NUM_TTTS_PER_SPC * NUM_BIFS_PER_TTT + 1;
   localparam int                 BIF_NUM_BITS                                       = $clog2(NUM_BIFS); 
   localparam int                 NUM_GPC_BIFS                                       = 4 * NUM_SPCS_PER_GPC * NUM_TTTS_PER_SPC * NUM_BIFS_PER_TTT; 



   localparam int                 NUM_REAL_BIFS                                      = 21; //7   2*SPC_NUM+1
   localparam int                 REAL_BIF_NUM_BITS                                  = 5; //3
   localparam int                 BIF_NUM_ROUNDED_UP_BITS                            = 6; //4
   localparam int                 BIF_ID_BITS                                        = 10; //7  //by luqj at 20230321, 9->10, BIF_NUM_BITS + EXT_REORDERED_ID_BITS, reordered_id: 3->4
   //localparam int                 NUM_BIFS                                         = 49; //13
   //localparam int                 NUM_REAL_BIFS                                    = 25; //7
   //localparam int                 REAL_BIF_NUM_BITS                                = 5; //3
   //localparam int                 BIF_NUM_BITS                                     = 6; //4
   //localparam int                 BIF_NUM_ROUNDED_UP_BITS                          = 6; //4
   //localparam int                 BIF_ID_BITS                                      = 9; //7
   //#endif NUM_SPC_10_12--
   //
   localparam int                 NUM_CP_FAULT_ARB_PORTS                             = 5;
   localparam int                 NUM_CP_FAULT_ARB_PORTS_WIDTH                       = $clog2(NUM_CP_FAULT_ARB_PORTS);
   localparam int                 NUM_MSS_MEM_PORTS                                  = 65; //   by luoml01 at 20240206, for GP3, 65 mem_port
   //localparam int                 NUM_MSS_MEM_PORTS                                  = 65; //   by luoml01 at 20240206, for GP3, 65 mem_port

   localparam int                 NUM_CHEST                                          = 16; // equal NUM_MSS_MEM_PORTS/gc_features_pack_::NUM_AXIBUS_PER_CHEST;
   localparam int                 NUM_CHEST_BITS                                     = 4;
   localparam int                 CHEST_NUM_MSS_MEM_PORTS                            = NUM_MSS_MEM_PORTS;
   localparam int                 MSS_MEM_PORT_BITS                                  = $clog2(NUM_MSS_MEM_PORTS);  //   by luoml01 at 20240206, for GP3, 65 mem_port
   localparam int                 CHEST_X1_MEM_PORT_BITS                             = 1;
   localparam int                 ASC_ADD_SLOTS_TO_CACHELINES                        = 44;
   localparam int                 ASC_NUM_SLOTS                                      = 300;
   localparam int                 ASC_NUM_SLOTS_BITS                                 = 9;
   localparam int                 ASC_64B_BURSTLENGTH                                = 1;
   localparam int                 ASC_128B_BURSTLENGTH                               = 3;
   localparam int                 ASC_64B_BURSTLENGTH_BITS                           = 1;
   localparam int                 ASC_128B_BURSTLENGTH_BITS                          = 2; 


   localparam int                 VADDR_PAGE_OFFSET_WIDTH                            = 7;
   localparam int                 VHA_INTERNAL_DATA_WIDTH                            = 256;
   localparam int                 VHA_INTERNAL_DATA_MASK_WIDTH                       = 32;
   localparam int                 VHA_VADDR_LOW                                      = 5;
   localparam int                 VHA_RDI_TAG_REUSE                                  = 1;
   localparam int                 VHA_RDI_TAG_REUSE_W                                = 1;
   localparam int                 NUM_L1_BANKS                                       = 4;
   localparam int                 L1_BANK_BITS                                       = 2;
   localparam int                 NUM_L1_SETS                                        = 8;
   localparam int                 L1_SET_BITS                                        = 3;
   localparam int                 L1_CACHELINE_SIZE                                  = 512;
   localparam int                 NUM_MCU_WAYS                                       = 16; //12
   localparam int                 NUM_TCU_WAYS                                       = 16; //12
   localparam int                 L1_MAX_WAY_BITS                                    = 4;
   localparam int                 VADDR_BITS_FBCDC                                   = 41;
   localparam int                 VADDR_BITS_NON_FBCDC                               = 48;
   localparam int                 VADDR_BITS_MCU_L1                                  = 41;
   localparam int                 VADDR_BITS_MSS                                     = 48;
   localparam int                 VADDR_BITS_MMU                                     = 48;
   localparam int                 VPAGE_BITS                                         = 28;
   localparam int                 PM_VPAGE_BITS                                      = 20;
   localparam int                 PPAGE_BITS                                         = 28;
   localparam int                 CTXT_RAM_DEPTH                                     = 32;

   localparam int                 NUM_OS_IDS                                         = 16;
   localparam int                 OS_ID_BITS                                         = 4;

//hanyd add
   localparam int                  TCU_ID_BITS                                       = 3;
   localparam int                  SWIFT0_TCU0_ID                                    = 0;
   localparam int                  SWIFT0_TCU1_ID                                    = 1;
   localparam int                  SWIFT1_TCU0_ID                                    = 2;
   localparam int                  SWIFT1_TCU1_ID                                    = 3;
   localparam int                  SWIFT2_TCU0_ID                                    = 4;
   localparam int                  SWIFT2_TCU1_ID                                    = 5;

//hanyd end
   localparam int                 EXT_REORDERED_ID_BITS                              = 4;   // by luqj at 20230601, for add tcu_id field, 3->4

   localparam int                 EXT_REORDERED_SO_SEQ_NUM_ID_BITS                   = 3;



   localparam int                 JONES_EXT_REORDERED_RPM_ID                         = 0;
   localparam int                 JONES_EXT_REORDERED_SO_REQ_ID                      = 6;
   localparam int                 TEXAS0_EXT_REORDERED_MCU_ID                        = 0;
   localparam int                 TEXAS0_EXT_REORDERED_TCU_ID                        = 1;
//hanyd add
   localparam int                 TEXAS0_EXT_REORDERED_TCU_ID_0                      = 7;
   localparam int                 TEXAS0_EXT_REORDERED_TCU_ID_1                      = 8;
   localparam int                 TEXAS0_EXT_REORDERED_TCU_ID_2                      = 9;
   localparam int                 TEXAS0_EXT_REORDERED_TCU_ID_3                      = 10;
   localparam int                 TEXAS0_EXT_REORDERED_TCU_ID_4                      = 11;
   localparam int                 TEXAS0_EXT_REORDERED_TCU_ID_5                      = 12;
//hanyd end   
   localparam int                 TEXAS0_EXT_REORDERED_TMC_ID                        = 13;

   localparam int                 TEXAS0_EXT_REORDERED_RAC_ID                        = 2;
   localparam int                 TEXAS0_EXT_REORDERED_AMC_ID                        = 3;
   localparam int                 TEXAS0_EXT_REORDERED_SO_REQ_ID                     = 6;
   localparam int                 TEXAS0_EXT_REORDERED_SO_PBE0_SEQ_NUM_ID            = 0;
   localparam int                 TEXAS0_EXT_REORDERED_SO_VCE_SEQ_NUM_ID             = 1;
   localparam int                 TEXAS0_EXT_REORDERED_SO_PPP_SEQ_NUM_ID             = 2;
   localparam int                 TEXAS0_EXT_REORDERED_SO_SHF_SEQ_NUM_ID             = 3;
   localparam int                 TEXAS0_EXT_REORDERED_SO_VDM_SEQ_NUM_ID             = 4;
   localparam int                 TEXAS0_EXT_REORDERED_SO_VCE_RTC_SEQ_NUM_ID         = 5;
   localparam int                 TEXAS1_EXT_REORDERED_MCU_ID                        = 0;
   localparam int                 TEXAS1_EXT_REORDERED_TCU_ID                        = 1;
//hanyd add
   localparam int                 TEXAS1_EXT_REORDERED_TCU_ID_0                      = 7;
   localparam int                 TEXAS1_EXT_REORDERED_TCU_ID_1                      = 8;
   localparam int                 TEXAS1_EXT_REORDERED_TCU_ID_2                      = 9;
   localparam int                 TEXAS1_EXT_REORDERED_TCU_ID_3                      = 10;
   localparam int                 TEXAS1_EXT_REORDERED_TCU_ID_4                      = 11;
   localparam int                 TEXAS1_EXT_REORDERED_TCU_ID_5                      = 12;
//hanyd end
   localparam int                 TEXAS1_EXT_REORDERED_TMC_ID                        = 13;

   localparam int                 TEXAS1_EXT_REORDERED_FBA_ID                        = 2;
   localparam int                 TEXAS1_EXT_REORDERED_SO_REQ_ID                     = 6;
   localparam int                 TEXAS1_EXT_REORDERED_SO_SHG_SEQ_NUM_ID             = 0;
   localparam int                 TEXAS1_EXT_REORDERED_SO_PBE1_SEQ_NUM_ID            = 1;

   localparam int                 TCUBRIDGE_EXT_REORDERED_TCU0_ID                    = 0;
   localparam int                 TCUBRIDGE_EXT_REORDERED_TCU1_ID                    = 1;
   localparam int                 TCUBRIDGE_EXT_REORDERED_TCU2_ID                    = 2;
//hanyd add
   localparam int                 TCUBRIDGE_EXT_REORDERED_TCU_ID_0                   = 7;
   localparam int                 TCUBRIDGE_EXT_REORDERED_TCU_ID_1                   = 8;
   localparam int                 TCUBRIDGE_EXT_REORDERED_TCU_ID_2                   = 9;
   localparam int                 TCUBRIDGE_EXT_REORDERED_TCU_ID_3                   = 10;
   localparam int                 TCUBRIDGE_EXT_REORDERED_TCU_ID_4                   = 11;
   localparam int                 TCUBRIDGE_EXT_REORDERED_TCU_ID_5                   = 12;
//hanyd end   
   
   localparam int                 TCUBRIDGE_EXT_REORDERED_TMC_ID                     = 13;
   
   localparam int                 AA_OPERATION_BITS                                  = 4;
   localparam int                 AA_IS_EVEN_PLACE                                   = AA_OPERATION_BITS;
   localparam int                 AA_IS_64_PLACE                                     = AA_IS_EVEN_PLACE + 1; 
   localparam int                 ROBUST_BUFFER_BASE_BITS                            = 41;
   localparam int                 ROBUST_BUFFER_SIZE_BITS                            = 32;


//-------------------------------------------------------------------------------------------
// for cp_bif/spc_bif config 2025 
//-------------------------------------------------------------------------------------------
   //ori parameter
   localparam int                 MEM_OPERATION_BITS                                 = 4;
   localparam int                 MH_PERSISTENCE_BITS                                = 2;
   localparam int                 SEQ_NUM_BITS                                       = 10;
   localparam int                 REQ_ID_BITS                                        = 6;
   localparam int                 BIF_DATA_BUS_WIDTH                                 = 512; // 
   localparam int                 VADDR_LOW                                          = 6;
   
  // // move from gc_features_pack_.sv
  // localparam int                 MH_CTXT_PASID_WIDTH                                = 6;   // by luqj at 20230420, 5->8, for 16chn_virtualization
  // localparam int                 MH_CTXT_PASID_WIDTH_LOG2                           = 3;
  // localparam int                 MH_CTXT_PASID_WIDTH_WIDTH                          = 3;

   localparam int                 MH_PASID_WIDTH                                = 10;   // by luqj at 20230420, 5->8, for 16chn_virtualization

   localparam int                 MH_VFID_WIDTH                                = 4;   // by luqj at 20230420, 5->8, for 16chn_virtualization

   // add
   localparam int                 VADDR_BIF_WIDTH                                    = 48;

   //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
   //   Enumerators
   //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

   typedef enum logic [3 : 0] {
      MEM_OPERATION_ENUM_MH_LOAD      = 4'b0000,
      MEM_OPERATION_ENUM_MH_TOUCH     = 4'b0001,
      MEM_OPERATION_ENUM_MH_STORE     = 4'b0100,
      MEM_OPERATION_ENUM_MH_ATOMIC32  = 4'b0101,
      MEM_OPERATION_ENUM_MH_ATOMIC64  = 4'b0110,
      MEM_OPERATION_ENUM_MH_ATOMICTST = 4'b0111,
      MEM_OPERATION_ENUM_MH_ATOMICFP32= 4'b1010,
      MEM_OPERATION_ENUM_MH_WR_FENCE  = 4'b1000,
      MEM_OPERATION_ENUM_MH_BARRIER   = 4'b1001,
      MEM_OPERATION_ENUM_MH_CCM_EVICT = 4'b1100,
      MEM_OPERATION_ENUM_MH_INVAL     = 4'b1101,
      MEM_OPERATION_ENUM_MH_FLUSH     = 4'b1110,
      MEM_OPERATION_ENUM_MH_FLUSHINV  = 4'b1111 
   } t_mem_operation_enum;

   typedef enum logic [3 : 0] {
      ATOMIC_OPERATION_ENUM_MH_AA_OP_ADD     = 4'b0000,
      ATOMIC_OPERATION_ENUM_MH_AA_OP_SUB     = 4'b0001,
      ATOMIC_OPERATION_ENUM_MH_AA_OP_XCHG    = 4'b0010,
      ATOMIC_OPERATION_ENUM_MH_AA_OP_CMPXCHG = 4'b0011,
      ATOMIC_OPERATION_ENUM_MH_AA_OP_UMIN    = 4'b0100,
      ATOMIC_OPERATION_ENUM_MH_AA_OP_IMIN    = 4'b0101,
      ATOMIC_OPERATION_ENUM_MH_AA_OP_UMAX    = 4'b0110,
      ATOMIC_OPERATION_ENUM_MH_AA_OP_IMAX    = 4'b0111,
      ATOMIC_OPERATION_ENUM_MH_AA_OP_AND     = 4'b1000,
      ATOMIC_OPERATION_ENUM_MH_AA_OP_OR      = 4'b1001,
      ATOMIC_OPERATION_ENUM_MH_AA_OP_XOR     = 4'b1010 
   } t_atomic_operation_enum;

   typedef enum logic [0 : 0] {
      MH_MCU_SUBREQ_ID_ENUM_C_PDS    = 1'b0,
      MH_MCU_SUBREQ_ID_ENUM_C_GLOBAL = 1'b1 
   } t_mh_mcu_subreq_id_enum;



endpackage
