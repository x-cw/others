

package pkg_axi_xbar_;

   localparam int                 R_CHANNEL_BUFFER_FIFO_DEPTH                                      = 10;
   localparam int                 W_CHANNEL_BUFFER_FIFO_DEPTH                                      = 8;

endpackage
