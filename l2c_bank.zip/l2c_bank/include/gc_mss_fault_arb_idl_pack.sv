// +FHDR----------------------------------------------------------------------------
// Copyright (c) 2025, Innosilicon, Inc. Confidential Proprietary
// PROJECT NAME  : xxx
// DEPARTMENT    : Digtal Frontend SOC
// AUTHOR        : luoml01
// EMAIL         : luoml01@innosilicon.com.cn
// CREATE ON     : 2025/02/28 15:41
// FILE NAME     : gc_mss_fault_arb_idl_pack.sv
// DESCRIPTION   :          
//         
// Copyright (c) 2025 Innosilicon.
// ALL RIGHTS RESERVED
// 
// ---------------------------------------------------------------------------------
// Modification History:
// Date         By              Version                 Change Description
// ---------------------------------------------------------------------------------
// 2025/02/28   luoml01         1.0                     Original
// 
// -FHDR----------------------------------------------------------------------------


package gc_mss_fault_arb_idl_pack;


    //typedef logic   [                                                1                   :  0 ]    t_if_spc_fault_rnw;
    //typedef logic   [                                                1                   :  0 ]    t_if_spc_fault_type;
    //typedef logic   [                                                3                   :  0 ]    t_if_spc_fault_level;
    //typedef logic   [ pkg_mh_::BIFS_PER_SPC_NUM_BITS                                  -1 :  0 ]    t_if_spc_fault_bif_id;
    //typedef logic   [ pkg_mh_::REQ_ID_BITS                                            -1 :  0 ]    t_if_spc_fault_req_id;
    //typedef logic   [ pkg_mh_::MH_PASID_WIDTH                                         -1 :  0 ]    t_if_spc_fault_pasid;
    //typedef logic   [ pkg_mh_::MH_VFID_WIDTH                                          -1 :  0 ]    t_if_spc_fault_vfid;
    //typedef logic   [ pkg_mh_::VADDR_BITS_MMU                                         -1 :  6 ]    t_if_spc_fault_vaddress;


    //typedef logic   [                                                1                   :  0 ]    t_if_gpc_fault_rnw;
    //typedef logic   [                                                1                   :  0 ]    t_if_gpc_fault_type;
    //typedef logic   [                                                3                   :  0 ]    t_if_gpc_fault_level;
    //typedef logic   [ pkg_mh_::BIFS_ID_WIDTH_PER_GPC -1                                  :  0 ]    t_if_gpc_fault_bif_id;
    //typedef logic   [ pkg_mh_::REQ_ID_BITS                                            -1 :  0 ]    t_if_gpc_fault_req_id;
    //typedef logic   [ pkg_mh_::MH_PASID_WIDTH                                         -1 :  0 ]    t_if_gpc_fault_pasid;
    //typedef logic   [ pkg_mh_::MH_VFID_WIDTH                                          -1 :  0 ]    t_if_gpc_fault_vfid;
    //typedef logic   [ pkg_mh_::VADDR_BITS_MMU                                         -1 :  6 ]    t_if_gpc_fault_vaddress;



    typedef logic   [                                                1          :  0 ]    t_if_mss_fault_rnw;
    typedef logic   [                                                1          :  0 ]    t_if_mss_fault_type;
    typedef logic   [                                                3          :  0 ]    t_if_mss_fault_level;
    typedef logic   [ pkg_mh_::BIFS_ID_WIDTH_PER_GPC  -1                        :  0 ]    t_if_mss_fault_bif_id;
    typedef logic   [ pkg_mh_::REQ_ID_BITS                          -1          :  0 ]    t_if_mss_fault_req_id;
    typedef logic   [ pkg_mh_::MH_PASID_WIDTH                       -1          :  0 ]    t_if_mss_fault_pasid;
    typedef logic   [ pkg_mh_::MH_VFID_WIDTH                        -1          :  0 ]    t_if_mss_fault_vfid;
    typedef logic   [ pkg_mh_::VADDR_BITS_MMU                       -1          :  6 ]    t_if_mss_fault_vaddress;

    typedef t_if_mss_fault_rnw      t_if_cp_fault_rnw     ;
    typedef t_if_mss_fault_type     t_if_cp_fault_type    ;
    typedef t_if_mss_fault_level    t_if_cp_fault_level   ;
    typedef t_if_mss_fault_req_id   t_if_cp_fault_req_id  ;
    typedef t_if_mss_fault_pasid    t_if_cp_fault_pasid   ;
    typedef t_if_mss_fault_vfid     t_if_cp_fault_vfid    ;
    typedef t_if_mss_fault_vaddress t_if_cp_fault_vaddress;
    typedef logic   [ pkg_mh_::BIFS_ID_WIDTH_PER_GPC -1  :  0 ]    t_if_cp_fault_bif_id;

    typedef t_if_mss_fault_rnw      t_if_spc_fault_rnw     ;
    typedef t_if_mss_fault_type     t_if_spc_fault_type    ;
    typedef t_if_mss_fault_level    t_if_spc_fault_level   ;
    typedef t_if_mss_fault_req_id   t_if_spc_fault_req_id  ;
    typedef t_if_mss_fault_pasid    t_if_spc_fault_pasid   ;
    typedef t_if_mss_fault_vfid     t_if_spc_fault_vfid    ;
    typedef t_if_mss_fault_vaddress t_if_spc_fault_vaddress;
    typedef logic   [ pkg_mh_::BIFS_PER_TTT_NUM_BITS -1 :  0 ]    t_if_spc_fault_bif_id;
    
    typedef t_if_mss_fault_rnw      t_if_gpc_fault_rnw     ;
    typedef t_if_mss_fault_type     t_if_gpc_fault_type    ;
    typedef t_if_mss_fault_level    t_if_gpc_fault_level   ;
    typedef t_if_mss_fault_req_id   t_if_gpc_fault_req_id  ;
    typedef t_if_mss_fault_pasid    t_if_gpc_fault_pasid   ;
    typedef t_if_mss_fault_vfid     t_if_gpc_fault_vfid    ;
    typedef t_if_mss_fault_vaddress t_if_gpc_fault_vaddress;
    typedef logic   [ pkg_mh_::BIFS_ID_WIDTH_PER_GPC -1  :  0 ]    t_if_gpc_fault_bif_id;



    typedef struct packed {
        t_if_spc_fault_type                                       fault_type;
        t_if_spc_fault_rnw                                        rnw;
        t_if_spc_fault_level                                      level;
        t_if_spc_fault_bif_id                                     bif_id;
        t_if_spc_fault_req_id                                     req_id;
        t_if_spc_fault_pasid                                      pasid;
        t_if_spc_fault_vfid                                       vfid;
        t_if_spc_fault_vaddress                                   vaddress;
    } t_if_spc_fault_rec;

    typedef struct packed {
        t_if_gpc_fault_type                                       fault_type;
        t_if_gpc_fault_rnw                                        rnw;
        t_if_gpc_fault_level                                      level;
        t_if_gpc_fault_bif_id                                     bif_id;
        t_if_gpc_fault_req_id                                     req_id;
        t_if_gpc_fault_pasid                                      pasid;
        t_if_gpc_fault_vfid                                       vfid;
        t_if_gpc_fault_vaddress                                   vaddress;
    } t_if_gpc_fault_rec;


    typedef struct packed {
        t_if_cp_fault_type                                       fault_type;
        t_if_cp_fault_rnw                                        rnw;
        t_if_cp_fault_level                                      level;
        t_if_cp_fault_bif_id                                     bif_id;
        t_if_cp_fault_req_id                                     req_id;
        t_if_cp_fault_pasid                                      pasid;
        t_if_cp_fault_vfid                                       vfid;
        t_if_cp_fault_vaddress                                   vaddress;
    } t_if_cp_fault_rec;

endpackage





// Local Variables:
// verilog-library-flags:("-y ./ -y ../")
// verilog-auto-inst-param-value:t
// End:
