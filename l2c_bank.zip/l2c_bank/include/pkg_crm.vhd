
-- #==========================================================================#
-- |                                                                          |
-- |  Copyright (c) 2022, Fantasy Technologies Limited and/or its         |
-- |  affiliated group companies ("Fantasy"). All rights reserved.        |
-- |  No part of this content, either material or conceptual may be copied    |
-- |  or distributed, transmitted, transcribed, stored in a retrieval system  |
-- |  or translated into any human or computer language in any form by any    |
-- |  means, electronic, mechanical manual, or otherwise, or disclosed to     |
-- |  third parties without the express written permission of Fantasy.    |
-- |                                                                          |
-- #==========================================================================#



library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
library work;





package pkg_crm is

   constant JONES_COMPUTE_DMN               : natural                                       := 2;
   constant JONES_VERTEX_DMN                : natural                                       := 2;
   constant JONES_PIXEL_DMN                 : natural                                       := 1;
   constant JONES_SYS_DMN                   : natural                                       := 2;
   constant JONES_BIF_DMN                   : natural                                       := 1;
   constant JONES_TDM_DMN                   : natural                                       := 1;
   constant JONES_PM_DMN                    : natural                                       := 1;
   constant JONES_RCE_DMN                   : natural                                       := 1;
   constant JONES_ASC_DMN                   : natural                                       := 1;
   constant FBCDC_FBCACHE_DMN               : natural                                       := 2;
   constant FBCDC_FBC_DMN                   : natural                                       := 2;
   constant FBCDC_FBDC_DMN                  : natural                                       := 2;
   constant FBCDC_FBM_DMN                   : natural                                       := 3;
   constant TEXAS_BIF_DMN                   : natural                                       := 2;
   constant TEXAS_MCU_L1_DMN                : natural                                       := 1;
   constant TEXAS_PDS_DMN                   : natural                                       := 2;
   constant TEXAS_PBE_DMN                   : natural                                       := 1;
   constant TEXAS_CPC_PIPE_DMN              : natural                                       := 1;
   constant MERCER_CU_DMN                  : natural                                       := 40;
   constant MERCER_CU_PIPES_SMP_IDX        : natural                                       := 0;
   constant MERCER_CU_PIPES_DMA_IDX        : natural                                       := 1;
   constant MERCER_CU_PIPES_EMI_IDX        : natural                                       := 2;
   constant MERCER_CU_PIPES_ITR_IDX        : natural                                       := 3;
   constant MERCER_CU_PIPES_CPX_IDX        : natural                                       := 4;
   constant MERCER_CU_PIPES_MOV_IDX        : natural                                       := 5;
   constant MERCER_CU_PIPES_EMIPSB_IDX     : natural                                       := 6;
   constant MERCER_CU_PIPES_TPX_IDX        : natural                                       := 7;
   constant MERCER_CU_PIPES_PAP_CMN_IDX    : natural                                       := 8;
   constant MERCER_CU_PIPES_PAP_FOP_IDX    : natural                                       := 9;
   constant MERCER_CU_PIPES_PAP_DOT_IDX    : natural                                       := 10;
   constant MERCER_CU_PIPES_SAP_IDX        : natural                                       := 11;
   constant MERCER_CU_PIPES_AP_IDX         : natural                                       := 12;
   constant MERCER_CU_PIPES_TENSOR_IDX     : natural                                       := 13;
   constant MERCER_CU_PIPES_TMA_IDX        : natural                                       := 14;
   constant MERCER_CU_PIPES_DMN            : natural                                       := 15;
   constant MERCER_ISP_DMN                  : natural                                       := 1;
   constant MERCER_MCU_L0_DMN               : natural                                       := 2;
   constant TEXAS_GEOM_SHARED_DMN           : natural                                       := 3;
   constant TEXAS_GEOM_TESS_DMN             : natural                                       := 2;
   constant TEXAS_GEOM_VERTEX_DMN           : natural                                       := 7;
   constant TEXAS_RAST_IPF_CLK_DMN          : natural                                       := 2;
   constant TEXAS_RAST_TPF_CLK_DMN          : natural                                       := 2;
   constant SWIFT_TCU_DMN                   : natural                                       := 2;
   constant SWIFT_CUL2CACHE_DMN            : natural                                       := 1;
   constant SWIFT_TPU_DMN                   : natural                                       := 3;
   constant SWIFT_YUV_DMN                   : natural                                       := 1;
   constant SWIFT_FP_DMN                    : natural                                       := 1;
   constant SWIFT_INT_DMN                   : natural                                       := 1;
   constant SWIFT_ASTC_DMN                  : natural                                       := 1;
   constant SWIFT_TF_DMN                    : natural                                       := 1;
   constant SWIFT_TAG_DMN                   : natural                                       := 1;
   constant SWIFT_MADD_DMN                  : natural                                       := 1;
   constant TIW                             : natural                                       := 1;
   constant TOW                             : natural                                       := 1;
   constant CRM_WAKEUP_TO_CLKEN_CLK_DELAY   : natural                                       := 1;
   constant RAC_RTS_DMN                     : natural                                       := 1;
   constant RAC_PCG_DMN                     : natural                                       := 1;
   constant RAC_BPS_DMN                     : natural                                       := 1;
   constant RAC_RS_DMN                      : natural                                       := 1;
   constant RAC_RRC_DMN                     : natural                                       := 1;
   constant RAC_URI_DMN                     : natural                                       := 1;


end package pkg_crm;

package body pkg_crm is

end package body pkg_crm;
