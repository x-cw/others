/*

 * #==========================================================================#
 * |                                                                          |
 * |  Copyright (c) 2022, Fantasy Technologies Limited and/or its         |
 * |  affiliated group companies ("Fantasy"). All rights reserved.        |
 * |  No part of this content, either material or conceptual may be copied    |
 * |  or distributed, transmitted, transcribed, stored in a retrieval system  |
 * |  or translated into any human or computer language in any form by any    |
 * |  means, electronic, mechanical manual, or otherwise, or disclosed to     |
 * |  third parties without the express written permission of Fantasy.    |
 * |                                                                          |
 * #==========================================================================#

 */


package pkg_soc_;




   localparam int                 AXIBUS_SOCIF_TAGIDS_WIDTH                          = 6;
   localparam int                 AXIBUS_SOCIF_XPU_TAGIDS_WIDTH                      = 6;
   localparam int                 SINGLE_CLOCK_DOMAIN                                = 1;
   localparam int                 FB_CDC_CYUV_CTRL                                   = 0;
   localparam int                 MSS_SIZE_ADJUSTMENT                                = 3;   // by luqj at 20230222, for 8M mss bank, 1 -> 3
   localparam int                 TB_MULTICORE                                       = 90;
   localparam int                 TB_AXI_ACE_COHERENCY_MODE                          = 3;
//   localparam int                 DDR_EXPAND_ENABLE                                  = 1;

   //SERIES_ID.PRODUCT_ID.RELEASE_ID   
   //0.0.0 IMG ORIGIN
   //1.0.0 GP1
   //1.1.0 GP2
   //2.0.0 G3_10SPC_3CU
   //2.1.0 G3_2SPC_3CU
   localparam logic [15: 0]      SERIES_ID                                           = 16'd1;
   localparam logic [15: 0]      PRODUCT_ID                                          = 16'd3;
   localparam logic [31: 0]      RELEASE_ID                                          = 32'd0;




endpackage
