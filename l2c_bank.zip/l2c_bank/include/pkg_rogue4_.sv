/*

 * #==========================================================================#
 * |                                                                          |
 * |  Copyright (c) 2022, Fantasy Technologies Limited and/or its         |
 * |  affiliated group companies ("Fantasy"). All rights reserved.        |
 * |  No part of this content, either material or conceptual may be copied    |
 * |  or distributed, transmitted, transcribed, stored in a retrieval system  |
 * |  or translated into any human or computer language in any form by any    |
 * |  means, electronic, mechanical manual, or otherwise, or disclosed to     |
 * |  third parties without the express written permission of Fantasy.    |
 * |                                                                          |
 * #==========================================================================#

 */


package pkg_rogue4_;




   localparam int                 RESYNC_BANKS                                       = 12;
   localparam int                 RESYNC_LOGBANKS                                    = 4;
   localparam int                 RESYNC_SDEPTH                                      = 3; //BUG3307 keep the parameter same as origin design, soc_timer use the constant 9 for the timing fix;

   localparam int                 FLOPSYNC_DEPTH                                     = 4;
   localparam int                 TILE_ID_BITS                                       = 4;
   localparam int                 SLOT_BITS                                          = 5;//2025.1.17 gp3 modified
   localparam int                 NUM_TE_PIPES                                       = 2;
   localparam int                 NUM_TE_PIPE_BITS                                   = 1;
   localparam int                 TASK_IDS                                           = 64;
   localparam int                 TASK_ID_BITS                                       = 6;
   localparam int                 NUM_TASKS                                          = 64;
   localparam int                 TASK_BITS                                          = 6;
   localparam int                 NUM_FC                                             = 2;
   localparam int                 FC_BITS                                            = 3;
   localparam int                 NUM_TESS_DM                                        = 1;
   localparam int                 PARTITION_STORE_DWORD_STORAGE                      = 32768;
   localparam int                 PS_MEM_BANK_DEPTH                                  = 1024;
   localparam int                 MIN_PIXEL_OUTPUT_DWORDS_PER_SAMPLE                 = 2;
   localparam int                 MAX_PIXEL_OUTPUT_DWORDS_PER_SAMPLE                 = 8;
   localparam int                 MAX_SAMPLES_PER_TILE                               = 2048;
   localparam int                 MAX_PIXELS_PER_TILE                                = 1024;
   localparam int                 NUM_PARTITIONS                                     = 16;
   localparam int                 USED_PARTITION_BITS                                = 4;
   localparam int                 ICTRL_L1CACHE_NUM_TAGS                             = 32;
   localparam int                 CUC_L1CACHE_NUM_TAGS                              = 32;
   localparam int                 CUC_L1CACHE_TAG_BITS                              = 5;
   localparam int                 CUC_L1CACHE_TOP_NUM_TAGS                          = 64;
   localparam int                 CUC_L1CACHE_TOP_TAG_BITS                          = 6;
   localparam int                 ICTRL_L1CACHE_TAG_BITS                             = 5;
   localparam int                 ICTRL_L1CACHE_TOP_NUM_TAGS                         = 64;
   localparam int                 ICTRL_L1CACHE_TOP_TAG_BITS                         = 6;
   localparam int                 STM_INSTANCE_MAX                                   = 4;
   localparam int                 STM_INSTANCE_MAX_BITS                              = 2;
   localparam int                 FSR_FRAG_HEIGHT_BITS                               = 2;
   localparam int                 FSR_FRAG_WIDTH_BITS                                = 2;
   localparam int                 MAX_FRAGMENT_SAMPLES                               = 16;
   localparam int                 MAX_FRAGMENT_SAMPLES_BITS                          = 4;
   localparam int                 NUM_TE                                        = 4;// for multi te wangbz01 20231228
   localparam int                 NUM_TE_BITS                                   = 2; 



   //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
   //   Enumerators
   //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

   typedef enum logic [1 : 0] {
      E_FSR_FRAG_HEIGHT_TYPE_X1 = 2'b00,
      E_FSR_FRAG_HEIGHT_TYPE_X2 = 2'b01,
      E_FSR_FRAG_HEIGHT_TYPE_X4 = 2'b10 
   } t_e_fsr_frag_height_type;

   typedef enum logic [1 : 0] {
      E_FSR_FRAG_WIDTH_TYPE_X1 = 2'b00,
      E_FSR_FRAG_WIDTH_TYPE_X2 = 2'b01,
      E_FSR_FRAG_WIDTH_TYPE_X4 = 2'b10 
   } t_e_fsr_frag_width_type;



endpackage
