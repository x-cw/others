
-- #==========================================================================#
-- |                                                                          |
-- |  Copyright (c) 2022, Fantasy Technologies Limited and/or its         |
-- |  affiliated group companies ("Fantasy"). All rights reserved.        |
-- |  No part of this content, either material or conceptual may be copied    |
-- |  or distributed, transmitted, transcribed, stored in a retrieval system  |
-- |  or translated into any human or computer language in any form by any    |
-- |  means, electronic, mechanical manual, or otherwise, or disclosed to     |
-- |  third parties without the express written permission of Fantasy.    |
-- |                                                                          |
-- #==========================================================================#



library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
library work;





package pkg_axi is

   --constant AXI_USER_BITS                   : natural                                       := 14;                     --  7->14 for GP3 by luoml01
   constant NUM_AXI_RIDS                    : natural                                       := 512;                    --  128->256, for GP3 by luoml01
   constant AXI_RID_BITS                    : natural                                       := 9;                      --  7->8, by for GP3 by luoml01
   constant NUM_AXI_WIDS                    : natural                                       := 256;                    --  64->128, for GP3 by luoml01
   constant AXI_WID_BITS                    : natural                                       := 8;                      --  6->7, for GP3 by luoml01
   constant NUM_CLB_RESERVED_WIDS           : natural                                       := 2;
   constant AXI_BUS_WIDTH                   : natural                                       := 512;                    --  256->512 for GP3
   constant ADDR_LOW                        : natural                                       := 6;                      --  5->6 for GP3
   constant PROT_SECURE                     : std_logic                                     := '0';
   constant PROT_NON_SECURE                 : std_logic                                     := '1';
   constant INCREMENTING                    : std_logic_vector(1 downto 0)                  := B"01";
   constant WRAPPING                        : std_logic_vector(1 downto 0)                  := B"10";
   constant AXI_ADDRESS_WIDTH               : natural                                       := 49;

   ----------------------------------------------------------------------------------------------------------------------------------
   --   Enumerators
   ----------------------------------------------------------------------------------------------------------------------------------
   attribute enum_encoding : string;

   type t_e_axi_feature_support_type is (
      FULL_ACE_ALL_128B   , -- 000
      FULL_ACE_C64B_NC128B, -- 001
      FULL_ACE_ALL_64B    , -- 010
      ACE_LITE_ALL_128B   , -- 011
      ACE_LITE_C64B_NC128B, -- 100
      ACE_LITE_ALL_64B    , -- 101
      NO_COHERENCY_128B   , -- 110
      NO_COHERENCY_64B      -- 111
   );
   attribute enum_encoding of t_e_axi_feature_support_type : type is "000 001 010 011 100 101 110 111";
   constant E_AXI_FEATURE_SUPPORT_TYPE_FULL_ACE_ALL_128B    : std_logic_vector(2 downto 0) := "000";
   constant E_AXI_FEATURE_SUPPORT_TYPE_FULL_ACE_C64B_NC128B : std_logic_vector(2 downto 0) := "001";
   constant E_AXI_FEATURE_SUPPORT_TYPE_FULL_ACE_ALL_64B     : std_logic_vector(2 downto 0) := "010";
   constant E_AXI_FEATURE_SUPPORT_TYPE_ACE_LITE_ALL_128B    : std_logic_vector(2 downto 0) := "011";
   constant E_AXI_FEATURE_SUPPORT_TYPE_ACE_LITE_C64B_NC128B : std_logic_vector(2 downto 0) := "100";
   constant E_AXI_FEATURE_SUPPORT_TYPE_ACE_LITE_ALL_64B     : std_logic_vector(2 downto 0) := "101";
   constant E_AXI_FEATURE_SUPPORT_TYPE_NO_COHERENCY_128B    : std_logic_vector(2 downto 0) := "110";
   constant E_AXI_FEATURE_SUPPORT_TYPE_NO_COHERENCY_64B     : std_logic_vector(2 downto 0) := "111";

   function to_slv(i : t_e_axi_feature_support_type ) return std_logic_vector;
   function to_t_e_axi_feature_support_type(i : std_logic_vector(2 downto 0)) return t_e_axi_feature_support_type;
end package pkg_axi;

package body pkg_axi is

   -- conversion function for e_axi_feature_support_type enumerator
   function to_slv(i : t_e_axi_feature_support_type ) return std_logic_vector is
      variable ret : std_logic_vector(2 downto 0);
   begin
      case i is
         when FULL_ACE_ALL_128B    => ret := E_AXI_FEATURE_SUPPORT_TYPE_FULL_ACE_ALL_128B;
         when FULL_ACE_C64B_NC128B => ret := E_AXI_FEATURE_SUPPORT_TYPE_FULL_ACE_C64B_NC128B;
         when FULL_ACE_ALL_64B     => ret := E_AXI_FEATURE_SUPPORT_TYPE_FULL_ACE_ALL_64B;
         when ACE_LITE_ALL_128B    => ret := E_AXI_FEATURE_SUPPORT_TYPE_ACE_LITE_ALL_128B;
         when ACE_LITE_C64B_NC128B => ret := E_AXI_FEATURE_SUPPORT_TYPE_ACE_LITE_C64B_NC128B;
         when ACE_LITE_ALL_64B     => ret := E_AXI_FEATURE_SUPPORT_TYPE_ACE_LITE_ALL_64B;
         when NO_COHERENCY_128B    => ret := E_AXI_FEATURE_SUPPORT_TYPE_NO_COHERENCY_128B;
         when others               => ret := E_AXI_FEATURE_SUPPORT_TYPE_NO_COHERENCY_64B;
      end case;
      return ret;
   end function;
   -- conversion function for e_axi_feature_support_type enumerator
   function to_t_e_axi_feature_support_type(i : std_logic_vector(2 downto 0)) return t_e_axi_feature_support_type is
      variable ret : t_e_axi_feature_support_type;
   begin
      case i is
         when E_AXI_FEATURE_SUPPORT_TYPE_FULL_ACE_ALL_128B    => ret := FULL_ACE_ALL_128B;
         when E_AXI_FEATURE_SUPPORT_TYPE_FULL_ACE_C64B_NC128B => ret := FULL_ACE_C64B_NC128B;
         when E_AXI_FEATURE_SUPPORT_TYPE_FULL_ACE_ALL_64B     => ret := FULL_ACE_ALL_64B;
         when E_AXI_FEATURE_SUPPORT_TYPE_ACE_LITE_ALL_128B    => ret := ACE_LITE_ALL_128B;
         when E_AXI_FEATURE_SUPPORT_TYPE_ACE_LITE_C64B_NC128B => ret := ACE_LITE_C64B_NC128B;
         when E_AXI_FEATURE_SUPPORT_TYPE_ACE_LITE_ALL_64B     => ret := ACE_LITE_ALL_64B;
         when E_AXI_FEATURE_SUPPORT_TYPE_NO_COHERENCY_128B    => ret := NO_COHERENCY_128B;
         when others                                          => ret := NO_COHERENCY_64B;
      end case;
      return ret;
   end function;

end package body pkg_axi;
