
-- #==========================================================================#
-- |                                                                          |
-- |  Copyright (c) 2022, Fantasy Technologies Limited and/or its         |
-- |  affiliated group companies ("Fantasy"). All rights reserved.        |
-- |  No part of this content, either material or conceptual may be copied    |
-- |  or distributed, transmitted, transcribed, stored in a retrieval system  |
-- |  or translated into any human or computer language in any form by any    |
-- |  means, electronic, mechanical manual, or otherwise, or disclosed to     |
-- |  third parties without the express written permission of Fantasy.    |
-- |                                                                          |
-- #==========================================================================#



library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
library work;





package pkg_gc_debug_tag_const is

   constant GC_DEBUG_TAG_VTX_DM_BITS       : natural                                       := 3;
   constant GC_DEBUG_TAG_VTX_KICK_BITS     : natural                                       := 12;
   constant GC_DEBUG_TAG_VTX_GENERATION_BITS: natural                                       := 4;
   constant GC_DEBUG_TAG_VTX_SPC_BITS      : natural                                       := 8;
   constant GC_DEBUG_TAG_VTX_PIM_BITS      : natural                                       := 32;
   constant GC_DEBUG_TAG_VTX_OBJECT_BITS   : natural                                       := 32;
   constant GC_DEBUG_TAG_VTX_BLOCK_ID_BITS : natural                                       := 32;
   constant GC_DEBUG_TAG_VTX_DATATYPE_BITS : natural                                       := 2;
   constant GC_DEBUG_TAG_VTX_VCECOUNT_BITS : natural                                       := 6;
   constant GC_DEBUG_TAG_VTX_TASK_BITS     : natural                                       := 32;
   constant GC_DEBUG_TAG_VTX_INST_0_BITS   : natural                                       := 7;
   constant GC_DEBUG_TAG_VTX_INST_1_BITS   : natural                                       := 7;
   constant GC_DEBUG_TAG_VTX_BASE_ADDR_BITS: natural                                       := 16;
   constant GC_DEBUG_TAG_VTX_INSTRUCTION_ID_BITS: natural                                       := 16;
   constant GC_DEBUG_TAG_VTX_GPU_ID_BITS   : natural                                       := 3;
   constant GC_DEBUG_TAG_VTX_BITS          : natural                                       := 212;
   constant GC_DEBUG_TAG_TSV_DM_BITS       : natural                                       := 3;
   constant GC_DEBUG_TAG_TSV_KICK_BITS     : natural                                       := 12;
   constant GC_DEBUG_TAG_TSV_GENERATION_BITS: natural                                       := 4;
   constant GC_DEBUG_TAG_TSV_SPC_BITS      : natural                                       := 8;
   constant GC_DEBUG_TAG_TSV_PIM_BITS      : natural                                       := 32;
   constant GC_DEBUG_TAG_TSV_OBJECT_BITS   : natural                                       := 32;
   constant GC_DEBUG_TAG_TSV_BLOCK_ID_BITS : natural                                       := 32;
   constant GC_DEBUG_TAG_TSV_DATATYPE_BITS : natural                                       := 2;
   constant GC_DEBUG_TAG_TSV_VCECOUNT_BITS : natural                                       := 6;
   constant GC_DEBUG_TAG_TSV_TASK_BITS     : natural                                       := 32;
   constant GC_DEBUG_TAG_TSV_INST_0_BITS   : natural                                       := 7;
   constant GC_DEBUG_TAG_TSV_INST_1_BITS   : natural                                       := 7;
   constant GC_DEBUG_TAG_TSV_BASE_ADDR_BITS: natural                                       := 16;
   constant GC_DEBUG_TAG_TSV_INSTRUCTION_ID_BITS: natural                                       := 16;
   constant GC_DEBUG_TAG_TSV_GPU_ID_BITS   : natural                                       := 3;
   constant GC_DEBUG_TAG_TSV_BITS          : natural                                       := 212;
   constant GC_DEBUG_TAG_CMP_DM_BITS       : natural                                       := 3;
   constant GC_DEBUG_TAG_CMP_KICK_BITS     : natural                                       := 12;
   constant GC_DEBUG_TAG_CMP_GENERATION_BITS: natural                                       := 4;
   constant GC_DEBUG_TAG_CMP_BLOCK_ID_BITS : natural                                       := 32;
   constant GC_DEBUG_TAG_CMP_GROUP_ID_BITS : natural                                       := 32;
   constant GC_DEBUG_TAG_CMP_TASK_BITS     : natural                                       := 32;
   constant GC_DEBUG_TAG_CMP_INST_0_BITS   : natural                                       := 7;
   constant GC_DEBUG_TAG_CMP_INST_1_BITS   : natural                                       := 7;
   constant GC_DEBUG_TAG_CMP_BASE_ADDR_BITS: natural                                       := 16;
   constant GC_DEBUG_TAG_CMP_INSTRUCTION_ID_BITS: natural                                       := 16;
   constant GC_DEBUG_TAG_CMP_GPU_ID_BITS   : natural                                       := 3;

   constant GC_DEBUG_TAG_CMP_SUBGROUPID_BITS     : natural                                 := 3;
   constant GC_DEBUG_TAG_CMP_TEMPALLOCATED_BITS  : natural                                 := 1;
   constant GC_DEBUG_TAG_CMP_TEMPBASEADDR_BITS   : natural                                 := 9;
   constant GC_DEBUG_TAG_CMP_ATTRALLOCATED_BITS  : natural                                 := 1;
   constant GC_DEBUG_TAG_CMP_ATTRBASEADDR_BITS   : natural                                 := 9;
   constant GC_DEBUG_TAG_CMP_SHAREDBASEADDR_BITS : natural                                 := 7;
   constant GC_DEBUG_TAG_CMP_LMSBASEADDR_BITS    : natural                                 := 10;
   constant GC_DEBUG_TAG_CMP_CFSBASEADDR_BITS    : natural                                 := 9;
   constant GC_DEBUG_TAG_CMP_TASKTYPE_BITS       : natural                                 := 3;
   
   constant GC_DEBUG_TAG_CMP_BITS          : natural                                       := 216;
   constant GC_DEBUG_TAG_F2D_DM_BITS       : natural                                       := 3;
   constant GC_DEBUG_TAG_F2D_KICK_BITS     : natural                                       := 12;
   constant GC_DEBUG_TAG_F2D_BLIT_BITS     : natural                                       := 16;
   constant GC_DEBUG_TAG_F2D_TILE_X_BITS   : natural                                       := 11;
   constant GC_DEBUG_TAG_F2D_TILE_Y_BITS   : natural                                       := 11;
   constant GC_DEBUG_TAG_F2D_GENERATION_BITS: natural                                       := 4;
   constant GC_DEBUG_TAG_F2D_OBJECT_BITS   : natural                                       := 32;
   constant GC_DEBUG_TAG_F2D_TASK_BITS     : natural                                       := 32;
   constant GC_DEBUG_TAG_F2D_INST_IN_BLOCK_BITS: natural                                       := 2;
   constant GC_DEBUG_TAG_F2D_INST_IN_TASK_BITS: natural                                       := 7;
   constant GC_DEBUG_TAG_F2D_PHASE_BITS    : natural                                       := 1;
   constant GC_DEBUG_TAG_F2D_SAMPLE_BITS   : natural                                       := 4;
   constant GC_DEBUG_TAG_F2D_BLOCK_X_0_BITS: natural                                       := 4;
   constant GC_DEBUG_TAG_F2D_BLOCK_Y_0_BITS: natural                                       := 4;
   constant GC_DEBUG_TAG_F2D_BLOCK_X_1_BITS: natural                                       := 4;
   constant GC_DEBUG_TAG_F2D_BLOCK_Y_1_BITS: natural                                       := 4;
   constant GC_DEBUG_TAG_F2D_BASE_ADDR_BITS: natural                                       := 16;
   constant GC_DEBUG_TAG_F2D_INSTRUCTION_ID_BITS: natural                                       := 16;
   constant GC_DEBUG_TAG_F2D_BLOCKS_COORDS_BITS: natural                                       := 256;
   constant GC_DEBUG_TAG_F2D_GPU_ID_BITS   : natural                                       := 3;
   constant GC_DEBUG_TAG_F2D_BITS          : natural                                       := 440;
   constant GC_DEBUG_TAG_PXL_DM_BITS       : natural                                       := 3;
   constant GC_DEBUG_TAG_PXL_KICK_BITS     : natural                                       := 12;
   constant GC_DEBUG_TAG_PXL_TILE_X_BITS   : natural                                       := 11;
   constant GC_DEBUG_TAG_PXL_TILE_Y_BITS   : natural                                       := 11;
   constant GC_DEBUG_TAG_PXL_GENERATION_BITS: natural                                       := 4;
   constant GC_DEBUG_TAG_PXL_OBJECT_BITS   : natural                                       := 32;
   constant GC_DEBUG_TAG_PXL_SUBOBJECT_BITS: natural                                       := 2;
   constant GC_DEBUG_TAG_PXL_TASK_BITS     : natural                                       := 32;
   constant GC_DEBUG_TAG_PXL_INST_IN_BLOCK_BITS: natural                                       := 2;
   constant GC_DEBUG_TAG_PXL_INST_IN_TASK_BITS: natural                                       := 7;
   constant GC_DEBUG_TAG_PXL_PHASE_BITS    : natural                                       := 1;
   constant GC_DEBUG_TAG_PXL_SAMPLE_BITS   : natural                                       := 4;
   constant GC_DEBUG_TAG_PXL_BLOCK_X_0_BITS: natural                                       := 4;
   constant GC_DEBUG_TAG_PXL_BLOCK_Y_0_BITS: natural                                       := 4;
   constant GC_DEBUG_TAG_PXL_BLOCK_X_1_BITS: natural                                       := 4;
   constant GC_DEBUG_TAG_PXL_BLOCK_Y_1_BITS: natural                                       := 4;
   constant GC_DEBUG_TAG_PXL_PUNCHTHROUGH_BITS: natural                                       := 1;
   constant GC_DEBUG_TAG_PXL_BASE_ADDR_BITS: natural                                       := 16;
   constant GC_DEBUG_TAG_PXL_INSTRUCTION_ID_BITS: natural                                       := 16;
   constant GC_DEBUG_TAG_PXL_BLOCKS_COORDS_BITS: natural                                       := 256;
   constant GC_DEBUG_TAG_PXL_GPU_ID_BITS   : natural                                       := 3;
   constant GC_DEBUG_TAG_PXL_BITS          : natural                                       := 427;
   constant GC_DEBUG_TAG_RAY_DM_BITS       : natural                                       := 3;
   constant GC_DEBUG_TAG_RAY_KICK_BITS     : natural                                       := 12;
   constant GC_DEBUG_TAG_RAY_GPU_ID_BITS   : natural                                       := 3;
   constant GC_DEBUG_TAG_RAY_GENERATION_BITS: natural                                       := 3;
   constant GC_DEBUG_TAG_RAY_TASK_TYPE_BITS: natural                                       := 3;
   constant GC_DEBUG_TAG_RAY_DISPATCH_ID_BITS: natural                                       := 32;
   constant GC_DEBUG_TAG_RAY_BROADCAST_BITS: natural                                       := 1;
   constant GC_DEBUG_TAG_RAY_GROUP_BITS    : natural                                       := 8;
   constant GC_DEBUG_TAG_RAY_SUB_GROUP_BITS: natural                                       := 8;
   constant GC_DEBUG_TAG_RAY_TASK_BITS     : natural                                       := 32;
   constant GC_DEBUG_TAG_RAY_INSTANCE_NUM_BITS: natural                                       := 7;
   constant GC_DEBUG_TAG_RAY_LAUNCH_ID_X_BITS: natural                                       := 16;
   constant GC_DEBUG_TAG_RAY_LAUNCH_ID_Y_BITS: natural                                       := 16;
   constant GC_DEBUG_TAG_RAY_LAUNCH_ID_Z_BITS: natural                                       := 16;
   constant GC_DEBUG_TAG_RAY_NOT_DETERMINISTIC_BITS: natural                                       := 1;
   constant GC_DEBUG_TAG_RAY_BASE_ADDR_BITS: natural                                       := 16;
   constant GC_DEBUG_TAG_RAY_INSTRUCTION_ID_BITS: natural                                       := 16;
   constant GC_DEBUG_TAG_RAY_BITS          : natural                                       := 193;
   constant GC_DEBUG_TAG_STM_DM_BITS       : natural                                       := 3;
   constant GC_DEBUG_TAG_STM_KICK_BITS     : natural                                       := 12;
   constant GC_DEBUG_TAG_STM_GENERATION_BITS: natural                                       := 4;
   constant GC_DEBUG_TAG_STM_SPC_BITS      : natural                                       := 8;
   constant GC_DEBUG_TAG_STM_PIM_BITS      : natural                                       := 32;
   constant GC_DEBUG_TAG_STM_BLOCK_ID_BITS : natural                                       := 32;
   constant GC_DEBUG_TAG_STM_TASK_BITS     : natural                                       := 32;
   constant GC_DEBUG_TAG_STM_BASE_ADDR_BITS: natural                                       := 16;
   constant GC_DEBUG_TAG_STM_INSTRUCTION_ID_BITS: natural                                       := 16;
   constant GC_DEBUG_TAG_STM_GPU_ID_BITS   : natural                                       := 3;
   constant GC_DEBUG_TAG_STM_BITS          : natural                                       := 158;
   constant DBGTAG_WIDTH                    : natural                                       := 440;


end package pkg_gc_debug_tag_const;

package body pkg_gc_debug_tag_const is

end package body pkg_gc_debug_tag_const;