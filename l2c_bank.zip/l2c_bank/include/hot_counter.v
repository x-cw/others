// +FHDR-----------------------------------------------------------------------
// Copyright (c) 2022, Innosilicon, Inc. Confidential Proprietary
// PROJECT NAME  : 
// BLOCK   NAME  : hot_counter
// DEPARTMENT    : Front-End Department
// AUTHOR        : Liushi
// EMAIL         : lius@innosilicon.com.cn
// ----------------------------------------------------------------------------
// Release History
// VERSION  DATE        AUTHOR    DESCRIPTION
// 1.0      20241020    Liushi  First initial
//
// Description   : 
// ----------------------------------------------------------------------------
// Others For More Information:
//
// -FHDR-----------------------------------------------------------------------

module hot_counter #(parameter M)
(
  clk,
  rst_n,
  perf_event,
  hot_cnt_en,
  hot_cnt,
  clear,
  perf_event_o
);

  input clk;
  input rst_n;
  input [M-1:0] perf_event;
  input hot_cnt_en;
  input clear;
  output [32-1:0] hot_cnt;
  output [25:0]  perf_event_o;

  //reg [6+M:0] hot_cnt_r;
  reg [5+M:0] hot_cnt_r;

  //when hot_cnt_en valid,hot_cnt_r increase according to perf_event------

  always @(posedge clk or negedge rst_n)begin
    if(~rst_n)
      hot_cnt_r <= {{6+M}{1'b0}};
    else if(clear)
      hot_cnt_r <= {{6+M}{1'b0}};//perf_event;
    else if(hot_cnt_en)
      hot_cnt_r <= hot_cnt_r + {6'b0,perf_event};
  end

  assign hot_cnt = {{(32-6-M){1'b0}}, hot_cnt_r};
  assign perf_event_o = {{(26-M){1'b0}},perf_event};

endmodule
