//-----------------------------------------------------------------------------------------------------------------
//
//                file : gc_cr_l2g_regbank.sv
//
//           copyright : 2001-2020 by Imagination Technologies Limited. All rights
//                       reserved. No part of this hardware description, either
//                       material or conceptual may be copied or distributed,
//                       transmitted, transcribed, stored in a retrieval system
//                       or translated into any human or computer language in
//                       any form by any means, electronic, mechanical, manual
//                       or otherwise, or disclosed to third parties without
//                       the express written permission of Imagination
//                       Technologies Limited, Home Park Estate, Kings Langley,
//                       Hertfordshire, WD4 8LZ, U.K.
//
//     generated from : (null)
//                 by : regconv.c REL/1@6006852 
//-----------------------------------------------------------------------------------------------------------------

module gc_cr_l2g_regbank_
import gc_cr_global_regpack_::*;
(
     input logic              clk
    ,input logic              resetn
    // external register access (via router) N.B. no flow control

    ,input  logic             regbank_valid
    ,input  logic [ 16 : 0 ]  regbank_addr
    ,input  logic [ 63 : 0 ]  regbank_wdata
    ,input  logic [ 7 : 0 ]   regbank_wmask
    ,input  logic             regbank_rdnwr
    ,output logic [ 63 : 0 ]  regbank_rdata
    ,output logic             regbank_rvalid
    ,input logic [  2 : 0 ]  regbank_instance


    // register gc_cr_l2_cfi_statusii (0xe0a0)
    ,input logic  gc_cr_l2_cfi_statusii_l2b64
    ,input logic  gc_cr_l2_cfi_statusii_l2b65
    ,input logic  gc_cr_l2_cfi_statusii_l2b66
    ,input logic  gc_cr_l2_cfi_statusii_l2b67
    ,input logic  gc_cr_l2_cfi_statusii_l2b68
    ,input logic  gc_cr_l2_cfi_statusii_l2b69
    ,input logic  gc_cr_l2_cfi_statusii_l2b70
    ,input logic  gc_cr_l2_cfi_statusii_l2b71
    ,input logic  gc_cr_l2_cfi_statusii_l2b72
    ,input logic  gc_cr_l2_cfi_statusii_l2b73
    ,input logic  gc_cr_l2_cfi_statusii_l2b74
    ,input logic  gc_cr_l2_cfi_statusii_l2b75
    ,input logic  gc_cr_l2_cfi_statusii_l2b76
    ,input logic  gc_cr_l2_cfi_statusii_l2b77
    ,input logic  gc_cr_l2_cfi_statusii_l2b78
    ,input logic  gc_cr_l2_cfi_statusii_l2b79


    // register gc_cr_clk_ctrl3 (0xa0)
    ,output logic [ 1 : 0 ] gc_cr_clk_ctrl3_l2g0
    ,output logic [ 1 : 0 ] gc_cr_clk_ctrl3_l2g1
    ,output logic [ 1 : 0 ] gc_cr_clk_ctrl3_l2g2
    ,output logic [ 1 : 0 ] gc_cr_clk_ctrl3_l2g3
    ,output logic [ 1 : 0 ] gc_cr_clk_ctrl3_l2g4
    ,output logic [ 1 : 0 ] gc_cr_clk_ctrl3_l2g5
    ,output logic [ 1 : 0 ] gc_cr_clk_ctrl3_l2g6
    ,output logic [ 1 : 0 ] gc_cr_clk_ctrl3_l2g7


    // register gc_cr_clk_status3 (0xa8)
    ,input logic  gc_cr_clk_status3_l2g0
    ,input logic  gc_cr_clk_status3_l2g1
    ,input logic  gc_cr_clk_status3_l2g2
    ,input logic  gc_cr_clk_status3_l2g3
    ,input logic  gc_cr_clk_status3_l2g4
    ,input logic  gc_cr_clk_status3_l2g5
    ,input logic  gc_cr_clk_status3_l2g6
    ,input logic  gc_cr_clk_status3_l2g7


    // register gc_cr_cu_lms_fp32_denormal_en (0x4468)
    ,output logic  gc_cr_cu_lms_fp32_denormal_en


    // register gc_cr_perf_mon1 (0x4708)
    ,output logic  gc_cr_perf_mon1_enable
    ,output logic  gc_cr_perf_mon1_time_stamp_enable
    ,output logic [ 15 : 0 ] gc_cr_perf_mon1_time_slot
    ,output logic [ 5 : 0 ] gc_cr_perf_mon1_fence_interval


    // register gc_cr_perf_mon4 (0x4720)
    ,output logic [ 4 : 0 ] gc_cr_perf_mon4_cu_group_id
    ,output logic [ 4 : 0 ] gc_cr_perf_mon4_spc_group_id
    ,output logic [ 4 : 0 ] gc_cr_perf_mon4_gpc_group_id
    ,output logic [ 4 : 0 ] gc_cr_perf_mon4_l2g_group_id
    ,output logic [ 4 : 0 ] gc_cr_perf_mon4_cp_group_id
    ,output logic [ 4 : 0 ] gc_cr_perf_mon4_ce_group_id


    // register gc_cr_l2_cfi_operation (0xe000)
    ,output logic [ 1 : 0 ] gc_cr_l2_cfi_operation


    // register gc_cr_l2_cfi_statusi (0xe008)
    ,input logic  gc_cr_l2_cfi_statusi_l2b0
    ,input logic  gc_cr_l2_cfi_statusi_l2b1
    ,input logic  gc_cr_l2_cfi_statusi_l2b2
    ,input logic  gc_cr_l2_cfi_statusi_l2b3
    ,input logic  gc_cr_l2_cfi_statusi_l2b4
    ,input logic  gc_cr_l2_cfi_statusi_l2b5
    ,input logic  gc_cr_l2_cfi_statusi_l2b6
    ,input logic  gc_cr_l2_cfi_statusi_l2b7
    ,input logic  gc_cr_l2_cfi_statusi_l2b8
    ,input logic  gc_cr_l2_cfi_statusi_l2b9
    ,input logic  gc_cr_l2_cfi_statusi_l2b10
    ,input logic  gc_cr_l2_cfi_statusi_l2b11
    ,input logic  gc_cr_l2_cfi_statusi_l2b12
    ,input logic  gc_cr_l2_cfi_statusi_l2b13
    ,input logic  gc_cr_l2_cfi_statusi_l2b14
    ,input logic  gc_cr_l2_cfi_statusi_l2b15
    ,input logic  gc_cr_l2_cfi_statusi_l2b16
    ,input logic  gc_cr_l2_cfi_statusi_l2b17
    ,input logic  gc_cr_l2_cfi_statusi_l2b18
    ,input logic  gc_cr_l2_cfi_statusi_l2b19
    ,input logic  gc_cr_l2_cfi_statusi_l2b20
    ,input logic  gc_cr_l2_cfi_statusi_l2b21
    ,input logic  gc_cr_l2_cfi_statusi_l2b22
    ,input logic  gc_cr_l2_cfi_statusi_l2b23
    ,input logic  gc_cr_l2_cfi_statusi_l2b24
    ,input logic  gc_cr_l2_cfi_statusi_l2b25
    ,input logic  gc_cr_l2_cfi_statusi_l2b26
    ,input logic  gc_cr_l2_cfi_statusi_l2b27
    ,input logic  gc_cr_l2_cfi_statusi_l2b28
    ,input logic  gc_cr_l2_cfi_statusi_l2b29
    ,input logic  gc_cr_l2_cfi_statusi_l2b30
    ,input logic  gc_cr_l2_cfi_statusi_l2b31
    ,input logic  gc_cr_l2_cfi_statusi_l2b32
    ,input logic  gc_cr_l2_cfi_statusi_l2b33
    ,input logic  gc_cr_l2_cfi_statusi_l2b34
    ,input logic  gc_cr_l2_cfi_statusi_l2b35
    ,input logic  gc_cr_l2_cfi_statusi_l2b36
    ,input logic  gc_cr_l2_cfi_statusi_l2b37
    ,input logic  gc_cr_l2_cfi_statusi_l2b38
    ,input logic  gc_cr_l2_cfi_statusi_l2b39
    ,input logic  gc_cr_l2_cfi_statusi_l2b40
    ,input logic  gc_cr_l2_cfi_statusi_l2b41
    ,input logic  gc_cr_l2_cfi_statusi_l2b42
    ,input logic  gc_cr_l2_cfi_statusi_l2b43
    ,input logic  gc_cr_l2_cfi_statusi_l2b44
    ,input logic  gc_cr_l2_cfi_statusi_l2b45
    ,input logic  gc_cr_l2_cfi_statusi_l2b46
    ,input logic  gc_cr_l2_cfi_statusi_l2b47
    ,input logic  gc_cr_l2_cfi_statusi_l2b48
    ,input logic  gc_cr_l2_cfi_statusi_l2b49
    ,input logic  gc_cr_l2_cfi_statusi_l2b50
    ,input logic  gc_cr_l2_cfi_statusi_l2b51
    ,input logic  gc_cr_l2_cfi_statusi_l2b52
    ,input logic  gc_cr_l2_cfi_statusi_l2b53
    ,input logic  gc_cr_l2_cfi_statusi_l2b54
    ,input logic  gc_cr_l2_cfi_statusi_l2b55
    ,input logic  gc_cr_l2_cfi_statusi_l2b56
    ,input logic  gc_cr_l2_cfi_statusi_l2b57
    ,input logic  gc_cr_l2_cfi_statusi_l2b58
    ,input logic  gc_cr_l2_cfi_statusi_l2b59
    ,input logic  gc_cr_l2_cfi_statusi_l2b60
    ,input logic  gc_cr_l2_cfi_statusi_l2b61
    ,input logic  gc_cr_l2_cfi_statusi_l2b62
    ,input logic  gc_cr_l2_cfi_statusi_l2b63


    // register gc_cr_l2_buffer_mode (0xe018)
    ,output logic [ 1 : 0 ] gc_cr_l2_buffer_mode_buffer_mode_percentage


    // register gc_cr_l2_persistence_reduce (0xe020)
    ,output logic  gc_cr_l2_persistence_reduce_persistence_reduce_enable
    ,output logic [ 20 : 0 ] gc_cr_l2_persistence_reduce_persistence_reduce_threshold


    // register gc_cr_l2_cmd (0xe028)
    ,output logic  gc_cr_l2_cmd_persistence_rst_all
    ,output logic  gc_cr_l2_cmd_cfi_clr


    // register gc_cr_l2g_idle (0xe030)
    ,input logic  gc_cr_l2g_idle_l2b0
    ,input logic  gc_cr_l2g_idle_l2b1
    ,input logic  gc_cr_l2g_idle_l2b2
    ,input logic  gc_cr_l2g_idle_l2b3
    ,input logic  gc_cr_l2g_idle_l2b4
    ,input logic  gc_cr_l2g_idle_l2b5
    ,input logic  gc_cr_l2g_idle_l2b6
    ,input logic  gc_cr_l2g_idle_l2b7
    ,input logic  gc_cr_l2g_idle_l2b8
    ,input logic  gc_cr_l2g_idle_l2b9
    ,input logic  gc_cr_l2g_idle_l2b10
    ,input logic  gc_cr_l2g_idle_l2b11
    ,input logic  gc_cr_l2g_idle_l2b12
    ,input logic  gc_cr_l2g_idle_l2b13
    ,input logic  gc_cr_l2g_idle_l2b14
    ,input logic  gc_cr_l2g_idle_l2b15
    ,input logic  gc_cr_l2g_idle_l2b16
    ,input logic  gc_cr_l2g_idle_l2b17
    ,input logic  gc_cr_l2g_idle_l2b18
    ,input logic  gc_cr_l2g_idle_l2b19
    ,input logic  gc_cr_l2g_idle_l2b20
    ,input logic  gc_cr_l2g_idle_l2b21
    ,input logic  gc_cr_l2g_idle_l2b22
    ,input logic  gc_cr_l2g_idle_l2b23
    ,input logic  gc_cr_l2g_idle_l2b24
    ,input logic  gc_cr_l2g_idle_l2b25
    ,input logic  gc_cr_l2g_idle_l2b26
    ,input logic  gc_cr_l2g_idle_l2b27
    ,input logic  gc_cr_l2g_idle_l2b28
    ,input logic  gc_cr_l2g_idle_l2b29
    ,input logic  gc_cr_l2g_idle_l2b30
    ,input logic  gc_cr_l2g_idle_l2b31
    ,input logic  gc_cr_l2g_idle_l2b32
    ,input logic  gc_cr_l2g_idle_l2b33
    ,input logic  gc_cr_l2g_idle_l2b34
    ,input logic  gc_cr_l2g_idle_l2b35
    ,input logic  gc_cr_l2g_idle_l2b36
    ,input logic  gc_cr_l2g_idle_l2b37
    ,input logic  gc_cr_l2g_idle_l2b38
    ,input logic  gc_cr_l2g_idle_l2b39
    ,input logic  gc_cr_l2g_idle_l2b40
    ,input logic  gc_cr_l2g_idle_l2b41
    ,input logic  gc_cr_l2g_idle_l2b42
    ,input logic  gc_cr_l2g_idle_l2b43
    ,input logic  gc_cr_l2g_idle_l2b44
    ,input logic  gc_cr_l2g_idle_l2b45
    ,input logic  gc_cr_l2g_idle_l2b46
    ,input logic  gc_cr_l2g_idle_l2b47
    ,input logic  gc_cr_l2g_idle_l2b48
    ,input logic  gc_cr_l2g_idle_l2b49
    ,input logic  gc_cr_l2g_idle_l2b50
    ,input logic  gc_cr_l2g_idle_l2b51
    ,input logic  gc_cr_l2g_idle_l2b52
    ,input logic  gc_cr_l2g_idle_l2b53
    ,input logic  gc_cr_l2g_idle_l2b54
    ,input logic  gc_cr_l2g_idle_l2b55
    ,input logic  gc_cr_l2g_idle_l2b56
    ,input logic  gc_cr_l2g_idle_l2b57
    ,input logic  gc_cr_l2g_idle_l2b58
    ,input logic  gc_cr_l2g_idle_l2b59
    ,input logic  gc_cr_l2g_idle_l2b60
    ,input logic  gc_cr_l2g_idle_l2b61
    ,input logic  gc_cr_l2g_idle_l2b62
    ,input logic  gc_cr_l2g_idle_l2b63


    // register gc_cr_l2g_error0 (0xe038)
    ,input logic [ 2 : 0 ] gc_cr_l2g_error0_l2b0
    ,input logic [ 2 : 0 ] gc_cr_l2g_error0_l2b1
    ,input logic [ 2 : 0 ] gc_cr_l2g_error0_l2b2
    ,input logic [ 2 : 0 ] gc_cr_l2g_error0_l2b3
    ,input logic [ 2 : 0 ] gc_cr_l2g_error0_l2b4
    ,input logic [ 2 : 0 ] gc_cr_l2g_error0_l2b5
    ,input logic [ 2 : 0 ] gc_cr_l2g_error0_l2b6
    ,input logic [ 2 : 0 ] gc_cr_l2g_error0_l2b7
    ,input logic [ 2 : 0 ] gc_cr_l2g_error0_l2b8
    ,input logic [ 2 : 0 ] gc_cr_l2g_error0_l2b9
    ,input logic [ 2 : 0 ] gc_cr_l2g_error0_l2b10
    ,input logic [ 2 : 0 ] gc_cr_l2g_error0_l2b11
    ,input logic [ 2 : 0 ] gc_cr_l2g_error0_l2b12
    ,input logic [ 2 : 0 ] gc_cr_l2g_error0_l2b13
    ,input logic [ 2 : 0 ] gc_cr_l2g_error0_l2b14
    ,input logic [ 2 : 0 ] gc_cr_l2g_error0_l2b15
    ,input logic [ 2 : 0 ] gc_cr_l2g_error0_l2b16
    ,input logic [ 2 : 0 ] gc_cr_l2g_error0_l2b17
    ,input logic [ 2 : 0 ] gc_cr_l2g_error0_l2b18
    ,input logic [ 2 : 0 ] gc_cr_l2g_error0_l2b19
    ,input logic [ 2 : 0 ] gc_cr_l2g_error0_l2b20


    // register gc_cr_l2g_error1 (0xe040)
    ,input logic [ 2 : 0 ] gc_cr_l2g_error1_l2b21
    ,input logic [ 2 : 0 ] gc_cr_l2g_error1_l2b22
    ,input logic [ 2 : 0 ] gc_cr_l2g_error1_l2b23
    ,input logic [ 2 : 0 ] gc_cr_l2g_error1_l2b24
    ,input logic [ 2 : 0 ] gc_cr_l2g_error1_l2b25
    ,input logic [ 2 : 0 ] gc_cr_l2g_error1_l2b26
    ,input logic [ 2 : 0 ] gc_cr_l2g_error1_l2b27
    ,input logic [ 2 : 0 ] gc_cr_l2g_error1_l2b28
    ,input logic [ 2 : 0 ] gc_cr_l2g_error1_l2b29
    ,input logic [ 2 : 0 ] gc_cr_l2g_error1_l2b30
    ,input logic [ 2 : 0 ] gc_cr_l2g_error1_l2b31
    ,input logic [ 2 : 0 ] gc_cr_l2g_error1_l2b32
    ,input logic [ 2 : 0 ] gc_cr_l2g_error1_l2b33
    ,input logic [ 2 : 0 ] gc_cr_l2g_error1_l2b34
    ,input logic [ 2 : 0 ] gc_cr_l2g_error1_l2b35
    ,input logic [ 2 : 0 ] gc_cr_l2g_error1_l2b36
    ,input logic [ 2 : 0 ] gc_cr_l2g_error1_l2b37
    ,input logic [ 2 : 0 ] gc_cr_l2g_error1_l2b38
    ,input logic [ 2 : 0 ] gc_cr_l2g_error1_l2b39
    ,input logic [ 2 : 0 ] gc_cr_l2g_error1_l2b40
    ,input logic [ 2 : 0 ] gc_cr_l2g_error1_l2b41


    // register gc_cr_l2g_error2 (0xe048)
    ,input logic [ 2 : 0 ] gc_cr_l2g_error2_l2b42
    ,input logic [ 2 : 0 ] gc_cr_l2g_error2_l2b43
    ,input logic [ 2 : 0 ] gc_cr_l2g_error2_l2b44
    ,input logic [ 2 : 0 ] gc_cr_l2g_error2_l2b45
    ,input logic [ 2 : 0 ] gc_cr_l2g_error2_l2b46
    ,input logic [ 2 : 0 ] gc_cr_l2g_error2_l2b47
    ,input logic [ 2 : 0 ] gc_cr_l2g_error2_l2b48
    ,input logic [ 2 : 0 ] gc_cr_l2g_error2_l2b49
    ,input logic [ 2 : 0 ] gc_cr_l2g_error2_l2b50
    ,input logic [ 2 : 0 ] gc_cr_l2g_error2_l2b51
    ,input logic [ 2 : 0 ] gc_cr_l2g_error2_l2b52
    ,input logic [ 2 : 0 ] gc_cr_l2g_error2_l2b53
    ,input logic [ 2 : 0 ] gc_cr_l2g_error2_l2b54
    ,input logic [ 2 : 0 ] gc_cr_l2g_error2_l2b55
    ,input logic [ 2 : 0 ] gc_cr_l2g_error2_l2b56
    ,input logic [ 2 : 0 ] gc_cr_l2g_error2_l2b57
    ,input logic [ 2 : 0 ] gc_cr_l2g_error2_l2b58
    ,input logic [ 2 : 0 ] gc_cr_l2g_error2_l2b59
    ,input logic [ 2 : 0 ] gc_cr_l2g_error2_l2b60
    ,input logic [ 2 : 0 ] gc_cr_l2g_error2_l2b61
    ,input logic [ 2 : 0 ] gc_cr_l2g_error2_l2b62


    // register gc_cr_l2g_error3 (0xe050)
    ,input logic [ 2 : 0 ] gc_cr_l2g_error3_l2b63


    // register gc_cr_l2_function_enable (0xe058)
    ,output logic  gc_cr_l2_function_enable_mem_scheduler
    ,output logic  gc_cr_l2_function_enable_bypass_mode
    ,output logic [ 1 : 0 ] gc_cr_l2_function_enable_hash_mode
    ,output logic [ 3 : 0 ] gc_cr_l2_function_enable_ddr_capacity


    // register gc_cr_l2_mem_sched_col_offset (0xe060)
    ,output logic [ 4 : 0 ] gc_cr_l2_mem_sched_col_offset_column_id_bit0
    ,output logic [ 4 : 0 ] gc_cr_l2_mem_sched_col_offset_column_id_bit1
    ,output logic [ 4 : 0 ] gc_cr_l2_mem_sched_col_offset_column_id_bit2
    ,output logic [ 4 : 0 ] gc_cr_l2_mem_sched_col_offset_column_id_bit3
    ,output logic [ 4 : 0 ] gc_cr_l2_mem_sched_col_offset_column_id_bit4
    ,output logic [ 4 : 0 ] gc_cr_l2_mem_sched_col_offset_column_id_bit5
    ,output logic [ 4 : 0 ] gc_cr_l2_mem_sched_col_offset_column_id_bit6
    ,output logic [ 4 : 0 ] gc_cr_l2_mem_sched_col_offset_column_id_bit7


    // register gc_cr_l2_mem_sched_bank_offset (0xe068)
    ,output logic [ 4 : 0 ] gc_cr_l2_mem_sched_bank_offset_bank_id_bit0
    ,output logic [ 4 : 0 ] gc_cr_l2_mem_sched_bank_offset_bank_id_bit1
    ,output logic [ 4 : 0 ] gc_cr_l2_mem_sched_bank_offset_bank_id_bit2
    ,output logic [ 4 : 0 ] gc_cr_l2_mem_sched_bank_offset_bank_id_bit3
    ,output logic [ 4 : 0 ] gc_cr_l2_mem_sched_bank_offset_bank_id_bit4


    // register gc_cr_l2_mem_sched_row_parti (0xe070)
    ,output logic [ 4 : 0 ] gc_cr_l2_mem_sched_row_parti_row_id_bit0
    ,output logic [ 4 : 0 ] gc_cr_l2_mem_sched_row_parti_row_id_bit1
    ,output logic [ 4 : 0 ] gc_cr_l2_mem_sched_row_parti_row_id_bit2
    ,output logic [ 4 : 0 ] gc_cr_l2_mem_sched_row_parti_row_id_bit3
    ,output logic [ 4 : 0 ] gc_cr_l2_mem_sched_row_parti_row_id_bit4
    ,output logic [ 4 : 0 ] gc_cr_l2_mem_sched_row_parti_row_id_bit5
    ,output logic [ 4 : 0 ] gc_cr_l2_mem_sched_row_parti_row_id_bit6
    ,output logic [ 4 : 0 ] gc_cr_l2_mem_sched_row_parti_row_id_bit7


    // register gc_cr_l2_mem_sched_row_partii (0xe078)
    ,output logic [ 4 : 0 ] gc_cr_l2_mem_sched_row_partii_row_id_bit8
    ,output logic [ 4 : 0 ] gc_cr_l2_mem_sched_row_partii_row_id_bit9
    ,output logic [ 4 : 0 ] gc_cr_l2_mem_sched_row_partii_row_id_bit10
    ,output logic [ 4 : 0 ] gc_cr_l2_mem_sched_row_partii_row_id_bit11
    ,output logic [ 4 : 0 ] gc_cr_l2_mem_sched_row_partii_row_id_bit12
    ,output logic [ 4 : 0 ] gc_cr_l2_mem_sched_row_partii_row_id_bit13
    ,output logic [ 4 : 0 ] gc_cr_l2_mem_sched_row_partii_row_id_bit14
    ,output logic [ 4 : 0 ] gc_cr_l2_mem_sched_row_partii_row_id_bit15


    // register gc_cr_l2_mem_sched_row_partiii (0xe080)
    ,output logic [ 4 : 0 ] gc_cr_l2_mem_sched_row_partiii_row_id_bit16
    ,output logic [ 4 : 0 ] gc_cr_l2_mem_sched_row_partiii_row_id_bit17


    // register gc_cr_ddr_hash_config_reg0 (0xe088)
    ,output logic [ 3 : 0 ] gc_cr_ddr_hash_config_reg0_row_id_bit0
    ,output logic [ 3 : 0 ] gc_cr_ddr_hash_config_reg0_row_id_bit1
    ,output logic [ 3 : 0 ] gc_cr_ddr_hash_config_reg0_row_id_bit2
    ,output logic [ 3 : 0 ] gc_cr_ddr_hash_config_reg0_row_id_bit3
    ,output logic [ 3 : 0 ] gc_cr_ddr_hash_config_reg0_row_id_bit4
    ,output logic [ 3 : 0 ] gc_cr_ddr_hash_config_reg0_row_id_bit5
    ,output logic [ 3 : 0 ] gc_cr_ddr_hash_config_reg0_row_id_bit6
    ,output logic [ 3 : 0 ] gc_cr_ddr_hash_config_reg0_row_id_bit7
    ,output logic [ 3 : 0 ] gc_cr_ddr_hash_config_reg0_row_id_bit8
    ,output logic [ 3 : 0 ] gc_cr_ddr_hash_config_reg0_row_id_bit9
    ,output logic [ 3 : 0 ] gc_cr_ddr_hash_config_reg0_row_id_bit10
    ,output logic [ 3 : 0 ] gc_cr_ddr_hash_config_reg0_row_id_bit11


    // register gc_cr_ddr_hash_config_reg1 (0xe090)
    ,output logic [ 3 : 0 ] gc_cr_ddr_hash_config_reg1_row_id_bit12
    ,output logic [ 3 : 0 ] gc_cr_ddr_hash_config_reg1_row_id_bit13
    ,output logic [ 3 : 0 ] gc_cr_ddr_hash_config_reg1_row_id_bit14
    ,output logic [ 3 : 0 ] gc_cr_ddr_hash_config_reg1_row_id_bit15
    ,output logic [ 3 : 0 ] gc_cr_ddr_hash_config_reg1_row_id_bit16
    ,output logic [ 3 : 0 ] gc_cr_ddr_hash_config_reg1_row_id_bit17
    ,output logic [ 3 : 0 ] gc_cr_ddr_hash_config_reg1_row_id_bit18
    ,output logic [ 3 : 0 ] gc_cr_ddr_hash_config_reg1_row_id_bit19
    ,output logic [ 3 : 0 ] gc_cr_ddr_hash_config_reg1_row_id_bit20
    ,output logic [ 3 : 0 ] gc_cr_ddr_hash_config_reg1_row_id_bit21
    ,output logic [ 3 : 0 ] gc_cr_ddr_hash_config_reg1_row_id_bit22
    ,output logic [ 3 : 0 ] gc_cr_ddr_hash_config_reg1_row_id_bit23


    // register gc_cr_l2g_idleii (0xe098)
    ,input logic  gc_cr_l2g_idleii_l2b64
    ,input logic  gc_cr_l2g_idleii_l2b65
    ,input logic  gc_cr_l2g_idleii_l2b66
    ,input logic  gc_cr_l2g_idleii_l2b67
    ,input logic  gc_cr_l2g_idleii_l2b68
    ,input logic  gc_cr_l2g_idleii_l2b69
    ,input logic  gc_cr_l2g_idleii_l2b70
    ,input logic  gc_cr_l2g_idleii_l2b71
    ,input logic  gc_cr_l2g_idleii_l2b72
    ,input logic  gc_cr_l2g_idleii_l2b73
    ,input logic  gc_cr_l2g_idleii_l2b74
    ,input logic  gc_cr_l2g_idleii_l2b75
    ,input logic  gc_cr_l2g_idleii_l2b76
    ,input logic  gc_cr_l2g_idleii_l2b77
    ,input logic  gc_cr_l2g_idleii_l2b78
    ,input logic  gc_cr_l2g_idleii_l2b79


    // register gc_cr_pwr_man_hysteresis (0xf138)
    ,output logic [ 4 : 0 ] gc_cr_pwr_man_hysteresis_value


    // register gc_cr_crm_reset_clk (0xf278)
    ,output logic [ 1 : 0 ] gc_cr_crm_reset_clk_ctrl


    // Notify 
    ,output logic                       gc_cr_l2_cfi_operation_notify
    ,output logic                       gc_cr_l2_cfi_operation_rdnotify
    ,output logic                       gc_cr_l2_cmd_notify
    ,output logic                       gc_cr_l2_cmd_rdnotify
);
gc_cr_l2g_regbank i_gc_cr_l2g_regbank
(.*);
endmodule
