/*

 * #==========================================================================#
 * |                                                                          |
 * |  Copyright (c) 2022, Fantasy Technologies Limited and/or its         |
 * |  affiliated group companies ("Fantasy"). All rights reserved.        |
 * |  No part of this content, either material or conceptual may be copied    |
 * |  or distributed, transmitted, transcribed, stored in a retrieval system  |
 * |  or translated into any human or computer language in any form by any    |
 * |  means, electronic, mechanical manual, or otherwise, or disclosed to     |
 * |  third parties without the express written permission of Fantasy.    |
 * |                                                                          |
 * #==========================================================================#

 */


package pkg_bif_;

   ///////
   localparam int                 OO_BIF_CMD_SEQ_NUM_WIDTH                               =10;
   localparam int                 OO_BIF_CMD_TAG_SB_WIDTH                                =7;
   localparam int                 OO_BIF_CMD_L1_POLICY_WIDTH                             =2;
   localparam int                 OO_BIF_CMD_BURST_LENGTH_WIDTH                          =2;
   localparam int                 OO_BIF_CMD_VADDRESS_HIGH                               =47;
   localparam int                 OO_BIF_CMD_VADDRESS_LOW                                =6;
   localparam int                 OO_BIF_CMD_CTXT_PASID_WIDTH                            =6;
   localparam int                 OO_BIF_CMD_PERSISTENCE_WIDTH                           =2;
   localparam int                 OO_BIF_CMD_OPERATION_WIDTH                             =4;
   

  



   localparam int                 BIF_CVT_CMD_VADDRESS_LOW                                   =6;
   localparam int                 BIF_CVT_CMD_VADDRESS_HIGH                                  =47;
   localparam int                 BIF_CVT_CMD_CONTEXT_ID_WIDTH                               =6;
   localparam int                 BIF_CVT_CMD_PERSISTENCE_WIDTH                              =2;
   



   ///////

   localparam int                 BIF_BURST_LENGTH_WIDTH                             = 2;
   localparam int                 BIF_TAG_SB_WIDTH                                   = 7;
   localparam int                 EXT_REORDERED_SO_TAG_SB_WIDTH                      = 7;
   localparam int                 CP_RTN_MEM_DEPTH                                = 512; // ori 256
   localparam int                 CP_RTN_MEM_DEPTH_LOG2                           = 9;   // ori 8
   localparam int                 CP_RTN_MEM_DATA_WIDTH                           = 257;
   localparam int                 CP_SEQ_FIFO_DATA_WIDTH                          = 19;  // ori 18
   localparam int                 TEXAS0_RTN_MEM_DEPTH                               = 384;//ori 256 ,modify by wbz for assertion issue fix
   localparam int                 TEXAS0_RTN_MEM_DEPTH_LOG2                          = 9;//ori 8 ,modify by wbz for assertion issue fix
   localparam int                 TEXAS0_RTN_MEM_DATA_WIDTH                          = 257;
   localparam int                 TEXAS0_SEQ_FIFO_DATA_WIDTH                         = 19;//ori 18, add 1 for modify by wbz for assertion issue fix
   localparam int                 TEXAS1_RTN_MEM_DEPTH                               = 256;
   localparam int                 TEXAS1_RTN_MEM_DEPTH_LOG2                          = 8;
   localparam int                 TEXAS1_RTN_MEM_DATA_WIDTH                          = 257;
   localparam int                 TEXAS1_SEQ_FIFO_DATA_WIDTH                         = 18;
   localparam int                 CP_IPP_CREDIT_WIDTH                             = 1;
   localparam int                 CP_DCE_CREDIT_WIDTH                             = 14;
   localparam int                 CP_PM_CREDIT_WIDTH                              = 1;
   localparam int                 CP_FWP_CREDIT_WIDTH                            = 1;
   localparam int                 CP_FWP_DMA_CREDIT_WIDTH                        = 1;
   localparam int                 CP_CPC_CREDIT_WIDTH                             = 2;
   localparam int                 CP_RCE_CREDIT_WIDTH                             = 2;
   localparam int                 CP_IPP_NUM_CREDIT                               = 2;
   localparam int                 CP_DCE_NUM_CREDIT                               = 8;  //ori: 2
   localparam int                 CP_PM_NUM_CREDIT                                = 2;
   localparam int                 CP_FWP_NUM_CREDIT                              = 2;
   localparam int                 CP_FWP_DMA_NUM_CREDIT                          = 5;
   localparam int                 CP_CPC_NUM_CREDIT                               = 2;
   localparam int                 CP_RCE_NUM_CREDIT                               = 2;
   localparam int                 TEXAS_ISP_CREDIT_WIDTH                             = 1;
   localparam int                 TEXAS_ISP_NUM_CREDIT                               = 8;
   localparam int                 TEXAS_MCU_CREDIT_WIDTH                             = 1;
   localparam int                 TEXAS_MCU_NUM_CREDIT                               = 2;
   localparam int                 TEXAS0_IPF_CREDIT_WIDTH                            = 24; //ori: 16
   localparam int                 TEXAS0_IPF_CPF_CREDIT_WIDTH                        = 1;
   localparam int                 TEXAS0_CPC_CREDIT_WIDTH                            = 2;
   localparam int                 TEXAS0_IPF_NUM_CREDIT                              = 4;
   localparam int                 TEXAS0_IPF_CPF_NUM_CREDIT                          = 4;
   localparam int                 TEXAS0_CPC_NUM_CREDIT                              = 2;
   localparam int                 TEXAS1_TPF_CPF_CREDIT_WIDTH                        = 1;
   localparam int                 TEXAS1_CU_L2_CREDIT_WIDTH                         = 1;
   localparam int                 TEXAS1_IPP_CREDIT_WIDTH                            = 1;
   localparam int                 TEXAS1_DCE_CREDIT_WIDTH                            = 14;
   localparam int                 TEXAS1_TPF_CPF_NUM_CREDIT                          = 4;
   localparam int                 TEXAS1_CU_L2_NUM_CREDIT                           = 2;
   localparam int                 TEXAS1_IPP_NUM_CREDIT                              = 2;
   localparam int                 TEXAS1_DCE_NUM_CREDIT                              = 2;
   localparam int                 TEXAS_BSC_CREDIT_WIDTH                             = 1;
   localparam int                 TEXAS_BSC_NUM_CREDIT                               = 4;
   localparam int                 CP_REQUESTOR_NUM                                = 9;
   localparam int                 CP_RTN_MEM_TAG_NUM                              = 24;
   localparam int                 CP_RTN_MEM_REQUESTOR_NUM                        = 9;
   localparam int                 TEXAS0_REQUESTOR_NUM                               = 10; //ori: 9
   localparam int                 TEXAS0_RTN_MEM_TAG_NUM                             = 28; // 28 = 24+4 ; ori = 19 = 16+3
   localparam int                 TEXAS0_RTN_MEM_REQUESTOR_NUM                       = 5; // ori: 4
   localparam int                 TEXAS1_REQUESTOR_NUM                               = 13; //cxt:12; bxt 10 -> 11
   localparam int                 TEXAS1_RTN_MEM_TAG_NUM                             = 9; // bxt 7 -> 8
   localparam int                 TEXAS1_RTN_MEM_REQUESTOR_NUM                       = 9; // bxt 7 -> 8
   localparam int                 BIF_SEQ_NUM_FIFO_GRANULARITY                       = 4;
   localparam int                 CP_SEQ_NUM_FIFO_DEPTH                           = 324;
   localparam int                 TEXAS0_SEQ_NUM_FIFO_DEPTH                          = 309;
   localparam int                 TEXAS1_SEQ_NUM_FIFO_DEPTH                          = 276;
   localparam int                 CP_SEQ_NUM_FIFO_DEPTH_RND                       = 324;
   localparam int                 TEXAS0_SEQ_NUM_FIFO_DEPTH_RND                      = 312;
   localparam int                 TEXAS1_SEQ_NUM_FIFO_DEPTH_RND                      = 276;
   localparam int                 CP_SEQ_NUM_FIFO_DEPTH_RND_LOG2                  = 9;
   localparam int                 TEXAS0_SEQ_NUM_FIFO_DEPTH_RND_LOG2                 = 9;
   localparam int                 TEXAS1_SEQ_NUM_FIFO_DEPTH_RND_LOG2                 = 9;
   localparam int                 TEXAS0_PBE0_REQ0_ID                                = 7;
   localparam int                 TEXAS0_PBE0_REQ1_ID                                = 8;
   localparam int                 TEXAS0_ISP0_REQ0_ID                                = 34;
   localparam int                 TEXAS0_ISP0_REQ1_ID                                = 35;
   localparam int                 TEXAS0_ISP2_REQ0_ID                                = 36;
   localparam int                 TEXAS0_ISP2_REQ1_ID                                = 37;
   localparam int                 TEXAS1_PBE1_REQ0_ID                                = 15;
   localparam int                 TEXAS1_PBE1_REQ1_ID                                = 16;
   localparam int                 TEXAS1_ISP1_REQ0_ID                                = 19;
   localparam int                 TEXAS1_ISP1_REQ1_ID                                = 20;

// add 
   localparam int      		  L1_POLICY_WIDTH     					= 2;
   localparam int                 SPC_BIF_REQUESTOR_NUM                              = 3; 
   localparam int                 SPC_BIF_EXT_REORDERED_MCUL1_ID                     = 0;  
   localparam int                 SPC_BIF_EXT_REORDERED_BSC_ID                       = 1;  
   localparam int                 SPC_BIF_EXT_REORDERED_L2_ICACHE_ID                 = 2;  

   // per bif 
   localparam int                 CP_BIF_REQUESTOR_NUM                                = 8; 
   localparam int                 CP_BIF_RTN_MEM_DEPTH                                = 14; 
   localparam int                 CP_BIF_RTN_MEM_DEPTH_LOG2                           = 4; 
   localparam int                 CP_BIF_RTN_MEM_DATA_WIDTH                           = 513; 
   localparam int                 CP_BIF_SEQ_FIFO_DATA_WIDTH                          = 13; // 18 -1 burst_len=2
   localparam int                 CP_BIF_RTN_MEM_TAG_NUM                              = 9; // 2*4 + 1
   localparam int                 CP_BIF_RTN_MEM_REQUESTOR_NUM                        = 5; 
   localparam int                 CP_BIF_SEQ_NUM_FIFO_DEPTH                           = 35;
   localparam int                 CP_BIF_SEQ_NUM_FIFO_DEPTH_RND                       = 36; 
   localparam int                 CP_BIF_SEQ_NUM_FIFO_DEPTH_RND_LOG2                  = 6; 
 
   // per requestor 
   localparam int                 CP_BIF_CPC0_CREDIT_WIDTH                             = 2; 
   localparam int                 CP_BIF_CPC0_NUM_CREDIT                               = 2; 
   localparam int                 CP_BIF_CPC1_CREDIT_WIDTH                             = 2; 
   localparam int                 CP_BIF_CPC1_NUM_CREDIT                               = 2; 
   localparam int                 CP_BIF_CPC2_CREDIT_WIDTH                             = 2; 
   localparam int                 CP_BIF_CPC2_NUM_CREDIT                               = 2; 
   localparam int                 CP_BIF_CPC3_CREDIT_WIDTH                             = 2; 
   localparam int                 CP_BIF_CPC3_NUM_CREDIT                               = 2; 
   localparam int                 CP_BIF_FWP_CREDIT_WIDTH                             = 1; 
   localparam int                 CP_BIF_FWP_NUM_CREDIT                               = 2; 
   localparam int                 CP_BIF_FWP_DMA_NUM_CREDIT                               = 5; 
 
 
   // pkg_mh_ PARAMETERS  
   localparam int                 CP_BIF_EXT_REORDERED_PU_ID                        = 3;  
   localparam int                 CP_BIF_EXT_REORDERED_PERFMON_ID                   = 2;  
   localparam int                 CP_BIF_EXT_REORDERED_CE_PERFMON_ID                = 1;  
endpackage
