/*

 * #==========================================================================#
 * |                                                                          |
 * |  Copyright (c) 2022, Fantasy Technologies Limited and/or its         |
 * |  affiliated group companies ("Fantasy"). All rights reserved.        |
 * |  No part of this content, either material or conceptual may be copied    |
 * |  or distributed, transmitted, transcribed, stored in a retrieval system  |
 * |  or translated into any human or computer language in any form by any    |
 * |  means, electronic, mechanical manual, or otherwise, or disclosed to     |
 * |  third parties without the express written permission of Fantasy.    |
 * |                                                                          |
 * #==========================================================================#

 */

// ////////////////////////////////////////////////////////////////////////////-
// entity:  gpc_gfx_spstore_gen_bist_r
//
// purpose: Single port synchronous RAM with configurable write word partitions
//          and back end read register to help achieve timing closure. The
//          register does not have a specific external clock enable
//
// +////////////////////////-+////-+////-+////////+////////////////+
// | gpc_gfx_spstore_        | RAM | Reg | Bypass | Design         |
// |             w,p,d,log2d | O/P | O/P | Input  | Suitability    |
// +////////////////////////-+////-+////-+////////+////////////////+
// | _.vhd & _novital.vhd    | Yes |     |        | Fundamental    |
// | bist.vhdm               | Yes |     |        | Low level only |
// | gen_bist_r.vhd          |     | Yes |        | Standard use   |<<<
// | pipeline_gen_bist_r.vhd |     | Yes |        | Standard use   |
// | bypass_gen_bist_r.vhd   | Yes | Yes |  Yes   | Standard use   |
// | bpout_gen_bist_r.vhd    | Yes | Yes |        | Standard use   |
// | flexible_gen_bist_r.vhd | Yes | Yes |  Yes   | Standard use   |
// +////////////////////////-+////-+////-+////////+////////////////+
//
// hierarchy: This is an RTL designer's standard component
//
//        gpc_gfx_spstore_gen_bist_r                << YOU ARE HERE
//         |
//         +- gpc_gfx_spstore_bist
//             |
//             +- gpc_gfx_spstore
//             |
//             +- [ gpc_gfx_bistwrap_sing ]
//
// ////////////////////////////////////////////////////////////////////////////-

// DIMENSIONS
//   Physical generics: w, d, p, log2d, wrcen, write_skid, read_skid
//
//                        width
//              <////////// w //////////>
//
//              +//////////////////////-+   ^
//              |_______________________|   |
//              |_______________________|   |  d
//              |_______________________|      e
//              |                       |   d  p
//              |                       |      t
//              :                       :   |  h
//              |                       |   |
//              +//////////////////////-+   v
//                         w/p *
//              <- p -><- p -> .. <- p ->
//                      partitions
//
//   All partitions are equal in size. In other words, the generic w is an
//   integer multiple of generic p.
//
//   Example partition:
//      [w = 128, p = 32] => w/p = 4 partitions => 4 write enables
//
//   Skid registers:
//      Added when either or both write_skid/read_skid = '1'

// PORTS
//   +////////////////////////////////////////////////////////-+
//   | name          |  bits  |dir| description                |
//   +////////////////////////////////////////////////////////-+
//   | addr          | log2d  | i | address                    |
//   | c_en          |   1    | i | chip enable (ACTIVE LOW)   |
//   | rd_data       |   w    | o | read data                  |
//   |               |        |   |                            |
//   | wr_data       |   w    | i | write data ((w/p)*p bits)  |
//   | wr_en         |  w/p   | i | write enables (ACTIVE LOW) |
//   |               |        |   |                            |
//   | clk           |   1    | i | common r/w clock           |
//   | resetn        |   1    | i | reset to BIST (ACTIVE LOW) |
//   |               |        |   |                            |
//   | bist_in       |f(w,p,d)| i | input from BIST controller |
//   | bist_out      |f(w,p,d)| o | result to BIST controller  |
//   +////////////////////////////////////////////////////////-+

// BEHAVIOURIAL MODEL
//   Functional behaviour is similar to gpc_gfx_spstore_bist but this hierarchical
//   level adds a back end read data register for timing purposes
//
//   Read latency:  2 clock
//   Write latency: 1 clock
//
//                   +//////////////////////////////////-+
//                   |      gpc_gfx_spstore_bist         |
//                   |                                   |
//                   |  +////////////////////////////-+  |
//                   |  |     gpc_gfx_spstore         |  |
//                   |  |                             |  |
//     addr     /////|//|-*///////////////////////.   |  |
//     c_en     ////-|//|-|//-*//////////////////.|   |  |
//                   |  | |   |                  ||   |  | rd
//                   |  | | +////+   +////-+   +////+ |  | en +////+
//                   |  | '-| wr |   |     |   | rd |-|//|////|    |
//     wr_en    /////|//|//-|proc|-/-| mem |-/-|proc|-|//|////|    |///->
//     wr_data  /////|//|//-|    |   |     |   |    | |  |    |    |   rd_data
//                   |  |   |    |  +|>    |  +|>   | |  | .//|>   |
//                   |  |   +////+  |+////-+  |+////+ |  | |  +////+
//                   |  |           |         |       |  | |
//     clk      ////-|//|//////////-*////////-*//////-|//|-'
//                   |  +////////////////////////////-+  |
//                   |  +////////////////////////////-+  |
//                   |  |                             |  |
//     bist_in  /////|//|  [ gpc_gfx_bistwrap_sing ]  |//|/////////-> bist_out
//     resetn   ////-|//|                             |  |
//                   |  +////////////////////////////-+  |
//                   +//////////////////////////////////-+
// Notes:
//   + In addition to wr_en, writes require c_en to be asserted (low)
//
// Read Skid Register
//   The current read address is compared against the cached last read address.
//   If it matches, then the data in the output register can be re-used without
//   having to access the RAM. This saves power.
//
//   The read skid register is updated on a miss i.e. when a RAM macro read
//   was required.
//
// Write Skid Register
//   Unmasked writes are cached. If a read address subsequently matches the
//   cached value, the read data can be supplied from the register rather than
//   the RAM. This can save power.
//
//   The write skid register is updated on new unmasked write, and invalidated
//   altogether on a masked write.

// OPTIONAL UTILITY GENERIC
//   id : integer value that can be assigned to each instance (default 0)
//                                                                      -=:PB=-
// ////////////////////////////////////////////////////////////////////////////-

module gpu_core_sp_gfx_spstore_gen_bist_r 
   import gpc_gfx_rambist_pack_::*;
#(
      parameter int                                      w                                                            = 32              ,
      parameter int                                      p                                                            = 2              ,
      parameter int                                      d                                                            = 2              ,
      parameter int                                      log2d                                                        = 1              ,
      parameter int                                      ECC                                                          = 0              ,    // ECC enable : 0=disable ECC; 1=enable ECC



      parameter int                                      id                                                           = 0              ,    // unique value per instance
      parameter logic                                    write_skid                                                   = 1'b0           ,    // write-triggered skid enable
      parameter logic                                    read_skid                                                    = 1'b0                // read_triggered skid enable 
)
(

      input    logic                                                        clk                                     ,
      input    logic                                                        resetn                                  ,
      input    logic                                                        c_en                                    ,
      input    logic [ ( w / p ) - 1 : 0 ]                                  wr_en                                   ,
      input    logic [ log2d - 1 : 0 ]                                      addr                                    ,
      input    logic [ w - 1 : 0 ]                                          wr_data                                 ,
      output   logic [ w - 1 : 0 ]                                          rd_data                                 ,
      // bist signals






      input    logic [ spstore_in ( w , p , d , ECC ) - 1 : 0 ]             bist_in                                 ,
      output   logic [ spstore_out ( w , p , d , ECC ) - 1 : 0 ]            bist_out                                ,
      input    logic                                                        tst_gclkenable                            
);





   //synopsys translate_off
   import gpc_gfx_backdoor_pkg_::*;
   //synopsys translate_on


   logic                                         rd_en_r                                 ;
   logic [ w - 1 : 0 ]                           rd_data_ram                             ;
   logic [ w - 1 : 0 ]                           rd_data_ram_r                           ;
   // Write-triggered skid signals
   logic                                         rd_wr_skid                              ;
   // Read-triggered skid signals
   logic                                         rd_rd_skid                              ;
   // Global skid signals
   logic                                         read_en                                 ;
   logic                                         gated_c_en                              ;
   logic [ w - 1 : 0 ]                           rd_data_mux                             ;

   ///////////////////////////////////////////////
   // backdoor access
   ///////////////////////////////////////////////
   //synopsys translate_off
   `ifndef SRAM_MODEL_SIM
   backdoor_access_fwd #(.w(w)) backdoor = new();
   initial backdoor.inst = i_gpu_core_sp_gfx_spstore_wrap.backdoor;
   `endif
   //synopsys translate_on
   ///////////////////////////////////////////////
   ///////////////////////////////////////////////
   // END backdoor access
   ///////////////////////////////////////////////

   gpu_core_sp_gfx_spstore_wrap_
      #(
         .w                               (w)                                          ,
         .p                               (p)                                          ,
         .d                               (d)                                          ,
         .log2d                           (log2d)                                      ,
         .ECC                             (ECC)                                        ,



         .id                              (id)                                          
         )
      i_gpu_core_sp_gfx_spstore_wrap
      (
         .clk                             (clk)                                        ,
         .resetn                          (resetn)                                     ,
         .c_en                            (gated_c_en)                                 ,
         .wr_en                           (wr_en)                                      ,
         .addr                            (addr)                                       ,
         .wr_data                         (wr_data)                                    ,
         .rd_data_ram                     (rd_data_ram)                                ,






         .bist_in                         (bist_in)                                    ,
         .bist_out                        (bist_out)                                   ,
         .tst_gclkenable                  (tst_gclkenable)                              
         );

   always_ff@(posedge clk or negedge resetn) begin
      if ( resetn == 1'b0 ) begin
         rd_en_r <= 1'b1 ;
      end else begin
         if ( c_en == 1'b0 & ( & wr_en ) == 1'b1 ) begin    // COV:tag4
            rd_en_r <= 1'b0 ;
         end else if ( rd_en_r == 1'b0 ) begin
            rd_en_r <= 1'b1 ;
         end
      end
   end

   // //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
   // Start of skid register additions
   // //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
   // chip enable is active low and rd_wr_skid is active high
   assign gated_c_en = c_en | rd_wr_skid | rd_rd_skid ;    // COV:tag6


   if ( ( ( write_skid == 1'b1 ) | ( read_skid == 1'b1 ) ) ) begin : g_common_skid

      // asserted when read is performed
      always_comb begin : p_read_en
         if ( ( ( ( & wr_en ) == 1'b1 ) & ( c_en == 1'b0 ) ) ) begin    // COV:tag2
            read_en = 1'b1 ;    // COV:tag3
         end else begin
            read_en = 1'b0 ;    // COV:tag3
         end
      end

   end // g_common_skid



   // if skids are active, generate skid registers (write triggered)
   if ( ( write_skid == 1'b1 ) ) begin : g_write_skid

      logic                                         full_write                              ;
      logic                                         masked_write                            ;
      logic [ w - 1 : 0 ]                           data_wr_skid                            ;
      logic [ log2d - 1 : 0 ]                       addr_wr_skid                            ;
      logic                                         valid_wr_skid                           ;
      logic                                         rd_wr_skid_r                            ;


      // asserted when full write is performed
      always_comb begin : p_full_write
         if ( ( ( ( | wr_en ) == 1'b0 ) & ( c_en == 1'b0 ) ) ) begin    // COV:tag2
            full_write = 1'b1 ;    // COV:tag3
         end else begin
            full_write = 1'b0 ;    // COV:tag3
         end
      end


      // asserted when masked write is performed
      always_comb begin : p_masked_write
         if ( ( ( full_write == 1'b0 ) & ( ( & wr_en ) == 1'b0 ) ) ) begin    // COV:tag2
            masked_write = 1'b1 ;    // COV:tag3
         end else begin
            masked_write = 1'b0 ;    // COV:tag3
         end
      end


      // skid registers
      always_ff @(posedge clk or negedge resetn) begin : p_wr_skid
         if ( ( resetn == 1'b0 ) ) begin
            data_wr_skid <= '0;    // COV:tag3
            addr_wr_skid <= '0;

         end else begin
            if ( ( full_write == 1'b1 ) ) begin
               data_wr_skid <= wr_data ;    // COV:tag3
               addr_wr_skid <= addr ;
            end
         end
      end


      // valid skid register
      always_ff @(posedge clk or negedge resetn) begin : p_valid_wr_skid
         if ( ( resetn == 1'b0 ) ) begin
            valid_wr_skid <= 1'b0 ;    // COV:tag3

         end else begin
            if ( ( full_write == 1'b1 ) ) begin
               valid_wr_skid <= 1'b1 ;    // COV:tag3

            end else if ( ( ( masked_write == 1'b1 ) & ( addr == addr_wr_skid ) ) ) begin    // COV:tag2
               valid_wr_skid <= 1'b0 ;    // COV:tag3
            end
         end
      end


      // signal is asserted when skid contains valid data and read is performed
      always_comb begin : p_rd_wr_skid
         if ( ( ( addr == addr_wr_skid ) & ( valid_wr_skid == 1'b1 ) & ( read_en == 1'b1 ) ) ) begin    // COV:tag2
            rd_wr_skid = 1'b1 ;    // COV:tag3
         end else begin
            rd_wr_skid = 1'b0 ;    // COV:tag3
         end
      end


      // registered rd_wr_skid signal required for timing
      always_ff @(posedge clk or negedge resetn) begin : p_rd_wr_skid_r
         if ( ( resetn == 1'b0 ) ) begin
            rd_wr_skid_r <= 1'b0 ;    // COV:tag3
         end else begin
            if ( ( rd_wr_skid_r != rd_wr_skid ) ) begin
               rd_wr_skid_r <= rd_wr_skid ;    // COV:tag3
            end
         end
      end


      // read data multiplexer
   always_comb begin : p_rdata_mux
      rd_data_mux = ( rd_wr_skid_r == 1'b1 ) ? data_wr_skid : rd_data_ram  ;    // COV:tag7


   end
   end // g_write_skid



   if ( ( write_skid == 1'b0 ) ) begin : g_no_write_skid

      assign rd_wr_skid = 1'b0 ;
      assign rd_data_mux = rd_data_ram ;

   end // g_no_write_skid



   // generate for read-triggered skid registers
   if ( ( read_skid == 1'b1 ) ) begin : g_read_skid

      logic                                         read_en_r                               ;
      logic [ log2d - 1 : 0 ]                       addr_rd_skid                            ;
      logic                                         valid_rd_skid                           ;


      always_ff @(posedge clk or negedge resetn) begin : p_read_en_r
         if ( ( resetn == 1'b0 ) ) begin
               read_en_r <= 1'b0 ;    // COV:tag3
         end else begin
            if ( ( read_en_r != read_en ) ) begin
               read_en_r <= read_en ;    // COV:tag3
            end
         end
      end


      always_ff @(posedge clk or negedge resetn) begin : p_addr_rd_skid
         if ( ( resetn == 1'b0 ) ) begin
            addr_rd_skid <= '0;    // COV:tag3

         end else begin
            if ( ( ( addr != addr_rd_skid ) & ( read_en == 1'b1 ) ) ) begin    // COV:tag2
               addr_rd_skid <= addr ;    // COV:tag3
            end
         end
      end


      always_comb begin : p_rd_rd_skid
         rd_rd_skid = 1'b0 ;    // COV:tag3

         if ( ( ( read_en == 1'b1 ) & ( read_en_r == 1'b1 ) & ( addr == addr_rd_skid ) & ( valid_rd_skid == 1'b1 ) ) ) begin    // COV:tag2
            rd_rd_skid = 1'b1 ;    // COV:tag3
         end
      end


      always_ff @(posedge clk or negedge resetn) begin : p_valid_rd_skid
         if ( ( resetn == 1'b0 ) ) begin
            valid_rd_skid <= 1'b0 ;    // COV:tag3

         end else begin
            if ( ( read_en == 1'b1 ) ) begin
               valid_rd_skid <= 1'b1 ;    // COV:tag3
            end else if ( ( ( addr == addr_rd_skid ) & ( c_en == 1'b0 ) & ( read_en == 1'b0 ) ) ) begin    // COV:tag7
               valid_rd_skid <= 1'b0 ;    // COV:tag3
            end
         end
      end

   end // g_read_skid



   if ( ( read_skid == 1'b0 ) ) begin : g_no_read_skid

  
      assign rd_rd_skid = 1'b0 ;
   end // g_no_read_skid

   // //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
   // End of skid register additions
   // //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

   always_ff@(posedge clk) begin
      begin    // COV:tag5
      if ( rd_en_r == 1'b0 ) begin
         rd_data_ram_r <= rd_data_mux ;
         end
      end
   end

   assign rd_data = rd_data_ram_r ;

endmodule    // gpc_gfx_spstore_gen_bist_r
