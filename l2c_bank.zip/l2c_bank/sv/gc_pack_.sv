/*

 * #==========================================================================#
 * |                                                                          |
 * |  Copyright (c) 2022, Fantasy Technologies Limited and/or its         |
 * |  affiliated group companies ("Fantasy"). All rights reserved.        |
 * |  No part of this content, either material or conceptual may be copied    |
 * |  or distributed, transmitted, transcribed, stored in a retrieval system  |
 * |  or translated into any human or computer language in any form by any    |
 * |  means, electronic, mechanical manual, or otherwise, or disclosed to     |
 * |  third parties without the express written permission of Fantasy.    |
 * |                                                                          |
 * #==========================================================================#

 */

// ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////-
// package name: gc_pack_
// purpose: Define localparams used by the whole core
// ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////-

package gc_pack_ ;

   //////////////////////////////////////////////////////////////////////////////////////////////-
   // Set locations of input/output files
   //////////////////////////////////////////////////////////////////////////////////////////////-
//synopsys translate_off
   // Directory containing input files
   localparam string GPC_INF_DIR   = "../infiles/current/";

   // Directory in which to write outfiles
   localparam string GPC_OUTF_DIR = "../outfiles/";

   // Directory containing configs controlling which outfiles are written
   localparam string GPC_OUTF_CFG_DIR = "../work/";

   // Main outfile config file
   localparam string GPC_OUTF_CFG = "../work/gc_outf_enable";

   // Director containing debug configuration files
   localparam string GPC_DEBUG_CFG_DIR = "../work/";

   // Debug config file
   localparam string GPC_DEBUG_CFG = "../work/gc_debug_config";
//synopsys translate_on
   //////////////////////////////////////////////////////////////////////////////////////////////-

endpackage
