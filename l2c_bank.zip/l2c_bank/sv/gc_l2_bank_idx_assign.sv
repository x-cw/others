/*


*/

// ----------------------------------------------------------------------------------------------
// entity name: gc_l2_bank_idx_assign
// purpose: Manage and assign a pool of Indices
// ----------------------------------------------------------------------------------------------

module gc_l2_bank_idx_assign 
#(
    parameter   NUM_INDICES     = 128,
    parameter   INDEX_BITS      = $clog2(NUM_INDICES),
    parameter   SIZE_WIDTH      = 2
)(
    input  logic                            clk,
    input  logic                            resetn,
    output logic                            idx_assign_idle,
    // ----------------------------------------------------------------------------
    // Allocate Indices
    // ----------------------------------------------------------------------------
    input  logic                            allocate_valid,
    input  logic   [SIZE_WIDTH - 1:0]       allocate_size,
    output logic                            assigned_index_valid,
    output logic   [INDEX_BITS - 1:0]       assigned_index,
    // ----------------------------------------------------------------------------
    // Free Indices
    // ----------------------------------------------------------------------------
    input  logic   [NUM_INDICES - 1:0]      index_freed_mask
);

// ----------------------------------------------------------------------------
// local parameter
// ----------------------------------------------------------------------------
localparam  MAX_ALLOC_INDEX = 2**SIZE_WIDTH;

logic [MAX_ALLOC_INDEX-1                : 0]    allocate_mask;
logic [NUM_INDICES-1+(MAX_ALLOC_INDEX-1): 0]    current_mask_wrap;
logic [NUM_INDICES - 1  : 0]                    fit_posn_mask;
logic                                           assigned_index_valid_l;
logic [INDEX_BITS  - 1  : 0]                    assigned_index_l;
logic [INDEX_BITS  - 1  : 0]                    assigned_index_rr;
logic [INDEX_BITS  - 1  : 0]                    prev_assigned_index;
logic [INDEX_BITS  - 1  : 0]                    coarse_prev_assigned_index;
logic [NUM_INDICES - 1  : 0]                    index_used_mask;
logic [NUM_INDICES - 1  : 0]                    n_index_used_mask;
logic [INDEX_BITS       : 0]                    n_index_end;
logic                                           n_index_wrap;

assign idx_assign_idle = ~(|(index_used_mask));
// ----------------------------------------------------------------------------
// Generate an allocation mask
// ----------------------------------------------------------------------------
assign allocate_mask = ~(({ {{MAX_ALLOC_INDEX-1}{1'b1}}, 1'b0} << (allocate_size)));
// ----------------------------------------------------------------------------
// Find out where within our mask the new allocation mask can fit
// ----------------------------------------------------------------------------
// example :SIZE_WIDTH=3, max allocate_size=8, need wrap 7-bit(8-1) index_used_mask
assign current_mask_wrap = {index_used_mask[MAX_ALLOC_INDEX-2:0], index_used_mask};

always_comb begin : p_allocate_mask_comb
    for(int unsigned p=0; p<=NUM_INDICES - 1; p++) begin
        // Set the bit corresponding to position p low if any of the next MAX_ALLOC_INDEX bits in the current mask starting at p and working 
        // upwards are set along with the corresponding bit in the MAX_ALLOC_INDEX-bit allocation mask
        fit_posn_mask[p] = (~|(current_mask_wrap[p +: MAX_ALLOC_INDEX] & allocate_mask)); // COV:t0
    end
end : p_allocate_mask_comb

assign assigned_index_valid_l = allocate_valid & (|(fit_posn_mask));

gpc_round_robin_index_arch1_ #(
    .width          (NUM_INDICES                ),
    .hold_previous  (1'b0                       )
) i_gpc_round_robin_index_arch1_assigned_index (
    .valids         (fit_posn_mask              ),
    .previous_index (coarse_prev_assigned_index ),
    .next_index     (assigned_index_rr          )
);

assign assigned_index_l = allocate_valid==1'b1 ? assigned_index_rr : prev_assigned_index;
// split to 4 range, find from range, not find from LSB always
assign coarse_prev_assigned_index[INDEX_BITS - 2 +: 2] = prev_assigned_index[INDEX_BITS - 2 +: 2];
assign coarse_prev_assigned_index[INDEX_BITS - 3:0] = '0;

always_ff @(posedge clk or negedge resetn) begin : p_index_used_mask_clkdrs
    if(!resetn) begin
        prev_assigned_index <= '0;
        index_used_mask <= '0;
    end
    else begin
        if(assigned_index_valid_l==1'b1) begin
            prev_assigned_index <= assigned_index_l;
        end
        if(assigned_index_valid_l==1'b1 || (|(index_freed_mask))==1'b1) begin
            index_used_mask <= n_index_used_mask;
        end
    end
end : p_index_used_mask_clkdrs

assign n_index_end  = {1'b0, assigned_index_l} + {1'b0, {INDEX_BITS-SIZE_WIDTH{1'b0}}, allocate_size};
assign n_index_wrap = n_index_end >= NUM_INDICES ? 1'b1 : 1'b0;

always_comb begin : p_next_index_used_mask_comb
    // Indices which are not being freed this cycle remain high if already set
    // n_index_used_mask = index_used_mask & ~index_freed_mask; // COV:t1
    // if(assigned_index_valid_l==1'b1) begin
    //     n_index_used_mask[(assigned_index_l)] = 1'b1;

    //     for(int unsigned size=1; size<MAX_ALLOC_INDEX; size++) begin
    //         if(size<=(allocate_size)) begin
    //             n_index_used_mask[((assigned_index_l) + size)%NUM_INDICES] = 1'b1;
    //         end
    //     end
    // end
    if(assigned_index_valid_l==1'b1) begin
        for(int unsigned size=0; size<NUM_INDICES; size++) begin
            if(n_index_wrap) begin
                if((size>=assigned_index_l) || (size<=(n_index_end-NUM_INDICES))) begin
                    n_index_used_mask[size] = 1'b1;
                end
                else begin
                    n_index_used_mask[size] = index_used_mask[size] & ~index_freed_mask[size];
                end
            end
            else if((size>=assigned_index_l) && (size<=((assigned_index_l+{{INDEX_BITS-SIZE_WIDTH{1'b0}}, allocate_size})))) begin
                n_index_used_mask[size] = 1'b1;
            end
            else begin
                n_index_used_mask[size] = index_used_mask[size] & ~index_freed_mask[size];
            end
        end
    end
    else begin
        n_index_used_mask = index_used_mask & ~index_freed_mask;
    end
end : p_next_index_used_mask_comb

// Assign local copies to outputs
assign assigned_index_valid = assigned_index_valid_l;
assign assigned_index = assigned_index_l;

endmodule : gc_l2_bank_idx_assign
