package pkg_cp_top;

`ifndef GPU_SYNTHESIS
   localparam CLK_ALIGN_DELAY = 1ps;
`endif

localparam  CP0_AXI5_ADDR_WIDTH   = 49;
localparam  CP0_AXI5_DATA_WIDTH   = 512;
localparam  CP0_AXI5_ID_WIDTH     = 9;
localparam  CP0_AXI5_LEN_WIDTH    = 3;
localparam  CP1_AXI4_ADDR_WIDTH   = 49;
localparam  CP1_AXI4_DATA_WIDTH   = 512;
localparam  CP1_AXI4_ID_WIDTH     = 9;
//localparam  CP1_AXI4_USER_WIDTH   = 18; no use
localparam  CP1_AXI4_LEN_WIDTH    = 3;
localparam  CP_CM_AXI4_ADDR_WIDTH = 41;
localparam  CP_CM_AXI4_DATA_WIDTH = 32;
localparam  CP_CM_AXI4_ID_WIDTH   = 6;
localparam  CP_CM_AXI4_USER_WIDTH = 8;
localparam  CP_CM_AXI4_LEN_WIDTH  = 4;
localparam  CP_CS_AXI4_ADDR_WIDTH = 32;
localparam  CP_CS_AXI4_DATA_WIDTH = 32;
localparam  CP_CS_AXI4_ID_WIDTH   = 6;
localparam  CP_CS_AXI4_USER_WIDTH = 8;
localparam  CP_CS_AXI4_LEN_WIDTH  = 4;


localparam  CP_PIM_AXI4_ADDR_WIDTH    = 16;
localparam  CP_PIM_AXI4_DATA_WIDTH    = 128;
localparam  CP_PIM_AXI4_ID_WIDTH      = 6;
localparam  CP_PIM_AXI4_LEN_WIDTH     = 4; 

//cp
//localparam                 NUM_SPC                                         = 8;
//localparam                 NUM_SPC_LOG2                                    = 3;
//localparam                 NUM_SPC_WIDTH                                   = 3;
localparam                 NUM_GPC                                         = 4;

localparam                 NUM_CP_IDLE                                     = 2;











//localparam                 CPC_RQ_CREDIT_WIDTH    = 4;
//localparam                 CPC_RQ_DESTID_WIDTH    = 2;
//localparam                 CPC_RQ_CPCID_WIDTH     = 2;
//localparam                 CPC_RQ_PARTITION_WIDTH = 222;
//localparam                 CPC_DOUT_CUID_WIDTH    = 4;
//localparam                 CPC_RSP_KERNELID_WIDTH = 6;

// mutex 
localparam                 MUTEX_NUM      =16;
localparam                 MUTEX_NUM_LOG2 =4;
localparam                 NUM_BIF2AXI    = 65;


endpackage
