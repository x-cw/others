/*

 * #==========================================================================#
 * |                                                                          |
 * |  Copyright (c) 2023, Fantasy Technologies Limited and/or its         |
 * |  affiliated group companies ("Fantasy"). All rights reserved.        |
 * |  No part of this content, either material or conceptual may be copied    |
 * |  or distributed, transmitted, transcribed, stored in a retrieval system  |
 * |  or translated into any human or computer language in any form by any    |
 * |  means, electronic, mechanical manual, or otherwise, or disclosed to     |
 * |  third parties without the express written permission of Fantasy.    |
 * |                                                                          |
 * #==========================================================================#

 */


// ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////-
// entity name: gpc_gfx_rstlres
//
// Component Description: IMGLIB3 Registered Staller
// Inserts a register in the valid, enable and data path between upstream and downstream modules in order to break a timing path.
// Data from the upstream module is always subject to at least a cycle delay as a result of inserting an RSTL into the path.
//
// Extensions on standard gpc_gfx_rstl functionality are that by default the datapath is reset so control signals can be fed through
// the gpc_gfx_rstlres. In order to preserve area when possible, the nonreset_width generic can be used to set aside a portion at the
// bottom of the data bus din if required to remain unreset when mixing control and datapath signals in the component.
//
// The gpc_gfx_rstl effectively operates as a 2-entry FIFO; when empty, data will be loaded directly into the output dout_i register
// stage, where it will be presented to the downstream module on the following cycle with vout asserted. If the downstream enable is
// set, then the data from dout_i will be transferred downstream. If more data is presented from upstream this will replace the
// data in dout_i on this cycle and the process will continue.
//
// If the downstream_enable drops, however, the gpc_gfx_rstl has the capacity to buffer up two cycles of data from din internally
// before propagating the enable drop to the upstream enable. On the cycle after dout_i is loaded, the next data presented at
// din will be loaded into the holding register stage, hld_din, and it's accompanying valid hld_vin will also be set.
//
// Once data is loaded into the hld_din stage, this will be multiplexed onto the input of the dout_i register stage to replace
// the dout_i data when it is transferred downstream. When the downstream enable is asserted again, if upstream data is presented
// it will replace the data in hld_din as the data is clocked into the dout_i output stage.
//
// If upstream data is not presented, the hld_din stage will empty itself into dout_i which will then go empty once downstream
// enable is presented, leaving the gpc_gfx_rstl empty.
//
// The area cost associated with adding a Registered Staller into the design is the 2 register stages of width W plus the muxing
// logic, however valid and data downstream, and enable upstream are all registered breaking any timing path across the interface.
//
// Generics:
// w              - INTEGER
//                - Width of Data bus Input/Output std_logic_vector
// nonreset_width - INTEGER
//                - Number of bits of din bus that should NOT be reset, (starting from LSB)
//                - DEFAULT 0 (all bits are reset)
//
// Portlist:
// clk     - Clock Input
// resetn  - Active-low asynchronous Reset
// din     - Data bus input (sized by generic w)
// vin     - Valid input from upstream module
// eout    - Enable output to upstream module
// dout    - Data bus output (sized by generic w)
// vout    - Valid output to downstream module
// ein     - Enable input from downstream module
// ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////-
//
//                               +-
//                               | \
//                               |  \
// din +//+//////////////////////+   |        +//////+
//        |                      |   |        |      |
//        |                      |   +////////+      +//////-+ dout
//        |      +//////+ hld_din|   |        |      |
//        |      |      |        |   |        |      |
//        +//////+      +////////+   |        |\     |
//               |      |        |  /      +//+/     |
//               |      |        | /       |  |      |
//               |\     |        +-        |  +//////+
//           +//-+/     |                  |
//           |   |      |                  |
//           |   +//////+                  |
//           |                             |
// clk +////-+////////////////////////////-+
//
// ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////-




module gpc_gfx_rstlres_
#(
   parameter int                                      w                                                            = 8              ,
           parameter int                                      nonreset_width                                               = 0               
)
(
   input    logic                                                        clk                                     ,
        input    logic                                                        resetn                                  ,
        // upstream signals
        input    logic [ w - 1 : 0 ]                                          din                                     ,
        input    logic                                                        vin                                     ,
        output   logic                                                        eout                                    ,
        // downstream signals
        output   logic [ w - 1 : 0 ]                                          dout                                    ,
        output   logic                                                        vout                                    ,
        input    logic                                                        ein                                       
);

   logic [ w - 1 : 0 ]                           hld_din                                 ;
   logic [ w - 1 : 0 ]                           nxt_hld_din                             ;
   logic                                         hld_vin                                 ;
   logic                                         nxt_hld_vin                             ;
   logic [ w - 1 : 0 ]                           dout_i                                  ;
   logic [ w - 1 : 0 ]                           nxt_dout                                ;
   logic                                         vout_i                                  ;
   logic                                         nxt_vout                                ;
   logic                                         eout_i                                  ;
   logic                                         nxt_eout                                ;
   logic [ w - 1 : 0 ]                           dsel                                    ;
   logic                                         vsel                                    ;









   always_ff @(posedge clk or negedge resetn) begin : rctrl
      if ( ( resetn == 1'b0 ) ) begin
         hld_vin <= 1'b0 ;
         vout_i <= 1'b0 ;
         eout_i <= 1'b1 ;
      end else begin
         hld_vin <= nxt_hld_vin ;
         vout_i <= nxt_vout ;
         eout_i <= nxt_eout ;
      end
   end // rctrl

   // No need to reset hld_din as not muxed into output unless previously written
   always_ff @(posedge clk) begin : p_hld_din
   
      begin
         // if holding register is getting a new value then load it
         if ( ( ein == 1'b0 & eout_i == 1'b1 & vin == 1'b1 & vout_i == 1'b1 ) ) begin
            hld_din <= nxt_hld_din ;
         end
      end
   end // p_hld_din

   if ( ( nonreset_width < w ) ) begin : g_reset_regs
      always_ff @(posedge clk or negedge resetn) begin : reset_regs
         if ( ( resetn == 1'b0 ) ) begin
            dout_i [ w - 1 : nonreset_width ] <= '0 ;
         end else begin
            // only clock data register if going to be valid
            // which is when it is being read or is empty and there is valid data upstream
            if ( ( ein == 1'b1 | vout_i == 1'b0 ) & ( ( eout_i == 1'b1 & vin == 1'b1 ) | hld_vin == 1'b1 ) ) begin    // COV:tag2
               dout_i [ w - 1 : nonreset_width ] <= nxt_dout [ w - 1 : nonreset_width ] ;
            end
         end
      end // reset_regs
   end // g_reset_regs

   if ( ( nonreset_width > 0 ) ) begin : g_nonreset_regs
      always_ff @(posedge clk) begin : nonreset_regs
         begin
            // only clock data register if going to be valid
            // which is when it is being read or is empty and there is valid data upstream
            if ( ( ein == 1'b1 | vout_i == 1'b0 ) & ( ( eout_i == 1'b1 & vin == 1'b1 ) | hld_vin == 1'b1 ) ) begin
               dout_i [ nonreset_width - 1 : 0 ] <= nxt_dout [ nonreset_width - 1 : 0 ] ;
            end
         end
      end // nonreset_regs
   end // g_nonreset_regs

   assign dout = dout_i ;
   assign vout = vout_i ;
   assign eout = eout_i ;

   // holding register is loaded with input if ready to accept data, otherwise
   // HOLD
   assign nxt_hld_din = ( eout_i == 1'b1 & vin == 1'b1 ) ? din : hld_din  ;

   // the holding register becomes valid when data not being taken and
   assign nxt_hld_vin = ( ein == 1'b0 & eout_i == 1'b1 & vin == 1'b1 & vout_i == 1'b1 ) ? 1'b1 : ( ein == 1'b1 ) ? 1'b0 : hld_vin   ;  

   // //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
   // dout register is loaded with
   // din     : if holding register is empty and being read or not currently valid
   // hld_din : if holding register is full and being read or not currently valid
   // dout_i  : HOLD, if not being read and currently valid
   assign dsel = ( hld_vin == 1'b0 ) ? din : hld_din  ;

   assign nxt_dout = ( ein == 1'b1 | vout_i == 1'b0 ) ? dsel : dout_i  ;

   // //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
   // vout register is
   // vin     : if holding register is empty and being read or not currently valid
   // 1       : if holding register is full and being read or not currently valid
   // vout_i  : HOLD, if not being read and currently valid
   assign vsel = ( hld_vin == 1'b0 ) ? ( eout_i & vin ) : 1'b1  ;    // COV:tag1

   assign nxt_vout = ( ein == 1'b1 | vout_i == 1'b0 ) ? vsel : vout_i  ;

   // //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
   // take data in if valid enable is active downstream which means it will be read out or
   // the holding register is empty and ..... or
   // the holding register is empty and there is no new data coming in
   assign nxt_eout = ( ( ein == 1'b1 ) | ( hld_vin == 1'b0 & vout_i == 1'b0 ) | ( hld_vin == 1'b0 & vin == 1'b0 ) ) ? 1'b1 : 1'b0  ; 

endmodule // gpc_gfx_rstlres
