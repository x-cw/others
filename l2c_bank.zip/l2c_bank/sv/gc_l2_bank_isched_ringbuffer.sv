/*

 * #==========================================================================#
 * |                                                                          |
 * |  Copyright (c) 2023, Fantasy Technologies Limited and/or its         |
 * |  affiliated group companies ("Fantasy"). All rights reserved.        |
 * |  No part of this content, either material or conceptual may be copied    |
 * |  or distributed, transmitted, transcribed, stored in a retrieval system  |
 * |  or translated into any human or computer language in any form by any    |
 * |  means, electronic, mechanical manual, or otherwise, or disclosed to     |
 * |  third parties without the express written permission of Fantasy.    |
 * |                                                                          |
 * #==========================================================================#

 */
// Converted using /user/jfd/Perforce/jeff.bond_volcanic4_ws/infra/hardware_flow/convsv/MAIN/src/convsv.py on 19/05/2022 11:02:20. Original source file: gc_mss_bank_isched_ring_buffer.vhd

module gc_l2_bank_isched_ringbuffer 
   import gc_l2_bank_pkg::*;
   import gpc_gfx_timing_buffer_pack_::*;

   // ---------------------------------------------------------------------------------------------------------------------------------
   // entity name: gc_l2_bank_isched_rb
   // purpose: Reorder instructions and determine what to execute on behalf of the Instruction Scheduler
   // ---------------------------------------------------------------------------------------------------------------------------------
(
   input  logic                                                      clk,
   input  logic                                                      resetn,
   output logic                                                      l2_bank_isched_rb_idle,
   // --------------------------------------------------------------------
   // Tagctrl Interfaces
   // --------------------------------------------------------------------
   // TagCtrl instruction interface: WR, RD, AA, Prefetch
   input  logic                                                      tagctrl_isched_valid,
   output logic                                                      tagctrl_isched_ready,
   input  tagctrl_isched_record_type                                 tagctrl_isched_rec,



   // ----------------------------------------------------------------------------
   // XBAR Interface
   // ----------------------------------------------------------------------------
   // Issued Instructions
   output logic                   [L2_NUM_RCTRL-1:0]                 isched_xbar_instr_valid,
   input  logic                   [L2_NUM_RCTRL-1:0]                 isched_xbar_instr_ready,
   output isched_xbar_record_type [L2_NUM_RCTRL-1:0]                 isched_xbar_instr_rec,

   // ----------------------------------------------------------------------------
   // RAM Ctrl Interface
   // ----------------------------------------------------------------------------
   // Clear Waiting linefill/WB Bit interface (either when Linefill data has returned or cacheline is ready)
   input  logic [L2_NUM_RCTRL-1:0]                                   rctrl_isched_valid,
   input  rctrl_isched_record_type  [L2_NUM_RCTRL-1:0]               rctrl_isched_rec,
                                                                     


   // ----------------------------------------------------------------------------
   //GDM
   // ----------------------------------------------------------------------------
   
   output logic l2b_reqsch_sortq_full,
   output logic l2b_reqsch_sortq_stall_but_not_full

);



localparam logic  [L2_IWDB_INDEX_BITS - 1                         : 0                          ] RAM_IWDB_INDEX  = '0;
localparam logic  [$high(RAM_IWDB_INDEX) + 1 + L2_AXI_ID_WIDTH -1 : $high(RAM_IWDB_INDEX) + 1  ] RAM_AXID        = '0;
localparam logic  [$high(RAM_AXID) + 1 + 2 - 1                    : $high(RAM_AXID)  + 1       ] RAM_START_BEAT  = '0;
localparam logic  [$high(RAM_START_BEAT) + 1 + 2 - 1              : $high(RAM_START_BEAT) + 1  ] RAM_BLEN        = '0;
localparam logic  [$high(RAM_BLEN) + 1 + 3 - 1                    : $high(RAM_BLEN) + 1        ] RAM_INSTRUCTION = '0;
localparam logic  [$high(RAM_INSTRUCTION) + 1 + 2 -1              : $high(RAM_INSTRUCTION) + 1 ] RAM_CHECK_PARTIAL = '0;

localparam int REORDER_BUFFER_RAM_P = ISCHED_RING_BUFFER_RAM_WIDTH;

logic [L2_NUM_RCTRL-1:0]                                                             instruction_cnt_dec;
logic                                                                                instruction_cnt_inc;
logic [L2_ISCHED_RB_ENTRY_BITS:0]                                                    pending_instruction_cnt;
logic                                                                                tagctrl_isched_input_accepted;
//logic                                                                                tagctrl_isched_bypass;

logic [L2_NUM_RCTRL-1:0]                                                             rctrl_isched_lf_done_valid;
                                                                                                              
logic [L2_NUM_RCTRL-1:0]                                                             rctrl_isched_wb_done_valid;



logic [L2_ISCHED_NUM_RB_ENTRY-1:0]                                                   rb_entry_valid;
logic [L2_ISCHED_NUM_RB_ENTRY-1:0]                                                   rb_entry_valid_sll1;
logic                                                                                rb_entries_busy;


logic [L2_ISCHED_RB_ENTRY_BITS-1:0]                                                   n_prev_oldest_buffer_entry;
logic [L2_ISCHED_RB_ENTRY_BITS-1:0]                                                   prev_oldest_buffer_entry;
logic [L2_ISCHED_RB_ENTRY_BITS-1:0]                                                   n_assign_buffer_entry;
logic [L2_ISCHED_RB_ENTRY_BITS-1:0]                                                   assign_buffer_entry;
logic [L2_NUM_RCTRL-1:0][L2_ISCHED_NUM_RB_ENTRY-1 :0]                                 rb_entry_output_valid;
logic [L2_NUM_RCTRL-1:0]                                                              next_output_buffer_entry_valid;
logic [L2_NUM_RCTRL-1:0][L2_ISCHED_RB_ENTRY_BITS-1:0]                                 next_output_buffer_entry;
//logic [L2_NUM_RCTRL-1:0]                                                              accept_into_execution_stage;
//logic [L2_NUM_RCTRL-1:0]                                                              execute_instruction_valid;
logic [L2_NUM_RCTRL-1:0]                                                              execute_instruction_ready;
isched_xbar_record_type [L2_NUM_RCTRL-1:0]                                            execute_instruction_rec;
logic [L2_NUM_RCTRL-1:0]                                                              execute_instruction_tbuf_valid;
logic [L2_NUM_RCTRL-1:0]                                                              execute_instruction_tbuf_ready;
isched_xbar_record_type [L2_NUM_RCTRL-1:0]                                            execute_instruction_tbuf_rec;

//logic                                                                                 tagctrl_isched_wb_completing;

//logic [L2_NUM_SECTOR-1:0]                                                             tagctrl_isched_stage0_sector_lf_returning;
//logic [L2_NUM_SECTOR-1:0]                                                             tagctrl_isched_stage0_sector_lf_returning_per_rctrl [L2_NUM_RCTRL-1:0];
//logic                                                                                 tagctrl_isched_stage0_wb_completing;
//logic [L2_NUM_RCTRL-1:0]                                                              tagctrl_isched_stage0_wb_completing_per_rctrl;

logic [L2_NUM_SECTOR-1:0]                                                             tagctrl_isched_stage1_sector_lf_return_already;
logic [L2_NUM_SECTOR-1:0]                                                             tagctrl_isched_stage1_sector_lf_returning;
logic [L2_NUM_SECTOR-1:0]                                                             tagctrl_isched_stage1_sector_lf_returning_per_rctrl [L2_NUM_RCTRL-1:0];
logic                                                                                 tagctrl_isched_stage1_wb_completing;
logic                                                                                 tagctrl_isched_stage1_wb_complete_already;
logic [L2_NUM_RCTRL-1:0]                                                              tagctrl_isched_stage1_wb_completing_per_rctrl;

ring_buffer_entries_record_type [L2_ISCHED_NUM_RB_ENTRY-1:0]                          n_ring_buffer_entries;
ring_buffer_entries_record_type [L2_ISCHED_NUM_RB_ENTRY-1:0]                          ring_buffer_entries;

logic [L2_NUM_RCTRL-1:0]                                                              search_lf_result_valid ;
logic [L2_ISCHED_NUM_RB_ENTRY-1:0]                                                    search_lf_result_mask [L2_NUM_RCTRL-1:0] ;
logic [L2_NUM_RCTRL-1:0]                                                              search_wb_result_valid ;
logic [L2_ISCHED_NUM_RB_ENTRY-1:0]                                                    search_wb_result_mask [L2_NUM_RCTRL-1:0] ;

logic [L2_ISCHED_NUM_RB_ENTRY-1:0]                                                    n_rb_entry_valid;


logic [L2_NUM_SECTOR-1 : 0][L2_ISCHED_NUM_RB_ENTRY-1:0]                               tagctrl_isched_lookup_lf ;
logic [L2_ISCHED_NUM_RB_ENTRY-1:0]                                                    tagctrl_isched_lookup_wb;

logic [L2_NUM_SECTOR-1:0]                                                             tagctrl_isched_lf_new_status;
logic                                                                                 tagctrl_isched_wb_new_status;


//logic                                                                                 tagctrl_isched_stage0_valid;
//logic                                                                                 tagctrl_isched_stage0_ready;
//tagctrl_isched_record_type                                                            tagctrl_isched_stage0_rec;

logic                                                                                 tagctrl_isched_stage1_valid;
logic                                                                                 tagctrl_isched_stage1_ready;
tagctrl_isched_record_type                                                            tagctrl_isched_stage1_rec;

logic [L2_NUM_RCTRL-1:0]next_output_buffer_entry_ready;
logic [L2_NUM_RCTRL-1:0]pending_readout_valid;
logic [L2_NUM_RCTRL-1:0]pending_readout_ready;
logic [L2_NUM_RCTRL-1:0][L2_ISCHED_RB_ENTRY_BITS-1:0]pending_readout_idx;





   


// Decrement the instruction counter when an instruction is moved out of the masks
assign instruction_cnt_dec = pending_readout_valid & pending_readout_ready;
assign instruction_cnt_inc = tagctrl_isched_input_accepted;

// Counter for in-flight instructions
always_ff@(posedge clk or negedge resetn) begin : p_in_flight_counter_clkdrs
   if(resetn==1'b0) begin
      pending_instruction_cnt <= '0;
   end
   else begin
      if(instruction_cnt_inc || (|instruction_cnt_dec)) begin
         pending_instruction_cnt <= pending_instruction_cnt + 9'(instruction_cnt_inc) - 9'(instruction_cnt_dec[0]) - 9'(instruction_cnt_dec[1]);
      end
   end
end : p_in_flight_counter_clkdrs


assign rb_entries_busy = pending_instruction_cnt>0 ? 1'b1 : 1'b0;
assign l2_bank_isched_rb_idle = (rb_entries_busy==1'b1 || tagctrl_isched_valid==1'b1 || tagctrl_isched_stage1_valid==1'b1  || (|execute_instruction_tbuf_valid)) ? 1'b0 : 1'b1;
// Drop ready whenever the Reorder Buffer Entry which should be assigned next is already populated as entries are always
// assigned in incrementing order such that it is always possible to work out the order in which they were submitted
assign tagctrl_isched_stage1_ready = (assign_buffer_entry==prev_oldest_buffer_entry) ? 1'b0 : 1'b1;
// Allow a request to bypass when there is nothing else in the Buffer and the request is a Hit (either RD or AA), note that the
// buffer being empty also includes the output register stages otherwise a bypass instruction may overtake something it shouldn't
//assign tagctrl_isched_bypass = (tagctrl_isched_valid==1'b1 && (tagctrl_isched_rec.instruction==RD || tagctrl_isched_rec.instruction==AA || tagctrl_isched_rec.instruction==WR) && (tagctrl_isched_rec.linefill_waiting==1'b0 || tagctrl_isched_cacheline_returning==1'b1) && (tagctrl_isched_rec.wb_waiting==1'b0 || tagctrl_isched_wb_completing) && (tagctrl_isched_rec.hazard_flag == 2'b0) && pending_instruction_cnt==0 && execute_instruction_mstl_valid==1'b0 && isched_rctrl_instr_valid_l==1'b0) ? 1'b1 : 1'b0;

assign tagctrl_isched_input_accepted = tagctrl_isched_stage1_valid & tagctrl_isched_stage1_ready;
//assign tagctrl_isched_input_accepted = tagctrl_isched_valid & tagctrl_isched_ready_l & ~tagctrl_isched_bypass;
// Determine if the Cacheline pointed to by the incoming instruction is outstanding or not including if it is returning in the
// same cycle





//always_comb begin : p_overwrite_the_waiting_status_in_stage0
//   tagctrl_isched_stage0_rec = tagctrl_isched_rec;
   
   // if(tagctrl_isched_stage0_sector_lf_returning==1'b1)begin
   //    tagctrl_isched_stage0_rec.linefill_waiting = tagctrl_isched_rec.linefill_waiting & ~tagctrl_isched_stage0_sector_lf_returning;
   // end

   // if(tagctrl_isched_stage0_wb_completing==1'b1)begin
   //    tagctrl_isched_stage0_rec.wb_waiting = tagctrl_isched_rec.wb_waiting & ~tagctrl_isched_stage0_wb_completing;
   // end
//end



gpc_gfx_timing_buffer_ #(
   .BUFFER_TYPE   (GPC_GFX_TIMING_BUFFER_PIPE_REG), //can't be change
   .WIDTH         ($bits(tagctrl_isched_rec))
) i_tbuff_tagctrl_isched_stage1 (
   .clk              ( clk                         ) ,
   .resetn           ( resetn                      ) ,
   .tbuff_in_valid   ( tagctrl_isched_valid        ) ,
   .tbuff_in_enable  ( tagctrl_isched_ready        ) ,
   .tbuff_in_data    ( tagctrl_isched_rec          ) ,
   .tbuff_out_valid  ( tagctrl_isched_stage1_valid ) ,
   .tbuff_out_enable ( tagctrl_isched_stage1_ready ) ,
   .tbuff_out_data   ( tagctrl_isched_stage1_rec   )
);





//stage0 lf status overwrite

//assign tagctrl_isched_stage0_sector_lf_returning = tagctrl_isched_stage0_sector_lf_returning_per_rctrl[0] | tagctrl_isched_stage0_sector_lf_returning_per_rctrl[1];

// always_comb begin: p_stage0_sector_lf_returning_comb
//    tagctrl_isched_stage0_sector_lf_returning_per_rctrl = '{default : '0};
//    
//    for(int RCTRL_NUM=0; RCTRL_NUM<=L2_NUM_RCTRL-1; RCTRL_NUM++)begin
//       if (rctrl_isched_lf_done_valid[RCTRL_NUM]==1'b1 && tagctrl_isched_valid==1'b1)begin
//          if (tagctrl_isched_rec.set==rctrl_isched_rec[RCTRL_NUM].set && tagctrl_isched_rec.way==rctrl_isched_rec[RCTRL_NUM].way)begin
//             for(int SECTOR=0; SECTOR<=L2_NUM_SECTOR-1; SECTOR++)begin
//                if (rctrl_isched_rec[RCTRL_NUM].sector_mask[SECTOR]==1'b1)begin
//                   tagctrl_isched_stage0_sector_lf_returning_per_rctrl[RCTRL_NUM][SECTOR] = 1'b1;
//                end
//             end
//          end
//       end
//    end
// end : p_stage0_sector_lf_returning_comb


//stage1 lf status overwrite

assign tagctrl_isched_stage1_sector_lf_returning = tagctrl_isched_stage1_sector_lf_returning_per_rctrl[0] | tagctrl_isched_stage1_sector_lf_returning_per_rctrl[1];


always_ff@(posedge clk or negedge resetn)begin
   if(resetn==1'b0)begin
      tagctrl_isched_stage1_sector_lf_return_already <= '0;
   end
   else begin
      tagctrl_isched_stage1_sector_lf_return_already <= (tagctrl_isched_stage1_sector_lf_return_already | tagctrl_isched_stage1_sector_lf_returning) & ~{2{tagctrl_isched_stage1_ready}};
   end
end


always_comb begin: p_stage1_sector_lf_returning_comb
   tagctrl_isched_stage1_sector_lf_returning_per_rctrl = '{default : '0};
   
   for(int RCTRL_NUM=0; RCTRL_NUM<=L2_NUM_RCTRL-1; RCTRL_NUM++)begin
      if (rctrl_isched_lf_done_valid[RCTRL_NUM]==1'b1 && tagctrl_isched_stage1_valid==1'b1)begin
         if (tagctrl_isched_stage1_rec.set==rctrl_isched_rec[RCTRL_NUM].set && tagctrl_isched_stage1_rec.way==rctrl_isched_rec[RCTRL_NUM].way)begin
            for(int SECTOR=0; SECTOR<=L2_NUM_SECTOR-1; SECTOR++)begin
               if (rctrl_isched_rec[RCTRL_NUM].sector_mask[SECTOR]==1'b1)begin
                  tagctrl_isched_stage1_sector_lf_returning_per_rctrl[RCTRL_NUM][SECTOR] = 1'b1;
               end
            end
         end
      end
   end
end : p_stage1_sector_lf_returning_comb



generate
for(genvar RCTRL_NUM=0; RCTRL_NUM<= L2_NUM_RCTRL-1; RCTRL_NUM++)begin : g_stage01_wb_completing

//stage0 wb status overwrite
   //always_comb begin : p_stage0_port_wb_completing_comb
   //
   //   tagctrl_isched_stage0_wb_completing_per_rctrl[RCTRL_NUM] = 1'b0;
   //
   //   if(rctrl_isched_wb_done_valid[RCTRL_NUM]==1'b1 && tagctrl_isched_valid==1'b1)begin
   //      if(rctrl_isched_rec[RCTRL_NUM].set==tagctrl_isched_rec.set)begin
   //         if(rctrl_isched_rec[RCTRL_NUM].way==tagctrl_isched_rec.way)begin
   //            tagctrl_isched_stage0_wb_completing_per_rctrl[RCTRL_NUM] = 1'b1;
   //         end
   //      end
   //   end
   //   
   //end
   
   
   
//stage1 wb status overwrite
   always_comb begin : p_stage1_port_wb_completing_comb
      tagctrl_isched_stage1_wb_completing_per_rctrl[RCTRL_NUM] = 1'b0;
      
      if(rctrl_isched_wb_done_valid[RCTRL_NUM]==1'b1 && tagctrl_isched_stage1_valid==1'b1)begin
         if(rctrl_isched_rec[RCTRL_NUM].set==tagctrl_isched_stage1_rec.set)begin
            if(rctrl_isched_rec[RCTRL_NUM].way==tagctrl_isched_stage1_rec.way)begin
               tagctrl_isched_stage1_wb_completing_per_rctrl[RCTRL_NUM] = 1'b1;
            end
         end
      end
   end

end : g_stage01_wb_completing
endgenerate

//assign tagctrl_isched_stage0_wb_completing = |tagctrl_isched_stage0_wb_completing_per_rctrl;

assign tagctrl_isched_stage1_wb_completing = |tagctrl_isched_stage1_wb_completing_per_rctrl;



always_ff@(posedge clk or negedge resetn)begin
   if(resetn==1'b0)begin
      tagctrl_isched_stage1_wb_complete_already <= 1'b0;
   end
   else begin
      tagctrl_isched_stage1_wb_complete_already <= (tagctrl_isched_stage1_wb_complete_already | tagctrl_isched_stage1_wb_completing) & ~tagctrl_isched_stage1_ready;
   end
end



// ----------------------------------------------------------------------------
// Manage the Reorder Buffer entries which hold the instructions in submission order (effectively a circular buffer)
// ----------------------------------------------------------------------------

assign n_assign_buffer_entry = (assign_buffer_entry==L2_ISCHED_NUM_RB_ENTRY - 1) ? '0 : assign_buffer_entry + 1;


always_ff@(posedge clk or negedge resetn) begin : p_manage_ring_buffer_clkdrs
   if(resetn==1'b0) begin
      assign_buffer_entry <= '0;
   end
   else begin
      if(tagctrl_isched_input_accepted==1'b1) begin
         assign_buffer_entry <= n_assign_buffer_entry;
      end
   end
end : p_manage_ring_buffer_clkdrs




// ----------------------------------------------------------------------------
// lookup the buffer entry to assign the linefill and wb status
// ----------------------------------------------------------------------------
generate
for(genvar ENTRY=0; ENTRY<=L2_ISCHED_NUM_RB_ENTRY-1; ENTRY++ ) begin : g_tagctrl_isched_lookup_wb_lf_status
   always_comb begin : p_lookup_lf_wb_comb
      tagctrl_isched_lookup_lf[0][ENTRY] = 1'b0;
      tagctrl_isched_lookup_lf[1][ENTRY] = 1'b0;
      tagctrl_isched_lookup_wb[ENTRY] = 1'b0;
   
      if(tagctrl_isched_stage1_valid==1'b1 && rb_entry_valid[ENTRY]==1'b1)begin
         if(tagctrl_isched_stage1_rec.set==ring_buffer_entries[ENTRY].set && tagctrl_isched_stage1_rec.way==ring_buffer_entries[ENTRY].way)begin
            tagctrl_isched_lookup_wb[ENTRY] = ring_buffer_entries[ENTRY].wb_waiting;
   
   
            if(|(tagctrl_isched_stage1_rec.sector_mask & ring_buffer_entries[ENTRY].sector_mask))begin
               tagctrl_isched_lookup_lf[0][ENTRY] = ring_buffer_entries[ENTRY].linefill_waiting[0];
               tagctrl_isched_lookup_lf[1][ENTRY] = ring_buffer_entries[ENTRY].linefill_waiting[1];
            end
            else begin
               if(tagctrl_isched_stage1_rec.sector_mask[0] & ring_buffer_entries[ENTRY].linefill_waiting[0])begin
                  tagctrl_isched_lookup_lf[0][ENTRY] = ring_buffer_entries[ENTRY].linefill_waiting[0];
               end
               if(tagctrl_isched_stage1_rec.sector_mask[1] & ring_buffer_entries[ENTRY].linefill_waiting[1])begin
                  tagctrl_isched_lookup_lf[1][ENTRY] = ring_buffer_entries[ENTRY].linefill_waiting[1];
               end
            end
         end
      end
      
   end : p_lookup_lf_wb_comb

end : g_tagctrl_isched_lookup_wb_lf_status






for(genvar SECTOR=0; SECTOR<=L2_NUM_SECTOR-1; SECTOR++) begin : g_get_new_linefill_waiting_status
   assign tagctrl_isched_lf_new_status[SECTOR] =  |tagctrl_isched_lookup_lf[SECTOR];
end : g_get_new_linefill_waiting_status
endgenerate

assign tagctrl_isched_wb_new_status = |tagctrl_isched_lookup_wb;





 //----------------------------------------------------------------------------
 //record the stauts on the Buffer Entries
 //----------------------------------------------------------------------------
always_comb begin : p_write_status_to_buffer_entries
   n_ring_buffer_entries = ring_buffer_entries;
   if (tagctrl_isched_input_accepted == 1'b1)begin
      n_ring_buffer_entries[assign_buffer_entry]                  = tagctrl_isched_stage1_rec;
      n_ring_buffer_entries[assign_buffer_entry].linefill_waiting = (tagctrl_isched_stage1_rec.linefill_waiting | tagctrl_isched_lf_new_status) & ~(tagctrl_isched_stage1_sector_lf_returning | tagctrl_isched_stage1_sector_lf_return_already);
      n_ring_buffer_entries[assign_buffer_entry].wb_waiting       = (tagctrl_isched_stage1_rec.wb_waiting | tagctrl_isched_wb_new_status) & ~(tagctrl_isched_stage1_wb_complete_already | tagctrl_isched_stage1_wb_completing);
   end
   
   for(int RCTRL_NUM=0; RCTRL_NUM<=L2_NUM_RCTRL-1; RCTRL_NUM++)begin
      if(search_lf_result_valid[RCTRL_NUM] == 1'b1)begin
         for(int ENTRY=L2_ISCHED_NUM_RB_ENTRY-1; ENTRY>=0; ENTRY--)begin
            if(search_lf_result_mask[RCTRL_NUM][ENTRY]==1'b1 && rb_entry_valid[ENTRY]==1'b1)begin
               for(int SECTOR=0; SECTOR<=L2_NUM_SECTOR-1; SECTOR++)begin
                  if(rctrl_isched_rec[RCTRL_NUM].sector_mask[SECTOR]==1'b1)begin
                     n_ring_buffer_entries[ENTRY].linefill_waiting[SECTOR] = 1'b0;
                  end
               end
            end
         end
      end

      if(search_wb_result_valid[RCTRL_NUM] == 1'b1)begin
         for(int ENTRY=L2_ISCHED_NUM_RB_ENTRY-1; ENTRY>=0; ENTRY--)begin
            if(search_wb_result_mask[RCTRL_NUM][ENTRY]==1'b1 && rb_entry_valid[ENTRY]==1'b1)begin
               n_ring_buffer_entries[ENTRY].wb_waiting = 1'b0;
            end
         end
      end

   end
   
end : p_write_status_to_buffer_entries

//generate
//for(genvar ENTRY=0; ENTRY<=L2_ISCHED_NUM_RB_ENTRY-1; ENTRY++)begin : g_ring_buffer_entries_comb
//   always_comb begin : p_write_status_to_buffer_entries
//      n_ring_buffer_entries[ENTRY] = ring_buffer_entries[ENTRY];
//      if (tagctrl_isched_input_accepted && ENTRY==assign_buffer_entry)begin
//         n_ring_buffer_entries[ENTRY]                  = tagctrl_isched_stage1_rec;
//         n_ring_buffer_entries[ENTRY].linefill_waiting = (tagctrl_isched_stage1_rec.linefill_waiting | tagctrl_isched_lf_new_status) & ~(tagctrl_isched_stage1_sector_lf_returning | tagctrl_isched_stage1_sector_lf_return_already);
//         n_ring_buffer_entries[ENTRY].wb_waiting       = (tagctrl_isched_stage1_rec.wb_waiting | tagctrl_isched_wb_new_status) & ~(tagctrl_isched_stage1_wb_complete_already | tagctrl_isched_stage1_wb_completing);
//      end
//      else begin
//         if(search_lf_result_mask[0][ENTRY]==1'b1 && rb_entry_valid[ENTRY]==1'b1)begin//0 for RCTRL 0
//            n_ring_buffer_entries[ENTRY].linefill_waiting = ring_buffer_entries[ENTRY].linefill_waiting & (~rctrl_isched_rec[0].sector_mask);
//         end
//         else if(search_lf_result_mask[1][ENTRY]==1'b1 && rb_entry_valid[ENTRY]==1'b1)begin  // 1 for RCTRL 1
//            n_ring_buffer_entries[ENTRY].linefill_waiting = ring_buffer_entries[ENTRY].linefill_waiting & (~rctrl_isched_rec[1].sector_mask);
//         end
//
//   
//         if(search_wb_result_valid[0] == 1'b1)begin //0 for RCTRL 0
//            if(search_wb_result_mask[0][ENTRY]==1'b1 && rb_entry_valid[ENTRY]==1'b1)begin
//               n_ring_buffer_entries[ENTRY].wb_waiting = 1'b0;
//            end
//         end
//         else if(search_wb_result_valid[1] == 1'b1)begin // 1 for RCTRL 1
//            if(search_wb_result_mask[1][ENTRY]==1'b1 && rb_entry_valid[ENTRY]==1'b1)begin
//               n_ring_buffer_entries[ENTRY].wb_waiting = 1'b0;
//            end
//         end
//
//   
//      end
//      
//   end : p_write_status_to_buffer_entries
//end : g_ring_buffer_entries_comb
//endgenerate


always_ff@(posedge clk or negedge resetn) begin : p_write_status_to_buffer_entries_clkd
   if(resetn==1'b0)begin
      for(int ENTRY=0; ENTRY<=L2_ISCHED_NUM_RB_ENTRY-1; ENTRY++)begin
         ring_buffer_entries[ENTRY] <= '0;
      end
   end
   else begin
      if((tagctrl_isched_input_accepted == 1'b1) || (|search_lf_result_valid == 1'b1) || (|search_wb_result_valid == 1'b1))begin
         for(int unsigned entry_div4=0; entry_div4<=L2_ISCHED_NUM_RB_ENTRY/4-1; entry_div4++)begin
            ring_buffer_entries[4*entry_div4 + 0] <= n_ring_buffer_entries[4*entry_div4 + 0];
            ring_buffer_entries[4*entry_div4 + 1] <= n_ring_buffer_entries[4*entry_div4 + 1];
            ring_buffer_entries[4*entry_div4 + 2] <= n_ring_buffer_entries[4*entry_div4 + 2];
            ring_buffer_entries[4*entry_div4 + 3] <= n_ring_buffer_entries[4*entry_div4 + 3];
         end
      end
   end
end : p_write_status_to_buffer_entries_clkd



generate
for(genvar RCTRL_NUM=0; RCTRL_NUM<=L2_NUM_RCTRL-1; RCTRL_NUM++)begin : g_decode_lf_or_wb
   assign rctrl_isched_lf_done_valid[RCTRL_NUM] = rctrl_isched_valid[RCTRL_NUM] &  rctrl_isched_rec[RCTRL_NUM].lf_or_wb;   //1 for lf; 0 for wb
   assign rctrl_isched_wb_done_valid[RCTRL_NUM] = rctrl_isched_valid[RCTRL_NUM] & ~rctrl_isched_rec[RCTRL_NUM].lf_or_wb;
end
endgenerate

// ----------------------------------------------------------------------------
// Lookup on the Buffer Entries
// ----------------------------------------------------------------------------
// Perform a lookup on the Ring Buffer entries for incoming Misses based on the set, way, sector_mask
always_comb begin : p_incoming_linefill_lookup_comb
   //search_lf_result_valid = '0;
   search_lf_result_mask = '{default : '0};
   
   for(int RCTRL_NUM=0; RCTRL_NUM<= L2_NUM_RCTRL-1; RCTRL_NUM++)begin
      if(rctrl_isched_lf_done_valid[RCTRL_NUM]==1'b1) begin
         for(int ENTRY=L2_ISCHED_NUM_RB_ENTRY-1; ENTRY>=0; ENTRY--)begin
            if(rctrl_isched_rec[RCTRL_NUM].set==ring_buffer_entries[ENTRY].set)begin
               if(rctrl_isched_rec[RCTRL_NUM].way==ring_buffer_entries[ENTRY].way)begin
                  //search_lf_result_valid[RCTRL_NUM] = 1'b1;
                  search_lf_result_mask[RCTRL_NUM][ENTRY] = 1'b1;
               end
            end
         end
      end
   end
end : p_incoming_linefill_lookup_comb

generate
for(genvar RCTRL_NUM=0; RCTRL_NUM<=L2_NUM_RCTRL-1; RCTRL_NUM++)begin : g_search_lf_result_valid_comb
   assign search_lf_result_valid[RCTRL_NUM] = |search_lf_result_mask[RCTRL_NUM];
end
endgenerate



// Perform a lookup on the Ring Buffer entries for incoming write back signal based on the set, way
always_comb begin : p_incoming_wb_lookup_comb
   //search_wb_result_valid = '0;
   search_wb_result_mask = '{default : '0};
   
   for(int RCTRL_NUM=0; RCTRL_NUM<=L2_NUM_RCTRL-1; RCTRL_NUM++)begin
      if(rctrl_isched_wb_done_valid[RCTRL_NUM]==1'b1)begin
         for(int ENTRY=L2_ISCHED_NUM_RB_ENTRY-1; ENTRY>=0; ENTRY--)begin
            if(rctrl_isched_rec[RCTRL_NUM].set==ring_buffer_entries[ENTRY].set)begin
               if(rctrl_isched_rec[RCTRL_NUM].way==ring_buffer_entries[ENTRY].way)begin
                  //search_wb_result_valid[RCTRL_NUM] = 1'b1;
                  search_wb_result_mask[RCTRL_NUM][ENTRY] = 1'b1;
               end
            end
         end
      end
   end
end : p_incoming_wb_lookup_comb

generate
for(genvar RCTRL_NUM=0; RCTRL_NUM<=L2_NUM_RCTRL-1; RCTRL_NUM++)begin : g_search_wb_result_valid_comb
   assign search_wb_result_valid[RCTRL_NUM] = |search_wb_result_mask[RCTRL_NUM];
end



for (genvar ENTRY = 0; ENTRY < L2_ISCHED_INSTR_DEPTH; ENTRY++) begin
   always_comb begin : p_rb_entries_live_comb
      n_rb_entry_valid[ENTRY] = rb_entry_valid[ENTRY];
      
      if(tagctrl_isched_input_accepted && ENTRY == assign_buffer_entry) begin
         n_rb_entry_valid[ENTRY] = 1'b1;
      end
      else if (pending_readout_valid[0] && pending_readout_ready[0] && ENTRY == pending_readout_idx[0]) begin
         n_rb_entry_valid[ENTRY] = 1'b0;
      end
      else if (pending_readout_valid[1] && pending_readout_ready[1] && ENTRY == pending_readout_idx[1]) begin
         n_rb_entry_valid[ENTRY] = 1'b0;
      end
   end : p_rb_entries_live_comb
end
endgenerate



// ----------------------------------------------------------------------------
// Combine the 3 masks into a single process to optimise clock-gating
// ----------------------------------------------------------------------------
always_ff@(posedge clk or negedge resetn) begin : p_rb_entry_masks_clkdrs
   if(resetn==1'b0) begin
      rb_entry_valid <= '0;
   end
   else begin

      for(int unsigned entry_div16=0; entry_div16<=L2_ISCHED_INSTR_DEPTH/16 - 1; entry_div16++) begin
         if((tagctrl_isched_input_accepted==1'b1 && entry_div16==(assign_buffer_entry[L2_ISCHED_RB_ENTRY_BITS - 1:4])) ||  (|pending_readout_valid )) begin 
            rb_entry_valid[16*entry_div16 +: 16]         <= n_rb_entry_valid[16*entry_div16 +: 16];
         end
      end
   end
end : p_rb_entry_masks_clkdrs

// ----------------------------------------------------------------------------
// Search for the oldest entry which can execute
// ----------------------------------------------------------------------------
// Extend the rb_entry_valid mask so that the LSB is wrapped to the top of the vector
assign rb_entry_valid_sll1 = {n_rb_entry_valid[0], n_rb_entry_valid[L2_ISCHED_INSTR_DEPTH - 1:1]};
assign n_prev_oldest_buffer_entry = (prev_oldest_buffer_entry==L2_ISCHED_INSTR_DEPTH - 1)? '0 : prev_oldest_buffer_entry + 1'b1;

always_ff@(posedge clk or negedge resetn) begin : p_prev_oldest_entry_pointer_clkdrs
   if(resetn==1'b0) begin
      prev_oldest_buffer_entry <= (L2_ISCHED_INSTR_DEPTH - 1);
   end
   else begin
      // Only allow the prev_oldest pointer to advance when the execution register stage is not stalled otherwise there is the
      // potential danger that the slot currently pointed to by the execute pointer will get overwritten before it has been
      // accepted by the downstream register stage
      if(((rb_entries_busy==1'b1 || tagctrl_isched_stage1_ready==1'b0) && rb_entry_valid_sll1[prev_oldest_buffer_entry]==1'b0)) begin
         prev_oldest_buffer_entry <= n_prev_oldest_buffer_entry;
      end
   end
end : p_prev_oldest_entry_pointer_clkdrs

generate
   for (genvar RCTRL = 0; RCTRL < L2_NUM_RCTRL; RCTRL ++) begin : g_drive_rb_entry_output_rctrl_logic
      for(genvar  ENTRY=0; ENTRY<=L2_ISCHED_NUM_RB_ENTRY-1; ENTRY++) begin : g_drive_rb_entry_output_logic
         assign rb_entry_output_valid[RCTRL][ENTRY] = rb_entry_valid[ENTRY] 
                                                      && (~(pending_readout_valid[RCTRL] && pending_readout_idx[RCTRL] == ENTRY))
                                                      && (~(|ring_buffer_entries[ENTRY].linefill_waiting))  
                                                      && (~ring_buffer_entries[ENTRY].wb_waiting) 
                                                      && ring_buffer_entries[ENTRY].set[$clog2(L2_NUM_RCTRL)-1:0] == RCTRL;
      end
      assign next_output_buffer_entry_valid[RCTRL] = (|(rb_entry_output_valid[RCTRL]));
      //Instantiation of round robin arbiter.
      gpc_round_robin_index_arch1_ # (
         .width                      ( L2_ISCHED_INSTR_DEPTH           ) ,
         .hold_previous              ( 1'b0                            ) )
      i_gpc_round_robin_index_arch1  (
         .valids                     ( rb_entry_output_valid[RCTRL]    ) ,
         .previous_index             ( prev_oldest_buffer_entry        ) ,
         .next_index                 ( next_output_buffer_entry[RCTRL] ) );

      // ----------------------------------------------------------------------------
      // register entry index firt, then readout command field to reduce
      // fanout 
      // ----------------------------------------------------------------------------
      assign next_output_buffer_entry_ready[RCTRL] = (~pending_readout_valid[RCTRL]) || pending_readout_ready[RCTRL];
      always_ff@(posedge clk or negedge resetn) begin
         if (!resetn) begin
            pending_readout_valid[RCTRL] <= 1'b0;
            pending_readout_idx[RCTRL] <= '0;
         end
         else if (next_output_buffer_entry_valid[RCTRL] && next_output_buffer_entry_ready[RCTRL]) begin
            pending_readout_valid[RCTRL] <= 1'b1;
            pending_readout_idx[RCTRL] <= next_output_buffer_entry[RCTRL];
         end
         else if (pending_readout_valid[RCTRL] && pending_readout_ready[RCTRL]) begin
            pending_readout_valid[RCTRL] <= 1'b0;
         end
      end


      // ----------------------------------------------------------------------------
      // Execute
      // ----------------------------------------------------------------------------
      assign pending_readout_ready[RCTRL]                 = execute_instruction_ready[RCTRL];
      assign execute_instruction_rec[RCTRL].instruction   = ring_buffer_entries[pending_readout_idx[RCTRL]].instruction     ;
      assign execute_instruction_rec[RCTRL].axid          = ring_buffer_entries[pending_readout_idx[RCTRL]].axid            ;
      assign execute_instruction_rec[RCTRL].set           = ring_buffer_entries[pending_readout_idx[RCTRL]].set             ;
      assign execute_instruction_rec[RCTRL].way           = ring_buffer_entries[pending_readout_idx[RCTRL]].way             ;
      assign execute_instruction_rec[RCTRL].sector_mask   = ring_buffer_entries[pending_readout_idx[RCTRL]].sector_mask     ;
      assign execute_instruction_rec[RCTRL].start_beat    = ring_buffer_entries[pending_readout_idx[RCTRL]].start_beat      ;
      assign execute_instruction_rec[RCTRL].blen          = ring_buffer_entries[pending_readout_idx[RCTRL]].blen            ;
      assign execute_instruction_rec[RCTRL].iwdb_index    = ring_buffer_entries[pending_readout_idx[RCTRL]].iwdb_index      ;
      assign execute_instruction_rec[RCTRL].check_partial = ring_buffer_entries[pending_readout_idx[RCTRL]].check_partial   ;

      gpc_gfx_timing_buffer_ #           (
         .BUFFER_TYPE                    ( GPC_GFX_TIMING_BUFFER_MSTL             ) , 
         .WIDTH                          ( $bits(isched_xbar_record_type          ) ))
      i_gpc_gfx_timing_buffer_exec_instr (
         .clk                            ( clk                                    ) ,
         .resetn                         ( resetn                                 ) ,
         .tbuff_in_valid                 ( pending_readout_valid [RCTRL] ) ,
         .tbuff_in_enable                ( execute_instruction_ready      [RCTRL] ) ,
         .tbuff_in_data                  ( execute_instruction_rec        [RCTRL] ) ,
         .tbuff_out_valid                ( execute_instruction_tbuf_valid [RCTRL] ) ,
         .tbuff_out_enable               ( execute_instruction_tbuf_ready [RCTRL] ) ,
         .tbuff_out_data                 ( execute_instruction_tbuf_rec   [RCTRL] ) );

      assign isched_xbar_instr_valid[RCTRL]             = execute_instruction_tbuf_valid [RCTRL]   ;
      assign execute_instruction_tbuf_ready [RCTRL]     = isched_xbar_instr_ready[RCTRL]           ;
      assign isched_xbar_instr_rec[RCTRL].set           = execute_instruction_tbuf_rec[RCTRL].set         ;
      assign isched_xbar_instr_rec[RCTRL].way           = execute_instruction_tbuf_rec[RCTRL].way         ;
      assign isched_xbar_instr_rec[RCTRL].instruction   = execute_instruction_tbuf_rec[RCTRL].instruction ;
      assign isched_xbar_instr_rec[RCTRL].iwdb_index    = execute_instruction_tbuf_rec[RCTRL].iwdb_index      ;
      assign isched_xbar_instr_rec[RCTRL].axid          = execute_instruction_tbuf_rec[RCTRL].axid            ;
      assign isched_xbar_instr_rec[RCTRL].start_beat    = execute_instruction_tbuf_rec[RCTRL].start_beat      ;
      assign isched_xbar_instr_rec[RCTRL].blen          = execute_instruction_tbuf_rec[RCTRL].blen            ;
      assign isched_xbar_instr_rec[RCTRL].check_partial = execute_instruction_tbuf_rec[RCTRL].check_partial   ;
      assign isched_xbar_instr_rec[RCTRL].sector_mask   = execute_instruction_tbuf_rec[RCTRL].sector_mask ;
   end : g_drive_rb_entry_output_rctrl_logic
endgenerate

assign l2b_reqsch_sortq_full =  (pending_instruction_cnt==L2_ISCHED_NUM_RB_ENTRY) ? 1'b1 : 1'b0;
assign l2b_reqsch_sortq_stall_but_not_full = ~l2b_reqsch_sortq_full && tagctrl_isched_valid && ~tagctrl_isched_ready;

endmodule : gc_l2_bank_isched_ringbuffer
