// ---------------------------------------------------------------------------------
// Project Name  : IC_Design
// Author        : liusm
// Email         : liusm@innosilicon.com.cn
// Create On     : 2025/05/22 10:50
// Last Modified : 2025/08/04 14:10
// File Name     : gc_l2_bank_lru.sv
// Description   :
// 
// Copyright (c) 2025 Innosilicon.
// ALL RIGHTS RESERVED
// 
// ---------------------------------------------------------------------------------
// Modification History:
// Date         By              Version                 Change Description
// ---------------------------------------------------------------------------------
// 2025/05/22   liusm           1.0                     Original
// 
// ----------------------------------------------------------------------------------


module gc_l2_bank_lru
import gc_l2_bank_pkg::*;
#(parameter BANK_GROUP_NUM = 8,
  parameter BANK_GROUP_BITS = 3
)
(
      input  logic                         clk
,     input  logic                         resetn


,     input  logic                         select_en
,     input  logic   [BANK_GROUP_BITS-1:0] select_bank_group


,     output logic   [BANK_GROUP_BITS-1:0] bank_group_order0 // higher priority 
,     output logic   [BANK_GROUP_BITS-1:0] bank_group_order1 
,     output logic   [BANK_GROUP_BITS-1:0] bank_group_order2 
,     output logic   [BANK_GROUP_BITS-1:0] bank_group_order3 
,     output logic   [BANK_GROUP_BITS-1:0] bank_group_order4 
,     output logic   [BANK_GROUP_BITS-1:0] bank_group_order5 
,     output logic   [BANK_GROUP_BITS-1:0] bank_group_order6 
,     output logic   [BANK_GROUP_BITS-1:0] bank_group_order7 
);

logic [BANK_GROUP_NUM-1:0] [BANK_GROUP_BITS-1:0] bank_group_order;
logic [BANK_GROUP_NUM-1:0] bank_group_hit_mask;
logic [BANK_GROUP_BITS-1:0] hit_index;

if (BANK_GROUP_BITS == 2) begin
   assign hit_index[1] = |bank_group_hit_mask[3:2];
   assign hit_index[0] = bank_group_hit_mask[3] | bank_group_hit_mask[1];
end
if (BANK_GROUP_BITS == 3) begin
   assign hit_index = func_onehot_to_binary_8bits(bank_group_hit_mask);
end

for (genvar BG = 0; BG < BANK_GROUP_NUM/2-1; BG ++) begin
   always_ff@(posedge clk or negedge resetn) begin
      if (!resetn) begin
         bank_group_order[2*BG] <= 2*BG;
         bank_group_order[2*BG+1] <= 2*BG+1;
      end
      else if (BG >= hit_index[BANK_GROUP_BITS-1:1] && select_en) begin
         bank_group_order[2*BG] <= bank_group_order[2*(BG+1)];
         bank_group_order[2*BG+1] <= bank_group_order[2*(BG+1)+1];
      end
   end
   assign bank_group_hit_mask[2*BG] = bank_group_order[2*BG] == select_bank_group;
   assign bank_group_hit_mask[2*BG+1] = bank_group_order[2*BG+1] == select_bank_group;
end
always_ff@(posedge clk or negedge resetn) begin
   if (!resetn) begin
      bank_group_order[BANK_GROUP_NUM-1] <= BANK_GROUP_NUM-1;
      bank_group_order[BANK_GROUP_NUM-2] <= BANK_GROUP_NUM-2;
   end
   else if (select_en) begin
      bank_group_order[BANK_GROUP_NUM-1] <= select_bank_group;
      bank_group_order[BANK_GROUP_NUM-2] <= {select_bank_group[BANK_GROUP_BITS-1:1], ~select_bank_group[0]};
   end
end
assign bank_group_hit_mask[BANK_GROUP_NUM-1] =  bank_group_order[BANK_GROUP_NUM-1] == select_bank_group;
assign bank_group_hit_mask[BANK_GROUP_NUM-2] =  bank_group_order[BANK_GROUP_NUM-2] == select_bank_group;


// if the selected is the last node, doesnt change the order
// if the selected DDR bank is 



assign bank_group_order0 = bank_group_order[0];
assign bank_group_order1 = bank_group_order[1];
assign bank_group_order2 = bank_group_order[2];
assign bank_group_order3 = bank_group_order[3];
assign bank_group_order4 = bank_group_order[4];
assign bank_group_order5 = bank_group_order[5];
assign bank_group_order6 = bank_group_order[6];
assign bank_group_order7 = bank_group_order[7];




// synopsys translate_off

default clocking cb @(posedge clk);
endclocking
default disable iff(!resetn);


as__hit_onehot_check:
   assert property (select_en |-> $onehot(bank_group_hit_mask));
as__hit_index_check:
   assert property (select_en |-> bank_group_hit_mask[hit_index]);




// synopsys translate_on












endmodule
// Local Variables:
// verilog-library-directories:("./" ) 
// End:
