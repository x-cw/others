/*

 * #==========================================================================#
 * |                                                                          |
 * |  Copyright (c) 2023, Fantasy Technologies Limited and/or its         |
 * |  affiliated group companies ("Fantasy"). All rights reserved.        |
 * |  No part of this content, either material or conceptual may be copied    |
 * |  or distributed, transmitted, transcribed, stored in a retrieval system  |
 * |  or translated into any human or computer language in any form by any    |
 * |  means, electronic, mechanical manual, or otherwise, or disclosed to     |
 * |  third parties without the express written permission of Fantasy.    |
 * |                                                                          |
 * #==========================================================================#

 */
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// THIS FILE IS AUTO-GENERATED. DO NOT EDIT.
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

package pkg_gc_dfu_;
   import pkg_bif_::*;
   import pkg_cp_top::*;
   import pkg_mh_::*;
   import gc_features_pack_::*;

   typedef logic [                                 1 : 0]           t_if_spc_dfu_cp_dfu_req_operation        ;
   typedef logic [                                 1 : 0]           t_if_cp_dfu_spc_dfu_broadcast_operation  ;
   typedef logic [                                 1 : 0]           t_if_slave_dfu_spc_dfu_req_operation;
   typedef logic [                                 1 : 0]           t_if_spc_dfu_slave_dfu_broadcast_operation ;

   typedef logic [   pkg_mh_::MH_PERSISTENCE_BITS-1 : 0] t_if_spc_dfu_cp_dfu_req_persistence      ;
   typedef logic [   pkg_mh_::MH_PERSISTENCE_BITS-1 : 0] t_if_slave_dfu_spc_dfu_req_persistence   ;
   typedef logic [   pkg_mh_::MH_PERSISTENCE_BITS-1 : 0] t_if_cp_dfu_spc_dfu_broadcast_persistence;
   typedef logic [   pkg_mh_::MH_PERSISTENCE_BITS-1 : 0] t_if_spc_dfu_slave_dfu_broadcast_persistence ;
 
   typedef logic [   gc_features_pack_::MH_CTXT_PASID_WIDTH-1 : 0]  t_if_spc_dfu_cp_dfu_req_ctxt_pasid       ;
   typedef logic [   gc_features_pack_::MH_CTXT_PASID_WIDTH-1 : 0]  t_if_cp_dfu_spc_dfu_broadcast_ctxt_pasid ;
   typedef logic [   gc_features_pack_::MH_CTXT_PASID_WIDTH-1 : 0]  t_if_slave_dfu_spc_dfu_req_ctxt_pasid    ;
   typedef logic [   gc_features_pack_::MH_CTXT_PASID_WIDTH-1 : 0]  t_if_spc_dfu_slave_dfu_broadcast_ctxt_pasid ;
   
   typedef logic [   pkg_mh_::VADDR_BIF_WIDTH-1: pkg_mh_::VADDR_LOW]      t_if_spc_dfu_cp_dfu_req_vaddress         ;
   typedef logic [   pkg_mh_::VADDR_BIF_WIDTH-1: pkg_mh_::VADDR_LOW]      t_if_slave_dfu_spc_dfu_req_vaddress      ;
   

   typedef struct packed {
      logic [1:0]                                                      dfu_operation;
      logic [pkg_mh_::MH_PERSISTENCE_BITS-1:0]                         persistence;
      logic [gc_features_pack_::MH_CTXT_PASID_WIDTH - 1:0]            ctxt_pasid;
      logic                                                            l2_policy;
      logic [pkg_mh_::VADDR_BIF_WIDTH-1: pkg_mh_::VADDR_LOW]           vaddress;
      logic                                                            valid;
   } dfu_hot_table_rec_type;

   typedef struct packed {
      logic [1:0]                                                       dfu_operation;
      logic [pkg_mh_::MH_PERSISTENCE_BITS-1:0]                          persistence;
      logic [gc_features_pack_::MH_CTXT_PASID_WIDTH- 1:0]              ctxt_pasid;
      logic                                                             l2_policy;
      logic [pkg_mh_::VADDR_BIF_WIDTH-1: pkg_mh_::VADDR_LOW]            vaddress;
   } dfu_operation_rec_type;


   localparam int CP_DFU_POSN  =   8;
   localparam     BROADCAST_TBUFF_LENGTH  = MH_PERSISTENCE_BITS+MH_CTXT_PASID_WIDTH+ 2 + 1;
   localparam     REQUEST_TBUFF_LENGTH  = MH_PERSISTENCE_BITS+MH_CTXT_PASID_WIDTH+ 2 + 1 + VADDR_BIF_WIDTH - VADDR_LOW;

   
endpackage
