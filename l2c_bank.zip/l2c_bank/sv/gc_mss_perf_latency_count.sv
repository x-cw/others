// +FHDR----------------------------------------------------------------------------
// Copyright (c) 2025, Innosilicon, Inc. Confidential Proprietary
// PROJECT NAME  : xxx
// DEPARTMENT    : Digtal Frontend GPU MSS
// AUTHOR        : luoml01
// EMAIL         : luoml01@innosilicon.com.cn
// CREATE ON     : 2025/03/11 20:57
// FILE NAME     : gc_mss_perf_latency_count.sv
// DESCRIPTION   :          
//         
// Copyright (c) 2025 Innosilicon.
// ALL RIGHTS RESERVED
// 
// ---------------------------------------------------------------------------------
// Modification History:
// Date         By              Version                 Change Description
// ---------------------------------------------------------------------------------
// 2025/03/11   luoml01         1.0                     Original
// 
// -FHDR----------------------------------------------------------------------------


module gc_mss_perf_latency_count
#(
   parameter ID_WIDTH = 8,
   parameter LATENCY_WIDTH = 10

)
(
input logic clk,
input logic resetn,


input logic req_valid,
input logic req_ready,
input logic [ID_WIDTH-1:0] req_id,


input logic rtn_valid,
input logic rtn_ready,
input logic [ID_WIDTH-1:0] rtn_id,

output logic [LATENCY_WIDTH-1:0] gc_cr_avg_latency,
output logic [LATENCY_WIDTH-1:0] gc_cr_min_latency,
output logic [LATENCY_WIDTH+2-1:0] gc_cr_max_latency
);

   logic latency_valid;
   logic latency_ready;
   logic [LATENCY_WIDTH-1:0] latency_10bit_value;
   logic measuring_transaction;
   logic [ID_WIDTH-1:0] measuring_id;
   logic [LATENCY_WIDTH+2-1:0] latency_counter;

   logic [LATENCY_WIDTH+2-1:0] avg_latency;
   logic [LATENCY_WIDTH-1:0] min_latency;
   logic [LATENCY_WIDTH+2-1:0] max_latency;
   logic [LATENCY_WIDTH+3-1:0] sum_latency;

   logic roundup;

   // Latency Counter
   always_ff@(posedge clk or negedge resetn) begin : p_latency_measurement_clkdrs
      if(resetn==1'b0) begin
         measuring_transaction <= 1'b0;
         measuring_id          <= '0;
         latency_valid         <= 1'b0;
         latency_counter       <= '0;
      end
      else begin
         if(measuring_transaction==1'b1) begin
            if((&(latency_counter))==1'b0) begin // don't allow the counter to overflow
               latency_counter <= latency_counter + 1;
            end
            if((rtn_valid==1'b1 && rtn_ready==1'b1 &&  rtn_id==measuring_id)) begin
               // The transaction we were monitoring has now returned therefore output the counter value
               measuring_transaction <= 1'b0;
               latency_valid <= 1'b1;
            end
         end
         else if(latency_valid==1'b1) begin
            // Wait for measured value to be accepted before beginning another latency measurement
            latency_valid <= 1'b0;
         end
         else if(req_valid==1'b1 && req_ready==1'b1) begin
            measuring_transaction <= 1'b1;
            measuring_id <= req_id;
            latency_counter <= '0;
         end
      end
   end : p_latency_measurement_clkdrs



   assign latency_10bit_value = latency_counter[11:10]==2'b00 ? latency_counter[9:0] : '1;


   assign roundup = ((latency_counter[0] ^ avg_latency[0])==1'b1 && latency_counter[11:1]>avg_latency[11:1]) ? 1'b1 : 1'b0;
   assign sum_latency = (13)'(avg_latency) + latency_counter + roundup;

   always_ff@(posedge clk or negedge resetn) begin : p_rolling_average_registers_clkdrs
      if(resetn==1'b0) begin
         avg_latency <= '0;
         min_latency <= '1;
         max_latency <= '0;
      end
      else begin
         if(latency_valid==1'b1) begin
            // Right-shift the results by 1-bit to divide the result by 2 and create a rolling average
            avg_latency <= sum_latency[12:1];
            if(latency_10bit_value<min_latency) begin // Min latency should not exceed a 10-bit value
               min_latency <= latency_10bit_value;
            end
            if(latency_counter>max_latency) begin
               max_latency <= latency_counter;
            end
         end
      end
   end : p_rolling_average_registers_clkdrs

   // The average latency values are 10-bit wide in the Status register, so the 12-bit counter value must be limited to 1023
   assign gc_cr_avg_latency = avg_latency[11:10]==2'b00 ? (avg_latency[9:0]) : '1;
   assign gc_cr_min_latency = min_latency;

   assign gc_cr_max_latency = max_latency;

   
endmodule
// Local Variables:
// verilog-library-flags:("-y ./ -y ../")
// verilog-auto-inst-param-value:t
// End:
