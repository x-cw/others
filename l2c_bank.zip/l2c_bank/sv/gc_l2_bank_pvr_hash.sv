// ---------------------------------------------------------------------------------
// Project Name  : IC_Design
// Author        : liusm
// Email         : liusm@innosilicon.com.cn
// Create On     : 2025/09/04 14:00
// Last Modified : 2025/09/18 18:02
// File Name     : gc_l2_bank_pvr_hash.sv
// Description   :
// 
// Copyright (c) 2025 Innosilicon.
// ALL RIGHTS RESERVED
// 
// ---------------------------------------------------------------------------------
// Modification History:
// Date         By              Version                 Change Description
// ---------------------------------------------------------------------------------
// 2025/09/04   liusm           1.0                     Original
// 
// ----------------------------------------------------------------------------------


module gc_l2_bank_pvr_hash
#(
   parameter BANK_BITS = 4,                
   parameter ROW_BITS  = 17
)(
    input   wire    [4:0]                reg_sdram_row_size       , //the row width of the sdram
    input   wire                         reg_ddrc_addrmap_hash_en ,
    input   wire    [ROW_BITS-1:0]       am_row                   ,
    input   wire    [BANK_BITS-1:0]      am_ba                    ,
    output  wire    [BANK_BITS-1:0]      hash_bank 
);


function automatic logic [3:0] lut4 (input [3:0] x);
   logic [3:0] result;
    case( x )
         4'h0   :  result = 4'h0;
         4'h1   :  result = 4'hc;
         4'h2   :  result = 4'h9;
         4'h3   :  result = 4'h5;
         4'h4   :  result = 4'hd;
         4'h5   :  result = 4'h4;
         4'h6   :  result = 4'he;
         4'h7   :  result = 4'h7;
         4'h8   :  result = 4'hb;
         4'h9   :  result = 4'h2;
         4'ha   :  result = 4'h8;
         4'hb   :  result = 4'h1;
         4'hc   :  result = 4'hf;
         4'hd   :  result = 4'h3;
         4'he   :  result = 4'h6;
         4'hf   :  result = 4'ha;
         default :  result =  4'h0;
    endcase
    return result;
endfunction

function automatic logic [4:0] lut5 (input logic [4:0] x);
   logic [4:0] result;
   case( x )
      5'h0   :  result = 5'h00;
      5'h1   :  result = 5'h03;
      5'h2   :  result = 5'h12;
      5'h3   :  result = 5'h18;
      5'h4   :  result = 5'h07;
      5'h5   :  result = 5'h06;
      5'h6   :  result = 5'h0e;
      5'h7   :  result = 5'h01;
      5'h8   :  result = 5'h04;
      5'h9   :  result = 5'h1d;
      5'ha   :  result = 5'h14;
      5'hb   :  result = 5'h0c;
      5'hc   :  result = 5'h1a;
      5'hd   :  result = 5'h0f;
      5'he   :  result = 5'h08;
      5'hf   :  result = 5'h0a;
      5'h10  :  result = 5'h0b;
      5'h11  :  result = 5'h19;
      5'h12  :  result = 5'h1e;
      5'h13  :  result = 5'h17;
      5'h14  :  result = 5'h1f;
      5'h15  :  result = 5'h10;
      5'h16  :  result = 5'h02;
      5'h17  :  result = 5'h11;
      5'h18  :  result = 5'h16;
      5'h19  :  result = 5'h0d;
      5'h1a  :  result = 5'h1b;
      5'h1b  :  result = 5'h15;
      5'h1c  :  result = 5'h13;
      5'h1d  :  result = 5'h09;
      5'h1e  :  result = 5'h1c;
      5'h1f  :  result = 5'h05;
      default :  result =  5'h00;
   endcase
   return result;
endfunction

function automatic logic [4:0] rotate5by1(input logic [4:0] x);
   return {x[0], x[4:1]};
endfunction 
function automatic logic [4:0] rotate5by2(input logic [4:0] x);
   return {x[1:0], x[4:2]};
endfunction
function automatic logic [4:0] rotate5by3(input logic [4:0] x);
   return {x[2:0], x[4:3]};
endfunction

function automatic logic [3:0] rotate4by1(input logic [3:0] x);
   return {x[0], x[3:1]};
endfunction 
function automatic logic [3:0] rotate4by2(input logic [3:0] x);
   return {x[1:0], x[3:2]};
endfunction
function automatic logic [3:0] rotate4by3(input logic [3:0] x);
   return {x[2:0], x[3:3]};
endfunction

function automatic logic [4-1:0] hash13_4b (input logic [12:0] x);
   logic [3:0] result;
   result[0] = x[1] ^ x[5] ^ x[8] ^ x[9] ^ x[11];
   result[1] = x[2] ^ x[3] ^ x[6] ^ x[9] ^ x[12];
   result[2] = x[0] ^ x[4] ^ x[7] ^ x[10];
   result[3] = x[1] ^ x[5] ^ x[8] ^ x[11];
   return result;
endfunction

function automatic logic [3:0] hash14_4b (input logic [13:0] x);
   logic [3:0] result;
   result[0] = x[2] ^ x[5] ^ x[8] ^ x[13];
   result[1] = x[0] ^ x[4] ^ x[9] ^ x[12];
   result[2] = x[3] ^ x[7] ^ x[11];
   result[3] = x[1] ^ x[6] ^ x[10];
   return result;
endfunction


function automatic logic [3:0] hash15_4b (input logic [14:0] x);
   logic [3:0] result;
   result[0] = x[2] ^ x[4] ^ x[8] ^ x[11];
   result[1] = x[0] ^ x[5] ^ x[9] ^ x[14];
   result[2] = x[3] ^ x[6] ^ x[10] ^ x[13];
   result[3] = x[1] ^ x[7] ^ x[12];
   return result;
endfunction

function automatic logic [3:0] hash16_4b (input logic [15:0] x);
   logic [3:0] result;
   result[0] = x[0] ^ x[4] ^ x[9] ^ x[12];
   result[1] = x[1] ^ x[5] ^ x[8] ^ x[13];
   result[2] = x[3] ^ x[7] ^ x[11] ^ x[14];
   result[3] = x[2] ^ x[6] ^ x[10] ^ x[15];
   return result;
endfunction

function automatic logic [3:0] hash17_4b (input logic [16:0] x);
   logic [3:0] result;
   result[0] = x[1] ^ x[5] ^ x[7] ^ x[13] ^ x[15];
   result[1] = x[0] ^ x[4] ^ x[9] ^ x[12];
   result[2] = x[2] ^ x[6] ^ x[10] ^ x[14];
   result[3] = x[3] ^ x[8] ^ x[11] ^ x[16];
   return result;
endfunction
logic [12:0]  hash4_13_data;
logic [12:0]  hash4_13_swap;


assign hash4_13_data[12:9]= lut4(am_row[12:9]);
assign hash4_13_data[8:5] = lut4(am_row[8:5]);
assign hash4_13_data[4:0] = lut5(am_row[4:0]);

assign hash4_13_swap = {hash4_13_data[12:9], rotate4by1(hash4_13_data[8:5]), rotate5by2( hash4_13_data[4:0])};





logic [13:0]  hash4_14_data;
logic [13:0]  hash4_14_swap;

assign  hash4_14_data[13:10] = lut4(am_row[13:10]);
assign  hash4_14_data[9:5 ]  = lut5(am_row[9:5])  ;
assign  hash4_14_data[4:0]   = lut5(am_row[4:0])  ;
assign hash4_14_swap = {hash4_14_data[13:10], rotate5by1(hash4_14_data[9:5 ]), rotate5by2(hash4_14_data[4:0])};


logic [14:0]  hash4_15_data;
logic [14:0]  hash4_15_swap;

assign  hash4_15_data[14:10] = lut5(am_row[14:10]);
assign  hash4_15_data[9:5 ]  = lut5(am_row[9:5])  ;
assign  hash4_15_data[4:0]   = lut5(am_row[4:0])  ;
assign hash4_15_swap = {hash4_15_data[14:10], rotate5by1(hash4_15_data[9:5 ]), rotate5by2(hash4_15_data[4:0])};


logic [15:0]  hash4_16_data;
logic [15:0]  hash4_16_swap;

assign  hash4_16_data[15:12] = lut4(am_row[15:12]);
assign  hash4_16_data[11:8]  = lut4(am_row[11:8]);
assign  hash4_16_data[7:4 ]  = lut4(am_row[7:4])  ;
assign  hash4_16_data[3:0]   = lut4(am_row[3:0])  ;
assign hash4_16_swap = {hash4_16_data[15:12], rotate4by1(hash4_16_data[11:8 ]), rotate4by2(hash4_16_data[7:4]), rotate4by3(hash4_16_data[3:0])};

logic [16:0]  hash4_17_data;
logic [16:0]  hash4_17_swap;

assign  hash4_17_data[13+:4] = lut4(am_row[13+:4]);
assign  hash4_17_data[9+:4]  = lut4(am_row[9+:4]);
assign  hash4_17_data[5+:4]  = lut4(am_row[5+:4])  ;
assign  hash4_17_data[0+:5]  = lut5(am_row[0+:5])  ;
assign hash4_17_swap = {hash4_17_data[13+:4], rotate4by1(hash4_17_data[9+:4]), rotate4by2(hash4_17_data[5+:4]), rotate5by3(hash4_17_data[0+:5])};


function automatic logic [1:0] hash13_to_2 (input logic [12:0] x);
   logic [1:0] result;
   logic [12:0] hash_swap;
   
   hash_swap[12:9] = lut4(x[12:9]);
   hash_swap[8:5]  = rotate4by1(lut4(x[8:5]));
   hash_swap[4:0]  = rotate5by2(lut5(x[4:0]));

   result[0] = hash_swap[1] ^ hash_swap[2] ^ hash_swap[4] ^ hash_swap[7] ^ hash_swap[8] ^ hash_swap[9] ^ hash_swap[11];
   result[1] = hash_swap[0] ^ hash_swap[3] ^ hash_swap[5] ^ hash_swap[6] ^ hash_swap[10] ^ hash_swap[12];
   return result;
endfunction

function automatic logic [1:0] hash14_to_2 (input logic [13:0] x);
   logic [1:0] result;
   logic [13:0] hash_swap;
   
   hash_swap[13:10] = lut4(x[13:10]);
   hash_swap[9:5]   = rotate5by1(lut5(x[9:5]));
   hash_swap[4:0]   = rotate5by2(lut5(x[4:0]));

   result[0] = hash_swap[2] ^ hash_swap[3] ^ hash_swap[5] ^ hash_swap[7] ^ hash_swap[8] ^ hash_swap[11] ^ hash_swap[13];
   result[1] = hash_swap[0] ^ hash_swap[1] ^ hash_swap[4] ^ hash_swap[6] ^ hash_swap[9] ^ hash_swap[10] ^ hash_swap[12];
   return result;
endfunction


function automatic logic [1:0] hash15_to_2 (input logic [14:0] x);
   logic [1:0] result;
   logic [14:0] hash_swap;
   
   hash_swap[10+:5] = lut5(x[10+:5]);
   hash_swap[5+:5]  = rotate5by1(lut5(x[5+:5]));
   hash_swap[0+:5]  = rotate5by2(lut5(x[0+:5]));
   
   result [0] = hash_swap[2] ^ hash_swap[3] ^ hash_swap[4] ^ hash_swap[8] ^ hash_swap[6] ^ hash_swap[10] ^ hash_swap[11] ^ hash_swap[13];
   result [1] = hash_swap[0] ^ hash_swap[1] ^ hash_swap[5] ^ hash_swap[7] ^ hash_swap[9] ^ hash_swap[12] ^ hash_swap[14];
   return result;
endfunction


function automatic logic [1:0] hash16_to_2 (input logic [15:0] x);
   logic [1:0] result;
   logic [15:0] hash_swap;
   hash_swap[12+:4] = lut4       ( x[12+:4]      );
   hash_swap[8+:4]  = rotate4by1 ( lut4(x[8+:4]) );
   hash_swap[4+:4]  = rotate4by2 ( lut4(x[4+:4]) );
   hash_swap[0+:4]  = rotate4by3 ( lut4(x[0+:4]) );
   result[0] = hash_swap[0] ^ hash_swap[3] ^ hash_swap[4] ^ hash_swap[7] ^ hash_swap[9] ^ hash_swap[11] ^ hash_swap[12] ^ hash_swap[14];
   result[1] = hash_swap[1] ^ hash_swap[2] ^ hash_swap[5] ^ hash_swap[6] ^ hash_swap[8] ^ hash_swap[10] ^ hash_swap[13] ^ hash_swap[15];
   return result;
endfunction



function automatic logic [1:0] hash17_to_2 (input logic [16:0] x);
   logic [1:0] result;
   logic [16:0] hash_swap;
   hash_swap[13+:4] = lut4(x[13+:4]);
   hash_swap[9+:4]  = rotate4by1(lut4(x[9+:4]));
   hash_swap[5+:4]  = rotate4by2(lut4(x[5+:4]));
   hash_swap[0+:5]  = rotate5by3(lut5(x[0+:5]));
   result[0] = hash_swap[1] ^ hash_swap[2] ^ hash_swap[5] ^ hash_swap[6] ^ hash_swap[7] ^ hash_swap[10] ^ hash_swap[13] ^ hash_swap[14] ^ hash_swap[15];
   result[1] = hash_swap[0] ^ hash_swap[3] ^ hash_swap[4] ^ hash_swap[8] ^ hash_swap[9] ^ hash_swap[11] ^ hash_swap[12] ^ hash_swap[16];
   return result;
endfunction

function automatic logic [1:0] hash18_to_2 (input logic [17:0] x);
   logic [1:0] result;
   logic [17:0] hash_swap;
   hash_swap[14+:4] = lut4(x[14+:4]);
   hash_swap[10+:4] = rotate4by1(lut4(x[10+:4]));
   hash_swap[5+:5]  = rotate5by2(lut5(x[5+:5]));
   hash_swap[0+:5]  = rotate5by3(lut5(x[0+:5]));
   result[0] = hash_swap[0] ^ hash_swap[1] ^ hash_swap[4] ^ hash_swap[6] ^ hash_swap[9] ^ hash_swap[11] ^ hash_swap[12] ^ hash_swap[13] ^ hash_swap[14];
   result[1] = hash_swap[2] ^ hash_swap[3] ^ hash_swap[5] ^ hash_swap[7] ^ hash_swap[8] ^ hash_swap[10] ^ hash_swap[15] ^ hash_swap[16] ^ hash_swap[17];
   return result;
endfunction

function automatic logic [1:0] hash19_to_2 (input logic [18:0] x);
   logic [1:0] result;
   logic [18:0] hash_swap;
   hash_swap[15+:4] = lut4(x[15+:4]);
   hash_swap[10+:5] = rotate5by1(lut5(x[10+:5]));
   hash_swap[5+:5]  = rotate5by2(lut5(x[5+:5]));
   hash_swap[0+:5]  = rotate5by3(lut5(x[0+:5]));
   result[0] = hash_swap[2] ^ hash_swap[3] ^ hash_swap[4] ^ hash_swap[5] ^ hash_swap[6] ^ hash_swap[10] ^ hash_swap[12] ^ hash_swap[13] ^ hash_swap[14] ^ hash_swap[18];
   result[1] = hash_swap[0] ^ hash_swap[1] ^ hash_swap[7] ^ hash_swap[8] ^ hash_swap[9] ^ hash_swap[11] ^ hash_swap[15] ^ hash_swap[16] ^ hash_swap[17];
   return result;
endfunction

logic [3:0] hash_bank_bg;
logic [3:0] hash4_bank;
always_comb begin
   case (reg_sdram_row_size)
      5'd13: begin 
         hash_bank_bg[1:0] = hash13_to_2(am_row[12:0]);
         hash_bank_bg[3:2] = hash15_to_2({am_row[12:0], hash_bank_bg[1:0]});
      end
      5'd14: begin 
         hash_bank_bg[1:0] = hash14_to_2(am_row[13:0]);
         hash_bank_bg[3:2] = hash16_to_2({am_row[13:0], hash_bank_bg[1:0]});
      end
      5'd15: begin 
         hash_bank_bg[1:0] = hash15_to_2(am_row[14:0]);
         hash_bank_bg[3:2] = hash17_to_2({am_row[14:0], hash_bank_bg[1:0]});
      end
      5'd16: begin 
         hash_bank_bg[1:0] = hash16_to_2(am_row[15:0]);
         hash_bank_bg[3:2] = hash18_to_2({am_row[15:0], hash_bank_bg[1:0]});
      end
      5'd17: begin 
         hash_bank_bg[1:0] = hash17_to_2(am_row[16:0]);
         hash_bank_bg[3:2] = hash19_to_2({am_row[16:0], hash_bank_bg[1:0]});
      end
      default: begin
         hash_bank_bg[1:0] = hash13_to_2(am_row[12:0]);
         hash_bank_bg[3:2] = hash15_to_2({am_row[12:0], hash_bank_bg[1:0]});
      end
   endcase
end




always_comb begin
   case (reg_sdram_row_size)
        5'd13  : hash4_bank = hash13_4b(hash4_13_swap);
        5'd14  : hash4_bank = hash14_4b(hash4_14_swap);
        5'd15  : hash4_bank = hash15_4b(hash4_15_swap);
        5'd16  : hash4_bank = hash16_4b(hash4_16_swap);
        5'd17  : hash4_bank = hash17_4b(hash4_17_swap);
        default: hash4_bank = hash13_4b(hash4_13_swap);
   endcase
end


assign hash_bank = reg_ddrc_addrmap_hash_en ? hash_bank_bg ^ am_ba : hash4_bank ^ am_ba;



endmodule
// Local Variables:
// verilog-library-directories:("./" ) 
// End:
