/*

 * #==========================================================================#
 * |                                                                          |
 * |  Copyright (c) 2023, Fantasy Technologies Limited and/or its         |
 * |  affiliated group companies ("Fantasy"). All rights reserved.        |
 * |  No part of this content, either material or conceptual may be copied    |
 * |  or distributed, transmitted, transcribed, stored in a retrieval system  |
 * |  or translated into any human or computer language in any form by any    |
 * |  means, electronic, mechanical manual, or otherwise, or disclosed to     |
 * |  third parties without the express written permission of Fantasy.    |
 * |                                                                          |
 * #==========================================================================#

 */

// ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////-
// entity name: gpc_gfx_rpfifo_byp
// purpose: This fifo will bypass the input straight through to the output when the fifo is empty, resulting in a combinational path through the block
//          The data is not reset
// ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////-



module gpc_gfx_rpfifo_byp_
#(
      // Default values are required for Formality corediff
      parameter int                                      w                                                            = 1              ,    // width of fifo
      parameter int                                      d                                                            = 2              ,    // depth of fifo
      parameter int                                      registered_enable                                            = 1                   // when zero allows a write when FIFO is already full but a read is happening NB This infers a combinatorial path from the downstream enable to the upstream enable 
)
(
      input    logic                                                        clk                                     ,
      input    logic                                                        resetn                                  ,
      input    logic                                                        fifo_in_valid                           ,
      output   logic                                                        fifo_in_enable                          ,
      input    logic [ w - 1 : 0 ]                                          fifo_in_data                            ,
      output   logic                                                        fifo_out_valid                          ,
      input    logic                                                        fifo_out_enable                         ,
      output   logic [ w - 1 : 0 ]                                          fifo_out_data                             
);

   import gpc_gfx_std_func_pack_::*;

   localparam int                                           L2D                                      = $clog2 ( d )                  ;
   typedef logic [ 0 : d - 1 ] [ w - 1 : 0 ] nreg_array ;

   logic                                         fifo_in_enable_l                        ;
   nreg_array                                    nxt_regarray                            ;

   logic [ L2D - 1 : 0 ]                         write_count                             ;
   logic [ L2D - 1 : 0 ]                         read_count                              ;
   logic                                         fifo_full                               ;
   logic                                         fifo_empty                              ;
   logic                                         fifo_push_cond                          ;
   logic                                         fifo_pop_cond                           ;

   // //////////////////////////////////////////////////////////////////////////// 
   // generate register and mux array 
   // ////////////////////////////////////////////////////////////////////////////  

   assign fifo_pop_cond = fifo_out_enable & ~ fifo_empty ;    // COV:tag10
   assign fifo_push_cond = fifo_in_valid & fifo_in_enable_l & ~ ( fifo_out_enable & fifo_empty ) ;    // COV:tag1

   always_ff @(posedge clk or negedge resetn) begin : p_fifo_ptrs
      logic [ $left(write_count) : $right(write_count) ] write_count_v                           ;
      logic [ $left(read_count) : $right(read_count) ] read_count_v                            ;
      if ( resetn == 1'b0 ) begin
         read_count <= '0  ;
         write_count <= '0  ;
         fifo_empty <= 1'b1 ;
         fifo_full <= 1'b0 ;
      end else begin


         if ( fifo_push_cond == 1'b1 ) begin
            if ( write_count == d - 1 ) begin
               write_count_v = '0  ;
            end else begin
               write_count_v = write_count + 1 ;
            end
         end else begin
            write_count_v = write_count ;
         end
         if ( fifo_pop_cond == 1'b1 ) begin
            if ( read_count == d - 1 ) begin
               read_count_v = '0  ;
            end else begin
               read_count_v = read_count + 1 ;
            end
         end else begin
            read_count_v = read_count ;
         end
         if ( read_count_v == write_count_v ) begin
            if ( fifo_full == 1'b1 ) begin
               if ( fifo_pop_cond == 1'b1 & fifo_push_cond == 1'b0 ) begin    // COV:tagDepth1_1
                  fifo_full <= 1'b0 ;    // COV:tag0
               end
            end else if ( fifo_empty == 1'b1 ) begin
               if ( fifo_push_cond == 1'b1 & fifo_pop_cond == 1'b0 ) begin    // COV:tagDepth1_2
                  fifo_empty <= 1'b0 ;    // COV:tag0
               end
            end else if ( fifo_push_cond == 1'b1 ) begin
               fifo_full <= 1'b1 ;    // COV:tag2
            end else begin    // fifo_pop_cond = '1'
               fifo_empty <= 1'b1 ;
            end
         end else begin
            fifo_empty <= 1'b0 ;
            fifo_full <= 1'b0 ;
         end
         read_count <= read_count_v ;
         write_count <= write_count_v ;
      end
   end // p_fifo_ptrs

   always_ff @(posedge clk) begin : p_fifo_data
      begin
         if ( fifo_push_cond == 1'b1 ) begin
            nxt_regarray [ write_count ] <= fifo_in_data ;
         end
      end
   end // p_fifo_data

   assign fifo_out_data = fifo_empty == 1'b0 ? nxt_regarray [ read_count ] : fifo_in_data  ; 
   
   assign fifo_out_valid = ~ ( fifo_empty ) | fifo_in_valid ;

   if ( registered_enable == 1 ) begin : g_registered_enable

      assign fifo_in_enable_l = ~ fifo_full ;

   end // g_registered_enable

   // upstream enable is based on the contents of the FIFO and the downstream enable ie whether the FIFO is being read on this cycle
   if ( registered_enable == 0 ) begin : g_combinatorial_enable

      assign fifo_in_enable_l = ~ fifo_full | fifo_out_enable ;    // COV:tag4

   end // g_combinatorial_enable

   assign fifo_in_enable = fifo_in_enable_l ;
   
endmodule // gpc_gfx_rpfifo_byp



