/*

 * #==========================================================================#
 * |                                                                          |
 * |  Copyright (c) 2022, Fantasy Technologies Limited and/or its         |
 * |  affiliated group companies ("Fantasy"). All rights reserved.        |
 * |  No part of this content, either material or conceptual may be copied    |
 * |  or distributed, transmitted, transcribed, stored in a retrieval system  |
 * |  or translated into any human or computer language in any form by any    |
 * |  means, electronic, mechanical manual, or otherwise, or disclosed to     |
 * |  third parties without the express written permission of Fantasy.    |
 * |                                                                          |
 * #==========================================================================#

 */

// ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////-
// entity name: gpc_gfx_rpfifo_cnt
// low power architecture
// array organized by rows, the size of each row depends on the depth of the FIFO
// read and write are done using pointers
// ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////-



      // NB This infers a combinatorial path from the downstream enable to the upstream enable


module gpc_gfx_rpfifo_cnt_
#(
      parameter int                                      w                                                            = 10             ,    // width of fifo
      parameter int                                      d                                                            = 64             ,    // depth of fifo
      parameter int                                      l2d                                                          = 2              ,    // number of bits required for depth
      parameter int                                      registered_enable                                            = 1              ,    // when zero allows a write when FIFO is already full but a read is happening
      parameter int                                      count_free_space                                             = 0              ,    // when zero counts the used entries, otherwise count is available/free space
      parameter int                                      clkgate_sharing                                              = 1                   // if 1 the register on the same row in the array share the same clock gating cells. This allows a reduction of the area and usually a saving of the power if the toggle rate on the input data is low (e.g. <20%). 
)
(
      input    logic                                                        clk                                     ,
      input    logic                                                        resetn                                  ,
      input    logic                                                        fifo_in_valid                           ,
      output   logic                                                        fifo_in_enable                          ,
      input    logic [ w - 1 : 0 ]                                          fifo_in_data                            ,
      output   logic                                                        fifo_out_valid                          ,
      input    logic                                                        fifo_out_enable                         ,
      output   logic [ w - 1 : 0 ]                                          fifo_out_data                           ,
      output   logic [ l2d : 0 ]                                            count                                     
);


   // pragma coverage off
   // max: returns the larger of two naturals
   function automatic int max;
   input int                                           x, y ;
   begin
      if ( x > y ) begin    // COV:tag0
         return x ;    // COV:tag0
      end else begin
         return y ;    // COV:tag0
      end
   end
   endfunction

   // get_row_depth:
   // the row depth increases as the fifo depth increases. The values in this function are found heuristically with the aim of
   // reducing the power consumption when the toggle rate is 10% on the input data.
   function automatic int get_row_depth;
   input int                                           d, w ;
   begin
      if ( ( d <= 24 & w <= 32 ) | ( d <= 48 & w > 32 ) ) begin    // COV:tag1
         return 1 ;    // COV:tag0
      end
      if ( d <= 128 ) begin    // COV:tag0
         return 2 ;    // COV:tag0
      end
      if ( d <= 256 ) begin    // COV:tag0
         return 3 ;    // COV:tag0
      end
      if ( d <= 512 ) begin    // COV:tag0
         return 4 ;    // COV:tag0
      end
      return 5 ;    // COV:tag0
   end
   endfunction
   // pragma coverage on

   localparam int                                           ROW_DEPTH                                = get_row_depth ( d , w )       ;
   localparam int                                           ROWS                                     = ( d - 2 ) / ROW_DEPTH + 1     ;
   localparam int                                           LAST_ROW_DEPTH                           = d - 1 - ( ROWS - 1 ) * ROW_DEPTH;    // the last row can have a lower depth

   localparam int                                           LOG2ROW_DEPTH                            = max ( $clog2 ( ROW_DEPTH ) , 1 );
   localparam int                                           LOG2ROWS                                 = max ( $clog2 ( ROWS ) , 1 )   ;

   localparam logic [ LOG2ROWS - 1 : 0 ]                    MAX_ROW_PTR                              = ROWS - 1                      ;
   localparam logic [ LOG2ROW_DEPTH - 1 : 0 ]               ZERO_ROW_COUNTER                         = 0                             ;
   localparam logic [ LOG2ROW_DEPTH - 1 : 0 ]               MAX_ROW_COUNTER                          = ROW_DEPTH - 1                 ;
   localparam logic [ LOG2ROW_DEPTH - 1 : 0 ]               MAX_LAST_ROW_COUNTER                     = LAST_ROW_DEPTH - 1            ;

//   localparam logic [ l2d : 0 ]                             MAXSPACE                                 = d                             ;

   typedef logic [ 0 : ROW_DEPTH - 1 ] [ w - 1 : 0 ] row_type ;
   typedef row_type [ 0 : ROWS - 1 ] array_type ;
   typedef logic [ 0 : d - 2 ] [ w - 1 : 0 ] array1d_type ;

   array_type                                    fifo_array                              ;
   array1d_type                                  fifo_array1d                            ;

   logic                                         fifo_internal_ein                       ;
   logic                                         fifo_internal_vin                       ;
   logic                                         fifo_internal_eout                      ;

   logic [ w - 1 : 0 ]                           fifo_out_data_l                         ;

// Internal row counters
// these counters start from 0 and go to ROW_DEPTH-1. If row_read_counter is N then N entries are already read from the present
// row
   logic [ LOG2ROW_DEPTH - 1 : 0 ]               row_read_counter                        ;
   logic [ LOG2ROW_DEPTH - 1 : 0 ]               row_write_counter                       ;
   logic [ LOG2ROW_DEPTH - 1 : 0 ]               n_row_read_counter                      ;
   logic [ LOG2ROW_DEPTH - 1 : 0 ]               n_row_write_counter                     ;

// Pointers to locations to write/read in the FIFO array. When the first RD/WR operation is done on a row, the read/write pointer
// refers to that row.
   logic [ LOG2ROWS - 1 : 0 ]                    read_addr_lopower                       ;
   logic [ LOG2ROWS - 1 : 0 ]                    write_addr_lopower                      ;
   logic [ LOG2ROWS - 1 : 0 ]                    n_read_addr_lopower                     ;
   logic [ LOG2ROWS - 1 : 0 ]                    n_write_addr_lopower                    ;

   logic                                         fifo_internal_ein_l                     ;

// control signals
   logic                                         write_straight                          ;
   logic                                         empty_array                             ;

// WR/RD control signal on the array
   logic                                         array_write_en                          ;
   logic                                         array_read_en                           ;
   logic                                         read_op                                 ;
   logic                                         write_op                                ;
   logic                                         new_row_to_write                        ;
   logic                                         new_row_to_read                         ;

   logic                                         output_register_busy                    ;
   logic                                         incomplete_row_read                     ;

   logic                                         n_full                                  ;
   logic                                         full_i                                  ;

   logic                                         n_notempty                              ;
   logic                                         notempty_i                              ;

   logic [ l2d : 0 ]                             count_l                                 ;
   logic [ l2d : 0 ]                             n_count                                 ;
   logic                                         addresses_equal                         ;




   // sanity check l2d (address range) against the actual depth of the fifo
   //
   // synopsys translate_off
   // pragma coverage off
   initial begin : sanity_p
      GPC_GFX_RPFIFO_C:  assert ( d <= ( 2.0 ** l2d ) ) else $info ( "GPC_GFX_RPFIFO_CNT: log2(depth) insufficient for actual depth - please increase it" ) ;
   end
   // pragma coverage on
   // synopsys translate_on

























   // array update (write and shift operations)
   always_ff@(posedge clk) begin : p_sub_fifo_array_clkd
      logic    row_read_op;
      integer  max_ind;
      logic    array_reg_en;
      
      for ( int addr = 0 ; addr <= ROWS - 1 ; addr = addr + 1 ) begin
         if ( write_addr_lopower == addr && array_write_en == 1'b1 ) begin    // A write is occurring on this row COV:tag12
            // The first register of the row is loaded with the input data
            fifo_array [  addr  ] [  0  ] <= fifo_in_data ;    // COV:tag31
            // update of the other register of the row
            if ( ROW_DEPTH > 1 ) begin
               for ( int i = 1 ; i <= ROW_DEPTH - 1 ; i = i + 1 ) begin    // cycle on the registers of the row -- COV:tag14
                  //default assignment for local var
                  array_reg_en = 0;
                  if ( addr < ROWS - 1 | i < LAST_ROW_DEPTH ) begin    // in the last row there are only LAST_ROW_DEPTH registers, not -- COV:tag9
                     // ROW_DEPTH like in the other rows
                     if ( clkgate_sharing == 1 ) begin    // COV:tag43
                        // all the registers of the row are enabled simultaneously
                        array_reg_en = 1 ;    // COV:tag19
                     end else begin
                        if ( full_i == 1'b1 | i < row_write_counter ) begin    // COV:tag3
                           // if the fifo is full all the register of the row are valid and so all of them must be shifted to the next one
                           // if i < row_write_counter then the register must be enabled because the previous one contains valid data
                           array_reg_en = 1 ;    // COV:tag2
                        end else begin
                           // i >= row_write_counter
                           if ( incomplete_row_read == 1'b1 ) begin    // COV:tag2
                              // the read is occurring from an incomplete row. Only row_write_counter entries are valid, and the
                              // first one (stored in the register with index row_write_counter-1) is loaded directly in the
                              // output register
                              array_reg_en = 0 ;    // COV:tag2
                           end else begin
                              if ( i == row_write_counter ) begin    // COV:tag2
                                 // this register loads the data from the previous one (with index row_write_counter-1), that
                                 // contains the first entry of the row
                                 array_reg_en = 1 ;    // COV:tag2
                              end else begin
                                 row_read_op = read_addr_lopower == addr & array_read_en == 1'b1 ;    // it holds true when a -- COV:tag3
                                 // read operation is occurring on this row (and a write operation is occurring as well)
                                 if ( write_addr_lopower == read_addr_lopower ) begin
                                    // read and write are occurring on the same cycle
                                    // There are row_write_counter entries at the beginning of the row (the tail of the fifo) and
                                    // ROW_DEPTH-row_read_counter entries after them (the head of the fifo).
                                    // All of them must be shifted because a write is occurring.
                                    if ( addr < ROWS - 1 ) begin    // COV:tag2
                                       max_ind = ROW_DEPTH - row_read_counter + row_write_counter ;    // COV:tag2
                                    end else begin
                                       max_ind = LAST_ROW_DEPTH - row_read_counter + row_write_counter ;    // COV:tag2
                                    end
                                    if ( i < max_ind || ( row_read_op != 1'b1 && i == max_ind ) ) begin    // COV:tag3
                                       array_reg_en = 1 ;    // COV:tag2
                                    end else begin
                                       array_reg_en = 0 ;    // COV:tag2
                                    end
                                 end else begin
                                    array_reg_en = 0 ;    // COV:tag2
                                 end
                              end
                           end
                        end
                     end
                  end
                  if ( array_reg_en ) begin    // COV:tag43
                     fifo_array [  addr  ] [  i  ] <= fifo_array [  addr  ] [  i - 1  ] ;    // COV:tag43
                  end
               end
            end
         end
      end
   end

// map only used array fifo entries to linear array so that unused entries are not connected to the output and will be removed
// during synthesis
   always_comb begin : p_fifo_array1d
   begin
      for ( int addr = 0 ; addr <= ROWS - 2 ; addr = addr + 1 ) begin
         for ( int i = 0 ; i <= ROW_DEPTH - 1 ; i = i + 1 ) begin    // COV:tag11
            fifo_array1d [  addr * ROW_DEPTH + i  ] = fifo_array [  addr  ] [  i  ] ;    // COV:tag11
         end
      end
      for ( int i = 0 ; i <= LAST_ROW_DEPTH - 1 ; i = i + 1 ) begin
         fifo_array1d [  ( ROWS - 1 ) * ROW_DEPTH + i  ] = fifo_array [  ROWS - 1  ] [  i  ] ;
      end
   end
   end

// FIFO Output
   always_ff@(posedge clk or negedge  resetn) begin : p_rpfifo_output
      integer i;
   begin
      if ( resetn == 1'b0 ) begin
         fifo_out_data_l <= ( '0 ) ;
      end else begin
         begin
            // update of the output register
            if ( write_straight == 1'b1 ) begin
               fifo_out_data_l <= fifo_in_data ;
            end else if ( array_read_en == 1'b1 ) begin    // COV:tag30
               if ( incomplete_row_read == 1'b1 ) begin    // COV:tag30
                  i = row_write_counter - 1 ;    // COV:tag43
               end else begin
                  if ( read_addr_lopower == MAX_ROW_PTR ) begin    // COV:tag30
                     // the read is occurring on the last row
                     if ( read_addr_lopower == write_addr_lopower ) begin    // COV:tag30
                        i = LAST_ROW_DEPTH - 1 - row_read_counter + row_write_counter ;    // COV:tag30
                     end else begin
                        i = LAST_ROW_DEPTH - 1 - row_read_counter ;    // COV:tag11
                     end
                  end else begin
                     // the read is not occurring on the last row
                     if ( read_addr_lopower == write_addr_lopower ) begin    // COV:tag11
                        i = ROW_DEPTH - 1 - row_read_counter + row_write_counter ;    // COV:tag11
                     end else begin
                        i = ROW_DEPTH - 1 - row_read_counter ;    // COV:tag11
                     end
                  end
               end
               fifo_out_data_l <= fifo_array1d [  read_addr_lopower * ROW_DEPTH + i  ] ;    // COV:tag30
            end
         end
      end
   end
   end

   generate
   if (( count_free_space == 0 )) begin : g_normal_count
      // Counter process
      always_ff@(posedge clk or negedge  resetn) begin : p_cnt_clkd
      begin
         if ( resetn == 1'b0 ) begin    // COV:tag15
            count_l <= ( '0 ) ;    // COV:tag15
         end else begin
            begin    // COV:tag15
               count_l <= n_count ;    // COV:tag15
            end
         end
      end
      end
      assign n_count = fifo_internal_ein_l == 1'b1 & fifo_internal_vin == 1'b1 & ~ ( notempty_i == 1'b1 & fifo_internal_eout == 1'b1 ) ? count_l + 1'b1 : ~ ( fifo_internal_ein_l == 1'b1 & fifo_internal_vin == 1'b1 ) & notempty_i == 1'b1 & fifo_internal_eout == 1'b1 ? count_l - 1'b1 : count_l   ;    // COV:tag16 COV:tag16 
   end
   endgenerate

   generate
   if (( count_free_space == 1 )) begin : g_free_space_count
      // Counter process
      always_ff@(posedge clk or negedge  resetn) begin : p_cnt_clkd
      begin
         if ( resetn == 1'b0 ) begin    // COV:tag17
            count_l <= d ;    // COV:tag17
         end else begin
            begin    // COV:tag17
               count_l <= n_count ;    // COV:tag17
            end
         end
      end
      end
      assign n_count = fifo_internal_ein_l == 1'b1 & fifo_internal_vin == 1'b1 & ~ ( notempty_i == 1'b1 & fifo_internal_eout == 1'b1 ) ? count_l - 1'b1 : ~ ( fifo_internal_ein_l == 1'b1 & fifo_internal_vin == 1'b1 ) & notempty_i == 1'b1 & fifo_internal_eout == 1'b1 ? count_l + 1'b1 : count_l   ;    // COV:tag25 COV:tag18 
   end
   endgenerate

// Other control register update
   always_ff@(posedge clk or negedge  resetn) begin : p_address_update
   begin
      if ( resetn == 1'b0 ) begin
         read_addr_lopower <= ( '0 ) ;
         write_addr_lopower <= ( '0 ) ;
         row_read_counter <= ( '0 ) ;
         row_write_counter <= ( '0 ) ;
         full_i <= 1'b0 ;
         notempty_i <= 1'b0 ;
      end else begin
         begin
            read_addr_lopower <= n_read_addr_lopower ;
            write_addr_lopower <= n_write_addr_lopower ;
            row_read_counter <= n_row_read_counter ;
            if ( write_op == 1'b1 | read_op == 1'b1 ) begin
               // clock gating condition: these registers are updated only when a read or a write occur
               row_write_counter <= n_row_write_counter ;
               full_i <= n_full ;
               notempty_i <= n_notempty ;
            end
         end
      end
   end
   end

// ////////////////////////////////////////////////////////////////////////////
// combinatorial logic
// ////////////////////////////////////////////////////////////////////////////

   assign addresses_equal = write_addr_lopower == read_addr_lopower & row_write_counter == row_read_counter ? 1'b1 : 1'b0  ;    // COV:tag5 

// FIFO status
   assign empty_array = addresses_equal & ~ full_i ;    // COV:tag13

// output_register_busy is high if the output register cannot be updated in the next clock cycle
   assign output_register_busy = notempty_i & ~ fifo_internal_eout ;

// array W/R enabling
   generate
   if (registered_enable == 1) begin : g_registered_enable
      assign fifo_internal_ein_l = ~ full_i ;
   end
   endgenerate

   // upstream enable is based on the contents of the FIFO and the downstream enable ie whether the FIFO is being read on this cycle
   generate
   if (registered_enable == 0) begin : g_combinatorial_enable
      assign fifo_internal_ein_l = ~ full_i | fifo_internal_eout ;    // COV:tag4
   end
   endgenerate

   // read access to the incomplete row
   assign incomplete_row_read = fifo_internal_eout == 1'b1 & empty_array == 1'b0 & output_register_busy == 1'b0 & write_addr_lopower == read_addr_lopower & full_i == 1'b0 & row_read_counter == ZERO_ROW_COUNTER ? 1'b1 : 1'b0  ;    // COV:tag6 the array is not empty the output register can be updated  if the fifo is full the row is not incomplete if row_read_counter was greater than 0 then the row had been full 

   // read access to the array
   assign array_read_en = fifo_internal_eout & ~ empty_array ;    // COV:tag46

   // write enable on the array
   assign array_write_en = fifo_internal_ein_l & fifo_internal_vin & ~ write_straight ;    // COV:tag24

   // end of row signals
   assign new_row_to_write = ( row_write_counter == MAX_ROW_COUNTER & write_addr_lopower != MAX_ROW_PTR ) | ( row_write_counter == MAX_LAST_ROW_COUNTER & write_addr_lopower == MAX_ROW_PTR ) ? 1'b1 : 1'b0  ;    // COV:tag7   

   assign new_row_to_read = ( row_read_counter == MAX_ROW_COUNTER & read_addr_lopower != MAX_ROW_PTR ) | ( row_read_counter == MAX_LAST_ROW_COUNTER & read_addr_lopower == MAX_ROW_PTR ) ? 1'b1 : 1'b0  ;    // COV:tag7   

   // next row counter calculation
   // row_write_counter can be decreased (row_read_counter can't) if a read is done on an incomplete row
   assign n_row_write_counter = ~ ( array_write_en == 1'b1 ^ incomplete_row_read == 1'b1 ) ? row_write_counter : ( array_write_en == 1'b0 & incomplete_row_read == 1'b1 ) ? row_write_counter - 1'b1 : new_row_to_write == 1'b1 ? ( '0 ) : row_write_counter + 1'b1    ;    // COV:tag45 COV:tag20 COV:tag21 

   assign n_row_read_counter = array_read_en == 1'b0 | incomplete_row_read == 1'b1 ? row_read_counter : new_row_to_read == 1'b1 ? ( '0 ) : row_read_counter + 1'b1   ;    // COV:tag27 COV:tag48 

   // // next address calculation
   assign n_write_addr_lopower = ~ ( array_write_en == 1'b1 & incomplete_row_read == 1'b0 & new_row_to_write == 1'b1 ) ? write_addr_lopower : write_addr_lopower == MAX_ROW_PTR ? ( '0 ) : write_addr_lopower + 1'b1   ;    // COV:tag8 COV:tag22 

   // read address calculation.
   assign n_read_addr_lopower = ~ ( array_read_en == 1'b1 & new_row_to_read == 1'b1 ) ? read_addr_lopower : read_addr_lopower == MAX_ROW_PTR ? ( '0 ) : read_addr_lopower + 1'b1   ;    // COV:tag10 COV:tag22 

   assign read_op = notempty_i & fifo_internal_eout ;    // COV:tag40
   assign write_op = fifo_internal_ein_l & fifo_internal_vin ;    // COV:tag41

   assign n_full = ( n_write_addr_lopower == read_addr_lopower & n_row_write_counter == row_read_counter & fifo_out_enable == 1'b0 & fifo_in_valid == 1'b1 & write_straight == 1'b0 ) | ( addresses_equal == 1'b1 & read_op == write_op & full_i == 1'b1 ) ? 1'b1 : 1'b0  ;    // COV:tag28       

   assign n_notempty = ( ~ ( empty_array & ~ output_register_busy ) | ( fifo_internal_vin & fifo_internal_ein ) ) ;    // COV:tag42

   assign write_straight = empty_array & fifo_internal_vin & ~ output_register_busy ;    // COV:tag47

   assign fifo_internal_ein = fifo_internal_ein_l ;
   assign fifo_out_data = fifo_out_data_l ;

   // ////////////////////////////////////////////////////////////////////////////
   // tailoring for the specific rpfifo type
   // ////////////////////////////////////////////////////////////////////////////

   assign fifo_internal_vin = fifo_in_valid ;
   assign fifo_internal_eout = fifo_out_enable & notempty_i ;    // COV:tag23
   assign count = count_l ;
   assign fifo_in_enable = fifo_internal_ein ;
   assign fifo_out_valid = notempty_i ;

endmodule
