// ---------------------------------------------------------------------------------
// Project Name  : IC_Design
// Author        : liusm
// Email         : liusm@innosilicon.com.cn
// Create On     : 2025/02/27 11:14
// Last Modified : 2025/02/27 17:46
// File Name     : gc_l2_bank_cal_plru.sv
// Description   :
// 
// Copyright (c) 2025 Innosilicon.
// ALL RIGHTS RESERVED
// 
// ---------------------------------------------------------------------------------
// Modification History:
// Date         By              Version                 Change Description
// ---------------------------------------------------------------------------------
// 2025/02/27   liusm           1.0                     Original
// 
// ----------------------------------------------------------------------------------


module gc_l2_bank_cal_plru
import gc_l2_bank_pkg::*;
(
   input    logic    [L2_NUM_WAY-1:0]        avaliable_cacheline // 1 means cacheline can be replaced. 0 means cannot be replaced
,  input    logic    [L2_NUM_WAY-1:0][1:0]   ways_valids
,  input    logic    [L2_NUM_WAY-1:0][1:0]   persistences
,  input    logic    [L2_NUM_WAY-2:0]        plru_bits
,  output   logic    [L2_NUM_WAY_BITS-1:0]   replace_way 
);


logic [L2_NUM_WAY-1:0]                  empty_cacheline_mask       ; // 1 means can be replaced
logic [L2_NUM_WAY-1:0]                  persistence0_cacheline_mask; // 1 means can be replaced
logic [L2_NUM_WAY-1:0]                  persistence1_cacheline_mask; // 1 means can be replaced
logic [L2_NUM_WAY-1:0]                  persistence2_cacheline_mask; // 1 means can be replaced
logic [L2_NUM_WAY-1:0]                  persistence3_cacheline_mask; // 1 means can be replaced

logic [L2_NUM_WAY_BITS-1:0]            empty_cacheline_candidate;
logic [L2_NUM_WAY_BITS-1:0]            persistence0_cacheline_candidate;
logic [L2_NUM_WAY_BITS-1:0]            persistence1_cacheline_candidate;
logic [L2_NUM_WAY_BITS-1:0]            persistence2_cacheline_candidate;
logic [L2_NUM_WAY_BITS-1:0]            persistence3_cacheline_candidate;



generate
   for (genvar way = 0 ; way < L2_NUM_WAY; way ++) begin: g_cal_mask_to_evict_cacheline
      assign empty_cacheline_mask[way]        = avaliable_cacheline[way] && ways_valids[way] == 2'b00;
      assign persistence0_cacheline_mask[way] = avaliable_cacheline[way] && ways_valids[way] != 2'b00 && persistences[way] == 2'b00;
      assign persistence1_cacheline_mask[way] = avaliable_cacheline[way] && ways_valids[way] != 2'b00 && persistences[way] == 2'b01;
      assign persistence2_cacheline_mask[way] = avaliable_cacheline[way] && ways_valids[way] != 2'b00 && persistences[way] == 2'b10;
      assign persistence3_cacheline_mask[way] = avaliable_cacheline[way] && ways_valids[way] != 2'b00 && persistences[way] == 2'b11;
   end
endgenerate

assign empty_cacheline_candidate        = gc_l2_bank_pkg::func_plru_find_8ways(~empty_cacheline_mask       , plru_bits); 
assign persistence0_cacheline_candidate = gc_l2_bank_pkg::func_plru_find_8ways(~persistence0_cacheline_mask, plru_bits);
assign persistence1_cacheline_candidate = gc_l2_bank_pkg::func_plru_find_8ways(~persistence1_cacheline_mask, plru_bits);
assign persistence2_cacheline_candidate = gc_l2_bank_pkg::func_plru_find_8ways(~persistence2_cacheline_mask, plru_bits);
assign persistence3_cacheline_candidate = gc_l2_bank_pkg::func_plru_find_8ways(~persistence3_cacheline_mask, plru_bits);


assign replace_way =   |empty_cacheline_mask        ? empty_cacheline_candidate :
                       |persistence0_cacheline_mask ? persistence0_cacheline_candidate :
                       |persistence1_cacheline_mask ? persistence1_cacheline_candidate :
                       |persistence2_cacheline_mask ? persistence2_cacheline_candidate :
                        persistence3_cacheline_candidate ;




endmodule
// Local Variables:
// verilog-library-directories:("./" ) 
// End:
