// +FHDR----------------------------------------------------------------------------
// Copyright (c) 2025, Innosilicon, Inc. Confidential Proprietary
// PROJECT NAME  : xxx
// DEPARTMENT    : Digtal Frontend SOC
// AUTHOR        : luoml01
// EMAIL         : luoml01@innosilicon.com.cn
// CREATE ON     : 2025/03/27 21:58
// FILE NAME     : gc_l2_bank_sched_xbar_wrap.sv
// DESCRIPTION   :          
//         
// Copyright (c) 2025 Innosilicon.
// ALL RIGHTS RESERVED
// 
// ---------------------------------------------------------------------------------
// Modification History:
// Date         By              Version                 Change Description
// ---------------------------------------------------------------------------------
// 2025/03/27   luoml01         1.0                     Original
// 
// -FHDR----------------------------------------------------------------------------


module gc_l2_bank_sched_xbar_wrap
import gc_l2_bank_pkg::*;
import bank_sched_pkg::*;
import sched_bank_pkg::*;
import gpc_gfx_timing_buffer_pack_::*;


(
input logic clk,
input logic resetn,
output logic idle,

input   logic [L2_XBAR_NUM_BANK-1:0]                        memif_xbar_req_valid,
output  logic [L2_XBAR_NUM_BANK-1:0]                        memif_xbar_req_ready,
input   bank_sched_data_bus_t [L2_XBAR_NUM_BANK-1:0]        memif_xbar_req_rec  ,


output   logic [L2_XBAR_NUM_BANK-1:0]                       xbar_sched_req_valid,
input    logic [L2_XBAR_NUM_BANK-1:0]                       xbar_sched_req_ready,
output   bank_group_sched_data_bus_t [L2_XBAR_NUM_BANK-1:0] xbar_sched_req_rec  ,




output    logic [L2_XBAR_NUM_BANK-1:0]                      xbar_memif_rsp_valid,
input     logic [L2_XBAR_NUM_BANK-1:0]                      xbar_memif_rsp_ready,
output    sched_bank_data_bus_t [L2_XBAR_NUM_BANK-1:0]      xbar_memif_rsp_rec  ,



                                                          
input    logic [L2_XBAR_NUM_BANK-1:0]                       sched_xbar_rsp_valid,
output   logic [L2_XBAR_NUM_BANK-1:0]                       sched_xbar_rsp_ready,
input    sched_bank_group_data_bus_t [L2_XBAR_NUM_BANK-1:0] sched_xbar_rsp_rec  


);


logic [34-1:0] memif_xbar_req_pa       [1:0] ;
logic [34-1:0] xbar_sched_req_pa       [1:0] ;
                                                     
logic [34-1:0] sched_xbar_rsp_pa       [1:0] ;
logic [34-1:0] xbar_memif_rsp_pa       [1:0] ;
                                            
logic [7:0] xbar_sched_req_buffer_index[1:0] ;
logic [6:0] xbar_memif_rsp_buffer_index[1:0] ;

logic [6:0] memif_xbar_input_id [1:0];
logic [0:0] memif_xbar_input_idx [1:0];

logic [6:0] sched_xbar_rsp_input_id [1:0];
logic [0:0] sched_xbar_rsp_input_idx [1:0];

logic xbar_idle;
logic rdi_idle;

assign idle = xbar_idle & rdi_idle;


assign memif_xbar_input_id[0] = memif_xbar_req_rec[0].buffer_index;
assign memif_xbar_input_id[1] = memif_xbar_req_rec[1].buffer_index;

assign memif_xbar_input_idx[0] =  memif_xbar_req_rec[0].pa[33];
assign memif_xbar_input_idx[1] =  memif_xbar_req_rec[1].pa[33];


 gc_mss_xbar
#( .CHANNEL         (0),
   .NUM_REQ         (2),
   .NUM_TARGET      (2),
   .INPUT_ID_WIDTH  (7),
   .REQ_SB_WIDTH    ($size(memif_xbar_req_pa[0])),
   .OUTPUT_ID_WIDTH (8),
   .INPUT_IDX_WIDTH (1),
   .TBUFF_TYPE      (GPC_GFX_TIMING_BUFFER_PIPE_REG)

)
i_gc_sched_req_xbar
(
.clk                 ( clk                         ) ,
.resetn              ( resetn                      ) ,
.idle                ( xbar_idle                   ) ,
                     
.req_input_valid     ( memif_xbar_req_valid        ) ,
.req_input_ready     ( memif_xbar_req_ready        ) ,
.req_input_slv       ( memif_xbar_req_pa           ) ,
.req_input_id        ( memif_xbar_input_id         ) ,
.req_input_idx       ( memif_xbar_input_idx        ) ,
                     
                     
.target_output_valid ( xbar_sched_req_valid        ) ,
.target_output_ready ( xbar_sched_req_ready        ) ,
.target_output_slv   ( xbar_sched_req_pa           ) ,
.target_output_id    ( xbar_sched_req_buffer_index )

);






assign sched_xbar_rsp_input_id[0] = sched_xbar_rsp_rec[0].buffer_index[6:0];
assign sched_xbar_rsp_input_id[1] = sched_xbar_rsp_rec[1].buffer_index[6:0];

assign sched_xbar_rsp_input_idx[0] = sched_xbar_rsp_rec[0].buffer_index[7];
assign sched_xbar_rsp_input_idx[1] = sched_xbar_rsp_rec[1].buffer_index[7];

 gc_mss_xbar
#( .CHANNEL         (1),
   .NUM_REQ         (2),
   .NUM_TARGET      (2),
   .INPUT_ID_WIDTH  (7),
   .REQ_SB_WIDTH    ($size(sched_xbar_rsp_pa[0])),
   .OUTPUT_ID_WIDTH (7),
   .INPUT_IDX_WIDTH (1),
   .TBUFF_TYPE      (GPC_GFX_TIMING_BUFFER_PIPE_REG)

)
i_gc_sched_rtn_xbar
(
.clk                 ( clk                         ) ,
.resetn              ( resetn                      ) ,
.idle                ( rdi_idle                    ) ,
                     
                     
.req_input_valid     ( sched_xbar_rsp_valid        ) ,
.req_input_ready     ( sched_xbar_rsp_ready        ) ,
.req_input_slv       ( sched_xbar_rsp_pa           ) ,
.req_input_id        ( sched_xbar_rsp_input_id     ) ,
.req_input_idx       ( sched_xbar_rsp_input_idx    ) ,
                     
                     
.target_output_valid ( xbar_memif_rsp_valid        ) ,
.target_output_ready ( xbar_memif_rsp_ready        ) ,
.target_output_slv   ( xbar_memif_rsp_pa           ) ,
.target_output_id    ( xbar_memif_rsp_buffer_index )

);

generate
for(genvar QUEUE=0; QUEUE<=2-1; QUEUE++)begin  : g_sched_port
         
   assign xbar_sched_req_rec[QUEUE].buffer_index = xbar_sched_req_buffer_index[QUEUE] ; 
   assign xbar_sched_req_rec[QUEUE].pa = xbar_sched_req_pa[QUEUE];
   assign sched_xbar_rsp_pa[QUEUE] = sched_xbar_rsp_rec[QUEUE].pa;

end : g_sched_port



for(genvar MEMIF=0; MEMIF<=2-1; MEMIF++)begin : g_memif_port

   assign xbar_memif_rsp_rec[MEMIF].buffer_index = xbar_memif_rsp_buffer_index[MEMIF];
   assign xbar_memif_rsp_rec[MEMIF].pa = xbar_memif_rsp_pa[MEMIF];
   assign memif_xbar_req_pa[MEMIF] = memif_xbar_req_rec[MEMIF].pa;

end : g_memif_port
endgenerate




endmodule
// Local Variables:
// verilog-library-flags:("-y ./ -y ../")
// verilog-auto-inst-param-value:t
// End:

