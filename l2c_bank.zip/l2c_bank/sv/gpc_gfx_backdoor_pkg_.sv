/*

 * #==========================================================================#
 * |                                                                          |
 * |  Copyright (c) 2022, Fantasy Technologies Limited and/or its         |
 * |  affiliated group companies ("Fantasy"). All rights reserved.        |
 * |  No part of this content, either material or conceptual may be copied    |
 * |  or distributed, transmitted, transcribed, stored in a retrieval system  |
 * |  or translated into any human or computer language in any form by any    |
 * |  means, electronic, mechanical manual, or otherwise, or disclosed to     |
 * |  third parties without the express written permission of Fantasy.    |
 * |                                                                          |
 * #==========================================================================#

 */


package gpc_gfx_backdoor_pkg_;

   //synopsys translate_off

   /////////////////////////////////////////////////////////////////////
   // virtual class to help with access to backdoor read/write functions
   // in SPSTORE, DPSTORE and RGSTORE instances
   /////////////////////////////////////////////////////////////////////

   //virtual class to wrap the backdoor functions. All backdoor classes
   //must derive from this
   virtual class backdoor_access_base #(parameter int w=1);
     pure virtual task              write(int addr, logic [w-1:0] data, int verbose=0);
     pure virtual function [w-1:0]  read(int addr, int verbose=0);
   endclass

   //a simple 'forwarding' class that forwards backdoor requests to a sub-instance
   class backdoor_access_fwd #(parameter w=1) extends backdoor_access_base #(.w(w));
      backdoor_access_base #(.w(w)) inst;   
      task                 write(int addr, logic [w-1:0] data, int verbose=0);
         inst.write(addr, data, verbose);
      endtask

      function [w-1:0] read(int addr, int verbose=0);
         return inst.read(addr, verbose);
      endfunction
   endclass

   //synopsys translate_on

endpackage
