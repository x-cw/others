/*

 * #==========================================================================#
 * |                                                                          |
 * |  Copyright (c) 2022, Fantasy Technologies Limited and/or its         |
 * |  affiliated group companies ("Fantasy"). All rights reserved.        |
 * |  No part of this content, either material or conceptual may be copied    |
 * |  or distributed, transmitted, transcribed, stored in a retrieval system  |
 * |  or translated into any human or computer language in any form by any    |
 * |  means, electronic, mechanical manual, or otherwise, or disclosed to     |
 * |  third parties without the express written permission of Fantasy.    |
 * |                                                                          |
 * #==========================================================================#

 */

module gpu_core2_clock_gate
#(
   parameter tiw=1, // width of test bus input
   parameter tow=1  // width of test bus output
)
(
   input te,                // test enable
   input cp,                // clock input
   input e,                 // enable
   output q,                // gated clock out
   input [tiw - 1:0] tin,   // test bus input
   output [tow - 1:0] tout // test bus output
);

`ifndef GPU_SYNTHESIS
   //CLOCK GATE FOR sim
   reg ge; // gate enabled

   // clock gate cell
   always @(cp, e, te) begin
      if (cp == 1'b0) begin
         if (te == 1'b1 || e == 1'b1) // COV:tag1 
            ge <= 1'b1;
         else
            ge <= 1'b0;
      end
   end

   assign q = ge && cp;

   // Both tin and tout are not used. tin ANDd with 0 for Lint warning
   assign tout = tin & {tow{1'b0}}; // COV:tag2

`else
   //for synthesis
   wire  ED;
   wire  GE;
   wire  VDD;

//   `ifdef SAMSUNG4LPP
       PREICG_D4_N_S7P94TL_C60L06 hand_latch(
//   `else
//       PREICG_D4_N_M7P5TL_C60L08 hand_latch(
//   `endif
      .E(e),
      .SE(te),
      .CK(cp),
      .ECK(q)
  );
 
   assign tout = {tow{1'b0}};  

`endif

endmodule
