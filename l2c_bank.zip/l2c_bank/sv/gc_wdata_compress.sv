/*

 * #==========================================================================#
 * |                                                                          |
 * |  Copyright (c) 2023, Fantasy Technologies Limited and/or its         |
 * |  affiliated group companies ("Fantasy"). All rights reserved.        |
 * |  No part of this content, either material or conceptual may be copied    |
 * |  or distributed, transmitted, transcribed, stored in a retrieval system  |
 * |  or translated into any human or computer language in any form by any    |
 * |  means, electronic, mechanical manual, or otherwise, or disclosed to     |
 * |  third parties without the express written permission of Fantasy.    |
 * |                                                                          |
 * #==========================================================================#

 */
module gc_wdata_compress
   import pkg_mh_::*;
   import gc_wd_compress_pack_::*;
(
   input  logic                  wdata_aa,
   input  standard_wd_rec        wdata_standard_rec,
   output compressed_wd_rec      wdata_compress_rec
);

   assign wdata_compress_rec = f_wd_compress(wdata_standard_rec, wdata_aa);
endmodule : gc_wdata_compress
