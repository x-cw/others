// +FHDR----------------------------------------------------------------------------
// Copyright (c) 2025, Innosilicon, Inc. Confidential Proprietary
// PROJECT NAME  : xxx
// DEPARTMENT    : Digtal Frontend GPU IP
// AUTHOR        : luoml01
// EMAIL         : luoml01@innosilicon.com.cn
// CREATE ON     : 2025/03/27 17:30
// FILE NAME     : gc_l2_bank_nsp_xbar_wrap.sv
// DESCRIPTION   :          
//         
// Copyright (c) 2025 Innosilicon.
// ALL RIGHTS RESERVED
// 
// ---------------------------------------------------------------------------------
// Modification History:
// Date         By              Version                 Change Description
// ---------------------------------------------------------------------------------
// 2025/03/27   luoml01         1.0                     Original
// 
// -FHDR----------------------------------------------------------------------------


module gc_l2_bank_nsp_xbar_wrap

import gc_l2_bank_pkg::*;
import group_nsp_req_pkg::*;
import group_nsp_rsp_pkg::*;
import nsp_req_pkg::*;
import nsp_rsp_pkg::*;
import gpc_gfx_timing_buffer_pack_::*;
(
input logic clk,
input logic resetn,

output logic idle,

input   logic [L2_XBAR_NUM_BANK-1:0]                        memif_xbar_req_valid,
output  logic [L2_XBAR_NUM_BANK-1:0]                        memif_xbar_req_ready,
input   nsp_req_data_bus_t [L2_XBAR_NUM_BANK-1:0]           memif_xbar_req_rec  ,


output   logic [L2_XBAR_NUM_BANK-1:0]                       xbar_nsp_req_valid,
input    logic [L2_XBAR_NUM_BANK-1:0]                       xbar_nsp_req_ready,
output   group_nsp_req_data_bus_t [L2_XBAR_NUM_BANK-1:0]    xbar_nsp_req_rec  ,




output    logic [L2_XBAR_NUM_BANK-1:0]                      xbar_memif_rsp_valid,
input     logic [L2_XBAR_NUM_BANK-1:0]                      xbar_memif_rsp_ready,
output    nsp_rsp_data_bus_t [L2_XBAR_NUM_BANK-1:0]         xbar_memif_rsp_rec  ,



                                                          
input    logic [L2_XBAR_NUM_BANK-1:0]                       nsp_xbar_rsp_valid,
output   logic [L2_XBAR_NUM_BANK-1:0]                       nsp_xbar_rsp_ready,
input    group_nsp_rsp_data_bus_t [L2_XBAR_NUM_BANK-1:0]    nsp_xbar_rsp_rec  


);


logic [1+33+256+1+1+1+32+8+3-1:0] memif_xbar_req_slv[1:0] ;
logic [1+33+256+1+1+1+32+8+3-1:0] xbar_nsp_req_slv  [1:0] ;
                                                          
logic [256+3+2+1+1-1:0] nsp_xbar_rsp_slv            [1:0] ;
logic [256+3+2+1+1-1:0] xbar_memif_rsp_slv          [1:0] ;
                                                         
logic [7:0] xbar_nsp_req_trid                       [1:0] ;
logic [6:0] xbar_memif_rsp_trid                     [1:0] ;

logic xbar_idle;
logic rdi_idle;

logic [6:0] memif_xbar_req_input_id  [1:0];
logic [0:0] memif_xbar_req_input_idx [1:0];

logic [6:0] nsp_xbar_rsp_input_id [1:0];
logic [0:0] nsp_xbar_rsp_input_idx [1:0];


assign idle = xbar_idle & rdi_idle;


assign memif_xbar_req_input_id[0] =  memif_xbar_req_rec[0].trid;
assign memif_xbar_req_input_id[1] =  memif_xbar_req_rec[1].trid;

assign memif_xbar_req_input_idx[0] = memif_xbar_req_rec[0].addr[33];
assign memif_xbar_req_input_idx[1] = memif_xbar_req_rec[1].addr[33];


 gc_mss_xbar
#( .CHANNEL         (0),
   .NUM_REQ         (2),
   .NUM_TARGET      (2),
   .INPUT_ID_WIDTH  (7),
   .REQ_SB_WIDTH    ($size(memif_xbar_req_slv[0])),
   .OUTPUT_ID_WIDTH (8),
   .INPUT_IDX_WIDTH (1),
   .TBUFF_TYPE      (GPC_GFX_TIMING_BUFFER_WIRE)

)
i_gc_nsp_req_xbar
(
.clk                 ( clk                      ) ,
.resetn              ( resetn                   ) ,
.idle                ( xbar_idle                ) ,
                     
.req_input_valid     ( memif_xbar_req_valid     ) ,
.req_input_ready     ( memif_xbar_req_ready     ) ,
.req_input_slv       ( memif_xbar_req_slv       ) ,
.req_input_id        ( memif_xbar_req_input_id  ) ,
.req_input_idx       ( memif_xbar_req_input_idx ) ,
                     
                     
.target_output_valid ( xbar_nsp_req_valid       ) ,
.target_output_ready ( xbar_nsp_req_ready       ) ,
.target_output_slv   ( xbar_nsp_req_slv         ) ,
.target_output_id    ( xbar_nsp_req_trid        )

);



assign nsp_xbar_rsp_input_id[0] = nsp_xbar_rsp_rec[0].trid[6:0];
assign nsp_xbar_rsp_input_id[1] = nsp_xbar_rsp_rec[1].trid[6:0];

assign nsp_xbar_rsp_input_idx[0] = nsp_xbar_rsp_rec[0].trid[7];
assign nsp_xbar_rsp_input_idx[1] = nsp_xbar_rsp_rec[1].trid[7];


 gc_mss_xbar
#( .CHANNEL         (1),
   .NUM_REQ         (2),
   .NUM_TARGET      (2),
   .INPUT_ID_WIDTH  (7),
   .REQ_SB_WIDTH    ($size(nsp_xbar_rsp_slv[0])),
   .OUTPUT_ID_WIDTH (7),
   .INPUT_IDX_WIDTH (1),
   .TBUFF_TYPE      (GPC_GFX_TIMING_BUFFER_WIRE)

)
i_gc_nsp_rtn_xbar
(
.clk                 ( clk                    ) ,
.resetn              ( resetn                 ) ,
.idle                ( rdi_idle               ) ,
                     
.req_input_valid     ( nsp_xbar_rsp_valid     ) ,
.req_input_ready     ( nsp_xbar_rsp_ready     ) ,
.req_input_slv       ( nsp_xbar_rsp_slv       ) ,
.req_input_id        ( nsp_xbar_rsp_input_id  ) ,
.req_input_idx       ( nsp_xbar_rsp_input_idx ) ,
                     
                     
.target_output_valid ( xbar_memif_rsp_valid   ) ,
.target_output_ready ( xbar_memif_rsp_ready   ) ,
.target_output_slv   ( xbar_memif_rsp_slv     ) ,
.target_output_id    ( xbar_memif_rsp_trid    )

);

generate
for(genvar NSP=0; NSP<=2-1; NSP++)begin  : g_nsp_port
   assign  nsp_xbar_rsp_slv[NSP] = { nsp_xbar_rsp_rec[NSP].data    ,
                                     nsp_xbar_rsp_rec[NSP].errcode ,
                                     nsp_xbar_rsp_rec[NSP].status  ,
                                     nsp_xbar_rsp_rec[NSP].cont    ,
                                     nsp_xbar_rsp_rec[NSP].last };
   
   
   assign { xbar_nsp_req_rec[NSP].last   ,
            xbar_nsp_req_rec[NSP].be     ,
            xbar_nsp_req_rec[NSP].data   ,
            xbar_nsp_req_rec[NSP].excid  ,
            xbar_nsp_req_rec[NSP].seqid  ,
            xbar_nsp_req_rec[NSP].flowid ,
            xbar_nsp_req_rec[NSP].addr   ,
            xbar_nsp_req_rec[NSP].length ,
            xbar_nsp_req_rec[NSP].opc    } = xbar_nsp_req_slv[NSP];
         
   assign xbar_nsp_req_rec[NSP].trid = xbar_nsp_req_trid[NSP] ; 

end : g_nsp_port



for(genvar MEMIF=0; MEMIF<=2-1; MEMIF++)begin : g_memif_port


   assign  { xbar_memif_rsp_rec[MEMIF].data    ,
             xbar_memif_rsp_rec[MEMIF].errcode ,
             xbar_memif_rsp_rec[MEMIF].status  ,
             xbar_memif_rsp_rec[MEMIF].cont    ,
             xbar_memif_rsp_rec[MEMIF].last    } = xbar_memif_rsp_slv[MEMIF];
   
   
   assign memif_xbar_req_slv[MEMIF] = { memif_xbar_req_rec[MEMIF].last       ,
                                        memif_xbar_req_rec[MEMIF].be         ,
                                        memif_xbar_req_rec[MEMIF].data       ,
                                        memif_xbar_req_rec[MEMIF].excid      ,
                                        memif_xbar_req_rec[MEMIF].seqid      ,
                                        memif_xbar_req_rec[MEMIF].flowid     ,
                                        memif_xbar_req_rec[MEMIF].addr[32:0] ,
                                        memif_xbar_req_rec[MEMIF].length     ,
                                        memif_xbar_req_rec[MEMIF].opc } ;

   assign xbar_memif_rsp_rec[MEMIF].trid = xbar_memif_rsp_trid[MEMIF];

end : g_memif_port
endgenerate




endmodule
// Local Variables:
// verilog-library-flags:("-y ./ -y ../")
// verilog-auto-inst-param-value:t
// End:
