// ---------------------------------------------------------------------------------
// Project Name  : IC_Design
// Author        : liusm
// Email         : liusm@innosilicon.com.cn
// Create On     : 2024/09/09 13:56
// Last Modified : 2024/09/09 13:56
// File Name     : lib_binary_to_onehot.sv
// Description   :
// 
// Copyright (c) 2024 Innosilicon.
// ALL RIGHTS RESERVED
// 
// ---------------------------------------------------------------------------------
// Modification History:
// Date         By              Version                 Change Description
// ---------------------------------------------------------------------------------
// 2024/09/09   liusm           1.0                     Original
// 
// ----------------------------------------------------------------------------------


module gc_l2_bank_onehot_to_binary
#(
   parameter WIDTH = 4
)
(
   input logic  [2**WIDTH-1:0]   onehot,
   output logic [WIDTH-1:0]      binary
);
   localparam HALF_WIDTH = 2**(WIDTH-1);
   localparam FULL_WIDTH = 2**WIDTH;
   logic [WIDTH-2:0] temp_binary[1:0]; 
   generate
      if (WIDTH == 1)
         assign binary[0] = onehot[1];
      else begin : g_instance_lower_bits
         // translate the lower 2**(WITDH-2) to binary.
         gc_l2_bank_onehot_to_binary
         #(.WIDTH(WIDTH-1))
         u_gc_l2_bank_onehot_to_binary_low
         (  .onehot(onehot[HALF_WIDTH-1:0]),
            .binary(temp_binary[0]));
         
         // translate the higher 2**(WITDH-2) to binary.
         gc_l2_bank_onehot_to_binary
         #(.WIDTH(WIDTH-1))
         u_gc_l2_bank_onehot_to_binary_high
         (  .onehot(onehot[FULL_WIDTH-1:HALF_WIDTH]),
            .binary(temp_binary[1]));
         assign binary[WIDTH-2:0] = temp_binary[0] | temp_binary[1];
         assign binary[WIDTH-1] = |(onehot[FULL_WIDTH-1:HALF_WIDTH]);
      end
   endgenerate


//as__onehot_check:  assert property($isonehot0(onehot));
endmodule

// Local Variables:
// verilog-library-directories:("./" ) 
// End:
