// +FHDR----------------------------------------------------------------------------
// Copyright (c) 2025, Innosilicon, Inc. Confidential Proprietary
// PROJECT NAME  : xxx
// DEPARTMENT    : Digtal Frontend GPU MSS
// AUTHOR        : luoml01
// EMAIL         : luoml01@innosilicon.com.cn
// CREATE ON     : 2025/03/11 20:57
// FILE NAME     : gc_mss_perf_latency_count.sv
// DESCRIPTION   :          
//         
// Copyright (c) 2025 Innosilicon.
// ALL RIGHTS RESERVED
// 
// ---------------------------------------------------------------------------------
// Modification History:
// Date         By              Version                 Change Description
// ---------------------------------------------------------------------------------
// 2025/03/11   luoml01         1.0                     Original
// 
// -FHDR----------------------------------------------------------------------------


module gc_mss_sim_latency_count
#(
   parameter ID_WIDTH = 8,
   parameter LATENCY_WIDTH = 10

)
(
input  logic clk,
input  logic resetn,


input  logic req_valid,
input  logic req_ready,
input  logic [ID_WIDTH-1:0] req_id,


input  logic rtn_valid,
input  logic rtn_ready,
input  logic [ID_WIDTH-1:0] rtn_id,

output logic latency_valid,
output logic [LATENCY_WIDTH+2-1:0] latency_counter

);

   logic measuring_transaction;
   logic [ID_WIDTH-1:0] measuring_id;



   // Latency Counter
   always_ff@(posedge clk or negedge resetn) begin : p_latency_measurement_clkdrs
      if(resetn==1'b0) begin
         measuring_transaction <= 1'b0;
         measuring_id          <= '0;
         latency_valid         <= 1'b0;
         latency_counter       <= '0;
      end
      else begin
         if(measuring_transaction==1'b1) begin
            if((&(latency_counter))==1'b0) begin // don't allow the counter to overflow
               latency_counter <= latency_counter + 1;
            end
            if((rtn_valid==1'b1 && rtn_ready==1'b1 &&  rtn_id==measuring_id)) begin
               // The transaction we were monitoring has now returned therefore output the counter value
               measuring_transaction <= 1'b0;
               latency_valid <= 1'b1;
            end
         end
         else if(latency_valid==1'b1) begin
            // Wait for measured value to be accepted before beginning another latency measurement
            latency_valid <= 1'b0;
         end
         else if(req_valid==1'b1 && req_ready==1'b1) begin
            measuring_transaction <= 1'b1;
            measuring_id <= req_id;
            latency_counter <= '0;
         end
      end
   end : p_latency_measurement_clkdrs

   
endmodule
// Local Variables:
// verilog-library-flags:("-y ./ -y ../")
// verilog-auto-inst-param-value:t
// End:
