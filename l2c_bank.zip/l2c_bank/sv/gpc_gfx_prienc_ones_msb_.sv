/*

 * #==========================================================================#
 * |                                                                          |
 * |  Copyright (c) 2022, Fantasy Technologies Limited and/or its         |
 * |  affiliated group companies ("Fantasy"). All rights reserved.        |
 * |  No part of this content, either material or conceptual may be copied    |
 * |  or distributed, transmitted, transcribed, stored in a retrieval system  |
 * |  or translated into any human or computer language in any form by any    |
 * |  means, electronic, mechanical manual, or otherwise, or disclosed to     |
 * |  third parties without the express written permission of Fantasy.    |
 * |                                                                          |
 * #==========================================================================#

 */


module gpc_gfx_prienc_ones_msb_
#(
      parameter int                             W              = 4               ,     // Input Width of a single write
      parameter int                             OUTPUT_WIDTH   = 2
)
(
      input  logic [ W - 1 : 0 ]                vector                           ,
      output logic [ OUTPUT_WIDTH - 1 : 0 ]     result
      
);

   import gpc_gfx_std_func_pack_::*;

   localparam INPUT_WIDTH = gpc_min(2**OUTPUT_WIDTH, W);
   integer unsigned   prienc_vec  [W-1:0];
   logic [W-1:0]      vec_down;

   assign vec_down      = vector;

   always_comb
   begin
      prienc_vec[0] = 0;
      for (int i = 1; i < INPUT_WIDTH; i++) begin
         if (vec_down[i] == 1'b1) begin
            prienc_vec[i] = i;
         end else begin
            prienc_vec[i] = prienc_vec[i-1];
         end
      end
   end
   
   assign result = OUTPUT_WIDTH'(prienc_vec[INPUT_WIDTH - 1]);

endmodule
   
   
