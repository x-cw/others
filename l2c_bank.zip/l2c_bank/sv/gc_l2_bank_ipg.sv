/*



*/
// ----------------------------------------------------------------------------------------------
// entity name: gc_l2_bank_ipg
// purpose: clock gating control
// ----------------------------------------------------------------------------------------------

module gc_l2_bank_ipg
import group_nsp_req_pkg::*;
import group_nsp_rsp_pkg::*;
import nsp_rsp_pkg::*;
import nsp_req_pkg::*;
import axi5_ar_pkg::*;
import axi5_r_pkg::*;
import axi5_aw_pkg::*;
import axi5_w_pkg::*;
import axi5_b_pkg::*;
import gc_l2_bank_pkg::*;
(
    // AXI interface
    input   logic                           pgi_axi_slv_0_arvalid,
    output  logic                           pgi_axi_slv_0_arready,
    input   axi5_ar_data_bus_t              pgi_axi_slv_0_ar_rec,
    output  logic                           pgi_axi_slv_0_rvalid,
    input   logic                           pgi_axi_slv_0_rready,
    output  axi5_r_data_bus_t               pgi_axi_slv_0_r_rec,
    input   logic                           pgi_axi_slv_0_awvalid,
    output  logic                           pgi_axi_slv_0_awready,
    input   axi5_aw_data_bus_t              pgi_axi_slv_0_aw_rec,
    input   logic                           pgi_axi_slv_0_wvalid,
    output  logic                           pgi_axi_slv_0_wready,
    input   axi5_w_data_bus_t               pgi_axi_slv_0_w_rec,
    output  logic                           pgi_axi_slv_0_bvalid,
    input   logic                           pgi_axi_slv_0_bready,
    output  axi5_b_data_bus_t               pgi_axi_slv_0_b_rec,

    output  logic                           pgo_axi_slv_0_arvalid,
    input   logic                           pgo_axi_slv_0_arready,
    output  axi5_ar_data_bus_t              pgo_axi_slv_0_ar_rec,
    input   logic                           pgo_axi_slv_0_rvalid,
    output  logic                           pgo_axi_slv_0_rready,
    input   axi5_r_data_bus_t               pgo_axi_slv_0_r_rec,
    output  logic                           pgo_axi_slv_0_awvalid,
    input   logic                           pgo_axi_slv_0_awready,
    output  axi5_aw_data_bus_t              pgo_axi_slv_0_aw_rec,
    output  logic                           pgo_axi_slv_0_wvalid,
    input   logic                           pgo_axi_slv_0_wready,
    output  axi5_w_data_bus_t               pgo_axi_slv_0_w_rec,
    input   logic                           pgo_axi_slv_0_bvalid,
    output  logic                           pgo_axi_slv_0_bready,
    input   axi5_b_data_bus_t               pgo_axi_slv_0_b_rec,

    input   logic                           pgi_axi_slv_1_arvalid,
    output  logic                           pgi_axi_slv_1_arready,
    input   axi5_ar_data_bus_t              pgi_axi_slv_1_ar_rec,
    output  logic                           pgi_axi_slv_1_rvalid,
    input   logic                           pgi_axi_slv_1_rready,
    output  axi5_r_data_bus_t               pgi_axi_slv_1_r_rec,
    input   logic                           pgi_axi_slv_1_awvalid,
    output  logic                           pgi_axi_slv_1_awready,
    input   axi5_aw_data_bus_t              pgi_axi_slv_1_aw_rec,
    input   logic                           pgi_axi_slv_1_wvalid,
    output  logic                           pgi_axi_slv_1_wready,
    input   axi5_w_data_bus_t               pgi_axi_slv_1_w_rec,
    output  logic                           pgi_axi_slv_1_bvalid,
    input   logic                           pgi_axi_slv_1_bready,
    output  axi5_b_data_bus_t               pgi_axi_slv_1_b_rec,

    output  logic                           pgo_axi_slv_1_arvalid,
    input   logic                           pgo_axi_slv_1_arready,
    output  axi5_ar_data_bus_t              pgo_axi_slv_1_ar_rec,
    input   logic                           pgo_axi_slv_1_rvalid,
    output  logic                           pgo_axi_slv_1_rready,
    input   axi5_r_data_bus_t               pgo_axi_slv_1_r_rec,
    output  logic                           pgo_axi_slv_1_awvalid,
    input   logic                           pgo_axi_slv_1_awready,
    output  axi5_aw_data_bus_t              pgo_axi_slv_1_aw_rec,
    output  logic                           pgo_axi_slv_1_wvalid,
    input   logic                           pgo_axi_slv_1_wready,
    output  axi5_w_data_bus_t               pgo_axi_slv_1_w_rec,
    input   logic                           pgo_axi_slv_1_bvalid,
    output  logic                           pgo_axi_slv_1_bready,
    input   axi5_b_data_bus_t               pgo_axi_slv_1_b_rec,
    // NSP interface
    input   logic                    [L2_XBAR_NUM_BANK-1:0] pgi_nsp_req_valid,
    output  logic                    [L2_XBAR_NUM_BANK-1:0] pgi_nsp_req_ready,
    input   group_nsp_req_data_bus_t [L2_XBAR_NUM_BANK-1:0] pgi_nsp_req_rec,
    output  logic                    [L2_XBAR_NUM_BANK-1:0] pgi_nsp_rsp_valid,
    input   logic                    [L2_XBAR_NUM_BANK-1:0] pgi_nsp_rsp_ready,
    output  group_nsp_rsp_data_bus_t [L2_XBAR_NUM_BANK-1:0] pgi_nsp_rsp_rec,

    output  logic                    [L2_XBAR_NUM_BANK-1:0] pgo_nsp_req_valid,
    input   logic                    [L2_XBAR_NUM_BANK-1:0] pgo_nsp_req_ready,
    output  group_nsp_req_data_bus_t [L2_XBAR_NUM_BANK-1:0] pgo_nsp_req_rec,
    input   logic                    [L2_XBAR_NUM_BANK-1:0] pgo_nsp_rsp_valid,
    output  logic                    [L2_XBAR_NUM_BANK-1:0] pgo_nsp_rsp_ready,
    input   group_nsp_rsp_data_bus_t [L2_XBAR_NUM_BANK-1:0] pgo_nsp_rsp_rec,

    output  logic                           l2_ipg_wakeup,
    input   logic                           clk_status
);

assign pgi_axi_slv_0_arready    = pgo_axi_slv_0_arready & clk_status;
assign pgi_axi_slv_0_rvalid     = pgo_axi_slv_0_rvalid              ;
assign pgi_axi_slv_0_r_rec      = pgo_axi_slv_0_r_rec               ;
assign pgi_axi_slv_0_awready    = pgo_axi_slv_0_awready & clk_status;
assign pgi_axi_slv_0_wready     = pgo_axi_slv_0_wready  & clk_status;
assign pgi_axi_slv_0_bvalid     = pgo_axi_slv_0_bvalid              ;
assign pgi_axi_slv_0_b_rec      = pgo_axi_slv_0_b_rec               ;

assign pgo_axi_slv_0_arvalid    = pgi_axi_slv_0_arvalid & clk_status;
assign pgo_axi_slv_0_ar_rec     = pgi_axi_slv_0_ar_rec              ;
assign pgo_axi_slv_0_rready     = pgi_axi_slv_0_rready              ;
assign pgo_axi_slv_0_awvalid    = pgi_axi_slv_0_awvalid & clk_status;
assign pgo_axi_slv_0_aw_rec     = pgi_axi_slv_0_aw_rec              ;
assign pgo_axi_slv_0_wvalid     = pgi_axi_slv_0_wvalid  & clk_status;
assign pgo_axi_slv_0_w_rec      = pgi_axi_slv_0_w_rec               ;
assign pgo_axi_slv_0_bready     = pgi_axi_slv_0_bready              ;

assign pgi_axi_slv_1_arready    = pgo_axi_slv_1_arready & clk_status;
assign pgi_axi_slv_1_rvalid     = pgo_axi_slv_1_rvalid              ;
assign pgi_axi_slv_1_r_rec      = pgo_axi_slv_1_r_rec               ;
assign pgi_axi_slv_1_awready    = pgo_axi_slv_1_awready & clk_status;
assign pgi_axi_slv_1_wready     = pgo_axi_slv_1_wready  & clk_status;
assign pgi_axi_slv_1_bvalid     = pgo_axi_slv_1_bvalid              ;
assign pgi_axi_slv_1_b_rec      = pgo_axi_slv_1_b_rec               ;

assign pgo_axi_slv_1_arvalid    = pgi_axi_slv_1_arvalid & clk_status;
assign pgo_axi_slv_1_ar_rec     = pgi_axi_slv_1_ar_rec              ;
assign pgo_axi_slv_1_rready     = pgi_axi_slv_1_rready              ;
assign pgo_axi_slv_1_awvalid    = pgi_axi_slv_1_awvalid & clk_status;
assign pgo_axi_slv_1_aw_rec     = pgi_axi_slv_1_aw_rec              ;
assign pgo_axi_slv_1_wvalid     = pgi_axi_slv_1_wvalid  & clk_status;
assign pgo_axi_slv_1_w_rec      = pgi_axi_slv_1_w_rec               ;
assign pgo_axi_slv_1_bready     = pgi_axi_slv_1_bready              ;

assign pgo_nsp_req_valid        = pgi_nsp_req_valid                                     ;
assign pgo_nsp_req_rec          = pgi_nsp_req_rec                                       ;
assign pgo_nsp_rsp_ready        = pgi_nsp_rsp_ready                                     ;
                                                   
assign pgi_nsp_req_ready        = pgo_nsp_req_ready                                     ;
assign pgi_nsp_rsp_valid        = pgo_nsp_rsp_valid                                     ;
assign pgi_nsp_rsp_rec          = pgo_nsp_rsp_rec                                       ;


assign l2_ipg_wakeup = |{pgi_axi_slv_0_arvalid, pgi_axi_slv_0_awvalid, pgi_axi_slv_0_wvalid, 
                         pgi_axi_slv_1_arvalid, pgi_axi_slv_1_awvalid, pgi_axi_slv_1_wvalid, 
                         pgo_nsp_rsp_valid};

endmodule
