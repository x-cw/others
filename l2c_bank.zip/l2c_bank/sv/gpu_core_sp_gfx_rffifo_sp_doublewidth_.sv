/*

 * #==========================================================================#
 * |                                                                          |
 * |  Copyright (c) 2023, Fantasy Technologies Limited and/or its         |
 * |  affiliated group companies ("Fantasy"). All rights reserved.        |
 * |  No part of this content, either material or conceptual may be copied    |
 * |  or distributed, transmitted, transcribed, stored in a retrieval system  |
 * |  or translated into any human or computer language in any form by any    |
 * |  means, electronic, mechanical manual, or otherwise, or disclosed to     |
 * |  third parties without the express written permission of Fantasy.    |
 * |                                                                          |
 * #==========================================================================#

 */

// ////////////////////////////////////////////////////////////////////////-
// entity: rffifo_sp 
// purpose: single port register file based fifo with 0 threshold flags
// variant: this implementation uses a double width register file in order to try to sustain 1 read and 1 write
//          per clock cycle whilst only using a single port RAM.
// ////////////////////////////////////////////////////////////////////////-

module gpu_core_sp_gfx_rffifo_sp_doublewidth_
   import gpc_gfx_rambist_pack_::*;
#(
      parameter int                                      use_gray_code                                                = 0              ,    // Gray encoding of read/write addresses for power optimization. 0 = Disabled (Default), 1 = Enabled
      parameter int                                      use_flush                                                    = 0              ,    // set to 1 to use flush signal
      parameter int                                      ECC                                                          = 0              ,    // ECC enable : 0=disable ECC; 1=enable ECC
      parameter int                                      id                                                           = 0              ,    // id
      parameter int                                      w                                                            = 4              ,    // As width is doubled internally then 2 x Width must meet any Macro guidelines etc
      parameter int                                      d                                                            = 8              ,    // As depth is halved internally then Depth / 2 must meet any Macro guidelines etc
      parameter int                                      log2d                                                        = 3              ,
      parameter int                                      rd_priority                                                  = 1                   // Reads are given priority (Set to 0 to override this and give writes priority, however caution should be observed here as this will tend to cause the FIFO to fill up and may starve downstream modules which may not have valid data even if the FIFO is full) 
)
(
      input    logic                                                        clk                                     ,
      input    logic                                                        resetn                                  ,
      input    logic                                                        flush                                   ,
      // Valid/Enable interfaces
      input    logic                                                        fifo_in_valid                           ,
      output   logic                                                        fifo_in_enable                          ,
      input    logic [ w - 1 : 0 ]                                          fifo_in_data                            ,
      output   logic                                                        fifo_out_valid                          ,
      input    logic                                                        fifo_out_enable                         ,
      output   logic [ w - 1 : 0 ]                                          fifo_out_data                           ,
      // FIFO status
      output   logic                                                        idle                                    ,
      // BIST & Scan






      input    logic [ spstore_in ( 2 * w , 2 * w , d / 2 , ECC ) - 1 : 0 ] bist_in                                 ,
      output   logic [ spstore_out ( 2 * w , 2 * w , d / 2 , ECC ) - 1 : 0 ] bist_out                                ,
      input    logic                                                        tst_gclkenable                            
);
   import gpc_gfx_std_func_pack_::*;




   // Data Packing

   logic                                         upper_half_packed_data_valid            ;
   logic [ w - 1 : 0 ]                           muxed_upper_half_packed_data            ;

   logic                                         lower_half_packed_data_valid            ;
   logic [ w - 1 : 0 ]                           lower_half_packed_data                  ;

   // FIFO Control Signals
   logic                                         rd_strobe_n                             ;

   localparam logic [ log2d - 2 : 0 ]            MAXPTR = d/2 - 1;

   logic                                         validup                                 ;
   logic                                         validup_bypass                          ;
   logic                                         enableup                                ;
   logic                                         notempty                                ;

   logic                                         request_read                            ;





   logic [ log2d - 2 : 0 ]                       n_rd_addr                               ;
   logic [ log2d - 2 : 0 ]                       rd_addr                                 ;
   logic [ log2d - 2 : 0 ]                       n_wr_addr                               ;
   logic [ log2d - 2 : 0 ]                       wr_addr                                 ;


   // Register File Pins
   logic                                         strobe_n                                ;
   logic [ 0 : 0 ]                               wr_strobe_n                             ;
   logic [ log2d - 2 : 0 ]                       ram_addr                                ;
   logic [ log2d - 2 : 0 ]                       ram_addr_encoded                        ;
   logic [ 2 * w - 1 : 0 ]                       ram_wr_data                             ;
   logic [ 2 * w - 1 : 0 ]                       ram_rd_data                             ;
   logic [ 0 : 0 ]                               bypass_load                             ;
   logic                                         rd_en                                   ;


   // Data Unpacking Stage
   logic                                         rd_strobe_r                             ;
   logic [ 1 : 0 ]                               halves_valid                            ;
   logic                                         n_hold_output_valid                     ;
   logic                                         hold_output_valid                       ;
   logic [ w - 1 : 0 ]                           hold_output_data                        ;


   assign rd_en = 1'b0 ;

   // sanity check log2d (address range) against the actual depth of the fifo
   //









   if ( rd_priority == 1 ) begin : g_rd_priority0
      logic [ w - 1 : 0 ]                           upper_half_packed_data                  ;
      // Connect full flag so input is only disabled when the enable from the FIFO is low and the packing register full or a read is
      // taking place as reads are given priority
      assign fifo_in_enable = ( enableup == 1'b0 | request_read == 1'b1 ) & upper_half_packed_data_valid == 1'b1 & lower_half_packed_data_valid == 1'b1 ? 1'b0 : 1'b1  ;    // COV:tag4

     
      // FIFO data packer front-end.
      // Takes two sequential accesses and converts them
      // into a single (wider) access.
      
      always_ff @(posedge clk or negedge resetn) begin : p_pack_input_data_clkdrs
         if ( resetn == 1'b0 ) begin    // COV:tag10
            lower_half_packed_data_valid <= 1'b0 ;    // COV:tag10
            upper_half_packed_data_valid <= 1'b0 ;
         end else begin

            // Buffer up first access from input and raise the valid
            if ( ( lower_half_packed_data_valid == 1'b0 | validup_bypass == 1'b1 | upper_half_packed_data_valid == 1'b1 ) & fifo_in_valid == 1'b1 ) begin    // COV:tag10
               lower_half_packed_data_valid <= 1'b1 ;    // COV:tag10
            end else if ( ( validup == 1'b1 & enableup == 1'b1 & request_read == 1'b0 ) | validup_bypass == 1'b1 ) begin    // Request accepted into FIFO, drop valid -- COV:tag8
               lower_half_packed_data_valid <= 1'b0 ;    // COV:tag10
            end

            if ( lower_half_packed_data_valid == 1'b1 & validup_bypass == 1'b0 & ( enableup == 1'b0 | request_read == 1'b1 ) & fifo_in_valid == 1'b1 ) begin    // COV:tag10
               upper_half_packed_data_valid <= 1'b1 ;    // COV:tag10
            end else if ( ( validup == 1'b1 & enableup == 1'b1 & request_read == 1'b0 ) | validup_bypass == 1'b1 ) begin    // Request accepted into FIFO, drop valid  -- COV:tag8
               upper_half_packed_data_valid <= 1'b0 ;    // COV:tag10
            end

            // flush logic only synthesised when used
            if ( ( use_flush == 1 ) ) begin    // COV:tag0
               if ( ( flush == 1'b1 ) ) begin    // COV:tag0
                  lower_half_packed_data_valid <= 1'b0 ;    // COV:tag0
                  upper_half_packed_data_valid <= 1'b0 ;    // COV:tag0
               end
            end

         end
      end // p_pack_input_data_clkdrs

      always_ff @(posedge clk) begin : p_pack_input_data_clkd
         begin    // COV:tag10
            // Buffer first data access but don't write.
            if ( ( lower_half_packed_data_valid == 1'b0 | validup_bypass == 1'b1 | ( upper_half_packed_data_valid == 1'b1 & enableup == 1'b1 & request_read == 1'b0 ) ) & fifo_in_valid == 1'b1 ) begin    // COV:tag5
               lower_half_packed_data <= fifo_in_data ;    // COV:tag10
            end

            if ( lower_half_packed_data_valid == 1'b1 & upper_half_packed_data_valid == 1'b0 & validup_bypass == 1'b0 & ( enableup == 1'b0 | request_read == 1'b1 ) & fifo_in_valid == 1'b1 ) begin    // COV:tag10
               upper_half_packed_data <= fifo_in_data ;    // COV:tag10
            end
         end
      end // p_pack_input_data_clkd

      assign muxed_upper_half_packed_data = upper_half_packed_data_valid == 1'b1 ? upper_half_packed_data : fifo_in_data  ;    // COV:tag8 


            // Pass valid to FIFO whenever a pair of data is ready to be written
      assign validup = ( fifo_in_valid | upper_half_packed_data_valid ) & lower_half_packed_data_valid & ~ validup_bypass ;    // COV:tag8
   end // g_rd_priority0

   else begin : g_wr_priority0
      // Connect full flag so input is only disabled when the enable from the FIFO is low and the packing register full
      assign fifo_in_enable = enableup == 1'b0 & lower_half_packed_data_valid == 1'b1 ? 1'b0 : 1'b1  ;    // COV:tag3
    
      // FIFO data packer front-end.
      // Takes two sequential accesses and converts them
      // into a single (wider) access.
      
      always_ff @(posedge clk or negedge resetn) begin : p_pack_input_data_clkdrs
         if ( resetn == 1'b0 ) begin    // COV:tag1
            lower_half_packed_data_valid <= 1'b0 ;    // COV:tag1
         end else begin

            // Buffer up first access from input and raise the valid
            if ( ( lower_half_packed_data_valid == 1'b0 | validup_bypass == 1'b1 ) & fifo_in_valid == 1'b1 ) begin    // COV:tag1
               lower_half_packed_data_valid <= 1'b1 ;    // COV:tag1
            end else if ( ( validup == 1'b1 & enableup == 1'b1 ) | validup_bypass == 1'b1 ) begin    // Request accepted into FIFO, drop valid -- COV:tag3
               lower_half_packed_data_valid <= 1'b0 ;    // COV:tag1
            end

            // flush logic only synthesised when used
            if ( ( use_flush == 1 ) ) begin    // COV:tag2
               if ( ( flush == 1'b1 ) ) begin    // COV:tag2
                  lower_half_packed_data_valid <= 1'b0 ;    // COV:tag2
               end
            end

         end
      end // p_pack_input_data_clkdrs

      always_ff @(posedge clk) begin : p_pack_input_data_clkd
         begin    // COV:tag1
            // Buffer first data access but don't write.
            if ( ( lower_half_packed_data_valid == 1'b0 | validup_bypass == 1'b1 ) & fifo_in_valid == 1'b1 ) begin    // COV:tag1
               lower_half_packed_data <= fifo_in_data ;    // COV:tag1
            end
         end
      end // p_pack_input_data_clkd

      assign upper_half_packed_data_valid = 1'b0 ;


      assign muxed_upper_half_packed_data = fifo_in_data ;


      // Pass valid to FIFO whenever a pair of data is ready to be written
      assign validup = fifo_in_valid & lower_half_packed_data_valid & ~ validup_bypass ;    // COV:tag3
   end // g_wr_priority0

   // Allow single access into FIFO bypassing the RAM when it is empty and there is nothing in the output register otherwise wait for further writes
   assign validup_bypass = lower_half_packed_data_valid == 1'b1 & notempty == 1'b0 & rd_strobe_r == 1'b1 & ( halves_valid == 2'b00 | ( halves_valid == 2'b01 & fifo_out_enable == 1'b1 ) ) ? 1'b1 : 1'b0  ; 


   assign ram_wr_data = { muxed_upper_half_packed_data , lower_half_packed_data } ;

   //
   // FIFO Instantiation
   //


   //
   // Generate minimalist chip enables (lowest power)
   //
   if ( rd_priority == 1 ) begin : g_rd_priority1
      // Reads take priority over Writes
      assign wr_strobe_n [ 0 ] = ( validup == 1'b1 & enableup == 1'b1 ) & request_read == 1'b0 ? 1'b0 : 1'b1  ;    // COV:tag6
      assign rd_strobe_n = request_read == 1'b1 ? 1'b0 : 1'b1  ;    // COV:tag6


      assign strobe_n = wr_strobe_n [ 0 ] & rd_strobe_n ;    // COV:tag6
      assign ram_addr = request_read == 1'b1 ? rd_addr : wr_addr  ;    // COV:tag6
   end // g_rd_priority1

   else begin : g_wr_priority1
   // Writes take priority over Reads
      assign wr_strobe_n [ 0 ] = ( validup == 1'b1 & enableup == 1'b1 ) ? 1'b0 : 1'b1  ;    // COV:tag3
      assign rd_strobe_n = request_read == 1'b1 & ( validup == 1'b0 | enableup == 1'b0 ) ? 1'b0 : 1'b1  ;    // COV:tag3


      assign strobe_n = wr_strobe_n [ 0 ] & rd_strobe_n ;    // COV:tag3
      assign ram_addr = ( validup == 1'b1 & enableup == 1'b1 ) ? wr_addr : rd_addr  ;    // COV:tag3
   end // g_wr_priority1

   assign bypass_load [ 0 ] = validup_bypass ;

   gpu_core_sp_gfx_spstore_bypass_gen_bist_r_
      #(
         .w                               (w * 2)                                      ,
         .p                               (w * 2)                                      ,
         .d                               (d / 2)                                      ,
         .log2d                           (log2d - 1)                                  ,
         .ECC                             (ECC)                                        ,
         .id                              (id)                                         ,
         .byp_in                          (1)                                           
         )
      mem
      (
         .clk                             (clk)                                        ,
         .resetn                          (resetn)                                     ,
         .c_en                            (strobe_n)                                   ,
         .wr_en                           (wr_strobe_n)                                ,
         .rd_en                           (rd_en)                                      ,
         .addr                            (ram_addr_encoded)                           ,
         .wr_data                         (ram_wr_data)                                ,
         .bypass_load                     (bypass_load)                                ,
         .bypass_data                     (ram_wr_data)                                ,
         .rd_data                         (ram_rd_data)                                ,
         .ram_data                        ()                                           ,
         .bist_in                         (bist_in)                                    ,
         .bist_out                        (bist_out)                                   ,
         .tst_gclkenable                  (tst_gclkenable)                               
         );

   //
   // FIFO Control
   //
   assign n_wr_addr = wr_addr == MAXPTR ? {(log2d-1){1'b0}} : wr_addr + 1  ; 

   assign n_rd_addr = rd_addr == MAXPTR ? {(log2d-1){1'b0}} : rd_addr + 1  ; 

   always_ff @(posedge clk or negedge resetn) begin : p_fifo_ctrl_clkdrs
      if ( resetn == 1'b0 ) begin
         wr_addr <= {(log2d-1){1'b0}};
         rd_addr <= {(log2d-1){1'b0}};

         enableup <= 1'b1 ;
         notempty <= 1'b0 ;
      end else begin

         //
         // Increment pointers
         //
         if ( wr_strobe_n [ 0 ] == 1'b0 ) begin
            wr_addr <= n_wr_addr ;
            notempty <= 1'b1 ;
            if ( n_wr_addr == rd_addr ) begin
               // FIFO is going full
               enableup <= 1'b0 ;
            end
         end

         if ( rd_strobe_n == 1'b0 ) begin
            rd_addr <= n_rd_addr ;
            enableup <= 1'b1 ;
            if ( n_rd_addr == wr_addr ) begin
               // FIFO is going empty
               notempty <= 1'b0 ;
            end
         end
         // flush logic only synthesised when used
         if ( ( use_flush == 1 ) ) begin    // COV:tag0
            if ( ( flush == 1'b1 ) ) begin    // COV:tag0
               wr_addr <= {(log2d-1){1'b0}} ;    // COV:tag0
               rd_addr <= {(log2d-1){1'b0}} ;    // COV:tag0
               enableup <= 1'b1 ;    // COV:tag0
               notempty <= 1'b0 ;    // COV:tag0



            end
         end

      end
   end // p_fifo_ctrl_clkdrs



   // Create a signal to request reads either when the holding register is empty or about to go empty and the FIFO has valid 
   // contents to read
   always_comb begin : p_read_pipeline_comb 
      request_read = 1'b0 ;
      case (halves_valid)
         2'b00:
         begin
            if ( notempty == 1'b1 & rd_strobe_r == 1'b1 ) begin
               request_read = 1'b1 ;
            end
         end
         2'b01:
         begin
            if ( notempty == 1'b1 & fifo_out_enable == 1'b1 ) begin
               // No need to check rd_strobe_r in this case, as it must be '1'.
               // For rd_strobe_r to be 0, request_read must have been high in the previous cycle.  For request_read to be high in that cycle,
               // halves_valid must have been either all-zero, or be expecting to be set to all zero on the next clock edge (i.e. all data in
               // the RAM output register must be either being sent to the output or put in the holding register).
               // Therefore, if rd_strobe_r=0, halves_valid must also be all-zero.
               request_read = 1'b1 ;
            end
         end
         default:
         begin
            if ( notempty == 1'b1 & hold_output_valid == 1'b0 & fifo_out_enable == 1'b1 ) begin
               // No need to check rd_strobe_r in this case, as it must be '1'.  See previous justification.
               request_read = 1'b1 ;
            end
      end
      endcase // halves_valid

      n_hold_output_valid = hold_output_valid ;
      if ( ( ( halves_valid == 2'b11 & hold_output_valid == 1'b0 & fifo_out_enable == 1'b1 ) | ( halves_valid == 2'b01 & ( ( hold_output_valid == 1'b0 & fifo_out_enable == 1'b0 ) | ( hold_output_valid == 1'b1 & fifo_out_enable == 1'b1 ) ) ) ) ) begin  
         n_hold_output_valid = 1'b1 ;
      end else if ( hold_output_valid == 1'b1 & fifo_out_enable == 1'b1 ) begin
         n_hold_output_valid = 1'b0 ;
      end
   end // p_read_pipeline_comb


   always_ff @(posedge clk or negedge resetn) begin : p_read_pipeline_clkdrs
      if ( resetn == 1'b0 ) begin
         rd_strobe_r <= 1'b1 ;
         hold_output_valid <= 1'b0 ;
         halves_valid <= 2'b00 ;
      end else begin

         if ( rd_strobe_n == 1'b0 | rd_strobe_r == 1'b0 | ( | halves_valid ) == 1'b1 | hold_output_valid == 1'b1 ) begin
            // Create a registered version of the read strobe
            rd_strobe_r <= rd_strobe_n ;
            // Creat a valid for the holding register
            hold_output_valid <= n_hold_output_valid ;
         end

         if ( rd_strobe_r == 1'b0 ) begin

            halves_valid <= 2'b11 ;

         end else if ( validup_bypass == 1'b1 ) begin

            halves_valid <= { upper_half_packed_data_valid , lower_half_packed_data_valid } ;

         end else if ( halves_valid == 2'b01 & ( hold_output_valid == 1'b0 | fifo_out_enable == 1'b1 ) ) begin

            halves_valid <= 2'b00 ;

         end else if ( halves_valid == 2'b11 & hold_output_valid == 1'b0 & fifo_out_enable == 1'b1 ) begin

            // When there is an enable both halves are always accepted, the lower half forms the output directly and the top half is 
            // moved to a holding register on the same cycle to allow further RAM reads to take place without risk of losing data
            halves_valid <= 2'b00 ;

         end

         // flush logic only synthesised when used
         if ( ( use_flush == 1 ) ) begin
            if ( ( flush == 1'b1 ) ) begin    // COV:tag0
              rd_strobe_r <= 1'b1 ;    // COV:tag0
              hold_output_valid <= 1'b0 ;    // COV:tag0
              halves_valid <= 2'b00 ;    // COV:tag0
            end
         end

      end
   end // p_read_pipeline_clkdrs

   if ( use_gray_code == 0 ) begin : g_no_use_gray_code
      assign ram_addr_encoded = ram_addr ;
   end // g_no_use_gray_code
   else begin : g_use_gray_code
      gpc_gfx_gray_encode                # (.D(d/2))
      i_addr_gpc_gfx_gray_encode           (.addr_in(ram_addr),
                                             .result(ram_addr_encoded)  
                                             );
   end // g_use_gray_code

   always_ff @(posedge clk) begin
      begin
         if ( halves_valid == 2'b11 & hold_output_valid == 1'b0 & fifo_out_enable == 1'b1 ) begin
            hold_output_data <= ram_rd_data [ 2 * w - 1 : w ] ;
         end else if ( halves_valid == 2'b01 & ( ( hold_output_valid == 1'b0 & fifo_out_enable == 1'b0 ) | ( hold_output_valid == 1'b1 & fifo_out_enable == 1'b1 ) ) ) begin 
            hold_output_data <= ram_rd_data [ w - 1 : 0 ] ;
         end
      end
   end

   assign fifo_out_valid = hold_output_valid | halves_valid [ 0 ] ;    // Valid data in either the upper or lower half of the data
   assign fifo_out_data = hold_output_valid == 1'b1 ? hold_output_data : ram_rd_data [ w - 1 : 0 ]  ; 

   assign idle = ~ lower_half_packed_data_valid & ~ notempty & rd_strobe_r & ~ ( | halves_valid ) & ~ hold_output_valid ;    // COV:tag7

endmodule // gpu_core_sp_gfx_rffifo_sp_doublewidth


