// Author: jinjifang
// Date: 2024/1/8
// Description: the common flip-flop fifo

module gc_lib_reg_fifo_multiread #(
                         parameter type DTYPE = logic [7:0],    // data type is configurable to support packed struct
                         parameter integer DEPTH = 4,
                         parameter integer READ_PORT = 3
                         )(
                           input logic                      clk,
                           input logic                      resetn, 
                           // the push port
                           input logic                      push, 
                           output logic                     full, 
                           input DTYPE                      din,
                           // the multiple read port
                           input logic [READ_PORT-1:0]      pop, 
                           output logic [READ_PORT-1:0]     empty,  
                           output DTYPE [READ_PORT-1:0]     dout
                           );

    localparam  DEPTH_BITS      = (DEPTH == 1) ? 1 : $clog2(DEPTH);

    // user signals
    logic [DEPTH_BITS:0]                                wptr;
    logic [DEPTH_BITS:0]                                rptr [READ_PORT-1:0];
    logic [READ_PORT-1:0]                               full_w;
    DTYPE                                               fifo_mem [DEPTH-1 : 0];  


    //wprt
    always @(posedge clk or negedge resetn) begin
       if (!resetn) begin
          wptr <= {(DEPTH_BITS+1){1'b0}};
    end    
       else if (push) begin
          if(wptr[DEPTH_BITS-1:0] == DEPTH - 1)
             wptr <= {!wptr[DEPTH_BITS], {DEPTH_BITS{1'b0}}};
          else
             wptr <= wptr + 1'b1;
       end
    end

    generate
        for(genvar i = 0; i < READ_PORT; i++) begin
            //read pointer
            always @(posedge clk or negedge resetn) begin
                if (!resetn) 
                    rptr[i] <= {(DEPTH_BITS+1){1'b0}};
                else if (pop[i]) begin
                    if(rptr[i][DEPTH_BITS-1:0] == DEPTH - 1)
                        rptr[i] <= {!rptr[i][DEPTH_BITS], {DEPTH_BITS{1'b0}}};
                    else
                        rptr[i] <= rptr[i] + 1'b1;
               end
            end

            // dout
            assign  dout[i] = fifo_mem[rptr[i][DEPTH_BITS-1:0]];

            // full and empty flag
            assign empty[i]     = wptr == rptr[i];
            assign full_w[i]    = (wptr[DEPTH_BITS] ^ rptr[i][DEPTH_BITS]) & (wptr[DEPTH_BITS-1:0] == rptr[i][DEPTH_BITS-1:0]);
        end
    endgenerate
    
    // full if any read port is full
    assign full = |full_w;



    //fifo_mem
    generate
       for(genvar i = 0; i < DEPTH; i = i + 1) begin
          always @(posedge clk) begin
             if( push & (i == wptr[DEPTH_BITS-1:0]))
               fifo_mem[i] <= din;
          end
       end
    endgenerate

   
//synopsys translate_off
    logic   push_legal;
    assign push_legal = !full;
    gpu_assert_always_on_event u_assert_push(.clk(clk), .resetn(resetn), .sample(push), .expr(push_legal), .msg("push overflow"));


    logic [READ_PORT-1:0]   pop_legal;
    generate
        for(genvar i = 0; i < READ_PORT; i++) begin
            assign pop_legal[i] = !empty[i];
            gpu_assert_always_on_event u_assert_pop0(.clk(clk), .resetn(resetn), .sample(pop[i]), .expr(pop_legal[i]), .msg("pop underflow"));
        end

    endgenerate


//synopsys translate_on


endmodule
