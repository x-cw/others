/*

 * #==========================================================================#
 * |                                                                          |
 * |  Copyright (c) 2022, Fantasy Technologies Limited and/or its         |
 * |  affiliated group companies ("Fantasy"). All rights reserved.        |
 * |  No part of this content, either material or conceptual may be copied    |
 * |  or distributed, transmitted, transcribed, stored in a retrieval system  |
 * |  or translated into any human or computer language in any form by any    |
 * |  means, electronic, mechanical manual, or otherwise, or disclosed to     |
 * |  third parties without the express written permission of Fantasy.    |
 * |                                                                          |
 * #==========================================================================#

 */

package gpc_gfx_fileio_pack_;

// synopsys translate_off

   import gpc_gfx_tb_pack_::*;
   import gpc_gfx_std_func_pack_::*;

// ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////-
// entity name: gpc_gfx_fileio_pack
// purpose: Provide standard FILE I/O functionality as well as parsing of out.txt files
// ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////-


   localparam int                                           IMGFIO_ERROR                             = 0                             ;

   typedef string                                           line;
   typedef string                                           IMGUChar;
   
   typedef int IMGInt ;
   typedef string IMGString ;
   typedef string IMGStringPtr;
   typedef int IMGFileHandle ;

   //////////////////////////////////////////////////////////////////////////////
   // Shared variables including Arguments and the record for the currently active file
   //////////////////////////////////////////////////////////////////////////////    

   static logic                                  test_finished                            = 0                             ;

   ////////////////////////////////////////////////////////////////////////////-
   // External Functions
   ////////////////////////////////////////////////////////////////////////////-

   //////////////////////////////////////////////////////////////////////////////
   // Function to check whether a file exists.
   // If the file is already open for reading or writing then this check will
   // return true, otherwise an attempt is made to open the file for reading.
   //
   // As the file is opened then closed immediately within the same function
   // call this shouldn't cause problems with opening too many files at once,
   // hence this doesn't need to work via the managed filehandles.
   //////////////////////////////////////////////////////////////////////////////  
   //function automatic logic imgfio_fexists;
   //input  IMGString                                      filename ;
   //endfunction // imgfio_fexists

   
   ////////////////////////////////////////////////////////////////////////////////
   // Procedure very similar to hwrite but will write out 'X's for unknown not '0's
   // And auto expands to a multiple of 4
   //////////////////////////////////////////////////////////////////////////////// 
   task automatic imgfio_uwrite;     
      inout  IMGString                                   line ;
      input  logic[127:0] VALUE ;
      input  bits;
      logic [3:0] nibble;
      for (int l = 0; l <= bits; l = l + 4) begin
          if ((|nibble != 1'b0) & (|nibble != 1'b1)) begin
              line = {line, "X"};
          end else begin
              line = {line, $psprintf("%x", nibble)};
          end
      end
   endtask
   
   //////////////////////////////////////////////////////////////////////////////
   // Function to open file for reading or writing if not open already. 
   // This is now a wrapper for IMGFIO_fopen_chk that will abort if the file doesn't
   // exist.
   //////////////////////////////////////////////////////////////////////////////  
   function automatic IMGFileHandle imgfio_fopen;
   input  IMGString                                      filename ;
   input  IMGString                                      mode ;
       return $fopen(filename, mode);
   endfunction // imgfio_fopen


   //////////////////////////////////////////////////////////////////////////////
   // Function to open file for reading or writing if not open already. Also performs
   // initialisation & then returns the corresponding file handle for subsequent accesses. 
   //////////////////////////////////////////////////////////////////////////////  
   function automatic IMGFileHandle imgfio_fopen_chk;
   input  IMGString                                      filename ;
   input  IMGString                                      mode ;
       return $fopen(filename, mode);
   endfunction // imgfio_fopen_chk
   
   
   //////////////////////////////////////////////////////////////////////////////
   // Function to close the file, free the buffer and remove the file record structure
   //////////////////////////////////////////////////////////////////////////////     
   task automatic imgfio_fclose;
   input  IMGFileHandle                                  filehandle ;
       $fclose(filehandle);
   endtask // imgfio_fclose



   //////////////////////////////////////////////////////////////////////////////
   // Function to flush the file buffers
   //////////////////////////////////////////////////////////////////////////////     
   task automatic imgfio_flush;
   input  IMGFileHandle                                  filehandle ;
       $fflush(filehandle);
   endtask // imgfio_flush


   //////////////////////////////////////////////////////////////////////////////
   // Function to read a character from a file. The character is actually read from a cache which
   // improves efficiency by storing up to MAX_STRING_SIZE characters which are read in a single burst 
   //////////////////////////////////////////////////////////////////////////////    
   task automatic imgfio_fgetc;
   input  IMGFileHandle                                  filehandle ;
   output  IMGUChar                                       char ;
          char = string'($fgetc(filehandle));
   endtask // imgfio_fgetc


   //////////////////////////////////////////////////////////////////////////////
   // Function to place a character in a file. The character is actually written to a cache which
   // improves efficiency by storing up to MAX_STRING_SIZE characters which are written in a single burst
   //////////////////////////////////////////////////////////////////////////////
   task automatic imgfio_fputc;
   input  IMGFileHandle                                  filehandle ;
   input  IMGUChar                                       char ;
       $fwrite(filehandle, "%s", char);
   endtask // imgfio_fputc

   //////////////////////////////////////////////////////////////////////////////
   // Function to place a 32bit word in a file.
   //////////////////////////////////////////////////////////////////////////////
   // task automatic imgfio_fputword;
   // input  IMGFileHandle                                  filehandle ;
   // input  logic                                          word ;
   // endtask // imgfio_fputword

   //////////////////////////////////////////////////////////////////////////////
   // Function to place a character back in the cache so it can be retrieved for a second
   // time by a subsequent "fget" command. 
   //////////////////////////////////////////////////////////////////////////////    
   // task automatic imgfio_fungetc;
   // input  IMGFileHandle                                  filehandle ;
   // endtask // imgfio_fungetc


   //////////////////////////////////////////////////////////////////////////////
   // Function to read a word from a file stopping at white space. Any white space before the word
   // is also discarded. The underlying function works one character at a time by making calls to "fgetc"
   //////////////////////////////////////////////////////////////////////////////    
   task automatic imgfio_fgets;
   input  IMGFileHandle                                  filehandle ;
   output line                                           string_out ;
   output logic                                          at_end ;
   int count;
        string_out = "";
        at_end = 0;
        if (!$feof(filehandle)) begin
            count = $fscanf(filehandle, "%s", string_out);
        end
        if ($feof(filehandle)) begin
            at_end = 1;
        end   
   endtask // imgfio_fgets


   //////////////////////////////////////////////////////////////////////////////
   // Function to place a word into a file. Each character is actually written using the fputc function
   //////////////////////////////////////////////////////////////////////////////   
   task automatic imgfio_fputs;
   input  IMGFileHandle                                  filehandle ;
   output line                                           string_in ;
       $fwrite(filehandle, "%s", string_in);
   endtask // imgfio_fputs


   //////////////////////////////////////////////////////////////////////////////
   // Function to read a line from a file stopping at vertical formatting. Any white space before the word
   // is also discarded. The underlying function works one character at a time by making calls to "fgetc"
   //////////////////////////////////////////////////////////////////////////////   
   task automatic imgfio_fgetline;
   input  IMGFileHandle                                  filehandle ;
   output line                                           string_out ;
   output logic                                          at_end ;
   int res;
        string_out = "";
        at_end = 0;
        if (!$feof(filehandle)) begin
            res = $fgets(string_out, filehandle);
        end
        if ($feof(filehandle)) begin
            at_end = 1;
        end
   endtask // imgfio_fgetline


   //////////////////////////////////////////////////////////////////////////////
   // Function to place a word into a file followed by a new line character. Each character
   // is actually written using the fputc function which performs underlying cache interactions
   //////////////////////////////////////////////////////////////////////////////   
   task automatic imgfio_fputline;
   input  IMGFileHandle                                  filehandle ;
   input  line                                           string_in ;
      $fwrite(filehandle, "%s\n", string_in);
   endtask // imgfio_fputline


   //////////////////////////////////////////////////////////////////////////////
   // Function to check if test is finished
   //////////////////////////////////////////////////////////////////////////////     
   function automatic logic imgfio_testfinished;
   input  int                                            ip ;
      if ( test_finished ) begin
         return 1 ;
      end else begin
         return 0 ;
      end
   endfunction // imgfio_testfinished

   //////////////////////////////////////////////////////////////////////////////
   // Function to set test finished when an out.txt is not used
   //////////////////////////////////////////////////////////////////////////////     
   task automatic imgfio_set_testfinished;
   input  int                                            ip ;
      test_finished = 1 ;
   endtask // imgfio_set_testfinished


// synopsys translate_on
   
endpackage
