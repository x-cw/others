// +FHDR----------------------------------------------------------------------------
// Copyright (c) 2025, Innosilicon, Inc. Confidential Proprietary
// PROJECT NAME  : xxx
// DEPARTMENT    : Digtal Frontend IP
// AUTHOR        : luoml01
// EMAIL         : luoml01@innosilicon.com.cn
// CREATE ON     : 2025/03/27 10:19
// FILE NAME     : gc_mss_xbar.sv
// DESCRIPTION   :          
//         
// Copyright (c) 2025 Innosilicon.
// ALL RIGHTS RESERVED
// 
// ---------------------------------------------------------------------------------
// Modification History:
// Date         By              Version                 Change Description
// ---------------------------------------------------------------------------------
// 2025/03/27   luoml01         1.0                     Original
// 
// -FHDR----------------------------------------------------------------------------


module gc_mss_xbar
import gpc_gfx_timing_buffer_pack_::*;
#( parameter CHANNEL = 0, //0 for REQ, 1 for RTN
   parameter NUM_REQ = 2,
   parameter NUM_TARGET = 2,
   parameter INPUT_ID_WIDTH = 7,
   parameter REQ_SB_WIDTH = 256,
   parameter OUTPUT_ID_WIDTH = 8,
   parameter INPUT_IDX_WIDTH = 1,
   parameter TBUFF_TYPE = GPC_GFX_TIMING_BUFFER_WIRE

)
(
input logic clk,
input logic resetn,
output logic idle,


input  logic [NUM_REQ-1:0]             req_input_valid                       ,
output logic [NUM_REQ-1:0]             req_input_ready                       ,
input  logic [REQ_SB_WIDTH-1:0]        req_input_slv        [NUM_REQ-1:0]    ,
input  logic [INPUT_ID_WIDTH-1:0]      req_input_id         [NUM_REQ-1:0]    ,
input  logic [INPUT_IDX_WIDTH-1:0]     req_input_idx        [NUM_REQ-1:0]    ,


output logic [NUM_TARGET-1:0]          target_output_valid                   ,
input  logic [NUM_TARGET-1:0]          target_output_ready                   ,
output logic [REQ_SB_WIDTH-1:0]        target_output_slv    [NUM_TARGET-1:0] ,
output logic [OUTPUT_ID_WIDTH-1:0]     target_output_id     [NUM_TARGET-1:0] 


);


localparam int REQ_NUM_WIDTH = $clog2(NUM_REQ);



logic [NUM_REQ-1:0] req_rr_input_valid [NUM_TARGET-1:0];
logic [NUM_REQ-1:0] req_rr_input_ready [NUM_TARGET-1:0];
logic [NUM_TARGET-1:0] [NUM_REQ-1:0] [REQ_SB_WIDTH-1:0]    req_rr_input_slv;
logic [NUM_TARGET-1:0] [NUM_REQ-1:0] [INPUT_ID_WIDTH-1:0]  req_rr_input_id ;

logic [REQ_NUM_WIDTH-1:0] prev_selected_req [NUM_TARGET-1:0];
logic [REQ_NUM_WIDTH-1:0] next_index_round_robin_req [NUM_TARGET-1:0];

logic [OUTPUT_ID_WIDTH-1:0] target_output_tbuff_in_id [NUM_TARGET-1:0];
logic [NUM_TARGET-1:0] target_output_tbuff_in_valid;
logic [NUM_TARGET-1:0] target_output_tbuff_in_ready;
logic [REQ_SB_WIDTH-1:0] target_output_tbuff_in_slv [NUM_TARGET-1:0];



assign idle = req_input_valid=='0 && target_output_tbuff_in_valid=='0 && target_output_valid=='0;



//always_comb begin : p_req_to_target_cvt_comv
//
//   for(int unsigned REQ=0; REQ<=NUM_REQ-1; REQ++)begin : p_req_cvt_comb
//      req_input_ready[REQ] = ~req_input_valid[REQ];
//
//      for(int unsigned TGT=0; TGT<=NUM_TARGET-1; TGT++)begin : p_target_cvt_comb
//         req_rr_input_valid [TGT][REQ] = 1'b0;
//         req_rr_input_slv   [TGT][REQ] = '0;
//         req_rr_input_id    [TGT][REQ] = '0;
//
//         if(req_input_valid[REQ]==1'b1 && TGT==req_input_idx[REQ])begin
//            req_rr_input_valid [TGT][REQ] = 1'b1;
//            req_rr_input_slv   [TGT][REQ] = req_input_slv[REQ];
//            req_rr_input_id    [TGT][REQ] = req_input_id[REQ];
//
//            req_input_ready    [REQ]      = req_rr_input_ready[TGT][REQ];
//         end
//      end
//   end 
//end : p_req_to_target_cvt_comv

generate
for(genvar REQ=0; REQ<=NUM_REQ-1; REQ++)begin : g_req_input
   always_comb begin : p_req_ready_comb
      req_input_ready[REQ] = ~req_input_valid[REQ];

      if(req_input_valid[REQ]==1'b1)begin
         req_input_ready[REQ] = req_rr_input_ready[req_input_idx[REQ]][REQ];
      end
   end : p_req_ready_comb

   for(genvar TGT=0; TGT<=NUM_TARGET-1; TGT++)begin : g_target_input
      always_comb begin : p_req_to_target_cvt_comb
         req_rr_input_valid [TGT][REQ] = 1'b0;
         req_rr_input_slv   [TGT][REQ] = '0;
         req_rr_input_id    [TGT][REQ] = '0;

         if(req_input_valid[REQ]==1'b1 && TGT==req_input_idx[REQ])begin
            req_rr_input_valid [TGT][REQ] = 1'b1;
            req_rr_input_slv   [TGT][REQ] = req_input_slv[REQ];
            req_rr_input_id    [TGT][REQ] = req_input_id [REQ];
         end
      end : p_req_to_target_cvt_comb
   end : g_target_input
end : g_req_input


for(genvar TGT=0; TGT<=NUM_TARGET-1; TGT++)begin : g_target_output_drive

   // use round robin arbitration on the per requester mask to chose which req returns data to which requester
   gpc_round_robin_index_arch1_ #(
      .width         (NUM_REQ),
      .hold_previous (1'b0)
   ) i_rr_req_input (
      .valids         ( req_rr_input_valid         [TGT]) ,
      .previous_index ( prev_selected_req          [TGT]) ,
      .next_index     ( next_index_round_robin_req [TGT])
   );
   
   
   
   
   always_ff@(posedge clk or negedge resetn)begin
      if(resetn==1'b0)begin
         prev_selected_req[TGT] <= '0;
      end
      else if(target_output_tbuff_in_valid[TGT]==1'b1 && target_output_tbuff_in_ready[TGT]==1'b1)begin
         prev_selected_req[TGT] <= next_index_round_robin_req[TGT];
      end
   end
   
   
   
   assign target_output_tbuff_in_slv [TGT]= req_rr_input_slv[TGT][next_index_round_robin_req[TGT]];

   if(CHANNEL==0) begin : g_req_channel_id
      assign target_output_tbuff_in_id  [TGT] = {next_index_round_robin_req[TGT], req_rr_input_id[TGT][next_index_round_robin_req[TGT]]};
   end
   if(CHANNEL==1) begin : g_rtn_channel_id
      assign target_output_tbuff_in_id  [TGT] =  req_rr_input_id[TGT][next_index_round_robin_req[TGT]];
   end


   
   assign target_output_tbuff_in_valid[TGT] = |req_rr_input_valid[TGT];
   
   
   always_comb begin : p_req_input_ready_comb
      req_rr_input_ready[TGT] = ~req_rr_input_valid[TGT];
      if(req_rr_input_valid[TGT][next_index_round_robin_req[TGT]]==1'b1)begin
         req_rr_input_ready[TGT][next_index_round_robin_req[TGT]] = target_output_tbuff_in_ready[TGT];
      end
   end
   
   
   // Timing Buffer on the Execute Instruction interface
   gpc_gfx_timing_buffer_ #(
      .BUFFER_TYPE   (TBUFF_TYPE), 
      .WIDTH         (OUTPUT_ID_WIDTH + REQ_SB_WIDTH)
   ) i_tbuff_target_output (
      .clk              ( clk                                                               ) ,
      .resetn           ( resetn                                                            ) ,
      .tbuff_in_valid   ( target_output_tbuff_in_valid                            [TGT]     ) ,
      .tbuff_in_enable  ( target_output_tbuff_in_ready                            [TGT]     ) ,
      .tbuff_in_data    ( {target_output_tbuff_in_id[TGT], target_output_tbuff_in_slv[TGT]} ) ,
      .tbuff_out_valid  ( target_output_valid                                     [TGT]     ) ,
      .tbuff_out_enable ( target_output_ready                                     [TGT]     ) ,
      .tbuff_out_data   ( {target_output_id[TGT], target_output_slv[TGT]}                   )
   );
end : g_target_output_drive
endgenerate
















endmodule
// Local Variables:
// verilog-library-flags:("-y ./ -y ../")
// verilog-auto-inst-param-value:t
// End:
