/********************************************
* Copyright 2023 Innosilicon Technology Ltd *
* Computational Microarchitecture           *
********************************************/

module gc_fp32_adder_denorm_flush #(
    parameter   ew      =   8,
    parameter   mw_a    =   23,
    parameter   mw_b    =   23,
    parameter   mw_y    =   23
)(
    input  logic   clk,
    input  logic   enable,
    input  logic [ ew + mw_a:0 ]    a,
    input  logic [ ew + mw_b:0 ]    b,
    output logic [ ew + mw_y:0 ]    y
);

    localparam  mw_m        =   max( mw_a, mw_b );
    localparam  mw_n        =   max( mw_m, mw_y );
    localparam  mw_d        =   mw_n - mw_y;
    localparam  mw_n_log2   =   $clog2( 2 + mw_n + 2 );
    localparam  ew_n        =   max( ew, mw_n_log2);

    // float extraction
    logic               sign_a,sign_b;
    logic [ ew-1   :0]  exp_a,exp_b;
    logic [ mw_a-1 :0]  mant_a;
    logic [ mw_b-1 :0]  mant_b;

    // control signals
    logic   nan_or_inf_a,nan_or_inf_b;
    logic   expzero_a,expzero_b;
    logic   mantzero_a,mantzero_b;
    logic   nan_or_inf, denorm, denorms, negatives;

    logic   subtract, negate, shiftout;
    logic   nan_y;
    logic   a_ge_b;
    logic   sign_y;

    // internal signals
    logic   [ ew   : 0]  exp_delta_n, exp_delta_p;// ew + 1 - 1
    logic   [ ew-1 : 0]  exp_delta, exp_l, exp_l_pp;
    logic   [ mw_m-1:0]  mant_a_zpr, mant_b_zpr;
    logic   [ mw_m-1:0]  mant_l, mant_s;
    logic                mant_p_c;
    logic   [ mw_n+2:0]  mant_s_shift;
    logic   [ mw_n+3:0]  mant_s_addend;
    logic   [ mw_n+2:0]  mant_s_mask;
    logic   [ mw_n_log2-1:0]  shift;

    logic   sticky_s;



    //-----------------------------------
    //---------P0 Stage------------------
    //-----------------------------------

    // signal extractions
    assign  sign_a   =   a[ mw_a + ew ];
    assign  exp_a   =   a[ mw_a + ew -1 : mw_a];
    assign  mant_a  =   a[ mw_a - 1: 0];

    assign  sign_b   =   b[ mw_b + ew ];
    assign  exp_b   =   b[ mw_b + ew -1 : mw_b];
    assign  mant_b  =   b[ mw_b - 1: 0];

    // ctrl signals
    assign  nan_or_inf_a   =   &(exp_a);
    assign  nan_or_inf_b   =   &(exp_b);
    assign  expzero_a    =   ~(|exp_a);
    assign  expzero_b    =   ~(|exp_b);
    assign  mantzero_a   =   ~(|mant_a);
    assign  mantzero_b   =   ~(|mant_b);
    assign  nan_or_inf     =   nan_or_inf_a || nan_or_inf_b;
    assign  denorm      =   expzero_a  || expzero_b;
    assign  denorms     =   expzero_a  && expzero_b;
    assign  negatives   =   sign_a   &&  sign_b;

    // compare part
    assign  subtract    =   sign_a   ^  sign_b; // a minus operation

    assign  exp_delta_p =   exp_a - exp_b;
    assign  exp_delta_n =   exp_b - exp_a;
    assign  exp_delta   =   exp_delta_p[ew]? exp_delta_n : exp_delta_p;

    assign  mant_a_zpr  =   mant_a  << ( mw_m - mw_a );
    assign  mant_b_zpr  =   mant_b  << ( mw_m - mw_b );

    // order
    assign  a_ge_b      =   { exp_a, mant_a_zpr, sign_b } >= { exp_b, mant_b_zpr, sign_a };

    // sort
    assign  exp_l       =   a_ge_b ? exp_a : exp_b;
    assign  mant_l      =   a_ge_b ? mant_a_zpr : mant_b_zpr;
    assign  mant_s      =   a_ge_b ? mant_b_zpr : mant_a_zpr;

    // align
    generate
        if ( ew > mw_n_log2)begin
            assign  shiftout    =  denorm  ||  nan_or_inf ||  (|exp_delta[ew-1:mw_n_log2]);
            assign  shift       =  exp_delta[mw_n_log2-1:0] | {mw_n_log2{shiftout}};
        end
    endgenerate

    generate
        if ( ew <= mw_n_log2)begin
            assign  shiftout    =  denorm  ||  nan_or_inf ;
            assign  shift       =  { {mw_n_log2-ew{1'b0}},exp_delta} | {mw_n_log2{shiftout}};
        end
    endgenerate

    assign  negate          =   subtract  &&  ~denorm ;
    assign  mant_s_shift    =   { 1'b1, mant_s, {mw_n-mw_m{1'b0}}, 2'b00} >> shift;
    assign  mant_s_addend   =   { negate, mant_s_shift ^ {mw_n+3{negate}}};
    assign  mant_s_mask     =   ~ ( {mw_n+3{1'b1}} << shift );
    assign  sticky_s        =   ~denorm &&  ( negate ^ ( |({1'b1,mant_s} & (mant_s_mask[mw_n+2:(mw_n-mw_m+2)])) ));

    // add
    assign  mant_p_c        =   negate;
    // normalise
    assign  exp_l_pp        =   exp_l + 1;
    // exceptions
    assign  nan_y           =   ( nan_or_inf_a && ~mantzero_a) || ( nan_or_inf_b && ~mantzero_b ) || ( subtract && nan_or_inf_a && nan_or_inf_b);
    // result 
    assign  sign_y          =   a_ge_b ? sign_a: sign_b;

    //----------------------------------
    //---------P1 Stage-----------------
    //----------------------------------

    /////////////////////
    // register signal //
    /////////////////////

    // sort
    logic   [ mw_m-1:0]  mant_l_p1;
    // align
    logic   [ mw_n+3:0]  mant_s_addend_p1;
    logic                sticky_s_p1;
    // add
    logic                mant_p_c_p1;
    // normalise
    logic   [ ew-1 : 0]  exp_l_pp_p1;
    // result
    logic                sign_y_p1;
    // exception
    logic                nan_or_inf_p1;
    logic                nan_y_p1;
    logic                denorms_p1;
    logic                negatives_p1;

    always_ff @(posedge clk)begin
        if(enable) begin
            mant_l_p1           <=  mant_l;
            mant_s_addend_p1    <=  mant_s_addend;
            sticky_s_p1         <=  sticky_s;
            mant_p_c_p1         <=  mant_p_c;
            exp_l_pp_p1         <=  exp_l_pp;
            sign_y_p1           <=  sign_y;
            nan_or_inf_p1       <=  nan_or_inf;
            nan_y_p1            <=  nan_y;
            denorms_p1          <=  denorms;
            negatives_p1        <=  negatives;
        end
    end

    //////////////////////////
    // combinational signal //
    //////////////////////////

    // leading zero count signal
    logic   [ mw_n_log2:0] mant_p_dxp;
    // mant and exp 
    logic   [ mw_n+4:0]  mant_p_p1;
    logic   [ ew_n : 0]  exp_n_p1;
    logic   [ mw_n+4:0]  mant_n_p1;
    // rte
    logic   sticky, round, guard, incr;
    logic                mant_r_c_p1;
    logic   [ mw_y+1:0]  mant_r_p1;
    logic   [ mw_y-1:0]  mant_y_p1;
    logic   [ ew_n : 0]  exp_y_p1;
    // exceptions
    logic   inf_y_p1, denorm_y_p1, exception_p1;
    // result
    logic   [ ew + mw_y  :0]  y_e, y_n;



    // add
    assign  mant_p_p1          =   { 2'b01, mant_l_p1, {mw_n-mw_m{1'b0}}, 3'b000} + { mant_s_addend_p1, sticky_s_p1} + mant_p_c_p1;

    // normalise

    always_comb begin
        logic [mw_n_log2:0] p_dxp;
        for ( p_dxp = mw_n+4;p_dxp > 0; p_dxp--)begin
            if( mant_p_p1[p_dxp] ) break;
        end
        mant_p_dxp  =   mw_n + 4 - p_dxp;
    end

    assign  exp_n_p1        =   { {ew_n-ew{1'b0}}, exp_l_pp_p1} - mant_p_dxp;
    assign  mant_n_p1       =   mant_p_p1  <<  mant_p_dxp;

    // rte
    assign  guard           =   mant_n_p1[4 + mw_d];
    assign  round           =   mant_n_p1[4 + mw_d -1];
    assign  sticky          =  |mant_n_p1[4 + mw_d -2:0];
    assign  incr            =   (guard && round) || (round && sticky);

    assign  mant_r_c_p1     =   incr;
    assign  mant_r_p1       =   { 1'b0, mant_n_p1[mw_n+4:mw_d+4]} + mant_r_c_p1;
    assign  mant_y_p1       =   mant_r_p1[ mw_y + 1]?  mant_r_p1[mw_y:1] : mant_r_p1[mw_y-1:0];
    assign  exp_y_p1        =   mant_r_p1[ mw_y + 1]?  exp_n_p1 + 1 : exp_n_p1;

    // exceptions
    assign  inf_y_p1           =   nan_or_inf_p1 || ( ~mant_p_c_p1 && ( (|exp_y_p1[ew_n:ew]) || (&exp_y_p1[ew-1:0]) ) );
    assign  denorm_y_p1        =   denorms_p1 || exp_y_p1[ew_n] || (~(|exp_y_p1)) || (mant_p_c_p1 && (~(|mant_p_p1)) );
    assign  exception_p1       =   nan_y_p1 || inf_y_p1 || denorm_y_p1;

    // result
    assign  y_e             =   { (~nan_y_p1 && ( negatives_p1 || (~denorms_p1 && sign_y_p1))), {ew{inf_y_p1}}, nan_y_p1, {mw_y-1{1'b0}}};
    assign  y_n             =   { sign_y_p1, exp_y_p1[ew-1:0], mant_y_p1};
    assign  y               =   exception_p1? y_e : y_n;

    function int max(input int a,input int b);
        if ( a > b)
            return a;
        else
            return b;
    endfunction



endmodule
