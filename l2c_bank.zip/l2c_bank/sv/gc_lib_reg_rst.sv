// Author: jinjifang
// Date: 2024/1/5
// Description: the flip-flop with reset, but no enable

module gc_lib_reg_rst(/*AUTOARG*/
   // Outputs
   q,
   // Inputs
   clk, resetn, d
   );

   parameter      WIDTH = 1;
   parameter      INIT = {WIDTH{1'b0}};

   input wire                    clk;
   input wire                    resetn;

   input wire [WIDTH-1:0]        d;
   output reg [WIDTH-1:0]        q;

   always @(posedge clk or negedge resetn) begin
      if(!resetn)
         q <= INIT;
      else
         q <= d;
   end

endmodule

