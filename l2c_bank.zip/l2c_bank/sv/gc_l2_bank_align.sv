/*


*/

// ----------------------------------------------------------------------------------------------
// entity name: gc_l2_bank_align
// purpose: L2 interactive with AXI interface, allocate IWDB index.
//          generate buffer mode request to isched, cache request to tagctrl
// ----------------------------------------------------------------------------------------------


module gc_l2_bank_align
import axi5_ar_pkg::*;
import axi5_r_pkg::*;
import axi5_aw_pkg::*;
import axi5_w_pkg::*;
import axi5_b_pkg::*;
import gpc_gfx_timing_buffer_pack_::*;
import gc_l2_bank_pkg::*;
(
    // global interface
    input   logic       clk,
    input   logic       resetn,
    output  logic       l2_align_idle,
    // AXI slave AR-channel
    input   logic                                   axi_slv_arvalid,
    output  logic                                   axi_slv_arready,
    input   axi5_ar_data_bus_t                      axi_slv_ar_rec,
    // AXI slave R-channel
    output  logic                                   axi_slv_rvalid,
    input   logic                                   axi_slv_rready,
    output  axi5_r_data_bus_t                       axi_slv_r_rec,
    // AXI slave AW-channel
    input   logic                                   axi_slv_awvalid,
    output  logic                                   axi_slv_awready,
    input   axi5_aw_data_bus_t                      axi_slv_aw_rec,
    // AXI slave W-channel
    input   logic                                   axi_slv_wvalid,
    output  logic                                   axi_slv_wready,
    input   axi5_w_data_bus_t                       axi_slv_w_rec,
    // AXI slave B-channel
    output  logic                                   axi_slv_bvalid,
    input   logic                                   axi_slv_bready,
    output  axi5_b_data_bus_t                       axi_slv_b_rec,

    // To TAGCTRL for cacheline request
    output  logic                                   align_tagctrl_valid,
    input   logic                                   align_tagctrl_ready,
    output  align_tagctrl_record_type               align_tagctrl_record,
    // To ISCHED for buffer mode request
    output  logic                                   align_isched_bm_valid,
    input   logic                                   align_isched_bm_ready,
    output  align_isched_bm_record_type             align_isched_bm_rec,
    // write IWDB interface
    output  logic                                   align_iwdb_valid,
    input   logic                                   align_iwdb_ready,
    output  align_iwdb_write_record_type            align_iwdb_rec,

    input   logic                                   iwdb_align_free_valid,
    input   logic   [L2_IWDB_INDEX_BITS-1:0]        iwdb_align_free_index,

    // RCTRL read data return interface
    input   logic                   [L2_NUM_RCTRL-1: 0] rctrl_align_valid,
    output  logic                   [L2_NUM_RCTRL-1: 0] rctrl_align_ready,
    input   memif_align_record_type [L2_NUM_RCTRL-1: 0] rctrl_align_rec,
    // ROB read data return interface, for bypass read miss
    input   logic                                   memif_align_valid,
    output  logic                                   memif_align_ready,
    input   memif_align_record_type                 memif_align_rec,
    // performance counter
    output  logic               l2b_fromaxi_ar_wl               ,
    output  logic               l2b_fromaxi_ar_bl_eq0_wl        ,
    output  logic               l2b_fromaxi_ar_bl_eq1_wl        ,
    output  logic               l2b_fromaxi_ar_bl_eq2_wl        ,
    output  logic               l2b_fromaxi_ar_bl_eq3_wl        ,
    output  logic               l2b_fromaxi_ar_bp               ,
    output  logic               l2b_toaxi_r_wl                  ,
    output  logic               l2b_toaxi_r_bp                  ,
    output  logic               l2b_fromaxi_aw_wl               ,
    output  logic               l2b_fromaxi_aw_bl_eq0_wl        ,
    output  logic               l2b_fromaxi_aw_bl_eq1_wl        ,
    output  logic               l2b_fromaxi_aw_bl_eq2_wl        ,
    output  logic               l2b_fromaxi_aw_bl_eq3_wl        ,
    output  logic               l2b_fromaxi_aw_bp               ,
    output  logic               l2b_fromaxi_w_wl                ,
    output  logic               l2b_fromaxi_w_bp                ,
    output  logic               l2b_fromaxi_smp_read_req_num    ,
    output  logic               l2b_fromaxi_smp_read_req_sum    ,
    output  logic               l2b_fromaxi_smp_write_req_num   ,
    output  logic               l2b_fromaxi_smp_write_req_sum   ,
    output  logic               l2b_fromaxi_smp_atomic_req_num  ,
    output  logic               l2b_fromaxi_smp_atomic_req_sum  ,
    output  logic               l2b_align_awdb_full             ,
    // configure register
    input   logic               gc_cr_l2_cmd_notify,
    input   logic               gc_cr_l2_cmd_persistence_rst_all,
    input   logic               gc_cr_l2_cmd_cfi_clr,
    input   logic               gc_cr_l2_cfi_operation_notify,
    input   logic [ 1 : 0 ]     gc_cr_l2_cfi_operation,
    input   logic [ 1 : 0 ]     gc_cr_l2_buffer_mode_percentage,
    output  logic               gc_cr_l2_cfi_status_l2b_finish,
    input   logic               gc_cr_l2_persistence_reduce_enable,
    input   logic [ 20 : 0 ]    gc_cr_l2_persistence_reduce_threshold,
    // CFI complete interface
    input   logic               tagctrl_align_cfi_complete
);

// -------------------------------------------------------------------------------------------------
// interanl signal define
// -------------------------------------------------------------------------------------------------
localparam int unsigned L2_ALIGN_W_FIFO_DEPTH   = 4;
localparam int unsigned L2_ALIGN_IDX_FIFO_DEPTH = 8;
localparam int unsigned L2_ALIGN_ARB_SRC_NUM    = 2;
localparam int unsigned L2_ALIGN_ARB_IDX_BITS   = $clog2(L2_ALIGN_ARB_SRC_NUM);
localparam int unsigned L2_ALIGN_WID_FIFO_DEPTH = 8;
localparam int unsigned L2_ALIGN_WL_FIFO_DEPTH  = 4;
localparam int unsigned L2_ALIGN_RTN_FIFO_DEPTH = 6;
localparam int unsigned L2_ALIGN_R_ARB_SRC_NUM  = L2_NUM_RCTRL +1;
localparam int unsigned L2_ALIGN_R_ARB_SRC_BITS = $clog2(L2_ALIGN_R_ARB_SRC_NUM);
localparam int unsigned L2_ALIGN_WID_ARB_NUM    = 2;
localparam int unsigned L2_PERSIS_TIME_UNIT     = 50000;

logic                                   is_ar_bm_req;
logic                                   is_aw_bm_req;
logic                                   is_rstl_aa_req;
logic                                   is_idx_aa_req;
logic                                   idx_assign_idle;
logic                                   is_atomic_128;
logic                                   is_atomic_wrap;
logic                                   is_atomic_fp32;
logic                                   is_atomic_64;
logic [1 : 0]                           extended_atomic_opcode;

logic                                   axi_rstl_arvalid;
logic                                   axi_rstl_arready;
axi5_ar_data_bus_t                      axi_rstl_ar_rec;

logic                                   ar_cache_valid;
logic                                   ar_cache_ready;
align_tagctrl_record_type               ar_cache_rec;

logic                                   ar_bm_valid;
logic                                   ar_bm_ready;
align_isched_bm_record_type             ar_bm_rec;

logic                                   aw_bm_valid;
logic                                   aw_bm_ready;
align_isched_bm_record_type             aw_bm_rec;

logic                                   axi_rstl_awvalid;
logic                                   axi_rstl_awready;
axi5_aw_data_bus_t                      axi_rstl_aw_rec;

logic                                   axi_idx_in_awvalid;
logic                                   axi_idx_in_awready;

logic                                   axi_idx_out_awvalid;
logic                                   axi_idx_out_awready;
axi5_aw_data_bus_t                      axi_idx_out_aw_rec;
logic [L2_IWDB_INDEX_BITS-1     : 0]    axi_idx_awiwdb;

logic [L2_IWDB_INDEX_BITS-1     : 0]    allocated_iwdb_idx;
logic                                   allocate_iwdb_valid;
logic                                   allocated_iwdb_valid;

logic                                   aw_cache_valid;
logic                                   aw_cache_ready;
align_tagctrl_record_type               aw_cache_rec;

logic [  1 : 0]                         atomic_size;
logic [L2_AA_OP_WIDTH-1         : 0]    atomic_op;
logic [(L2_AXI_BUS_WIDTH/8/4)-1 : 0]    dword_active;

logic                                   idx_fifo_in_valid;
logic                                   idx_fifo_in_ready;
logic                                   idx_fifo_out_valid;
logic                                   idx_fifo_out_ready;

logic [L2_IWDB_INDEX_BITS-1     : 0]    iwdb_iwdb_index;
logic [  1 : 0]                         iwdb_atomic_size;
logic [L2_AA_OP_WIDTH-1         : 0]    iwdb_atomic_op;
logic                                   iwdb_atomic_wrap;
logic                                   iwdb_is_atomic;
logic [L2_AXI_LEN_WIDTH-1       : 0]    iwdb_index_offset;
logic [L2_IWDB_INDEX_BITS       : 0]    iwdb_index_ovf;
logic                                   align_iwdb_rstl_vld_rdy;

logic                                   axi_rstl_wvalid;
logic                                   axi_rstl_wready;
axi5_w_data_bus_t                       axi_rstl_w_rec;
logic [(L2_AXI_BUS_WIDTH/8)-1   : 0]    uncompress_wstrb;

logic                                   axi_rstl_bvalid;
logic                                   axi_rstl_bready;
logic                                   axi_rstl_bvld_rdy;
logic [L2_AXI_ID_WIDTH-1        : 0]    axi_rstl_bid;
logic                                   wid_fifo_in_valid;
logic                                   wid_fifo_in_ready;
logic [L2_AXI_ID_WIDTH-1        : 0]    wid_fifo_in_data;
logic                                   wid_fifo_out_valid;
logic                                   aw_ready_2_wid_fifo;
logic                                   wid_fifo_out_ready;
logic                                   wlast_fifo_in_valid;
logic                                   wlast_fifo_in_ready;
logic                                   wlast_fifo_out_valid;
logic                                   wlast_fifo_out_ready;
logic                                   wlast_fifo_in_vld_rdy;

logic [L2_ALIGN_R_ARB_SRC_NUM-1 : 0]    read_rtn_valids;
logic [L2_ALIGN_R_ARB_SRC_BITS-1: 0]    read_rtn_pre_index;
logic [L2_ALIGN_R_ARB_SRC_BITS-1: 0]    read_rtn_cur_index;
axi5_r_data_bus_t                       axi_rstl_r_rec;
logic                                   axi_rstl_rvalid;
logic                                   axi_rstl_rready;
logic                                   axi_rstl_rvld_rdy;

logic [L2_ALIGN_ARB_SRC_NUM-1   : 0]    bm_arb_valids;
logic [L2_ALIGN_ARB_IDX_BITS-1  : 0]    bm_arb_pre_index;
logic [L2_ALIGN_ARB_IDX_BITS-1  : 0]    bm_arb_cur_index;
logic [L2_ALIGN_ARB_SRC_NUM-1   : 0]    cache_arb_valids;
logic [L2_ALIGN_ARB_IDX_BITS-1  : 0]    cache_arb_pre_index;
logic [L2_ALIGN_ARB_IDX_BITS-1  : 0]    cache_arb_cur_index;
logic                                   bm_arb_valid;
logic                                   bm_arb_ready;
logic                                   cache_arb_valid;
logic                                   cache_arb_ready;
logic                                   align_tc_rstl_valid;
logic                                   align_tc_rstl_ready;
logic                                   align_tc_rstl_vld_rdy;
align_tagctrl_record_type               align_tc_rstl_in_rec;

logic                                   align_isched_rstl_valid;
logic                                   align_isched_rstl_ready;
align_isched_bm_record_type             align_isched_rstl_in_rec;

logic                                   align_iwdb_rstl_valid;
logic                                   align_iwdb_rstl_ready;
align_iwdb_write_record_type            align_iwdb_rstl_in_rec;

logic                                   memif_align_rstl_valid;
logic                                   memif_align_rstl_ready;
memif_align_record_type                 memif_align_out_rec;
logic [L2_IWDB_DEPTH-1          : 0]    iwdb_align_index_free;

logic                   [L2_NUM_RCTRL-1 : 0]    rctrl_align_rstl_valid;
logic                   [L2_NUM_RCTRL-1 : 0]    rctrl_align_rstl_ready;
memif_align_record_type [L2_NUM_RCTRL-1 : 0]    rctrl_align_out_rec;

logic               buffer_mode_25;
logic               buffer_mode_50;
logic               gc_cr_l2_persi_clr;
logic               gc_cr_l2_cfi_clr;
logic               is_cfg_flush;
logic               is_cfg_invld;
logic               is_cfg_flushinv;
logic               is_cfg_reduce_persist;
logic               is_cfg_rst_persist;
logic [15:0]        persis_time_unit_add;
logic [15:0]        persis_time_unit;
logic [20:0]        persis_time_cnt;
logic               persis_time_cnt_inc;
logic               is_cfg_req;
logic [ 6:0]        l2_align_idle_tmp;

logic               is_cfg_stall_flush         ;
logic               is_cfg_stall_invld         ;
logic               is_cfg_stall_flushinv      ;
logic               is_cfg_stall_rst_persist   ;
logic               is_cfg_stall_reduce_persist;
logic               is_cfg_pending_flush         ;
logic               is_cfg_pending_invld         ;
logic               is_cfg_pending_flushinv      ;
logic               is_cfg_pending_rst_persist   ;
logic               is_cfg_pending_reduce_persist;
logic               is_cfg_send_flush         ;
logic               is_cfg_send_invld         ;
logic               is_cfg_send_flushinv      ;
logic               is_cfg_send_rst_persist   ;
logic               is_cfg_send_reduce_persist;

logic               init_invalid_r0;
logic               init_invalid_r1;
logic               init_invalid;
logic               init_invalid_clr;
logic               init_invalid_send;
logic               init_invalid_busy;


localparam int unsigned L2_ALIGN_IDX_FIFO_WIDTH = $size(allocated_iwdb_idx) + $size(atomic_size) + $size(atomic_op) +1 +1;
localparam int unsigned L2_ALIGN_TC_TB_WIDTH    = $size(align_tagctrl_record_type   );
localparam int unsigned L2_ALIGN_ISCHED_TB_WIDTH= $size(align_isched_bm_record_type );
localparam int unsigned L2_ALIGN_IWDB_TB_WIDTH  = $size(align_iwdb_write_record_type);
localparam int unsigned L2_MEMIF_ALIGN_TB_WIDTH = $size(memif_align_record_type     );
localparam int unsigned L2_RCTRL_ALIGN_TB_WIDTH = $size(memif_align_record_type     );
                                                
logic [L2_ALIGN_IDX_FIFO_WIDTH-1 : 0]   idx_fifo_in_data;
logic [L2_ALIGN_IDX_FIFO_WIDTH-1 : 0]   idx_fifo_out_data;



// -------------------------------------------------------------------------------------------------
// AR-channel, including buffer mode and cross cacheline size
// -------------------------------------------------------------------------------------------------
// AR-channel input data timing buffer
gpc_gfx_timing_buffer_#(
    .BUFFER_TYPE (GPC_GFX_TIMING_BUFFER_RSTL),
    .WIDTH       (AXI5_AR_DATA_BUS_BITS     )
)i_timing_buffer_ar(
    .clk             (clk                   ),
    .resetn          (resetn                ),
    .tbuff_in_valid  (axi_slv_arvalid       ),
    .tbuff_in_enable (axi_slv_arready       ),
    .tbuff_in_data   (axi_slv_ar_rec        ),
    .tbuff_out_valid (axi_rstl_arvalid      ),
    .tbuff_out_enable(axi_rstl_arready      ),
    .tbuff_out_data  (axi_rstl_ar_rec       )
);

// generate buffer mode request
assign is_ar_bm_req = axi_rstl_ar_rec.user[9];

assign ar_bm_valid            = is_ar_bm_req ? axi_rstl_arvalid   : 'b0;
assign ar_bm_rec.instruction  = RD                    ;
assign ar_bm_rec.set          = axi_rstl_ar_rec.addr[L2_CACHELINE_BITS +: L2_NUM_SET_BITS];
assign ar_bm_rec.way          = buffer_mode_25 ? {2'b11, axi_rstl_ar_rec.addr[L2_CACHELINE_BITS+L2_NUM_SET_BITS]} :   // 6+[16]
                                buffer_mode_50 ? {1'b1 , axi_rstl_ar_rec.addr[L2_CACHELINE_BITS+L2_NUM_SET_BITS +: 2]} :    // 4+[17:16]
                                'b0;      // don't care
assign ar_bm_rec.start_beat   = axi_rstl_ar_rec.addr[7:6] ;
assign ar_bm_rec.blen         = axi_rstl_ar_rec.len       ;
assign ar_bm_rec.burst        = axi_rstl_ar_rec.burst     ;
assign ar_bm_rec.axid         = axi_rstl_ar_rec.id        ;
assign ar_bm_rec.iwdb_index   = 'b0;  // no used

// generate cacheline request
assign ar_cache_valid               = ~is_ar_bm_req ? axi_rstl_arvalid  : 'b0;
assign ar_cache_rec.instruction     = AXI_RD                    ;
assign ar_cache_rec.axid            = axi_rstl_ar_rec.id        ;
assign ar_cache_rec.addr            = axi_rstl_ar_rec.addr      ;
assign ar_cache_rec.blen            = axi_rstl_ar_rec.len       ;
assign ar_cache_rec.burst           = axi_rstl_ar_rec.burst     ;
assign ar_cache_rec.axcache         = axi_rstl_ar_rec.cache     ;
assign ar_cache_rec.persistence     = axi_rstl_ar_rec.user[6:5] ;
assign ar_cache_rec.prefetch_size   = axi_rstl_ar_rec.user[4]   ;
assign ar_cache_rec.iwdb_index      = 'b0;

// return ready to RSTL
assign axi_rstl_arready = is_ar_bm_req ? ar_bm_ready : ar_cache_ready;
// -------------------------------------------------------------------------------------------------
// AW-channel, including buffer mode, cross cacheline size and allocate IWDB index
// -------------------------------------------------------------------------------------------------
// AW-channel input data timing buffer
assign axi_rstl_awready = allocated_iwdb_valid;

gpc_gfx_timing_buffer_#(
    .BUFFER_TYPE (GPC_GFX_TIMING_BUFFER_RSTL),
    .WIDTH       (AXI5_AW_DATA_BUS_BITS     )
)i_timing_buffer_aw(
    .clk             (clk                   ),
    .resetn          (resetn                ),
    .tbuff_in_valid  (axi_slv_awvalid       ),
    .tbuff_in_enable (axi_slv_awready       ),
    .tbuff_in_data   (axi_slv_aw_rec        ),
    .tbuff_out_valid (axi_rstl_awvalid      ),
    .tbuff_out_enable(axi_rstl_awready      ),
    .tbuff_out_data  (axi_rstl_aw_rec       )
);

// allocate IWDB index
always_comb begin: p_iwdb_align_index_free
    for(int i=0; i<L2_IWDB_DEPTH; i++) begin
        if(iwdb_align_free_valid & (i == iwdb_align_free_index)) begin
            iwdb_align_index_free[i] = 1'b1;
        end
        else begin
            iwdb_align_index_free[i] = 1'b0;
        end
    end
end: p_iwdb_align_index_free

assign allocate_iwdb_valid = axi_rstl_awvalid & axi_idx_in_awready & idx_fifo_in_ready;

gc_l2_bank_idx_assign #(
    .NUM_INDICES (L2_IWDB_DEPTH     ),
    .INDEX_BITS  (L2_IWDB_INDEX_BITS),
    .SIZE_WIDTH  (L2_AXI_LEN_WIDTH  )
) i_gc_bank_l2_idx_assign (
    .clk                    (clk                    ),  // I
    .resetn                 (resetn                 ),  // I
    .idx_assign_idle        (idx_assign_idle        ),  // O
    .allocate_valid         (allocate_iwdb_valid    ),  // I
    .allocate_size          (axi_rstl_aw_rec.len    ),  // I
    .assigned_index_valid   (allocated_iwdb_valid   ),  // O
    .assigned_index         (allocated_iwdb_idx     ),  // O
    .index_freed_mask       (iwdb_align_index_free  )   // I
);

// control between two RSTL
assign axi_idx_in_awvalid   = allocated_iwdb_valid;
assign axi_idx_out_awready  = is_aw_bm_req ? (aw_bm_ready & wid_fifo_in_ready) : (aw_cache_ready & wid_fifo_in_ready);

// timing buffer after get IWDB index
gpc_gfx_timing_buffer_#(
    .BUFFER_TYPE (GPC_GFX_TIMING_BUFFER_RSTL                                ),
    .WIDTH       (AXI5_AW_DATA_BUS_BITS+$size(allocated_iwdb_idx)+1         )
)i_timing_buffer_aw_idx(
    .clk             (clk                                                   ),
    .resetn          (resetn                                                ),
    .tbuff_in_valid  (axi_idx_in_awvalid                                    ),
    .tbuff_in_enable (axi_idx_in_awready                                    ),
    .tbuff_in_data   ({axi_rstl_aw_rec, allocated_iwdb_idx, is_rstl_aa_req} ),
    .tbuff_out_valid (axi_idx_out_awvalid                                   ),
    .tbuff_out_enable(axi_idx_out_awready                                   ),
    .tbuff_out_data  ({axi_idx_out_aw_rec, axi_idx_awiwdb , is_idx_aa_req } )
);

// generate buffer mode request
assign is_aw_bm_req         = axi_idx_out_aw_rec.user[9];

// assign aw_bm_valid            = is_aw_bm_req   ? (axi_idx_out_awvalid & axi_idx_out_awready) : 'b0;
assign aw_bm_valid            = is_aw_bm_req   ? (axi_idx_out_awvalid & wid_fifo_in_ready) : 'b0;
assign aw_bm_rec.instruction  = is_idx_aa_req  ? AA : WR;
assign aw_bm_rec.set          = axi_idx_out_aw_rec.addr[L2_CACHELINE_BITS +: L2_NUM_SET_BITS]   ;
assign aw_bm_rec.way          = buffer_mode_25 ? {2'b11, axi_idx_out_aw_rec.addr[L2_CACHELINE_BITS+L2_NUM_SET_BITS]} :  // 6+[16]
                                buffer_mode_50 ? {1'b1 , axi_idx_out_aw_rec.addr[L2_CACHELINE_BITS+L2_NUM_SET_BITS +: 2]} : // 4+[17:16]
                                                 'b0;                       // don't care
assign aw_bm_rec.start_beat   = axi_idx_out_aw_rec.addr[7:6]    ;
assign aw_bm_rec.blen         = axi_idx_out_aw_rec.len          ;
assign aw_bm_rec.burst        = axi_idx_out_aw_rec.burst        ;
assign aw_bm_rec.axid         = axi_idx_out_aw_rec.id           ;
assign aw_bm_rec.iwdb_index   = axi_idx_awiwdb                  ;

// generate cacheline request
// assign aw_cache_valid               = ~is_aw_bm_req ? (axi_idx_out_awvalid & axi_idx_out_awready) : 'b0;
assign aw_cache_valid               = ~is_aw_bm_req ? (axi_idx_out_awvalid & wid_fifo_in_ready) : 'b0;
assign aw_cache_rec.instruction     = is_idx_aa_req ? AXI_AA : AXI_WR;
assign aw_cache_rec.axid            = axi_idx_out_aw_rec.id          ;
assign aw_cache_rec.addr            = axi_idx_out_aw_rec.addr        ;
assign aw_cache_rec.blen            = axi_idx_out_aw_rec.len         ;
assign aw_cache_rec.burst           = axi_idx_out_aw_rec.burst       ;
assign aw_cache_rec.axcache         = axi_idx_out_aw_rec.cache       ;
assign aw_cache_rec.persistence     = axi_idx_out_aw_rec.user[6:5]   ;
assign aw_cache_rec.prefetch_size   = axi_idx_out_aw_rec.user[4]     ;
assign aw_cache_rec.iwdb_index      = axi_idx_awiwdb                 ;

// generate atomic size and operation code
assign is_rstl_aa_req           = |axi_rstl_aw_rec.atop;
assign is_atomic_128            = axi_rstl_aw_rec.user[8];
assign is_atomic_wrap           = axi_rstl_aw_rec.user[7];
assign is_atomic_fp32           = axi_rstl_aw_rec.user[3];
assign is_atomic_64             = axi_rstl_aw_rec.user[2];
assign extended_atomic_opcode   = axi_rstl_aw_rec.user[1:0];

assign atomic_size = is_atomic_128 ? L2_AA_SIZE_128 : (is_atomic_64 ? L2_AA_SIZE_64 : L2_AA_SIZE_32);

always_comb begin: p_atomic_op
    if(is_atomic_fp32) begin                                        // atomic fp32
        if(extended_atomic_opcode == L2_AA_EXT_SUB) begin           // atomic sub; axi_rstl_aw_rec.atop[2:0] == L2_AA_ATOP_ADD
            atomic_op = L2_AA_OP_FSUB;
        end
        else if(axi_rstl_aw_rec.atop[2:0] == L2_AA_ATOP_SMAX) begin // atomic smax
            atomic_op = L2_AA_OP_FMAX;
        end
        else if(axi_rstl_aw_rec.atop[2:0] == L2_AA_ATOP_SMIN) begin // atomic smin
            atomic_op = L2_AA_OP_FMIN;
        end
        else if(axi_rstl_aw_rec.atop[2:0] == L2_AA_ATOP_ADD)  begin // atomic add
            atomic_op = L2_AA_OP_FADD;
        end
        else begin                                                  // atomic compare, atop == L2_AA_ATOP_COMP
            atomic_op = L2_AA_OP_FCMPXCHG;
        end
    end
    else begin        
        if(axi_rstl_aw_rec.atop == L2_AA_ATOP_SWAP) begin           // atomic swap
            atomic_op = L2_AA_OP_XCHG;
        end
        else if(axi_rstl_aw_rec.atop == L2_AA_ATOP_COMP) begin      // atomic compare
            atomic_op = L2_AA_OP_CMPXCHG;
        end
        else begin                                          
            if(extended_atomic_opcode == L2_AA_EXT_NORM) begin      // normal atomic opcode, fowllow AXI protocol
                case(axi_rstl_aw_rec.atop[2:0])
                    L2_AA_ATOP_ADD  : atomic_op = L2_AA_OP_ADD;     // atomic add
                    L2_AA_ATOP_EOR  : atomic_op = L2_AA_OP_XOR;     // atomic exclusive OR
                    L2_AA_ATOP_SMAX : atomic_op = L2_AA_OP_IMAX;    // atomic signed max
                    L2_AA_ATOP_SMIN : atomic_op = L2_AA_OP_IMIN;    // atomic signed min
                    L2_AA_ATOP_UMAX : atomic_op = L2_AA_OP_UMAX;    // atomic unsigned max
                    default: atomic_op = L2_AA_OP_UMIN;             // atomic unsigned min, 'b111
                endcase
            end
            else if(extended_atomic_opcode == L2_AA_EXT_SUB) begin  // atomic sub
                atomic_op = L2_AA_OP_SUB;
            end
            else if(extended_atomic_opcode == L2_AA_EXT_AND) begin  // atomic and
                atomic_op = L2_AA_OP_AND;
            end
            else begin                                              // atomic or
                atomic_op = L2_AA_OP_OR;
            end
        end
    end
end: p_atomic_op

// IWDB index FIFO
assign idx_fifo_in_valid = allocated_iwdb_valid;
assign idx_fifo_in_data  = {is_rstl_aa_req, is_atomic_wrap, atomic_op, atomic_size, allocated_iwdb_idx};
assign {iwdb_is_atomic, iwdb_atomic_wrap, iwdb_atomic_op, iwdb_atomic_size, iwdb_iwdb_index} = idx_fifo_out_data;
assign idx_fifo_out_ready = axi_rstl_w_rec.last & align_iwdb_rstl_vld_rdy & wlast_fifo_in_vld_rdy;

gpc_gfx_rpfifo_ #(
    .w                  (L2_ALIGN_IDX_FIFO_WIDTH),
    .d                  (L2_ALIGN_IDX_FIFO_DEPTH),
    .registered_enable  (1                      )
) i_fifo_iwdb_index(
    .clk                (clk                    ),  // I
    .resetn             (resetn                 ),  // I
    .fifo_in_valid      (idx_fifo_in_valid      ),  // I
    .fifo_in_enable     (idx_fifo_in_ready      ),  // O
    .fifo_in_data       (idx_fifo_in_data       ),  // I
    .fifo_out_valid     (idx_fifo_out_valid     ),  // O
    .fifo_out_enable    (idx_fifo_out_ready     ),  // I
    .fifo_out_data      (idx_fifo_out_data      )   // O
);

// -------------------------------------------------------------------------------------------------
// W-channel, pop index fifo and write IWDB
// -------------------------------------------------------------------------------------------------
// W-channel input data timing buffer
gpc_gfx_rpfifo_ #(
    .w                  (AXI5_W_DATA_BUS_BITS   ),
    .d                  (L2_ALIGN_W_FIFO_DEPTH  ),
    .registered_enable  (1                      ) 
) i_fifo_wdata (
    .clk                (clk                    ),  // I
    .resetn             (resetn                 ),  // I
    .fifo_in_valid      (axi_slv_wvalid         ),  // I
    .fifo_in_enable     (axi_slv_wready         ),  // O
    .fifo_in_data       (axi_slv_w_rec          ),  // I
    .fifo_out_valid     (axi_rstl_wvalid        ),  // O
    .fifo_out_enable    (axi_rstl_wready        ),  // I
    .fifo_out_data      (axi_rstl_w_rec         )   // O
);

// compress write data strobe for atomic operation
generate
    for(genvar IDX=0; IDX<(L2_AXI_BUS_WIDTH/8/4); IDX++) begin: g_gen_dwrod_active
        assign dword_active[IDX] = &axi_rstl_w_rec.strb[IDX*4 +: 4];
    end
endgenerate

// write IWDB
assign align_iwdb_rstl_valid    = idx_fifo_out_valid & axi_rstl_wvalid & wlast_fifo_in_ready;
assign align_iwdb_rstl_vld_rdy  = align_iwdb_rstl_valid & align_iwdb_rstl_ready;
assign align_iwdb_rstl_in_rec.atomic   = iwdb_is_atomic;

assign uncompress_wstrb         = iwdb_is_atomic ? {40'b0, iwdb_atomic_wrap, iwdb_atomic_size, iwdb_atomic_op, dword_active} : 
                                                axi_rstl_w_rec.strb;
assign {align_iwdb_rstl_in_rec.strb, align_iwdb_rstl_in_rec.data} = f_wd_compress(axi_rstl_w_rec.data, uncompress_wstrb, iwdb_is_atomic);

// write IWDB index 0 after overflow L2_IWDB_DEPTH
assign iwdb_index_ovf   = {1'b0, iwdb_iwdb_index} + {{L2_IWDB_INDEX_BITS-L2_AXI_LEN_WIDTH+1{1'b0}}, iwdb_index_offset};
assign align_iwdb_rstl_in_rec.iwdb_index = (iwdb_index_ovf >= L2_IWDB_DEPTH) ? iwdb_index_ovf-L2_IWDB_DEPTH : iwdb_index_ovf[L2_IWDB_INDEX_BITS-1:0];

assign axi_rstl_wready  = axi_rstl_w_rec.last ? (align_iwdb_rstl_vld_rdy & wlast_fifo_in_vld_rdy) : align_iwdb_rstl_vld_rdy;

always_ff @(posedge clk or negedge resetn) begin: p_iwdb_index_offset
    if(!resetn) begin
        iwdb_index_offset <= {L2_AXI_LEN_WIDTH{1'b0}};
    end
    else if(axi_rstl_wready & axi_rstl_w_rec.last) begin
        iwdb_index_offset <= {L2_AXI_LEN_WIDTH{1'b0}};
    end
    else if(axi_rstl_wready) begin
        iwdb_index_offset <= iwdb_index_offset + 1'b1;
    end
end: p_iwdb_index_offset

// write IWDB timing buffer
gpc_gfx_timing_buffer_#(
    .BUFFER_TYPE (GPC_GFX_TIMING_BUFFER_RSTL),
    .WIDTH       (L2_ALIGN_IWDB_TB_WIDTH    )
) i_tb_align_iwdb (
    .clk             (clk                   ),
    .resetn          (resetn                ),
    .tbuff_in_valid  (align_iwdb_rstl_valid ),
    .tbuff_in_enable (align_iwdb_rstl_ready ),
    .tbuff_in_data   (align_iwdb_rstl_in_rec),
    .tbuff_out_valid (align_iwdb_valid      ),
    .tbuff_out_enable(align_iwdb_ready      ),
    .tbuff_out_data  (align_iwdb_rec        )
);

// -------------------------------------------------------------------------------------------------
// B-channel, generate write response after send out write request and write data
// -------------------------------------------------------------------------------------------------
// write last fifo, buffer wlast for sync between awid and wlast
assign wlast_fifo_in_valid  = idx_fifo_out_valid & (axi_rstl_wvalid & axi_rstl_w_rec.last) & align_iwdb_rstl_ready;
assign wlast_fifo_out_ready = axi_rstl_bvld_rdy;
assign wlast_fifo_in_vld_rdy= wlast_fifo_in_valid & wlast_fifo_in_ready;

gpc_gfx_rpfifo_ #(
    .w                  (1                      ),
    .d                  (L2_ALIGN_WL_FIFO_DEPTH ),
    .registered_enable  (1                      ) 
) i_fifo_wlast (
    .clk                (clk                    ),  // I
    .resetn             (resetn                 ),  // I
    .fifo_in_valid      (wlast_fifo_in_valid    ),  // I
    .fifo_in_enable     (wlast_fifo_in_ready    ),  // O
    .fifo_in_data       (1'b1                   ),  // I
    .fifo_out_valid     (wlast_fifo_out_valid   ),  // O
    .fifo_out_enable    (wlast_fifo_out_ready   ),  // I
    .fifo_out_data      (                       )   // O, no used
);




// WID FIFO; get WID after send request to TAGCTRL
assign aw_ready_2_wid_fifo  = is_aw_bm_req ? aw_bm_ready : aw_cache_ready;
assign wid_fifo_in_valid    = axi_idx_out_awvalid & aw_ready_2_wid_fifo;
assign wid_fifo_in_data     = axi_idx_out_aw_rec.id;
assign wid_fifo_out_ready   = axi_rstl_bvld_rdy;

gpc_gfx_rpfifo_ #(
    .w                  (L2_AXI_ID_WIDTH        ),
    .d                  (L2_ALIGN_WID_FIFO_DEPTH),
    .registered_enable  (1                      ) 
) i_fifo_wid (
    .clk                (clk                    ),  // I
    .resetn             (resetn                 ),  // I
    .fifo_in_valid      (wid_fifo_in_valid      ),  // I
    .fifo_in_enable     (wid_fifo_in_ready      ),  // O
    .fifo_in_data       (wid_fifo_in_data       ),  // I
    .fifo_out_valid     (wid_fifo_out_valid     ),  // O
    .fifo_out_enable    (wid_fifo_out_ready     ),  // I
    .fifo_out_data      (axi_rstl_bid           )   // O
);

// write response output data timing buffer
assign axi_rstl_bvalid  = wlast_fifo_out_valid & wid_fifo_out_valid;
assign axi_rstl_bvld_rdy= axi_rstl_bvalid & axi_rstl_bready;
assign axi_slv_b_rec.resp = 'b0;

gpc_gfx_timing_buffer_#(
    .BUFFER_TYPE (GPC_GFX_TIMING_BUFFER_RSTL),
    .WIDTH       (L2_AXI_ID_WIDTH           )
) i_timing_buffer_b (
    .clk             (clk                   ),
    .resetn          (resetn                ),
    .tbuff_in_valid  (axi_rstl_bvalid       ),
    .tbuff_in_enable (axi_rstl_bready       ),
    .tbuff_in_data   (axi_rstl_bid          ),
    .tbuff_out_valid (axi_slv_bvalid        ),
    .tbuff_out_enable(axi_slv_bready        ),
    .tbuff_out_data  (axi_slv_b_rec.id      )
);

// -------------------------------------------------------------------------------------------------
// R-channel, pop index fifo and write IWDB
// -------------------------------------------------------------------------------------------------
// read return data timing buffer
generate
    for(genvar RC=0; RC<L2_NUM_RCTRL; RC++) begin: g_rctrl_rd_rtn_tb
        assign rctrl_align_rstl_ready[RC] = axi_rstl_rvld_rdy & (read_rtn_cur_index == RC);

        gpc_gfx_rpfifo_ #(
            .w                  (L2_RCTRL_ALIGN_TB_WIDTH    ),
            .d                  (L2_ALIGN_RTN_FIFO_DEPTH    ),
            .registered_enable  (1                          ) 
        ) i_rc_read_rtn_fifo (
            .clk                (clk                        ),  // I
            .resetn             (resetn                     ),  // I
            .fifo_in_valid      (rctrl_align_valid     [RC] ),  // I
            .fifo_in_enable     (rctrl_align_ready     [RC] ),  // O
            .fifo_in_data       (rctrl_align_rec       [RC] ),  // I
            .fifo_out_valid     (rctrl_align_rstl_valid[RC] ),  // O
            .fifo_out_enable    (rctrl_align_rstl_ready[RC] ),  // I
            .fifo_out_data      (rctrl_align_out_rec   [RC] )   // O
        );

    end
endgenerate


gpc_gfx_timing_buffer_#(
    .BUFFER_TYPE (GPC_GFX_TIMING_BUFFER_RSTL    ),
    .WIDTH       (L2_MEMIF_ALIGN_TB_WIDTH       )
)i_tb_memif_align_rd_rtn(
    .clk             (clk                       ),
    .resetn          (resetn                    ),
    .tbuff_in_valid  (memif_align_valid         ),
    .tbuff_in_enable (memif_align_ready         ),
    .tbuff_in_data   (memif_align_rec           ),
    .tbuff_out_valid (memif_align_rstl_valid    ),
    .tbuff_out_enable(memif_align_rstl_ready    ),
    .tbuff_out_data  (memif_align_out_rec       )
);

// read return data arbiter
assign read_rtn_valids = {memif_align_rstl_valid, rctrl_align_rstl_valid};

gpc_round_robin_index_arch1_ #(
    .width          (L2_ALIGN_R_ARB_SRC_NUM ),
    .hold_previous  (1'b0                   )
) i_align_read_rtn_rr (
    .valids         (read_rtn_valids        ),
    .previous_index (read_rtn_pre_index     ),
    .next_index     (read_rtn_cur_index     )
);

always_ff @(posedge clk or negedge resetn) begin: p_read_rtn_pre_index
    if(!resetn) begin
        read_rtn_pre_index <= 'b0;
    end
    else if(axi_rstl_rvld_rdy & axi_rstl_r_rec.last) begin
        read_rtn_pre_index <= read_rtn_cur_index;
    end
    else if(axi_rstl_rvld_rdy) begin    // current index has highest priority for reduce interleave
        read_rtn_pre_index <= (read_rtn_cur_index == 'b0) ? L2_NUM_RCTRL : (read_rtn_cur_index - 1'b1);
    end
end: p_read_rtn_pre_index

// read response output data timing buffer
assign axi_rstl_rvld_rdy    = axi_rstl_rvalid & axi_rstl_rready;
assign memif_align_rstl_ready = axi_rstl_rvld_rdy & (read_rtn_cur_index == L2_NUM_RCTRL);

// read return data select
always_comb begin: p_axi_rd_rtn
    if(read_rtn_cur_index < L2_NUM_RCTRL) begin
        axi_rstl_rvalid     = rctrl_align_rstl_valid[read_rtn_cur_index];
        axi_rstl_r_rec.data = rctrl_align_out_rec[read_rtn_cur_index].data;
        axi_rstl_r_rec.id   = rctrl_align_out_rec[read_rtn_cur_index].axid;
        axi_rstl_r_rec.last = rctrl_align_out_rec[read_rtn_cur_index].last;
    end
    else begin
        axi_rstl_rvalid     = memif_align_rstl_valid;
        axi_rstl_r_rec.data = memif_align_out_rec.data;
        axi_rstl_r_rec.id   = memif_align_out_rec.axid;
        axi_rstl_r_rec.last = memif_align_out_rec.last;
    end
end: p_axi_rd_rtn

assign axi_rstl_r_rec.resp = 'b0;

gpc_gfx_timing_buffer_#(
    .BUFFER_TYPE (GPC_GFX_TIMING_BUFFER_RSTL),
    .WIDTH       (AXI5_R_DATA_BUS_BITS      )
)i_timing_buffer_r(
    .clk             (clk                   ),
    .resetn          (resetn                ),
    .tbuff_in_valid  (axi_rstl_rvalid       ),
    .tbuff_in_enable (axi_rstl_rready       ),
    .tbuff_in_data   (axi_rstl_r_rec        ),
    .tbuff_out_valid (axi_slv_rvalid        ),
    .tbuff_out_enable(axi_slv_rready        ),
    .tbuff_out_data  (axi_slv_r_rec         )
);

// -------------------------------------------------------------------------------------------------
// buffer request and cacheline request arbiter
// -------------------------------------------------------------------------------------------------
// buffer mode request arbiter
assign bm_arb_valids    = {aw_bm_valid, ar_bm_valid};
assign bm_arb_valid     = |bm_arb_valids;
assign bm_arb_ready     = align_isched_rstl_ready;
assign aw_bm_ready      =  bm_arb_cur_index & bm_arb_ready;
assign ar_bm_ready      = ~bm_arb_cur_index & bm_arb_ready;

gpc_round_robin_index_arch1_ #(
    .width          (L2_ALIGN_ARB_SRC_NUM   ),
    .hold_previous  (1'b0                   )
) i_align_bm_req_rr (
    .valids         (bm_arb_valids          ),
    .previous_index (bm_arb_pre_index       ),
    .next_index     (bm_arb_cur_index       )
);

always_ff @(posedge clk or negedge resetn) begin: p_bm_arb_pre_index
    if(!resetn) begin
        bm_arb_pre_index <= 'b0;
    end
    else if(bm_arb_valid & bm_arb_ready) begin
        bm_arb_pre_index <= bm_arb_cur_index;
    end
end: p_bm_arb_pre_index

assign align_isched_rstl_valid  = bm_arb_cur_index ? (aw_bm_valid & bm_arb_ready) : ar_bm_valid  ;
assign align_isched_rstl_in_rec = bm_arb_cur_index ? aw_bm_rec   : ar_bm_rec    ;

// output data timing buffer
gpc_gfx_timing_buffer_#(
    .BUFFER_TYPE (GPC_GFX_TIMING_BUFFER_RSTL    ),
    .WIDTH       (L2_ALIGN_ISCHED_TB_WIDTH      )
)i_tb_align_isched(
    .clk             (clk                       ),
    .resetn          (resetn                    ),
    .tbuff_in_valid  (align_isched_rstl_valid   ),
    .tbuff_in_enable (align_isched_rstl_ready   ),
    .tbuff_in_data   (align_isched_rstl_in_rec  ),
    .tbuff_out_valid (align_isched_bm_valid     ),
    .tbuff_out_enable(align_isched_bm_ready     ),
    .tbuff_out_data  (align_isched_bm_rec       )
);

// cacheline request arbiter
assign cache_arb_valids     = {aw_cache_valid, ar_cache_valid};
assign cache_arb_valid      = (|cache_arb_valids) & init_invalid_send;
assign cache_arb_ready      = align_tc_rstl_ready & (~(init_invalid | is_cfg_req));
assign aw_cache_ready       =  cache_arb_cur_index & cache_arb_ready & (~is_cfg_req);
assign ar_cache_ready       = ~cache_arb_cur_index & cache_arb_ready & (~is_cfg_req);

gpc_round_robin_index_arch1_ #(
    .width          (L2_ALIGN_ARB_SRC_NUM   ),
    .hold_previous  (1'b0                   )
) i_align_cache_req_rr (
    .valids         (cache_arb_valids       ),
    .previous_index (cache_arb_pre_index    ),
    .next_index     (cache_arb_cur_index    )
);

always_ff @(posedge clk or negedge resetn) begin: p_cache_arb_pre_index
    if(!resetn) begin
        cache_arb_pre_index <= 'b0;
    end
    else if(cache_arb_valid & cache_arb_ready) begin
        cache_arb_pre_index <= cache_arb_cur_index;
    end
end: p_cache_arb_pre_index

// insert CFG_INVALID after reset release
assign align_tc_rstl_vld_rdy = align_tc_rstl_valid & align_tc_rstl_ready;
assign init_invalid_clr = init_invalid & align_tc_rstl_vld_rdy & (align_tc_rstl_in_rec.instruction == CFG_INVALID);
assign init_invalid_busy= init_invalid_r0 | init_invalid_r1 | init_invalid | (~init_invalid_send);

always_ff @(posedge clk or negedge resetn) begin: p_init_invalid
    if(!resetn) begin
        init_invalid_r0     <= 1'b0;
        init_invalid_r1     <= 1'b0;
        init_invalid        <= 1'b0;
    end
    else if(~init_invalid_send) begin
        if(init_invalid_clr) begin
            init_invalid_r0 <= 1'b0;
            init_invalid_r1 <= 1'b0;
            init_invalid    <= 1'b0;
        end
        else begin
            init_invalid_r0 <= 1'b1;
            init_invalid_r1 <= init_invalid_r0;
            init_invalid    <= init_invalid_r1;
        end
    end
end: p_init_invalid

always_ff @(posedge clk or negedge resetn) begin: p_init_invalid_send
    if(~resetn) begin
        init_invalid_send <= 1'b0;
    end
    else if(init_invalid_clr) begin
        init_invalid_send <= 1'b1;
    end
end: p_init_invalid_send
    

// insert CFG instruction request
assign is_cfg_req = is_cfg_pending_flush | is_cfg_pending_invld | is_cfg_pending_flushinv | 
                    is_cfg_pending_reduce_persist | is_cfg_pending_rst_persist;
assign align_tc_rstl_valid = init_invalid        ? 1'b1 :
                             ~init_invalid_send  ? 1'b0 :
                             is_cfg_req          ? 1'b1 : 
                             cache_arb_cur_index ? (aw_cache_valid & cache_arb_ready)   : ar_cache_valid;
assign align_tc_rstl_in_rec.instruction    = init_invalid                  ? CFG_INVALID                : 
                                             is_cfg_pending_flush          ? CFG_FLUSH                  :
                                             is_cfg_pending_invld          ? CFG_INVALID                :
                                             is_cfg_pending_flushinv       ? CFG_FLUSH_INVALID          :
                                             is_cfg_pending_rst_persist    ? CFG_RST_PERSIST            :
                                             is_cfg_pending_reduce_persist ? CFG_REDUCE_PERSIST         :
                                             cache_arb_cur_index           ? aw_cache_rec.instruction   :
                                                                             ar_cache_rec.instruction   ;

assign align_tc_rstl_in_rec.axid           = (is_cfg_req | init_invalid) ? 'b0 : cache_arb_cur_index ? aw_cache_rec.axid         : ar_cache_rec.axid         ;
assign align_tc_rstl_in_rec.addr           = (is_cfg_req | init_invalid) ? 'b0 : cache_arb_cur_index ? aw_cache_rec.addr         : ar_cache_rec.addr         ;
assign align_tc_rstl_in_rec.iwdb_index     = (is_cfg_req | init_invalid) ? 'b0 : cache_arb_cur_index ? aw_cache_rec.iwdb_index   : ar_cache_rec.iwdb_index   ;
assign align_tc_rstl_in_rec.blen           = (is_cfg_req | init_invalid) ? 'b0 : cache_arb_cur_index ? aw_cache_rec.blen         : ar_cache_rec.blen         ;
assign align_tc_rstl_in_rec.burst          = (is_cfg_req | init_invalid) ? 'b0 : cache_arb_cur_index ? aw_cache_rec.burst        : ar_cache_rec.burst        ;
assign align_tc_rstl_in_rec.axcache        = (is_cfg_req | init_invalid) ? 'b0 : cache_arb_cur_index ? aw_cache_rec.axcache      : ar_cache_rec.axcache      ;
assign align_tc_rstl_in_rec.persistence    = (is_cfg_req | init_invalid) ? 'b0 : cache_arb_cur_index ? aw_cache_rec.persistence  : ar_cache_rec.persistence  ;
assign align_tc_rstl_in_rec.prefetch_size  = (is_cfg_req | init_invalid) ? 'b0 : cache_arb_cur_index ? aw_cache_rec.prefetch_size: ar_cache_rec.prefetch_size;

// output data timing buffer
gpc_gfx_timing_buffer_#(
    .BUFFER_TYPE (GPC_GFX_TIMING_BUFFER_RSTL),
    .WIDTH       (L2_ALIGN_TC_TB_WIDTH      )
)i_tb_align_tagctrl(
    .clk             (clk                   ),
    .resetn          (resetn                ),
    .tbuff_in_valid  (align_tc_rstl_valid   ),
    .tbuff_in_enable (align_tc_rstl_ready   ),
    .tbuff_in_data   (align_tc_rstl_in_rec  ),
    .tbuff_out_valid (align_tagctrl_valid   ),
    .tbuff_out_enable(align_tagctrl_ready   ),
    .tbuff_out_data  (align_tagctrl_record  )
);


// -------------------------------------------------------------------------------------------------
// configure register
// -------------------------------------------------------------------------------------------------
assign buffer_mode_25 = (gc_cr_l2_buffer_mode_percentage == 2'b01) ? 1'b1 : 1'b0;
assign buffer_mode_50 = (gc_cr_l2_buffer_mode_percentage == 2'b10) ? 1'b1 : 1'b0;


// CFI operation
assign gc_cr_l2_persi_clr   = gc_cr_l2_cmd_notify & gc_cr_l2_cmd_persistence_rst_all;
assign gc_cr_l2_cfi_clr     = gc_cr_l2_cmd_notify & gc_cr_l2_cmd_cfi_clr;

assign is_cfg_flush     = gc_cr_l2_cfi_operation_notify & (gc_cr_l2_cfi_operation == 2'b01);
assign is_cfg_invld     = gc_cr_l2_cfi_operation_notify & (gc_cr_l2_cfi_operation == 2'b00);
assign is_cfg_flushinv  = gc_cr_l2_cfi_operation_notify & (gc_cr_l2_cfi_operation == 2'b10);

// configure operation pending
assign is_cfg_pending_flush         = is_cfg_flush          | is_cfg_stall_flush         ;
assign is_cfg_pending_invld         = is_cfg_invld          | is_cfg_stall_invld         ;
assign is_cfg_pending_flushinv      = is_cfg_flushinv       | is_cfg_stall_flushinv      ;
assign is_cfg_pending_rst_persist   = is_cfg_rst_persist    | is_cfg_stall_rst_persist   ;
assign is_cfg_pending_reduce_persist= is_cfg_reduce_persist | is_cfg_stall_reduce_persist;

assign is_cfg_send_flush         =align_tc_rstl_vld_rdy && (align_tc_rstl_in_rec.instruction == CFG_FLUSH         );
assign is_cfg_send_invld         =align_tc_rstl_vld_rdy && (align_tc_rstl_in_rec.instruction == CFG_INVALID       ) & (~init_invalid);
assign is_cfg_send_flushinv      =align_tc_rstl_vld_rdy && (align_tc_rstl_in_rec.instruction == CFG_FLUSH_INVALID );
assign is_cfg_send_rst_persist   =align_tc_rstl_vld_rdy && (align_tc_rstl_in_rec.instruction == CFG_RST_PERSIST   );
assign is_cfg_send_reduce_persist=align_tc_rstl_vld_rdy && (align_tc_rstl_in_rec.instruction == CFG_REDUCE_PERSIST);

always @(posedge clk or negedge resetn) begin
    if(!resetn) begin
        is_cfg_stall_flush          <= 1'b0;
        is_cfg_stall_invld          <= 1'b0;
        is_cfg_stall_flushinv       <= 1'b0;
        is_cfg_stall_rst_persist    <= 1'b0;
        is_cfg_stall_reduce_persist <= 1'b0;
    end
    else begin
        if(is_cfg_flush & ~(is_cfg_send_flush))
            is_cfg_stall_flush          <= 1'b1;
        else if(is_cfg_stall_flush & is_cfg_send_flush)
            is_cfg_stall_flush          <= 1'b0;

        if(is_cfg_invld & ~(is_cfg_send_invld))
            is_cfg_stall_invld          <= 1'b1;
        else if(is_cfg_stall_invld & is_cfg_send_invld)
            is_cfg_stall_invld          <= 1'b0;

        if(is_cfg_flushinv & ~(is_cfg_send_flushinv))
            is_cfg_stall_flushinv       <= 1'b1;
        else if(is_cfg_stall_flushinv & is_cfg_send_flushinv)
            is_cfg_stall_flushinv       <= 1'b0;

        if(is_cfg_rst_persist & ~(is_cfg_send_rst_persist))
            is_cfg_stall_rst_persist    <= 1'b1;
        else if(is_cfg_stall_rst_persist & is_cfg_send_rst_persist)
            is_cfg_stall_rst_persist    <= 1'b0;

        if(is_cfg_reduce_persist & ~(is_cfg_send_reduce_persist))
            is_cfg_stall_reduce_persist <= 1'b1;
        else if(is_cfg_stall_reduce_persist & is_cfg_send_reduce_persist)
            is_cfg_stall_reduce_persist <= 1'b0;
    end
end

always_ff @(posedge clk or negedge resetn) begin: p_cr_l2_cfi_complete
    if(!resetn) begin
        gc_cr_l2_cfi_status_l2b_finish <= 1'b1;
    end
    else if(gc_cr_l2_cfi_clr | gc_cr_l2_cfi_operation_notify) begin
        gc_cr_l2_cfi_status_l2b_finish <= 1'b0;
    end
    else if(tagctrl_align_cfi_complete) begin
        gc_cr_l2_cfi_status_l2b_finish <= 1'b1;
    end
end: p_cr_l2_cfi_complete

// persistence update
// reduce persistence per gc_cr_l2_persistence_reduce_threshold*L2_PERSIS_TIME_UNIT cycle
assign persis_time_unit_add = persis_time_unit + 16'b1;
assign persis_time_cnt_inc  = (persis_time_unit_add == L2_PERSIS_TIME_UNIT) ? 1'b1 : 1'b0;

always_ff @(posedge clk or negedge resetn) begin: p_persis_time_unit
    if(!resetn) begin
        persis_time_unit <= 'b0;
    end
    else if(gc_cr_l2_persistence_reduce_enable) begin
        if(persis_time_cnt_inc) begin
            persis_time_unit <= 'b0;
        end
        else begin
            persis_time_unit <= persis_time_unit_add;
        end
    end
end: p_persis_time_unit

assign is_cfg_reduce_persist = (gc_cr_l2_persistence_reduce_enable & (persis_time_cnt == gc_cr_l2_persistence_reduce_threshold));
assign is_cfg_rst_persist    = gc_cr_l2_persi_clr;

always_ff @(posedge clk or negedge resetn) begin: p_persis_time_cnt
    if(!resetn) begin
        persis_time_cnt <= 'b0;
    end
    else if(gc_cr_l2_persistence_reduce_enable) begin
        if(is_cfg_reduce_persist) begin
            persis_time_cnt <= 'b0;
        end
        else if(persis_time_cnt_inc) begin
            persis_time_cnt <= persis_time_cnt + 1'b1;
        end
    end
end: p_persis_time_cnt


// -------------------------------------------------------------------------------------------------
// idle
// -------------------------------------------------------------------------------------------------
// axi input/output, input-rstl valid
assign l2_align_idle_tmp[0] = ~axi_slv_arvalid & ~axi_slv_awvalid & ~axi_slv_wvalid & ~axi_slv_rvalid & ~axi_slv_bvalid;
assign l2_align_idle_tmp[1] = ~axi_rstl_arvalid & ~axi_rstl_awvalid & ~axi_idx_out_awvalid & ~axi_rstl_wvalid;
// to tagctrl/isched/iwdb output valid
assign l2_align_idle_tmp[2] = ~init_invalid_busy & ~align_tc_rstl_valid & 
                              ~align_tagctrl_valid & ~align_isched_bm_valid & ~align_iwdb_valid;
// from rctrl, tagctrl input, input-rstl valid
assign l2_align_idle_tmp[3] = ~(|rctrl_align_valid) & ~memif_align_valid;
assign l2_align_idle_tmp[4] = ~(|rctrl_align_rstl_valid) & ~memif_align_rstl_valid;
// index assign path, wid path valid
assign l2_align_idle_tmp[5] = ~idx_fifo_out_valid & idx_assign_idle;
assign l2_align_idle_tmp[6] = ~wid_fifo_out_valid & ~wlast_fifo_out_valid;

always_ff @(posedge clk or negedge resetn) begin: p_l2_align_idle
    if(!resetn) begin
        l2_align_idle <= 1'b0;
    end
    else if(&l2_align_idle_tmp) begin
        l2_align_idle <= 1'b1;
    end
    else begin
        l2_align_idle <= 1'b0;
    end
end: p_l2_align_idle

// -------------------------------------------------------------------------------------------------
// performance counter
// -------------------------------------------------------------------------------------------------
localparam  L2_AXI_BL0 = 2'b00;
localparam  L2_AXI_BL1 = 2'b01;
localparam  L2_AXI_BL2 = 2'b10;
localparam  L2_AXI_BL3 = 2'b11;

logic                       axi_rstl_ar_vld_rdy;
logic                       axi_rstl_aw_vld_rdy;
logic                       axi_rstl_aw_atomic;
logic [L2_AXI_ID_WIDTH-1:0] l2b_perf_lat_arid;
logic [L2_AXI_ID_WIDTH-1:0] l2b_perf_lat_awid;
logic [L2_AXI_ID_WIDTH-1:0] l2b_perf_lat_aaid;
logic                       l2b_fromaxi_smp_read_set1   ;
logic                       l2b_fromaxi_smp_read_set2   ;
logic                       l2b_fromaxi_smp_read_set    ;
logic                       l2b_fromaxi_smp_read_clr    ;
logic                       l2b_fromaxi_smp_write_set1  ;
logic                       l2b_fromaxi_smp_write_set2  ;
logic                       l2b_fromaxi_smp_write_set   ;
logic                       l2b_fromaxi_smp_write_clr   ;
logic                       l2b_fromaxi_smp_atomic_set1 ;
logic                       l2b_fromaxi_smp_atomic_set2 ;
logic                       l2b_fromaxi_smp_atomic_set  ;
logic                       l2b_fromaxi_smp_atomic_clr  ;
logic                       l2b_fromaxi_atomic_brtn_set ;
logic                       l2b_fromaxi_atomic_rrtn_set ;
logic                       l2b_fromaxi_atomic_brtn     ;
logic                       l2b_fromaxi_atomic_rrtn     ;
logic                       l2b_fromaxi_atomic_complete ;

assign axi_rstl_ar_vld_rdy = axi_rstl_arvalid & axi_rstl_arready;
assign axi_rstl_aw_vld_rdy = axi_rstl_awvalid & axi_rstl_awready;
assign axi_rstl_aw_atomic  = |axi_rstl_aw_rec.atop;

assign l2b_fromaxi_ar_wl        = axi_rstl_ar_vld_rdy ;
assign l2b_fromaxi_ar_bl_eq0_wl = axi_rstl_ar_vld_rdy && (axi_rstl_ar_rec.len == L2_AXI_BL0);
assign l2b_fromaxi_ar_bl_eq1_wl = axi_rstl_ar_vld_rdy && (axi_rstl_ar_rec.len == L2_AXI_BL1);
assign l2b_fromaxi_ar_bl_eq2_wl = axi_rstl_ar_vld_rdy && (axi_rstl_ar_rec.len == L2_AXI_BL2);
assign l2b_fromaxi_ar_bl_eq3_wl = axi_rstl_ar_vld_rdy && (axi_rstl_ar_rec.len == L2_AXI_BL3);
assign l2b_fromaxi_ar_bp        = axi_rstl_arvalid    &  ~axi_rstl_arready;

assign l2b_toaxi_r_wl           = axi_rstl_rvalid     &   axi_rstl_rready ;
assign l2b_toaxi_r_bp           = axi_rstl_rvalid     &  ~axi_rstl_rready ;

assign l2b_fromaxi_aw_wl        = axi_rstl_aw_vld_rdy ;
assign l2b_fromaxi_aw_bl_eq0_wl = axi_rstl_aw_vld_rdy && (axi_rstl_aw_rec.len == L2_AXI_BL0);
assign l2b_fromaxi_aw_bl_eq1_wl = axi_rstl_aw_vld_rdy && (axi_rstl_aw_rec.len == L2_AXI_BL1);
assign l2b_fromaxi_aw_bl_eq2_wl = axi_rstl_aw_vld_rdy && (axi_rstl_aw_rec.len == L2_AXI_BL2);
assign l2b_fromaxi_aw_bl_eq3_wl = axi_rstl_aw_vld_rdy && (axi_rstl_aw_rec.len == L2_AXI_BL3);
assign l2b_fromaxi_aw_bp        = axi_rstl_awvalid    &  ~axi_rstl_awready;                  

assign l2b_fromaxi_w_wl         = axi_rstl_wvalid     &   axi_rstl_wready ;
assign l2b_fromaxi_w_bp         = axi_rstl_wvalid     &  ~axi_rstl_wready ;

assign l2b_fromaxi_smp_read_set1   = ~l2b_fromaxi_smp_read_req_sum   & axi_rstl_ar_vld_rdy;
assign l2b_fromaxi_smp_read_set2   =  l2b_fromaxi_smp_read_req_sum   & axi_rstl_rvld_rdy   & axi_rstl_r_rec.last & (axi_rstl_r_rec.id == l2b_perf_lat_arid) &  axi_rstl_ar_vld_rdy;
assign l2b_fromaxi_smp_read_clr    =  l2b_fromaxi_smp_read_req_sum   & axi_rstl_rvld_rdy   & axi_rstl_r_rec.last & (axi_rstl_r_rec.id == l2b_perf_lat_arid) & ~axi_rstl_ar_vld_rdy;

assign l2b_fromaxi_smp_write_set1  = ~l2b_fromaxi_smp_write_req_sum  & axi_rstl_aw_vld_rdy & ~axi_rstl_aw_atomic;
assign l2b_fromaxi_smp_write_set2  =  l2b_fromaxi_smp_write_req_sum  & axi_rstl_bvld_rdy   & (axi_rstl_bid == l2b_perf_lat_awid) &  (axi_rstl_aw_vld_rdy & ~axi_rstl_aw_atomic);
assign l2b_fromaxi_smp_write_clr   =  l2b_fromaxi_smp_write_req_sum  & axi_rstl_bvld_rdy   & (axi_rstl_bid == l2b_perf_lat_awid) & ~(axi_rstl_aw_vld_rdy & ~axi_rstl_aw_atomic);

assign l2b_fromaxi_atomic_brtn_set =  l2b_fromaxi_smp_atomic_req_sum & axi_rstl_bvld_rdy   & (axi_rstl_bid == l2b_perf_lat_aaid);
assign l2b_fromaxi_atomic_rrtn_set =  l2b_fromaxi_smp_atomic_req_sum & axi_rstl_rvld_rdy   & axi_rstl_r_rec.last & (axi_rstl_r_rec.id == l2b_perf_lat_aaid);
assign l2b_fromaxi_atomic_complete = (l2b_fromaxi_atomic_brtn_set | l2b_fromaxi_atomic_brtn) & (l2b_fromaxi_atomic_rrtn_set | l2b_fromaxi_atomic_rrtn);

assign l2b_fromaxi_smp_atomic_set1 = ~l2b_fromaxi_smp_atomic_req_sum &   axi_rstl_aw_vld_rdy & axi_rstl_aw_atomic ;
assign l2b_fromaxi_smp_atomic_set2 =  l2b_fromaxi_atomic_complete    &  (axi_rstl_aw_vld_rdy & axi_rstl_aw_atomic);
assign l2b_fromaxi_smp_atomic_clr  =  l2b_fromaxi_atomic_complete    & ~(axi_rstl_aw_vld_rdy & axi_rstl_aw_atomic);

assign l2b_fromaxi_smp_read_set   = l2b_fromaxi_smp_read_set1   | l2b_fromaxi_smp_read_set2  ;
assign l2b_fromaxi_smp_write_set  = l2b_fromaxi_smp_write_set1  | l2b_fromaxi_smp_write_set2 ;
assign l2b_fromaxi_smp_atomic_set = l2b_fromaxi_smp_atomic_set1 | l2b_fromaxi_smp_atomic_set2;

always_ff @(posedge clk or negedge resetn) begin: p_perf_latency
    if(!resetn) begin
        l2b_fromaxi_smp_read_req_num        <= 'b0;
        l2b_fromaxi_smp_read_req_sum        <= 'b0;
        l2b_fromaxi_smp_write_req_num       <= 'b0;
        l2b_fromaxi_smp_write_req_sum       <= 'b0;
        l2b_fromaxi_smp_atomic_req_num      <= 'b0;
        l2b_fromaxi_smp_atomic_req_sum      <= 'b0;
        l2b_fromaxi_atomic_brtn             <= 'b0;
        l2b_fromaxi_atomic_rrtn             <= 'b0;
        l2b_perf_lat_arid                   <= 'b0;
        l2b_perf_lat_awid                   <= 'b0;
        l2b_perf_lat_aaid                   <= 'b0;
    end
    else begin
        l2b_fromaxi_smp_read_req_num        <= l2b_fromaxi_smp_read_set   & ~l2b_fromaxi_smp_read_clr  ;
        l2b_fromaxi_smp_write_req_num       <= l2b_fromaxi_smp_write_set  & ~l2b_fromaxi_smp_write_clr ;
        l2b_fromaxi_smp_atomic_req_num      <= l2b_fromaxi_smp_atomic_set & ~l2b_fromaxi_smp_atomic_clr;

        if(l2b_fromaxi_smp_read_set) begin
            l2b_fromaxi_smp_read_req_sum    <= 1'b1;
            l2b_perf_lat_arid               <= axi_rstl_ar_rec.id;
        end
        else if(l2b_fromaxi_smp_read_clr) begin
            l2b_fromaxi_smp_read_req_sum    <= 1'b0;
        end

         if(l2b_fromaxi_smp_write_set) begin
            l2b_fromaxi_smp_write_req_sum   <= 1'b1;
            l2b_perf_lat_awid               <= axi_rstl_aw_rec.id;
        end
        else if(l2b_fromaxi_smp_write_clr) begin
            l2b_fromaxi_smp_write_req_sum   <= 1'b0;
        end

        if(l2b_fromaxi_smp_atomic_set) begin
            l2b_fromaxi_smp_atomic_req_sum  <= 1'b1;
            l2b_perf_lat_aaid               <= axi_rstl_aw_rec.id;
        end
        else if(l2b_fromaxi_smp_atomic_clr) begin
            l2b_fromaxi_smp_atomic_req_sum  <= 1'b0;
        end

        if(l2b_fromaxi_atomic_complete)
            l2b_fromaxi_atomic_brtn <= 1'b0;
        else if(l2b_fromaxi_atomic_brtn_set)
            l2b_fromaxi_atomic_brtn <= 1'b1;
        
        if(l2b_fromaxi_atomic_complete)
            l2b_fromaxi_atomic_rrtn <= 1'b0;
        else if(l2b_fromaxi_atomic_rrtn_set)
            l2b_fromaxi_atomic_rrtn <= 1'b1;
    end
end: p_perf_latency

assign l2b_align_awdb_full = allocate_iwdb_valid & ~allocated_iwdb_valid;
// -------------------------------------------------------------------------------------------------
// assertions
// -------------------------------------------------------------------------------------------------
// synopsys translate_off
logic                                   atomic_strb_check_en;
logic [(L2_AXI_BUS_WIDTH/8/4)-1 : 0]    axi_wstrb_4_and;
logic [(L2_AXI_BUS_WIDTH/8/4)-1 : 0]    axi_wstrb_4_or;
logic [(L2_AXI_BUS_WIDTH/8/8)-1 : 0]    axi_wstrb_8_and;
logic [(L2_AXI_BUS_WIDTH/8/8)-1 : 0]    axi_wstrb_8_or;
logic [(L2_AXI_BUS_WIDTH/8/16)-1: 0]    axi_wstrb_16_and;
logic [(L2_AXI_BUS_WIDTH/8/16)-1: 0]    axi_wstrb_16_or;
logic [(L2_AXI_BUS_WIDTH/8/32)-1: 0]    axi_wstrb_32_and;
logic [(L2_AXI_BUS_WIDTH/8/32)-1: 0]    axi_wstrb_32_or;
logic                                   axi_wstrb_4_check;
logic                                   axi_wstrb_8_check;
logic                                   axi_wstrb_16_check;
logic                                   axi_wstrb_32_check;
logic                                   axi_wstrb_4_check_en;
logic                                   axi_wstrb_8_check_en;
logic                                   axi_wstrb_16_check_en;
logic                                   axi_wstrb_32_check_en;
logic [(2**L2_AXI_ID_WIDTH)-1   : 0]    axi_arid_busy;
logic [(2**L2_AXI_ID_WIDTH)-1   : 0]    axi_awid_busy;

logic [(2**L2_AXI_ID_WIDTH)-1   : 0]    axi_axid_busy;
logic                                   axi_req_valid;
logic [L2_AXI_ID_WIDTH-1        : 0]    axi_req_id   ;
logic [5:0]                             watop        ;
logic [2:0]                             axi_req_size ;
logic [7:0]                             axi_req_len  ;

// atomic opcode and user signal check
property atomic_op_check(is_rstl_aa_req, is_atomic_fp32, extended_atomic_opcode, watop);
    disable iff(!resetn)
    @(posedge clk) is_rstl_aa_req |-> 
        (( is_atomic_fp32 & (watop==6'b100000) & (extended_atomic_opcode==2'b00)) ||   // fp32 add
         ( is_atomic_fp32 & (watop==6'b100000) & (extended_atomic_opcode==2'b01)) ||   // fp32 sub
         ( is_atomic_fp32 & (watop==6'b100100) & (extended_atomic_opcode==2'b00)) ||   // fp32 smax
         ( is_atomic_fp32 & (watop==6'b100101) & (extended_atomic_opcode==2'b00)) ||   // fp32 smin
         ( is_atomic_fp32 & (watop==6'b110001) & (extended_atomic_opcode==2'b00)) ||   // fp32 compare
         (~is_atomic_fp32 & (watop==6'b110000) & (extended_atomic_opcode==2'b00)) ||   // axi atomic swap
         (~is_atomic_fp32 & (watop==6'b110001) & (extended_atomic_opcode==2'b00)) ||   // axi atomic compare
         (~is_atomic_fp32 & (watop==6'b100010) & (extended_atomic_opcode==2'b00)) ||   // axi atomicload, exclusive OR
         (~is_atomic_fp32 & (watop==6'b100100) & (extended_atomic_opcode==2'b00)) ||   // axi atomicload, signed max
         (~is_atomic_fp32 & (watop==6'b100101) & (extended_atomic_opcode==2'b00)) ||   // axi atomicload, signed min
         (~is_atomic_fp32 & (watop==6'b100110) & (extended_atomic_opcode==2'b00)) ||   // axi atomicload, unsigned max
         (~is_atomic_fp32 & (watop==6'b100111) & (extended_atomic_opcode==2'b00)) ||   // axi atomicload, unsigned min
         (~is_atomic_fp32 & (watop==6'b100000)));         // axi atomicload, add, sub, and, or
endproperty

property atomic_strb_check(atomic_strb_check_en, axi_rstl_wstrb_and, axi_rstl_wstrb_or);
    disable iff(!resetn)
    @(posedge clk) atomic_strb_check_en |-> (axi_rstl_wstrb_and == axi_rstl_wstrb_or);
endproperty

a_atomic_op_check : assert property(atomic_op_check(is_rstl_aa_req, is_atomic_fp32, extended_atomic_opcode, axi_rstl_aw_rec.atop))
                    else $error("illegal atomic code or atomic user bits");

// atomic write strobe check
assign atomic_strb_check_en = align_iwdb_rstl_vld_rdy & align_iwdb_rstl_in_rec.atomic;

assign axi_wstrb_4_check  =  (iwdb_atomic_op != L2_AA_OP_CMPXCHG) && (iwdb_atomic_size == L2_AA_SIZE_32 );
assign axi_wstrb_8_check  = ((iwdb_atomic_op != L2_AA_OP_CMPXCHG) && (iwdb_atomic_size == L2_AA_SIZE_64))|| 
                            ((iwdb_atomic_op == L2_AA_OP_CMPXCHG) && (iwdb_atomic_size == L2_AA_SIZE_32));
assign axi_wstrb_16_check =  (iwdb_atomic_op == L2_AA_OP_CMPXCHG) && (iwdb_atomic_size == L2_AA_SIZE_64 );
assign axi_wstrb_32_check =  (iwdb_atomic_op == L2_AA_OP_CMPXCHG) && (iwdb_atomic_size == L2_AA_SIZE_128);

assign axi_wstrb_4_check_en = atomic_strb_check_en & axi_wstrb_4_check ;
assign axi_wstrb_8_check_en = atomic_strb_check_en & axi_wstrb_8_check ;
assign axi_wstrb_16_check_en= atomic_strb_check_en & axi_wstrb_16_check;
assign axi_wstrb_32_check_en= atomic_strb_check_en & axi_wstrb_32_check;

generate
for(genvar IDX=0; IDX<(L2_AXI_BUS_WIDTH/8/4); IDX++) begin: g_continuous_4_bit1
    assign axi_wstrb_4_and[IDX] = &axi_rstl_w_rec.strb[IDX*4 +: 4];
    assign axi_wstrb_4_or [IDX] = |axi_rstl_w_rec.strb[IDX*4 +: 4];
    a_atomic_strb_4_check: assert property(atomic_strb_check(axi_wstrb_4_check_en, axi_wstrb_4_and[IDX], axi_wstrb_4_or[IDX]))
                           else $error("illegal axi write strb for atomic operation");
end
endgenerate

generate
for(genvar IDX=0; IDX<(L2_AXI_BUS_WIDTH/8/8); IDX++) begin: g_continuous_8_bit1
    assign axi_wstrb_8_and[IDX] = &axi_rstl_w_rec.strb[IDX*8 +: 8];
    assign axi_wstrb_8_or [IDX] = |axi_rstl_w_rec.strb[IDX*8 +: 8];
    a_atomic_strb_8_check: assert property(atomic_strb_check(axi_wstrb_8_check_en, axi_wstrb_8_and[IDX], axi_wstrb_8_or[IDX]))
                           else $error("illegal axi write strb for atomic operation");
end
endgenerate

generate
for(genvar IDX=0; IDX<(L2_AXI_BUS_WIDTH/8/16); IDX++) begin: g_continuous_16_bit1
    assign axi_wstrb_16_and[IDX] = &axi_rstl_w_rec.strb[IDX*16 +: 16];
    assign axi_wstrb_16_or [IDX] = |axi_rstl_w_rec.strb[IDX*16 +: 16];
    a_atomic_strb_16_check:assert property(atomic_strb_check(axi_wstrb_16_check_en, axi_wstrb_16_and[IDX], axi_wstrb_16_or[IDX]))
                           else $error("illegal axi write strb for atomic operation");
end
endgenerate

generate
for(genvar IDX=0; IDX<(L2_AXI_BUS_WIDTH/8/32); IDX++) begin: g_continuous_32_bit1
    assign axi_wstrb_32_and[IDX] = &axi_rstl_w_rec.strb[IDX*32 +: 32];
    assign axi_wstrb_32_or [IDX] = |axi_rstl_w_rec.strb[IDX*32 +: 32];
    a_atomic_strb_32_check:assert property(atomic_strb_check(axi_wstrb_32_check_en, axi_wstrb_32_and[IDX], axi_wstrb_32_or[IDX]))
                           else $error("illegal axi write strb for atomic operation");
end
endgenerate


// address 512-bit alignment check
// property axi_addr_align_check(axi_req_valid, axi_req_addr);
//     disable iff(!resetn)
//     @(posedge clk) axi_req_valid |-> (axi_req_addr[5:0] == 'b0);
// endproperty
// 
// a_araddr_check : assert property(axi_addr_align_check(axi_slv_arvalid, axi_slv_ar_rec.addr))
//                  else $error("illegal axi read address");
// a_awaddr_check : assert property(axi_addr_align_check(axi_slv_awvalid, axi_slv_aw_rec.addr))
//                  else $error("illegal axi write address");

// narrow request burst length check
property axi_narrow_blen_check(axi_req_valid, axi_req_size, axi_req_len);
    disable iff(!resetn)
    @(posedge clk) (axi_req_valid && (axi_req_size < 3'h6)) |-> (axi_req_len == 'b0);
endproperty

a_ar_size_len_check : assert property(axi_narrow_blen_check(axi_slv_arvalid, axi_slv_ar_rec.size, {6'b0, axi_slv_ar_rec.len}))
                      else $error("axi burst length must be zero for narrow request");
a_aw_size_len_check : assert property(axi_narrow_blen_check(axi_slv_awvalid, axi_slv_aw_rec.size, {6'b0, axi_slv_aw_rec.len}))
                      else $error("axi burst length must be zero for narrow request");

// cross cacheline check
property axi_cross_cl_check(axi_req_valid, axi_req_addr, axi_req_size, axi_req_len, axi_req_burst);
    disable iff(!resetn)
    @(posedge clk) axi_req_valid |-> (((axi_req_burst == 2'b01) && ((((axi_req_addr[7:0]>>axi_req_size)<<axi_req_size)+((1'b1<<axi_req_size)*(axi_req_len+1'b1)))<=256)) ||
                                      ((axi_req_burst == 2'b10) && (((1'b1<<axi_req_size)*(axi_req_len+1'b1))<=256)));
endproperty

a_ar_cross_cl_check : assert property(axi_cross_cl_check(axi_slv_arvalid, axi_slv_ar_rec.addr, axi_slv_ar_rec.size, axi_slv_ar_rec.len, axi_slv_ar_rec.burst))
                      else $error("axi read request cross cacheline");
a_aw_cross_cl_check : assert property(axi_cross_cl_check(axi_slv_awvalid, axi_slv_aw_rec.addr, axi_slv_aw_rec.size, axi_slv_aw_rec.len, axi_slv_aw_rec.burst))
                      else $error("axi write request cross cacheline");

// unique axid check
always_ff @(posedge clk or negedge resetn) begin
    if(!resetn) begin
        axi_arid_busy <= 'b0;
        axi_awid_busy <= 'b0;
    end
    else begin
        if(axi_slv_arvalid & axi_slv_arready) begin
            axi_arid_busy[axi_slv_ar_rec.id] <= 1'b1;
        end
        if(axi_slv_awvalid & axi_slv_awready & (|axi_slv_aw_rec.atop)) begin
            axi_arid_busy[axi_slv_aw_rec.id] <= 1'b1;
        end
        if(axi_slv_rvalid & axi_slv_rready & axi_slv_r_rec.last) begin
            axi_arid_busy[axi_slv_r_rec.id] <= 1'b0;
        end

        if(axi_slv_awvalid & axi_slv_awready) begin
            axi_awid_busy[axi_slv_aw_rec.id] <= 1'b1;
        end
        if(axi_slv_bvalid & axi_slv_bready) begin
            axi_awid_busy[axi_slv_b_rec.id] <= 1'b0;
        end
    end
end

property axi_unique_id_check(axi_req_valid, axi_req_id, axi_axid_busy);
    disable iff(!resetn)
    //@(posedge clk) (axi_req_valid && (~$isunknown(axi_req_id))) |-> (~axi_axid_busy[axi_req_id]);
    @(posedge clk) (axi_req_valid) |-> (~axi_axid_busy[axi_req_id]);
endproperty

a_ar_unique_id_check : assert property(axi_unique_id_check(axi_slv_arvalid, axi_slv_ar_rec.id, axi_arid_busy))
                       else $error("not unique axi read ID");
a_aw_unique_id_check : assert property(axi_unique_id_check(axi_slv_awvalid, axi_slv_aw_rec.id, axi_awid_busy))
                       else $error("not unique axi write ID");

property buf_mode_addr_check(is_buffer_mode, buf_percentage, req_addr);
    disable iff(!resetn)
    @(posedge clk) (is_buffer_mode & (buf_percentage == 2'b01)) |-> (~req_addr[L2_CACHELINE_BITS+L2_NUM_SET_BITS+1]);
endproperty

a_ar_buf_mode_addr_check : assert property(buf_mode_addr_check(ar_bm_valid, gc_cr_l2_buffer_mode_percentage, axi_rstl_ar_rec.addr))
                           else $error("buffer mode read  address out way_id boundary");
a_aw_buf_mode_addr_check : assert property(buf_mode_addr_check(aw_bm_valid, gc_cr_l2_buffer_mode_percentage, axi_idx_out_aw_rec.addr))
                           else $error("buffer mode write address out way_id boundary");

property buf_mode_en_check(is_buffer_mode, buf_percentage);
    disable iff(!resetn)
    @(posedge clk) (buf_percentage == 2'b0) |-> (~is_buffer_mode);
endproperty

a_ar_buf_mode_en_check : assert property(buf_mode_en_check(ar_bm_valid, gc_cr_l2_buffer_mode_percentage))
                         else $error("don't support buffer mode when buffer mode percentage is 0");
a_aw_buf_mode_en_check : assert property(buf_mode_en_check(aw_bm_valid, gc_cr_l2_buffer_mode_percentage))
                         else $error("don't support buffer mode when buffer mode percentage is 0");

// write response id in-order check
logic                           wid_dbg_fifo_in_valid;
logic                           wid_dbg_fifo_in_ready;
logic                           wid_dbg_fifo_out_valid;
logic                           wid_dbg_fifo_out_ready;
logic [L2_AXI_ID_WIDTH-1 : 0]   wid_dbg_fifo_out_data;
logic [L2_AXI_ID_WIDTH-1 : 0]   axi_wr_rsp_id;

assign wid_dbg_fifo_in_valid  = axi_slv_awvalid & axi_slv_awready;
assign wid_dbg_fifo_out_ready = axi_slv_bvalid  & axi_slv_bready ;

gpc_gfx_rpfifo_ #(
    .w                  (L2_AXI_ID_WIDTH        ),
    .d                  (128                    ),
    .registered_enable  (1                      ) 
) i_fifo_wid_debug (
    .clk                (clk                    ),  // I
    .resetn             (resetn                 ),  // I
    .fifo_in_valid      (wid_dbg_fifo_in_valid  ),  // I
    .fifo_in_enable     (wid_dbg_fifo_in_ready  ),  // O
    .fifo_in_data       (axi_slv_aw_rec.id      ),  // I
    .fifo_out_valid     (wid_dbg_fifo_out_valid ),  // O
    .fifo_out_enable    (wid_dbg_fifo_out_ready ),  // I
    .fifo_out_data      (wid_dbg_fifo_out_data  )   // O
);

property dbg_fifo_in_ready_check(axi_slv_awvalid, wid_dbg_fifo_in_ready);
    disable iff(!resetn)
    @(posedge clk) axi_slv_awvalid |-> wid_dbg_fifo_in_ready;
endproperty

a_dbg_fifo_depth_check : assert property(dbg_fifo_in_ready_check(axi_slv_awvalid, wid_dbg_fifo_in_ready))
                         else $fatal(0, "AXI WID debug fifo overflow");

property wr_rsp_id_in_order_check(wid_dbg_fifo_out_ready, wid_dbg_fifo_out_data, axi_wr_rsp_id);
    disable iff(!resetn)
    @(posedge clk) wid_dbg_fifo_out_ready |-> (wid_dbg_fifo_out_data == axi_wr_rsp_id);
endproperty

a_wr_rsp_id_order_check : assert property(wr_rsp_id_in_order_check(wid_dbg_fifo_out_ready, wid_dbg_fifo_out_data, axi_slv_b_rec.id))
                          else $fatal(0, "AXI write response ID must be in-order");
// synopsys translate_on

endmodule
