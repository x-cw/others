/*

 * #==========================================================================#
 * |                                                                          |
 * |  Copyright (c) 2022, Fantasy Technologies Limited and/or its         |
 * |  affiliated group companies ("Fantasy"). All rights reserved.        |
 * |  No part of this content, either material or conceptual may be copied    |
 * |  or distributed, transmitted, transcribed, stored in a retrieval system  |
 * |  or translated into any human or computer language in any form by any    |
 * |  means, electronic, mechanical manual, or otherwise, or disclosed to     |
 * |  third parties without the express written permission of Fantasy.    |
 * |                                                                          |
 * #==========================================================================#

 */

// ////////////////////////////////////////////////////////////////////////////-
// entity:  gpu_core_sp_gfx_spstore_pipeline_gen_bist_r
//
// purpose: Single port synchronous RAM with configurable write word partitions
//          and back end read register to help achieve timing closure
//
// +////////////////////////-+////-+////-+////////+////////////////+
// | gpc_gfx_spstore_        | RAM | Reg | Bypass | Design         |
// |             w,p,d,log2d | O/P | O/P | Input  | Suitability    |
// +////////////////////////-+////-+////-+////////+////////////////+
// | _.vhd & _novital.vhd    | Yes |     |        | Fundamental    |
// | bist.vhdm               | Yes |     |        | Low level only |
// | gen_bist_r.vhd          |     | Yes |        | Standard use   |
// | pipeline_gen_bist_r.vhd |     | Yes |        | Standard use   |<<<
// | bypass_gen_bist_r.vhd   | Yes | Yes |  Yes   | Standard use   |
// | bpout_gen_bist_r.vhd    | Yes | Yes |        | Standard use   |
// | flexible_gen_bist_r.vhd | Yes | Yes |  Yes   | Standard use   |
// +////////////////////////-+////-+////-+////////+////////////////+
//
// hierarchy: This is an RTL designer's standard component
//
//        gpc_gfx_spstore_[pipeline|bypass]_gen_bist_r   << YOU ARE HERE
//         |
//         +- gpc_gfx_spstore_bist
//             |
//             +- gpc_gfx_spstore
//             |
//             +- [ gpc_gfx_bistwrap_sing ]
//
// ////////////////////////////////////////////////////////////////////////////-

// DIMENSIONS
//   Physical generics: w, d, p, log2d, wrcen*
//
//                        width
//              <////////// w //////////>
//
//              +//////////////////////-+   ^
//              |_______________________|   |
//              |_______________________|   |  d
//              |_______________________|      e
//              |                       |   d  p
//              |                       |      t
//              :                       :   |  h
//              |                       |   |
//              +//////////////////////-+   v
//                         w/p *
//              <- p -><- p -> .. <- p ->
//                      partitions
//
//   All partitions are equal in size. In other words, the generic w is an
//   integer multiple of generic p.
//
//   Example partition:
//      [w = 128, p = 32] => w/p = 4 partitions => 4 write enables

// PORTS
//   +////////////////////////////////////////////////////////-+
//   | name          |  bits  |dir| description                |
//   +////////////////////////////////////////////////////////-+
//   | addr          | log2d  | i | address                    |
//   | c_en          |   1    | i | chip enable (ACTIVE LOW)   |
//   | rd_data_cken  |   1    | i | read register clock gate   |
//   | rd_data       |   w    | o | read data                  |
//   |               |        |   |                            |
//   | wr_data       |   w    | i | write data ((w/p)*p bits)  |
//   | wr_en         |  w/p   | i | write enables (ACTIVE LOW) |
//   |               |        |   |                            |
//   | clk           |   1    | i | common r/w clock           |
//   | resetn        |   1    | i | reset to BIST (ACTIVE LOW) |
//   |               |        |   |                            |
//   | bist_in       |f(w,p,d)| i | input from BIST controller |
//   | bist_out      |f(w,p,d)| o | result to BIST controller  |
//   +////////////////////////////////////////////////////////-+

// BEHAVIOURIAL MODEL
//   Functional behaviour is similar to gpc_gfx_spstore_bist but this hierarchical
//   level adds a back end read data register for timing purposes
//
//   Read latency:  2 clock
//   Write latency: 1 clock
//
//    rd_data_cken ////////////////////////////////////////////-.
//                   +//////////////////////////////////-+      |
//                   |      gpc_gfx_spstore_bist         |      |
//                   |                                   |      |
//                   |  +////////////////////////////-+  |      |
//                   |  |     gpc_gfx_spstore         |  |      |
//                   |  |                             |  |      |
//     addr     /////|//|-*///////////////////////.   |  |      |
//     c_en     ////-|//|-|//-*//////////////////.|   |  |      |ck
//                   |  | |   |                  ||   |  | rd   |en
//                   |  | | +////+   +////-+   +////+ |  | en +////+
//                   |  | '-| wr |   |     |   | rd |-|//|////|    |
//     wr_en    /////|//|//-|proc|-/-| mem |-/-|proc|-|//|////|    |///->
//     wr_data  /////|//|//-|    |   |     |   |    | |  |    |    |   rd_data
//                   |  |   |    |  +|>    |  +|>   | |  | .//|>   |
//                   |  |   +////+  |+////-+  |+////+ |  | |  +////+
//                   |  |           |         |       |  | |
//     clk      ////-|//|//////////-*////////-*//////-|//|-'
//                   |  +////////////////////////////-+  |
//                   |  +////////////////////////////-+  |
//                   |  |                             |  |
//     bist_in  /////|//|  [ gpc_gfx_bistwrap_sing ]  |//|/////////-> bist_out
//     resetn   ////-|//|                             |  |
//                   |  +////////////////////////////-+  |
//                   +//////////////////////////////////-+
//   Notes:
//   + In addition to wr_en, writes require c_en to be asserted (low)
//   + A read is classed as "not a write". The consequence of this is that
//     when a write takes place, but with any of the word partitions [i]
//     not written (wr_en[i] = '1'), the bit slices for those partitions are
//     read instead. For this behaviour to be visible, rd_data_cken must also
//     be asserted. If this is unclear, you should check the p_qa_i process.

// OPTIONAL UTILITY GENERIC
//   id : integer value that can be assigned to each instance (default 0)
//                                                                      -=:PB=-
// ////////////////////////////////////////////////////////////////////////////-

module gpu_core_sp_gfx_spstore_pipeline_gen_bist_r_
   import gpc_gfx_rambist_pack_::*;
#(
      parameter int w     = 32,
      parameter int p     = 32,
      parameter int d     = 8 ,
      parameter int log2d = 3 ,
      parameter int ECC   = 0 ,



      parameter int id    = 0
)
(
      input    logic                                                        clk,
      input    logic                                                        resetn,
      input    logic                                                        c_en,
      input    logic [ ( w / p ) - 1 : 0 ]                                  wr_en,
      input    logic [ log2d - 1 : 0 ]                                      addr,
      input    logic [ w - 1 : 0 ]                                          wr_data,
      output   logic [ w - 1 : 0 ]                                          rd_data,
      input    logic                                                        rd_data_cken,






      // bist signals
      input    logic [ spstore_in ( w , p , d , ECC ) - 1 : 0 ]             bist_in,
      output   logic [ spstore_out ( w , p , d , ECC ) - 1 : 0 ]            bist_out,
      input    logic                                                        tst_gclkenable
);









   logic                                                        rd_en_r;
   logic [ w - 1 : 0 ]                                          rd_data_ram;
   logic [ w - 1 : 0 ]                                          rd_data_ram_r;

   ///////////////////////////////////////////////
   // backdoor access
   ///////////////////////////////////////////////




   ///////////////////////////////////////////////
   ///////////////////////////////////////////////
   // END backdoor access
   ///////////////////////////////////////////////

   gpu_core_sp_gfx_spstore_wrap_
         #(
         .w(w),
         .p(p),
         .d(d),
         .log2d(log2d),
         .ECC(ECC),



         .id(id)
         )
         i_gpu_core_sp_gfx_spstore_wrap
         (
         .clk(clk),
         .resetn(resetn),
         .c_en(c_en),
         .wr_en(wr_en),
         .addr(addr),
         .wr_data(wr_data),
         .rd_data_ram(rd_data_ram),






         .bist_in(bist_in),
         .bist_out(bist_out),
         .tst_gclkenable(tst_gclkenable)
         );

   // //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
   // Register the Ram Data for timing (This variant has an input enable signal to govern whether the data is registered or not)
   // //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

   always_ff@(posedge clk or negedge  resetn) begin
      if ( resetn == 1'b0 ) begin
         rd_en_r <= 1'b1 ;
      end else begin
         if ( c_en == 1'b0 & ( & wr_en ) == 1'b1 ) begin
            rd_en_r <= 1'b0 ;
         end else if ( ( rd_en_r == 1'b0 & rd_data_cken == 1'b1 ) ) begin
            rd_en_r <= 1'b1 ;
         end
         // synopsys translate_off
         // pragma coverage off
         if ( rd_en_r == 1'b0 & rd_data_cken == 1'b0 & c_en == 1'b0 ) begin
            gpc_gfx_spstore:  assert ( 0 ) else $warning ( "gpu_core_sp_gfx_spstore_pipeline_gen_bist_r: read data is not propagated to the output register before the following memory operation and it is now lost" ) ;
         end
         // pragma coverage on
         // synopsys translate_on
      end
   end

   generate
   for(genvar i = (w/p)-1; i>=0; i--) begin : g_rd_data_ram
      always_ff@(posedge clk)
      begin
         if ( rd_en_r == 1'b0 & rd_data_cken == 1'b1 ) begin
            rd_data_ram_r [  ( i + 1 ) * p - 1 : i * p  ] <= rd_data_ram [  ( i + 1 ) * p - 1 : i * p  ] ;
         end
      end
   end
   endgenerate

   assign rd_data = rd_data_ram_r;

endmodule

