/*

 * #==========================================================================#
 * |                                                                          |
 * |  Copyright (c) 2023, Fantasy Technologies Limited and/or its         |
 * |  affiliated group companies ("Fantasy"). All rights reserved.        |
 * |  No part of this content, either material or conceptual may be copied    |
 * |  or distributed, transmitted, transcribed, stored in a retrieval system  |
 * |  or translated into any human or computer language in any form by any    |
 * |  means, electronic, mechanical manual, or otherwise, or disclosed to     |
 * |  third parties without the express written permission of Fantasy.    |
 * |                                                                          |
 * #==========================================================================#

 */



package pkg_cpc_ctrl_;




  // (EVENT_SIGNAL_OBJECT)
    localparam [31 : 0]   CPC_CTRL_EVENT_SIGNAL_OBJECT_DATA                   = 32'h0;
    localparam integer CPC_CTRL_EVENT_SIGNAL_OBJECT_DATA_FIELDWIDTH = 32;

  //Compute kernel control stream
  // (KERNEL0)

    localparam [0 : 0]    CPC_CTRL_COMPUTE_KERNEL0_CU_TARGET                            = 1'h0;
    localparam integer CPC_CTRL_COMPUTE_KERNEL0_CU_TARGET_FIELDWIDTH                    = 1; 

    localparam [2 : 1]    CPC_CTRL_COMPUTE_KERNEL0_PARITION_DIM                          = 2'h0;
    localparam integer CPC_CTRL_COMPUTE_KERNEL0_PARITION_DIM_FIELDWIDTH                  = 2; 

    localparam [4 : 3]    CPC_CTRL_COMPUTE_KERNEL0_SD_TYPE                               = 2'h0;
    localparam integer CPC_CTRL_COMPUTE_KERNEL0_SD_TYPE_FIELDWIDTH                       = 2; 

    localparam [6 : 6]    CPC_CTRL_COMPUTE_KERNEL0_CU_ALLOC_TYPE                        = 1'h0;
    localparam integer CPC_CTRL_COMPUTE_KERNEL0_CU_ALLOC_TYPE_FIELDWIDTH                = 1;  

    localparam [11 : 7]    CPC_CTRL_COMPUTE_KERNEL0_DOUT_PATTERN                         = 5'h0;
    localparam integer CPC_CTRL_COMPUTE_KERNEL0_DOUT_PATTERN_FIELDWIDTH                  = 5;  

    localparam [18 : 12]   CPC_CTRL_COMPUTE_KERNEL0_CU_UNIFIED_SIZE                     = 7'h0;
    localparam integer CPC_CTRL_COMPUTE_KERNEL0_CU_UNIFIED_SIZE_FIELDWIDTH              = 7; 

    localparam [19 : 19]   CPC_CTRL_COMPUTE_KERNEL0_PROFILING_ENABLE                     = 1'h0;
    localparam integer CPC_CTRL_COMPUTE_KERNEL0_PROFILING_ENABLE_FIELDWIDTH              = 1; 

    localparam [20 : 20]   CPC_CTRL_COMPUTE_KERNEL0_NONUNIFORM_PRESENT                   = 1'h0;
    localparam integer CPC_CTRL_COMPUTE_KERNEL0_NONUNIFORM_PRESENT_FIELDWIDTH            = 1; 

    localparam [21 : 21]   CPC_CTRL_COMPUTE_KERNEL0_WAIT_ON_FLUSH                        = 1'h0;
    localparam integer CPC_CTRL_COMPUTE_KERNEL0_WAIT_ON_FLUSH_FIELDWIDTH                 = 1;

    localparam [22 : 22]   CPC_CTRL_COMPUTE_KERNEL0_FLUSH                                = 1'h0;
    localparam integer CPC_CTRL_COMPUTE_KERNEL0_FLUSH_FIELDWIDTH                         = 1;  

    localparam [23 : 23]   CPC_CTRL_COMPUTE_KERNEL0_FLSUHINV_ENABLE                      = 1'h0;
    localparam integer CPC_CTRL_COMPUTE_KERNEL0_FLSUHINV_ENABLE_FIELDWIDTH               = 1; 

    localparam [24 : 24]   CPC_CTRL_COMPUTE_KERNEL0_EVENT_SIGNAL_OBJECT_PRESENT          = 1'h0;
    localparam integer CPC_CTRL_COMPUTE_KERNEL0_EVENT_SIGNAL_OBJECT_PRESENT_FIELDWIDTH   = 1;

    localparam [25 : 25]   CPC_CTRL_COMPUTE_KERNEL0_WAIT_ON_SINGAL                       = 1'h0;
    localparam integer CPC_CTRL_COMPUTE_KERNEL0_WAIT_ON_SINGAL_FIELDWIDTH                = 1;  

    localparam [26 : 26]   CPC_CTRL_COMPUTE_KERNEL0_INDIRECT_PRESENT                     = 1'h0;
    localparam integer CPC_CTRL_COMPUTE_KERNEL0_INDIRECT_PRESENT_FIELDWIDTH              = 1;  

    localparam [31 : 27]   CPC_CTRL_COMPUTE_KERNEL0_BLOCK_TYPE                           = 5'h0;
    localparam integer CPC_CTRL_COMPUTE_KERNEL0_BLOCK_TYPE_FIELDWIDTH                    = 5;  


  // (KERNEL1)
    localparam [0 : 0]    CPC_CTRL_COMPUTE_KERNEL1_PERFORMANCE_TRACKED                   = 1'h0;
    localparam integer CPC_CTRL_COMPUTE_KERNEL1_PERFORMANCE_TRACKED_FIELDWIDTH           = 1;

    localparam [6 : 5]    CPC_CTRL_COMPUTE_KERNEL1_WORK_ITEM_MODE                        = 2'h0;
    localparam integer CPC_CTRL_COMPUTE_KERNEL1_WORK_ITEM_MODE_FIELDWIDTH                = 2;

    localparam [13 : 7]    CPC_CTRL_COMPUTE_KERNEL1_CU_TEMP_SIZE                        = 7'h0;
    localparam integer CPC_CTRL_COMPUTE_KERNEL1_CU_TEMP_SIZE_FIELDWIDTH                 = 7;

    localparam [24 : 14]   CPC_CTRL_COMPUTE_KERNEL1_CU_ALLOC_SIZE                       = 11'h0;
    localparam integer CPC_CTRL_COMPUTE_KERNEL1_DATA_ADDR_FIELDWIDTH                     = 11;

    localparam [31 : 25]   CPC_CTRL_COMPUTE_KERNEL1_MAX_INSTANCE                         = 7'h0;
    localparam integer CPC_CTRL_COMPUTE_KERNEL1_MAX_INSTANCE_FIELDWIDTH                  = 7;


  // (KERNEL2)  
    localparam [31 : 0]   CPC_CTRL_COMPUTE_KERNEL2_WORKGROUP_X                           = 32'h0;
    localparam integer CPC_CTRL_COMPUTE_KERNEL2_WORKGROUP_X_FIELDWIDTH                   = 32;


  // (KERNEL3)  
    localparam [31 : 0]   CPC_CTRL_COMPUTE_KERNEL3_WORKGROUP_Y                           = 32'h0;
    localparam integer CPC_CTRL_COMPUTE_KERNEL3_WORKGROUP_Y_FIELDWIDTH                   = 32;


  // (KERNEL4)  
    localparam [31 : 0]   CPC_CTRL_COMPUTE_KERNEL4_WORKGROUP_Z                           = 32'h0;
    localparam integer CPC_CTRL_COMPUTE_KERNEL4_WORKGROUP_Z_FIELDWIDTH                   = 32;

  // (KERNEL5)  
    localparam [15 : 0]   CPC_CTRL_COMPUTE_KERNEL5_INDIRECT_ADDRMSB                      = 16'h0;
    localparam integer CPC_CTRL_COMPUTE_KERNEL5_INDIRECT_ADDRMSB_FIELDWIDTH              = 16;

  // (KERNEL6)  
    localparam [31 : 2]   CPC_CTRL_COMPUTE_KERNEL6_INDIRECT_ADDRLSB                      = 30'h0;
    localparam integer CPC_CTRL_COMPUTE_KERNEL6_INDIRECT_ADDRLSB_FIELDWIDTH              = 30;


  // (KERNEL7)  
    localparam [9 : 0]    CPC_CTRL_COMPUTE_KERNEL7_WORKGROUP_SIZE_Z                      = 10'h0;
    localparam integer CPC_CTRL_COMPUTE_KERNEL7_WORKGROUP_SIZE_Z_FIELDWIDTH              = 10;
    localparam [19 : 10]   CPC_CTRL_COMPUTE_KERNEL7_WORKGROUP_SIZE_Y                     = 10'h0;
    localparam integer CPC_CTRL_COMPUTE_KERNEL7_WORKGROUP_SIZE_Y_FIELDWIDTH              = 10;
    localparam [29 : 20]   CPC_CTRL_COMPUTE_KERNEL7_WORKGROUP_SIZE_X                     = 10'h0;
    localparam integer CPC_CTRL_COMPUTE_KERNEL7_WORKGROUP_SIZE_X_FIELDWIDTH              = 10;


  // (KERNEL8)  
    localparam [31 : 0]    CPC_CTRL_COMPUTE_KERNEL8_PARITITON_SIZE                       = 32'h0;
    localparam integer CPC_CTRL_COMPUTE_KERNEL8_PARITITON_SIZE_FIELDWIDTH                = 32;


  // (KERNEL9)  
    localparam [31 : 20]    CPC_CTRL_COMPUTE_KERNEL9_SHARED_SIZE                         = 12'h0;
    localparam integer CPC_CTRL_COMPUTE_KERNEL9_SHARED_SIZE_FIELDWIDTH                   = 12;

    localparam [15 : 0]     CPC_CTRL_COMPUTE_KERNEL9_SHARED_BASE_ADDRESS_MSB             = 16'h0;
    localparam integer CPC_CTRL_COMPUTE_KERNEL9_SHARED_BASE_ADDRESS_MSB_FIELDWIDTH       = 16;

  // (KERNEL10) 
    localparam [31 : 0]    CPC_CTRL_COMPUTE_KERNEL10_SHARED_BASE_ADDRESS_LSB             = 32'h0;
    localparam integer CPC_CTRL_COMPUTE_KERNEL10_SHARED_BASE_ADDRESS_LSB_FIELDWIDTH      = 32;

  // (KERNEL11) 
    localparam [31 : 26]    CPC_CTRL_COMPUTE_KERNEL11_SHARED_ACCESS_POLICY               = 6'h0;
    localparam integer CPC_CTRL_COMPUTE_KERNEL11_SHARED_ACCESS_POLICY_FIELDWIDTH         = 6;

    localparam [12 : 0]    CPC_CTRL_COMPUTE_KERNEL11_SHARED_STORE_OFFEST                 = 13'h0;
    localparam integer CPC_CTRL_COMPUTE_KERNEL11_SHARED_STORE_OFFEST_FIELDWIDTH          = 13;

  // (KERNEL12) 
    localparam [31 : 28]    CPC_CTRL_COMPUTE_KERNEL12_BARRIER_VALUE                      = 4'h0;
    localparam integer CPC_CTRL_COMPUTE_KERNEL12_BARRIER_VALUE_FIELDWIDTH                = 4;

    localparam [19 : 19]    CPC_CTRL_COMPUTE_KERNEL12_WG_DISPATH_MODE                    = 1'h0;
    localparam integer CPC_CTRL_COMPUTE_KERNEL12_WG_DISPATH_MODE_FIELDWIDTH              = 1;

    localparam [18 : 16]    CPC_CTRL_COMPUTE_KERNEL12_WI_NEED_DIM                        = 3'h0;
    localparam integer CPC_CTRL_COMPUTE_KERNEL12_WI_NEED_DIM_FIELDWIDTH                  = 3;

    localparam [15 : 13]    CPC_CTRL_COMPUTE_KERNEL12_WG_NEED_DIM                        = 3'h0;
    localparam integer CPC_CTRL_COMPUTE_KERNEL12_WG_NEED_DIM_FIELDWIDTH                  = 3;

    localparam [12 : 0]    CPC_CTRL_COMPUTE_KERNEL12_UNIFIED_STORE_OFFEST                = 13'h0;
    localparam integer CPC_CTRL_COMPUTE_KERNEL12_UNIFIED_STORE_OFFEST_FIELDWIDTH         = 13;

  // (KERNEL13) 
    localparam [30 : 30]    CPC_CTRL_COMPUTE_KERNEL13_BARRIER                            = 1'h0;
    localparam integer CPC_CTRL_COMPUTE_KERNEL13_BARRIER_FIELDWIDTH                      = 1;

    localparam [29 : 0]    CPC_CTRL_COMPUTE_KERNEL13_CU_PC                               = 30'h0;
    localparam integer CPC_CTRL_COMPUTE_KERNEL13_CU_PC_FIELDWIDTH                        = 30;

  // (KERNEL14) 
    localparam [21 : 21]    CPC_CTRL_COMPUTE_KERNEL14_OBJECT_FLUSH_ENABLE                = 1'h0;
    localparam integer CPC_CTRL_COMPUTE_KERNEL14_OBJECT_FLUSH_ENABLE_FIELDWIDTH          = 1;

    localparam [20 : 20]    CPC_CTRL_COMPUTE_KERNEL14_OBJECT_CACHE_CTRL_COMPUTE          = 1'h0;
    localparam integer CPC_CTRL_COMPUTE_KERNEL14_OBJECT_CACHE_CTRL_COMPUTE_FIELDWIDTH    = 1;

    localparam [19 : 16]    CPC_CTRL_COMPUTE_KERNEL14_OBJECT_ATOMIC_OP                   = 4'h0;
    localparam integer CPC_CTRL_COMPUTE_KERNEL14_OBJECT_ATOMIC_OP_FIELDWIDTH             = 4;

    localparam [15 : 0]    CPC_CTRL_COMPUTE_KERNEL14_OBJECT_ADDR_MSB                     = 16'h0;
    localparam integer CPC_CTRL_COMPUTE_KERNEL14_OBJECT_ADDR_MSB_FIELDWIDTH              = 16;

  // (KERNEL15) 
    localparam [31 : 3]    CPC_CTRL_COMPUTE_KERNEL15_OBJECT_ADDR_LSB                     = 30'h0;
    localparam integer CPC_CTRL_COMPUTE_KERNEL15_OBJECT_ADDR_LSB_FIELDWIDTH              = 30;

  // (KERNEL16) 
    localparam [31 : 0]    CPC_CTRL_COMPUTE_KERNEL16_OBJECT_DATA_MSB                     = 32'h0;
    localparam integer CPC_CTRL_COMPUTE_KERNEL16_OBJECT_DATA_MSB_FIELDWIDTH              = 32;

  // (KERNEL17) 
    localparam [31 : 0]    CPC_CTRL_COMPUTE_KERNEL17_OBJECT_DATA_LSB                     = 32'h0;
    localparam integer CPC_CTRL_COMPUTE_KERNEL17_OBJECT_DATA_LSB_FIELDWIDTH              = 32;

  // (KERNEL18) 
    localparam [9 : 0]    CPC_CTRL_COMPUTE_KERNEL18_NU_WORKGROUP_SIZE_Z                  = 10'h0;
    localparam integer CPC_CTRL_COMPUTE_KERNEL18_NU_WORKGROUP_SIZE_Z_FIELDWIDTH          = 10;  

    localparam [19 : 10]   CPC_CTRL_COMPUTE_KERNEL18_NU_WORKGROUP_SIZE_Y                 = 10'h0;
    localparam integer CPC_CTRL_COMPUTE_KERNEL18_NU_WORKGROUP_SIZE_Y_FIELDWIDTH          = 10;  

    localparam [29 : 20]   CPC_CTRL_COMPUTE_KERNEL18_NU_WORKGROUP_SIZE_X                 = 10'h0;
    localparam integer CPC_CTRL_COMPUTE_KERNEL18_NU_WORKGROUP_SIZE_X_FIELDWIDTH          = 10;    

  // (KERNEL19) 
    localparam [31 : 16]    CPC_CTRL_COMPUTE_KERNEL19_TIMESTAMP_END_ADDR_MSB             = 16'h0;
    localparam integer CPC_CTRL_COMPUTE_KERNEL19_TIMESTAMP_END_ADDR_MSB_FIELDWIDTH       = 16;  

    localparam [15 : 0]    CPC_CTRL_COMPUTE_KERNEL19_TIMESTAMP_START_ADDR_MSB            = 16'h0;
    localparam integer CPC_CTRL_COMPUTE_KERNEL19_TIMESTAMP_START_ADDR_MSB_FIELDWIDTH     = 16; 

  // (KERNEL20) 
    localparam [31 : 3]     CPC_CTRL_COMPUTE_KERNEL20_TIMESTAMP_START_ADDR_LSB           = 29'h0;
    localparam integer CPC_CTRL_COMPUTE_KERNEL20_TIMESTAMP_START_ADDR_LSB_FIELDWIDTH     = 29;  

  // (KERNEL21) 
    localparam [31 : 3]     CPC_CTRL_COMPUTE_KERNEL21_TIMESTAMP_END_ADDR_LSB             = 29'h0;
    localparam integer CPC_CTRL_COMPUTE_KERNEL21_TIMESTAMP_END_ADDR_LSB_FIELDWIDTH       = 29;  


  //FENCE kernel control stream
  // (KERNEL0)
    localparam [26 : 26]     CPC_CTRL_FENCE_KERNEL0_FLUSHUINV_ENABLE                     = 1'h0;
    localparam integer CPC_CTRL_FENCE_KERNEL0_FLUSHUINV_ENABLE_FIELDWIDTH                = 1;  

    localparam [25 : 24]     CPC_CTRL_FENCE_KERNEL0_CACHE_CTRL                           = 2'h0;
    localparam integer CPC_CTRL_FENCE_KERNEL0_CACHE_CTRL_FIELDWIDTH                      = 2;

    localparam [23 : 23]     CPC_CTRL_FENCE_KERNEL0_FENCE_TYPE                           = 1'h0;
    localparam integer CPC_CTRL_FENCE_KERNEL0_FENCE_TYPE_FIELDWIDTH                      = 1;

    localparam [21 : 20]     CPC_CTRL_FENCE_KERNEL0_SUB_OP_CODE                          = 2'h0;
    localparam integer CPC_CTRL_FENCE_KERNEL0_SUB_OP_CODE_FIELDWIDTH                     = 2;

    localparam [19 : 19]     CPC_CTRL_FENCE_KERNEL0_INTERRUPT_ENABLE                     = 1'h0;
    localparam integer CPC_CTRL_FENCE_KERNEL0_INTERRUPT_ENABLE_FIELDWIDTH                = 1;

    localparam [18 : 16]     CPC_CTRL_FENCE_KERNEL0_COMPARISON_MODE                      = 3'h0;
    localparam integer CPC_CTRL_FENCE_KERNEL0_COMPARISON_MODE_FIELDWIDTH                 = 3;




  // (KERNEL1)
    localparam [31 : 3]     CPC_CTRL_FENCE_KERNEL1_ADDR_LSB                              = 29'h0;
    localparam integer CPC_CTRL_FENCE_KERNEL1_ADDR_LSB_FIELDWIDTH                        = 29;

  // (KERNEL2)
    localparam [15 : 0]     CPC_CTRL_FENCE_KERNEL2_ADDR_MSB                              = 16'h0;
    localparam integer CPC_CTRL_FENCE_KERNEL2_ADDR_MSB_FIELDWIDTH                        = 16;

  // (KERNEL3)
    localparam [31 : 0]     CPC_CTRL_FENCE_KERNEL3_DATA_LSB                              = 32'h0;
    localparam integer CPC_CTRL_FENCE_KERNEL3_DATA_LSB_FIELDWIDTH                        = 32;

  // (KERNEL4)
    localparam [31 : 0]     CPC_CTRL_FENCE_KERNEL4_DATA_MSB                              = 32'h0;
    localparam integer CPC_CTRL_FENCE_KERNEL4_DATA_MSB_FIELDWIDTH                        = 32;


    //context state
    //DW0
    localparam int    CP_CTRL_CONTEXT_STATE_DW0                          = 0;
    localparam [31+(32*CP_CTRL_CONTEXT_STATE_DW0) : 2+(32*CP_CTRL_CONTEXT_STATE_DW0)]   CPC_CTRL_CONTEXT_STATE_CONTROL_STREAM_ADDRESS_LSB   = 30'h0;
    localparam integer CPC_CTRL_CONTEXT_STATE_CONTROL_STREAM_ADDRESS_LSB_FIELDWIDTH = 30;


    //DW1
    localparam int    CP_CTRL_CONTEXT_STATE_DW1                          = 1;
    localparam [15+(CP_CTRL_CONTEXT_STATE_DW1*32) : 0+ (CP_CTRL_CONTEXT_STATE_DW1*32)]   CPC_CTRL_CONTEXT_STATE_CONTROL_STREAM_ADDRESS_MSB      = 16'h0;
    localparam integer CPC_CTRL_CONTEXT_STATE_CONTROL_STREAM_ADDRESS_MSB_FIELDWIDTH = 16;

    localparam [16+(CP_CTRL_CONTEXT_STATE_DW1*32) : 16+(CP_CTRL_CONTEXT_STATE_DW1*32)]   CPC_CTRL_CONTEXT_STATE_PARITION_INACTIVE      = 1'h0;
    localparam integer CPC_CTRL_CONTEXT_STATE_PARITION_INACTIVE_FIELDWIDTH = 1; 

    localparam [17+(CP_CTRL_CONTEXT_STATE_DW1*32) : 17+(CP_CTRL_CONTEXT_STATE_DW1*32)]   CPC_CTRL_CONTEXT_STATE_ACTIVE_REG_SHARED_KERNEL      = 1'h0;
    localparam integer CPC_CTRL_CONTEXT_STATE_ACTIVE_REG_SHARED_KERNEL_FIELDWIDTH = 1; 


    localparam [23+(CP_CTRL_CONTEXT_STATE_DW1*32) : 22+(CP_CTRL_CONTEXT_STATE_DW1*32)]   CPC_CTRL_CONTEXT_STATE_BLOCK_ID     = 2'h0;
    localparam integer CPC_CTRL_CONTEXT_STATE_BLOCK_ID_FIELDWIDTH = 2;  

    localparam [30+(CP_CTRL_CONTEXT_STATE_DW1*32) : 25+(CP_CTRL_CONTEXT_STATE_DW1*32)]   CPC_CTRL_CONTEXT_STATE_KERNEL_ID     = 6'h0;
    localparam integer CPC_CTRL_CONTEXT_STATE_KERNEL_ID_FIELDWIDTH = 6;  

    localparam [31+(CP_CTRL_CONTEXT_STATE_DW1*32) : 31+(CP_CTRL_CONTEXT_STATE_DW1*32)]   CPC_CTRL_CONTEXT_STATE_NEED_RESUME    = 1'h0;
    localparam integer CPC_CTRL_CONTEXT_STATE_NEED_RESUME_FIELDWIDTH = 1;  

    //DW2
    localparam int    CP_CTRL_CONTEXT_STATE_DW2                          = 2;
    localparam [31+(CP_CTRL_CONTEXT_STATE_DW2*32) : 0+(CP_CTRL_CONTEXT_STATE_DW2*32)]   CPC_CTRL_CONTEXT_STATE_SHARED_KERNEL_HEADER     = 32'h0;
    localparam integer CPC_CTRL_CONTEXT_STATE_SHARED_KERNEL_HEADER_FIELDWIDTH = 32;  


    //DW3
    localparam int    CP_CTRL_CONTEXT_STATE_DW3                          = 3;
    localparam [31+(CP_CTRL_CONTEXT_STATE_DW3*32) : 25+(CP_CTRL_CONTEXT_STATE_DW3*32)]   CPC_CTRL_CONTEXT_SHARED_KERNEL_MAX_INSTANCE      = 7'h0;
    localparam integer CPC_CTRL_CONTEXT_SHARED_KERNEL_MAX_INSTANCE_FIELDWIDTH = 7; 

    localparam [24+(CP_CTRL_CONTEXT_STATE_DW3*32) : 14+(CP_CTRL_CONTEXT_STATE_DW3*32)]   CPC_CTRL_CONTEXT_SHARED_KERNEL_ALLOC_SIZE      = 11'h0;
    localparam integer CPC_CTRL_CONTEXT_SHARED_KERNEL_ALLOC_SIZE_FIELDWIDTH = 11; 

    localparam [13+(CP_CTRL_CONTEXT_STATE_DW3*32) : 7+(CP_CTRL_CONTEXT_STATE_DW3*32)]   CPC_CTRL_CONTEXT_SHARED_KERNEL_CU_TEMP_SIZE      = 7'h0;
    localparam integer CPC_CTRL_CONTEXT_SHARED_KERNEL_CU_TEMP_SIZE_FIELDWIDTH = 7; 

    localparam [6+(CP_CTRL_CONTEXT_STATE_DW3*32) : 5+(CP_CTRL_CONTEXT_STATE_DW3*32)]   CPC_CTRL_CONTEXT_SHARED_KERNEL_WORKITEM_MODE      = 2'h0;
    localparam integer CPC_CTRL_CONTEXT_SHARED_KERNEL_WORKITEM_MODE_FIELDWIDTH = 2; 

    localparam [0+(CP_CTRL_CONTEXT_STATE_DW3*32) : 0+(CP_CTRL_CONTEXT_STATE_DW3*32)]   CPC_CTRL_CONTEXT_SHARED_KERNEL_PERFORMANCE_TRACKED      = 1'h0;
    localparam integer CPC_CTRL_CONTEXT_SHARED_KERNEL_PERFORMANCE_TRACKED_FIELDWIDTH = 1; 


    //DW4
    localparam int    CP_CTRL_CONTEXT_STATE_DW4                          = 4;
    localparam [31+(CP_CTRL_CONTEXT_STATE_DW4*32) : 20+(CP_CTRL_CONTEXT_STATE_DW4*32)]   CPC_CTRL_CONTEXT_SHARED_KERNEL_SHARED_SIZE      = 12'h0;
    localparam integer CPC_CTRL_CONTEXT_SHARED_KERNEL_SHARED_SIZE_FIELDWIDTH = 12; 

    localparam [15+(CP_CTRL_CONTEXT_STATE_DW4*32) : 0+(CP_CTRL_CONTEXT_STATE_DW4*32)]   CPC_CTRL_CONTEXT_SHARED_KERNEL_SHARED_BASE_ADDR_MSB   = 16'h0;
    localparam integer CPC_CTRL_CONTEXT_SHARED_KERNEL_SHARED_BASE_ADDR_MSB_FIELDWIDTH = 16; 


    //DW5
    localparam int    CP_CTRL_CONTEXT_STATE_DW5                          = 5;
    localparam [31+(CP_CTRL_CONTEXT_STATE_DW5*32) : 0+(CP_CTRL_CONTEXT_STATE_DW5*32)]   CPC_CTRL_CONTEXT_SHARED_KERNEL_SHARED_BASE_ADDR_LSB   = 32'h0;
    localparam integer CPC_CTRL_CONTEXT_SHARED_KERNEL_SHARED_BASE_ADDR_LSB_FIELDWIDTH = 32; 


    //DW6
    localparam int    CP_CTRL_CONTEXT_STATE_DW6                          = 6;
    localparam [31+(CP_CTRL_CONTEXT_STATE_DW6*32) : 26+(CP_CTRL_CONTEXT_STATE_DW6*32)]   CPC_CTRL_CONTEXT_SHARED_KERNEL_SHARED_ACCESS_POLICY   = 6'h0;
    localparam integer CPC_CTRL_CONTEXT_SHARED_KERNEL_SHARED_ACCESS_POLICY_FIELDWIDTH = 6; 

    localparam [12+(CP_CTRL_CONTEXT_STATE_DW6*32) : 0+(CP_CTRL_CONTEXT_STATE_DW6*32)]   CPC_CTRL_CONTEXT_SHARED_KERNEL_SHARED_STORE_OFFEST   = 13'h0;
    localparam integer CPC_CTRL_CONTEXT_SHARED_KERNEL_SHARED_STORE_OFFEST_FIELDWIDTH = 13;
   
   
   //DW7
    localparam int    CP_CTRL_CONTEXT_STATE_DW7                          = 7;
    localparam [30+(CP_CTRL_CONTEXT_STATE_DW7*32) : 30+(CP_CTRL_CONTEXT_STATE_DW7*32)]   CPC_CTRL_CONTEXT_SHARED_KERNEL_BARRIER   = 1'h0;
    localparam integer CPC_CTRL_CONTEXT_SHARED_KERNEL_BARRIER_FIELDWIDTH = 1; 

    localparam [29+(CP_CTRL_CONTEXT_STATE_DW7*32) : 0+(CP_CTRL_CONTEXT_STATE_DW7*32)]   CPC_CTRL_CONTEXT_SHARED_KERNEL_CU_PC   = 30'h0;
    localparam integer CPC_CTRL_CONTEXT_SHARED_KERNEL_CU_PC_FIELDWIDTH = 30; 

    //DW8
    localparam int    CP_CTRL_CONTEXT_STATE_DW8                          = 8;
    localparam [31+(CP_CTRL_CONTEXT_STATE_DW8*32) : 0+(CP_CTRL_CONTEXT_STATE_DW8*32)]   CPC_CTRL_CONTEXT_STATE_DISPATCH_KERNEL_HEADER     = 32'h0;
    localparam integer CPC_CTRL_CONTEXT_STATE_DISPATCH_KERNEL_HEADER_FIELDWIDTH = 32;  

    localparam [4+(CP_CTRL_CONTEXT_STATE_DW8*32) : 3+(CP_CTRL_CONTEXT_STATE_DW8*32)]   CPC_CTRL_CONTEXT_STATE_DISPATCH_SD_TYPE     = 2'h0;
    localparam integer CPC_CTRL_CONTEXT_STATE_DISPATCH_SD_TYPE_FIELDWIDTH = 2;  

    localparam [6+(CP_CTRL_CONTEXT_STATE_DW8*32) : 6+(CP_CTRL_CONTEXT_STATE_DW8*32)]   CPC_CTRL_CONTEXT_STATE_DISPATCH_ALLOCATE_TYPE  = 1'h0;
    localparam integer CPC_CTRL_CONTEXT_STATE_DISPATCH_ALLOCATE_TYPE_FIELDWIDTH = 1;  

    localparam [11+(CP_CTRL_CONTEXT_STATE_DW8*32) : 7+(CP_CTRL_CONTEXT_STATE_DW8*32)]   CPC_CTRL_CONTEXT_STATE_DISPATCH_DOUT_PARTTERN  = 5'h0;
    localparam integer CPC_CTRL_CONTEXT_STATE_DISPATCH_DOUT_PARTTERN_FIELDWIDTH = 5; 

    //DW9
    localparam int    CP_CTRL_CONTEXT_STATE_DW9                          = 9;
    localparam [31+(CP_CTRL_CONTEXT_STATE_DW9*32) : 0+(CP_CTRL_CONTEXT_STATE_DW9*32)]   CPC_CTRL_CONTEXT_STATE_PARTITION_X     = 32'h0;
    localparam integer CPC_CTRL_CONTEXT_STATE_PARTITION_X_FIELDWIDTH = 32;  

    //DW10
    localparam int    CP_CTRL_CONTEXT_STATE_DW10                          = 10;
    localparam [31+(CP_CTRL_CONTEXT_STATE_DW10*32) : 0+(CP_CTRL_CONTEXT_STATE_DW10*32)]   CPC_CTRL_CONTEXT_STATE_PARTITION_Y     = 32'h0;
    localparam integer CPC_CTRL_CONTEXT_STATE_PARTITION_Y_FIELDWIDTH = 32;  

    //DW11
    localparam int    CP_CTRL_CONTEXT_STATE_DW11                          = 11;
    localparam [31+(CP_CTRL_CONTEXT_STATE_DW11*32) : 0+(CP_CTRL_CONTEXT_STATE_DW11*32)]   CPC_CTRL_CONTEXT_STATE_PARTITION_Z     = 32'h0;
    localparam integer CPC_CTRL_CONTEXT_STATE_PARTITION_Z_FIELDWIDTH = 32;  


    //DW12
    localparam int    CP_CTRL_CONTEXT_STATE_DW12                          = 12;
    localparam [31+(CP_CTRL_CONTEXT_STATE_DW12*32) : 0+(CP_CTRL_CONTEXT_STATE_DW12*32)]   CPC_CTRL_CONTEXT_STATE_PARTITION_X_COUNTER     = 32'h0;
    localparam integer CPC_CTRL_CONTEXT_STATE_PARTITION_X_COUNTER_FIELDWIDTH = 32;  

    //DW13
    localparam int    CP_CTRL_CONTEXT_STATE_DW13                          = 13;
    localparam [31+(CP_CTRL_CONTEXT_STATE_DW13*32) : 0+(CP_CTRL_CONTEXT_STATE_DW13*32)]   CPC_CTRL_CONTEXT_STATE_PARTITION_Y_COUNTER     = 32'h0;
    localparam integer CPC_CTRL_CONTEXT_STATE_PARTITION_Y_COUNTER_FIELDWIDTH = 32; 


    //DW14
    localparam int    CP_CTRL_CONTEXT_STATE_DW14                          = 14;
    localparam [31+(CP_CTRL_CONTEXT_STATE_DW14*32) : 0+(CP_CTRL_CONTEXT_STATE_DW14*32)]   CPC_CTRL_CONTEXT_STATE_PARTITION_Z_COUNTER     = 32'h0;
    localparam integer CPC_CTRL_CONTEXT_STATE_PARTITION_Z_COUNTER_FIELDWIDTH = 32; 


    //DW15
    localparam int    CP_CTRL_CONTEXT_STATE_DW15                          = 15;
    localparam [31+(CP_CTRL_CONTEXT_STATE_DW15*32) : 0+(CP_CTRL_CONTEXT_STATE_DW15*32)]   CPC_CTRL_CONTEXT_STATE_PARTITION_SIZE     = 32'h0;
    localparam integer CPC_CTRL_CONTEXT_STATE_PARTITION_SIZE_FIELDWIDTH = 32; 


    //DW16
    localparam int    CP_CTRL_CONTEXT_STATE_DW16                          = 0;
    localparam [31+(CP_CTRL_CONTEXT_STATE_DW16*32) : 0+(CP_CTRL_CONTEXT_STATE_DW16*32)]   CPC_CTRL_CONTEXT_STATE_WORKGROUP_X     = 32'h0;
    localparam integer CPC_CTRL_CONTEXT_STATE_WORKGROUP_X_FIELDWIDTH = 32; 


    //DW17
    localparam int    CP_CTRL_CONTEXT_STATE_DW17                          = 1;
    localparam [31+(CP_CTRL_CONTEXT_STATE_DW17*32) : 0+(CP_CTRL_CONTEXT_STATE_DW17*32)]   CPC_CTRL_CONTEXT_STATE_WORKGROUP_Y     = 32'h0;
    localparam integer CPC_CTRL_CONTEXT_STATE_WORKGROUP_Y_FIELDWIDTH = 32; 


    //DW18
    localparam int    CP_CTRL_CONTEXT_STATE_DW18                          = 2;
    localparam [31+(CP_CTRL_CONTEXT_STATE_DW18*32) : 0+(CP_CTRL_CONTEXT_STATE_DW18*32)]   CPC_CTRL_CONTEXT_STATE_WORKGROUP_Z     = 32'h0;
    localparam integer CPC_CTRL_CONTEXT_STATE_WORKGROUP_Z_FIELDWIDTH = 32; 


    //DW19
    localparam int    CP_CTRL_CONTEXT_STATE_DW19                          = 3;
    localparam [9+(CP_CTRL_CONTEXT_STATE_DW19*32) : 0+(CP_CTRL_CONTEXT_STATE_DW19*32)]   CPC_CTRL_CONTEXT_STATE_WORKGROUP_SIZE_X     = 10'h0;
    localparam integer CPC_CTRL_CONTEXT_STATE_WORKGROUP_SIZE_X_FIELDWIDTH = 10; 

    localparam [19+(CP_CTRL_CONTEXT_STATE_DW19*32) : 10+(CP_CTRL_CONTEXT_STATE_DW19*32)]   CPC_CTRL_CONTEXT_STATE_WORKGROUP_SIZE_Y     = 10'h0;
    localparam integer CPC_CTRL_CONTEXT_STATE_WORKGROUP_SIZE_Y_FIELDWIDTH = 10; 

    localparam [29+(CP_CTRL_CONTEXT_STATE_DW19*32) : 20+(CP_CTRL_CONTEXT_STATE_DW19*32)]   CPC_CTRL_CONTEXT_STATE_WORKGROUP_SIZE_Z     = 10'h0;
    localparam integer CPC_CTRL_CONTEXT_STATE_WORKGROUP_SIZE_Z_FIELDWIDTH = 10; 


    //DW20
    localparam int    CP_CTRL_CONTEXT_STATE_DW20                          = 4;
    localparam [31+(CP_CTRL_CONTEXT_STATE_DW20*32) : 25+(CP_CTRL_CONTEXT_STATE_DW20*32)]   CPC_CTRL_CONTEXT_MAX_INSTANCE      = 7'h0;
    localparam integer CPC_CTRL_CONTEXT_MAX_INSTANCE_FIELDWIDTH = 7; 

    localparam [24+(CP_CTRL_CONTEXT_STATE_DW20*32) : 14+(CP_CTRL_CONTEXT_STATE_DW20*32)]   CPC_CTRL_CONTEXT_ALLOC_SIZE      = 11'h0;
    localparam integer CPC_CTRL_CONTEXT_ALLOC_SIZE_FIELDWIDTH = 11; 

    localparam [13+(CP_CTRL_CONTEXT_STATE_DW20*32) : 7+(CP_CTRL_CONTEXT_STATE_DW20*32)]   CPC_CTRL_CONTEXT_CU_TEMP_SIZE      = 7'h0;
    localparam integer CPC_CTRL_CONTEXT_CU_TEMP_SIZE_FIELDWIDTH = 7; 

    localparam [6+(CP_CTRL_CONTEXT_STATE_DW20*32) : 5+(CP_CTRL_CONTEXT_STATE_DW20*32)]   CPC_CTRL_CONTEXT_WORKITEM_MODE      = 2'h0;
    localparam integer CPC_CTRL_CONTEXT_WORKITEM_MODE_FIELDWIDTH = 2; 

    localparam [0+(CP_CTRL_CONTEXT_STATE_DW20*32) : 0+(CP_CTRL_CONTEXT_STATE_DW20*32)]   CPC_CTRL_CONTEXT_PERFORMANCE_TRACKED   = 1'h0;
    localparam integer CPC_CTRL_CONTEXT_PERFORMANCE_TRACKED_FIELDWIDTH = 1; 




    //DW21
    localparam int    CP_CTRL_CONTEXT_STATE_DW21                          = 5;
    localparam [9+(CP_CTRL_CONTEXT_STATE_DW21*32) : 0+(CP_CTRL_CONTEXT_STATE_DW21*32)]   CPC_CTRL_CONTEXT_STATE_NU_WORKGROUP_SIZE_X     = 10'h0;
    localparam integer CPC_CTRL_CONTEXT_STATE_NU_WORKGROUP_SIZE_X_FIELDWIDTH = 10; 

    localparam [19+(CP_CTRL_CONTEXT_STATE_DW21*32) : 10+(CP_CTRL_CONTEXT_STATE_DW21*32)]   CPC_CTRL_CONTEXT_STATE_NU_WORKGROUP_SIZE_Y     = 10'h0;
    localparam integer CPC_CTRL_CONTEXT_STATE_NU_WORKGROUP_SIZE_Y_FIELDWIDTH = 10; 

    localparam [29+(CP_CTRL_CONTEXT_STATE_DW21*32) : 20+(CP_CTRL_CONTEXT_STATE_DW21*32)]   CPC_CTRL_CONTEXT_STATE_NU_WORKGROUP_SIZE_Z     = 10'h0;
    localparam integer CPC_CTRL_CONTEXT_STATE_NU_WORKGROUP_SIZE_Z_FIELDWIDTH = 10; 



    //DW22
    localparam int    CP_CTRL_CONTEXT_STATE_DW22                          = 6;
    localparam [31+(CP_CTRL_CONTEXT_STATE_DW22*32) : 28+(CP_CTRL_CONTEXT_STATE_DW22*32)]   CPC_CTRL_CONTEXT_STATE_BARRIER_VALUE     = 4'h0;
    localparam integer CPC_CTRL_CONTEXT_STATE_BARRIER_VALUE_FIELDWIDTH = 4; 

    localparam [19+(CP_CTRL_CONTEXT_STATE_DW22*32) : 19+(CP_CTRL_CONTEXT_STATE_DW22*32)]   CPC_CTRL_CONTEXT_STATE_WG_DISPATCH_MODE     = 1'h0;
    localparam integer CPC_CTRL_CONTEXT_STATE_WG_DISPATCH_MODE_FIELDWIDTH = 1; 

    localparam [18+(CP_CTRL_CONTEXT_STATE_DW22*32) : 16+(CP_CTRL_CONTEXT_STATE_DW22*32)]   CPC_CTRL_CONTEXT_STATE_WI_NEED_DIM     = 3'h0;
    localparam integer CPC_CTRL_CONTEXT_STATE_WI_NEED_DIM_FIELDWIDTH = 3; 

    localparam [15+(CP_CTRL_CONTEXT_STATE_DW22*32) : 13+(CP_CTRL_CONTEXT_STATE_DW22*32)]   CPC_CTRL_CONTEXT_STATE_WG_NEED_DIM     = 3'h0;
    localparam integer CPC_CTRL_CONTEXT_STATE_WG_NEED_DIM_FIELDWIDTH = 3;

    localparam [12+(CP_CTRL_CONTEXT_STATE_DW22*32) : 0+(CP_CTRL_CONTEXT_STATE_DW22*32)]   CPC_CTRL_CONTEXT_STATE_UNIFIED_STORE_OFFEST     = 13'h0;
    localparam integer CPC_CTRL_CONTEXT_STATE_UNIFIED_STORE_OFFEST_FIELDWIDTH = 13;


   //DW23
    localparam int    CP_CTRL_CONTEXT_STATE_DW23                          = 7;
    localparam [30+(CP_CTRL_CONTEXT_STATE_DW23*32) : 30+(CP_CTRL_CONTEXT_STATE_DW23*32)]   CPC_CTRL_CONTEXT_STATE_BARRIER   = 1'h0;
    localparam integer CPC_CTRL_CONTEXT_STATE_BARRIER_FIELDWIDTH = 1; 

    localparam [29+(CP_CTRL_CONTEXT_STATE_DW23*32) : 0+(CP_CTRL_CONTEXT_STATE_DW23*32)]   CPC_CTRL_CONTEXT_STATE_CU_PC   = 30'h0;
    localparam integer CPC_CTRL_CONTEXT_STATE_CU_PC_FIELDWIDTH = 30; 


   //DW24
    localparam int    CP_CTRL_CONTEXT_STATE_DW24                          = 8;
    localparam [0+(CP_CTRL_CONTEXT_STATE_DW24*32) : 0+(CP_CTRL_CONTEXT_STATE_DW24*32)]   CPC_CTRL_CONTEXT_STATE_OBJECT_FLUSHINV_ENABLE   = 1'h0;
    localparam integer CPC_CTRL_CONTEXT_STATE_OBJECT_FLUSHINV_ENABLE_FIELDWIDTH = 1; 

    localparam [1+(CP_CTRL_CONTEXT_STATE_DW24*32) : 1+(CP_CTRL_CONTEXT_STATE_DW24*32)]   CPC_CTRL_CONTEXT_STATE_OBJECT_CACHE_CTRL   = 1'h0;
    localparam integer CPC_CTRL_CONTEXT_STATE_OBJECT_CACHE_CTRL_FIELDWIDTH = 1; 

    localparam [5+(CP_CTRL_CONTEXT_STATE_DW24*32) : 2+(CP_CTRL_CONTEXT_STATE_DW24*32)]   CPC_CTRL_CONTEXT_STATE_OBJECT_ATOMIC_OP   = 4'h0;
    localparam integer CPC_CTRL_CONTEXT_STATE_OBJECT_ATOMIC_OP_FIELDWIDTH = 4; 

    localparam [21+(CP_CTRL_CONTEXT_STATE_DW24*32) : 6+(CP_CTRL_CONTEXT_STATE_DW24*32)]   CPC_CTRL_CONTEXT_STATE_OBJECT_ADDRESS_MSB   = 16'h0;
    localparam integer CPC_CTRL_CONTEXT_STATE_OBJECT_ADDRESS_MSB_FIELDWIDTH = 16; 

   //DW25
    localparam int    CP_CTRL_CONTEXT_STATE_DW25                          = 9;
    localparam [28+(CP_CTRL_CONTEXT_STATE_DW25*32) : 0+(CP_CTRL_CONTEXT_STATE_DW25*32)]   CPC_CTRL_CONTEXT_STATE_OBJECT_ADDRESS_LSB   = 29'h0;
    localparam integer CPC_CTRL_CONTEXT_STATE_OBJECT_ADDRESS_LSB_FIELDWIDTH = 29; 

    //DW26
    localparam int    CP_CTRL_CONTEXT_STATE_DW26                          = 10;
    localparam [31+(CP_CTRL_CONTEXT_STATE_DW26*32) : 0+(CP_CTRL_CONTEXT_STATE_DW26*32)]   CPC_CTRL_CONTEXT_STATE_OBJECT_DATA_MSB   = 32'h0;
    localparam integer CPC_CTRL_CONTEXT_STATE_OBJECT_DATA_MSB_FIELDWIDTH = 32; 

    //DW27
    localparam int    CP_CTRL_CONTEXT_STATE_DW27                          = 11;
    localparam [31+(CP_CTRL_CONTEXT_STATE_DW27*32) : 0+(CP_CTRL_CONTEXT_STATE_DW27*32)]   CPC_CTRL_CONTEXT_STATE_OBJECT_DATA_LSB   = 32'h0;
    localparam integer CPC_CTRL_CONTEXT_STATE_OBJECT_DATA_LSB_FIELDWIDTH = 32; 


    //DW28
    localparam int    CP_CTRL_CONTEXT_STATE_DW28                          = 12;
    localparam [31+(CP_CTRL_CONTEXT_STATE_DW28*32) : 16+(CP_CTRL_CONTEXT_STATE_DW28*32)]   CPC_CTRL_CONTEXT_STATE_TIMESTAMP_END_ADDR_MSB   = 16'h0;
    localparam integer CPC_CTRL_CONTEXT_STATE_TIMESTAMP_END_ADDR_MSB_FIELDWIDTH = 16; 

    //DW29
    localparam int    CP_CTRL_CONTEXT_STATE_DW29                          = 13;
    localparam [28+(CP_CTRL_CONTEXT_STATE_DW29*32) : 0+(CP_CTRL_CONTEXT_STATE_DW29*32)]   CPC_CTRL_CONTEXT_STATE_TIMESTAMP_END_ADDR_LSB   = 29'h0;
    localparam integer CPC_CTRL_CONTEXT_STATE_TIMESTAMP_END_ADDR_LSB_FIELDWIDTH = 29; 
    
    //kernel id
    localparam [5 : 0]   CPC_CTRL_PT_DATA_KERNEL_ID   = 6'h0;
    localparam integer CPC_CTRL_PT_DATA_KERNEL_ID_FIELDWIDTH   = 6; 
    
    typedef logic [3 : 0]   CPC_CTRL_aa_operation_type;
    //Encoding of the AA_OPERATION field
    localparam CPC_CTRL_aa_operation_type  CPC_CTRL_AA_OPERATION_EVENT     = 4'hf;  // EVENT (0xf)



    //GC_CR_COMPUTE_MSS_MMU_AUTO_CACHE_OPS_CTRL register
    localparam [0 : 0]     GC_CR_COMPUTE_MSS_MMU_AUTO_CACHE_OPS_CTRL_MSS_INVALIDATE_BITFIELD        = 1'h0;
    localparam integer GC_CR_COMPUTE_MSS_MMU_AUTO_CACHE_OPS_CTRL_MSS_INVALIDATE_BITFIELD_FILE_WIDTH = 1;  

    localparam [1 : 1]     GC_CR_COMPUTE_MSS_MMU_AUTO_CACHE_OPS_CTRL_MSS_FLUSH_BITFIELD             = 1'h0;
    localparam integer GC_CR_COMPUTE_MSS_MMU_AUTO_CACHE_OPS_CTRL_MSS_FLUSH_BITFIELD_FILE_WIDTH      = 1;  



    //pim send kernel
    localparam int    CP_CTRL_PIM_DW0                         = 0;
    localparam [3+(CP_CTRL_PIM_DW0*32) : 0+ (CP_CTRL_PIM_DW0*32)]     CPC_CTRL_PIM_VFID = 4'h0;
    localparam integer CPC_CTRL_PIM_VFID_FIELDWIDTH = 4;

    localparam [13+(CP_CTRL_PIM_DW0*32) : 4+ (CP_CTRL_PIM_DW0*32)]    CPC_CTRL_PIM_PASID = 10'h0;
    localparam integer CPC_CTRL_PIM_PASID_FIELDWIDTH = 10;

    localparam [15+(CP_CTRL_PIM_DW0*32) : 14+ (CP_CTRL_PIM_DW0*32)]   CPC_CTRL_PIM_DMID = 2'h0;
    localparam integer CPC_CTRL_PIM_DMID_FIELDWIDTH = 2;

    localparam [19+(CP_CTRL_PIM_DW0*32) : 16+ (CP_CTRL_PIM_DW0*32)]   CPC_CTRL_PIM_DM_QUEUE_ID = 4'h0;
    localparam integer CPC_CTRL_PIM_DM_QUEUE_ID_FIELDWIDTH = 4;

    localparam [27+(CP_CTRL_PIM_DW0*32) : 20+ (CP_CTRL_PIM_DW0*32)]   CPC_CTRL_PIM_KERNEL_ID = 8'h0;
    localparam integer CPC_CTRL_PIM_KERNEL_ID_FIELDWIDTH = 8;
    
    localparam [31+(CP_CTRL_PIM_DW0*32) : 28+ (CP_CTRL_PIM_DW0*32)]   CPC_CTRL_PIM_RESERVE = 4'h0;
    localparam integer CPC_CTRL_PIM_RESERVE_FIELDWIDTH = 4;



    localparam int    CP_CTRL_PIM_DW1                         = 1;
    localparam [31+(CP_CTRL_PIM_DW1*32) : 0+ (CP_CTRL_PIM_DW1*32)]     CPC_CTRL_PIM_DW1_RESERVE = 32'h0;
    localparam integer CPC_CTRL_PIM_DW1_RESERVE_FIELDWIDTH = 32;

    localparam int    CP_CTRL_PIM_DW2                         = 2;
    localparam [31+(CP_CTRL_PIM_DW2*32) : 0+ (CP_CTRL_PIM_DW2*32)]     CPC_CTRL_PIM_DW2_DATA = 32'h0;
    localparam integer CPC_CTRL_PIM_DW2_DATA_FIELDWIDTH = 32;


    localparam int    CP_CTRL_PIM_DW3                         = 3;
    localparam [31+(CP_CTRL_PIM_DW3*32) : 0+ (CP_CTRL_PIM_DW3*32)]     CPC_CTRL_PIM_DW3_DATA = 32'h0;
    localparam integer CPC_CTRL_PIM_DW3_DATA_FIELDWIDTH = 32;


    localparam int    CP_CTRL_PIM_DW4                         = 4;
    localparam [31+(CP_CTRL_PIM_DW4*32) : 0+ (CP_CTRL_PIM_DW4*32)]     CPC_CTRL_PIM_DW4_DATA = 32'h0;
    localparam integer CPC_CTRL_PIM_DW4_DATA_FIELDWIDTH = 32;


    localparam int    CP_CTRL_PIM_DW5                         = 5;
    localparam [31+(CP_CTRL_PIM_DW5*32) : 0+ (CP_CTRL_PIM_DW5*32)]     CPC_CTRL_PIM_DW5_DATA = 32'h0;
    localparam integer CPC_CTRL_PIM_DW5_DATA_FIELDWIDTH = 32;


    localparam int    CP_CTRL_PIM_DW6                         = 6;
    localparam [31+(CP_CTRL_PIM_DW6*32) : 0+ (CP_CTRL_PIM_DW6*32)]     CPC_CTRL_PIM_DW6_DATA = 32'h0;
    localparam integer CPC_CTRL_PIM_DW6_DATA_FIELDWIDTH = 32;


    localparam int    CP_CTRL_PIM_DW7                         = 7;
    localparam [31+(CP_CTRL_PIM_DW7*32) : 0+ (CP_CTRL_PIM_DW7*32)]     CPC_CTRL_PIM_DW7_DATA = 32'h0;
    localparam integer CPC_CTRL_PIM_DW7_DATA_FIELDWIDTH = 32;

    localparam int    CP_CTRL_PIM_DW8                         = 8;
    localparam [31+(CP_CTRL_PIM_DW8*32) : 0+ (CP_CTRL_PIM_DW8*32)]     CPC_CTRL_PIM_DW8_DATA = 32'h0;
    localparam integer CPC_CTRL_PIM_DW8_DATA_FIELDWIDTH = 32;

    localparam int    CP_CTRL_PIM_DW9                         = 9;
    localparam [31+(CP_CTRL_PIM_DW9*32) : 0+ (CP_CTRL_PIM_DW9*32)]     CPC_CTRL_PIM_DW9_DATA = 32'h0;
    localparam integer CPC_CTRL_PIM_DW9_DATA_FIELDWIDTH = 32;


    localparam int    CP_CTRL_PIM_DW10                         = 10;
    localparam [31+(CP_CTRL_PIM_DW10*32) : 0+ (CP_CTRL_PIM_DW10*32)]     CPC_CTRL_PIM_DW10_DATA = 32'h0;
    localparam integer CPC_CTRL_PIM_DW10_DATA_FIELDWIDTH = 32;


    localparam int    CP_CTRL_PIM_DW11                         = 11;
    localparam [31+(CP_CTRL_PIM_DW11*32) : 0+ (CP_CTRL_PIM_DW11*32)]     CPC_CTRL_PIM_DW11_DATA = 32'h0;
    localparam integer CPC_CTRL_PIM_DW11_DATA_FIELDWIDTH = 32;


    localparam int    CP_CTRL_PIM_DW12                         = 12;
    localparam [31+(CP_CTRL_PIM_DW12*32) : 0+ (CP_CTRL_PIM_DW12*32)]     CPC_CTRL_PIM_DW12_DATA = 32'h0;
    localparam integer CPC_CTRL_PIM_DW12_DATA_FIELDWIDTH = 32;


    localparam int    CP_CTRL_PIM_DW13                         = 13;
    localparam [31+(CP_CTRL_PIM_DW13*32) : 0+ (CP_CTRL_PIM_DW13*32)]     CPC_CTRL_PIM_DW13_DATA = 32'h0;
    localparam integer CPC_CTRL_PIM_DW13_DATA_FIELDWIDTH = 32;


    localparam int    CP_CTRL_PIM_DW14                         = 14;
    localparam [31+(CP_CTRL_PIM_DW14*32) : 0+ (CP_CTRL_PIM_DW14*32)]     CPC_CTRL_PIM_DW14_DATA = 32'h0;
    localparam integer CPC_CTRL_PIM_DW14_DATA_FIELDWIDTH = 32;


    localparam int    CP_CTRL_PIM_DW15                         = 15;
    localparam [31+(CP_CTRL_PIM_DW15*32) : 0+ (CP_CTRL_PIM_DW15*32)]     CPC_CTRL_PIM_DW15_DATA = 32'h0;
    localparam integer CPC_CTRL_PIM_DW15_DATA_FIELDWIDTH = 32;



endpackage 

