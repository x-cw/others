
module ecc_decoder #(
    parameter data_width     =  32,
    parameter ecc_width_in   =  7
) (
  input   [data_width-1:0]  data,
  input   [ecc_width_in-1:0]     ecc,
  input                     ecc_enable,
  output  [data_width-1:0]  data_out,
  output                    cor_err,
  output                    unc_err
);


localparam  mask_p10=800'hFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFC00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
localparam  mask_p9=800'hFFFFFFFFFFE0000000000000000000000000000000000000000000000000000000000000003FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF80000000000000000000000000000000000000000000000000000000000000;
localparam  mask_p8=800'h00000000001FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFE00000000000000000000000000000003FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFC00000000000000000000000000000007FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000000000000000000000000000;
localparam  mask_p7=800'h00000000001FFFFFFFFFFFFFFFE0000000000000001FFFFFFFFFFFFFFFE0000000000000003FFFFFFFFFFFFFFFC0000000000000003FFFFFFFFFFFFFFFC0000000000000007FFFFFFFFFFFFFFF8000000000000000FFFFFFFFFFFFFFFE00000000000000;
localparam  mask_p6=800'hFFE00000001FFFFFFFE00000001FFFFFFFE00000001FFFFFFFE00000001FFFFFFFE00000003FFFFFFFC00000003FFFFFFFC00000003FFFFFFFC00000003FFFFFFFC00000007FFFFFFF800000007FFFFFFF80000000FFFFFFFF00000001FFFFFFFC000000;
localparam  mask_p5=800'h001FFFE0001FFFE0001FFFE0001FFFE0001FFFE0001FFFE0001FFFE0001FFFE0001FFFE0003FFFC0003FFFC0003FFFC0003FFFC0003FFFC0003FFFC0003FFFC0003FFFC0007FFF80007FFF80007FFF80007FFF8000FFFF0000FFFF0001FFFE0003FFF800;
localparam  mask_p4=800'hE01FE01FE01FE01FE01FE01FE01FE01FE01FE01FE01FE01FE01FE01FE01FE01FE01FE01FE03FC03FC03FC03FC03FC03FC03FC03FC03FC03FC03FC03FC03FC03FC03FC03FC07F807F807F807F807F807F807F807F80FF00FF00FF00FF01FE01FE03FC07F0;
localparam  mask_p3=800'h1E1E1E1E1E1E1E1E1E1E1E1E1E1E1E1E1E1E1E1E1E1E1E1E1E1E1E1E1E1E1E1E1E1E1E1E1E3C3C3C3C3C3C3C3C3C3C3C3C3C3C3C3C3C3C3C3C3C3C3C3C3C3C3C3C3C3C3C3C78787878787878787878787878787878F0F0F0F0F0F0F0F1E1E1E1E3C3C78E;
localparam  mask_p2=800'h99999999999999999999999999999999999999999999999999999999999999999999999999B33333333333333333333333333333333333333333333333333333333333333366666666666666666666666666666666CCCCCCCCCCCCCCCD9999999B33366D;
localparam  mask_p1=800'h555555555555555555555555555555555555555555555555555555555555555555555555556AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD5555555555555555555555555555555AAAAAAAAAAAAAAAB55555556AAAD5B;
localparam  mask_p0=800'h32CD32D2CD2D32D2CD32CD2D32D2CD2D32CD32D2CD32CD2D32CD32D2CD2D32D2CD32CD2D32DA65A59A659A5A65A59A5A659A65A59A659A5A659A65A59A5A65A59A659A5A65CB34B4CB34CB4B34B4CB4B34CB34B4CB69969669966969972CD2D32DA65CB7;

 generate 
    if (5<=data_width && data_width<=11) begin : decoder_width_5_11
        localparam ecc_width = 5;
        wire  [ecc_width-1:0]   ecc_post;
        wire  [ecc_width-1:0]   syndrome;
        wire  [ecc_width-2:0]   err_bit;
        wire  [data_width-1:0]  data_out_ecc;
        wire  [data_width+ecc_width-1:0]  data_temp;
        wire  [data_width+ecc_width-1:0]  data_out_temp;
        wire  [data_width+ecc_width-1:0]  shift='h1; 
        assign syndrome       = ecc ^ ecc_post;
        assign cor_err        = (|syndrome[ecc_width-1:0]) &  syndrome[0];
        assign unc_err        = (|syndrome[ecc_width-1:0]) & ~syndrome[0];
        assign data_out_temp  = data_temp ^ (shift << err_bit);

        assign err_bit        = {syndrome[4],syndrome[3],syndrome[2],syndrome[1]};
        assign data_temp      = {data[data_width-1:4],1'b0,data[3:1],1'b0,data[0],3'b0};
        assign data_out_ecc      = {data_out_temp[data_width+ecc_width-1:9],data_out_temp[7:5],data_out_temp[3]};
        assign ecc_post[0] = (^data)^(^ecc[ecc_width-1:1]);
        assign ecc_post[1] = ^ (data &  mask_p1[data_width-1:0]);
        assign ecc_post[2] = ^ (data &  mask_p2[data_width-1:0]);
        assign ecc_post[3] = ^ (data &  mask_p3[data_width-1:0]);
        assign ecc_post[4] = ^ (data &  mask_p4[data_width-1:0]);

        assign data_out  = ecc_enable ? ~unc_err ?data_out_ecc:data :data;
    end
    else if (12<=data_width && data_width<=26) begin : decoder_width_12_26
        localparam ecc_width = 6;
        wire  [ecc_width-1:0]   ecc_post;
        wire  [ecc_width-1:0]   syndrome;
        wire  [ecc_width-2:0]   err_bit;
        wire  [data_width-1:0]  data_out_ecc;
        wire  [data_width+ecc_width-1:0]  data_temp;
        wire  [data_width+ecc_width-1:0]  data_out_temp;
        wire  [data_width+ecc_width-1:0]  shift='h1; 
        assign syndrome       = ecc ^ ecc_post;
        assign cor_err        = (|syndrome[ecc_width-1:0]) &  syndrome[0];
        assign unc_err        = (|syndrome[ecc_width-1:0]) & ~syndrome[0];
        assign data_out_temp  = data_temp ^ (shift << err_bit);

        assign err_bit        = {syndrome[5],syndrome[4],syndrome[3],syndrome[2],syndrome[1]};
        assign data_temp      = {data[data_width-1:11],1'b0,data[10:4],1'b0,data[3:1],1'b0,data[0],3'b0};
        assign data_out_ecc       = {data_out_temp[data_width+ecc_width-1:17],data_out_temp[15:9],data_out_temp[7:5],data_out_temp[3]};
        assign ecc_post[0] = (^data)^(^ecc[ecc_width-1:1]);
        assign ecc_post[1] = ^ (data &  mask_p1[data_width-1:0]);
        assign ecc_post[2] = ^ (data &  mask_p2[data_width-1:0]);
        assign ecc_post[3] = ^ (data &  mask_p3[data_width-1:0]);
        assign ecc_post[4] = ^ (data &  mask_p4[data_width-1:0]);
        assign ecc_post[5] = ^ (data &  mask_p5[data_width-1:0]);

        assign data_out  = ecc_enable ? ~unc_err ?data_out_ecc:data :data;
    end
    else if (27<=data_width && data_width<=57) begin : decoder_width_27_57
        localparam ecc_width = 7;
        wire  [ecc_width-1:0]   ecc_post;
        wire  [ecc_width-1:0]   syndrome;
        wire  [ecc_width-2:0]   err_bit;
        wire  [data_width-1:0]  data_out_ecc;
        wire  [data_width+ecc_width-1:0]  data_temp;
        wire  [data_width+ecc_width-1:0]  data_out_temp;
        wire  [data_width+ecc_width-1:0]  shift='h1; 
        assign syndrome       = ecc ^ ecc_post;
        assign cor_err        = (|syndrome[ecc_width-1:0]) &  syndrome[0];
        assign unc_err        = (|syndrome[ecc_width-1:0]) & ~syndrome[0];
        assign data_out_temp  = data_temp ^ (shift << err_bit);

        assign err_bit        = {syndrome[6],syndrome[5],syndrome[4],syndrome[3],syndrome[2],syndrome[1]};
        assign data_temp      = {data[data_width-1:26],1'b0,data[25:11],1'b0,data[10:4],1'b0,data[3:1],1'b0,data[0],3'b0};
        assign data_out_ecc       = {data_out_temp[data_width+ecc_width-1:33],data_out_temp[31:17],data_out_temp[15:9],data_out_temp[7:5],data_out_temp[3]};
        assign ecc_post[0] = (^data)^(^ecc[ecc_width-1:1]);
        assign ecc_post[1] = ^ (data &  mask_p1[data_width-1:0]);
        assign ecc_post[2] = ^ (data &  mask_p2[data_width-1:0]);
        assign ecc_post[3] = ^ (data &  mask_p3[data_width-1:0]);
        assign ecc_post[4] = ^ (data &  mask_p4[data_width-1:0]);
        assign ecc_post[5] = ^ (data &  mask_p5[data_width-1:0]);
        assign ecc_post[6] = ^ (data &  mask_p6[data_width-1:0]);

        assign data_out  = ecc_enable ? ~unc_err ?data_out_ecc:data :data;
    end
    else if (58<=data_width && data_width<=120) begin : decoder_width_58_120
        localparam ecc_width = 8;
        wire  [ecc_width-1:0]   ecc_post;
        wire  [ecc_width-1:0]   syndrome;
        wire  [ecc_width-2:0]   err_bit;
        wire  [data_width-1:0]  data_out_ecc;
        wire  [data_width+ecc_width-1:0]  data_temp;
        wire  [data_width+ecc_width-1:0]  data_out_temp;
        wire  [data_width+ecc_width-1:0]  shift='h1; 
        assign syndrome       = ecc ^ ecc_post;
        assign cor_err        = (|syndrome[ecc_width-1:0]) &  syndrome[0];
        assign unc_err        = (|syndrome[ecc_width-1:0]) & ~syndrome[0];
        assign data_out_temp  = data_temp ^ (shift << err_bit);
        
        assign err_bit        = {syndrome[7],syndrome[6],syndrome[5],syndrome[4],syndrome[3],syndrome[2],syndrome[1]};
        assign data_temp      = {data[data_width-1:57],1'b0,data[56:26],1'b0,data[25:11],1'b0,data[10:4],1'b0,data[3:1],1'b0,data[0],3'b0};
        assign data_out_ecc       = {data_out_temp[data_width+ecc_width-1:65],data_out_temp[63:33],data_out_temp[31:17],data_out_temp[15:9],data_out_temp[7:5],data_out_temp[3]};
        
        assign ecc_post[0] = (^data)^(^ecc[ecc_width-1:1]);
        assign ecc_post[1] = ^ (data &  mask_p1[data_width-1:0]);
        assign ecc_post[2] = ^ (data &  mask_p2[data_width-1:0]);
        assign ecc_post[3] = ^ (data &  mask_p3[data_width-1:0]);
        assign ecc_post[4] = ^ (data &  mask_p4[data_width-1:0]);
        assign ecc_post[5] = ^ (data &  mask_p5[data_width-1:0]);
        assign ecc_post[6] = ^ (data &  mask_p6[data_width-1:0]);
        assign ecc_post[7] = ^ (data &  mask_p7[data_width-1:0]);

        assign data_out  = ecc_enable ? ~unc_err ?data_out_ecc:data :data;
    end
    else if (121<=data_width && data_width<=247) begin : decoder_width_121_247
        localparam ecc_width = 9;
        wire  [ecc_width-1:0]   ecc_post;
        wire  [ecc_width-1:0]   syndrome;
        wire  [ecc_width-2:0]   err_bit;
        wire  [data_width-1:0]  data_out_ecc;
        wire  [data_width+ecc_width-1:0]  data_temp;
        wire  [data_width+ecc_width-1:0]  data_out_temp;
        wire  [data_width+ecc_width-1:0]  shift='h1; 
        assign syndrome       = ecc ^ ecc_post;
        assign cor_err        = (|syndrome[ecc_width-1:0]) &  syndrome[0];
        assign unc_err        = (|syndrome[ecc_width-1:0]) & ~syndrome[0];
        assign data_out_temp  = data_temp ^ (shift << err_bit);
      
        assign err_bit        = {syndrome[8],syndrome[7],syndrome[6],syndrome[5],syndrome[4],syndrome[3],syndrome[2],syndrome[1]};
        assign data_temp      = {data[data_width-1:120],1'b0,data[119:57],1'b0,data[56:26],1'b0,data[25:11],1'b0,data[10:4],1'b0,data[3:1],1'b0,data[0],3'b0};
        assign data_out_ecc       = {data_out_temp[data_width+ecc_width-1:129],data_out_temp[127:65],data_out_temp[63:33],data_out_temp[31:17],data_out_temp[15:9],data_out_temp[7:5],data_out_temp[3]};
 
        assign ecc_post[0] = (^data)^(^ecc[ecc_width-1:1]);
        assign ecc_post[1] = ^ (data &  mask_p1[data_width-1:0]);
        assign ecc_post[2] = ^ (data &  mask_p2[data_width-1:0]);
        assign ecc_post[3] = ^ (data &  mask_p3[data_width-1:0]);
        assign ecc_post[4] = ^ (data &  mask_p4[data_width-1:0]);
        assign ecc_post[5] = ^ (data &  mask_p5[data_width-1:0]);
        assign ecc_post[6] = ^ (data &  mask_p6[data_width-1:0]);
        assign ecc_post[7] = ^ (data &  mask_p7[data_width-1:0]);
        assign ecc_post[8] = ^ (data &  mask_p8[data_width-1:0]);

        assign data_out  = ecc_enable ? ~unc_err ?data_out_ecc:data :data;
    end
    else if (248<=data_width && data_width<=502) begin : decoder_width_248_502
        localparam ecc_width = 10;
        wire  [ecc_width-1:0]   ecc_post;
        wire  [ecc_width-1:0]   syndrome;
        wire  [ecc_width-2:0]   err_bit;
        wire  [data_width-1:0]  data_out_ecc;
        wire  [data_width+ecc_width-1:0]  data_temp;
        wire  [data_width+ecc_width-1:0]  data_out_temp;
        wire  [data_width+ecc_width-1:0]  shift='h1; 
        assign syndrome       = ecc ^ ecc_post;
        assign cor_err        = (|syndrome[ecc_width-1:0]) &  syndrome[0];
        assign unc_err        = (|syndrome[ecc_width-1:0]) & ~syndrome[0];
        assign data_out_temp  = data_temp ^ (shift << err_bit);
      
        assign err_bit        = {syndrome[9],syndrome[8],syndrome[7],syndrome[6],syndrome[5],syndrome[4],syndrome[3],syndrome[2],syndrome[1]};
        assign data_temp      = {data[data_width-1:247],1'b0,data[246:120],1'b0,data[119:57],1'b0,data[56:26],1'b0,data[25:11],1'b0,data[10:4],1'b0,data[3:1],1'b0,data[0],3'b0};
        assign data_out_ecc       = {data_out_temp[data_width+ecc_width-1:257],data_out_temp[255:129],data_out_temp[127:65],data_out_temp[63:33],data_out_temp[31:17],data_out_temp[15:9],data_out_temp[7:5],data_out_temp[3]};
 
        assign ecc_post[0] = (^data)^(^ecc[ecc_width-1:1]);
        assign ecc_post[1] = ^ (data &  mask_p1[data_width-1:0]);
        assign ecc_post[2] = ^ (data &  mask_p2[data_width-1:0]);
        assign ecc_post[3] = ^ (data &  mask_p3[data_width-1:0]);
        assign ecc_post[4] = ^ (data &  mask_p4[data_width-1:0]);
        assign ecc_post[5] = ^ (data &  mask_p5[data_width-1:0]);
        assign ecc_post[6] = ^ (data &  mask_p6[data_width-1:0]);
        assign ecc_post[7] = ^ (data &  mask_p7[data_width-1:0]);
        assign ecc_post[8] = ^ (data &  mask_p8[data_width-1:0]);
        assign ecc_post[9] = ^ (data &  mask_p9[data_width-1:0]);

        assign data_out  = ecc_enable ? ~unc_err ?data_out_ecc:data :data;
    end
    else if (503<=data_width && data_width<=800) begin : decoder_width_503_800
        localparam ecc_width = 11;
        wire  [ecc_width-1:0]   ecc_post;
        wire  [ecc_width-1:0]   syndrome;
        wire  [ecc_width-2:0]   err_bit;
        wire  [data_width-1:0]  data_out_ecc;
        wire  [data_width+ecc_width-1:0]  data_temp;
        wire  [data_width+ecc_width-1:0]  data_out_temp;
        wire  [data_width+ecc_width-1:0]  shift='h1; 
        assign syndrome       = ecc ^ ecc_post;
        assign cor_err        = (|syndrome[ecc_width-1:0]) &  syndrome[0];
        assign unc_err        = (|syndrome[ecc_width-1:0]) & ~syndrome[0];
        assign data_out_temp  = data_temp ^ (shift << err_bit);
      
        assign err_bit        = {syndrome[10],syndrome[9],syndrome[8],syndrome[7],syndrome[6],syndrome[5],syndrome[4],syndrome[3],syndrome[2],syndrome[1]};
        assign data_temp      = {data[data_width-1:502],1'b0,data[501:247],1'b0,data[246:120],1'b0,data[119:57],1'b0,data[56:26],1'b0,data[25:11],1'b0,data[10:4],1'b0,data[3:1],1'b0,data[0],3'b0};
        assign data_out_ecc       = {data_out_temp[data_width+ecc_width-1:513],data_out_temp[511:257],data_out_temp[255:129],data_out_temp[127:65],data_out_temp[63:33],data_out_temp[31:17],data_out_temp[15:9],data_out_temp[7:5],data_out_temp[3]};
 
        assign ecc_post[0] = (^data)^(^ecc[ecc_width-1:1]);
        assign ecc_post[1] = ^ (data &  mask_p1[data_width-1:0]);
        assign ecc_post[2] = ^ (data &  mask_p2[data_width-1:0]);
        assign ecc_post[3] = ^ (data &  mask_p3[data_width-1:0]);
        assign ecc_post[4] = ^ (data &  mask_p4[data_width-1:0]);
        assign ecc_post[5] = ^ (data &  mask_p5[data_width-1:0]);
        assign ecc_post[6] = ^ (data &  mask_p6[data_width-1:0]);
        assign ecc_post[7] = ^ (data &  mask_p7[data_width-1:0]);
        assign ecc_post[8] = ^ (data &  mask_p8[data_width-1:0]);
        assign ecc_post[9] = ^ (data &  mask_p9[data_width-1:0]);
        assign ecc_post[10] = ^ (data &  mask_p10[data_width-1:0]);

        assign data_out  = ecc_enable ? ~unc_err ?data_out_ecc:data :data;
    end
endgenerate
endmodule

