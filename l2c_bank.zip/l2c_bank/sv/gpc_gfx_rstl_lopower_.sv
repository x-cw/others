/*

 * #==========================================================================#
 * |                                                                          |
 * |  Copyright (c) 2022, Fantasy Technologies Limited and/or its         |
 * |  affiliated group companies ("Fantasy"). All rights reserved.        |
 * |  No part of this content, either material or conceptual may be copied    |
 * |  or distributed, transmitted, transcribed, stored in a retrieval system  |
 * |  or translated into any human or computer language in any form by any    |
 * |  means, electronic, mechanical manual, or otherwise, or disclosed to     |
 * |  third parties without the express written permission of Fantasy.    |
 * |                                                                          |
 * #==========================================================================#

 */

// ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////-
// entity name: gpc_gfx_rstl_lopower (functionally identical to gpc_gfx_rstl, power optimised but with combinatorial output data, while 
// gpc_gfx_rstl has registered output data)
//
// Component Description: IMGLIB3 Registered Staller
// Inserts a register in the valid, enable and data path between upstream and downstream modules in order to break a timing path.
// Data from the upstream module is always subject to at least a cycle delay as a result of inserting an RSTL into the path.
//
// There are two data registers (reg0 and reg1). The input is loaded into one of the two registers with a demux (the control signal 
// is sel_in). The output is read from one of the two registers with a mux (the control signal is sel_out). If both registers 
// contain data, the one with the older data is muxed to the output, in order to preserve the order of the data entries.
//
// If one of the two register is full and it is not being read (vin=0) then the input data is loaded into the other register.
// If both registers are full, the enable going to the upstream (eout) is set to 0.
//
// The control logic is aimed to reduce the toggling of the control signals. So the control signals of the mux and demux changes 
// only when necessary.
//
// The power saving is obtained as the data is loaded only once (either into reg0 or reg1), while in gpc_gfx_rstl the data can be 
// propagated twice if it's loaded into hdl_din first (and then to dout).
// However, the output data (dout) is now combinatorial, so the timing is worse than in gpc_gfx_rstl. This could in some cases cause an 
// overall power increase, as the dout register could be the start point of a critical path.
//
// Power saving (compared to gpc_gfx_rstl) is typically obtained when the width is at least 16 bits.
//
// The area cost associated with adding a Registered Staller into the design is the 2 register stages of width W plus the muxing
// logic, however valid and data downstream, and enable upstream are all registered breaking any timing path across the interface.
//
// Generics:
// w           - INTEGER
//             - Width of Data bus Input/Output std_logic_vector
//
// Portlist:
// clk     - Clock Input
// resetn  - Active-low asynchronous Reset
// din     - Data bus input (sized by generic w)
// vin     - Valid input from upstream module
// eout    - Enable output to upstream module
// dout    - Data bus output (sized by generic w)
// vout    - Valid output to downstream module
// ein     - Enable input from downstream module
// ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////-
//
//                     +////////+     +              
//                     |        |     |\             
//            +////->  |  reg0  +//-> | \            
//            |        |        |     |  +           
//            |        +////////+     |  |           
//    din +//-+                       |  +////-> dout
//            |        +////////+     |  |           
//            |        |        |     |  +           
//            +////->  |  reg1  +//-> | /            
//                     |        |     |/             
//                     +////////+     +              
//
// ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////-



module gpc_gfx_rstl_lopower_
#(
   parameter int                                      w                                                            = 2               
)
(
   input    logic                                                        clk                                     ,
        input    logic                                                        resetn                                  ,
        // upstream signals
        input    logic [ w - 1 : 0 ]                                          din                                     ,
        input    logic                                                        vin                                     ,
        output   logic                                                        eout                                    ,
        // downstream signals
        output   logic [ w - 1 : 0 ]                                          dout                                    ,
        output   logic                                                        vout                                    ,
        input    logic                                                        ein                                       
);

   logic                                         both_reg_valid                          ;    // is is high when both registers contain valid data (it is equivalent to hld_vin of
   // gpc_gfx_rstl)
   logic                                         nxt_both_reg_valid                      ;
   logic                                         vout_i                                  ;
   logic                                         nxt_vout                                ;
   logic                                         eout_i                                  ;
   logic                                         nxt_eout                                ;
   logic                                         sel_in                                  ;
   logic                                         nxt_sel_in                              ;
   logic                                         sel_out                                 ;
   logic                                         nxt_sel_out                             ;

   logic [ w - 1 : 0 ]                           reg0                                    ;
   logic [ w - 1 : 0 ]                           reg1                                    ;

   logic                                         count0                                  ;
   logic                                         count1                                  ;

   
      always_ff @(posedge clk or negedge resetn) begin : rctrl
         if ( ( resetn == 1'b0 ) ) begin
            both_reg_valid <= 1'b0 ;
            vout_i <= 1'b0 ;
            eout_i <= 1'b1 ;
            sel_in <= 1'b0 ;
            sel_out <= 1'b0 ;
         end else begin
            both_reg_valid <= nxt_both_reg_valid ;
            vout_i <= nxt_vout ;
            eout_i <= nxt_eout ;
            sel_in <= nxt_sel_in ;
            sel_out <= nxt_sel_out ;
         end
      end // rctrl

      always_ff @(posedge clk) begin : data_regs_clkd
         begin
            if ( ( eout_i == 1'b1 & vin == 1'b1 ) ) begin    // input data are loaded in one of the two registers
               if ( nxt_sel_in == 1'b0 ) begin
                  reg0 <= din ;
               end else begin
                  reg1 <= din ;
               end
            end
         end
      end // data_regs_clkd

      // output mux
      assign dout = sel_out == 1'b0 ? reg0 : reg1  ; 

   // count0 is high when both registers are emtpy
      assign count0 = ~ both_reg_valid & ~ vout_i ;    // COV:tag2

      // count1 is high when only one register contains valid data
      assign count1 = ~ both_reg_valid & vout_i ;

      // input demux selection. It must change when new valid data are coming and one register already contains valid data (that are 
      // not being read)
      assign nxt_sel_in = vin == 1'b1 & count1 == 1'b1 & ein == 1'b0 ? ~ sel_in : sel_in  ; 

      // output mux selection. It is equal to:
      // nxt_sel_in : if the input data must be sent out at the next clock cycle, so when there are 
      // valid data in the input (vin=1), when the input is enabled (eout=1) and when there is not a valid output (vout=0).
      // not sel_out : if both the register contain valid data and one of them is being read, the mux selection must be switched
      // sel_out : otherwise mux selection must not change   
      assign nxt_sel_out = vin == 1'b1 & eout_i == 1'b1 & vout_i == 1'b0 ? nxt_sel_in : both_reg_valid == 1'b1 & ein == 1'b1 ? ~ sel_out : sel_out   ;    // COV:tag3  

      // Both of the registers contain valid data when there is already a valid output and it is not being taken and there is new input that 
      // is being taken. Otherwise if the output is taken and there is not a new valid input at least one register will not contain 
      // valid data in the next clock cycle so both_reg_valid will be low. Otherwise both_reg_valid will not change.
      assign nxt_both_reg_valid = vout_i == 1'b1 & ein == 1'b0 & vin == 1'b1 ? 1'b1 : ein == 1'b1 & ~ ( vin == 1'b1 & eout_i == 1'b1 ) ? 1'b0 : both_reg_valid   ;    // COV:tag4 

      // The input is enabled if the following cases:
      // When both of the registers are empty (count0=1)
      // When one of the register is full but the output is taken out or there is not a valid input
      // When both of the registers are full but the output is taken out
      assign nxt_eout = count0 == 1'b1 | ( count1 == 1'b1 & ( vin == 1'b0 | ein == 1'b1 ) ) | ( both_reg_valid == 1'b1 & ein == 1'b1 ) ? 1'b1 : 1'b0  ;    // COV:tag5 

      // The output will be not valid in the following cases:
      // When just one of the registers is full (count1=1) but it is read (ein=1) and there is not a valid input (vin=0)
      // When both of the registers are empty (count0=1) and the input is not valid (vin=0) or it is not enabled (eout=0). After a 
      // reset eout is low even if both of the registers are empty
      assign nxt_vout = ( count1 == 1'b1 & vin == 1'b0 & ein == 1'b1 ) | ( count0 == 1'b1 & ( vin == 1'b0 | eout_i == 1'b0 ) ) ? 1'b0 : 1'b1  ;    // COV:tag1 
      
      assign vout = vout_i ;
      assign eout = eout_i ;
   
endmodule // gpc_gfx_rstl_lopower
