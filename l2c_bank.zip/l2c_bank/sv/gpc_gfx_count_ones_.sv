/*

 * #==========================================================================#
 * |                                                                          |
 * |  Copyright (c) 2022, Fantasy Technologies Limited and/or its         |
 * |  affiliated group companies ("Fantasy"). All rights reserved.        |
 * |  No part of this content, either material or conceptual may be copied    |
 * |  or distributed, transmitted, transcribed, stored in a retrieval system  |
 * |  or translated into any human or computer language in any form by any    |
 * |  means, electronic, mechanical manual, or otherwise, or disclosed to     |
 * |  third parties without the express written permission of Fantasy.    |
 * |                                                                          |
 * #==========================================================================#

 */

module gpc_gfx_count_ones_ #(
   parameter int W = 4,
   parameter int RESULT_BITS = $clog2(W+1)
) (
   input  logic [ W-1:0 ]                vector                           ,
   output logic [ RESULT_BITS-1 : 0 ]    result
);

   logic [W-1:0][RESULT_BITS-1:0]      v_add;

   assign v_add[0] = (RESULT_BITS)'(vector[0]);

   for (genvar b = 1; b < W; b++) begin : g_add_bits
      assign v_add[b] = v_add[b-1] + (RESULT_BITS)'(vector[b]);
   end

   assign result = v_add[W-1];


endmodule
