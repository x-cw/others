//-----------------------------------------------------------------------------------------------------------------
//
//                file : gc_cr_l2g_regbank.sv
//
//           copyright : 2001-2020 by Imagination Technologies Limited. All rights
//                       reserved. No part of this hardware description, either
//                       material or conceptual may be copied or distributed,
//                       transmitted, transcribed, stored in a retrieval system
//                       or translated into any human or computer language in
//                       any form by any means, electronic, mechanical, manual
//                       or otherwise, or disclosed to third parties without
//                       the express written permission of Imagination
//                       Technologies Limited, Home Park Estate, Kings Langley,
//                       Hertfordshire, WD4 8LZ, U.K.
//
//     generated from : (null)
//                 by : regconv.c REL/1@6006852 
//-----------------------------------------------------------------------------------------------------------------

module gc_cr_l2g_regbank
import gc_cr_global_regpack_::*;
(
     input logic              clk
    ,input logic              resetn
    // external register access (via router) N.B. no flow control

    ,input  logic             regbank_valid
    ,input  logic [ 16 : 0 ]  regbank_addr
    ,input  logic [ 63 : 0 ]  regbank_wdata
    ,input  logic [ 7 : 0 ]   regbank_wmask
    ,input  logic             regbank_rdnwr
    ,output logic [ 63 : 0 ]  regbank_rdata
    ,output logic             regbank_rvalid
    ,input logic [  2 : 0 ]  regbank_instance


    // register gc_cr_l2_cfi_statusii (0xe0a0)
    ,input logic  gc_cr_l2_cfi_statusii_l2b64
    ,input logic  gc_cr_l2_cfi_statusii_l2b65
    ,input logic  gc_cr_l2_cfi_statusii_l2b66
    ,input logic  gc_cr_l2_cfi_statusii_l2b67
    ,input logic  gc_cr_l2_cfi_statusii_l2b68
    ,input logic  gc_cr_l2_cfi_statusii_l2b69
    ,input logic  gc_cr_l2_cfi_statusii_l2b70
    ,input logic  gc_cr_l2_cfi_statusii_l2b71
    ,input logic  gc_cr_l2_cfi_statusii_l2b72
    ,input logic  gc_cr_l2_cfi_statusii_l2b73
    ,input logic  gc_cr_l2_cfi_statusii_l2b74
    ,input logic  gc_cr_l2_cfi_statusii_l2b75
    ,input logic  gc_cr_l2_cfi_statusii_l2b76
    ,input logic  gc_cr_l2_cfi_statusii_l2b77
    ,input logic  gc_cr_l2_cfi_statusii_l2b78
    ,input logic  gc_cr_l2_cfi_statusii_l2b79


    // register gc_cr_clk_ctrl3 (0xa0)
    ,output logic [ 1 : 0 ] gc_cr_clk_ctrl3_l2g0
    ,output logic [ 1 : 0 ] gc_cr_clk_ctrl3_l2g1
    ,output logic [ 1 : 0 ] gc_cr_clk_ctrl3_l2g2
    ,output logic [ 1 : 0 ] gc_cr_clk_ctrl3_l2g3
    ,output logic [ 1 : 0 ] gc_cr_clk_ctrl3_l2g4
    ,output logic [ 1 : 0 ] gc_cr_clk_ctrl3_l2g5
    ,output logic [ 1 : 0 ] gc_cr_clk_ctrl3_l2g6
    ,output logic [ 1 : 0 ] gc_cr_clk_ctrl3_l2g7


    // register gc_cr_clk_status3 (0xa8)
    ,input logic  gc_cr_clk_status3_l2g0
    ,input logic  gc_cr_clk_status3_l2g1
    ,input logic  gc_cr_clk_status3_l2g2
    ,input logic  gc_cr_clk_status3_l2g3
    ,input logic  gc_cr_clk_status3_l2g4
    ,input logic  gc_cr_clk_status3_l2g5
    ,input logic  gc_cr_clk_status3_l2g6
    ,input logic  gc_cr_clk_status3_l2g7


    // register gc_cr_cu_lms_fp32_denormal_en (0x4468)
    ,output logic  gc_cr_cu_lms_fp32_denormal_en


    // register gc_cr_perf_mon1 (0x4708)
    ,output logic  gc_cr_perf_mon1_enable
    ,output logic  gc_cr_perf_mon1_time_stamp_enable
    ,output logic [ 15 : 0 ] gc_cr_perf_mon1_time_slot
    ,output logic [ 5 : 0 ] gc_cr_perf_mon1_fence_interval


    // register gc_cr_perf_mon4 (0x4720)
    ,output logic [ 4 : 0 ] gc_cr_perf_mon4_cu_group_id
    ,output logic [ 4 : 0 ] gc_cr_perf_mon4_spc_group_id
    ,output logic [ 4 : 0 ] gc_cr_perf_mon4_gpc_group_id
    ,output logic [ 4 : 0 ] gc_cr_perf_mon4_l2g_group_id
    ,output logic [ 4 : 0 ] gc_cr_perf_mon4_cp_group_id
    ,output logic [ 4 : 0 ] gc_cr_perf_mon4_ce_group_id


    // register gc_cr_l2_cfi_operation (0xe000)
    ,output logic [ 1 : 0 ] gc_cr_l2_cfi_operation


    // register gc_cr_l2_cfi_statusi (0xe008)
    ,input logic  gc_cr_l2_cfi_statusi_l2b0
    ,input logic  gc_cr_l2_cfi_statusi_l2b1
    ,input logic  gc_cr_l2_cfi_statusi_l2b2
    ,input logic  gc_cr_l2_cfi_statusi_l2b3
    ,input logic  gc_cr_l2_cfi_statusi_l2b4
    ,input logic  gc_cr_l2_cfi_statusi_l2b5
    ,input logic  gc_cr_l2_cfi_statusi_l2b6
    ,input logic  gc_cr_l2_cfi_statusi_l2b7
    ,input logic  gc_cr_l2_cfi_statusi_l2b8
    ,input logic  gc_cr_l2_cfi_statusi_l2b9
    ,input logic  gc_cr_l2_cfi_statusi_l2b10
    ,input logic  gc_cr_l2_cfi_statusi_l2b11
    ,input logic  gc_cr_l2_cfi_statusi_l2b12
    ,input logic  gc_cr_l2_cfi_statusi_l2b13
    ,input logic  gc_cr_l2_cfi_statusi_l2b14
    ,input logic  gc_cr_l2_cfi_statusi_l2b15
    ,input logic  gc_cr_l2_cfi_statusi_l2b16
    ,input logic  gc_cr_l2_cfi_statusi_l2b17
    ,input logic  gc_cr_l2_cfi_statusi_l2b18
    ,input logic  gc_cr_l2_cfi_statusi_l2b19
    ,input logic  gc_cr_l2_cfi_statusi_l2b20
    ,input logic  gc_cr_l2_cfi_statusi_l2b21
    ,input logic  gc_cr_l2_cfi_statusi_l2b22
    ,input logic  gc_cr_l2_cfi_statusi_l2b23
    ,input logic  gc_cr_l2_cfi_statusi_l2b24
    ,input logic  gc_cr_l2_cfi_statusi_l2b25
    ,input logic  gc_cr_l2_cfi_statusi_l2b26
    ,input logic  gc_cr_l2_cfi_statusi_l2b27
    ,input logic  gc_cr_l2_cfi_statusi_l2b28
    ,input logic  gc_cr_l2_cfi_statusi_l2b29
    ,input logic  gc_cr_l2_cfi_statusi_l2b30
    ,input logic  gc_cr_l2_cfi_statusi_l2b31
    ,input logic  gc_cr_l2_cfi_statusi_l2b32
    ,input logic  gc_cr_l2_cfi_statusi_l2b33
    ,input logic  gc_cr_l2_cfi_statusi_l2b34
    ,input logic  gc_cr_l2_cfi_statusi_l2b35
    ,input logic  gc_cr_l2_cfi_statusi_l2b36
    ,input logic  gc_cr_l2_cfi_statusi_l2b37
    ,input logic  gc_cr_l2_cfi_statusi_l2b38
    ,input logic  gc_cr_l2_cfi_statusi_l2b39
    ,input logic  gc_cr_l2_cfi_statusi_l2b40
    ,input logic  gc_cr_l2_cfi_statusi_l2b41
    ,input logic  gc_cr_l2_cfi_statusi_l2b42
    ,input logic  gc_cr_l2_cfi_statusi_l2b43
    ,input logic  gc_cr_l2_cfi_statusi_l2b44
    ,input logic  gc_cr_l2_cfi_statusi_l2b45
    ,input logic  gc_cr_l2_cfi_statusi_l2b46
    ,input logic  gc_cr_l2_cfi_statusi_l2b47
    ,input logic  gc_cr_l2_cfi_statusi_l2b48
    ,input logic  gc_cr_l2_cfi_statusi_l2b49
    ,input logic  gc_cr_l2_cfi_statusi_l2b50
    ,input logic  gc_cr_l2_cfi_statusi_l2b51
    ,input logic  gc_cr_l2_cfi_statusi_l2b52
    ,input logic  gc_cr_l2_cfi_statusi_l2b53
    ,input logic  gc_cr_l2_cfi_statusi_l2b54
    ,input logic  gc_cr_l2_cfi_statusi_l2b55
    ,input logic  gc_cr_l2_cfi_statusi_l2b56
    ,input logic  gc_cr_l2_cfi_statusi_l2b57
    ,input logic  gc_cr_l2_cfi_statusi_l2b58
    ,input logic  gc_cr_l2_cfi_statusi_l2b59
    ,input logic  gc_cr_l2_cfi_statusi_l2b60
    ,input logic  gc_cr_l2_cfi_statusi_l2b61
    ,input logic  gc_cr_l2_cfi_statusi_l2b62
    ,input logic  gc_cr_l2_cfi_statusi_l2b63


    // register gc_cr_l2_buffer_mode (0xe018)
    ,output logic [ 1 : 0 ] gc_cr_l2_buffer_mode_buffer_mode_percentage


    // register gc_cr_l2_persistence_reduce (0xe020)
    ,output logic  gc_cr_l2_persistence_reduce_persistence_reduce_enable
    ,output logic [ 20 : 0 ] gc_cr_l2_persistence_reduce_persistence_reduce_threshold


    // register gc_cr_l2_cmd (0xe028)
    ,output logic  gc_cr_l2_cmd_persistence_rst_all
    ,output logic  gc_cr_l2_cmd_cfi_clr


    // register gc_cr_l2g_idle (0xe030)
    ,input logic  gc_cr_l2g_idle_l2b0
    ,input logic  gc_cr_l2g_idle_l2b1
    ,input logic  gc_cr_l2g_idle_l2b2
    ,input logic  gc_cr_l2g_idle_l2b3
    ,input logic  gc_cr_l2g_idle_l2b4
    ,input logic  gc_cr_l2g_idle_l2b5
    ,input logic  gc_cr_l2g_idle_l2b6
    ,input logic  gc_cr_l2g_idle_l2b7
    ,input logic  gc_cr_l2g_idle_l2b8
    ,input logic  gc_cr_l2g_idle_l2b9
    ,input logic  gc_cr_l2g_idle_l2b10
    ,input logic  gc_cr_l2g_idle_l2b11
    ,input logic  gc_cr_l2g_idle_l2b12
    ,input logic  gc_cr_l2g_idle_l2b13
    ,input logic  gc_cr_l2g_idle_l2b14
    ,input logic  gc_cr_l2g_idle_l2b15
    ,input logic  gc_cr_l2g_idle_l2b16
    ,input logic  gc_cr_l2g_idle_l2b17
    ,input logic  gc_cr_l2g_idle_l2b18
    ,input logic  gc_cr_l2g_idle_l2b19
    ,input logic  gc_cr_l2g_idle_l2b20
    ,input logic  gc_cr_l2g_idle_l2b21
    ,input logic  gc_cr_l2g_idle_l2b22
    ,input logic  gc_cr_l2g_idle_l2b23
    ,input logic  gc_cr_l2g_idle_l2b24
    ,input logic  gc_cr_l2g_idle_l2b25
    ,input logic  gc_cr_l2g_idle_l2b26
    ,input logic  gc_cr_l2g_idle_l2b27
    ,input logic  gc_cr_l2g_idle_l2b28
    ,input logic  gc_cr_l2g_idle_l2b29
    ,input logic  gc_cr_l2g_idle_l2b30
    ,input logic  gc_cr_l2g_idle_l2b31
    ,input logic  gc_cr_l2g_idle_l2b32
    ,input logic  gc_cr_l2g_idle_l2b33
    ,input logic  gc_cr_l2g_idle_l2b34
    ,input logic  gc_cr_l2g_idle_l2b35
    ,input logic  gc_cr_l2g_idle_l2b36
    ,input logic  gc_cr_l2g_idle_l2b37
    ,input logic  gc_cr_l2g_idle_l2b38
    ,input logic  gc_cr_l2g_idle_l2b39
    ,input logic  gc_cr_l2g_idle_l2b40
    ,input logic  gc_cr_l2g_idle_l2b41
    ,input logic  gc_cr_l2g_idle_l2b42
    ,input logic  gc_cr_l2g_idle_l2b43
    ,input logic  gc_cr_l2g_idle_l2b44
    ,input logic  gc_cr_l2g_idle_l2b45
    ,input logic  gc_cr_l2g_idle_l2b46
    ,input logic  gc_cr_l2g_idle_l2b47
    ,input logic  gc_cr_l2g_idle_l2b48
    ,input logic  gc_cr_l2g_idle_l2b49
    ,input logic  gc_cr_l2g_idle_l2b50
    ,input logic  gc_cr_l2g_idle_l2b51
    ,input logic  gc_cr_l2g_idle_l2b52
    ,input logic  gc_cr_l2g_idle_l2b53
    ,input logic  gc_cr_l2g_idle_l2b54
    ,input logic  gc_cr_l2g_idle_l2b55
    ,input logic  gc_cr_l2g_idle_l2b56
    ,input logic  gc_cr_l2g_idle_l2b57
    ,input logic  gc_cr_l2g_idle_l2b58
    ,input logic  gc_cr_l2g_idle_l2b59
    ,input logic  gc_cr_l2g_idle_l2b60
    ,input logic  gc_cr_l2g_idle_l2b61
    ,input logic  gc_cr_l2g_idle_l2b62
    ,input logic  gc_cr_l2g_idle_l2b63


    // register gc_cr_l2g_error0 (0xe038)
    ,input logic [ 2 : 0 ] gc_cr_l2g_error0_l2b0
    ,input logic [ 2 : 0 ] gc_cr_l2g_error0_l2b1
    ,input logic [ 2 : 0 ] gc_cr_l2g_error0_l2b2
    ,input logic [ 2 : 0 ] gc_cr_l2g_error0_l2b3
    ,input logic [ 2 : 0 ] gc_cr_l2g_error0_l2b4
    ,input logic [ 2 : 0 ] gc_cr_l2g_error0_l2b5
    ,input logic [ 2 : 0 ] gc_cr_l2g_error0_l2b6
    ,input logic [ 2 : 0 ] gc_cr_l2g_error0_l2b7
    ,input logic [ 2 : 0 ] gc_cr_l2g_error0_l2b8
    ,input logic [ 2 : 0 ] gc_cr_l2g_error0_l2b9
    ,input logic [ 2 : 0 ] gc_cr_l2g_error0_l2b10
    ,input logic [ 2 : 0 ] gc_cr_l2g_error0_l2b11
    ,input logic [ 2 : 0 ] gc_cr_l2g_error0_l2b12
    ,input logic [ 2 : 0 ] gc_cr_l2g_error0_l2b13
    ,input logic [ 2 : 0 ] gc_cr_l2g_error0_l2b14
    ,input logic [ 2 : 0 ] gc_cr_l2g_error0_l2b15
    ,input logic [ 2 : 0 ] gc_cr_l2g_error0_l2b16
    ,input logic [ 2 : 0 ] gc_cr_l2g_error0_l2b17
    ,input logic [ 2 : 0 ] gc_cr_l2g_error0_l2b18
    ,input logic [ 2 : 0 ] gc_cr_l2g_error0_l2b19
    ,input logic [ 2 : 0 ] gc_cr_l2g_error0_l2b20


    // register gc_cr_l2g_error1 (0xe040)
    ,input logic [ 2 : 0 ] gc_cr_l2g_error1_l2b21
    ,input logic [ 2 : 0 ] gc_cr_l2g_error1_l2b22
    ,input logic [ 2 : 0 ] gc_cr_l2g_error1_l2b23
    ,input logic [ 2 : 0 ] gc_cr_l2g_error1_l2b24
    ,input logic [ 2 : 0 ] gc_cr_l2g_error1_l2b25
    ,input logic [ 2 : 0 ] gc_cr_l2g_error1_l2b26
    ,input logic [ 2 : 0 ] gc_cr_l2g_error1_l2b27
    ,input logic [ 2 : 0 ] gc_cr_l2g_error1_l2b28
    ,input logic [ 2 : 0 ] gc_cr_l2g_error1_l2b29
    ,input logic [ 2 : 0 ] gc_cr_l2g_error1_l2b30
    ,input logic [ 2 : 0 ] gc_cr_l2g_error1_l2b31
    ,input logic [ 2 : 0 ] gc_cr_l2g_error1_l2b32
    ,input logic [ 2 : 0 ] gc_cr_l2g_error1_l2b33
    ,input logic [ 2 : 0 ] gc_cr_l2g_error1_l2b34
    ,input logic [ 2 : 0 ] gc_cr_l2g_error1_l2b35
    ,input logic [ 2 : 0 ] gc_cr_l2g_error1_l2b36
    ,input logic [ 2 : 0 ] gc_cr_l2g_error1_l2b37
    ,input logic [ 2 : 0 ] gc_cr_l2g_error1_l2b38
    ,input logic [ 2 : 0 ] gc_cr_l2g_error1_l2b39
    ,input logic [ 2 : 0 ] gc_cr_l2g_error1_l2b40
    ,input logic [ 2 : 0 ] gc_cr_l2g_error1_l2b41


    // register gc_cr_l2g_error2 (0xe048)
    ,input logic [ 2 : 0 ] gc_cr_l2g_error2_l2b42
    ,input logic [ 2 : 0 ] gc_cr_l2g_error2_l2b43
    ,input logic [ 2 : 0 ] gc_cr_l2g_error2_l2b44
    ,input logic [ 2 : 0 ] gc_cr_l2g_error2_l2b45
    ,input logic [ 2 : 0 ] gc_cr_l2g_error2_l2b46
    ,input logic [ 2 : 0 ] gc_cr_l2g_error2_l2b47
    ,input logic [ 2 : 0 ] gc_cr_l2g_error2_l2b48
    ,input logic [ 2 : 0 ] gc_cr_l2g_error2_l2b49
    ,input logic [ 2 : 0 ] gc_cr_l2g_error2_l2b50
    ,input logic [ 2 : 0 ] gc_cr_l2g_error2_l2b51
    ,input logic [ 2 : 0 ] gc_cr_l2g_error2_l2b52
    ,input logic [ 2 : 0 ] gc_cr_l2g_error2_l2b53
    ,input logic [ 2 : 0 ] gc_cr_l2g_error2_l2b54
    ,input logic [ 2 : 0 ] gc_cr_l2g_error2_l2b55
    ,input logic [ 2 : 0 ] gc_cr_l2g_error2_l2b56
    ,input logic [ 2 : 0 ] gc_cr_l2g_error2_l2b57
    ,input logic [ 2 : 0 ] gc_cr_l2g_error2_l2b58
    ,input logic [ 2 : 0 ] gc_cr_l2g_error2_l2b59
    ,input logic [ 2 : 0 ] gc_cr_l2g_error2_l2b60
    ,input logic [ 2 : 0 ] gc_cr_l2g_error2_l2b61
    ,input logic [ 2 : 0 ] gc_cr_l2g_error2_l2b62


    // register gc_cr_l2g_error3 (0xe050)
    ,input logic [ 2 : 0 ] gc_cr_l2g_error3_l2b63


    // register gc_cr_l2_function_enable (0xe058)
    ,output logic  gc_cr_l2_function_enable_mem_scheduler
    ,output logic  gc_cr_l2_function_enable_bypass_mode
    ,output logic [ 1 : 0 ] gc_cr_l2_function_enable_hash_mode
    ,output logic [ 3 : 0 ] gc_cr_l2_function_enable_ddr_capacity


    // register gc_cr_l2_mem_sched_col_offset (0xe060)
    ,output logic [ 4 : 0 ] gc_cr_l2_mem_sched_col_offset_column_id_bit0
    ,output logic [ 4 : 0 ] gc_cr_l2_mem_sched_col_offset_column_id_bit1
    ,output logic [ 4 : 0 ] gc_cr_l2_mem_sched_col_offset_column_id_bit2
    ,output logic [ 4 : 0 ] gc_cr_l2_mem_sched_col_offset_column_id_bit3
    ,output logic [ 4 : 0 ] gc_cr_l2_mem_sched_col_offset_column_id_bit4
    ,output logic [ 4 : 0 ] gc_cr_l2_mem_sched_col_offset_column_id_bit5
    ,output logic [ 4 : 0 ] gc_cr_l2_mem_sched_col_offset_column_id_bit6
    ,output logic [ 4 : 0 ] gc_cr_l2_mem_sched_col_offset_column_id_bit7


    // register gc_cr_l2_mem_sched_bank_offset (0xe068)
    ,output logic [ 4 : 0 ] gc_cr_l2_mem_sched_bank_offset_bank_id_bit0
    ,output logic [ 4 : 0 ] gc_cr_l2_mem_sched_bank_offset_bank_id_bit1
    ,output logic [ 4 : 0 ] gc_cr_l2_mem_sched_bank_offset_bank_id_bit2
    ,output logic [ 4 : 0 ] gc_cr_l2_mem_sched_bank_offset_bank_id_bit3
    ,output logic [ 4 : 0 ] gc_cr_l2_mem_sched_bank_offset_bank_id_bit4


    // register gc_cr_l2_mem_sched_row_parti (0xe070)
    ,output logic [ 4 : 0 ] gc_cr_l2_mem_sched_row_parti_row_id_bit0
    ,output logic [ 4 : 0 ] gc_cr_l2_mem_sched_row_parti_row_id_bit1
    ,output logic [ 4 : 0 ] gc_cr_l2_mem_sched_row_parti_row_id_bit2
    ,output logic [ 4 : 0 ] gc_cr_l2_mem_sched_row_parti_row_id_bit3
    ,output logic [ 4 : 0 ] gc_cr_l2_mem_sched_row_parti_row_id_bit4
    ,output logic [ 4 : 0 ] gc_cr_l2_mem_sched_row_parti_row_id_bit5
    ,output logic [ 4 : 0 ] gc_cr_l2_mem_sched_row_parti_row_id_bit6
    ,output logic [ 4 : 0 ] gc_cr_l2_mem_sched_row_parti_row_id_bit7


    // register gc_cr_l2_mem_sched_row_partii (0xe078)
    ,output logic [ 4 : 0 ] gc_cr_l2_mem_sched_row_partii_row_id_bit8
    ,output logic [ 4 : 0 ] gc_cr_l2_mem_sched_row_partii_row_id_bit9
    ,output logic [ 4 : 0 ] gc_cr_l2_mem_sched_row_partii_row_id_bit10
    ,output logic [ 4 : 0 ] gc_cr_l2_mem_sched_row_partii_row_id_bit11
    ,output logic [ 4 : 0 ] gc_cr_l2_mem_sched_row_partii_row_id_bit12
    ,output logic [ 4 : 0 ] gc_cr_l2_mem_sched_row_partii_row_id_bit13
    ,output logic [ 4 : 0 ] gc_cr_l2_mem_sched_row_partii_row_id_bit14
    ,output logic [ 4 : 0 ] gc_cr_l2_mem_sched_row_partii_row_id_bit15


    // register gc_cr_l2_mem_sched_row_partiii (0xe080)
    ,output logic [ 4 : 0 ] gc_cr_l2_mem_sched_row_partiii_row_id_bit16
    ,output logic [ 4 : 0 ] gc_cr_l2_mem_sched_row_partiii_row_id_bit17


    // register gc_cr_ddr_hash_config_reg0 (0xe088)
    ,output logic [ 3 : 0 ] gc_cr_ddr_hash_config_reg0_row_id_bit0
    ,output logic [ 3 : 0 ] gc_cr_ddr_hash_config_reg0_row_id_bit1
    ,output logic [ 3 : 0 ] gc_cr_ddr_hash_config_reg0_row_id_bit2
    ,output logic [ 3 : 0 ] gc_cr_ddr_hash_config_reg0_row_id_bit3
    ,output logic [ 3 : 0 ] gc_cr_ddr_hash_config_reg0_row_id_bit4
    ,output logic [ 3 : 0 ] gc_cr_ddr_hash_config_reg0_row_id_bit5
    ,output logic [ 3 : 0 ] gc_cr_ddr_hash_config_reg0_row_id_bit6
    ,output logic [ 3 : 0 ] gc_cr_ddr_hash_config_reg0_row_id_bit7
    ,output logic [ 3 : 0 ] gc_cr_ddr_hash_config_reg0_row_id_bit8
    ,output logic [ 3 : 0 ] gc_cr_ddr_hash_config_reg0_row_id_bit9
    ,output logic [ 3 : 0 ] gc_cr_ddr_hash_config_reg0_row_id_bit10
    ,output logic [ 3 : 0 ] gc_cr_ddr_hash_config_reg0_row_id_bit11


    // register gc_cr_ddr_hash_config_reg1 (0xe090)
    ,output logic [ 3 : 0 ] gc_cr_ddr_hash_config_reg1_row_id_bit12
    ,output logic [ 3 : 0 ] gc_cr_ddr_hash_config_reg1_row_id_bit13
    ,output logic [ 3 : 0 ] gc_cr_ddr_hash_config_reg1_row_id_bit14
    ,output logic [ 3 : 0 ] gc_cr_ddr_hash_config_reg1_row_id_bit15
    ,output logic [ 3 : 0 ] gc_cr_ddr_hash_config_reg1_row_id_bit16
    ,output logic [ 3 : 0 ] gc_cr_ddr_hash_config_reg1_row_id_bit17
    ,output logic [ 3 : 0 ] gc_cr_ddr_hash_config_reg1_row_id_bit18
    ,output logic [ 3 : 0 ] gc_cr_ddr_hash_config_reg1_row_id_bit19
    ,output logic [ 3 : 0 ] gc_cr_ddr_hash_config_reg1_row_id_bit20
    ,output logic [ 3 : 0 ] gc_cr_ddr_hash_config_reg1_row_id_bit21
    ,output logic [ 3 : 0 ] gc_cr_ddr_hash_config_reg1_row_id_bit22
    ,output logic [ 3 : 0 ] gc_cr_ddr_hash_config_reg1_row_id_bit23


    // register gc_cr_l2g_idleii (0xe098)
    ,input logic  gc_cr_l2g_idleii_l2b64
    ,input logic  gc_cr_l2g_idleii_l2b65
    ,input logic  gc_cr_l2g_idleii_l2b66
    ,input logic  gc_cr_l2g_idleii_l2b67
    ,input logic  gc_cr_l2g_idleii_l2b68
    ,input logic  gc_cr_l2g_idleii_l2b69
    ,input logic  gc_cr_l2g_idleii_l2b70
    ,input logic  gc_cr_l2g_idleii_l2b71
    ,input logic  gc_cr_l2g_idleii_l2b72
    ,input logic  gc_cr_l2g_idleii_l2b73
    ,input logic  gc_cr_l2g_idleii_l2b74
    ,input logic  gc_cr_l2g_idleii_l2b75
    ,input logic  gc_cr_l2g_idleii_l2b76
    ,input logic  gc_cr_l2g_idleii_l2b77
    ,input logic  gc_cr_l2g_idleii_l2b78
    ,input logic  gc_cr_l2g_idleii_l2b79


    // register gc_cr_pwr_man_hysteresis (0xf138)
    ,output logic [ 4 : 0 ] gc_cr_pwr_man_hysteresis_value


    // register gc_cr_crm_reset_clk (0xf278)
    ,output logic [ 1 : 0 ] gc_cr_crm_reset_clk_ctrl


    // Notify 
    ,output logic                       gc_cr_l2_cfi_operation_notify
    ,output logic                       gc_cr_l2_cfi_operation_rdnotify
    ,output logic                       gc_cr_l2_cmd_notify
    ,output logic                       gc_cr_l2_cmd_rdnotify
);

    logic             reg_ad_val;
    logic [ 16 : 0 ]  reg_addr ;
    logic [ 63 : 0 ]  reg_wdata;
    logic [ 7 : 0 ]   reg_wmask;
    logic             reg_rdnwr;
    logic             wr;
    logic             rd;
    logic [ 16 : 0]   addr;
    logic [ 63 : 0]   wdata;
    logic [ 7 : 0 ]   wmask;
    logic             rd0_val;
    logic [ 63 : 0 ]  rdata0;

    logic [ 15 : 0 ]                                      gc_cr_l2_cfi_statusii_bundled;
    logic [ 15 : 0 ]                                      gc_cr_clk_ctrl3_bundled;
    logic [ 7 : 0 ]                                       gc_cr_clk_status3_bundled;
    logic [ 23 : 0 ]                                      gc_cr_perf_mon1_bundled;
    logic [ 29 : 0 ]                                      gc_cr_perf_mon4_bundled;
    logic [ 63 : 0 ]                                      gc_cr_l2_cfi_statusi_bundled;
    logic [ 1 : 0 ]                                       gc_cr_l2_buffer_mode_bundled;
    logic [ 21 : 0 ]                                      gc_cr_l2_persistence_reduce_bundled;
    logic [ 1 : 0 ]                                       gc_cr_l2_cmd_bundled;
    logic [ 63 : 0 ]                                      gc_cr_l2g_idle_bundled;
    logic [ 62 : 0 ]                                      gc_cr_l2g_error0_bundled;
    logic [ 62 : 0 ]                                      gc_cr_l2g_error1_bundled;
    logic [ 62 : 0 ]                                      gc_cr_l2g_error2_bundled;
    logic [ 2 : 0 ]                                       gc_cr_l2g_error3_bundled;
    logic [ 7 : 0 ]                                       gc_cr_l2_function_enable_bundled;
    logic [ 39 : 0 ]                                      gc_cr_l2_mem_sched_col_offset_bundled;
    logic [ 24 : 0 ]                                      gc_cr_l2_mem_sched_bank_offset_bundled;
    logic [ 39 : 0 ]                                      gc_cr_l2_mem_sched_row_parti_bundled;
    logic [ 39 : 0 ]                                      gc_cr_l2_mem_sched_row_partii_bundled;
    logic [ 9 : 0 ]                                       gc_cr_l2_mem_sched_row_partiii_bundled;
    logic [ 47 : 0 ]                                      gc_cr_ddr_hash_config_reg0_bundled;
    logic [ 47 : 0 ]                                      gc_cr_ddr_hash_config_reg1_bundled;
    logic [ 15 : 0 ]                                      gc_cr_l2g_idleii_bundled;
    logic [ 4 : 0 ]                                       gc_cr_pwr_man_hysteresis_bundled;
    logic [ 1 : 0 ]                                       gc_cr_crm_reset_clk_bundled;

    logic [  2 : 0 ]  regbank_instance_r;



    // {{ register data in
    always_ff @(posedge clk, negedge resetn)
    begin : sys_reg_val
        if (~resetn) begin
            reg_ad_val <= 0;
        end else begin
            reg_ad_val <= regbank_valid;
        end

    end // sys_reg_val;


    always_ff @(posedge clk)

    begin : sys_reg
            if (regbank_valid) begin
                reg_addr  <= regbank_addr;
                reg_wdata <= regbank_wdata;
                reg_wmask <= regbank_wmask;
                reg_rdnwr <= regbank_rdnwr;
            end
    end // sys_reg;


    // register regbank_instance signal
    always_ff @(posedge clk)
    begin : p_regbank_instance_reg

        regbank_instance_r <= regbank_instance;
    end // p_regbank_instance_reg;


    // ----------------------
    // read/write enables --
    // ----------------------

    assign wr    = (~reg_rdnwr) & reg_ad_val;
    assign rd    = reg_rdnwr & reg_ad_val;
    assign addr  = reg_addr;
    assign wdata = reg_wdata;
    assign wmask = reg_wmask;
    // }}

    // {{ register bank 0
    gc_cr_l2g_regs0 c0

        (

            .clk                                    (clk),
            .resetn                                 (resetn),

            .sys_addr                               (addr),
            .sys_wdata                              (wdata),
            .sys_wmask                              (wmask),
            .sys_wr                                 (wr),
            .sys_rd                                 (rd),

            .sys_rdata                              (rdata0),
            .sys_rd_val                             (rd0_val),
            .regbank_instance                        (regbank_instance_r),
            .gc_cr_l2_cfi_statusii                         (gc_cr_l2_cfi_statusii_bundled),
            .gc_cr_clk_ctrl3                               (gc_cr_clk_ctrl3_bundled),
            .gc_cr_clk_status3                             (gc_cr_clk_status3_bundled),
            .gc_cr_cu_lms_fp32_denormal_en                 (gc_cr_cu_lms_fp32_denormal_en),
            .gc_cr_perf_mon1                               (gc_cr_perf_mon1_bundled),
            .gc_cr_perf_mon4                               (gc_cr_perf_mon4_bundled),
            .gc_cr_l2_cfi_operation                        (gc_cr_l2_cfi_operation),
            .gc_cr_l2_cfi_statusi                          (gc_cr_l2_cfi_statusi_bundled),
            .gc_cr_l2_buffer_mode                          (gc_cr_l2_buffer_mode_bundled),
            .gc_cr_l2_persistence_reduce                   (gc_cr_l2_persistence_reduce_bundled),
            .gc_cr_l2_cmd                                  (gc_cr_l2_cmd_bundled),
            .gc_cr_l2g_idle                                (gc_cr_l2g_idle_bundled),
            .gc_cr_l2g_error0                              (gc_cr_l2g_error0_bundled),
            .gc_cr_l2g_error1                              (gc_cr_l2g_error1_bundled),
            .gc_cr_l2g_error2                              (gc_cr_l2g_error2_bundled),
            .gc_cr_l2g_error3                              (gc_cr_l2g_error3_bundled),
            .gc_cr_l2_function_enable                      (gc_cr_l2_function_enable_bundled),
            .gc_cr_l2_mem_sched_col_offset                 (gc_cr_l2_mem_sched_col_offset_bundled),
            .gc_cr_l2_mem_sched_bank_offset                (gc_cr_l2_mem_sched_bank_offset_bundled),
            .gc_cr_l2_mem_sched_row_parti                  (gc_cr_l2_mem_sched_row_parti_bundled),
            .gc_cr_l2_mem_sched_row_partii                 (gc_cr_l2_mem_sched_row_partii_bundled),
            .gc_cr_l2_mem_sched_row_partiii                (gc_cr_l2_mem_sched_row_partiii_bundled),
            .gc_cr_ddr_hash_config_reg0                    (gc_cr_ddr_hash_config_reg0_bundled),
            .gc_cr_ddr_hash_config_reg1                    (gc_cr_ddr_hash_config_reg1_bundled),
            .gc_cr_l2g_idleii                              (gc_cr_l2g_idleii_bundled),
            .gc_cr_pwr_man_hysteresis                      (gc_cr_pwr_man_hysteresis_bundled),
            .gc_cr_crm_reset_clk                           (gc_cr_crm_reset_clk_bundled),
            .gc_cr_l2_cfi_operation_notify                 (gc_cr_l2_cfi_operation_notify),
            .gc_cr_l2_cfi_operation_rdnotify               (gc_cr_l2_cfi_operation_rdnotify),
            .gc_cr_l2_cmd_notify                           (gc_cr_l2_cmd_notify),
            .gc_cr_l2_cmd_rdnotify                         (gc_cr_l2_cmd_rdnotify)
       );
    //}}
//-------------------------
// register output valid --
//-------------------------

    always_ff @(posedge clk, negedge resetn)
    begin : rd_val_reg

        if (~resetn) begin
            regbank_rvalid <= 0;
        end else begin
            regbank_rvalid <= reg_ad_val & reg_rdnwr;
        end

    end // rd_val_reg;


    always_ff @(posedge clk, negedge resetn)

    begin : rd_data_reg

        if (~resetn) begin
            regbank_rdata <= 0;

        end else begin
            // mux out data from either source

            if ( rd0_val ) begin
                regbank_rdata <= rdata0;
            end else if (reg_ad_val & reg_rdnwr) begin
                regbank_rdata <= 0;
            end

        end

    end // rd_data_reg;

    // {{ wire up split registers 1
    assign gc_cr_l2_cfi_statusii_bundled[0]                = gc_cr_l2_cfi_statusii_l2b64;
    assign gc_cr_l2_cfi_statusii_bundled[1]                = gc_cr_l2_cfi_statusii_l2b65;
    assign gc_cr_l2_cfi_statusii_bundled[2]                = gc_cr_l2_cfi_statusii_l2b66;
    assign gc_cr_l2_cfi_statusii_bundled[3]                = gc_cr_l2_cfi_statusii_l2b67;
    assign gc_cr_l2_cfi_statusii_bundled[4]                = gc_cr_l2_cfi_statusii_l2b68;
    assign gc_cr_l2_cfi_statusii_bundled[5]                = gc_cr_l2_cfi_statusii_l2b69;
    assign gc_cr_l2_cfi_statusii_bundled[6]                = gc_cr_l2_cfi_statusii_l2b70;
    assign gc_cr_l2_cfi_statusii_bundled[7]                = gc_cr_l2_cfi_statusii_l2b71;
    assign gc_cr_l2_cfi_statusii_bundled[8]                = gc_cr_l2_cfi_statusii_l2b72;
    assign gc_cr_l2_cfi_statusii_bundled[9]                = gc_cr_l2_cfi_statusii_l2b73;
    assign gc_cr_l2_cfi_statusii_bundled[10]               = gc_cr_l2_cfi_statusii_l2b74;
    assign gc_cr_l2_cfi_statusii_bundled[11]               = gc_cr_l2_cfi_statusii_l2b75;
    assign gc_cr_l2_cfi_statusii_bundled[12]               = gc_cr_l2_cfi_statusii_l2b76;
    assign gc_cr_l2_cfi_statusii_bundled[13]               = gc_cr_l2_cfi_statusii_l2b77;
    assign gc_cr_l2_cfi_statusii_bundled[14]               = gc_cr_l2_cfi_statusii_l2b78;
    assign gc_cr_l2_cfi_statusii_bundled[15]               = gc_cr_l2_cfi_statusii_l2b79;
    assign gc_cr_clk_ctrl3_l2g0                            = gc_cr_clk_ctrl3_bundled[1:0];
    assign gc_cr_clk_ctrl3_l2g1                            = gc_cr_clk_ctrl3_bundled[3:2];
    assign gc_cr_clk_ctrl3_l2g2                            = gc_cr_clk_ctrl3_bundled[5:4];
    assign gc_cr_clk_ctrl3_l2g3                            = gc_cr_clk_ctrl3_bundled[7:6];
    assign gc_cr_clk_ctrl3_l2g4                            = gc_cr_clk_ctrl3_bundled[9:8];
    assign gc_cr_clk_ctrl3_l2g5                            = gc_cr_clk_ctrl3_bundled[11:10];
    assign gc_cr_clk_ctrl3_l2g6                            = gc_cr_clk_ctrl3_bundled[13:12];
    assign gc_cr_clk_ctrl3_l2g7                            = gc_cr_clk_ctrl3_bundled[15:14];
    assign gc_cr_clk_status3_bundled[0]                    = gc_cr_clk_status3_l2g0;
    assign gc_cr_clk_status3_bundled[1]                    = gc_cr_clk_status3_l2g1;
    assign gc_cr_clk_status3_bundled[2]                    = gc_cr_clk_status3_l2g2;
    assign gc_cr_clk_status3_bundled[3]                    = gc_cr_clk_status3_l2g3;
    assign gc_cr_clk_status3_bundled[4]                    = gc_cr_clk_status3_l2g4;
    assign gc_cr_clk_status3_bundled[5]                    = gc_cr_clk_status3_l2g5;
    assign gc_cr_clk_status3_bundled[6]                    = gc_cr_clk_status3_l2g6;
    assign gc_cr_clk_status3_bundled[7]                    = gc_cr_clk_status3_l2g7;
    assign gc_cr_perf_mon1_enable                          = gc_cr_perf_mon1_bundled[0];
    assign gc_cr_perf_mon1_time_stamp_enable               = gc_cr_perf_mon1_bundled[1];
    assign gc_cr_perf_mon1_time_slot                       = gc_cr_perf_mon1_bundled[17:2];
    assign gc_cr_perf_mon1_fence_interval                  = gc_cr_perf_mon1_bundled[23:18];
    assign gc_cr_perf_mon4_cu_group_id                     = gc_cr_perf_mon4_bundled[4:0];
    assign gc_cr_perf_mon4_spc_group_id                    = gc_cr_perf_mon4_bundled[9:5];
    assign gc_cr_perf_mon4_gpc_group_id                    = gc_cr_perf_mon4_bundled[14:10];
    assign gc_cr_perf_mon4_l2g_group_id                    = gc_cr_perf_mon4_bundled[19:15];
    assign gc_cr_perf_mon4_cp_group_id                     = gc_cr_perf_mon4_bundled[24:20];
    assign gc_cr_perf_mon4_ce_group_id                     = gc_cr_perf_mon4_bundled[29:25];
    assign gc_cr_l2_cfi_statusi_bundled[0]                 = gc_cr_l2_cfi_statusi_l2b0;
    assign gc_cr_l2_cfi_statusi_bundled[1]                 = gc_cr_l2_cfi_statusi_l2b1;
    assign gc_cr_l2_cfi_statusi_bundled[2]                 = gc_cr_l2_cfi_statusi_l2b2;
    assign gc_cr_l2_cfi_statusi_bundled[3]                 = gc_cr_l2_cfi_statusi_l2b3;
    assign gc_cr_l2_cfi_statusi_bundled[4]                 = gc_cr_l2_cfi_statusi_l2b4;
    assign gc_cr_l2_cfi_statusi_bundled[5]                 = gc_cr_l2_cfi_statusi_l2b5;
    assign gc_cr_l2_cfi_statusi_bundled[6]                 = gc_cr_l2_cfi_statusi_l2b6;
    assign gc_cr_l2_cfi_statusi_bundled[7]                 = gc_cr_l2_cfi_statusi_l2b7;
    assign gc_cr_l2_cfi_statusi_bundled[8]                 = gc_cr_l2_cfi_statusi_l2b8;
    assign gc_cr_l2_cfi_statusi_bundled[9]                 = gc_cr_l2_cfi_statusi_l2b9;
    assign gc_cr_l2_cfi_statusi_bundled[10]                = gc_cr_l2_cfi_statusi_l2b10;
    assign gc_cr_l2_cfi_statusi_bundled[11]                = gc_cr_l2_cfi_statusi_l2b11;
    assign gc_cr_l2_cfi_statusi_bundled[12]                = gc_cr_l2_cfi_statusi_l2b12;
    assign gc_cr_l2_cfi_statusi_bundled[13]                = gc_cr_l2_cfi_statusi_l2b13;
    assign gc_cr_l2_cfi_statusi_bundled[14]                = gc_cr_l2_cfi_statusi_l2b14;
    assign gc_cr_l2_cfi_statusi_bundled[15]                = gc_cr_l2_cfi_statusi_l2b15;
    assign gc_cr_l2_cfi_statusi_bundled[16]                = gc_cr_l2_cfi_statusi_l2b16;
    assign gc_cr_l2_cfi_statusi_bundled[17]                = gc_cr_l2_cfi_statusi_l2b17;
    assign gc_cr_l2_cfi_statusi_bundled[18]                = gc_cr_l2_cfi_statusi_l2b18;
    assign gc_cr_l2_cfi_statusi_bundled[19]                = gc_cr_l2_cfi_statusi_l2b19;
    assign gc_cr_l2_cfi_statusi_bundled[20]                = gc_cr_l2_cfi_statusi_l2b20;
    assign gc_cr_l2_cfi_statusi_bundled[21]                = gc_cr_l2_cfi_statusi_l2b21;
    assign gc_cr_l2_cfi_statusi_bundled[22]                = gc_cr_l2_cfi_statusi_l2b22;
    assign gc_cr_l2_cfi_statusi_bundled[23]                = gc_cr_l2_cfi_statusi_l2b23;
    assign gc_cr_l2_cfi_statusi_bundled[24]                = gc_cr_l2_cfi_statusi_l2b24;
    assign gc_cr_l2_cfi_statusi_bundled[25]                = gc_cr_l2_cfi_statusi_l2b25;
    assign gc_cr_l2_cfi_statusi_bundled[26]                = gc_cr_l2_cfi_statusi_l2b26;
    assign gc_cr_l2_cfi_statusi_bundled[27]                = gc_cr_l2_cfi_statusi_l2b27;
    assign gc_cr_l2_cfi_statusi_bundled[28]                = gc_cr_l2_cfi_statusi_l2b28;
    assign gc_cr_l2_cfi_statusi_bundled[29]                = gc_cr_l2_cfi_statusi_l2b29;
    assign gc_cr_l2_cfi_statusi_bundled[30]                = gc_cr_l2_cfi_statusi_l2b30;
    assign gc_cr_l2_cfi_statusi_bundled[31]                = gc_cr_l2_cfi_statusi_l2b31;
    assign gc_cr_l2_cfi_statusi_bundled[32]                = gc_cr_l2_cfi_statusi_l2b32;
    assign gc_cr_l2_cfi_statusi_bundled[33]                = gc_cr_l2_cfi_statusi_l2b33;
    assign gc_cr_l2_cfi_statusi_bundled[34]                = gc_cr_l2_cfi_statusi_l2b34;
    assign gc_cr_l2_cfi_statusi_bundled[35]                = gc_cr_l2_cfi_statusi_l2b35;
    assign gc_cr_l2_cfi_statusi_bundled[36]                = gc_cr_l2_cfi_statusi_l2b36;
    assign gc_cr_l2_cfi_statusi_bundled[37]                = gc_cr_l2_cfi_statusi_l2b37;
    assign gc_cr_l2_cfi_statusi_bundled[38]                = gc_cr_l2_cfi_statusi_l2b38;
    assign gc_cr_l2_cfi_statusi_bundled[39]                = gc_cr_l2_cfi_statusi_l2b39;
    assign gc_cr_l2_cfi_statusi_bundled[40]                = gc_cr_l2_cfi_statusi_l2b40;
    assign gc_cr_l2_cfi_statusi_bundled[41]                = gc_cr_l2_cfi_statusi_l2b41;
    assign gc_cr_l2_cfi_statusi_bundled[42]                = gc_cr_l2_cfi_statusi_l2b42;
    assign gc_cr_l2_cfi_statusi_bundled[43]                = gc_cr_l2_cfi_statusi_l2b43;
    assign gc_cr_l2_cfi_statusi_bundled[44]                = gc_cr_l2_cfi_statusi_l2b44;
    assign gc_cr_l2_cfi_statusi_bundled[45]                = gc_cr_l2_cfi_statusi_l2b45;
    assign gc_cr_l2_cfi_statusi_bundled[46]                = gc_cr_l2_cfi_statusi_l2b46;
    assign gc_cr_l2_cfi_statusi_bundled[47]                = gc_cr_l2_cfi_statusi_l2b47;
    assign gc_cr_l2_cfi_statusi_bundled[48]                = gc_cr_l2_cfi_statusi_l2b48;
    assign gc_cr_l2_cfi_statusi_bundled[49]                = gc_cr_l2_cfi_statusi_l2b49;
    assign gc_cr_l2_cfi_statusi_bundled[50]                = gc_cr_l2_cfi_statusi_l2b50;
    assign gc_cr_l2_cfi_statusi_bundled[51]                = gc_cr_l2_cfi_statusi_l2b51;
    assign gc_cr_l2_cfi_statusi_bundled[52]                = gc_cr_l2_cfi_statusi_l2b52;
    assign gc_cr_l2_cfi_statusi_bundled[53]                = gc_cr_l2_cfi_statusi_l2b53;
    assign gc_cr_l2_cfi_statusi_bundled[54]                = gc_cr_l2_cfi_statusi_l2b54;
    assign gc_cr_l2_cfi_statusi_bundled[55]                = gc_cr_l2_cfi_statusi_l2b55;
    assign gc_cr_l2_cfi_statusi_bundled[56]                = gc_cr_l2_cfi_statusi_l2b56;
    assign gc_cr_l2_cfi_statusi_bundled[57]                = gc_cr_l2_cfi_statusi_l2b57;
    assign gc_cr_l2_cfi_statusi_bundled[58]                = gc_cr_l2_cfi_statusi_l2b58;
    assign gc_cr_l2_cfi_statusi_bundled[59]                = gc_cr_l2_cfi_statusi_l2b59;
    assign gc_cr_l2_cfi_statusi_bundled[60]                = gc_cr_l2_cfi_statusi_l2b60;
    assign gc_cr_l2_cfi_statusi_bundled[61]                = gc_cr_l2_cfi_statusi_l2b61;
    assign gc_cr_l2_cfi_statusi_bundled[62]                = gc_cr_l2_cfi_statusi_l2b62;
    assign gc_cr_l2_cfi_statusi_bundled[63]                = gc_cr_l2_cfi_statusi_l2b63;
    assign gc_cr_l2_buffer_mode_buffer_mode_percentage     = gc_cr_l2_buffer_mode_bundled[1:0];
    assign gc_cr_l2_persistence_reduce_persistence_reduce_enable  = gc_cr_l2_persistence_reduce_bundled[0];
    assign gc_cr_l2_persistence_reduce_persistence_reduce_threshold  = gc_cr_l2_persistence_reduce_bundled[21:1];
    assign gc_cr_l2_cmd_persistence_rst_all                = gc_cr_l2_cmd_bundled[0];
    assign gc_cr_l2_cmd_cfi_clr                            = gc_cr_l2_cmd_bundled[1];
    assign gc_cr_l2g_idle_bundled[0]                       = gc_cr_l2g_idle_l2b0;
    assign gc_cr_l2g_idle_bundled[1]                       = gc_cr_l2g_idle_l2b1;
    assign gc_cr_l2g_idle_bundled[2]                       = gc_cr_l2g_idle_l2b2;
    assign gc_cr_l2g_idle_bundled[3]                       = gc_cr_l2g_idle_l2b3;
    assign gc_cr_l2g_idle_bundled[4]                       = gc_cr_l2g_idle_l2b4;
    assign gc_cr_l2g_idle_bundled[5]                       = gc_cr_l2g_idle_l2b5;
    assign gc_cr_l2g_idle_bundled[6]                       = gc_cr_l2g_idle_l2b6;
    assign gc_cr_l2g_idle_bundled[7]                       = gc_cr_l2g_idle_l2b7;
    assign gc_cr_l2g_idle_bundled[8]                       = gc_cr_l2g_idle_l2b8;
    assign gc_cr_l2g_idle_bundled[9]                       = gc_cr_l2g_idle_l2b9;
    assign gc_cr_l2g_idle_bundled[10]                      = gc_cr_l2g_idle_l2b10;
    assign gc_cr_l2g_idle_bundled[11]                      = gc_cr_l2g_idle_l2b11;
    assign gc_cr_l2g_idle_bundled[12]                      = gc_cr_l2g_idle_l2b12;
    assign gc_cr_l2g_idle_bundled[13]                      = gc_cr_l2g_idle_l2b13;
    assign gc_cr_l2g_idle_bundled[14]                      = gc_cr_l2g_idle_l2b14;
    assign gc_cr_l2g_idle_bundled[15]                      = gc_cr_l2g_idle_l2b15;
    assign gc_cr_l2g_idle_bundled[16]                      = gc_cr_l2g_idle_l2b16;
    assign gc_cr_l2g_idle_bundled[17]                      = gc_cr_l2g_idle_l2b17;
    assign gc_cr_l2g_idle_bundled[18]                      = gc_cr_l2g_idle_l2b18;
    assign gc_cr_l2g_idle_bundled[19]                      = gc_cr_l2g_idle_l2b19;
    assign gc_cr_l2g_idle_bundled[20]                      = gc_cr_l2g_idle_l2b20;
    assign gc_cr_l2g_idle_bundled[21]                      = gc_cr_l2g_idle_l2b21;
    assign gc_cr_l2g_idle_bundled[22]                      = gc_cr_l2g_idle_l2b22;
    assign gc_cr_l2g_idle_bundled[23]                      = gc_cr_l2g_idle_l2b23;
    assign gc_cr_l2g_idle_bundled[24]                      = gc_cr_l2g_idle_l2b24;
    assign gc_cr_l2g_idle_bundled[25]                      = gc_cr_l2g_idle_l2b25;
    assign gc_cr_l2g_idle_bundled[26]                      = gc_cr_l2g_idle_l2b26;
    assign gc_cr_l2g_idle_bundled[27]                      = gc_cr_l2g_idle_l2b27;
    assign gc_cr_l2g_idle_bundled[28]                      = gc_cr_l2g_idle_l2b28;
    assign gc_cr_l2g_idle_bundled[29]                      = gc_cr_l2g_idle_l2b29;
    assign gc_cr_l2g_idle_bundled[30]                      = gc_cr_l2g_idle_l2b30;
    assign gc_cr_l2g_idle_bundled[31]                      = gc_cr_l2g_idle_l2b31;
    assign gc_cr_l2g_idle_bundled[32]                      = gc_cr_l2g_idle_l2b32;
    assign gc_cr_l2g_idle_bundled[33]                      = gc_cr_l2g_idle_l2b33;
    assign gc_cr_l2g_idle_bundled[34]                      = gc_cr_l2g_idle_l2b34;
    assign gc_cr_l2g_idle_bundled[35]                      = gc_cr_l2g_idle_l2b35;
    assign gc_cr_l2g_idle_bundled[36]                      = gc_cr_l2g_idle_l2b36;
    assign gc_cr_l2g_idle_bundled[37]                      = gc_cr_l2g_idle_l2b37;
    assign gc_cr_l2g_idle_bundled[38]                      = gc_cr_l2g_idle_l2b38;
    assign gc_cr_l2g_idle_bundled[39]                      = gc_cr_l2g_idle_l2b39;
    assign gc_cr_l2g_idle_bundled[40]                      = gc_cr_l2g_idle_l2b40;
    assign gc_cr_l2g_idle_bundled[41]                      = gc_cr_l2g_idle_l2b41;
    assign gc_cr_l2g_idle_bundled[42]                      = gc_cr_l2g_idle_l2b42;
    assign gc_cr_l2g_idle_bundled[43]                      = gc_cr_l2g_idle_l2b43;
    assign gc_cr_l2g_idle_bundled[44]                      = gc_cr_l2g_idle_l2b44;
    assign gc_cr_l2g_idle_bundled[45]                      = gc_cr_l2g_idle_l2b45;
    assign gc_cr_l2g_idle_bundled[46]                      = gc_cr_l2g_idle_l2b46;
    assign gc_cr_l2g_idle_bundled[47]                      = gc_cr_l2g_idle_l2b47;
    assign gc_cr_l2g_idle_bundled[48]                      = gc_cr_l2g_idle_l2b48;
    assign gc_cr_l2g_idle_bundled[49]                      = gc_cr_l2g_idle_l2b49;
    assign gc_cr_l2g_idle_bundled[50]                      = gc_cr_l2g_idle_l2b50;
    assign gc_cr_l2g_idle_bundled[51]                      = gc_cr_l2g_idle_l2b51;
    assign gc_cr_l2g_idle_bundled[52]                      = gc_cr_l2g_idle_l2b52;
    assign gc_cr_l2g_idle_bundled[53]                      = gc_cr_l2g_idle_l2b53;
    assign gc_cr_l2g_idle_bundled[54]                      = gc_cr_l2g_idle_l2b54;
    assign gc_cr_l2g_idle_bundled[55]                      = gc_cr_l2g_idle_l2b55;
    assign gc_cr_l2g_idle_bundled[56]                      = gc_cr_l2g_idle_l2b56;
    assign gc_cr_l2g_idle_bundled[57]                      = gc_cr_l2g_idle_l2b57;
    assign gc_cr_l2g_idle_bundled[58]                      = gc_cr_l2g_idle_l2b58;
    assign gc_cr_l2g_idle_bundled[59]                      = gc_cr_l2g_idle_l2b59;
    assign gc_cr_l2g_idle_bundled[60]                      = gc_cr_l2g_idle_l2b60;
    assign gc_cr_l2g_idle_bundled[61]                      = gc_cr_l2g_idle_l2b61;
    assign gc_cr_l2g_idle_bundled[62]                      = gc_cr_l2g_idle_l2b62;
    assign gc_cr_l2g_idle_bundled[63]                      = gc_cr_l2g_idle_l2b63;
    assign gc_cr_l2g_error0_bundled[2:0]                   = gc_cr_l2g_error0_l2b0;
    assign gc_cr_l2g_error0_bundled[5:3]                   = gc_cr_l2g_error0_l2b1;
    assign gc_cr_l2g_error0_bundled[8:6]                   = gc_cr_l2g_error0_l2b2;
    assign gc_cr_l2g_error0_bundled[11:9]                  = gc_cr_l2g_error0_l2b3;
    assign gc_cr_l2g_error0_bundled[14:12]                 = gc_cr_l2g_error0_l2b4;
    assign gc_cr_l2g_error0_bundled[17:15]                 = gc_cr_l2g_error0_l2b5;
    assign gc_cr_l2g_error0_bundled[20:18]                 = gc_cr_l2g_error0_l2b6;
    assign gc_cr_l2g_error0_bundled[23:21]                 = gc_cr_l2g_error0_l2b7;
    assign gc_cr_l2g_error0_bundled[26:24]                 = gc_cr_l2g_error0_l2b8;
    assign gc_cr_l2g_error0_bundled[29:27]                 = gc_cr_l2g_error0_l2b9;
    assign gc_cr_l2g_error0_bundled[32:30]                 = gc_cr_l2g_error0_l2b10;
    assign gc_cr_l2g_error0_bundled[35:33]                 = gc_cr_l2g_error0_l2b11;
    assign gc_cr_l2g_error0_bundled[38:36]                 = gc_cr_l2g_error0_l2b12;
    assign gc_cr_l2g_error0_bundled[41:39]                 = gc_cr_l2g_error0_l2b13;
    assign gc_cr_l2g_error0_bundled[44:42]                 = gc_cr_l2g_error0_l2b14;
    assign gc_cr_l2g_error0_bundled[47:45]                 = gc_cr_l2g_error0_l2b15;
    assign gc_cr_l2g_error0_bundled[50:48]                 = gc_cr_l2g_error0_l2b16;
    assign gc_cr_l2g_error0_bundled[53:51]                 = gc_cr_l2g_error0_l2b17;
    assign gc_cr_l2g_error0_bundled[56:54]                 = gc_cr_l2g_error0_l2b18;
    assign gc_cr_l2g_error0_bundled[59:57]                 = gc_cr_l2g_error0_l2b19;
    assign gc_cr_l2g_error0_bundled[62:60]                 = gc_cr_l2g_error0_l2b20;
    assign gc_cr_l2g_error1_bundled[2:0]                   = gc_cr_l2g_error1_l2b21;
    assign gc_cr_l2g_error1_bundled[5:3]                   = gc_cr_l2g_error1_l2b22;
    assign gc_cr_l2g_error1_bundled[8:6]                   = gc_cr_l2g_error1_l2b23;
    assign gc_cr_l2g_error1_bundled[11:9]                  = gc_cr_l2g_error1_l2b24;
    assign gc_cr_l2g_error1_bundled[14:12]                 = gc_cr_l2g_error1_l2b25;
    assign gc_cr_l2g_error1_bundled[17:15]                 = gc_cr_l2g_error1_l2b26;
    assign gc_cr_l2g_error1_bundled[20:18]                 = gc_cr_l2g_error1_l2b27;
    assign gc_cr_l2g_error1_bundled[23:21]                 = gc_cr_l2g_error1_l2b28;
    assign gc_cr_l2g_error1_bundled[26:24]                 = gc_cr_l2g_error1_l2b29;
    assign gc_cr_l2g_error1_bundled[29:27]                 = gc_cr_l2g_error1_l2b30;
    assign gc_cr_l2g_error1_bundled[32:30]                 = gc_cr_l2g_error1_l2b31;
    assign gc_cr_l2g_error1_bundled[35:33]                 = gc_cr_l2g_error1_l2b32;
    assign gc_cr_l2g_error1_bundled[38:36]                 = gc_cr_l2g_error1_l2b33;
    assign gc_cr_l2g_error1_bundled[41:39]                 = gc_cr_l2g_error1_l2b34;
    assign gc_cr_l2g_error1_bundled[44:42]                 = gc_cr_l2g_error1_l2b35;
    assign gc_cr_l2g_error1_bundled[47:45]                 = gc_cr_l2g_error1_l2b36;
    assign gc_cr_l2g_error1_bundled[50:48]                 = gc_cr_l2g_error1_l2b37;
    assign gc_cr_l2g_error1_bundled[53:51]                 = gc_cr_l2g_error1_l2b38;
    assign gc_cr_l2g_error1_bundled[56:54]                 = gc_cr_l2g_error1_l2b39;
    assign gc_cr_l2g_error1_bundled[59:57]                 = gc_cr_l2g_error1_l2b40;
    assign gc_cr_l2g_error1_bundled[62:60]                 = gc_cr_l2g_error1_l2b41;
    assign gc_cr_l2g_error2_bundled[2:0]                   = gc_cr_l2g_error2_l2b42;
    assign gc_cr_l2g_error2_bundled[5:3]                   = gc_cr_l2g_error2_l2b43;
    assign gc_cr_l2g_error2_bundled[8:6]                   = gc_cr_l2g_error2_l2b44;
    assign gc_cr_l2g_error2_bundled[11:9]                  = gc_cr_l2g_error2_l2b45;
    assign gc_cr_l2g_error2_bundled[14:12]                 = gc_cr_l2g_error2_l2b46;
    assign gc_cr_l2g_error2_bundled[17:15]                 = gc_cr_l2g_error2_l2b47;
    assign gc_cr_l2g_error2_bundled[20:18]                 = gc_cr_l2g_error2_l2b48;
    assign gc_cr_l2g_error2_bundled[23:21]                 = gc_cr_l2g_error2_l2b49;
    assign gc_cr_l2g_error2_bundled[26:24]                 = gc_cr_l2g_error2_l2b50;
    assign gc_cr_l2g_error2_bundled[29:27]                 = gc_cr_l2g_error2_l2b51;
    assign gc_cr_l2g_error2_bundled[32:30]                 = gc_cr_l2g_error2_l2b52;
    assign gc_cr_l2g_error2_bundled[35:33]                 = gc_cr_l2g_error2_l2b53;
    assign gc_cr_l2g_error2_bundled[38:36]                 = gc_cr_l2g_error2_l2b54;
    assign gc_cr_l2g_error2_bundled[41:39]                 = gc_cr_l2g_error2_l2b55;
    assign gc_cr_l2g_error2_bundled[44:42]                 = gc_cr_l2g_error2_l2b56;
    assign gc_cr_l2g_error2_bundled[47:45]                 = gc_cr_l2g_error2_l2b57;
    assign gc_cr_l2g_error2_bundled[50:48]                 = gc_cr_l2g_error2_l2b58;
    assign gc_cr_l2g_error2_bundled[53:51]                 = gc_cr_l2g_error2_l2b59;
    assign gc_cr_l2g_error2_bundled[56:54]                 = gc_cr_l2g_error2_l2b60;
    assign gc_cr_l2g_error2_bundled[59:57]                 = gc_cr_l2g_error2_l2b61;
    assign gc_cr_l2g_error2_bundled[62:60]                 = gc_cr_l2g_error2_l2b62;
    assign gc_cr_l2g_error3_bundled[2:0]                   = gc_cr_l2g_error3_l2b63;
    assign gc_cr_l2_function_enable_mem_scheduler          = gc_cr_l2_function_enable_bundled[0];
    assign gc_cr_l2_function_enable_bypass_mode            = gc_cr_l2_function_enable_bundled[1];
    assign gc_cr_l2_function_enable_hash_mode              = gc_cr_l2_function_enable_bundled[3:2];
    assign gc_cr_l2_function_enable_ddr_capacity           = gc_cr_l2_function_enable_bundled[7:4];
    assign gc_cr_l2_mem_sched_col_offset_column_id_bit0    = gc_cr_l2_mem_sched_col_offset_bundled[4:0];
    assign gc_cr_l2_mem_sched_col_offset_column_id_bit1    = gc_cr_l2_mem_sched_col_offset_bundled[9:5];
    assign gc_cr_l2_mem_sched_col_offset_column_id_bit2    = gc_cr_l2_mem_sched_col_offset_bundled[14:10];
    assign gc_cr_l2_mem_sched_col_offset_column_id_bit3    = gc_cr_l2_mem_sched_col_offset_bundled[19:15];
    assign gc_cr_l2_mem_sched_col_offset_column_id_bit4    = gc_cr_l2_mem_sched_col_offset_bundled[24:20];
    assign gc_cr_l2_mem_sched_col_offset_column_id_bit5    = gc_cr_l2_mem_sched_col_offset_bundled[29:25];
    assign gc_cr_l2_mem_sched_col_offset_column_id_bit6    = gc_cr_l2_mem_sched_col_offset_bundled[34:30];
    assign gc_cr_l2_mem_sched_col_offset_column_id_bit7    = gc_cr_l2_mem_sched_col_offset_bundled[39:35];
    assign gc_cr_l2_mem_sched_bank_offset_bank_id_bit0     = gc_cr_l2_mem_sched_bank_offset_bundled[4:0];
    assign gc_cr_l2_mem_sched_bank_offset_bank_id_bit1     = gc_cr_l2_mem_sched_bank_offset_bundled[9:5];
    assign gc_cr_l2_mem_sched_bank_offset_bank_id_bit2     = gc_cr_l2_mem_sched_bank_offset_bundled[14:10];
    assign gc_cr_l2_mem_sched_bank_offset_bank_id_bit3     = gc_cr_l2_mem_sched_bank_offset_bundled[19:15];
    assign gc_cr_l2_mem_sched_bank_offset_bank_id_bit4     = gc_cr_l2_mem_sched_bank_offset_bundled[24:20];
    assign gc_cr_l2_mem_sched_row_parti_row_id_bit0        = gc_cr_l2_mem_sched_row_parti_bundled[4:0];
    assign gc_cr_l2_mem_sched_row_parti_row_id_bit1        = gc_cr_l2_mem_sched_row_parti_bundled[9:5];
    assign gc_cr_l2_mem_sched_row_parti_row_id_bit2        = gc_cr_l2_mem_sched_row_parti_bundled[14:10];
    assign gc_cr_l2_mem_sched_row_parti_row_id_bit3        = gc_cr_l2_mem_sched_row_parti_bundled[19:15];
    assign gc_cr_l2_mem_sched_row_parti_row_id_bit4        = gc_cr_l2_mem_sched_row_parti_bundled[24:20];
    assign gc_cr_l2_mem_sched_row_parti_row_id_bit5        = gc_cr_l2_mem_sched_row_parti_bundled[29:25];
    assign gc_cr_l2_mem_sched_row_parti_row_id_bit6        = gc_cr_l2_mem_sched_row_parti_bundled[34:30];
    assign gc_cr_l2_mem_sched_row_parti_row_id_bit7        = gc_cr_l2_mem_sched_row_parti_bundled[39:35];
    assign gc_cr_l2_mem_sched_row_partii_row_id_bit8       = gc_cr_l2_mem_sched_row_partii_bundled[4:0];
    assign gc_cr_l2_mem_sched_row_partii_row_id_bit9       = gc_cr_l2_mem_sched_row_partii_bundled[9:5];
    assign gc_cr_l2_mem_sched_row_partii_row_id_bit10      = gc_cr_l2_mem_sched_row_partii_bundled[14:10];
    assign gc_cr_l2_mem_sched_row_partii_row_id_bit11      = gc_cr_l2_mem_sched_row_partii_bundled[19:15];
    assign gc_cr_l2_mem_sched_row_partii_row_id_bit12      = gc_cr_l2_mem_sched_row_partii_bundled[24:20];
    assign gc_cr_l2_mem_sched_row_partii_row_id_bit13      = gc_cr_l2_mem_sched_row_partii_bundled[29:25];
    assign gc_cr_l2_mem_sched_row_partii_row_id_bit14      = gc_cr_l2_mem_sched_row_partii_bundled[34:30];
    assign gc_cr_l2_mem_sched_row_partii_row_id_bit15      = gc_cr_l2_mem_sched_row_partii_bundled[39:35];
    assign gc_cr_l2_mem_sched_row_partiii_row_id_bit16     = gc_cr_l2_mem_sched_row_partiii_bundled[4:0];
    assign gc_cr_l2_mem_sched_row_partiii_row_id_bit17     = gc_cr_l2_mem_sched_row_partiii_bundled[9:5];
    assign gc_cr_ddr_hash_config_reg0_row_id_bit0          = gc_cr_ddr_hash_config_reg0_bundled[3:0];
    assign gc_cr_ddr_hash_config_reg0_row_id_bit1          = gc_cr_ddr_hash_config_reg0_bundled[7:4];
    assign gc_cr_ddr_hash_config_reg0_row_id_bit2          = gc_cr_ddr_hash_config_reg0_bundled[11:8];
    assign gc_cr_ddr_hash_config_reg0_row_id_bit3          = gc_cr_ddr_hash_config_reg0_bundled[15:12];
    assign gc_cr_ddr_hash_config_reg0_row_id_bit4          = gc_cr_ddr_hash_config_reg0_bundled[19:16];
    assign gc_cr_ddr_hash_config_reg0_row_id_bit5          = gc_cr_ddr_hash_config_reg0_bundled[23:20];
    assign gc_cr_ddr_hash_config_reg0_row_id_bit6          = gc_cr_ddr_hash_config_reg0_bundled[27:24];
    assign gc_cr_ddr_hash_config_reg0_row_id_bit7          = gc_cr_ddr_hash_config_reg0_bundled[31:28];
    assign gc_cr_ddr_hash_config_reg0_row_id_bit8          = gc_cr_ddr_hash_config_reg0_bundled[35:32];
    assign gc_cr_ddr_hash_config_reg0_row_id_bit9          = gc_cr_ddr_hash_config_reg0_bundled[39:36];
    assign gc_cr_ddr_hash_config_reg0_row_id_bit10         = gc_cr_ddr_hash_config_reg0_bundled[43:40];
    assign gc_cr_ddr_hash_config_reg0_row_id_bit11         = gc_cr_ddr_hash_config_reg0_bundled[47:44];
    assign gc_cr_ddr_hash_config_reg1_row_id_bit12         = gc_cr_ddr_hash_config_reg1_bundled[3:0];
    assign gc_cr_ddr_hash_config_reg1_row_id_bit13         = gc_cr_ddr_hash_config_reg1_bundled[7:4];
    assign gc_cr_ddr_hash_config_reg1_row_id_bit14         = gc_cr_ddr_hash_config_reg1_bundled[11:8];
    assign gc_cr_ddr_hash_config_reg1_row_id_bit15         = gc_cr_ddr_hash_config_reg1_bundled[15:12];
    assign gc_cr_ddr_hash_config_reg1_row_id_bit16         = gc_cr_ddr_hash_config_reg1_bundled[19:16];
    assign gc_cr_ddr_hash_config_reg1_row_id_bit17         = gc_cr_ddr_hash_config_reg1_bundled[23:20];
    assign gc_cr_ddr_hash_config_reg1_row_id_bit18         = gc_cr_ddr_hash_config_reg1_bundled[27:24];
    assign gc_cr_ddr_hash_config_reg1_row_id_bit19         = gc_cr_ddr_hash_config_reg1_bundled[31:28];
    assign gc_cr_ddr_hash_config_reg1_row_id_bit20         = gc_cr_ddr_hash_config_reg1_bundled[35:32];
    assign gc_cr_ddr_hash_config_reg1_row_id_bit21         = gc_cr_ddr_hash_config_reg1_bundled[39:36];
    assign gc_cr_ddr_hash_config_reg1_row_id_bit22         = gc_cr_ddr_hash_config_reg1_bundled[43:40];
    assign gc_cr_ddr_hash_config_reg1_row_id_bit23         = gc_cr_ddr_hash_config_reg1_bundled[47:44];
    assign gc_cr_l2g_idleii_bundled[0]                     = gc_cr_l2g_idleii_l2b64;
    assign gc_cr_l2g_idleii_bundled[1]                     = gc_cr_l2g_idleii_l2b65;
    assign gc_cr_l2g_idleii_bundled[2]                     = gc_cr_l2g_idleii_l2b66;
    assign gc_cr_l2g_idleii_bundled[3]                     = gc_cr_l2g_idleii_l2b67;
    assign gc_cr_l2g_idleii_bundled[4]                     = gc_cr_l2g_idleii_l2b68;
    assign gc_cr_l2g_idleii_bundled[5]                     = gc_cr_l2g_idleii_l2b69;
    assign gc_cr_l2g_idleii_bundled[6]                     = gc_cr_l2g_idleii_l2b70;
    assign gc_cr_l2g_idleii_bundled[7]                     = gc_cr_l2g_idleii_l2b71;
    assign gc_cr_l2g_idleii_bundled[8]                     = gc_cr_l2g_idleii_l2b72;
    assign gc_cr_l2g_idleii_bundled[9]                     = gc_cr_l2g_idleii_l2b73;
    assign gc_cr_l2g_idleii_bundled[10]                    = gc_cr_l2g_idleii_l2b74;
    assign gc_cr_l2g_idleii_bundled[11]                    = gc_cr_l2g_idleii_l2b75;
    assign gc_cr_l2g_idleii_bundled[12]                    = gc_cr_l2g_idleii_l2b76;
    assign gc_cr_l2g_idleii_bundled[13]                    = gc_cr_l2g_idleii_l2b77;
    assign gc_cr_l2g_idleii_bundled[14]                    = gc_cr_l2g_idleii_l2b78;
    assign gc_cr_l2g_idleii_bundled[15]                    = gc_cr_l2g_idleii_l2b79;
    assign gc_cr_pwr_man_hysteresis_value                  = gc_cr_pwr_man_hysteresis_bundled[4:0];
    assign gc_cr_crm_reset_clk_ctrl                        = gc_cr_crm_reset_clk_bundled[1:0];


    // {{ wire up split registers 2
    // }}

endmodule
