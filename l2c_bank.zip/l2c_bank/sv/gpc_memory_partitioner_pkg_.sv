/*

 * #==========================================================================#
 * |                                                                          |
 * |  Copyright (c) 2022, Fantasy Technologies Limited and/or its         |
 * |  affiliated group companies ("Fantasy"). All rights reserved.        |
 * |  No part of this content, either material or conceptual may be copied    |
 * |  or distributed, transmitted, transcribed, stored in a retrieval system  |
 * |  or translated into any human or computer language in any form by any    |
 * |  means, electronic, mechanical manual, or otherwise, or disclosed to     |
 * |  third parties without the express written permission of Fantasy.    |
 * |                                                                          |
 * #==========================================================================#

 */
package gpc_memory_partitioner_pkg_;

   localparam RG_ID_COUNT = 32;
   localparam NO_RG_ID_COUNT = 32;

   typedef integer t_rg_mem_ids[RG_ID_COUNT-1 : 0];
   typedef integer t_no_rg_mem_ids[NO_RG_ID_COUNT-1 : 0];

// RTL shall pick all the RGs from RG_MEM_IDS list so the threshold must be set to 0

   localparam RG_THRESHOLD = 1024;
   localparam RG_THRESHOLD_D = 16;
   localparam t_rg_mem_ids    RG_MEM_IDS    =  { 106000, 83000, 23015, 23011, 23018, 23000, 23003, 23009, 55004, 55002, 65007, 44000, 128000, 23012, 94002, 120001, 88000, 104001, 28003, 64007, 49001, 64014, 64010, 54005, 60001, 122000, 21008, 21006, 21007, 21005, 21001, 46004 };
   localparam t_no_rg_mem_ids NO_RG_MEM_IDS =  { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };

endpackage
