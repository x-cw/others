/*

 * #==========================================================================#
 * |                                                                          |
 * |  Copyright (c) 2022, Fantasy Technologies Limited and/or its         |
 * |  affiliated group companies ("Fantasy"). All rights reserved.        |
 * |  No part of this content, either material or conceptual may be copied    |
 * |  or distributed, transmitted, transcribed, stored in a retrieval system  |
 * |  or translated into any human or computer language in any form by any    |
 * |  means, electronic, mechanical manual, or otherwise, or disclosed to     |
 * |  third parties without the express written permission of Fantasy.    |
 * |                                                                          |
 * #==========================================================================#

 */


module gpc_gfx_rstl_
#(
  parameter w = 2
)
(
 input logic clk,
 input logic resetn,
 input logic [w-1:0] din,
 input logic vin,
 output logic eout,
 output logic [w-1:0] dout,
 input logic ein,
 output logic vout
);
`ifdef  EMU_SYNTHESIS_FIFO_RAM_NO_USE
//Used in FPGA and palladium env.
// Change 3D-Array to 2D-Array for resource opt in palladium. By Wu Cheng`en @Sep-12-2025
gc_lib_reg_fifo_wrapper #( .w(w), .d(2), .registered_enable(1) ) u_ram_fifo(
    .clk             (clk   ),
    .resetn          (resetn),
    .fifo_in_valid   (vin   ),
    .fifo_in_enable  (eout  ),
    .fifo_in_data    (din   ),
    .fifo_out_valid  (vout  ),
    .fifo_out_enable (ein   ),
    .fifo_out_data   (dout  ) 
);

`else
   logic [ w - 1 : 0 ]                                        hld_din;
   logic                                                      hld_vin;
   logic                                                      nxt_hld_vin;
   logic [ w - 1 : 0 ]                                        dout_i;
   logic                                                      vout_i;
   logic                                                      nxt_vout;
   logic                                                      eout_i;
   logic                                                      nxt_eout;
   logic                                                      vsel;


   always_ff@(posedge clk or  negedge resetn) begin : rctrl
   begin
      if ( ( resetn == 1'b0 ) ) begin
         hld_vin <= 1'b0 ;
         vout_i <= 1'b0 ;
         eout_i <= 1'b1 ;
      end else begin
         hld_vin <= nxt_hld_vin ;
         vout_i <= nxt_vout ;
         eout_i <= nxt_eout ;
      end
   end
   end

   always_ff@(posedge clk) begin : ctrl
   begin
      // if holding register is getting a new value then load it. Only gets it if not going straight to dout
      // if dout is full and is not being read and new data on input then load the hld register if empty
      // eout_i set to 1 indicates hld register is empty
      if ( ( ( vout_i == 1'b1 && ein == 1'b0 ) && ( eout_i == 1'b1 && vin == 1'b1 ) ) ) begin
         hld_din <= din ;
      end

      // only clock data register if going to be valid
      // which is when it is being read or is empty and there is valid data upstream
      // din     : if holding register is empty and being read or not currently valid
      // hld_din : if holding register is full and being read or not currently valid
      // dout_i  : HOLD, if not being read and currently valid. This part done in the clk process
      
      if ( ( ein == 1'b1 || vout_i == 1'b0 ) && ( hld_vin == 1'b1 || ( eout_i == 1'b1 && vin == 1'b1 ) ) ) begin
         if ( ( hld_vin == 1'b0 ) ) begin
            dout_i <= din ;
         end else begin
            dout_i <= hld_din ;
         end
      end
   end
   end

   assign dout = dout_i ;
   assign vout = vout_i ;
   assign eout = eout_i ;

   // the holding register becomes valid when dout is full and not being taken and there is new input that is being taken
   // it will remain valid if the above is not true and data is not been taken out
   assign nxt_hld_vin = ( ( vout_i == 1'b1 && ein == 1'b0 ) && ( eout_i == 1'b1 && vin == 1'b1 ) ) ? 1'b1 : ( ein == 1'b1 ) ? 1'b0 : hld_vin   ;

   // //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
   // vout register is
   // vin     : if holding register is empty and being read or not currently valid
   // 1       : if holding register is full and being read or not currently valid
   // vout_i  : HOLD, if not being read and currently valid
   assign vsel = ( hld_vin == 1'b0 ) ? ( eout_i && vin ) : 1'b1  ;

   assign nxt_vout = ( ein == 1'b1 || vout_i == 1'b0 ) ? vsel : vout_i  ;

   // //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
   // Decide if hld register will be empty on next clock cycle
   // valid enable is active downstream which means it will be read out or
   // the holding register is empty and the output register is empty   or
   // the holding register is empty and there is no new data coming in
   assign nxt_eout = ( ( ein == 1'b1 ) || ( hld_vin == 1'b0 && vout_i == 1'b0 ) || ( hld_vin == 1'b0 && vin == 1'b0 ) ) ? 1'b1 : 1'b0  ;

`endif
endmodule
