/*

 * #==========================================================================#
 * |                                                                          |
 * |  Copyright (c) 2022, Fantasy Technologies Limited and/or its         |
 * |  affiliated group companies ("Fantasy"). All rights reserved.        |
 * |  No part of this content, either material or conceptual may be copied    |
 * |  or distributed, transmitted, transcribed, stored in a retrieval system  |
 * |  or translated into any human or computer language in any form by any    |
 * |  means, electronic, mechanical manual, or otherwise, or disclosed to     |
 * |  third parties without the express written permission of Fantasy.    |
 * |                                                                          |
 * #==========================================================================#

 */


// ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////-
// entity name: gpc_gfx_mux
// purpose: 2-input, 1-output, multiplexor
// ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////-



module gpc_gfx_mux_
(
      input    logic                                                        A                                       ,
      input    logic                                                        B                                       ,
      input    logic                                                        S                                       ,
      output   logic                                                        Y                                        
);


   always_comb begin
      case (S)    
         1'b0:
         begin
            Y = A ;
         end
         1'b1:
         begin
            Y = B ;    // COV:tag1
         end
         default:
         begin
            Y = 1'bx ;    // COV:tag1
      end
      endcase // S
   end

endmodule // gpc_gfx_mux
