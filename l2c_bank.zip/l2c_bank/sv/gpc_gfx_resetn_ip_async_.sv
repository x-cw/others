/*

 * #==========================================================================#
 * |                                                                          |
 * |  Copyright (c) 2022, Fantasy Technologies Limited and/or its         |
 * |  affiliated group companies ("Fantasy"). All rights reserved.        |
 * |  No part of this content, either material or conceptual may be copied    |
 * |  or distributed, transmitted, transcribed, stored in a retrieval system  |
 * |  or translated into any human or computer language in any form by any    |
 * |  means, electronic, mechanical manual, or otherwise, or disclosed to     |
 * |  third parties without the express written permission of Fantasy.    |
 * |                                                                          |
 * #==========================================================================#

 */

// ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////-
// entity name: gpc_gfx_resetn_ip_async
//
// Component Description: IMGLIB3 Reset Resynchronizer
// Resynchronises asynchronous input resets when those are de-asserted. Reset assertion is transparent (asynchronous).
//
// Resynchronization is obtained with a chain of sdepth+1 active-high Flip-Flops, whose asynchronous reset signals are driven by AND combination
// of component input resets. When a reset is asserted, FFs output is set to zero asynchronously, propagating directly to component output.
// Once reset is de-asserted, '1' starts to propagate from input of first FF to output of second FF. The purpose of this double FF
// structure is to avoid eventual metastable state propagating out of gpc_gfx_resetn_ip_async. As direct consequence, reset propagation is delayed
// by this component of an extra clock cycle.
//
// The component includes two mux, controlled by tst_scan_mode port. They are both necessary to implement scan chain into the design. The first mux
// force FFs to be driven by ipin_resetn, while the second one force the output in the same way.
//
// Portlist:
// soft_reset: soft reset signal, active high
// ipin_resetn: external ipin reset signal, active low
// clk: clock input (posedge)
// resetn_sync: output reset signal, active low
// tst_scan_mode: enables scan chain testing, force output and FFs to be driven by ipin_resetn
//
//

//
//                                                                   tst_scan_mode +////-+
//                                                   sdepth+1             +////////+     |
//                                            <////-  stages  //////>              +-+-+-+
//                                            +//////+       +//////+                | |
//                                        '1' |      |  \ \  |      |              +-+-+-+    sync_resetn
//                                         +//>      +/// ///>      +//////////////>     +////////>
//                                            | FF   |  \ \  | FF   |   ipin_resetn| MUX |
//                                            |      |       |      |     +////////>     |
//                                        clk |\     |   clk |\     |              +////-+
//                                         +//+/     |    +//+/     |
//                                            |      |       |      |
//                                            +//O//-+       +//-O//+
//                                               |               |
//           ++   tst_scan_mode +////-+          |               |
//           | \       +////////+     |          |               |
//soft_reset |  \               +-+-+-+          |               |
//       ////O   +                | |            |               |
//           |   |              +-+-+-+          |               |
//           |   +//////////////+     +//////////+//////////////-+
//           |   |   ipin_resetn| MUX |   ipin_and_soft_resetn
//ipin_resetn|   |     +////////>     |
//       ////+   +              +////-+
//           |  /
//           | /
//           ++
//
//
//
// ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////-



module gpc_gfx_resetn_ip_async_
#(
      parameter int                                      sdepth                                                       = 1               
)
(
      input    logic                                                        soft_reset                              ,    // active high
      input    logic                                                        ipin_resetn                             ,    // active low
      input    logic                                                        clk                                     ,    // posedge clk
      output   logic                                                        resetn_sync                             ,    // active low
      input    logic                                                        tst_scan_mode                            
);

   // output of first mux
   logic                                         ipin_and_soft_resetn                    ;

   // Registers used to re synchronize reset signal and avoid metastable state
   logic                                         resetn_r                                ;

   // combined hard and soft reset
   logic                                         resetn_comb                             ;




   // soft reset is active high while design reset is active low, so soft_reset is negated before being merged with ipin_resetn.
   // resetn_comb result as an asynchronous active low reset signal
   assign resetn_comb = ( ~ soft_reset ) & ipin_resetn ;

   // this is used to allow resetn_r1 and resetn_r2 to have there asynchronous reset port directly controlled by ipin_resetn when
   // scan chain mode is active
   gpc_gfx_mux_
      mux_1
      (
         .A                               (resetn_comb)                                ,
         .B                               (ipin_resetn)                                ,
         .S                               (tst_scan_mode)                              ,
         .Y                               (ipin_and_soft_resetn)                        
         );

   // Registers are asynchronously reset but then clock out at '1' synchronously.
   // The process involve multiple registers to avoid matastable state propagate to sync_resetn in case of reset variation close to
   // clock edge. This implies an extra clock cycle delay from input reset de-assertion to output variation.

   gpc_gfx_sync_chain_
      #(
         .sdepth                          (sdepth)                                       
         )
      capture_en
      (
         .clk                             (clk)                                        ,
         .resetn                          (ipin_and_soft_resetn)                       ,
         .chain_in                        (1'b1)                                       ,
         .chain_out                       (resetn_r)                                     
         );

   // This mux force resetn_sync (entity output) to be e ipin_resetn in scan chain mode, otherwise it is driven by registers output
   gpc_gfx_mux_
      mux_2
      (
         .A                               (resetn_r)                                   ,
         .B                               (ipin_resetn)                                ,
         .S                               (tst_scan_mode)                              ,
         .Y                               (resetn_sync)                                 
         );

endmodule // gpc_gfx_resetn_ip_async
