// Author: jinjifang
// Date: 2024/1/5
// Description: the flip-flop with enable, but no reset

module gc_lib_reg_en(/*AUTOARG*/
   // Outputs
   q,
   // Inputs
   clk, d, en
   );

   parameter      WIDTH = 1;
   parameter      INIT = {WIDTH{1'b0}};

   input wire                    clk;

   input wire [WIDTH-1:0]        d;
   input wire                    en;
   output reg [WIDTH-1:0]        q;

   always @(posedge clk) begin
      if(en)
         q <= d;
   end

endmodule

