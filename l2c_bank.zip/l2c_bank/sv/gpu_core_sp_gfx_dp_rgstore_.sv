/*

 * #==========================================================================#
 * |                                                                          |
 * |  Copyright (c) 2022, Fantasy Technologies Limited and/or its         |
 * |  affiliated group companies ("Fantasy"). All rights reserved.        |
 * |  No part of this content, either material or conceptual may be copied    |
 * |  or distributed, transmitted, transcribed, stored in a retrieval system  |
 * |  or translated into any human or computer language in any form by any    |
 * |  means, electronic, mechanical manual, or otherwise, or disclosed to     |
 * |  third parties without the express written permission of Fantasy.    |
 * |                                                                          |
 * #==========================================================================#

 */

// ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////-
// entity name: gpu_core_sp_gfx_dp_rgstore_
// purpose: Performs the function of a dual port ram but using registers
// Write port is B and read port is A. CLKA and CLKB must be the same.
// Data is captured on clock and read data has one cycle of
// latency.
// ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////-

module gpu_core_sp_gfx_dp_rgstore_
  #(
    parameter   w     = 32, // integer
    parameter   p     = 32, // integer
    parameter   d     = 16, // integer
    parameter   log2d = 4   // integer
    )
   (
    input logic                       CLKA,
    input logic                       CENA,
    input logic [ log2d - 1 : 0 ]     AA,
    output logic [ w - 1 : 0 ]        QA,
    input logic                       CLKB,
    input logic                       CENB,
    input logic [ ( w / p ) - 1 : 0 ] WENB,
    input logic [ log2d - 1 : 0 ]     AB,
    input logic [ w - 1 : 0 ]         DB
);

   logic                   wen_ctrl;
   logic [0:d-1][w-1:0]    d_001;

   ///////////////////////////////////////////////
   // backdoor access
   ///////////////////////////////////////////////

   ///////////////////////////////////////////////
   // END backdoor access
   ///////////////////////////////////////////////

   assign wen_ctrl = &(WENB);

   // Write process
   always_ff@(posedge CLKB) begin : wr
      if (CENB == 1'b0 && wen_ctrl == 1'b0) begin
         for (int i = (w / p) - 1; i >= 0; i--) begin
           if (WENB[i] == 1'b0) begin
              d_001[AB][(p*i) +: p] <= DB[(p*i) +: p];
           end
         end
      end
   end : wr

   // Read process
   always_ff@(posedge CLKA)
   begin : rd
      if (CENA == 1'b0) begin
         QA <= d_001[AA];
      end
   end : rd

endmodule
