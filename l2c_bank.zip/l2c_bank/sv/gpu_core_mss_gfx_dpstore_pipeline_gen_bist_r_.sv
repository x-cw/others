/*

 * #==========================================================================#
 * |                                                                          |
 * |  Copyright (c) 2022, Fantasy Technologies Limited and/or its         |
 * |  affiliated group companies ("Fantasy"). All rights reserved.        |
 * |  No part of this content, either material or conceptual may be copied    |
 * |  or distributed, transmitted, transcribed, stored in a retrieval system  |
 * |  or translated into any human or computer language in any form by any    |
 * |  means, electronic, mechanical manual, or otherwise, or disclosed to     |
 * |  third parties without the express written permission of Fantasy.    |
 * |                                                                          |
 * #==========================================================================#

 */

// ////////////////////////////////////////////////////////////////////////////-
// entity:  gpu_core_gfx_dpstore_pipeline_gen_bist_r
//
// purpose: Dual port synchronous RAM with configurable write word partitions
//          and back end read register to help achieve timing closure
//
// +////////////////////////-+////////+////-+////-+////////+////////////////+
// | gpu_core_gfx_dpstore_        |        | RAM | Reg | Bypass | Design         |
// |             w,p,d,log2d | Clocks | O/P | O/P | Input  | Suitability    |
// +////////////////////////-+////////+////-+////-+////////+////////////////+
// | _.vhd & _novital.vhd    |  2:RW  | Yes |     |        | Fundamental    |
// | bist.vhdm               | single | Yes |     |        | Low level only |
// | bist_async.vhdm         |  2:RW  | Yes |     |        | Low level only |
// | gen_bist_r.vhd          | single |     | Yes |        | Standard use   |
// | pipeline_gen_bist_r.vhd | single |     | Yes |        | Standard use   |<<<
// | bypass_gen_bist_r.vhd   | single |     | Yes |  Yes   | Standard use   |
// | flexible_gen_bist_r.vhd | single | Yes | Yes |  Yes   | Standard use   |
// | flexible_gen_bist_r     |        |     |     |        |                |
// |              _async.vhd |  2:RW  | Yes | Yes |  Yes   | Standard use   |
// +////////////////////////-+////////+////-+////-+////////+////////////////+
//
// hierarchy: This is an RTL designer's standard component
//
//        gpu_core_gfx_dpstore_pipeline_gen_bist_r       << YOU ARE HERE
//         |
//         +- gpu_core_gfx_dpstore_bist
//             |
//             +- gpu_core_gfx_dpstore
//             |
//             +- [ gpu_core_gfx_bistwrap ]
//
// ////////////////////////////////////////////////////////////////////////////-

// DIMENSIONS
//   Physical generics: w, d, p, log2d, wrcen*
//
//                        width
//              <////////// w //////////>
//
//              +//////////////////////-+   ^
//              |_______________________|   |
//              |_______________________|   |  d
//              |_______________________|      e
//              |                       |   d  p
//              |                       |      t
//              :                       :   |  h
//              |                       |   |
//              +//////////////////////-+   v
//                         w/p *
//              <- p -><- p -> .. <- p ->
//                      partitions
//
//   All partitions are equal in size. In other words, the generic w is an
//   integer multiple of generic p.
//
//   Example partition:
//      [w = 128, p = 32] => w/p = 4 partitions => 4 write enables

// PORTS
//   +////////////////////////////////////////////////////////-+
//   | name          |  bits  |dir| description                |
//   +////////////////////////////////////////////////////////-+
//   | rd_addr       | log2d  | i | read address               |
//   | rd_en         |   1    | i | read strobe (ACTIVE LOW)   |
//   | rd_data_cken  |   1    | i | read register clock gate   |
//   | rd_data       |   w    | o | read data                  |
//   |               |        |   |                            |
//   | wr_addr       | log2d  | i | write address              |
//   | wr_data       |   w    | i | write data ((w/p)*p bits)  |
//   | wr_en *       |(w/p)+1*| i | write enables*(ACTIVE LOW) |
//   |               |        |   |                            |
//   | clk           |   1    | i | common r/w clock           |
//   | resetn        |   1    | i | reset to BIST (ACTIVE LOW) |
//   |               |        |   |                            |
//   | bist_in       |f(w,p,d)| i | input from BIST controller |
//   | bist_out      |f(w,p,d)| o | result to BIST controller  |
//   +////////////////////////////////////////////////////////-+
//
//  * - wr_en width can be configured with generic wrcen to have an extra bit:
//
//    wrcen
//      0 : w/p bits => one ACTIVE LOW write enable per word partition (default)
//      1 : w/p+1 bits => one ADDITIONAL (ACTIVE LOW) write enable
//
//      If configured, the extra bit indicates that any one of the per word
//      partition write enables is asserted.

// BEHAVIOURIAL MODEL
//   Functional behaviour is similar to gpu_core_gfx_dpstore_bist but this hierarchical
//   level adds a back end read data register for timing purposes
//
//   Read latency:  2 clocks
//   Write latency: 1 clock
//
//      rd_data_cken ////////////////////////////////////////-.
//                     +////////////////////////////////-+    |
//                     |      gpu_core_gfx_dpstore_bist       |    |
//                     |                                 |    |
//                     |  +//////////////////////////-+  |    |
//                     |  |     gpu_core_gfx_dpstore       |  |    |
//                     |  |                           |  |    |
//      rd_addr, rd_en-|//|//////////////////////.    |  |    |
//                     |  |                      |    |  |    |en
//                     |  | +////+   +////-+   +////+ |  |  +////+
//      wr_addr    ///-|//|-| wr |   |     |   | rd | |  |  |    |
//      wr_en      ///-|//|-|proc|-/-| mem |-/-|proc|-|//|//|    |///-> rd_data
//      wr_data    ///-|//|-|    |   |     |   |    | |  |  |    |
//                     |  | |    |  +|>    |  +|>   | |  | +|>   |
//                     |  | +////+  |+////-+  |+////+ |  | |+////+
//                     |  |         |         |       |  | |
//      clk        ////|//|////////-*////////-*//////-|//|-'
//                     |  +//////////////////////////-+  |
//                     |  +//////////////////////////-+  |
//                     |  |                           |  |
//      bist_in    ///-|//|   [ gpu_core_gfx_bistwrap ]    |//|///////////-> bist_out
//      resetn     ////|//|                           |  |
//                     |  +//////////////////////////-+  |
//                     +////////////////////////////////-+

// OPTIONAL UTILITY GENERICS
//   id       : integer value that can be assigned to each instance (default 0)
//                                                                      -=:PB=-
// ////////////////////////////////////////////////////////////////////////////-

module gpu_core_mss_gfx_dpstore_pipeline_gen_bist_r_ 
   import gpc_gfx_rambist_pack_::*;
#(
      parameter int                                      w                                                            = 32             ,    // Data width
      parameter int                                      p                                                            = 32             ,    // Word partition size (bits per WEN)
      parameter int                                      d                                                            = 8              ,    // Data depth
      parameter int                                      log2d                                                        = 3              ,    // Address width
      parameter int                                      wrcen                                                        = 0              ,    // Write Port chip enable: 0=and_reduce(wr_en)
                                                 // 1=wr_en(w/p)
      parameter int                                      ECC                                                          = 0              ,    // ECC enable : 0=disable ECC; 1=enable ECC



      parameter int                                      id                                                           = 0                   // unique value per instance
)
(
      input    logic                                                        clk                                     ,
      input    logic                                                        resetn                                  ,
      // read port
      input    logic                                                        rd_en                                   ,
      input    logic [ log2d - 1 : 0 ]                                      rd_addr                                 ,
      output   logic [ w - 1 : 0 ]                                          rd_data                                 ,
      input    logic                                                        rd_data_cken                            ,    // clk enable on rd_data register
      // write port
      input    logic [ ( w / p ) + wrcen - 1 : 0 ]                          wr_en                                   ,
      input    logic [ log2d - 1 : 0 ]                                      wr_addr                                 ,
      input    logic [ w - 1 : 0 ]                                          wr_data                                 ,
      // bist signals






      input    logic [ dpstore_in ( w,p,d,ECC ) - 1 : 0 ]                   bist_in                                 ,
      output   logic [ dpstore_out ( w,p,d,ECC ) - 1 : 0 ]                  bist_out                                ,
      input    logic                                                        tst_gclkenable                            
);

   








   logic [ w - 1 : 0 ]                           rd_data_ram                             ;
   logic [ w - 1 : 0 ]                           rd_data_ram_r                           ;

   ///////////////////////////////////////////////
   // backdoor access
   ///////////////////////////////////////////////




   ///////////////////////////////////////////////
   ///////////////////////////////////////////////
   // END backdoor access
   ///////////////////////////////////////////////


   gpu_core_mss_gfx_dpstore_wrap_
      #(
         .w                               (w)                                          ,
         .p                               (p)                                          ,
         .d                               (d)                                          ,
         .log2d                           (log2d)                                      ,
         .wrcen                           (wrcen)                                      ,
         .ECC                             (ECC)                                        ,



         .id                              (id)                                         
         )
      i_gpu_core_mss_gfx_dpstore_wrap
      (
         .clk                             (clk)                                        ,
         .resetn                          (resetn)                                     ,
         .rd_en                           (rd_en)                                      ,
         .rd_addr                         (rd_addr)                                    ,
         .rd_data_ram                     (rd_data_ram)                                ,
         .wr_en                           (wr_en)                                      ,
         .wr_addr                         (wr_addr)                                    ,
         .wr_data                         (wr_data)                                    ,






         .bist_in                         (bist_in)                                    ,
         .bist_out                        (bist_out)                                   ,
         .tst_gclkenable                  (tst_gclkenable)                               
         );

   // //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
   // Register the Ram Data for timing (This variant has an input enable signal to govern whether the data is registered or not)
   // //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
   always_ff @(posedge clk) begin
      begin
         if ( rd_data_cken == 1'b1 ) begin
            rd_data_ram_r <= rd_data_ram ;
         end
      end
   end

   assign rd_data = rd_data_ram_r ;

endmodule // gpu_core_gfx_dpstore_pipeline_gen_bist_r

