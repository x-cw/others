// ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////-
// entity name: gpc_gfx_timing_buffer_pipe
// Component Description: IMGLIB3 Generic Timing Buffer
// Generic Timing Buffer (use BUFFER_TYPE generic to instantiate a wide variety of modules)
//
// For description of each instantiated buffer type check appropriate source file.
//
// ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////-
// BUFFER TYPE     |   AREA COST   | VALID/DATA | ENABLE CHAIN | Comments
// ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////-
// Wire            |     ZERO!     | Same cycle | Not Broken   | No benefit!
// Simple Pipe reg | W x (FF)      | Delayed    | Not Broken   | Data registered but possible timing problems on the enable
// RSTL            | W x (2FF+Mux) | Delayed    | Broken       | Largest area but best for timing as everything is registered
// RSTL LOW POWER  |
// RSTL FAST IN    |
// HSTL            | W x (FF)      | Delayed    | Broken       | 50% Max throughput (use for low BW), but everything is registered
// MSTL            | W x (FF+Mux)  | Same cycle | Broken       | Data combinatorial but enable now registered to help timing
// Cascaded MSTLs  | W x 2(FF+Mux) | Same cycle | Broken       | Behaves like 2 deep FIFO with zero output latency
// ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////-
//
// Generics:
// BUFFER_TYPE - INTEGER
//             - Buffer Type to introduce - see table above, DEFAULT = 0 = Wire
// WIDTH       - INTEGER
//             - Width of Data bus Input/Output std_logic_vector
//
// Portlist:
// clk               - Clock Input
// resetn            - Active-low asynchronous Reset
// tbuff_in_data     - Data bus input (sized by generic w)
// tbuff_in_valid    - Valid input from upstream module
// tbuff_in_enable   - Enable output to upstream module
// tbuff_out_data    - Data bus output (sized by generic w)
// tbuff_out_valid   - Valid output to downstream module
// tbuff_out_enable  - Enable input from downstream module
//
// ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////-




module gpc_gfx_timing_buffer_pipe_
#(
      parameter int                                      BUFFER_TYPE                                                  = 0              ,
      parameter int                                      WIDTH                                                        = 32             ,
      parameter int                                      PIPE_STAGES                                                  = 1
)
(
      input    logic                                                        clk                                     ,
      input    logic                                                        resetn                                  ,
      // Input V/E Interface
      input    logic                                                        tbuff_in_valid                          ,
      output   logic                                                        tbuff_in_enable                         ,
      input    logic [ WIDTH - 1 : 0 ]                                      tbuff_in_data                           ,
      // Output V/E Interface
      output   logic                                                        tbuff_out_valid                         ,
      input    logic                                                        tbuff_out_enable                        ,
      output   logic [ WIDTH - 1 : 0 ]                                      tbuff_out_data
);

   import gpc_gfx_timing_buffer_pack_::*;

   logic  [PIPE_STAGES-1 :0]               in_valid_array    ;
   logic  [PIPE_STAGES-1 :0]               in_enable_array   ;
   logic  [PIPE_STAGES-1 :0][WIDTH-1 :0]   in_data_array     ;
   logic  [PIPE_STAGES-1 :0]               out_valid_array   ;
   logic  [PIPE_STAGES-1 :0]               out_enable_array  ;
   logic  [PIPE_STAGES-1 :0][WIDTH-1 :0]   out_data_array    ;

   //input connect
   assign in_valid_array[0]                  = tbuff_in_valid                    ;
   assign in_data_array[0]                   = tbuff_in_data                     ;
   assign tbuff_in_enable                    = in_enable_array[0]                ;

   //output connect
   assign tbuff_out_valid                    = out_valid_array[PIPE_STAGES-1]    ;
   assign out_enable_array[PIPE_STAGES-1]    = tbuff_out_enable                  ;
   assign tbuff_out_data                     = out_data_array[PIPE_STAGES-1]     ;

   //inner connect
   always_comb begin
      for (int buffer_idx=0; buffer_idx<PIPE_STAGES-1; buffer_idx++) begin
         in_valid_array[buffer_idx+1] = out_valid_array[buffer_idx]     ;
         out_enable_array[buffer_idx] = in_enable_array[buffer_idx+1]   ;
         in_data_array[buffer_idx+1]  = out_data_array[buffer_idx]      ;
      end
   end



   //generate gpc_gfx_timing_buffer_ instance
   genvar i;
   generate
      for (i=0; i < PIPE_STAGES; i=i+1) begin : g_gen_gpc_gfx_timing_buffer
         gpc_gfx_timing_buffer_
         #(
               .BUFFER_TYPE (BUFFER_TYPE) ,
               .WIDTH       (WIDTH)
         )i_timing_buffer_
         (
               .clk             (clk      ),
               .resetn          (resetn   ),

               .tbuff_in_valid  (in_valid_array[i]  ),
               .tbuff_in_enable (in_enable_array[i] ),
               .tbuff_in_data   (in_data_array[i]   ),

               .tbuff_out_valid (out_valid_array[i] ),
               .tbuff_out_enable(out_enable_array[i]),
               .tbuff_out_data  (out_data_array[i]  )
         );

      end
   endgenerate


endmodule // gpc_gfx_timing_buffer_pipe_
