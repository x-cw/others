
module gpc_gfx_timing_buffer_no_handshake_
#(

      parameter int                                      WIDTH                                                        = 32             ,
      parameter logic    [WIDTH-1:0]                     INI_DAT                                                      = {WIDTH{1'b0}}              
)
(
      input    logic                                                        clk                                     ,
      input    logic                                                        resetn                                  ,
      // Input Interface
      input    logic [ WIDTH - 1 : 0 ]                                      tbuff_in_data                           ,
      // Output Interface
      output   logic [ WIDTH - 1 : 0 ]                                      tbuff_out_data                           
);



   logic  [WIDTH-1 :0]   data_reg_array     ; 

   //input connect
   always_ff @(posedge clk or negedge resetn) begin
      if(!resetn)
         data_reg_array    <= INI_DAT ;
      else
         data_reg_array    <= tbuff_in_data    ;
   end

   //output connect
   assign tbuff_out_data                     = data_reg_array     ;

endmodule // gpc_gfx_timing_buffer_no_handshake_
