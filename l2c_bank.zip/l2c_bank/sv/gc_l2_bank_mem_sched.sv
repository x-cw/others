// ---------------------------------------------------------------------------------
// Project Name  : IC_Design
// Author        : liusm
// Email         : liusm@innosilicon.com.cn
// Create On     : 2025/01/07 11:05
// Last Modified : 2025/05/27 11:09
// File Name     : gc_l2_bank_mem_sched.sv
// Description   :
// 
// Copyright (c) 2025 Innosilicon.
// ALL RIGHTS RESERVED
// 
// ---------------------------------------------------------------------------------
// Modification History:
// Date         By              Version                 Change Description
// ---------------------------------------------------------------------------------
// 2025/01/07   liusm           1.0                     Original
// 
// ----------------------------------------------------------------------------------


module gc_l2_bank_mem_sched
import gc_l2_bank_pkg::*;
import gpc_gfx_timing_buffer_pack_::*;
(
      input    logic                         clk
,     input    logic                         resetn

,     output   logic                         mem_sched_idle

,     input    logic                         bank0_memif_sched_valid
,     output   logic                         bank0_memif_sched_ready
,     input    bank_group_sched_data_bus_t   bank0_memif_sched_rec



,     output   logic                         bank0_sched_memif_valid
,     input    logic                         bank0_sched_memif_ready
,     output   bank_group_sched_data_bus_t   bank0_sched_memif_rec


,     input    logic                         bank1_memif_sched_valid
,     output   logic                         bank1_memif_sched_ready
,     input    bank_group_sched_data_bus_t   bank1_memif_sched_rec



,     output   logic                         bank1_sched_memif_valid
,     input    logic                         bank1_sched_memif_ready
,     output   bank_group_sched_data_bus_t   bank1_sched_memif_rec
);

logic                                        req_queue0_idle               ;
logic                                        req_queue1_idle               ;

assign mem_sched_idle = req_queue0_idle && req_queue1_idle ;





// ========================================================================
// Ring buffer to reorder the PAs
// ========================================================================

gc_l2_bank_mem_sched_ring_buf
l2_bank_req_queue0     (
    .clk               ( clk                     )
   ,.resetn            ( resetn                  )
   
   ,.idle              ( req_queue0_idle         )
   
   ,.memif_sched_valid ( bank0_memif_sched_valid )
   ,.memif_sched_ready ( bank0_memif_sched_ready )
   ,.memif_sched_rec   ( bank0_memif_sched_rec   )
   
   
   ,.ring_buf_valid    ( bank0_sched_memif_valid )
   ,.ring_buf_ready    ( bank0_sched_memif_ready )
   ,.ring_buf_rec      ( bank0_sched_memif_rec   )
                                                 ) ;

gc_l2_bank_mem_sched_ring_buf
l2_bank_req_queue1     (
    .clk               ( clk                     )
   ,.resetn            ( resetn                  )
   
   ,.idle              ( req_queue1_idle         )
   
   ,.memif_sched_valid ( bank1_memif_sched_valid )
   ,.memif_sched_ready ( bank1_memif_sched_ready )
   ,.memif_sched_rec   ( bank1_memif_sched_rec   )
   
   ,.ring_buf_valid    ( bank1_sched_memif_valid )
   ,.ring_buf_ready    ( bank1_sched_memif_ready )
   ,.ring_buf_rec      ( bank1_sched_memif_rec   )
   );
endmodule
// Local Variables:
// verilog-library-directories:("./" ) 
// End:
