/*

 * #==========================================================================#
 * |                                                                          |
 * |  Copyright (c) 2022, Fantasy Technologies Limited and/or its         |
 * |  affiliated group companies ("Fantasy"). All rights reserved.        |
 * |  No part of this content, either material or conceptual may be copied    |
 * |  or distributed, transmitted, transcribed, stored in a retrieval system  |
 * |  or translated into any human or computer language in any form by any    |
 * |  means, electronic, mechanical manual, or otherwise, or disclosed to     |
 * |  third parties without the express written permission of Fantasy.    |
 * |                                                                          |
 * #==========================================================================#

 */


// ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////-
// entity name: gpc_gfx_hstl 
// Component Description: IMGLIB3 Half-sized Registered Staller
// Inserts a register in the valid, enable and data path between upstream and downstream modules in order to break a timing path.
// Data from the upstream module is always subject to at least a cycle delay as a result of inserting an RSTL into the path.
// In addition, at the cost of 1 cycle of latency to the throughput of this component, the gpc_gfx_hstl utilises half the register
// stages needed for a full gpc_gfx_rstl Registered Staller.
//
// The gpc_gfx_hstl effectively operates as a single pipeline stage between the upstream and downstream interfaces. The enable
// to the register stage is only set when the stage is empty, hence back to back valid cycles from upstream will be subject to a
// 1 cycle stall between updates of the register stage. However the area saving is significant particularly when used on a wide but
// more sparsely used interface.
//
// Generics:
// w           - INTEGER
//             - Width of Data bus Input/Output std_logic_vector
//
// Portlist:
// clk     - Clock Input
// resetn  - Active-low asynchronous Reset
// din     - Data bus input (sized by generic w)
// vin     - Valid input from upstream module
// eout    - Enable output to upstream module
// dout    - Data bus output (sized by generic w)
// vout    - Valid output to downstream module
// ein     - Enable input from downstream module
// ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////-
//              +//////+
//              |      |
//din +////////-+      +////////+ dout
//              |      |
//              |      |                   eout AND vin
//              |\     |                         +
//          +//-+/     |                         |
//          |   |      |                     +//-0//+
//          |   +//////+    ~eout AND ein    |      |
//          |                      +////////-1      +////////+ eout
//          |                                |      |
//          //////////////////////////////   |      |
//              +//////+                 |   |\     |
//              |      |                 +//-+/     |
//vin +////////-+      +////////+ vout   |   |      |
//              |      |                 |   +//////+
//              |      |                 |
//              |\     |                 |
//          +//-+/     |                 |
//          |   |      |                 |
//          |   +//////+                 |
//          |                            |
//          |                            |
//clk +//////////////////////////////////-
// ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////-



module gpc_gfx_hstl_
#(
   parameter int                                      w                                                            = 0               
)
(
   input    logic                                                        clk                                     ,
        input    logic                                                        resetn                                  ,
        // upstream signals
        input    logic [ w - 1 : 0 ]                                          din                                     ,
        input    logic                                                        vin                                     ,
        output   logic                                                        eout                                    ,
        // downstream signals
        output   logic [ w - 1 : 0 ]                                          dout                                    ,
        output   logic                                                        vout                                    ,
        input    logic                                                        ein                                       
);

   logic                                         eout_i                                  ;
   logic [ w - 1 : 0 ]                           dout_i                                  ;

   
   always_ff @(posedge clk or negedge resetn) begin : rctrl
      if ( ( resetn == 1'b0 ) ) begin
         eout_i <= 1'b1 ;
         vout <= 1'b0 ;
      end else begin

         if ( ( eout_i == 1'b1 ) ) begin

            // enable out high, so valid out must be low
            if ( ( vin == 1'b1 ) ) begin

               // new data so drop enable
               eout_i <= 1'b0 ;

            end

            // register data in
            vout <= vin ;

         end else begin

            // enable out low so valid out must be high
            if ( ( ein == 1'b1 ) ) begin

               eout_i <= 1'b1 ;

               // Drop the valid to allow for single cycle latency
               vout <= 1'b0 ;

            end

         end

      end
   end // rctrl

   assign dout = dout_i ;
   assign eout = eout_i ;

   always_ff @(posedge clk or negedge resetn) begin : rdout
      if ( ( resetn == 1'b0 ) ) begin
         dout_i <= '0 ;
      end else begin
         if ( ( eout_i == 1'b1 ) ) begin

            // Enabled, valid must be low
            if ( ( vin == 1'b1 ) ) begin

               // new data 
               dout_i <= din ;

            end

         end

      end
   end // rdout

endmodule // gpc_gfx_hstl
