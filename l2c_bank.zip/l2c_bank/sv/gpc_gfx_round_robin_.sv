/*

 * #==========================================================================#
 * |                                                                          |
 * |  Copyright (c) 2022, Fantasy Technologies Limited and/or its         |
 * |  affiliated group companies ("Fantasy"). All rights reserved.        |
 * |  No part of this content, either material or conceptual may be copied    |
 * |  or distributed, transmitted, transcribed, stored in a retrieval system  |
 * |  or translated into any human or computer language in any form by any    |
 * |  means, electronic, mechanical manual, or otherwise, or disclosed to     |
 * |  third parties without the express written permission of Fantasy.    |
 * |                                                                          |
 * #==========================================================================#

 */


module gpc_gfx_round_robin_
  #(
    parameter int W = 8               // Input Width
    )
   (
    input logic [ W - 1 : 0 ]          valids ,
    input logic [ $clog2(W) -1 : 0]    prev_req,
    output logic [ $clog2(W) - 1 : 0 ] result    
);

   import gpc_gfx_std_func_pack_::*;
   
   logic [$clog2(W)-1:0]  selected_req;
   
   always_comb begin
      logic [$clog2(W)-1:0] bit_to_check;

      selected_req  = prev_req;

      for (int outer_req = 0; outer_req <= W-1 ; outer_req++) begin
         if (outer_req == prev_req) begin
            for (int inner_req = W-1; inner_req >= 1 ; inner_req--) begin
               bit_to_check              = (inner_req + outer_req) % W;

               if (valids[bit_to_check] == 1'b1) begin
                  selected_req  = bit_to_check;
               end
            end
         end
      end // for (int outer_req = 0; outer_req <= NUM_REQ-1 ; outer_req++)
   end // always_comb
   
   assign result  = selected_req;
   
endmodule // gpc_gfx_round_robin_

                    
   
