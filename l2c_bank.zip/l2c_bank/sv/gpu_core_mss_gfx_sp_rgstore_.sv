/*

 * #==========================================================================#
 * |                                                                          |
 * |  Copyright (c) 2022, Fantasy Technologies Limited and/or its         |
 * |  affiliated group companies ("Fantasy"). All rights reserved.        |
 * |  No part of this content, either material or conceptual may be copied    |
 * |  or distributed, transmitted, transcribed, stored in a retrieval system  |
 * |  or translated into any human or computer language in any form by any    |
 * |  means, electronic, mechanical manual, or otherwise, or disclosed to     |
 * |  third parties without the express written permission of Fantasy.    |
 * |                                                                          |
 * #==========================================================================#

 */

// ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////-
// entity name: gpu_core_mss_gfx_sp_rgstore
// purpose: Implements the function of the single port ram using registers. Data is captured on clock and read data has one cycle of
// latency.
// ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////-

module gpu_core_mss_gfx_sp_rgstore_
#(
   parameter w     = 32, // integer
   parameter p     = 32, // integer
   parameter d     = 16, // integer
   parameter log2d = 4 // integer
)
(
   input  logic CLK,
   input  logic CEN,
   input  logic [ ( w / p ) - 1 : 0 ] WEN,
   input  logic [ log2d - 1 : 0 ] A,
   input  logic [ w - 1 : 0 ] DI,
   output logic [ w - 1 : 0 ] Q
);





   logic wen_ctrl;
   logic[ w - 1 : 0 ] d_001 [ 0:d-1 ];

   ///////////////////////////////////////////////
   // backdoor access
   ///////////////////////////////////////////////
































   ///////////////////////////////////////////////
   // END backdoor access
   ///////////////////////////////////////////////

   assign wen_ctrl = ( & WEN ) ;

   // Write process
   always_ff@(posedge CLK) begin : wr
      if ( ( CEN == 1'b0 && wen_ctrl == 1'b0 ) ) begin
         for (int i=( w / p ) - 1; i>=0 ;i--) begin
            if ( WEN [ i ] == 1'b0 ) begin
               d_001[A][( p * i )+:p] <= DI[ ( p * i )+:p ] ;
            end
         end
      end
   end

   // Read process
   always_ff@(posedge CLK) begin : rd
      if ( ( CEN == 1'b0 ) ) begin
         Q <= d_001[A] ;
      end
   end

endmodule

