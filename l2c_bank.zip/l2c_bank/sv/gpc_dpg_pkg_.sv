/*

 * #==========================================================================#
 * |                                                                          |
 * |  Copyright (c) 2022, Fantasy Technologies Limited and/or its         |
 * |  affiliated group companies ("Fantasy"). All rights reserved.        |
 * |  No part of this content, either material or conceptual may be copied    |
 * |  or distributed, transmitted, transcribed, stored in a retrieval system  |
 * |  or translated into any human or computer language in any form by any    |
 * |  means, electronic, mechanical manual, or otherwise, or disclosed to     |
 * |  third parties without the express written permission of Fantasy.    |
 * |                                                                          |
 * #==========================================================================#

 */
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//   Fantasy Technologies Datapath component
//   Please note this component has been verified as conforming to the design requirements
//   and any modifications required should be requested directly with the authors.
//

//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
// These functions are only intended for use within other datapath components, and are not meant for general use.
// They are verified for the range of -2147483647 to +2147483647 for dpg_max and dpg_min and
// for the range of +1 to +2147483647 for dpg_log2f and dpg_log2c.
//
// Outside the verified range, they are likely to produce unexpected results.
// This follows from the VHDL 1993 LRM section 3.1.2.1:
// "The range of INTEGER is implementation dependent, but it is guaranteed to include the range -2147483647 to +2147483647.
// It is defined with an ascending range."
// and positive is defined in section 3.2.1.2 as:
// "subtype POSITIVE is INTEGER range 1 to INTEGER'HIGH"
//

package gpc_dpg_pkg_;

   // maximum
  function automatic integer dpg_max(input integer a, b);
     if (a > b) return a; else return b;
  endfunction : dpg_max

   // minimum
   function automatic integer dpg_min(input integer a, b);
      if (a < b) return a; else return b;
   endfunction : dpg_min

   // floor( log2( x ) )
   function automatic integer dpg_log2f(input integer x);
      // synopsys translate_off
      assert (x > 0) else $fatal(1, "input to dpg_log2f must be positive");
      // synopsys translate_on
      for (int i = 0; i < 30; i++)
        if (x < 2**(i+1))
          return i;
      return 30;
   endfunction : dpg_log2f

   // ceil( log2( x ) )
   function automatic integer dpg_log2c(input integer x);
      // synopsys translate_off
      assert (x > 0) else $fatal(1, "input to dpg_log2c must be positive");
      // synopsys translate_on
      for (int i = 0; i < 31; i++)
        if (x <= 2**i)
          return i;
      return 31;
   endfunction

endpackage : gpc_dpg_pkg_
