/*

 * #==========================================================================#
 * |                                                                          |
 * |  Copyright (c) 2022, Fantasy Technologies Limited and/or its         |
 * |  affiliated group companies ("Fantasy"). All rights reserved.        |
 * |  No part of this content, either material or conceptual may be copied    |
 * |  or distributed, transmitted, transcribed, stored in a retrieval system  |
 * |  or translated into any human or computer language in any form by any    |
 * |  means, electronic, mechanical manual, or otherwise, or disclosed to     |
 * |  third parties without the express written permission of Fantasy.    |
 * |                                                                          |
 * #==========================================================================#

 */

package gpc_gfx_tb_pack_;


// GPC_GFX_TB_PACK

// NOTES :
////////////////////////////////////////////-
// This Package is used to configure the   //
// tag names or mnemonics used to identify //
// modules within a design. By customising //
// the constants below gpc_bus_stim can    //
// identify data destined for a given      //
// module by recognising the tag name. The //
// corresponding bit of the sys_sel_vector //
// is subsequently set which can be used   //
// as a valid signal for that module.      //
////////////////////////////////////////////-




   // OFFSET CONFIGURATION          
   localparam int                                           GFXLIB_NO_OF_OFFSETS                     = 14                            ;

   // Bit position where offset ends ie the part of the offset address which is compared
   // with an outfile. ie 12 would mean that 31 downto "12" is compared with an address in
   // an outfile to search for a register matching those below. The lower bits allow addressing
   // of specific registers within a module.
   localparam int                                           OFFSET_END                               = 12                            ;

   // VIRTUAL ADDRESSING CONFIGURATION
   localparam int                                           NO_OF_VIRTUAL_ADDRESSING_SCHEMES         = 16                            ;

   typedef enum logic [3:0] {GCREG = 4'b0000,
                           IDLE = 4'b0001,
                           MEM_FWP_CM0 = 4'b0010,
                           MEM_FWP_CM1 = 4'b0011,
                           MEM_FWP_CM2 = 4'b0100,
                           REGALLCORES = 4'b0101,
                           REGCORE0 = 4'b0110,
                           REGCORE1 = 4'b0111,
                           REGCORE2 = 4'b1000,
                           REGCORE3 = 4'b1001,
                           REGHYDRA = 4'b1010,
                           REG_JX = 4'b1011,
                           REG_FWP_SD = 4'b1100,
                           REG_FWP_TB = 4'b1101,
                           REG_JD = 4'b1110,
                           REG_JTAG = 4'b1111} name_e;
   
   typedef enum bit [0:0] {NONE = 1'b0,
                           GC = 1'b1} applyto_e;
   
   typedef struct packed {
      logic [3:0]                                                      name                                    ;    // Maximum size of tag names (unusued chars should be left blank ' ')
      bit [0:0]                                                   apply_to                                ;    // Maximum size of tag names (unusued chars should be left blank ' ')
      logic [31 : 0 ]                                             addr                                    ;
   } va_t;

   typedef va_t [ 0 : NO_OF_VIRTUAL_ADDRESSING_SCHEMES - 1 ] va_array_t ;

// constant VA_ARRAY : va_array_t;

   // Function used to convert hex expressions in array   

   typedef struct packed {
      logic [3:0]                                                       name                                    ;    // Maximum size of tag names (unusued chars should be left blank ' ')
      logic [ 31 : 0 ]                                             addr                                    ;
      logic [ 31 : 0 ]                                             simaddr                                 ;
   } offset_t;

   typedef offset_t [ 0 : GFXLIB_NO_OF_OFFSETS - 1 ] offset_array_t ;
    
// constant OFFSET_ARRAY : offset_array_t;

   // returns integer index of the OFFSET_ARRAY for corresponding offset name

   // Note the offset name strings used below should be the same length as defined
// constant REG_JX_CS : integer;
// constant REG_FWP_SD_CS : integer;
// constant REG_FWP_TB_CS : integer;
// constant REG_JD_CS : integer;
// constant REG_JTAG_CS : integer;
//   typedef enum bit [1:0] {MEM_FWP_CM0,MEM_FWP_CM1,MEM_FWP_CM2,IDLE} name2_e;
   localparam int                                           NO_OF_MEM_ID                             = 3                             ;
   typedef struct packed {
      logic [3:0]                                                       name                                    ;    // Maximum size of tag names (unused chars should be left blank ' ')
      int                                                          mem_id                                  ;
   } mem_id_t;

   typedef mem_id_t [ 0 : NO_OF_MEM_ID - 1 ] mem_id_array_t ;

// constant MEM_ID_ARRAY : mem_id_array_t;

   
    
   // Stripped out function logic hex2slv;
       // Convert hex string to std_logic_vector


   localparam offset_array_t                                OFFSET_ARRAY                             = '{ 0 : '{ 4'b0101 , 32'h00000000 , 32'h00000000 } , 
                                                                                                          1 : '{ 4'b0110 , 32'h00004000 , 32'h00000000 } , 
                                                                                                          2 : '{ 4'b0111 , 32'h00008000 , 32'h00000000 } , 
                                                                                                          3 : '{ 4'b1000 , 32'h0000C000 , 32'h00000000 } , 
                                                                                                          4 : '{ 4'b1001 , 32'h00010000 , 32'h00000000 } , 
                                                                                                          5 : '{ 4'b1010 , 32'h00014000 , 32'h00000000 } , 
                                                                                                          6 : '{ 4'b1011   , 32'h00000000 , 32'h00000000 } , 
                                                                                                          7 : '{ 4'b1100 , 32'h00000000 , 32'h00000000 } , 
                                                                                                          8 : '{ 4'b1101 , 32'h00000000 , 32'h00000000 } , 
                                                                                                          9 : '{ 4'b0010 , 32'h00000000 , 32'h00000000 } , 
                                                                                                          10 : '{ 4'b0011 , 32'h00000000 , 32'h00000000 } , 
                                                                                                          11 : '{ 4'b0100 , 32'h00000000 , 32'h00000000 } , 
                                                                                                          12 : '{ 4'b1110       , 32'h00000000 , 32'h00000000 } , 
                                                                                                          13 : '{ 4'b1111 , 32'h00000000 , 32'h00000000 }  
                                                                                                          };    // Region Name, Chip offset address, Simulator offset address       REG_JX: Used for accesses into FWP through JTAG  REG_FWP_SD: Used for accesses into FWP through it's slave port  REG_FWP_TB: Used for test bench registers of FWP stand alone test bench  Used for block access to Fwp core memory ram 0  Used for block access to Fwp core memory ram 1  Used for block access to Fwp core memory ram 2  REG_JD: Used for accesses of FWP's debug interface registers  REG_JTAG: Used for low level JTAG commands   



   /*
    * localparam offset_array_t                                OFFSET_ARRAY                             = '{ 0 : '{ REGALLCORES , 32'h00000000 , 32'hXXXXXXXX } , 
                                                                                                           1 : '{ REGCORE0 , 32'h00004000 , 32'hXXXXXXXX } , 
                                                                                                           2 : '{ REGCORE1 , 32'h00008000 , 32'hXXXXXXXX } , 
                                                                                                           3 : '{ REGCORE2 , 32'h0000C000 , 32'hXXXXXXXX } , 
                                                                                                           4 : '{ REGCORE3 , 32'h00010000 , 32'hXXXXXXXX } , 
                                                                                                           5 : '{ REGHYDRA , 32'h00014000 , 32'hXXXXXXXX } , 
                                                                                                           6 : '{ REG_JX   , 32'h00000000 , 32'hXXXXXXXX } , 
                                                                                                           7 : '{ REG_FWP_SD , 32'h00000000 , 32'hXXXXXXXX } , 
                                                                                                           8 : '{ REG_FWP_TB , 32'h00000000 , 32'hXXXXXXXX } , 
                                                                                                           9 : '{ MEM_FWP_CM0 , 32'h00000000 , 32'hXXXXXXXX } , 
                                                                                                           10 : '{ MEM_FWP_CM1 , 32'h00000000 , 32'hXXXXXXXX } , 
                                                                                                           11 : '{ MEM_FWP_CM2 , 32'h00000000 , 32'hXXXXXXXX } , 
                                                                                                           12 : '{ REG_JD       , 32'h00000000 , 32'hXXXXXXXX } , 
                                                                                                           13 : '{ REG_JTAG , 32'h00000000 , 32'hXXXXXXXX }  
                                                                                                           };    // Region Name, Chip offset address, Simulator offset address       REG_JX: Used for accesses into FWP through JTAG  REG_FWP_SD: Used for accesses into FWP through it's slave port  REG_FWP_TB: Used for test bench registers of FWP stand alone test bench  Used for block access to Fwp core memory ram 0  Used for block access to Fwp core memory ram 1  Used for block access to Fwp core memory ram 2  REG_JD: Used for accesses of FWP's debug interface registers  REG_JTAG: Used for low level JTAG commands   
    */

   localparam va_array_t                                    VA_ARRAY                                 = '{ 0 : '{ 4'b0000 , 1'b1 , 32'h00001200 } , 
                                                                                                          1 : '{ 4'b0001 , 1'b0 ,  32'h00000000 } ,
                                                                                                          2 : '{ 4'b0001 , 1'b0 ,  32'h00000000 } ,
                                                                                                          3 : '{ 4'b0001 , 1'b0 ,  32'h00000000 } ,
                                                                                                          4 : '{ 4'b0001 , 1'b0 ,  32'h00000000 } ,
                                                                                                          5 : '{ 4'b0001 , 1'b0 ,  32'h00000000 } ,
                                                                                                          6 : '{ 4'b0001 , 1'b0 ,  32'h00000000 } ,
                                                                                                          7 : '{ 4'b0001 , 1'b0 ,  32'h00000000 } ,
                                                                                                          8 : '{ 4'b0001 , 1'b0 ,  32'h00000000 } ,
                                                                                                          9 : '{ 4'b0001 , 1'b0 ,  32'h00000000 } ,
                                                                                                          10 : '{ 4'b0001 , 1'b0 ,  32'h00000000 } ,
                                                                                                          11 : '{ 4'b0001 , 1'b0 ,  32'h00000000 } ,
                                                                                                          12 : '{ 4'b0001 , 1'b0 ,  32'h00000000 } ,
                                                                                                          13 : '{ 4'b0001 , 1'b0 ,  32'h00000000 } ,
                                                                                                          14 : '{ 4'b0001 , 1'b0 ,  32'h00000000 } ,
                                                                                                          15 : '{ 4'b0001 , 1'b0 ,  32'h00000000 }
                                                            
                                                                                                          };    // Configuration name, Prefix to apply scheme to, Base table address (byte addr) Base Table Address for Rogue  

    localparam mem_id_array_t                                MEM_ID_ARRAY                             = '{ 0 : '{ 4'b0010 , 16 } , 
                                                                                                           1 : '{ 4'b0011, 17 } , 
                                                                                                           2 : '{ 4'b0100 , 18 } 
                                                                                                           };     

   // returns integer index of the OFFSET_ARRAY for corresponding offset name
   function automatic int get_index_from_offset_array;
   input  logic [3:0]                                         offset_name ;
      int                                           index                                   ;
      for ( int index = 0 ; index <= GFXLIB_NO_OF_OFFSETS - 1 ; index = index + 1 ) begin
         if ( ( OFFSET_ARRAY [ index ] .name == offset_name ) ) begin
            return ( index ) ;
         end
      end
      return ( 0 ) ;
   endfunction // get_index_from_offset_array

   // Note the offset name strings used below should be the same length as defined in OFFSET_ARRAY
   localparam int                                           REG_JX_CS                                = get_index_from_offset_array ( 4'b1011 );
   localparam int                                           REG_FWP_SD_CS                           = get_index_from_offset_array ( 4'b1100 );
   localparam int                                           REG_FWP_TB_CS                           = get_index_from_offset_array ( 4'b1101 );
   localparam int                                           REG_JD_CS                                = get_index_from_offset_array ( 4'b1110 );
   localparam int                                           REG_JTAG_CS                              = get_index_from_offset_array ( 4'b1111 );
    
endpackage
