// ---------------------------------------------------------------------------------
// Project Name  : IC_Design
// Author        : liusm
// Email         : liusm@innosilicon.com.cn
// Create On     : 2025/01/06 19:13
// Last Modified : 2025/08/25 17:41
// File Name     : gc_l2_bank_rob.sv
// Description   :
// 
// Copyright (c) 2025 Innosilicon.
// ALL RIGHTS RESERVED
// 
// ---------------------------------------------------------------------------------
// Modification History:
// Date         By              Version                 Change Description
// ---------------------------------------------------------------------------------
// 2025/01/06   liusm           1.0                     Original
// 
// ----------------------------------------------------------------------------------


module gc_l2_bank_rob
import gpc_gfx_timing_buffer_pack_::*;
import gc_l2_bank_pkg::*;

(
      input   logic                             clk
,     input   logic                             resetn

,     output  logic                             rob_idle

,     input   logic                             read_valid
,     output  logic                             read_ready
,     input   l2_bank_rob_pipe_record_type      read_rec

,     output  logic                             readout_valid
,     input   logic                             readout_ready
,     output  l2_bank_rob_readout_record_type   readout_rec


,     input   logic                             write_valid
,     input   l2_bank_rob_write_record_type     write_rec

,     output  logic [L2_ROB_DEPTH-1:0]          index_free_mask
,     input   logic                             tst_gclkenable
);

generate
// if (L2_ROB_DEPTH == 160) begin: g_two_size_ram
if (0) begin: g_two_size_ram
   localparam int L2_ROB_PART1_DEPTH = 256                               ;
   localparam int L2_ROB_PART1_BITS  = $clog2(L2_ROB_PART1_DEPTH)        ;

   localparam int L2_ROB_PART2_DEPTH = L2_ROB_DEPTH*2-L2_ROB_PART1_DEPTH ;
   localparam int L2_ROB_PART2_BITS  = $clog2(L2_ROB_PART2_DEPTH)        ;
   logic                                                write_ready                ;
   logic                                                rob_write_valid            ;
   logic                                                rob_write_en               ;
   logic [L2_ROB_BITS:0]                                rob_write_addr             ;
   logic [L2_NSP_DATA_BITS-1:0]                         rob_write_data             ;

   logic [L2_ROB_DEPTH*2-1:0]                           rob_index_used_mask        ;

   logic                                                request_stage1_valid       ;
   logic                                                request_stage1_ready       ;
   logic [L2_NSP_DATA_BITS-1:0]                         request_stage1_data        ;
   l2_bank_rob_pipe_record_type                         request_stage1_rec         ;
   logic [L2_NSP_DATA_BITS-1:0]                         qa1                        ;
   logic [L2_NSP_DATA_BITS-1:0]                         qa2                        ;

   logic                                                split_issued               ;
   logic [L2_ROB_BITS:0]                                split_rd_addr              ;
   logic                                                n_request_stage1_valid     ;
   logic                                                n_request_stage1_ready     ;
   logic                                                request_stage1_last        ;
   
   logic                                                read_ram_select            ; // 0: parti; 1: partii
   logic                                                write_ram_select           ;
   logic                                                cenb1                      ;
   logic                                                cenb2                      ;
   logic                                                cena1                      ;
   logic                                                cena2                      ;
   logic                                                request_stage1_stall_valid ;
   logic [L2_NSP_DATA_BITS-1:0]                         request_stage1_stall_data  ;

   for (genvar INDEX = 0; INDEX < L2_ROB_DEPTH*2; INDEX++) begin: g_update_rob_mask
      always_ff@(posedge clk or negedge resetn) begin
         if (!resetn) begin
            rob_index_used_mask[INDEX] <= '0;
         end
         else if (rob_write_valid && INDEX == rob_write_addr) begin
            rob_index_used_mask[INDEX] <= 1'b1;
         end
         else if (n_request_stage1_valid && n_request_stage1_ready && split_rd_addr == INDEX) begin
            rob_index_used_mask[INDEX] <= 1'b0;
         end
      end
   end
   for (genvar INDEX = 0; INDEX < L2_ROB_DEPTH; INDEX++) begin
      always_ff@(posedge clk or negedge resetn) begin
         if (!resetn) 
            index_free_mask[INDEX] <= 1'b0;
         else if (request_stage1_valid && request_stage1_ready && request_stage1_last && request_stage1_rec.rob_index == INDEX) begin
            index_free_mask [INDEX] <= 1'b1;
         end 
         else begin
            index_free_mask[INDEX] <= 1'b0;
         end
      end
   end

   // write data to ROB
   assign write_ready = 1'b1;
   always_ff@(posedge clk or negedge resetn) begin
      if (!resetn) begin
         rob_write_valid <= 1'b0;
         rob_write_addr  <= '0;
         rob_write_data  <= '0;
         rob_write_en    <= '0;
      end
      else if (write_valid && write_ready) begin
         rob_write_valid <= 1'b1;
         rob_write_data  <= write_rec.write_data[L2_NSP_DATA_BITS-1:0]; //
         rob_write_addr  <= {write_rec.rob_index, write_rec.write_mask[0]};
         rob_write_en    <= 1'b0; // active low
      end
      else if (rob_write_valid) begin
         rob_write_valid <= 1'b0;
         rob_write_en <= 1'b1;
      end
   end

   always_ff@(posedge clk or negedge resetn) begin
      if (!resetn) begin
         split_issued <= 1'b0;
      end
      else if (read_valid && read_ready) begin
         split_issued <= 1'b0;
      end
      else if (n_request_stage1_valid && n_request_stage1_ready) begin
         split_issued <= 1'b1;
      end
   end
   assign split_rd_addr = split_issued ? {read_rec.rob_index, 1'b1} : {read_rec.rob_index, 1'b0};

   assign read_ready = split_issued && n_request_stage1_ready;

   assign n_request_stage1_valid = read_valid;
   assign n_request_stage1_ready = (!request_stage1_valid | request_stage1_ready) && (rob_index_used_mask[split_rd_addr]) && n_request_stage1_valid;
   
   
   assign read_ram_select  = read_valid ?  |split_rd_addr[L2_ROB_BITS:L2_ROB_PART1_BITS] : 1'b0;
   assign write_ram_select = rob_write_valid ? |rob_write_addr[L2_ROB_BITS:L2_ROB_PART1_BITS] : 1'b0;
   assign cenb1            = ~rob_write_valid        ||  write_ram_select;
   assign cenb2            = ~rob_write_valid        || ~write_ram_select;
   assign cena1            = ~n_request_stage1_valid ||  read_ram_select;
   assign cena2            = ~n_request_stage1_valid || ~read_ram_select;


   gpu_core_mss_gfx_dpstore   # ( // lower 256 rob index
       .w                       ( 256                                   ) ,
       .p                       ( 256                                   ) ,
       .d                       ( L2_ROB_PART1_DEPTH                    ) ,
       .log2d                   ( L2_ROB_PART1_BITS                     ) ,
       .id                      ( 30003                                 ) )
   i_rob_dpsram_parti           (
    .CLKA                       ( clk                                   )
   ,.CENA                       ( cena1                                 )
   ,.AA                         ( split_rd_addr[L2_ROB_PART1_BITS-1:0]  )
   ,.QA                         ( qa1                                   )
   ,.CLKB                       ( clk                                   )
   ,.CENB                       ( cenb1                                 ) // active low
   ,.WENB                       ( rob_write_en                          ) // active low
   ,.AB                         ( rob_write_addr[L2_ROB_PART1_BITS-1:0] )
   ,.DB                         ( rob_write_data                        )
   ,.TE                         ( tst_gclkenable                        )
   ,.L2M                        (                                       )
   ,.SRAM                       (                                       ) );




   gpu_core_mss_gfx_dpstore   # ( // higher 64 rob index
       .w                       ( 256                                   ) ,
       .p                       ( 256                                   ) ,
       .d                       ( L2_ROB_PART2_DEPTH                    ) ,
       .log2d                   ( L2_ROB_PART2_BITS                     ) ,
       .id                      ( 30008                                 ) )
   i_rob_dpsram_partii          (
    .CLKA                       ( clk                                   )
   ,.CENA                       ( cena2                                 )
   ,.AA                         ( split_rd_addr[L2_ROB_PART2_BITS-1:0]  )
   ,.QA                         ( qa2                                   )
   ,.CLKB                       ( clk                                   )
   ,.CENB                       ( cenb2                                 ) // active low
   ,.WENB                       ( rob_write_en                          ) // active low
   ,.AB                         ( rob_write_addr[L2_ROB_PART2_BITS-1:0] )
   ,.DB                         ( rob_write_data                        )
   ,.TE                         ( tst_gclkenable                        )
   ,.L2M                        (                                       )
   ,.SRAM                       (                                       ) );
   logic request_stage1_ram_select;
   always_ff@(posedge clk or negedge resetn) begin
      if (!resetn) begin
         request_stage1_valid <= '0;
         request_stage1_rec <= '0;
         request_stage1_last <= 1'b0;
         request_stage1_ram_select <= 1'b0;
      end
      else if (n_request_stage1_valid && n_request_stage1_ready) begin
         request_stage1_valid <= 1'b1;
         request_stage1_rec <= read_rec;
         request_stage1_last <=  split_issued;
         request_stage1_ram_select <= read_ram_select;
      end
      else if (request_stage1_valid && request_stage1_ready) begin
         request_stage1_valid <= 1'b0;
      end
   end
   assign request_stage1_data = request_stage1_stall_valid ? request_stage1_stall_data : request_stage1_ram_select ? qa2 : qa1;


   always_ff@(posedge clk or negedge resetn) begin
      if (!resetn) begin
         request_stage1_stall_valid <= '0;
         request_stage1_stall_data <= '0;
      end
      else if (request_stage1_valid && !request_stage1_ready) begin
         request_stage1_stall_valid <= 1'b1;
         request_stage1_stall_data <= request_stage1_data;
      end
      else if (request_stage1_valid && request_stage1_ready) begin
         request_stage1_stall_valid <= 1'b0;
      end
   end
   
   logic [L2_NSP_DATA_BITS-1:0] first_data;
   always_ff@(posedge clk or negedge resetn) begin
      if (!resetn) begin
         first_data <= '0;
      end
      else if (request_stage1_valid && !request_stage1_last)begin
         first_data <= request_stage1_ram_select ? qa2 : qa1;
      end
   end

   logic                             readout_tb_valid ;
   logic                             readout_tb_ready ;
   l2_bank_rob_readout_record_type   readout_tb_rec   ;


   assign readout_tb_valid           = request_stage1_valid && request_stage1_last;
   assign request_stage1_ready       = request_stage1_valid && request_stage1_last ? readout_tb_ready : 1'b1;
   assign readout_tb_rec.axid        = request_stage1_rec.axid;
   assign readout_tb_rec.set         = request_stage1_rec.set;
   assign readout_tb_rec.way         = request_stage1_rec.way;
   assign readout_tb_rec.beat        = request_stage1_rec.beat;
   assign readout_tb_rec.sector_mask = request_stage1_rec.sector_mask;
   assign readout_tb_rec.linefill    = request_stage1_rec.linefill;
   assign readout_tb_rec.last        = request_stage1_rec.last;
   assign readout_tb_rec.data        = {request_stage1_data, first_data};


   gpc_gfx_timing_buffer_
   #(
       .BUFFER_TYPE           ( GPC_GFX_TIMING_BUFFER_MSTL            )
      ,.WIDTH                 ( $bits(l2_bank_rob_readout_record_type ) ))
   i_read_rec_timing_buffer   (
      .clk                    ( clk                                   )
    , .resetn                 ( resetn                                )
    , .tbuff_in_valid         ( readout_tb_valid                      )
    , .tbuff_in_enable        ( readout_tb_ready                      )
    , .tbuff_in_data          ( readout_tb_rec                        )
    
    , .tbuff_out_valid        (readout_valid                          )
    , .tbuff_out_enable       (readout_ready                          )
    , .tbuff_out_data         (readout_rec                            ) );


   assign rob_idle = ~request_stage1_valid && ~rob_write_valid && ~readout_valid;
end
else begin: g_single_ram_size
   logic                         write_ready                            ;
   logic                         rob_write_valid                        ;
   logic [1:0]                   rob_write_en                           ;
   logic [L2_ROB_BITS-1:0]       rob_write_addr                         ;
   logic [L2_BEAT_WIDTH-1:0]     rob_write_data             ;

   logic [L2_NUM_SECTOR-1:0]     rob_index_used_mask [L2_ROB_DEPTH-1:0] ;

   logic                         request_stage1_valid                   ;
   logic                         request_stage1_ready                   ;
   logic [L2_BEAT_WIDTH-1:0]     request_stage1_data                    ;
   l2_bank_rob_pipe_record_type  request_stage1_rec                     ;
   logic [L2_BEAT_WIDTH-1:0]     qa                                     ;

   logic                         cena                                   ;
   logic                         request_stage1_stall_valid             ;
   logic [L2_BEAT_WIDTH-1:0]     request_stage1_stall_data              ;

   for (genvar index = 0; index < L2_ROB_DEPTH; index++) begin: g_update_rob_mask
      always_ff@(posedge clk or negedge resetn) begin
         if (!resetn) begin
            rob_index_used_mask[index] <= '0;
         end
         else if (rob_write_valid && index == rob_write_addr) begin
            rob_index_used_mask[index] <= rob_index_used_mask[index] | (~rob_write_en);
         end
         else if (read_valid && read_ready && read_rec.rob_index == index) begin
            rob_index_used_mask[index] <= 2'b00;
         end
      end
      
      always_ff@(posedge clk or negedge resetn) begin
         if (!resetn) 
            index_free_mask[index] <= 1'b0;
         else if (request_stage1_valid && request_stage1_ready && request_stage1_rec.rob_index == index) begin
            index_free_mask [index] <= 1'b1;
         end 
         else begin
            index_free_mask[index] <= 1'b0;
         end
      end
   end


   assign write_ready = 1'b1;
   always_ff@(posedge clk or negedge resetn) begin
      if (!resetn) begin
         rob_write_valid <= 1'b0;
         rob_write_addr  <= '0;
         rob_write_data  <= '0;
         rob_write_en    <= '0;
      end
      else if (write_valid && write_ready) begin
         rob_write_valid <= 1'b1;
         rob_write_data  <= {write_rec.write_data, write_rec.write_data}; //
         rob_write_addr  <= write_rec.rob_index;
         rob_write_en    <= write_rec.write_mask; // active low
      end
      else if (rob_write_valid) begin
         rob_write_valid <= 1'b0;
         rob_write_en <= 2'b11;
      end
   end

   assign cena = ~(read_valid & read_ready);

   gpu_core_mss_gfx_dpstore
   #(
       .w     ( 512              ) ,
       .p     ( 256              ) ,
       .d     ( L2_ROB_DEPTH     ) ,
       .log2d ( L2_ROB_BITS      ) ,
       .id    ( 30008            )
                                 )
   i_rob_dpsram     (
    .CLKA     ( clk                  )
   ,.CENA     ( cena                 )
   ,.AA       ( read_rec.rob_index   )
   ,.QA       ( qa                   )
   ,.CLKB     ( clk                  )
   ,.CENB     ( !rob_write_valid     ) // active low
   ,.WENB     ( rob_write_en         ) // active low
   ,.AB       ( rob_write_addr       )
   ,.DB       ( rob_write_data       )
   ,.TE       ( tst_gclkenable       )
   ,.L2M      (                      )
   ,.SRAM     (                      )
   );


   assign read_ready = (!request_stage1_valid | request_stage1_ready) && (&rob_index_used_mask[read_rec.rob_index]) && read_valid;
   always_ff@(posedge clk or negedge resetn) begin
      if (!resetn) begin
         request_stage1_valid <= '0;
         request_stage1_rec <= '0;
      end
      else if (read_valid & read_ready) begin
         request_stage1_valid <= 1'b1;
         request_stage1_rec <= read_rec;
      end
      else if (request_stage1_valid & request_stage1_ready) begin
         request_stage1_valid <= 1'b0;
      end
   end
   assign request_stage1_data = request_stage1_stall_valid ? request_stage1_stall_data : qa;


   always_ff@(posedge clk or negedge resetn) begin
      if (!resetn) begin
         request_stage1_stall_valid <= '0;
         request_stage1_stall_data <= '0;
      end
      else if (request_stage1_valid && !request_stage1_ready) begin
         request_stage1_stall_valid <= 1'b1;
         request_stage1_stall_data <= request_stage1_data;
      end
      else if (request_stage1_valid && request_stage1_ready) begin
         request_stage1_stall_valid <= 1'b0;
      end
   end


   assign readout_valid           = request_stage1_valid;
   assign request_stage1_ready    = readout_ready;
   assign readout_rec.axid        = request_stage1_rec.axid;
   assign readout_rec.set         = request_stage1_rec.set;
   assign readout_rec.way         = request_stage1_rec.way;
   assign readout_rec.beat        = request_stage1_rec.beat;
   assign readout_rec.sector_mask = request_stage1_rec.sector_mask;
   assign readout_rec.linefill    = request_stage1_rec.linefill;
   assign readout_rec.last        = request_stage1_rec.last;
   assign readout_rec.data        = request_stage1_data;




   assign rob_idle = ~request_stage1_valid && ~rob_write_valid;
end
endgenerate
endmodule
// Local Variables:
// verilog-library-directories:("./" ) 
// End:
