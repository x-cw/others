// ---------------------------------------------------------------------------------
// Project Name  : IC_Design
// Author        : liusm
// Email         : liusm@innosilicon.com.cn
// Create On     : 2025/05/09 10:21
// Last Modified : 2025/05/12 19:31
// File Name     : gc_l2_bank_cfi_maskout.sv
// Description   :
// 
// Copyright (c) 2025 Innosilicon.
// ALL RIGHTS RESERVED
// 
// ---------------------------------------------------------------------------------
// Modification History:
// Date         By              Version                 Change Description
// ---------------------------------------------------------------------------------
// 2025/05/09   liusm           1.0                     Original
// 
// ----------------------------------------------------------------------------------

// It is possible that application call write64(0x1c00, 2) to trigger L2 CFI operation. 
// This function will issue two write operations to regbank, therefore two write notify to L2 bank. The second write is a empty write.
// The two nofity will trigger two CFI operations in short time. It is illegal for L2 bank because the CFI can be issued when previous CFI is finished.
// To improve L2 robust, this module is designed to masked out the additional CFI notify when receive empty write
//
//
// If socif issue empty write or read request, all notify can not be issued to L2 bank
module gc_l2_bank_notify_maskout
import socif_regbank_w_pkg::*;
import gc_cr_global_regpack_::*;
(
      input    logic                                  clk
,     input    logic                                  resetn

,     input    logic                                  socif_valid
,     input    socif_regbank_w_data_bus_t             socif_rec

,     input    logic                                  i_gc_cr_l2_cfi_operation_notify
,     input    logic                                  i_gc_cr_l2_cmd_notify
,     output   logic                                  o_gc_cr_l2_cfi_operation_notify
,     output   logic                                  o_gc_cr_l2_cmd_notify
);



logic notify_en;

always_ff@(posedge clk or negedge resetn) begin
   if(!resetn) begin
      notify_en <= 1'b1; 
   end
   else if (socif_valid && (!socif_rec.rdnwr) && (~&socif_rec.wmask[7:4]) )begin // at least one wmask is low, the notify_en will be low on the next cycle.
       notify_en <= 1'b0;
   end
   else begin
      notify_en <= 1'b1;
   end
end

logic notify_en_r;

always_ff@(posedge clk or negedge resetn) begin
   if(!resetn) begin
      notify_en_r <= 1'b0; 
   end
   else begin
       notify_en_r <= notify_en;
   end
end

assign o_gc_cr_l2_cfi_operation_notify = i_gc_cr_l2_cfi_operation_notify & notify_en_r;
assign o_gc_cr_l2_cmd_notify = i_gc_cr_l2_cmd_notify & notify_en_r;


endmodule
// Local Variables:
// verilog-library-directories:("./" ) 
// End:
