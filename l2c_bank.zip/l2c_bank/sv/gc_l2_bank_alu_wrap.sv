/*


*/

// ----------------------------------------------------------------------------------------------
// entity name: gc_l2_bank_alu_wrap
// purpose: L2 atomic ALU
// ----------------------------------------------------------------------------------------------

module gc_l2_bank_alu_wrap
import gc_l2_bank_pkg::*;
(
    input   logic                               clk,
    input   logic                               resetn,
    input   logic                               enable,
    input   logic [  1 :0]                      aa_len,                 // atomic len: 0-32, 1-64, 2-128
    input   logic [L2_AA_OP_WIDTH-1         :0] aa_operation,
    input   logic [(L2_BEAT_WIDTH/32)-1     :0] dword_active,
    input   logic [L2_BEAT_WIDTH-1          :0] source_data,
    input   logic [L2_BEAT_WIDTH-1          :0] operand_a,
    output  logic [L2_BEAT_WIDTH-1          :0] aa_result,
    output  logic [L2_BEAT_WIDTH-1          :0] aa_result_fp32,
    output  logic [(L2_BEAT_WIDTH/8)-1      :0] aa_result_strb,         // active high
    input   logic                               flush_en
);


// ----------------------------------------------------------------------------------------------
// interanl signal define
// ----------------------------------------------------------------------------------------------
logic                                   aa_32bit;
logic                                   aa_64bit;
// logic                                   aa_128bit;
logic                                   aa_32_64;
logic                                   aa_fp;
logic [L2_BEAT_WIDTH-1       : 0]       operand_b;
logic [L2_BEAT_WIDTH-1       : 0]       aa_int_result;
logic [L2_BEAT_WIDTH-1       : 0]       aa_cas128_result;
logic [(L2_BEAT_WIDTH/32)-1  : 0]       aa_int_rlt_upd;
logic [(L2_BEAT_WIDTH/32)-1  : 0]       aa_cas128_rlt_upd;

logic                                   aa_32_64_r;
logic                                   aa_fp_r;
logic [(L2_BEAT_WIDTH/32)-1  : 0]       dword_active_r;
logic [L2_BEAT_WIDTH-1       : 0]       aa_fp32_result_r;
logic [(L2_BEAT_WIDTH/32)-1  : 0]       aa_fp32_rlt_upd_r;
logic [L2_BEAT_WIDTH-1       : 0]       aa_int_result_r;
logic [(L2_BEAT_WIDTH/32)-1  : 0]       aa_int_rlt_upd_r;
logic [L2_BEAT_WIDTH-1       : 0]       aa_cas128_result_r;
logic [(L2_BEAT_WIDTH/32)-1  : 0]       aa_cas128_rlt_upd_r;
logic [(L2_BEAT_WIDTH/32)-1  : 0]       aa_rlt_upd_r;
// ----------------------------------------------------------------------------------------------
// atomic length operation decode
// ----------------------------------------------------------------------------------------------
assign aa_32bit     = (aa_len == L2_AA_SIZE_32 ) ? 1'b1 : 1'b0;
assign aa_64bit     = (aa_len == L2_AA_SIZE_64 ) ? 1'b1 : 1'b0;
// assign aa_128bit    = (aa_len == L2_AA_SIZE_128) ? 1'b1 : 1'b0;

assign aa_fp        = aa_operation[4];
assign aa_32_64     = (aa_32bit | aa_64bit) & (~aa_fp);

// ----------------------------------------------------------------------------------------------
// generate operand_b
// ----------------------------------------------------------------------------------------------
// operand_a is compare data, operand_b is swap data for compare and swap (L2_AA_OP_CMPXCHG)
always_comb begin: gen_operand_b
    if(aa_32bit) begin
        for(int i=0; i<L2_BEAT_WIDTH/32/2; i++) begin        // shift within 8Byte boundary
            operand_b[i*64 +: 64] = {operand_a[i*64 +: 32], operand_a[i*64+32 +: 32]};
        end
    end
    else if(aa_64bit) begin
        for(int i=0; i<L2_BEAT_WIDTH/32/4; i++) begin        // shift within 16Byte boundary
            operand_b[i*128 +: 128] = {operand_a[i*128 +: 64], operand_a[i*128+64 +: 64]};
        end
    end
    else begin  // aa_128bit
        for(int i=0; i<L2_BEAT_WIDTH/32/8; i++) begin        // shift within 32Byte boundary
            operand_b[i*256 +: 256] = {operand_a[i*256 +: 128], operand_a[i*256+128 +: 128]};
        end
    end
end: gen_operand_b

// ----------------------------------------------------------------------------------------------
// atomic32 and atomic64 ALU instence
// ----------------------------------------------------------------------------------------------
generate
    for(genvar i=0; i<L2_BEAT_WIDTH/64; i++) begin: g_l2_bank_int_alu
        gc_l2_bank_int_alu i_gc_l2_bank_int_alu(
            .aa_64bit           (aa_64bit                           ),  // I
            .aa_operation       (aa_operation                       ),  // I
            .aa_source          (source_data    [i*64 +: 64]        ),  // I
            .aa_operand_a       (operand_a      [i*64 +: 64]        ),  // I
            .aa_operand_b       (operand_b      [i*64 +: 64]        ),  // I
            .aa_rlt_upd         (aa_int_rlt_upd [i*2  +: 2 ]        ),  // O
            .aa_destination     (aa_int_result  [i*64 +: 64]        )   // O
        );
    end
endgenerate

// ----------------------------------------------------------------------------------------------
// atomic FP32 ALU instence
// ----------------------------------------------------------------------------------------------
generate
    for(genvar i=0; i<L2_BEAT_WIDTH/32; i++) begin: g_l2_bank_fp32_alu
        gc_l2_bank_fp32_alu i_gc_l2_bank_fp32_alu(
            .clk                (clk                                ),  // I
            .resetn             (resetn                             ),  // I
            .enable             (enable                             ),  // I
            .flush_en           (flush_en                           ),  // I
            .aa_operation       (aa_operation                       ),  // I
            .operand_a          (source_data        [i*32 +: 32]    ),  // I
            .operand_b          (operand_a          [i*32 +: 32]    ),  // I, source_data +/- operand_a
            .swap_data          (operand_b          [i*32 +: 32]    ),  // I, for FP32 atomic compare
            .fp32_result        (aa_fp32_result_r   [i*32 +: 32]    ),  // O
            .fp32_rlt_upd       (aa_fp32_rlt_upd_r  [i]             )   // O
        );
    end
endgenerate

// ----------------------------------------------------------------------------------------------
// others atomic operation
// ----------------------------------------------------------------------------------------------
always_comb begin: g_l2_aa_swap_128
    for(int i=0; i<L2_BEAT_WIDTH/128; i++) begin
        if(dword_active[i*4] && (source_data[i*128 +: 128] == operand_a[i*128 +: 128])) begin
            aa_cas128_result[i*128 +: 128] = operand_b[i*128 +: 128];
            aa_cas128_rlt_upd[i*4  +:   4] = {4{1'b1}};
        end
        else begin
            aa_cas128_result[i*128 +: 128] = 'b0;
            aa_cas128_rlt_upd[i*4  +:   4] = 'b0;
        end
    end
end: g_l2_aa_swap_128


// ----------------------------------------------------------------------------------------------
// output data
// ----------------------------------------------------------------------------------------------
// int/cas128 result pipe
always_ff @(posedge clk or negedge resetn) begin
    if(!resetn) begin
        aa_32_64_r          <= 'b0;
        aa_fp_r             <= 'b0;
        dword_active_r      <= 'b0;
        aa_int_result_r     <= 'b0;
        aa_int_rlt_upd_r    <= 'b0;
        aa_cas128_result_r  <= 'b0;
        aa_cas128_rlt_upd_r <= 'b0;
    end
    else if(enable) begin
        aa_32_64_r          <= aa_32_64         ;
        aa_fp_r             <= aa_fp            ;
        dword_active_r      <= dword_active     ;
        aa_int_result_r     <= aa_int_result    ;
        aa_int_rlt_upd_r    <= aa_int_rlt_upd   ;
        aa_cas128_result_r  <= aa_cas128_result ;
        aa_cas128_rlt_upd_r <= aa_cas128_rlt_upd;
    end
end


assign aa_result        =  aa_32_64_r ? aa_int_result_r  : aa_cas128_result_r;
assign aa_result_fp32   =  aa_fp_r    ? aa_fp32_result_r : 'b0;

// 1bit dword_active --> 4bit strb
assign aa_rlt_upd_r = aa_32_64_r  ? aa_int_rlt_upd_r  :
                      aa_fp_r     ? aa_fp32_rlt_upd_r : aa_cas128_rlt_upd_r;

always_comb begin: g_aa_result_strb
    for(int i=0; i<L2_BEAT_WIDTH/32; i++) begin
        if(aa_rlt_upd_r[i]) begin
            aa_result_strb[i*4 +: 4] = {4{dword_active_r[i]}};
        end
        else begin
            aa_result_strb[i*4 +: 4] = {4{1'b0}};
        end
    end
end: g_aa_result_strb

endmodule
