/*

 * #==========================================================================#
 * |                                                                          |
 * |  Copyright (c) 2022, Fantasy Technologies Limited and/or its         |
 * |  affiliated group companies ("Fantasy"). All rights reserved.        |
 * |  No part of this content, either material or conceptual may be copied    |
 * |  or distributed, transmitted, transcribed, stored in a retrieval system  |
 * |  or translated into any human or computer language in any form by any    |
 * |  means, electronic, mechanical manual, or otherwise, or disclosed to     |
 * |  third parties without the express written permission of Fantasy.    |
 * |                                                                          |
 * #==========================================================================#

 */

// ////////////////////////////////////////////////////////////////////////////-
// entity:  gpc_gfx_spstore_wrap
//
// purpose: Conditially instantiates an gpc_gfx_spstore_bist (RAM) or
// gpc_gfx_rg_spstore (flops), based on threshold set my memory partitioner
//
// ////////////////////////////////////////////////////////////////////////////-

module gpc_gfx_spstore_wrap_
   import gpc_gfx_rambist_pack_::*;
#(
      parameter   w                                                            = 32             , // integer
      parameter   p                                                            = 32             , // integer
      parameter   d                                                            = 8              , // integer
      parameter   log2d                                                        = 3              , // integer
      parameter   ECC                                                          = 0              , // integer



      parameter   id                                                           = 0               // integer
)
(
      input    logic                                                      clk,
      input    logic                                                      resetn,
      input    logic                                                      c_en,
      input    logic [ ( w / p ) - 1 : 0 ]                                wr_en,
      input    logic [ log2d - 1 : 0 ]                                    addr,
      input    logic [ w - 1 : 0 ]                                        wr_data,
      output   logic [ w - 1 : 0 ]                                        rd_data_ram,






      input    logic [ spstore_in ( w , p , d , ECC ) - 1 : 0 ]           bist_in,
      output   logic [ spstore_out ( w , p , d , ECC ) - 1 : 0 ]          bist_out,
      input    logic                                                      tst_gclkenable
);





   //synopsys translate_off
   import gpc_gfx_backdoor_pkg_::*;
   //synopsys translate_on

   ///////////////////////////////////////////////
   // backdoor access
   ///////////////////////////////////////////////
   //synopsys translate_off
   `ifndef SRAM_MODEL_SIM
   backdoor_access_fwd #(.w(w)) backdoor = new();
   `endif
   //synopsys translate_on
   ///////////////////////////////////////////////
   // END backdoor access
   ///////////////////////////////////////////////


   //instance a RAM macro?
   if (ram_partitioner_threshold ( w , d , id )) begin : g_ram
   
      //synopsys translate_off
      `ifndef SRAM_MODEL_SIM
      //point our backdoor access class to the spstore submodule
      initial backdoor.inst = i_gpc_gfx_spstore_bist.backdoor;
      `endif
      //synopsys translate_on
      
      gpc_gfx_spstore_bist_
            #(
            .w(w),
            .p(p),
            .d(d),
            .log2d(log2d),
            .ECC(ECC),



            .id(id)
            )
         i_gpc_gfx_spstore_bist
         (
            .clk(clk),
            .resetn(resetn),
            .c_en(c_en),
            .wr_en(wr_en),
            .addr(addr),
            .wr_data(wr_data),
            .rd_data_ram(rd_data_ram),













            .bist_in(bist_in),
            .bist_out(bist_out),
            .tst_gclkenable(tst_gclkenable)
         );
   end
   else begin : g_flops

      //synopsys translate_off
      `ifndef SRAM_MODEL_SIM
      //point our backdoor access class to the rgstore submodule
      initial backdoor.inst = i_gpc_gfx_sp_rgstore_.backdoor;
      `endif
      //synopsys translate_on

      gpc_gfx_sp_rgstore_
            #(
            .w(w),
            .p(p),
            .d(d),
            .log2d(log2d)
            )
            i_gpc_gfx_sp_rgstore_
            (
            .CLK(clk),
            .CEN(c_en),
            .WEN(wr_en),
            .A(addr),
            .DI(wr_data),
            .Q(rd_data_ram)
            );







      assign bist_out = ( '0 ) ;
   end

endmodule

