// +FHDR----------------------------------------------------------------------------
// Copyright (c) 2025, Innosilicon, Inc. Confidential Proprietary
// PROJECT NAME  : xxx
// DEPARTMENT    : Digtal Frontend GPU MSS
// AUTHOR        : luoml01
// EMAIL         : luoml01@innosilicon.com.cn
// CREATE ON     : 2025/03/11 20:57
// FILE NAME     : gc_mss_perf_latency_count.sv
// DESCRIPTION   :          
//         
// Copyright (c) 2025 Innosilicon.
// ALL RIGHTS RESERVED
// 
// ---------------------------------------------------------------------------------
// Modification History:
// Date         By              Version                 Change Description
// ---------------------------------------------------------------------------------
// 2025/03/11   luoml01         1.0                     Original
// 
// -FHDR----------------------------------------------------------------------------


module gc_mss_sim_latency_count_calculator
#(
   parameter ID_WIDTH = 8,
   parameter LATENCY_WIDTH = 10

)
(
input logic clk,
input logic resetn,


input logic count_update,
input logic [11:0]latency_counter,

output logic [LATENCY_WIDTH+2-1:0] avg_latency,
output logic [LATENCY_WIDTH-1:0]   min_latency,
output logic [LATENCY_WIDTH+2-1:0] max_latency
);

   logic [LATENCY_WIDTH-1:0] latency_10bit_value;

   logic [LATENCY_WIDTH+3-1:0] sum_latency;

   logic [63:0]  latency_sum;
   logic [32:0]  counter_sum;



   always_ff@(posedge clk or negedge resetn) begin : p_latency_counter_clkdrs
      if(!resetn)begin
         counter_sum <= '0;
         latency_sum <= '0;
      end
      else if(count_update)begin
         counter_sum <= counter_sum + 1;
         latency_sum <= latency_sum + latency_counter;
      end
   end : p_latency_counter_clkdrs


   always_ff@(posedge clk or negedge resetn) begin : p_rolling_average_registers_clkdrs
      if(resetn==1'b0) begin
         avg_latency <= '0;
         min_latency <= '1;
         max_latency <= '0;
      end
      else begin
         if(count_update==1'b1) begin
            if(latency_counter<min_latency) begin // Min latency should not exceed a 10-bit value
               min_latency <= latency_counter;
            end
            if(latency_counter>max_latency) begin
               max_latency <= latency_counter;
            end
         end
         if(counter_sum != '0)begin
            avg_latency <= latency_sum/counter_sum;
         end
      end
   end : p_rolling_average_registers_clkdrs


   
endmodule
// Local Variables:
// verilog-library-flags:("-y ./ -y ../")
// verilog-auto-inst-param-value:t
// End:
