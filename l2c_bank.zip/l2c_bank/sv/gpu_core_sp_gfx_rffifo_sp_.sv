/*

 * #==========================================================================#
 * |                                                                          |
 * |  Copyright (c) 2023, Fantasy Technologies Limited and/or its         |
 * |  affiliated group companies ("Fantasy"). All rights reserved.        |
 * |  No part of this content, either material or conceptual may be copied    |
 * |  or distributed, transmitted, transcribed, stored in a retrieval system  |
 * |  or translated into any human or computer language in any form by any    |
 * |  means, electronic, mechanical manual, or otherwise, or disclosed to     |
 * |  third parties without the express written permission of Fantasy.    |
 * |                                                                          |
 * #==========================================================================#

 */

// ////////////////////////////////////////////////////////////////////////-
// entity: rffifo_sp
// purpose: single port register file based fifo with 0 threshold flags
// ////////////////////////////////////////////////////////////////////////-

module gpu_core_sp_gfx_rffifo_sp_
   import gpc_gfx_rambist_pack_::*;
#(
      parameter int                                      ECC                                                          = 0              ,    // ECC enable : 0=disable ECC; 1=enable ECC
      parameter int                                      id                                                           = 0              ,
      parameter int                                      use_gray_code                                                = 0              ,    // Gray encoding of read/write addresses for power optimization. 0 = Disabled (Default), 1 = Enabled
      parameter int                                      use_flush                                                    = 0              ,    // set to 1 to use flush signal
      parameter int                                      w                                                            = 140            ,
      parameter int                                      d                                                            = 32             ,
      parameter int                                      log2d                                                        = 5                
)
(
      input    logic                                                        clk                                     ,
      input    logic                                                        resetn                                  ,
      input    logic                                                        flush                                   ,
      // Valid/Enable interfaces
      input    logic                                                        fifo_in_valid                           ,
      output   logic                                                        fifo_in_enable                          ,
      input    logic [ w - 1 : 0 ]                                          fifo_in_data                            ,
      output   logic                                                        fifo_out_valid                          ,
      input    logic                                                        fifo_out_enable                         ,
      output   logic [ w - 1 : 0 ]                                          fifo_out_data                           ,
      // FIFO status
      output   logic                                                        idle                                    ,
      // BIST & Scan
      input    logic [ spstore_in ( w , w , d , ECC ) - 1 : 0 ]             bist_in                                 ,
      output   logic [ spstore_out ( w , w , d , ECC ) - 1 : 0 ]            bist_out                                ,
      input    logic                                                        tst_gclkenable                           
);

   import gpc_gfx_std_func_pack_::*;
   import gpc_gfx_timing_buffer_pack_::*;

   localparam logic [ 1 : 0 ]                    MAX_OUTSTANDING_READS = 2'b10 ;
   localparam logic [ log2d - 1 : 0 ]            MAXPTR                = d - 1 ;

   logic                                         fifo_notempty                           ;
   logic                                         fifo_in_enable_l                        ;
   logic                                         fifo_out_valid_l                        ;
   logic                                         fifo_out_enable_l                       ;

   logic [ log2d - 1 : 0 ]                       rd_addr                                 ;
   logic [ log2d - 1 : 0 ]                       wr_addr                                 ;
   logic [ log2d - 1 : 0 ]                       n_rd_addr                               ;
   logic [ log2d - 1 : 0 ]                       n_wr_addr                               ;
   logic                                         request_read                            ;

   // Register File Pins
   logic                                         strobe_n                                ;
   logic [ 0 : 0 ]                               wr_strobe_n                             ;
   logic                                         rd_strobe_n                             ;
   logic [ log2d - 1 : 0 ]                       ram_addr                                ;
   logic [ log2d - 1 : 0 ]                       ram_addr_encoded                        ;
   logic [ 1 : 0 ]                               outstanding_reads_r                     ;
   logic                                         rd_strobe_r                             ;
   logic                                         tbuff_in_valid0                         ;
   logic                                         tbuff_in_enable0                        ;
   logic [ w - 1 : 0 ]                           tbuff_in_data0                          ;

   logic                                         tbuff_in_valid1                         ;
   logic                                         tbuff_in_enable1                        ;
   logic [ w - 1 : 0 ]                           tbuff_in_data1                          ;
   logic                                         tbuff_out_valid0                        ;
   logic                                         tbuff_out_enable0                       ;

   // sanity check log2d (address range) against the actual depth of the fifo
   //

   //
   // Generate minimalist chip enables (lowest power)
   //
   // Writes take priority over Reads
   assign wr_strobe_n [ 0 ] = ( fifo_in_valid == 1'b1 & fifo_in_enable_l == 1'b1 ) ? 1'b0 : 1'b1  ;    // COV:tag3
   assign rd_strobe_n = request_read == 1'b1 & wr_strobe_n [ 0 ] == 1'b1 ? 1'b0 : 1'b1  ;

   assign strobe_n = wr_strobe_n [ 0 ] & rd_strobe_n ;
   assign ram_addr = wr_strobe_n [ 0 ] == 1'b0 ? wr_addr : rd_addr  ;

   gpu_core_sp_gfx_spstore_gen_bist_r
      #(
         .w                               (w)                                          ,
         .p                               (w)                                          ,
         .d                               (d)                                          ,
         .log2d                           (log2d)                                      ,
         .ECC                             (ECC)                                        ,
         .id                              (id)                                          
         )
      mem
      (
         .clk                             (clk)                                        ,
         .resetn                          (resetn)                                     ,
         .c_en                            (strobe_n)                                   ,
         .wr_en                           (wr_strobe_n)                                ,
         .addr                            (ram_addr_encoded)                           ,
         .wr_data                         (fifo_in_data)                               ,
         .rd_data                         (tbuff_in_data0)                             ,
         .bist_in                         (bist_in)                                    ,
         .bist_out                        (bist_out)                                   ,
         .tst_gclkenable                  (tst_gclkenable)                               
         );

   //
   // FIFO Control
   //
   always_ff @(posedge clk or negedge resetn) begin
      if ( resetn == 1'b0 ) begin
         wr_addr <= '0 ;
         rd_addr <= '0 ;

         fifo_in_enable_l <= 1'b1 ;
         fifo_notempty <= 1'b0 ;

         rd_strobe_r <= 1'b1 ;
//         mstl_valid_in <= '0';
         tbuff_in_valid0 <= 1'b0 ;
         outstanding_reads_r <= '0 ;
      end else begin
         //
         // Increment pointers
         //
         if ( wr_strobe_n [ 0 ] == 1'b0 ) begin
            wr_addr <= n_wr_addr ;
         end
         if ( rd_strobe_n == 1'b0 ) begin
            rd_addr <= n_rd_addr ;
         end

         //
         // Create upstream enable
         //
         if ( fifo_in_enable_l == 1'b0 ) begin
            // COV:tag4
            if ( rd_strobe_n == 1'b0 ) begin
               fifo_in_enable_l <= 1'b1 ;    // one slot freed up -- COV:tag4
            end
         end else if ( n_wr_addr == rd_addr & fifo_in_valid == 1'b1 ) begin    // COV:tag5
            // we take in a write which will set the write pointer equal to the read pointer // COV:tag4
            fifo_in_enable_l <= 1'b0 ;
         end
         //
         // Create downstream notempty used to gate reads
         //
         if ( wr_strobe_n [ 0 ] == 1'b0 ) begin
            fifo_notempty <= 1'b1 ;
         end else if ( n_rd_addr == wr_addr & rd_strobe_n == 1'b0 ) begin
            fifo_notempty <= 1'b0 ;
         end

         // Read pipeline
         rd_strobe_r <= rd_strobe_n ;
         if ( rd_strobe_r == 1'b0 ) begin
            tbuff_in_valid0 <= 1'b1 ;
         end else if ( tbuff_in_enable0 == 1'b1 ) begin
            tbuff_in_valid0 <= 1'b0 ;
         end
         if ( ( rd_strobe_n == 1'b0 & ( fifo_out_valid_l == 1'b0 | fifo_out_enable_l == 1'b0 ) ) ) begin
            // Reading the FIFO
            // not outputting this cycle
            outstanding_reads_r <= outstanding_reads_r + 1'b1 ;
         end
         if ( ( fifo_out_valid_l == 1'b1 & fifo_out_enable_l == 1'b1 & rd_strobe_n == 1'b1 ) ) begin
            // FIFO is outputting this cycle and not reading
            if ( ( outstanding_reads_r != 2'b00 ) ) begin
               // Check it can't go negative
               outstanding_reads_r <= outstanding_reads_r - 1'b1 ;
            end
         end

         // flush logic only synthesised when used
         if ( ( use_flush == 1 ) ) begin
            if ( ( flush == 1'b1 ) ) begin    // COV:tag2
               wr_addr <= '0 ;    // COV:tag2
               rd_addr <= '0 ;    // COV:tag2

               fifo_in_enable_l <= 1'b1 ;    // COV:tag2
               fifo_notempty <= 1'b0 ;    // COV:tag2

               rd_strobe_r <= 1'b1 ;    // COV:tag2
               tbuff_in_valid0 <= 1'b0 ;    // COV:tag2
               outstanding_reads_r <= '0  ; // COV:tag2
            end
         end
      end
   end

   assign n_wr_addr = wr_addr == MAXPTR ? '0 : wr_addr + 1'b1  ; 

   assign n_rd_addr = rd_addr == MAXPTR ? '0 : rd_addr + 1'b1  ; 

   // Create a signal to request reads when the MSTLs have room

   assign request_read = ( fifo_notempty == 1'b1 & ( fifo_out_enable == 1'b1 | outstanding_reads_r < MAX_OUTSTANDING_READS ) ) ? 1'b1 : 1'b0  ;

   if ( use_gray_code == 0 ) begin : g_no_use_gray_code

      assign ram_addr_encoded = ram_addr ;

   end // g_no_use_gray_code

   if ( use_gray_code == 1 ) begin : g_use_gray_code

      gpc_gfx_gray_encode                # (.D(d))
      i_addr_gpc_gfx_gray_encode           (.addr_in(ram_addr),
                                             .result(ram_addr_encoded)  
                                             );

   end // g_use_gray_code

    gpc_gfx_timing_buffer_
      #(
         .BUFFER_TYPE                     (GPC_GFX_TIMING_BUFFER_MSTL)                 ,
         .WIDTH                           (w)                                           
         )
      i_output_tbuff0
      (
         .clk                             (clk)                                        ,
         .resetn                          (resetn)                                     ,
         // Input V/E Interface
         .tbuff_in_valid                  (tbuff_in_valid0)                            ,
         .tbuff_in_enable                 (tbuff_in_enable0)                           ,
         .tbuff_in_data                   (tbuff_in_data0)                             ,
         // Output V/E Interface
         .tbuff_out_valid                 (tbuff_out_valid0)                           ,
         .tbuff_out_enable                (tbuff_out_enable0)                          ,
         .tbuff_out_data                  (tbuff_in_data1)                              
         );

   gpc_gfx_timing_buffer_
      #(
         .BUFFER_TYPE                     (GPC_GFX_TIMING_BUFFER_MSTL)                 ,
         .WIDTH                           (w)                                           
         )
      i_output_tbuff1
      (
         .clk                             (clk)                                        ,
         .resetn                          (resetn)                                     ,
         // Input V/E Interface
         .tbuff_in_valid                  (tbuff_in_valid1)                            ,
         .tbuff_in_enable                 (tbuff_in_enable1)                           ,
         .tbuff_in_data                   (tbuff_in_data1)                             ,
         // Output V/E Interface
         .tbuff_out_valid                 (fifo_out_valid_l)                           ,
         .tbuff_out_enable                (fifo_out_enable_l)                          ,
         .tbuff_out_data                  (fifo_out_data)                               
         );

   // Connect external interfaces
   assign fifo_in_enable = fifo_in_enable_l ;
   assign fifo_out_valid = fifo_out_valid_l ;

   if ( use_flush == 0 ) begin : g_no_flush

      assign fifo_out_enable_l = fifo_out_enable ;    // COV:tag0
      assign tbuff_in_valid1 = tbuff_out_valid0 ;    // COV:tag0
      assign tbuff_out_enable0 = tbuff_in_enable1 ;    // COV:tag0

   end // g_no_flush

   if ( use_flush == 1 ) begin : g_use_flush

      assign fifo_out_enable_l = fifo_out_enable | flush ;    // COV:tag1
      assign tbuff_in_valid1 = flush == 1'b0 ? tbuff_out_valid0 : 1'b0  ;    // COV:tag1
      assign tbuff_out_enable0 = tbuff_in_enable1 | flush ;    // COV:tag1

   end // g_use_flush
   assign idle = ~ fifo_notempty & rd_strobe_r & ~ fifo_out_valid_l ;

endmodule // gpu_core_sp_gfx_rffifo_sp
