//-----------------------------------------------------------------------------------------------------------------
//
//                file : gc_cr_global_regfields_.sv
//
//           copyright : 2001-2020 by Imagination Technologies Limited. All rights
//                       reserved. No part of this hardware description, either
//                       material or conceptual may be copied or distributed,
//                       transmitted, transcribed, stored in a retrieval system
//                       or translated into any human or computer language in
//                       any form by any means, electronic, mechanical, manual
//                       or otherwise, or disclosed to third parties without
//                       the express written permission of Imagination
//                       Technologies Limited, Home Park Estate, Kings Langley,
//                       Hertfordshire, WD4 8LZ, U.K.
//
//     generated from : (null)
//                 by : regconv.c REL/1@6006852 
//-----------------------------------------------------------------------------------------------------------------



package gc_cr_global_regfields_;


 // gc_cr_mmu_indirect
localparam logic [ 2 : 0 ] GC_CR_MMU_INDIRECT_ADDRESS_BITFIELD                 = 3'h0;

 // gc_cr_ttt_indirect
localparam logic [ 3 : 0 ] GC_CR_TTT_INDIRECT_ADDRESS_BITFIELD                 = 4'h0;

 // gc_cr_l2g_indirect
localparam logic [ 2 : 0 ] GC_CR_L2G_INDIRECT_ADDRESS_BITFIELD                 = 3'h0;

 // gc_cr_eu_indirect
localparam logic [ 7 : 0 ] GC_CR_EU_INDIRECT_ADDRESS_BITFIELD                  = 8'h0;

 // gc_cr_cu_indirect
localparam logic [ 6 : 0 ] GC_CR_CU_INDIRECT_ADDRESS_BITFIELD                  = 7'h0;

 // gc_cr_spc_indirect
localparam logic [ 3 : 0 ] GC_CR_SPC_INDIRECT_ADDRESS_BITFIELD                 = 4'h0;

 // gc_cr_gpc_indirect
localparam logic [ 1 : 0 ] GC_CR_GPC_INDIRECT_ADDRESS_BITFIELD                 = 2'h0;

 // gc_cr_product_id
localparam logic [ 31 : 16 ] GC_CR_PRODUCT_ID_GPC_PRODUCT_ID_BITFIELD          = 16'h0;

 // gc_cr_core_id
localparam logic [ 15 : 0 ] GC_CR_CORE_ID_CONFIG_ID_BITFIELD                   = 16'h0;
localparam logic [ 31 : 16 ] GC_CR_CORE_ID_NUMBER_OF_SCALABLE_UNITS_BITFIELD   = 16'h0;
localparam logic [ 47 : 32 ] GC_CR_CORE_ID_VERSION_ID_BITFIELD                 = 16'h0;
localparam logic [ 63 : 48 ] GC_CR_CORE_ID_BRANCH_ID_BITFIELD                  = 16'h0;

 // gc_cr_core_ip_integrator_id
localparam logic [ 31 : 0 ] GC_CR_CORE_IP_INTEGRATOR_ID_RELEASE_ID_BITFIELD    = 32'h0;
localparam logic [ 47 : 32 ] GC_CR_CORE_IP_INTEGRATOR_ID_PRODUCT_ID_BITFIELD   = 16'h0;
localparam logic [ 63 : 48 ] GC_CR_CORE_IP_INTEGRATOR_ID_SERIES_ID_BITFIELD    = 16'h0;

 // gc_cr_core_ip_changelist
localparam logic [ 31 : 0 ] GC_CR_CORE_IP_CHANGELIST_VALUE_BITFIELD            = 32'h0;

 // gc_cr_power_event
localparam logic [ 0 : 0 ] GC_CR_POWER_EVENT_TYPE_BITFIELD                     = 1'h0;
localparam logic [ 0 : 0 ] GC_CR_POWER_EVENT_TYPE_POWER_DOWN                   = 1'h0;
localparam logic [ 0 : 0 ] GC_CR_POWER_EVENT_TYPE_POWER_UP                     = 1'h1;
localparam logic [ 1 : 1 ] GC_CR_POWER_EVENT_REQ_BITFIELD                      = 1'h0;
localparam logic [ 63 : 32 ] GC_CR_POWER_EVENT_DOMAIN_CLUSTER_BITFIELD         = 32'h0;

 // gc_cr_cluster_efuse
localparam logic [ 63 : 0 ] GC_CR_CLUSTER_EFUSE_VALUE_BITFIELD                 = 64'hffffffffffffffff;

 // gc_cr_soc_timer_gray
localparam logic [ 63 : 0 ] GC_CR_SOC_TIMER_GRAY_VALUE_BITFIELD                = 64'h0;

 // gc_cr_soc_timer_binary
localparam logic [ 63 : 0 ] GC_CR_SOC_TIMER_BINARY_VALUE_BITFIELD              = 64'h0;

 // gc_cr_timer
localparam logic [ 47 : 0 ] GC_CR_TIMER_VALUE_BITFIELD                         = 48'h0;
localparam logic [ 63 : 63 ] GC_CR_TIMER_BIT31_BITFIELD                        = 1'h0;

 // gc_cr_axi_exaccess
localparam logic [ 0 : 0 ] GC_CR_AXI_EXACCESS_SOCIF_ENABLE_BITFIELD            = 1'h0;

 // gc_cr_fw_state
localparam logic [ 0 : 0 ] GC_CR_FW_STATE_ACTIVE_BITFIELD                      = 1'h1;
localparam logic [ 3 : 1 ] GC_CR_FW_STATE_RESERVED_BITFIELD                    = 3'h0;

 // gc_cr_gpu_state_config
localparam logic [ 16 : 0 ] GC_CR_GPU_STATE_CONFIG_HYSTERESIS_THRESHOLD_VALUE_BITFIELD  = 17'h7ff;
localparam logic [ 17 : 17 ] GC_CR_GPU_STATE_CONFIG_DISABLE_MTS_STATE_BITFIELD  = 1'h0;

 // gc_cr_regbank_request_invalid
localparam logic [ 0 : 0 ] GC_CR_REGBANK_REQUEST_INVALID_MISSING_REGISTER_BITFIELD  = 1'h0;
localparam logic [ 1 : 1 ] GC_CR_REGBANK_REQUEST_INVALID_OUT_OF_RANGE_BITFIELD  = 1'h0;

 // gc_cr_socif_wakeup_enable
localparam logic [ 0 : 0 ] GC_CR_SOCIF_WAKEUP_ENABLE_ALWAYS_BITFIELD           = 1'h0;

 // gc_cr_scratch0
localparam logic [ 63 : 0 ] GC_CR_SCRATCH0_DATA_BITFIELD                       = 64'h0;

 // gc_cr_scratch1
localparam logic [ 63 : 0 ] GC_CR_SCRATCH1_DATA_BITFIELD                       = 64'h0;

 // gc_cr_scratch2
localparam logic [ 63 : 0 ] GC_CR_SCRATCH2_DATA_BITFIELD                       = 64'h0;

 // gc_cr_scratch3
localparam logic [ 63 : 0 ] GC_CR_SCRATCH3_DATA_BITFIELD                       = 64'h0;

 // gc_cr_scratch4
localparam logic [ 63 : 0 ] GC_CR_SCRATCH4_DATA_BITFIELD                       = 64'h0;

 // gc_cr_scratch5
localparam logic [ 63 : 0 ] GC_CR_SCRATCH5_DATA_BITFIELD                       = 64'h0;

 // gc_cr_scratch6
localparam logic [ 63 : 0 ] GC_CR_SCRATCH6_DATA_BITFIELD                       = 64'h0;

 // gc_cr_scratch7
localparam logic [ 63 : 0 ] GC_CR_SCRATCH7_DATA_BITFIELD                       = 64'h0;

 // gc_cr_scratch8
localparam logic [ 63 : 0 ] GC_CR_SCRATCH8_DATA_BITFIELD                       = 64'h0;

 // gc_cr_scratch9
localparam logic [ 63 : 0 ] GC_CR_SCRATCH9_DATA_BITFIELD                       = 64'h0;

 // gc_cr_scratch10
localparam logic [ 63 : 0 ] GC_CR_SCRATCH10_DATA_BITFIELD                      = 64'h0;

 // gc_cr_scratch11
localparam logic [ 63 : 0 ] GC_CR_SCRATCH11_DATA_BITFIELD                      = 64'h0;

 // gc_cr_scratch12
localparam logic [ 63 : 0 ] GC_CR_SCRATCH12_DATA_BITFIELD                      = 64'h0;

 // gc_cr_scratch13
localparam logic [ 63 : 0 ] GC_CR_SCRATCH13_DATA_BITFIELD                      = 64'h0;

 // gc_cr_scratch14
localparam logic [ 63 : 0 ] GC_CR_SCRATCH14_DATA_BITFIELD                      = 64'h0;

 // gc_cr_scratch15
localparam logic [ 63 : 0 ] GC_CR_SCRATCH15_DATA_BITFIELD                      = 64'h0;

 // gc_cr_os0_scratch0
localparam logic [ 31 : 0 ] GC_CR_OS0_SCRATCH0_DATA_BITFIELD                   = 32'h0;

 // gc_cr_os0_scratch1
localparam logic [ 31 : 0 ] GC_CR_OS0_SCRATCH1_DATA_BITFIELD                   = 32'h0;

 // gc_cr_os0_scratch2
localparam logic [ 31 : 0 ] GC_CR_OS0_SCRATCH2_DATA_BITFIELD                   = 32'h0;

 // gc_cr_os0_scratch3
localparam logic [ 31 : 0 ] GC_CR_OS0_SCRATCH3_DATA_BITFIELD                   = 32'h0;

 // gc_cr_os1_scratch0
localparam logic [ 31 : 0 ] GC_CR_OS1_SCRATCH0_DATA_BITFIELD                   = 32'h0;

 // gc_cr_os1_scratch1
localparam logic [ 31 : 0 ] GC_CR_OS1_SCRATCH1_DATA_BITFIELD                   = 32'h0;

 // gc_cr_os1_scratch2
localparam logic [ 31 : 0 ] GC_CR_OS1_SCRATCH2_DATA_BITFIELD                   = 32'h0;

 // gc_cr_os1_scratch3
localparam logic [ 31 : 0 ] GC_CR_OS1_SCRATCH3_DATA_BITFIELD                   = 32'h0;

 // gc_cr_os2_scratch0
localparam logic [ 31 : 0 ] GC_CR_OS2_SCRATCH0_DATA_BITFIELD                   = 32'h0;

 // gc_cr_os2_scratch1
localparam logic [ 31 : 0 ] GC_CR_OS2_SCRATCH1_DATA_BITFIELD                   = 32'h0;

 // gc_cr_os2_scratch2
localparam logic [ 31 : 0 ] GC_CR_OS2_SCRATCH2_DATA_BITFIELD                   = 32'h0;

 // gc_cr_os2_scratch3
localparam logic [ 31 : 0 ] GC_CR_OS2_SCRATCH3_DATA_BITFIELD                   = 32'h0;

 // gc_cr_os3_scratch0
localparam logic [ 31 : 0 ] GC_CR_OS3_SCRATCH0_DATA_BITFIELD                   = 32'h0;

 // gc_cr_os3_scratch1
localparam logic [ 31 : 0 ] GC_CR_OS3_SCRATCH1_DATA_BITFIELD                   = 32'h0;

 // gc_cr_os3_scratch2
localparam logic [ 31 : 0 ] GC_CR_OS3_SCRATCH2_DATA_BITFIELD                   = 32'h0;

 // gc_cr_os3_scratch3
localparam logic [ 31 : 0 ] GC_CR_OS3_SCRATCH3_DATA_BITFIELD                   = 32'h0;

 // gc_cr_os4_scratch0
localparam logic [ 31 : 0 ] GC_CR_OS4_SCRATCH0_DATA_BITFIELD                   = 32'h0;

 // gc_cr_os4_scratch1
localparam logic [ 31 : 0 ] GC_CR_OS4_SCRATCH1_DATA_BITFIELD                   = 32'h0;

 // gc_cr_os4_scratch2
localparam logic [ 31 : 0 ] GC_CR_OS4_SCRATCH2_DATA_BITFIELD                   = 32'h0;

 // gc_cr_os4_scratch3
localparam logic [ 31 : 0 ] GC_CR_OS4_SCRATCH3_DATA_BITFIELD                   = 32'h0;

 // gc_cr_os5_scratch0
localparam logic [ 31 : 0 ] GC_CR_OS5_SCRATCH0_DATA_BITFIELD                   = 32'h0;

 // gc_cr_os5_scratch1
localparam logic [ 31 : 0 ] GC_CR_OS5_SCRATCH1_DATA_BITFIELD                   = 32'h0;

 // gc_cr_os5_scratch2
localparam logic [ 31 : 0 ] GC_CR_OS5_SCRATCH2_DATA_BITFIELD                   = 32'h0;

 // gc_cr_os5_scratch3
localparam logic [ 31 : 0 ] GC_CR_OS5_SCRATCH3_DATA_BITFIELD                   = 32'h0;

 // gc_cr_os6_scratch0
localparam logic [ 31 : 0 ] GC_CR_OS6_SCRATCH0_DATA_BITFIELD                   = 32'h0;

 // gc_cr_os6_scratch1
localparam logic [ 31 : 0 ] GC_CR_OS6_SCRATCH1_DATA_BITFIELD                   = 32'h0;

 // gc_cr_os6_scratch2
localparam logic [ 31 : 0 ] GC_CR_OS6_SCRATCH2_DATA_BITFIELD                   = 32'h0;

 // gc_cr_os6_scratch3
localparam logic [ 31 : 0 ] GC_CR_OS6_SCRATCH3_DATA_BITFIELD                   = 32'h0;

 // gc_cr_os7_scratch0
localparam logic [ 31 : 0 ] GC_CR_OS7_SCRATCH0_DATA_BITFIELD                   = 32'h0;

 // gc_cr_os7_scratch1
localparam logic [ 31 : 0 ] GC_CR_OS7_SCRATCH1_DATA_BITFIELD                   = 32'h0;

 // gc_cr_os7_scratch2
localparam logic [ 31 : 0 ] GC_CR_OS7_SCRATCH2_DATA_BITFIELD                   = 32'h0;

 // gc_cr_os7_scratch3
localparam logic [ 31 : 0 ] GC_CR_OS7_SCRATCH3_DATA_BITFIELD                   = 32'h0;

 // gc_cr_os8_scratch0
localparam logic [ 31 : 0 ] GC_CR_OS8_SCRATCH0_DATA_BITFIELD                   = 32'h0;

 // gc_cr_os8_scratch1
localparam logic [ 31 : 0 ] GC_CR_OS8_SCRATCH1_DATA_BITFIELD                   = 32'h0;

 // gc_cr_os8_scratch2
localparam logic [ 31 : 0 ] GC_CR_OS8_SCRATCH2_DATA_BITFIELD                   = 32'h0;

 // gc_cr_os8_scratch3
localparam logic [ 31 : 0 ] GC_CR_OS8_SCRATCH3_DATA_BITFIELD                   = 32'h0;

 // gc_cr_os9_scratch0
localparam logic [ 31 : 0 ] GC_CR_OS9_SCRATCH0_DATA_BITFIELD                   = 32'h0;

 // gc_cr_os9_scratch1
localparam logic [ 31 : 0 ] GC_CR_OS9_SCRATCH1_DATA_BITFIELD                   = 32'h0;

 // gc_cr_os9_scratch2
localparam logic [ 31 : 0 ] GC_CR_OS9_SCRATCH2_DATA_BITFIELD                   = 32'h0;

 // gc_cr_os9_scratch3
localparam logic [ 31 : 0 ] GC_CR_OS9_SCRATCH3_DATA_BITFIELD                   = 32'h0;

 // gc_cr_os10_scratch0
localparam logic [ 31 : 0 ] GC_CR_OS10_SCRATCH0_DATA_BITFIELD                  = 32'h0;

 // gc_cr_os10_scratch1
localparam logic [ 31 : 0 ] GC_CR_OS10_SCRATCH1_DATA_BITFIELD                  = 32'h0;

 // gc_cr_os10_scratch2
localparam logic [ 31 : 0 ] GC_CR_OS10_SCRATCH2_DATA_BITFIELD                  = 32'h0;

 // gc_cr_os10_scratch3
localparam logic [ 31 : 0 ] GC_CR_OS10_SCRATCH3_DATA_BITFIELD                  = 32'h0;

 // gc_cr_os11_scratch0
localparam logic [ 31 : 0 ] GC_CR_OS11_SCRATCH0_DATA_BITFIELD                  = 32'h0;

 // gc_cr_os11_scratch1
localparam logic [ 31 : 0 ] GC_CR_OS11_SCRATCH1_DATA_BITFIELD                  = 32'h0;

 // gc_cr_os11_scratch2
localparam logic [ 31 : 0 ] GC_CR_OS11_SCRATCH2_DATA_BITFIELD                  = 32'h0;

 // gc_cr_os11_scratch3
localparam logic [ 31 : 0 ] GC_CR_OS11_SCRATCH3_DATA_BITFIELD                  = 32'h0;

 // gc_cr_os12_scratch0
localparam logic [ 31 : 0 ] GC_CR_OS12_SCRATCH0_DATA_BITFIELD                  = 32'h0;

 // gc_cr_os12_scratch1
localparam logic [ 31 : 0 ] GC_CR_OS12_SCRATCH1_DATA_BITFIELD                  = 32'h0;

 // gc_cr_os12_scratch2
localparam logic [ 31 : 0 ] GC_CR_OS12_SCRATCH2_DATA_BITFIELD                  = 32'h0;

 // gc_cr_os12_scratch3
localparam logic [ 31 : 0 ] GC_CR_OS12_SCRATCH3_DATA_BITFIELD                  = 32'h0;

 // gc_cr_os13_scratch0
localparam logic [ 31 : 0 ] GC_CR_OS13_SCRATCH0_DATA_BITFIELD                  = 32'h0;

 // gc_cr_os13_scratch1
localparam logic [ 31 : 0 ] GC_CR_OS13_SCRATCH1_DATA_BITFIELD                  = 32'h0;

 // gc_cr_os13_scratch2
localparam logic [ 31 : 0 ] GC_CR_OS13_SCRATCH2_DATA_BITFIELD                  = 32'h0;

 // gc_cr_os13_scratch3
localparam logic [ 31 : 0 ] GC_CR_OS13_SCRATCH3_DATA_BITFIELD                  = 32'h0;

 // gc_cr_os14_scratch0
localparam logic [ 31 : 0 ] GC_CR_OS14_SCRATCH0_DATA_BITFIELD                  = 32'h0;

 // gc_cr_os14_scratch1
localparam logic [ 31 : 0 ] GC_CR_OS14_SCRATCH1_DATA_BITFIELD                  = 32'h0;

 // gc_cr_os14_scratch2
localparam logic [ 31 : 0 ] GC_CR_OS14_SCRATCH2_DATA_BITFIELD                  = 32'h0;

 // gc_cr_os14_scratch3
localparam logic [ 31 : 0 ] GC_CR_OS14_SCRATCH3_DATA_BITFIELD                  = 32'h0;

 // gc_cr_os15_scratch0
localparam logic [ 31 : 0 ] GC_CR_OS15_SCRATCH0_DATA_BITFIELD                  = 32'h0;

 // gc_cr_os15_scratch1
localparam logic [ 31 : 0 ] GC_CR_OS15_SCRATCH1_DATA_BITFIELD                  = 32'h0;

 // gc_cr_os15_scratch2
localparam logic [ 31 : 0 ] GC_CR_OS15_SCRATCH2_DATA_BITFIELD                  = 32'h0;

 // gc_cr_os15_scratch3
localparam logic [ 31 : 0 ] GC_CR_OS15_SCRATCH3_DATA_BITFIELD                  = 32'h0;

 // gc_cr_fwcore_dmi_data0
localparam logic [ 31 : 0 ] GC_CR_FWCORE_DMI_DATA0_VAL_BITFIELD                = 32'h0;
localparam logic [ 63 : 32 ] GC_CR_FWCORE_DMI_DATA0_RESERVED_32_BITFIELD       = 32'h0;

 // gc_cr_fwcore_dmi_data1
localparam logic [ 31 : 0 ] GC_CR_FWCORE_DMI_DATA1_VAL_BITFIELD                = 32'h0;
localparam logic [ 63 : 32 ] GC_CR_FWCORE_DMI_DATA1_RESERVED_32_BITFIELD       = 32'h0;

 // gc_cr_fwcore_dmi_dmcontrol
localparam logic [ 0 : 0 ] GC_CR_FWCORE_DMI_DMCONTROL_DMACTIVE_BITFIELD        = 1'h0;
localparam logic [ 1 : 1 ] GC_CR_FWCORE_DMI_DMCONTROL_NDMRESET_BITFIELD        = 1'h0;
localparam logic [ 27 : 2 ] GC_CR_FWCORE_DMI_DMCONTROL_RESERVED_2_BITFIELD     = 26'h0;
localparam logic [ 28 : 28 ] GC_CR_FWCORE_DMI_DMCONTROL_ACKHAVERESET_BITFIELD  = 1'h0;
localparam logic [ 29 : 29 ] GC_CR_FWCORE_DMI_DMCONTROL_RESERVED_29_BITFIELD   = 1'h0;
localparam logic [ 31 : 31 ] GC_CR_FWCORE_DMI_DMCONTROL_HALTREQ_BITFIELD       = 1'h0;
localparam logic [ 63 : 32 ] GC_CR_FWCORE_DMI_DMCONTROL_RESERVED_32_BITFIELD   = 32'h0;

 // gc_cr_fwcore_dmi_dmstatus
localparam logic [ 3 : 0 ] GC_CR_FWCORE_DMI_DMSTATUS_VERSION_BITFIELD          = 4'h2;
localparam logic [ 4 : 4 ] GC_CR_FWCORE_DMI_DMSTATUS_CONFSTRPTRVALID_BITFIELD  = 1'h0;
localparam logic [ 5 : 5 ] GC_CR_FWCORE_DMI_DMSTATUS_HASRESETHALTREQ_BITFIELD  = 1'h0;
localparam logic [ 6 : 6 ] GC_CR_FWCORE_DMI_DMSTATUS_AUTHBUSY_BITFIELD         = 1'h0;
localparam logic [ 7 : 7 ] GC_CR_FWCORE_DMI_DMSTATUS_AUTHENTICATED_BITFIELD    = 1'h0;
localparam logic [ 8 : 8 ] GC_CR_FWCORE_DMI_DMSTATUS_ANYHALTED_BITFIELD        = 1'h0;
localparam logic [ 9 : 9 ] GC_CR_FWCORE_DMI_DMSTATUS_ALLHALTED_BITFIELD        = 1'h0;
localparam logic [ 10 : 10 ] GC_CR_FWCORE_DMI_DMSTATUS_ANYRUNNING_BITFIELD     = 1'h0;
localparam logic [ 11 : 11 ] GC_CR_FWCORE_DMI_DMSTATUS_ALLRUNNING_BITFIELD     = 1'h0;
localparam logic [ 12 : 12 ] GC_CR_FWCORE_DMI_DMSTATUS_ANYUNAVAIL_BITFIELD     = 1'h0;
localparam logic [ 13 : 13 ] GC_CR_FWCORE_DMI_DMSTATUS_ALLUNAVAIL_BITFIELD     = 1'h0;
localparam logic [ 14 : 14 ] GC_CR_FWCORE_DMI_DMSTATUS_ANYNONEXISTENT_BITFIELD  = 1'h0;
localparam logic [ 15 : 15 ] GC_CR_FWCORE_DMI_DMSTATUS_ALLNONEXISTENT_BITFIELD  = 1'h0;
localparam logic [ 16 : 16 ] GC_CR_FWCORE_DMI_DMSTATUS_ANYRESUMEACK_BITFIELD   = 1'h0;
localparam logic [ 17 : 17 ] GC_CR_FWCORE_DMI_DMSTATUS_ALLRESUMEACK_BITFIELD   = 1'h0;
localparam logic [ 18 : 18 ] GC_CR_FWCORE_DMI_DMSTATUS_ANYHAVERESET_BITFIELD   = 1'h0;
localparam logic [ 19 : 19 ] GC_CR_FWCORE_DMI_DMSTATUS_ALLHAVERESET_BITFIELD   = 1'h0;
localparam logic [ 21 : 20 ] GC_CR_FWCORE_DMI_DMSTATUS_RESERVED_20_BITFIELD    = 2'h0;
localparam logic [ 22 : 22 ] GC_CR_FWCORE_DMI_DMSTATUS_IMPEBREAK_BITFIELD      = 1'h0;
localparam logic [ 63 : 23 ] GC_CR_FWCORE_DMI_DMSTATUS_RESERVED_23_BITFIELD    = 41'h0;

 // gc_cr_fwcore_dmi_abstractcs
localparam logic [ 3 : 0 ] GC_CR_FWCORE_DMI_ABSTRACTCS_DATACOUNT_BITFIELD      = 4'h0;
localparam logic [ 7 : 4 ] GC_CR_FWCORE_DMI_ABSTRACTCS_RESERVED_4_BITFIELD     = 4'h0;
localparam logic [ 10 : 8 ] GC_CR_FWCORE_DMI_ABSTRACTCS_CMDERR_BITFIELD        = 3'h0;
localparam logic [ 11 : 11 ] GC_CR_FWCORE_DMI_ABSTRACTCS_RESERVED_11_BITFIELD  = 1'h0;
localparam logic [ 12 : 12 ] GC_CR_FWCORE_DMI_ABSTRACTCS_BUSY_BITFIELD         = 1'h0;
localparam logic [ 23 : 13 ] GC_CR_FWCORE_DMI_ABSTRACTCS_RESERVED_13_BITFIELD  = 11'h0;
localparam logic [ 28 : 24 ] GC_CR_FWCORE_DMI_ABSTRACTCS_PROGBUFSIZE_BITFIELD  = 5'h0;
localparam logic [ 63 : 29 ] GC_CR_FWCORE_DMI_ABSTRACTCS_RESERVED_29_BITFIELD  = 35'h0;

 // gc_cr_fwcore_dmi_command
localparam logic [ 23 : 0 ] GC_CR_FWCORE_DMI_COMMAND_CONTROL_BITFIELD          = 24'h0;
localparam logic [ 31 : 24 ] GC_CR_FWCORE_DMI_COMMAND_CMDTYPE_BITFIELD         = 8'h0;
localparam logic [ 63 : 32 ] GC_CR_FWCORE_DMI_COMMAND_RESERVED_32_BITFIELD     = 32'h0;

 // gc_cr_fwcore_dmi_sbcs
localparam logic [ 0 : 0 ] GC_CR_FWCORE_DMI_SBCS_SBACCESS8_BITFIELD            = 1'h0;
localparam logic [ 1 : 1 ] GC_CR_FWCORE_DMI_SBCS_SBACCESS16_BITFIELD           = 1'h0;
localparam logic [ 2 : 2 ] GC_CR_FWCORE_DMI_SBCS_SBACCESS32_BITFIELD           = 1'h0;
localparam logic [ 3 : 3 ] GC_CR_FWCORE_DMI_SBCS_SBACCESS64_BITFIELD           = 1'h0;
localparam logic [ 4 : 4 ] GC_CR_FWCORE_DMI_SBCS_SBACCESS128_BITFIELD          = 1'h0;
localparam logic [ 11 : 5 ] GC_CR_FWCORE_DMI_SBCS_SBASIZE_BITFIELD             = 7'h0;
localparam logic [ 14 : 12 ] GC_CR_FWCORE_DMI_SBCS_SBERROR_BITFIELD            = 3'h0;
localparam logic [ 15 : 15 ] GC_CR_FWCORE_DMI_SBCS_SBREADONDATA_BITFIELD       = 1'h0;
localparam logic [ 16 : 16 ] GC_CR_FWCORE_DMI_SBCS_SBAUTOINCREMENT_BITFIELD    = 1'h0;
localparam logic [ 19 : 17 ] GC_CR_FWCORE_DMI_SBCS_SBACCESS_BITFIELD           = 3'h0;
localparam logic [ 20 : 20 ] GC_CR_FWCORE_DMI_SBCS_SBREADONADDR_BITFIELD       = 1'h0;
localparam logic [ 21 : 21 ] GC_CR_FWCORE_DMI_SBCS_SBBUSY_BITFIELD             = 1'h0;
localparam logic [ 22 : 22 ] GC_CR_FWCORE_DMI_SBCS_SBBUSYERROR_BITFIELD        = 1'h0;
localparam logic [ 28 : 23 ] GC_CR_FWCORE_DMI_SBCS_RESERVED_23_BITFIELD        = 6'h0;
localparam logic [ 31 : 29 ] GC_CR_FWCORE_DMI_SBCS_SBVERSION_BITFIELD          = 3'h0;
localparam logic [ 63 : 32 ] GC_CR_FWCORE_DMI_SBCS_RESERVED_32_BITFIELD        = 32'h0;

 // gc_cr_fwcore_dmi_sbaddress0
localparam logic [ 31 : 0 ] GC_CR_FWCORE_DMI_SBADDRESS0_ADDRESS_BITFIELD       = 32'h0;
localparam logic [ 63 : 32 ] GC_CR_FWCORE_DMI_SBADDRESS0_RESERVED_29_BITFIELD  = 32'h0;

 // gc_cr_fwcore_dmi_sbdata0
localparam logic [ 63 : 0 ] GC_CR_FWCORE_DMI_SBDATA0_RESERVED_0_BITFIELD       = 64'h0;

 // gc_cr_fwcore_dmi_sbdata1
localparam logic [ 63 : 0 ] GC_CR_FWCORE_DMI_SBDATA1_RESERVED_0_BITFIELD       = 64'h0;

 // gc_cr_fwcore_dmi_sbdata2
localparam logic [ 63 : 0 ] GC_CR_FWCORE_DMI_SBDATA2_RESERVED_0_BITFIELD       = 64'h0;

 // gc_cr_fwcore_dmi_sbdata3
localparam logic [ 63 : 0 ] GC_CR_FWCORE_DMI_SBDATA3_RESERVED_0_BITFIELD       = 64'h0;

 // gc_cr_fwcore_dmi_haltsum0
localparam logic [ 31 : 0 ] GC_CR_FWCORE_DMI_HALTSUM0_VAL_BITFIELD             = 32'h0;
localparam logic [ 63 : 32 ] GC_CR_FWCORE_DMI_HALTSUM0_RESERVED_32_BITFIELD    = 32'h0;

 // gc_cr_fwcore_dmi_reserved0
localparam logic [ 63 : 0 ] GC_CR_FWCORE_DMI_RESERVED0_RESERVED_0_BITFIELD     = 64'h0;

 // gc_cr_fwp_sp_mslvdatax
localparam logic [ 31 : 0 ] GC_CR_FWP_SP_MSLVDATAX_MSLVDATAX_BITFIELD          = 32'h0;

 // gc_cr_fwp_sp_mslvdatax_packed
localparam logic [ 31 : 0 ] GC_CR_FWP_SP_MSLVDATAX_PACKED_MSLVDATAX_BITFIELD   = 32'h0;

 // gc_cr_fwp_sp_reserved15_0

 // gc_cr_fwp_sp_reserved15_1

 // gc_cr_fwp_sp_reserved15_2

 // gc_cr_fwp_sp_reserved15_3

 // gc_cr_fwp_sp_reserved15_4

 // gc_cr_fwp_sp_reserved15_5

 // gc_cr_fwp_sp_reserved15_6

 // gc_cr_fwp_sp_mslvdatat
localparam logic [ 31 : 0 ] GC_CR_FWP_SP_MSLVDATAT_MSLVDATAT_BITFIELD          = 32'h0;

 // gc_cr_fwp_sp_mslvdatat_packed
localparam logic [ 31 : 0 ] GC_CR_FWP_SP_MSLVDATAT_PACKED_MSLVDATAT_BITFIELD   = 32'h0;

 // gc_cr_fwp_sp_reserved16_0

 // gc_cr_fwp_sp_reserved16_1

 // gc_cr_fwp_sp_reserved16_2

 // gc_cr_fwp_sp_reserved16_3

 // gc_cr_fwp_sp_reserved16_4

 // gc_cr_fwp_sp_reserved16_5

 // gc_cr_fwp_sp_reserved16_6

 // gc_cr_fwp_sp_mslvctrl0
localparam logic [ 0 : 0 ] GC_CR_FWP_SP_MSLVCTRL0_RD_BITFIELD                  = 1'h0;
localparam logic [ 1 : 1 ] GC_CR_FWP_SP_MSLVCTRL0_AUTOINCR_BITFIELD            = 1'h0;
localparam logic [ 31 : 2 ] GC_CR_FWP_SP_MSLVCTRL0_ADDR_BITFIELD               = 30'h0;

 // gc_cr_fwp_sp_mslvctrl0_packed
localparam logic [ 0 : 0 ] GC_CR_FWP_SP_MSLVCTRL0_PACKED_RD_BITFIELD           = 1'h0;
localparam logic [ 1 : 1 ] GC_CR_FWP_SP_MSLVCTRL0_PACKED_AUTOINCR_BITFIELD     = 1'h0;
localparam logic [ 31 : 2 ] GC_CR_FWP_SP_MSLVCTRL0_PACKED_ADDR_BITFIELD        = 30'h0;

 // gc_cr_fwp_sp_reserved17_0

 // gc_cr_fwp_sp_reserved17_1

 // gc_cr_fwp_sp_reserved17_2

 // gc_cr_fwp_sp_reserved17_3

 // gc_cr_fwp_sp_reserved17_4

 // gc_cr_fwp_sp_reserved17_5

 // gc_cr_fwp_sp_reserved17_6

 // gc_cr_fwp_sp_mslvctrl1
localparam logic [ 1 : 0 ] GC_CR_FWP_SP_MSLVCTRL1_BYTE_ROUND_BITFIELD          = 2'h0;
localparam logic [ 3 : 2 ] GC_CR_FWP_SP_MSLVCTRL1_TRANS_SIZE_BITFIELD          = 2'h0;
localparam logic [ 5 : 4 ] GC_CR_FWP_SP_MSLVCTRL1_THREAD_BITFIELD              = 2'h0;
localparam logic [ 18 : 18 ] GC_CR_FWP_SP_MSLVCTRL1_WR_ACTIVE_BITFIELD         = 1'h0;
localparam logic [ 20 : 20 ] GC_CR_FWP_SP_MSLVCTRL1_DEFERR_BITFIELD            = 1'h0;
localparam logic [ 23 : 21 ] GC_CR_FWP_SP_MSLVCTRL1_DEFERRID_BITFIELD          = 3'h0;
localparam logic [ 24 : 24 ] GC_CR_FWP_SP_MSLVCTRL1_READY_BITFIELD             = 1'h0;
localparam logic [ 25 : 25 ] GC_CR_FWP_SP_MSLVCTRL1_COREMEM_IDLE_BITFIELD      = 1'h0;
localparam logic [ 26 : 26 ] GC_CR_FWP_SP_MSLVCTRL1_GBLPORT_IDLE_BITFIELD      = 1'h0;
localparam logic [ 28 : 28 ] GC_CR_FWP_SP_MSLVCTRL1_ATOMIC_INTERLOCK_BITFIELD  = 1'h0;
localparam logic [ 29 : 29 ] GC_CR_FWP_SP_MSLVCTRL1_LOCK2_INTERLOCK_BITFIELD   = 1'h0;
localparam logic [ 31 : 30 ] GC_CR_FWP_SP_MSLVCTRL1_DEFERRTHREAD_BITFIELD      = 2'h0;

 // gc_cr_fwp_sp_mslvctrl1_packed
localparam logic [ 1 : 0 ] GC_CR_FWP_SP_MSLVCTRL1_PACKED_BYTE_ROUND_BITFIELD   = 2'h0;
localparam logic [ 3 : 2 ] GC_CR_FWP_SP_MSLVCTRL1_PACKED_TRANS_SIZE_BITFIELD   = 2'h0;
localparam logic [ 5 : 4 ] GC_CR_FWP_SP_MSLVCTRL1_PACKED_THREAD_BITFIELD       = 2'h0;
localparam logic [ 18 : 18 ] GC_CR_FWP_SP_MSLVCTRL1_PACKED_WR_ACTIVE_BITFIELD  = 1'h0;
localparam logic [ 20 : 20 ] GC_CR_FWP_SP_MSLVCTRL1_PACKED_DEFERR_BITFIELD     = 1'h0;
localparam logic [ 23 : 21 ] GC_CR_FWP_SP_MSLVCTRL1_PACKED_DEFERRID_BITFIELD   = 3'h0;
localparam logic [ 24 : 24 ] GC_CR_FWP_SP_MSLVCTRL1_PACKED_READY_BITFIELD      = 1'h0;
localparam logic [ 25 : 25 ] GC_CR_FWP_SP_MSLVCTRL1_PACKED_COREMEM_IDLE_BITFIELD  = 1'h0;
localparam logic [ 26 : 26 ] GC_CR_FWP_SP_MSLVCTRL1_PACKED_GBLPORT_IDLE_BITFIELD  = 1'h0;
localparam logic [ 28 : 28 ] GC_CR_FWP_SP_MSLVCTRL1_PACKED_ATOMIC_INTERLOCK_BITFIELD  = 1'h0;
localparam logic [ 29 : 29 ] GC_CR_FWP_SP_MSLVCTRL1_PACKED_LOCK2_INTERLOCK_BITFIELD  = 1'h0;
localparam logic [ 31 : 30 ] GC_CR_FWP_SP_MSLVCTRL1_PACKED_DEFERRTHREAD_BITFIELD  = 2'h0;

 // gc_cr_fwp_sp_reserved18_0

 // gc_cr_fwp_sp_reserved18_1

 // gc_cr_fwp_sp_reserved18_2

 // gc_cr_fwp_sp_reserved18_3

 // gc_cr_fwp_sp_reserved18_4

 // gc_cr_fwp_sp_reserved18_5

 // gc_cr_fwp_sp_reserved18_6

 // gc_cr_fwp_sp_reserved0_0

 // gc_cr_fwp_sp_reserved0_1

 // gc_cr_fwp_sp_reserved0_2

 // gc_cr_fwp_sp_reserved0_3

 // gc_cr_fwp_sp_reserved0_4

 // gc_cr_fwp_sp_reserved0_5

 // gc_cr_fwp_sp_reserved0_6

 // gc_cr_fwp_sp_reserved0_7

 // gc_cr_fwp_sp_reserved0

 // gc_cr_fwp_sp_reserved1_0

 // gc_cr_fwp_sp_reserved1_1

 // gc_cr_fwp_sp_reserved1_2

 // gc_cr_fwp_sp_reserved1_3

 // gc_cr_fwp_sp_reserved1_4

 // gc_cr_fwp_sp_reserved1_5

 // gc_cr_fwp_sp_reserved1_6

 // gc_cr_fwp_sp_reserved1_7

 // gc_cr_fwp_sp_reserved1

 // gc_cr_fwp_sp_reserved2_0

 // gc_cr_fwp_sp_reserved2_1

 // gc_cr_fwp_sp_reserved2_2

 // gc_cr_fwp_sp_reserved2_3

 // gc_cr_fwp_sp_reserved2_4

 // gc_cr_fwp_sp_reserved2_5

 // gc_cr_fwp_sp_reserved2_6

 // gc_cr_fwp_sp_reserved2_7

 // gc_cr_fwp_sp_reserved2

 // gc_cr_fwp_sp_reserved3_0

 // gc_cr_fwp_sp_reserved3_1

 // gc_cr_fwp_sp_reserved3_2

 // gc_cr_fwp_sp_reserved3_3

 // gc_cr_fwp_sp_reserved3_4

 // gc_cr_fwp_sp_reserved3_5

 // gc_cr_fwp_sp_reserved3_6

 // gc_cr_fwp_sp_reserved3_7

 // gc_cr_fwp_sp_reserved3

 // gc_cr_fwp_sp_reserved4_0

 // gc_cr_fwp_sp_reserved4_1

 // gc_cr_fwp_sp_reserved4_2

 // gc_cr_fwp_sp_reserved4_3

 // gc_cr_fwp_sp_reserved4_4

 // gc_cr_fwp_sp_reserved4_5

 // gc_cr_fwp_sp_reserved4_6

 // gc_cr_fwp_sp_reserved4_7

 // gc_cr_fwp_sp_reserved4

 // gc_cr_fwp_sp_reserved5_0

 // gc_cr_fwp_sp_reserved5_1

 // gc_cr_fwp_sp_reserved5_2

 // gc_cr_fwp_sp_reserved5_3

 // gc_cr_fwp_sp_reserved5_4

 // gc_cr_fwp_sp_reserved5_5

 // gc_cr_fwp_sp_reserved5_6

 // gc_cr_fwp_sp_reserved5_7

 // gc_cr_fwp_sp_reserved5

 // gc_cr_fwp_sp_mslvhandshke
localparam logic [ 1 : 0 ] GC_CR_FWP_SP_MSLVHANDSHKE_OUTPUT_BITFIELD           = 2'h0;
localparam logic [ 3 : 2 ] GC_CR_FWP_SP_MSLVHANDSHKE_INPUT_BITFIELD            = 2'h0;

 // gc_cr_fwp_sp_mslvhandshke_packed
localparam logic [ 1 : 0 ] GC_CR_FWP_SP_MSLVHANDSHKE_PACKED_OUTPUT_BITFIELD    = 2'h0;
localparam logic [ 3 : 2 ] GC_CR_FWP_SP_MSLVHANDSHKE_PACKED_INPUT_BITFIELD     = 2'h0;

 // gc_cr_fwp_sp_reserved19_0

 // gc_cr_fwp_sp_reserved19_1

 // gc_cr_fwp_sp_reserved19_2

 // gc_cr_fwp_sp_reserved19_3

 // gc_cr_fwp_sp_reserved19_4

 // gc_cr_fwp_sp_reserved19_5

 // gc_cr_fwp_sp_reserved19_6

 // gc_cr_fwp_sp_reserved6_0

 // gc_cr_fwp_sp_reserved6_1

 // gc_cr_fwp_sp_reserved6_2

 // gc_cr_fwp_sp_reserved6_3

 // gc_cr_fwp_sp_reserved6_4

 // gc_cr_fwp_sp_reserved6_5

 // gc_cr_fwp_sp_reserved6_6

 // gc_cr_fwp_sp_reserved6_7

 // gc_cr_fwp_sp_reserved6

 // gc_cr_fwp_sp_reserved7_0

 // gc_cr_fwp_sp_reserved7_1

 // gc_cr_fwp_sp_reserved7_2

 // gc_cr_fwp_sp_reserved7_3

 // gc_cr_fwp_sp_reserved7_4

 // gc_cr_fwp_sp_reserved7_5

 // gc_cr_fwp_sp_reserved7_6

 // gc_cr_fwp_sp_reserved7_7

 // gc_cr_fwp_sp_reserved7

 // gc_cr_fwp_sp_reserved8_0

 // gc_cr_fwp_sp_reserved8_1

 // gc_cr_fwp_sp_reserved8_2

 // gc_cr_fwp_sp_reserved8_3

 // gc_cr_fwp_sp_reserved8_4

 // gc_cr_fwp_sp_reserved8_5

 // gc_cr_fwp_sp_reserved8_6

 // gc_cr_fwp_sp_reserved8_7

 // gc_cr_fwp_sp_reserved8

 // gc_cr_fwp_sp_reserved9_0

 // gc_cr_fwp_sp_reserved9_1

 // gc_cr_fwp_sp_reserved9_2

 // gc_cr_fwp_sp_reserved9_3

 // gc_cr_fwp_sp_reserved9_4

 // gc_cr_fwp_sp_reserved9_5

 // gc_cr_fwp_sp_reserved9_6

 // gc_cr_fwp_sp_reserved9_7

 // gc_cr_fwp_sp_reserved9

 // gc_cr_fwp_sp_reserved10_0

 // gc_cr_fwp_sp_reserved10_1

 // gc_cr_fwp_sp_reserved10_2

 // gc_cr_fwp_sp_reserved10_3

 // gc_cr_fwp_sp_reserved10_4

 // gc_cr_fwp_sp_reserved10_5

 // gc_cr_fwp_sp_reserved10_6

 // gc_cr_fwp_sp_reserved10_7

 // gc_cr_fwp_sp_reserved10

 // gc_cr_fwp_sp_mslvt0kick
localparam logic [ 15 : 0 ] GC_CR_FWP_SP_MSLVT0KICK_MSLVT0KICK_BITFIELD        = 16'h0;

 // gc_cr_fwp_sp_mslvt0kick_packed
localparam logic [ 15 : 0 ] GC_CR_FWP_SP_MSLVT0KICK_PACKED_MSLVT0KICK_BITFIELD  = 16'h0;

 // gc_cr_fwp_sp_reserved20_0

 // gc_cr_fwp_sp_reserved20_1

 // gc_cr_fwp_sp_reserved20_2

 // gc_cr_fwp_sp_reserved20_3

 // gc_cr_fwp_sp_reserved20_4

 // gc_cr_fwp_sp_reserved20_5

 // gc_cr_fwp_sp_reserved20_6

 // gc_cr_fwp_sp_mslvt0kicki
localparam logic [ 15 : 0 ] GC_CR_FWP_SP_MSLVT0KICKI_MSLVT0KICKI_BITFIELD      = 16'h0;

 // gc_cr_fwp_sp_mslvt0kicki_packed
localparam logic [ 15 : 0 ] GC_CR_FWP_SP_MSLVT0KICKI_PACKED_MSLVT0KICKI_BITFIELD  = 16'h0;

 // gc_cr_fwp_sp_reserved21_0

 // gc_cr_fwp_sp_reserved21_1

 // gc_cr_fwp_sp_reserved21_2

 // gc_cr_fwp_sp_reserved21_3

 // gc_cr_fwp_sp_reserved21_4

 // gc_cr_fwp_sp_reserved21_5

 // gc_cr_fwp_sp_reserved21_6

 // gc_cr_fwp_sp_mslvt1kick
localparam logic [ 15 : 0 ] GC_CR_FWP_SP_MSLVT1KICK_MSLVT1KICK_BITFIELD        = 16'h0;

 // gc_cr_fwp_sp_mslvt1kick_packed
localparam logic [ 15 : 0 ] GC_CR_FWP_SP_MSLVT1KICK_PACKED_MSLVT1KICK_BITFIELD  = 16'h0;

 // gc_cr_fwp_sp_reserved22_0

 // gc_cr_fwp_sp_reserved22_1

 // gc_cr_fwp_sp_reserved22_2

 // gc_cr_fwp_sp_reserved22_3

 // gc_cr_fwp_sp_reserved22_4

 // gc_cr_fwp_sp_reserved22_5

 // gc_cr_fwp_sp_reserved22_6

 // gc_cr_fwp_sp_mslvt1kicki
localparam logic [ 15 : 0 ] GC_CR_FWP_SP_MSLVT1KICKI_MSLVT1KICKI_BITFIELD      = 16'h0;

 // gc_cr_fwp_sp_mslvt1kicki_packed
localparam logic [ 15 : 0 ] GC_CR_FWP_SP_MSLVT1KICKI_PACKED_MSLVT1KICKI_BITFIELD  = 16'h0;

 // gc_cr_fwp_sp_reserved23_0

 // gc_cr_fwp_sp_reserved23_1

 // gc_cr_fwp_sp_reserved23_2

 // gc_cr_fwp_sp_reserved23_3

 // gc_cr_fwp_sp_reserved23_4

 // gc_cr_fwp_sp_reserved23_5

 // gc_cr_fwp_sp_reserved23_6

 // gc_cr_fwp_sp_mslvt2kick
localparam logic [ 15 : 0 ] GC_CR_FWP_SP_MSLVT2KICK_MSLVT2KICK_BITFIELD        = 16'h0;

 // gc_cr_fwp_sp_mslvt2kick_packed
localparam logic [ 15 : 0 ] GC_CR_FWP_SP_MSLVT2KICK_PACKED_MSLVT2KICK_BITFIELD  = 16'h0;

 // gc_cr_fwp_sp_reserved24_0

 // gc_cr_fwp_sp_reserved24_1

 // gc_cr_fwp_sp_reserved24_2

 // gc_cr_fwp_sp_reserved24_3

 // gc_cr_fwp_sp_reserved24_4

 // gc_cr_fwp_sp_reserved24_5

 // gc_cr_fwp_sp_reserved24_6

 // gc_cr_fwp_sp_mslvt2kicki
localparam logic [ 15 : 0 ] GC_CR_FWP_SP_MSLVT2KICKI_MSLVT2KICKI_BITFIELD      = 16'h0;

 // gc_cr_fwp_sp_mslvt2kicki_packed
localparam logic [ 15 : 0 ] GC_CR_FWP_SP_MSLVT2KICKI_PACKED_MSLVT2KICKI_BITFIELD  = 16'h0;

 // gc_cr_fwp_sp_reserved25_0

 // gc_cr_fwp_sp_reserved25_1

 // gc_cr_fwp_sp_reserved25_2

 // gc_cr_fwp_sp_reserved25_3

 // gc_cr_fwp_sp_reserved25_4

 // gc_cr_fwp_sp_reserved25_5

 // gc_cr_fwp_sp_reserved25_6

 // gc_cr_fwp_sp_mslvt3kick
localparam logic [ 15 : 0 ] GC_CR_FWP_SP_MSLVT3KICK_MSLVT3KICK_BITFIELD        = 16'h0;

 // gc_cr_fwp_sp_mslvt3kick_packed
localparam logic [ 15 : 0 ] GC_CR_FWP_SP_MSLVT3KICK_PACKED_MSLVT3KICK_BITFIELD  = 16'h0;

 // gc_cr_fwp_sp_reserved26_0

 // gc_cr_fwp_sp_reserved26_1

 // gc_cr_fwp_sp_reserved26_2

 // gc_cr_fwp_sp_reserved26_3

 // gc_cr_fwp_sp_reserved26_4

 // gc_cr_fwp_sp_reserved26_5

 // gc_cr_fwp_sp_reserved26_6

 // gc_cr_fwp_sp_mslvt3kicki
localparam logic [ 15 : 0 ] GC_CR_FWP_SP_MSLVT3KICKI_MSLVT3KICKI_BITFIELD      = 16'h0;

 // gc_cr_fwp_sp_mslvt3kicki_packed
localparam logic [ 15 : 0 ] GC_CR_FWP_SP_MSLVT3KICKI_PACKED_MSLVT3KICKI_BITFIELD  = 16'h0;

 // gc_cr_fwp_sp_reserved27_0

 // gc_cr_fwp_sp_reserved27_1

 // gc_cr_fwp_sp_reserved27_2

 // gc_cr_fwp_sp_reserved27_3

 // gc_cr_fwp_sp_reserved27_4

 // gc_cr_fwp_sp_reserved27_5

 // gc_cr_fwp_sp_reserved27_6

 // gc_cr_fwp_sp_mslvrst
localparam logic [ 0 : 0 ] GC_CR_FWP_SP_MSLVRST_SOFTRESET_BITFIELD             = 1'h0;

 // gc_cr_fwp_sp_mslvrst_packed
localparam logic [ 0 : 0 ] GC_CR_FWP_SP_MSLVRST_PACKED_SOFTRESET_BITFIELD      = 1'h0;

 // gc_cr_fwp_sp_reserved28_0

 // gc_cr_fwp_sp_reserved28_1

 // gc_cr_fwp_sp_reserved28_2

 // gc_cr_fwp_sp_reserved28_3

 // gc_cr_fwp_sp_reserved28_4

 // gc_cr_fwp_sp_reserved28_5

 // gc_cr_fwp_sp_reserved28_6

 // gc_cr_fwp_sp_mslvirqstatus
localparam logic [ 2 : 2 ] GC_CR_FWP_SP_MSLVIRQSTATUS_TRIGVECT2_BITFIELD       = 1'h0;
localparam logic [ 3 : 3 ] GC_CR_FWP_SP_MSLVIRQSTATUS_TRIGVECT3_BITFIELD       = 1'h0;

 // gc_cr_fwp_sp_mslvirqstatus_packed
localparam logic [ 2 : 2 ] GC_CR_FWP_SP_MSLVIRQSTATUS_PACKED_TRIGVECT2_BITFIELD  = 1'h0;
localparam logic [ 3 : 3 ] GC_CR_FWP_SP_MSLVIRQSTATUS_PACKED_TRIGVECT3_BITFIELD  = 1'h0;

 // gc_cr_fwp_sp_reserved29_0

 // gc_cr_fwp_sp_reserved29_1

 // gc_cr_fwp_sp_reserved29_2

 // gc_cr_fwp_sp_reserved29_3

 // gc_cr_fwp_sp_reserved29_4

 // gc_cr_fwp_sp_reserved29_5

 // gc_cr_fwp_sp_reserved29_6

 // gc_cr_fwp_sp_mslvirqenable
localparam logic [ 2 : 2 ] GC_CR_FWP_SP_MSLVIRQENABLE_EVENT0_BITFIELD          = 1'h0;
localparam logic [ 3 : 3 ] GC_CR_FWP_SP_MSLVIRQENABLE_EVENT1_BITFIELD          = 1'h0;

 // gc_cr_fwp_sp_mslvirqenable_packed
localparam logic [ 2 : 2 ] GC_CR_FWP_SP_MSLVIRQENABLE_PACKED_EVENT0_BITFIELD   = 1'h0;
localparam logic [ 3 : 3 ] GC_CR_FWP_SP_MSLVIRQENABLE_PACKED_EVENT1_BITFIELD   = 1'h0;

 // gc_cr_fwp_sp_reserved30_0

 // gc_cr_fwp_sp_reserved30_1

 // gc_cr_fwp_sp_reserved30_2

 // gc_cr_fwp_sp_reserved30_3

 // gc_cr_fwp_sp_reserved30_4

 // gc_cr_fwp_sp_reserved30_5

 // gc_cr_fwp_sp_reserved30_6

 // gc_cr_fwp_sp_mslvirqlevel
localparam logic [ 0 : 0 ] GC_CR_FWP_SP_MSLVIRQLEVEL_MODE_BITFIELD             = 1'h0;

 // gc_cr_fwp_sp_mslvirqlevel_packed
localparam logic [ 0 : 0 ] GC_CR_FWP_SP_MSLVIRQLEVEL_PACKED_MODE_BITFIELD      = 1'h0;

 // gc_cr_fwp_sp_reserved31_0

 // gc_cr_fwp_sp_reserved31_1

 // gc_cr_fwp_sp_reserved31_2

 // gc_cr_fwp_sp_reserved31_3

 // gc_cr_fwp_sp_reserved31_4

 // gc_cr_fwp_sp_reserved31_5

 // gc_cr_fwp_sp_reserved31_6

 // gc_cr_fwp_sp_reserved11_0

 // gc_cr_fwp_sp_reserved11_1

 // gc_cr_fwp_sp_reserved11_2

 // gc_cr_fwp_sp_reserved11_3

 // gc_cr_fwp_sp_reserved11_4

 // gc_cr_fwp_sp_reserved11_5

 // gc_cr_fwp_sp_reserved11_6

 // gc_cr_fwp_sp_reserved11_7

 // gc_cr_fwp_sp_reserved11

 // gc_cr_fwp_sp_reserved12_0

 // gc_cr_fwp_sp_reserved12_1

 // gc_cr_fwp_sp_reserved12_2

 // gc_cr_fwp_sp_reserved12_3

 // gc_cr_fwp_sp_reserved12_4

 // gc_cr_fwp_sp_reserved12_5

 // gc_cr_fwp_sp_reserved12_6

 // gc_cr_fwp_sp_reserved12_7

 // gc_cr_fwp_sp_reserved12

 // gc_cr_fwp_sp_reserved13_0

 // gc_cr_fwp_sp_reserved13_1

 // gc_cr_fwp_sp_reserved13_2

 // gc_cr_fwp_sp_reserved13_3

 // gc_cr_fwp_sp_reserved13_4

 // gc_cr_fwp_sp_reserved13_5

 // gc_cr_fwp_sp_reserved13_6

 // gc_cr_fwp_sp_reserved13_7

 // gc_cr_fwp_sp_reserved13

 // gc_cr_fwp_sp_reserved14_0

 // gc_cr_fwp_sp_reserved14_1

 // gc_cr_fwp_sp_reserved14_2

 // gc_cr_fwp_sp_reserved14_3

 // gc_cr_fwp_sp_reserved14_4

 // gc_cr_fwp_sp_reserved14_5

 // gc_cr_fwp_sp_reserved14_6

 // gc_cr_fwp_sp_reserved14_7

 // gc_cr_fwp_sp_reserved14

 // gc_cr_mts_schedule
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE_DM_BITFIELD                      = 4'h0;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE_DM_DM0                           = 4'h0;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE_DM_DM1                           = 4'h1;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE_DM_DM2                           = 4'h2;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE_DM_DM3                           = 4'h3;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE_DM_DM4                           = 4'h4;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE_DM_DM5                           = 4'h5;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE_DM_DM6                           = 4'h6;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE_DM_DM7                           = 4'h7;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE_DM_DM_ALL                        = 4'hf;
localparam logic [ 4 : 4 ] GC_CR_MTS_SCHEDULE_TASK_BITFIELD                    = 1'h0;
localparam logic [ 4 : 4 ] GC_CR_MTS_SCHEDULE_TASK_NON_COUNTED                 = 1'h0;
localparam logic [ 4 : 4 ] GC_CR_MTS_SCHEDULE_TASK_COUNTED                     = 1'h1;
localparam logic [ 5 : 5 ] GC_CR_MTS_SCHEDULE_CONTEXT_BITFIELD                 = 1'h0;
localparam logic [ 5 : 5 ] GC_CR_MTS_SCHEDULE_CONTEXT_BGCTX                    = 1'h0;
localparam logic [ 5 : 5 ] GC_CR_MTS_SCHEDULE_CONTEXT_INTCTX                   = 1'h1;
localparam logic [ 7 : 6 ] GC_CR_MTS_SCHEDULE_PRIORITY_BITFIELD                = 2'h0;
localparam logic [ 7 : 6 ] GC_CR_MTS_SCHEDULE_PRIORITY_PRT0                    = 2'h0;
localparam logic [ 7 : 6 ] GC_CR_MTS_SCHEDULE_PRIORITY_PRT1                    = 2'h1;
localparam logic [ 7 : 6 ] GC_CR_MTS_SCHEDULE_PRIORITY_PRT2                    = 2'h2;
localparam logic [ 7 : 6 ] GC_CR_MTS_SCHEDULE_PRIORITY_PRT3                    = 2'h3;
localparam logic [ 8 : 8 ] GC_CR_MTS_SCHEDULE_HOST_BITFIELD                    = 1'h0;
localparam logic [ 8 : 8 ] GC_CR_MTS_SCHEDULE_HOST_BG_TIMER                    = 1'h0;
localparam logic [ 8 : 8 ] GC_CR_MTS_SCHEDULE_HOST_HOST                        = 1'h1;

 // gc_cr_mts_schedule1
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE1_DM_BITFIELD                     = 4'h0;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE1_DM_DM0                          = 4'h0;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE1_DM_DM1                          = 4'h1;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE1_DM_DM2                          = 4'h2;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE1_DM_DM3                          = 4'h3;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE1_DM_DM4                          = 4'h4;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE1_DM_DM5                          = 4'h5;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE1_DM_DM6                          = 4'h6;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE1_DM_DM7                          = 4'h7;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE1_DM_DM_ALL                       = 4'hf;
localparam logic [ 4 : 4 ] GC_CR_MTS_SCHEDULE1_TASK_BITFIELD                   = 1'h0;
localparam logic [ 4 : 4 ] GC_CR_MTS_SCHEDULE1_TASK_NON_COUNTED                = 1'h0;
localparam logic [ 4 : 4 ] GC_CR_MTS_SCHEDULE1_TASK_COUNTED                    = 1'h1;
localparam logic [ 5 : 5 ] GC_CR_MTS_SCHEDULE1_CONTEXT_BITFIELD                = 1'h0;
localparam logic [ 5 : 5 ] GC_CR_MTS_SCHEDULE1_CONTEXT_BGCTX                   = 1'h0;
localparam logic [ 5 : 5 ] GC_CR_MTS_SCHEDULE1_CONTEXT_INTCTX                  = 1'h1;
localparam logic [ 7 : 6 ] GC_CR_MTS_SCHEDULE1_PRIORITY_BITFIELD               = 2'h0;
localparam logic [ 7 : 6 ] GC_CR_MTS_SCHEDULE1_PRIORITY_PRT0                   = 2'h0;
localparam logic [ 7 : 6 ] GC_CR_MTS_SCHEDULE1_PRIORITY_PRT1                   = 2'h1;
localparam logic [ 7 : 6 ] GC_CR_MTS_SCHEDULE1_PRIORITY_PRT2                   = 2'h2;
localparam logic [ 7 : 6 ] GC_CR_MTS_SCHEDULE1_PRIORITY_PRT3                   = 2'h3;
localparam logic [ 8 : 8 ] GC_CR_MTS_SCHEDULE1_HOST_BITFIELD                   = 1'h0;
localparam logic [ 8 : 8 ] GC_CR_MTS_SCHEDULE1_HOST_BG_TIMER                   = 1'h0;
localparam logic [ 8 : 8 ] GC_CR_MTS_SCHEDULE1_HOST_HOST                       = 1'h1;

 // gc_cr_mts_schedule2
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE2_DM_BITFIELD                     = 4'h0;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE2_DM_DM0                          = 4'h0;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE2_DM_DM1                          = 4'h1;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE2_DM_DM2                          = 4'h2;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE2_DM_DM3                          = 4'h3;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE2_DM_DM4                          = 4'h4;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE2_DM_DM5                          = 4'h5;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE2_DM_DM6                          = 4'h6;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE2_DM_DM7                          = 4'h7;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE2_DM_DM_ALL                       = 4'hf;
localparam logic [ 4 : 4 ] GC_CR_MTS_SCHEDULE2_TASK_BITFIELD                   = 1'h0;
localparam logic [ 4 : 4 ] GC_CR_MTS_SCHEDULE2_TASK_NON_COUNTED                = 1'h0;
localparam logic [ 4 : 4 ] GC_CR_MTS_SCHEDULE2_TASK_COUNTED                    = 1'h1;
localparam logic [ 5 : 5 ] GC_CR_MTS_SCHEDULE2_CONTEXT_BITFIELD                = 1'h0;
localparam logic [ 5 : 5 ] GC_CR_MTS_SCHEDULE2_CONTEXT_BGCTX                   = 1'h0;
localparam logic [ 5 : 5 ] GC_CR_MTS_SCHEDULE2_CONTEXT_INTCTX                  = 1'h1;
localparam logic [ 7 : 6 ] GC_CR_MTS_SCHEDULE2_PRIORITY_BITFIELD               = 2'h0;
localparam logic [ 7 : 6 ] GC_CR_MTS_SCHEDULE2_PRIORITY_PRT0                   = 2'h0;
localparam logic [ 7 : 6 ] GC_CR_MTS_SCHEDULE2_PRIORITY_PRT1                   = 2'h1;
localparam logic [ 7 : 6 ] GC_CR_MTS_SCHEDULE2_PRIORITY_PRT2                   = 2'h2;
localparam logic [ 7 : 6 ] GC_CR_MTS_SCHEDULE2_PRIORITY_PRT3                   = 2'h3;
localparam logic [ 8 : 8 ] GC_CR_MTS_SCHEDULE2_HOST_BITFIELD                   = 1'h0;
localparam logic [ 8 : 8 ] GC_CR_MTS_SCHEDULE2_HOST_BG_TIMER                   = 1'h0;
localparam logic [ 8 : 8 ] GC_CR_MTS_SCHEDULE2_HOST_HOST                       = 1'h1;

 // gc_cr_mts_schedule3
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE3_DM_BITFIELD                     = 4'h0;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE3_DM_DM0                          = 4'h0;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE3_DM_DM1                          = 4'h1;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE3_DM_DM2                          = 4'h2;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE3_DM_DM3                          = 4'h3;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE3_DM_DM4                          = 4'h4;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE3_DM_DM5                          = 4'h5;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE3_DM_DM6                          = 4'h6;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE3_DM_DM7                          = 4'h7;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE3_DM_DM_ALL                       = 4'hf;
localparam logic [ 4 : 4 ] GC_CR_MTS_SCHEDULE3_TASK_BITFIELD                   = 1'h0;
localparam logic [ 4 : 4 ] GC_CR_MTS_SCHEDULE3_TASK_NON_COUNTED                = 1'h0;
localparam logic [ 4 : 4 ] GC_CR_MTS_SCHEDULE3_TASK_COUNTED                    = 1'h1;
localparam logic [ 5 : 5 ] GC_CR_MTS_SCHEDULE3_CONTEXT_BITFIELD                = 1'h0;
localparam logic [ 5 : 5 ] GC_CR_MTS_SCHEDULE3_CONTEXT_BGCTX                   = 1'h0;
localparam logic [ 5 : 5 ] GC_CR_MTS_SCHEDULE3_CONTEXT_INTCTX                  = 1'h1;
localparam logic [ 7 : 6 ] GC_CR_MTS_SCHEDULE3_PRIORITY_BITFIELD               = 2'h0;
localparam logic [ 7 : 6 ] GC_CR_MTS_SCHEDULE3_PRIORITY_PRT0                   = 2'h0;
localparam logic [ 7 : 6 ] GC_CR_MTS_SCHEDULE3_PRIORITY_PRT1                   = 2'h1;
localparam logic [ 7 : 6 ] GC_CR_MTS_SCHEDULE3_PRIORITY_PRT2                   = 2'h2;
localparam logic [ 7 : 6 ] GC_CR_MTS_SCHEDULE3_PRIORITY_PRT3                   = 2'h3;
localparam logic [ 8 : 8 ] GC_CR_MTS_SCHEDULE3_HOST_BITFIELD                   = 1'h0;
localparam logic [ 8 : 8 ] GC_CR_MTS_SCHEDULE3_HOST_BG_TIMER                   = 1'h0;
localparam logic [ 8 : 8 ] GC_CR_MTS_SCHEDULE3_HOST_HOST                       = 1'h1;

 // gc_cr_mts_schedule4
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE4_DM_BITFIELD                     = 4'h0;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE4_DM_DM0                          = 4'h0;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE4_DM_DM1                          = 4'h1;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE4_DM_DM2                          = 4'h2;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE4_DM_DM3                          = 4'h3;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE4_DM_DM4                          = 4'h4;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE4_DM_DM5                          = 4'h5;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE4_DM_DM6                          = 4'h6;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE4_DM_DM7                          = 4'h7;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE4_DM_DM_ALL                       = 4'hf;
localparam logic [ 4 : 4 ] GC_CR_MTS_SCHEDULE4_TASK_BITFIELD                   = 1'h0;
localparam logic [ 4 : 4 ] GC_CR_MTS_SCHEDULE4_TASK_NON_COUNTED                = 1'h0;
localparam logic [ 4 : 4 ] GC_CR_MTS_SCHEDULE4_TASK_COUNTED                    = 1'h1;
localparam logic [ 5 : 5 ] GC_CR_MTS_SCHEDULE4_CONTEXT_BITFIELD                = 1'h0;
localparam logic [ 5 : 5 ] GC_CR_MTS_SCHEDULE4_CONTEXT_BGCTX                   = 1'h0;
localparam logic [ 5 : 5 ] GC_CR_MTS_SCHEDULE4_CONTEXT_INTCTX                  = 1'h1;
localparam logic [ 7 : 6 ] GC_CR_MTS_SCHEDULE4_PRIORITY_BITFIELD               = 2'h0;
localparam logic [ 7 : 6 ] GC_CR_MTS_SCHEDULE4_PRIORITY_PRT0                   = 2'h0;
localparam logic [ 7 : 6 ] GC_CR_MTS_SCHEDULE4_PRIORITY_PRT1                   = 2'h1;
localparam logic [ 7 : 6 ] GC_CR_MTS_SCHEDULE4_PRIORITY_PRT2                   = 2'h2;
localparam logic [ 7 : 6 ] GC_CR_MTS_SCHEDULE4_PRIORITY_PRT3                   = 2'h3;
localparam logic [ 8 : 8 ] GC_CR_MTS_SCHEDULE4_HOST_BITFIELD                   = 1'h0;
localparam logic [ 8 : 8 ] GC_CR_MTS_SCHEDULE4_HOST_BG_TIMER                   = 1'h0;
localparam logic [ 8 : 8 ] GC_CR_MTS_SCHEDULE4_HOST_HOST                       = 1'h1;

 // gc_cr_mts_schedule5
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE5_DM_BITFIELD                     = 4'h0;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE5_DM_DM0                          = 4'h0;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE5_DM_DM1                          = 4'h1;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE5_DM_DM2                          = 4'h2;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE5_DM_DM3                          = 4'h3;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE5_DM_DM4                          = 4'h4;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE5_DM_DM5                          = 4'h5;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE5_DM_DM6                          = 4'h6;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE5_DM_DM7                          = 4'h7;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE5_DM_DM_ALL                       = 4'hf;
localparam logic [ 4 : 4 ] GC_CR_MTS_SCHEDULE5_TASK_BITFIELD                   = 1'h0;
localparam logic [ 4 : 4 ] GC_CR_MTS_SCHEDULE5_TASK_NON_COUNTED                = 1'h0;
localparam logic [ 4 : 4 ] GC_CR_MTS_SCHEDULE5_TASK_COUNTED                    = 1'h1;
localparam logic [ 5 : 5 ] GC_CR_MTS_SCHEDULE5_CONTEXT_BITFIELD                = 1'h0;
localparam logic [ 5 : 5 ] GC_CR_MTS_SCHEDULE5_CONTEXT_BGCTX                   = 1'h0;
localparam logic [ 5 : 5 ] GC_CR_MTS_SCHEDULE5_CONTEXT_INTCTX                  = 1'h1;
localparam logic [ 7 : 6 ] GC_CR_MTS_SCHEDULE5_PRIORITY_BITFIELD               = 2'h0;
localparam logic [ 7 : 6 ] GC_CR_MTS_SCHEDULE5_PRIORITY_PRT0                   = 2'h0;
localparam logic [ 7 : 6 ] GC_CR_MTS_SCHEDULE5_PRIORITY_PRT1                   = 2'h1;
localparam logic [ 7 : 6 ] GC_CR_MTS_SCHEDULE5_PRIORITY_PRT2                   = 2'h2;
localparam logic [ 7 : 6 ] GC_CR_MTS_SCHEDULE5_PRIORITY_PRT3                   = 2'h3;
localparam logic [ 8 : 8 ] GC_CR_MTS_SCHEDULE5_HOST_BITFIELD                   = 1'h0;
localparam logic [ 8 : 8 ] GC_CR_MTS_SCHEDULE5_HOST_BG_TIMER                   = 1'h0;
localparam logic [ 8 : 8 ] GC_CR_MTS_SCHEDULE5_HOST_HOST                       = 1'h1;

 // gc_cr_mts_schedule6
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE6_DM_BITFIELD                     = 4'h0;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE6_DM_DM0                          = 4'h0;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE6_DM_DM1                          = 4'h1;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE6_DM_DM2                          = 4'h2;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE6_DM_DM3                          = 4'h3;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE6_DM_DM4                          = 4'h4;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE6_DM_DM5                          = 4'h5;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE6_DM_DM6                          = 4'h6;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE6_DM_DM7                          = 4'h7;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE6_DM_DM_ALL                       = 4'hf;
localparam logic [ 4 : 4 ] GC_CR_MTS_SCHEDULE6_TASK_BITFIELD                   = 1'h0;
localparam logic [ 4 : 4 ] GC_CR_MTS_SCHEDULE6_TASK_NON_COUNTED                = 1'h0;
localparam logic [ 4 : 4 ] GC_CR_MTS_SCHEDULE6_TASK_COUNTED                    = 1'h1;
localparam logic [ 5 : 5 ] GC_CR_MTS_SCHEDULE6_CONTEXT_BITFIELD                = 1'h0;
localparam logic [ 5 : 5 ] GC_CR_MTS_SCHEDULE6_CONTEXT_BGCTX                   = 1'h0;
localparam logic [ 5 : 5 ] GC_CR_MTS_SCHEDULE6_CONTEXT_INTCTX                  = 1'h1;
localparam logic [ 7 : 6 ] GC_CR_MTS_SCHEDULE6_PRIORITY_BITFIELD               = 2'h0;
localparam logic [ 7 : 6 ] GC_CR_MTS_SCHEDULE6_PRIORITY_PRT0                   = 2'h0;
localparam logic [ 7 : 6 ] GC_CR_MTS_SCHEDULE6_PRIORITY_PRT1                   = 2'h1;
localparam logic [ 7 : 6 ] GC_CR_MTS_SCHEDULE6_PRIORITY_PRT2                   = 2'h2;
localparam logic [ 7 : 6 ] GC_CR_MTS_SCHEDULE6_PRIORITY_PRT3                   = 2'h3;
localparam logic [ 8 : 8 ] GC_CR_MTS_SCHEDULE6_HOST_BITFIELD                   = 1'h0;
localparam logic [ 8 : 8 ] GC_CR_MTS_SCHEDULE6_HOST_BG_TIMER                   = 1'h0;
localparam logic [ 8 : 8 ] GC_CR_MTS_SCHEDULE6_HOST_HOST                       = 1'h1;

 // gc_cr_mts_schedule7
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE7_DM_BITFIELD                     = 4'h0;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE7_DM_DM0                          = 4'h0;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE7_DM_DM1                          = 4'h1;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE7_DM_DM2                          = 4'h2;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE7_DM_DM3                          = 4'h3;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE7_DM_DM4                          = 4'h4;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE7_DM_DM5                          = 4'h5;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE7_DM_DM6                          = 4'h6;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE7_DM_DM7                          = 4'h7;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE7_DM_DM_ALL                       = 4'hf;
localparam logic [ 4 : 4 ] GC_CR_MTS_SCHEDULE7_TASK_BITFIELD                   = 1'h0;
localparam logic [ 4 : 4 ] GC_CR_MTS_SCHEDULE7_TASK_NON_COUNTED                = 1'h0;
localparam logic [ 4 : 4 ] GC_CR_MTS_SCHEDULE7_TASK_COUNTED                    = 1'h1;
localparam logic [ 5 : 5 ] GC_CR_MTS_SCHEDULE7_CONTEXT_BITFIELD                = 1'h0;
localparam logic [ 5 : 5 ] GC_CR_MTS_SCHEDULE7_CONTEXT_BGCTX                   = 1'h0;
localparam logic [ 5 : 5 ] GC_CR_MTS_SCHEDULE7_CONTEXT_INTCTX                  = 1'h1;
localparam logic [ 7 : 6 ] GC_CR_MTS_SCHEDULE7_PRIORITY_BITFIELD               = 2'h0;
localparam logic [ 7 : 6 ] GC_CR_MTS_SCHEDULE7_PRIORITY_PRT0                   = 2'h0;
localparam logic [ 7 : 6 ] GC_CR_MTS_SCHEDULE7_PRIORITY_PRT1                   = 2'h1;
localparam logic [ 7 : 6 ] GC_CR_MTS_SCHEDULE7_PRIORITY_PRT2                   = 2'h2;
localparam logic [ 7 : 6 ] GC_CR_MTS_SCHEDULE7_PRIORITY_PRT3                   = 2'h3;
localparam logic [ 8 : 8 ] GC_CR_MTS_SCHEDULE7_HOST_BITFIELD                   = 1'h0;
localparam logic [ 8 : 8 ] GC_CR_MTS_SCHEDULE7_HOST_BG_TIMER                   = 1'h0;
localparam logic [ 8 : 8 ] GC_CR_MTS_SCHEDULE7_HOST_HOST                       = 1'h1;

 // gc_cr_mts_schedule8
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE8_DM_BITFIELD                     = 4'h0;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE8_DM_DM0                          = 4'h0;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE8_DM_DM1                          = 4'h1;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE8_DM_DM2                          = 4'h2;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE8_DM_DM3                          = 4'h3;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE8_DM_DM4                          = 4'h4;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE8_DM_DM5                          = 4'h5;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE8_DM_DM6                          = 4'h6;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE8_DM_DM7                          = 4'h7;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE8_DM_DM_ALL                       = 4'hf;
localparam logic [ 4 : 4 ] GC_CR_MTS_SCHEDULE8_TASK_BITFIELD                   = 1'h0;
localparam logic [ 4 : 4 ] GC_CR_MTS_SCHEDULE8_TASK_NON_COUNTED                = 1'h0;
localparam logic [ 4 : 4 ] GC_CR_MTS_SCHEDULE8_TASK_COUNTED                    = 1'h1;
localparam logic [ 5 : 5 ] GC_CR_MTS_SCHEDULE8_CONTEXT_BITFIELD                = 1'h0;
localparam logic [ 5 : 5 ] GC_CR_MTS_SCHEDULE8_CONTEXT_BGCTX                   = 1'h0;
localparam logic [ 5 : 5 ] GC_CR_MTS_SCHEDULE8_CONTEXT_INTCTX                  = 1'h1;
localparam logic [ 7 : 6 ] GC_CR_MTS_SCHEDULE8_PRIORITY_BITFIELD               = 2'h0;
localparam logic [ 7 : 6 ] GC_CR_MTS_SCHEDULE8_PRIORITY_PRT0                   = 2'h0;
localparam logic [ 7 : 6 ] GC_CR_MTS_SCHEDULE8_PRIORITY_PRT1                   = 2'h1;
localparam logic [ 7 : 6 ] GC_CR_MTS_SCHEDULE8_PRIORITY_PRT2                   = 2'h2;
localparam logic [ 7 : 6 ] GC_CR_MTS_SCHEDULE8_PRIORITY_PRT3                   = 2'h3;
localparam logic [ 8 : 8 ] GC_CR_MTS_SCHEDULE8_HOST_BITFIELD                   = 1'h0;
localparam logic [ 8 : 8 ] GC_CR_MTS_SCHEDULE8_HOST_BG_TIMER                   = 1'h0;
localparam logic [ 8 : 8 ] GC_CR_MTS_SCHEDULE8_HOST_HOST                       = 1'h1;

 // gc_cr_mts_schedule9
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE9_DM_BITFIELD                     = 4'h0;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE9_DM_DM0                          = 4'h0;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE9_DM_DM1                          = 4'h1;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE9_DM_DM2                          = 4'h2;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE9_DM_DM3                          = 4'h3;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE9_DM_DM4                          = 4'h4;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE9_DM_DM5                          = 4'h5;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE9_DM_DM6                          = 4'h6;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE9_DM_DM7                          = 4'h7;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE9_DM_DM_ALL                       = 4'hf;
localparam logic [ 4 : 4 ] GC_CR_MTS_SCHEDULE9_TASK_BITFIELD                   = 1'h0;
localparam logic [ 4 : 4 ] GC_CR_MTS_SCHEDULE9_TASK_NON_COUNTED                = 1'h0;
localparam logic [ 4 : 4 ] GC_CR_MTS_SCHEDULE9_TASK_COUNTED                    = 1'h1;
localparam logic [ 5 : 5 ] GC_CR_MTS_SCHEDULE9_CONTEXT_BITFIELD                = 1'h0;
localparam logic [ 5 : 5 ] GC_CR_MTS_SCHEDULE9_CONTEXT_BGCTX                   = 1'h0;
localparam logic [ 5 : 5 ] GC_CR_MTS_SCHEDULE9_CONTEXT_INTCTX                  = 1'h1;
localparam logic [ 7 : 6 ] GC_CR_MTS_SCHEDULE9_PRIORITY_BITFIELD               = 2'h0;
localparam logic [ 7 : 6 ] GC_CR_MTS_SCHEDULE9_PRIORITY_PRT0                   = 2'h0;
localparam logic [ 7 : 6 ] GC_CR_MTS_SCHEDULE9_PRIORITY_PRT1                   = 2'h1;
localparam logic [ 7 : 6 ] GC_CR_MTS_SCHEDULE9_PRIORITY_PRT2                   = 2'h2;
localparam logic [ 7 : 6 ] GC_CR_MTS_SCHEDULE9_PRIORITY_PRT3                   = 2'h3;
localparam logic [ 8 : 8 ] GC_CR_MTS_SCHEDULE9_HOST_BITFIELD                   = 1'h0;
localparam logic [ 8 : 8 ] GC_CR_MTS_SCHEDULE9_HOST_BG_TIMER                   = 1'h0;
localparam logic [ 8 : 8 ] GC_CR_MTS_SCHEDULE9_HOST_HOST                       = 1'h1;

 // gc_cr_mts_schedule10
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE10_DM_BITFIELD                    = 4'h0;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE10_DM_DM0                         = 4'h0;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE10_DM_DM1                         = 4'h1;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE10_DM_DM2                         = 4'h2;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE10_DM_DM3                         = 4'h3;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE10_DM_DM4                         = 4'h4;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE10_DM_DM5                         = 4'h5;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE10_DM_DM6                         = 4'h6;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE10_DM_DM7                         = 4'h7;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE10_DM_DM_ALL                      = 4'hf;
localparam logic [ 4 : 4 ] GC_CR_MTS_SCHEDULE10_TASK_BITFIELD                  = 1'h0;
localparam logic [ 4 : 4 ] GC_CR_MTS_SCHEDULE10_TASK_NON_COUNTED               = 1'h0;
localparam logic [ 4 : 4 ] GC_CR_MTS_SCHEDULE10_TASK_COUNTED                   = 1'h1;
localparam logic [ 5 : 5 ] GC_CR_MTS_SCHEDULE10_CONTEXT_BITFIELD               = 1'h0;
localparam logic [ 5 : 5 ] GC_CR_MTS_SCHEDULE10_CONTEXT_BGCTX                  = 1'h0;
localparam logic [ 5 : 5 ] GC_CR_MTS_SCHEDULE10_CONTEXT_INTCTX                 = 1'h1;
localparam logic [ 7 : 6 ] GC_CR_MTS_SCHEDULE10_PRIORITY_BITFIELD              = 2'h0;
localparam logic [ 7 : 6 ] GC_CR_MTS_SCHEDULE10_PRIORITY_PRT0                  = 2'h0;
localparam logic [ 7 : 6 ] GC_CR_MTS_SCHEDULE10_PRIORITY_PRT1                  = 2'h1;
localparam logic [ 7 : 6 ] GC_CR_MTS_SCHEDULE10_PRIORITY_PRT2                  = 2'h2;
localparam logic [ 7 : 6 ] GC_CR_MTS_SCHEDULE10_PRIORITY_PRT3                  = 2'h3;
localparam logic [ 8 : 8 ] GC_CR_MTS_SCHEDULE10_HOST_BITFIELD                  = 1'h0;
localparam logic [ 8 : 8 ] GC_CR_MTS_SCHEDULE10_HOST_BG_TIMER                  = 1'h0;
localparam logic [ 8 : 8 ] GC_CR_MTS_SCHEDULE10_HOST_HOST                      = 1'h1;

 // gc_cr_mts_schedule11
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE11_DM_BITFIELD                    = 4'h0;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE11_DM_DM0                         = 4'h0;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE11_DM_DM1                         = 4'h1;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE11_DM_DM2                         = 4'h2;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE11_DM_DM3                         = 4'h3;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE11_DM_DM4                         = 4'h4;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE11_DM_DM5                         = 4'h5;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE11_DM_DM6                         = 4'h6;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE11_DM_DM7                         = 4'h7;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE11_DM_DM_ALL                      = 4'hf;
localparam logic [ 4 : 4 ] GC_CR_MTS_SCHEDULE11_TASK_BITFIELD                  = 1'h0;
localparam logic [ 4 : 4 ] GC_CR_MTS_SCHEDULE11_TASK_NON_COUNTED               = 1'h0;
localparam logic [ 4 : 4 ] GC_CR_MTS_SCHEDULE11_TASK_COUNTED                   = 1'h1;
localparam logic [ 5 : 5 ] GC_CR_MTS_SCHEDULE11_CONTEXT_BITFIELD               = 1'h0;
localparam logic [ 5 : 5 ] GC_CR_MTS_SCHEDULE11_CONTEXT_BGCTX                  = 1'h0;
localparam logic [ 5 : 5 ] GC_CR_MTS_SCHEDULE11_CONTEXT_INTCTX                 = 1'h1;
localparam logic [ 7 : 6 ] GC_CR_MTS_SCHEDULE11_PRIORITY_BITFIELD              = 2'h0;
localparam logic [ 7 : 6 ] GC_CR_MTS_SCHEDULE11_PRIORITY_PRT0                  = 2'h0;
localparam logic [ 7 : 6 ] GC_CR_MTS_SCHEDULE11_PRIORITY_PRT1                  = 2'h1;
localparam logic [ 7 : 6 ] GC_CR_MTS_SCHEDULE11_PRIORITY_PRT2                  = 2'h2;
localparam logic [ 7 : 6 ] GC_CR_MTS_SCHEDULE11_PRIORITY_PRT3                  = 2'h3;
localparam logic [ 8 : 8 ] GC_CR_MTS_SCHEDULE11_HOST_BITFIELD                  = 1'h0;
localparam logic [ 8 : 8 ] GC_CR_MTS_SCHEDULE11_HOST_BG_TIMER                  = 1'h0;
localparam logic [ 8 : 8 ] GC_CR_MTS_SCHEDULE11_HOST_HOST                      = 1'h1;

 // gc_cr_mts_schedule12
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE12_DM_BITFIELD                    = 4'h0;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE12_DM_DM0                         = 4'h0;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE12_DM_DM1                         = 4'h1;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE12_DM_DM2                         = 4'h2;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE12_DM_DM3                         = 4'h3;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE12_DM_DM4                         = 4'h4;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE12_DM_DM5                         = 4'h5;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE12_DM_DM6                         = 4'h6;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE12_DM_DM7                         = 4'h7;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE12_DM_DM_ALL                      = 4'hf;
localparam logic [ 4 : 4 ] GC_CR_MTS_SCHEDULE12_TASK_BITFIELD                  = 1'h0;
localparam logic [ 4 : 4 ] GC_CR_MTS_SCHEDULE12_TASK_NON_COUNTED               = 1'h0;
localparam logic [ 4 : 4 ] GC_CR_MTS_SCHEDULE12_TASK_COUNTED                   = 1'h1;
localparam logic [ 5 : 5 ] GC_CR_MTS_SCHEDULE12_CONTEXT_BITFIELD               = 1'h0;
localparam logic [ 5 : 5 ] GC_CR_MTS_SCHEDULE12_CONTEXT_BGCTX                  = 1'h0;
localparam logic [ 5 : 5 ] GC_CR_MTS_SCHEDULE12_CONTEXT_INTCTX                 = 1'h1;
localparam logic [ 7 : 6 ] GC_CR_MTS_SCHEDULE12_PRIORITY_BITFIELD              = 2'h0;
localparam logic [ 7 : 6 ] GC_CR_MTS_SCHEDULE12_PRIORITY_PRT0                  = 2'h0;
localparam logic [ 7 : 6 ] GC_CR_MTS_SCHEDULE12_PRIORITY_PRT1                  = 2'h1;
localparam logic [ 7 : 6 ] GC_CR_MTS_SCHEDULE12_PRIORITY_PRT2                  = 2'h2;
localparam logic [ 7 : 6 ] GC_CR_MTS_SCHEDULE12_PRIORITY_PRT3                  = 2'h3;
localparam logic [ 8 : 8 ] GC_CR_MTS_SCHEDULE12_HOST_BITFIELD                  = 1'h0;
localparam logic [ 8 : 8 ] GC_CR_MTS_SCHEDULE12_HOST_BG_TIMER                  = 1'h0;
localparam logic [ 8 : 8 ] GC_CR_MTS_SCHEDULE12_HOST_HOST                      = 1'h1;

 // gc_cr_mts_schedule13
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE13_DM_BITFIELD                    = 4'h0;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE13_DM_DM0                         = 4'h0;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE13_DM_DM1                         = 4'h1;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE13_DM_DM2                         = 4'h2;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE13_DM_DM3                         = 4'h3;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE13_DM_DM4                         = 4'h4;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE13_DM_DM5                         = 4'h5;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE13_DM_DM6                         = 4'h6;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE13_DM_DM7                         = 4'h7;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE13_DM_DM_ALL                      = 4'hf;
localparam logic [ 4 : 4 ] GC_CR_MTS_SCHEDULE13_TASK_BITFIELD                  = 1'h0;
localparam logic [ 4 : 4 ] GC_CR_MTS_SCHEDULE13_TASK_NON_COUNTED               = 1'h0;
localparam logic [ 4 : 4 ] GC_CR_MTS_SCHEDULE13_TASK_COUNTED                   = 1'h1;
localparam logic [ 5 : 5 ] GC_CR_MTS_SCHEDULE13_CONTEXT_BITFIELD               = 1'h0;
localparam logic [ 5 : 5 ] GC_CR_MTS_SCHEDULE13_CONTEXT_BGCTX                  = 1'h0;
localparam logic [ 5 : 5 ] GC_CR_MTS_SCHEDULE13_CONTEXT_INTCTX                 = 1'h1;
localparam logic [ 7 : 6 ] GC_CR_MTS_SCHEDULE13_PRIORITY_BITFIELD              = 2'h0;
localparam logic [ 7 : 6 ] GC_CR_MTS_SCHEDULE13_PRIORITY_PRT0                  = 2'h0;
localparam logic [ 7 : 6 ] GC_CR_MTS_SCHEDULE13_PRIORITY_PRT1                  = 2'h1;
localparam logic [ 7 : 6 ] GC_CR_MTS_SCHEDULE13_PRIORITY_PRT2                  = 2'h2;
localparam logic [ 7 : 6 ] GC_CR_MTS_SCHEDULE13_PRIORITY_PRT3                  = 2'h3;
localparam logic [ 8 : 8 ] GC_CR_MTS_SCHEDULE13_HOST_BITFIELD                  = 1'h0;
localparam logic [ 8 : 8 ] GC_CR_MTS_SCHEDULE13_HOST_BG_TIMER                  = 1'h0;
localparam logic [ 8 : 8 ] GC_CR_MTS_SCHEDULE13_HOST_HOST                      = 1'h1;

 // gc_cr_mts_schedule14
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE14_DM_BITFIELD                    = 4'h0;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE14_DM_DM0                         = 4'h0;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE14_DM_DM1                         = 4'h1;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE14_DM_DM2                         = 4'h2;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE14_DM_DM3                         = 4'h3;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE14_DM_DM4                         = 4'h4;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE14_DM_DM5                         = 4'h5;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE14_DM_DM6                         = 4'h6;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE14_DM_DM7                         = 4'h7;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE14_DM_DM_ALL                      = 4'hf;
localparam logic [ 4 : 4 ] GC_CR_MTS_SCHEDULE14_TASK_BITFIELD                  = 1'h0;
localparam logic [ 4 : 4 ] GC_CR_MTS_SCHEDULE14_TASK_NON_COUNTED               = 1'h0;
localparam logic [ 4 : 4 ] GC_CR_MTS_SCHEDULE14_TASK_COUNTED                   = 1'h1;
localparam logic [ 5 : 5 ] GC_CR_MTS_SCHEDULE14_CONTEXT_BITFIELD               = 1'h0;
localparam logic [ 5 : 5 ] GC_CR_MTS_SCHEDULE14_CONTEXT_BGCTX                  = 1'h0;
localparam logic [ 5 : 5 ] GC_CR_MTS_SCHEDULE14_CONTEXT_INTCTX                 = 1'h1;
localparam logic [ 7 : 6 ] GC_CR_MTS_SCHEDULE14_PRIORITY_BITFIELD              = 2'h0;
localparam logic [ 7 : 6 ] GC_CR_MTS_SCHEDULE14_PRIORITY_PRT0                  = 2'h0;
localparam logic [ 7 : 6 ] GC_CR_MTS_SCHEDULE14_PRIORITY_PRT1                  = 2'h1;
localparam logic [ 7 : 6 ] GC_CR_MTS_SCHEDULE14_PRIORITY_PRT2                  = 2'h2;
localparam logic [ 7 : 6 ] GC_CR_MTS_SCHEDULE14_PRIORITY_PRT3                  = 2'h3;
localparam logic [ 8 : 8 ] GC_CR_MTS_SCHEDULE14_HOST_BITFIELD                  = 1'h0;
localparam logic [ 8 : 8 ] GC_CR_MTS_SCHEDULE14_HOST_BG_TIMER                  = 1'h0;
localparam logic [ 8 : 8 ] GC_CR_MTS_SCHEDULE14_HOST_HOST                      = 1'h1;

 // gc_cr_mts_schedule15
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE15_DM_BITFIELD                    = 4'h0;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE15_DM_DM0                         = 4'h0;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE15_DM_DM1                         = 4'h1;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE15_DM_DM2                         = 4'h2;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE15_DM_DM3                         = 4'h3;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE15_DM_DM4                         = 4'h4;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE15_DM_DM5                         = 4'h5;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE15_DM_DM6                         = 4'h6;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE15_DM_DM7                         = 4'h7;
localparam logic [ 3 : 0 ] GC_CR_MTS_SCHEDULE15_DM_DM_ALL                      = 4'hf;
localparam logic [ 4 : 4 ] GC_CR_MTS_SCHEDULE15_TASK_BITFIELD                  = 1'h0;
localparam logic [ 4 : 4 ] GC_CR_MTS_SCHEDULE15_TASK_NON_COUNTED               = 1'h0;
localparam logic [ 4 : 4 ] GC_CR_MTS_SCHEDULE15_TASK_COUNTED                   = 1'h1;
localparam logic [ 5 : 5 ] GC_CR_MTS_SCHEDULE15_CONTEXT_BITFIELD               = 1'h0;
localparam logic [ 5 : 5 ] GC_CR_MTS_SCHEDULE15_CONTEXT_BGCTX                  = 1'h0;
localparam logic [ 5 : 5 ] GC_CR_MTS_SCHEDULE15_CONTEXT_INTCTX                 = 1'h1;
localparam logic [ 7 : 6 ] GC_CR_MTS_SCHEDULE15_PRIORITY_BITFIELD              = 2'h0;
localparam logic [ 7 : 6 ] GC_CR_MTS_SCHEDULE15_PRIORITY_PRT0                  = 2'h0;
localparam logic [ 7 : 6 ] GC_CR_MTS_SCHEDULE15_PRIORITY_PRT1                  = 2'h1;
localparam logic [ 7 : 6 ] GC_CR_MTS_SCHEDULE15_PRIORITY_PRT2                  = 2'h2;
localparam logic [ 7 : 6 ] GC_CR_MTS_SCHEDULE15_PRIORITY_PRT3                  = 2'h3;
localparam logic [ 8 : 8 ] GC_CR_MTS_SCHEDULE15_HOST_BITFIELD                  = 1'h0;
localparam logic [ 8 : 8 ] GC_CR_MTS_SCHEDULE15_HOST_BG_TIMER                  = 1'h0;
localparam logic [ 8 : 8 ] GC_CR_MTS_SCHEDULE15_HOST_HOST                      = 1'h1;

 // gc_cr_mts_proc_complete
localparam logic [ 0 : 0 ] GC_CR_MTS_PROC_COMPLETE_THREAD_BITFIELD             = 1'h0;
localparam logic [ 1 : 1 ] GC_CR_MTS_PROC_COMPLETE_CONTEXT_BITFIELD            = 1'h0;
localparam logic [ 1 : 1 ] GC_CR_MTS_PROC_COMPLETE_CONTEXT_BGCTX               = 1'h0;
localparam logic [ 1 : 1 ] GC_CR_MTS_PROC_COMPLETE_CONTEXT_INTCTX              = 1'h1;

 // gc_cr_mts_bgctx_sbdata0
localparam logic [ 3 : 0 ] GC_CR_MTS_BGCTX_SBDATA0_DM_BITFIELD                 = 4'h0;
localparam logic [ 3 : 0 ] GC_CR_MTS_BGCTX_SBDATA0_DM_DM0                      = 4'h0;
localparam logic [ 3 : 0 ] GC_CR_MTS_BGCTX_SBDATA0_DM_DM1                      = 4'h1;
localparam logic [ 3 : 0 ] GC_CR_MTS_BGCTX_SBDATA0_DM_DM2                      = 4'h2;
localparam logic [ 3 : 0 ] GC_CR_MTS_BGCTX_SBDATA0_DM_DM3                      = 4'h3;
localparam logic [ 3 : 0 ] GC_CR_MTS_BGCTX_SBDATA0_DM_DM4                      = 4'h4;
localparam logic [ 3 : 0 ] GC_CR_MTS_BGCTX_SBDATA0_DM_DM5                      = 4'h5;
localparam logic [ 3 : 0 ] GC_CR_MTS_BGCTX_SBDATA0_DM_DM6                      = 4'h6;
localparam logic [ 3 : 0 ] GC_CR_MTS_BGCTX_SBDATA0_DM_DM7                      = 4'h7;
localparam logic [ 3 : 0 ] GC_CR_MTS_BGCTX_SBDATA0_DM_DM_ALL                   = 4'hf;
localparam logic [ 4 : 4 ] GC_CR_MTS_BGCTX_SBDATA0_TASK_BITFIELD               = 1'h0;
localparam logic [ 4 : 4 ] GC_CR_MTS_BGCTX_SBDATA0_TASK_NON_COUNTED            = 1'h0;
localparam logic [ 4 : 4 ] GC_CR_MTS_BGCTX_SBDATA0_TASK_COUNTED                = 1'h1;
localparam logic [ 5 : 5 ] GC_CR_MTS_BGCTX_SBDATA0_THREAD_ACTIVE_BITFIELD      = 1'h0;
localparam logic [ 9 : 6 ] GC_CR_MTS_BGCTX_SBDATA0_OS_ID_BITFIELD              = 4'h0;

 // gc_cr_mts_bgctx_sbdata1
localparam logic [ 3 : 0 ] GC_CR_MTS_BGCTX_SBDATA1_DM_BITFIELD                 = 4'h0;
localparam logic [ 3 : 0 ] GC_CR_MTS_BGCTX_SBDATA1_DM_DM0                      = 4'h0;
localparam logic [ 3 : 0 ] GC_CR_MTS_BGCTX_SBDATA1_DM_DM1                      = 4'h1;
localparam logic [ 3 : 0 ] GC_CR_MTS_BGCTX_SBDATA1_DM_DM2                      = 4'h2;
localparam logic [ 3 : 0 ] GC_CR_MTS_BGCTX_SBDATA1_DM_DM3                      = 4'h3;
localparam logic [ 3 : 0 ] GC_CR_MTS_BGCTX_SBDATA1_DM_DM4                      = 4'h4;
localparam logic [ 3 : 0 ] GC_CR_MTS_BGCTX_SBDATA1_DM_DM5                      = 4'h5;
localparam logic [ 3 : 0 ] GC_CR_MTS_BGCTX_SBDATA1_DM_DM6                      = 4'h6;
localparam logic [ 3 : 0 ] GC_CR_MTS_BGCTX_SBDATA1_DM_DM7                      = 4'h7;
localparam logic [ 3 : 0 ] GC_CR_MTS_BGCTX_SBDATA1_DM_DM_ALL                   = 4'hf;
localparam logic [ 4 : 4 ] GC_CR_MTS_BGCTX_SBDATA1_TASK_BITFIELD               = 1'h0;
localparam logic [ 4 : 4 ] GC_CR_MTS_BGCTX_SBDATA1_TASK_NON_COUNTED            = 1'h0;
localparam logic [ 4 : 4 ] GC_CR_MTS_BGCTX_SBDATA1_TASK_COUNTED                = 1'h1;
localparam logic [ 5 : 5 ] GC_CR_MTS_BGCTX_SBDATA1_THREAD_ACTIVE_BITFIELD      = 1'h0;
localparam logic [ 9 : 6 ] GC_CR_MTS_BGCTX_SBDATA1_OS_ID_BITFIELD              = 4'h0;

 // gc_cr_mts_intctx_sbdata0
localparam logic [ 1 : 0 ] GC_CR_MTS_INTCTX_SBDATA0_INT_TASK_BITFIELD          = 2'h0;
localparam logic [ 1 : 0 ] GC_CR_MTS_INTCTX_SBDATA0_INT_TASK_INT0              = 2'h0;
localparam logic [ 1 : 0 ] GC_CR_MTS_INTCTX_SBDATA0_INT_TASK_INT1              = 2'h1;
localparam logic [ 1 : 0 ] GC_CR_MTS_INTCTX_SBDATA0_INT_TASK_INT2              = 2'h2;
localparam logic [ 1 : 0 ] GC_CR_MTS_INTCTX_SBDATA0_INT_TASK_INT3              = 2'h3;
localparam logic [ 5 : 2 ] GC_CR_MTS_INTCTX_SBDATA0_DM_BITFIELD                = 4'h0;
localparam logic [ 5 : 2 ] GC_CR_MTS_INTCTX_SBDATA0_DM_DM0                     = 4'h0;
localparam logic [ 5 : 2 ] GC_CR_MTS_INTCTX_SBDATA0_DM_DM1                     = 4'h1;
localparam logic [ 5 : 2 ] GC_CR_MTS_INTCTX_SBDATA0_DM_DM2                     = 4'h2;
localparam logic [ 5 : 2 ] GC_CR_MTS_INTCTX_SBDATA0_DM_DM3                     = 4'h3;
localparam logic [ 5 : 2 ] GC_CR_MTS_INTCTX_SBDATA0_DM_DM4                     = 4'h4;
localparam logic [ 5 : 2 ] GC_CR_MTS_INTCTX_SBDATA0_DM_DM5                     = 4'h5;
localparam logic [ 5 : 2 ] GC_CR_MTS_INTCTX_SBDATA0_DM_DM6                     = 4'h6;
localparam logic [ 5 : 2 ] GC_CR_MTS_INTCTX_SBDATA0_DM_DM7                     = 4'h7;
localparam logic [ 5 : 2 ] GC_CR_MTS_INTCTX_SBDATA0_DM_DM_ALL                  = 4'hf;
localparam logic [ 37 : 6 ] GC_CR_MTS_INTCTX_SBDATA0_INT_STATUS_BITFIELD       = 32'h0;
localparam logic [ 38 : 38 ] GC_CR_MTS_INTCTX_SBDATA0_THREAD_ACTIVE_BITFIELD   = 1'h0;
localparam logic [ 42 : 39 ] GC_CR_MTS_INTCTX_SBDATA0_OS_ID_BITFIELD           = 4'h0;

 // gc_cr_mts_intctx_sbdata1
localparam logic [ 1 : 0 ] GC_CR_MTS_INTCTX_SBDATA1_INT_TASK_BITFIELD          = 2'h0;
localparam logic [ 1 : 0 ] GC_CR_MTS_INTCTX_SBDATA1_INT_TASK_INT0              = 2'h0;
localparam logic [ 1 : 0 ] GC_CR_MTS_INTCTX_SBDATA1_INT_TASK_INT1              = 2'h1;
localparam logic [ 1 : 0 ] GC_CR_MTS_INTCTX_SBDATA1_INT_TASK_INT2              = 2'h2;
localparam logic [ 1 : 0 ] GC_CR_MTS_INTCTX_SBDATA1_INT_TASK_INT3              = 2'h3;
localparam logic [ 5 : 2 ] GC_CR_MTS_INTCTX_SBDATA1_DM_BITFIELD                = 4'h0;
localparam logic [ 5 : 2 ] GC_CR_MTS_INTCTX_SBDATA1_DM_DM0                     = 4'h0;
localparam logic [ 5 : 2 ] GC_CR_MTS_INTCTX_SBDATA1_DM_DM1                     = 4'h1;
localparam logic [ 5 : 2 ] GC_CR_MTS_INTCTX_SBDATA1_DM_DM2                     = 4'h2;
localparam logic [ 5 : 2 ] GC_CR_MTS_INTCTX_SBDATA1_DM_DM3                     = 4'h3;
localparam logic [ 5 : 2 ] GC_CR_MTS_INTCTX_SBDATA1_DM_DM4                     = 4'h4;
localparam logic [ 5 : 2 ] GC_CR_MTS_INTCTX_SBDATA1_DM_DM5                     = 4'h5;
localparam logic [ 5 : 2 ] GC_CR_MTS_INTCTX_SBDATA1_DM_DM6                     = 4'h6;
localparam logic [ 5 : 2 ] GC_CR_MTS_INTCTX_SBDATA1_DM_DM7                     = 4'h7;
localparam logic [ 5 : 2 ] GC_CR_MTS_INTCTX_SBDATA1_DM_DM_ALL                  = 4'hf;
localparam logic [ 37 : 6 ] GC_CR_MTS_INTCTX_SBDATA1_INT_STATUS_BITFIELD       = 32'h0;
localparam logic [ 38 : 38 ] GC_CR_MTS_INTCTX_SBDATA1_THREAD_ACTIVE_BITFIELD   = 1'h0;
localparam logic [ 42 : 39 ] GC_CR_MTS_INTCTX_SBDATA1_OS_ID_BITFIELD           = 4'h0;

 // gc_cr_mts_bgctx_thread0_dm_assoc
localparam logic [ 15 : 0 ] GC_CR_MTS_BGCTX_THREAD0_DM_ASSOC_DM_ASSOC_BITFIELD  = 16'h0;

 // gc_cr_mts_intctx_thread0_dm_assoc
localparam logic [ 15 : 0 ] GC_CR_MTS_INTCTX_THREAD0_DM_ASSOC_DM_ASSOC_BITFIELD  = 16'h0;

 // gc_cr_mts_fwtop_wrapper_config
localparam logic [ 0 : 0 ] GC_CR_MTS_FWTOP_WRAPPER_CONFIG_IDLE_CTRL_BITFIELD   = 1'h1;
localparam logic [ 0 : 0 ] GC_CR_MTS_FWTOP_WRAPPER_CONFIG_IDLE_CTRL_FWP        = 1'h0;
localparam logic [ 0 : 0 ] GC_CR_MTS_FWTOP_WRAPPER_CONFIG_IDLE_CTRL_MTS        = 1'h1;

 // gc_cr_mts_dm0_interrupt_enable
localparam logic [ 31 : 0 ] GC_CR_MTS_DM0_INTERRUPT_ENABLE_INT_ENABLE_BITFIELD  = 32'h0;

 // gc_cr_mts_dm1_interrupt_enable
localparam logic [ 31 : 0 ] GC_CR_MTS_DM1_INTERRUPT_ENABLE_INT_ENABLE_BITFIELD  = 32'h0;

 // gc_cr_mts_dm2_interrupt_enable
localparam logic [ 31 : 0 ] GC_CR_MTS_DM2_INTERRUPT_ENABLE_INT_ENABLE_BITFIELD  = 32'h0;

 // gc_cr_mts_dm3_interrupt_enable
localparam logic [ 31 : 0 ] GC_CR_MTS_DM3_INTERRUPT_ENABLE_INT_ENABLE_BITFIELD  = 32'h0;

 // gc_cr_mts_dm4_interrupt_enable
localparam logic [ 31 : 0 ] GC_CR_MTS_DM4_INTERRUPT_ENABLE_INT_ENABLE_BITFIELD  = 32'h0;

 // gc_cr_mts_dm5_interrupt_enable
localparam logic [ 31 : 0 ] GC_CR_MTS_DM5_INTERRUPT_ENABLE_INT_ENABLE_BITFIELD  = 32'h0;

 // gc_cr_mts_dm6_interrupt_enable
localparam logic [ 31 : 0 ] GC_CR_MTS_DM6_INTERRUPT_ENABLE_INT_ENABLE_BITFIELD  = 32'h0;

 // gc_cr_mts_dm7_interrupt_enable
localparam logic [ 31 : 0 ] GC_CR_MTS_DM7_INTERRUPT_ENABLE_INT_ENABLE_BITFIELD  = 32'h0;

 // gc_cr_mts_event_mask
localparam logic [ 31 : 0 ] GC_CR_MTS_EVENT_MASK_MASK_BITFIELD                 = 32'h0;

 // gc_cr_mts_event_clear
localparam logic [ 31 : 0 ] GC_CR_MTS_EVENT_CLEAR_CLEAR_BITFIELD               = 32'h0;

 // gc_cr_mts_intctx
localparam logic [ 7 : 0 ] GC_CR_MTS_INTCTX_DM_INTERRUPT_SCHEDULE_BITFIELD     = 8'h0;
localparam logic [ 15 : 8 ] GC_CR_MTS_INTCTX_DM_TIMER_SCHEDULE_BITFIELD        = 8'h0;
localparam logic [ 29 : 22 ] GC_CR_MTS_INTCTX_DM_HOST_SCHEDULE_BITFIELD        = 8'h0;

 // gc_cr_mts_intctx1
localparam logic [ 7 : 0 ] GC_CR_MTS_INTCTX1_DM_INTERRUPT_SCHEDULE_BITFIELD    = 8'h0;
localparam logic [ 15 : 8 ] GC_CR_MTS_INTCTX1_DM_TIMER_SCHEDULE_BITFIELD       = 8'h0;
localparam logic [ 29 : 22 ] GC_CR_MTS_INTCTX1_DM_HOST_SCHEDULE_BITFIELD       = 8'h0;

 // gc_cr_mts_intctx2
localparam logic [ 7 : 0 ] GC_CR_MTS_INTCTX2_DM_INTERRUPT_SCHEDULE_BITFIELD    = 8'h0;
localparam logic [ 15 : 8 ] GC_CR_MTS_INTCTX2_DM_TIMER_SCHEDULE_BITFIELD       = 8'h0;
localparam logic [ 29 : 22 ] GC_CR_MTS_INTCTX2_DM_HOST_SCHEDULE_BITFIELD       = 8'h0;

 // gc_cr_mts_intctx3
localparam logic [ 7 : 0 ] GC_CR_MTS_INTCTX3_DM_INTERRUPT_SCHEDULE_BITFIELD    = 8'h0;
localparam logic [ 15 : 8 ] GC_CR_MTS_INTCTX3_DM_TIMER_SCHEDULE_BITFIELD       = 8'h0;
localparam logic [ 29 : 22 ] GC_CR_MTS_INTCTX3_DM_HOST_SCHEDULE_BITFIELD       = 8'h0;

 // gc_cr_mts_intctx4
localparam logic [ 7 : 0 ] GC_CR_MTS_INTCTX4_DM_INTERRUPT_SCHEDULE_BITFIELD    = 8'h0;
localparam logic [ 15 : 8 ] GC_CR_MTS_INTCTX4_DM_TIMER_SCHEDULE_BITFIELD       = 8'h0;
localparam logic [ 29 : 22 ] GC_CR_MTS_INTCTX4_DM_HOST_SCHEDULE_BITFIELD       = 8'h0;

 // gc_cr_mts_intctx5
localparam logic [ 7 : 0 ] GC_CR_MTS_INTCTX5_DM_INTERRUPT_SCHEDULE_BITFIELD    = 8'h0;
localparam logic [ 15 : 8 ] GC_CR_MTS_INTCTX5_DM_TIMER_SCHEDULE_BITFIELD       = 8'h0;
localparam logic [ 29 : 22 ] GC_CR_MTS_INTCTX5_DM_HOST_SCHEDULE_BITFIELD       = 8'h0;

 // gc_cr_mts_intctx6
localparam logic [ 7 : 0 ] GC_CR_MTS_INTCTX6_DM_INTERRUPT_SCHEDULE_BITFIELD    = 8'h0;
localparam logic [ 15 : 8 ] GC_CR_MTS_INTCTX6_DM_TIMER_SCHEDULE_BITFIELD       = 8'h0;
localparam logic [ 29 : 22 ] GC_CR_MTS_INTCTX6_DM_HOST_SCHEDULE_BITFIELD       = 8'h0;

 // gc_cr_mts_intctx7
localparam logic [ 7 : 0 ] GC_CR_MTS_INTCTX7_DM_INTERRUPT_SCHEDULE_BITFIELD    = 8'h0;
localparam logic [ 15 : 8 ] GC_CR_MTS_INTCTX7_DM_TIMER_SCHEDULE_BITFIELD       = 8'h0;
localparam logic [ 29 : 22 ] GC_CR_MTS_INTCTX7_DM_HOST_SCHEDULE_BITFIELD       = 8'h0;

 // gc_cr_mts_intctx8
localparam logic [ 7 : 0 ] GC_CR_MTS_INTCTX8_DM_INTERRUPT_SCHEDULE_BITFIELD    = 8'h0;
localparam logic [ 15 : 8 ] GC_CR_MTS_INTCTX8_DM_TIMER_SCHEDULE_BITFIELD       = 8'h0;
localparam logic [ 29 : 22 ] GC_CR_MTS_INTCTX8_DM_HOST_SCHEDULE_BITFIELD       = 8'h0;

 // gc_cr_mts_intctx9
localparam logic [ 7 : 0 ] GC_CR_MTS_INTCTX9_DM_INTERRUPT_SCHEDULE_BITFIELD    = 8'h0;
localparam logic [ 15 : 8 ] GC_CR_MTS_INTCTX9_DM_TIMER_SCHEDULE_BITFIELD       = 8'h0;
localparam logic [ 29 : 22 ] GC_CR_MTS_INTCTX9_DM_HOST_SCHEDULE_BITFIELD       = 8'h0;

 // gc_cr_mts_intctx10
localparam logic [ 7 : 0 ] GC_CR_MTS_INTCTX10_DM_INTERRUPT_SCHEDULE_BITFIELD   = 8'h0;
localparam logic [ 15 : 8 ] GC_CR_MTS_INTCTX10_DM_TIMER_SCHEDULE_BITFIELD      = 8'h0;
localparam logic [ 29 : 22 ] GC_CR_MTS_INTCTX10_DM_HOST_SCHEDULE_BITFIELD      = 8'h0;

 // gc_cr_mts_intctx11
localparam logic [ 7 : 0 ] GC_CR_MTS_INTCTX11_DM_INTERRUPT_SCHEDULE_BITFIELD   = 8'h0;
localparam logic [ 15 : 8 ] GC_CR_MTS_INTCTX11_DM_TIMER_SCHEDULE_BITFIELD      = 8'h0;
localparam logic [ 29 : 22 ] GC_CR_MTS_INTCTX11_DM_HOST_SCHEDULE_BITFIELD      = 8'h0;

 // gc_cr_mts_intctx12
localparam logic [ 7 : 0 ] GC_CR_MTS_INTCTX12_DM_INTERRUPT_SCHEDULE_BITFIELD   = 8'h0;
localparam logic [ 15 : 8 ] GC_CR_MTS_INTCTX12_DM_TIMER_SCHEDULE_BITFIELD      = 8'h0;
localparam logic [ 29 : 22 ] GC_CR_MTS_INTCTX12_DM_HOST_SCHEDULE_BITFIELD      = 8'h0;

 // gc_cr_mts_intctx13
localparam logic [ 7 : 0 ] GC_CR_MTS_INTCTX13_DM_INTERRUPT_SCHEDULE_BITFIELD   = 8'h0;
localparam logic [ 15 : 8 ] GC_CR_MTS_INTCTX13_DM_TIMER_SCHEDULE_BITFIELD      = 8'h0;
localparam logic [ 29 : 22 ] GC_CR_MTS_INTCTX13_DM_HOST_SCHEDULE_BITFIELD      = 8'h0;

 // gc_cr_mts_intctx14
localparam logic [ 7 : 0 ] GC_CR_MTS_INTCTX14_DM_INTERRUPT_SCHEDULE_BITFIELD   = 8'h0;
localparam logic [ 15 : 8 ] GC_CR_MTS_INTCTX14_DM_TIMER_SCHEDULE_BITFIELD      = 8'h0;
localparam logic [ 29 : 22 ] GC_CR_MTS_INTCTX14_DM_HOST_SCHEDULE_BITFIELD      = 8'h0;

 // gc_cr_mts_intctx15
localparam logic [ 7 : 0 ] GC_CR_MTS_INTCTX15_DM_INTERRUPT_SCHEDULE_BITFIELD   = 8'h0;
localparam logic [ 15 : 8 ] GC_CR_MTS_INTCTX15_DM_TIMER_SCHEDULE_BITFIELD      = 8'h0;
localparam logic [ 29 : 22 ] GC_CR_MTS_INTCTX15_DM_HOST_SCHEDULE_BITFIELD      = 8'h0;

 // gc_cr_mts_bgctx
localparam logic [ 7 : 0 ] GC_CR_MTS_BGCTX_DM_NONCOUNTED_SCHEDULE_BITFIELD     = 8'h0;

 // gc_cr_mts_bgctx1
localparam logic [ 7 : 0 ] GC_CR_MTS_BGCTX1_DM_NONCOUNTED_SCHEDULE_BITFIELD    = 8'h0;

 // gc_cr_mts_bgctx2
localparam logic [ 7 : 0 ] GC_CR_MTS_BGCTX2_DM_NONCOUNTED_SCHEDULE_BITFIELD    = 8'h0;

 // gc_cr_mts_bgctx3
localparam logic [ 7 : 0 ] GC_CR_MTS_BGCTX3_DM_NONCOUNTED_SCHEDULE_BITFIELD    = 8'h0;

 // gc_cr_mts_bgctx4
localparam logic [ 7 : 0 ] GC_CR_MTS_BGCTX4_DM_NONCOUNTED_SCHEDULE_BITFIELD    = 8'h0;

 // gc_cr_mts_bgctx5
localparam logic [ 7 : 0 ] GC_CR_MTS_BGCTX5_DM_NONCOUNTED_SCHEDULE_BITFIELD    = 8'h0;

 // gc_cr_mts_bgctx6
localparam logic [ 7 : 0 ] GC_CR_MTS_BGCTX6_DM_NONCOUNTED_SCHEDULE_BITFIELD    = 8'h0;

 // gc_cr_mts_bgctx7
localparam logic [ 7 : 0 ] GC_CR_MTS_BGCTX7_DM_NONCOUNTED_SCHEDULE_BITFIELD    = 8'h0;

 // gc_cr_mts_bgctx8
localparam logic [ 7 : 0 ] GC_CR_MTS_BGCTX8_DM_NONCOUNTED_SCHEDULE_BITFIELD    = 8'h0;

 // gc_cr_mts_bgctx9
localparam logic [ 7 : 0 ] GC_CR_MTS_BGCTX9_DM_NONCOUNTED_SCHEDULE_BITFIELD    = 8'h0;

 // gc_cr_mts_bgctx10
localparam logic [ 7 : 0 ] GC_CR_MTS_BGCTX10_DM_NONCOUNTED_SCHEDULE_BITFIELD   = 8'h0;

 // gc_cr_mts_bgctx11
localparam logic [ 7 : 0 ] GC_CR_MTS_BGCTX11_DM_NONCOUNTED_SCHEDULE_BITFIELD   = 8'h0;

 // gc_cr_mts_bgctx12
localparam logic [ 7 : 0 ] GC_CR_MTS_BGCTX12_DM_NONCOUNTED_SCHEDULE_BITFIELD   = 8'h0;

 // gc_cr_mts_bgctx13
localparam logic [ 7 : 0 ] GC_CR_MTS_BGCTX13_DM_NONCOUNTED_SCHEDULE_BITFIELD   = 8'h0;

 // gc_cr_mts_bgctx14
localparam logic [ 7 : 0 ] GC_CR_MTS_BGCTX14_DM_NONCOUNTED_SCHEDULE_BITFIELD   = 8'h0;

 // gc_cr_mts_bgctx15
localparam logic [ 7 : 0 ] GC_CR_MTS_BGCTX15_DM_NONCOUNTED_SCHEDULE_BITFIELD   = 8'h0;

 // gc_cr_mts_bgctx_counted_schedule
localparam logic [ 7 : 0 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE_DM0_BITFIELD       = 8'h0;
localparam logic [ 15 : 8 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE_DM1_BITFIELD      = 8'h0;
localparam logic [ 23 : 16 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE_DM2_BITFIELD     = 8'h0;
localparam logic [ 31 : 24 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE_DM3_BITFIELD     = 8'h0;
localparam logic [ 39 : 32 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE_DM4_BITFIELD     = 8'h0;
localparam logic [ 47 : 40 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE_DM5_BITFIELD     = 8'h0;
localparam logic [ 55 : 48 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE_DM6_BITFIELD     = 8'h0;
localparam logic [ 63 : 56 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE_DM7_BITFIELD     = 8'h0;

 // gc_cr_mts_bgctx_counted_schedule1
localparam logic [ 7 : 0 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE1_DM0_BITFIELD      = 8'h0;
localparam logic [ 15 : 8 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE1_DM1_BITFIELD     = 8'h0;
localparam logic [ 23 : 16 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE1_DM2_BITFIELD    = 8'h0;
localparam logic [ 31 : 24 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE1_DM3_BITFIELD    = 8'h0;
localparam logic [ 39 : 32 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE1_DM4_BITFIELD    = 8'h0;
localparam logic [ 47 : 40 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE1_DM5_BITFIELD    = 8'h0;
localparam logic [ 55 : 48 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE1_DM6_BITFIELD    = 8'h0;
localparam logic [ 63 : 56 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE1_DM7_BITFIELD    = 8'h0;

 // gc_cr_mts_bgctx_counted_schedule2
localparam logic [ 7 : 0 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE2_DM0_BITFIELD      = 8'h0;
localparam logic [ 15 : 8 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE2_DM1_BITFIELD     = 8'h0;
localparam logic [ 23 : 16 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE2_DM2_BITFIELD    = 8'h0;
localparam logic [ 31 : 24 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE2_DM3_BITFIELD    = 8'h0;
localparam logic [ 39 : 32 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE2_DM4_BITFIELD    = 8'h0;
localparam logic [ 47 : 40 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE2_DM5_BITFIELD    = 8'h0;
localparam logic [ 55 : 48 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE2_DM6_BITFIELD    = 8'h0;
localparam logic [ 63 : 56 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE2_DM7_BITFIELD    = 8'h0;

 // gc_cr_mts_bgctx_counted_schedule3
localparam logic [ 7 : 0 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE3_DM0_BITFIELD      = 8'h0;
localparam logic [ 15 : 8 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE3_DM1_BITFIELD     = 8'h0;
localparam logic [ 23 : 16 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE3_DM2_BITFIELD    = 8'h0;
localparam logic [ 31 : 24 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE3_DM3_BITFIELD    = 8'h0;
localparam logic [ 39 : 32 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE3_DM4_BITFIELD    = 8'h0;
localparam logic [ 47 : 40 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE3_DM5_BITFIELD    = 8'h0;
localparam logic [ 55 : 48 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE3_DM6_BITFIELD    = 8'h0;
localparam logic [ 63 : 56 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE3_DM7_BITFIELD    = 8'h0;

 // gc_cr_mts_bgctx_counted_schedule4
localparam logic [ 7 : 0 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE4_DM0_BITFIELD      = 8'h0;
localparam logic [ 15 : 8 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE4_DM1_BITFIELD     = 8'h0;
localparam logic [ 23 : 16 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE4_DM2_BITFIELD    = 8'h0;
localparam logic [ 31 : 24 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE4_DM3_BITFIELD    = 8'h0;
localparam logic [ 39 : 32 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE4_DM4_BITFIELD    = 8'h0;
localparam logic [ 47 : 40 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE4_DM5_BITFIELD    = 8'h0;
localparam logic [ 55 : 48 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE4_DM6_BITFIELD    = 8'h0;
localparam logic [ 63 : 56 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE4_DM7_BITFIELD    = 8'h0;

 // gc_cr_mts_bgctx_counted_schedule5
localparam logic [ 7 : 0 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE5_DM0_BITFIELD      = 8'h0;
localparam logic [ 15 : 8 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE5_DM1_BITFIELD     = 8'h0;
localparam logic [ 23 : 16 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE5_DM2_BITFIELD    = 8'h0;
localparam logic [ 31 : 24 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE5_DM3_BITFIELD    = 8'h0;
localparam logic [ 39 : 32 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE5_DM4_BITFIELD    = 8'h0;
localparam logic [ 47 : 40 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE5_DM5_BITFIELD    = 8'h0;
localparam logic [ 55 : 48 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE5_DM6_BITFIELD    = 8'h0;
localparam logic [ 63 : 56 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE5_DM7_BITFIELD    = 8'h0;

 // gc_cr_mts_bgctx_counted_schedule6
localparam logic [ 7 : 0 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE6_DM0_BITFIELD      = 8'h0;
localparam logic [ 15 : 8 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE6_DM1_BITFIELD     = 8'h0;
localparam logic [ 23 : 16 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE6_DM2_BITFIELD    = 8'h0;
localparam logic [ 31 : 24 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE6_DM3_BITFIELD    = 8'h0;
localparam logic [ 39 : 32 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE6_DM4_BITFIELD    = 8'h0;
localparam logic [ 47 : 40 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE6_DM5_BITFIELD    = 8'h0;
localparam logic [ 55 : 48 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE6_DM6_BITFIELD    = 8'h0;
localparam logic [ 63 : 56 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE6_DM7_BITFIELD    = 8'h0;

 // gc_cr_mts_bgctx_counted_schedule7
localparam logic [ 7 : 0 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE7_DM0_BITFIELD      = 8'h0;
localparam logic [ 15 : 8 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE7_DM1_BITFIELD     = 8'h0;
localparam logic [ 23 : 16 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE7_DM2_BITFIELD    = 8'h0;
localparam logic [ 31 : 24 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE7_DM3_BITFIELD    = 8'h0;
localparam logic [ 39 : 32 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE7_DM4_BITFIELD    = 8'h0;
localparam logic [ 47 : 40 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE7_DM5_BITFIELD    = 8'h0;
localparam logic [ 55 : 48 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE7_DM6_BITFIELD    = 8'h0;
localparam logic [ 63 : 56 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE7_DM7_BITFIELD    = 8'h0;

 // gc_cr_mts_bgctx_counted_schedule8
localparam logic [ 7 : 0 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE8_DM0_BITFIELD      = 8'h0;
localparam logic [ 15 : 8 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE8_DM1_BITFIELD     = 8'h0;
localparam logic [ 23 : 16 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE8_DM2_BITFIELD    = 8'h0;
localparam logic [ 31 : 24 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE8_DM3_BITFIELD    = 8'h0;
localparam logic [ 39 : 32 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE8_DM4_BITFIELD    = 8'h0;
localparam logic [ 47 : 40 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE8_DM5_BITFIELD    = 8'h0;
localparam logic [ 55 : 48 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE8_DM6_BITFIELD    = 8'h0;
localparam logic [ 63 : 56 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE8_DM7_BITFIELD    = 8'h0;

 // gc_cr_mts_bgctx_counted_schedule9
localparam logic [ 7 : 0 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE9_DM0_BITFIELD      = 8'h0;
localparam logic [ 15 : 8 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE9_DM1_BITFIELD     = 8'h0;
localparam logic [ 23 : 16 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE9_DM2_BITFIELD    = 8'h0;
localparam logic [ 31 : 24 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE9_DM3_BITFIELD    = 8'h0;
localparam logic [ 39 : 32 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE9_DM4_BITFIELD    = 8'h0;
localparam logic [ 47 : 40 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE9_DM5_BITFIELD    = 8'h0;
localparam logic [ 55 : 48 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE9_DM6_BITFIELD    = 8'h0;
localparam logic [ 63 : 56 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE9_DM7_BITFIELD    = 8'h0;

 // gc_cr_mts_bgctx_counted_schedule10
localparam logic [ 7 : 0 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE10_DM0_BITFIELD     = 8'h0;
localparam logic [ 15 : 8 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE10_DM1_BITFIELD    = 8'h0;
localparam logic [ 23 : 16 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE10_DM2_BITFIELD   = 8'h0;
localparam logic [ 31 : 24 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE10_DM3_BITFIELD   = 8'h0;
localparam logic [ 39 : 32 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE10_DM4_BITFIELD   = 8'h0;
localparam logic [ 47 : 40 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE10_DM5_BITFIELD   = 8'h0;
localparam logic [ 55 : 48 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE10_DM6_BITFIELD   = 8'h0;
localparam logic [ 63 : 56 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE10_DM7_BITFIELD   = 8'h0;

 // gc_cr_mts_bgctx_counted_schedule11
localparam logic [ 7 : 0 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE11_DM0_BITFIELD     = 8'h0;
localparam logic [ 15 : 8 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE11_DM1_BITFIELD    = 8'h0;
localparam logic [ 23 : 16 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE11_DM2_BITFIELD   = 8'h0;
localparam logic [ 31 : 24 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE11_DM3_BITFIELD   = 8'h0;
localparam logic [ 39 : 32 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE11_DM4_BITFIELD   = 8'h0;
localparam logic [ 47 : 40 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE11_DM5_BITFIELD   = 8'h0;
localparam logic [ 55 : 48 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE11_DM6_BITFIELD   = 8'h0;
localparam logic [ 63 : 56 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE11_DM7_BITFIELD   = 8'h0;

 // gc_cr_mts_bgctx_counted_schedule12
localparam logic [ 7 : 0 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE12_DM0_BITFIELD     = 8'h0;
localparam logic [ 15 : 8 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE12_DM1_BITFIELD    = 8'h0;
localparam logic [ 23 : 16 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE12_DM2_BITFIELD   = 8'h0;
localparam logic [ 31 : 24 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE12_DM3_BITFIELD   = 8'h0;
localparam logic [ 39 : 32 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE12_DM4_BITFIELD   = 8'h0;
localparam logic [ 47 : 40 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE12_DM5_BITFIELD   = 8'h0;
localparam logic [ 55 : 48 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE12_DM6_BITFIELD   = 8'h0;
localparam logic [ 63 : 56 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE12_DM7_BITFIELD   = 8'h0;

 // gc_cr_mts_bgctx_counted_schedule13
localparam logic [ 7 : 0 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE13_DM0_BITFIELD     = 8'h0;
localparam logic [ 15 : 8 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE13_DM1_BITFIELD    = 8'h0;
localparam logic [ 23 : 16 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE13_DM2_BITFIELD   = 8'h0;
localparam logic [ 31 : 24 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE13_DM3_BITFIELD   = 8'h0;
localparam logic [ 39 : 32 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE13_DM4_BITFIELD   = 8'h0;
localparam logic [ 47 : 40 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE13_DM5_BITFIELD   = 8'h0;
localparam logic [ 55 : 48 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE13_DM6_BITFIELD   = 8'h0;
localparam logic [ 63 : 56 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE13_DM7_BITFIELD   = 8'h0;

 // gc_cr_mts_bgctx_counted_schedule14
localparam logic [ 7 : 0 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE14_DM0_BITFIELD     = 8'h0;
localparam logic [ 15 : 8 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE14_DM1_BITFIELD    = 8'h0;
localparam logic [ 23 : 16 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE14_DM2_BITFIELD   = 8'h0;
localparam logic [ 31 : 24 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE14_DM3_BITFIELD   = 8'h0;
localparam logic [ 39 : 32 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE14_DM4_BITFIELD   = 8'h0;
localparam logic [ 47 : 40 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE14_DM5_BITFIELD   = 8'h0;
localparam logic [ 55 : 48 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE14_DM6_BITFIELD   = 8'h0;
localparam logic [ 63 : 56 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE14_DM7_BITFIELD   = 8'h0;

 // gc_cr_mts_bgctx_counted_schedule15
localparam logic [ 7 : 0 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE15_DM0_BITFIELD     = 8'h0;
localparam logic [ 15 : 8 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE15_DM1_BITFIELD    = 8'h0;
localparam logic [ 23 : 16 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE15_DM2_BITFIELD   = 8'h0;
localparam logic [ 31 : 24 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE15_DM3_BITFIELD   = 8'h0;
localparam logic [ 39 : 32 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE15_DM4_BITFIELD   = 8'h0;
localparam logic [ 47 : 40 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE15_DM5_BITFIELD   = 8'h0;
localparam logic [ 55 : 48 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE15_DM6_BITFIELD   = 8'h0;
localparam logic [ 63 : 56 ] GC_CR_MTS_BGCTX_COUNTED_SCHEDULE15_DM7_BITFIELD   = 8'h0;

 // gc_cr_mts_gpu_int_status
localparam logic [ 31 : 0 ] GC_CR_MTS_GPU_INT_STATUS_STATUS_BITFIELD           = 32'h0;

 // gc_cr_mts_os_priority
localparam logic [ 1 : 0 ] GC_CR_MTS_OS_PRIORITY_ID0_BITFIELD                  = 2'h0;
localparam logic [ 3 : 2 ] GC_CR_MTS_OS_PRIORITY_ID1_BITFIELD                  = 2'h0;
localparam logic [ 5 : 4 ] GC_CR_MTS_OS_PRIORITY_ID2_BITFIELD                  = 2'h0;
localparam logic [ 7 : 6 ] GC_CR_MTS_OS_PRIORITY_ID3_BITFIELD                  = 2'h0;
localparam logic [ 9 : 8 ] GC_CR_MTS_OS_PRIORITY_ID4_BITFIELD                  = 2'h0;
localparam logic [ 11 : 10 ] GC_CR_MTS_OS_PRIORITY_ID5_BITFIELD                = 2'h0;
localparam logic [ 13 : 12 ] GC_CR_MTS_OS_PRIORITY_ID6_BITFIELD                = 2'h0;
localparam logic [ 15 : 14 ] GC_CR_MTS_OS_PRIORITY_ID7_BITFIELD                = 2'h0;
localparam logic [ 17 : 16 ] GC_CR_MTS_OS_PRIORITY_ID8_BITFIELD                = 2'h0;
localparam logic [ 19 : 18 ] GC_CR_MTS_OS_PRIORITY_ID9_BITFIELD                = 2'h0;
localparam logic [ 21 : 20 ] GC_CR_MTS_OS_PRIORITY_ID10_BITFIELD               = 2'h0;
localparam logic [ 23 : 22 ] GC_CR_MTS_OS_PRIORITY_ID11_BITFIELD               = 2'h0;
localparam logic [ 25 : 24 ] GC_CR_MTS_OS_PRIORITY_ID12_BITFIELD               = 2'h0;
localparam logic [ 27 : 26 ] GC_CR_MTS_OS_PRIORITY_ID13_BITFIELD               = 2'h0;
localparam logic [ 29 : 28 ] GC_CR_MTS_OS_PRIORITY_ID14_BITFIELD               = 2'h0;
localparam logic [ 31 : 30 ] GC_CR_MTS_OS_PRIORITY_ID15_BITFIELD               = 2'h0;

 // gc_cr_irq_os0_event_status
localparam logic [ 1 : 0 ] GC_CR_IRQ_OS0_EVENT_STATUS_SOURCE_BITFIELD          = 2'h0;

 // gc_cr_irq_os0_event_clear
localparam logic [ 1 : 0 ] GC_CR_IRQ_OS0_EVENT_CLEAR_SOURCE_BITFIELD           = 2'h0;

 // gc_cr_irq_os1_event_status
localparam logic [ 1 : 0 ] GC_CR_IRQ_OS1_EVENT_STATUS_SOURCE_BITFIELD          = 2'h0;

 // gc_cr_irq_os1_event_clear
localparam logic [ 1 : 0 ] GC_CR_IRQ_OS1_EVENT_CLEAR_SOURCE_BITFIELD           = 2'h0;

 // gc_cr_irq_os2_event_status
localparam logic [ 1 : 0 ] GC_CR_IRQ_OS2_EVENT_STATUS_SOURCE_BITFIELD          = 2'h0;

 // gc_cr_irq_os2_event_clear
localparam logic [ 1 : 0 ] GC_CR_IRQ_OS2_EVENT_CLEAR_SOURCE_BITFIELD           = 2'h0;

 // gc_cr_irq_os3_event_status
localparam logic [ 1 : 0 ] GC_CR_IRQ_OS3_EVENT_STATUS_SOURCE_BITFIELD          = 2'h0;

 // gc_cr_irq_os3_event_clear
localparam logic [ 1 : 0 ] GC_CR_IRQ_OS3_EVENT_CLEAR_SOURCE_BITFIELD           = 2'h0;

 // gc_cr_irq_os4_event_status
localparam logic [ 1 : 0 ] GC_CR_IRQ_OS4_EVENT_STATUS_SOURCE_BITFIELD          = 2'h0;

 // gc_cr_irq_os4_event_clear
localparam logic [ 1 : 0 ] GC_CR_IRQ_OS4_EVENT_CLEAR_SOURCE_BITFIELD           = 2'h0;

 // gc_cr_irq_os5_event_status
localparam logic [ 1 : 0 ] GC_CR_IRQ_OS5_EVENT_STATUS_SOURCE_BITFIELD          = 2'h0;

 // gc_cr_irq_os5_event_clear
localparam logic [ 1 : 0 ] GC_CR_IRQ_OS5_EVENT_CLEAR_SOURCE_BITFIELD           = 2'h0;

 // gc_cr_irq_os6_event_status
localparam logic [ 1 : 0 ] GC_CR_IRQ_OS6_EVENT_STATUS_SOURCE_BITFIELD          = 2'h0;

 // gc_cr_irq_os6_event_clear
localparam logic [ 1 : 0 ] GC_CR_IRQ_OS6_EVENT_CLEAR_SOURCE_BITFIELD           = 2'h0;

 // gc_cr_irq_os7_event_status
localparam logic [ 1 : 0 ] GC_CR_IRQ_OS7_EVENT_STATUS_SOURCE_BITFIELD          = 2'h0;

 // gc_cr_irq_os7_event_clear
localparam logic [ 1 : 0 ] GC_CR_IRQ_OS7_EVENT_CLEAR_SOURCE_BITFIELD           = 2'h0;

 // gc_cr_irq_os8_event_status
localparam logic [ 1 : 0 ] GC_CR_IRQ_OS8_EVENT_STATUS_SOURCE_BITFIELD          = 2'h0;

 // gc_cr_irq_os8_event_clear
localparam logic [ 1 : 0 ] GC_CR_IRQ_OS8_EVENT_CLEAR_SOURCE_BITFIELD           = 2'h0;

 // gc_cr_irq_os9_event_status
localparam logic [ 1 : 0 ] GC_CR_IRQ_OS9_EVENT_STATUS_SOURCE_BITFIELD          = 2'h0;

 // gc_cr_irq_os9_event_clear
localparam logic [ 1 : 0 ] GC_CR_IRQ_OS9_EVENT_CLEAR_SOURCE_BITFIELD           = 2'h0;

 // gc_cr_irq_os10_event_status
localparam logic [ 1 : 0 ] GC_CR_IRQ_OS10_EVENT_STATUS_SOURCE_BITFIELD         = 2'h0;

 // gc_cr_irq_os10_event_clear
localparam logic [ 1 : 0 ] GC_CR_IRQ_OS10_EVENT_CLEAR_SOURCE_BITFIELD          = 2'h0;

 // gc_cr_irq_os11_event_status
localparam logic [ 1 : 0 ] GC_CR_IRQ_OS11_EVENT_STATUS_SOURCE_BITFIELD         = 2'h0;

 // gc_cr_irq_os11_event_clear
localparam logic [ 1 : 0 ] GC_CR_IRQ_OS11_EVENT_CLEAR_SOURCE_BITFIELD          = 2'h0;

 // gc_cr_irq_os12_event_status
localparam logic [ 1 : 0 ] GC_CR_IRQ_OS12_EVENT_STATUS_SOURCE_BITFIELD         = 2'h0;

 // gc_cr_irq_os12_event_clear
localparam logic [ 1 : 0 ] GC_CR_IRQ_OS12_EVENT_CLEAR_SOURCE_BITFIELD          = 2'h0;

 // gc_cr_irq_os13_event_status
localparam logic [ 1 : 0 ] GC_CR_IRQ_OS13_EVENT_STATUS_SOURCE_BITFIELD         = 2'h0;

 // gc_cr_irq_os13_event_clear
localparam logic [ 1 : 0 ] GC_CR_IRQ_OS13_EVENT_CLEAR_SOURCE_BITFIELD          = 2'h0;

 // gc_cr_irq_os14_event_status
localparam logic [ 1 : 0 ] GC_CR_IRQ_OS14_EVENT_STATUS_SOURCE_BITFIELD         = 2'h0;

 // gc_cr_irq_os14_event_clear
localparam logic [ 1 : 0 ] GC_CR_IRQ_OS14_EVENT_CLEAR_SOURCE_BITFIELD          = 2'h0;

 // gc_cr_irq_os15_event_status
localparam logic [ 1 : 0 ] GC_CR_IRQ_OS15_EVENT_STATUS_SOURCE_BITFIELD         = 2'h0;

 // gc_cr_irq_os15_event_clear
localparam logic [ 1 : 0 ] GC_CR_IRQ_OS15_EVENT_CLEAR_SOURCE_BITFIELD          = 2'h0;

 // gc_cr_mts_schedule_enable
localparam logic [ 15 : 0 ] GC_CR_MTS_SCHEDULE_ENABLE_MASK_BITFIELD            = 16'hffff;

 // gc_cr_host_irq
localparam logic [ 3 : 0 ] GC_CR_HOST_IRQ_OSID_BITFIELD                        = 4'h0;
localparam logic [ 4 : 4 ] GC_CR_HOST_IRQ_SOURCE_BITFIELD                      = 1'h0;

 // gc_cr_fwp_boot
localparam logic [ 0 : 0 ] GC_CR_FWP_BOOT_MODE_BITFIELD                        = 1'h0;

 // gc_cr_dma_param0_ch0
localparam logic [ 0 : 0 ] GC_CR_DMA_PARAM0_CH0_INTERRUPT_WHEN_DONE_BITFIELD   = 1'h0;
localparam logic [ 3 : 3 ] GC_CR_DMA_PARAM0_CH0_PROGRAM_REGISTERS_BITFIELD     = 1'h0;
localparam logic [ 4 : 4 ] GC_CR_DMA_PARAM0_CH0_DIRECTION_BITFIELD             = 1'h0;
localparam logic [ 31 : 5 ] GC_CR_DMA_PARAM0_CH0_VIRTUAL_ADDR_LSBS_BITFIELD    = 27'h0;

 // gc_cr_dma_param0_ch1
localparam logic [ 0 : 0 ] GC_CR_DMA_PARAM0_CH1_INTERRUPT_WHEN_DONE_BITFIELD   = 1'h0;
localparam logic [ 3 : 3 ] GC_CR_DMA_PARAM0_CH1_PROGRAM_REGISTERS_BITFIELD     = 1'h0;
localparam logic [ 4 : 4 ] GC_CR_DMA_PARAM0_CH1_DIRECTION_BITFIELD             = 1'h0;
localparam logic [ 31 : 5 ] GC_CR_DMA_PARAM0_CH1_VIRTUAL_ADDR_LSBS_BITFIELD    = 27'h0;

 // gc_cr_dma_param1_ch0
localparam logic [ 15 : 0 ] GC_CR_DMA_PARAM1_CH0_VIRTUAL_ADDR_MSBS_BITFIELD    = 16'h0;
localparam logic [ 31 : 16 ] GC_CR_DMA_PARAM1_CH0_BLOCK_SIZE_BITFIELD          = 16'h0;

 // gc_cr_dma_param1_ch1
localparam logic [ 15 : 0 ] GC_CR_DMA_PARAM1_CH1_VIRTUAL_ADDR_MSBS_BITFIELD    = 16'h0;
localparam logic [ 31 : 16 ] GC_CR_DMA_PARAM1_CH1_BLOCK_SIZE_BITFIELD          = 16'h0;

 // gc_cr_dma_param2_ch0
localparam logic [ 14 : 0 ] GC_CR_DMA_PARAM2_CH0_CORE_MEM_ADDR_BITFIELD        = 15'h0;
localparam logic [ 15 : 15 ] GC_CR_DMA_PARAM2_CH0_MEM_SEL_BITFIELD             = 1'h0;
localparam logic [ 23 : 16 ] GC_CR_DMA_PARAM2_CH0_MMU_CONTEXT_BITFIELD         = 8'h0;
localparam logic [ 31 : 24 ] GC_CR_DMA_PARAM2_CH0_TRANSFER_ID_BITFIELD         = 8'h0;

 // gc_cr_dma_param2_ch1
localparam logic [ 14 : 0 ] GC_CR_DMA_PARAM2_CH1_CORE_MEM_ADDR_BITFIELD        = 15'h0;
localparam logic [ 15 : 15 ] GC_CR_DMA_PARAM2_CH1_MEM_SEL_BITFIELD             = 1'h0;
localparam logic [ 23 : 16 ] GC_CR_DMA_PARAM2_CH1_MMU_CONTEXT_BITFIELD         = 8'h0;
localparam logic [ 31 : 24 ] GC_CR_DMA_PARAM2_CH1_TRANSFER_ID_BITFIELD         = 8'h0;

 // gc_cr_dma_done_ch0
localparam logic [ 7 : 0 ] GC_CR_DMA_DONE_CH0_ID_BITFIELD                      = 8'h0;
localparam logic [ 8 : 8 ] GC_CR_DMA_DONE_CH0_FAIL_BITFIELD                    = 1'h0;

 // gc_cr_dma_done_ch1
localparam logic [ 7 : 0 ] GC_CR_DMA_DONE_CH1_ID_BITFIELD                      = 8'h0;
localparam logic [ 8 : 8 ] GC_CR_DMA_DONE_CH1_FAIL_BITFIELD                    = 1'h0;

 // gc_cr_dma_done_ch2
localparam logic [ 7 : 0 ] GC_CR_DMA_DONE_CH2_ID_BITFIELD                      = 8'h0;
localparam logic [ 8 : 8 ] GC_CR_DMA_DONE_CH2_FAIL_BITFIELD                    = 1'h0;

 // gc_cr_dma_done_ch3
localparam logic [ 7 : 0 ] GC_CR_DMA_DONE_CH3_ID_BITFIELD                      = 8'h0;
localparam logic [ 8 : 8 ] GC_CR_DMA_DONE_CH3_FAIL_BITFIELD                    = 1'h0;

 // gc_cr_dma_control
localparam logic [ 1 : 0 ] GC_CR_DMA_CONTROL_CH0_PRIORITY_BITFIELD             = 2'h0;
localparam logic [ 3 : 2 ] GC_CR_DMA_CONTROL_CH1_PRIORITY_BITFIELD             = 2'h0;
localparam logic [ 5 : 4 ] GC_CR_DMA_CONTROL_CH2_PRIORITY_BITFIELD             = 2'h0;
localparam logic [ 7 : 6 ] GC_CR_DMA_CONTROL_CH3_PRIORITY_BITFIELD             = 2'h0;
localparam logic [ 8 : 8 ] GC_CR_DMA_CONTROL_CLEAR_BITFIELD                    = 1'h0;

 // gc_cr_dma_status
localparam logic [ 0 : 0 ] GC_CR_DMA_STATUS_CH0_TRANSFER_FIFO_EMPTY_BITFIELD   = 1'h1;
localparam logic [ 1 : 1 ] GC_CR_DMA_STATUS_CH1_TRANSFER_FIFO_EMPTY_BITFIELD   = 1'h1;
localparam logic [ 2 : 2 ] GC_CR_DMA_STATUS_CH2_TRANSFER_FIFO_EMPTY_BITFIELD   = 1'h1;
localparam logic [ 3 : 3 ] GC_CR_DMA_STATUS_CH3_TRANSFER_FIFO_EMPTY_BITFIELD   = 1'h1;
localparam logic [ 4 : 4 ] GC_CR_DMA_STATUS_CH0_TRANSFER_FIFO_FULL_BITFIELD    = 1'h0;
localparam logic [ 5 : 5 ] GC_CR_DMA_STATUS_CH1_TRANSFER_FIFO_FULL_BITFIELD    = 1'h0;
localparam logic [ 6 : 6 ] GC_CR_DMA_STATUS_CH2_TRANSFER_FIFO_FULL_BITFIELD    = 1'h0;
localparam logic [ 7 : 7 ] GC_CR_DMA_STATUS_CH3_TRANSFER_FIFO_FULL_BITFIELD    = 1'h0;
localparam logic [ 8 : 8 ] GC_CR_DMA_STATUS_CH0_TRANSFER_FIFO_OVERFLOW_BITFIELD  = 1'h0;
localparam logic [ 9 : 9 ] GC_CR_DMA_STATUS_CH1_TRANSFER_FIFO_OVERFLOW_BITFIELD  = 1'h0;
localparam logic [ 10 : 10 ] GC_CR_DMA_STATUS_CH2_TRANSFER_FIFO_OVERFLOW_BITFIELD  = 1'h0;
localparam logic [ 11 : 11 ] GC_CR_DMA_STATUS_CH3_TRANSFER_FIFO_OVERFLOW_BITFIELD  = 1'h0;
localparam logic [ 12 : 12 ] GC_CR_DMA_STATUS_CH0_DONE_FIFO_NOT_EMPTY_BITFIELD  = 1'h0;
localparam logic [ 13 : 13 ] GC_CR_DMA_STATUS_CH1_DONE_FIFO_NOT_EMPTY_BITFIELD  = 1'h0;
localparam logic [ 14 : 14 ] GC_CR_DMA_STATUS_CH2_DONE_FIFO_NOT_EMPTY_BITFIELD  = 1'h0;
localparam logic [ 15 : 15 ] GC_CR_DMA_STATUS_CH3_DONE_FIFO_NOT_EMPTY_BITFIELD  = 1'h0;
localparam logic [ 16 : 16 ] GC_CR_DMA_STATUS_CH0_DONE_FIFO_OVERFLOW_BITFIELD  = 1'h0;
localparam logic [ 17 : 17 ] GC_CR_DMA_STATUS_CH1_DONE_FIFO_OVERFLOW_BITFIELD  = 1'h0;
localparam logic [ 18 : 18 ] GC_CR_DMA_STATUS_CH2_DONE_FIFO_OVERFLOW_BITFIELD  = 1'h0;
localparam logic [ 19 : 19 ] GC_CR_DMA_STATUS_CH3_DONE_FIFO_OVERFLOW_BITFIELD  = 1'h0;
localparam logic [ 20 : 20 ] GC_CR_DMA_STATUS_CH0_TRANSFER_COMPLETE_BITFIELD   = 1'h0;
localparam logic [ 21 : 21 ] GC_CR_DMA_STATUS_CH1_TRANSFER_COMPLETE_BITFIELD   = 1'h0;
localparam logic [ 22 : 22 ] GC_CR_DMA_STATUS_CH2_TRANSFER_COMPLETE_BITFIELD   = 1'h0;
localparam logic [ 23 : 23 ] GC_CR_DMA_STATUS_CH3_TRANSFER_COMPLETE_BITFIELD   = 1'h0;
localparam logic [ 24 : 24 ] GC_CR_DMA_STATUS_INVALID_VIRTUAL_ADDR_BITFIELD    = 1'h0;
localparam logic [ 25 : 25 ] GC_CR_DMA_STATUS_INVALID_CORE_MEM_ADDR_BITFIELD   = 1'h0;

 // gc_cr_dma_interrupt
localparam logic [ 0 : 0 ] GC_CR_DMA_INTERRUPT_CH0_TRANSFER_FIFO_EMPTY_BITFIELD  = 1'h1;
localparam logic [ 1 : 1 ] GC_CR_DMA_INTERRUPT_CH1_TRANSFER_FIFO_EMPTY_BITFIELD  = 1'h1;
localparam logic [ 2 : 2 ] GC_CR_DMA_INTERRUPT_CH2_TRANSFER_FIFO_EMPTY_BITFIELD  = 1'h1;
localparam logic [ 3 : 3 ] GC_CR_DMA_INTERRUPT_CH3_TRANSFER_FIFO_EMPTY_BITFIELD  = 1'h1;
localparam logic [ 4 : 4 ] GC_CR_DMA_INTERRUPT_CH0_TRANSFER_FIFO_FULL_BITFIELD  = 1'h0;
localparam logic [ 5 : 5 ] GC_CR_DMA_INTERRUPT_CH1_TRANSFER_FIFO_FULL_BITFIELD  = 1'h0;
localparam logic [ 6 : 6 ] GC_CR_DMA_INTERRUPT_CH2_TRANSFER_FIFO_FULL_BITFIELD  = 1'h0;
localparam logic [ 7 : 7 ] GC_CR_DMA_INTERRUPT_CH3_TRANSFER_FIFO_FULL_BITFIELD  = 1'h0;
localparam logic [ 8 : 8 ] GC_CR_DMA_INTERRUPT_CH0_TRANSFER_FIFO_OVERFLOW_BITFIELD  = 1'h0;
localparam logic [ 9 : 9 ] GC_CR_DMA_INTERRUPT_CH1_TRANSFER_FIFO_OVERFLOW_BITFIELD  = 1'h0;
localparam logic [ 10 : 10 ] GC_CR_DMA_INTERRUPT_CH2_TRANSFER_FIFO_OVERFLOW_BITFIELD  = 1'h0;
localparam logic [ 11 : 11 ] GC_CR_DMA_INTERRUPT_CH3_TRANSFER_FIFO_OVERFLOW_BITFIELD  = 1'h0;
localparam logic [ 12 : 12 ] GC_CR_DMA_INTERRUPT_CH0_DONE_FIFO_NOT_EMPTY_BITFIELD  = 1'h0;
localparam logic [ 13 : 13 ] GC_CR_DMA_INTERRUPT_CH1_DONE_FIFO_NOT_EMPTY_BITFIELD  = 1'h0;
localparam logic [ 14 : 14 ] GC_CR_DMA_INTERRUPT_CH2_DONE_FIFO_NOT_EMPTY_BITFIELD  = 1'h0;
localparam logic [ 15 : 15 ] GC_CR_DMA_INTERRUPT_CH3_DONE_FIFO_NOT_EMPTY_BITFIELD  = 1'h0;
localparam logic [ 16 : 16 ] GC_CR_DMA_INTERRUPT_CH0_DONE_FIFO_OVERFLOW_BITFIELD  = 1'h0;
localparam logic [ 17 : 17 ] GC_CR_DMA_INTERRUPT_CH1_DONE_FIFO_OVERFLOW_BITFIELD  = 1'h0;
localparam logic [ 18 : 18 ] GC_CR_DMA_INTERRUPT_CH2_DONE_FIFO_OVERFLOW_BITFIELD  = 1'h0;
localparam logic [ 19 : 19 ] GC_CR_DMA_INTERRUPT_CH3_DONE_FIFO_OVERFLOW_BITFIELD  = 1'h0;
localparam logic [ 20 : 20 ] GC_CR_DMA_INTERRUPT_CH0_TRANSFER_COMPLETE_BITFIELD  = 1'h0;
localparam logic [ 21 : 21 ] GC_CR_DMA_INTERRUPT_CH1_TRANSFER_COMPLETE_BITFIELD  = 1'h0;
localparam logic [ 22 : 22 ] GC_CR_DMA_INTERRUPT_CH2_TRANSFER_COMPLETE_BITFIELD  = 1'h0;
localparam logic [ 23 : 23 ] GC_CR_DMA_INTERRUPT_CH3_TRANSFER_COMPLETE_BITFIELD  = 1'h0;
localparam logic [ 24 : 24 ] GC_CR_DMA_INTERRUPT_INVALID_VIRTUAL_ADDR_BITFIELD  = 1'h0;
localparam logic [ 25 : 25 ] GC_CR_DMA_INTERRUPT_INVALID_CORE_MEM_ADDR_BITFIELD  = 1'h0;

 // gc_cr_dma_interrupt_enable
localparam logic [ 0 : 0 ] GC_CR_DMA_INTERRUPT_ENABLE_CH0_TRANSFER_FIFO_EMPTY_BITFIELD  = 1'h0;
localparam logic [ 1 : 1 ] GC_CR_DMA_INTERRUPT_ENABLE_CH1_TRANSFER_FIFO_EMPTY_BITFIELD  = 1'h0;
localparam logic [ 2 : 2 ] GC_CR_DMA_INTERRUPT_ENABLE_CH2_TRANSFER_FIFO_EMPTY_BITFIELD  = 1'h0;
localparam logic [ 3 : 3 ] GC_CR_DMA_INTERRUPT_ENABLE_CH3_TRANSFER_FIFO_EMPTY_BITFIELD  = 1'h0;
localparam logic [ 4 : 4 ] GC_CR_DMA_INTERRUPT_ENABLE_CH0_TRANSFER_FIFO_FULL_BITFIELD  = 1'h0;
localparam logic [ 5 : 5 ] GC_CR_DMA_INTERRUPT_ENABLE_CH1_TRANSFER_FIFO_FULL_BITFIELD  = 1'h0;
localparam logic [ 6 : 6 ] GC_CR_DMA_INTERRUPT_ENABLE_CH2_TRANSFER_FIFO_FULL_BITFIELD  = 1'h0;
localparam logic [ 7 : 7 ] GC_CR_DMA_INTERRUPT_ENABLE_CH3_TRANSFER_FIFO_FULL_BITFIELD  = 1'h0;
localparam logic [ 8 : 8 ] GC_CR_DMA_INTERRUPT_ENABLE_CH0_TRANSFER_FIFO_OVERFLOW_BITFIELD  = 1'h0;
localparam logic [ 9 : 9 ] GC_CR_DMA_INTERRUPT_ENABLE_CH1_TRANSFER_FIFO_OVERFLOW_BITFIELD  = 1'h0;
localparam logic [ 10 : 10 ] GC_CR_DMA_INTERRUPT_ENABLE_CH2_TRANSFER_FIFO_OVERFLOW_BITFIELD  = 1'h0;
localparam logic [ 11 : 11 ] GC_CR_DMA_INTERRUPT_ENABLE_CH3_TRANSFER_FIFO_OVERFLOW_BITFIELD  = 1'h0;
localparam logic [ 12 : 12 ] GC_CR_DMA_INTERRUPT_ENABLE_CH0_DONE_FIFO_NOT_EMPTY_BITFIELD  = 1'h0;
localparam logic [ 13 : 13 ] GC_CR_DMA_INTERRUPT_ENABLE_CH1_DONE_FIFO_NOT_EMPTY_BITFIELD  = 1'h0;
localparam logic [ 14 : 14 ] GC_CR_DMA_INTERRUPT_ENABLE_CH2_DONE_FIFO_NOT_EMPTY_BITFIELD  = 1'h0;
localparam logic [ 15 : 15 ] GC_CR_DMA_INTERRUPT_ENABLE_CH3_DONE_FIFO_NOT_EMPTY_BITFIELD  = 1'h0;
localparam logic [ 16 : 16 ] GC_CR_DMA_INTERRUPT_ENABLE_CH0_DONE_FIFO_OVERFLOW_BITFIELD  = 1'h0;
localparam logic [ 17 : 17 ] GC_CR_DMA_INTERRUPT_ENABLE_CH1_DONE_FIFO_OVERFLOW_BITFIELD  = 1'h0;
localparam logic [ 18 : 18 ] GC_CR_DMA_INTERRUPT_ENABLE_CH2_DONE_FIFO_OVERFLOW_BITFIELD  = 1'h0;
localparam logic [ 19 : 19 ] GC_CR_DMA_INTERRUPT_ENABLE_CH3_DONE_FIFO_OVERFLOW_BITFIELD  = 1'h0;
localparam logic [ 20 : 20 ] GC_CR_DMA_INTERRUPT_ENABLE_CH0_TRANSFER_COMPLETE_BITFIELD  = 1'h0;
localparam logic [ 21 : 21 ] GC_CR_DMA_INTERRUPT_ENABLE_CH1_TRANSFER_COMPLETE_BITFIELD  = 1'h0;
localparam logic [ 22 : 22 ] GC_CR_DMA_INTERRUPT_ENABLE_CH2_TRANSFER_COMPLETE_BITFIELD  = 1'h0;
localparam logic [ 23 : 23 ] GC_CR_DMA_INTERRUPT_ENABLE_CH3_TRANSFER_COMPLETE_BITFIELD  = 1'h0;
localparam logic [ 24 : 24 ] GC_CR_DMA_INTERRUPT_ENABLE_INVALID_VIRTUAL_ADDR_BITFIELD  = 1'h0;
localparam logic [ 25 : 25 ] GC_CR_DMA_INTERRUPT_ENABLE_INVALID_CORE_MEM_ADDR_BITFIELD  = 1'h0;

 // gc_cr_dma_prog_ch0
localparam logic [ 15 : 0 ] GC_CR_DMA_PROG_CH0_PROG_ADDR_CORE_MEM_ADDR_BITFIELD  = 16'h0;
localparam logic [ 31 : 16 ] GC_CR_DMA_PROG_CH0_PROG_DATA_CORE_MEM_ADDR_BITFIELD  = 16'h0;

 // gc_cr_dma_prog_ch1
localparam logic [ 15 : 0 ] GC_CR_DMA_PROG_CH1_PROG_ADDR_CORE_MEM_ADDR_BITFIELD  = 16'h0;
localparam logic [ 31 : 16 ] GC_CR_DMA_PROG_CH1_PROG_DATA_CORE_MEM_ADDR_BITFIELD  = 16'h0;

 // gc_cr_fwcore_addr_remap_config0
localparam logic [ 7 : 0 ] GC_CR_FWCORE_ADDR_REMAP_CONFIG0_MMU_CONTEXT_BITFIELD  = 8'h0;
localparam logic [ 59 : 44 ] GC_CR_FWCORE_ADDR_REMAP_CONFIG0_SIZE_BITFIELD     = 16'h0;
localparam logic [ 60 : 60 ] GC_CR_FWCORE_ADDR_REMAP_CONFIG0_FETCH_EN_BITFIELD  = 1'h0;
localparam logic [ 61 : 61 ] GC_CR_FWCORE_ADDR_REMAP_CONFIG0_LOAD_STORE_EN_BITFIELD  = 1'h0;

 // gc_cr_fwcore_addr_remap_config1
localparam logic [ 7 : 0 ] GC_CR_FWCORE_ADDR_REMAP_CONFIG1_MMU_CONTEXT_BITFIELD  = 8'h0;
localparam logic [ 59 : 44 ] GC_CR_FWCORE_ADDR_REMAP_CONFIG1_SIZE_BITFIELD     = 16'h0;
localparam logic [ 60 : 60 ] GC_CR_FWCORE_ADDR_REMAP_CONFIG1_FETCH_EN_BITFIELD  = 1'h0;
localparam logic [ 61 : 61 ] GC_CR_FWCORE_ADDR_REMAP_CONFIG1_LOAD_STORE_EN_BITFIELD  = 1'h0;

 // gc_cr_fwcore_addr_remap_config2
localparam logic [ 7 : 0 ] GC_CR_FWCORE_ADDR_REMAP_CONFIG2_MMU_CONTEXT_BITFIELD  = 8'h0;
localparam logic [ 59 : 44 ] GC_CR_FWCORE_ADDR_REMAP_CONFIG2_SIZE_BITFIELD     = 16'h0;
localparam logic [ 60 : 60 ] GC_CR_FWCORE_ADDR_REMAP_CONFIG2_FETCH_EN_BITFIELD  = 1'h0;
localparam logic [ 61 : 61 ] GC_CR_FWCORE_ADDR_REMAP_CONFIG2_LOAD_STORE_EN_BITFIELD  = 1'h0;

 // gc_cr_fwcore_addr_remap_config3
localparam logic [ 7 : 0 ] GC_CR_FWCORE_ADDR_REMAP_CONFIG3_MMU_CONTEXT_BITFIELD  = 8'h0;
localparam logic [ 59 : 44 ] GC_CR_FWCORE_ADDR_REMAP_CONFIG3_SIZE_BITFIELD     = 16'h0;
localparam logic [ 60 : 60 ] GC_CR_FWCORE_ADDR_REMAP_CONFIG3_FETCH_EN_BITFIELD  = 1'h0;
localparam logic [ 61 : 61 ] GC_CR_FWCORE_ADDR_REMAP_CONFIG3_LOAD_STORE_EN_BITFIELD  = 1'h0;

 // gc_cr_fwcore_addr_remap_config4
localparam logic [ 7 : 0 ] GC_CR_FWCORE_ADDR_REMAP_CONFIG4_MMU_CONTEXT_BITFIELD  = 8'h0;
localparam logic [ 59 : 44 ] GC_CR_FWCORE_ADDR_REMAP_CONFIG4_SIZE_BITFIELD     = 16'h0;
localparam logic [ 60 : 60 ] GC_CR_FWCORE_ADDR_REMAP_CONFIG4_FETCH_EN_BITFIELD  = 1'h0;
localparam logic [ 61 : 61 ] GC_CR_FWCORE_ADDR_REMAP_CONFIG4_LOAD_STORE_EN_BITFIELD  = 1'h0;

 // gc_cr_fwcore_addr_remap_config5
localparam logic [ 7 : 0 ] GC_CR_FWCORE_ADDR_REMAP_CONFIG5_MMU_CONTEXT_BITFIELD  = 8'h0;
localparam logic [ 59 : 44 ] GC_CR_FWCORE_ADDR_REMAP_CONFIG5_SIZE_BITFIELD     = 16'hffff;
localparam logic [ 60 : 60 ] GC_CR_FWCORE_ADDR_REMAP_CONFIG5_FETCH_EN_BITFIELD  = 1'h0;
localparam logic [ 61 : 61 ] GC_CR_FWCORE_ADDR_REMAP_CONFIG5_LOAD_STORE_EN_BITFIELD  = 1'h1;

 // gc_cr_fwcore_addr_remap_config6
localparam logic [ 7 : 0 ] GC_CR_FWCORE_ADDR_REMAP_CONFIG6_MMU_CONTEXT_BITFIELD  = 8'h0;
localparam logic [ 59 : 44 ] GC_CR_FWCORE_ADDR_REMAP_CONFIG6_SIZE_BITFIELD     = 16'h0;
localparam logic [ 60 : 60 ] GC_CR_FWCORE_ADDR_REMAP_CONFIG6_FETCH_EN_BITFIELD  = 1'h0;
localparam logic [ 61 : 61 ] GC_CR_FWCORE_ADDR_REMAP_CONFIG6_LOAD_STORE_EN_BITFIELD  = 1'h0;

 // gc_cr_fwcore_addr_remap_config7
localparam logic [ 7 : 0 ] GC_CR_FWCORE_ADDR_REMAP_CONFIG7_MMU_CONTEXT_BITFIELD  = 8'h0;
localparam logic [ 59 : 44 ] GC_CR_FWCORE_ADDR_REMAP_CONFIG7_SIZE_BITFIELD     = 16'h0;
localparam logic [ 60 : 60 ] GC_CR_FWCORE_ADDR_REMAP_CONFIG7_FETCH_EN_BITFIELD  = 1'h0;
localparam logic [ 61 : 61 ] GC_CR_FWCORE_ADDR_REMAP_CONFIG7_LOAD_STORE_EN_BITFIELD  = 1'h0;

 // gc_cr_fwcore_addr_remap_config8
localparam logic [ 7 : 0 ] GC_CR_FWCORE_ADDR_REMAP_CONFIG8_MMU_CONTEXT_BITFIELD  = 8'h0;
localparam logic [ 59 : 44 ] GC_CR_FWCORE_ADDR_REMAP_CONFIG8_SIZE_BITFIELD     = 16'h0;
localparam logic [ 60 : 60 ] GC_CR_FWCORE_ADDR_REMAP_CONFIG8_FETCH_EN_BITFIELD  = 1'h0;
localparam logic [ 61 : 61 ] GC_CR_FWCORE_ADDR_REMAP_CONFIG8_LOAD_STORE_EN_BITFIELD  = 1'h0;

 // gc_cr_fwcore_addr_remap_config9
localparam logic [ 7 : 0 ] GC_CR_FWCORE_ADDR_REMAP_CONFIG9_MMU_CONTEXT_BITFIELD  = 8'h0;
localparam logic [ 59 : 44 ] GC_CR_FWCORE_ADDR_REMAP_CONFIG9_SIZE_BITFIELD     = 16'h0;
localparam logic [ 60 : 60 ] GC_CR_FWCORE_ADDR_REMAP_CONFIG9_FETCH_EN_BITFIELD  = 1'h0;
localparam logic [ 61 : 61 ] GC_CR_FWCORE_ADDR_REMAP_CONFIG9_LOAD_STORE_EN_BITFIELD  = 1'h0;

 // gc_cr_fwcore_addr_remap_config10
localparam logic [ 7 : 0 ] GC_CR_FWCORE_ADDR_REMAP_CONFIG10_MMU_CONTEXT_BITFIELD  = 8'h0;
localparam logic [ 59 : 44 ] GC_CR_FWCORE_ADDR_REMAP_CONFIG10_SIZE_BITFIELD    = 16'h0;
localparam logic [ 60 : 60 ] GC_CR_FWCORE_ADDR_REMAP_CONFIG10_FETCH_EN_BITFIELD  = 1'h0;
localparam logic [ 61 : 61 ] GC_CR_FWCORE_ADDR_REMAP_CONFIG10_LOAD_STORE_EN_BITFIELD  = 1'h0;

 // gc_cr_fwcore_addr_remap_config11
localparam logic [ 7 : 0 ] GC_CR_FWCORE_ADDR_REMAP_CONFIG11_MMU_CONTEXT_BITFIELD  = 8'h0;
localparam logic [ 59 : 44 ] GC_CR_FWCORE_ADDR_REMAP_CONFIG11_SIZE_BITFIELD    = 16'h0;
localparam logic [ 60 : 60 ] GC_CR_FWCORE_ADDR_REMAP_CONFIG11_FETCH_EN_BITFIELD  = 1'h0;
localparam logic [ 61 : 61 ] GC_CR_FWCORE_ADDR_REMAP_CONFIG11_LOAD_STORE_EN_BITFIELD  = 1'h0;

 // gc_cr_fwcore_addr_remap_config12
localparam logic [ 7 : 0 ] GC_CR_FWCORE_ADDR_REMAP_CONFIG12_MMU_CONTEXT_BITFIELD  = 8'h0;
localparam logic [ 59 : 44 ] GC_CR_FWCORE_ADDR_REMAP_CONFIG12_SIZE_BITFIELD    = 16'hffff;
localparam logic [ 60 : 60 ] GC_CR_FWCORE_ADDR_REMAP_CONFIG12_FETCH_EN_BITFIELD  = 1'h1;
localparam logic [ 61 : 61 ] GC_CR_FWCORE_ADDR_REMAP_CONFIG12_LOAD_STORE_EN_BITFIELD  = 1'h0;

 // gc_cr_fwcore_addr_remap_config13
localparam logic [ 7 : 0 ] GC_CR_FWCORE_ADDR_REMAP_CONFIG13_MMU_CONTEXT_BITFIELD  = 8'h0;
localparam logic [ 59 : 44 ] GC_CR_FWCORE_ADDR_REMAP_CONFIG13_SIZE_BITFIELD    = 16'h0;
localparam logic [ 60 : 60 ] GC_CR_FWCORE_ADDR_REMAP_CONFIG13_FETCH_EN_BITFIELD  = 1'h0;
localparam logic [ 61 : 61 ] GC_CR_FWCORE_ADDR_REMAP_CONFIG13_LOAD_STORE_EN_BITFIELD  = 1'h0;

 // gc_cr_fwcore_addr_remap_config14
localparam logic [ 7 : 0 ] GC_CR_FWCORE_ADDR_REMAP_CONFIG14_MMU_CONTEXT_BITFIELD  = 8'h0;
localparam logic [ 59 : 44 ] GC_CR_FWCORE_ADDR_REMAP_CONFIG14_SIZE_BITFIELD    = 16'h0;
localparam logic [ 60 : 60 ] GC_CR_FWCORE_ADDR_REMAP_CONFIG14_FETCH_EN_BITFIELD  = 1'h0;
localparam logic [ 61 : 61 ] GC_CR_FWCORE_ADDR_REMAP_CONFIG14_LOAD_STORE_EN_BITFIELD  = 1'h0;

 // gc_cr_fwcore_addr_remap_config15
localparam logic [ 7 : 0 ] GC_CR_FWCORE_ADDR_REMAP_CONFIG15_MMU_CONTEXT_BITFIELD  = 8'h0;
localparam logic [ 59 : 44 ] GC_CR_FWCORE_ADDR_REMAP_CONFIG15_SIZE_BITFIELD    = 16'h0;
localparam logic [ 60 : 60 ] GC_CR_FWCORE_ADDR_REMAP_CONFIG15_FETCH_EN_BITFIELD  = 1'h0;
localparam logic [ 61 : 61 ] GC_CR_FWCORE_ADDR_REMAP_CONFIG15_LOAD_STORE_EN_BITFIELD  = 1'h0;

 // gc_cr_fwcore_addr_remap_config0_devvaddr
localparam logic [ 47 : 12 ] GC_CR_FWCORE_ADDR_REMAP_CONFIG0_DEVVADDR_DEVVADDR_BITFIELD  = 36'he1c000;

 // gc_cr_fwcore_addr_remap_config1_devvaddr
localparam logic [ 47 : 12 ] GC_CR_FWCORE_ADDR_REMAP_CONFIG1_DEVVADDR_DEVVADDR_BITFIELD  = 36'he1c000;

 // gc_cr_fwcore_addr_remap_config2_devvaddr
localparam logic [ 47 : 12 ] GC_CR_FWCORE_ADDR_REMAP_CONFIG2_DEVVADDR_DEVVADDR_BITFIELD  = 36'he1c000;

 // gc_cr_fwcore_addr_remap_config3_devvaddr
localparam logic [ 47 : 12 ] GC_CR_FWCORE_ADDR_REMAP_CONFIG3_DEVVADDR_DEVVADDR_BITFIELD  = 36'he1c000;

 // gc_cr_fwcore_addr_remap_config4_devvaddr
localparam logic [ 47 : 12 ] GC_CR_FWCORE_ADDR_REMAP_CONFIG4_DEVVADDR_DEVVADDR_BITFIELD  = 36'he1c000;

 // gc_cr_fwcore_addr_remap_config5_devvaddr
localparam logic [ 47 : 12 ] GC_CR_FWCORE_ADDR_REMAP_CONFIG5_DEVVADDR_DEVVADDR_BITFIELD  = 36'he1c000;

 // gc_cr_fwcore_addr_remap_config6_devvaddr
localparam logic [ 47 : 12 ] GC_CR_FWCORE_ADDR_REMAP_CONFIG6_DEVVADDR_DEVVADDR_BITFIELD  = 36'he1c000;

 // gc_cr_fwcore_addr_remap_config7_devvaddr
localparam logic [ 47 : 12 ] GC_CR_FWCORE_ADDR_REMAP_CONFIG7_DEVVADDR_DEVVADDR_BITFIELD  = 36'he1c000;

 // gc_cr_fwcore_addr_remap_config8_devvaddr
localparam logic [ 47 : 12 ] GC_CR_FWCORE_ADDR_REMAP_CONFIG8_DEVVADDR_DEVVADDR_BITFIELD  = 36'he1c000;

 // gc_cr_fwcore_addr_remap_config9_devvaddr
localparam logic [ 47 : 12 ] GC_CR_FWCORE_ADDR_REMAP_CONFIG9_DEVVADDR_DEVVADDR_BITFIELD  = 36'he1c000;

 // gc_cr_fwcore_addr_remap_config10_devvaddr
localparam logic [ 47 : 12 ] GC_CR_FWCORE_ADDR_REMAP_CONFIG10_DEVVADDR_DEVVADDR_BITFIELD  = 36'he1c000;

 // gc_cr_fwcore_addr_remap_config11_devvaddr
localparam logic [ 47 : 12 ] GC_CR_FWCORE_ADDR_REMAP_CONFIG11_DEVVADDR_DEVVADDR_BITFIELD  = 36'he1c000;

 // gc_cr_fwcore_addr_remap_config12_devvaddr
localparam logic [ 47 : 12 ] GC_CR_FWCORE_ADDR_REMAP_CONFIG12_DEVVADDR_DEVVADDR_BITFIELD  = 36'he1c000;

 // gc_cr_fwcore_addr_remap_config13_devvaddr
localparam logic [ 47 : 12 ] GC_CR_FWCORE_ADDR_REMAP_CONFIG13_DEVVADDR_DEVVADDR_BITFIELD  = 36'he1c000;

 // gc_cr_fwcore_addr_remap_config14_devvaddr
localparam logic [ 47 : 12 ] GC_CR_FWCORE_ADDR_REMAP_CONFIG14_DEVVADDR_DEVVADDR_BITFIELD  = 36'he1c000;

 // gc_cr_fwcore_addr_remap_config15_devvaddr
localparam logic [ 47 : 12 ] GC_CR_FWCORE_ADDR_REMAP_CONFIG15_DEVVADDR_DEVVADDR_BITFIELD  = 36'he1c000;

 // gc_cr_fwcore_wrapper_nmi_enable
localparam logic [ 0 : 0 ] GC_CR_FWCORE_WRAPPER_NMI_ENABLE_EVENT_EN_BITFIELD   = 1'h0;

 // gc_cr_fwcore_wrapper_nmi_event
localparam logic [ 0 : 0 ] GC_CR_FWCORE_WRAPPER_NMI_EVENT_TRIGGER_EN_BITFIELD  = 1'h0;

 // gc_cr_fwcore_wrapper_reset_vector
localparam logic [ 31 : 1 ] GC_CR_FWCORE_WRAPPER_RESET_VECTOR_ADDR_BITFIELD    = 31'h60000000;

 // gc_cr_fwcore_wrapper_nmi_vector
localparam logic [ 31 : 1 ] GC_CR_FWCORE_WRAPPER_NMI_VECTOR_ADDR_BITFIELD      = 31'h60000800;

 // gc_cr_gpu_cfi_op
localparam logic [ 5 : 0 ] GC_CR_GPU_CFI_OP_CONTEXT_BITFIELD                   = 6'h0;
localparam logic [ 8 : 8 ] GC_CR_GPU_CFI_OP_L2_POLICY_BITFIELD                 = 1'h0;
localparam logic [ 10 : 9 ] GC_CR_GPU_CFI_OP_SCOPE_BITFIELD                    = 2'h0;
localparam logic [ 12 : 11 ] GC_CR_GPU_CFI_OP_OPERATION_BITFIELD               = 2'h0;
localparam logic [ 14 : 13 ] GC_CR_GPU_CFI_OP_L1_POLICY_BITFIELD               = 2'h0;

 // gc_cr_gpu_cfi_address
localparam logic [ 47 : 6 ] GC_CR_GPU_CFI_ADDRESS_VALUE_BITFIELD               = 42'h0;

 // gc_cr_gpu_cfi_status
localparam logic [ 0 : 0 ] GC_CR_GPU_CFI_STATUS_ERR_BITFIELD                   = 1'h0;
localparam logic [ 1 : 1 ] GC_CR_GPU_CFI_STATUS_FULL_BITFIELD                  = 1'h0;

 // gc_cr_gpu_fence_op
localparam logic [ 0 : 0 ] GC_CR_GPU_FENCE_OP_L2_POLICY_BITFIELD               = 1'h0;
localparam logic [ 1 : 1 ] GC_CR_GPU_FENCE_OP_PENDING_BITFIELD                 = 1'h0;

 // gc_cr_cp_fix_disable
localparam logic [ 15 : 0 ] GC_CR_CP_FIX_DISABLE_DISABLE_BITFIELD              = 16'h0;

 // gc_cr_riscv_dma_pipe
localparam logic [ 3 : 0 ] GC_CR_RISCV_DMA_PIPE_WORDS_BITFIELD                 = 4'h4;

 // gc_cr_riscv_mtime_stat
localparam logic [ 63 : 0 ] GC_CR_RISCV_MTIME_STAT_VALUE_BITFIELD              = 64'h0;

 // gc_cr_riscv_mtime_set
localparam logic [ 63 : 0 ] GC_CR_RISCV_MTIME_SET_SET_BITFIELD                 = 64'h0;

 // gc_cr_riscv_mtime_cmp
localparam logic [ 63 : 0 ] GC_CR_RISCV_MTIME_CMP_CMP_BITFIELD                 = 64'h0;

 // gc_cr_riscv_mtime_ctrl
localparam logic [ 0 : 0 ] GC_CR_RISCV_MTIME_CTRL_ENABLE_BITFIELD              = 1'h0;
localparam logic [ 1 : 1 ] GC_CR_RISCV_MTIME_CTRL_PAUSE_BITFIELD               = 1'h1;
localparam logic [ 31 : 31 ] GC_CR_RISCV_MTIME_CTRL_SOFT_RESET_BITFIELD        = 1'h0;

 // gc_cr_riscv_axi_mmu
localparam logic [ 1 : 0 ] GC_CR_RISCV_AXI_MMU_AWUSER_PERSISTENCE_BITFIELD     = 2'h0;
localparam logic [ 2 : 2 ] GC_CR_RISCV_AXI_MMU_AW_TBU_REQ_IS_PA_BITFIELD       = 1'h0;
localparam logic [ 4 : 3 ] GC_CR_RISCV_AXI_MMU_ARUSER_PERSISTENCE_BITFIELD     = 2'h0;
localparam logic [ 5 : 5 ] GC_CR_RISCV_AXI_MMU_AR_TBU_REQ_IS_PA_BITFIELD       = 1'h0;

 // gc_cr_reg_error_clear
localparam logic [ 3 : 0 ] GC_CR_REG_ERROR_CLEAR_CLEAR_BITFIELD                = 4'h0;

 // gc_cr_reg_error_code
localparam logic [ 11 : 0 ] GC_CR_REG_ERROR_CODE_CODE_BITFIELD                 = 12'h0;

 // gc_cr_reg_req_cnt_idle
localparam logic [ 3 : 0 ] GC_CR_REG_REQ_CNT_IDLE_IDLE_BITFIELD                = 4'h0;

 // gc_cr_fwp_cfi
localparam logic [ 47 : 4 ] GC_CR_FWP_CFI_ADDRESS_BITFIELD                     = 44'h0;

 // gc_cr_fwp_cfi_op
localparam logic [ 7 : 0 ] GC_CR_FWP_CFI_OP_CONTEXT_BITFIELD                   = 8'h0;
localparam logic [ 10 : 9 ] GC_CR_FWP_CFI_OP_SCOPE_BITFIELD                    = 2'h0;
localparam logic [ 12 : 11 ] GC_CR_FWP_CFI_OP_OPERATION_BITFIELD               = 2'h0;

 // gc_cr_fwp_fence_op
localparam logic [ 1 : 1 ] GC_CR_FWP_FENCE_OP_PENDING_BITFIELD                 = 1'h0;
localparam logic [ 2 : 2 ] GC_CR_FWP_FENCE_OP_FBCDC_BITFIELD                   = 1'h0;

 // gc_cr_fwp_cfi_mh_control
localparam logic [ 0 : 0 ] GC_CR_FWP_CFI_MH_CONTROL_L2_POLICY_BITFIELD         = 1'h1;
localparam logic [ 1 : 1 ] GC_CR_FWP_CFI_MH_CONTROL_L1_POLICY_BITFIELD         = 1'h1;

 // gc_cr_fwp_fence_mh_control
localparam logic [ 0 : 0 ] GC_CR_FWP_FENCE_MH_CONTROL_L2_POLICY_BITFIELD       = 1'h1;

 // enum gc_cr_crm_reset_clk_mode
localparam logic [ 1 : 0 ] GC_CR_CRM_RESET_CLK_MODE_OFF                        = 2'h0;
localparam logic [ 1 : 0 ] GC_CR_CRM_RESET_CLK_MODE_ON_16                      = 2'h1;
localparam logic [ 1 : 0 ] GC_CR_CRM_RESET_CLK_MODE_ON_64                      = 2'h2;
localparam logic [ 1 : 0 ] GC_CR_CRM_RESET_CLK_MODE_ON                         = 2'h3;

 // gc_cr_crm_reset_clk
localparam logic [ 1 : 0 ] GC_CR_CRM_RESET_CLK_CTRL_BITFIELD                   = 2'h0;
localparam logic [ 1 : 0 ] GC_CR_CRM_RESET_CLK_CTRL_OFF                        = 2'h0;
localparam logic [ 1 : 0 ] GC_CR_CRM_RESET_CLK_CTRL_ON_16                      = 2'h1;
localparam logic [ 1 : 0 ] GC_CR_CRM_RESET_CLK_CTRL_ON_64                      = 2'h2;
localparam logic [ 1 : 0 ] GC_CR_CRM_RESET_CLK_CTRL_ON                         = 2'h3;

 // enum gc_cr_tbu_bif2axi_crm_reset_clk_mode
localparam logic [ 1 : 0 ] GC_CR_TBU_BIF2AXI_CRM_RESET_CLK_MODE_OFF            = 2'h0;
localparam logic [ 1 : 0 ] GC_CR_TBU_BIF2AXI_CRM_RESET_CLK_MODE_ON_16          = 2'h1;
localparam logic [ 1 : 0 ] GC_CR_TBU_BIF2AXI_CRM_RESET_CLK_MODE_ON_64          = 2'h2;
localparam logic [ 1 : 0 ] GC_CR_TBU_BIF2AXI_CRM_RESET_CLK_MODE_ON             = 2'h3;

 // gc_cr_tbu_bif2axi_crm_reset_clk
localparam logic [ 1 : 0 ] GC_CR_TBU_BIF2AXI_CRM_RESET_CLK_CTRL_BITFIELD       = 2'h0;
localparam logic [ 1 : 0 ] GC_CR_TBU_BIF2AXI_CRM_RESET_CLK_CTRL_OFF            = 2'h0;
localparam logic [ 1 : 0 ] GC_CR_TBU_BIF2AXI_CRM_RESET_CLK_CTRL_ON_16          = 2'h1;
localparam logic [ 1 : 0 ] GC_CR_TBU_BIF2AXI_CRM_RESET_CLK_CTRL_ON_64          = 2'h2;
localparam logic [ 1 : 0 ] GC_CR_TBU_BIF2AXI_CRM_RESET_CLK_CTRL_ON             = 2'h3;

 // enum gc_cr_cp_bif_crm_reset_clk_mode
localparam logic [ 1 : 0 ] GC_CR_CP_BIF_CRM_RESET_CLK_MODE_OFF                 = 2'h0;
localparam logic [ 1 : 0 ] GC_CR_CP_BIF_CRM_RESET_CLK_MODE_ON_16               = 2'h1;
localparam logic [ 1 : 0 ] GC_CR_CP_BIF_CRM_RESET_CLK_MODE_ON_64               = 2'h2;
localparam logic [ 1 : 0 ] GC_CR_CP_BIF_CRM_RESET_CLK_MODE_ON                  = 2'h3;

 // gc_cr_cp_bif_crm_reset_clk
localparam logic [ 1 : 0 ] GC_CR_CP_BIF_CRM_RESET_CLK_CTRL_BITFIELD            = 2'h0;
localparam logic [ 1 : 0 ] GC_CR_CP_BIF_CRM_RESET_CLK_CTRL_OFF                 = 2'h0;
localparam logic [ 1 : 0 ] GC_CR_CP_BIF_CRM_RESET_CLK_CTRL_ON_16               = 2'h1;
localparam logic [ 1 : 0 ] GC_CR_CP_BIF_CRM_RESET_CLK_CTRL_ON_64               = 2'h2;
localparam logic [ 1 : 0 ] GC_CR_CP_BIF_CRM_RESET_CLK_CTRL_ON                  = 2'h3;

 // enum gc_cr_cpc0_crm_reset_clk_mode
localparam logic [ 1 : 0 ] GC_CR_CPC0_CRM_RESET_CLK_MODE_OFF                   = 2'h0;
localparam logic [ 1 : 0 ] GC_CR_CPC0_CRM_RESET_CLK_MODE_ON_16                 = 2'h1;
localparam logic [ 1 : 0 ] GC_CR_CPC0_CRM_RESET_CLK_MODE_ON_64                 = 2'h2;
localparam logic [ 1 : 0 ] GC_CR_CPC0_CRM_RESET_CLK_MODE_ON                    = 2'h3;

 // gc_cr_cpc0_crm_reset_clk
localparam logic [ 1 : 0 ] GC_CR_CPC0_CRM_RESET_CLK_CTRL_BITFIELD              = 2'h0;
localparam logic [ 1 : 0 ] GC_CR_CPC0_CRM_RESET_CLK_CTRL_OFF                   = 2'h0;
localparam logic [ 1 : 0 ] GC_CR_CPC0_CRM_RESET_CLK_CTRL_ON_16                 = 2'h1;
localparam logic [ 1 : 0 ] GC_CR_CPC0_CRM_RESET_CLK_CTRL_ON_64                 = 2'h2;
localparam logic [ 1 : 0 ] GC_CR_CPC0_CRM_RESET_CLK_CTRL_ON                    = 2'h3;

 // enum gc_cr_cpc1_crm_reset_clk_mode
localparam logic [ 1 : 0 ] GC_CR_CPC1_CRM_RESET_CLK_MODE_OFF                   = 2'h0;
localparam logic [ 1 : 0 ] GC_CR_CPC1_CRM_RESET_CLK_MODE_ON_16                 = 2'h1;
localparam logic [ 1 : 0 ] GC_CR_CPC1_CRM_RESET_CLK_MODE_ON_64                 = 2'h2;
localparam logic [ 1 : 0 ] GC_CR_CPC1_CRM_RESET_CLK_MODE_ON                    = 2'h3;

 // gc_cr_cpc1_crm_reset_clk
localparam logic [ 1 : 0 ] GC_CR_CPC1_CRM_RESET_CLK_CTRL_BITFIELD              = 2'h0;
localparam logic [ 1 : 0 ] GC_CR_CPC1_CRM_RESET_CLK_CTRL_OFF                   = 2'h0;
localparam logic [ 1 : 0 ] GC_CR_CPC1_CRM_RESET_CLK_CTRL_ON_16                 = 2'h1;
localparam logic [ 1 : 0 ] GC_CR_CPC1_CRM_RESET_CLK_CTRL_ON_64                 = 2'h2;
localparam logic [ 1 : 0 ] GC_CR_CPC1_CRM_RESET_CLK_CTRL_ON                    = 2'h3;

 // enum gc_cr_cpc2_crm_reset_clk_mode
localparam logic [ 1 : 0 ] GC_CR_CPC2_CRM_RESET_CLK_MODE_OFF                   = 2'h0;
localparam logic [ 1 : 0 ] GC_CR_CPC2_CRM_RESET_CLK_MODE_ON_16                 = 2'h1;
localparam logic [ 1 : 0 ] GC_CR_CPC2_CRM_RESET_CLK_MODE_ON_64                 = 2'h2;
localparam logic [ 1 : 0 ] GC_CR_CPC2_CRM_RESET_CLK_MODE_ON                    = 2'h3;

 // gc_cr_cpc2_crm_reset_clk
localparam logic [ 1 : 0 ] GC_CR_CPC2_CRM_RESET_CLK_CTRL_BITFIELD              = 2'h0;
localparam logic [ 1 : 0 ] GC_CR_CPC2_CRM_RESET_CLK_CTRL_OFF                   = 2'h0;
localparam logic [ 1 : 0 ] GC_CR_CPC2_CRM_RESET_CLK_CTRL_ON_16                 = 2'h1;
localparam logic [ 1 : 0 ] GC_CR_CPC2_CRM_RESET_CLK_CTRL_ON_64                 = 2'h2;
localparam logic [ 1 : 0 ] GC_CR_CPC2_CRM_RESET_CLK_CTRL_ON                    = 2'h3;

 // enum gc_cr_cpc3_crm_reset_clk_mode
localparam logic [ 1 : 0 ] GC_CR_CPC3_CRM_RESET_CLK_MODE_OFF                   = 2'h0;
localparam logic [ 1 : 0 ] GC_CR_CPC3_CRM_RESET_CLK_MODE_ON_16                 = 2'h1;
localparam logic [ 1 : 0 ] GC_CR_CPC3_CRM_RESET_CLK_MODE_ON_64                 = 2'h2;
localparam logic [ 1 : 0 ] GC_CR_CPC3_CRM_RESET_CLK_MODE_ON                    = 2'h3;

 // gc_cr_cpc3_crm_reset_clk
localparam logic [ 1 : 0 ] GC_CR_CPC3_CRM_RESET_CLK_CTRL_BITFIELD              = 2'h0;
localparam logic [ 1 : 0 ] GC_CR_CPC3_CRM_RESET_CLK_CTRL_OFF                   = 2'h0;
localparam logic [ 1 : 0 ] GC_CR_CPC3_CRM_RESET_CLK_CTRL_ON_16                 = 2'h1;
localparam logic [ 1 : 0 ] GC_CR_CPC3_CRM_RESET_CLK_CTRL_ON_64                 = 2'h2;
localparam logic [ 1 : 0 ] GC_CR_CPC3_CRM_RESET_CLK_CTRL_ON                    = 2'h3;

 // gc_cr_cpc0_pasid
localparam logic [ 9 : 0 ] GC_CR_CPC0_PASID_PASID_BITFIELD                     = 10'h0;

 // gc_cr_cpc1_pasid
localparam logic [ 9 : 0 ] GC_CR_CPC1_PASID_PASID_BITFIELD                     = 10'h0;

 // gc_cr_cpc2_pasid
localparam logic [ 9 : 0 ] GC_CR_CPC2_PASID_PASID_BITFIELD                     = 10'h0;

 // gc_cr_cpc3_pasid
localparam logic [ 9 : 0 ] GC_CR_CPC3_PASID_PASID_BITFIELD                     = 10'h0;

 // gc_cr_cpc0_vfid
localparam logic [ 3 : 0 ] GC_CR_CPC0_VFID_VFID_BITFIELD                       = 4'h0;

 // gc_cr_cpc1_vfid
localparam logic [ 3 : 0 ] GC_CR_CPC1_VFID_VFID_BITFIELD                       = 4'h0;

 // gc_cr_cpc2_vfid
localparam logic [ 3 : 0 ] GC_CR_CPC2_VFID_VFID_BITFIELD                       = 4'h0;

 // gc_cr_cpc3_vfid
localparam logic [ 3 : 0 ] GC_CR_CPC3_VFID_VFID_BITFIELD                       = 4'h0;

 // gc_cr_bif_outstanding_read
localparam logic [ 15 : 0 ] GC_CR_BIF_OUTSTANDING_READ_COUNTER_BITFIELD        = 16'h0;

 // gc_cr_bif_rtn_fifo_word_count
localparam logic [ 9 : 0 ] GC_CR_BIF_RTN_FIFO_WORD_COUNT_COUNTER_BITFIELD      = 10'h0;

 // gc_cr_bif_pfs
localparam logic [ 0 : 0 ] GC_CR_BIF_PFS_STALL_COMPLETE_BITFIELD               = 1'h1;
localparam logic [ 1 : 1 ] GC_CR_BIF_PFS_REQUEST_IP_IDLE_BITFIELD              = 1'h1;
localparam logic [ 2 : 2 ] GC_CR_BIF_PFS_WDATA_IP_IDLE_BITFIELD                = 1'h1;
localparam logic [ 3 : 3 ] GC_CR_BIF_PFS_NONFWP_WDATA_COMPLETE_BITFIELD        = 1'h1;
localparam logic [ 4 : 4 ] GC_CR_BIF_PFS_NONFWP_REQ_COMPLETE_BITFIELD          = 1'h1;
localparam logic [ 5 : 5 ] GC_CR_BIF_PFS_RTN_MEM_IF_IDLE_BITFIELD              = 1'h1;
localparam logic [ 6 : 6 ] GC_CR_BIF_PFS_ARB_IDLE_BITFIELD                     = 1'h1;
localparam logic [ 7 : 7 ] GC_CR_BIF_PFS_TILING_IDLE_BITFIELD                  = 1'h1;
localparam logic [ 8 : 8 ] GC_CR_BIF_PFS_L2G_STALLING_BITFIELD                 = 1'h0;

 // gc_cr_bif_pfs_wdata_completion
localparam logic [ 0 : 0 ] GC_CR_BIF_PFS_WDATA_COMPLETION_ENABLE_BITFIELD      = 1'h1;

 // gc_cr_pwr_man_hysteresis
localparam logic [ 4 : 0 ] GC_CR_PWR_MAN_HYSTERESIS_VALUE_BITFIELD             = 5'h1f;

 // gc_cr_tbu_bif2axi_pwr_man_hysteresis
localparam logic [ 4 : 0 ] GC_CR_TBU_BIF2AXI_PWR_MAN_HYSTERESIS_VALUE_BITFIELD  = 5'h1f;

 // gc_cr_cp_bif_pwr_man_hysteresis
localparam logic [ 4 : 0 ] GC_CR_CP_BIF_PWR_MAN_HYSTERESIS_VALUE_BITFIELD      = 5'h1f;

 // gc_cr_cpc0_pwr_man_hysteresis
localparam logic [ 4 : 0 ] GC_CR_CPC0_PWR_MAN_HYSTERESIS_VALUE_BITFIELD        = 5'h1f;

 // gc_cr_cpc1_pwr_man_hysteresis
localparam logic [ 4 : 0 ] GC_CR_CPC1_PWR_MAN_HYSTERESIS_VALUE_BITFIELD        = 5'h1f;

 // gc_cr_cpc2_pwr_man_hysteresis
localparam logic [ 4 : 0 ] GC_CR_CPC2_PWR_MAN_HYSTERESIS_VALUE_BITFIELD        = 5'h1f;

 // gc_cr_cpc3_pwr_man_hysteresis
localparam logic [ 4 : 0 ] GC_CR_CPC3_PWR_MAN_HYSTERESIS_VALUE_BITFIELD        = 5'h1f;

 // gc_cr_fwcore_wdt_reset
localparam logic [ 0 : 0 ] GC_CR_FWCORE_WDT_RESET_EN_BITFIELD                  = 1'h0;

 // gc_cr_fwcore_wdt_ctrl
localparam logic [ 0 : 0 ] GC_CR_FWCORE_WDT_CTRL_ENABLE_BITFIELD               = 1'h0;
localparam logic [ 12 : 8 ] GC_CR_FWCORE_WDT_CTRL_THRESHOLD_BITFIELD           = 5'h0;
localparam logic [ 31 : 16 ] GC_CR_FWCORE_WDT_CTRL_PROT_BITFIELD               = 16'h0;

 // gc_cr_fwcore_wdt_count
localparam logic [ 31 : 0 ] GC_CR_FWCORE_WDT_COUNT_VALUE_BITFIELD              = 32'h0;

 // gc_cr_fwc_uart_base_address
localparam logic [ 31 : 0 ] GC_CR_FWC_UART_BASE_ADDRESS_VALUE_BITFIELD         = 32'h384000;

 // gc_cr_multicore_broadcast
localparam logic [ 7 : 0 ] GC_CR_MULTICORE_BROADCAST_FIRMWARE_MASK_BITFIELD    = 8'hff;
localparam logic [ 15 : 8 ] GC_CR_MULTICORE_BROADCAST_PROGRAMMER_MASK_BITFIELD  = 8'hff;

 // gc_cr_multicore_compute_ctrl_common
localparam logic [ 7 : 0 ] GC_CR_MULTICORE_COMPUTE_CTRL_COMMON_GPU_ENABLE_BITFIELD  = 8'h1;
localparam logic [ 29 : 8 ] GC_CR_MULTICORE_COMPUTE_CTRL_COMMON_EXECUTE_COUNT_BITFIELD  = 22'h0;
localparam logic [ 31 : 30 ] GC_CR_MULTICORE_COMPUTE_CTRL_COMMON_WORKLOAD_TYPE_BITFIELD  = 2'h0;

 // gc_cr_multicore_power
localparam logic [ 7 : 0 ] GC_CR_MULTICORE_POWER_STATE_BITFIELD                = 8'hff;

 // gc_cr_sys_bus_secure
localparam logic [ 0 : 0 ] GC_CR_SYS_BUS_SECURE_ENABLE_BITFIELD                = 1'h1;

 // enum gc_cr_clk_ctrl0_mode
localparam logic [ 1 : 0 ] GC_CR_CLK_CTRL0_MODE_OFF                            = 2'h0;
localparam logic [ 1 : 0 ] GC_CR_CLK_CTRL0_MODE_ON                             = 2'h1;
localparam logic [ 1 : 0 ] GC_CR_CLK_CTRL0_MODE_AUTO                           = 2'h2;

 // gc_cr_clk_ctrl0
localparam logic [ 1 : 0 ] GC_CR_CLK_CTRL0_CPC0_BITFIELD                       = 2'h2;
localparam logic [ 1 : 0 ] GC_CR_CLK_CTRL0_CPC0_OFF                            = 2'h0;
localparam logic [ 1 : 0 ] GC_CR_CLK_CTRL0_CPC0_ON                             = 2'h1;
localparam logic [ 1 : 0 ] GC_CR_CLK_CTRL0_CPC0_AUTO                           = 2'h2;
localparam logic [ 3 : 2 ] GC_CR_CLK_CTRL0_CPC1_BITFIELD                       = 2'h2;
localparam logic [ 3 : 2 ] GC_CR_CLK_CTRL0_CPC1_OFF                            = 2'h0;
localparam logic [ 3 : 2 ] GC_CR_CLK_CTRL0_CPC1_ON                             = 2'h1;
localparam logic [ 3 : 2 ] GC_CR_CLK_CTRL0_CPC1_AUTO                           = 2'h2;
localparam logic [ 5 : 4 ] GC_CR_CLK_CTRL0_CPC2_BITFIELD                       = 2'h2;
localparam logic [ 5 : 4 ] GC_CR_CLK_CTRL0_CPC2_OFF                            = 2'h0;
localparam logic [ 5 : 4 ] GC_CR_CLK_CTRL0_CPC2_ON                             = 2'h1;
localparam logic [ 5 : 4 ] GC_CR_CLK_CTRL0_CPC2_AUTO                           = 2'h2;
localparam logic [ 7 : 6 ] GC_CR_CLK_CTRL0_CPC3_BITFIELD                       = 2'h2;
localparam logic [ 7 : 6 ] GC_CR_CLK_CTRL0_CPC3_OFF                            = 2'h0;
localparam logic [ 7 : 6 ] GC_CR_CLK_CTRL0_CPC3_ON                             = 2'h1;
localparam logic [ 7 : 6 ] GC_CR_CLK_CTRL0_CPC3_AUTO                           = 2'h2;
localparam logic [ 9 : 8 ] GC_CR_CLK_CTRL0_CP_BITFIELD                         = 2'h2;
localparam logic [ 9 : 8 ] GC_CR_CLK_CTRL0_CP_OFF                              = 2'h0;
localparam logic [ 9 : 8 ] GC_CR_CLK_CTRL0_CP_ON                               = 2'h1;
localparam logic [ 9 : 8 ] GC_CR_CLK_CTRL0_CP_AUTO                             = 2'h2;
localparam logic [ 11 : 10 ] GC_CR_CLK_CTRL0_TBU_BIF2AXI_BITFIELD              = 2'h2;
localparam logic [ 11 : 10 ] GC_CR_CLK_CTRL0_TBU_BIF2AXI_OFF                   = 2'h0;
localparam logic [ 11 : 10 ] GC_CR_CLK_CTRL0_TBU_BIF2AXI_ON                    = 2'h1;
localparam logic [ 11 : 10 ] GC_CR_CLK_CTRL0_TBU_BIF2AXI_AUTO                  = 2'h2;
localparam logic [ 13 : 12 ] GC_CR_CLK_CTRL0_CP_BIF_BITFIELD                   = 2'h2;
localparam logic [ 13 : 12 ] GC_CR_CLK_CTRL0_CP_BIF_OFF                        = 2'h0;
localparam logic [ 13 : 12 ] GC_CR_CLK_CTRL0_CP_BIF_ON                         = 2'h1;
localparam logic [ 13 : 12 ] GC_CR_CLK_CTRL0_CP_BIF_AUTO                       = 2'h2;

 // enum gc_cr_clk_status0_mode
localparam logic [ 0 : 0 ] GC_CR_CLK_STATUS0_MODE_GATED                        = 1'h0;
localparam logic [ 0 : 0 ] GC_CR_CLK_STATUS0_MODE_RUNNING                      = 1'h1;

 // gc_cr_clk_status0
localparam logic [ 0 : 0 ] GC_CR_CLK_STATUS0_CPC0_BITFIELD                     = 1'h1;
localparam logic [ 0 : 0 ] GC_CR_CLK_STATUS0_CPC0_GATED                        = 1'h0;
localparam logic [ 0 : 0 ] GC_CR_CLK_STATUS0_CPC0_RUNNING                      = 1'h1;
localparam logic [ 1 : 1 ] GC_CR_CLK_STATUS0_CPC1_BITFIELD                     = 1'h1;
localparam logic [ 1 : 1 ] GC_CR_CLK_STATUS0_CPC1_GATED                        = 1'h0;
localparam logic [ 1 : 1 ] GC_CR_CLK_STATUS0_CPC1_RUNNING                      = 1'h1;
localparam logic [ 2 : 2 ] GC_CR_CLK_STATUS0_CPC2_BITFIELD                     = 1'h1;
localparam logic [ 2 : 2 ] GC_CR_CLK_STATUS0_CPC2_GATED                        = 1'h0;
localparam logic [ 2 : 2 ] GC_CR_CLK_STATUS0_CPC2_RUNNING                      = 1'h1;
localparam logic [ 3 : 3 ] GC_CR_CLK_STATUS0_CPC3_BITFIELD                     = 1'h1;
localparam logic [ 3 : 3 ] GC_CR_CLK_STATUS0_CPC3_GATED                        = 1'h0;
localparam logic [ 3 : 3 ] GC_CR_CLK_STATUS0_CPC3_RUNNING                      = 1'h1;
localparam logic [ 5 : 5 ] GC_CR_CLK_STATUS0_CP_BITFIELD                       = 1'h1;
localparam logic [ 5 : 5 ] GC_CR_CLK_STATUS0_CP_GATED                          = 1'h0;
localparam logic [ 5 : 5 ] GC_CR_CLK_STATUS0_CP_RUNNING                        = 1'h1;
localparam logic [ 6 : 6 ] GC_CR_CLK_STATUS0_TBU_BIF2AXI_BITFIELD              = 1'h1;
localparam logic [ 6 : 6 ] GC_CR_CLK_STATUS0_TBU_BIF2AXI_GATED                 = 1'h0;
localparam logic [ 6 : 6 ] GC_CR_CLK_STATUS0_TBU_BIF2AXI_RUNNING               = 1'h1;
localparam logic [ 7 : 7 ] GC_CR_CLK_STATUS0_CP_BIF_BITFIELD                   = 1'h1;
localparam logic [ 7 : 7 ] GC_CR_CLK_STATUS0_CP_BIF_GATED                      = 1'h0;
localparam logic [ 7 : 7 ] GC_CR_CLK_STATUS0_CP_BIF_RUNNING                    = 1'h1;

 // enum gc_cr_clk_ctrl1_mode
localparam logic [ 1 : 0 ] GC_CR_CLK_CTRL1_MODE_OFF                            = 2'h0;
localparam logic [ 1 : 0 ] GC_CR_CLK_CTRL1_MODE_ON                             = 2'h1;
localparam logic [ 1 : 0 ] GC_CR_CLK_CTRL1_MODE_AUTO                           = 2'h2;

 // gc_cr_clk_ctrl1
localparam logic [ 1 : 0 ] GC_CR_CLK_CTRL1_CPC_PIPE_BITFIELD                   = 2'h2;
localparam logic [ 1 : 0 ] GC_CR_CLK_CTRL1_CPC_PIPE_OFF                        = 2'h0;
localparam logic [ 1 : 0 ] GC_CR_CLK_CTRL1_CPC_PIPE_ON                         = 2'h1;
localparam logic [ 1 : 0 ] GC_CR_CLK_CTRL1_CPC_PIPE_AUTO                       = 2'h2;
localparam logic [ 3 : 2 ] GC_CR_CLK_CTRL1_CU_PIPE_PAP_BITFIELD                = 2'h2;
localparam logic [ 3 : 2 ] GC_CR_CLK_CTRL1_CU_PIPE_PAP_OFF                     = 2'h0;
localparam logic [ 3 : 2 ] GC_CR_CLK_CTRL1_CU_PIPE_PAP_ON                      = 2'h1;
localparam logic [ 3 : 2 ] GC_CR_CLK_CTRL1_CU_PIPE_PAP_AUTO                    = 2'h2;
localparam logic [ 5 : 4 ] GC_CR_CLK_CTRL1_CU_PIPE_SAP_BITFIELD                = 2'h2;
localparam logic [ 5 : 4 ] GC_CR_CLK_CTRL1_CU_PIPE_SAP_OFF                     = 2'h0;
localparam logic [ 5 : 4 ] GC_CR_CLK_CTRL1_CU_PIPE_SAP_ON                      = 2'h1;
localparam logic [ 5 : 4 ] GC_CR_CLK_CTRL1_CU_PIPE_SAP_AUTO                    = 2'h2;
localparam logic [ 7 : 6 ] GC_CR_CLK_CTRL1_CU_PIPE_LMS_BITFIELD                = 2'h2;
localparam logic [ 7 : 6 ] GC_CR_CLK_CTRL1_CU_PIPE_LMS_OFF                     = 2'h0;
localparam logic [ 7 : 6 ] GC_CR_CLK_CTRL1_CU_PIPE_LMS_ON                      = 2'h1;
localparam logic [ 7 : 6 ] GC_CR_CLK_CTRL1_CU_PIPE_LMS_AUTO                    = 2'h2;
localparam logic [ 9 : 8 ] GC_CR_CLK_CTRL1_CU_PIPE_MAU_BITFIELD                = 2'h2;
localparam logic [ 9 : 8 ] GC_CR_CLK_CTRL1_CU_PIPE_MAU_OFF                     = 2'h0;
localparam logic [ 9 : 8 ] GC_CR_CLK_CTRL1_CU_PIPE_MAU_ON                      = 2'h1;
localparam logic [ 9 : 8 ] GC_CR_CLK_CTRL1_CU_PIPE_MAU_AUTO                    = 2'h2;
localparam logic [ 11 : 10 ] GC_CR_CLK_CTRL1_CU_PIPE_TENSOR_BITFIELD           = 2'h2;
localparam logic [ 11 : 10 ] GC_CR_CLK_CTRL1_CU_PIPE_TENSOR_OFF                = 2'h0;
localparam logic [ 11 : 10 ] GC_CR_CLK_CTRL1_CU_PIPE_TENSOR_ON                 = 2'h1;
localparam logic [ 11 : 10 ] GC_CR_CLK_CTRL1_CU_PIPE_TENSOR_AUTO               = 2'h2;
localparam logic [ 13 : 12 ] GC_CR_CLK_CTRL1_CU_PIPE_LSU_BITFIELD              = 2'h2;
localparam logic [ 13 : 12 ] GC_CR_CLK_CTRL1_CU_PIPE_LSU_OFF                   = 2'h0;
localparam logic [ 13 : 12 ] GC_CR_CLK_CTRL1_CU_PIPE_LSU_ON                    = 2'h1;
localparam logic [ 13 : 12 ] GC_CR_CLK_CTRL1_CU_PIPE_LSU_AUTO                  = 2'h2;
localparam logic [ 15 : 14 ] GC_CR_CLK_CTRL1_CU_PIPE_SMP_BITFIELD              = 2'h2;
localparam logic [ 15 : 14 ] GC_CR_CLK_CTRL1_CU_PIPE_SMP_OFF                   = 2'h0;
localparam logic [ 15 : 14 ] GC_CR_CLK_CTRL1_CU_PIPE_SMP_ON                    = 2'h1;
localparam logic [ 15 : 14 ] GC_CR_CLK_CTRL1_CU_PIPE_SMP_AUTO                  = 2'h2;
localparam logic [ 17 : 16 ] GC_CR_CLK_CTRL1_CU_L2ICACHE_BITFIELD              = 2'h2;
localparam logic [ 17 : 16 ] GC_CR_CLK_CTRL1_CU_L2ICACHE_OFF                   = 2'h0;
localparam logic [ 17 : 16 ] GC_CR_CLK_CTRL1_CU_L2ICACHE_ON                    = 2'h1;
localparam logic [ 17 : 16 ] GC_CR_CLK_CTRL1_CU_L2ICACHE_AUTO                  = 2'h2;
localparam logic [ 19 : 18 ] GC_CR_CLK_CTRL1_L0C_BITFIELD                      = 2'h2;
localparam logic [ 19 : 18 ] GC_CR_CLK_CTRL1_L0C_OFF                           = 2'h0;
localparam logic [ 19 : 18 ] GC_CR_CLK_CTRL1_L0C_ON                            = 2'h1;
localparam logic [ 19 : 18 ] GC_CR_CLK_CTRL1_L0C_AUTO                          = 2'h2;
localparam logic [ 23 : 22 ] GC_CR_CLK_CTRL1_L1C_BITFIELD                      = 2'h2;
localparam logic [ 23 : 22 ] GC_CR_CLK_CTRL1_L1C_OFF                           = 2'h0;
localparam logic [ 23 : 22 ] GC_CR_CLK_CTRL1_L1C_ON                            = 2'h1;
localparam logic [ 23 : 22 ] GC_CR_CLK_CTRL1_L1C_AUTO                          = 2'h2;
localparam logic [ 25 : 24 ] GC_CR_CLK_CTRL1_CU0_INSTANCE_BITFIELD             = 2'h2;
localparam logic [ 25 : 24 ] GC_CR_CLK_CTRL1_CU0_INSTANCE_OFF                  = 2'h0;
localparam logic [ 25 : 24 ] GC_CR_CLK_CTRL1_CU0_INSTANCE_ON                   = 2'h1;
localparam logic [ 25 : 24 ] GC_CR_CLK_CTRL1_CU0_INSTANCE_AUTO                 = 2'h2;
localparam logic [ 27 : 26 ] GC_CR_CLK_CTRL1_CU1_INSTANCE_BITFIELD             = 2'h2;
localparam logic [ 27 : 26 ] GC_CR_CLK_CTRL1_CU1_INSTANCE_OFF                  = 2'h0;
localparam logic [ 27 : 26 ] GC_CR_CLK_CTRL1_CU1_INSTANCE_ON                   = 2'h1;
localparam logic [ 27 : 26 ] GC_CR_CLK_CTRL1_CU1_INSTANCE_AUTO                 = 2'h2;
localparam logic [ 29 : 28 ] GC_CR_CLK_CTRL1_CU2_INSTANCE_BITFIELD             = 2'h2;
localparam logic [ 29 : 28 ] GC_CR_CLK_CTRL1_CU2_INSTANCE_OFF                  = 2'h0;
localparam logic [ 29 : 28 ] GC_CR_CLK_CTRL1_CU2_INSTANCE_ON                   = 2'h1;
localparam logic [ 29 : 28 ] GC_CR_CLK_CTRL1_CU2_INSTANCE_AUTO                 = 2'h2;
localparam logic [ 31 : 30 ] GC_CR_CLK_CTRL1_CU3_INSTANCE_BITFIELD             = 2'h2;
localparam logic [ 31 : 30 ] GC_CR_CLK_CTRL1_CU3_INSTANCE_OFF                  = 2'h0;
localparam logic [ 31 : 30 ] GC_CR_CLK_CTRL1_CU3_INSTANCE_ON                   = 2'h1;
localparam logic [ 31 : 30 ] GC_CR_CLK_CTRL1_CU3_INSTANCE_AUTO                 = 2'h2;

 // enum gc_cr_clk_status1_mode
localparam logic [ 0 : 0 ] GC_CR_CLK_STATUS1_MODE_GATED                        = 1'h0;
localparam logic [ 0 : 0 ] GC_CR_CLK_STATUS1_MODE_RUNNING                      = 1'h1;

 // gc_cr_clk_status1
localparam logic [ 0 : 0 ] GC_CR_CLK_STATUS1_CPC_PIPE_BITFIELD                 = 1'h1;
localparam logic [ 0 : 0 ] GC_CR_CLK_STATUS1_CPC_PIPE_GATED                    = 1'h0;
localparam logic [ 0 : 0 ] GC_CR_CLK_STATUS1_CPC_PIPE_RUNNING                  = 1'h1;
localparam logic [ 1 : 1 ] GC_CR_CLK_STATUS1_CU_PIPE_PAP_BITFIELD              = 1'h1;
localparam logic [ 1 : 1 ] GC_CR_CLK_STATUS1_CU_PIPE_PAP_GATED                 = 1'h0;
localparam logic [ 1 : 1 ] GC_CR_CLK_STATUS1_CU_PIPE_PAP_RUNNING               = 1'h1;
localparam logic [ 2 : 2 ] GC_CR_CLK_STATUS1_CU_PIPE_SAP_BITFIELD              = 1'h1;
localparam logic [ 2 : 2 ] GC_CR_CLK_STATUS1_CU_PIPE_SAP_GATED                 = 1'h0;
localparam logic [ 2 : 2 ] GC_CR_CLK_STATUS1_CU_PIPE_SAP_RUNNING               = 1'h1;
localparam logic [ 3 : 3 ] GC_CR_CLK_STATUS1_CU_PIPE_LMS_BITFIELD              = 1'h1;
localparam logic [ 3 : 3 ] GC_CR_CLK_STATUS1_CU_PIPE_LMS_GATED                 = 1'h0;
localparam logic [ 3 : 3 ] GC_CR_CLK_STATUS1_CU_PIPE_LMS_RUNNING               = 1'h1;
localparam logic [ 4 : 4 ] GC_CR_CLK_STATUS1_CU_PIPE_MAU_BITFIELD              = 1'h1;
localparam logic [ 4 : 4 ] GC_CR_CLK_STATUS1_CU_PIPE_MAU_GATED                 = 1'h0;
localparam logic [ 4 : 4 ] GC_CR_CLK_STATUS1_CU_PIPE_MAU_RUNNING               = 1'h1;
localparam logic [ 5 : 5 ] GC_CR_CLK_STATUS1_CU_PIPE_TENSOR_BITFIELD           = 1'h1;
localparam logic [ 5 : 5 ] GC_CR_CLK_STATUS1_CU_PIPE_TENSOR_GATED              = 1'h0;
localparam logic [ 5 : 5 ] GC_CR_CLK_STATUS1_CU_PIPE_TENSOR_RUNNING            = 1'h1;
localparam logic [ 6 : 6 ] GC_CR_CLK_STATUS1_CU_PIPE_LSU_BITFIELD              = 1'h1;
localparam logic [ 6 : 6 ] GC_CR_CLK_STATUS1_CU_PIPE_LSU_GATED                 = 1'h0;
localparam logic [ 6 : 6 ] GC_CR_CLK_STATUS1_CU_PIPE_LSU_RUNNING               = 1'h1;
localparam logic [ 7 : 7 ] GC_CR_CLK_STATUS1_CU_PIPE_SMP_BITFIELD              = 1'h1;
localparam logic [ 7 : 7 ] GC_CR_CLK_STATUS1_CU_PIPE_SMP_GATED                 = 1'h0;
localparam logic [ 7 : 7 ] GC_CR_CLK_STATUS1_CU_PIPE_SMP_RUNNING               = 1'h1;
localparam logic [ 8 : 8 ] GC_CR_CLK_STATUS1_CU_L2ICACHE_BITFIELD              = 1'h1;
localparam logic [ 8 : 8 ] GC_CR_CLK_STATUS1_CU_L2ICACHE_GATED                 = 1'h0;
localparam logic [ 8 : 8 ] GC_CR_CLK_STATUS1_CU_L2ICACHE_RUNNING               = 1'h1;
localparam logic [ 9 : 9 ] GC_CR_CLK_STATUS1_L0C_BITFIELD                      = 1'h1;
localparam logic [ 9 : 9 ] GC_CR_CLK_STATUS1_L0C_GATED                         = 1'h0;
localparam logic [ 9 : 9 ] GC_CR_CLK_STATUS1_L0C_RUNNING                       = 1'h1;
localparam logic [ 11 : 11 ] GC_CR_CLK_STATUS1_L1C_BITFIELD                    = 1'h1;
localparam logic [ 11 : 11 ] GC_CR_CLK_STATUS1_L1C_GATED                       = 1'h0;
localparam logic [ 11 : 11 ] GC_CR_CLK_STATUS1_L1C_RUNNING                     = 1'h1;
localparam logic [ 12 : 12 ] GC_CR_CLK_STATUS1_CU0_INSTANCE_BITFIELD           = 1'h1;
localparam logic [ 12 : 12 ] GC_CR_CLK_STATUS1_CU0_INSTANCE_GATED              = 1'h0;
localparam logic [ 12 : 12 ] GC_CR_CLK_STATUS1_CU0_INSTANCE_RUNNING            = 1'h1;
localparam logic [ 13 : 13 ] GC_CR_CLK_STATUS1_CU1_INSTANCE_BITFIELD           = 1'h1;
localparam logic [ 13 : 13 ] GC_CR_CLK_STATUS1_CU1_INSTANCE_GATED              = 1'h0;
localparam logic [ 13 : 13 ] GC_CR_CLK_STATUS1_CU1_INSTANCE_RUNNING            = 1'h1;
localparam logic [ 14 : 14 ] GC_CR_CLK_STATUS1_CU2_INSTANCE_BITFIELD           = 1'h1;
localparam logic [ 14 : 14 ] GC_CR_CLK_STATUS1_CU2_INSTANCE_GATED              = 1'h0;
localparam logic [ 14 : 14 ] GC_CR_CLK_STATUS1_CU2_INSTANCE_RUNNING            = 1'h1;
localparam logic [ 15 : 15 ] GC_CR_CLK_STATUS1_CU3_INSTANCE_BITFIELD           = 1'h1;
localparam logic [ 15 : 15 ] GC_CR_CLK_STATUS1_CU3_INSTANCE_GATED              = 1'h0;
localparam logic [ 15 : 15 ] GC_CR_CLK_STATUS1_CU3_INSTANCE_RUNNING            = 1'h1;

 // enum gc_cr_clk_ctrl2_mode
localparam logic [ 1 : 0 ] GC_CR_CLK_CTRL2_MODE_OFF                            = 2'h0;
localparam logic [ 1 : 0 ] GC_CR_CLK_CTRL2_MODE_ON                             = 2'h1;
localparam logic [ 1 : 0 ] GC_CR_CLK_CTRL2_MODE_AUTO                           = 2'h2;

 // gc_cr_clk_ctrl2
localparam logic [ 1 : 0 ] GC_CR_CLK_CTRL2_BE_BITFIELD                         = 2'h2;
localparam logic [ 1 : 0 ] GC_CR_CLK_CTRL2_BE_OFF                              = 2'h0;
localparam logic [ 1 : 0 ] GC_CR_CLK_CTRL2_BE_ON                               = 2'h1;
localparam logic [ 1 : 0 ] GC_CR_CLK_CTRL2_BE_AUTO                             = 2'h2;
localparam logic [ 3 : 2 ] GC_CR_CLK_CTRL2_ME_BITFIELD                         = 2'h2;
localparam logic [ 3 : 2 ] GC_CR_CLK_CTRL2_ME_OFF                              = 2'h0;
localparam logic [ 3 : 2 ] GC_CR_CLK_CTRL2_ME_ON                               = 2'h1;
localparam logic [ 3 : 2 ] GC_CR_CLK_CTRL2_ME_AUTO                             = 2'h2;
localparam logic [ 5 : 4 ] GC_CR_CLK_CTRL2_FE_BITFIELD                         = 2'h2;
localparam logic [ 5 : 4 ] GC_CR_CLK_CTRL2_FE_OFF                              = 2'h0;
localparam logic [ 5 : 4 ] GC_CR_CLK_CTRL2_FE_ON                               = 2'h1;
localparam logic [ 5 : 4 ] GC_CR_CLK_CTRL2_FE_AUTO                             = 2'h2;

 // enum gc_cr_clk_status2_mode
localparam logic [ 0 : 0 ] GC_CR_CLK_STATUS2_MODE_GATED                        = 1'h0;
localparam logic [ 0 : 0 ] GC_CR_CLK_STATUS2_MODE_RUNNING                      = 1'h1;

 // gc_cr_clk_status2
localparam logic [ 0 : 0 ] GC_CR_CLK_STATUS2_BE_BITFIELD                       = 1'h1;
localparam logic [ 0 : 0 ] GC_CR_CLK_STATUS2_BE_GATED                          = 1'h0;
localparam logic [ 0 : 0 ] GC_CR_CLK_STATUS2_BE_RUNNING                        = 1'h1;
localparam logic [ 1 : 1 ] GC_CR_CLK_STATUS2_ME_BITFIELD                       = 1'h1;
localparam logic [ 1 : 1 ] GC_CR_CLK_STATUS2_ME_GATED                          = 1'h0;
localparam logic [ 1 : 1 ] GC_CR_CLK_STATUS2_ME_RUNNING                        = 1'h1;
localparam logic [ 2 : 2 ] GC_CR_CLK_STATUS2_FE_BITFIELD                       = 1'h1;
localparam logic [ 2 : 2 ] GC_CR_CLK_STATUS2_FE_GATED                          = 1'h0;
localparam logic [ 2 : 2 ] GC_CR_CLK_STATUS2_FE_RUNNING                        = 1'h1;
localparam logic [ 3 : 3 ] GC_CR_CLK_STATUS2_FE_QUEUE0_BITFIELD                = 1'h1;
localparam logic [ 3 : 3 ] GC_CR_CLK_STATUS2_FE_QUEUE0_GATED                   = 1'h0;
localparam logic [ 3 : 3 ] GC_CR_CLK_STATUS2_FE_QUEUE0_RUNNING                 = 1'h1;
localparam logic [ 4 : 4 ] GC_CR_CLK_STATUS2_FE_QUEUE1_BITFIELD                = 1'h1;
localparam logic [ 4 : 4 ] GC_CR_CLK_STATUS2_FE_QUEUE1_GATED                   = 1'h0;
localparam logic [ 4 : 4 ] GC_CR_CLK_STATUS2_FE_QUEUE1_RUNNING                 = 1'h1;
localparam logic [ 5 : 5 ] GC_CR_CLK_STATUS2_FE_QUEUE2_BITFIELD                = 1'h1;
localparam logic [ 5 : 5 ] GC_CR_CLK_STATUS2_FE_QUEUE2_GATED                   = 1'h0;
localparam logic [ 5 : 5 ] GC_CR_CLK_STATUS2_FE_QUEUE2_RUNNING                 = 1'h1;
localparam logic [ 6 : 6 ] GC_CR_CLK_STATUS2_FE_QUEUE3_BITFIELD                = 1'h1;
localparam logic [ 6 : 6 ] GC_CR_CLK_STATUS2_FE_QUEUE3_GATED                   = 1'h0;
localparam logic [ 6 : 6 ] GC_CR_CLK_STATUS2_FE_QUEUE3_RUNNING                 = 1'h1;
localparam logic [ 7 : 7 ] GC_CR_CLK_STATUS2_FE_QUEUE4_BITFIELD                = 1'h1;
localparam logic [ 7 : 7 ] GC_CR_CLK_STATUS2_FE_QUEUE4_GATED                   = 1'h0;
localparam logic [ 7 : 7 ] GC_CR_CLK_STATUS2_FE_QUEUE4_RUNNING                 = 1'h1;
localparam logic [ 8 : 8 ] GC_CR_CLK_STATUS2_FE_QUEUE5_BITFIELD                = 1'h1;
localparam logic [ 8 : 8 ] GC_CR_CLK_STATUS2_FE_QUEUE5_GATED                   = 1'h0;
localparam logic [ 8 : 8 ] GC_CR_CLK_STATUS2_FE_QUEUE5_RUNNING                 = 1'h1;
localparam logic [ 9 : 9 ] GC_CR_CLK_STATUS2_FE_QUEUE6_BITFIELD                = 1'h1;
localparam logic [ 9 : 9 ] GC_CR_CLK_STATUS2_FE_QUEUE6_GATED                   = 1'h0;
localparam logic [ 9 : 9 ] GC_CR_CLK_STATUS2_FE_QUEUE6_RUNNING                 = 1'h1;
localparam logic [ 10 : 10 ] GC_CR_CLK_STATUS2_FE_QUEUE7_BITFIELD              = 1'h1;
localparam logic [ 10 : 10 ] GC_CR_CLK_STATUS2_FE_QUEUE7_GATED                 = 1'h0;
localparam logic [ 10 : 10 ] GC_CR_CLK_STATUS2_FE_QUEUE7_RUNNING               = 1'h1;

 // enum gc_cr_clk_ctrl3_mode
localparam logic [ 1 : 0 ] GC_CR_CLK_CTRL3_MODE_OFF                            = 2'h0;
localparam logic [ 1 : 0 ] GC_CR_CLK_CTRL3_MODE_ON                             = 2'h1;
localparam logic [ 1 : 0 ] GC_CR_CLK_CTRL3_MODE_AUTO                           = 2'h2;

 // gc_cr_clk_ctrl3
localparam logic [ 1 : 0 ] GC_CR_CLK_CTRL3_L2G0_BITFIELD                       = 2'h2;
localparam logic [ 1 : 0 ] GC_CR_CLK_CTRL3_L2G0_OFF                            = 2'h0;
localparam logic [ 1 : 0 ] GC_CR_CLK_CTRL3_L2G0_ON                             = 2'h1;
localparam logic [ 1 : 0 ] GC_CR_CLK_CTRL3_L2G0_AUTO                           = 2'h2;
localparam logic [ 3 : 2 ] GC_CR_CLK_CTRL3_L2G1_BITFIELD                       = 2'h2;
localparam logic [ 3 : 2 ] GC_CR_CLK_CTRL3_L2G1_OFF                            = 2'h0;
localparam logic [ 3 : 2 ] GC_CR_CLK_CTRL3_L2G1_ON                             = 2'h1;
localparam logic [ 3 : 2 ] GC_CR_CLK_CTRL3_L2G1_AUTO                           = 2'h2;
localparam logic [ 5 : 4 ] GC_CR_CLK_CTRL3_L2G2_BITFIELD                       = 2'h2;
localparam logic [ 5 : 4 ] GC_CR_CLK_CTRL3_L2G2_OFF                            = 2'h0;
localparam logic [ 5 : 4 ] GC_CR_CLK_CTRL3_L2G2_ON                             = 2'h1;
localparam logic [ 5 : 4 ] GC_CR_CLK_CTRL3_L2G2_AUTO                           = 2'h2;
localparam logic [ 7 : 6 ] GC_CR_CLK_CTRL3_L2G3_BITFIELD                       = 2'h2;
localparam logic [ 7 : 6 ] GC_CR_CLK_CTRL3_L2G3_OFF                            = 2'h0;
localparam logic [ 7 : 6 ] GC_CR_CLK_CTRL3_L2G3_ON                             = 2'h1;
localparam logic [ 7 : 6 ] GC_CR_CLK_CTRL3_L2G3_AUTO                           = 2'h2;
localparam logic [ 9 : 8 ] GC_CR_CLK_CTRL3_L2G4_BITFIELD                       = 2'h2;
localparam logic [ 9 : 8 ] GC_CR_CLK_CTRL3_L2G4_OFF                            = 2'h0;
localparam logic [ 9 : 8 ] GC_CR_CLK_CTRL3_L2G4_ON                             = 2'h1;
localparam logic [ 9 : 8 ] GC_CR_CLK_CTRL3_L2G4_AUTO                           = 2'h2;
localparam logic [ 11 : 10 ] GC_CR_CLK_CTRL3_L2G5_BITFIELD                     = 2'h2;
localparam logic [ 11 : 10 ] GC_CR_CLK_CTRL3_L2G5_OFF                          = 2'h0;
localparam logic [ 11 : 10 ] GC_CR_CLK_CTRL3_L2G5_ON                           = 2'h1;
localparam logic [ 11 : 10 ] GC_CR_CLK_CTRL3_L2G5_AUTO                         = 2'h2;
localparam logic [ 13 : 12 ] GC_CR_CLK_CTRL3_L2G6_BITFIELD                     = 2'h2;
localparam logic [ 13 : 12 ] GC_CR_CLK_CTRL3_L2G6_OFF                          = 2'h0;
localparam logic [ 13 : 12 ] GC_CR_CLK_CTRL3_L2G6_ON                           = 2'h1;
localparam logic [ 13 : 12 ] GC_CR_CLK_CTRL3_L2G6_AUTO                         = 2'h2;
localparam logic [ 15 : 14 ] GC_CR_CLK_CTRL3_L2G7_BITFIELD                     = 2'h2;
localparam logic [ 15 : 14 ] GC_CR_CLK_CTRL3_L2G7_OFF                          = 2'h0;
localparam logic [ 15 : 14 ] GC_CR_CLK_CTRL3_L2G7_ON                           = 2'h1;
localparam logic [ 15 : 14 ] GC_CR_CLK_CTRL3_L2G7_AUTO                         = 2'h2;

 // enum gc_cr_clk_status3_mode
localparam logic [ 0 : 0 ] GC_CR_CLK_STATUS3_MODE_GATED                        = 1'h0;
localparam logic [ 0 : 0 ] GC_CR_CLK_STATUS3_MODE_RUNNING                      = 1'h1;

 // gc_cr_clk_status3
localparam logic [ 0 : 0 ] GC_CR_CLK_STATUS3_L2G0_BITFIELD                     = 1'h1;
localparam logic [ 0 : 0 ] GC_CR_CLK_STATUS3_L2G0_GATED                        = 1'h0;
localparam logic [ 0 : 0 ] GC_CR_CLK_STATUS3_L2G0_RUNNING                      = 1'h1;
localparam logic [ 1 : 1 ] GC_CR_CLK_STATUS3_L2G1_BITFIELD                     = 1'h1;
localparam logic [ 1 : 1 ] GC_CR_CLK_STATUS3_L2G1_GATED                        = 1'h0;
localparam logic [ 1 : 1 ] GC_CR_CLK_STATUS3_L2G1_RUNNING                      = 1'h1;
localparam logic [ 2 : 2 ] GC_CR_CLK_STATUS3_L2G2_BITFIELD                     = 1'h1;
localparam logic [ 2 : 2 ] GC_CR_CLK_STATUS3_L2G2_GATED                        = 1'h0;
localparam logic [ 2 : 2 ] GC_CR_CLK_STATUS3_L2G2_RUNNING                      = 1'h1;
localparam logic [ 3 : 3 ] GC_CR_CLK_STATUS3_L2G3_BITFIELD                     = 1'h1;
localparam logic [ 3 : 3 ] GC_CR_CLK_STATUS3_L2G3_GATED                        = 1'h0;
localparam logic [ 3 : 3 ] GC_CR_CLK_STATUS3_L2G3_RUNNING                      = 1'h1;
localparam logic [ 4 : 4 ] GC_CR_CLK_STATUS3_L2G4_BITFIELD                     = 1'h1;
localparam logic [ 4 : 4 ] GC_CR_CLK_STATUS3_L2G4_GATED                        = 1'h0;
localparam logic [ 4 : 4 ] GC_CR_CLK_STATUS3_L2G4_RUNNING                      = 1'h1;
localparam logic [ 5 : 5 ] GC_CR_CLK_STATUS3_L2G5_BITFIELD                     = 1'h1;
localparam logic [ 5 : 5 ] GC_CR_CLK_STATUS3_L2G5_GATED                        = 1'h0;
localparam logic [ 5 : 5 ] GC_CR_CLK_STATUS3_L2G5_RUNNING                      = 1'h1;
localparam logic [ 6 : 6 ] GC_CR_CLK_STATUS3_L2G6_BITFIELD                     = 1'h1;
localparam logic [ 6 : 6 ] GC_CR_CLK_STATUS3_L2G6_GATED                        = 1'h0;
localparam logic [ 6 : 6 ] GC_CR_CLK_STATUS3_L2G6_RUNNING                      = 1'h1;
localparam logic [ 7 : 7 ] GC_CR_CLK_STATUS3_L2G7_BITFIELD                     = 1'h1;
localparam logic [ 7 : 7 ] GC_CR_CLK_STATUS3_L2G7_GATED                        = 1'h0;
localparam logic [ 7 : 7 ] GC_CR_CLK_STATUS3_L2G7_RUNNING                      = 1'h1;

 // enum gc_cr_clk_ctrl4_mode
localparam logic [ 1 : 0 ] GC_CR_CLK_CTRL4_MODE_OFF                            = 2'h0;
localparam logic [ 1 : 0 ] GC_CR_CLK_CTRL4_MODE_ON                             = 2'h1;
localparam logic [ 1 : 0 ] GC_CR_CLK_CTRL4_MODE_AUTO                           = 2'h2;

 // gc_cr_clk_ctrl4
localparam logic [ 1 : 0 ] GC_CR_CLK_CTRL4_GPC0_MMU_BITFIELD                   = 2'h2;
localparam logic [ 1 : 0 ] GC_CR_CLK_CTRL4_GPC0_MMU_OFF                        = 2'h0;
localparam logic [ 1 : 0 ] GC_CR_CLK_CTRL4_GPC0_MMU_ON                         = 2'h1;
localparam logic [ 1 : 0 ] GC_CR_CLK_CTRL4_GPC0_MMU_AUTO                       = 2'h2;
localparam logic [ 3 : 2 ] GC_CR_CLK_CTRL4_GPC1_MMU_BITFIELD                   = 2'h2;
localparam logic [ 3 : 2 ] GC_CR_CLK_CTRL4_GPC1_MMU_OFF                        = 2'h0;
localparam logic [ 3 : 2 ] GC_CR_CLK_CTRL4_GPC1_MMU_ON                         = 2'h1;
localparam logic [ 3 : 2 ] GC_CR_CLK_CTRL4_GPC1_MMU_AUTO                       = 2'h2;
localparam logic [ 5 : 4 ] GC_CR_CLK_CTRL4_GPC2_MMU_BITFIELD                   = 2'h2;
localparam logic [ 5 : 4 ] GC_CR_CLK_CTRL4_GPC2_MMU_OFF                        = 2'h0;
localparam logic [ 5 : 4 ] GC_CR_CLK_CTRL4_GPC2_MMU_ON                         = 2'h1;
localparam logic [ 5 : 4 ] GC_CR_CLK_CTRL4_GPC2_MMU_AUTO                       = 2'h2;
localparam logic [ 7 : 6 ] GC_CR_CLK_CTRL4_GPC3_MMU_BITFIELD                   = 2'h2;
localparam logic [ 7 : 6 ] GC_CR_CLK_CTRL4_GPC3_MMU_OFF                        = 2'h0;
localparam logic [ 7 : 6 ] GC_CR_CLK_CTRL4_GPC3_MMU_ON                         = 2'h1;
localparam logic [ 7 : 6 ] GC_CR_CLK_CTRL4_GPC3_MMU_AUTO                       = 2'h2;
localparam logic [ 9 : 8 ] GC_CR_CLK_CTRL4_CP_MMU_BITFIELD                     = 2'h2;
localparam logic [ 9 : 8 ] GC_CR_CLK_CTRL4_CP_MMU_OFF                          = 2'h0;
localparam logic [ 9 : 8 ] GC_CR_CLK_CTRL4_CP_MMU_ON                           = 2'h1;
localparam logic [ 9 : 8 ] GC_CR_CLK_CTRL4_CP_MMU_AUTO                         = 2'h2;

 // enum gc_cr_clk_status4_mode
localparam logic [ 0 : 0 ] GC_CR_CLK_STATUS4_MODE_GATED                        = 1'h0;
localparam logic [ 0 : 0 ] GC_CR_CLK_STATUS4_MODE_RUNNING                      = 1'h1;

 // gc_cr_clk_status4
localparam logic [ 0 : 0 ] GC_CR_CLK_STATUS4_GPC0_MMU_BITFIELD                 = 1'h1;
localparam logic [ 0 : 0 ] GC_CR_CLK_STATUS4_GPC0_MMU_GATED                    = 1'h0;
localparam logic [ 0 : 0 ] GC_CR_CLK_STATUS4_GPC0_MMU_RUNNING                  = 1'h1;
localparam logic [ 1 : 1 ] GC_CR_CLK_STATUS4_GPC1_MMU_BITFIELD                 = 1'h1;
localparam logic [ 1 : 1 ] GC_CR_CLK_STATUS4_GPC1_MMU_GATED                    = 1'h0;
localparam logic [ 1 : 1 ] GC_CR_CLK_STATUS4_GPC1_MMU_RUNNING                  = 1'h1;
localparam logic [ 2 : 2 ] GC_CR_CLK_STATUS4_GPC2_MMU_BITFIELD                 = 1'h1;
localparam logic [ 2 : 2 ] GC_CR_CLK_STATUS4_GPC2_MMU_GATED                    = 1'h0;
localparam logic [ 2 : 2 ] GC_CR_CLK_STATUS4_GPC2_MMU_RUNNING                  = 1'h1;
localparam logic [ 3 : 3 ] GC_CR_CLK_STATUS4_GPC3_MMU_BITFIELD                 = 1'h1;
localparam logic [ 3 : 3 ] GC_CR_CLK_STATUS4_GPC3_MMU_GATED                    = 1'h0;
localparam logic [ 3 : 3 ] GC_CR_CLK_STATUS4_GPC3_MMU_RUNNING                  = 1'h1;
localparam logic [ 4 : 4 ] GC_CR_CLK_STATUS4_CP_MMU_BITFIELD                   = 1'h1;
localparam logic [ 4 : 4 ] GC_CR_CLK_STATUS4_CP_MMU_GATED                      = 1'h0;
localparam logic [ 4 : 4 ] GC_CR_CLK_STATUS4_CP_MMU_RUNNING                    = 1'h1;

 // enum gc_cr_clk_ctrl5_mode
localparam logic [ 1 : 0 ] GC_CR_CLK_CTRL5_MODE_OFF                            = 2'h0;
localparam logic [ 1 : 0 ] GC_CR_CLK_CTRL5_MODE_ON                             = 2'h1;
localparam logic [ 1 : 0 ] GC_CR_CLK_CTRL5_MODE_AUTO                           = 2'h2;

 // gc_cr_clk_ctrl5
localparam logic [ 1 : 0 ] GC_CR_CLK_CTRL5_TTT_BITFIELD                        = 2'h2;
localparam logic [ 1 : 0 ] GC_CR_CLK_CTRL5_TTT_OFF                             = 2'h0;
localparam logic [ 1 : 0 ] GC_CR_CLK_CTRL5_TTT_ON                              = 2'h1;
localparam logic [ 1 : 0 ] GC_CR_CLK_CTRL5_TTT_AUTO                            = 2'h2;

 // enum gc_cr_clk_status5_mode
localparam logic [ 0 : 0 ] GC_CR_CLK_STATUS5_MODE_GATED                        = 1'h0;
localparam logic [ 0 : 0 ] GC_CR_CLK_STATUS5_MODE_RUNNING                      = 1'h1;

 // gc_cr_clk_status5
localparam logic [ 0 : 0 ] GC_CR_CLK_STATUS5_TTT_BITFIELD                      = 1'h1;
localparam logic [ 0 : 0 ] GC_CR_CLK_STATUS5_TTT_GATED                         = 1'h0;
localparam logic [ 0 : 0 ] GC_CR_CLK_STATUS5_TTT_RUNNING                       = 1'h1;

 // gc_cr_soft_reset
localparam logic [ 2 : 2 ] GC_CR_SOFT_RESET_COMPUTE0_BITFIELD                  = 1'h0;
localparam logic [ 3 : 3 ] GC_CR_SOFT_RESET_COMPUTE1_BITFIELD                  = 1'h0;
localparam logic [ 4 : 4 ] GC_CR_SOFT_RESET_COMPUTE2_BITFIELD                  = 1'h0;
localparam logic [ 5 : 5 ] GC_CR_SOFT_RESET_COMPUTE3_BITFIELD                  = 1'h0;
localparam logic [ 9 : 9 ] GC_CR_SOFT_RESET_FWTOP_BITFIELD                     = 1'h0;
localparam logic [ 12 : 12 ] GC_CR_SOFT_RESET_CE_BITFIELD                      = 1'h0;
localparam logic [ 13 : 13 ] GC_CR_SOFT_RESET_CE_QUEUE0_BITFIELD               = 1'h0;
localparam logic [ 14 : 14 ] GC_CR_SOFT_RESET_CE_QUEUE1_BITFIELD               = 1'h0;
localparam logic [ 15 : 15 ] GC_CR_SOFT_RESET_CE_QUEUE2_BITFIELD               = 1'h0;
localparam logic [ 16 : 16 ] GC_CR_SOFT_RESET_CE_QUEUE3_BITFIELD               = 1'h0;
localparam logic [ 17 : 17 ] GC_CR_SOFT_RESET_CE_QUEUE4_BITFIELD               = 1'h0;
localparam logic [ 18 : 18 ] GC_CR_SOFT_RESET_CE_QUEUE5_BITFIELD               = 1'h0;
localparam logic [ 19 : 19 ] GC_CR_SOFT_RESET_CE_QUEUE6_BITFIELD               = 1'h0;
localparam logic [ 20 : 20 ] GC_CR_SOFT_RESET_CE_QUEUE7_BITFIELD               = 1'h0;
localparam logic [ 21 : 21 ] GC_CR_SOFT_RESET_GPC0_BITFIELD                    = 1'h0;
localparam logic [ 22 : 22 ] GC_CR_SOFT_RESET_GPC1_BITFIELD                    = 1'h0;
localparam logic [ 23 : 23 ] GC_CR_SOFT_RESET_GPC2_BITFIELD                    = 1'h0;
localparam logic [ 24 : 24 ] GC_CR_SOFT_RESET_GPC3_BITFIELD                    = 1'h0;
localparam logic [ 25 : 25 ] GC_CR_SOFT_RESET_CP_BITFIELD                      = 1'h0;
localparam logic [ 26 : 26 ] GC_CR_SOFT_RESET_CP_CE_BITFIELD                   = 1'h0;
localparam logic [ 39 : 39 ] GC_CR_SOFT_RESET_CP_BIF_BITFIELD                  = 1'h0;

 // gc_cr_power_complete_or_abort
localparam logic [ 0 : 0 ] GC_CR_POWER_COMPLETE_OR_ABORT_COMPLETE_BITFIELD     = 1'h0;
localparam logic [ 1 : 1 ] GC_CR_POWER_COMPLETE_OR_ABORT_ABORT_BITFIELD        = 1'h0;

 // gc_cr_event_enable
localparam logic [ 0 : 0 ] GC_CR_EVENT_ENABLE_COMPUTE0_FINISHED_BITFIELD       = 1'h0;
localparam logic [ 1 : 1 ] GC_CR_EVENT_ENABLE_COMPUTE0_BUFFER_STALL_BITFIELD   = 1'h0;
localparam logic [ 2 : 2 ] GC_CR_EVENT_ENABLE_COMPUTE0_SIGNAL_FAILURE_BITFIELD  = 1'h0;
localparam logic [ 3 : 3 ] GC_CR_EVENT_ENABLE_COMPUTE0_FENCE_UPDATE_BITFIELD   = 1'h0;
localparam logic [ 4 : 4 ] GC_CR_EVENT_ENABLE_COMPUTE1_FINISHED_BITFIELD       = 1'h0;
localparam logic [ 5 : 5 ] GC_CR_EVENT_ENABLE_COMPUTE1_BUFFER_STALL_BITFIELD   = 1'h0;
localparam logic [ 6 : 6 ] GC_CR_EVENT_ENABLE_COMPUTE1_SIGNAL_FAILURE_BITFIELD  = 1'h0;
localparam logic [ 7 : 7 ] GC_CR_EVENT_ENABLE_COMPUTE1_FENCE_UPDATE_BITFIELD   = 1'h0;
localparam logic [ 8 : 8 ] GC_CR_EVENT_ENABLE_COMPUTE2_FINISHED_BITFIELD       = 1'h0;
localparam logic [ 9 : 9 ] GC_CR_EVENT_ENABLE_COMPUTE2_BUFFER_STALL_BITFIELD   = 1'h0;
localparam logic [ 10 : 10 ] GC_CR_EVENT_ENABLE_COMPUTE2_SIGNAL_FAILURE_BITFIELD  = 1'h0;
localparam logic [ 11 : 11 ] GC_CR_EVENT_ENABLE_COMPUTE2_FENCE_UPDATE_BITFIELD  = 1'h0;
localparam logic [ 12 : 12 ] GC_CR_EVENT_ENABLE_COMPUTE3_FINISHED_BITFIELD     = 1'h0;
localparam logic [ 13 : 13 ] GC_CR_EVENT_ENABLE_COMPUTE3_BUFFER_STALL_BITFIELD  = 1'h0;
localparam logic [ 14 : 14 ] GC_CR_EVENT_ENABLE_COMPUTE3_SIGNAL_FAILURE_BITFIELD  = 1'h0;
localparam logic [ 15 : 15 ] GC_CR_EVENT_ENABLE_COMPUTE3_FENCE_UPDATE_BITFIELD  = 1'h0;
localparam logic [ 16 : 16 ] GC_CR_EVENT_ENABLE_MMU_PAGE_FAULT_BITFIELD        = 1'h0;
localparam logic [ 17 : 17 ] GC_CR_EVENT_ENABLE_CU_TRIGGER_BITFIELD            = 1'h0;
localparam logic [ 18 : 18 ] GC_CR_EVENT_ENABLE_WDT_TIMEOUT_BITFIELD           = 1'h0;
localparam logic [ 19 : 19 ] GC_CR_EVENT_ENABLE_CE_QUEUE0_BITFIELD             = 1'h0;
localparam logic [ 20 : 20 ] GC_CR_EVENT_ENABLE_CE_QUEUE1_BITFIELD             = 1'h0;
localparam logic [ 21 : 21 ] GC_CR_EVENT_ENABLE_CE_QUEUE2_BITFIELD             = 1'h0;
localparam logic [ 22 : 22 ] GC_CR_EVENT_ENABLE_CE_QUEUE3_BITFIELD             = 1'h0;
localparam logic [ 23 : 23 ] GC_CR_EVENT_ENABLE_CE_QUEUE4_BITFIELD             = 1'h0;
localparam logic [ 24 : 24 ] GC_CR_EVENT_ENABLE_CE_QUEUE5_BITFIELD             = 1'h0;
localparam logic [ 25 : 25 ] GC_CR_EVENT_ENABLE_CE_QUEUE6_BITFIELD             = 1'h0;
localparam logic [ 26 : 26 ] GC_CR_EVENT_ENABLE_CE_QUEUE7_BITFIELD             = 1'h0;
localparam logic [ 27 : 27 ] GC_CR_EVENT_ENABLE_PERF_MON_DONE_BITFIELD         = 1'h0;
localparam logic [ 28 : 28 ] GC_CR_EVENT_ENABLE_DOORBELL_KICK_BITFIELD         = 1'h0;
localparam logic [ 29 : 29 ] GC_CR_EVENT_ENABLE_POWER_COMPLETE_OR_ABORT_BITFIELD  = 1'h0;
localparam logic [ 30 : 30 ] GC_CR_EVENT_ENABLE_PIM_BITFIELD                   = 1'h0;
localparam logic [ 31 : 31 ] GC_CR_EVENT_ENABLE_UART_BITFIELD                  = 1'h0;

 // gc_cr_event_status
localparam logic [ 0 : 0 ] GC_CR_EVENT_STATUS_COMPUTE0_FINISHED_BITFIELD       = 1'h0;
localparam logic [ 1 : 1 ] GC_CR_EVENT_STATUS_COMPUTE0_BUFFER_STALL_BITFIELD   = 1'h0;
localparam logic [ 2 : 2 ] GC_CR_EVENT_STATUS_COMPUTE0_SIGNAL_FAILURE_BITFIELD  = 1'h0;
localparam logic [ 3 : 3 ] GC_CR_EVENT_STATUS_COMPUTE0_FENCE_UPDATE_BITFIELD   = 1'h0;
localparam logic [ 4 : 4 ] GC_CR_EVENT_STATUS_COMPUTE1_FINISHED_BITFIELD       = 1'h0;
localparam logic [ 5 : 5 ] GC_CR_EVENT_STATUS_COMPUTE1_BUFFER_STALL_BITFIELD   = 1'h0;
localparam logic [ 6 : 6 ] GC_CR_EVENT_STATUS_COMPUTE1_SIGNAL_FAILURE_BITFIELD  = 1'h0;
localparam logic [ 7 : 7 ] GC_CR_EVENT_STATUS_COMPUTE1_FENCE_UPDATE_BITFIELD   = 1'h0;
localparam logic [ 8 : 8 ] GC_CR_EVENT_STATUS_COMPUTE2_FINISHED_BITFIELD       = 1'h0;
localparam logic [ 9 : 9 ] GC_CR_EVENT_STATUS_COMPUTE2_BUFFER_STALL_BITFIELD   = 1'h0;
localparam logic [ 10 : 10 ] GC_CR_EVENT_STATUS_COMPUTE2_SIGNAL_FAILURE_BITFIELD  = 1'h0;
localparam logic [ 11 : 11 ] GC_CR_EVENT_STATUS_COMPUTE2_FENCE_UPDATE_BITFIELD  = 1'h0;
localparam logic [ 12 : 12 ] GC_CR_EVENT_STATUS_COMPUTE3_FINISHED_BITFIELD     = 1'h0;
localparam logic [ 13 : 13 ] GC_CR_EVENT_STATUS_COMPUTE3_BUFFER_STALL_BITFIELD  = 1'h0;
localparam logic [ 14 : 14 ] GC_CR_EVENT_STATUS_COMPUTE3_SIGNAL_FAILURE_BITFIELD  = 1'h0;
localparam logic [ 15 : 15 ] GC_CR_EVENT_STATUS_COMPUTE3_FENCE_UPDATE_BITFIELD  = 1'h0;
localparam logic [ 16 : 16 ] GC_CR_EVENT_STATUS_MMU_PAGE_FAULT_BITFIELD        = 1'h0;
localparam logic [ 17 : 17 ] GC_CR_EVENT_STATUS_CU_TRIGGER_BITFIELD            = 1'h0;
localparam logic [ 18 : 18 ] GC_CR_EVENT_STATUS_WDT_TIMEOUT_BITFIELD           = 1'h0;
localparam logic [ 19 : 19 ] GC_CR_EVENT_STATUS_CE_QUEUE0_BITFIELD             = 1'h0;
localparam logic [ 20 : 20 ] GC_CR_EVENT_STATUS_CE_QUEUE1_BITFIELD             = 1'h0;
localparam logic [ 21 : 21 ] GC_CR_EVENT_STATUS_CE_QUEUE2_BITFIELD             = 1'h0;
localparam logic [ 22 : 22 ] GC_CR_EVENT_STATUS_CE_QUEUE3_BITFIELD             = 1'h0;
localparam logic [ 23 : 23 ] GC_CR_EVENT_STATUS_CE_QUEUE4_BITFIELD             = 1'h0;
localparam logic [ 24 : 24 ] GC_CR_EVENT_STATUS_CE_QUEUE5_BITFIELD             = 1'h0;
localparam logic [ 25 : 25 ] GC_CR_EVENT_STATUS_CE_QUEUE6_BITFIELD             = 1'h0;
localparam logic [ 26 : 26 ] GC_CR_EVENT_STATUS_CE_QUEUE7_BITFIELD             = 1'h0;
localparam logic [ 27 : 27 ] GC_CR_EVENT_STATUS_PERF_MON_DONE_BITFIELD         = 1'h0;
localparam logic [ 28 : 28 ] GC_CR_EVENT_STATUS_DOORBELL_KICK_BITFIELD         = 1'h0;
localparam logic [ 29 : 29 ] GC_CR_EVENT_STATUS_POWER_COMPLETE_OR_ABORT_BITFIELD  = 1'h0;
localparam logic [ 30 : 30 ] GC_CR_EVENT_STATUS_PIM_BITFIELD                   = 1'h0;
localparam logic [ 31 : 31 ] GC_CR_EVENT_STATUS_UART_BITFIELD                  = 1'h0;

 // gc_cr_event_clear
localparam logic [ 0 : 0 ] GC_CR_EVENT_CLEAR_COMPUTE0_FINISHED_BITFIELD        = 1'h0;
localparam logic [ 1 : 1 ] GC_CR_EVENT_CLEAR_COMPUTE0_BUFFER_STALL_BITFIELD    = 1'h0;
localparam logic [ 2 : 2 ] GC_CR_EVENT_CLEAR_COMPUTE0_SIGNAL_FAILURE_BITFIELD  = 1'h0;
localparam logic [ 3 : 3 ] GC_CR_EVENT_CLEAR_COMPUTE0_FENCE_UPDATE_BITFIELD    = 1'h0;
localparam logic [ 4 : 4 ] GC_CR_EVENT_CLEAR_COMPUTE1_FINISHED_BITFIELD        = 1'h0;
localparam logic [ 5 : 5 ] GC_CR_EVENT_CLEAR_COMPUTE1_BUFFER_STALL_BITFIELD    = 1'h0;
localparam logic [ 6 : 6 ] GC_CR_EVENT_CLEAR_COMPUTE1_SIGNAL_FAILURE_BITFIELD  = 1'h0;
localparam logic [ 7 : 7 ] GC_CR_EVENT_CLEAR_COMPUTE1_FENCE_UPDATE_BITFIELD    = 1'h0;
localparam logic [ 8 : 8 ] GC_CR_EVENT_CLEAR_COMPUTE2_FINISHED_BITFIELD        = 1'h0;
localparam logic [ 9 : 9 ] GC_CR_EVENT_CLEAR_COMPUTE2_BUFFER_STALL_BITFIELD    = 1'h0;
localparam logic [ 10 : 10 ] GC_CR_EVENT_CLEAR_COMPUTE2_SIGNAL_FAILURE_BITFIELD  = 1'h0;
localparam logic [ 11 : 11 ] GC_CR_EVENT_CLEAR_COMPUTE2_FENCE_UPDATE_BITFIELD  = 1'h0;
localparam logic [ 12 : 12 ] GC_CR_EVENT_CLEAR_COMPUTE3_FINISHED_BITFIELD      = 1'h0;
localparam logic [ 13 : 13 ] GC_CR_EVENT_CLEAR_COMPUTE3_BUFFER_STALL_BITFIELD  = 1'h0;
localparam logic [ 14 : 14 ] GC_CR_EVENT_CLEAR_COMPUTE3_SIGNAL_FAILURE_BITFIELD  = 1'h0;
localparam logic [ 15 : 15 ] GC_CR_EVENT_CLEAR_COMPUTE3_FENCE_UPDATE_BITFIELD  = 1'h0;
localparam logic [ 16 : 16 ] GC_CR_EVENT_CLEAR_MMU_PAGE_FAULT_BITFIELD         = 1'h0;
localparam logic [ 17 : 17 ] GC_CR_EVENT_CLEAR_CU_TRIGGER_BITFIELD             = 1'h0;
localparam logic [ 18 : 18 ] GC_CR_EVENT_CLEAR_WDT_TIMEOUT_BITFIELD            = 1'h0;
localparam logic [ 19 : 19 ] GC_CR_EVENT_CLEAR_CE_QUEUE0_BITFIELD              = 1'h0;
localparam logic [ 20 : 20 ] GC_CR_EVENT_CLEAR_CE_QUEUE1_BITFIELD              = 1'h0;
localparam logic [ 21 : 21 ] GC_CR_EVENT_CLEAR_CE_QUEUE2_BITFIELD              = 1'h0;
localparam logic [ 22 : 22 ] GC_CR_EVENT_CLEAR_CE_QUEUE3_BITFIELD              = 1'h0;
localparam logic [ 23 : 23 ] GC_CR_EVENT_CLEAR_CE_QUEUE4_BITFIELD              = 1'h0;
localparam logic [ 24 : 24 ] GC_CR_EVENT_CLEAR_CE_QUEUE5_BITFIELD              = 1'h0;
localparam logic [ 25 : 25 ] GC_CR_EVENT_CLEAR_CE_QUEUE6_BITFIELD              = 1'h0;
localparam logic [ 26 : 26 ] GC_CR_EVENT_CLEAR_CE_QUEUE7_BITFIELD              = 1'h0;
localparam logic [ 27 : 27 ] GC_CR_EVENT_CLEAR_PERF_MON_DONE_BITFIELD          = 1'h0;
localparam logic [ 28 : 28 ] GC_CR_EVENT_CLEAR_DOORBELL_KICK_BITFIELD          = 1'h0;
localparam logic [ 29 : 29 ] GC_CR_EVENT_CLEAR_POWER_COMPLETE_OR_ABORT_BITFIELD  = 1'h0;
localparam logic [ 30 : 30 ] GC_CR_EVENT_CLEAR_PIM_BITFIELD                    = 1'h0;
localparam logic [ 31 : 31 ] GC_CR_EVENT_CLEAR_UART_BITFIELD                   = 1'h0;

 // gc_cr_trm_ctrl
localparam logic [ 0 : 0 ] GC_CR_TRM_CTRL_SM_OVERLAP_ENABLE_BITFIELD           = 1'h1;
localparam logic [ 7 : 1 ] GC_CR_TRM_CTRL_MAX_NUM_CPC0_TASKS_BITFIELD          = 7'h30;
localparam logic [ 14 : 8 ] GC_CR_TRM_CTRL_MAX_NUM_CPC1_TASKS_BITFIELD         = 7'h30;
localparam logic [ 21 : 15 ] GC_CR_TRM_CTRL_MAX_NUM_CPC2_TASKS_BITFIELD        = 7'h30;
localparam logic [ 28 : 22 ] GC_CR_TRM_CTRL_MAX_NUM_CPC3_TASKS_BITFIELD        = 7'h30;

 // gc_cr_dmkill
localparam logic [ 0 : 0 ] GC_CR_DMKILL_CPC0_BITFIELD                          = 1'h0;
localparam logic [ 1 : 1 ] GC_CR_DMKILL_CPC1_BITFIELD                          = 1'h0;
localparam logic [ 2 : 2 ] GC_CR_DMKILL_CPC2_BITFIELD                          = 1'h0;
localparam logic [ 3 : 3 ] GC_CR_DMKILL_CPC3_BITFIELD                          = 1'h0;

 // gc_cr_cp_idle
localparam logic [ 0 : 0 ] GC_CR_CP_IDLE_GMUTEX_BITFIELD                       = 1'h1;
localparam logic [ 1 : 1 ] GC_CR_CP_IDLE_BIF_WRAP_BITFIELD                     = 1'h1;
localparam logic [ 2 : 2 ] GC_CR_CP_IDLE_CPC_PREFETCH_ARB_BITFIELD             = 1'h1;
localparam logic [ 3 : 3 ] GC_CR_CP_IDLE_CPC3_BITFIELD                         = 1'h1;
localparam logic [ 4 : 4 ] GC_CR_CP_IDLE_CPC2_BITFIELD                         = 1'h1;
localparam logic [ 5 : 5 ] GC_CR_CP_IDLE_CPC1_BITFIELD                         = 1'h1;
localparam logic [ 6 : 6 ] GC_CR_CP_IDLE_CPC0_BITFIELD                         = 1'h1;
localparam logic [ 7 : 7 ] GC_CR_CP_IDLE_CP_ARB_BITFIELD                       = 1'h1;
localparam logic [ 8 : 8 ] GC_CR_CP_IDLE_SOCIF_BITFIELD                        = 1'h1;
localparam logic [ 10 : 10 ] GC_CR_CP_IDLE_AXI_MMU_BITFIELD                    = 1'h1;
localparam logic [ 11 : 11 ] GC_CR_CP_IDLE_FAULT_ARB_BITFIELD                  = 1'h1;
localparam logic [ 12 : 12 ] GC_CR_CP_IDLE_FWC_BITFIELD                        = 1'h1;
localparam logic [ 13 : 13 ] GC_CR_CP_IDLE_DFU_BITFIELD                        = 1'h1;
localparam logic [ 14 : 14 ] GC_CR_CP_IDLE_GSYNC_BITFIELD                      = 1'h1;

 // gc_cr_gpc_idle
localparam logic [ 0 : 0 ] GC_CR_GPC_IDLE_MUTEX_CTRL_BITFIELD                  = 1'h1;
localparam logic [ 1 : 1 ] GC_CR_GPC_IDLE_CTD_BITFIELD                         = 1'h1;
localparam logic [ 2 : 2 ] GC_CR_GPC_IDLE_SPC1_BITFIELD                        = 1'h1;
localparam logic [ 3 : 3 ] GC_CR_GPC_IDLE_SPC0_BITFIELD                        = 1'h1;

 // gc_cr_pu_prefetch_ctrl
localparam logic [ 4 : 0 ] GC_CR_PU_PREFETCH_CTRL_SIZE_BITFIELD                = 5'h0;
localparam logic [ 10 : 5 ] GC_CR_PU_PREFETCH_CTRL_CTX_ID_BITFIELD             = 6'h0;
localparam logic [ 11 : 11 ] GC_CR_PU_PREFETCH_CTRL_L2_CACHE_POLICY_BITFIELD   = 1'h0;
localparam logic [ 13 : 12 ] GC_CR_PU_PREFETCH_CTRL_PERSISTENCE_BITFIELD       = 2'h0;

 // gc_cr_pu_prefetch
localparam logic [ 47 : 0 ] GC_CR_PU_PREFETCH_ADDR_BITFIELD                    = 48'h0;

 // gc_cr_merge_delay
localparam logic [ 15 : 0 ] GC_CR_MERGE_DELAY_CP_CNT_BITFIELD                  = 16'h28;
localparam logic [ 31 : 16 ] GC_CR_MERGE_DELAY_SPC_CNT_BITFIELD                = 16'h28;

 // gc_cr_pf_doorbell_index
localparam logic [ 11 : 0 ] GC_CR_PF_DOORBELL_INDEX_INDEX_BITFIELD             = 12'h0;

 // gc_cr_vf1_doorbell_index
localparam logic [ 11 : 0 ] GC_CR_VF1_DOORBELL_INDEX_INDEX_BITFIELD            = 12'h0;

 // gc_cr_vf2_doorbell_index
localparam logic [ 11 : 0 ] GC_CR_VF2_DOORBELL_INDEX_INDEX_BITFIELD            = 12'h0;

 // gc_cr_vf3_doorbell_index
localparam logic [ 11 : 0 ] GC_CR_VF3_DOORBELL_INDEX_INDEX_BITFIELD            = 12'h0;

 // gc_cr_vf4_doorbell_index
localparam logic [ 11 : 0 ] GC_CR_VF4_DOORBELL_INDEX_INDEX_BITFIELD            = 12'h0;

 // gc_cr_vf5_doorbell_index
localparam logic [ 11 : 0 ] GC_CR_VF5_DOORBELL_INDEX_INDEX_BITFIELD            = 12'h0;

 // gc_cr_vf6_doorbell_index
localparam logic [ 11 : 0 ] GC_CR_VF6_DOORBELL_INDEX_INDEX_BITFIELD            = 12'h0;

 // gc_cr_vf7_doorbell_index
localparam logic [ 11 : 0 ] GC_CR_VF7_DOORBELL_INDEX_INDEX_BITFIELD            = 12'h0;

 // gc_cr_vf8_doorbell_index
localparam logic [ 11 : 0 ] GC_CR_VF8_DOORBELL_INDEX_INDEX_BITFIELD            = 12'h0;

 // gc_cr_vf9_doorbell_index
localparam logic [ 11 : 0 ] GC_CR_VF9_DOORBELL_INDEX_INDEX_BITFIELD            = 12'h0;

 // gc_cr_vf10_doorbell_index
localparam logic [ 11 : 0 ] GC_CR_VF10_DOORBELL_INDEX_INDEX_BITFIELD           = 12'h0;

 // gc_cr_vf11_doorbell_index
localparam logic [ 11 : 0 ] GC_CR_VF11_DOORBELL_INDEX_INDEX_BITFIELD           = 12'h0;

 // gc_cr_vf12_doorbell_index
localparam logic [ 11 : 0 ] GC_CR_VF12_DOORBELL_INDEX_INDEX_BITFIELD           = 12'h0;

 // gc_cr_vf13_doorbell_index
localparam logic [ 11 : 0 ] GC_CR_VF13_DOORBELL_INDEX_INDEX_BITFIELD           = 12'h0;

 // gc_cr_vf14_doorbell_index
localparam logic [ 11 : 0 ] GC_CR_VF14_DOORBELL_INDEX_INDEX_BITFIELD           = 12'h0;

 // gc_cr_vf15_doorbell_index
localparam logic [ 11 : 0 ] GC_CR_VF15_DOORBELL_INDEX_INDEX_BITFIELD           = 12'h0;

 // gc_cr_pf_queue_num
localparam logic [ 5 : 0 ] GC_CR_PF_QUEUE_NUM_NUM_BITFIELD                     = 6'h0;

 // gc_cr_vf1_queue_num
localparam logic [ 5 : 0 ] GC_CR_VF1_QUEUE_NUM_NUM_BITFIELD                    = 6'h0;

 // gc_cr_vf2_queue_num
localparam logic [ 5 : 0 ] GC_CR_VF2_QUEUE_NUM_NUM_BITFIELD                    = 6'h0;

 // gc_cr_vf3_queue_num
localparam logic [ 5 : 0 ] GC_CR_VF3_QUEUE_NUM_NUM_BITFIELD                    = 6'h0;

 // gc_cr_vf4_queue_num
localparam logic [ 5 : 0 ] GC_CR_VF4_QUEUE_NUM_NUM_BITFIELD                    = 6'h0;

 // gc_cr_vf5_queue_num
localparam logic [ 5 : 0 ] GC_CR_VF5_QUEUE_NUM_NUM_BITFIELD                    = 6'h0;

 // gc_cr_vf6_queue_num
localparam logic [ 5 : 0 ] GC_CR_VF6_QUEUE_NUM_NUM_BITFIELD                    = 6'h0;

 // gc_cr_vf7_queue_num
localparam logic [ 5 : 0 ] GC_CR_VF7_QUEUE_NUM_NUM_BITFIELD                    = 6'h0;

 // gc_cr_vf8_queue_num
localparam logic [ 5 : 0 ] GC_CR_VF8_QUEUE_NUM_NUM_BITFIELD                    = 6'h0;

 // gc_cr_vf9_queue_num
localparam logic [ 5 : 0 ] GC_CR_VF9_QUEUE_NUM_NUM_BITFIELD                    = 6'h0;

 // gc_cr_vf10_queue_num
localparam logic [ 5 : 0 ] GC_CR_VF10_QUEUE_NUM_NUM_BITFIELD                   = 6'h0;

 // gc_cr_vf11_queue_num
localparam logic [ 5 : 0 ] GC_CR_VF11_QUEUE_NUM_NUM_BITFIELD                   = 6'h0;

 // gc_cr_vf12_queue_num
localparam logic [ 5 : 0 ] GC_CR_VF12_QUEUE_NUM_NUM_BITFIELD                   = 6'h0;

 // gc_cr_vf13_queue_num
localparam logic [ 5 : 0 ] GC_CR_VF13_QUEUE_NUM_NUM_BITFIELD                   = 6'h0;

 // gc_cr_vf14_queue_num
localparam logic [ 5 : 0 ] GC_CR_VF14_QUEUE_NUM_NUM_BITFIELD                   = 6'h0;

 // gc_cr_vf15_queue_num
localparam logic [ 5 : 0 ] GC_CR_VF15_QUEUE_NUM_NUM_BITFIELD                   = 6'h0;

 // gc_cr_hw_queue_indirect
localparam logic [ 5 : 0 ] GC_CR_HW_QUEUE_INDIRECT_INDIRECT_BITFIELD           = 6'h0;

 // gc_cr_fw_poll_hw_queue
localparam logic [ 63 : 0 ] GC_CR_FW_POLL_HW_QUEUE_QUEUE_BITFIELD              = 64'h0;

 // gc_cr_hw_queue_doorbell_low
localparam logic [ 31 : 0 ] GC_CR_HW_QUEUE_DOORBELL_LOW_DOORBELL_BITFIELD      = 32'h0;

 // gc_cr_hw_queue_doorbell_high
localparam logic [ 31 : 0 ] GC_CR_HW_QUEUE_DOORBELL_HIGH_DOORBELL_BITFIELD     = 32'h0;

 // gc_cr_cpc0_compute_enable
localparam logic [ 63 : 0 ] GC_CR_CPC0_COMPUTE_ENABLE_CLUSTER_BITFIELD         = 64'hffffffffffffffff;

 // gc_cr_cpc1_compute_enable
localparam logic [ 63 : 0 ] GC_CR_CPC1_COMPUTE_ENABLE_CLUSTER_BITFIELD         = 64'hffffffffffffffff;

 // gc_cr_cpc2_compute_enable
localparam logic [ 63 : 0 ] GC_CR_CPC2_COMPUTE_ENABLE_CLUSTER_BITFIELD         = 64'hffffffffffffffff;

 // gc_cr_cpc3_compute_enable
localparam logic [ 63 : 0 ] GC_CR_CPC3_COMPUTE_ENABLE_CLUSTER_BITFIELD         = 64'hffffffffffffffff;

 // gc_cr_cpc_ctrl
localparam logic [ 0 : 0 ] GC_CR_CPC_CTRL_WORKGROUP_MODE_BITFIELD              = 1'h0;
localparam logic [ 0 : 0 ] GC_CR_CPC_CTRL_WORKGROUP_MODE_DEMAND                = 1'h0;
localparam logic [ 0 : 0 ] GC_CR_CPC_CTRL_WORKGROUP_MODE_ROUND_ROBIN_STRICT    = 1'h1;

 // gc_cr_cpc_ctrl_kernel
localparam logic [ 0 : 0 ] GC_CR_CPC_CTRL_KERNEL_PREEMPT_ENABLE_BITFIELD       = 1'h0;

 // gc_cr_cp_arb_cpc0
localparam logic [ 1 : 0 ] GC_CR_CP_ARB_CPC0_PRIORITY_BITFIELD                 = 2'h1;

 // gc_cr_cp_arb_cpc1
localparam logic [ 1 : 0 ] GC_CR_CP_ARB_CPC1_PRIORITY_BITFIELD                 = 2'h1;

 // gc_cr_cp_arb_cpc2
localparam logic [ 1 : 0 ] GC_CR_CP_ARB_CPC2_PRIORITY_BITFIELD                 = 2'h1;

 // gc_cr_cp_arb_cpc3
localparam logic [ 1 : 0 ] GC_CR_CP_ARB_CPC3_PRIORITY_BITFIELD                 = 2'h1;

 // gc_cr_cp_arb_parition
localparam logic [ 3 : 0 ] GC_CR_CP_ARB_PARITION_MAX_CREDIT_BITFIELD           = 4'h0;

 // gc_cr_cp_pim0_virtual_address
localparam logic [ 47 : 0 ] GC_CR_CP_PIM0_VIRTUAL_ADDRESS_ADDRESS_BITFIELD     = 48'h2000000000;

 // gc_cr_cp_pim1_virtual_address
localparam logic [ 47 : 0 ] GC_CR_CP_PIM1_VIRTUAL_ADDRESS_ADDRESS_BITFIELD     = 48'h4000000000;

 // gc_cr_cp_pim_credit_counter
localparam logic [ 4 : 0 ] GC_CR_CP_PIM_CREDIT_COUNTER_COUNTER_BITFIELD        = 5'hf;

 // gc_cr_cp_pim0_cfg_base_address
localparam logic [ 31 : 0 ] GC_CR_CP_PIM0_CFG_BASE_ADDRESS_ADDRESS_BITFIELD    = 32'h2000000;

 // gc_cr_cp_pim1_cfg_base_address
localparam logic [ 31 : 0 ] GC_CR_CP_PIM1_CFG_BASE_ADDRESS_ADDRESS_BITFIELD    = 32'h3000000;

 // gc_cr_cp_pim_rtn_base_addr
localparam logic [ 15 : 0 ] GC_CR_CP_PIM_RTN_BASE_ADDR_ADDR_BITFIELD           = 16'h0;

 // gc_cr_cp_pim_interrupt_status0
localparam logic [ 63 : 0 ] GC_CR_CP_PIM_INTERRUPT_STATUS0_STATUS0_BITFIELD    = 64'h0;

 // gc_cr_cp_pim_interrupt_status1
localparam logic [ 63 : 0 ] GC_CR_CP_PIM_INTERRUPT_STATUS1_STATUS1_BITFIELD    = 64'h0;

 // gc_cr_cp_max_cpc_pim_outstanding_kernel_id
localparam logic [ 4 : 0 ] GC_CR_CP_MAX_CPC_PIM_OUTSTANDING_KERNEL_ID_ID_BITFIELD  = 5'h1f;

 // gc_cr_cp_pim_interrupt_buffer_threshold
localparam logic [ 5 : 0 ] GC_CR_CP_PIM_INTERRUPT_BUFFER_THRESHOLD_THRESHOLD_BITFIELD  = 6'h3f;

 // gc_cr_cpc0_cb_base
localparam logic [ 47 : 2 ] GC_CR_CPC0_CB_BASE_ADDR_BITFIELD                   = 46'h0;

 // gc_cr_cpc0_cb
localparam logic [ 47 : 2 ] GC_CR_CPC0_CB_SIZE_BITFIELD                        = 46'h0;

 // gc_cr_cpc0_cb_queue
localparam logic [ 47 : 6 ] GC_CR_CPC0_CB_QUEUE_CTRL_BASE_ADDR_BITFIELD        = 42'h0;

 // gc_cr_cpc0_cb_write_pointer_guard
localparam logic [ 47 : 2 ] GC_CR_CPC0_CB_WRITE_POINTER_GUARD_SIZE_BITFIELD    = 46'h10;

 // gc_cr_cpc0_cb_read_pointer_update
localparam logic [ 47 : 2 ] GC_CR_CPC0_CB_READ_POINTER_UPDATE_FREQUENCY_BITFIELD  = 46'h3fffffffffff;

 // gc_cr_cpc0_cb_read
localparam logic [ 47 : 2 ] GC_CR_CPC0_CB_READ_POINTER_BITFIELD                = 46'h0;

 // gc_cr_cpc0_stack_state_base
localparam logic [ 47 : 6 ] GC_CR_CPC0_STACK_STATE_BASE_ADDR_BITFIELD          = 42'h0;

 // gc_cr_cpc0_stack
localparam logic [ 0 : 0 ] GC_CR_CPC0_STACK_DISABLE_BITFIELD                   = 1'h0;

 // gc_cr_cpc0_queue_fence_poll_ctrl
localparam logic [ 7 : 0 ] GC_CR_CPC0_QUEUE_FENCE_POLL_CTRL_INTERVAL_BITFIELD  = 8'h0;
localparam logic [ 15 : 8 ] GC_CR_CPC0_QUEUE_FENCE_POLL_CTRL_TRY_TIMES_BITFIELD  = 8'h1;

 // gc_cr_cpc0_ctrl
localparam logic [ 0 : 0 ] GC_CR_CPC0_CTRL_KERNEL_ID_DEBUG_MODE_BITFIELD       = 1'h0;

 // gc_cr_cpc0_compute_mss_mmu_auto_cache_ops_ctrl
localparam logic [ 0 : 0 ] GC_CR_CPC0_COMPUTE_MSS_MMU_AUTO_CACHE_OPS_CTRL_COMPUTE_L2G_INVALIDATE_BITFIELD  = 1'h1;
localparam logic [ 1 : 1 ] GC_CR_CPC0_COMPUTE_MSS_MMU_AUTO_CACHE_OPS_CTRL_COMPUTE_L2G_FLUSH_BITFIELD  = 1'h1;

 // gc_cr_perf_counter_force_cpc0
localparam logic [ 0 : 0 ] GC_CR_PERF_COUNTER_FORCE_CPC0_ALWAYS_ON_BITFIELD    = 1'h0;

 // gc_cr_cpc0_context_state_base
localparam logic [ 47 : 6 ] GC_CR_CPC0_CONTEXT_STATE_BASE_ADDR_BITFIELD        = 42'h0;

 // gc_cr_cpc0_context_store
localparam logic [ 0 : 0 ] GC_CR_CPC0_CONTEXT_STORE_PULSE_BITFIELD             = 1'h0;

 // gc_cr_cpc0_context_load
localparam logic [ 0 : 0 ] GC_CR_CPC0_CONTEXT_LOAD_PULSE_BITFIELD              = 1'h0;

 // gc_cr_cpc0_resume
localparam logic [ 0 : 0 ] GC_CR_CPC0_RESUME_PULSE_BITFIELD                    = 1'h0;

 // gc_cr_cpc0_context_mapping_compute
localparam logic [ 5 : 0 ] GC_CR_CPC0_CONTEXT_MAPPING_COMPUTE_COMPUTE_BITFIELD  = 6'h0;
localparam logic [ 11 : 6 ] GC_CR_CPC0_CONTEXT_MAPPING_COMPUTE_COMPUTE_QUEUE_BITFIELD  = 6'h0;

 // gc_cr_cpc0_compute_start
localparam logic [ 0 : 0 ] GC_CR_CPC0_COMPUTE_START_PULSE_BITFIELD             = 1'h0;

 // gc_cr_cpc0_signal
localparam logic [ 47 : 3 ] GC_CR_CPC0_SIGNAL_ADDRESS_BITFIELD                 = 45'h0;

 // gc_cr_cpc0_signal_data_returned
localparam logic [ 63 : 0 ] GC_CR_CPC0_SIGNAL_DATA_RETURNED_VALUE_BITFIELD     = 64'h0;

 // gc_cr_cpc0_signal_data_expected
localparam logic [ 63 : 0 ] GC_CR_CPC0_SIGNAL_DATA_EXPECTED_VALUE_BITFIELD     = 64'h0;

 // gc_cr_cpc0_context_store_status
localparam logic [ 0 : 0 ] GC_CR_CPC0_CONTEXT_STORE_STATUS_COMPLETE_BITFIELD   = 1'h0;
localparam logic [ 1 : 1 ] GC_CR_CPC0_CONTEXT_STORE_STATUS_NEED_RESUME_BITFIELD  = 1'h0;

 // gc_cr_cpc0_mh_control
localparam logic [ 1 : 0 ] GC_CR_CPC0_MH_CONTROL_PERSISTENCE_BITFIELD          = 2'h0;
localparam logic [ 3 : 2 ] GC_CR_CPC0_MH_CONTROL_L1_POLICY_BITFIELD            = 2'h0;
localparam logic [ 4 : 4 ] GC_CR_CPC0_MH_CONTROL_L2_POLICY_STATE_BITFIELD      = 1'h0;
localparam logic [ 5 : 5 ] GC_CR_CPC0_MH_CONTROL_L2_POLICY_SIG_EVT_BITFIELD    = 1'h0;
localparam logic [ 6 : 6 ] GC_CR_CPC0_MH_CONTROL_L2_POLICY_INDIRECT_BITFIELD   = 1'h0;
localparam logic [ 7 : 7 ] GC_CR_CPC0_MH_CONTROL_L2_POLICY_CB_BITFIELD         = 1'h0;
localparam logic [ 8 : 8 ] GC_CR_CPC0_MH_CONTROL_L2_POLICY_PROFILING_BITFIELD  = 1'h0;
localparam logic [ 9 : 9 ] GC_CR_CPC0_MH_CONTROL_L2_POLICY_UP_DE_FENCE_BITFIELD  = 1'h0;

 // gc_cr_cpc0_fence_update_address
localparam logic [ 47 : 0 ] GC_CR_CPC0_FENCE_UPDATE_ADDRESS_ADDRESS_BITFIELD   = 48'h0;

 // gc_cr_cpc1_cb_base
localparam logic [ 47 : 2 ] GC_CR_CPC1_CB_BASE_ADDR_BITFIELD                   = 46'h0;

 // gc_cr_cpc1_cb
localparam logic [ 47 : 2 ] GC_CR_CPC1_CB_SIZE_BITFIELD                        = 46'h0;

 // gc_cr_cpc1_cb_queue
localparam logic [ 47 : 6 ] GC_CR_CPC1_CB_QUEUE_CTRL_BASE_ADDR_BITFIELD        = 42'h0;

 // gc_cr_cpc1_cb_write_pointer_guard
localparam logic [ 47 : 2 ] GC_CR_CPC1_CB_WRITE_POINTER_GUARD_SIZE_BITFIELD    = 46'h10;

 // gc_cr_cpc1_cb_read_pointer_update
localparam logic [ 47 : 2 ] GC_CR_CPC1_CB_READ_POINTER_UPDATE_FREQUENCY_BITFIELD  = 46'h3fffffffffff;

 // gc_cr_cpc1_cb_read
localparam logic [ 47 : 2 ] GC_CR_CPC1_CB_READ_POINTER_BITFIELD                = 46'h0;

 // gc_cr_cpc1_stack_state_base
localparam logic [ 47 : 6 ] GC_CR_CPC1_STACK_STATE_BASE_ADDR_BITFIELD          = 42'h0;

 // gc_cr_cpc1_stack
localparam logic [ 0 : 0 ] GC_CR_CPC1_STACK_DISABLE_BITFIELD                   = 1'h0;

 // gc_cr_cpc1_queue_fence_poll_ctrl
localparam logic [ 7 : 0 ] GC_CR_CPC1_QUEUE_FENCE_POLL_CTRL_INTERVAL_BITFIELD  = 8'h0;
localparam logic [ 15 : 8 ] GC_CR_CPC1_QUEUE_FENCE_POLL_CTRL_TRY_TIMES_BITFIELD  = 8'h1;

 // gc_cr_cpc1_ctrl
localparam logic [ 0 : 0 ] GC_CR_CPC1_CTRL_KERNEL_ID_DEBUG_MODE_BITFIELD       = 1'h0;

 // gc_cr_cpc1_compute_mss_mmu_auto_cache_ops_ctrl
localparam logic [ 0 : 0 ] GC_CR_CPC1_COMPUTE_MSS_MMU_AUTO_CACHE_OPS_CTRL_COMPUTE_L2G_INVALIDATE_BITFIELD  = 1'h1;
localparam logic [ 1 : 1 ] GC_CR_CPC1_COMPUTE_MSS_MMU_AUTO_CACHE_OPS_CTRL_COMPUTE_L2G_FLUSH_BITFIELD  = 1'h1;

 // gc_cr_perf_counter_force_cpc1
localparam logic [ 0 : 0 ] GC_CR_PERF_COUNTER_FORCE_CPC1_ALWAYS_ON_BITFIELD    = 1'h0;

 // gc_cr_cpc1_context_state_base
localparam logic [ 47 : 6 ] GC_CR_CPC1_CONTEXT_STATE_BASE_ADDR_BITFIELD        = 42'h0;

 // gc_cr_cpc1_context_store
localparam logic [ 0 : 0 ] GC_CR_CPC1_CONTEXT_STORE_PULSE_BITFIELD             = 1'h0;

 // gc_cr_cpc1_context_load
localparam logic [ 0 : 0 ] GC_CR_CPC1_CONTEXT_LOAD_PULSE_BITFIELD              = 1'h0;

 // gc_cr_cpc1_resume
localparam logic [ 0 : 0 ] GC_CR_CPC1_RESUME_PULSE_BITFIELD                    = 1'h0;

 // gc_cr_cpc1_context_mapping_compute
localparam logic [ 5 : 0 ] GC_CR_CPC1_CONTEXT_MAPPING_COMPUTE_COMPUTE_BITFIELD  = 6'h0;
localparam logic [ 11 : 6 ] GC_CR_CPC1_CONTEXT_MAPPING_COMPUTE_COMPUTE_QUEUE_BITFIELD  = 6'h0;

 // gc_cr_cpc1_compute_start
localparam logic [ 0 : 0 ] GC_CR_CPC1_COMPUTE_START_PULSE_BITFIELD             = 1'h0;

 // gc_cr_cpc1_signal
localparam logic [ 47 : 3 ] GC_CR_CPC1_SIGNAL_ADDRESS_BITFIELD                 = 45'h0;

 // gc_cr_cpc1_signal_data_returned
localparam logic [ 63 : 0 ] GC_CR_CPC1_SIGNAL_DATA_RETURNED_VALUE_BITFIELD     = 64'h0;

 // gc_cr_cpc1_signal_data_expected
localparam logic [ 63 : 0 ] GC_CR_CPC1_SIGNAL_DATA_EXPECTED_VALUE_BITFIELD     = 64'h0;

 // gc_cr_cpc1_context_store_status
localparam logic [ 0 : 0 ] GC_CR_CPC1_CONTEXT_STORE_STATUS_COMPLETE_BITFIELD   = 1'h0;
localparam logic [ 1 : 1 ] GC_CR_CPC1_CONTEXT_STORE_STATUS_NEED_RESUME_BITFIELD  = 1'h0;

 // gc_cr_cpc1_mh_control
localparam logic [ 1 : 0 ] GC_CR_CPC1_MH_CONTROL_PERSISTENCE_BITFIELD          = 2'h0;
localparam logic [ 3 : 2 ] GC_CR_CPC1_MH_CONTROL_L1_POLICY_BITFIELD            = 2'h0;
localparam logic [ 4 : 4 ] GC_CR_CPC1_MH_CONTROL_L2_POLICY_STATE_BITFIELD      = 1'h0;
localparam logic [ 5 : 5 ] GC_CR_CPC1_MH_CONTROL_L2_POLICY_SIG_EVT_BITFIELD    = 1'h0;
localparam logic [ 6 : 6 ] GC_CR_CPC1_MH_CONTROL_L2_POLICY_INDIRECT_BITFIELD   = 1'h0;
localparam logic [ 7 : 7 ] GC_CR_CPC1_MH_CONTROL_L2_POLICY_CB_BITFIELD         = 1'h0;
localparam logic [ 8 : 8 ] GC_CR_CPC1_MH_CONTROL_L2_POLICY_PROFILING_BITFIELD  = 1'h0;
localparam logic [ 9 : 9 ] GC_CR_CPC1_MH_CONTROL_L2_POLICY_UP_DE_FENCE_BITFIELD  = 1'h0;

 // gc_cr_cpc1_fence_update_address
localparam logic [ 47 : 0 ] GC_CR_CPC1_FENCE_UPDATE_ADDRESS_ADDRESS_BITFIELD   = 48'h0;

 // gc_cr_cpc2_cb_base
localparam logic [ 47 : 2 ] GC_CR_CPC2_CB_BASE_ADDR_BITFIELD                   = 46'h0;

 // gc_cr_cpc2_cb
localparam logic [ 47 : 2 ] GC_CR_CPC2_CB_SIZE_BITFIELD                        = 46'h0;

 // gc_cr_cpc2_cb_queue
localparam logic [ 47 : 6 ] GC_CR_CPC2_CB_QUEUE_CTRL_BASE_ADDR_BITFIELD        = 42'h0;

 // gc_cr_cpc2_cb_write_pointer_guard
localparam logic [ 47 : 2 ] GC_CR_CPC2_CB_WRITE_POINTER_GUARD_SIZE_BITFIELD    = 46'h10;

 // gc_cr_cpc2_cb_read_pointer_update
localparam logic [ 47 : 2 ] GC_CR_CPC2_CB_READ_POINTER_UPDATE_FREQUENCY_BITFIELD  = 46'h3fffffffffff;

 // gc_cr_cpc2_cb_read
localparam logic [ 47 : 2 ] GC_CR_CPC2_CB_READ_POINTER_BITFIELD                = 46'h0;

 // gc_cr_cpc2_stack_state_base
localparam logic [ 47 : 6 ] GC_CR_CPC2_STACK_STATE_BASE_ADDR_BITFIELD          = 42'h0;

 // gc_cr_cpc2_stack
localparam logic [ 0 : 0 ] GC_CR_CPC2_STACK_DISABLE_BITFIELD                   = 1'h0;

 // gc_cr_cpc2_queue_fence_poll_ctrl
localparam logic [ 7 : 0 ] GC_CR_CPC2_QUEUE_FENCE_POLL_CTRL_INTERVAL_BITFIELD  = 8'h0;
localparam logic [ 15 : 8 ] GC_CR_CPC2_QUEUE_FENCE_POLL_CTRL_TRY_TIMES_BITFIELD  = 8'h1;

 // gc_cr_cpc2_ctrl
localparam logic [ 0 : 0 ] GC_CR_CPC2_CTRL_KERNEL_ID_DEBUG_MODE_BITFIELD       = 1'h0;

 // gc_cr_cpc2_compute_mss_mmu_auto_cache_ops_ctrl
localparam logic [ 0 : 0 ] GC_CR_CPC2_COMPUTE_MSS_MMU_AUTO_CACHE_OPS_CTRL_COMPUTE_L2G_INVALIDATE_BITFIELD  = 1'h1;
localparam logic [ 1 : 1 ] GC_CR_CPC2_COMPUTE_MSS_MMU_AUTO_CACHE_OPS_CTRL_COMPUTE_L2G_FLUSH_BITFIELD  = 1'h1;

 // gc_cr_perf_counter_force_cpc2
localparam logic [ 0 : 0 ] GC_CR_PERF_COUNTER_FORCE_CPC2_ALWAYS_ON_BITFIELD    = 1'h0;

 // gc_cr_cpc2_context_state_base
localparam logic [ 47 : 6 ] GC_CR_CPC2_CONTEXT_STATE_BASE_ADDR_BITFIELD        = 42'h0;

 // gc_cr_cpc2_context_store
localparam logic [ 0 : 0 ] GC_CR_CPC2_CONTEXT_STORE_PULSE_BITFIELD             = 1'h0;

 // gc_cr_cpc2_context_load
localparam logic [ 0 : 0 ] GC_CR_CPC2_CONTEXT_LOAD_PULSE_BITFIELD              = 1'h0;

 // gc_cr_cpc2_resume
localparam logic [ 0 : 0 ] GC_CR_CPC2_RESUME_PULSE_BITFIELD                    = 1'h0;

 // gc_cr_cpc2_context_mapping_compute
localparam logic [ 5 : 0 ] GC_CR_CPC2_CONTEXT_MAPPING_COMPUTE_COMPUTE_BITFIELD  = 6'h0;
localparam logic [ 11 : 6 ] GC_CR_CPC2_CONTEXT_MAPPING_COMPUTE_COMPUTE_QUEUE_BITFIELD  = 6'h0;

 // gc_cr_cpc2_compute_start
localparam logic [ 0 : 0 ] GC_CR_CPC2_COMPUTE_START_PULSE_BITFIELD             = 1'h0;

 // gc_cr_cpc2_signal
localparam logic [ 47 : 3 ] GC_CR_CPC2_SIGNAL_ADDRESS_BITFIELD                 = 45'h0;

 // gc_cr_cpc2_signal_data_returned
localparam logic [ 63 : 0 ] GC_CR_CPC2_SIGNAL_DATA_RETURNED_VALUE_BITFIELD     = 64'h0;

 // gc_cr_cpc2_signal_data_expected
localparam logic [ 63 : 0 ] GC_CR_CPC2_SIGNAL_DATA_EXPECTED_VALUE_BITFIELD     = 64'h0;

 // gc_cr_cpc2_context_store_status
localparam logic [ 0 : 0 ] GC_CR_CPC2_CONTEXT_STORE_STATUS_COMPLETE_BITFIELD   = 1'h0;
localparam logic [ 1 : 1 ] GC_CR_CPC2_CONTEXT_STORE_STATUS_NEED_RESUME_BITFIELD  = 1'h0;

 // gc_cr_cpc2_mh_control
localparam logic [ 1 : 0 ] GC_CR_CPC2_MH_CONTROL_PERSISTENCE_BITFIELD          = 2'h0;
localparam logic [ 3 : 2 ] GC_CR_CPC2_MH_CONTROL_L1_POLICY_BITFIELD            = 2'h0;
localparam logic [ 4 : 4 ] GC_CR_CPC2_MH_CONTROL_L2_POLICY_STATE_BITFIELD      = 1'h0;
localparam logic [ 5 : 5 ] GC_CR_CPC2_MH_CONTROL_L2_POLICY_SIG_EVT_BITFIELD    = 1'h0;
localparam logic [ 6 : 6 ] GC_CR_CPC2_MH_CONTROL_L2_POLICY_INDIRECT_BITFIELD   = 1'h0;
localparam logic [ 7 : 7 ] GC_CR_CPC2_MH_CONTROL_L2_POLICY_CB_BITFIELD         = 1'h0;
localparam logic [ 8 : 8 ] GC_CR_CPC2_MH_CONTROL_L2_POLICY_PROFILING_BITFIELD  = 1'h0;
localparam logic [ 9 : 9 ] GC_CR_CPC2_MH_CONTROL_L2_POLICY_UP_DE_FENCE_BITFIELD  = 1'h0;

 // gc_cr_cpc2_fence_update_address
localparam logic [ 47 : 0 ] GC_CR_CPC2_FENCE_UPDATE_ADDRESS_ADDRESS_BITFIELD   = 48'h0;

 // gc_cr_cpc3_cb_base
localparam logic [ 47 : 2 ] GC_CR_CPC3_CB_BASE_ADDR_BITFIELD                   = 46'h0;

 // gc_cr_cpc3_cb
localparam logic [ 47 : 2 ] GC_CR_CPC3_CB_SIZE_BITFIELD                        = 46'h0;

 // gc_cr_cpc3_cb_queue
localparam logic [ 47 : 6 ] GC_CR_CPC3_CB_QUEUE_CTRL_BASE_ADDR_BITFIELD        = 42'h0;

 // gc_cr_cpc3_cb_write_pointer_guard
localparam logic [ 47 : 2 ] GC_CR_CPC3_CB_WRITE_POINTER_GUARD_SIZE_BITFIELD    = 46'h10;

 // gc_cr_cpc3_cb_read_pointer_update
localparam logic [ 47 : 2 ] GC_CR_CPC3_CB_READ_POINTER_UPDATE_FREQUENCY_BITFIELD  = 46'h3fffffffffff;

 // gc_cr_cpc3_cb_read
localparam logic [ 47 : 2 ] GC_CR_CPC3_CB_READ_POINTER_BITFIELD                = 46'h0;

 // gc_cr_cpc3_stack_state_base
localparam logic [ 47 : 6 ] GC_CR_CPC3_STACK_STATE_BASE_ADDR_BITFIELD          = 42'h0;

 // gc_cr_cpc3_stack
localparam logic [ 0 : 0 ] GC_CR_CPC3_STACK_DISABLE_BITFIELD                   = 1'h0;

 // gc_cr_cpc3_queue_fence_poll_ctrl
localparam logic [ 7 : 0 ] GC_CR_CPC3_QUEUE_FENCE_POLL_CTRL_INTERVAL_BITFIELD  = 8'h0;
localparam logic [ 15 : 8 ] GC_CR_CPC3_QUEUE_FENCE_POLL_CTRL_TRY_TIMES_BITFIELD  = 8'h1;

 // gc_cr_cpc3_ctrl
localparam logic [ 0 : 0 ] GC_CR_CPC3_CTRL_KERNEL_ID_DEBUG_MODE_BITFIELD       = 1'h0;

 // gc_cr_cpc3_compute_mss_mmu_auto_cache_ops_ctrl
localparam logic [ 0 : 0 ] GC_CR_CPC3_COMPUTE_MSS_MMU_AUTO_CACHE_OPS_CTRL_COMPUTE_L2G_INVALIDATE_BITFIELD  = 1'h1;
localparam logic [ 1 : 1 ] GC_CR_CPC3_COMPUTE_MSS_MMU_AUTO_CACHE_OPS_CTRL_COMPUTE_L2G_FLUSH_BITFIELD  = 1'h1;

 // gc_cr_perf_counter_force_cpc3
localparam logic [ 0 : 0 ] GC_CR_PERF_COUNTER_FORCE_CPC3_ALWAYS_ON_BITFIELD    = 1'h0;

 // gc_cr_cpc3_context_state_base
localparam logic [ 47 : 6 ] GC_CR_CPC3_CONTEXT_STATE_BASE_ADDR_BITFIELD        = 42'h0;

 // gc_cr_cpc3_context_store
localparam logic [ 0 : 0 ] GC_CR_CPC3_CONTEXT_STORE_PULSE_BITFIELD             = 1'h0;

 // gc_cr_cpc3_context_load
localparam logic [ 0 : 0 ] GC_CR_CPC3_CONTEXT_LOAD_PULSE_BITFIELD              = 1'h0;

 // gc_cr_cpc3_resume
localparam logic [ 0 : 0 ] GC_CR_CPC3_RESUME_PULSE_BITFIELD                    = 1'h0;

 // gc_cr_cpc3_context_mapping_compute
localparam logic [ 5 : 0 ] GC_CR_CPC3_CONTEXT_MAPPING_COMPUTE_COMPUTE_BITFIELD  = 6'h0;
localparam logic [ 11 : 6 ] GC_CR_CPC3_CONTEXT_MAPPING_COMPUTE_COMPUTE_QUEUE_BITFIELD  = 6'h0;

 // gc_cr_cpc3_compute_start
localparam logic [ 0 : 0 ] GC_CR_CPC3_COMPUTE_START_PULSE_BITFIELD             = 1'h0;

 // gc_cr_cpc3_signal
localparam logic [ 47 : 3 ] GC_CR_CPC3_SIGNAL_ADDRESS_BITFIELD                 = 45'h0;

 // gc_cr_cpc3_signal_data_returned
localparam logic [ 63 : 0 ] GC_CR_CPC3_SIGNAL_DATA_RETURNED_VALUE_BITFIELD     = 64'h0;

 // gc_cr_cpc3_signal_data_expected
localparam logic [ 63 : 0 ] GC_CR_CPC3_SIGNAL_DATA_EXPECTED_VALUE_BITFIELD     = 64'h0;

 // gc_cr_cpc3_context_store_status
localparam logic [ 0 : 0 ] GC_CR_CPC3_CONTEXT_STORE_STATUS_COMPLETE_BITFIELD   = 1'h0;
localparam logic [ 1 : 1 ] GC_CR_CPC3_CONTEXT_STORE_STATUS_NEED_RESUME_BITFIELD  = 1'h0;

 // gc_cr_cpc3_mh_control
localparam logic [ 1 : 0 ] GC_CR_CPC3_MH_CONTROL_PERSISTENCE_BITFIELD          = 2'h0;
localparam logic [ 3 : 2 ] GC_CR_CPC3_MH_CONTROL_L1_POLICY_BITFIELD            = 2'h0;
localparam logic [ 4 : 4 ] GC_CR_CPC3_MH_CONTROL_L2_POLICY_STATE_BITFIELD      = 1'h0;
localparam logic [ 5 : 5 ] GC_CR_CPC3_MH_CONTROL_L2_POLICY_SIG_EVT_BITFIELD    = 1'h0;
localparam logic [ 6 : 6 ] GC_CR_CPC3_MH_CONTROL_L2_POLICY_INDIRECT_BITFIELD   = 1'h0;
localparam logic [ 7 : 7 ] GC_CR_CPC3_MH_CONTROL_L2_POLICY_CB_BITFIELD         = 1'h0;
localparam logic [ 8 : 8 ] GC_CR_CPC3_MH_CONTROL_L2_POLICY_PROFILING_BITFIELD  = 1'h0;
localparam logic [ 9 : 9 ] GC_CR_CPC3_MH_CONTROL_L2_POLICY_UP_DE_FENCE_BITFIELD  = 1'h0;

 // gc_cr_cpc3_fence_update_address
localparam logic [ 47 : 0 ] GC_CR_CPC3_FENCE_UPDATE_ADDRESS_ADDRESS_BITFIELD   = 48'h0;

 // gc_cr_perf_mon_overall_pointer
localparam logic [ 31 : 0 ] GC_CR_PERF_MON_OVERALL_POINTER_PONITER_BITFIELD    = 32'h0;

 // gc_cr_perf_mon_overall_num
localparam logic [ 15 : 0 ] GC_CR_PERF_MON_OVERALL_NUM_PONITER_BITFIELD        = 16'h0;

 // gc_cr_perf_mon_overall_int_mask_overflow
localparam logic [ 53 : 0 ] GC_CR_PERF_MON_OVERALL_INT_MASK_OVERFLOW_OVERFLOW_BITFIELD  = 54'h0;

 // gc_cr_perf_mon_overall_int_mask_fail
localparam logic [ 53 : 0 ] GC_CR_PERF_MON_OVERALL_INT_MASK_FAIL_FAIL_BITFIELD  = 54'h0;

 // gc_cr_perf_mon_overall_int_mask_done
localparam logic [ 53 : 0 ] GC_CR_PERF_MON_OVERALL_INT_MASK_DONE_DONE_BITFIELD  = 54'h0;

 // gc_cr_perf_mon_overall_int_mask_overall_done
localparam logic [ 0 : 0 ] GC_CR_PERF_MON_OVERALL_INT_MASK_OVERALL_DONE_DONE_BITFIELD  = 1'h0;

 // gc_cr_perf_mon_overall_int_clr_overflow
localparam logic [ 53 : 0 ] GC_CR_PERF_MON_OVERALL_INT_CLR_OVERFLOW_OVERFLOW_BITFIELD  = 54'h0;

 // gc_cr_perf_mon_overall_int_clr_fail
localparam logic [ 53 : 0 ] GC_CR_PERF_MON_OVERALL_INT_CLR_FAIL_FAIL_BITFIELD  = 54'h0;

 // gc_cr_perf_mon_overall_int_clr_done
localparam logic [ 53 : 0 ] GC_CR_PERF_MON_OVERALL_INT_CLR_DONE_DONE_BITFIELD  = 54'h0;

 // gc_cr_perf_mon_overall_int_clr_overall_done
localparam logic [ 0 : 0 ] GC_CR_PERF_MON_OVERALL_INT_CLR_OVERALL_DONE_DONE_BITFIELD  = 1'h0;

 // gc_cr_tap_border_colour_cpc0
localparam logic [ 45 : 0 ] GC_CR_TAP_BORDER_COLOUR_CPC0_TABLE_BITFIELD        = 46'h0;

 // gc_cr_tap_border_colour_cpc1
localparam logic [ 45 : 0 ] GC_CR_TAP_BORDER_COLOUR_CPC1_TABLE_BITFIELD        = 46'h0;

 // gc_cr_tap_border_colour_cpc2
localparam logic [ 45 : 0 ] GC_CR_TAP_BORDER_COLOUR_CPC2_TABLE_BITFIELD        = 46'h0;

 // gc_cr_tap_border_colour_cpc3
localparam logic [ 45 : 0 ] GC_CR_TAP_BORDER_COLOUR_CPC3_TABLE_BITFIELD        = 46'h0;

 // gc_cr_trm_ctrl_max_num_tasks
localparam logic [ 6 : 0 ] GC_CR_TRM_CTRL_MAX_NUM_TASKS_CPC0_BITFIELD          = 7'h40;
localparam logic [ 13 : 7 ] GC_CR_TRM_CTRL_MAX_NUM_TASKS_CPC1_BITFIELD         = 7'h40;
localparam logic [ 20 : 14 ] GC_CR_TRM_CTRL_MAX_NUM_TASKS_CPC2_BITFIELD        = 7'h40;
localparam logic [ 27 : 21 ] GC_CR_TRM_CTRL_MAX_NUM_TASKS_CPC3_BITFIELD        = 7'h40;

 // gc_cr_trm_usrm_num_regions_cpc
localparam logic [ 15 : 0 ] GC_CR_TRM_USRM_NUM_REGIONS_CPC_TEMP_BITFIELD       = 16'h120;
localparam logic [ 31 : 16 ] GC_CR_TRM_USRM_NUM_REGIONS_CPC_ATTR_BITFIELD      = 16'h20;

 // gc_cr_trm_shsrm_cu_debug_size
localparam logic [ 4 : 0 ] GC_CR_TRM_SHSRM_CU_DEBUG_SIZE_DEBUG_SIZE_BITFIELD   = 5'h0;

 // gc_cr_cu_override_ctrl
localparam logic [ 6 : 0 ] GC_CR_CU_OVERRIDE_CTRL_DEBUG_TEMPS_BITFIELD         = 7'h0;
localparam logic [ 7 : 7 ] GC_CR_CU_OVERRIDE_CTRL_SELECTIVE_RATE_BITFIELD      = 1'h0;
localparam logic [ 8 : 8 ] GC_CR_CU_OVERRIDE_CTRL_OUTPUT_WRITES_BITFIELD       = 1'h0;
localparam logic [ 9 : 9 ] GC_CR_CU_OVERRIDE_CTRL_PHASE_PASSES_BITFIELD        = 1'h0;
localparam logic [ 10 : 10 ] GC_CR_CU_OVERRIDE_CTRL_PRIORITY_BITFIELD          = 1'h0;
localparam logic [ 11 : 11 ] GC_CR_CU_OVERRIDE_CTRL_LATE_PARTN_BITFIELD        = 1'h0;
localparam logic [ 13 : 12 ] GC_CR_CU_OVERRIDE_CTRL_MAX_GROUP_BITFIELD         = 2'h0;
localparam logic [ 14 : 14 ] GC_CR_CU_OVERRIDE_CTRL_NO_RESERVE_BITFIELD        = 1'h0;
localparam logic [ 16 : 15 ] GC_CR_CU_OVERRIDE_CTRL_RESERVE_SLOTS_BITFIELD     = 2'h0;
localparam logic [ 17 : 17 ] GC_CR_CU_OVERRIDE_CTRL_PHASE_BOTH_BITFIELD        = 1'h0;
localparam logic [ 18 : 18 ] GC_CR_CU_OVERRIDE_CTRL_CUC_SG_FIFO_BITFIELD       = 1'h0;

 // gc_cr_cu_watchdog_status
localparam logic [ 2 : 0 ] GC_CR_CU_WATCHDOG_STATUS_EU0_CDM_ID0_BITFIELD       = 3'h0;
localparam logic [ 5 : 3 ] GC_CR_CU_WATCHDOG_STATUS_EU0_CDM_ID1_BITFIELD       = 3'h0;
localparam logic [ 8 : 6 ] GC_CR_CU_WATCHDOG_STATUS_EU0_CDM_ID2_BITFIELD       = 3'h0;
localparam logic [ 11 : 9 ] GC_CR_CU_WATCHDOG_STATUS_EU0_CDM_ID3_BITFIELD      = 3'h0;
localparam logic [ 20 : 18 ] GC_CR_CU_WATCHDOG_STATUS_EU1_CDM_ID0_BITFIELD     = 3'h0;
localparam logic [ 23 : 21 ] GC_CR_CU_WATCHDOG_STATUS_EU1_CDM_ID1_BITFIELD     = 3'h0;
localparam logic [ 26 : 24 ] GC_CR_CU_WATCHDOG_STATUS_EU1_CDM_ID2_BITFIELD     = 3'h0;
localparam logic [ 29 : 27 ] GC_CR_CU_WATCHDOG_STATUS_EU1_CDM_ID3_BITFIELD     = 3'h0;

 // gc_cr_cu_oldest_task_status
localparam logic [ 0 : 0 ] GC_CR_CU_OLDEST_TASK_STATUS_WORK_TYPE_BITFIELD      = 1'h0;
localparam logic [ 1 : 1 ] GC_CR_CU_OLDEST_TASK_STATUS_COEFF_TYPE_BITFIELD     = 1'h0;
localparam logic [ 2 : 2 ] GC_CR_CU_OLDEST_TASK_STATUS_MCU_ED_BITFIELD         = 1'h0;
localparam logic [ 3 : 3 ] GC_CR_CU_OLDEST_TASK_STATUS_TFPU_CS_ED_BITFIELD     = 1'h0;
localparam logic [ 4 : 4 ] GC_CR_CU_OLDEST_TASK_STATUS_PDS_US_ED_BITFIELD      = 1'h0;
localparam logic [ 5 : 5 ] GC_CR_CU_OLDEST_TASK_STATUS_PDS_CS_ED_BITFIELD      = 1'h0;
localparam logic [ 6 : 6 ] GC_CR_CU_OLDEST_TASK_STATUS_PDS_TM_TS_WR_ED_BITFIELD  = 1'h0;
localparam logic [ 7 : 7 ] GC_CR_CU_OLDEST_TASK_STATUS_PDS_SBD_ED_BITFIELD     = 1'h0;
localparam logic [ 8 : 8 ] GC_CR_CU_OLDEST_TASK_STATUS_NEW_SD_BITFIELD         = 1'h0;
localparam logic [ 10 : 9 ] GC_CR_CU_OLDEST_TASK_STATUS_STATE_BITFIELD         = 2'h0;
localparam logic [ 13 : 11 ] GC_CR_CU_OLDEST_TASK_STATUS_DM_BITFIELD           = 3'h0;
localparam logic [ 16 : 14 ] GC_CR_CU_OLDEST_TASK_STATUS_TASK_TYPE_BITFIELD    = 3'h0;
localparam logic [ 17 : 17 ] GC_CR_CU_OLDEST_TASK_STATUS_CMP_DM_DEP_BITFIELD   = 1'h0;

 // gc_cr_perf_reset
localparam logic [ 0 : 0 ] GC_CR_PERF_RESET_SEL_COMP_BITFIELD                  = 1'h0;

 // gc_cr_perf_cu_sg_temp_alloc_stall
localparam logic [ 31 : 0 ] GC_CR_PERF_CU_SG_TEMP_ALLOC_STALL_COMPUTE_CYCLES_COUNT_BITFIELD  = 32'h0;

 // gc_cr_cu_shared_group_clear_pending
localparam logic [ 0 : 0 ] GC_CR_CU_SHARED_GROUP_CLEAR_PENDING_PENDING_BITFIELD  = 1'h0;

 // gc_cr_cu_trigger
localparam logic [ 0 : 0 ] GC_CR_CU_TRIGGER_EVENT_BITFIELD                     = 1'h0;

 // gc_cr_cu_perf
localparam logic [ 0 : 0 ] GC_CR_CU_PERF_ENABLE_BITFIELD                       = 1'h0;

 // gc_cr_cu_inst_cache
localparam logic [ 0 : 0 ] GC_CR_CU_INST_CACHE_INVALIDATE_BITFIELD             = 1'h0;

 // gc_cr_cu_dmkill_cpc_id
localparam logic [ 3 : 0 ] GC_CR_CU_DMKILL_CPC_ID_CPC_ID_BITFIELD              = 4'h0;

 // gc_cr_cu_bsc_req_ctrl
localparam logic [ 1 : 0 ] GC_CR_CU_BSC_REQ_CTRL_PERSISTENCE_BITFIELD          = 2'h0;
localparam logic [ 3 : 2 ] GC_CR_CU_BSC_REQ_CTRL_L1_CACHE_POLICY_BITFIELD      = 2'h0;
localparam logic [ 4 : 4 ] GC_CR_CU_BSC_REQ_CTRL_L2_CACHE_POLICY_BITFIELD      = 1'h0;
localparam logic [ 5 : 5 ] GC_CR_CU_BSC_REQ_CTRL_PREFETCH_SIZE_BITFIELD        = 1'h0;

 // gc_cr_cu_temp
localparam logic [ 47 : 0 ] GC_CR_CU_TEMP_SPILLING_BITFIELD                    = 48'h0;

 // gc_cr_cu_code_base_compute0
localparam logic [ 47 : 6 ] GC_CR_CU_CODE_BASE_COMPUTE0_ADDR_BITFIELD          = 42'h0;

 // gc_cr_cu_code_base_compute1
localparam logic [ 47 : 6 ] GC_CR_CU_CODE_BASE_COMPUTE1_ADDR_BITFIELD          = 42'h0;

 // gc_cr_cu_code_base_compute2
localparam logic [ 47 : 6 ] GC_CR_CU_CODE_BASE_COMPUTE2_ADDR_BITFIELD          = 42'h0;

 // gc_cr_cu_code_base_compute3
localparam logic [ 47 : 6 ] GC_CR_CU_CODE_BASE_COMPUTE3_ADDR_BITFIELD          = 42'h0;

 // gc_cr_l2ic_cfg
localparam logic [ 1 : 0 ] GC_CR_L2IC_CFG_PERSISTENCE_BITFIELD                 = 2'h0;
localparam logic [ 3 : 2 ] GC_CR_L2IC_CFG_L1CHACHE_POLICY_BITFIELD             = 2'h0;
localparam logic [ 4 : 4 ] GC_CR_L2IC_CFG_L2CHACHE_POLICY_BITFIELD             = 1'h0;
localparam logic [ 5 : 5 ] GC_CR_L2IC_CFG_PREFETCH_SIZE_BITFIELD               = 1'h1;

 // gc_cr_l1_glb_ctrl
localparam logic [ 0 : 0 ] GC_CR_L1_GLB_CTRL_HASH_MODE_BITFIELD                = 1'h1;
localparam logic [ 0 : 0 ] GC_CR_L1_GLB_CTRL_HASH_MODE_LINEAR_HASH             = 1'h0;
localparam logic [ 0 : 0 ] GC_CR_L1_GLB_CTRL_HASH_MODE_GP3_DEFAULT_HASHING     = 1'h1;

 // gc_cr_l1c_disable
localparam logic [ 0 : 0 ] GC_CR_L1C_DISABLE_FWD_BITFIELD                      = 1'h0;

 // gc_cr_cpcpipe_task_max
localparam logic [ 6 : 0 ] GC_CR_CPCPIPE_TASK_MAX_CREDITS_BITFIELD             = 7'h76;

 // gc_cr_cu_hq_resch
localparam logic [ 0 : 0 ] GC_CR_CU_HQ_RESCH_DISABLE_BITFIELD                  = 1'h0;

 // gc_cr_cu_timer
localparam logic [ 63 : 0 ] GC_CR_CU_TIMER_CNT_BITFIELD                        = 64'h0;

 // gc_cr_cu_timer_cnt
localparam logic [ 0 : 0 ] GC_CR_CU_TIMER_CNT_RESET_BITFIELD                   = 1'h0;

 // gc_cr_cu_global_special_register_cpc00
localparam logic [ 31 : 0 ] GC_CR_CU_GLOBAL_SPECIAL_REGISTER_CPC00_DATA_BITFIELD  = 32'h0;

 // gc_cr_cu_global_special_register_cpc01
localparam logic [ 31 : 0 ] GC_CR_CU_GLOBAL_SPECIAL_REGISTER_CPC01_DATA_BITFIELD  = 32'h0;

 // gc_cr_cu_global_special_register_cpc02
localparam logic [ 31 : 0 ] GC_CR_CU_GLOBAL_SPECIAL_REGISTER_CPC02_DATA_BITFIELD  = 32'h0;

 // gc_cr_cu_global_special_register_cpc03
localparam logic [ 31 : 0 ] GC_CR_CU_GLOBAL_SPECIAL_REGISTER_CPC03_DATA_BITFIELD  = 32'h0;

 // gc_cr_cu_global_special_register_cpc10
localparam logic [ 31 : 0 ] GC_CR_CU_GLOBAL_SPECIAL_REGISTER_CPC10_DATA_BITFIELD  = 32'h0;

 // gc_cr_cu_global_special_register_cpc11
localparam logic [ 31 : 0 ] GC_CR_CU_GLOBAL_SPECIAL_REGISTER_CPC11_DATA_BITFIELD  = 32'h0;

 // gc_cr_cu_global_special_register_cpc12
localparam logic [ 31 : 0 ] GC_CR_CU_GLOBAL_SPECIAL_REGISTER_CPC12_DATA_BITFIELD  = 32'h0;

 // gc_cr_cu_global_special_register_cpc13
localparam logic [ 31 : 0 ] GC_CR_CU_GLOBAL_SPECIAL_REGISTER_CPC13_DATA_BITFIELD  = 32'h0;

 // gc_cr_cu_global_special_register_cpc20
localparam logic [ 31 : 0 ] GC_CR_CU_GLOBAL_SPECIAL_REGISTER_CPC20_DATA_BITFIELD  = 32'h0;

 // gc_cr_cu_global_special_register_cpc21
localparam logic [ 31 : 0 ] GC_CR_CU_GLOBAL_SPECIAL_REGISTER_CPC21_DATA_BITFIELD  = 32'h0;

 // gc_cr_cu_global_special_register_cpc22
localparam logic [ 31 : 0 ] GC_CR_CU_GLOBAL_SPECIAL_REGISTER_CPC22_DATA_BITFIELD  = 32'h0;

 // gc_cr_cu_global_special_register_cpc23
localparam logic [ 31 : 0 ] GC_CR_CU_GLOBAL_SPECIAL_REGISTER_CPC23_DATA_BITFIELD  = 32'h0;

 // gc_cr_cu_global_special_register_cpc30
localparam logic [ 31 : 0 ] GC_CR_CU_GLOBAL_SPECIAL_REGISTER_CPC30_DATA_BITFIELD  = 32'h0;

 // gc_cr_cu_global_special_register_cpc31
localparam logic [ 31 : 0 ] GC_CR_CU_GLOBAL_SPECIAL_REGISTER_CPC31_DATA_BITFIELD  = 32'h0;

 // gc_cr_cu_global_special_register_cpc32
localparam logic [ 31 : 0 ] GC_CR_CU_GLOBAL_SPECIAL_REGISTER_CPC32_DATA_BITFIELD  = 32'h0;

 // gc_cr_cu_global_special_register_cpc33
localparam logic [ 31 : 0 ] GC_CR_CU_GLOBAL_SPECIAL_REGISTER_CPC33_DATA_BITFIELD  = 32'h0;

 // gc_cr_cu_inst_cache_lock_release
localparam logic [ 63 : 0 ] GC_CR_CU_INST_CACHE_LOCK_RELEASE_STATUS_BITFIELD   = 64'hffffffffffffffff;

 // gc_cr_cu_inst_cache_lock
localparam logic [ 0 : 0 ] GC_CR_CU_INST_CACHE_LOCK_EN_BITFIELD                = 1'h1;
localparam logic [ 1 : 1 ] GC_CR_CU_INST_CACHE_LOCK_CLEAR_BITFIELD             = 1'h0;

 // gc_cr_cu_breakpoint
localparam logic [ 30 : 0 ] GC_CR_CU_BREAKPOINT_ADDR_BITFIELD                  = 31'h0;

 // gc_cr_dmkill_shader
localparam logic [ 31 : 2 ] GC_CR_DMKILL_SHADER_ADDR_BITFIELD                  = 30'h0;

 // gc_cr_cu_dm_slot0
localparam logic [ 3 : 0 ] GC_CR_CU_DM_SLOT0_SLOT_0_BITFIELD                   = 4'hf;
localparam logic [ 3 : 0 ] GC_CR_CU_DM_SLOT0_SLOT_0_COMPUTE0                   = 4'h0;
localparam logic [ 3 : 0 ] GC_CR_CU_DM_SLOT0_SLOT_0_COMPUTE1                   = 4'h1;
localparam logic [ 3 : 0 ] GC_CR_CU_DM_SLOT0_SLOT_0_COMPUTE2                   = 4'h2;
localparam logic [ 3 : 0 ] GC_CR_CU_DM_SLOT0_SLOT_0_COMPUTE3                   = 4'h3;
localparam logic [ 3 : 0 ] GC_CR_CU_DM_SLOT0_SLOT_0_EMPTY                      = 4'hf;
localparam logic [ 7 : 4 ] GC_CR_CU_DM_SLOT0_SLOT_1_BITFIELD                   = 4'hf;
localparam logic [ 7 : 4 ] GC_CR_CU_DM_SLOT0_SLOT_1_COMPUTE0                   = 4'h0;
localparam logic [ 7 : 4 ] GC_CR_CU_DM_SLOT0_SLOT_1_COMPUTE1                   = 4'h1;
localparam logic [ 7 : 4 ] GC_CR_CU_DM_SLOT0_SLOT_1_COMPUTE2                   = 4'h2;
localparam logic [ 7 : 4 ] GC_CR_CU_DM_SLOT0_SLOT_1_COMPUTE3                   = 4'h3;
localparam logic [ 7 : 4 ] GC_CR_CU_DM_SLOT0_SLOT_1_EMPTY                      = 4'hf;
localparam logic [ 11 : 8 ] GC_CR_CU_DM_SLOT0_SLOT_2_BITFIELD                  = 4'hf;
localparam logic [ 11 : 8 ] GC_CR_CU_DM_SLOT0_SLOT_2_COMPUTE0                  = 4'h0;
localparam logic [ 11 : 8 ] GC_CR_CU_DM_SLOT0_SLOT_2_COMPUTE1                  = 4'h1;
localparam logic [ 11 : 8 ] GC_CR_CU_DM_SLOT0_SLOT_2_COMPUTE2                  = 4'h2;
localparam logic [ 11 : 8 ] GC_CR_CU_DM_SLOT0_SLOT_2_COMPUTE3                  = 4'h3;
localparam logic [ 11 : 8 ] GC_CR_CU_DM_SLOT0_SLOT_2_EMPTY                     = 4'hf;
localparam logic [ 15 : 12 ] GC_CR_CU_DM_SLOT0_SLOT_3_BITFIELD                 = 4'hf;
localparam logic [ 15 : 12 ] GC_CR_CU_DM_SLOT0_SLOT_3_COMPUTE0                 = 4'h0;
localparam logic [ 15 : 12 ] GC_CR_CU_DM_SLOT0_SLOT_3_COMPUTE1                 = 4'h1;
localparam logic [ 15 : 12 ] GC_CR_CU_DM_SLOT0_SLOT_3_COMPUTE2                 = 4'h2;
localparam logic [ 15 : 12 ] GC_CR_CU_DM_SLOT0_SLOT_3_COMPUTE3                 = 4'h3;
localparam logic [ 15 : 12 ] GC_CR_CU_DM_SLOT0_SLOT_3_EMPTY                    = 4'hf;
localparam logic [ 19 : 16 ] GC_CR_CU_DM_SLOT0_SLOT_4_BITFIELD                 = 4'hf;
localparam logic [ 19 : 16 ] GC_CR_CU_DM_SLOT0_SLOT_4_COMPUTE0                 = 4'h0;
localparam logic [ 19 : 16 ] GC_CR_CU_DM_SLOT0_SLOT_4_COMPUTE1                 = 4'h1;
localparam logic [ 19 : 16 ] GC_CR_CU_DM_SLOT0_SLOT_4_COMPUTE2                 = 4'h2;
localparam logic [ 19 : 16 ] GC_CR_CU_DM_SLOT0_SLOT_4_COMPUTE3                 = 4'h3;
localparam logic [ 19 : 16 ] GC_CR_CU_DM_SLOT0_SLOT_4_EMPTY                    = 4'hf;
localparam logic [ 23 : 20 ] GC_CR_CU_DM_SLOT0_SLOT_5_BITFIELD                 = 4'hf;
localparam logic [ 23 : 20 ] GC_CR_CU_DM_SLOT0_SLOT_5_COMPUTE0                 = 4'h0;
localparam logic [ 23 : 20 ] GC_CR_CU_DM_SLOT0_SLOT_5_COMPUTE1                 = 4'h1;
localparam logic [ 23 : 20 ] GC_CR_CU_DM_SLOT0_SLOT_5_COMPUTE2                 = 4'h2;
localparam logic [ 23 : 20 ] GC_CR_CU_DM_SLOT0_SLOT_5_COMPUTE3                 = 4'h3;
localparam logic [ 23 : 20 ] GC_CR_CU_DM_SLOT0_SLOT_5_EMPTY                    = 4'hf;
localparam logic [ 27 : 24 ] GC_CR_CU_DM_SLOT0_SLOT_6_BITFIELD                 = 4'hf;
localparam logic [ 27 : 24 ] GC_CR_CU_DM_SLOT0_SLOT_6_COMPUTE0                 = 4'h0;
localparam logic [ 27 : 24 ] GC_CR_CU_DM_SLOT0_SLOT_6_COMPUTE1                 = 4'h1;
localparam logic [ 27 : 24 ] GC_CR_CU_DM_SLOT0_SLOT_6_COMPUTE2                 = 4'h2;
localparam logic [ 27 : 24 ] GC_CR_CU_DM_SLOT0_SLOT_6_COMPUTE3                 = 4'h3;
localparam logic [ 27 : 24 ] GC_CR_CU_DM_SLOT0_SLOT_6_EMPTY                    = 4'hf;
localparam logic [ 31 : 28 ] GC_CR_CU_DM_SLOT0_SLOT_7_BITFIELD                 = 4'hf;
localparam logic [ 31 : 28 ] GC_CR_CU_DM_SLOT0_SLOT_7_COMPUTE0                 = 4'h0;
localparam logic [ 31 : 28 ] GC_CR_CU_DM_SLOT0_SLOT_7_COMPUTE1                 = 4'h1;
localparam logic [ 31 : 28 ] GC_CR_CU_DM_SLOT0_SLOT_7_COMPUTE2                 = 4'h2;
localparam logic [ 31 : 28 ] GC_CR_CU_DM_SLOT0_SLOT_7_COMPUTE3                 = 4'h3;
localparam logic [ 31 : 28 ] GC_CR_CU_DM_SLOT0_SLOT_7_EMPTY                    = 4'hf;

 // gc_cr_cu_dm_slot1
localparam logic [ 3 : 0 ] GC_CR_CU_DM_SLOT1_SLOT_0_BITFIELD                   = 4'hf;
localparam logic [ 3 : 0 ] GC_CR_CU_DM_SLOT1_SLOT_0_COMPUTE0                   = 4'h0;
localparam logic [ 3 : 0 ] GC_CR_CU_DM_SLOT1_SLOT_0_COMPUTE1                   = 4'h1;
localparam logic [ 3 : 0 ] GC_CR_CU_DM_SLOT1_SLOT_0_COMPUTE2                   = 4'h2;
localparam logic [ 3 : 0 ] GC_CR_CU_DM_SLOT1_SLOT_0_COMPUTE3                   = 4'h3;
localparam logic [ 3 : 0 ] GC_CR_CU_DM_SLOT1_SLOT_0_EMPTY                      = 4'hf;
localparam logic [ 7 : 4 ] GC_CR_CU_DM_SLOT1_SLOT_1_BITFIELD                   = 4'hf;
localparam logic [ 7 : 4 ] GC_CR_CU_DM_SLOT1_SLOT_1_COMPUTE0                   = 4'h0;
localparam logic [ 7 : 4 ] GC_CR_CU_DM_SLOT1_SLOT_1_COMPUTE1                   = 4'h1;
localparam logic [ 7 : 4 ] GC_CR_CU_DM_SLOT1_SLOT_1_COMPUTE2                   = 4'h2;
localparam logic [ 7 : 4 ] GC_CR_CU_DM_SLOT1_SLOT_1_COMPUTE3                   = 4'h3;
localparam logic [ 7 : 4 ] GC_CR_CU_DM_SLOT1_SLOT_1_EMPTY                      = 4'hf;
localparam logic [ 11 : 8 ] GC_CR_CU_DM_SLOT1_SLOT_2_BITFIELD                  = 4'hf;
localparam logic [ 11 : 8 ] GC_CR_CU_DM_SLOT1_SLOT_2_COMPUTE0                  = 4'h0;
localparam logic [ 11 : 8 ] GC_CR_CU_DM_SLOT1_SLOT_2_COMPUTE1                  = 4'h1;
localparam logic [ 11 : 8 ] GC_CR_CU_DM_SLOT1_SLOT_2_COMPUTE2                  = 4'h2;
localparam logic [ 11 : 8 ] GC_CR_CU_DM_SLOT1_SLOT_2_COMPUTE3                  = 4'h3;
localparam logic [ 11 : 8 ] GC_CR_CU_DM_SLOT1_SLOT_2_EMPTY                     = 4'hf;
localparam logic [ 15 : 12 ] GC_CR_CU_DM_SLOT1_SLOT_3_BITFIELD                 = 4'hf;
localparam logic [ 15 : 12 ] GC_CR_CU_DM_SLOT1_SLOT_3_COMPUTE0                 = 4'h0;
localparam logic [ 15 : 12 ] GC_CR_CU_DM_SLOT1_SLOT_3_COMPUTE1                 = 4'h1;
localparam logic [ 15 : 12 ] GC_CR_CU_DM_SLOT1_SLOT_3_COMPUTE2                 = 4'h2;
localparam logic [ 15 : 12 ] GC_CR_CU_DM_SLOT1_SLOT_3_COMPUTE3                 = 4'h3;
localparam logic [ 15 : 12 ] GC_CR_CU_DM_SLOT1_SLOT_3_EMPTY                    = 4'hf;
localparam logic [ 19 : 16 ] GC_CR_CU_DM_SLOT1_SLOT_4_BITFIELD                 = 4'hf;
localparam logic [ 19 : 16 ] GC_CR_CU_DM_SLOT1_SLOT_4_COMPUTE0                 = 4'h0;
localparam logic [ 19 : 16 ] GC_CR_CU_DM_SLOT1_SLOT_4_COMPUTE1                 = 4'h1;
localparam logic [ 19 : 16 ] GC_CR_CU_DM_SLOT1_SLOT_4_COMPUTE2                 = 4'h2;
localparam logic [ 19 : 16 ] GC_CR_CU_DM_SLOT1_SLOT_4_COMPUTE3                 = 4'h3;
localparam logic [ 19 : 16 ] GC_CR_CU_DM_SLOT1_SLOT_4_EMPTY                    = 4'hf;
localparam logic [ 23 : 20 ] GC_CR_CU_DM_SLOT1_SLOT_5_BITFIELD                 = 4'hf;
localparam logic [ 23 : 20 ] GC_CR_CU_DM_SLOT1_SLOT_5_COMPUTE0                 = 4'h0;
localparam logic [ 23 : 20 ] GC_CR_CU_DM_SLOT1_SLOT_5_COMPUTE1                 = 4'h1;
localparam logic [ 23 : 20 ] GC_CR_CU_DM_SLOT1_SLOT_5_COMPUTE2                 = 4'h2;
localparam logic [ 23 : 20 ] GC_CR_CU_DM_SLOT1_SLOT_5_COMPUTE3                 = 4'h3;
localparam logic [ 23 : 20 ] GC_CR_CU_DM_SLOT1_SLOT_5_EMPTY                    = 4'hf;
localparam logic [ 27 : 24 ] GC_CR_CU_DM_SLOT1_SLOT_6_BITFIELD                 = 4'hf;
localparam logic [ 27 : 24 ] GC_CR_CU_DM_SLOT1_SLOT_6_COMPUTE0                 = 4'h0;
localparam logic [ 27 : 24 ] GC_CR_CU_DM_SLOT1_SLOT_6_COMPUTE1                 = 4'h1;
localparam logic [ 27 : 24 ] GC_CR_CU_DM_SLOT1_SLOT_6_COMPUTE2                 = 4'h2;
localparam logic [ 27 : 24 ] GC_CR_CU_DM_SLOT1_SLOT_6_COMPUTE3                 = 4'h3;
localparam logic [ 27 : 24 ] GC_CR_CU_DM_SLOT1_SLOT_6_EMPTY                    = 4'hf;
localparam logic [ 31 : 28 ] GC_CR_CU_DM_SLOT1_SLOT_7_BITFIELD                 = 4'hf;
localparam logic [ 31 : 28 ] GC_CR_CU_DM_SLOT1_SLOT_7_COMPUTE0                 = 4'h0;
localparam logic [ 31 : 28 ] GC_CR_CU_DM_SLOT1_SLOT_7_COMPUTE1                 = 4'h1;
localparam logic [ 31 : 28 ] GC_CR_CU_DM_SLOT1_SLOT_7_COMPUTE2                 = 4'h2;
localparam logic [ 31 : 28 ] GC_CR_CU_DM_SLOT1_SLOT_7_COMPUTE3                 = 4'h3;
localparam logic [ 31 : 28 ] GC_CR_CU_DM_SLOT1_SLOT_7_EMPTY                    = 4'hf;

 // gc_cr_cu_dm_slot2
localparam logic [ 3 : 0 ] GC_CR_CU_DM_SLOT2_SLOT_0_BITFIELD                   = 4'hf;
localparam logic [ 3 : 0 ] GC_CR_CU_DM_SLOT2_SLOT_0_COMPUTE0                   = 4'h0;
localparam logic [ 3 : 0 ] GC_CR_CU_DM_SLOT2_SLOT_0_COMPUTE1                   = 4'h1;
localparam logic [ 3 : 0 ] GC_CR_CU_DM_SLOT2_SLOT_0_COMPUTE2                   = 4'h2;
localparam logic [ 3 : 0 ] GC_CR_CU_DM_SLOT2_SLOT_0_COMPUTE3                   = 4'h3;
localparam logic [ 3 : 0 ] GC_CR_CU_DM_SLOT2_SLOT_0_EMPTY                      = 4'hf;
localparam logic [ 7 : 4 ] GC_CR_CU_DM_SLOT2_SLOT_1_BITFIELD                   = 4'hf;
localparam logic [ 7 : 4 ] GC_CR_CU_DM_SLOT2_SLOT_1_COMPUTE0                   = 4'h0;
localparam logic [ 7 : 4 ] GC_CR_CU_DM_SLOT2_SLOT_1_COMPUTE1                   = 4'h1;
localparam logic [ 7 : 4 ] GC_CR_CU_DM_SLOT2_SLOT_1_COMPUTE2                   = 4'h2;
localparam logic [ 7 : 4 ] GC_CR_CU_DM_SLOT2_SLOT_1_COMPUTE3                   = 4'h3;
localparam logic [ 7 : 4 ] GC_CR_CU_DM_SLOT2_SLOT_1_EMPTY                      = 4'hf;
localparam logic [ 11 : 8 ] GC_CR_CU_DM_SLOT2_SLOT_2_BITFIELD                  = 4'hf;
localparam logic [ 11 : 8 ] GC_CR_CU_DM_SLOT2_SLOT_2_COMPUTE0                  = 4'h0;
localparam logic [ 11 : 8 ] GC_CR_CU_DM_SLOT2_SLOT_2_COMPUTE1                  = 4'h1;
localparam logic [ 11 : 8 ] GC_CR_CU_DM_SLOT2_SLOT_2_COMPUTE2                  = 4'h2;
localparam logic [ 11 : 8 ] GC_CR_CU_DM_SLOT2_SLOT_2_COMPUTE3                  = 4'h3;
localparam logic [ 11 : 8 ] GC_CR_CU_DM_SLOT2_SLOT_2_EMPTY                     = 4'hf;
localparam logic [ 15 : 12 ] GC_CR_CU_DM_SLOT2_SLOT_3_BITFIELD                 = 4'hf;
localparam logic [ 15 : 12 ] GC_CR_CU_DM_SLOT2_SLOT_3_COMPUTE0                 = 4'h0;
localparam logic [ 15 : 12 ] GC_CR_CU_DM_SLOT2_SLOT_3_COMPUTE1                 = 4'h1;
localparam logic [ 15 : 12 ] GC_CR_CU_DM_SLOT2_SLOT_3_COMPUTE2                 = 4'h2;
localparam logic [ 15 : 12 ] GC_CR_CU_DM_SLOT2_SLOT_3_COMPUTE3                 = 4'h3;
localparam logic [ 15 : 12 ] GC_CR_CU_DM_SLOT2_SLOT_3_EMPTY                    = 4'hf;
localparam logic [ 19 : 16 ] GC_CR_CU_DM_SLOT2_SLOT_4_BITFIELD                 = 4'hf;
localparam logic [ 19 : 16 ] GC_CR_CU_DM_SLOT2_SLOT_4_COMPUTE0                 = 4'h0;
localparam logic [ 19 : 16 ] GC_CR_CU_DM_SLOT2_SLOT_4_COMPUTE1                 = 4'h1;
localparam logic [ 19 : 16 ] GC_CR_CU_DM_SLOT2_SLOT_4_COMPUTE2                 = 4'h2;
localparam logic [ 19 : 16 ] GC_CR_CU_DM_SLOT2_SLOT_4_COMPUTE3                 = 4'h3;
localparam logic [ 19 : 16 ] GC_CR_CU_DM_SLOT2_SLOT_4_EMPTY                    = 4'hf;
localparam logic [ 23 : 20 ] GC_CR_CU_DM_SLOT2_SLOT_5_BITFIELD                 = 4'hf;
localparam logic [ 23 : 20 ] GC_CR_CU_DM_SLOT2_SLOT_5_COMPUTE0                 = 4'h0;
localparam logic [ 23 : 20 ] GC_CR_CU_DM_SLOT2_SLOT_5_COMPUTE1                 = 4'h1;
localparam logic [ 23 : 20 ] GC_CR_CU_DM_SLOT2_SLOT_5_COMPUTE2                 = 4'h2;
localparam logic [ 23 : 20 ] GC_CR_CU_DM_SLOT2_SLOT_5_COMPUTE3                 = 4'h3;
localparam logic [ 23 : 20 ] GC_CR_CU_DM_SLOT2_SLOT_5_EMPTY                    = 4'hf;
localparam logic [ 27 : 24 ] GC_CR_CU_DM_SLOT2_SLOT_6_BITFIELD                 = 4'hf;
localparam logic [ 27 : 24 ] GC_CR_CU_DM_SLOT2_SLOT_6_COMPUTE0                 = 4'h0;
localparam logic [ 27 : 24 ] GC_CR_CU_DM_SLOT2_SLOT_6_COMPUTE1                 = 4'h1;
localparam logic [ 27 : 24 ] GC_CR_CU_DM_SLOT2_SLOT_6_COMPUTE2                 = 4'h2;
localparam logic [ 27 : 24 ] GC_CR_CU_DM_SLOT2_SLOT_6_COMPUTE3                 = 4'h3;
localparam logic [ 27 : 24 ] GC_CR_CU_DM_SLOT2_SLOT_6_EMPTY                    = 4'hf;
localparam logic [ 31 : 28 ] GC_CR_CU_DM_SLOT2_SLOT_7_BITFIELD                 = 4'hf;
localparam logic [ 31 : 28 ] GC_CR_CU_DM_SLOT2_SLOT_7_COMPUTE0                 = 4'h0;
localparam logic [ 31 : 28 ] GC_CR_CU_DM_SLOT2_SLOT_7_COMPUTE1                 = 4'h1;
localparam logic [ 31 : 28 ] GC_CR_CU_DM_SLOT2_SLOT_7_COMPUTE2                 = 4'h2;
localparam logic [ 31 : 28 ] GC_CR_CU_DM_SLOT2_SLOT_7_COMPUTE3                 = 4'h3;
localparam logic [ 31 : 28 ] GC_CR_CU_DM_SLOT2_SLOT_7_EMPTY                    = 4'hf;

 // gc_cr_cu_dm_slot3
localparam logic [ 3 : 0 ] GC_CR_CU_DM_SLOT3_SLOT_0_BITFIELD                   = 4'hf;
localparam logic [ 3 : 0 ] GC_CR_CU_DM_SLOT3_SLOT_0_COMPUTE0                   = 4'h0;
localparam logic [ 3 : 0 ] GC_CR_CU_DM_SLOT3_SLOT_0_COMPUTE1                   = 4'h1;
localparam logic [ 3 : 0 ] GC_CR_CU_DM_SLOT3_SLOT_0_COMPUTE2                   = 4'h2;
localparam logic [ 3 : 0 ] GC_CR_CU_DM_SLOT3_SLOT_0_COMPUTE3                   = 4'h3;
localparam logic [ 3 : 0 ] GC_CR_CU_DM_SLOT3_SLOT_0_EMPTY                      = 4'hf;
localparam logic [ 7 : 4 ] GC_CR_CU_DM_SLOT3_SLOT_1_BITFIELD                   = 4'hf;
localparam logic [ 7 : 4 ] GC_CR_CU_DM_SLOT3_SLOT_1_COMPUTE0                   = 4'h0;
localparam logic [ 7 : 4 ] GC_CR_CU_DM_SLOT3_SLOT_1_COMPUTE1                   = 4'h1;
localparam logic [ 7 : 4 ] GC_CR_CU_DM_SLOT3_SLOT_1_COMPUTE2                   = 4'h2;
localparam logic [ 7 : 4 ] GC_CR_CU_DM_SLOT3_SLOT_1_COMPUTE3                   = 4'h3;
localparam logic [ 7 : 4 ] GC_CR_CU_DM_SLOT3_SLOT_1_EMPTY                      = 4'hf;
localparam logic [ 11 : 8 ] GC_CR_CU_DM_SLOT3_SLOT_2_BITFIELD                  = 4'hf;
localparam logic [ 11 : 8 ] GC_CR_CU_DM_SLOT3_SLOT_2_COMPUTE0                  = 4'h0;
localparam logic [ 11 : 8 ] GC_CR_CU_DM_SLOT3_SLOT_2_COMPUTE1                  = 4'h1;
localparam logic [ 11 : 8 ] GC_CR_CU_DM_SLOT3_SLOT_2_COMPUTE2                  = 4'h2;
localparam logic [ 11 : 8 ] GC_CR_CU_DM_SLOT3_SLOT_2_COMPUTE3                  = 4'h3;
localparam logic [ 11 : 8 ] GC_CR_CU_DM_SLOT3_SLOT_2_EMPTY                     = 4'hf;
localparam logic [ 15 : 12 ] GC_CR_CU_DM_SLOT3_SLOT_3_BITFIELD                 = 4'hf;
localparam logic [ 15 : 12 ] GC_CR_CU_DM_SLOT3_SLOT_3_COMPUTE0                 = 4'h0;
localparam logic [ 15 : 12 ] GC_CR_CU_DM_SLOT3_SLOT_3_COMPUTE1                 = 4'h1;
localparam logic [ 15 : 12 ] GC_CR_CU_DM_SLOT3_SLOT_3_COMPUTE2                 = 4'h2;
localparam logic [ 15 : 12 ] GC_CR_CU_DM_SLOT3_SLOT_3_COMPUTE3                 = 4'h3;
localparam logic [ 15 : 12 ] GC_CR_CU_DM_SLOT3_SLOT_3_EMPTY                    = 4'hf;
localparam logic [ 19 : 16 ] GC_CR_CU_DM_SLOT3_SLOT_4_BITFIELD                 = 4'hf;
localparam logic [ 19 : 16 ] GC_CR_CU_DM_SLOT3_SLOT_4_COMPUTE0                 = 4'h0;
localparam logic [ 19 : 16 ] GC_CR_CU_DM_SLOT3_SLOT_4_COMPUTE1                 = 4'h1;
localparam logic [ 19 : 16 ] GC_CR_CU_DM_SLOT3_SLOT_4_COMPUTE2                 = 4'h2;
localparam logic [ 19 : 16 ] GC_CR_CU_DM_SLOT3_SLOT_4_COMPUTE3                 = 4'h3;
localparam logic [ 19 : 16 ] GC_CR_CU_DM_SLOT3_SLOT_4_EMPTY                    = 4'hf;
localparam logic [ 23 : 20 ] GC_CR_CU_DM_SLOT3_SLOT_5_BITFIELD                 = 4'hf;
localparam logic [ 23 : 20 ] GC_CR_CU_DM_SLOT3_SLOT_5_COMPUTE0                 = 4'h0;
localparam logic [ 23 : 20 ] GC_CR_CU_DM_SLOT3_SLOT_5_COMPUTE1                 = 4'h1;
localparam logic [ 23 : 20 ] GC_CR_CU_DM_SLOT3_SLOT_5_COMPUTE2                 = 4'h2;
localparam logic [ 23 : 20 ] GC_CR_CU_DM_SLOT3_SLOT_5_COMPUTE3                 = 4'h3;
localparam logic [ 23 : 20 ] GC_CR_CU_DM_SLOT3_SLOT_5_EMPTY                    = 4'hf;
localparam logic [ 27 : 24 ] GC_CR_CU_DM_SLOT3_SLOT_6_BITFIELD                 = 4'hf;
localparam logic [ 27 : 24 ] GC_CR_CU_DM_SLOT3_SLOT_6_COMPUTE0                 = 4'h0;
localparam logic [ 27 : 24 ] GC_CR_CU_DM_SLOT3_SLOT_6_COMPUTE1                 = 4'h1;
localparam logic [ 27 : 24 ] GC_CR_CU_DM_SLOT3_SLOT_6_COMPUTE2                 = 4'h2;
localparam logic [ 27 : 24 ] GC_CR_CU_DM_SLOT3_SLOT_6_COMPUTE3                 = 4'h3;
localparam logic [ 27 : 24 ] GC_CR_CU_DM_SLOT3_SLOT_6_EMPTY                    = 4'hf;
localparam logic [ 31 : 28 ] GC_CR_CU_DM_SLOT3_SLOT_7_BITFIELD                 = 4'hf;
localparam logic [ 31 : 28 ] GC_CR_CU_DM_SLOT3_SLOT_7_COMPUTE0                 = 4'h0;
localparam logic [ 31 : 28 ] GC_CR_CU_DM_SLOT3_SLOT_7_COMPUTE1                 = 4'h1;
localparam logic [ 31 : 28 ] GC_CR_CU_DM_SLOT3_SLOT_7_COMPUTE2                 = 4'h2;
localparam logic [ 31 : 28 ] GC_CR_CU_DM_SLOT3_SLOT_7_COMPUTE3                 = 4'h3;
localparam logic [ 31 : 28 ] GC_CR_CU_DM_SLOT3_SLOT_7_EMPTY                    = 4'hf;

 // gc_cr_cu_slot_sched_policy
localparam logic [ 0 : 0 ] GC_CR_CU_SLOT_SCHED_POLICY_MODE_BITFIELD            = 1'h1;
localparam logic [ 0 : 0 ] GC_CR_CU_SLOT_SCHED_POLICY_MODE_OLDEST_POLICY       = 1'h0;
localparam logic [ 0 : 0 ] GC_CR_CU_SLOT_SCHED_POLICY_MODE_ROUND_ROBIN_POLICY   = 1'h1;

 // gc_cr_eu_pipe_idle
localparam logic [ 0 : 0 ] GC_CR_EU_PIPE_IDLE_ICTRL_BITFIELD                   = 1'h1;
localparam logic [ 1 : 1 ] GC_CR_EU_PIPE_IDLE_SS_BITFIELD                      = 1'h1;
localparam logic [ 2 : 2 ] GC_CR_EU_PIPE_IDLE_CMN_FQ_BITFIELD                  = 1'h1;
localparam logic [ 3 : 3 ] GC_CR_EU_PIPE_IDLE_CEU_BITFIELD                     = 1'h1;
localparam logic [ 4 : 4 ] GC_CR_EU_PIPE_IDLE_FC_BITFIELD                      = 1'h1;
localparam logic [ 5 : 5 ] GC_CR_EU_PIPE_IDLE_SFU_BITFIELD                     = 1'h1;
localparam logic [ 6 : 6 ] GC_CR_EU_PIPE_IDLE_LSU_BITFIELD                     = 1'h1;
localparam logic [ 7 : 7 ] GC_CR_EU_PIPE_IDLE_MAU_BITFIELD                     = 1'h1;
localparam logic [ 8 : 8 ] GC_CR_EU_PIPE_IDLE_TC_BITFIELD                      = 1'h1;
localparam logic [ 9 : 9 ] GC_CR_EU_PIPE_IDLE_SMP_BITFIELD                     = 1'h1;
localparam logic [ 10 : 10 ] GC_CR_EU_PIPE_IDLE_PAP_HQ_FOP_BITFIELD            = 1'h1;
localparam logic [ 11 : 11 ] GC_CR_EU_PIPE_IDLE_PAP_HQ_CVT_BITFIELD            = 1'h1;
localparam logic [ 12 : 12 ] GC_CR_EU_PIPE_IDLE_SPAG_PAP_BITFIELD              = 1'h1;
localparam logic [ 13 : 13 ] GC_CR_EU_PIPE_IDLE_SPAG_SAP_BITFIELD              = 1'h1;
localparam logic [ 14 : 14 ] GC_CR_EU_PIPE_IDLE_PAP_SAG_COMMON_BITFIELD        = 1'h1;
localparam logic [ 15 : 15 ] GC_CR_EU_PIPE_IDLE_PAP_SAG_ROUTER_BITFIELD        = 1'h1;
localparam logic [ 16 : 16 ] GC_CR_EU_PIPE_IDLE_SAP_SAG_COMMON_BITFIELD        = 1'h1;
localparam logic [ 17 : 17 ] GC_CR_EU_PIPE_IDLE_SAP_SAG_ROUTER_BITFIELD        = 1'h1;
localparam logic [ 18 : 18 ] GC_CR_EU_PIPE_IDLE_SPAG0_BITFIELD                 = 1'h1;
localparam logic [ 19 : 19 ] GC_CR_EU_PIPE_IDLE_SPAG1_BITFIELD                 = 1'h1;
localparam logic [ 20 : 20 ] GC_CR_EU_PIPE_IDLE_SPAG2_BITFIELD                 = 1'h1;
localparam logic [ 21 : 21 ] GC_CR_EU_PIPE_IDLE_SPAG3_BITFIELD                 = 1'h1;
localparam logic [ 22 : 22 ] GC_CR_EU_PIPE_IDLE_SHS_BITFIELD                   = 1'h1;
localparam logic [ 23 : 23 ] GC_CR_EU_PIPE_IDLE_PS_BITFIELD                    = 1'h1;
localparam logic [ 24 : 24 ] GC_CR_EU_PIPE_IDLE_SRS_BITFIELD                   = 1'h1;
localparam logic [ 25 : 25 ] GC_CR_EU_PIPE_IDLE_DFU_BITFIELD                   = 1'h1;
localparam logic [ 26 : 26 ] GC_CR_EU_PIPE_IDLE_BIF_ARB_BITFIELD               = 1'h1;
localparam logic [ 27 : 27 ] GC_CR_EU_PIPE_IDLE_RESERVED0_BITFIELD             = 1'h1;
localparam logic [ 28 : 28 ] GC_CR_EU_PIPE_IDLE_RESERVED1_BITFIELD             = 1'h1;

 // gc_cr_cu_idle
localparam logic [ 0 : 0 ] GC_CR_CU_IDLE_EU1_BITFIELD                          = 1'h1;
localparam logic [ 1 : 1 ] GC_CR_CU_IDLE_EU0_BITFIELD                          = 1'h1;
localparam logic [ 2 : 2 ] GC_CR_CU_IDLE_PERF_MON_BITFIELD                     = 1'h1;
localparam logic [ 3 : 3 ] GC_CR_CU_IDLE_BIF_ARB_BITFIELD                      = 1'h1;
localparam logic [ 4 : 4 ] GC_CR_CU_IDLE_L0C1_BITFIELD                         = 1'h1;
localparam logic [ 5 : 5 ] GC_CR_CU_IDLE_L0C0_BITFIELD                         = 1'h1;
localparam logic [ 6 : 6 ] GC_CR_CU_IDLE_LMS_BITFIELD                          = 1'h1;
localparam logic [ 7 : 7 ] GC_CR_CU_IDLE_TS_BITFIELD                           = 1'h1;
localparam logic [ 8 : 8 ] GC_CR_CU_IDLE_TRM_BITFIELD                          = 1'h1;

 // gc_cr_cu_exception
localparam logic [ 0 : 0 ] GC_CR_CU_EXCEPTION_AC_WRITE_BITFIELD                = 1'h0;
localparam logic [ 1 : 1 ] GC_CR_CU_EXCEPTION_AC_READ_BITFIELD                 = 1'h0;
localparam logic [ 2 : 2 ] GC_CR_CU_EXCEPTION_LSU_WRITE_BITFIELD               = 1'h0;
localparam logic [ 3 : 3 ] GC_CR_CU_EXCEPTION_LSU_READ_BITFIELD                = 1'h0;
localparam logic [ 4 : 4 ] GC_CR_CU_EXCEPTION_LMS_AP_0_WRITE_BITFIELD          = 1'h0;
localparam logic [ 5 : 5 ] GC_CR_CU_EXCEPTION_LMS_AP_0_READ_BITFIELD           = 1'h0;
localparam logic [ 6 : 6 ] GC_CR_CU_EXCEPTION_LMS_AP_1_WRITE_BITFIELD          = 1'h0;
localparam logic [ 7 : 7 ] GC_CR_CU_EXCEPTION_LMS_AP_1_READ_BITFIELD           = 1'h0;
localparam logic [ 8 : 8 ] GC_CR_CU_EXCEPTION_LMS_MOV_0_WRITE_BITFIELD         = 1'h0;
localparam logic [ 9 : 9 ] GC_CR_CU_EXCEPTION_LMS_MOV_0_READ_BITFIELD          = 1'h0;
localparam logic [ 10 : 10 ] GC_CR_CU_EXCEPTION_LMS_MOV_1_WRITE_BITFIELD       = 1'h0;
localparam logic [ 11 : 11 ] GC_CR_CU_EXCEPTION_LMS_MOV_1_READ_BITFIELD        = 1'h0;
localparam logic [ 12 : 12 ] GC_CR_CU_EXCEPTION_LMS_LSU_0_WRITE_BITFIELD       = 1'h0;
localparam logic [ 13 : 13 ] GC_CR_CU_EXCEPTION_LMS_LSU_0_READ_BITFIELD        = 1'h0;
localparam logic [ 14 : 14 ] GC_CR_CU_EXCEPTION_LMS_LSU_1_WRITE_BITFIELD       = 1'h0;
localparam logic [ 15 : 15 ] GC_CR_CU_EXCEPTION_LMS_LSU_1_READ_BITFIELD        = 1'h0;

 // gc_cr_cu_exception_rw_reset
localparam logic [ 0 : 0 ] GC_CR_CU_EXCEPTION_RW_RESET_AC_BITFIELD             = 1'h0;
localparam logic [ 1 : 1 ] GC_CR_CU_EXCEPTION_RW_RESET_LSU_BITFIELD            = 1'h0;
localparam logic [ 2 : 2 ] GC_CR_CU_EXCEPTION_RW_RESET_LMS_AP_0_BITFIELD       = 1'h0;
localparam logic [ 3 : 3 ] GC_CR_CU_EXCEPTION_RW_RESET_LMS_AP_1_BITFIELD       = 1'h0;
localparam logic [ 4 : 4 ] GC_CR_CU_EXCEPTION_RW_RESET_LMS_MOV_0_BITFIELD      = 1'h0;
localparam logic [ 5 : 5 ] GC_CR_CU_EXCEPTION_RW_RESET_LMS_MOV_1_BITFIELD      = 1'h0;
localparam logic [ 6 : 6 ] GC_CR_CU_EXCEPTION_RW_RESET_LMS_LSU_0_BITFIELD      = 1'h0;
localparam logic [ 7 : 7 ] GC_CR_CU_EXCEPTION_RW_RESET_LMS_LSU_1_BITFIELD      = 1'h0;

 // gc_cr_cu_exception_oob_chk
localparam logic [ 0 : 0 ] GC_CR_CU_EXCEPTION_OOB_CHK_LSU_OOB_CHK_EN_BITFIELD  = 1'h1;
localparam logic [ 1 : 1 ] GC_CR_CU_EXCEPTION_OOB_CHK_MAU_OOB_CHK_EN_BITFIELD  = 1'h1;
localparam logic [ 2 : 2 ] GC_CR_CU_EXCEPTION_OOB_CHK_LMS_OOB_CHK_EN_BITFIELD  = 1'h1;

 // gc_cr_spc_bif_outstanding_read_counter0
localparam logic [ 15 : 0 ] GC_CR_SPC_BIF_OUTSTANDING_READ_COUNTER0_BIF0_BITFIELD  = 16'h0;
localparam logic [ 31 : 16 ] GC_CR_SPC_BIF_OUTSTANDING_READ_COUNTER0_BIF1_BITFIELD  = 16'h0;
localparam logic [ 47 : 32 ] GC_CR_SPC_BIF_OUTSTANDING_READ_COUNTER0_BIF2_BITFIELD  = 16'h0;
localparam logic [ 63 : 48 ] GC_CR_SPC_BIF_OUTSTANDING_READ_COUNTER0_BIF3_BITFIELD  = 16'h0;

 // gc_cr_spc_bif_outstanding_read_counter1
localparam logic [ 15 : 0 ] GC_CR_SPC_BIF_OUTSTANDING_READ_COUNTER1_BIF0_BITFIELD  = 16'h0;
localparam logic [ 31 : 16 ] GC_CR_SPC_BIF_OUTSTANDING_READ_COUNTER1_BIF1_BITFIELD  = 16'h0;
localparam logic [ 47 : 32 ] GC_CR_SPC_BIF_OUTSTANDING_READ_COUNTER1_BIF2_BITFIELD  = 16'h0;
localparam logic [ 63 : 48 ] GC_CR_SPC_BIF_OUTSTANDING_READ_COUNTER1_BIF3_BITFIELD  = 16'h0;

 // gc_cr_spc_bif_rtn_fifo_word_count0
localparam logic [ 9 : 0 ] GC_CR_SPC_BIF_RTN_FIFO_WORD_COUNT0_BIF0_BITFIELD    = 10'h0;
localparam logic [ 19 : 10 ] GC_CR_SPC_BIF_RTN_FIFO_WORD_COUNT0_BIF1_BITFIELD  = 10'h0;
localparam logic [ 29 : 20 ] GC_CR_SPC_BIF_RTN_FIFO_WORD_COUNT0_BIF2_BITFIELD  = 10'h0;
localparam logic [ 39 : 30 ] GC_CR_SPC_BIF_RTN_FIFO_WORD_COUNT0_BIF3_BITFIELD  = 10'h0;

 // gc_cr_spc_bif_rtn_fifo_word_count1
localparam logic [ 9 : 0 ] GC_CR_SPC_BIF_RTN_FIFO_WORD_COUNT1_BIF0_BITFIELD    = 10'h0;
localparam logic [ 19 : 10 ] GC_CR_SPC_BIF_RTN_FIFO_WORD_COUNT1_BIF1_BITFIELD  = 10'h0;
localparam logic [ 29 : 20 ] GC_CR_SPC_BIF_RTN_FIFO_WORD_COUNT1_BIF2_BITFIELD  = 10'h0;
localparam logic [ 39 : 30 ] GC_CR_SPC_BIF_RTN_FIFO_WORD_COUNT1_BIF3_BITFIELD  = 10'h0;

 // gc_cr_spc_bif_pfs0
localparam logic [ 0 : 0 ] GC_CR_SPC_BIF_PFS0_STALL_COMPLETE_BIF0_BITFIELD     = 1'h1;
localparam logic [ 1 : 1 ] GC_CR_SPC_BIF_PFS0_STALL_COMPLETE_BIF1_BITFIELD     = 1'h1;
localparam logic [ 2 : 2 ] GC_CR_SPC_BIF_PFS0_STALL_COMPLETE_BIF2_BITFIELD     = 1'h1;
localparam logic [ 3 : 3 ] GC_CR_SPC_BIF_PFS0_STALL_COMPLETE_BIF3_BITFIELD     = 1'h1;
localparam logic [ 4 : 4 ] GC_CR_SPC_BIF_PFS0_REQUEST_IP_IDLE_BIF0_BITFIELD    = 1'h1;
localparam logic [ 5 : 5 ] GC_CR_SPC_BIF_PFS0_REQUEST_IP_IDLE_BIF1_BITFIELD    = 1'h1;
localparam logic [ 6 : 6 ] GC_CR_SPC_BIF_PFS0_REQUEST_IP_IDLE_BIF2_BITFIELD    = 1'h1;
localparam logic [ 7 : 7 ] GC_CR_SPC_BIF_PFS0_REQUEST_IP_IDLE_BIF3_BITFIELD    = 1'h1;
localparam logic [ 8 : 8 ] GC_CR_SPC_BIF_PFS0_WDATA_IP_IDLE_BIF0_BITFIELD      = 1'h1;
localparam logic [ 9 : 9 ] GC_CR_SPC_BIF_PFS0_WDATA_IP_IDLE_BIF1_BITFIELD      = 1'h1;
localparam logic [ 10 : 10 ] GC_CR_SPC_BIF_PFS0_WDATA_IP_IDLE_BIF2_BITFIELD    = 1'h1;
localparam logic [ 11 : 11 ] GC_CR_SPC_BIF_PFS0_WDATA_IP_IDLE_BIF3_BITFIELD    = 1'h1;
localparam logic [ 12 : 12 ] GC_CR_SPC_BIF_PFS0_NONFWP_WDATA_COMPLETE_BIF0_BITFIELD  = 1'h1;
localparam logic [ 13 : 13 ] GC_CR_SPC_BIF_PFS0_NONFWP_WDATA_COMPLETE_BIF1_BITFIELD  = 1'h1;
localparam logic [ 14 : 14 ] GC_CR_SPC_BIF_PFS0_NONFWP_WDATA_COMPLETE_BIF2_BITFIELD  = 1'h1;
localparam logic [ 15 : 15 ] GC_CR_SPC_BIF_PFS0_NONFWP_WDATA_COMPLETE_BIF3_BITFIELD  = 1'h1;
localparam logic [ 16 : 16 ] GC_CR_SPC_BIF_PFS0_NONFWP_REQ_COMPLETE_BIF0_BITFIELD  = 1'h1;
localparam logic [ 17 : 17 ] GC_CR_SPC_BIF_PFS0_NONFWP_REQ_COMPLETE_BIF1_BITFIELD  = 1'h1;
localparam logic [ 18 : 18 ] GC_CR_SPC_BIF_PFS0_NONFWP_REQ_COMPLETE_BIF2_BITFIELD  = 1'h1;
localparam logic [ 19 : 19 ] GC_CR_SPC_BIF_PFS0_NONFWP_REQ_COMPLETE_BIF3_BITFIELD  = 1'h1;
localparam logic [ 20 : 20 ] GC_CR_SPC_BIF_PFS0_RTN_MEM_IF_IDLE_BIF0_BITFIELD  = 1'h1;
localparam logic [ 21 : 21 ] GC_CR_SPC_BIF_PFS0_RTN_MEM_IF_IDLE_BIF1_BITFIELD  = 1'h1;
localparam logic [ 22 : 22 ] GC_CR_SPC_BIF_PFS0_RTN_MEM_IF_IDLE_BIF2_BITFIELD  = 1'h1;
localparam logic [ 23 : 23 ] GC_CR_SPC_BIF_PFS0_RTN_MEM_IF_IDLE_BIF3_BITFIELD  = 1'h1;
localparam logic [ 24 : 24 ] GC_CR_SPC_BIF_PFS0_ARB_IDLE_BIF0_BITFIELD         = 1'h1;
localparam logic [ 25 : 25 ] GC_CR_SPC_BIF_PFS0_ARB_IDLE_BIF1_BITFIELD         = 1'h1;
localparam logic [ 26 : 26 ] GC_CR_SPC_BIF_PFS0_ARB_IDLE_BIF2_BITFIELD         = 1'h1;
localparam logic [ 27 : 27 ] GC_CR_SPC_BIF_PFS0_ARB_IDLE_BIF3_BITFIELD         = 1'h1;
localparam logic [ 28 : 28 ] GC_CR_SPC_BIF_PFS0_TILING_IDLE_BIF0_BITFIELD      = 1'h1;
localparam logic [ 29 : 29 ] GC_CR_SPC_BIF_PFS0_TILING_IDLE_BIF1_BITFIELD      = 1'h1;
localparam logic [ 30 : 30 ] GC_CR_SPC_BIF_PFS0_TILING_IDLE_BIF2_BITFIELD      = 1'h1;
localparam logic [ 31 : 31 ] GC_CR_SPC_BIF_PFS0_TILING_IDLE_BIF3_BITFIELD      = 1'h1;
localparam logic [ 32 : 32 ] GC_CR_SPC_BIF_PFS0_L2G_STALLING_BIF0_BITFIELD     = 1'h0;
localparam logic [ 33 : 33 ] GC_CR_SPC_BIF_PFS0_L2G_STALLING_BIF1_BITFIELD     = 1'h0;
localparam logic [ 34 : 34 ] GC_CR_SPC_BIF_PFS0_L2G_STALLING_BIF2_BITFIELD     = 1'h0;
localparam logic [ 35 : 35 ] GC_CR_SPC_BIF_PFS0_L2G_STALLING_BIF3_BITFIELD     = 1'h0;

 // gc_cr_spc_bif_pfs1
localparam logic [ 0 : 0 ] GC_CR_SPC_BIF_PFS1_STALL_COMPLETE_BIF0_BITFIELD     = 1'h1;
localparam logic [ 1 : 1 ] GC_CR_SPC_BIF_PFS1_STALL_COMPLETE_BIF1_BITFIELD     = 1'h1;
localparam logic [ 2 : 2 ] GC_CR_SPC_BIF_PFS1_STALL_COMPLETE_BIF2_BITFIELD     = 1'h1;
localparam logic [ 3 : 3 ] GC_CR_SPC_BIF_PFS1_STALL_COMPLETE_BIF3_BITFIELD     = 1'h1;
localparam logic [ 4 : 4 ] GC_CR_SPC_BIF_PFS1_REQUEST_IP_IDLE_BIF0_BITFIELD    = 1'h1;
localparam logic [ 5 : 5 ] GC_CR_SPC_BIF_PFS1_REQUEST_IP_IDLE_BIF1_BITFIELD    = 1'h1;
localparam logic [ 6 : 6 ] GC_CR_SPC_BIF_PFS1_REQUEST_IP_IDLE_BIF2_BITFIELD    = 1'h1;
localparam logic [ 7 : 7 ] GC_CR_SPC_BIF_PFS1_REQUEST_IP_IDLE_BIF3_BITFIELD    = 1'h1;
localparam logic [ 8 : 8 ] GC_CR_SPC_BIF_PFS1_WDATA_IP_IDLE_BIF0_BITFIELD      = 1'h1;
localparam logic [ 9 : 9 ] GC_CR_SPC_BIF_PFS1_WDATA_IP_IDLE_BIF1_BITFIELD      = 1'h1;
localparam logic [ 10 : 10 ] GC_CR_SPC_BIF_PFS1_WDATA_IP_IDLE_BIF2_BITFIELD    = 1'h1;
localparam logic [ 11 : 11 ] GC_CR_SPC_BIF_PFS1_WDATA_IP_IDLE_BIF3_BITFIELD    = 1'h1;
localparam logic [ 12 : 12 ] GC_CR_SPC_BIF_PFS1_NONFWP_WDATA_COMPLETE_BIF0_BITFIELD  = 1'h1;
localparam logic [ 13 : 13 ] GC_CR_SPC_BIF_PFS1_NONFWP_WDATA_COMPLETE_BIF1_BITFIELD  = 1'h1;
localparam logic [ 14 : 14 ] GC_CR_SPC_BIF_PFS1_NONFWP_WDATA_COMPLETE_BIF2_BITFIELD  = 1'h1;
localparam logic [ 15 : 15 ] GC_CR_SPC_BIF_PFS1_NONFWP_WDATA_COMPLETE_BIF3_BITFIELD  = 1'h1;
localparam logic [ 16 : 16 ] GC_CR_SPC_BIF_PFS1_NONFWP_REQ_COMPLETE_BIF0_BITFIELD  = 1'h1;
localparam logic [ 17 : 17 ] GC_CR_SPC_BIF_PFS1_NONFWP_REQ_COMPLETE_BIF1_BITFIELD  = 1'h1;
localparam logic [ 18 : 18 ] GC_CR_SPC_BIF_PFS1_NONFWP_REQ_COMPLETE_BIF2_BITFIELD  = 1'h1;
localparam logic [ 19 : 19 ] GC_CR_SPC_BIF_PFS1_NONFWP_REQ_COMPLETE_BIF3_BITFIELD  = 1'h1;
localparam logic [ 20 : 20 ] GC_CR_SPC_BIF_PFS1_RTN_MEM_IF_IDLE_BIF0_BITFIELD  = 1'h1;
localparam logic [ 21 : 21 ] GC_CR_SPC_BIF_PFS1_RTN_MEM_IF_IDLE_BIF1_BITFIELD  = 1'h1;
localparam logic [ 22 : 22 ] GC_CR_SPC_BIF_PFS1_RTN_MEM_IF_IDLE_BIF2_BITFIELD  = 1'h1;
localparam logic [ 23 : 23 ] GC_CR_SPC_BIF_PFS1_RTN_MEM_IF_IDLE_BIF3_BITFIELD  = 1'h1;
localparam logic [ 24 : 24 ] GC_CR_SPC_BIF_PFS1_ARB_IDLE_BIF0_BITFIELD         = 1'h1;
localparam logic [ 25 : 25 ] GC_CR_SPC_BIF_PFS1_ARB_IDLE_BIF1_BITFIELD         = 1'h1;
localparam logic [ 26 : 26 ] GC_CR_SPC_BIF_PFS1_ARB_IDLE_BIF2_BITFIELD         = 1'h1;
localparam logic [ 27 : 27 ] GC_CR_SPC_BIF_PFS1_ARB_IDLE_BIF3_BITFIELD         = 1'h1;
localparam logic [ 28 : 28 ] GC_CR_SPC_BIF_PFS1_TILING_IDLE_BIF0_BITFIELD      = 1'h1;
localparam logic [ 29 : 29 ] GC_CR_SPC_BIF_PFS1_TILING_IDLE_BIF1_BITFIELD      = 1'h1;
localparam logic [ 30 : 30 ] GC_CR_SPC_BIF_PFS1_TILING_IDLE_BIF2_BITFIELD      = 1'h1;
localparam logic [ 31 : 31 ] GC_CR_SPC_BIF_PFS1_TILING_IDLE_BIF3_BITFIELD      = 1'h1;
localparam logic [ 32 : 32 ] GC_CR_SPC_BIF_PFS1_L2G_STALLING_BIF0_BITFIELD     = 1'h0;
localparam logic [ 33 : 33 ] GC_CR_SPC_BIF_PFS1_L2G_STALLING_BIF1_BITFIELD     = 1'h0;
localparam logic [ 34 : 34 ] GC_CR_SPC_BIF_PFS1_L2G_STALLING_BIF2_BITFIELD     = 1'h0;
localparam logic [ 35 : 35 ] GC_CR_SPC_BIF_PFS1_L2G_STALLING_BIF3_BITFIELD     = 1'h0;

 // gc_cr_bif_pfs_wdata_completion_enable0
localparam logic [ 0 : 0 ] GC_CR_BIF_PFS_WDATA_COMPLETION_ENABLE0_BIF0_BITFIELD  = 1'h1;
localparam logic [ 1 : 1 ] GC_CR_BIF_PFS_WDATA_COMPLETION_ENABLE0_BIF1_BITFIELD  = 1'h1;
localparam logic [ 2 : 2 ] GC_CR_BIF_PFS_WDATA_COMPLETION_ENABLE0_BIF2_BITFIELD  = 1'h1;
localparam logic [ 3 : 3 ] GC_CR_BIF_PFS_WDATA_COMPLETION_ENABLE0_BIF3_BITFIELD  = 1'h1;

 // gc_cr_bif_pfs_wdata_completion_enable1
localparam logic [ 0 : 0 ] GC_CR_BIF_PFS_WDATA_COMPLETION_ENABLE1_BIF0_BITFIELD  = 1'h1;
localparam logic [ 1 : 1 ] GC_CR_BIF_PFS_WDATA_COMPLETION_ENABLE1_BIF1_BITFIELD  = 1'h1;
localparam logic [ 2 : 2 ] GC_CR_BIF_PFS_WDATA_COMPLETION_ENABLE1_BIF2_BITFIELD  = 1'h1;
localparam logic [ 3 : 3 ] GC_CR_BIF_PFS_WDATA_COMPLETION_ENABLE1_BIF3_BITFIELD  = 1'h1;

 // gc_cr_l0c_oob_fail_status0
localparam logic [ 0 : 0 ] GC_CR_L0C_OOB_FAIL_STATUS0_CPC0_BITFIELD            = 1'h0;
localparam logic [ 1 : 1 ] GC_CR_L0C_OOB_FAIL_STATUS0_CPC1_BITFIELD            = 1'h0;
localparam logic [ 2 : 2 ] GC_CR_L0C_OOB_FAIL_STATUS0_CPC2_BITFIELD            = 1'h0;
localparam logic [ 3 : 3 ] GC_CR_L0C_OOB_FAIL_STATUS0_CPC3_BITFIELD            = 1'h0;

 // gc_cr_l0c_oob_fail_status1
localparam logic [ 0 : 0 ] GC_CR_L0C_OOB_FAIL_STATUS1_CPC0_BITFIELD            = 1'h0;
localparam logic [ 1 : 1 ] GC_CR_L0C_OOB_FAIL_STATUS1_CPC1_BITFIELD            = 1'h0;
localparam logic [ 2 : 2 ] GC_CR_L0C_OOB_FAIL_STATUS1_CPC2_BITFIELD            = 1'h0;
localparam logic [ 3 : 3 ] GC_CR_L0C_OOB_FAIL_STATUS1_CPC3_BITFIELD            = 1'h0;

 // gc_cr_l0c_oob_fail_clear0
localparam logic [ 0 : 0 ] GC_CR_L0C_OOB_FAIL_CLEAR0_CPC0_BITFIELD             = 1'h0;
localparam logic [ 1 : 1 ] GC_CR_L0C_OOB_FAIL_CLEAR0_CPC1_BITFIELD             = 1'h0;
localparam logic [ 2 : 2 ] GC_CR_L0C_OOB_FAIL_CLEAR0_CPC2_BITFIELD             = 1'h0;
localparam logic [ 3 : 3 ] GC_CR_L0C_OOB_FAIL_CLEAR0_CPC3_BITFIELD             = 1'h0;

 // gc_cr_l0c_oob_fail_clear1
localparam logic [ 0 : 0 ] GC_CR_L0C_OOB_FAIL_CLEAR1_CPC0_BITFIELD             = 1'h0;
localparam logic [ 1 : 1 ] GC_CR_L0C_OOB_FAIL_CLEAR1_CPC1_BITFIELD             = 1'h0;
localparam logic [ 2 : 2 ] GC_CR_L0C_OOB_FAIL_CLEAR1_CPC2_BITFIELD             = 1'h0;
localparam logic [ 3 : 3 ] GC_CR_L0C_OOB_FAIL_CLEAR1_CPC3_BITFIELD             = 1'h0;

 // gc_cr_l0c_tma_error0
localparam logic [ 0 : 0 ] GC_CR_L0C_TMA_ERROR0_TID_MCM_NOTMATCH_BITFIELD      = 1'h0;
localparam logic [ 1 : 1 ] GC_CR_L0C_TMA_ERROR0_MCAST_TAG_ALL_USED_BITFIELD    = 1'h0;
localparam logic [ 2 : 2 ] GC_CR_L0C_TMA_ERROR0_DOUBLE_ARRIVE_BITFIELD         = 1'h0;

 // gc_cr_l0c_tma_error1
localparam logic [ 0 : 0 ] GC_CR_L0C_TMA_ERROR1_TID_MCM_NOTMATCH_BITFIELD      = 1'h0;
localparam logic [ 1 : 1 ] GC_CR_L0C_TMA_ERROR1_MCAST_TAG_ALL_USED_BITFIELD    = 1'h0;
localparam logic [ 2 : 2 ] GC_CR_L0C_TMA_ERROR1_DOUBLE_ARRIVE_BITFIELD         = 1'h0;

 // gc_cr_l0c_ctrl0
localparam logic [ 0 : 0 ] GC_CR_L0C_CTRL0_REQ_ARBITER_POLICY_BITFIELD         = 1'h0;
localparam logic [ 1 : 1 ] GC_CR_L0C_CTRL0_HALF_BANDWIDTH_ENABLE_BITFIELD      = 1'h0;

 // gc_cr_l0c_ctrl1
localparam logic [ 0 : 0 ] GC_CR_L0C_CTRL1_REQ_ARBITER_POLICY_BITFIELD         = 1'h0;
localparam logic [ 1 : 1 ] GC_CR_L0C_CTRL1_HALF_BANDWIDTH_ENABLE_BITFIELD      = 1'h0;

 // gc_cr_task_feedback
localparam logic [ 0 : 0 ] GC_CR_TASK_FEEDBACK_ENABLE_BITFIELD                 = 1'h1;
localparam logic [ 6 : 1 ] GC_CR_TASK_FEEDBACK_THRESHOLD_BITFIELD              = 6'ha;

 // gc_cr_multicore_ctrl_gpu_offset_compute0
localparam logic [ 2 : 0 ] GC_CR_MULTICORE_CTRL_GPU_OFFSET_COMPUTE0_COMPUTE0_BITFIELD  = 3'h0;

 // gc_cr_multicore_ctrl_gpu_offset_compute1
localparam logic [ 2 : 0 ] GC_CR_MULTICORE_CTRL_GPU_OFFSET_COMPUTE1_COMPUTE1_BITFIELD  = 3'h0;

 // gc_cr_multicore_ctrl_gpu_offset_compute2
localparam logic [ 2 : 0 ] GC_CR_MULTICORE_CTRL_GPU_OFFSET_COMPUTE2_COMPUTE2_BITFIELD  = 3'h0;

 // gc_cr_multicore_ctrl_gpu_offset_compute3
localparam logic [ 2 : 0 ] GC_CR_MULTICORE_CTRL_GPU_OFFSET_COMPUTE3_COMPUTE3_BITFIELD  = 3'h0;

 // gc_cr_smp_cmp_cfg_state_global_base_cmp0_msb
localparam logic [ 11 : 0 ] GC_CR_SMP_CMP_CFG_STATE_GLOBAL_BASE_CMP0_MSB_CMP0_MSB_BITFIELD  = 12'h0;

 // gc_cr_smp_cmp_cfg_state_global_base_cmp1_msb
localparam logic [ 11 : 0 ] GC_CR_SMP_CMP_CFG_STATE_GLOBAL_BASE_CMP1_MSB_CMP1_MSB_BITFIELD  = 12'h0;

 // gc_cr_smp_cmp_cfg_state_global_base_cmp2_msb
localparam logic [ 11 : 0 ] GC_CR_SMP_CMP_CFG_STATE_GLOBAL_BASE_CMP2_MSB_CMP2_MSB_BITFIELD  = 12'h0;

 // gc_cr_smp_cmp_cfg_state_global_base_cmp3_msb
localparam logic [ 11 : 0 ] GC_CR_SMP_CMP_CFG_STATE_GLOBAL_BASE_CMP3_MSB_CMP3_MSB_BITFIELD  = 12'h0;

 // gc_cr_cu_lms_fp32_denormal_en
localparam logic [ 0 : 0 ] GC_CR_CU_LMS_FP32_DENORMAL_EN_EN_BITFIELD           = 1'h0;

 // gc_cr_cu_serv_compute0
localparam logic [ 16 : 0 ] GC_CR_CU_SERV_COMPUTE0_COMPUTE0_BITFIELD           = 17'h10000;

 // gc_cr_cu_serv_compute1
localparam logic [ 16 : 0 ] GC_CR_CU_SERV_COMPUTE1_COMPUTE1_BITFIELD           = 17'h10000;

 // gc_cr_cu_serv_compute2
localparam logic [ 16 : 0 ] GC_CR_CU_SERV_COMPUTE2_COMPUTE2_BITFIELD           = 17'h10000;

 // gc_cr_cu_serv_compute3
localparam logic [ 16 : 0 ] GC_CR_CU_SERV_COMPUTE3_COMPUTE3_BITFIELD           = 17'h10000;

 // gc_cr_perf_mon0
localparam logic [ 0 : 0 ] GC_CR_PERF_MON0_NORMAL_MODE_START_BITFIELD          = 1'h0;
localparam logic [ 2 : 1 ] GC_CR_PERF_MON0_DUMP_TRIGGER_BITFIELD               = 2'h0;

 // gc_cr_perf_mon1
localparam logic [ 0 : 0 ] GC_CR_PERF_MON1_ENABLE_BITFIELD                     = 1'h0;
localparam logic [ 1 : 1 ] GC_CR_PERF_MON1_TIME_STAMP_ENABLE_BITFIELD          = 1'h0;
localparam logic [ 17 : 2 ] GC_CR_PERF_MON1_TIME_SLOT_BITFIELD                 = 16'h0;
localparam logic [ 23 : 18 ] GC_CR_PERF_MON1_FENCE_INTERVAL_BITFIELD           = 6'h0;

 // gc_cr_perf_mon2
localparam logic [ 41 : 0 ] GC_CR_PERF_MON2_BASE_ADDR_BITFIELD                 = 42'h0;

 // gc_cr_perf_mon3
localparam logic [ 1 : 0 ] GC_CR_PERF_MON3_PERSISTENCE_BITFIELD                = 2'h0;
localparam logic [ 7 : 2 ] GC_CR_PERF_MON3_CTXT_PASID_BITFIELD                 = 6'h0;
localparam logic [ 9 : 8 ] GC_CR_PERF_MON3_L1_POLICY_BITFIELD                  = 2'h0;
localparam logic [ 10 : 10 ] GC_CR_PERF_MON3_L2_POLICY_BITFIELD                = 1'h0;
localparam logic [ 11 : 11 ] GC_CR_PERF_MON3_L2_PREFETCH_SIZE_BITFIELD         = 1'h0;
localparam logic [ 43 : 12 ] GC_CR_PERF_MON3_SPACE_SIZE_BITFIELD               = 32'h0;

 // gc_cr_perf_mon4
localparam logic [ 4 : 0 ] GC_CR_PERF_MON4_CU_GROUP_ID_BITFIELD                = 5'h0;
localparam logic [ 9 : 5 ] GC_CR_PERF_MON4_SPC_GROUP_ID_BITFIELD               = 5'h0;
localparam logic [ 14 : 10 ] GC_CR_PERF_MON4_GPC_GROUP_ID_BITFIELD             = 5'h0;
localparam logic [ 19 : 15 ] GC_CR_PERF_MON4_L2G_GROUP_ID_BITFIELD             = 5'h0;
localparam logic [ 24 : 20 ] GC_CR_PERF_MON4_CP_GROUP_ID_BITFIELD              = 5'h0;
localparam logic [ 29 : 25 ] GC_CR_PERF_MON4_CE_GROUP_ID_BITFIELD              = 5'h0;

 // gc_cr_perf_mon_int_status0
localparam logic [ 53 : 0 ] GC_CR_PERF_MON_INT_STATUS0_DONE_STATUS_BITFIELD    = 54'h0;
localparam logic [ 54 : 54 ] GC_CR_PERF_MON_INT_STATUS0_OVERALL_ALL_DONE_STATUS_BITFIELD  = 1'h0;

 // gc_cr_perf_mon_int_status1
localparam logic [ 53 : 0 ] GC_CR_PERF_MON_INT_STATUS1_FAIL_STATUS_BITFIELD    = 54'h0;

 // gc_cr_perf_mon_int_status2
localparam logic [ 53 : 0 ] GC_CR_PERF_MON_INT_STATUS2_OVF_STATUS_BITFIELD     = 54'h0;

 // gc_cr_cu_watchdog_reset
localparam logic [ 0 : 0 ] GC_CR_CU_WATCHDOG_RESET_CMP0_DM_BITFIELD            = 1'h0;
localparam logic [ 1 : 1 ] GC_CR_CU_WATCHDOG_RESET_CMP1_DM_BITFIELD            = 1'h0;
localparam logic [ 2 : 2 ] GC_CR_CU_WATCHDOG_RESET_CMP2_DM_BITFIELD            = 1'h0;
localparam logic [ 3 : 3 ] GC_CR_CU_WATCHDOG_RESET_CMP3_DM_BITFIELD            = 1'h0;

 // gc_cr_cu_watchdog_enable
localparam logic [ 0 : 0 ] GC_CR_CU_WATCHDOG_ENABLE_CMP0_DM_BITFIELD           = 1'h0;
localparam logic [ 1 : 1 ] GC_CR_CU_WATCHDOG_ENABLE_CMP1_DM_BITFIELD           = 1'h0;
localparam logic [ 2 : 2 ] GC_CR_CU_WATCHDOG_ENABLE_CMP2_DM_BITFIELD           = 1'h0;
localparam logic [ 3 : 3 ] GC_CR_CU_WATCHDOG_ENABLE_CMP3_DM_BITFIELD           = 1'h0;

 // gc_cr_cu_slot0
localparam logic [ 30 : 1 ] GC_CR_CU_SLOT0_PC_BITFIELD                         = 30'h0;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT0_STATUS_BITFIELD                    = 5'h0;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT0_STATUS_EMPTY_COMPLETED             = 5'h0;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT0_STATUS_WAIT_ACTIVE                 = 5'h1;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT0_STATUS_ACTIVE_READY                = 5'h2;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT0_STATUS_ACTIVE_RUNNING              = 5'h3;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT0_STATUS_WAIT_MUTEX_LOCK             = 5'h4;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT0_STATUS_WAIT_CACHE_HIT              = 5'h5;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT0_STATUS_WAIT_CACHE_DOUBLE_HIT       = 5'h6;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT0_STATUS_WAIT_OB_FREED               = 5'h7;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT0_STATUS_WAIT_OB_ACTIVE              = 5'h8;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT0_STATUS_WAIT_BARRIER_WAKEUP         = 5'h9;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT0_STATUS_WAIT_PASS_GROUP             = 5'ha;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT0_STATUS_WAIT_PIPELINE_NOT_FULL      = 5'hb;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT0_STATUS_WAIT_DEU_NOT_FULL           = 5'hc;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT0_STATUS_WAIT_PIP_OLDEST             = 5'hd;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT0_STATUS_WAIT_FC_ZERO                = 5'he;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT0_STATUS_WAIT_WFC_ZERO               = 5'hf;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT0_STATUS_WAIT_NOT_FC_MAX             = 5'h10;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT0_STATUS_WAIT_NOT_WFC_MAX            = 5'h11;

 // gc_cr_cu_slot1
localparam logic [ 30 : 1 ] GC_CR_CU_SLOT1_PC_BITFIELD                         = 30'h0;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT1_STATUS_BITFIELD                    = 5'h0;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT1_STATUS_EMPTY_COMPLETED             = 5'h0;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT1_STATUS_WAIT_ACTIVE                 = 5'h1;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT1_STATUS_ACTIVE_READY                = 5'h2;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT1_STATUS_ACTIVE_RUNNING              = 5'h3;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT1_STATUS_WAIT_MUTEX_LOCK             = 5'h4;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT1_STATUS_WAIT_CACHE_HIT              = 5'h5;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT1_STATUS_WAIT_CACHE_DOUBLE_HIT       = 5'h6;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT1_STATUS_WAIT_OB_FREED               = 5'h7;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT1_STATUS_WAIT_OB_ACTIVE              = 5'h8;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT1_STATUS_WAIT_BARRIER_WAKEUP         = 5'h9;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT1_STATUS_WAIT_PASS_GROUP             = 5'ha;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT1_STATUS_WAIT_PIPELINE_NOT_FULL      = 5'hb;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT1_STATUS_WAIT_DEU_NOT_FULL           = 5'hc;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT1_STATUS_WAIT_PIP_OLDEST             = 5'hd;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT1_STATUS_WAIT_FC_ZERO                = 5'he;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT1_STATUS_WAIT_WFC_ZERO               = 5'hf;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT1_STATUS_WAIT_NOT_FC_MAX             = 5'h10;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT1_STATUS_WAIT_NOT_WFC_MAX            = 5'h11;

 // gc_cr_cu_slot2
localparam logic [ 30 : 1 ] GC_CR_CU_SLOT2_PC_BITFIELD                         = 30'h0;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT2_STATUS_BITFIELD                    = 5'h0;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT2_STATUS_EMPTY_COMPLETED             = 5'h0;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT2_STATUS_WAIT_ACTIVE                 = 5'h1;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT2_STATUS_ACTIVE_READY                = 5'h2;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT2_STATUS_ACTIVE_RUNNING              = 5'h3;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT2_STATUS_WAIT_MUTEX_LOCK             = 5'h4;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT2_STATUS_WAIT_CACHE_HIT              = 5'h5;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT2_STATUS_WAIT_CACHE_DOUBLE_HIT       = 5'h6;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT2_STATUS_WAIT_OB_FREED               = 5'h7;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT2_STATUS_WAIT_OB_ACTIVE              = 5'h8;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT2_STATUS_WAIT_BARRIER_WAKEUP         = 5'h9;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT2_STATUS_WAIT_PASS_GROUP             = 5'ha;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT2_STATUS_WAIT_PIPELINE_NOT_FULL      = 5'hb;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT2_STATUS_WAIT_DEU_NOT_FULL           = 5'hc;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT2_STATUS_WAIT_PIP_OLDEST             = 5'hd;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT2_STATUS_WAIT_FC_ZERO                = 5'he;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT2_STATUS_WAIT_WFC_ZERO               = 5'hf;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT2_STATUS_WAIT_NOT_FC_MAX             = 5'h10;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT2_STATUS_WAIT_NOT_WFC_MAX            = 5'h11;

 // gc_cr_cu_slot3
localparam logic [ 30 : 1 ] GC_CR_CU_SLOT3_PC_BITFIELD                         = 30'h0;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT3_STATUS_BITFIELD                    = 5'h0;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT3_STATUS_EMPTY_COMPLETED             = 5'h0;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT3_STATUS_WAIT_ACTIVE                 = 5'h1;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT3_STATUS_ACTIVE_READY                = 5'h2;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT3_STATUS_ACTIVE_RUNNING              = 5'h3;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT3_STATUS_WAIT_MUTEX_LOCK             = 5'h4;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT3_STATUS_WAIT_CACHE_HIT              = 5'h5;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT3_STATUS_WAIT_CACHE_DOUBLE_HIT       = 5'h6;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT3_STATUS_WAIT_OB_FREED               = 5'h7;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT3_STATUS_WAIT_OB_ACTIVE              = 5'h8;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT3_STATUS_WAIT_BARRIER_WAKEUP         = 5'h9;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT3_STATUS_WAIT_PASS_GROUP             = 5'ha;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT3_STATUS_WAIT_PIPELINE_NOT_FULL      = 5'hb;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT3_STATUS_WAIT_DEU_NOT_FULL           = 5'hc;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT3_STATUS_WAIT_PIP_OLDEST             = 5'hd;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT3_STATUS_WAIT_FC_ZERO                = 5'he;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT3_STATUS_WAIT_WFC_ZERO               = 5'hf;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT3_STATUS_WAIT_NOT_FC_MAX             = 5'h10;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT3_STATUS_WAIT_NOT_WFC_MAX            = 5'h11;

 // gc_cr_cu_slot4
localparam logic [ 30 : 1 ] GC_CR_CU_SLOT4_PC_BITFIELD                         = 30'h0;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT4_STATUS_BITFIELD                    = 5'h0;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT4_STATUS_EMPTY_COMPLETED             = 5'h0;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT4_STATUS_WAIT_ACTIVE                 = 5'h1;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT4_STATUS_ACTIVE_READY                = 5'h2;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT4_STATUS_ACTIVE_RUNNING              = 5'h3;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT4_STATUS_WAIT_MUTEX_LOCK             = 5'h4;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT4_STATUS_WAIT_CACHE_HIT              = 5'h5;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT4_STATUS_WAIT_CACHE_DOUBLE_HIT       = 5'h6;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT4_STATUS_WAIT_OB_FREED               = 5'h7;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT4_STATUS_WAIT_OB_ACTIVE              = 5'h8;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT4_STATUS_WAIT_BARRIER_WAKEUP         = 5'h9;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT4_STATUS_WAIT_PASS_GROUP             = 5'ha;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT4_STATUS_WAIT_PIPELINE_NOT_FULL      = 5'hb;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT4_STATUS_WAIT_DEU_NOT_FULL           = 5'hc;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT4_STATUS_WAIT_PIP_OLDEST             = 5'hd;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT4_STATUS_WAIT_FC_ZERO                = 5'he;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT4_STATUS_WAIT_WFC_ZERO               = 5'hf;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT4_STATUS_WAIT_NOT_FC_MAX             = 5'h10;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT4_STATUS_WAIT_NOT_WFC_MAX            = 5'h11;

 // gc_cr_cu_slot5
localparam logic [ 30 : 1 ] GC_CR_CU_SLOT5_PC_BITFIELD                         = 30'h0;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT5_STATUS_BITFIELD                    = 5'h0;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT5_STATUS_EMPTY_COMPLETED             = 5'h0;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT5_STATUS_WAIT_ACTIVE                 = 5'h1;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT5_STATUS_ACTIVE_READY                = 5'h2;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT5_STATUS_ACTIVE_RUNNING              = 5'h3;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT5_STATUS_WAIT_MUTEX_LOCK             = 5'h4;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT5_STATUS_WAIT_CACHE_HIT              = 5'h5;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT5_STATUS_WAIT_CACHE_DOUBLE_HIT       = 5'h6;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT5_STATUS_WAIT_OB_FREED               = 5'h7;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT5_STATUS_WAIT_OB_ACTIVE              = 5'h8;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT5_STATUS_WAIT_BARRIER_WAKEUP         = 5'h9;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT5_STATUS_WAIT_PASS_GROUP             = 5'ha;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT5_STATUS_WAIT_PIPELINE_NOT_FULL      = 5'hb;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT5_STATUS_WAIT_DEU_NOT_FULL           = 5'hc;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT5_STATUS_WAIT_PIP_OLDEST             = 5'hd;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT5_STATUS_WAIT_FC_ZERO                = 5'he;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT5_STATUS_WAIT_WFC_ZERO               = 5'hf;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT5_STATUS_WAIT_NOT_FC_MAX             = 5'h10;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT5_STATUS_WAIT_NOT_WFC_MAX            = 5'h11;

 // gc_cr_cu_slot6
localparam logic [ 30 : 1 ] GC_CR_CU_SLOT6_PC_BITFIELD                         = 30'h0;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT6_STATUS_BITFIELD                    = 5'h0;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT6_STATUS_EMPTY_COMPLETED             = 5'h0;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT6_STATUS_WAIT_ACTIVE                 = 5'h1;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT6_STATUS_ACTIVE_READY                = 5'h2;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT6_STATUS_ACTIVE_RUNNING              = 5'h3;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT6_STATUS_WAIT_MUTEX_LOCK             = 5'h4;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT6_STATUS_WAIT_CACHE_HIT              = 5'h5;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT6_STATUS_WAIT_CACHE_DOUBLE_HIT       = 5'h6;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT6_STATUS_WAIT_OB_FREED               = 5'h7;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT6_STATUS_WAIT_OB_ACTIVE              = 5'h8;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT6_STATUS_WAIT_BARRIER_WAKEUP         = 5'h9;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT6_STATUS_WAIT_PASS_GROUP             = 5'ha;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT6_STATUS_WAIT_PIPELINE_NOT_FULL      = 5'hb;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT6_STATUS_WAIT_DEU_NOT_FULL           = 5'hc;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT6_STATUS_WAIT_PIP_OLDEST             = 5'hd;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT6_STATUS_WAIT_FC_ZERO                = 5'he;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT6_STATUS_WAIT_WFC_ZERO               = 5'hf;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT6_STATUS_WAIT_NOT_FC_MAX             = 5'h10;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT6_STATUS_WAIT_NOT_WFC_MAX            = 5'h11;

 // gc_cr_cu_slot7
localparam logic [ 30 : 1 ] GC_CR_CU_SLOT7_PC_BITFIELD                         = 30'h0;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT7_STATUS_BITFIELD                    = 5'h0;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT7_STATUS_EMPTY_COMPLETED             = 5'h0;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT7_STATUS_WAIT_ACTIVE                 = 5'h1;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT7_STATUS_ACTIVE_READY                = 5'h2;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT7_STATUS_ACTIVE_RUNNING              = 5'h3;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT7_STATUS_WAIT_MUTEX_LOCK             = 5'h4;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT7_STATUS_WAIT_CACHE_HIT              = 5'h5;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT7_STATUS_WAIT_CACHE_DOUBLE_HIT       = 5'h6;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT7_STATUS_WAIT_OB_FREED               = 5'h7;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT7_STATUS_WAIT_OB_ACTIVE              = 5'h8;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT7_STATUS_WAIT_BARRIER_WAKEUP         = 5'h9;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT7_STATUS_WAIT_PASS_GROUP             = 5'ha;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT7_STATUS_WAIT_PIPELINE_NOT_FULL      = 5'hb;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT7_STATUS_WAIT_DEU_NOT_FULL           = 5'hc;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT7_STATUS_WAIT_PIP_OLDEST             = 5'hd;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT7_STATUS_WAIT_FC_ZERO                = 5'he;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT7_STATUS_WAIT_WFC_ZERO               = 5'hf;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT7_STATUS_WAIT_NOT_FC_MAX             = 5'h10;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT7_STATUS_WAIT_NOT_WFC_MAX            = 5'h11;

 // gc_cr_cu_slot8
localparam logic [ 30 : 1 ] GC_CR_CU_SLOT8_PC_BITFIELD                         = 30'h0;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT8_STATUS_BITFIELD                    = 5'h0;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT8_STATUS_EMPTY_COMPLETED             = 5'h0;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT8_STATUS_WAIT_ACTIVE                 = 5'h1;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT8_STATUS_ACTIVE_READY                = 5'h2;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT8_STATUS_ACTIVE_RUNNING              = 5'h3;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT8_STATUS_WAIT_MUTEX_LOCK             = 5'h4;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT8_STATUS_WAIT_CACHE_HIT              = 5'h5;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT8_STATUS_WAIT_CACHE_DOUBLE_HIT       = 5'h6;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT8_STATUS_WAIT_OB_FREED               = 5'h7;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT8_STATUS_WAIT_OB_ACTIVE              = 5'h8;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT8_STATUS_WAIT_BARRIER_WAKEUP         = 5'h9;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT8_STATUS_WAIT_PASS_GROUP             = 5'ha;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT8_STATUS_WAIT_PIPELINE_NOT_FULL      = 5'hb;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT8_STATUS_WAIT_DEU_NOT_FULL           = 5'hc;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT8_STATUS_WAIT_PIP_OLDEST             = 5'hd;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT8_STATUS_WAIT_FC_ZERO                = 5'he;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT8_STATUS_WAIT_WFC_ZERO               = 5'hf;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT8_STATUS_WAIT_NOT_FC_MAX             = 5'h10;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT8_STATUS_WAIT_NOT_WFC_MAX            = 5'h11;

 // gc_cr_cu_slot9
localparam logic [ 30 : 1 ] GC_CR_CU_SLOT9_PC_BITFIELD                         = 30'h0;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT9_STATUS_BITFIELD                    = 5'h0;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT9_STATUS_EMPTY_COMPLETED             = 5'h0;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT9_STATUS_WAIT_ACTIVE                 = 5'h1;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT9_STATUS_ACTIVE_READY                = 5'h2;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT9_STATUS_ACTIVE_RUNNING              = 5'h3;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT9_STATUS_WAIT_MUTEX_LOCK             = 5'h4;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT9_STATUS_WAIT_CACHE_HIT              = 5'h5;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT9_STATUS_WAIT_CACHE_DOUBLE_HIT       = 5'h6;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT9_STATUS_WAIT_OB_FREED               = 5'h7;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT9_STATUS_WAIT_OB_ACTIVE              = 5'h8;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT9_STATUS_WAIT_BARRIER_WAKEUP         = 5'h9;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT9_STATUS_WAIT_PASS_GROUP             = 5'ha;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT9_STATUS_WAIT_PIPELINE_NOT_FULL      = 5'hb;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT9_STATUS_WAIT_DEU_NOT_FULL           = 5'hc;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT9_STATUS_WAIT_PIP_OLDEST             = 5'hd;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT9_STATUS_WAIT_FC_ZERO                = 5'he;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT9_STATUS_WAIT_WFC_ZERO               = 5'hf;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT9_STATUS_WAIT_NOT_FC_MAX             = 5'h10;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT9_STATUS_WAIT_NOT_WFC_MAX            = 5'h11;

 // gc_cr_cu_slot10
localparam logic [ 30 : 1 ] GC_CR_CU_SLOT10_PC_BITFIELD                        = 30'h0;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT10_STATUS_BITFIELD                   = 5'h0;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT10_STATUS_EMPTY_COMPLETED            = 5'h0;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT10_STATUS_WAIT_ACTIVE                = 5'h1;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT10_STATUS_ACTIVE_READY               = 5'h2;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT10_STATUS_ACTIVE_RUNNING             = 5'h3;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT10_STATUS_WAIT_MUTEX_LOCK            = 5'h4;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT10_STATUS_WAIT_CACHE_HIT             = 5'h5;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT10_STATUS_WAIT_CACHE_DOUBLE_HIT      = 5'h6;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT10_STATUS_WAIT_OB_FREED              = 5'h7;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT10_STATUS_WAIT_OB_ACTIVE             = 5'h8;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT10_STATUS_WAIT_BARRIER_WAKEUP        = 5'h9;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT10_STATUS_WAIT_PASS_GROUP            = 5'ha;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT10_STATUS_WAIT_PIPELINE_NOT_FULL     = 5'hb;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT10_STATUS_WAIT_DEU_NOT_FULL          = 5'hc;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT10_STATUS_WAIT_PIP_OLDEST            = 5'hd;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT10_STATUS_WAIT_FC_ZERO               = 5'he;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT10_STATUS_WAIT_WFC_ZERO              = 5'hf;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT10_STATUS_WAIT_NOT_FC_MAX            = 5'h10;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT10_STATUS_WAIT_NOT_WFC_MAX           = 5'h11;

 // gc_cr_cu_slot11
localparam logic [ 30 : 1 ] GC_CR_CU_SLOT11_PC_BITFIELD                        = 30'h0;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT11_STATUS_BITFIELD                   = 5'h0;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT11_STATUS_EMPTY_COMPLETED            = 5'h0;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT11_STATUS_WAIT_ACTIVE                = 5'h1;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT11_STATUS_ACTIVE_READY               = 5'h2;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT11_STATUS_ACTIVE_RUNNING             = 5'h3;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT11_STATUS_WAIT_MUTEX_LOCK            = 5'h4;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT11_STATUS_WAIT_CACHE_HIT             = 5'h5;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT11_STATUS_WAIT_CACHE_DOUBLE_HIT      = 5'h6;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT11_STATUS_WAIT_OB_FREED              = 5'h7;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT11_STATUS_WAIT_OB_ACTIVE             = 5'h8;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT11_STATUS_WAIT_BARRIER_WAKEUP        = 5'h9;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT11_STATUS_WAIT_PASS_GROUP            = 5'ha;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT11_STATUS_WAIT_PIPELINE_NOT_FULL     = 5'hb;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT11_STATUS_WAIT_DEU_NOT_FULL          = 5'hc;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT11_STATUS_WAIT_PIP_OLDEST            = 5'hd;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT11_STATUS_WAIT_FC_ZERO               = 5'he;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT11_STATUS_WAIT_WFC_ZERO              = 5'hf;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT11_STATUS_WAIT_NOT_FC_MAX            = 5'h10;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT11_STATUS_WAIT_NOT_WFC_MAX           = 5'h11;

 // gc_cr_cu_slot12
localparam logic [ 30 : 1 ] GC_CR_CU_SLOT12_PC_BITFIELD                        = 30'h0;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT12_STATUS_BITFIELD                   = 5'h0;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT12_STATUS_EMPTY_COMPLETED            = 5'h0;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT12_STATUS_WAIT_ACTIVE                = 5'h1;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT12_STATUS_ACTIVE_READY               = 5'h2;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT12_STATUS_ACTIVE_RUNNING             = 5'h3;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT12_STATUS_WAIT_MUTEX_LOCK            = 5'h4;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT12_STATUS_WAIT_CACHE_HIT             = 5'h5;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT12_STATUS_WAIT_CACHE_DOUBLE_HIT      = 5'h6;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT12_STATUS_WAIT_OB_FREED              = 5'h7;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT12_STATUS_WAIT_OB_ACTIVE             = 5'h8;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT12_STATUS_WAIT_BARRIER_WAKEUP        = 5'h9;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT12_STATUS_WAIT_PASS_GROUP            = 5'ha;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT12_STATUS_WAIT_PIPELINE_NOT_FULL     = 5'hb;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT12_STATUS_WAIT_DEU_NOT_FULL          = 5'hc;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT12_STATUS_WAIT_PIP_OLDEST            = 5'hd;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT12_STATUS_WAIT_FC_ZERO               = 5'he;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT12_STATUS_WAIT_WFC_ZERO              = 5'hf;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT12_STATUS_WAIT_NOT_FC_MAX            = 5'h10;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT12_STATUS_WAIT_NOT_WFC_MAX           = 5'h11;

 // gc_cr_cu_slot13
localparam logic [ 30 : 1 ] GC_CR_CU_SLOT13_PC_BITFIELD                        = 30'h0;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT13_STATUS_BITFIELD                   = 5'h0;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT13_STATUS_EMPTY_COMPLETED            = 5'h0;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT13_STATUS_WAIT_ACTIVE                = 5'h1;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT13_STATUS_ACTIVE_READY               = 5'h2;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT13_STATUS_ACTIVE_RUNNING             = 5'h3;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT13_STATUS_WAIT_MUTEX_LOCK            = 5'h4;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT13_STATUS_WAIT_CACHE_HIT             = 5'h5;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT13_STATUS_WAIT_CACHE_DOUBLE_HIT      = 5'h6;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT13_STATUS_WAIT_OB_FREED              = 5'h7;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT13_STATUS_WAIT_OB_ACTIVE             = 5'h8;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT13_STATUS_WAIT_BARRIER_WAKEUP        = 5'h9;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT13_STATUS_WAIT_PASS_GROUP            = 5'ha;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT13_STATUS_WAIT_PIPELINE_NOT_FULL     = 5'hb;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT13_STATUS_WAIT_DEU_NOT_FULL          = 5'hc;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT13_STATUS_WAIT_PIP_OLDEST            = 5'hd;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT13_STATUS_WAIT_FC_ZERO               = 5'he;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT13_STATUS_WAIT_WFC_ZERO              = 5'hf;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT13_STATUS_WAIT_NOT_FC_MAX            = 5'h10;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT13_STATUS_WAIT_NOT_WFC_MAX           = 5'h11;

 // gc_cr_cu_slot14
localparam logic [ 30 : 1 ] GC_CR_CU_SLOT14_PC_BITFIELD                        = 30'h0;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT14_STATUS_BITFIELD                   = 5'h0;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT14_STATUS_EMPTY_COMPLETED            = 5'h0;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT14_STATUS_WAIT_ACTIVE                = 5'h1;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT14_STATUS_ACTIVE_READY               = 5'h2;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT14_STATUS_ACTIVE_RUNNING             = 5'h3;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT14_STATUS_WAIT_MUTEX_LOCK            = 5'h4;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT14_STATUS_WAIT_CACHE_HIT             = 5'h5;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT14_STATUS_WAIT_CACHE_DOUBLE_HIT      = 5'h6;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT14_STATUS_WAIT_OB_FREED              = 5'h7;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT14_STATUS_WAIT_OB_ACTIVE             = 5'h8;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT14_STATUS_WAIT_BARRIER_WAKEUP        = 5'h9;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT14_STATUS_WAIT_PASS_GROUP            = 5'ha;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT14_STATUS_WAIT_PIPELINE_NOT_FULL     = 5'hb;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT14_STATUS_WAIT_DEU_NOT_FULL          = 5'hc;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT14_STATUS_WAIT_PIP_OLDEST            = 5'hd;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT14_STATUS_WAIT_FC_ZERO               = 5'he;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT14_STATUS_WAIT_WFC_ZERO              = 5'hf;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT14_STATUS_WAIT_NOT_FC_MAX            = 5'h10;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT14_STATUS_WAIT_NOT_WFC_MAX           = 5'h11;

 // gc_cr_cu_slot15
localparam logic [ 30 : 1 ] GC_CR_CU_SLOT15_PC_BITFIELD                        = 30'h0;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT15_STATUS_BITFIELD                   = 5'h0;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT15_STATUS_EMPTY_COMPLETED            = 5'h0;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT15_STATUS_WAIT_ACTIVE                = 5'h1;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT15_STATUS_ACTIVE_READY               = 5'h2;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT15_STATUS_ACTIVE_RUNNING             = 5'h3;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT15_STATUS_WAIT_MUTEX_LOCK            = 5'h4;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT15_STATUS_WAIT_CACHE_HIT             = 5'h5;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT15_STATUS_WAIT_CACHE_DOUBLE_HIT      = 5'h6;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT15_STATUS_WAIT_OB_FREED              = 5'h7;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT15_STATUS_WAIT_OB_ACTIVE             = 5'h8;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT15_STATUS_WAIT_BARRIER_WAKEUP        = 5'h9;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT15_STATUS_WAIT_PASS_GROUP            = 5'ha;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT15_STATUS_WAIT_PIPELINE_NOT_FULL     = 5'hb;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT15_STATUS_WAIT_DEU_NOT_FULL          = 5'hc;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT15_STATUS_WAIT_PIP_OLDEST            = 5'hd;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT15_STATUS_WAIT_FC_ZERO               = 5'he;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT15_STATUS_WAIT_WFC_ZERO              = 5'hf;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT15_STATUS_WAIT_NOT_FC_MAX            = 5'h10;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT15_STATUS_WAIT_NOT_WFC_MAX           = 5'h11;

 // gc_cr_cu_slot16
localparam logic [ 30 : 1 ] GC_CR_CU_SLOT16_PC_BITFIELD                        = 30'h0;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT16_STATUS_BITFIELD                   = 5'h0;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT16_STATUS_EMPTY_COMPLETED            = 5'h0;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT16_STATUS_WAIT_ACTIVE                = 5'h1;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT16_STATUS_ACTIVE_READY               = 5'h2;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT16_STATUS_ACTIVE_RUNNING             = 5'h3;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT16_STATUS_WAIT_MUTEX_LOCK            = 5'h4;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT16_STATUS_WAIT_CACHE_HIT             = 5'h5;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT16_STATUS_WAIT_CACHE_DOUBLE_HIT      = 5'h6;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT16_STATUS_WAIT_OB_FREED              = 5'h7;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT16_STATUS_WAIT_OB_ACTIVE             = 5'h8;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT16_STATUS_WAIT_BARRIER_WAKEUP        = 5'h9;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT16_STATUS_WAIT_PASS_GROUP            = 5'ha;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT16_STATUS_WAIT_PIPELINE_NOT_FULL     = 5'hb;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT16_STATUS_WAIT_DEU_NOT_FULL          = 5'hc;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT16_STATUS_WAIT_PIP_OLDEST            = 5'hd;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT16_STATUS_WAIT_FC_ZERO               = 5'he;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT16_STATUS_WAIT_WFC_ZERO              = 5'hf;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT16_STATUS_WAIT_NOT_FC_MAX            = 5'h10;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT16_STATUS_WAIT_NOT_WFC_MAX           = 5'h11;

 // gc_cr_cu_slot17
localparam logic [ 30 : 1 ] GC_CR_CU_SLOT17_PC_BITFIELD                        = 30'h0;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT17_STATUS_BITFIELD                   = 5'h0;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT17_STATUS_EMPTY_COMPLETED            = 5'h0;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT17_STATUS_WAIT_ACTIVE                = 5'h1;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT17_STATUS_ACTIVE_READY               = 5'h2;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT17_STATUS_ACTIVE_RUNNING             = 5'h3;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT17_STATUS_WAIT_MUTEX_LOCK            = 5'h4;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT17_STATUS_WAIT_CACHE_HIT             = 5'h5;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT17_STATUS_WAIT_CACHE_DOUBLE_HIT      = 5'h6;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT17_STATUS_WAIT_OB_FREED              = 5'h7;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT17_STATUS_WAIT_OB_ACTIVE             = 5'h8;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT17_STATUS_WAIT_BARRIER_WAKEUP        = 5'h9;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT17_STATUS_WAIT_PASS_GROUP            = 5'ha;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT17_STATUS_WAIT_PIPELINE_NOT_FULL     = 5'hb;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT17_STATUS_WAIT_DEU_NOT_FULL          = 5'hc;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT17_STATUS_WAIT_PIP_OLDEST            = 5'hd;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT17_STATUS_WAIT_FC_ZERO               = 5'he;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT17_STATUS_WAIT_WFC_ZERO              = 5'hf;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT17_STATUS_WAIT_NOT_FC_MAX            = 5'h10;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT17_STATUS_WAIT_NOT_WFC_MAX           = 5'h11;

 // gc_cr_cu_slot18
localparam logic [ 30 : 1 ] GC_CR_CU_SLOT18_PC_BITFIELD                        = 30'h0;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT18_STATUS_BITFIELD                   = 5'h0;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT18_STATUS_EMPTY_COMPLETED            = 5'h0;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT18_STATUS_WAIT_ACTIVE                = 5'h1;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT18_STATUS_ACTIVE_READY               = 5'h2;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT18_STATUS_ACTIVE_RUNNING             = 5'h3;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT18_STATUS_WAIT_MUTEX_LOCK            = 5'h4;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT18_STATUS_WAIT_CACHE_HIT             = 5'h5;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT18_STATUS_WAIT_CACHE_DOUBLE_HIT      = 5'h6;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT18_STATUS_WAIT_OB_FREED              = 5'h7;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT18_STATUS_WAIT_OB_ACTIVE             = 5'h8;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT18_STATUS_WAIT_BARRIER_WAKEUP        = 5'h9;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT18_STATUS_WAIT_PASS_GROUP            = 5'ha;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT18_STATUS_WAIT_PIPELINE_NOT_FULL     = 5'hb;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT18_STATUS_WAIT_DEU_NOT_FULL          = 5'hc;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT18_STATUS_WAIT_PIP_OLDEST            = 5'hd;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT18_STATUS_WAIT_FC_ZERO               = 5'he;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT18_STATUS_WAIT_WFC_ZERO              = 5'hf;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT18_STATUS_WAIT_NOT_FC_MAX            = 5'h10;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT18_STATUS_WAIT_NOT_WFC_MAX           = 5'h11;

 // gc_cr_cu_slot19
localparam logic [ 30 : 1 ] GC_CR_CU_SLOT19_PC_BITFIELD                        = 30'h0;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT19_STATUS_BITFIELD                   = 5'h0;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT19_STATUS_EMPTY_COMPLETED            = 5'h0;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT19_STATUS_WAIT_ACTIVE                = 5'h1;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT19_STATUS_ACTIVE_READY               = 5'h2;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT19_STATUS_ACTIVE_RUNNING             = 5'h3;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT19_STATUS_WAIT_MUTEX_LOCK            = 5'h4;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT19_STATUS_WAIT_CACHE_HIT             = 5'h5;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT19_STATUS_WAIT_CACHE_DOUBLE_HIT      = 5'h6;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT19_STATUS_WAIT_OB_FREED              = 5'h7;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT19_STATUS_WAIT_OB_ACTIVE             = 5'h8;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT19_STATUS_WAIT_BARRIER_WAKEUP        = 5'h9;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT19_STATUS_WAIT_PASS_GROUP            = 5'ha;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT19_STATUS_WAIT_PIPELINE_NOT_FULL     = 5'hb;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT19_STATUS_WAIT_DEU_NOT_FULL          = 5'hc;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT19_STATUS_WAIT_PIP_OLDEST            = 5'hd;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT19_STATUS_WAIT_FC_ZERO               = 5'he;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT19_STATUS_WAIT_WFC_ZERO              = 5'hf;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT19_STATUS_WAIT_NOT_FC_MAX            = 5'h10;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT19_STATUS_WAIT_NOT_WFC_MAX           = 5'h11;

 // gc_cr_cu_slot20
localparam logic [ 30 : 1 ] GC_CR_CU_SLOT20_PC_BITFIELD                        = 30'h0;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT20_STATUS_BITFIELD                   = 5'h0;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT20_STATUS_EMPTY_COMPLETED            = 5'h0;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT20_STATUS_WAIT_ACTIVE                = 5'h1;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT20_STATUS_ACTIVE_READY               = 5'h2;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT20_STATUS_ACTIVE_RUNNING             = 5'h3;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT20_STATUS_WAIT_MUTEX_LOCK            = 5'h4;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT20_STATUS_WAIT_CACHE_HIT             = 5'h5;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT20_STATUS_WAIT_CACHE_DOUBLE_HIT      = 5'h6;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT20_STATUS_WAIT_OB_FREED              = 5'h7;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT20_STATUS_WAIT_OB_ACTIVE             = 5'h8;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT20_STATUS_WAIT_BARRIER_WAKEUP        = 5'h9;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT20_STATUS_WAIT_PASS_GROUP            = 5'ha;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT20_STATUS_WAIT_PIPELINE_NOT_FULL     = 5'hb;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT20_STATUS_WAIT_DEU_NOT_FULL          = 5'hc;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT20_STATUS_WAIT_PIP_OLDEST            = 5'hd;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT20_STATUS_WAIT_FC_ZERO               = 5'he;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT20_STATUS_WAIT_WFC_ZERO              = 5'hf;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT20_STATUS_WAIT_NOT_FC_MAX            = 5'h10;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT20_STATUS_WAIT_NOT_WFC_MAX           = 5'h11;

 // gc_cr_cu_slot21
localparam logic [ 30 : 1 ] GC_CR_CU_SLOT21_PC_BITFIELD                        = 30'h0;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT21_STATUS_BITFIELD                   = 5'h0;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT21_STATUS_EMPTY_COMPLETED            = 5'h0;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT21_STATUS_WAIT_ACTIVE                = 5'h1;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT21_STATUS_ACTIVE_READY               = 5'h2;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT21_STATUS_ACTIVE_RUNNING             = 5'h3;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT21_STATUS_WAIT_MUTEX_LOCK            = 5'h4;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT21_STATUS_WAIT_CACHE_HIT             = 5'h5;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT21_STATUS_WAIT_CACHE_DOUBLE_HIT      = 5'h6;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT21_STATUS_WAIT_OB_FREED              = 5'h7;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT21_STATUS_WAIT_OB_ACTIVE             = 5'h8;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT21_STATUS_WAIT_BARRIER_WAKEUP        = 5'h9;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT21_STATUS_WAIT_PASS_GROUP            = 5'ha;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT21_STATUS_WAIT_PIPELINE_NOT_FULL     = 5'hb;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT21_STATUS_WAIT_DEU_NOT_FULL          = 5'hc;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT21_STATUS_WAIT_PIP_OLDEST            = 5'hd;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT21_STATUS_WAIT_FC_ZERO               = 5'he;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT21_STATUS_WAIT_WFC_ZERO              = 5'hf;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT21_STATUS_WAIT_NOT_FC_MAX            = 5'h10;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT21_STATUS_WAIT_NOT_WFC_MAX           = 5'h11;

 // gc_cr_cu_slot22
localparam logic [ 30 : 1 ] GC_CR_CU_SLOT22_PC_BITFIELD                        = 30'h0;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT22_STATUS_BITFIELD                   = 5'h0;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT22_STATUS_EMPTY_COMPLETED            = 5'h0;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT22_STATUS_WAIT_ACTIVE                = 5'h1;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT22_STATUS_ACTIVE_READY               = 5'h2;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT22_STATUS_ACTIVE_RUNNING             = 5'h3;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT22_STATUS_WAIT_MUTEX_LOCK            = 5'h4;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT22_STATUS_WAIT_CACHE_HIT             = 5'h5;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT22_STATUS_WAIT_CACHE_DOUBLE_HIT      = 5'h6;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT22_STATUS_WAIT_OB_FREED              = 5'h7;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT22_STATUS_WAIT_OB_ACTIVE             = 5'h8;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT22_STATUS_WAIT_BARRIER_WAKEUP        = 5'h9;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT22_STATUS_WAIT_PASS_GROUP            = 5'ha;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT22_STATUS_WAIT_PIPELINE_NOT_FULL     = 5'hb;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT22_STATUS_WAIT_DEU_NOT_FULL          = 5'hc;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT22_STATUS_WAIT_PIP_OLDEST            = 5'hd;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT22_STATUS_WAIT_FC_ZERO               = 5'he;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT22_STATUS_WAIT_WFC_ZERO              = 5'hf;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT22_STATUS_WAIT_NOT_FC_MAX            = 5'h10;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT22_STATUS_WAIT_NOT_WFC_MAX           = 5'h11;

 // gc_cr_cu_slot23
localparam logic [ 30 : 1 ] GC_CR_CU_SLOT23_PC_BITFIELD                        = 30'h0;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT23_STATUS_BITFIELD                   = 5'h0;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT23_STATUS_EMPTY_COMPLETED            = 5'h0;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT23_STATUS_WAIT_ACTIVE                = 5'h1;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT23_STATUS_ACTIVE_READY               = 5'h2;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT23_STATUS_ACTIVE_RUNNING             = 5'h3;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT23_STATUS_WAIT_MUTEX_LOCK            = 5'h4;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT23_STATUS_WAIT_CACHE_HIT             = 5'h5;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT23_STATUS_WAIT_CACHE_DOUBLE_HIT      = 5'h6;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT23_STATUS_WAIT_OB_FREED              = 5'h7;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT23_STATUS_WAIT_OB_ACTIVE             = 5'h8;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT23_STATUS_WAIT_BARRIER_WAKEUP        = 5'h9;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT23_STATUS_WAIT_PASS_GROUP            = 5'ha;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT23_STATUS_WAIT_PIPELINE_NOT_FULL     = 5'hb;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT23_STATUS_WAIT_DEU_NOT_FULL          = 5'hc;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT23_STATUS_WAIT_PIP_OLDEST            = 5'hd;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT23_STATUS_WAIT_FC_ZERO               = 5'he;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT23_STATUS_WAIT_WFC_ZERO              = 5'hf;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT23_STATUS_WAIT_NOT_FC_MAX            = 5'h10;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT23_STATUS_WAIT_NOT_WFC_MAX           = 5'h11;

 // gc_cr_cu_slot24
localparam logic [ 30 : 1 ] GC_CR_CU_SLOT24_PC_BITFIELD                        = 30'h0;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT24_STATUS_BITFIELD                   = 5'h0;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT24_STATUS_EMPTY_COMPLETED            = 5'h0;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT24_STATUS_WAIT_ACTIVE                = 5'h1;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT24_STATUS_ACTIVE_READY               = 5'h2;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT24_STATUS_ACTIVE_RUNNING             = 5'h3;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT24_STATUS_WAIT_MUTEX_LOCK            = 5'h4;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT24_STATUS_WAIT_CACHE_HIT             = 5'h5;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT24_STATUS_WAIT_CACHE_DOUBLE_HIT      = 5'h6;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT24_STATUS_WAIT_OB_FREED              = 5'h7;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT24_STATUS_WAIT_OB_ACTIVE             = 5'h8;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT24_STATUS_WAIT_BARRIER_WAKEUP        = 5'h9;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT24_STATUS_WAIT_PASS_GROUP            = 5'ha;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT24_STATUS_WAIT_PIPELINE_NOT_FULL     = 5'hb;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT24_STATUS_WAIT_DEU_NOT_FULL          = 5'hc;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT24_STATUS_WAIT_PIP_OLDEST            = 5'hd;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT24_STATUS_WAIT_FC_ZERO               = 5'he;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT24_STATUS_WAIT_WFC_ZERO              = 5'hf;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT24_STATUS_WAIT_NOT_FC_MAX            = 5'h10;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT24_STATUS_WAIT_NOT_WFC_MAX           = 5'h11;

 // gc_cr_cu_slot25
localparam logic [ 30 : 1 ] GC_CR_CU_SLOT25_PC_BITFIELD                        = 30'h0;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT25_STATUS_BITFIELD                   = 5'h0;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT25_STATUS_EMPTY_COMPLETED            = 5'h0;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT25_STATUS_WAIT_ACTIVE                = 5'h1;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT25_STATUS_ACTIVE_READY               = 5'h2;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT25_STATUS_ACTIVE_RUNNING             = 5'h3;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT25_STATUS_WAIT_MUTEX_LOCK            = 5'h4;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT25_STATUS_WAIT_CACHE_HIT             = 5'h5;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT25_STATUS_WAIT_CACHE_DOUBLE_HIT      = 5'h6;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT25_STATUS_WAIT_OB_FREED              = 5'h7;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT25_STATUS_WAIT_OB_ACTIVE             = 5'h8;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT25_STATUS_WAIT_BARRIER_WAKEUP        = 5'h9;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT25_STATUS_WAIT_PASS_GROUP            = 5'ha;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT25_STATUS_WAIT_PIPELINE_NOT_FULL     = 5'hb;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT25_STATUS_WAIT_DEU_NOT_FULL          = 5'hc;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT25_STATUS_WAIT_PIP_OLDEST            = 5'hd;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT25_STATUS_WAIT_FC_ZERO               = 5'he;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT25_STATUS_WAIT_WFC_ZERO              = 5'hf;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT25_STATUS_WAIT_NOT_FC_MAX            = 5'h10;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT25_STATUS_WAIT_NOT_WFC_MAX           = 5'h11;

 // gc_cr_cu_slot26
localparam logic [ 30 : 1 ] GC_CR_CU_SLOT26_PC_BITFIELD                        = 30'h0;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT26_STATUS_BITFIELD                   = 5'h0;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT26_STATUS_EMPTY_COMPLETED            = 5'h0;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT26_STATUS_WAIT_ACTIVE                = 5'h1;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT26_STATUS_ACTIVE_READY               = 5'h2;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT26_STATUS_ACTIVE_RUNNING             = 5'h3;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT26_STATUS_WAIT_MUTEX_LOCK            = 5'h4;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT26_STATUS_WAIT_CACHE_HIT             = 5'h5;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT26_STATUS_WAIT_CACHE_DOUBLE_HIT      = 5'h6;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT26_STATUS_WAIT_OB_FREED              = 5'h7;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT26_STATUS_WAIT_OB_ACTIVE             = 5'h8;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT26_STATUS_WAIT_BARRIER_WAKEUP        = 5'h9;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT26_STATUS_WAIT_PASS_GROUP            = 5'ha;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT26_STATUS_WAIT_PIPELINE_NOT_FULL     = 5'hb;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT26_STATUS_WAIT_DEU_NOT_FULL          = 5'hc;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT26_STATUS_WAIT_PIP_OLDEST            = 5'hd;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT26_STATUS_WAIT_FC_ZERO               = 5'he;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT26_STATUS_WAIT_WFC_ZERO              = 5'hf;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT26_STATUS_WAIT_NOT_FC_MAX            = 5'h10;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT26_STATUS_WAIT_NOT_WFC_MAX           = 5'h11;

 // gc_cr_cu_slot27
localparam logic [ 30 : 1 ] GC_CR_CU_SLOT27_PC_BITFIELD                        = 30'h0;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT27_STATUS_BITFIELD                   = 5'h0;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT27_STATUS_EMPTY_COMPLETED            = 5'h0;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT27_STATUS_WAIT_ACTIVE                = 5'h1;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT27_STATUS_ACTIVE_READY               = 5'h2;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT27_STATUS_ACTIVE_RUNNING             = 5'h3;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT27_STATUS_WAIT_MUTEX_LOCK            = 5'h4;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT27_STATUS_WAIT_CACHE_HIT             = 5'h5;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT27_STATUS_WAIT_CACHE_DOUBLE_HIT      = 5'h6;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT27_STATUS_WAIT_OB_FREED              = 5'h7;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT27_STATUS_WAIT_OB_ACTIVE             = 5'h8;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT27_STATUS_WAIT_BARRIER_WAKEUP        = 5'h9;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT27_STATUS_WAIT_PASS_GROUP            = 5'ha;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT27_STATUS_WAIT_PIPELINE_NOT_FULL     = 5'hb;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT27_STATUS_WAIT_DEU_NOT_FULL          = 5'hc;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT27_STATUS_WAIT_PIP_OLDEST            = 5'hd;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT27_STATUS_WAIT_FC_ZERO               = 5'he;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT27_STATUS_WAIT_WFC_ZERO              = 5'hf;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT27_STATUS_WAIT_NOT_FC_MAX            = 5'h10;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT27_STATUS_WAIT_NOT_WFC_MAX           = 5'h11;

 // gc_cr_cu_slot28
localparam logic [ 30 : 1 ] GC_CR_CU_SLOT28_PC_BITFIELD                        = 30'h0;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT28_STATUS_BITFIELD                   = 5'h0;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT28_STATUS_EMPTY_COMPLETED            = 5'h0;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT28_STATUS_WAIT_ACTIVE                = 5'h1;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT28_STATUS_ACTIVE_READY               = 5'h2;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT28_STATUS_ACTIVE_RUNNING             = 5'h3;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT28_STATUS_WAIT_MUTEX_LOCK            = 5'h4;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT28_STATUS_WAIT_CACHE_HIT             = 5'h5;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT28_STATUS_WAIT_CACHE_DOUBLE_HIT      = 5'h6;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT28_STATUS_WAIT_OB_FREED              = 5'h7;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT28_STATUS_WAIT_OB_ACTIVE             = 5'h8;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT28_STATUS_WAIT_BARRIER_WAKEUP        = 5'h9;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT28_STATUS_WAIT_PASS_GROUP            = 5'ha;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT28_STATUS_WAIT_PIPELINE_NOT_FULL     = 5'hb;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT28_STATUS_WAIT_DEU_NOT_FULL          = 5'hc;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT28_STATUS_WAIT_PIP_OLDEST            = 5'hd;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT28_STATUS_WAIT_FC_ZERO               = 5'he;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT28_STATUS_WAIT_WFC_ZERO              = 5'hf;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT28_STATUS_WAIT_NOT_FC_MAX            = 5'h10;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT28_STATUS_WAIT_NOT_WFC_MAX           = 5'h11;

 // gc_cr_cu_slot29
localparam logic [ 30 : 1 ] GC_CR_CU_SLOT29_PC_BITFIELD                        = 30'h0;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT29_STATUS_BITFIELD                   = 5'h0;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT29_STATUS_EMPTY_COMPLETED            = 5'h0;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT29_STATUS_WAIT_ACTIVE                = 5'h1;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT29_STATUS_ACTIVE_READY               = 5'h2;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT29_STATUS_ACTIVE_RUNNING             = 5'h3;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT29_STATUS_WAIT_MUTEX_LOCK            = 5'h4;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT29_STATUS_WAIT_CACHE_HIT             = 5'h5;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT29_STATUS_WAIT_CACHE_DOUBLE_HIT      = 5'h6;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT29_STATUS_WAIT_OB_FREED              = 5'h7;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT29_STATUS_WAIT_OB_ACTIVE             = 5'h8;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT29_STATUS_WAIT_BARRIER_WAKEUP        = 5'h9;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT29_STATUS_WAIT_PASS_GROUP            = 5'ha;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT29_STATUS_WAIT_PIPELINE_NOT_FULL     = 5'hb;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT29_STATUS_WAIT_DEU_NOT_FULL          = 5'hc;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT29_STATUS_WAIT_PIP_OLDEST            = 5'hd;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT29_STATUS_WAIT_FC_ZERO               = 5'he;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT29_STATUS_WAIT_WFC_ZERO              = 5'hf;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT29_STATUS_WAIT_NOT_FC_MAX            = 5'h10;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT29_STATUS_WAIT_NOT_WFC_MAX           = 5'h11;

 // gc_cr_cu_slot30
localparam logic [ 30 : 1 ] GC_CR_CU_SLOT30_PC_BITFIELD                        = 30'h0;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT30_STATUS_BITFIELD                   = 5'h0;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT30_STATUS_EMPTY_COMPLETED            = 5'h0;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT30_STATUS_WAIT_ACTIVE                = 5'h1;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT30_STATUS_ACTIVE_READY               = 5'h2;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT30_STATUS_ACTIVE_RUNNING             = 5'h3;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT30_STATUS_WAIT_MUTEX_LOCK            = 5'h4;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT30_STATUS_WAIT_CACHE_HIT             = 5'h5;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT30_STATUS_WAIT_CACHE_DOUBLE_HIT      = 5'h6;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT30_STATUS_WAIT_OB_FREED              = 5'h7;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT30_STATUS_WAIT_OB_ACTIVE             = 5'h8;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT30_STATUS_WAIT_BARRIER_WAKEUP        = 5'h9;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT30_STATUS_WAIT_PASS_GROUP            = 5'ha;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT30_STATUS_WAIT_PIPELINE_NOT_FULL     = 5'hb;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT30_STATUS_WAIT_DEU_NOT_FULL          = 5'hc;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT30_STATUS_WAIT_PIP_OLDEST            = 5'hd;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT30_STATUS_WAIT_FC_ZERO               = 5'he;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT30_STATUS_WAIT_WFC_ZERO              = 5'hf;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT30_STATUS_WAIT_NOT_FC_MAX            = 5'h10;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT30_STATUS_WAIT_NOT_WFC_MAX           = 5'h11;

 // gc_cr_cu_slot31
localparam logic [ 30 : 1 ] GC_CR_CU_SLOT31_PC_BITFIELD                        = 30'h0;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT31_STATUS_BITFIELD                   = 5'h0;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT31_STATUS_EMPTY_COMPLETED            = 5'h0;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT31_STATUS_WAIT_ACTIVE                = 5'h1;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT31_STATUS_ACTIVE_READY               = 5'h2;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT31_STATUS_ACTIVE_RUNNING             = 5'h3;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT31_STATUS_WAIT_MUTEX_LOCK            = 5'h4;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT31_STATUS_WAIT_CACHE_HIT             = 5'h5;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT31_STATUS_WAIT_CACHE_DOUBLE_HIT      = 5'h6;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT31_STATUS_WAIT_OB_FREED              = 5'h7;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT31_STATUS_WAIT_OB_ACTIVE             = 5'h8;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT31_STATUS_WAIT_BARRIER_WAKEUP        = 5'h9;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT31_STATUS_WAIT_PASS_GROUP            = 5'ha;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT31_STATUS_WAIT_PIPELINE_NOT_FULL     = 5'hb;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT31_STATUS_WAIT_DEU_NOT_FULL          = 5'hc;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT31_STATUS_WAIT_PIP_OLDEST            = 5'hd;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT31_STATUS_WAIT_FC_ZERO               = 5'he;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT31_STATUS_WAIT_WFC_ZERO              = 5'hf;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT31_STATUS_WAIT_NOT_FC_MAX            = 5'h10;
localparam logic [ 36 : 32 ] GC_CR_CU_SLOT31_STATUS_WAIT_NOT_WFC_MAX           = 5'h11;

 // gc_cr_spc_idle
localparam logic [ 0 : 0 ] GC_CR_SPC_IDLE_CU0_BITFIELD                         = 1'h1;
localparam logic [ 1 : 1 ] GC_CR_SPC_IDLE_CU1_BITFIELD                         = 1'h1;
localparam logic [ 2 : 2 ] GC_CR_SPC_IDLE_CU2_BITFIELD                         = 1'h1;
localparam logic [ 3 : 3 ] GC_CR_SPC_IDLE_CU3_BITFIELD                         = 1'h1;

 // gc_cr_ce_idle
localparam logic [ 0 : 0 ] GC_CR_CE_IDLE_QUEUE0_BITFIELD                       = 1'h1;
localparam logic [ 1 : 1 ] GC_CR_CE_IDLE_QUEUE1_BITFIELD                       = 1'h1;
localparam logic [ 2 : 2 ] GC_CR_CE_IDLE_QUEUE2_BITFIELD                       = 1'h1;
localparam logic [ 3 : 3 ] GC_CR_CE_IDLE_QUEUE3_BITFIELD                       = 1'h1;
localparam logic [ 4 : 4 ] GC_CR_CE_IDLE_QUEUE4_BITFIELD                       = 1'h1;
localparam logic [ 5 : 5 ] GC_CR_CE_IDLE_QUEUE5_BITFIELD                       = 1'h1;
localparam logic [ 6 : 6 ] GC_CR_CE_IDLE_QUEUE6_BITFIELD                       = 1'h1;
localparam logic [ 7 : 7 ] GC_CR_CE_IDLE_QUEUE7_BITFIELD                       = 1'h1;
localparam logic [ 16 : 16 ] GC_CR_CE_IDLE_ME0_BITFIELD                        = 1'h1;
localparam logic [ 17 : 17 ] GC_CR_CE_IDLE_ME1_BITFIELD                        = 1'h1;
localparam logic [ 18 : 18 ] GC_CR_CE_IDLE_ME2_BITFIELD                        = 1'h1;
localparam logic [ 19 : 19 ] GC_CR_CE_IDLE_ME3_BITFIELD                        = 1'h1;
localparam logic [ 24 : 24 ] GC_CR_CE_IDLE_BE_BITFIELD                         = 1'h1;
localparam logic [ 25 : 25 ] GC_CR_CE_IDLE_ME_SCHED_BITFIELD                   = 1'h1;

 // gc_cr_ce_gtt_req_mode
localparam logic [ 0 : 0 ] GC_CR_CE_GTT_REQ_MODE_MODE_BITFIELD                 = 1'h0;

 // gc_cr_mss_axcache_ctrl
localparam logic [ 0 : 0 ] GC_CR_MSS_AXCACHE_CTRL_CTRL_BITFIELD                = 1'h0;

 // gc_cr_ce_mmu_ace_qos_ctrl
localparam logic [ 3 : 0 ] GC_CR_CE_MMU_ACE_QOS_CTRL_QOS_CTRL_BITFIELD         = 4'h0;

 // gc_cr_ce_event_ckbit
localparam logic [ 0 : 0 ] GC_CR_CE_EVENT_CKBIT_CKBIT_BITFIELD                 = 1'h0;

 // gc_cr_ce_axi_outstanding
localparam logic [ 6 : 0 ] GC_CR_CE_AXI_OUTSTANDING_WR_BITFIELD                = 7'h7f;
localparam logic [ 14 : 8 ] GC_CR_CE_AXI_OUTSTANDING_RD_BITFIELD               = 7'h7f;

 // gc_cr_ce_ace_01_avg
localparam logic [ 15 : 0 ] GC_CR_CE_ACE_01_AVG_RD_LATENCY0_BITFIELD           = 16'h0;
localparam logic [ 31 : 16 ] GC_CR_CE_ACE_01_AVG_WR_LATENCY0_BITFIELD          = 16'h0;
localparam logic [ 47 : 32 ] GC_CR_CE_ACE_01_AVG_RD_LATENCY1_BITFIELD          = 16'h0;
localparam logic [ 63 : 48 ] GC_CR_CE_ACE_01_AVG_WR_LATENCY1_BITFIELD          = 16'h0;

 // gc_cr_ce_ace_23_avg
localparam logic [ 15 : 0 ] GC_CR_CE_ACE_23_AVG_RD_LATENCY2_BITFIELD           = 16'h0;
localparam logic [ 31 : 16 ] GC_CR_CE_ACE_23_AVG_WR_LATENCY2_BITFIELD          = 16'h0;
localparam logic [ 47 : 32 ] GC_CR_CE_ACE_23_AVG_RD_LATENCY3_BITFIELD          = 16'h0;
localparam logic [ 63 : 48 ] GC_CR_CE_ACE_23_AVG_WR_LATENCY3_BITFIELD          = 16'h0;

 // gc_cr_ce_copy0_data_size
localparam logic [ 41 : 0 ] GC_CR_CE_COPY0_DATA_SIZE_DATA_SIZE_BITFIELD        = 42'h0;

 // gc_cr_ce_copy1_data_size
localparam logic [ 41 : 0 ] GC_CR_CE_COPY1_DATA_SIZE_DATA_SIZE_BITFIELD        = 42'h0;

 // gc_cr_ce_copy2_data_size
localparam logic [ 41 : 0 ] GC_CR_CE_COPY2_DATA_SIZE_DATA_SIZE_BITFIELD        = 42'h0;

 // gc_cr_ce_copy3_data_size
localparam logic [ 41 : 0 ] GC_CR_CE_COPY3_DATA_SIZE_DATA_SIZE_BITFIELD        = 42'h0;

 // gc_cr_ce_copy0_task_period
localparam logic [ 41 : 0 ] GC_CR_CE_COPY0_TASK_PERIOD_TASK_PERIOD_BITFIELD    = 42'h0;

 // gc_cr_ce_copy1_task_period
localparam logic [ 41 : 0 ] GC_CR_CE_COPY1_TASK_PERIOD_TASK_PERIOD_BITFIELD    = 42'h0;

 // gc_cr_ce_copy2_task_period
localparam logic [ 41 : 0 ] GC_CR_CE_COPY2_TASK_PERIOD_TASK_PERIOD_BITFIELD    = 42'h0;

 // gc_cr_ce_copy3_task_period
localparam logic [ 41 : 0 ] GC_CR_CE_COPY3_TASK_PERIOD_TASK_PERIOD_BITFIELD    = 42'h0;

 // gc_cr_ce_perf_count_enable
localparam logic [ 0 : 0 ] GC_CR_CE_PERF_COUNT_ENABLE_COUNT_ENABLE_BITFIELD    = 1'h0;

 // gc_cr_ce_multi_chip_raw_enable
localparam logic [ 0 : 0 ] GC_CR_CE_MULTI_CHIP_RAW_ENABLE_ENABLE_BITFIELD      = 1'h1;

 // gc_cr_ce_if_idle_cnt
localparam logic [ 31 : 0 ] GC_CR_CE_IF_IDLE_CNT_IDLE_CNT_BITFIELD             = 32'h0;

 // gc_cr_pim0_ce_buffer_addr
localparam logic [ 48 : 0 ] GC_CR_PIM0_CE_BUFFER_ADDR_ADDR_BITFIELD            = 49'h2000000000;

 // gc_cr_pim1_ce_buffer_addr
localparam logic [ 48 : 0 ] GC_CR_PIM1_CE_BUFFER_ADDR_ADDR_BITFIELD            = 49'h4000000000;

 // gc_cr_ce_pim_credit_num
localparam logic [ 6 : 0 ] GC_CR_CE_PIM_CREDIT_NUM_LOW_BITFIELD                = 7'h9;
localparam logic [ 14 : 8 ] GC_CR_CE_PIM_CREDIT_NUM_MID_BITFIELD               = 7'h13;
localparam logic [ 22 : 16 ] GC_CR_CE_PIM_CREDIT_NUM_HIGH_BITFIELD             = 7'h1f;

 // gc_cr_ce_pim_axi_outstanding
localparam logic [ 6 : 0 ] GC_CR_CE_PIM_AXI_OUTSTANDING_OUTSTANDING_BITFIELD   = 7'h1f;

 // gc_cr_ce_cp_ctrl_mask
localparam logic [ 0 : 0 ] GC_CR_CE_CP_CTRL_MASK_MASK_BITFIELD                 = 1'h0;

 // gc_cr_ce_queue0_mmu
localparam logic [ 9 : 0 ] GC_CR_CE_QUEUE0_MMU_PASID_BITFIELD                  = 10'h0;
localparam logic [ 19 : 16 ] GC_CR_CE_QUEUE0_MMU_VFID_OSID_BITFIELD            = 4'h0;

 // gc_cr_ce_queue0_start
localparam logic [ 0 : 0 ] GC_CR_CE_QUEUE0_START_PLUSE_BITFIELD                = 1'h0;
localparam logic [ 1 : 1 ] GC_CR_CE_QUEUE0_START_CONTEXT_RESUME_BITFIELD       = 1'h0;

 // gc_cr_ce_queue0_rb_base
localparam logic [ 47 : 6 ] GC_CR_CE_QUEUE0_RB_BASE_ADDR_BITFIELD              = 42'h0;

 // gc_cr_ce_queue0_rb
localparam logic [ 29 : 2 ] GC_CR_CE_QUEUE0_RB_WOFF_UPDATE_CTRL_BITFIELD       = 28'h20;
localparam logic [ 61 : 41 ] GC_CR_CE_QUEUE0_RB_SIZE_BITFIELD                  = 21'h20;

 // gc_cr_ce_queue0_rb_roff
localparam logic [ 29 : 2 ] GC_CR_CE_QUEUE0_RB_ROFF_OFFSET_BITFIELD            = 28'h0;

 // gc_cr_ce_queue0_rb_ctrl_base
localparam logic [ 47 : 3 ] GC_CR_CE_QUEUE0_RB_CTRL_BASE_ADDR_BITFIELD         = 45'h0;

 // gc_cr_ce_queue0_rb_roff_update_ctrl
localparam logic [ 29 : 2 ] GC_CR_CE_QUEUE0_RB_ROFF_UPDATE_CTRL_THRESHOLD_BITFIELD  = 28'h20;

 // gc_cr_ce_queue0_l2_policy
localparam logic [ 1 : 0 ] GC_CR_CE_QUEUE0_L2_POLICY_PERSISTENT_BITFIELD       = 2'h3;
localparam logic [ 2 : 2 ] GC_CR_CE_QUEUE0_L2_POLICY_RB_BITFIELD               = 1'h0;
localparam logic [ 3 : 3 ] GC_CR_CE_QUEUE0_L2_POLICY_IB_BITFIELD               = 1'h0;
localparam logic [ 4 : 4 ] GC_CR_CE_QUEUE0_L2_POLICY_FENCE_BITFIELD            = 1'h0;
localparam logic [ 5 : 5 ] GC_CR_CE_QUEUE0_L2_POLICY_OFFSET_BITFIELD           = 1'h0;

 // gc_cr_ce_queue0_error_status
localparam logic [ 1 : 0 ] GC_CR_CE_QUEUE0_ERROR_STATUS_AXI_READ_RSP_BITFIELD  = 2'h0;
localparam logic [ 2 : 2 ] GC_CR_CE_QUEUE0_ERROR_STATUS_RAW_READ_BITFIELD      = 1'h0;
localparam logic [ 5 : 4 ] GC_CR_CE_QUEUE0_ERROR_STATUS_AXI_WRITE_RSP_BITFIELD  = 2'h0;

 // gc_cr_ce_queue0_context_store_base
localparam logic [ 47 : 4 ] GC_CR_CE_QUEUE0_CONTEXT_STORE_BASE_ADDR_BITFIELD   = 44'h0;

 // gc_cr_ce_queue0_cs_status
localparam logic [ 0 : 0 ] GC_CR_CE_QUEUE0_CS_STATUS_STATUS_BITFIELD           = 1'h0;

 // gc_cr_ce_queue0
localparam logic [ 0 : 0 ] GC_CR_CE_QUEUE0_CONTINUE_BITFIELD                   = 1'h0;
localparam logic [ 1 : 1 ] GC_CR_CE_QUEUE0_CONTEXT_STORE_BITFIELD              = 1'h0;

 // gc_cr_ce_queue0_fence
localparam logic [ 15 : 0 ] GC_CR_CE_QUEUE0_FENCE_POLL_CTRL_BITFIELD           = 16'h804;

 // gc_cr_ce_queue0_ace_qos
localparam logic [ 3 : 0 ] GC_CR_CE_QUEUE0_ACE_QOS_CTRL_BITFIELD               = 4'h0;

 // gc_cr_ce_queue0_local_event
localparam logic [ 0 : 0 ] GC_CR_CE_QUEUE0_LOCAL_EVENT_COMPLETE_BITFIELD       = 1'h0;
localparam logic [ 1 : 1 ] GC_CR_CE_QUEUE0_LOCAL_EVENT_SIGNAL_WAIT_FAIL_BITFIELD  = 1'h0;
localparam logic [ 2 : 2 ] GC_CR_CE_QUEUE0_LOCAL_EVENT_STALL_BITFIELD          = 1'h0;
localparam logic [ 3 : 3 ] GC_CR_CE_QUEUE0_LOCAL_EVENT_EXCEPTION_AND_QUEUE_ERR_BITFIELD  = 1'h0;
localparam logic [ 4 : 4 ] GC_CR_CE_QUEUE0_LOCAL_EVENT_FENCE_INTERRUPT_BITFIELD  = 1'h0;
localparam logic [ 5 : 5 ] GC_CR_CE_QUEUE0_LOCAL_EVENT_PAGE_FAULT_BITFIELD     = 1'h0;
localparam logic [ 6 : 6 ] GC_CR_CE_QUEUE0_LOCAL_EVENT_AXI_RESP_ERR_BITFIELD   = 1'h0;
localparam logic [ 7 : 7 ] GC_CR_CE_QUEUE0_LOCAL_EVENT_PIM_ERROR_FOUND_BITFIELD  = 1'h0;

 // gc_cr_ce_queue0_local_event_enable
localparam logic [ 7 : 0 ] GC_CR_CE_QUEUE0_LOCAL_EVENT_ENABLE_ENABLE_BITFIELD  = 8'hff;

 // gc_cr_ce_queue0_local_event_clear
localparam logic [ 7 : 0 ] GC_CR_CE_QUEUE0_LOCAL_EVENT_CLEAR_CLEAR_BITFIELD    = 8'h0;

 // gc_cr_ce_queue0_mmu_fault_status
localparam logic [ 0 : 0 ] GC_CR_CE_QUEUE0_MMU_FAULT_STATUS_FAULT_VALID_BITFIELD  = 1'h0;
localparam logic [ 2 : 1 ] GC_CR_CE_QUEUE0_MMU_FAULT_STATUS_FAULT_TYPE_BITFIELD  = 2'h0;
localparam logic [ 5 : 3 ] GC_CR_CE_QUEUE0_MMU_FAULT_STATUS_FAULT_LEVEL_BITFIELD  = 3'h0;
localparam logic [ 6 : 6 ] GC_CR_CE_QUEUE0_MMU_FAULT_STATUS_FAULT_SRC_BITFIELD  = 1'h0;
localparam logic [ 9 : 7 ] GC_CR_CE_QUEUE0_MMU_FAULT_STATUS_VFID_BITFIELD      = 3'h0;
localparam logic [ 19 : 10 ] GC_CR_CE_QUEUE0_MMU_FAULT_STATUS_PASID_BITFIELD   = 10'h0;
localparam logic [ 63 : 20 ] GC_CR_CE_QUEUE0_MMU_FAULT_STATUS_VADDRESS_BITFIELD  = 44'h0;

 // gc_cr_ce_queue0_priority
localparam logic [ 1 : 0 ] GC_CR_CE_QUEUE0_PRIORITY_PRIORITY_BITFIELD          = 2'h0;

 // gc_cr_ce_queue0_max_task
localparam logic [ 6 : 0 ] GC_CR_CE_QUEUE0_MAX_TASK_MAX_TASK_BITFIELD          = 7'h8;

 // gc_cr_ce_queue0_fence_wait_address
localparam logic [ 47 : 0 ] GC_CR_CE_QUEUE0_FENCE_WAIT_ADDRESS_ADDRESS_BITFIELD  = 48'h0;

 // gc_cr_ce_queue0_fence_wait_expected_value
localparam logic [ 63 : 0 ] GC_CR_CE_QUEUE0_FENCE_WAIT_EXPECTED_VALUE_VALUE_BITFIELD  = 64'h0;

 // gc_cr_ce_queue0_fence_wait_return_value
localparam logic [ 63 : 0 ] GC_CR_CE_QUEUE0_FENCE_WAIT_RETURN_VALUE_VALUE_BITFIELD  = 64'h0;

 // gc_cr_ce_queue0_fence_update_address
localparam logic [ 47 : 0 ] GC_CR_CE_QUEUE0_FENCE_UPDATE_ADDRESS_ADDRESS_BITFIELD  = 48'h0;

 // gc_cr_ce_queue0_if_idle_cnt
localparam logic [ 31 : 0 ] GC_CR_CE_QUEUE0_IF_IDLE_CNT_IDLE_CNT_BITFIELD      = 32'h0;

 // gc_cr_ce_queue0_rb_woff
localparam logic [ 29 : 2 ] GC_CR_CE_QUEUE0_RB_WOFF_WOFF_BITFIELD              = 28'h0;

 // gc_cr_ce_queue0_pim_error_status
localparam logic [ 63 : 0 ] GC_CR_CE_QUEUE0_PIM_ERROR_STATUS_ERROR_STATUS_BITFIELD  = 64'h0;

 // gc_cr_ce_queue1_mmu
localparam logic [ 9 : 0 ] GC_CR_CE_QUEUE1_MMU_PASID_BITFIELD                  = 10'h0;
localparam logic [ 19 : 16 ] GC_CR_CE_QUEUE1_MMU_VFID_OSID_BITFIELD            = 4'h0;

 // gc_cr_ce_queue1_start
localparam logic [ 0 : 0 ] GC_CR_CE_QUEUE1_START_PLUSE_BITFIELD                = 1'h0;
localparam logic [ 1 : 1 ] GC_CR_CE_QUEUE1_START_CONTEXT_RESUME_BITFIELD       = 1'h0;

 // gc_cr_ce_queue1_rb_base
localparam logic [ 47 : 6 ] GC_CR_CE_QUEUE1_RB_BASE_ADDR_BITFIELD              = 42'h0;

 // gc_cr_ce_queue1_rb
localparam logic [ 29 : 2 ] GC_CR_CE_QUEUE1_RB_WOFF_UPDATE_CTRL_BITFIELD       = 28'h20;
localparam logic [ 61 : 41 ] GC_CR_CE_QUEUE1_RB_SIZE_BITFIELD                  = 21'h20;

 // gc_cr_ce_queue1_rb_roff
localparam logic [ 29 : 2 ] GC_CR_CE_QUEUE1_RB_ROFF_OFFSET_BITFIELD            = 28'h0;

 // gc_cr_ce_queue1_rb_ctrl_base
localparam logic [ 47 : 3 ] GC_CR_CE_QUEUE1_RB_CTRL_BASE_ADDR_BITFIELD         = 45'h0;

 // gc_cr_ce_queue1_rb_roff_update_ctrl
localparam logic [ 29 : 2 ] GC_CR_CE_QUEUE1_RB_ROFF_UPDATE_CTRL_THRESHOLD_BITFIELD  = 28'h20;

 // gc_cr_ce_queue1_l2_policy
localparam logic [ 1 : 0 ] GC_CR_CE_QUEUE1_L2_POLICY_PERSISTENT_BITFIELD       = 2'h3;
localparam logic [ 2 : 2 ] GC_CR_CE_QUEUE1_L2_POLICY_RB_BITFIELD               = 1'h0;
localparam logic [ 3 : 3 ] GC_CR_CE_QUEUE1_L2_POLICY_IB_BITFIELD               = 1'h0;
localparam logic [ 4 : 4 ] GC_CR_CE_QUEUE1_L2_POLICY_FENCE_BITFIELD            = 1'h0;
localparam logic [ 5 : 5 ] GC_CR_CE_QUEUE1_L2_POLICY_OFFSET_BITFIELD           = 1'h0;

 // gc_cr_ce_queue1_error_status
localparam logic [ 1 : 0 ] GC_CR_CE_QUEUE1_ERROR_STATUS_AXI_READ_RSP_BITFIELD  = 2'h0;
localparam logic [ 2 : 2 ] GC_CR_CE_QUEUE1_ERROR_STATUS_RAW_READ_BITFIELD      = 1'h0;
localparam logic [ 5 : 4 ] GC_CR_CE_QUEUE1_ERROR_STATUS_AXI_WRITE_RSP_BITFIELD  = 2'h0;

 // gc_cr_ce_queue1_context_store_base
localparam logic [ 47 : 4 ] GC_CR_CE_QUEUE1_CONTEXT_STORE_BASE_ADDR_BITFIELD   = 44'h0;

 // gc_cr_ce_queue1_cs_status
localparam logic [ 0 : 0 ] GC_CR_CE_QUEUE1_CS_STATUS_STATUS_BITFIELD           = 1'h0;

 // gc_cr_ce_queue1
localparam logic [ 0 : 0 ] GC_CR_CE_QUEUE1_CONTINUE_BITFIELD                   = 1'h0;
localparam logic [ 1 : 1 ] GC_CR_CE_QUEUE1_CONTEXT_STORE_BITFIELD              = 1'h0;

 // gc_cr_ce_queue1_fence
localparam logic [ 15 : 0 ] GC_CR_CE_QUEUE1_FENCE_POLL_CTRL_BITFIELD           = 16'h804;

 // gc_cr_ce_queue1_ace_qos
localparam logic [ 3 : 0 ] GC_CR_CE_QUEUE1_ACE_QOS_CTRL_BITFIELD               = 4'h0;

 // gc_cr_ce_queue1_local_event
localparam logic [ 0 : 0 ] GC_CR_CE_QUEUE1_LOCAL_EVENT_COMPLETE_BITFIELD       = 1'h0;
localparam logic [ 1 : 1 ] GC_CR_CE_QUEUE1_LOCAL_EVENT_SIGNAL_WAIT_FAIL_BITFIELD  = 1'h0;
localparam logic [ 2 : 2 ] GC_CR_CE_QUEUE1_LOCAL_EVENT_STALL_BITFIELD          = 1'h0;
localparam logic [ 3 : 3 ] GC_CR_CE_QUEUE1_LOCAL_EVENT_EXCEPTION_AND_QUEUE_ERR_BITFIELD  = 1'h0;
localparam logic [ 4 : 4 ] GC_CR_CE_QUEUE1_LOCAL_EVENT_FENCE_INTERRUPT_BITFIELD  = 1'h0;
localparam logic [ 5 : 5 ] GC_CR_CE_QUEUE1_LOCAL_EVENT_PAGE_FAULT_BITFIELD     = 1'h0;
localparam logic [ 6 : 6 ] GC_CR_CE_QUEUE1_LOCAL_EVENT_AXI_RESP_ERR_BITFIELD   = 1'h0;
localparam logic [ 7 : 7 ] GC_CR_CE_QUEUE1_LOCAL_EVENT_PIM_ERROR_FOUND_BITFIELD  = 1'h0;

 // gc_cr_ce_queue1_local_event_enable
localparam logic [ 7 : 0 ] GC_CR_CE_QUEUE1_LOCAL_EVENT_ENABLE_ENABLE_BITFIELD  = 8'hff;

 // gc_cr_ce_queue1_local_event_clear
localparam logic [ 7 : 0 ] GC_CR_CE_QUEUE1_LOCAL_EVENT_CLEAR_CLEAR_BITFIELD    = 8'h0;

 // gc_cr_ce_queue1_mmu_fault_status
localparam logic [ 0 : 0 ] GC_CR_CE_QUEUE1_MMU_FAULT_STATUS_FAULT_VALID_BITFIELD  = 1'h0;
localparam logic [ 2 : 1 ] GC_CR_CE_QUEUE1_MMU_FAULT_STATUS_FAULT_TYPE_BITFIELD  = 2'h0;
localparam logic [ 5 : 3 ] GC_CR_CE_QUEUE1_MMU_FAULT_STATUS_FAULT_LEVEL_BITFIELD  = 3'h0;
localparam logic [ 6 : 6 ] GC_CR_CE_QUEUE1_MMU_FAULT_STATUS_FAULT_SRC_BITFIELD  = 1'h0;
localparam logic [ 9 : 7 ] GC_CR_CE_QUEUE1_MMU_FAULT_STATUS_VFID_BITFIELD      = 3'h0;
localparam logic [ 19 : 10 ] GC_CR_CE_QUEUE1_MMU_FAULT_STATUS_PASID_BITFIELD   = 10'h0;
localparam logic [ 63 : 20 ] GC_CR_CE_QUEUE1_MMU_FAULT_STATUS_VADDRESS_BITFIELD  = 44'h0;

 // gc_cr_ce_queue1_priority
localparam logic [ 1 : 0 ] GC_CR_CE_QUEUE1_PRIORITY_PRIORITY_BITFIELD          = 2'h0;

 // gc_cr_ce_queue1_max_task
localparam logic [ 6 : 0 ] GC_CR_CE_QUEUE1_MAX_TASK_MAX_TASK_BITFIELD          = 7'h8;

 // gc_cr_ce_queue1_fence_wait_address
localparam logic [ 47 : 0 ] GC_CR_CE_QUEUE1_FENCE_WAIT_ADDRESS_ADDRESS_BITFIELD  = 48'h0;

 // gc_cr_ce_queue1_fence_wait_expected_value
localparam logic [ 63 : 0 ] GC_CR_CE_QUEUE1_FENCE_WAIT_EXPECTED_VALUE_VALUE_BITFIELD  = 64'h0;

 // gc_cr_ce_queue1_fence_wait_return_value
localparam logic [ 63 : 0 ] GC_CR_CE_QUEUE1_FENCE_WAIT_RETURN_VALUE_VALUE_BITFIELD  = 64'h0;

 // gc_cr_ce_queue1_fence_update_address
localparam logic [ 47 : 0 ] GC_CR_CE_QUEUE1_FENCE_UPDATE_ADDRESS_ADDRESS_BITFIELD  = 48'h0;

 // gc_cr_ce_queue1_if_idle_cnt
localparam logic [ 31 : 0 ] GC_CR_CE_QUEUE1_IF_IDLE_CNT_IDLE_CNT_BITFIELD      = 32'h0;

 // gc_cr_ce_queue1_rb_woff
localparam logic [ 29 : 2 ] GC_CR_CE_QUEUE1_RB_WOFF_WOFF_BITFIELD              = 28'h0;

 // gc_cr_ce_queue1_pim_error_status
localparam logic [ 63 : 0 ] GC_CR_CE_QUEUE1_PIM_ERROR_STATUS_ERROR_STATUS_BITFIELD  = 64'h0;

 // gc_cr_ce_queue2_mmu
localparam logic [ 9 : 0 ] GC_CR_CE_QUEUE2_MMU_PASID_BITFIELD                  = 10'h0;
localparam logic [ 19 : 16 ] GC_CR_CE_QUEUE2_MMU_VFID_OSID_BITFIELD            = 4'h0;

 // gc_cr_ce_queue2_start
localparam logic [ 0 : 0 ] GC_CR_CE_QUEUE2_START_PLUSE_BITFIELD                = 1'h0;
localparam logic [ 1 : 1 ] GC_CR_CE_QUEUE2_START_CONTEXT_RESUME_BITFIELD       = 1'h0;

 // gc_cr_ce_queue2_rb_base
localparam logic [ 47 : 6 ] GC_CR_CE_QUEUE2_RB_BASE_ADDR_BITFIELD              = 42'h0;

 // gc_cr_ce_queue2_rb
localparam logic [ 29 : 2 ] GC_CR_CE_QUEUE2_RB_WOFF_UPDATE_CTRL_BITFIELD       = 28'h20;
localparam logic [ 61 : 41 ] GC_CR_CE_QUEUE2_RB_SIZE_BITFIELD                  = 21'h20;

 // gc_cr_ce_queue2_rb_roff
localparam logic [ 29 : 2 ] GC_CR_CE_QUEUE2_RB_ROFF_OFFSET_BITFIELD            = 28'h0;

 // gc_cr_ce_queue2_rb_ctrl_base
localparam logic [ 47 : 3 ] GC_CR_CE_QUEUE2_RB_CTRL_BASE_ADDR_BITFIELD         = 45'h0;

 // gc_cr_ce_queue2_rb_roff_update_ctrl
localparam logic [ 29 : 2 ] GC_CR_CE_QUEUE2_RB_ROFF_UPDATE_CTRL_THRESHOLD_BITFIELD  = 28'h20;

 // gc_cr_ce_queue2_l2_policy
localparam logic [ 1 : 0 ] GC_CR_CE_QUEUE2_L2_POLICY_PERSISTENT_BITFIELD       = 2'h3;
localparam logic [ 2 : 2 ] GC_CR_CE_QUEUE2_L2_POLICY_RB_BITFIELD               = 1'h0;
localparam logic [ 3 : 3 ] GC_CR_CE_QUEUE2_L2_POLICY_IB_BITFIELD               = 1'h0;
localparam logic [ 4 : 4 ] GC_CR_CE_QUEUE2_L2_POLICY_FENCE_BITFIELD            = 1'h0;
localparam logic [ 5 : 5 ] GC_CR_CE_QUEUE2_L2_POLICY_OFFSET_BITFIELD           = 1'h0;

 // gc_cr_ce_queue2_error_status
localparam logic [ 1 : 0 ] GC_CR_CE_QUEUE2_ERROR_STATUS_AXI_READ_RSP_BITFIELD  = 2'h0;
localparam logic [ 2 : 2 ] GC_CR_CE_QUEUE2_ERROR_STATUS_RAW_READ_BITFIELD      = 1'h0;
localparam logic [ 5 : 4 ] GC_CR_CE_QUEUE2_ERROR_STATUS_AXI_WRITE_RSP_BITFIELD  = 2'h0;

 // gc_cr_ce_queue2_context_store_base
localparam logic [ 47 : 4 ] GC_CR_CE_QUEUE2_CONTEXT_STORE_BASE_ADDR_BITFIELD   = 44'h0;

 // gc_cr_ce_queue2_cs_status
localparam logic [ 0 : 0 ] GC_CR_CE_QUEUE2_CS_STATUS_STATUS_BITFIELD           = 1'h0;

 // gc_cr_ce_queue2
localparam logic [ 0 : 0 ] GC_CR_CE_QUEUE2_CONTINUE_BITFIELD                   = 1'h0;
localparam logic [ 1 : 1 ] GC_CR_CE_QUEUE2_CONTEXT_STORE_BITFIELD              = 1'h0;

 // gc_cr_ce_queue2_fence
localparam logic [ 15 : 0 ] GC_CR_CE_QUEUE2_FENCE_POLL_CTRL_BITFIELD           = 16'h804;

 // gc_cr_ce_queue2_ace_qos
localparam logic [ 3 : 0 ] GC_CR_CE_QUEUE2_ACE_QOS_CTRL_BITFIELD               = 4'h0;

 // gc_cr_ce_queue2_local_event
localparam logic [ 0 : 0 ] GC_CR_CE_QUEUE2_LOCAL_EVENT_COMPLETE_BITFIELD       = 1'h0;
localparam logic [ 1 : 1 ] GC_CR_CE_QUEUE2_LOCAL_EVENT_SIGNAL_WAIT_FAIL_BITFIELD  = 1'h0;
localparam logic [ 2 : 2 ] GC_CR_CE_QUEUE2_LOCAL_EVENT_STALL_BITFIELD          = 1'h0;
localparam logic [ 3 : 3 ] GC_CR_CE_QUEUE2_LOCAL_EVENT_EXCEPTION_AND_QUEUE_ERR_BITFIELD  = 1'h0;
localparam logic [ 4 : 4 ] GC_CR_CE_QUEUE2_LOCAL_EVENT_FENCE_INTERRUPT_BITFIELD  = 1'h0;
localparam logic [ 5 : 5 ] GC_CR_CE_QUEUE2_LOCAL_EVENT_PAGE_FAULT_BITFIELD     = 1'h0;
localparam logic [ 6 : 6 ] GC_CR_CE_QUEUE2_LOCAL_EVENT_AXI_RESP_ERR_BITFIELD   = 1'h0;
localparam logic [ 7 : 7 ] GC_CR_CE_QUEUE2_LOCAL_EVENT_PIM_ERROR_FOUND_BITFIELD  = 1'h0;

 // gc_cr_ce_queue2_local_event_enable
localparam logic [ 7 : 0 ] GC_CR_CE_QUEUE2_LOCAL_EVENT_ENABLE_ENABLE_BITFIELD  = 8'hff;

 // gc_cr_ce_queue2_local_event_clear
localparam logic [ 7 : 0 ] GC_CR_CE_QUEUE2_LOCAL_EVENT_CLEAR_CLEAR_BITFIELD    = 8'h0;

 // gc_cr_ce_queue2_mmu_fault_status
localparam logic [ 0 : 0 ] GC_CR_CE_QUEUE2_MMU_FAULT_STATUS_FAULT_VALID_BITFIELD  = 1'h0;
localparam logic [ 2 : 1 ] GC_CR_CE_QUEUE2_MMU_FAULT_STATUS_FAULT_TYPE_BITFIELD  = 2'h0;
localparam logic [ 5 : 3 ] GC_CR_CE_QUEUE2_MMU_FAULT_STATUS_FAULT_LEVEL_BITFIELD  = 3'h0;
localparam logic [ 6 : 6 ] GC_CR_CE_QUEUE2_MMU_FAULT_STATUS_FAULT_SRC_BITFIELD  = 1'h0;
localparam logic [ 9 : 7 ] GC_CR_CE_QUEUE2_MMU_FAULT_STATUS_VFID_BITFIELD      = 3'h0;
localparam logic [ 19 : 10 ] GC_CR_CE_QUEUE2_MMU_FAULT_STATUS_PASID_BITFIELD   = 10'h0;
localparam logic [ 63 : 20 ] GC_CR_CE_QUEUE2_MMU_FAULT_STATUS_VADDRESS_BITFIELD  = 44'h0;

 // gc_cr_ce_queue2_priority
localparam logic [ 1 : 0 ] GC_CR_CE_QUEUE2_PRIORITY_PRIORITY_BITFIELD          = 2'h0;

 // gc_cr_ce_queue2_max_task
localparam logic [ 6 : 0 ] GC_CR_CE_QUEUE2_MAX_TASK_MAX_TASK_BITFIELD          = 7'h8;

 // gc_cr_ce_queue2_fence_wait_address
localparam logic [ 47 : 0 ] GC_CR_CE_QUEUE2_FENCE_WAIT_ADDRESS_ADDRESS_BITFIELD  = 48'h0;

 // gc_cr_ce_queue2_fence_wait_expected_value
localparam logic [ 63 : 0 ] GC_CR_CE_QUEUE2_FENCE_WAIT_EXPECTED_VALUE_VALUE_BITFIELD  = 64'h0;

 // gc_cr_ce_queue2_fence_wait_return_value
localparam logic [ 63 : 0 ] GC_CR_CE_QUEUE2_FENCE_WAIT_RETURN_VALUE_VALUE_BITFIELD  = 64'h0;

 // gc_cr_ce_queue2_fence_update_address
localparam logic [ 47 : 0 ] GC_CR_CE_QUEUE2_FENCE_UPDATE_ADDRESS_ADDRESS_BITFIELD  = 48'h0;

 // gc_cr_ce_queue2_if_idle_cnt
localparam logic [ 31 : 0 ] GC_CR_CE_QUEUE2_IF_IDLE_CNT_IDLE_CNT_BITFIELD      = 32'h0;

 // gc_cr_ce_queue2_rb_woff
localparam logic [ 29 : 2 ] GC_CR_CE_QUEUE2_RB_WOFF_WOFF_BITFIELD              = 28'h0;

 // gc_cr_ce_queue2_pim_error_status
localparam logic [ 63 : 0 ] GC_CR_CE_QUEUE2_PIM_ERROR_STATUS_ERROR_STATUS_BITFIELD  = 64'h0;

 // gc_cr_ce_queue3_mmu
localparam logic [ 9 : 0 ] GC_CR_CE_QUEUE3_MMU_PASID_BITFIELD                  = 10'h0;
localparam logic [ 19 : 16 ] GC_CR_CE_QUEUE3_MMU_VFID_OSID_BITFIELD            = 4'h0;

 // gc_cr_ce_queue3_start
localparam logic [ 0 : 0 ] GC_CR_CE_QUEUE3_START_PLUSE_BITFIELD                = 1'h0;
localparam logic [ 1 : 1 ] GC_CR_CE_QUEUE3_START_CONTEXT_RESUME_BITFIELD       = 1'h0;

 // gc_cr_ce_queue3_rb_base
localparam logic [ 47 : 6 ] GC_CR_CE_QUEUE3_RB_BASE_ADDR_BITFIELD              = 42'h0;

 // gc_cr_ce_queue3_rb
localparam logic [ 29 : 2 ] GC_CR_CE_QUEUE3_RB_WOFF_UPDATE_CTRL_BITFIELD       = 28'h20;
localparam logic [ 61 : 41 ] GC_CR_CE_QUEUE3_RB_SIZE_BITFIELD                  = 21'h20;

 // gc_cr_ce_queue3_rb_roff
localparam logic [ 29 : 2 ] GC_CR_CE_QUEUE3_RB_ROFF_OFFSET_BITFIELD            = 28'h0;

 // gc_cr_ce_queue3_rb_ctrl_base
localparam logic [ 47 : 3 ] GC_CR_CE_QUEUE3_RB_CTRL_BASE_ADDR_BITFIELD         = 45'h0;

 // gc_cr_ce_queue3_rb_roff_update_ctrl
localparam logic [ 29 : 2 ] GC_CR_CE_QUEUE3_RB_ROFF_UPDATE_CTRL_THRESHOLD_BITFIELD  = 28'h20;

 // gc_cr_ce_queue3_l2_policy
localparam logic [ 1 : 0 ] GC_CR_CE_QUEUE3_L2_POLICY_PERSISTENT_BITFIELD       = 2'h3;
localparam logic [ 2 : 2 ] GC_CR_CE_QUEUE3_L2_POLICY_RB_BITFIELD               = 1'h0;
localparam logic [ 3 : 3 ] GC_CR_CE_QUEUE3_L2_POLICY_IB_BITFIELD               = 1'h0;
localparam logic [ 4 : 4 ] GC_CR_CE_QUEUE3_L2_POLICY_FENCE_BITFIELD            = 1'h0;
localparam logic [ 5 : 5 ] GC_CR_CE_QUEUE3_L2_POLICY_OFFSET_BITFIELD           = 1'h0;

 // gc_cr_ce_queue3_error_status
localparam logic [ 1 : 0 ] GC_CR_CE_QUEUE3_ERROR_STATUS_AXI_READ_RSP_BITFIELD  = 2'h0;
localparam logic [ 2 : 2 ] GC_CR_CE_QUEUE3_ERROR_STATUS_RAW_READ_BITFIELD      = 1'h0;
localparam logic [ 5 : 4 ] GC_CR_CE_QUEUE3_ERROR_STATUS_AXI_WRITE_RSP_BITFIELD  = 2'h0;

 // gc_cr_ce_queue3_context_store_base
localparam logic [ 47 : 4 ] GC_CR_CE_QUEUE3_CONTEXT_STORE_BASE_ADDR_BITFIELD   = 44'h0;

 // gc_cr_ce_queue3_cs_status
localparam logic [ 0 : 0 ] GC_CR_CE_QUEUE3_CS_STATUS_STATUS_BITFIELD           = 1'h0;

 // gc_cr_ce_queue3
localparam logic [ 0 : 0 ] GC_CR_CE_QUEUE3_CONTINUE_BITFIELD                   = 1'h0;
localparam logic [ 1 : 1 ] GC_CR_CE_QUEUE3_CONTEXT_STORE_BITFIELD              = 1'h0;

 // gc_cr_ce_queue3_fence
localparam logic [ 15 : 0 ] GC_CR_CE_QUEUE3_FENCE_POLL_CTRL_BITFIELD           = 16'h804;

 // gc_cr_ce_queue3_ace_qos
localparam logic [ 3 : 0 ] GC_CR_CE_QUEUE3_ACE_QOS_CTRL_BITFIELD               = 4'h0;

 // gc_cr_ce_queue3_local_event
localparam logic [ 0 : 0 ] GC_CR_CE_QUEUE3_LOCAL_EVENT_COMPLETE_BITFIELD       = 1'h0;
localparam logic [ 1 : 1 ] GC_CR_CE_QUEUE3_LOCAL_EVENT_SIGNAL_WAIT_FAIL_BITFIELD  = 1'h0;
localparam logic [ 2 : 2 ] GC_CR_CE_QUEUE3_LOCAL_EVENT_STALL_BITFIELD          = 1'h0;
localparam logic [ 3 : 3 ] GC_CR_CE_QUEUE3_LOCAL_EVENT_EXCEPTION_AND_QUEUE_ERR_BITFIELD  = 1'h0;
localparam logic [ 4 : 4 ] GC_CR_CE_QUEUE3_LOCAL_EVENT_FENCE_INTERRUPT_BITFIELD  = 1'h0;
localparam logic [ 5 : 5 ] GC_CR_CE_QUEUE3_LOCAL_EVENT_PAGE_FAULT_BITFIELD     = 1'h0;
localparam logic [ 6 : 6 ] GC_CR_CE_QUEUE3_LOCAL_EVENT_AXI_RESP_ERR_BITFIELD   = 1'h0;
localparam logic [ 7 : 7 ] GC_CR_CE_QUEUE3_LOCAL_EVENT_PIM_ERROR_FOUND_BITFIELD  = 1'h0;

 // gc_cr_ce_queue3_local_event_enable
localparam logic [ 7 : 0 ] GC_CR_CE_QUEUE3_LOCAL_EVENT_ENABLE_ENABLE_BITFIELD  = 8'hff;

 // gc_cr_ce_queue3_local_event_clear
localparam logic [ 7 : 0 ] GC_CR_CE_QUEUE3_LOCAL_EVENT_CLEAR_CLEAR_BITFIELD    = 8'h0;

 // gc_cr_ce_queue3_mmu_fault_status
localparam logic [ 0 : 0 ] GC_CR_CE_QUEUE3_MMU_FAULT_STATUS_FAULT_VALID_BITFIELD  = 1'h0;
localparam logic [ 2 : 1 ] GC_CR_CE_QUEUE3_MMU_FAULT_STATUS_FAULT_TYPE_BITFIELD  = 2'h0;
localparam logic [ 5 : 3 ] GC_CR_CE_QUEUE3_MMU_FAULT_STATUS_FAULT_LEVEL_BITFIELD  = 3'h0;
localparam logic [ 6 : 6 ] GC_CR_CE_QUEUE3_MMU_FAULT_STATUS_FAULT_SRC_BITFIELD  = 1'h0;
localparam logic [ 9 : 7 ] GC_CR_CE_QUEUE3_MMU_FAULT_STATUS_VFID_BITFIELD      = 3'h0;
localparam logic [ 19 : 10 ] GC_CR_CE_QUEUE3_MMU_FAULT_STATUS_PASID_BITFIELD   = 10'h0;
localparam logic [ 63 : 20 ] GC_CR_CE_QUEUE3_MMU_FAULT_STATUS_VADDRESS_BITFIELD  = 44'h0;

 // gc_cr_ce_queue3_priority
localparam logic [ 1 : 0 ] GC_CR_CE_QUEUE3_PRIORITY_PRIORITY_BITFIELD          = 2'h0;

 // gc_cr_ce_queue3_max_task
localparam logic [ 6 : 0 ] GC_CR_CE_QUEUE3_MAX_TASK_MAX_TASK_BITFIELD          = 7'h8;

 // gc_cr_ce_queue3_fence_wait_address
localparam logic [ 47 : 0 ] GC_CR_CE_QUEUE3_FENCE_WAIT_ADDRESS_ADDRESS_BITFIELD  = 48'h0;

 // gc_cr_ce_queue3_fence_wait_expected_value
localparam logic [ 63 : 0 ] GC_CR_CE_QUEUE3_FENCE_WAIT_EXPECTED_VALUE_VALUE_BITFIELD  = 64'h0;

 // gc_cr_ce_queue3_fence_wait_return_value
localparam logic [ 63 : 0 ] GC_CR_CE_QUEUE3_FENCE_WAIT_RETURN_VALUE_VALUE_BITFIELD  = 64'h0;

 // gc_cr_ce_queue3_fence_update_address
localparam logic [ 47 : 0 ] GC_CR_CE_QUEUE3_FENCE_UPDATE_ADDRESS_ADDRESS_BITFIELD  = 48'h0;

 // gc_cr_ce_queue3_if_idle_cnt
localparam logic [ 31 : 0 ] GC_CR_CE_QUEUE3_IF_IDLE_CNT_IDLE_CNT_BITFIELD      = 32'h0;

 // gc_cr_ce_queue3_rb_woff
localparam logic [ 29 : 2 ] GC_CR_CE_QUEUE3_RB_WOFF_WOFF_BITFIELD              = 28'h0;

 // gc_cr_ce_queue3_pim_error_status
localparam logic [ 63 : 0 ] GC_CR_CE_QUEUE3_PIM_ERROR_STATUS_ERROR_STATUS_BITFIELD  = 64'h0;

 // gc_cr_ce_queue4_mmu
localparam logic [ 9 : 0 ] GC_CR_CE_QUEUE4_MMU_PASID_BITFIELD                  = 10'h0;
localparam logic [ 19 : 16 ] GC_CR_CE_QUEUE4_MMU_VFID_OSID_BITFIELD            = 4'h0;

 // gc_cr_ce_queue4_start
localparam logic [ 0 : 0 ] GC_CR_CE_QUEUE4_START_PLUSE_BITFIELD                = 1'h0;
localparam logic [ 1 : 1 ] GC_CR_CE_QUEUE4_START_CONTEXT_RESUME_BITFIELD       = 1'h0;

 // gc_cr_ce_queue4_rb_base
localparam logic [ 47 : 6 ] GC_CR_CE_QUEUE4_RB_BASE_ADDR_BITFIELD              = 42'h0;

 // gc_cr_ce_queue4_rb
localparam logic [ 29 : 2 ] GC_CR_CE_QUEUE4_RB_WOFF_UPDATE_CTRL_BITFIELD       = 28'h20;
localparam logic [ 61 : 41 ] GC_CR_CE_QUEUE4_RB_SIZE_BITFIELD                  = 21'h20;

 // gc_cr_ce_queue4_rb_roff
localparam logic [ 29 : 2 ] GC_CR_CE_QUEUE4_RB_ROFF_OFFSET_BITFIELD            = 28'h0;

 // gc_cr_ce_queue4_rb_ctrl_base
localparam logic [ 47 : 3 ] GC_CR_CE_QUEUE4_RB_CTRL_BASE_ADDR_BITFIELD         = 45'h0;

 // gc_cr_ce_queue4_rb_roff_update_ctrl
localparam logic [ 29 : 2 ] GC_CR_CE_QUEUE4_RB_ROFF_UPDATE_CTRL_THRESHOLD_BITFIELD  = 28'h20;

 // gc_cr_ce_queue4_l2_policy
localparam logic [ 1 : 0 ] GC_CR_CE_QUEUE4_L2_POLICY_PERSISTENT_BITFIELD       = 2'h3;
localparam logic [ 2 : 2 ] GC_CR_CE_QUEUE4_L2_POLICY_RB_BITFIELD               = 1'h0;
localparam logic [ 3 : 3 ] GC_CR_CE_QUEUE4_L2_POLICY_IB_BITFIELD               = 1'h0;
localparam logic [ 4 : 4 ] GC_CR_CE_QUEUE4_L2_POLICY_FENCE_BITFIELD            = 1'h0;
localparam logic [ 5 : 5 ] GC_CR_CE_QUEUE4_L2_POLICY_OFFSET_BITFIELD           = 1'h0;

 // gc_cr_ce_queue4_error_status
localparam logic [ 1 : 0 ] GC_CR_CE_QUEUE4_ERROR_STATUS_AXI_READ_RSP_BITFIELD  = 2'h0;
localparam logic [ 2 : 2 ] GC_CR_CE_QUEUE4_ERROR_STATUS_RAW_READ_BITFIELD      = 1'h0;
localparam logic [ 5 : 4 ] GC_CR_CE_QUEUE4_ERROR_STATUS_AXI_WRITE_RSP_BITFIELD  = 2'h0;

 // gc_cr_ce_queue4_context_store_base
localparam logic [ 47 : 4 ] GC_CR_CE_QUEUE4_CONTEXT_STORE_BASE_ADDR_BITFIELD   = 44'h0;

 // gc_cr_ce_queue4_cs_status
localparam logic [ 0 : 0 ] GC_CR_CE_QUEUE4_CS_STATUS_STATUS_BITFIELD           = 1'h0;

 // gc_cr_ce_queue4
localparam logic [ 0 : 0 ] GC_CR_CE_QUEUE4_CONTINUE_BITFIELD                   = 1'h0;
localparam logic [ 1 : 1 ] GC_CR_CE_QUEUE4_CONTEXT_STORE_BITFIELD              = 1'h0;

 // gc_cr_ce_queue4_fence
localparam logic [ 15 : 0 ] GC_CR_CE_QUEUE4_FENCE_POLL_CTRL_BITFIELD           = 16'h804;

 // gc_cr_ce_queue4_ace_qos
localparam logic [ 3 : 0 ] GC_CR_CE_QUEUE4_ACE_QOS_CTRL_BITFIELD               = 4'h0;

 // gc_cr_ce_queue4_local_event
localparam logic [ 0 : 0 ] GC_CR_CE_QUEUE4_LOCAL_EVENT_COMPLETE_BITFIELD       = 1'h0;
localparam logic [ 1 : 1 ] GC_CR_CE_QUEUE4_LOCAL_EVENT_SIGNAL_WAIT_FAIL_BITFIELD  = 1'h0;
localparam logic [ 2 : 2 ] GC_CR_CE_QUEUE4_LOCAL_EVENT_STALL_BITFIELD          = 1'h0;
localparam logic [ 3 : 3 ] GC_CR_CE_QUEUE4_LOCAL_EVENT_EXCEPTION_AND_QUEUE_ERR_BITFIELD  = 1'h0;
localparam logic [ 4 : 4 ] GC_CR_CE_QUEUE4_LOCAL_EVENT_FENCE_INTERRUPT_BITFIELD  = 1'h0;
localparam logic [ 5 : 5 ] GC_CR_CE_QUEUE4_LOCAL_EVENT_PAGE_FAULT_BITFIELD     = 1'h0;
localparam logic [ 6 : 6 ] GC_CR_CE_QUEUE4_LOCAL_EVENT_AXI_RESP_ERR_BITFIELD   = 1'h0;
localparam logic [ 7 : 7 ] GC_CR_CE_QUEUE4_LOCAL_EVENT_PIM_ERROR_FOUND_BITFIELD  = 1'h0;

 // gc_cr_ce_queue4_local_event_enable
localparam logic [ 7 : 0 ] GC_CR_CE_QUEUE4_LOCAL_EVENT_ENABLE_ENABLE_BITFIELD  = 8'hff;

 // gc_cr_ce_queue4_local_event_clear
localparam logic [ 7 : 0 ] GC_CR_CE_QUEUE4_LOCAL_EVENT_CLEAR_CLEAR_BITFIELD    = 8'h0;

 // gc_cr_ce_queue4_mmu_fault_status
localparam logic [ 0 : 0 ] GC_CR_CE_QUEUE4_MMU_FAULT_STATUS_FAULT_VALID_BITFIELD  = 1'h0;
localparam logic [ 2 : 1 ] GC_CR_CE_QUEUE4_MMU_FAULT_STATUS_FAULT_TYPE_BITFIELD  = 2'h0;
localparam logic [ 5 : 3 ] GC_CR_CE_QUEUE4_MMU_FAULT_STATUS_FAULT_LEVEL_BITFIELD  = 3'h0;
localparam logic [ 6 : 6 ] GC_CR_CE_QUEUE4_MMU_FAULT_STATUS_FAULT_SRC_BITFIELD  = 1'h0;
localparam logic [ 9 : 7 ] GC_CR_CE_QUEUE4_MMU_FAULT_STATUS_VFID_BITFIELD      = 3'h0;
localparam logic [ 19 : 10 ] GC_CR_CE_QUEUE4_MMU_FAULT_STATUS_PASID_BITFIELD   = 10'h0;
localparam logic [ 63 : 20 ] GC_CR_CE_QUEUE4_MMU_FAULT_STATUS_VADDRESS_BITFIELD  = 44'h0;

 // gc_cr_ce_queue4_priority
localparam logic [ 1 : 0 ] GC_CR_CE_QUEUE4_PRIORITY_PRIORITY_BITFIELD          = 2'h0;

 // gc_cr_ce_queue4_max_task
localparam logic [ 6 : 0 ] GC_CR_CE_QUEUE4_MAX_TASK_MAX_TASK_BITFIELD          = 7'h8;

 // gc_cr_ce_queue4_fence_wait_address
localparam logic [ 47 : 0 ] GC_CR_CE_QUEUE4_FENCE_WAIT_ADDRESS_ADDRESS_BITFIELD  = 48'h0;

 // gc_cr_ce_queue4_fence_wait_expected_value
localparam logic [ 63 : 0 ] GC_CR_CE_QUEUE4_FENCE_WAIT_EXPECTED_VALUE_VALUE_BITFIELD  = 64'h0;

 // gc_cr_ce_queue4_fence_wait_return_value
localparam logic [ 63 : 0 ] GC_CR_CE_QUEUE4_FENCE_WAIT_RETURN_VALUE_VALUE_BITFIELD  = 64'h0;

 // gc_cr_ce_queue4_fence_update_address
localparam logic [ 47 : 0 ] GC_CR_CE_QUEUE4_FENCE_UPDATE_ADDRESS_ADDRESS_BITFIELD  = 48'h0;

 // gc_cr_ce_queue4_if_idle_cnt
localparam logic [ 31 : 0 ] GC_CR_CE_QUEUE4_IF_IDLE_CNT_IDLE_CNT_BITFIELD      = 32'h0;

 // gc_cr_ce_queue4_rb_woff
localparam logic [ 29 : 2 ] GC_CR_CE_QUEUE4_RB_WOFF_WOFF_BITFIELD              = 28'h0;

 // gc_cr_ce_queue4_pim_error_status
localparam logic [ 63 : 0 ] GC_CR_CE_QUEUE4_PIM_ERROR_STATUS_ERROR_STATUS_BITFIELD  = 64'h0;

 // gc_cr_ce_queue5_mmu
localparam logic [ 9 : 0 ] GC_CR_CE_QUEUE5_MMU_PASID_BITFIELD                  = 10'h0;
localparam logic [ 19 : 16 ] GC_CR_CE_QUEUE5_MMU_VFID_OSID_BITFIELD            = 4'h0;

 // gc_cr_ce_queue5_start
localparam logic [ 0 : 0 ] GC_CR_CE_QUEUE5_START_PLUSE_BITFIELD                = 1'h0;
localparam logic [ 1 : 1 ] GC_CR_CE_QUEUE5_START_CONTEXT_RESUME_BITFIELD       = 1'h0;

 // gc_cr_ce_queue5_rb_base
localparam logic [ 47 : 6 ] GC_CR_CE_QUEUE5_RB_BASE_ADDR_BITFIELD              = 42'h0;

 // gc_cr_ce_queue5_rb
localparam logic [ 29 : 2 ] GC_CR_CE_QUEUE5_RB_WOFF_UPDATE_CTRL_BITFIELD       = 28'h20;
localparam logic [ 61 : 41 ] GC_CR_CE_QUEUE5_RB_SIZE_BITFIELD                  = 21'h20;

 // gc_cr_ce_queue5_rb_roff
localparam logic [ 29 : 2 ] GC_CR_CE_QUEUE5_RB_ROFF_OFFSET_BITFIELD            = 28'h0;

 // gc_cr_ce_queue5_rb_ctrl_base
localparam logic [ 47 : 3 ] GC_CR_CE_QUEUE5_RB_CTRL_BASE_ADDR_BITFIELD         = 45'h0;

 // gc_cr_ce_queue5_rb_roff_update_ctrl
localparam logic [ 29 : 2 ] GC_CR_CE_QUEUE5_RB_ROFF_UPDATE_CTRL_THRESHOLD_BITFIELD  = 28'h20;

 // gc_cr_ce_queue5_l2_policy
localparam logic [ 1 : 0 ] GC_CR_CE_QUEUE5_L2_POLICY_PERSISTENT_BITFIELD       = 2'h3;
localparam logic [ 2 : 2 ] GC_CR_CE_QUEUE5_L2_POLICY_RB_BITFIELD               = 1'h0;
localparam logic [ 3 : 3 ] GC_CR_CE_QUEUE5_L2_POLICY_IB_BITFIELD               = 1'h0;
localparam logic [ 4 : 4 ] GC_CR_CE_QUEUE5_L2_POLICY_FENCE_BITFIELD            = 1'h0;
localparam logic [ 5 : 5 ] GC_CR_CE_QUEUE5_L2_POLICY_OFFSET_BITFIELD           = 1'h0;

 // gc_cr_ce_queue5_error_status
localparam logic [ 1 : 0 ] GC_CR_CE_QUEUE5_ERROR_STATUS_AXI_READ_RSP_BITFIELD  = 2'h0;
localparam logic [ 2 : 2 ] GC_CR_CE_QUEUE5_ERROR_STATUS_RAW_READ_BITFIELD      = 1'h0;
localparam logic [ 5 : 4 ] GC_CR_CE_QUEUE5_ERROR_STATUS_AXI_WRITE_RSP_BITFIELD  = 2'h0;

 // gc_cr_ce_queue5_context_store_base
localparam logic [ 47 : 4 ] GC_CR_CE_QUEUE5_CONTEXT_STORE_BASE_ADDR_BITFIELD   = 44'h0;

 // gc_cr_ce_queue5_cs_status
localparam logic [ 0 : 0 ] GC_CR_CE_QUEUE5_CS_STATUS_STATUS_BITFIELD           = 1'h0;

 // gc_cr_ce_queue5
localparam logic [ 0 : 0 ] GC_CR_CE_QUEUE5_CONTINUE_BITFIELD                   = 1'h0;
localparam logic [ 1 : 1 ] GC_CR_CE_QUEUE5_CONTEXT_STORE_BITFIELD              = 1'h0;

 // gc_cr_ce_queue5_fence
localparam logic [ 15 : 0 ] GC_CR_CE_QUEUE5_FENCE_POLL_CTRL_BITFIELD           = 16'h804;

 // gc_cr_ce_queue5_ace_qos
localparam logic [ 3 : 0 ] GC_CR_CE_QUEUE5_ACE_QOS_CTRL_BITFIELD               = 4'h0;

 // gc_cr_ce_queue5_local_event
localparam logic [ 0 : 0 ] GC_CR_CE_QUEUE5_LOCAL_EVENT_COMPLETE_BITFIELD       = 1'h0;
localparam logic [ 1 : 1 ] GC_CR_CE_QUEUE5_LOCAL_EVENT_SIGNAL_WAIT_FAIL_BITFIELD  = 1'h0;
localparam logic [ 2 : 2 ] GC_CR_CE_QUEUE5_LOCAL_EVENT_STALL_BITFIELD          = 1'h0;
localparam logic [ 3 : 3 ] GC_CR_CE_QUEUE5_LOCAL_EVENT_EXCEPTION_AND_QUEUE_ERR_BITFIELD  = 1'h0;
localparam logic [ 4 : 4 ] GC_CR_CE_QUEUE5_LOCAL_EVENT_FENCE_INTERRUPT_BITFIELD  = 1'h0;
localparam logic [ 5 : 5 ] GC_CR_CE_QUEUE5_LOCAL_EVENT_PAGE_FAULT_BITFIELD     = 1'h0;
localparam logic [ 6 : 6 ] GC_CR_CE_QUEUE5_LOCAL_EVENT_AXI_RESP_ERR_BITFIELD   = 1'h0;
localparam logic [ 7 : 7 ] GC_CR_CE_QUEUE5_LOCAL_EVENT_PIM_ERROR_FOUND_BITFIELD  = 1'h0;

 // gc_cr_ce_queue5_local_event_enable
localparam logic [ 7 : 0 ] GC_CR_CE_QUEUE5_LOCAL_EVENT_ENABLE_ENABLE_BITFIELD  = 8'hff;

 // gc_cr_ce_queue5_local_event_clear
localparam logic [ 7 : 0 ] GC_CR_CE_QUEUE5_LOCAL_EVENT_CLEAR_CLEAR_BITFIELD    = 8'h0;

 // gc_cr_ce_queue5_mmu_fault_status
localparam logic [ 0 : 0 ] GC_CR_CE_QUEUE5_MMU_FAULT_STATUS_FAULT_VALID_BITFIELD  = 1'h0;
localparam logic [ 2 : 1 ] GC_CR_CE_QUEUE5_MMU_FAULT_STATUS_FAULT_TYPE_BITFIELD  = 2'h0;
localparam logic [ 5 : 3 ] GC_CR_CE_QUEUE5_MMU_FAULT_STATUS_FAULT_LEVEL_BITFIELD  = 3'h0;
localparam logic [ 6 : 6 ] GC_CR_CE_QUEUE5_MMU_FAULT_STATUS_FAULT_SRC_BITFIELD  = 1'h0;
localparam logic [ 9 : 7 ] GC_CR_CE_QUEUE5_MMU_FAULT_STATUS_VFID_BITFIELD      = 3'h0;
localparam logic [ 19 : 10 ] GC_CR_CE_QUEUE5_MMU_FAULT_STATUS_PASID_BITFIELD   = 10'h0;
localparam logic [ 63 : 20 ] GC_CR_CE_QUEUE5_MMU_FAULT_STATUS_VADDRESS_BITFIELD  = 44'h0;

 // gc_cr_ce_queue5_priority
localparam logic [ 1 : 0 ] GC_CR_CE_QUEUE5_PRIORITY_PRIORITY_BITFIELD          = 2'h0;

 // gc_cr_ce_queue5_max_task
localparam logic [ 6 : 0 ] GC_CR_CE_QUEUE5_MAX_TASK_MAX_TASK_BITFIELD          = 7'h8;

 // gc_cr_ce_queue5_fence_wait_address
localparam logic [ 47 : 0 ] GC_CR_CE_QUEUE5_FENCE_WAIT_ADDRESS_ADDRESS_BITFIELD  = 48'h0;

 // gc_cr_ce_queue5_fence_wait_expected_value
localparam logic [ 63 : 0 ] GC_CR_CE_QUEUE5_FENCE_WAIT_EXPECTED_VALUE_VALUE_BITFIELD  = 64'h0;

 // gc_cr_ce_queue5_fence_wait_return_value
localparam logic [ 63 : 0 ] GC_CR_CE_QUEUE5_FENCE_WAIT_RETURN_VALUE_VALUE_BITFIELD  = 64'h0;

 // gc_cr_ce_queue5_fence_update_address
localparam logic [ 47 : 0 ] GC_CR_CE_QUEUE5_FENCE_UPDATE_ADDRESS_ADDRESS_BITFIELD  = 48'h0;

 // gc_cr_ce_queue5_if_idle_cnt
localparam logic [ 31 : 0 ] GC_CR_CE_QUEUE5_IF_IDLE_CNT_IDLE_CNT_BITFIELD      = 32'h0;

 // gc_cr_ce_queue5_rb_woff
localparam logic [ 29 : 2 ] GC_CR_CE_QUEUE5_RB_WOFF_WOFF_BITFIELD              = 28'h0;

 // gc_cr_ce_queue5_pim_error_status
localparam logic [ 63 : 0 ] GC_CR_CE_QUEUE5_PIM_ERROR_STATUS_ERROR_STATUS_BITFIELD  = 64'h0;

 // gc_cr_ce_queue6_mmu
localparam logic [ 9 : 0 ] GC_CR_CE_QUEUE6_MMU_PASID_BITFIELD                  = 10'h0;
localparam logic [ 19 : 16 ] GC_CR_CE_QUEUE6_MMU_VFID_OSID_BITFIELD            = 4'h0;

 // gc_cr_ce_queue6_start
localparam logic [ 0 : 0 ] GC_CR_CE_QUEUE6_START_PLUSE_BITFIELD                = 1'h0;
localparam logic [ 1 : 1 ] GC_CR_CE_QUEUE6_START_CONTEXT_RESUME_BITFIELD       = 1'h0;

 // gc_cr_ce_queue6_rb_base
localparam logic [ 47 : 6 ] GC_CR_CE_QUEUE6_RB_BASE_ADDR_BITFIELD              = 42'h0;

 // gc_cr_ce_queue6_rb
localparam logic [ 29 : 2 ] GC_CR_CE_QUEUE6_RB_WOFF_UPDATE_CTRL_BITFIELD       = 28'h20;
localparam logic [ 61 : 41 ] GC_CR_CE_QUEUE6_RB_SIZE_BITFIELD                  = 21'h20;

 // gc_cr_ce_queue6_rb_roff
localparam logic [ 29 : 2 ] GC_CR_CE_QUEUE6_RB_ROFF_OFFSET_BITFIELD            = 28'h0;

 // gc_cr_ce_queue6_rb_ctrl_base
localparam logic [ 47 : 3 ] GC_CR_CE_QUEUE6_RB_CTRL_BASE_ADDR_BITFIELD         = 45'h0;

 // gc_cr_ce_queue6_rb_roff_update_ctrl
localparam logic [ 29 : 2 ] GC_CR_CE_QUEUE6_RB_ROFF_UPDATE_CTRL_THRESHOLD_BITFIELD  = 28'h20;

 // gc_cr_ce_queue6_l2_policy
localparam logic [ 1 : 0 ] GC_CR_CE_QUEUE6_L2_POLICY_PERSISTENT_BITFIELD       = 2'h3;
localparam logic [ 2 : 2 ] GC_CR_CE_QUEUE6_L2_POLICY_RB_BITFIELD               = 1'h0;
localparam logic [ 3 : 3 ] GC_CR_CE_QUEUE6_L2_POLICY_IB_BITFIELD               = 1'h0;
localparam logic [ 4 : 4 ] GC_CR_CE_QUEUE6_L2_POLICY_FENCE_BITFIELD            = 1'h0;
localparam logic [ 5 : 5 ] GC_CR_CE_QUEUE6_L2_POLICY_OFFSET_BITFIELD           = 1'h0;

 // gc_cr_ce_queue6_error_status
localparam logic [ 1 : 0 ] GC_CR_CE_QUEUE6_ERROR_STATUS_AXI_READ_RSP_BITFIELD  = 2'h0;
localparam logic [ 2 : 2 ] GC_CR_CE_QUEUE6_ERROR_STATUS_RAW_READ_BITFIELD      = 1'h0;
localparam logic [ 5 : 4 ] GC_CR_CE_QUEUE6_ERROR_STATUS_AXI_WRITE_RSP_BITFIELD  = 2'h0;

 // gc_cr_ce_queue6_context_store_base
localparam logic [ 47 : 4 ] GC_CR_CE_QUEUE6_CONTEXT_STORE_BASE_ADDR_BITFIELD   = 44'h0;

 // gc_cr_ce_queue6_cs_status
localparam logic [ 0 : 0 ] GC_CR_CE_QUEUE6_CS_STATUS_STATUS_BITFIELD           = 1'h0;

 // gc_cr_ce_queue6
localparam logic [ 0 : 0 ] GC_CR_CE_QUEUE6_CONTINUE_BITFIELD                   = 1'h0;
localparam logic [ 1 : 1 ] GC_CR_CE_QUEUE6_CONTEXT_STORE_BITFIELD              = 1'h0;

 // gc_cr_ce_queue6_fence
localparam logic [ 15 : 0 ] GC_CR_CE_QUEUE6_FENCE_POLL_CTRL_BITFIELD           = 16'h804;

 // gc_cr_ce_queue6_ace_qos
localparam logic [ 3 : 0 ] GC_CR_CE_QUEUE6_ACE_QOS_CTRL_BITFIELD               = 4'h0;

 // gc_cr_ce_queue6_local_event
localparam logic [ 0 : 0 ] GC_CR_CE_QUEUE6_LOCAL_EVENT_COMPLETE_BITFIELD       = 1'h0;
localparam logic [ 1 : 1 ] GC_CR_CE_QUEUE6_LOCAL_EVENT_SIGNAL_WAIT_FAIL_BITFIELD  = 1'h0;
localparam logic [ 2 : 2 ] GC_CR_CE_QUEUE6_LOCAL_EVENT_STALL_BITFIELD          = 1'h0;
localparam logic [ 3 : 3 ] GC_CR_CE_QUEUE6_LOCAL_EVENT_EXCEPTION_AND_QUEUE_ERR_BITFIELD  = 1'h0;
localparam logic [ 4 : 4 ] GC_CR_CE_QUEUE6_LOCAL_EVENT_FENCE_INTERRUPT_BITFIELD  = 1'h0;
localparam logic [ 5 : 5 ] GC_CR_CE_QUEUE6_LOCAL_EVENT_PAGE_FAULT_BITFIELD     = 1'h0;
localparam logic [ 6 : 6 ] GC_CR_CE_QUEUE6_LOCAL_EVENT_AXI_RESP_ERR_BITFIELD   = 1'h0;
localparam logic [ 7 : 7 ] GC_CR_CE_QUEUE6_LOCAL_EVENT_PIM_ERROR_FOUND_BITFIELD  = 1'h0;

 // gc_cr_ce_queue6_local_event_enable
localparam logic [ 7 : 0 ] GC_CR_CE_QUEUE6_LOCAL_EVENT_ENABLE_ENABLE_BITFIELD  = 8'hff;

 // gc_cr_ce_queue6_local_event_clear
localparam logic [ 7 : 0 ] GC_CR_CE_QUEUE6_LOCAL_EVENT_CLEAR_CLEAR_BITFIELD    = 8'h0;

 // gc_cr_ce_queue6_mmu_fault_status
localparam logic [ 0 : 0 ] GC_CR_CE_QUEUE6_MMU_FAULT_STATUS_FAULT_VALID_BITFIELD  = 1'h0;
localparam logic [ 2 : 1 ] GC_CR_CE_QUEUE6_MMU_FAULT_STATUS_FAULT_TYPE_BITFIELD  = 2'h0;
localparam logic [ 5 : 3 ] GC_CR_CE_QUEUE6_MMU_FAULT_STATUS_FAULT_LEVEL_BITFIELD  = 3'h0;
localparam logic [ 6 : 6 ] GC_CR_CE_QUEUE6_MMU_FAULT_STATUS_FAULT_SRC_BITFIELD  = 1'h0;
localparam logic [ 9 : 7 ] GC_CR_CE_QUEUE6_MMU_FAULT_STATUS_VFID_BITFIELD      = 3'h0;
localparam logic [ 19 : 10 ] GC_CR_CE_QUEUE6_MMU_FAULT_STATUS_PASID_BITFIELD   = 10'h0;
localparam logic [ 63 : 20 ] GC_CR_CE_QUEUE6_MMU_FAULT_STATUS_VADDRESS_BITFIELD  = 44'h0;

 // gc_cr_ce_queue6_priority
localparam logic [ 1 : 0 ] GC_CR_CE_QUEUE6_PRIORITY_PRIORITY_BITFIELD          = 2'h0;

 // gc_cr_ce_queue6_max_task
localparam logic [ 6 : 0 ] GC_CR_CE_QUEUE6_MAX_TASK_MAX_TASK_BITFIELD          = 7'h8;

 // gc_cr_ce_queue6_fence_wait_address
localparam logic [ 47 : 0 ] GC_CR_CE_QUEUE6_FENCE_WAIT_ADDRESS_ADDRESS_BITFIELD  = 48'h0;

 // gc_cr_ce_queue6_fence_wait_expected_value
localparam logic [ 63 : 0 ] GC_CR_CE_QUEUE6_FENCE_WAIT_EXPECTED_VALUE_VALUE_BITFIELD  = 64'h0;

 // gc_cr_ce_queue6_fence_wait_return_value
localparam logic [ 63 : 0 ] GC_CR_CE_QUEUE6_FENCE_WAIT_RETURN_VALUE_VALUE_BITFIELD  = 64'h0;

 // gc_cr_ce_queue6_fence_update_address
localparam logic [ 47 : 0 ] GC_CR_CE_QUEUE6_FENCE_UPDATE_ADDRESS_ADDRESS_BITFIELD  = 48'h0;

 // gc_cr_ce_queue6_if_idle_cnt
localparam logic [ 31 : 0 ] GC_CR_CE_QUEUE6_IF_IDLE_CNT_IDLE_CNT_BITFIELD      = 32'h0;

 // gc_cr_ce_queue6_rb_woff
localparam logic [ 29 : 2 ] GC_CR_CE_QUEUE6_RB_WOFF_WOFF_BITFIELD              = 28'h0;

 // gc_cr_ce_queue6_pim_error_status
localparam logic [ 63 : 0 ] GC_CR_CE_QUEUE6_PIM_ERROR_STATUS_ERROR_STATUS_BITFIELD  = 64'h0;

 // gc_cr_ce_queue7_mmu
localparam logic [ 9 : 0 ] GC_CR_CE_QUEUE7_MMU_PASID_BITFIELD                  = 10'h0;
localparam logic [ 19 : 16 ] GC_CR_CE_QUEUE7_MMU_VFID_OSID_BITFIELD            = 4'h0;

 // gc_cr_ce_queue7_start
localparam logic [ 0 : 0 ] GC_CR_CE_QUEUE7_START_PLUSE_BITFIELD                = 1'h0;
localparam logic [ 1 : 1 ] GC_CR_CE_QUEUE7_START_CONTEXT_RESUME_BITFIELD       = 1'h0;

 // gc_cr_ce_queue7_rb_base
localparam logic [ 47 : 6 ] GC_CR_CE_QUEUE7_RB_BASE_ADDR_BITFIELD              = 42'h0;

 // gc_cr_ce_queue7_rb
localparam logic [ 29 : 2 ] GC_CR_CE_QUEUE7_RB_WOFF_UPDATE_CTRL_BITFIELD       = 28'h20;
localparam logic [ 61 : 41 ] GC_CR_CE_QUEUE7_RB_SIZE_BITFIELD                  = 21'h20;

 // gc_cr_ce_queue7_rb_roff
localparam logic [ 29 : 2 ] GC_CR_CE_QUEUE7_RB_ROFF_OFFSET_BITFIELD            = 28'h0;

 // gc_cr_ce_queue7_rb_ctrl_base
localparam logic [ 47 : 3 ] GC_CR_CE_QUEUE7_RB_CTRL_BASE_ADDR_BITFIELD         = 45'h0;

 // gc_cr_ce_queue7_rb_roff_update_ctrl
localparam logic [ 29 : 2 ] GC_CR_CE_QUEUE7_RB_ROFF_UPDATE_CTRL_THRESHOLD_BITFIELD  = 28'h20;

 // gc_cr_ce_queue7_l2_policy
localparam logic [ 1 : 0 ] GC_CR_CE_QUEUE7_L2_POLICY_PERSISTENT_BITFIELD       = 2'h3;
localparam logic [ 2 : 2 ] GC_CR_CE_QUEUE7_L2_POLICY_RB_BITFIELD               = 1'h0;
localparam logic [ 3 : 3 ] GC_CR_CE_QUEUE7_L2_POLICY_IB_BITFIELD               = 1'h0;
localparam logic [ 4 : 4 ] GC_CR_CE_QUEUE7_L2_POLICY_FENCE_BITFIELD            = 1'h0;
localparam logic [ 5 : 5 ] GC_CR_CE_QUEUE7_L2_POLICY_OFFSET_BITFIELD           = 1'h0;

 // gc_cr_ce_queue7_error_status
localparam logic [ 1 : 0 ] GC_CR_CE_QUEUE7_ERROR_STATUS_AXI_READ_RSP_BITFIELD  = 2'h0;
localparam logic [ 2 : 2 ] GC_CR_CE_QUEUE7_ERROR_STATUS_RAW_READ_BITFIELD      = 1'h0;
localparam logic [ 5 : 4 ] GC_CR_CE_QUEUE7_ERROR_STATUS_AXI_WRITE_RSP_BITFIELD  = 2'h0;

 // gc_cr_ce_queue7_context_store_base
localparam logic [ 47 : 4 ] GC_CR_CE_QUEUE7_CONTEXT_STORE_BASE_ADDR_BITFIELD   = 44'h0;

 // gc_cr_ce_queue7_cs_status
localparam logic [ 0 : 0 ] GC_CR_CE_QUEUE7_CS_STATUS_STATUS_BITFIELD           = 1'h0;

 // gc_cr_ce_queue7
localparam logic [ 0 : 0 ] GC_CR_CE_QUEUE7_CONTINUE_BITFIELD                   = 1'h0;
localparam logic [ 1 : 1 ] GC_CR_CE_QUEUE7_CONTEXT_STORE_BITFIELD              = 1'h0;

 // gc_cr_ce_queue7_fence
localparam logic [ 15 : 0 ] GC_CR_CE_QUEUE7_FENCE_POLL_CTRL_BITFIELD           = 16'h804;

 // gc_cr_ce_queue7_ace_qos
localparam logic [ 3 : 0 ] GC_CR_CE_QUEUE7_ACE_QOS_CTRL_BITFIELD               = 4'h0;

 // gc_cr_ce_queue7_local_event
localparam logic [ 0 : 0 ] GC_CR_CE_QUEUE7_LOCAL_EVENT_COMPLETE_BITFIELD       = 1'h0;
localparam logic [ 1 : 1 ] GC_CR_CE_QUEUE7_LOCAL_EVENT_SIGNAL_WAIT_FAIL_BITFIELD  = 1'h0;
localparam logic [ 2 : 2 ] GC_CR_CE_QUEUE7_LOCAL_EVENT_STALL_BITFIELD          = 1'h0;
localparam logic [ 3 : 3 ] GC_CR_CE_QUEUE7_LOCAL_EVENT_EXCEPTION_AND_QUEUE_ERR_BITFIELD  = 1'h0;
localparam logic [ 4 : 4 ] GC_CR_CE_QUEUE7_LOCAL_EVENT_FENCE_INTERRUPT_BITFIELD  = 1'h0;
localparam logic [ 5 : 5 ] GC_CR_CE_QUEUE7_LOCAL_EVENT_PAGE_FAULT_BITFIELD     = 1'h0;
localparam logic [ 6 : 6 ] GC_CR_CE_QUEUE7_LOCAL_EVENT_AXI_RESP_ERR_BITFIELD   = 1'h0;
localparam logic [ 7 : 7 ] GC_CR_CE_QUEUE7_LOCAL_EVENT_PIM_ERROR_FOUND_BITFIELD  = 1'h0;

 // gc_cr_ce_queue7_local_event_enable
localparam logic [ 7 : 0 ] GC_CR_CE_QUEUE7_LOCAL_EVENT_ENABLE_ENABLE_BITFIELD  = 8'hff;

 // gc_cr_ce_queue7_local_event_clear
localparam logic [ 7 : 0 ] GC_CR_CE_QUEUE7_LOCAL_EVENT_CLEAR_CLEAR_BITFIELD    = 8'h0;

 // gc_cr_ce_queue7_mmu_fault_status
localparam logic [ 0 : 0 ] GC_CR_CE_QUEUE7_MMU_FAULT_STATUS_FAULT_VALID_BITFIELD  = 1'h0;
localparam logic [ 2 : 1 ] GC_CR_CE_QUEUE7_MMU_FAULT_STATUS_FAULT_TYPE_BITFIELD  = 2'h0;
localparam logic [ 5 : 3 ] GC_CR_CE_QUEUE7_MMU_FAULT_STATUS_FAULT_LEVEL_BITFIELD  = 3'h0;
localparam logic [ 6 : 6 ] GC_CR_CE_QUEUE7_MMU_FAULT_STATUS_FAULT_SRC_BITFIELD  = 1'h0;
localparam logic [ 9 : 7 ] GC_CR_CE_QUEUE7_MMU_FAULT_STATUS_VFID_BITFIELD      = 3'h0;
localparam logic [ 19 : 10 ] GC_CR_CE_QUEUE7_MMU_FAULT_STATUS_PASID_BITFIELD   = 10'h0;
localparam logic [ 63 : 20 ] GC_CR_CE_QUEUE7_MMU_FAULT_STATUS_VADDRESS_BITFIELD  = 44'h0;

 // gc_cr_ce_queue7_priority
localparam logic [ 1 : 0 ] GC_CR_CE_QUEUE7_PRIORITY_PRIORITY_BITFIELD          = 2'h0;

 // gc_cr_ce_queue7_max_task
localparam logic [ 6 : 0 ] GC_CR_CE_QUEUE7_MAX_TASK_MAX_TASK_BITFIELD          = 7'h8;

 // gc_cr_ce_queue7_fence_wait_address
localparam logic [ 47 : 0 ] GC_CR_CE_QUEUE7_FENCE_WAIT_ADDRESS_ADDRESS_BITFIELD  = 48'h0;

 // gc_cr_ce_queue7_fence_wait_expected_value
localparam logic [ 63 : 0 ] GC_CR_CE_QUEUE7_FENCE_WAIT_EXPECTED_VALUE_VALUE_BITFIELD  = 64'h0;

 // gc_cr_ce_queue7_fence_wait_return_value
localparam logic [ 63 : 0 ] GC_CR_CE_QUEUE7_FENCE_WAIT_RETURN_VALUE_VALUE_BITFIELD  = 64'h0;

 // gc_cr_ce_queue7_fence_update_address
localparam logic [ 47 : 0 ] GC_CR_CE_QUEUE7_FENCE_UPDATE_ADDRESS_ADDRESS_BITFIELD  = 48'h0;

 // gc_cr_ce_queue7_if_idle_cnt
localparam logic [ 31 : 0 ] GC_CR_CE_QUEUE7_IF_IDLE_CNT_IDLE_CNT_BITFIELD      = 32'h0;

 // gc_cr_ce_queue7_rb_woff
localparam logic [ 29 : 2 ] GC_CR_CE_QUEUE7_RB_WOFF_WOFF_BITFIELD              = 28'h0;

 // gc_cr_ce_queue7_pim_error_status
localparam logic [ 63 : 0 ] GC_CR_CE_QUEUE7_PIM_ERROR_STATUS_ERROR_STATUS_BITFIELD  = 64'h0;

 // gc_cr_gsync_ctrl
localparam logic [ 3 : 0 ] GC_CR_GSYNC_CTRL_CFI_TIMEOUT_CYCLES_BITFIELD        = 4'h3;
localparam logic [ 4 : 4 ] GC_CR_GSYNC_CTRL_CFI_TIMEOUT_ENABLE_BITFIELD        = 1'h1;

 // gc_cr_gsync_status
localparam logic [ 15 : 0 ] GC_CR_GSYNC_STATUS_CFI_TIMEOUTS_BITFIELD           = 16'h0;

 // gc_cr_perf_enable_full
localparam logic [ 0 : 0 ] GC_CR_PERF_ENABLE_FULL_RANGE_BITFIELD               = 1'h0;

 // gc_cr_mmu_mapping_context
localparam logic [ 5 : 0 ] GC_CR_MMU_MAPPING_CONTEXT_ID_BITFIELD               = 6'h0;

 // gc_cr_mmu_mapping
localparam logic [ 3 : 0 ] GC_CR_MMU_MAPPING_VFID_BITFIELD                     = 4'h0;
localparam logic [ 25 : 16 ] GC_CR_MMU_MAPPING_PASID_BITFIELD                  = 10'h0;

 // gc_cr_axi_status0
localparam logic [ 11 : 0 ] GC_CR_AXI_STATUS0_BUS0_OUTSTANDING_READS_BITFIELD  = 12'h0;
localparam logic [ 23 : 12 ] GC_CR_AXI_STATUS0_BUS1_OUTSTANDING_READS_BITFIELD  = 12'h0;
localparam logic [ 35 : 24 ] GC_CR_AXI_STATUS0_BUS0_OUTSTANDING_WRITES_BITFIELD  = 12'h0;
localparam logic [ 47 : 36 ] GC_CR_AXI_STATUS0_BUS1_OUTSTANDING_WRITES_BITFIELD  = 12'h0;

 // gc_cr_axi_status1
localparam logic [ 11 : 0 ] GC_CR_AXI_STATUS1_BUS0_OUTSTANDING_READS_BITFIELD  = 12'h0;
localparam logic [ 23 : 12 ] GC_CR_AXI_STATUS1_BUS1_OUTSTANDING_READS_BITFIELD  = 12'h0;
localparam logic [ 35 : 24 ] GC_CR_AXI_STATUS1_BUS0_OUTSTANDING_WRITES_BITFIELD  = 12'h0;
localparam logic [ 47 : 36 ] GC_CR_AXI_STATUS1_BUS1_OUTSTANDING_WRITES_BITFIELD  = 12'h0;

 // gc_cr_axi_status_cp
localparam logic [ 11 : 0 ] GC_CR_AXI_STATUS_CP_BUS0_OUTSTANDING_READS_BITFIELD  = 12'h0;
localparam logic [ 35 : 24 ] GC_CR_AXI_STATUS_CP_BUS0_OUTSTANDING_WRITES_BITFIELD  = 12'h0;

 // gc_cr_axi_axcache_ctrl
localparam logic [ 0 : 0 ] GC_CR_AXI_AXCACHE_CTRL_SNOOP_BITFIELD               = 1'h0;

 // gc_cr_axi_qos_ctrl
localparam logic [ 3 : 0 ] GC_CR_AXI_QOS_CTRL_LOW_BITFIELD                     = 4'h0;
localparam logic [ 7 : 4 ] GC_CR_AXI_QOS_CTRL_MEDIUM_BITFIELD                  = 4'h4;
localparam logic [ 11 : 8 ] GC_CR_AXI_QOS_CTRL_HIGH_BITFIELD                   = 4'h8;
localparam logic [ 15 : 12 ] GC_CR_AXI_QOS_CTRL_CRITICAL_BITFIELD              = 4'hf;

 // gc_cr_axi_priority_mapping_ctrl
localparam logic [ 1 : 0 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_RESERVE_BITFIELD    = 2'h1;
localparam logic [ 1 : 0 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_RESERVE_LOW         = 2'h0;
localparam logic [ 1 : 0 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_RESERVE_MEDIUM      = 2'h1;
localparam logic [ 1 : 0 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_RESERVE_HIGH        = 2'h2;
localparam logic [ 1 : 0 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_RESERVE_CRITICAL    = 2'h3;
localparam logic [ 3 : 2 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_CPC0_BITFIELD       = 2'h1;
localparam logic [ 3 : 2 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_CPC0_LOW            = 2'h0;
localparam logic [ 3 : 2 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_CPC0_MEDIUM         = 2'h1;
localparam logic [ 3 : 2 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_CPC0_HIGH           = 2'h2;
localparam logic [ 3 : 2 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_CPC0_CRITICAL       = 2'h3;
localparam logic [ 5 : 4 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_CPC1_BITFIELD       = 2'h1;
localparam logic [ 5 : 4 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_CPC1_LOW            = 2'h0;
localparam logic [ 5 : 4 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_CPC1_MEDIUM         = 2'h1;
localparam logic [ 5 : 4 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_CPC1_HIGH           = 2'h2;
localparam logic [ 5 : 4 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_CPC1_CRITICAL       = 2'h3;
localparam logic [ 7 : 6 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_CPC2_BITFIELD       = 2'h1;
localparam logic [ 7 : 6 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_CPC2_LOW            = 2'h0;
localparam logic [ 7 : 6 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_CPC2_MEDIUM         = 2'h1;
localparam logic [ 7 : 6 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_CPC2_HIGH           = 2'h2;
localparam logic [ 7 : 6 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_CPC2_CRITICAL       = 2'h3;
localparam logic [ 9 : 8 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_CPC3_BITFIELD       = 2'h1;
localparam logic [ 9 : 8 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_CPC3_LOW            = 2'h0;
localparam logic [ 9 : 8 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_CPC3_MEDIUM         = 2'h1;
localparam logic [ 9 : 8 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_CPC3_HIGH           = 2'h2;
localparam logic [ 9 : 8 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_CPC3_CRITICAL       = 2'h3;
localparam logic [ 11 : 10 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_FWP_BITFIELD      = 2'h2;
localparam logic [ 11 : 10 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_FWP_LOW           = 2'h0;
localparam logic [ 11 : 10 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_FWP_MEDIUM        = 2'h1;
localparam logic [ 11 : 10 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_FWP_HIGH          = 2'h2;
localparam logic [ 11 : 10 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_FWP_CRITICAL      = 2'h3;
localparam logic [ 13 : 12 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_FWP_DMA_BITFIELD  = 2'h1;
localparam logic [ 13 : 12 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_FWP_DMA_LOW       = 2'h0;
localparam logic [ 13 : 12 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_FWP_DMA_MEDIUM    = 2'h1;
localparam logic [ 13 : 12 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_FWP_DMA_HIGH      = 2'h2;
localparam logic [ 13 : 12 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_FWP_DMA_CRITICAL   = 2'h3;
localparam logic [ 15 : 14 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_PU_BITFIELD       = 2'h1;
localparam logic [ 15 : 14 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_PU_LOW            = 2'h0;
localparam logic [ 15 : 14 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_PU_MEDIUM         = 2'h1;
localparam logic [ 15 : 14 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_PU_HIGH           = 2'h2;
localparam logic [ 15 : 14 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_PU_CRITICAL       = 2'h3;
localparam logic [ 17 : 16 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_BSC_BITFIELD      = 2'h2;
localparam logic [ 17 : 16 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_BSC_LOW           = 2'h0;
localparam logic [ 17 : 16 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_BSC_MEDIUM        = 2'h1;
localparam logic [ 17 : 16 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_BSC_HIGH          = 2'h2;
localparam logic [ 17 : 16 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_BSC_CRITICAL      = 2'h3;
localparam logic [ 19 : 18 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_RAW_READ_BITFIELD  = 2'h3;
localparam logic [ 19 : 18 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_RAW_READ_LOW      = 2'h0;
localparam logic [ 19 : 18 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_RAW_READ_MEDIUM   = 2'h1;
localparam logic [ 19 : 18 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_RAW_READ_HIGH     = 2'h2;
localparam logic [ 19 : 18 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_RAW_READ_CRITICAL   = 2'h3;
localparam logic [ 21 : 20 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_CE_PFM_BITFIELD   = 2'h0;
localparam logic [ 21 : 20 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_CE_PFM_LOW        = 2'h0;
localparam logic [ 21 : 20 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_CE_PFM_MEDIUM     = 2'h1;
localparam logic [ 21 : 20 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_CE_PFM_HIGH       = 2'h2;
localparam logic [ 21 : 20 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_CE_PFM_CRITICAL   = 2'h3;
localparam logic [ 23 : 22 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_TCU_BITFIELD      = 2'h0;
localparam logic [ 23 : 22 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_TCU_LOW           = 2'h0;
localparam logic [ 23 : 22 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_TCU_MEDIUM        = 2'h1;
localparam logic [ 23 : 22 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_TCU_HIGH          = 2'h2;
localparam logic [ 23 : 22 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_TCU_CRITICAL      = 2'h3;
localparam logic [ 25 : 24 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_L2ICACHE_BITFIELD  = 2'h2;
localparam logic [ 25 : 24 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_L2ICACHE_LOW      = 2'h0;
localparam logic [ 25 : 24 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_L2ICACHE_MEDIUM   = 2'h1;
localparam logic [ 25 : 24 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_L2ICACHE_HIGH     = 2'h2;
localparam logic [ 25 : 24 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_L2ICACHE_CRITICAL   = 2'h3;
localparam logic [ 27 : 26 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_MCU_L1_BITFIELD   = 2'h0;
localparam logic [ 27 : 26 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_MCU_L1_LOW        = 2'h0;
localparam logic [ 27 : 26 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_MCU_L1_MEDIUM     = 2'h1;
localparam logic [ 27 : 26 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_MCU_L1_HIGH       = 2'h2;
localparam logic [ 27 : 26 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_MCU_L1_CRITICAL   = 2'h3;
localparam logic [ 29 : 28 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_IPF_BITFIELD      = 2'h1;
localparam logic [ 29 : 28 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_IPF_LOW           = 2'h0;
localparam logic [ 29 : 28 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_IPF_MEDIUM        = 2'h1;
localparam logic [ 29 : 28 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_IPF_HIGH          = 2'h2;
localparam logic [ 29 : 28 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_IPF_CRITICAL      = 2'h3;
localparam logic [ 31 : 30 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_ASC_BITFIELD      = 2'h0;
localparam logic [ 31 : 30 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_ASC_LOW           = 2'h0;
localparam logic [ 31 : 30 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_ASC_MEDIUM        = 2'h1;
localparam logic [ 31 : 30 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_ASC_HIGH          = 2'h2;
localparam logic [ 31 : 30 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_ASC_CRITICAL      = 2'h3;
localparam logic [ 33 : 32 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_ISP_BITFIELD      = 2'h0;
localparam logic [ 33 : 32 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_ISP_LOW           = 2'h0;
localparam logic [ 33 : 32 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_ISP_MEDIUM        = 2'h1;
localparam logic [ 33 : 32 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_ISP_HIGH          = 2'h2;
localparam logic [ 33 : 32 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_ISP_CRITICAL      = 2'h3;
localparam logic [ 35 : 34 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_GEOM_BITFIELD     = 2'h1;
localparam logic [ 35 : 34 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_GEOM_LOW          = 2'h0;
localparam logic [ 35 : 34 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_GEOM_MEDIUM       = 2'h1;
localparam logic [ 35 : 34 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_GEOM_HIGH         = 2'h2;
localparam logic [ 35 : 34 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_GEOM_CRITICAL     = 2'h3;
localparam logic [ 41 : 36 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_RESERVED2_BITFIELD  = 6'h0;
localparam logic [ 43 : 42 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_TPF_BITFIELD      = 2'h1;
localparam logic [ 43 : 42 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_TPF_LOW           = 2'h0;
localparam logic [ 43 : 42 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_TPF_MEDIUM        = 2'h1;
localparam logic [ 43 : 42 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_TPF_HIGH          = 2'h2;
localparam logic [ 43 : 42 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_TPF_CRITICAL      = 2'h3;
localparam logic [ 45 : 44 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_PDSRW_BITFIELD    = 2'h1;
localparam logic [ 45 : 44 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_PDSRW_LOW         = 2'h0;
localparam logic [ 45 : 44 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_PDSRW_MEDIUM      = 2'h1;
localparam logic [ 45 : 44 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_PDSRW_HIGH        = 2'h2;
localparam logic [ 45 : 44 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_PDSRW_CRITICAL    = 2'h3;
localparam logic [ 47 : 46 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_PDS_BITFIELD      = 2'h2;
localparam logic [ 47 : 46 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_PDS_LOW           = 2'h0;
localparam logic [ 47 : 46 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_PDS_MEDIUM        = 2'h1;
localparam logic [ 47 : 46 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_PDS_HIGH          = 2'h2;
localparam logic [ 47 : 46 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_PDS_CRITICAL      = 2'h3;
localparam logic [ 49 : 48 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_CU_BITFIELD       = 2'h2;
localparam logic [ 49 : 48 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_CU_LOW            = 2'h0;
localparam logic [ 49 : 48 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_CU_MEDIUM         = 2'h1;
localparam logic [ 49 : 48 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_CU_HIGH           = 2'h2;
localparam logic [ 49 : 48 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_CU_CRITICAL       = 2'h3;
localparam logic [ 51 : 50 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_UNUSED_ID2_BITFIELD  = 2'h1;
localparam logic [ 51 : 50 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_UNUSED_ID2_LOW    = 2'h0;
localparam logic [ 51 : 50 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_UNUSED_ID2_MEDIUM   = 2'h1;
localparam logic [ 51 : 50 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_UNUSED_ID2_HIGH   = 2'h2;
localparam logic [ 51 : 50 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_UNUSED_ID2_CRITICAL   = 2'h3;
localparam logic [ 57 : 52 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_RESERVED1_BITFIELD  = 6'h0;
localparam logic [ 59 : 58 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_FBM_BSC_BITFIELD  = 2'h3;
localparam logic [ 59 : 58 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_FBM_BSC_LOW       = 2'h0;
localparam logic [ 59 : 58 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_FBM_BSC_MEDIUM    = 2'h1;
localparam logic [ 59 : 58 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_FBM_BSC_HIGH      = 2'h2;
localparam logic [ 59 : 58 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_FBM_BSC_CRITICAL   = 2'h3;
localparam logic [ 61 : 60 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_RESERVED0_BITFIELD  = 2'h0;
localparam logic [ 63 : 62 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_MMU_BITFIELD      = 2'h3;
localparam logic [ 63 : 62 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_MMU_LOW           = 2'h0;
localparam logic [ 63 : 62 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_MMU_MEDIUM        = 2'h1;
localparam logic [ 63 : 62 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_MMU_HIGH          = 2'h2;
localparam logic [ 63 : 62 ] GC_CR_AXI_PRIORITY_MAPPING_CTRL_MMU_CRITICAL      = 2'h3;

 // gc_cr_axi_status_spc
localparam logic [ 3 : 0 ] GC_CR_AXI_STATUS_SPC_RD_BUS0_ERROR_BITFIELD         = 4'h0;
localparam logic [ 7 : 4 ] GC_CR_AXI_STATUS_SPC_WR_BUS0_ERROR_BITFIELD         = 4'h0;
localparam logic [ 11 : 8 ] GC_CR_AXI_STATUS_SPC_RD_BUS1_ERROR_BITFIELD        = 4'h0;
localparam logic [ 15 : 12 ] GC_CR_AXI_STATUS_SPC_WR_BUS1_ERROR_BITFIELD       = 4'h0;
localparam logic [ 19 : 16 ] GC_CR_AXI_STATUS_SPC_RD_BUS2_ERROR_BITFIELD       = 4'h0;
localparam logic [ 23 : 20 ] GC_CR_AXI_STATUS_SPC_WR_BUS2_ERROR_BITFIELD       = 4'h0;
localparam logic [ 27 : 24 ] GC_CR_AXI_STATUS_SPC_RD_BUS3_ERROR_BITFIELD       = 4'h0;
localparam logic [ 31 : 28 ] GC_CR_AXI_STATUS_SPC_WR_BUS3_ERROR_BITFIELD       = 4'h0;

 // gc_cr_axi_status
localparam logic [ 3 : 0 ] GC_CR_AXI_STATUS_RD_BUS_ERROR_BITFIELD              = 4'h0;
localparam logic [ 7 : 4 ] GC_CR_AXI_STATUS_WR_BUS_ERROR_BITFIELD              = 4'h0;

 // gc_cr_cp_fault_stop_status_gpc
localparam logic [ 63 : 0 ] GC_CR_CP_FAULT_STOP_STATUS_GPC_BIF_BITFIELD        = 64'h0;

 // gc_cr_cp_fault_stop_ctrl_gpc
localparam logic [ 63 : 0 ] GC_CR_CP_FAULT_STOP_CTRL_GPC_ENABLE_BITFIELD       = 64'hffffffffffffffff;

 // gc_cr_cp_fault_stop_status_cp
localparam logic [ 0 : 0 ] GC_CR_CP_FAULT_STOP_STATUS_CP_BIF_BITFIELD          = 1'h0;

 // gc_cr_cp_fault_stop_ctrl
localparam logic [ 0 : 0 ] GC_CR_CP_FAULT_STOP_CTRL_CP_ENABLE_BITFIELD         = 1'h1;
localparam logic [ 1 : 1 ] GC_CR_CP_FAULT_STOP_CTRL_ALL_BITFIELD               = 1'h0;

 // gc_cr_l2_rd_status0
localparam logic [ 9 : 0 ] GC_CR_L2_RD_STATUS0_MIN_LOW_QOS_LATENCY_BITFIELD    = 10'h0;
localparam logic [ 19 : 10 ] GC_CR_L2_RD_STATUS0_MIN_CRITICAL_QOS_LATENCY_BITFIELD  = 10'h0;
localparam logic [ 29 : 20 ] GC_CR_L2_RD_STATUS0_AVG_LOW_QOS_LATENCY_BITFIELD  = 10'h0;
localparam logic [ 39 : 30 ] GC_CR_L2_RD_STATUS0_AVG_CRITICAL_QOS_LATENCY_BITFIELD  = 10'h0;
localparam logic [ 51 : 40 ] GC_CR_L2_RD_STATUS0_MAX_LOW_QOS_LATENCY_BITFIELD  = 12'h0;
localparam logic [ 63 : 52 ] GC_CR_L2_RD_STATUS0_MAX_CRITICAL_QOS_LATENCY_BITFIELD  = 12'h0;

 // gc_cr_l2_wr_status0
localparam logic [ 9 : 0 ] GC_CR_L2_WR_STATUS0_MIN_LOW_QOS_LATENCY_BITFIELD    = 10'h0;
localparam logic [ 19 : 10 ] GC_CR_L2_WR_STATUS0_MIN_CRITICAL_QOS_LATENCY_BITFIELD  = 10'h0;
localparam logic [ 29 : 20 ] GC_CR_L2_WR_STATUS0_AVG_LOW_QOS_LATENCY_BITFIELD  = 10'h0;
localparam logic [ 39 : 30 ] GC_CR_L2_WR_STATUS0_AVG_CRITICAL_QOS_LATENCY_BITFIELD  = 10'h0;
localparam logic [ 51 : 40 ] GC_CR_L2_WR_STATUS0_MAX_LOW_QOS_LATENCY_BITFIELD  = 12'h0;
localparam logic [ 63 : 52 ] GC_CR_L2_WR_STATUS0_MAX_CRITICAL_QOS_LATENCY_BITFIELD  = 12'h0;

 // gc_cr_l2_rd_status1
localparam logic [ 9 : 0 ] GC_CR_L2_RD_STATUS1_MIN_LOW_QOS_LATENCY_BITFIELD    = 10'h0;
localparam logic [ 19 : 10 ] GC_CR_L2_RD_STATUS1_MIN_CRITICAL_QOS_LATENCY_BITFIELD  = 10'h0;
localparam logic [ 29 : 20 ] GC_CR_L2_RD_STATUS1_AVG_LOW_QOS_LATENCY_BITFIELD  = 10'h0;
localparam logic [ 39 : 30 ] GC_CR_L2_RD_STATUS1_AVG_CRITICAL_QOS_LATENCY_BITFIELD  = 10'h0;
localparam logic [ 51 : 40 ] GC_CR_L2_RD_STATUS1_MAX_LOW_QOS_LATENCY_BITFIELD  = 12'h0;
localparam logic [ 63 : 52 ] GC_CR_L2_RD_STATUS1_MAX_CRITICAL_QOS_LATENCY_BITFIELD  = 12'h0;

 // gc_cr_l2_wr_status1
localparam logic [ 9 : 0 ] GC_CR_L2_WR_STATUS1_MIN_LOW_QOS_LATENCY_BITFIELD    = 10'h0;
localparam logic [ 19 : 10 ] GC_CR_L2_WR_STATUS1_MIN_CRITICAL_QOS_LATENCY_BITFIELD  = 10'h0;
localparam logic [ 29 : 20 ] GC_CR_L2_WR_STATUS1_AVG_LOW_QOS_LATENCY_BITFIELD  = 10'h0;
localparam logic [ 39 : 30 ] GC_CR_L2_WR_STATUS1_AVG_CRITICAL_QOS_LATENCY_BITFIELD  = 10'h0;
localparam logic [ 51 : 40 ] GC_CR_L2_WR_STATUS1_MAX_LOW_QOS_LATENCY_BITFIELD  = 12'h0;
localparam logic [ 63 : 52 ] GC_CR_L2_WR_STATUS1_MAX_CRITICAL_QOS_LATENCY_BITFIELD  = 12'h0;

 // gc_cr_l2_rd_status2
localparam logic [ 9 : 0 ] GC_CR_L2_RD_STATUS2_MIN_LOW_QOS_LATENCY_BITFIELD    = 10'h0;
localparam logic [ 19 : 10 ] GC_CR_L2_RD_STATUS2_MIN_CRITICAL_QOS_LATENCY_BITFIELD  = 10'h0;
localparam logic [ 29 : 20 ] GC_CR_L2_RD_STATUS2_AVG_LOW_QOS_LATENCY_BITFIELD  = 10'h0;
localparam logic [ 39 : 30 ] GC_CR_L2_RD_STATUS2_AVG_CRITICAL_QOS_LATENCY_BITFIELD  = 10'h0;
localparam logic [ 51 : 40 ] GC_CR_L2_RD_STATUS2_MAX_LOW_QOS_LATENCY_BITFIELD  = 12'h0;
localparam logic [ 63 : 52 ] GC_CR_L2_RD_STATUS2_MAX_CRITICAL_QOS_LATENCY_BITFIELD  = 12'h0;

 // gc_cr_l2_wr_status2
localparam logic [ 9 : 0 ] GC_CR_L2_WR_STATUS2_MIN_LOW_QOS_LATENCY_BITFIELD    = 10'h0;
localparam logic [ 19 : 10 ] GC_CR_L2_WR_STATUS2_MIN_CRITICAL_QOS_LATENCY_BITFIELD  = 10'h0;
localparam logic [ 29 : 20 ] GC_CR_L2_WR_STATUS2_AVG_LOW_QOS_LATENCY_BITFIELD  = 10'h0;
localparam logic [ 39 : 30 ] GC_CR_L2_WR_STATUS2_AVG_CRITICAL_QOS_LATENCY_BITFIELD  = 10'h0;
localparam logic [ 51 : 40 ] GC_CR_L2_WR_STATUS2_MAX_LOW_QOS_LATENCY_BITFIELD  = 12'h0;
localparam logic [ 63 : 52 ] GC_CR_L2_WR_STATUS2_MAX_CRITICAL_QOS_LATENCY_BITFIELD  = 12'h0;

 // gc_cr_l2_rd_status3
localparam logic [ 9 : 0 ] GC_CR_L2_RD_STATUS3_MIN_LOW_QOS_LATENCY_BITFIELD    = 10'h0;
localparam logic [ 19 : 10 ] GC_CR_L2_RD_STATUS3_MIN_CRITICAL_QOS_LATENCY_BITFIELD  = 10'h0;
localparam logic [ 29 : 20 ] GC_CR_L2_RD_STATUS3_AVG_LOW_QOS_LATENCY_BITFIELD  = 10'h0;
localparam logic [ 39 : 30 ] GC_CR_L2_RD_STATUS3_AVG_CRITICAL_QOS_LATENCY_BITFIELD  = 10'h0;
localparam logic [ 51 : 40 ] GC_CR_L2_RD_STATUS3_MAX_LOW_QOS_LATENCY_BITFIELD  = 12'h0;
localparam logic [ 63 : 52 ] GC_CR_L2_RD_STATUS3_MAX_CRITICAL_QOS_LATENCY_BITFIELD  = 12'h0;

 // gc_cr_l2_wr_status3
localparam logic [ 9 : 0 ] GC_CR_L2_WR_STATUS3_MIN_LOW_QOS_LATENCY_BITFIELD    = 10'h0;
localparam logic [ 19 : 10 ] GC_CR_L2_WR_STATUS3_MIN_CRITICAL_QOS_LATENCY_BITFIELD  = 10'h0;
localparam logic [ 29 : 20 ] GC_CR_L2_WR_STATUS3_AVG_LOW_QOS_LATENCY_BITFIELD  = 10'h0;
localparam logic [ 39 : 30 ] GC_CR_L2_WR_STATUS3_AVG_CRITICAL_QOS_LATENCY_BITFIELD  = 10'h0;
localparam logic [ 51 : 40 ] GC_CR_L2_WR_STATUS3_MAX_LOW_QOS_LATENCY_BITFIELD  = 12'h0;
localparam logic [ 63 : 52 ] GC_CR_L2_WR_STATUS3_MAX_CRITICAL_QOS_LATENCY_BITFIELD  = 12'h0;

 // gc_cr_l2_rd_status_cp
localparam logic [ 9 : 0 ] GC_CR_L2_RD_STATUS_CP_MIN_LOW_QOS_LATENCY_BITFIELD  = 10'h0;
localparam logic [ 19 : 10 ] GC_CR_L2_RD_STATUS_CP_MIN_CRITICAL_QOS_LATENCY_BITFIELD  = 10'h0;
localparam logic [ 29 : 20 ] GC_CR_L2_RD_STATUS_CP_AVG_LOW_QOS_LATENCY_BITFIELD  = 10'h0;
localparam logic [ 39 : 30 ] GC_CR_L2_RD_STATUS_CP_AVG_CRITICAL_QOS_LATENCY_BITFIELD  = 10'h0;
localparam logic [ 51 : 40 ] GC_CR_L2_RD_STATUS_CP_MAX_LOW_QOS_LATENCY_BITFIELD  = 12'h0;
localparam logic [ 63 : 52 ] GC_CR_L2_RD_STATUS_CP_MAX_CRITICAL_QOS_LATENCY_BITFIELD  = 12'h0;

 // gc_cr_l2_wr_status_cp
localparam logic [ 9 : 0 ] GC_CR_L2_WR_STATUS_CP_MIN_LOW_QOS_LATENCY_BITFIELD  = 10'h0;
localparam logic [ 19 : 10 ] GC_CR_L2_WR_STATUS_CP_MIN_CRITICAL_QOS_LATENCY_BITFIELD  = 10'h0;
localparam logic [ 29 : 20 ] GC_CR_L2_WR_STATUS_CP_AVG_LOW_QOS_LATENCY_BITFIELD  = 10'h0;
localparam logic [ 39 : 30 ] GC_CR_L2_WR_STATUS_CP_AVG_CRITICAL_QOS_LATENCY_BITFIELD  = 10'h0;
localparam logic [ 51 : 40 ] GC_CR_L2_WR_STATUS_CP_MAX_LOW_QOS_LATENCY_BITFIELD  = 12'h0;
localparam logic [ 63 : 52 ] GC_CR_L2_WR_STATUS_CP_MAX_CRITICAL_QOS_LATENCY_BITFIELD  = 12'h0;

 // gc_cr_gpc_bif_mmu_idle_status
localparam logic [ 0 : 0 ] GC_CR_GPC_BIF_MMU_IDLE_STATUS_GPC0_SPC0_TTT0_4BIF2AXI_IDLE_BITFIELD  = 1'h1;
localparam logic [ 1 : 1 ] GC_CR_GPC_BIF_MMU_IDLE_STATUS_GPC0_SPC0_TTT0_4UTLB_IDLE_BITFIELD  = 1'h1;
localparam logic [ 2 : 2 ] GC_CR_GPC_BIF_MMU_IDLE_STATUS_GPC0_SPC0_TTT0_MTLB_IDLE_BITFIELD  = 1'h1;
localparam logic [ 3 : 3 ] GC_CR_GPC_BIF_MMU_IDLE_STATUS_GPC0_TCU_IDLE_BITFIELD  = 1'h1;
localparam logic [ 4 : 4 ] GC_CR_GPC_BIF_MMU_IDLE_STATUS_GPC0_SPC0_TTT1_4BIF2AXI_IDLE_BITFIELD  = 1'h1;
localparam logic [ 5 : 5 ] GC_CR_GPC_BIF_MMU_IDLE_STATUS_GPC0_SPC0_TTT1_4UTLB_IDLE_BITFIELD  = 1'h1;
localparam logic [ 6 : 6 ] GC_CR_GPC_BIF_MMU_IDLE_STATUS_GPC0_SPC0_TTT1_MTLB_IDLE_BITFIELD  = 1'h1;
localparam logic [ 7 : 7 ] GC_CR_GPC_BIF_MMU_IDLE_STATUS_RESERVE0_BITFIELD     = 1'h0;
localparam logic [ 8 : 8 ] GC_CR_GPC_BIF_MMU_IDLE_STATUS_GPC0_SPC1_TTT0_4BIF2AXI_IDLE_BITFIELD  = 1'h1;
localparam logic [ 9 : 9 ] GC_CR_GPC_BIF_MMU_IDLE_STATUS_GPC0_SPC1_TTT0_4UTLB_IDLE_BITFIELD  = 1'h1;
localparam logic [ 10 : 10 ] GC_CR_GPC_BIF_MMU_IDLE_STATUS_GPC0_SPC1_TTT0_MTLB_IDLE_BITFIELD  = 1'h1;
localparam logic [ 11 : 11 ] GC_CR_GPC_BIF_MMU_IDLE_STATUS_RESERVE1_BITFIELD   = 1'h0;
localparam logic [ 12 : 12 ] GC_CR_GPC_BIF_MMU_IDLE_STATUS_GPC0_SPC1_TTT1_4BIF2AXI_IDLE_BITFIELD  = 1'h1;
localparam logic [ 13 : 13 ] GC_CR_GPC_BIF_MMU_IDLE_STATUS_GPC0_SPC1_TTT1_4UTLB_IDLE_BITFIELD  = 1'h1;
localparam logic [ 14 : 14 ] GC_CR_GPC_BIF_MMU_IDLE_STATUS_GPC0_SPC1_TTT1_MTLB_IDLE_BITFIELD  = 1'h1;
localparam logic [ 15 : 15 ] GC_CR_GPC_BIF_MMU_IDLE_STATUS_RESERVE2_BITFIELD   = 1'h0;
localparam logic [ 16 : 16 ] GC_CR_GPC_BIF_MMU_IDLE_STATUS_GPC1_SPC0_TTT0_4BIF2AXI_IDLE_BITFIELD  = 1'h1;
localparam logic [ 17 : 17 ] GC_CR_GPC_BIF_MMU_IDLE_STATUS_GPC1_SPC0_TTT0_4UTLB_IDLE_BITFIELD  = 1'h1;
localparam logic [ 18 : 18 ] GC_CR_GPC_BIF_MMU_IDLE_STATUS_GPC1_SPC0_TTT0_MTLB_IDLE_BITFIELD  = 1'h1;
localparam logic [ 19 : 19 ] GC_CR_GPC_BIF_MMU_IDLE_STATUS_GPC1_TCU_IDLE_BITFIELD  = 1'h1;
localparam logic [ 20 : 20 ] GC_CR_GPC_BIF_MMU_IDLE_STATUS_GPC1_SPC0_TTT1_4BIF2AXI_IDLE_BITFIELD  = 1'h1;
localparam logic [ 21 : 21 ] GC_CR_GPC_BIF_MMU_IDLE_STATUS_GPC1_SPC0_TTT1_4UTLB_IDLE_BITFIELD  = 1'h1;
localparam logic [ 22 : 22 ] GC_CR_GPC_BIF_MMU_IDLE_STATUS_GPC1_SPC0_TTT1_MTLB_IDLE_BITFIELD  = 1'h1;
localparam logic [ 23 : 23 ] GC_CR_GPC_BIF_MMU_IDLE_STATUS_RESERVE3_BITFIELD   = 1'h0;
localparam logic [ 24 : 24 ] GC_CR_GPC_BIF_MMU_IDLE_STATUS_GPC1_SPC1_TTT0_4BIF2AXI_IDLE_BITFIELD  = 1'h1;
localparam logic [ 25 : 25 ] GC_CR_GPC_BIF_MMU_IDLE_STATUS_GPC1_SPC1_TTT0_4UTLB_IDLE_BITFIELD  = 1'h1;
localparam logic [ 26 : 26 ] GC_CR_GPC_BIF_MMU_IDLE_STATUS_GPC1_SPC1_TTT0_MTLB_IDLE_BITFIELD  = 1'h1;
localparam logic [ 27 : 27 ] GC_CR_GPC_BIF_MMU_IDLE_STATUS_RESERVE4_BITFIELD   = 1'h0;
localparam logic [ 28 : 28 ] GC_CR_GPC_BIF_MMU_IDLE_STATUS_GPC1_SPC1_TTT1_4BIF2AXI_IDLE_BITFIELD  = 1'h1;
localparam logic [ 29 : 29 ] GC_CR_GPC_BIF_MMU_IDLE_STATUS_GPC1_SPC1_TTT1_4UTLB_IDLE_BITFIELD  = 1'h1;
localparam logic [ 30 : 30 ] GC_CR_GPC_BIF_MMU_IDLE_STATUS_GPC1_SPC1_TTT1_MTLB_IDLE_BITFIELD  = 1'h1;
localparam logic [ 31 : 31 ] GC_CR_GPC_BIF_MMU_IDLE_STATUS_RESERVE5_BITFIELD   = 1'h0;
localparam logic [ 32 : 32 ] GC_CR_GPC_BIF_MMU_IDLE_STATUS_GPC2_SPC0_TTT0_4BIF2AXI_IDLE_BITFIELD  = 1'h1;
localparam logic [ 33 : 33 ] GC_CR_GPC_BIF_MMU_IDLE_STATUS_GPC2_SPC0_TTT0_4UTLB_IDLE_BITFIELD  = 1'h1;
localparam logic [ 34 : 34 ] GC_CR_GPC_BIF_MMU_IDLE_STATUS_GPC2_SPC0_TTT0_MTLB_IDLE_BITFIELD  = 1'h1;
localparam logic [ 35 : 35 ] GC_CR_GPC_BIF_MMU_IDLE_STATUS_GPC2_TCU_IDLE_BITFIELD  = 1'h1;
localparam logic [ 36 : 36 ] GC_CR_GPC_BIF_MMU_IDLE_STATUS_GPC2_SPC0_TTT1_4BIF2AXI_IDLE_BITFIELD  = 1'h1;
localparam logic [ 37 : 37 ] GC_CR_GPC_BIF_MMU_IDLE_STATUS_GPC2_SPC0_TTT1_4UTLB_IDLE_BITFIELD  = 1'h1;
localparam logic [ 38 : 38 ] GC_CR_GPC_BIF_MMU_IDLE_STATUS_GPC2_SPC0_TTT1_MTLB_IDLE_BITFIELD  = 1'h1;
localparam logic [ 39 : 39 ] GC_CR_GPC_BIF_MMU_IDLE_STATUS_RESERVE6_BITFIELD   = 1'h0;
localparam logic [ 40 : 40 ] GC_CR_GPC_BIF_MMU_IDLE_STATUS_GPC2_SPC1_TTT0_4BIF2AXI_IDLE_BITFIELD  = 1'h1;
localparam logic [ 41 : 41 ] GC_CR_GPC_BIF_MMU_IDLE_STATUS_GPC2_SPC1_TTT0_4UTLB_IDLE_BITFIELD  = 1'h1;
localparam logic [ 42 : 42 ] GC_CR_GPC_BIF_MMU_IDLE_STATUS_GPC2_SPC1_TTT0_MTLB_IDLE_BITFIELD  = 1'h1;
localparam logic [ 43 : 43 ] GC_CR_GPC_BIF_MMU_IDLE_STATUS_RESERVE7_BITFIELD   = 1'h0;
localparam logic [ 44 : 44 ] GC_CR_GPC_BIF_MMU_IDLE_STATUS_GPC2_SPC1_TTT1_4BIF2AXI_IDLE_BITFIELD  = 1'h1;
localparam logic [ 45 : 45 ] GC_CR_GPC_BIF_MMU_IDLE_STATUS_GPC2_SPC1_TTT1_4UTLB_IDLE_BITFIELD  = 1'h1;
localparam logic [ 46 : 46 ] GC_CR_GPC_BIF_MMU_IDLE_STATUS_GPC2_SPC1_TTT1_MTLB_IDLE_BITFIELD  = 1'h1;
localparam logic [ 47 : 47 ] GC_CR_GPC_BIF_MMU_IDLE_STATUS_RESERVE8_BITFIELD   = 1'h0;
localparam logic [ 48 : 48 ] GC_CR_GPC_BIF_MMU_IDLE_STATUS_GPC3_SPC0_TTT0_4BIF2AXI_IDLE_BITFIELD  = 1'h1;
localparam logic [ 49 : 49 ] GC_CR_GPC_BIF_MMU_IDLE_STATUS_GPC3_SPC0_TTT0_4UTLB_IDLE_BITFIELD  = 1'h1;
localparam logic [ 50 : 50 ] GC_CR_GPC_BIF_MMU_IDLE_STATUS_GPC3_SPC0_TTT0_MTLB_IDLE_BITFIELD  = 1'h1;
localparam logic [ 51 : 51 ] GC_CR_GPC_BIF_MMU_IDLE_STATUS_GPC3_TCU_IDLE_BITFIELD  = 1'h1;
localparam logic [ 52 : 52 ] GC_CR_GPC_BIF_MMU_IDLE_STATUS_GPC3_SPC0_TTT1_4BIF2AXI_IDLE_BITFIELD  = 1'h1;
localparam logic [ 53 : 53 ] GC_CR_GPC_BIF_MMU_IDLE_STATUS_GPC3_SPC0_TTT1_4UTLB_IDLE_BITFIELD  = 1'h1;
localparam logic [ 54 : 54 ] GC_CR_GPC_BIF_MMU_IDLE_STATUS_GPC3_SPC0_TTT1_MTLB_IDLE_BITFIELD  = 1'h1;
localparam logic [ 55 : 55 ] GC_CR_GPC_BIF_MMU_IDLE_STATUS_RESERVE9_BITFIELD   = 1'h0;
localparam logic [ 56 : 56 ] GC_CR_GPC_BIF_MMU_IDLE_STATUS_GPC3_SPC1_TTT0_4BIF2AXI_IDLE_BITFIELD  = 1'h1;
localparam logic [ 57 : 57 ] GC_CR_GPC_BIF_MMU_IDLE_STATUS_GPC3_SPC1_TTT0_4UTLB_IDLE_BITFIELD  = 1'h1;
localparam logic [ 58 : 58 ] GC_CR_GPC_BIF_MMU_IDLE_STATUS_GPC3_SPC1_TTT0_MTLB_IDLE_BITFIELD  = 1'h1;
localparam logic [ 59 : 59 ] GC_CR_GPC_BIF_MMU_IDLE_STATUS_RESERVE10_BITFIELD  = 1'h0;
localparam logic [ 60 : 60 ] GC_CR_GPC_BIF_MMU_IDLE_STATUS_GPC3_SPC1_TTT1_4BIF2AXI_IDLE_BITFIELD  = 1'h1;
localparam logic [ 61 : 61 ] GC_CR_GPC_BIF_MMU_IDLE_STATUS_GPC3_SPC1_TTT1_4UTLB_IDLE_BITFIELD  = 1'h1;
localparam logic [ 62 : 62 ] GC_CR_GPC_BIF_MMU_IDLE_STATUS_GPC3_SPC1_TTT1_MTLB_IDLE_BITFIELD  = 1'h1;
localparam logic [ 63 : 63 ] GC_CR_GPC_BIF_MMU_IDLE_STATUS_RESERVE11_BITFIELD  = 1'h0;

 // gc_cr_cp_bif_mmu_idle_status
localparam logic [ 0 : 0 ] GC_CR_CP_BIF_MMU_IDLE_STATUS_CP_BIF2AXI_IDLE_BITFIELD  = 1'h1;
localparam logic [ 1 : 1 ] GC_CR_CP_BIF_MMU_IDLE_STATUS_CP_UTLB_IDLE_BITFIELD  = 1'h1;
localparam logic [ 2 : 2 ] GC_CR_CP_BIF_MMU_IDLE_STATUS_CP_MTLB_IDLE_BITFIELD  = 1'h1;
localparam logic [ 3 : 3 ] GC_CR_CP_BIF_MMU_IDLE_STATUS_CP_TCU_IDLE_BITFIELD   = 1'h1;

 // gc_cr_mss_multi_chip_raw
localparam logic [ 0 : 0 ] GC_CR_MSS_MULTI_CHIP_RAW_ENABLE_BITFIELD            = 1'h1;

 // gc_cr_raw_config
localparam logic [ 3 : 0 ] GC_CR_RAW_CONFIG_ID_BITFIELD                        = 4'h0;

 // gc_cr_raw_dest_config
localparam logic [ 48 : 0 ] GC_CR_RAW_DEST_CONFIG_ADDR_BITFIELD                = 49'h0;

 // gc_cr_remote_gpu_connect
localparam logic [ 7 : 0 ] GC_CR_REMOTE_GPU_CONNECT_BROKEN_BITFIELD            = 8'h0;

 // gc_cr_mmu_ctrl
localparam logic [ 3 : 0 ] GC_CR_MMU_CTRL_VF_NUM_BITFIELD                      = 4'h0;

 // gc_cr_mmu_vf1_ctrl
localparam logic [ 9 : 0 ] GC_CR_MMU_VF1_CTRL_PASID_NUM_BITFIELD               = 10'h0;

 // gc_cr_mmu_vf2_ctrl
localparam logic [ 9 : 0 ] GC_CR_MMU_VF2_CTRL_PASID_NUM_BITFIELD               = 10'h0;

 // gc_cr_mmu_vf3_ctrl
localparam logic [ 9 : 0 ] GC_CR_MMU_VF3_CTRL_PASID_NUM_BITFIELD               = 10'h0;

 // gc_cr_mmu_vf4_ctrl
localparam logic [ 9 : 0 ] GC_CR_MMU_VF4_CTRL_PASID_NUM_BITFIELD               = 10'h0;

 // gc_cr_mmu_vf5_ctrl
localparam logic [ 9 : 0 ] GC_CR_MMU_VF5_CTRL_PASID_NUM_BITFIELD               = 10'h0;

 // gc_cr_mmu_vf6_ctrl
localparam logic [ 9 : 0 ] GC_CR_MMU_VF6_CTRL_PASID_NUM_BITFIELD               = 10'h0;

 // gc_cr_mmu_vf7_ctrl
localparam logic [ 9 : 0 ] GC_CR_MMU_VF7_CTRL_PASID_NUM_BITFIELD               = 10'h0;

 // gc_cr_mmu_vf8_ctrl
localparam logic [ 9 : 0 ] GC_CR_MMU_VF8_CTRL_PASID_NUM_BITFIELD               = 10'h0;

 // gc_cr_mmu_vf9_ctrl
localparam logic [ 9 : 0 ] GC_CR_MMU_VF9_CTRL_PASID_NUM_BITFIELD               = 10'h0;

 // gc_cr_mmu_vf10_ctrl
localparam logic [ 9 : 0 ] GC_CR_MMU_VF10_CTRL_PASID_NUM_BITFIELD              = 10'h0;

 // gc_cr_mmu_vf11_ctrl
localparam logic [ 9 : 0 ] GC_CR_MMU_VF11_CTRL_PASID_NUM_BITFIELD              = 10'h0;

 // gc_cr_mmu_vf12_ctrl
localparam logic [ 9 : 0 ] GC_CR_MMU_VF12_CTRL_PASID_NUM_BITFIELD              = 10'h0;

 // gc_cr_mmu_vf13_ctrl
localparam logic [ 9 : 0 ] GC_CR_MMU_VF13_CTRL_PASID_NUM_BITFIELD              = 10'h0;

 // gc_cr_mmu_vf14_ctrl
localparam logic [ 9 : 0 ] GC_CR_MMU_VF14_CTRL_PASID_NUM_BITFIELD              = 10'h0;

 // gc_cr_mmu_vf15_ctrl
localparam logic [ 9 : 0 ] GC_CR_MMU_VF15_CTRL_PASID_NUM_BITFIELD              = 10'h0;

 // gc_cr_mmu_pf_ctrl_interrupt
localparam logic [ 0 : 0 ] GC_CR_MMU_PF_CTRL_INTERRUPT_ENABLE_BITFIELD         = 1'h0;

 // gc_cr_mmu_vf1_ctrl_interrupt
localparam logic [ 0 : 0 ] GC_CR_MMU_VF1_CTRL_INTERRUPT_ENABLE_BITFIELD        = 1'h0;

 // gc_cr_mmu_vf2_ctrl_interrupt
localparam logic [ 0 : 0 ] GC_CR_MMU_VF2_CTRL_INTERRUPT_ENABLE_BITFIELD        = 1'h0;

 // gc_cr_mmu_vf3_ctrl_interrupt
localparam logic [ 0 : 0 ] GC_CR_MMU_VF3_CTRL_INTERRUPT_ENABLE_BITFIELD        = 1'h0;

 // gc_cr_mmu_vf4_ctrl_interrupt
localparam logic [ 0 : 0 ] GC_CR_MMU_VF4_CTRL_INTERRUPT_ENABLE_BITFIELD        = 1'h0;

 // gc_cr_mmu_vf5_ctrl_interrupt
localparam logic [ 0 : 0 ] GC_CR_MMU_VF5_CTRL_INTERRUPT_ENABLE_BITFIELD        = 1'h0;

 // gc_cr_mmu_vf6_ctrl_interrupt
localparam logic [ 0 : 0 ] GC_CR_MMU_VF6_CTRL_INTERRUPT_ENABLE_BITFIELD        = 1'h0;

 // gc_cr_mmu_vf7_ctrl_interrupt
localparam logic [ 0 : 0 ] GC_CR_MMU_VF7_CTRL_INTERRUPT_ENABLE_BITFIELD        = 1'h0;

 // gc_cr_mmu_vf8_ctrl_interrupt
localparam logic [ 0 : 0 ] GC_CR_MMU_VF8_CTRL_INTERRUPT_ENABLE_BITFIELD        = 1'h0;

 // gc_cr_mmu_vf9_ctrl_interrupt
localparam logic [ 0 : 0 ] GC_CR_MMU_VF9_CTRL_INTERRUPT_ENABLE_BITFIELD        = 1'h0;

 // gc_cr_mmu_vf10_ctrl_interrupt
localparam logic [ 0 : 0 ] GC_CR_MMU_VF10_CTRL_INTERRUPT_ENABLE_BITFIELD       = 1'h0;

 // gc_cr_mmu_vf11_ctrl_interrupt
localparam logic [ 0 : 0 ] GC_CR_MMU_VF11_CTRL_INTERRUPT_ENABLE_BITFIELD       = 1'h0;

 // gc_cr_mmu_vf12_ctrl_interrupt
localparam logic [ 0 : 0 ] GC_CR_MMU_VF12_CTRL_INTERRUPT_ENABLE_BITFIELD       = 1'h0;

 // gc_cr_mmu_vf13_ctrl_interrupt
localparam logic [ 0 : 0 ] GC_CR_MMU_VF13_CTRL_INTERRUPT_ENABLE_BITFIELD       = 1'h0;

 // gc_cr_mmu_vf14_ctrl_interrupt
localparam logic [ 0 : 0 ] GC_CR_MMU_VF14_CTRL_INTERRUPT_ENABLE_BITFIELD       = 1'h0;

 // gc_cr_mmu_vf15_ctrl_interrupt
localparam logic [ 0 : 0 ] GC_CR_MMU_VF15_CTRL_INTERRUPT_ENABLE_BITFIELD       = 1'h0;

 // gc_cr_mmu_pf_base_mapping0
localparam logic [ 9 : 0 ] GC_CR_MMU_PF_BASE_MAPPING0_PASID_BITFIELD           = 10'h0;

 // gc_cr_mmu_pf_base_mapping1
localparam logic [ 1 : 0 ] GC_CR_MMU_PF_BASE_MAPPING1_TG_BITFIELD              = 2'h0;
localparam logic [ 4 : 4 ] GC_CR_MMU_PF_BASE_MAPPING1_SKIP_BITFIELD            = 1'h0;
localparam logic [ 52 : 8 ] GC_CR_MMU_PF_BASE_MAPPING1_BASE_ADDR_BITFIELD      = 45'h0;
localparam logic [ 53 : 53 ] GC_CR_MMU_PF_BASE_MAPPING1_INVALID_BITFIELD       = 1'h1;

 // gc_cr_mmu_vf1_base_mapping0
localparam logic [ 9 : 0 ] GC_CR_MMU_VF1_BASE_MAPPING0_PASID_BITFIELD          = 10'h0;

 // gc_cr_mmu_vf1_base_mapping1
localparam logic [ 1 : 0 ] GC_CR_MMU_VF1_BASE_MAPPING1_TG_BITFIELD             = 2'h0;
localparam logic [ 4 : 4 ] GC_CR_MMU_VF1_BASE_MAPPING1_SKIP_BITFIELD           = 1'h0;
localparam logic [ 52 : 8 ] GC_CR_MMU_VF1_BASE_MAPPING1_BASE_ADDR_BITFIELD     = 45'h0;
localparam logic [ 53 : 53 ] GC_CR_MMU_VF1_BASE_MAPPING1_INVALID_BITFIELD      = 1'h1;

 // gc_cr_mmu_vf2_base_mapping0
localparam logic [ 9 : 0 ] GC_CR_MMU_VF2_BASE_MAPPING0_PASID_BITFIELD          = 10'h0;

 // gc_cr_mmu_vf2_base_mapping1
localparam logic [ 1 : 0 ] GC_CR_MMU_VF2_BASE_MAPPING1_TG_BITFIELD             = 2'h0;
localparam logic [ 4 : 4 ] GC_CR_MMU_VF2_BASE_MAPPING1_SKIP_BITFIELD           = 1'h0;
localparam logic [ 52 : 8 ] GC_CR_MMU_VF2_BASE_MAPPING1_BASE_ADDR_BITFIELD     = 45'h0;
localparam logic [ 53 : 53 ] GC_CR_MMU_VF2_BASE_MAPPING1_INVALID_BITFIELD      = 1'h1;

 // gc_cr_mmu_vf3_base_mapping0
localparam logic [ 9 : 0 ] GC_CR_MMU_VF3_BASE_MAPPING0_PASID_BITFIELD          = 10'h0;

 // gc_cr_mmu_vf3_base_mapping1
localparam logic [ 1 : 0 ] GC_CR_MMU_VF3_BASE_MAPPING1_TG_BITFIELD             = 2'h0;
localparam logic [ 4 : 4 ] GC_CR_MMU_VF3_BASE_MAPPING1_SKIP_BITFIELD           = 1'h0;
localparam logic [ 52 : 8 ] GC_CR_MMU_VF3_BASE_MAPPING1_BASE_ADDR_BITFIELD     = 45'h0;
localparam logic [ 53 : 53 ] GC_CR_MMU_VF3_BASE_MAPPING1_INVALID_BITFIELD      = 1'h1;

 // gc_cr_mmu_vf4_base_mapping0
localparam logic [ 9 : 0 ] GC_CR_MMU_VF4_BASE_MAPPING0_PASID_BITFIELD          = 10'h0;

 // gc_cr_mmu_vf4_base_mapping1
localparam logic [ 1 : 0 ] GC_CR_MMU_VF4_BASE_MAPPING1_TG_BITFIELD             = 2'h0;
localparam logic [ 4 : 4 ] GC_CR_MMU_VF4_BASE_MAPPING1_SKIP_BITFIELD           = 1'h0;
localparam logic [ 52 : 8 ] GC_CR_MMU_VF4_BASE_MAPPING1_BASE_ADDR_BITFIELD     = 45'h0;
localparam logic [ 53 : 53 ] GC_CR_MMU_VF4_BASE_MAPPING1_INVALID_BITFIELD      = 1'h1;

 // gc_cr_mmu_vf5_base_mapping0
localparam logic [ 9 : 0 ] GC_CR_MMU_VF5_BASE_MAPPING0_PASID_BITFIELD          = 10'h0;

 // gc_cr_mmu_vf5_base_mapping1
localparam logic [ 1 : 0 ] GC_CR_MMU_VF5_BASE_MAPPING1_TG_BITFIELD             = 2'h0;
localparam logic [ 4 : 4 ] GC_CR_MMU_VF5_BASE_MAPPING1_SKIP_BITFIELD           = 1'h0;
localparam logic [ 52 : 8 ] GC_CR_MMU_VF5_BASE_MAPPING1_BASE_ADDR_BITFIELD     = 45'h0;
localparam logic [ 53 : 53 ] GC_CR_MMU_VF5_BASE_MAPPING1_INVALID_BITFIELD      = 1'h1;

 // gc_cr_mmu_vf6_base_mapping0
localparam logic [ 9 : 0 ] GC_CR_MMU_VF6_BASE_MAPPING0_PASID_BITFIELD          = 10'h0;

 // gc_cr_mmu_vf6_base_mapping1
localparam logic [ 1 : 0 ] GC_CR_MMU_VF6_BASE_MAPPING1_TG_BITFIELD             = 2'h0;
localparam logic [ 4 : 4 ] GC_CR_MMU_VF6_BASE_MAPPING1_SKIP_BITFIELD           = 1'h0;
localparam logic [ 52 : 8 ] GC_CR_MMU_VF6_BASE_MAPPING1_BASE_ADDR_BITFIELD     = 45'h0;
localparam logic [ 53 : 53 ] GC_CR_MMU_VF6_BASE_MAPPING1_INVALID_BITFIELD      = 1'h1;

 // gc_cr_mmu_vf7_base_mapping0
localparam logic [ 9 : 0 ] GC_CR_MMU_VF7_BASE_MAPPING0_PASID_BITFIELD          = 10'h0;

 // gc_cr_mmu_vf7_base_mapping1
localparam logic [ 1 : 0 ] GC_CR_MMU_VF7_BASE_MAPPING1_TG_BITFIELD             = 2'h0;
localparam logic [ 4 : 4 ] GC_CR_MMU_VF7_BASE_MAPPING1_SKIP_BITFIELD           = 1'h0;
localparam logic [ 52 : 8 ] GC_CR_MMU_VF7_BASE_MAPPING1_BASE_ADDR_BITFIELD     = 45'h0;
localparam logic [ 53 : 53 ] GC_CR_MMU_VF7_BASE_MAPPING1_INVALID_BITFIELD      = 1'h1;

 // gc_cr_mmu_vf8_base_mapping0
localparam logic [ 9 : 0 ] GC_CR_MMU_VF8_BASE_MAPPING0_PASID_BITFIELD          = 10'h0;

 // gc_cr_mmu_vf8_base_mapping1
localparam logic [ 1 : 0 ] GC_CR_MMU_VF8_BASE_MAPPING1_TG_BITFIELD             = 2'h0;
localparam logic [ 4 : 4 ] GC_CR_MMU_VF8_BASE_MAPPING1_SKIP_BITFIELD           = 1'h0;
localparam logic [ 52 : 8 ] GC_CR_MMU_VF8_BASE_MAPPING1_BASE_ADDR_BITFIELD     = 45'h0;
localparam logic [ 53 : 53 ] GC_CR_MMU_VF8_BASE_MAPPING1_INVALID_BITFIELD      = 1'h1;

 // gc_cr_mmu_vf9_base_mapping0
localparam logic [ 9 : 0 ] GC_CR_MMU_VF9_BASE_MAPPING0_PASID_BITFIELD          = 10'h0;

 // gc_cr_mmu_vf9_base_mapping1
localparam logic [ 1 : 0 ] GC_CR_MMU_VF9_BASE_MAPPING1_TG_BITFIELD             = 2'h0;
localparam logic [ 4 : 4 ] GC_CR_MMU_VF9_BASE_MAPPING1_SKIP_BITFIELD           = 1'h0;
localparam logic [ 52 : 8 ] GC_CR_MMU_VF9_BASE_MAPPING1_BASE_ADDR_BITFIELD     = 45'h0;
localparam logic [ 53 : 53 ] GC_CR_MMU_VF9_BASE_MAPPING1_INVALID_BITFIELD      = 1'h1;

 // gc_cr_mmu_vf10_base_mapping0
localparam logic [ 9 : 0 ] GC_CR_MMU_VF10_BASE_MAPPING0_PASID_BITFIELD         = 10'h0;

 // gc_cr_mmu_vf10_base_mapping1
localparam logic [ 1 : 0 ] GC_CR_MMU_VF10_BASE_MAPPING1_TG_BITFIELD            = 2'h0;
localparam logic [ 4 : 4 ] GC_CR_MMU_VF10_BASE_MAPPING1_SKIP_BITFIELD          = 1'h0;
localparam logic [ 52 : 8 ] GC_CR_MMU_VF10_BASE_MAPPING1_BASE_ADDR_BITFIELD    = 45'h0;
localparam logic [ 53 : 53 ] GC_CR_MMU_VF10_BASE_MAPPING1_INVALID_BITFIELD     = 1'h1;

 // gc_cr_mmu_vf11_base_mapping0
localparam logic [ 9 : 0 ] GC_CR_MMU_VF11_BASE_MAPPING0_PASID_BITFIELD         = 10'h0;

 // gc_cr_mmu_vf11_base_mapping1
localparam logic [ 1 : 0 ] GC_CR_MMU_VF11_BASE_MAPPING1_TG_BITFIELD            = 2'h0;
localparam logic [ 4 : 4 ] GC_CR_MMU_VF11_BASE_MAPPING1_SKIP_BITFIELD          = 1'h0;
localparam logic [ 52 : 8 ] GC_CR_MMU_VF11_BASE_MAPPING1_BASE_ADDR_BITFIELD    = 45'h0;
localparam logic [ 53 : 53 ] GC_CR_MMU_VF11_BASE_MAPPING1_INVALID_BITFIELD     = 1'h1;

 // gc_cr_mmu_vf12_base_mapping0
localparam logic [ 9 : 0 ] GC_CR_MMU_VF12_BASE_MAPPING0_PASID_BITFIELD         = 10'h0;

 // gc_cr_mmu_vf12_base_mapping1
localparam logic [ 1 : 0 ] GC_CR_MMU_VF12_BASE_MAPPING1_TG_BITFIELD            = 2'h0;
localparam logic [ 4 : 4 ] GC_CR_MMU_VF12_BASE_MAPPING1_SKIP_BITFIELD          = 1'h0;
localparam logic [ 52 : 8 ] GC_CR_MMU_VF12_BASE_MAPPING1_BASE_ADDR_BITFIELD    = 45'h0;
localparam logic [ 53 : 53 ] GC_CR_MMU_VF12_BASE_MAPPING1_INVALID_BITFIELD     = 1'h1;

 // gc_cr_mmu_vf13_base_mapping0
localparam logic [ 9 : 0 ] GC_CR_MMU_VF13_BASE_MAPPING0_PASID_BITFIELD         = 10'h0;

 // gc_cr_mmu_vf13_base_mapping1
localparam logic [ 1 : 0 ] GC_CR_MMU_VF13_BASE_MAPPING1_TG_BITFIELD            = 2'h0;
localparam logic [ 4 : 4 ] GC_CR_MMU_VF13_BASE_MAPPING1_SKIP_BITFIELD          = 1'h0;
localparam logic [ 52 : 8 ] GC_CR_MMU_VF13_BASE_MAPPING1_BASE_ADDR_BITFIELD    = 45'h0;
localparam logic [ 53 : 53 ] GC_CR_MMU_VF13_BASE_MAPPING1_INVALID_BITFIELD     = 1'h1;

 // gc_cr_mmu_vf14_base_mapping0
localparam logic [ 9 : 0 ] GC_CR_MMU_VF14_BASE_MAPPING0_PASID_BITFIELD         = 10'h0;

 // gc_cr_mmu_vf14_base_mapping1
localparam logic [ 1 : 0 ] GC_CR_MMU_VF14_BASE_MAPPING1_TG_BITFIELD            = 2'h0;
localparam logic [ 4 : 4 ] GC_CR_MMU_VF14_BASE_MAPPING1_SKIP_BITFIELD          = 1'h0;
localparam logic [ 52 : 8 ] GC_CR_MMU_VF14_BASE_MAPPING1_BASE_ADDR_BITFIELD    = 45'h0;
localparam logic [ 53 : 53 ] GC_CR_MMU_VF14_BASE_MAPPING1_INVALID_BITFIELD     = 1'h1;

 // gc_cr_mmu_vf15_base_mapping0
localparam logic [ 9 : 0 ] GC_CR_MMU_VF15_BASE_MAPPING0_PASID_BITFIELD         = 10'h0;

 // gc_cr_mmu_vf15_base_mapping1
localparam logic [ 1 : 0 ] GC_CR_MMU_VF15_BASE_MAPPING1_TG_BITFIELD            = 2'h0;
localparam logic [ 4 : 4 ] GC_CR_MMU_VF15_BASE_MAPPING1_SKIP_BITFIELD          = 1'h0;
localparam logic [ 52 : 8 ] GC_CR_MMU_VF15_BASE_MAPPING1_BASE_ADDR_BITFIELD    = 45'h0;
localparam logic [ 53 : 53 ] GC_CR_MMU_VF15_BASE_MAPPING1_INVALID_BITFIELD     = 1'h1;

 // gc_cr_mmu_s2_base_mapping0
localparam logic [ 3 : 0 ] GC_CR_MMU_S2_BASE_MAPPING0_VFID_BITFIELD            = 4'h0;
localparam logic [ 11 : 8 ] GC_CR_MMU_S2_BASE_MAPPING0_REG_NUM_BITFIELD        = 4'h0;

 // gc_cr_mmu_s2_base_mapping1
localparam logic [ 19 : 0 ] GC_CR_MMU_S2_BASE_MAPPING1_IPA_SIZE_BITFIELD       = 20'h0;
localparam logic [ 51 : 32 ] GC_CR_MMU_S2_BASE_MAPPING1_IPA_BASE_ADDR_BITFIELD  = 20'h0;

 // gc_cr_mmu_s2_base_mapping2
localparam logic [ 19 : 0 ] GC_CR_MMU_S2_BASE_MAPPING2_PA_BASE_ADDR_BITFIELD   = 20'h0;

 // gc_cr_mmu_fault_status0
localparam logic [ 0 : 0 ] GC_CR_MMU_FAULT_STATUS0_FAULT_BITFIELD              = 1'h0;
localparam logic [ 2 : 1 ] GC_CR_MMU_FAULT_STATUS0_TYPE_BITFIELD               = 2'h0;
localparam logic [ 5 : 3 ] GC_CR_MMU_FAULT_STATUS0_LEVEL_BITFIELD              = 3'h0;
localparam logic [ 7 : 6 ] GC_CR_MMU_FAULT_STATUS0_OP_BITFIELD                 = 2'h0;
localparam logic [ 11 : 8 ] GC_CR_MMU_FAULT_STATUS0_VFID_BITFIELD              = 4'h0;
localparam logic [ 21 : 12 ] GC_CR_MMU_FAULT_STATUS0_PASID_BITFIELD            = 10'h0;
localparam logic [ 27 : 22 ] GC_CR_MMU_FAULT_STATUS0_REQ_ID_BITFIELD           = 6'h0;
localparam logic [ 34 : 28 ] GC_CR_MMU_FAULT_STATUS0_BIF_ID_BITFIELD           = 7'h0;

 // gc_cr_mmu_fault_status1
localparam logic [ 43 : 0 ] GC_CR_MMU_FAULT_STATUS1_ADDR_BITFIELD              = 44'h0;

 // gc_cr_mmu_pf_sync
localparam logic [ 0 : 0 ] GC_CR_MMU_PF_SYNC_COMPLETE_BITFIELD                 = 1'h0;
localparam logic [ 14 : 1 ] GC_CR_MMU_PF_SYNC_CONS_PTR_BITFIELD                = 14'h0;
localparam logic [ 15 : 15 ] GC_CR_MMU_PF_SYNC_CONS_WRAP_BITFIELD              = 1'h0;
localparam logic [ 29 : 16 ] GC_CR_MMU_PF_SYNC_PROD_PTR_BITFIELD               = 14'h0;
localparam logic [ 30 : 30 ] GC_CR_MMU_PF_SYNC_PROD_WRAP_BITFIELD              = 1'h0;

 // gc_cr_mmu_vf1_sync
localparam logic [ 0 : 0 ] GC_CR_MMU_VF1_SYNC_COMPLETE_BITFIELD                = 1'h0;
localparam logic [ 14 : 1 ] GC_CR_MMU_VF1_SYNC_CONS_PTR_BITFIELD               = 14'h0;
localparam logic [ 15 : 15 ] GC_CR_MMU_VF1_SYNC_CONS_WRAP_BITFIELD             = 1'h0;
localparam logic [ 29 : 16 ] GC_CR_MMU_VF1_SYNC_PROD_PTR_BITFIELD              = 14'h0;
localparam logic [ 30 : 30 ] GC_CR_MMU_VF1_SYNC_PROD_WRAP_BITFIELD             = 1'h0;

 // gc_cr_mmu_vf2_sync
localparam logic [ 0 : 0 ] GC_CR_MMU_VF2_SYNC_COMPLETE_BITFIELD                = 1'h0;
localparam logic [ 14 : 1 ] GC_CR_MMU_VF2_SYNC_CONS_PTR_BITFIELD               = 14'h0;
localparam logic [ 15 : 15 ] GC_CR_MMU_VF2_SYNC_CONS_WRAP_BITFIELD             = 1'h0;
localparam logic [ 29 : 16 ] GC_CR_MMU_VF2_SYNC_PROD_PTR_BITFIELD              = 14'h0;
localparam logic [ 30 : 30 ] GC_CR_MMU_VF2_SYNC_PROD_WRAP_BITFIELD             = 1'h0;

 // gc_cr_mmu_vf3_sync
localparam logic [ 0 : 0 ] GC_CR_MMU_VF3_SYNC_COMPLETE_BITFIELD                = 1'h0;
localparam logic [ 14 : 1 ] GC_CR_MMU_VF3_SYNC_CONS_PTR_BITFIELD               = 14'h0;
localparam logic [ 15 : 15 ] GC_CR_MMU_VF3_SYNC_CONS_WRAP_BITFIELD             = 1'h0;
localparam logic [ 29 : 16 ] GC_CR_MMU_VF3_SYNC_PROD_PTR_BITFIELD              = 14'h0;
localparam logic [ 30 : 30 ] GC_CR_MMU_VF3_SYNC_PROD_WRAP_BITFIELD             = 1'h0;

 // gc_cr_mmu_vf4_sync
localparam logic [ 0 : 0 ] GC_CR_MMU_VF4_SYNC_COMPLETE_BITFIELD                = 1'h0;
localparam logic [ 14 : 1 ] GC_CR_MMU_VF4_SYNC_CONS_PTR_BITFIELD               = 14'h0;
localparam logic [ 15 : 15 ] GC_CR_MMU_VF4_SYNC_CONS_WRAP_BITFIELD             = 1'h0;
localparam logic [ 29 : 16 ] GC_CR_MMU_VF4_SYNC_PROD_PTR_BITFIELD              = 14'h0;
localparam logic [ 30 : 30 ] GC_CR_MMU_VF4_SYNC_PROD_WRAP_BITFIELD             = 1'h0;

 // gc_cr_mmu_vf5_sync
localparam logic [ 0 : 0 ] GC_CR_MMU_VF5_SYNC_COMPLETE_BITFIELD                = 1'h0;
localparam logic [ 14 : 1 ] GC_CR_MMU_VF5_SYNC_CONS_PTR_BITFIELD               = 14'h0;
localparam logic [ 15 : 15 ] GC_CR_MMU_VF5_SYNC_CONS_WRAP_BITFIELD             = 1'h0;
localparam logic [ 29 : 16 ] GC_CR_MMU_VF5_SYNC_PROD_PTR_BITFIELD              = 14'h0;
localparam logic [ 30 : 30 ] GC_CR_MMU_VF5_SYNC_PROD_WRAP_BITFIELD             = 1'h0;

 // gc_cr_mmu_vf6_sync
localparam logic [ 0 : 0 ] GC_CR_MMU_VF6_SYNC_COMPLETE_BITFIELD                = 1'h0;
localparam logic [ 14 : 1 ] GC_CR_MMU_VF6_SYNC_CONS_PTR_BITFIELD               = 14'h0;
localparam logic [ 15 : 15 ] GC_CR_MMU_VF6_SYNC_CONS_WRAP_BITFIELD             = 1'h0;
localparam logic [ 29 : 16 ] GC_CR_MMU_VF6_SYNC_PROD_PTR_BITFIELD              = 14'h0;
localparam logic [ 30 : 30 ] GC_CR_MMU_VF6_SYNC_PROD_WRAP_BITFIELD             = 1'h0;

 // gc_cr_mmu_vf7_sync
localparam logic [ 0 : 0 ] GC_CR_MMU_VF7_SYNC_COMPLETE_BITFIELD                = 1'h0;
localparam logic [ 14 : 1 ] GC_CR_MMU_VF7_SYNC_CONS_PTR_BITFIELD               = 14'h0;
localparam logic [ 15 : 15 ] GC_CR_MMU_VF7_SYNC_CONS_WRAP_BITFIELD             = 1'h0;
localparam logic [ 29 : 16 ] GC_CR_MMU_VF7_SYNC_PROD_PTR_BITFIELD              = 14'h0;
localparam logic [ 30 : 30 ] GC_CR_MMU_VF7_SYNC_PROD_WRAP_BITFIELD             = 1'h0;

 // gc_cr_mmu_vf8_sync
localparam logic [ 0 : 0 ] GC_CR_MMU_VF8_SYNC_COMPLETE_BITFIELD                = 1'h0;
localparam logic [ 14 : 1 ] GC_CR_MMU_VF8_SYNC_CONS_PTR_BITFIELD               = 14'h0;
localparam logic [ 15 : 15 ] GC_CR_MMU_VF8_SYNC_CONS_WRAP_BITFIELD             = 1'h0;
localparam logic [ 29 : 16 ] GC_CR_MMU_VF8_SYNC_PROD_PTR_BITFIELD              = 14'h0;
localparam logic [ 30 : 30 ] GC_CR_MMU_VF8_SYNC_PROD_WRAP_BITFIELD             = 1'h0;

 // gc_cr_mmu_vf9_sync
localparam logic [ 0 : 0 ] GC_CR_MMU_VF9_SYNC_COMPLETE_BITFIELD                = 1'h0;
localparam logic [ 14 : 1 ] GC_CR_MMU_VF9_SYNC_CONS_PTR_BITFIELD               = 14'h0;
localparam logic [ 15 : 15 ] GC_CR_MMU_VF9_SYNC_CONS_WRAP_BITFIELD             = 1'h0;
localparam logic [ 29 : 16 ] GC_CR_MMU_VF9_SYNC_PROD_PTR_BITFIELD              = 14'h0;
localparam logic [ 30 : 30 ] GC_CR_MMU_VF9_SYNC_PROD_WRAP_BITFIELD             = 1'h0;

 // gc_cr_mmu_vf10_sync
localparam logic [ 0 : 0 ] GC_CR_MMU_VF10_SYNC_COMPLETE_BITFIELD               = 1'h0;
localparam logic [ 14 : 1 ] GC_CR_MMU_VF10_SYNC_CONS_PTR_BITFIELD              = 14'h0;
localparam logic [ 15 : 15 ] GC_CR_MMU_VF10_SYNC_CONS_WRAP_BITFIELD            = 1'h0;
localparam logic [ 29 : 16 ] GC_CR_MMU_VF10_SYNC_PROD_PTR_BITFIELD             = 14'h0;
localparam logic [ 30 : 30 ] GC_CR_MMU_VF10_SYNC_PROD_WRAP_BITFIELD            = 1'h0;

 // gc_cr_mmu_vf11_sync
localparam logic [ 0 : 0 ] GC_CR_MMU_VF11_SYNC_COMPLETE_BITFIELD               = 1'h0;
localparam logic [ 14 : 1 ] GC_CR_MMU_VF11_SYNC_CONS_PTR_BITFIELD              = 14'h0;
localparam logic [ 15 : 15 ] GC_CR_MMU_VF11_SYNC_CONS_WRAP_BITFIELD            = 1'h0;
localparam logic [ 29 : 16 ] GC_CR_MMU_VF11_SYNC_PROD_PTR_BITFIELD             = 14'h0;
localparam logic [ 30 : 30 ] GC_CR_MMU_VF11_SYNC_PROD_WRAP_BITFIELD            = 1'h0;

 // gc_cr_mmu_vf12_sync
localparam logic [ 0 : 0 ] GC_CR_MMU_VF12_SYNC_COMPLETE_BITFIELD               = 1'h0;
localparam logic [ 14 : 1 ] GC_CR_MMU_VF12_SYNC_CONS_PTR_BITFIELD              = 14'h0;
localparam logic [ 15 : 15 ] GC_CR_MMU_VF12_SYNC_CONS_WRAP_BITFIELD            = 1'h0;
localparam logic [ 29 : 16 ] GC_CR_MMU_VF12_SYNC_PROD_PTR_BITFIELD             = 14'h0;
localparam logic [ 30 : 30 ] GC_CR_MMU_VF12_SYNC_PROD_WRAP_BITFIELD            = 1'h0;

 // gc_cr_mmu_vf13_sync
localparam logic [ 0 : 0 ] GC_CR_MMU_VF13_SYNC_COMPLETE_BITFIELD               = 1'h0;
localparam logic [ 14 : 1 ] GC_CR_MMU_VF13_SYNC_CONS_PTR_BITFIELD              = 14'h0;
localparam logic [ 15 : 15 ] GC_CR_MMU_VF13_SYNC_CONS_WRAP_BITFIELD            = 1'h0;
localparam logic [ 29 : 16 ] GC_CR_MMU_VF13_SYNC_PROD_PTR_BITFIELD             = 14'h0;
localparam logic [ 30 : 30 ] GC_CR_MMU_VF13_SYNC_PROD_WRAP_BITFIELD            = 1'h0;

 // gc_cr_mmu_vf14_sync
localparam logic [ 0 : 0 ] GC_CR_MMU_VF14_SYNC_COMPLETE_BITFIELD               = 1'h0;
localparam logic [ 14 : 1 ] GC_CR_MMU_VF14_SYNC_CONS_PTR_BITFIELD              = 14'h0;
localparam logic [ 15 : 15 ] GC_CR_MMU_VF14_SYNC_CONS_WRAP_BITFIELD            = 1'h0;
localparam logic [ 29 : 16 ] GC_CR_MMU_VF14_SYNC_PROD_PTR_BITFIELD             = 14'h0;
localparam logic [ 30 : 30 ] GC_CR_MMU_VF14_SYNC_PROD_WRAP_BITFIELD            = 1'h0;

 // gc_cr_mmu_vf15_sync
localparam logic [ 0 : 0 ] GC_CR_MMU_VF15_SYNC_COMPLETE_BITFIELD               = 1'h0;
localparam logic [ 14 : 1 ] GC_CR_MMU_VF15_SYNC_CONS_PTR_BITFIELD              = 14'h0;
localparam logic [ 15 : 15 ] GC_CR_MMU_VF15_SYNC_CONS_WRAP_BITFIELD            = 1'h0;
localparam logic [ 29 : 16 ] GC_CR_MMU_VF15_SYNC_PROD_PTR_BITFIELD             = 14'h0;
localparam logic [ 30 : 30 ] GC_CR_MMU_VF15_SYNC_PROD_WRAP_BITFIELD            = 1'h0;

 // gc_cr_mmu_pf_cmd0
localparam logic [ 7 : 0 ] GC_CR_MMU_PF_CMD0_TYPE_BITFIELD                     = 8'h0;
localparam logic [ 16 : 12 ] GC_CR_MMU_PF_CMD0_NUM_BITFIELD                    = 5'h0;
localparam logic [ 24 : 20 ] GC_CR_MMU_PF_CMD0_SCALE_BITFIELD                  = 5'h0;
localparam logic [ 47 : 32 ] GC_CR_MMU_PF_CMD0_VFID_BITFIELD                   = 16'h0;
localparam logic [ 63 : 48 ] GC_CR_MMU_PF_CMD0_PASID_BITFIELD                  = 16'h0;

 // gc_cr_mmu_pf_cmd1
localparam logic [ 0 : 0 ] GC_CR_MMU_PF_CMD1_LEAF_BITFIELD                     = 1'h0;
localparam logic [ 9 : 8 ] GC_CR_MMU_PF_CMD1_TTL_BITFIELD                      = 2'h0;
localparam logic [ 11 : 10 ] GC_CR_MMU_PF_CMD1_TG_BITFIELD                     = 2'h0;
localparam logic [ 63 : 12 ] GC_CR_MMU_PF_CMD1_ADDR_BITFIELD                   = 52'h0;

 // gc_cr_mmu_vf1_cmd0
localparam logic [ 7 : 0 ] GC_CR_MMU_VF1_CMD0_TYPE_BITFIELD                    = 8'h0;
localparam logic [ 16 : 12 ] GC_CR_MMU_VF1_CMD0_NUM_BITFIELD                   = 5'h0;
localparam logic [ 24 : 20 ] GC_CR_MMU_VF1_CMD0_SCALE_BITFIELD                 = 5'h0;
localparam logic [ 47 : 32 ] GC_CR_MMU_VF1_CMD0_VFID_BITFIELD                  = 16'h0;
localparam logic [ 63 : 48 ] GC_CR_MMU_VF1_CMD0_PASID_BITFIELD                 = 16'h0;

 // gc_cr_mmu_vf1_cmd1
localparam logic [ 0 : 0 ] GC_CR_MMU_VF1_CMD1_LEAF_BITFIELD                    = 1'h0;
localparam logic [ 9 : 8 ] GC_CR_MMU_VF1_CMD1_TTL_BITFIELD                     = 2'h0;
localparam logic [ 11 : 10 ] GC_CR_MMU_VF1_CMD1_TG_BITFIELD                    = 2'h0;
localparam logic [ 63 : 12 ] GC_CR_MMU_VF1_CMD1_ADDR_BITFIELD                  = 52'h0;

 // gc_cr_mmu_vf2_cmd0
localparam logic [ 7 : 0 ] GC_CR_MMU_VF2_CMD0_TYPE_BITFIELD                    = 8'h0;
localparam logic [ 16 : 12 ] GC_CR_MMU_VF2_CMD0_NUM_BITFIELD                   = 5'h0;
localparam logic [ 24 : 20 ] GC_CR_MMU_VF2_CMD0_SCALE_BITFIELD                 = 5'h0;
localparam logic [ 47 : 32 ] GC_CR_MMU_VF2_CMD0_VFID_BITFIELD                  = 16'h0;
localparam logic [ 63 : 48 ] GC_CR_MMU_VF2_CMD0_PASID_BITFIELD                 = 16'h0;

 // gc_cr_mmu_vf2_cmd1
localparam logic [ 0 : 0 ] GC_CR_MMU_VF2_CMD1_LEAF_BITFIELD                    = 1'h0;
localparam logic [ 9 : 8 ] GC_CR_MMU_VF2_CMD1_TTL_BITFIELD                     = 2'h0;
localparam logic [ 11 : 10 ] GC_CR_MMU_VF2_CMD1_TG_BITFIELD                    = 2'h0;
localparam logic [ 63 : 12 ] GC_CR_MMU_VF2_CMD1_ADDR_BITFIELD                  = 52'h0;

 // gc_cr_mmu_vf3_cmd0
localparam logic [ 7 : 0 ] GC_CR_MMU_VF3_CMD0_TYPE_BITFIELD                    = 8'h0;
localparam logic [ 16 : 12 ] GC_CR_MMU_VF3_CMD0_NUM_BITFIELD                   = 5'h0;
localparam logic [ 24 : 20 ] GC_CR_MMU_VF3_CMD0_SCALE_BITFIELD                 = 5'h0;
localparam logic [ 47 : 32 ] GC_CR_MMU_VF3_CMD0_VFID_BITFIELD                  = 16'h0;
localparam logic [ 63 : 48 ] GC_CR_MMU_VF3_CMD0_PASID_BITFIELD                 = 16'h0;

 // gc_cr_mmu_vf3_cmd1
localparam logic [ 0 : 0 ] GC_CR_MMU_VF3_CMD1_LEAF_BITFIELD                    = 1'h0;
localparam logic [ 9 : 8 ] GC_CR_MMU_VF3_CMD1_TTL_BITFIELD                     = 2'h0;
localparam logic [ 11 : 10 ] GC_CR_MMU_VF3_CMD1_TG_BITFIELD                    = 2'h0;
localparam logic [ 63 : 12 ] GC_CR_MMU_VF3_CMD1_ADDR_BITFIELD                  = 52'h0;

 // gc_cr_mmu_vf4_cmd0
localparam logic [ 7 : 0 ] GC_CR_MMU_VF4_CMD0_TYPE_BITFIELD                    = 8'h0;
localparam logic [ 16 : 12 ] GC_CR_MMU_VF4_CMD0_NUM_BITFIELD                   = 5'h0;
localparam logic [ 24 : 20 ] GC_CR_MMU_VF4_CMD0_SCALE_BITFIELD                 = 5'h0;
localparam logic [ 47 : 32 ] GC_CR_MMU_VF4_CMD0_VFID_BITFIELD                  = 16'h0;
localparam logic [ 63 : 48 ] GC_CR_MMU_VF4_CMD0_PASID_BITFIELD                 = 16'h0;

 // gc_cr_mmu_vf4_cmd1
localparam logic [ 0 : 0 ] GC_CR_MMU_VF4_CMD1_LEAF_BITFIELD                    = 1'h0;
localparam logic [ 9 : 8 ] GC_CR_MMU_VF4_CMD1_TTL_BITFIELD                     = 2'h0;
localparam logic [ 11 : 10 ] GC_CR_MMU_VF4_CMD1_TG_BITFIELD                    = 2'h0;
localparam logic [ 63 : 12 ] GC_CR_MMU_VF4_CMD1_ADDR_BITFIELD                  = 52'h0;

 // gc_cr_mmu_vf5_cmd0
localparam logic [ 7 : 0 ] GC_CR_MMU_VF5_CMD0_TYPE_BITFIELD                    = 8'h0;
localparam logic [ 16 : 12 ] GC_CR_MMU_VF5_CMD0_NUM_BITFIELD                   = 5'h0;
localparam logic [ 24 : 20 ] GC_CR_MMU_VF5_CMD0_SCALE_BITFIELD                 = 5'h0;
localparam logic [ 47 : 32 ] GC_CR_MMU_VF5_CMD0_VFID_BITFIELD                  = 16'h0;
localparam logic [ 63 : 48 ] GC_CR_MMU_VF5_CMD0_PASID_BITFIELD                 = 16'h0;

 // gc_cr_mmu_vf5_cmd1
localparam logic [ 0 : 0 ] GC_CR_MMU_VF5_CMD1_LEAF_BITFIELD                    = 1'h0;
localparam logic [ 9 : 8 ] GC_CR_MMU_VF5_CMD1_TTL_BITFIELD                     = 2'h0;
localparam logic [ 11 : 10 ] GC_CR_MMU_VF5_CMD1_TG_BITFIELD                    = 2'h0;
localparam logic [ 63 : 12 ] GC_CR_MMU_VF5_CMD1_ADDR_BITFIELD                  = 52'h0;

 // gc_cr_mmu_vf6_cmd0
localparam logic [ 7 : 0 ] GC_CR_MMU_VF6_CMD0_TYPE_BITFIELD                    = 8'h0;
localparam logic [ 16 : 12 ] GC_CR_MMU_VF6_CMD0_NUM_BITFIELD                   = 5'h0;
localparam logic [ 24 : 20 ] GC_CR_MMU_VF6_CMD0_SCALE_BITFIELD                 = 5'h0;
localparam logic [ 47 : 32 ] GC_CR_MMU_VF6_CMD0_VFID_BITFIELD                  = 16'h0;
localparam logic [ 63 : 48 ] GC_CR_MMU_VF6_CMD0_PASID_BITFIELD                 = 16'h0;

 // gc_cr_mmu_vf6_cmd1
localparam logic [ 0 : 0 ] GC_CR_MMU_VF6_CMD1_LEAF_BITFIELD                    = 1'h0;
localparam logic [ 9 : 8 ] GC_CR_MMU_VF6_CMD1_TTL_BITFIELD                     = 2'h0;
localparam logic [ 11 : 10 ] GC_CR_MMU_VF6_CMD1_TG_BITFIELD                    = 2'h0;
localparam logic [ 63 : 12 ] GC_CR_MMU_VF6_CMD1_ADDR_BITFIELD                  = 52'h0;

 // gc_cr_mmu_vf7_cmd0
localparam logic [ 7 : 0 ] GC_CR_MMU_VF7_CMD0_TYPE_BITFIELD                    = 8'h0;
localparam logic [ 16 : 12 ] GC_CR_MMU_VF7_CMD0_NUM_BITFIELD                   = 5'h0;
localparam logic [ 24 : 20 ] GC_CR_MMU_VF7_CMD0_SCALE_BITFIELD                 = 5'h0;
localparam logic [ 47 : 32 ] GC_CR_MMU_VF7_CMD0_VFID_BITFIELD                  = 16'h0;
localparam logic [ 63 : 48 ] GC_CR_MMU_VF7_CMD0_PASID_BITFIELD                 = 16'h0;

 // gc_cr_mmu_vf7_cmd1
localparam logic [ 0 : 0 ] GC_CR_MMU_VF7_CMD1_LEAF_BITFIELD                    = 1'h0;
localparam logic [ 9 : 8 ] GC_CR_MMU_VF7_CMD1_TTL_BITFIELD                     = 2'h0;
localparam logic [ 11 : 10 ] GC_CR_MMU_VF7_CMD1_TG_BITFIELD                    = 2'h0;
localparam logic [ 63 : 12 ] GC_CR_MMU_VF7_CMD1_ADDR_BITFIELD                  = 52'h0;

 // gc_cr_mmu_vf8_cmd0
localparam logic [ 7 : 0 ] GC_CR_MMU_VF8_CMD0_TYPE_BITFIELD                    = 8'h0;
localparam logic [ 16 : 12 ] GC_CR_MMU_VF8_CMD0_NUM_BITFIELD                   = 5'h0;
localparam logic [ 24 : 20 ] GC_CR_MMU_VF8_CMD0_SCALE_BITFIELD                 = 5'h0;
localparam logic [ 47 : 32 ] GC_CR_MMU_VF8_CMD0_VFID_BITFIELD                  = 16'h0;
localparam logic [ 63 : 48 ] GC_CR_MMU_VF8_CMD0_PASID_BITFIELD                 = 16'h0;

 // gc_cr_mmu_vf8_cmd1
localparam logic [ 0 : 0 ] GC_CR_MMU_VF8_CMD1_LEAF_BITFIELD                    = 1'h0;
localparam logic [ 9 : 8 ] GC_CR_MMU_VF8_CMD1_TTL_BITFIELD                     = 2'h0;
localparam logic [ 11 : 10 ] GC_CR_MMU_VF8_CMD1_TG_BITFIELD                    = 2'h0;
localparam logic [ 63 : 12 ] GC_CR_MMU_VF8_CMD1_ADDR_BITFIELD                  = 52'h0;

 // gc_cr_mmu_vf9_cmd0
localparam logic [ 7 : 0 ] GC_CR_MMU_VF9_CMD0_TYPE_BITFIELD                    = 8'h0;
localparam logic [ 16 : 12 ] GC_CR_MMU_VF9_CMD0_NUM_BITFIELD                   = 5'h0;
localparam logic [ 24 : 20 ] GC_CR_MMU_VF9_CMD0_SCALE_BITFIELD                 = 5'h0;
localparam logic [ 47 : 32 ] GC_CR_MMU_VF9_CMD0_VFID_BITFIELD                  = 16'h0;
localparam logic [ 63 : 48 ] GC_CR_MMU_VF9_CMD0_PASID_BITFIELD                 = 16'h0;

 // gc_cr_mmu_vf9_cmd1
localparam logic [ 0 : 0 ] GC_CR_MMU_VF9_CMD1_LEAF_BITFIELD                    = 1'h0;
localparam logic [ 9 : 8 ] GC_CR_MMU_VF9_CMD1_TTL_BITFIELD                     = 2'h0;
localparam logic [ 11 : 10 ] GC_CR_MMU_VF9_CMD1_TG_BITFIELD                    = 2'h0;
localparam logic [ 63 : 12 ] GC_CR_MMU_VF9_CMD1_ADDR_BITFIELD                  = 52'h0;

 // gc_cr_mmu_vf10_cmd0
localparam logic [ 7 : 0 ] GC_CR_MMU_VF10_CMD0_TYPE_BITFIELD                   = 8'h0;
localparam logic [ 16 : 12 ] GC_CR_MMU_VF10_CMD0_NUM_BITFIELD                  = 5'h0;
localparam logic [ 24 : 20 ] GC_CR_MMU_VF10_CMD0_SCALE_BITFIELD                = 5'h0;
localparam logic [ 47 : 32 ] GC_CR_MMU_VF10_CMD0_VFID_BITFIELD                 = 16'h0;
localparam logic [ 63 : 48 ] GC_CR_MMU_VF10_CMD0_PASID_BITFIELD                = 16'h0;

 // gc_cr_mmu_vf10_cmd1
localparam logic [ 0 : 0 ] GC_CR_MMU_VF10_CMD1_LEAF_BITFIELD                   = 1'h0;
localparam logic [ 9 : 8 ] GC_CR_MMU_VF10_CMD1_TTL_BITFIELD                    = 2'h0;
localparam logic [ 11 : 10 ] GC_CR_MMU_VF10_CMD1_TG_BITFIELD                   = 2'h0;
localparam logic [ 63 : 12 ] GC_CR_MMU_VF10_CMD1_ADDR_BITFIELD                 = 52'h0;

 // gc_cr_mmu_vf11_cmd0
localparam logic [ 7 : 0 ] GC_CR_MMU_VF11_CMD0_TYPE_BITFIELD                   = 8'h0;
localparam logic [ 16 : 12 ] GC_CR_MMU_VF11_CMD0_NUM_BITFIELD                  = 5'h0;
localparam logic [ 24 : 20 ] GC_CR_MMU_VF11_CMD0_SCALE_BITFIELD                = 5'h0;
localparam logic [ 47 : 32 ] GC_CR_MMU_VF11_CMD0_VFID_BITFIELD                 = 16'h0;
localparam logic [ 63 : 48 ] GC_CR_MMU_VF11_CMD0_PASID_BITFIELD                = 16'h0;

 // gc_cr_mmu_vf11_cmd1
localparam logic [ 0 : 0 ] GC_CR_MMU_VF11_CMD1_LEAF_BITFIELD                   = 1'h0;
localparam logic [ 9 : 8 ] GC_CR_MMU_VF11_CMD1_TTL_BITFIELD                    = 2'h0;
localparam logic [ 11 : 10 ] GC_CR_MMU_VF11_CMD1_TG_BITFIELD                   = 2'h0;
localparam logic [ 63 : 12 ] GC_CR_MMU_VF11_CMD1_ADDR_BITFIELD                 = 52'h0;

 // gc_cr_mmu_vf12_cmd0
localparam logic [ 7 : 0 ] GC_CR_MMU_VF12_CMD0_TYPE_BITFIELD                   = 8'h0;
localparam logic [ 16 : 12 ] GC_CR_MMU_VF12_CMD0_NUM_BITFIELD                  = 5'h0;
localparam logic [ 24 : 20 ] GC_CR_MMU_VF12_CMD0_SCALE_BITFIELD                = 5'h0;
localparam logic [ 47 : 32 ] GC_CR_MMU_VF12_CMD0_VFID_BITFIELD                 = 16'h0;
localparam logic [ 63 : 48 ] GC_CR_MMU_VF12_CMD0_PASID_BITFIELD                = 16'h0;

 // gc_cr_mmu_vf12_cmd1
localparam logic [ 0 : 0 ] GC_CR_MMU_VF12_CMD1_LEAF_BITFIELD                   = 1'h0;
localparam logic [ 9 : 8 ] GC_CR_MMU_VF12_CMD1_TTL_BITFIELD                    = 2'h0;
localparam logic [ 11 : 10 ] GC_CR_MMU_VF12_CMD1_TG_BITFIELD                   = 2'h0;
localparam logic [ 63 : 12 ] GC_CR_MMU_VF12_CMD1_ADDR_BITFIELD                 = 52'h0;

 // gc_cr_mmu_vf13_cmd0
localparam logic [ 7 : 0 ] GC_CR_MMU_VF13_CMD0_TYPE_BITFIELD                   = 8'h0;
localparam logic [ 16 : 12 ] GC_CR_MMU_VF13_CMD0_NUM_BITFIELD                  = 5'h0;
localparam logic [ 24 : 20 ] GC_CR_MMU_VF13_CMD0_SCALE_BITFIELD                = 5'h0;
localparam logic [ 47 : 32 ] GC_CR_MMU_VF13_CMD0_VFID_BITFIELD                 = 16'h0;
localparam logic [ 63 : 48 ] GC_CR_MMU_VF13_CMD0_PASID_BITFIELD                = 16'h0;

 // gc_cr_mmu_vf13_cmd1
localparam logic [ 0 : 0 ] GC_CR_MMU_VF13_CMD1_LEAF_BITFIELD                   = 1'h0;
localparam logic [ 9 : 8 ] GC_CR_MMU_VF13_CMD1_TTL_BITFIELD                    = 2'h0;
localparam logic [ 11 : 10 ] GC_CR_MMU_VF13_CMD1_TG_BITFIELD                   = 2'h0;
localparam logic [ 63 : 12 ] GC_CR_MMU_VF13_CMD1_ADDR_BITFIELD                 = 52'h0;

 // gc_cr_mmu_vf14_cmd0
localparam logic [ 7 : 0 ] GC_CR_MMU_VF14_CMD0_TYPE_BITFIELD                   = 8'h0;
localparam logic [ 16 : 12 ] GC_CR_MMU_VF14_CMD0_NUM_BITFIELD                  = 5'h0;
localparam logic [ 24 : 20 ] GC_CR_MMU_VF14_CMD0_SCALE_BITFIELD                = 5'h0;
localparam logic [ 47 : 32 ] GC_CR_MMU_VF14_CMD0_VFID_BITFIELD                 = 16'h0;
localparam logic [ 63 : 48 ] GC_CR_MMU_VF14_CMD0_PASID_BITFIELD                = 16'h0;

 // gc_cr_mmu_vf14_cmd1
localparam logic [ 0 : 0 ] GC_CR_MMU_VF14_CMD1_LEAF_BITFIELD                   = 1'h0;
localparam logic [ 9 : 8 ] GC_CR_MMU_VF14_CMD1_TTL_BITFIELD                    = 2'h0;
localparam logic [ 11 : 10 ] GC_CR_MMU_VF14_CMD1_TG_BITFIELD                   = 2'h0;
localparam logic [ 63 : 12 ] GC_CR_MMU_VF14_CMD1_ADDR_BITFIELD                 = 52'h0;

 // gc_cr_mmu_vf15_cmd0
localparam logic [ 7 : 0 ] GC_CR_MMU_VF15_CMD0_TYPE_BITFIELD                   = 8'h0;
localparam logic [ 16 : 12 ] GC_CR_MMU_VF15_CMD0_NUM_BITFIELD                  = 5'h0;
localparam logic [ 24 : 20 ] GC_CR_MMU_VF15_CMD0_SCALE_BITFIELD                = 5'h0;
localparam logic [ 47 : 32 ] GC_CR_MMU_VF15_CMD0_VFID_BITFIELD                 = 16'h0;
localparam logic [ 63 : 48 ] GC_CR_MMU_VF15_CMD0_PASID_BITFIELD                = 16'h0;

 // gc_cr_mmu_vf15_cmd1
localparam logic [ 0 : 0 ] GC_CR_MMU_VF15_CMD1_LEAF_BITFIELD                   = 1'h0;
localparam logic [ 9 : 8 ] GC_CR_MMU_VF15_CMD1_TTL_BITFIELD                    = 2'h0;
localparam logic [ 11 : 10 ] GC_CR_MMU_VF15_CMD1_TG_BITFIELD                   = 2'h0;
localparam logic [ 63 : 12 ] GC_CR_MMU_VF15_CMD1_ADDR_BITFIELD                 = 52'h0;

 // gc_cr_mmu_pf_cmd_queue_info
localparam logic [ 13 : 0 ] GC_CR_MMU_PF_CMD_QUEUE_INFO_PROD_PTR_BITFIELD      = 14'h0;
localparam logic [ 15 : 15 ] GC_CR_MMU_PF_CMD_QUEUE_INFO_PROD_WRAP_BITFIELD    = 1'h0;
localparam logic [ 29 : 16 ] GC_CR_MMU_PF_CMD_QUEUE_INFO_CONS_PTR_BITFIELD     = 14'h0;
localparam logic [ 31 : 31 ] GC_CR_MMU_PF_CMD_QUEUE_INFO_CONS_WRAP_BITFIELD    = 1'h0;
localparam logic [ 47 : 32 ] GC_CR_MMU_PF_CMD_QUEUE_INFO_TOTAL_SIZE_BITFIELD   = 16'h1000;

 // gc_cr_mmu_vf1_cmd_queue_info
localparam logic [ 13 : 0 ] GC_CR_MMU_VF1_CMD_QUEUE_INFO_PROD_PTR_BITFIELD     = 14'h0;
localparam logic [ 15 : 15 ] GC_CR_MMU_VF1_CMD_QUEUE_INFO_PROD_WRAP_BITFIELD   = 1'h0;
localparam logic [ 29 : 16 ] GC_CR_MMU_VF1_CMD_QUEUE_INFO_CONS_PTR_BITFIELD    = 14'h0;
localparam logic [ 31 : 31 ] GC_CR_MMU_VF1_CMD_QUEUE_INFO_CONS_WRAP_BITFIELD   = 1'h0;
localparam logic [ 47 : 32 ] GC_CR_MMU_VF1_CMD_QUEUE_INFO_TOTAL_SIZE_BITFIELD  = 16'h0;

 // gc_cr_mmu_vf2_cmd_queue_info
localparam logic [ 13 : 0 ] GC_CR_MMU_VF2_CMD_QUEUE_INFO_PROD_PTR_BITFIELD     = 14'h0;
localparam logic [ 15 : 15 ] GC_CR_MMU_VF2_CMD_QUEUE_INFO_PROD_WRAP_BITFIELD   = 1'h0;
localparam logic [ 29 : 16 ] GC_CR_MMU_VF2_CMD_QUEUE_INFO_CONS_PTR_BITFIELD    = 14'h0;
localparam logic [ 31 : 31 ] GC_CR_MMU_VF2_CMD_QUEUE_INFO_CONS_WRAP_BITFIELD   = 1'h0;
localparam logic [ 47 : 32 ] GC_CR_MMU_VF2_CMD_QUEUE_INFO_TOTAL_SIZE_BITFIELD  = 16'h0;

 // gc_cr_mmu_vf3_cmd_queue_info
localparam logic [ 13 : 0 ] GC_CR_MMU_VF3_CMD_QUEUE_INFO_PROD_PTR_BITFIELD     = 14'h0;
localparam logic [ 15 : 15 ] GC_CR_MMU_VF3_CMD_QUEUE_INFO_PROD_WRAP_BITFIELD   = 1'h0;
localparam logic [ 29 : 16 ] GC_CR_MMU_VF3_CMD_QUEUE_INFO_CONS_PTR_BITFIELD    = 14'h0;
localparam logic [ 31 : 31 ] GC_CR_MMU_VF3_CMD_QUEUE_INFO_CONS_WRAP_BITFIELD   = 1'h0;
localparam logic [ 47 : 32 ] GC_CR_MMU_VF3_CMD_QUEUE_INFO_TOTAL_SIZE_BITFIELD  = 16'h0;

 // gc_cr_mmu_vf4_cmd_queue_info
localparam logic [ 13 : 0 ] GC_CR_MMU_VF4_CMD_QUEUE_INFO_PROD_PTR_BITFIELD     = 14'h0;
localparam logic [ 15 : 15 ] GC_CR_MMU_VF4_CMD_QUEUE_INFO_PROD_WRAP_BITFIELD   = 1'h0;
localparam logic [ 29 : 16 ] GC_CR_MMU_VF4_CMD_QUEUE_INFO_CONS_PTR_BITFIELD    = 14'h0;
localparam logic [ 31 : 31 ] GC_CR_MMU_VF4_CMD_QUEUE_INFO_CONS_WRAP_BITFIELD   = 1'h0;
localparam logic [ 47 : 32 ] GC_CR_MMU_VF4_CMD_QUEUE_INFO_TOTAL_SIZE_BITFIELD  = 16'h0;

 // gc_cr_mmu_vf5_cmd_queue_info
localparam logic [ 13 : 0 ] GC_CR_MMU_VF5_CMD_QUEUE_INFO_PROD_PTR_BITFIELD     = 14'h0;
localparam logic [ 15 : 15 ] GC_CR_MMU_VF5_CMD_QUEUE_INFO_PROD_WRAP_BITFIELD   = 1'h0;
localparam logic [ 29 : 16 ] GC_CR_MMU_VF5_CMD_QUEUE_INFO_CONS_PTR_BITFIELD    = 14'h0;
localparam logic [ 31 : 31 ] GC_CR_MMU_VF5_CMD_QUEUE_INFO_CONS_WRAP_BITFIELD   = 1'h0;
localparam logic [ 47 : 32 ] GC_CR_MMU_VF5_CMD_QUEUE_INFO_TOTAL_SIZE_BITFIELD  = 16'h0;

 // gc_cr_mmu_vf6_cmd_queue_info
localparam logic [ 13 : 0 ] GC_CR_MMU_VF6_CMD_QUEUE_INFO_PROD_PTR_BITFIELD     = 14'h0;
localparam logic [ 15 : 15 ] GC_CR_MMU_VF6_CMD_QUEUE_INFO_PROD_WRAP_BITFIELD   = 1'h0;
localparam logic [ 29 : 16 ] GC_CR_MMU_VF6_CMD_QUEUE_INFO_CONS_PTR_BITFIELD    = 14'h0;
localparam logic [ 31 : 31 ] GC_CR_MMU_VF6_CMD_QUEUE_INFO_CONS_WRAP_BITFIELD   = 1'h0;
localparam logic [ 47 : 32 ] GC_CR_MMU_VF6_CMD_QUEUE_INFO_TOTAL_SIZE_BITFIELD  = 16'h0;

 // gc_cr_mmu_vf7_cmd_queue_info
localparam logic [ 13 : 0 ] GC_CR_MMU_VF7_CMD_QUEUE_INFO_PROD_PTR_BITFIELD     = 14'h0;
localparam logic [ 15 : 15 ] GC_CR_MMU_VF7_CMD_QUEUE_INFO_PROD_WRAP_BITFIELD   = 1'h0;
localparam logic [ 29 : 16 ] GC_CR_MMU_VF7_CMD_QUEUE_INFO_CONS_PTR_BITFIELD    = 14'h0;
localparam logic [ 31 : 31 ] GC_CR_MMU_VF7_CMD_QUEUE_INFO_CONS_WRAP_BITFIELD   = 1'h0;
localparam logic [ 47 : 32 ] GC_CR_MMU_VF7_CMD_QUEUE_INFO_TOTAL_SIZE_BITFIELD  = 16'h0;

 // gc_cr_mmu_vf8_cmd_queue_info
localparam logic [ 13 : 0 ] GC_CR_MMU_VF8_CMD_QUEUE_INFO_PROD_PTR_BITFIELD     = 14'h0;
localparam logic [ 15 : 15 ] GC_CR_MMU_VF8_CMD_QUEUE_INFO_PROD_WRAP_BITFIELD   = 1'h0;
localparam logic [ 29 : 16 ] GC_CR_MMU_VF8_CMD_QUEUE_INFO_CONS_PTR_BITFIELD    = 14'h0;
localparam logic [ 31 : 31 ] GC_CR_MMU_VF8_CMD_QUEUE_INFO_CONS_WRAP_BITFIELD   = 1'h0;
localparam logic [ 47 : 32 ] GC_CR_MMU_VF8_CMD_QUEUE_INFO_TOTAL_SIZE_BITFIELD  = 16'h0;

 // gc_cr_mmu_vf9_cmd_queue_info
localparam logic [ 13 : 0 ] GC_CR_MMU_VF9_CMD_QUEUE_INFO_PROD_PTR_BITFIELD     = 14'h0;
localparam logic [ 15 : 15 ] GC_CR_MMU_VF9_CMD_QUEUE_INFO_PROD_WRAP_BITFIELD   = 1'h0;
localparam logic [ 29 : 16 ] GC_CR_MMU_VF9_CMD_QUEUE_INFO_CONS_PTR_BITFIELD    = 14'h0;
localparam logic [ 31 : 31 ] GC_CR_MMU_VF9_CMD_QUEUE_INFO_CONS_WRAP_BITFIELD   = 1'h0;
localparam logic [ 47 : 32 ] GC_CR_MMU_VF9_CMD_QUEUE_INFO_TOTAL_SIZE_BITFIELD  = 16'h0;

 // gc_cr_mmu_vf10_cmd_queue_info
localparam logic [ 13 : 0 ] GC_CR_MMU_VF10_CMD_QUEUE_INFO_PROD_PTR_BITFIELD    = 14'h0;
localparam logic [ 15 : 15 ] GC_CR_MMU_VF10_CMD_QUEUE_INFO_PROD_WRAP_BITFIELD  = 1'h0;
localparam logic [ 29 : 16 ] GC_CR_MMU_VF10_CMD_QUEUE_INFO_CONS_PTR_BITFIELD   = 14'h0;
localparam logic [ 31 : 31 ] GC_CR_MMU_VF10_CMD_QUEUE_INFO_CONS_WRAP_BITFIELD  = 1'h0;
localparam logic [ 47 : 32 ] GC_CR_MMU_VF10_CMD_QUEUE_INFO_TOTAL_SIZE_BITFIELD  = 16'h0;

 // gc_cr_mmu_vf11_cmd_queue_info
localparam logic [ 13 : 0 ] GC_CR_MMU_VF11_CMD_QUEUE_INFO_PROD_PTR_BITFIELD    = 14'h0;
localparam logic [ 15 : 15 ] GC_CR_MMU_VF11_CMD_QUEUE_INFO_PROD_WRAP_BITFIELD  = 1'h0;
localparam logic [ 29 : 16 ] GC_CR_MMU_VF11_CMD_QUEUE_INFO_CONS_PTR_BITFIELD   = 14'h0;
localparam logic [ 31 : 31 ] GC_CR_MMU_VF11_CMD_QUEUE_INFO_CONS_WRAP_BITFIELD  = 1'h0;
localparam logic [ 47 : 32 ] GC_CR_MMU_VF11_CMD_QUEUE_INFO_TOTAL_SIZE_BITFIELD  = 16'h0;

 // gc_cr_mmu_vf12_cmd_queue_info
localparam logic [ 13 : 0 ] GC_CR_MMU_VF12_CMD_QUEUE_INFO_PROD_PTR_BITFIELD    = 14'h0;
localparam logic [ 15 : 15 ] GC_CR_MMU_VF12_CMD_QUEUE_INFO_PROD_WRAP_BITFIELD  = 1'h0;
localparam logic [ 29 : 16 ] GC_CR_MMU_VF12_CMD_QUEUE_INFO_CONS_PTR_BITFIELD   = 14'h0;
localparam logic [ 31 : 31 ] GC_CR_MMU_VF12_CMD_QUEUE_INFO_CONS_WRAP_BITFIELD  = 1'h0;
localparam logic [ 47 : 32 ] GC_CR_MMU_VF12_CMD_QUEUE_INFO_TOTAL_SIZE_BITFIELD  = 16'h0;

 // gc_cr_mmu_vf13_cmd_queue_info
localparam logic [ 13 : 0 ] GC_CR_MMU_VF13_CMD_QUEUE_INFO_PROD_PTR_BITFIELD    = 14'h0;
localparam logic [ 15 : 15 ] GC_CR_MMU_VF13_CMD_QUEUE_INFO_PROD_WRAP_BITFIELD  = 1'h0;
localparam logic [ 29 : 16 ] GC_CR_MMU_VF13_CMD_QUEUE_INFO_CONS_PTR_BITFIELD   = 14'h0;
localparam logic [ 31 : 31 ] GC_CR_MMU_VF13_CMD_QUEUE_INFO_CONS_WRAP_BITFIELD  = 1'h0;
localparam logic [ 47 : 32 ] GC_CR_MMU_VF13_CMD_QUEUE_INFO_TOTAL_SIZE_BITFIELD  = 16'h0;

 // gc_cr_mmu_vf14_cmd_queue_info
localparam logic [ 13 : 0 ] GC_CR_MMU_VF14_CMD_QUEUE_INFO_PROD_PTR_BITFIELD    = 14'h0;
localparam logic [ 15 : 15 ] GC_CR_MMU_VF14_CMD_QUEUE_INFO_PROD_WRAP_BITFIELD  = 1'h0;
localparam logic [ 29 : 16 ] GC_CR_MMU_VF14_CMD_QUEUE_INFO_CONS_PTR_BITFIELD   = 14'h0;
localparam logic [ 31 : 31 ] GC_CR_MMU_VF14_CMD_QUEUE_INFO_CONS_WRAP_BITFIELD  = 1'h0;
localparam logic [ 47 : 32 ] GC_CR_MMU_VF14_CMD_QUEUE_INFO_TOTAL_SIZE_BITFIELD  = 16'h0;

 // gc_cr_mmu_vf15_cmd_queue_info
localparam logic [ 13 : 0 ] GC_CR_MMU_VF15_CMD_QUEUE_INFO_PROD_PTR_BITFIELD    = 14'h0;
localparam logic [ 15 : 15 ] GC_CR_MMU_VF15_CMD_QUEUE_INFO_PROD_WRAP_BITFIELD  = 1'h0;
localparam logic [ 29 : 16 ] GC_CR_MMU_VF15_CMD_QUEUE_INFO_CONS_PTR_BITFIELD   = 14'h0;
localparam logic [ 31 : 31 ] GC_CR_MMU_VF15_CMD_QUEUE_INFO_CONS_WRAP_BITFIELD  = 1'h0;
localparam logic [ 47 : 32 ] GC_CR_MMU_VF15_CMD_QUEUE_INFO_TOTAL_SIZE_BITFIELD  = 16'h0;

 // gc_cr_mmu_warmup_cmd_config0
localparam logic [ 35 : 0 ] GC_CR_MMU_WARMUP_CMD_CONFIG0_ADDR_BITFIELD         = 36'h0;
localparam logic [ 49 : 40 ] GC_CR_MMU_WARMUP_CMD_CONFIG0_NUM_BITFIELD         = 10'h0;

 // gc_cr_mmu_warmup_cmd_config1
localparam logic [ 3 : 0 ] GC_CR_MMU_WARMUP_CMD_CONFIG1_VFID_BITFIELD          = 4'h0;
localparam logic [ 17 : 8 ] GC_CR_MMU_WARMUP_CMD_CONFIG1_PASID_BITFIELD        = 10'h0;
localparam logic [ 27 : 24 ] GC_CR_MMU_WARMUP_CMD_CONFIG1_STRIDE_BITFIELD      = 4'h0;

 // gc_cr_mmu_axi_error_status
localparam logic [ 4 : 0 ] GC_CR_MMU_AXI_ERROR_STATUS_RD_BUS_ERROR_BITFIELD    = 5'h0;

 // gc_cr_mmu_axi_config
localparam logic [ 3 : 0 ] GC_CR_MMU_AXI_CONFIG_QOS_BITFIELD                   = 4'hf;
localparam logic [ 4 : 4 ] GC_CR_MMU_AXI_CONFIG_ARCACHE_BITFIELD               = 1'h1;
localparam logic [ 5 : 5 ] GC_CR_MMU_AXI_CONFIG_PREFETCH_BITFIELD              = 1'h0;
localparam logic [ 7 : 6 ] GC_CR_MMU_AXI_CONFIG_PERSISTENT_BITFIELD            = 2'h3;

 // gc_cr_mmu_page_format_error_status
localparam logic [ 0 : 0 ] GC_CR_MMU_PAGE_FORMAT_ERROR_STATUS_ERROR_BITFIELD   = 1'h0;
localparam logic [ 5 : 2 ] GC_CR_MMU_PAGE_FORMAT_ERROR_STATUS_VFID_BITFIELD    = 4'h0;
localparam logic [ 15 : 6 ] GC_CR_MMU_PAGE_FORMAT_ERROR_STATUS_PASID_BITFIELD  = 10'h0;
localparam logic [ 51 : 16 ] GC_CR_MMU_PAGE_FORMAT_ERROR_STATUS_ADDR_BITFIELD  = 36'h0;
localparam logic [ 53 : 52 ] GC_CR_MMU_PAGE_FORMAT_ERROR_STATUS_LEVEL_BITFIELD  = 2'h0;

 // gc_cr_mmu_ctrl_tbu_status
localparam logic [ 31 : 0 ] GC_CR_MMU_CTRL_TBU_STATUS_DISABLE_BITFIELD         = 32'h0;

 // gc_cr_mmu_ctrl_tbu_hzd
localparam logic [ 3 : 0 ] GC_CR_MMU_CTRL_TBU_HZD_MODE_BITFIELD                = 4'h4;

 // gc_cr_mmu_ctrl_preload
localparam logic [ 0 : 0 ] GC_CR_MMU_CTRL_PRELOAD_DISABLE_BITFIELD             = 1'h0;

 // gc_cr_mmu_pf_cmd_error_status
localparam logic [ 3 : 0 ] GC_CR_MMU_PF_CMD_ERROR_STATUS_TYPE_BITFIELD         = 4'h0;

 // gc_cr_mmu_vf1_cmd_error_status
localparam logic [ 3 : 0 ] GC_CR_MMU_VF1_CMD_ERROR_STATUS_TYPE_BITFIELD        = 4'h0;

 // gc_cr_mmu_vf2_cmd_error_status
localparam logic [ 3 : 0 ] GC_CR_MMU_VF2_CMD_ERROR_STATUS_TYPE_BITFIELD        = 4'h0;

 // gc_cr_mmu_vf3_cmd_error_status
localparam logic [ 3 : 0 ] GC_CR_MMU_VF3_CMD_ERROR_STATUS_TYPE_BITFIELD        = 4'h0;

 // gc_cr_mmu_vf4_cmd_error_status
localparam logic [ 3 : 0 ] GC_CR_MMU_VF4_CMD_ERROR_STATUS_TYPE_BITFIELD        = 4'h0;

 // gc_cr_mmu_vf5_cmd_error_status
localparam logic [ 3 : 0 ] GC_CR_MMU_VF5_CMD_ERROR_STATUS_TYPE_BITFIELD        = 4'h0;

 // gc_cr_mmu_vf6_cmd_error_status
localparam logic [ 3 : 0 ] GC_CR_MMU_VF6_CMD_ERROR_STATUS_TYPE_BITFIELD        = 4'h0;

 // gc_cr_mmu_vf7_cmd_error_status
localparam logic [ 3 : 0 ] GC_CR_MMU_VF7_CMD_ERROR_STATUS_TYPE_BITFIELD        = 4'h0;

 // gc_cr_mmu_vf8_cmd_error_status
localparam logic [ 3 : 0 ] GC_CR_MMU_VF8_CMD_ERROR_STATUS_TYPE_BITFIELD        = 4'h0;

 // gc_cr_mmu_vf9_cmd_error_status
localparam logic [ 3 : 0 ] GC_CR_MMU_VF9_CMD_ERROR_STATUS_TYPE_BITFIELD        = 4'h0;

 // gc_cr_mmu_vf10_cmd_error_status
localparam logic [ 3 : 0 ] GC_CR_MMU_VF10_CMD_ERROR_STATUS_TYPE_BITFIELD       = 4'h0;

 // gc_cr_mmu_vf11_cmd_error_status
localparam logic [ 3 : 0 ] GC_CR_MMU_VF11_CMD_ERROR_STATUS_TYPE_BITFIELD       = 4'h0;

 // gc_cr_mmu_vf12_cmd_error_status
localparam logic [ 3 : 0 ] GC_CR_MMU_VF12_CMD_ERROR_STATUS_TYPE_BITFIELD       = 4'h0;

 // gc_cr_mmu_vf13_cmd_error_status
localparam logic [ 3 : 0 ] GC_CR_MMU_VF13_CMD_ERROR_STATUS_TYPE_BITFIELD       = 4'h0;

 // gc_cr_mmu_vf14_cmd_error_status
localparam logic [ 3 : 0 ] GC_CR_MMU_VF14_CMD_ERROR_STATUS_TYPE_BITFIELD       = 4'h0;

 // gc_cr_mmu_vf15_cmd_error_status
localparam logic [ 3 : 0 ] GC_CR_MMU_VF15_CMD_ERROR_STATUS_TYPE_BITFIELD       = 4'h0;

 // gc_cr_mmu_ctrl_tcu
localparam logic [ 4 : 0 ] GC_CR_MMU_CTRL_TCU_DISABLE_BITFIELD                 = 5'hf;

 // gc_cr_mmu_tcu_active
localparam logic [ 4 : 0 ] GC_CR_MMU_TCU_ACTIVE_STATUS_BITFIELD                = 5'h10;

 // gc_cr_mmu_perf_ctrl_select
localparam logic [ 1 : 0 ] GC_CR_MMU_PERF_CTRL_SELECT_UTLB_NUM_BITFIELD        = 2'h0;
localparam logic [ 3 : 2 ] GC_CR_MMU_PERF_CTRL_SELECT_TBU_NUM_BITFIELD         = 2'h0;
localparam logic [ 6 : 4 ] GC_CR_MMU_PERF_CTRL_SELECT_TCU_NUM_BITFIELD         = 3'h0;

 // gc_cr_mmu_perf_ctrl_cnt
localparam logic [ 2 : 0 ] GC_CR_MMU_PERF_CTRL_CNT_ENABLE_BITFIELD             = 3'h0;

 // gc_cr_mmu_perf_tcu_cnt0
localparam logic [ 30 : 0 ] GC_CR_MMU_PERF_TCU_CNT0_TRANSLATION_NUM_BITFIELD   = 31'h0;
localparam logic [ 31 : 31 ] GC_CR_MMU_PERF_TCU_CNT0_OVERFLOW_BITFIELD         = 1'h0;

 // gc_cr_mmu_perf_tcu_cnt1
localparam logic [ 30 : 0 ] GC_CR_MMU_PERF_TCU_CNT1_AXI_READ_NUM_BITFIELD      = 31'h0;
localparam logic [ 31 : 31 ] GC_CR_MMU_PERF_TCU_CNT1_OVERFLOW_BITFIELD         = 1'h0;

 // gc_cr_mmu_perf_tcu_cnt2
localparam logic [ 15 : 0 ] GC_CR_MMU_PERF_TCU_CNT2_AXI_MIN_LATENCY_BITFIELD   = 16'h0;

 // gc_cr_mmu_perf_tcu_cnt3
localparam logic [ 15 : 0 ] GC_CR_MMU_PERF_TCU_CNT3_AXI_MAX_LATENCY_BITFIELD   = 16'h0;

 // gc_cr_mmu_perf_tcu_cnt4
localparam logic [ 15 : 0 ] GC_CR_MMU_PERF_TCU_CNT4_AXI_AVG_LATENCY_BITFIELD   = 16'h0;

 // gc_cr_mmu_perf_tcu_cnt5
localparam logic [ 30 : 0 ] GC_CR_MMU_PERF_TCU_CNT5_HIT_L0_TABLE_NUM_BITFIELD  = 31'h0;
localparam logic [ 31 : 31 ] GC_CR_MMU_PERF_TCU_CNT5_OVERFLOW_BITFIELD         = 1'h0;

 // gc_cr_mmu_perf_tcu_cnt6
localparam logic [ 30 : 0 ] GC_CR_MMU_PERF_TCU_CNT6_HIT_L1_TABLE_NUM_BITFIELD  = 31'h0;
localparam logic [ 31 : 31 ] GC_CR_MMU_PERF_TCU_CNT6_OVERFLOW_BITFIELD         = 1'h0;

 // gc_cr_mmu_perf_tcu_cnt7
localparam logic [ 30 : 0 ] GC_CR_MMU_PERF_TCU_CNT7_HIT_L1_BLOCK_NUM_BITFIELD  = 31'h0;
localparam logic [ 31 : 31 ] GC_CR_MMU_PERF_TCU_CNT7_OVERFLOW_BITFIELD         = 1'h0;

 // gc_cr_mmu_perf_tcu_cnt8
localparam logic [ 30 : 0 ] GC_CR_MMU_PERF_TCU_CNT8_HIT_L2_TABLE_NUM_BITFIELD  = 31'h0;
localparam logic [ 31 : 31 ] GC_CR_MMU_PERF_TCU_CNT8_OVERFLOW_BITFIELD         = 1'h0;

 // gc_cr_mmu_perf_tcu_cnt9
localparam logic [ 30 : 0 ] GC_CR_MMU_PERF_TCU_CNT9_HIT_L2_BLOCK_NUM_BITFIELD  = 31'h0;
localparam logic [ 31 : 31 ] GC_CR_MMU_PERF_TCU_CNT9_OVERFLOW_BITFIELD         = 1'h0;

 // gc_cr_mmu_perf_tcu_cnt10
localparam logic [ 30 : 0 ] GC_CR_MMU_PERF_TCU_CNT10_HIT_L3_ENTRY_NUM_BITFIELD  = 31'h0;
localparam logic [ 31 : 31 ] GC_CR_MMU_PERF_TCU_CNT10_OVERFLOW_BITFIELD        = 1'h0;

 // gc_cr_mmu_perf_tbu_cnt0
localparam logic [ 62 : 0 ] GC_CR_MMU_PERF_TBU_CNT0_UTLB_TOTAL_LATENCY_BITFIELD  = 63'h0;
localparam logic [ 63 : 63 ] GC_CR_MMU_PERF_TBU_CNT0_OVERFLOW_BITFIELD         = 1'h0;

 // gc_cr_mmu_perf_tbu_cnt1
localparam logic [ 30 : 0 ] GC_CR_MMU_PERF_TBU_CNT1_UTLB_REQ_IN_NUM_BITFIELD   = 31'h0;
localparam logic [ 31 : 31 ] GC_CR_MMU_PERF_TBU_CNT1_OVERFLOW_BITFIELD         = 1'h0;

 // gc_cr_mmu_perf_tbu_cnt2
localparam logic [ 30 : 0 ] GC_CR_MMU_PERF_TBU_CNT2_UTLB_REQ_OUT_NUM_BITFIELD  = 31'h0;
localparam logic [ 31 : 31 ] GC_CR_MMU_PERF_TBU_CNT2_OVERFLOW_BITFIELD         = 1'h0;

 // gc_cr_mmu_perf_tbu_cnt3
localparam logic [ 30 : 0 ] GC_CR_MMU_PERF_TBU_CNT3_UTLB_CORE_HIT_NUM_BITFIELD  = 31'h0;
localparam logic [ 31 : 31 ] GC_CR_MMU_PERF_TBU_CNT3_OVERFLOW_BITFIELD         = 1'h0;

 // gc_cr_mmu_perf_tbu_cnt4
localparam logic [ 30 : 0 ] GC_CR_MMU_PERF_TBU_CNT4_MTLB_REQ_IN_NUM_BITFIELD   = 31'h0;
localparam logic [ 31 : 31 ] GC_CR_MMU_PERF_TBU_CNT4_OVERFLOW_BITFIELD         = 1'h0;

 // gc_cr_mmu_perf_tbu_cnt5
localparam logic [ 30 : 0 ] GC_CR_MMU_PERF_TBU_CNT5_MTLB_REQ_OUT_NUM_BITFIELD  = 31'h0;
localparam logic [ 31 : 31 ] GC_CR_MMU_PERF_TBU_CNT5_OVERFLOW_BITFIELD         = 1'h0;

 // gc_cr_mmu_perf_tbu_cnt6
localparam logic [ 30 : 0 ] GC_CR_MMU_PERF_TBU_CNT6_MTLB_BANK_HIT_NUM_BITFIELD  = 31'h0;
localparam logic [ 31 : 31 ] GC_CR_MMU_PERF_TBU_CNT6_OVERFLOW_BITFIELD         = 1'h0;

 // gc_cr_mmu_conus_error_status
localparam logic [ 0 : 0 ] GC_CR_MMU_CONUS_ERROR_STATUS_ERROR_BITFIELD         = 1'h0;
localparam logic [ 1 : 1 ] GC_CR_MMU_CONUS_ERROR_STATUS_TYPE_BITFIELD          = 1'h0;
localparam logic [ 5 : 2 ] GC_CR_MMU_CONUS_ERROR_STATUS_VFID_BITFIELD          = 4'h0;
localparam logic [ 15 : 6 ] GC_CR_MMU_CONUS_ERROR_STATUS_PASID_BITFIELD        = 10'h0;
localparam logic [ 51 : 16 ] GC_CR_MMU_CONUS_ERROR_STATUS_ADDR_BITFIELD        = 36'h0;

 // gc_cr_mmu_fw_warmup_cmd_config0
localparam logic [ 35 : 0 ] GC_CR_MMU_FW_WARMUP_CMD_CONFIG0_ADDR_BITFIELD      = 36'h0;
localparam logic [ 49 : 40 ] GC_CR_MMU_FW_WARMUP_CMD_CONFIG0_NUM_BITFIELD      = 10'h0;

 // gc_cr_mmu_fw_warmup_cmd_config1
localparam logic [ 3 : 0 ] GC_CR_MMU_FW_WARMUP_CMD_CONFIG1_VFID_BITFIELD       = 4'h0;
localparam logic [ 17 : 8 ] GC_CR_MMU_FW_WARMUP_CMD_CONFIG1_PASID_BITFIELD     = 10'h0;
localparam logic [ 27 : 24 ] GC_CR_MMU_FW_WARMUP_CMD_CONFIG1_STRIDE_BITFIELD   = 4'h0;

 // gc_cr_mmu_tcu_ctrl
localparam logic [ 1 : 0 ] GC_CR_MMU_TCU_CTRL_HASH_MODE_BITFIELD               = 2'h0;
localparam logic [ 2 : 2 ] GC_CR_MMU_TCU_CTRL_XBAR_MODE_BITFIELD               = 1'h0;
localparam logic [ 3 : 3 ] GC_CR_MMU_TCU_CTRL_LOOKUP_MODE_BITFIELD             = 1'h0;

 // gc_cr_mmu_tcu_hash_mode1_ctrl0
localparam logic [ 63 : 0 ] GC_CR_MMU_TCU_HASH_MODE1_CTRL0_CFG_BITFIELD        = 64'h8888888188888880;

 // gc_cr_mmu_tcu_hash_mode1_ctrl1
localparam logic [ 63 : 0 ] GC_CR_MMU_TCU_HASH_MODE1_CTRL1_CFG_BITFIELD        = 64'h8888888388888882;

 // gc_cr_mmu_tcu_hash_mode1_ctrl2
localparam logic [ 63 : 0 ] GC_CR_MMU_TCU_HASH_MODE1_CTRL2_CFG_BITFIELD        = 64'h8888888588888884;

 // gc_cr_mmu_tcu_hash_mode1_ctrl3
localparam logic [ 63 : 0 ] GC_CR_MMU_TCU_HASH_MODE1_CTRL3_CFG_BITFIELD        = 64'h8888888788888886;

 // gc_cr_mmu_tcu_hash_mode1_ctrl4
localparam logic [ 63 : 0 ] GC_CR_MMU_TCU_HASH_MODE1_CTRL4_CFG_BITFIELD        = 64'h8888888188888880;

 // gc_cr_mmu_tcu_hash_mode1_ctrl5
localparam logic [ 63 : 0 ] GC_CR_MMU_TCU_HASH_MODE1_CTRL5_CFG_BITFIELD        = 64'h8888888388888882;

 // gc_cr_mmu_tcu_hash_mode1_ctrl6
localparam logic [ 63 : 0 ] GC_CR_MMU_TCU_HASH_MODE1_CTRL6_CFG_BITFIELD        = 64'h8888885688888847;

 // gc_cr_l2_cfi_operation
localparam logic [ 1 : 0 ] GC_CR_L2_CFI_OPERATION_CFI_OPERATION_BITFIELD       = 2'h0;

 // gc_cr_l2_cfi_statusi
localparam logic [ 0 : 0 ] GC_CR_L2_CFI_STATUSI_L2B0_BITFIELD                  = 1'h1;
localparam logic [ 1 : 1 ] GC_CR_L2_CFI_STATUSI_L2B1_BITFIELD                  = 1'h1;
localparam logic [ 2 : 2 ] GC_CR_L2_CFI_STATUSI_L2B2_BITFIELD                  = 1'h1;
localparam logic [ 3 : 3 ] GC_CR_L2_CFI_STATUSI_L2B3_BITFIELD                  = 1'h1;
localparam logic [ 4 : 4 ] GC_CR_L2_CFI_STATUSI_L2B4_BITFIELD                  = 1'h1;
localparam logic [ 5 : 5 ] GC_CR_L2_CFI_STATUSI_L2B5_BITFIELD                  = 1'h1;
localparam logic [ 6 : 6 ] GC_CR_L2_CFI_STATUSI_L2B6_BITFIELD                  = 1'h1;
localparam logic [ 7 : 7 ] GC_CR_L2_CFI_STATUSI_L2B7_BITFIELD                  = 1'h1;
localparam logic [ 8 : 8 ] GC_CR_L2_CFI_STATUSI_L2B8_BITFIELD                  = 1'h1;
localparam logic [ 9 : 9 ] GC_CR_L2_CFI_STATUSI_L2B9_BITFIELD                  = 1'h1;
localparam logic [ 10 : 10 ] GC_CR_L2_CFI_STATUSI_L2B10_BITFIELD               = 1'h1;
localparam logic [ 11 : 11 ] GC_CR_L2_CFI_STATUSI_L2B11_BITFIELD               = 1'h1;
localparam logic [ 12 : 12 ] GC_CR_L2_CFI_STATUSI_L2B12_BITFIELD               = 1'h1;
localparam logic [ 13 : 13 ] GC_CR_L2_CFI_STATUSI_L2B13_BITFIELD               = 1'h1;
localparam logic [ 14 : 14 ] GC_CR_L2_CFI_STATUSI_L2B14_BITFIELD               = 1'h1;
localparam logic [ 15 : 15 ] GC_CR_L2_CFI_STATUSI_L2B15_BITFIELD               = 1'h1;
localparam logic [ 16 : 16 ] GC_CR_L2_CFI_STATUSI_L2B16_BITFIELD               = 1'h1;
localparam logic [ 17 : 17 ] GC_CR_L2_CFI_STATUSI_L2B17_BITFIELD               = 1'h1;
localparam logic [ 18 : 18 ] GC_CR_L2_CFI_STATUSI_L2B18_BITFIELD               = 1'h1;
localparam logic [ 19 : 19 ] GC_CR_L2_CFI_STATUSI_L2B19_BITFIELD               = 1'h1;
localparam logic [ 20 : 20 ] GC_CR_L2_CFI_STATUSI_L2B20_BITFIELD               = 1'h1;
localparam logic [ 21 : 21 ] GC_CR_L2_CFI_STATUSI_L2B21_BITFIELD               = 1'h1;
localparam logic [ 22 : 22 ] GC_CR_L2_CFI_STATUSI_L2B22_BITFIELD               = 1'h1;
localparam logic [ 23 : 23 ] GC_CR_L2_CFI_STATUSI_L2B23_BITFIELD               = 1'h1;
localparam logic [ 24 : 24 ] GC_CR_L2_CFI_STATUSI_L2B24_BITFIELD               = 1'h1;
localparam logic [ 25 : 25 ] GC_CR_L2_CFI_STATUSI_L2B25_BITFIELD               = 1'h1;
localparam logic [ 26 : 26 ] GC_CR_L2_CFI_STATUSI_L2B26_BITFIELD               = 1'h1;
localparam logic [ 27 : 27 ] GC_CR_L2_CFI_STATUSI_L2B27_BITFIELD               = 1'h1;
localparam logic [ 28 : 28 ] GC_CR_L2_CFI_STATUSI_L2B28_BITFIELD               = 1'h1;
localparam logic [ 29 : 29 ] GC_CR_L2_CFI_STATUSI_L2B29_BITFIELD               = 1'h1;
localparam logic [ 30 : 30 ] GC_CR_L2_CFI_STATUSI_L2B30_BITFIELD               = 1'h1;
localparam logic [ 31 : 31 ] GC_CR_L2_CFI_STATUSI_L2B31_BITFIELD               = 1'h1;
localparam logic [ 32 : 32 ] GC_CR_L2_CFI_STATUSI_L2B32_BITFIELD               = 1'h1;
localparam logic [ 33 : 33 ] GC_CR_L2_CFI_STATUSI_L2B33_BITFIELD               = 1'h1;
localparam logic [ 34 : 34 ] GC_CR_L2_CFI_STATUSI_L2B34_BITFIELD               = 1'h1;
localparam logic [ 35 : 35 ] GC_CR_L2_CFI_STATUSI_L2B35_BITFIELD               = 1'h1;
localparam logic [ 36 : 36 ] GC_CR_L2_CFI_STATUSI_L2B36_BITFIELD               = 1'h1;
localparam logic [ 37 : 37 ] GC_CR_L2_CFI_STATUSI_L2B37_BITFIELD               = 1'h1;
localparam logic [ 38 : 38 ] GC_CR_L2_CFI_STATUSI_L2B38_BITFIELD               = 1'h1;
localparam logic [ 39 : 39 ] GC_CR_L2_CFI_STATUSI_L2B39_BITFIELD               = 1'h1;
localparam logic [ 40 : 40 ] GC_CR_L2_CFI_STATUSI_L2B40_BITFIELD               = 1'h1;
localparam logic [ 41 : 41 ] GC_CR_L2_CFI_STATUSI_L2B41_BITFIELD               = 1'h1;
localparam logic [ 42 : 42 ] GC_CR_L2_CFI_STATUSI_L2B42_BITFIELD               = 1'h1;
localparam logic [ 43 : 43 ] GC_CR_L2_CFI_STATUSI_L2B43_BITFIELD               = 1'h1;
localparam logic [ 44 : 44 ] GC_CR_L2_CFI_STATUSI_L2B44_BITFIELD               = 1'h1;
localparam logic [ 45 : 45 ] GC_CR_L2_CFI_STATUSI_L2B45_BITFIELD               = 1'h1;
localparam logic [ 46 : 46 ] GC_CR_L2_CFI_STATUSI_L2B46_BITFIELD               = 1'h1;
localparam logic [ 47 : 47 ] GC_CR_L2_CFI_STATUSI_L2B47_BITFIELD               = 1'h1;
localparam logic [ 48 : 48 ] GC_CR_L2_CFI_STATUSI_L2B48_BITFIELD               = 1'h1;
localparam logic [ 49 : 49 ] GC_CR_L2_CFI_STATUSI_L2B49_BITFIELD               = 1'h1;
localparam logic [ 50 : 50 ] GC_CR_L2_CFI_STATUSI_L2B50_BITFIELD               = 1'h1;
localparam logic [ 51 : 51 ] GC_CR_L2_CFI_STATUSI_L2B51_BITFIELD               = 1'h1;
localparam logic [ 52 : 52 ] GC_CR_L2_CFI_STATUSI_L2B52_BITFIELD               = 1'h1;
localparam logic [ 53 : 53 ] GC_CR_L2_CFI_STATUSI_L2B53_BITFIELD               = 1'h1;
localparam logic [ 54 : 54 ] GC_CR_L2_CFI_STATUSI_L2B54_BITFIELD               = 1'h1;
localparam logic [ 55 : 55 ] GC_CR_L2_CFI_STATUSI_L2B55_BITFIELD               = 1'h1;
localparam logic [ 56 : 56 ] GC_CR_L2_CFI_STATUSI_L2B56_BITFIELD               = 1'h1;
localparam logic [ 57 : 57 ] GC_CR_L2_CFI_STATUSI_L2B57_BITFIELD               = 1'h1;
localparam logic [ 58 : 58 ] GC_CR_L2_CFI_STATUSI_L2B58_BITFIELD               = 1'h1;
localparam logic [ 59 : 59 ] GC_CR_L2_CFI_STATUSI_L2B59_BITFIELD               = 1'h1;
localparam logic [ 60 : 60 ] GC_CR_L2_CFI_STATUSI_L2B60_BITFIELD               = 1'h1;
localparam logic [ 61 : 61 ] GC_CR_L2_CFI_STATUSI_L2B61_BITFIELD               = 1'h1;
localparam logic [ 62 : 62 ] GC_CR_L2_CFI_STATUSI_L2B62_BITFIELD               = 1'h1;
localparam logic [ 63 : 63 ] GC_CR_L2_CFI_STATUSI_L2B63_BITFIELD               = 1'h1;

 // gc_cr_l2_buffer_mode
localparam logic [ 1 : 0 ] GC_CR_L2_BUFFER_MODE_BUFFER_MODE_PERCENTAGE_BITFIELD  = 2'h0;

 // gc_cr_l2_persistence_reduce
localparam logic [ 0 : 0 ] GC_CR_L2_PERSISTENCE_REDUCE_PERSISTENCE_REDUCE_ENABLE_BITFIELD  = 1'h0;
localparam logic [ 21 : 1 ] GC_CR_L2_PERSISTENCE_REDUCE_PERSISTENCE_REDUCE_THRESHOLD_BITFIELD  = 21'h0;

 // gc_cr_l2_cmd
localparam logic [ 0 : 0 ] GC_CR_L2_CMD_PERSISTENCE_RST_ALL_BITFIELD           = 1'h0;
localparam logic [ 1 : 1 ] GC_CR_L2_CMD_CFI_CLR_BITFIELD                       = 1'h0;

 // gc_cr_l2g_idle
localparam logic [ 0 : 0 ] GC_CR_L2G_IDLE_L2B0_BITFIELD                        = 1'h1;
localparam logic [ 1 : 1 ] GC_CR_L2G_IDLE_L2B1_BITFIELD                        = 1'h1;
localparam logic [ 2 : 2 ] GC_CR_L2G_IDLE_L2B2_BITFIELD                        = 1'h1;
localparam logic [ 3 : 3 ] GC_CR_L2G_IDLE_L2B3_BITFIELD                        = 1'h1;
localparam logic [ 4 : 4 ] GC_CR_L2G_IDLE_L2B4_BITFIELD                        = 1'h1;
localparam logic [ 5 : 5 ] GC_CR_L2G_IDLE_L2B5_BITFIELD                        = 1'h1;
localparam logic [ 6 : 6 ] GC_CR_L2G_IDLE_L2B6_BITFIELD                        = 1'h1;
localparam logic [ 7 : 7 ] GC_CR_L2G_IDLE_L2B7_BITFIELD                        = 1'h1;
localparam logic [ 8 : 8 ] GC_CR_L2G_IDLE_L2B8_BITFIELD                        = 1'h1;
localparam logic [ 9 : 9 ] GC_CR_L2G_IDLE_L2B9_BITFIELD                        = 1'h1;
localparam logic [ 10 : 10 ] GC_CR_L2G_IDLE_L2B10_BITFIELD                     = 1'h1;
localparam logic [ 11 : 11 ] GC_CR_L2G_IDLE_L2B11_BITFIELD                     = 1'h1;
localparam logic [ 12 : 12 ] GC_CR_L2G_IDLE_L2B12_BITFIELD                     = 1'h1;
localparam logic [ 13 : 13 ] GC_CR_L2G_IDLE_L2B13_BITFIELD                     = 1'h1;
localparam logic [ 14 : 14 ] GC_CR_L2G_IDLE_L2B14_BITFIELD                     = 1'h1;
localparam logic [ 15 : 15 ] GC_CR_L2G_IDLE_L2B15_BITFIELD                     = 1'h1;
localparam logic [ 16 : 16 ] GC_CR_L2G_IDLE_L2B16_BITFIELD                     = 1'h1;
localparam logic [ 17 : 17 ] GC_CR_L2G_IDLE_L2B17_BITFIELD                     = 1'h1;
localparam logic [ 18 : 18 ] GC_CR_L2G_IDLE_L2B18_BITFIELD                     = 1'h1;
localparam logic [ 19 : 19 ] GC_CR_L2G_IDLE_L2B19_BITFIELD                     = 1'h1;
localparam logic [ 20 : 20 ] GC_CR_L2G_IDLE_L2B20_BITFIELD                     = 1'h1;
localparam logic [ 21 : 21 ] GC_CR_L2G_IDLE_L2B21_BITFIELD                     = 1'h1;
localparam logic [ 22 : 22 ] GC_CR_L2G_IDLE_L2B22_BITFIELD                     = 1'h1;
localparam logic [ 23 : 23 ] GC_CR_L2G_IDLE_L2B23_BITFIELD                     = 1'h1;
localparam logic [ 24 : 24 ] GC_CR_L2G_IDLE_L2B24_BITFIELD                     = 1'h1;
localparam logic [ 25 : 25 ] GC_CR_L2G_IDLE_L2B25_BITFIELD                     = 1'h1;
localparam logic [ 26 : 26 ] GC_CR_L2G_IDLE_L2B26_BITFIELD                     = 1'h1;
localparam logic [ 27 : 27 ] GC_CR_L2G_IDLE_L2B27_BITFIELD                     = 1'h1;
localparam logic [ 28 : 28 ] GC_CR_L2G_IDLE_L2B28_BITFIELD                     = 1'h1;
localparam logic [ 29 : 29 ] GC_CR_L2G_IDLE_L2B29_BITFIELD                     = 1'h1;
localparam logic [ 30 : 30 ] GC_CR_L2G_IDLE_L2B30_BITFIELD                     = 1'h1;
localparam logic [ 31 : 31 ] GC_CR_L2G_IDLE_L2B31_BITFIELD                     = 1'h1;
localparam logic [ 32 : 32 ] GC_CR_L2G_IDLE_L2B32_BITFIELD                     = 1'h1;
localparam logic [ 33 : 33 ] GC_CR_L2G_IDLE_L2B33_BITFIELD                     = 1'h1;
localparam logic [ 34 : 34 ] GC_CR_L2G_IDLE_L2B34_BITFIELD                     = 1'h1;
localparam logic [ 35 : 35 ] GC_CR_L2G_IDLE_L2B35_BITFIELD                     = 1'h1;
localparam logic [ 36 : 36 ] GC_CR_L2G_IDLE_L2B36_BITFIELD                     = 1'h1;
localparam logic [ 37 : 37 ] GC_CR_L2G_IDLE_L2B37_BITFIELD                     = 1'h1;
localparam logic [ 38 : 38 ] GC_CR_L2G_IDLE_L2B38_BITFIELD                     = 1'h1;
localparam logic [ 39 : 39 ] GC_CR_L2G_IDLE_L2B39_BITFIELD                     = 1'h1;
localparam logic [ 40 : 40 ] GC_CR_L2G_IDLE_L2B40_BITFIELD                     = 1'h1;
localparam logic [ 41 : 41 ] GC_CR_L2G_IDLE_L2B41_BITFIELD                     = 1'h1;
localparam logic [ 42 : 42 ] GC_CR_L2G_IDLE_L2B42_BITFIELD                     = 1'h1;
localparam logic [ 43 : 43 ] GC_CR_L2G_IDLE_L2B43_BITFIELD                     = 1'h1;
localparam logic [ 44 : 44 ] GC_CR_L2G_IDLE_L2B44_BITFIELD                     = 1'h1;
localparam logic [ 45 : 45 ] GC_CR_L2G_IDLE_L2B45_BITFIELD                     = 1'h1;
localparam logic [ 46 : 46 ] GC_CR_L2G_IDLE_L2B46_BITFIELD                     = 1'h1;
localparam logic [ 47 : 47 ] GC_CR_L2G_IDLE_L2B47_BITFIELD                     = 1'h1;
localparam logic [ 48 : 48 ] GC_CR_L2G_IDLE_L2B48_BITFIELD                     = 1'h1;
localparam logic [ 49 : 49 ] GC_CR_L2G_IDLE_L2B49_BITFIELD                     = 1'h1;
localparam logic [ 50 : 50 ] GC_CR_L2G_IDLE_L2B50_BITFIELD                     = 1'h1;
localparam logic [ 51 : 51 ] GC_CR_L2G_IDLE_L2B51_BITFIELD                     = 1'h1;
localparam logic [ 52 : 52 ] GC_CR_L2G_IDLE_L2B52_BITFIELD                     = 1'h1;
localparam logic [ 53 : 53 ] GC_CR_L2G_IDLE_L2B53_BITFIELD                     = 1'h1;
localparam logic [ 54 : 54 ] GC_CR_L2G_IDLE_L2B54_BITFIELD                     = 1'h1;
localparam logic [ 55 : 55 ] GC_CR_L2G_IDLE_L2B55_BITFIELD                     = 1'h1;
localparam logic [ 56 : 56 ] GC_CR_L2G_IDLE_L2B56_BITFIELD                     = 1'h1;
localparam logic [ 57 : 57 ] GC_CR_L2G_IDLE_L2B57_BITFIELD                     = 1'h1;
localparam logic [ 58 : 58 ] GC_CR_L2G_IDLE_L2B58_BITFIELD                     = 1'h1;
localparam logic [ 59 : 59 ] GC_CR_L2G_IDLE_L2B59_BITFIELD                     = 1'h1;
localparam logic [ 60 : 60 ] GC_CR_L2G_IDLE_L2B60_BITFIELD                     = 1'h1;
localparam logic [ 61 : 61 ] GC_CR_L2G_IDLE_L2B61_BITFIELD                     = 1'h1;
localparam logic [ 62 : 62 ] GC_CR_L2G_IDLE_L2B62_BITFIELD                     = 1'h1;
localparam logic [ 63 : 63 ] GC_CR_L2G_IDLE_L2B63_BITFIELD                     = 1'h1;

 // gc_cr_l2g_error0
localparam logic [ 2 : 0 ] GC_CR_L2G_ERROR0_L2B0_BITFIELD                      = 3'h0;
localparam logic [ 5 : 3 ] GC_CR_L2G_ERROR0_L2B1_BITFIELD                      = 3'h0;
localparam logic [ 8 : 6 ] GC_CR_L2G_ERROR0_L2B2_BITFIELD                      = 3'h0;
localparam logic [ 11 : 9 ] GC_CR_L2G_ERROR0_L2B3_BITFIELD                     = 3'h0;
localparam logic [ 14 : 12 ] GC_CR_L2G_ERROR0_L2B4_BITFIELD                    = 3'h0;
localparam logic [ 17 : 15 ] GC_CR_L2G_ERROR0_L2B5_BITFIELD                    = 3'h0;
localparam logic [ 20 : 18 ] GC_CR_L2G_ERROR0_L2B6_BITFIELD                    = 3'h0;
localparam logic [ 23 : 21 ] GC_CR_L2G_ERROR0_L2B7_BITFIELD                    = 3'h0;
localparam logic [ 26 : 24 ] GC_CR_L2G_ERROR0_L2B8_BITFIELD                    = 3'h0;
localparam logic [ 29 : 27 ] GC_CR_L2G_ERROR0_L2B9_BITFIELD                    = 3'h0;
localparam logic [ 32 : 30 ] GC_CR_L2G_ERROR0_L2B10_BITFIELD                   = 3'h0;
localparam logic [ 35 : 33 ] GC_CR_L2G_ERROR0_L2B11_BITFIELD                   = 3'h0;
localparam logic [ 38 : 36 ] GC_CR_L2G_ERROR0_L2B12_BITFIELD                   = 3'h0;
localparam logic [ 41 : 39 ] GC_CR_L2G_ERROR0_L2B13_BITFIELD                   = 3'h0;
localparam logic [ 44 : 42 ] GC_CR_L2G_ERROR0_L2B14_BITFIELD                   = 3'h0;
localparam logic [ 47 : 45 ] GC_CR_L2G_ERROR0_L2B15_BITFIELD                   = 3'h0;
localparam logic [ 50 : 48 ] GC_CR_L2G_ERROR0_L2B16_BITFIELD                   = 3'h0;
localparam logic [ 53 : 51 ] GC_CR_L2G_ERROR0_L2B17_BITFIELD                   = 3'h0;
localparam logic [ 56 : 54 ] GC_CR_L2G_ERROR0_L2B18_BITFIELD                   = 3'h0;
localparam logic [ 59 : 57 ] GC_CR_L2G_ERROR0_L2B19_BITFIELD                   = 3'h0;
localparam logic [ 62 : 60 ] GC_CR_L2G_ERROR0_L2B20_BITFIELD                   = 3'h0;

 // gc_cr_l2g_error1
localparam logic [ 2 : 0 ] GC_CR_L2G_ERROR1_L2B21_BITFIELD                     = 3'h0;
localparam logic [ 5 : 3 ] GC_CR_L2G_ERROR1_L2B22_BITFIELD                     = 3'h0;
localparam logic [ 8 : 6 ] GC_CR_L2G_ERROR1_L2B23_BITFIELD                     = 3'h0;
localparam logic [ 11 : 9 ] GC_CR_L2G_ERROR1_L2B24_BITFIELD                    = 3'h0;
localparam logic [ 14 : 12 ] GC_CR_L2G_ERROR1_L2B25_BITFIELD                   = 3'h0;
localparam logic [ 17 : 15 ] GC_CR_L2G_ERROR1_L2B26_BITFIELD                   = 3'h0;
localparam logic [ 20 : 18 ] GC_CR_L2G_ERROR1_L2B27_BITFIELD                   = 3'h0;
localparam logic [ 23 : 21 ] GC_CR_L2G_ERROR1_L2B28_BITFIELD                   = 3'h0;
localparam logic [ 26 : 24 ] GC_CR_L2G_ERROR1_L2B29_BITFIELD                   = 3'h0;
localparam logic [ 29 : 27 ] GC_CR_L2G_ERROR1_L2B30_BITFIELD                   = 3'h0;
localparam logic [ 32 : 30 ] GC_CR_L2G_ERROR1_L2B31_BITFIELD                   = 3'h0;
localparam logic [ 35 : 33 ] GC_CR_L2G_ERROR1_L2B32_BITFIELD                   = 3'h0;
localparam logic [ 38 : 36 ] GC_CR_L2G_ERROR1_L2B33_BITFIELD                   = 3'h0;
localparam logic [ 41 : 39 ] GC_CR_L2G_ERROR1_L2B34_BITFIELD                   = 3'h0;
localparam logic [ 44 : 42 ] GC_CR_L2G_ERROR1_L2B35_BITFIELD                   = 3'h0;
localparam logic [ 47 : 45 ] GC_CR_L2G_ERROR1_L2B36_BITFIELD                   = 3'h0;
localparam logic [ 50 : 48 ] GC_CR_L2G_ERROR1_L2B37_BITFIELD                   = 3'h0;
localparam logic [ 53 : 51 ] GC_CR_L2G_ERROR1_L2B38_BITFIELD                   = 3'h0;
localparam logic [ 56 : 54 ] GC_CR_L2G_ERROR1_L2B39_BITFIELD                   = 3'h0;
localparam logic [ 59 : 57 ] GC_CR_L2G_ERROR1_L2B40_BITFIELD                   = 3'h0;
localparam logic [ 62 : 60 ] GC_CR_L2G_ERROR1_L2B41_BITFIELD                   = 3'h0;

 // gc_cr_l2g_error2
localparam logic [ 2 : 0 ] GC_CR_L2G_ERROR2_L2B42_BITFIELD                     = 3'h0;
localparam logic [ 5 : 3 ] GC_CR_L2G_ERROR2_L2B43_BITFIELD                     = 3'h0;
localparam logic [ 8 : 6 ] GC_CR_L2G_ERROR2_L2B44_BITFIELD                     = 3'h0;
localparam logic [ 11 : 9 ] GC_CR_L2G_ERROR2_L2B45_BITFIELD                    = 3'h0;
localparam logic [ 14 : 12 ] GC_CR_L2G_ERROR2_L2B46_BITFIELD                   = 3'h0;
localparam logic [ 17 : 15 ] GC_CR_L2G_ERROR2_L2B47_BITFIELD                   = 3'h0;
localparam logic [ 20 : 18 ] GC_CR_L2G_ERROR2_L2B48_BITFIELD                   = 3'h0;
localparam logic [ 23 : 21 ] GC_CR_L2G_ERROR2_L2B49_BITFIELD                   = 3'h0;
localparam logic [ 26 : 24 ] GC_CR_L2G_ERROR2_L2B50_BITFIELD                   = 3'h0;
localparam logic [ 29 : 27 ] GC_CR_L2G_ERROR2_L2B51_BITFIELD                   = 3'h0;
localparam logic [ 32 : 30 ] GC_CR_L2G_ERROR2_L2B52_BITFIELD                   = 3'h0;
localparam logic [ 35 : 33 ] GC_CR_L2G_ERROR2_L2B53_BITFIELD                   = 3'h0;
localparam logic [ 38 : 36 ] GC_CR_L2G_ERROR2_L2B54_BITFIELD                   = 3'h0;
localparam logic [ 41 : 39 ] GC_CR_L2G_ERROR2_L2B55_BITFIELD                   = 3'h0;
localparam logic [ 44 : 42 ] GC_CR_L2G_ERROR2_L2B56_BITFIELD                   = 3'h0;
localparam logic [ 47 : 45 ] GC_CR_L2G_ERROR2_L2B57_BITFIELD                   = 3'h0;
localparam logic [ 50 : 48 ] GC_CR_L2G_ERROR2_L2B58_BITFIELD                   = 3'h0;
localparam logic [ 53 : 51 ] GC_CR_L2G_ERROR2_L2B59_BITFIELD                   = 3'h0;
localparam logic [ 56 : 54 ] GC_CR_L2G_ERROR2_L2B60_BITFIELD                   = 3'h0;
localparam logic [ 59 : 57 ] GC_CR_L2G_ERROR2_L2B61_BITFIELD                   = 3'h0;
localparam logic [ 62 : 60 ] GC_CR_L2G_ERROR2_L2B62_BITFIELD                   = 3'h0;

 // gc_cr_l2g_error3
localparam logic [ 2 : 0 ] GC_CR_L2G_ERROR3_L2B63_BITFIELD                     = 3'h0;

 // gc_cr_l2_function_enable
localparam logic [ 0 : 0 ] GC_CR_L2_FUNCTION_ENABLE_MEM_SCHEDULER_BITFIELD     = 1'h0;
localparam logic [ 1 : 1 ] GC_CR_L2_FUNCTION_ENABLE_BYPASS_MODE_BITFIELD       = 1'h0;
localparam logic [ 3 : 2 ] GC_CR_L2_FUNCTION_ENABLE_HASH_MODE_BITFIELD         = 2'h0;
localparam logic [ 7 : 4 ] GC_CR_L2_FUNCTION_ENABLE_DDR_CAPACITY_BITFIELD      = 4'h0;

 // gc_cr_l2_mem_sched_col_offset
localparam logic [ 4 : 0 ] GC_CR_L2_MEM_SCHED_COL_OFFSET_COLUMN_ID_BIT0_BITFIELD  = 5'h0;
localparam logic [ 12 : 8 ] GC_CR_L2_MEM_SCHED_COL_OFFSET_COLUMN_ID_BIT1_BITFIELD  = 5'h0;
localparam logic [ 20 : 16 ] GC_CR_L2_MEM_SCHED_COL_OFFSET_COLUMN_ID_BIT2_BITFIELD  = 5'h0;
localparam logic [ 28 : 24 ] GC_CR_L2_MEM_SCHED_COL_OFFSET_COLUMN_ID_BIT3_BITFIELD  = 5'h0;
localparam logic [ 36 : 32 ] GC_CR_L2_MEM_SCHED_COL_OFFSET_COLUMN_ID_BIT4_BITFIELD  = 5'h0;
localparam logic [ 44 : 40 ] GC_CR_L2_MEM_SCHED_COL_OFFSET_COLUMN_ID_BIT5_BITFIELD  = 5'h0;
localparam logic [ 52 : 48 ] GC_CR_L2_MEM_SCHED_COL_OFFSET_COLUMN_ID_BIT6_BITFIELD  = 5'h0;
localparam logic [ 60 : 56 ] GC_CR_L2_MEM_SCHED_COL_OFFSET_COLUMN_ID_BIT7_BITFIELD  = 5'h0;

 // gc_cr_l2_mem_sched_bank_offset
localparam logic [ 4 : 0 ] GC_CR_L2_MEM_SCHED_BANK_OFFSET_BANK_ID_BIT0_BITFIELD  = 5'h0;
localparam logic [ 12 : 8 ] GC_CR_L2_MEM_SCHED_BANK_OFFSET_BANK_ID_BIT1_BITFIELD  = 5'h0;
localparam logic [ 20 : 16 ] GC_CR_L2_MEM_SCHED_BANK_OFFSET_BANK_ID_BIT2_BITFIELD  = 5'h0;
localparam logic [ 28 : 24 ] GC_CR_L2_MEM_SCHED_BANK_OFFSET_BANK_ID_BIT3_BITFIELD  = 5'h0;
localparam logic [ 36 : 32 ] GC_CR_L2_MEM_SCHED_BANK_OFFSET_BANK_ID_BIT4_BITFIELD  = 5'h0;

 // gc_cr_l2_mem_sched_row_parti
localparam logic [ 4 : 0 ] GC_CR_L2_MEM_SCHED_ROW_PARTI_ROW_ID_BIT0_BITFIELD   = 5'h0;
localparam logic [ 12 : 8 ] GC_CR_L2_MEM_SCHED_ROW_PARTI_ROW_ID_BIT1_BITFIELD  = 5'h0;
localparam logic [ 20 : 16 ] GC_CR_L2_MEM_SCHED_ROW_PARTI_ROW_ID_BIT2_BITFIELD  = 5'h0;
localparam logic [ 28 : 24 ] GC_CR_L2_MEM_SCHED_ROW_PARTI_ROW_ID_BIT3_BITFIELD  = 5'h0;
localparam logic [ 36 : 32 ] GC_CR_L2_MEM_SCHED_ROW_PARTI_ROW_ID_BIT4_BITFIELD  = 5'h0;
localparam logic [ 44 : 40 ] GC_CR_L2_MEM_SCHED_ROW_PARTI_ROW_ID_BIT5_BITFIELD  = 5'h0;
localparam logic [ 52 : 48 ] GC_CR_L2_MEM_SCHED_ROW_PARTI_ROW_ID_BIT6_BITFIELD  = 5'h0;
localparam logic [ 60 : 56 ] GC_CR_L2_MEM_SCHED_ROW_PARTI_ROW_ID_BIT7_BITFIELD  = 5'h0;

 // gc_cr_l2_mem_sched_row_partii
localparam logic [ 4 : 0 ] GC_CR_L2_MEM_SCHED_ROW_PARTII_ROW_ID_BIT8_BITFIELD  = 5'h0;
localparam logic [ 12 : 8 ] GC_CR_L2_MEM_SCHED_ROW_PARTII_ROW_ID_BIT9_BITFIELD  = 5'h0;
localparam logic [ 20 : 16 ] GC_CR_L2_MEM_SCHED_ROW_PARTII_ROW_ID_BIT10_BITFIELD  = 5'h0;
localparam logic [ 28 : 24 ] GC_CR_L2_MEM_SCHED_ROW_PARTII_ROW_ID_BIT11_BITFIELD  = 5'h0;
localparam logic [ 36 : 32 ] GC_CR_L2_MEM_SCHED_ROW_PARTII_ROW_ID_BIT12_BITFIELD  = 5'h0;
localparam logic [ 44 : 40 ] GC_CR_L2_MEM_SCHED_ROW_PARTII_ROW_ID_BIT13_BITFIELD  = 5'h0;
localparam logic [ 52 : 48 ] GC_CR_L2_MEM_SCHED_ROW_PARTII_ROW_ID_BIT14_BITFIELD  = 5'h0;
localparam logic [ 60 : 56 ] GC_CR_L2_MEM_SCHED_ROW_PARTII_ROW_ID_BIT15_BITFIELD  = 5'h0;

 // gc_cr_l2_mem_sched_row_partiii
localparam logic [ 4 : 0 ] GC_CR_L2_MEM_SCHED_ROW_PARTIII_ROW_ID_BIT16_BITFIELD  = 5'h0;
localparam logic [ 12 : 8 ] GC_CR_L2_MEM_SCHED_ROW_PARTIII_ROW_ID_BIT17_BITFIELD  = 5'h0;

 // gc_cr_ddr_hash_config_reg0
localparam logic [ 3 : 0 ] GC_CR_DDR_HASH_CONFIG_REG0_ROW_ID_BIT0_BITFIELD     = 4'h9;
localparam logic [ 7 : 4 ] GC_CR_DDR_HASH_CONFIG_REG0_ROW_ID_BIT1_BITFIELD     = 4'h9;
localparam logic [ 11 : 8 ] GC_CR_DDR_HASH_CONFIG_REG0_ROW_ID_BIT2_BITFIELD    = 4'h9;
localparam logic [ 15 : 12 ] GC_CR_DDR_HASH_CONFIG_REG0_ROW_ID_BIT3_BITFIELD   = 4'h9;
localparam logic [ 19 : 16 ] GC_CR_DDR_HASH_CONFIG_REG0_ROW_ID_BIT4_BITFIELD   = 4'h9;
localparam logic [ 23 : 20 ] GC_CR_DDR_HASH_CONFIG_REG0_ROW_ID_BIT5_BITFIELD   = 4'h9;
localparam logic [ 27 : 24 ] GC_CR_DDR_HASH_CONFIG_REG0_ROW_ID_BIT6_BITFIELD   = 4'h9;
localparam logic [ 31 : 28 ] GC_CR_DDR_HASH_CONFIG_REG0_ROW_ID_BIT7_BITFIELD   = 4'h9;
localparam logic [ 35 : 32 ] GC_CR_DDR_HASH_CONFIG_REG0_ROW_ID_BIT8_BITFIELD   = 4'h9;
localparam logic [ 39 : 36 ] GC_CR_DDR_HASH_CONFIG_REG0_ROW_ID_BIT9_BITFIELD   = 4'h9;
localparam logic [ 43 : 40 ] GC_CR_DDR_HASH_CONFIG_REG0_ROW_ID_BIT10_BITFIELD  = 4'h9;
localparam logic [ 47 : 44 ] GC_CR_DDR_HASH_CONFIG_REG0_ROW_ID_BIT11_BITFIELD  = 4'h9;

 // gc_cr_ddr_hash_config_reg1
localparam logic [ 3 : 0 ] GC_CR_DDR_HASH_CONFIG_REG1_ROW_ID_BIT12_BITFIELD    = 4'h9;
localparam logic [ 7 : 4 ] GC_CR_DDR_HASH_CONFIG_REG1_ROW_ID_BIT13_BITFIELD    = 4'h9;
localparam logic [ 11 : 8 ] GC_CR_DDR_HASH_CONFIG_REG1_ROW_ID_BIT14_BITFIELD   = 4'h9;
localparam logic [ 15 : 12 ] GC_CR_DDR_HASH_CONFIG_REG1_ROW_ID_BIT15_BITFIELD  = 4'h9;
localparam logic [ 19 : 16 ] GC_CR_DDR_HASH_CONFIG_REG1_ROW_ID_BIT16_BITFIELD  = 4'h9;
localparam logic [ 23 : 20 ] GC_CR_DDR_HASH_CONFIG_REG1_ROW_ID_BIT17_BITFIELD  = 4'h9;
localparam logic [ 27 : 24 ] GC_CR_DDR_HASH_CONFIG_REG1_ROW_ID_BIT18_BITFIELD  = 4'h9;
localparam logic [ 31 : 28 ] GC_CR_DDR_HASH_CONFIG_REG1_ROW_ID_BIT19_BITFIELD  = 4'h9;
localparam logic [ 35 : 32 ] GC_CR_DDR_HASH_CONFIG_REG1_ROW_ID_BIT20_BITFIELD  = 4'h9;
localparam logic [ 39 : 36 ] GC_CR_DDR_HASH_CONFIG_REG1_ROW_ID_BIT21_BITFIELD  = 4'h9;
localparam logic [ 43 : 40 ] GC_CR_DDR_HASH_CONFIG_REG1_ROW_ID_BIT22_BITFIELD  = 4'h9;
localparam logic [ 47 : 44 ] GC_CR_DDR_HASH_CONFIG_REG1_ROW_ID_BIT23_BITFIELD  = 4'h9;

 // gc_cr_l2g_idleii
localparam logic [ 0 : 0 ] GC_CR_L2G_IDLEII_L2B64_BITFIELD                     = 1'h1;
localparam logic [ 1 : 1 ] GC_CR_L2G_IDLEII_L2B65_BITFIELD                     = 1'h1;
localparam logic [ 2 : 2 ] GC_CR_L2G_IDLEII_L2B66_BITFIELD                     = 1'h1;
localparam logic [ 3 : 3 ] GC_CR_L2G_IDLEII_L2B67_BITFIELD                     = 1'h1;
localparam logic [ 4 : 4 ] GC_CR_L2G_IDLEII_L2B68_BITFIELD                     = 1'h1;
localparam logic [ 5 : 5 ] GC_CR_L2G_IDLEII_L2B69_BITFIELD                     = 1'h1;
localparam logic [ 6 : 6 ] GC_CR_L2G_IDLEII_L2B70_BITFIELD                     = 1'h1;
localparam logic [ 7 : 7 ] GC_CR_L2G_IDLEII_L2B71_BITFIELD                     = 1'h1;
localparam logic [ 8 : 8 ] GC_CR_L2G_IDLEII_L2B72_BITFIELD                     = 1'h1;
localparam logic [ 9 : 9 ] GC_CR_L2G_IDLEII_L2B73_BITFIELD                     = 1'h1;
localparam logic [ 10 : 10 ] GC_CR_L2G_IDLEII_L2B74_BITFIELD                   = 1'h1;
localparam logic [ 11 : 11 ] GC_CR_L2G_IDLEII_L2B75_BITFIELD                   = 1'h1;
localparam logic [ 12 : 12 ] GC_CR_L2G_IDLEII_L2B76_BITFIELD                   = 1'h1;
localparam logic [ 13 : 13 ] GC_CR_L2G_IDLEII_L2B77_BITFIELD                   = 1'h1;
localparam logic [ 14 : 14 ] GC_CR_L2G_IDLEII_L2B78_BITFIELD                   = 1'h1;
localparam logic [ 15 : 15 ] GC_CR_L2G_IDLEII_L2B79_BITFIELD                   = 1'h1;

 // gc_cr_l2_cfi_statusii
localparam logic [ 0 : 0 ] GC_CR_L2_CFI_STATUSII_L2B64_BITFIELD                = 1'h1;
localparam logic [ 1 : 1 ] GC_CR_L2_CFI_STATUSII_L2B65_BITFIELD                = 1'h1;
localparam logic [ 2 : 2 ] GC_CR_L2_CFI_STATUSII_L2B66_BITFIELD                = 1'h1;
localparam logic [ 3 : 3 ] GC_CR_L2_CFI_STATUSII_L2B67_BITFIELD                = 1'h1;
localparam logic [ 4 : 4 ] GC_CR_L2_CFI_STATUSII_L2B68_BITFIELD                = 1'h1;
localparam logic [ 5 : 5 ] GC_CR_L2_CFI_STATUSII_L2B69_BITFIELD                = 1'h1;
localparam logic [ 6 : 6 ] GC_CR_L2_CFI_STATUSII_L2B70_BITFIELD                = 1'h1;
localparam logic [ 7 : 7 ] GC_CR_L2_CFI_STATUSII_L2B71_BITFIELD                = 1'h1;
localparam logic [ 8 : 8 ] GC_CR_L2_CFI_STATUSII_L2B72_BITFIELD                = 1'h1;
localparam logic [ 9 : 9 ] GC_CR_L2_CFI_STATUSII_L2B73_BITFIELD                = 1'h1;
localparam logic [ 10 : 10 ] GC_CR_L2_CFI_STATUSII_L2B74_BITFIELD              = 1'h1;
localparam logic [ 11 : 11 ] GC_CR_L2_CFI_STATUSII_L2B75_BITFIELD              = 1'h1;
localparam logic [ 12 : 12 ] GC_CR_L2_CFI_STATUSII_L2B76_BITFIELD              = 1'h1;
localparam logic [ 13 : 13 ] GC_CR_L2_CFI_STATUSII_L2B77_BITFIELD              = 1'h1;
localparam logic [ 14 : 14 ] GC_CR_L2_CFI_STATUSII_L2B78_BITFIELD              = 1'h1;
localparam logic [ 15 : 15 ] GC_CR_L2_CFI_STATUSII_L2B79_BITFIELD              = 1'h1;
endpackage
