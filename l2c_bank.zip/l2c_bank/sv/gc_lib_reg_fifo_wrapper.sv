// Author: Wu Cheng`en
// Date: 2025/9/15
// Description: 
// FIFO IP wrapper, which is almost the same as gpc_gfx_rpfifo_.sv

module gc_lib_reg_fifo_wrapper 
#(
   parameter  w                  = 128, // width of fifo
   parameter  d                  = 4, // depth of fifo
   parameter  registered_enable  = 1 // when zero allows a write when FIFO is already full but a read is happening
)(
   input  logic            clk,
   input  logic            resetn,
   input  logic            fifo_in_valid,
   output logic            fifo_in_enable,
   input  logic   [w-1:0]  fifo_in_data,
   output logic            fifo_out_valid,
   input  logic            fifo_out_enable,
   output logic   [w-1:0]  fifo_out_data
);

logic                 ram_fifo_push, ram_fifo_pop, ram_fifo_full, ram_fifo_empty;

assign ram_fifo_push     = fifo_in_valid & fifo_in_enable;
generate
    if ( registered_enable == 1 ) begin //Can not support push when full
        assign fifo_in_enable    = ~ram_fifo_full;
    end 
    else begin //Support push when full + pop
        assign fifo_in_enable    = ~ram_fifo_full || fifo_out_enable;
    end
endgenerate

assign ram_fifo_pop      = fifo_out_enable & fifo_out_valid;
assign fifo_out_valid    = ~ram_fifo_empty;

gc_lib_reg_fifo #(.DTYPE(logic [w-1:0]), .DEPTH(d)) u_ram_fifo(
    .clk          (clk           ),
    .resetn       (resetn        ),
    .push         (ram_fifo_push ),
    .pop          (ram_fifo_pop  ),
    .full         (ram_fifo_full ),
    .empty        (ram_fifo_empty),
    .din          (fifo_in_data  ),
    .dout         (fifo_out_data )
);

endmodule
