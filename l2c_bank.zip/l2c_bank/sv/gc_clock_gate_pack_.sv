/*

 * #==========================================================================#
 * |                                                                          |
 * |  Copyright (c) 2022, Fantasy Technologies Limited and/or its         |
 * |  affiliated group companies ("Fantasy"). All rights reserved.        |
 * |  No part of this content, either material or conceptual may be copied    |
 * |  or distributed, transmitted, transcribed, stored in a retrieval system  |
 * |  or translated into any human or computer language in any form by any    |
 * |  means, electronic, mechanical manual, or otherwise, or disclosed to     |
 * |  third parties without the express written permission of Fantasy.    |
 * |                                                                          |
 * #==========================================================================#

 */
package gc_clock_gate_pack_;

// ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////-
// entity name: gc_clock_gate_pack
// purpose:
// ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////-

`ifndef GPU_SYNTHESIS
   localparam CLK_ALIGN_DELAY = 1ps;
`endif

   // all the clock gating IDs for this IP:
   localparam int                                           CGID_FWC_CORE                           = 0;
   localparam int                                           CGID_FWC_AUX                            = 1;
   localparam int                                           CGID_FWC_DUX                            = 2;
   localparam int                                           CGID_FWC_FPU                            = 3;
   localparam int                                           CGID_FWC_CTRL                           = 4;
   localparam int                                           CGID_FWC_DC                             = 5;
   localparam int                                           CGID_FWC_IC                             = 6;
   localparam int                                           CGID_FWC_MB                             = 7;
   localparam int                                           CGID_FWC_SYS                            = 8;
   localparam int                                           CGID_FWC_WC_SYS                         = 9;
   localparam int                                           CGID_FWC_SB                             = 10;
   localparam int                                           CGID_FWC_DBG                            = 11;
   localparam int                                           CGID_FWC_CCS                            = 12;
   localparam int                                           CGID_FWC_WFI_CORE                       = 13;
   // Mercer Layout Block
   typedef int per_cluster_cgid [ 0 : 15 ];    
   localparam per_cluster_cgid                              CGID_GC_CU                             = '{ 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31 };
   localparam per_cluster_cgid                              CGID_GC_CUPS                           = '{ 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46 };
   localparam per_cluster_cgid                              CGID_GC_CU_CORE                        = '{ 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62 };
   localparam per_cluster_cgid                              CGID_GC_PBE                             = '{ 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78 };
   localparam per_cluster_cgid                              CGID_GC_PBE_CORE                        = '{ 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94 };
   localparam per_cluster_cgid                              CGID_GC_MERCER                          = '{ 214, 215, 216, 217, 218, 219, 220, 221, 222, 223, 224, 225, 226, 227, 228, 229 };

   //Blackpearl Layout Block
   typedef int per_phantom_cgid [ 0 : 3 ];     
   localparam per_phantom_cgid                              CGID_GC_BLACKPEARL_CORE                 = '{ 95, 96, 97, 98 };
   localparam per_phantom_cgid                              CGID_GC_BIF_BLACKPEARL                  = '{ 99, 100, 101, 102 };
   localparam per_phantom_cgid                              CGID_GC_CU_SHARED                      = '{ 103, 104, 105, 106 };
   localparam per_phantom_cgid                              CGID_GC_GEOMETRY                        = '{ 107, 108, 109, 110 };
   localparam per_phantom_cgid                              CGID_GC_IPF                             = '{ 111, 112, 113, 114 };
   localparam per_phantom_cgid                              CGID_GC_PDS_SHARED                      = '{ 115, 116, 117, 118 };
   localparam per_phantom_cgid                              CGID_GC_BLACKPEARL_BALANCE              = '{ 119, 120, 121, 122 };
   localparam per_phantom_cgid                              CGID_GC_ISP                             = '{ 239, 240, 241, 242 };
   localparam per_phantom_cgid                              CGID_GC_TSP                             = '{ 243, 244, 245, 246 };









   //Teague Layout Block
   typedef int per_dust_cgid [ 0 : 7 ];        
   localparam per_dust_cgid                                 CGID_GC_TPU                             = '{ 123, 124, 125, 126, 127, 128, 129, 130 };
   localparam per_dust_cgid                                 CGID_GC_TPU_CORE                        = '{ 131, 132, 133, 134, 135, 136, 137, 138 };
   localparam per_dust_cgid                                 CGID_GC_ASTC                            = '{ 139, 140, 141, 142, 143, 144, 145, 146 };

   localparam per_dust_cgid                                 CGID_GC_TEXAS3_CORE                     = '{ 147, 148, 149, 150, 151, 152, 153, 154 };
   localparam per_dust_cgid                                 CGID_GC_TEXAS3_CORE_BALANCE             = '{ 155, 156, 157, 158, 159, 160, 161, 162 };
   localparam per_dust_cgid                                 CGID_GC_BIF_TEXAS                       = '{ 163, 164, 165, 166, 167, 168, 169, 170 };
   localparam per_dust_cgid                                 CGID_GC_MCU                             = '{ 171, 172, 173, 174, 175, 176, 177, 178 };
   localparam per_dust_cgid                                 CGID_GC_PDS                             = '{ 179, 180, 181, 182, 183, 184, 185, 186 };
   localparam per_dust_cgid                                 CGID_GC_TPU_MCU_DEMUX                   = '{ 195, 196, 197, 198, 199, 200, 201, 202 };
   localparam per_dust_cgid                                 CGID_GC_TEAGUE                          = '{ 230, 231, 232, 233, 234, 235, 236, 237 };
   localparam per_dust_cgid                                 CGID_GC_TEAGUE_FBC2_PBE_IF              = '{ 262, 263, 264, 265, 266, 267, 268, 269 };
   localparam per_dust_cgid                                 CGID_GC_TEAGUE_SOCIF_BUS_DELAY          = '{ 270, 271, 272, 273, 274, 275, 276, 277 };
   localparam per_dust_cgid                                 CGID_GC_TEAGUE_PIPELINE_MERCER_FBCDC    = '{ 278, 279, 280, 281, 282, 283, 284, 285 };
   localparam per_dust_cgid                                 CGID_GC_TEAGUE_PIPELINE_MERCER_TESS     = '{ 286, 287, 288, 289, 290, 291, 292, 293 };
   localparam per_dust_cgid                                 CGID_GC_TEAGUE_PIPELINE_MERCER          = '{ 294, 295, 296, 297, 298, 299, 300, 301 };
   localparam per_dust_cgid                                 CGID_GC_TEAGUE_PIPELINE_BLACKPEARL_FBCDC = '{ 302, 303, 304, 305, 306, 307, 308, 309 };
   localparam per_dust_cgid                                 CGID_GC_TEAGUE_PIPELINE_BLACKPEARL_TESS = '{ 310, 311, 312, 313, 314, 315, 316, 317 };
   localparam per_dust_cgid                                 CGID_GC_TEAGUE_PIPELINE_BLACKPEARL      = '{ 318, 319, 320, 321, 322, 323, 324, 325 };

   // TORNADO Block
   localparam int                                           CGID_GC_IPP                             = 57;
   localparam int                                           CGID_GC_TORN_CORE                       = 58;
   localparam int                                           CGID_GC_TEXAS_CORE                      = 59;

   localparam int                                           CGID_GC_VRDM                            = 68;
   localparam int                                           CGID_GC_SHF                             = 69;
   localparam int                                           CGID_GC_SHG                             = 70;
   localparam int                                           CGID_GC_RPM                             = 71;
   localparam int                                           CGID_GC_FBA                             = 72;
   localparam int                                           CGID_GC_DPX                             = 73;

   // JONES Layout Block
   localparam int                                           CGID_GC_VERTEX                          = 203;
   localparam int                                           CGID_GC_PIXEL                           = 204;
   localparam int                                           CGID_GC_COMPUTE                         = 205;
   localparam int                                           CGID_GC_BIF0                            = 206;
   localparam int                                           CGID_GC_PM                              = 207;
   localparam int                                           CGID_GC_SYS                             = 208;
   localparam int                                           CGID_GC_TLA                             = 209;
   localparam int                                           CGID_GC_JONES_CORE                      = 210;
   localparam int                                           CGID_GC_MSS_CORE                        = 211;
   localparam int                                           CGID_GC_MSS                             = 212;
   localparam int                                           CGID_GC_MEM                             = 213;
   localparam int                                           CGID_GC_VDM                             = 238;
   localparam int                                           CGID_GC_TDM                             = 239;


  

   // Clock gate test input width
   function automatic int clkgate_tiw;
   input  int                                           id;
      return ( 1 );
   endfunction // clkgate_tiw

   // Clock gate test output width
   function automatic int clkgate_tow;
   input  int                                           id;
      return ( 1 );
   endfunction // clkgate_tow

endpackage
