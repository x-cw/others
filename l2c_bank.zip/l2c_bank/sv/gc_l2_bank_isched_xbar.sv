// +FHDR----------------------------------------------------------------------------
// Copyright (c) 2024, Innosilicon, Inc. Confidential Proprietary
// PROJECT NAME  : xxx
// DEPARTMENT    : Digtal Frontend SOC
// AUTHOR        : luoml01
// EMAIL         : luoml01@innosilicon.com.cn
// CREATE ON     : 2024/12/31 15:56
// FILE NAME     : gc_l2_bank_isched_xbar.sv
// DESCRIPTION   :          
//         
// Copyright (c) 2024 Innosilicon.
// ALL RIGHTS RESERVED
// 
// ---------------------------------------------------------------------------------
// Modification History:
// Date         By              Version                 Change Description
// ---------------------------------------------------------------------------------
// 2024/12/31   luoml01         1.0                     Original
// 
// -FHDR----------------------------------------------------------------------------


module gc_l2_bank_isched_xbar
import gc_l2_bank_pkg::*;
(
      input  logic                                                     clk,
      input  logic                                                     resetn,
      output logic                                                     idle,

      input  logic [ L2_ISCHED_NUM_INPUT-2 : 0 ]                       req_xbar_valid,
      output logic [ L2_ISCHED_NUM_INPUT-2 : 0 ]                       req_xbar_ready,
      input  isched_xbar_record_type  [ L2_ISCHED_NUM_INPUT-2 : 0 ]    req_xbar_rec,


      input  logic                                                     memif_wb_req_valid,
      output logic                                                     memif_wb_req_ready,
      input  memif_wdc_record_type                                     memif_wb_req_rec,



      output logic [ L2_NUM_RCTRL-1        : 0 ]                       isched_splitter_valid,
      input  logic [ L2_NUM_RCTRL-1        : 0 ]                       isched_splitter_ready,
      //output  logic    [L2_NUM_RCTRL-1:0]                      isched_splitter_src[1:0],
      output isched_splitter_record_type [ L2_NUM_RCTRL-1        : 0 ] isched_splitter_rec

      

);


logic [L2_NUM_RCTRL-1:0]    [$clog2(L2_ISCHED_NUM_INPUT)-1:0]              prev_selected_req;
logic [L2_NUM_RCTRL-1:0]    [$clog2(L2_ISCHED_NUM_INPUT)-1:0]              selected_req;
logic [L2_NUM_RCTRL-1:0]    [$clog2(L2_ISCHED_NUM_INPUT)-1:0]              next_index_round_robin_req;


logic [L2_ISCHED_NUM_INPUT-2:0]           req_xbar_valid_mask [L2_NUM_RCTRL-1:0];

logic [L2_NUM_RCTRL-1:0]                  req_arb_valid;
logic [L2_NUM_RCTRL-1:0]                  req_arb_ready;
logic [L2_NUM_RCTRL-1:0]                  wb_req_ready;
logic [L2_NUM_RCTRL-1:0]                  wb_req_valid;

logic [L2_NUM_RCTRL-1:0] [1:0]            wb_req_access_sector;
logic [L2_NUM_RCTRL-1:0] [1:0]            wb_wr_req_access_sector;
logic [L2_NUM_RCTRL-1:0] [1:0]            wb_wr_req_end_beat;


memif_wdc_record_type [L2_NUM_RCTRL-1:0]  wb_req_rec;
localparam NUM_REQ_BITS = 1;






 // architecture rtl
assign idle = (((|(req_xbar_valid))==1'b0) && (memif_wb_req_valid==1'b0)) ? 1'b1 : 1'b0;
generate
for(genvar RCTRL_NUM=0; RCTRL_NUM<=L2_NUM_RCTRL - 1; RCTRL_NUM++) begin : g_per_req

   // resestable register process
   always_ff@(posedge clk or negedge resetn) begin : p_reg_rst
      if(resetn==1'b0) begin
         prev_selected_req[RCTRL_NUM] <= '0;
      end
      else begin
         if(req_arb_valid[RCTRL_NUM]==1'b1 && req_arb_ready[RCTRL_NUM]==1'b1) begin
            prev_selected_req[RCTRL_NUM] <= (selected_req[RCTRL_NUM]);
         end
      end
   end : p_reg_rst



   for(genvar REQ_NUM=0; REQ_NUM<=L2_ISCHED_NUM_INPUT-2; REQ_NUM++)begin : g_per_req_num
      assign req_xbar_valid_mask[RCTRL_NUM][REQ_NUM] = (req_xbar_valid[REQ_NUM]==1'b1 && req_xbar_rec[REQ_NUM].set[0]==((NUM_REQ_BITS)'(RCTRL_NUM)))? 1'b1 : 1'b0;
   end
   
   // use round robin arbitration on the per requester mask to chose which req returns data to which requester
   gpc_round_robin_index_arch1_ #(
      .width         (L2_ISCHED_NUM_INPUT-1),
      .hold_previous (1'b0)
   ) i_gpc_round_robin_index_arch1_round_robin_req (
      .valids           (req_xbar_valid_mask[RCTRL_NUM]),
      .previous_index   (prev_selected_req[RCTRL_NUM]),
      .next_index       (next_index_round_robin_req[RCTRL_NUM])
   );
   
   assign selected_req[RCTRL_NUM] = ((next_index_round_robin_req[RCTRL_NUM]));
   assign req_arb_valid[RCTRL_NUM] = |req_xbar_valid_mask[RCTRL_NUM];
   
   assign wb_wr_req_end_beat[RCTRL_NUM] = wb_req_rec[RCTRL_NUM].start_beat + wb_req_rec[RCTRL_NUM].blen;
   
   assign wb_req_access_sector[RCTRL_NUM] = {|wb_req_rec[RCTRL_NUM].beat_dirty_mask[3:2], |wb_req_rec[RCTRL_NUM].beat_dirty_mask[1:0]};

   assign wb_wr_req_access_sector[RCTRL_NUM][0] = (wb_req_rec[RCTRL_NUM].start_beat[1]==1'b0 ? 1'b1 : 1'b0) | wb_req_access_sector[RCTRL_NUM][0];

   assign wb_wr_req_access_sector[RCTRL_NUM][1] = (wb_wr_req_end_beat[RCTRL_NUM][1] ==1'b1 ? 1'b1 : 1'b0) | wb_req_access_sector[RCTRL_NUM][1];
   
   
   always_comb begin : p_final_select_output_port_comb
   
      wb_req_ready[RCTRL_NUM]                       = ~wb_req_valid[RCTRL_NUM];
      req_arb_ready[RCTRL_NUM]                      = ~req_arb_valid[RCTRL_NUM];
   
      isched_splitter_valid[RCTRL_NUM]              = 1'b0;
      isched_splitter_rec[RCTRL_NUM]                = '{instruction: RD ,default: '0};
   
      if(wb_req_valid[RCTRL_NUM]==1'b1)begin
         isched_splitter_valid[RCTRL_NUM]               = 1'b1;
         isched_splitter_rec[RCTRL_NUM].instruction     = wb_req_rec[RCTRL_NUM].instruction;
         isched_splitter_rec[RCTRL_NUM].set             = wb_req_rec[RCTRL_NUM].set;
         isched_splitter_rec[RCTRL_NUM].way             = wb_req_rec[RCTRL_NUM].way;

         isched_splitter_rec[RCTRL_NUM].start_beat      = wb_req_rec[RCTRL_NUM].start_beat;
         isched_splitter_rec[RCTRL_NUM].blen            = wb_req_rec[RCTRL_NUM].blen;
         isched_splitter_rec[RCTRL_NUM].iwdb_index      = wb_req_rec[RCTRL_NUM].iwdb_index;
         isched_splitter_rec[RCTRL_NUM].beat_dirty_mask = wb_req_rec[RCTRL_NUM].beat_dirty_mask;
         isched_splitter_rec[RCTRL_NUM].is_buffer_mode  = 1'b0;
         wb_req_ready[RCTRL_NUM]                        = isched_splitter_ready[RCTRL_NUM];

         if(isched_splitter_rec[RCTRL_NUM].instruction  ==WB | isched_splitter_rec[RCTRL_NUM].instruction==FLUSH)begin
            isched_splitter_rec[RCTRL_NUM].sector_mask  = wb_req_access_sector[RCTRL_NUM];
         end
         else begin
            isched_splitter_rec[RCTRL_NUM].sector_mask  = wb_wr_req_access_sector[RCTRL_NUM];
         end   

         //isched_splitter_src[RCTRL_NUM] = 2'b10;
      end
      else if(req_arb_valid[RCTRL_NUM] == 1'b1)begin
         isched_splitter_valid[RCTRL_NUM]                 = 1'b1;
         isched_splitter_rec[RCTRL_NUM].instruction       = req_xbar_rec[selected_req[RCTRL_NUM]].instruction;
         isched_splitter_rec[RCTRL_NUM].axid              = req_xbar_rec[selected_req[RCTRL_NUM]].axid;
         isched_splitter_rec[RCTRL_NUM].set               = req_xbar_rec[selected_req[RCTRL_NUM]].set;
         isched_splitter_rec[RCTRL_NUM].way               = req_xbar_rec[selected_req[RCTRL_NUM]].way;
         isched_splitter_rec[RCTRL_NUM].start_beat        = req_xbar_rec[selected_req[RCTRL_NUM]].start_beat;
         isched_splitter_rec[RCTRL_NUM].blen              = req_xbar_rec[selected_req[RCTRL_NUM]].blen;
         isched_splitter_rec[RCTRL_NUM].iwdb_index        = req_xbar_rec[selected_req[RCTRL_NUM]].iwdb_index;
         isched_splitter_rec[RCTRL_NUM].sector_mask       = req_xbar_rec[selected_req[RCTRL_NUM]].sector_mask;
         req_arb_ready[RCTRL_NUM]                         = isched_splitter_ready[RCTRL_NUM];
         //isched_splitter_src[RCTRL_NUM]  = ((2)'(selected_req[RCTRL_NUM]));
         if(selected_req[RCTRL_NUM] != 1'b0)begin //buffer mode request use the input port 0; rb use input port2;
            isched_splitter_rec[RCTRL_NUM].is_buffer_mode = 1'b0;
            isched_splitter_rec[RCTRL_NUM].check_partial    = req_xbar_rec[selected_req[RCTRL_NUM]].check_partial;
         end
         else begin
            isched_splitter_rec[RCTRL_NUM].is_buffer_mode = 1'b1;
         end
      end
   end
end
endgenerate


   // create a mask of valids from banks only returning data to this req
always_comb begin : p_per_wb_req_mask
   wb_req_valid = '0;
   wb_req_rec[0] = '{instruction: RD, default: '0};
   wb_req_rec[1] = '{instruction: RD, default: '0};

   memif_wb_req_ready = ~memif_wb_req_valid;

   if(memif_wb_req_valid==1'b1 && memif_wb_req_rec.set[0]==1'b0) begin
      wb_req_valid[0] = 1'b1;
      wb_req_rec[0] = memif_wb_req_rec;

      memif_wb_req_ready = wb_req_ready[0];
   end
   else if(memif_wb_req_valid==1'b1 && memif_wb_req_rec.set[0]==1'b1)begin
      wb_req_valid[1] = 1'b1;
      wb_req_rec[1] = memif_wb_req_rec;

      memif_wb_req_ready = wb_req_ready[1];
   end

end : p_per_wb_req_mask


// process to drive the correct req ready when the requester accepts the transaction
always_comb begin : p_req_ready
   req_xbar_ready = ~req_xbar_valid;

   for(int unsigned RCTRL_NUM=0; RCTRL_NUM<=L2_NUM_RCTRL - 1; RCTRL_NUM++) begin
      if(req_xbar_valid_mask[RCTRL_NUM][selected_req[RCTRL_NUM]]==1'b1) begin
         req_xbar_ready[selected_req[RCTRL_NUM]] = req_arb_ready[RCTRL_NUM];
      end
   end

end : p_req_ready

   
   






endmodule : gc_l2_bank_isched_xbar
// Local Variables:
// verilog-library-flags:("-y ./ -y ../")
// verilog-auto-inst-param-value:t
// End:
