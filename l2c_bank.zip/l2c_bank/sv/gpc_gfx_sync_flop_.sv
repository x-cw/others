/*

 * #==========================================================================#
 * |                                                                          |
 * |  Copyright (c) 2022, Fantasy Technologies Limited and/or its         |
 * |  affiliated group companies ("Fantasy"). All rights reserved.        |
 * |  No part of this content, either material or conceptual may be copied    |
 * |  or distributed, transmitted, transcribed, stored in a retrieval system  |
 * |  or translated into any human or computer language in any form by any    |
 * |  means, electronic, mechanical manual, or otherwise, or disclosed to     |
 * |  third parties without the express written permission of Fantasy.    |
 * |                                                                          |
 * #==========================================================================#

 */


// ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////-
// entity name: gpc_gfx_sync_flop
// purpose: single Flip-Flop entity -  used in the implementation of the Multi-Stage Synchronizer.
//          It is expected that these registers would normally be replaced with customer specific metastable registers.
// ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////-



module gpc_gfx_sync_flop_
(
      input    logic                                                        clk                                     ,
      input    logic                                                        resetn                                  ,

      input    logic                                                        d_in                                    ,
      output   logic                                                        q_out                                     
);
   always_ff @(posedge clk or negedge resetn) begin : sync_flop
      if ( resetn == 1'b0 ) begin
         q_out <= 1'b0 ;
      end else begin
         q_out <= d_in ;
      end
   end // sync_flop
endmodule // gpc_gfx_sync_flop
