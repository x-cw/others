
module ecc_encoder #(
    parameter data_width     =  32,
    parameter ecc_width_in   =  7
) (
  input   [data_width-1:0] data,
  output  [ecc_width_in-1:0]   ecc
);


localparam  mask_p10=800'hFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFC00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
localparam  mask_p9=800'hFFFFFFFFFFE0000000000000000000000000000000000000000000000000000000000000003FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF80000000000000000000000000000000000000000000000000000000000000;
localparam  mask_p8=800'h00000000001FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFE00000000000000000000000000000003FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFC00000000000000000000000000000007FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000000000000000000000000000;
localparam  mask_p7=800'h00000000001FFFFFFFFFFFFFFFE0000000000000001FFFFFFFFFFFFFFFE0000000000000003FFFFFFFFFFFFFFFC0000000000000003FFFFFFFFFFFFFFFC0000000000000007FFFFFFFFFFFFFFF8000000000000000FFFFFFFFFFFFFFFE00000000000000;
localparam  mask_p6=800'hFFE00000001FFFFFFFE00000001FFFFFFFE00000001FFFFFFFE00000001FFFFFFFE00000003FFFFFFFC00000003FFFFFFFC00000003FFFFFFFC00000003FFFFFFFC00000007FFFFFFF800000007FFFFFFF80000000FFFFFFFF00000001FFFFFFFC000000;
localparam  mask_p5=800'h001FFFE0001FFFE0001FFFE0001FFFE0001FFFE0001FFFE0001FFFE0001FFFE0001FFFE0003FFFC0003FFFC0003FFFC0003FFFC0003FFFC0003FFFC0003FFFC0003FFFC0007FFF80007FFF80007FFF80007FFF8000FFFF0000FFFF0001FFFE0003FFF800;
localparam  mask_p4=800'hE01FE01FE01FE01FE01FE01FE01FE01FE01FE01FE01FE01FE01FE01FE01FE01FE01FE01FE03FC03FC03FC03FC03FC03FC03FC03FC03FC03FC03FC03FC03FC03FC03FC03FC07F807F807F807F807F807F807F807F80FF00FF00FF00FF01FE01FE03FC07F0;
localparam  mask_p3=800'h1E1E1E1E1E1E1E1E1E1E1E1E1E1E1E1E1E1E1E1E1E1E1E1E1E1E1E1E1E1E1E1E1E1E1E1E1E3C3C3C3C3C3C3C3C3C3C3C3C3C3C3C3C3C3C3C3C3C3C3C3C3C3C3C3C3C3C3C3C78787878787878787878787878787878F0F0F0F0F0F0F0F1E1E1E1E3C3C78E;
localparam  mask_p2=800'h99999999999999999999999999999999999999999999999999999999999999999999999999B33333333333333333333333333333333333333333333333333333333333333366666666666666666666666666666666CCCCCCCCCCCCCCCD9999999B33366D;
localparam  mask_p1=800'h555555555555555555555555555555555555555555555555555555555555555555555555556AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD5555555555555555555555555555555AAAAAAAAAAAAAAAB55555556AAAD5B;
localparam  mask_p0=800'h32CD32D2CD2D32D2CD32CD2D32D2CD2D32CD32D2CD32CD2D32CD32D2CD2D32D2CD32CD2D32DA65A59A659A5A65A59A5A659A65A59A659A5A659A65A59A5A65A59A659A5A65CB34B4CB34CB4B34B4CB4B34CB34B4CB69969669966969972CD2D32DA65CB7;

 generate 
    if (5<=data_width && data_width<=11) begin : encoder_width_5_11
        wire p0;
        wire p1;
        wire p2;
        wire p3;
        wire p4;
        
        assign p0 = ^ (data & mask_p0[data_width-1:0]);
        assign p1 = ^ (data & mask_p1[data_width-1:0]);
        assign p2 = ^ (data & mask_p2[data_width-1:0]);
        assign p3 = ^ (data & mask_p3[data_width-1:0]);
        assign p4 = ^ (data & mask_p4[data_width-1:0]);
        assign ecc = {p4, p3, p2, p1, p0};
    end
    else if (12<=data_width && data_width<=26) begin : encoder_width_12_26
        wire p0;
        wire p1;
        wire p2;
        wire p3;
        wire p4;
        wire p5;
        
        assign p0 = ^ (data & mask_p0[data_width-1:0]);
        assign p1 = ^ (data & mask_p1[data_width-1:0]);
        assign p2 = ^ (data & mask_p2[data_width-1:0]);
        assign p3 = ^ (data & mask_p3[data_width-1:0]);
        assign p4 = ^ (data & mask_p4[data_width-1:0]);
        assign p5 = ^ (data & mask_p5[data_width-1:0]);
        assign ecc = {p5 ,p4, p3, p2, p1, p0};
    end
    else if (27<=data_width && data_width<=57) begin : encoder_width_27_57
        wire p0;
        wire p1;
        wire p2;
        wire p3;
        wire p4;
        wire p5;
        wire p6;
        
        assign p0 = ^ (data & mask_p0[data_width-1:0]);
        assign p1 = ^ (data & mask_p1[data_width-1:0]);
        assign p2 = ^ (data & mask_p2[data_width-1:0]);
        assign p3 = ^ (data & mask_p3[data_width-1:0]);
        assign p4 = ^ (data & mask_p4[data_width-1:0]);
        assign p5 = ^ (data & mask_p5[data_width-1:0]);
        assign p6 = ^ (data & mask_p6[data_width-1:0]);
        assign ecc = {p6, p5 ,p4, p3, p2, p1, p0};
    end
    else if (58<=data_width && data_width<=120) begin : encoder_width_58_120
        wire p0;
        wire p1;
        wire p2;
        wire p3;
        wire p4;
        wire p5;
        wire p6;
        wire p7;
        
        assign p0 = ^ (data & mask_p0[data_width-1:0]);
        assign p1 = ^ (data & mask_p1[data_width-1:0]);
        assign p2 = ^ (data & mask_p2[data_width-1:0]);
        assign p3 = ^ (data & mask_p3[data_width-1:0]);
        assign p4 = ^ (data & mask_p4[data_width-1:0]);
        assign p5 = ^ (data & mask_p5[data_width-1:0]);
        assign p6 = ^ (data & mask_p6[data_width-1:0]);
        assign p7 = ^ (data & mask_p7[data_width-1:0]);
        assign ecc = {p7, p6, p5 ,p4, p3, p2, p1, p0};
    end
    else if (121<=data_width && data_width<=247) begin : encoder_width_121_247
        wire p0;
        wire p1;
        wire p2;
        wire p3;
        wire p4;
        wire p5;
        wire p6;
        wire p7;
        wire p8;
        
        assign p0 = ^ (data & mask_p0[data_width-1:0]);
        assign p1 = ^ (data & mask_p1[data_width-1:0]);
        assign p2 = ^ (data & mask_p2[data_width-1:0]);
        assign p3 = ^ (data & mask_p3[data_width-1:0]);
        assign p4 = ^ (data & mask_p4[data_width-1:0]);
        assign p5 = ^ (data & mask_p5[data_width-1:0]);
        assign p6 = ^ (data & mask_p6[data_width-1:0]);
        assign p7 = ^ (data & mask_p7[data_width-1:0]);
        assign p8 = ^ (data & mask_p8[data_width-1:0]);
        assign ecc = {p8, p7, p6, p5 ,p4, p3, p2, p1, p0};
    end
    else if (248<=data_width && data_width<=502) begin : encoder_width_248_502
        wire p0;
        wire p1;
        wire p2;
        wire p3;
        wire p4;
        wire p5;
        wire p6;
        wire p7;
        wire p8;
        wire p9;
        
        assign p0 = ^ (data & mask_p0[data_width-1:0]);
        assign p1 = ^ (data & mask_p1[data_width-1:0]);
        assign p2 = ^ (data & mask_p2[data_width-1:0]);
        assign p3 = ^ (data & mask_p3[data_width-1:0]);
        assign p4 = ^ (data & mask_p4[data_width-1:0]);
        assign p5 = ^ (data & mask_p5[data_width-1:0]);
        assign p6 = ^ (data & mask_p6[data_width-1:0]);
        assign p7 = ^ (data & mask_p7[data_width-1:0]);
        assign p8 = ^ (data & mask_p8[data_width-1:0]);
        assign p9 = ^ (data & mask_p9[data_width-1:0]);
        assign ecc = {p9, p8, p7, p6, p5 ,p4, p3, p2, p1, p0};
    end
    else if (503<=data_width && data_width<=800) begin : encoder_width_503_800
        wire p0;
        wire p1;
        wire p2;
        wire p3;
        wire p4;
        wire p5;
        wire p6;
        wire p7;
        wire p8;
        wire p9;
        wire p10;
        
        assign p0 = ^ (data & mask_p0[data_width-1:0]);
        assign p1 = ^ (data & mask_p1[data_width-1:0]);
        assign p2 = ^ (data & mask_p2[data_width-1:0]);
        assign p3 = ^ (data & mask_p3[data_width-1:0]);
        assign p4 = ^ (data & mask_p4[data_width-1:0]);
        assign p5 = ^ (data & mask_p5[data_width-1:0]);
        assign p6 = ^ (data & mask_p6[data_width-1:0]);
        assign p7 = ^ (data & mask_p7[data_width-1:0]);
        assign p8 = ^ (data & mask_p8[data_width-1:0]);
        assign p9 = ^ (data & mask_p9[data_width-1:0]);
        assign p10 = ^ (data & mask_p10[data_width-1:0]);
        assign ecc = {p10, p9, p8, p7, p6, p5 ,p4, p3, p2, p1, p0};
    end
endgenerate
endmodule

