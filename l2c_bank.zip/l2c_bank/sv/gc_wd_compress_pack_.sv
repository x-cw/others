/*

 * #==========================================================================#
 * |                                                                          |
 * |  Copyright (c) 2023, Fantasy Technologies Limited and/or its         |
 * |  affiliated group companies ("Fantasy"). All rights reserved.        |
 * |  No part of this content, either material or conceptual may be copied    |
 * |  or distributed, transmitted, transcribed, stored in a retrieval system  |
 * |  or translated into any human or computer language in any form by any    |
 * |  means, electronic, mechanical manual, or otherwise, or disclosed to     |
 * |  third parties without the express written permission of Fantasy.    |
 * |                                                                          |
 * #==========================================================================#

 */
package gc_wd_compress_pack_;
   //import gc_features_pack_::*;
   import pkg_mh_::*;
   //import gc_mss_pack_::*;
   //import pkg_mss_::*;
   import pkg_bif_::*;


   typedef struct packed {



      logic   [BIF_DATA_BUS_WIDTH - 1:0]         data;
      logic   [(BIF_DATA_BUS_WIDTH/8)/4 - 1:0]   dword_partial;
      logic   [(BIF_DATA_BUS_WIDTH/8)/4 - 1:0]   dword_active;
   } compressed_wd_rec;

   typedef struct packed {
      logic   [BIF_DATA_BUS_WIDTH/8 - 1:0]   mask;
      logic   [BIF_DATA_BUS_WIDTH - 1:0]     data;



   } standard_wd_rec;

   typedef compressed_wd_rec      cmpr_wd_record_array_type;
   typedef standard_wd_rec        decmpr_wd_record_array_type;

   localparam       WDATA_COMPRESSED_REC_BITS   = (BIF_DATA_BUS_WIDTH/8)/4 + (BIF_DATA_BUS_WIDTH/8)/4 // dword_active,  dword_partial



                                                  + BIF_DATA_BUS_WIDTH; // data


   // Compress byte-mask bits of WMask into the WData
   function automatic compressed_wd_rec  f_wd_compress (
      standard_wd_rec      standard_wd,
      logic                aa
   );
      compressed_wd_rec      compressed_wd;
      // Atomic Access
      compressed_wd.data = standard_wd.data;
      compressed_wd.dword_active = standard_wd.mask[(BIF_DATA_BUS_WIDTH/8)/4 - 1:0];
      compressed_wd.dword_partial = standard_wd.mask[(BIF_DATA_BUS_WIDTH/8)/2 - 1:(BIF_DATA_BUS_WIDTH/8)/4];



      if(aa==1'b0) begin //For Non Atomic Access, overwrite output

         for(int unsigned b=0; b<=BIF_DATA_BUS_WIDTH/32 - 1; b++) begin
            compressed_wd.dword_active[b] = (~&(standard_wd.mask[4*b +: 4]));
            compressed_wd.dword_partial[b] = (|(standard_wd.mask[4*b +: 4]));
         end

         for(int unsigned d=0; d<=BIF_DATA_BUS_WIDTH/32 - 1; d++) begin // Cycle through all dwords
            // All upper nibbles in each byte are unchanged
            // Only the lower nibbles in partial dwords are altered to compress the wmask
            if(compressed_wd.dword_partial[d]==1'b1) begin
               // The low nibble of byte 0 is always the byte-granular mask
               compressed_wd.data[32*d +: 4] = standard_wd.mask[4*d +: 4];

               // For bytes 1-3, if the byte is masked then the low nibble is overloaded with the low nibble of byte 0
               for(int unsigned b=1; b<=3; b++) begin
                  if(standard_wd.mask[d*4 + b]==1'b1) begin
                     compressed_wd.data[8*b + 32*d +: 4] = standard_wd.data[32*d +: 4];
                  end
               end

            end
         end

      end
      return compressed_wd;
   endfunction : f_wd_compress

   // Decompress byte-mask bits from WData back into the WMask
   function automatic standard_wd_rec  f_wd_decompress (
      compressed_wd_rec      compressed_wd,
      logic                  aa
   );
      standard_wd_rec      standard_wd;
      // Atomic Access
      standard_wd.data = compressed_wd.data;
      standard_wd.mask[(BIF_DATA_BUS_WIDTH/8)/4 - 1:0] = compressed_wd.dword_active;
      standard_wd.mask[(BIF_DATA_BUS_WIDTH/8)/2 - 1:(BIF_DATA_BUS_WIDTH/8)/4] = compressed_wd.dword_partial;
      standard_wd.mask[(BIF_DATA_BUS_WIDTH/8)-1:(BIF_DATA_BUS_WIDTH/8)/2] = '0;



      if(aa==1'b0) begin //For Non atomic access, overwrite output

         for(int unsigned d=0; d<=BIF_DATA_BUS_WIDTH/32 - 1; d++) begin
            if(compressed_wd.dword_active[d]==1'b0) begin
               standard_wd.mask[4*d +: 4] = 4'b1111; // inactive dword has all bytes masked; the data is not altered.
            end
            else if(compressed_wd.dword_partial[d]==1'b0) begin
               standard_wd.mask[4*d +: 4] = 4'b0000; // active non-partial dword has all bytes non-masked; the data is not altered.
            end
            else begin
               standard_wd.mask[4*d +: 4] = compressed_wd.data[32*d +: 4]; // byte-granular mask retrieved from the low nibble of byte 0

               for(int unsigned b=1; b<=3; b++) begin
                  // Retrieve the low nibble of byte 0 from a masked byte
                  if(compressed_wd.data[d*32 + b]==1'b1) begin
                     standard_wd.data[32*d +: 4] = compressed_wd.data[8*b + 32*d +: 4];
                  end
               end

            end
         end

      end
      return standard_wd;
   endfunction : f_wd_decompress

endpackage : gc_wd_compress_pack_
