/*



*/
// ----------------------------------------------------------------------------------------------
// entity name: gc_l2_bank_int_pipe
// purpose: internal pipeline
// ----------------------------------------------------------------------------------------------

module gc_l2_bank_int_pipe
import group_nsp_req_pkg::*;
import group_nsp_rsp_pkg::*;
import nsp_rsp_pkg::*;
import nsp_req_pkg::*;
import bank_sched_pkg::*;
import sched_bank_pkg::*;
import axi5_ar_pkg::*;
import axi5_r_pkg::*;
import axi5_aw_pkg::*;
import axi5_w_pkg::*;
import axi5_b_pkg::*;
import gc_l2_bank_pkg::*;
import gc_l2_bank_group_pkg::*;
#(parameter BANK_WRAP = 0)
(
    // AXI interface
    input   logic                           i_axi_slv_0_arvalid,
    output  logic                           i_axi_slv_0_arready,
    input   axi5_ar_data_bus_t              i_axi_slv_0_ar_rec,
    output  logic                           i_axi_slv_0_rvalid,
    input   logic                           i_axi_slv_0_rready,
    output  axi5_r_data_bus_t               i_axi_slv_0_r_rec,
    input   logic                           i_axi_slv_0_awvalid,
    output  logic                           i_axi_slv_0_awready,
    input   axi5_aw_data_bus_t              i_axi_slv_0_aw_rec,
    input   logic                           i_axi_slv_0_wvalid,
    output  logic                           i_axi_slv_0_wready,
    input   axi5_w_data_bus_t               i_axi_slv_0_w_rec,
    output  logic                           i_axi_slv_0_bvalid,
    input   logic                           i_axi_slv_0_bready,
    output  axi5_b_data_bus_t               i_axi_slv_0_b_rec,

    output  logic                           o_axi_slv_0_arvalid,
    input   logic                           o_axi_slv_0_arready,
    output  axi5_ar_data_bus_t              o_axi_slv_0_ar_rec,
    input   logic                           o_axi_slv_0_rvalid,
    output  logic                           o_axi_slv_0_rready,
    input   axi5_r_data_bus_t               o_axi_slv_0_r_rec,
    output  logic                           o_axi_slv_0_awvalid,
    input   logic                           o_axi_slv_0_awready,
    output  axi5_aw_data_bus_t              o_axi_slv_0_aw_rec,
    output  logic                           o_axi_slv_0_wvalid,
    input   logic                           o_axi_slv_0_wready,
    output  axi5_w_data_bus_t               o_axi_slv_0_w_rec,
    input   logic                           o_axi_slv_0_bvalid,
    output  logic                           o_axi_slv_0_bready,
    input   axi5_b_data_bus_t               o_axi_slv_0_b_rec,

    input   logic                           i_axi_slv_1_arvalid,
    output  logic                           i_axi_slv_1_arready,
    input   axi5_ar_data_bus_t              i_axi_slv_1_ar_rec,
    output  logic                           i_axi_slv_1_rvalid,
    input   logic                           i_axi_slv_1_rready,
    output  axi5_r_data_bus_t               i_axi_slv_1_r_rec,
    input   logic                           i_axi_slv_1_awvalid,
    output  logic                           i_axi_slv_1_awready,
    input   axi5_aw_data_bus_t              i_axi_slv_1_aw_rec,
    input   logic                           i_axi_slv_1_wvalid,
    output  logic                           i_axi_slv_1_wready,
    input   axi5_w_data_bus_t               i_axi_slv_1_w_rec,
    output  logic                           i_axi_slv_1_bvalid,
    input   logic                           i_axi_slv_1_bready,
    output  axi5_b_data_bus_t               i_axi_slv_1_b_rec,

    output  logic                           o_axi_slv_1_arvalid,
    input   logic                           o_axi_slv_1_arready,
    output  axi5_ar_data_bus_t              o_axi_slv_1_ar_rec,
    input   logic                           o_axi_slv_1_rvalid,
    output  logic                           o_axi_slv_1_rready,
    input   axi5_r_data_bus_t               o_axi_slv_1_r_rec,
    output  logic                           o_axi_slv_1_awvalid,
    input   logic                           o_axi_slv_1_awready,
    output  axi5_aw_data_bus_t              o_axi_slv_1_aw_rec,
    output  logic                           o_axi_slv_1_wvalid,
    input   logic                           o_axi_slv_1_wready,
    output  axi5_w_data_bus_t               o_axi_slv_1_w_rec,
    input   logic                           o_axi_slv_1_bvalid,
    output  logic                           o_axi_slv_1_bready,
    input   axi5_b_data_bus_t               o_axi_slv_1_b_rec,
    // NSP interface
    input   logic                    [L2_XBAR_NUM_BANK-1:0] i_nsp_req_valid,
    output  logic                    [L2_XBAR_NUM_BANK-1:0] i_nsp_req_ready,
    input   group_nsp_req_data_bus_t [L2_XBAR_NUM_BANK-1:0] i_nsp_req_rec,
    output  logic                    [L2_XBAR_NUM_BANK-1:0] i_nsp_rsp_valid,
    input   logic                    [L2_XBAR_NUM_BANK-1:0] i_nsp_rsp_ready,
    output  group_nsp_rsp_data_bus_t [L2_XBAR_NUM_BANK-1:0] i_nsp_rsp_rec,

    output  logic                    [L2_XBAR_NUM_BANK-1:0] o_nsp_req_valid,
    input   logic                    [L2_XBAR_NUM_BANK-1:0] o_nsp_req_ready,
    output  group_nsp_req_data_bus_t [L2_XBAR_NUM_BANK-1:0] o_nsp_req_rec,
    input   logic                    [L2_XBAR_NUM_BANK-1:0] o_nsp_rsp_valid,
    output  logic                    [L2_XBAR_NUM_BANK-1:0] o_nsp_rsp_ready,
    input   group_nsp_rsp_data_bus_t [L2_XBAR_NUM_BANK-1:0] o_nsp_rsp_rec,
    // configure register
    input   logic [ 4 : 0 ]                 i_gc_cr_l2_mem_sched_row_partii_row_id_bit8,
    input   logic [ 4 : 0 ]                 i_gc_cr_l2_mem_sched_row_partii_row_id_bit9,
    input   logic [ 4 : 0 ]                 i_gc_cr_l2_mem_sched_row_partii_row_id_bit10,
    input   logic [ 4 : 0 ]                 i_gc_cr_l2_mem_sched_row_partii_row_id_bit11,
    input   logic [ 4 : 0 ]                 i_gc_cr_l2_mem_sched_row_partii_row_id_bit12,
    input   logic [ 4 : 0 ]                 i_gc_cr_l2_mem_sched_row_partii_row_id_bit13,
    input   logic [ 4 : 0 ]                 i_gc_cr_l2_mem_sched_row_partii_row_id_bit14,
    input   logic [ 4 : 0 ]                 i_gc_cr_l2_mem_sched_row_partii_row_id_bit15,
    input   logic [ 4 : 0 ]                 i_gc_cr_l2_mem_sched_row_partiii_row_id_bit16,
    input   logic [ 4 : 0 ]                 i_gc_cr_l2_mem_sched_row_partiii_row_id_bit17,
    input   logic [ 3 : 0 ]                 i_gc_cr_l2_function_enable_ddr_capacity,
    input   logic [ 1 : 0 ]                 i_gc_cr_clk_ctrl3_l2g,
    input   logic [ 1 : 0 ]                 i_gc_cr_l2_cfi_operation,
    input   logic [ 1 : 0 ]                 i_gc_cr_l2_buffer_mode_buffer_mode_percentage,
    input   logic                           i_gc_cr_l2_persistence_reduce_enable,
    input   logic [ 20 : 0 ]                i_gc_cr_l2_persistence_reduce_threshold,
    input   logic                           i_gc_cr_l2_cmd_persistence_rst_all,
    input   logic                           i_gc_cr_l2_cmd_cfi_clr,
    input   logic                           i_gc_cr_l2_function_enable_mem_scheduler,
    input   logic                           i_gc_cr_l2_function_enable_bypass_mode,
    input   logic [ 4 : 0 ]                 i_gc_cr_l2_mem_sched_col_offset_column_id_bit0,
    input   logic [ 4 : 0 ]                 i_gc_cr_l2_mem_sched_col_offset_column_id_bit1,
    input   logic [ 4 : 0 ]                 i_gc_cr_l2_mem_sched_col_offset_column_id_bit2,
    input   logic [ 4 : 0 ]                 i_gc_cr_l2_mem_sched_col_offset_column_id_bit3,
    input   logic [ 4 : 0 ]                 i_gc_cr_l2_mem_sched_col_offset_column_id_bit4,
    input   logic [ 4 : 0 ]                 i_gc_cr_l2_mem_sched_col_offset_column_id_bit5,
    input   logic [ 4 : 0 ]                 i_gc_cr_l2_mem_sched_bank_offset_bank_id_bit0,
    input   logic [ 4 : 0 ]                 i_gc_cr_l2_mem_sched_bank_offset_bank_id_bit1,
    input   logic [ 4 : 0 ]                 i_gc_cr_l2_mem_sched_bank_offset_bank_id_bit2,
    input   logic [ 4 : 0 ]                 i_gc_cr_l2_mem_sched_bank_offset_bank_id_bit3,
    input   logic [ 4 : 0 ]                 i_gc_cr_l2_mem_sched_bank_offset_bank_id_bit4,
    input   logic [ 4 : 0 ]                 i_gc_cr_l2_mem_sched_row_parti_row_id_bit0,
    input   logic [ 4 : 0 ]                 i_gc_cr_l2_mem_sched_row_parti_row_id_bit1,
    input   logic [ 4 : 0 ]                 i_gc_cr_l2_mem_sched_row_parti_row_id_bit2,
    input   logic [ 4 : 0 ]                 i_gc_cr_l2_mem_sched_row_parti_row_id_bit3,
    input   logic [ 4 : 0 ]                 i_gc_cr_l2_mem_sched_row_parti_row_id_bit4,
    input   logic [ 4 : 0 ]                 i_gc_cr_l2_mem_sched_row_parti_row_id_bit5,
    input   logic [ 4 : 0 ]                 i_gc_cr_l2_mem_sched_row_parti_row_id_bit6,
    input   logic [ 4 : 0 ]                 i_gc_cr_l2_mem_sched_row_parti_row_id_bit7,
    input   logic [ 3 : 0 ]                 i_gc_cr_ddr_hash_config_reg0_row_id_bit0        ,
    input   logic [ 3 : 0 ]                 i_gc_cr_ddr_hash_config_reg0_row_id_bit1        ,
    input   logic [ 3 : 0 ]                 i_gc_cr_ddr_hash_config_reg0_row_id_bit2        ,
    input   logic [ 3 : 0 ]                 i_gc_cr_ddr_hash_config_reg0_row_id_bit3        ,
    input   logic [ 3 : 0 ]                 i_gc_cr_ddr_hash_config_reg0_row_id_bit4        ,
    input   logic [ 3 : 0 ]                 i_gc_cr_ddr_hash_config_reg0_row_id_bit5        ,
    input   logic [ 3 : 0 ]                 i_gc_cr_ddr_hash_config_reg0_row_id_bit6        ,
    input   logic [ 3 : 0 ]                 i_gc_cr_ddr_hash_config_reg0_row_id_bit7        ,
    input   logic [ 3 : 0 ]                 i_gc_cr_ddr_hash_config_reg0_row_id_bit8        ,
    input   logic [ 3 : 0 ]                 i_gc_cr_ddr_hash_config_reg0_row_id_bit9        ,
    input   logic [ 3 : 0 ]                 i_gc_cr_ddr_hash_config_reg0_row_id_bit10       ,
    input   logic [ 3 : 0 ]                 i_gc_cr_ddr_hash_config_reg0_row_id_bit11       ,
    input   logic [ 3 : 0 ]                 i_gc_cr_ddr_hash_config_reg1_row_id_bit12       ,
    input   logic [ 3 : 0 ]                 i_gc_cr_ddr_hash_config_reg1_row_id_bit13       ,
    input   logic [ 3 : 0 ]                 i_gc_cr_ddr_hash_config_reg1_row_id_bit14       ,
    input   logic [ 3 : 0 ]                 i_gc_cr_ddr_hash_config_reg1_row_id_bit15       ,
    input   logic [ 3 : 0 ]                 i_gc_cr_ddr_hash_config_reg1_row_id_bit16       ,
    input   logic [ 3 : 0 ]                 i_gc_cr_ddr_hash_config_reg1_row_id_bit17       ,
    input   logic [ 3 : 0 ]                 i_gc_cr_ddr_hash_config_reg1_row_id_bit18       ,
    input   logic [ 3 : 0 ]                 i_gc_cr_ddr_hash_config_reg1_row_id_bit19       ,
    input   logic [ 3 : 0 ]                 i_gc_cr_ddr_hash_config_reg1_row_id_bit20       ,
    input   logic [ 3 : 0 ]                 i_gc_cr_ddr_hash_config_reg1_row_id_bit21       ,
    input   logic [ 3 : 0 ]                 i_gc_cr_ddr_hash_config_reg1_row_id_bit22       ,
    input   logic [ 3 : 0 ]                 i_gc_cr_ddr_hash_config_reg1_row_id_bit23       ,
    input   logic [ 1 : 0]                  i_gc_cr_l2_function_enable_hash_mode            ,
    input   logic [ 4 : 0 ]                 i_gc_cr_pwr_man_hysteresis_value,
    input   logic [ 1 : 0 ]                 i_gc_cr_crm_reset_clk_ctrl,
    input   logic                           i_gc_cr_cu_lms_fp32_denormal_en,
    input   logic                           i_gc_cr_l2_cfi_operation_notify,
    input   logic                           i_gc_cr_l2_cfi_operation_rdnotify,
    input   logic                           i_gc_cr_l2_cmd_notify,
    input   logic                           i_gc_cr_l2_cmd_rdnotify,
    output  logic                           i_gc_cr_clk_status3_l2g,
    output  logic                           i_gc_cr_l2_cfi_statusi_l2b0_finish,
    output  logic                           i_gc_cr_l2_cfi_statusi_l2b1_finish,
    output  logic [ 1 : 0 ]                 i_gc_cr_l2g_idle_l2g,
    output  logic [ 2 : 0 ]                 i_gc_cr_l2g_error0_l2b0,
    output  logic [ 2 : 0 ]                 i_gc_cr_l2g_error0_l2b1,

    output  logic [ 4 : 0 ]                 o_gc_cr_l2_mem_sched_row_partii_row_id_bit8,
    output  logic [ 4 : 0 ]                 o_gc_cr_l2_mem_sched_row_partii_row_id_bit9,
    output  logic [ 4 : 0 ]                 o_gc_cr_l2_mem_sched_row_partii_row_id_bit10,
    output  logic [ 4 : 0 ]                 o_gc_cr_l2_mem_sched_row_partii_row_id_bit11,
    output  logic [ 4 : 0 ]                 o_gc_cr_l2_mem_sched_row_partii_row_id_bit12,
    output  logic [ 4 : 0 ]                 o_gc_cr_l2_mem_sched_row_partii_row_id_bit13,
    output  logic [ 4 : 0 ]                 o_gc_cr_l2_mem_sched_row_partii_row_id_bit14,
    output  logic [ 4 : 0 ]                 o_gc_cr_l2_mem_sched_row_partii_row_id_bit15,
    output  logic [ 4 : 0 ]                 o_gc_cr_l2_mem_sched_row_partiii_row_id_bit16,
    output  logic [ 4 : 0 ]                 o_gc_cr_l2_mem_sched_row_partiii_row_id_bit17,
    output  logic [ 3 : 0 ]                 o_gc_cr_l2_function_enable_ddr_capacity,
    output  logic [ 1 : 0 ]                 o_gc_cr_clk_ctrl3_l2g,
    output  logic [ 1 : 0 ]                 o_gc_cr_l2_cfi_operation,
    output  logic [ 1 : 0 ]                 o_gc_cr_l2_buffer_mode_buffer_mode_percentage,
    output  logic                           o_gc_cr_l2_persistence_reduce_enable,
    output  logic [ 20 : 0 ]                o_gc_cr_l2_persistence_reduce_threshold,
    output  logic                           o_gc_cr_l2_cmd_persistence_rst_all,
    output  logic                           o_gc_cr_l2_cmd_cfi_clr,
    output  logic                           o_gc_cr_l2_function_enable_mem_scheduler,
    output  logic                           o_gc_cr_l2_function_enable_bypass_mode,
    output  logic [ 4 : 0 ]                 o_gc_cr_l2_mem_sched_col_offset_column_id_bit0,
    output  logic [ 4 : 0 ]                 o_gc_cr_l2_mem_sched_col_offset_column_id_bit1,
    output  logic [ 4 : 0 ]                 o_gc_cr_l2_mem_sched_col_offset_column_id_bit2,
    output  logic [ 4 : 0 ]                 o_gc_cr_l2_mem_sched_col_offset_column_id_bit3,
    output  logic [ 4 : 0 ]                 o_gc_cr_l2_mem_sched_col_offset_column_id_bit4,
    output  logic [ 4 : 0 ]                 o_gc_cr_l2_mem_sched_col_offset_column_id_bit5,
    output  logic [ 4 : 0 ]                 o_gc_cr_l2_mem_sched_bank_offset_bank_id_bit0,
    output  logic [ 4 : 0 ]                 o_gc_cr_l2_mem_sched_bank_offset_bank_id_bit1,
    output  logic [ 4 : 0 ]                 o_gc_cr_l2_mem_sched_bank_offset_bank_id_bit2,
    output  logic [ 4 : 0 ]                 o_gc_cr_l2_mem_sched_bank_offset_bank_id_bit3,
    output  logic [ 4 : 0 ]                 o_gc_cr_l2_mem_sched_bank_offset_bank_id_bit4,
    output  logic [ 4 : 0 ]                 o_gc_cr_l2_mem_sched_row_parti_row_id_bit0,
    output  logic [ 4 : 0 ]                 o_gc_cr_l2_mem_sched_row_parti_row_id_bit1,
    output  logic [ 4 : 0 ]                 o_gc_cr_l2_mem_sched_row_parti_row_id_bit2,
    output  logic [ 4 : 0 ]                 o_gc_cr_l2_mem_sched_row_parti_row_id_bit3,
    output  logic [ 4 : 0 ]                 o_gc_cr_l2_mem_sched_row_parti_row_id_bit4,
    output  logic [ 4 : 0 ]                 o_gc_cr_l2_mem_sched_row_parti_row_id_bit5,
    output  logic [ 4 : 0 ]                 o_gc_cr_l2_mem_sched_row_parti_row_id_bit6,
    output  logic [ 4 : 0 ]                 o_gc_cr_l2_mem_sched_row_parti_row_id_bit7,
    output  logic [ 3 : 0 ]                 o_gc_cr_ddr_hash_config_reg0_row_id_bit0        ,
    output  logic [ 3 : 0 ]                 o_gc_cr_ddr_hash_config_reg0_row_id_bit1        ,
    output  logic [ 3 : 0 ]                 o_gc_cr_ddr_hash_config_reg0_row_id_bit2        ,
    output  logic [ 3 : 0 ]                 o_gc_cr_ddr_hash_config_reg0_row_id_bit3        ,
    output  logic [ 3 : 0 ]                 o_gc_cr_ddr_hash_config_reg0_row_id_bit4        ,
    output  logic [ 3 : 0 ]                 o_gc_cr_ddr_hash_config_reg0_row_id_bit5        ,
    output  logic [ 3 : 0 ]                 o_gc_cr_ddr_hash_config_reg0_row_id_bit6        ,
    output  logic [ 3 : 0 ]                 o_gc_cr_ddr_hash_config_reg0_row_id_bit7        ,
    output  logic [ 3 : 0 ]                 o_gc_cr_ddr_hash_config_reg0_row_id_bit8        ,
    output  logic [ 3 : 0 ]                 o_gc_cr_ddr_hash_config_reg0_row_id_bit9        ,
    output  logic [ 3 : 0 ]                 o_gc_cr_ddr_hash_config_reg0_row_id_bit10       ,
    output  logic [ 3 : 0 ]                 o_gc_cr_ddr_hash_config_reg0_row_id_bit11       ,
    output  logic [ 3 : 0 ]                 o_gc_cr_ddr_hash_config_reg1_row_id_bit12       ,
    output  logic [ 3 : 0 ]                 o_gc_cr_ddr_hash_config_reg1_row_id_bit13       ,
    output  logic [ 3 : 0 ]                 o_gc_cr_ddr_hash_config_reg1_row_id_bit14       ,
    output  logic [ 3 : 0 ]                 o_gc_cr_ddr_hash_config_reg1_row_id_bit15       ,
    output  logic [ 3 : 0 ]                 o_gc_cr_ddr_hash_config_reg1_row_id_bit16       ,
    output  logic [ 3 : 0 ]                 o_gc_cr_ddr_hash_config_reg1_row_id_bit17       ,
    output  logic [ 3 : 0 ]                 o_gc_cr_ddr_hash_config_reg1_row_id_bit18       ,
    output  logic [ 3 : 0 ]                 o_gc_cr_ddr_hash_config_reg1_row_id_bit19       ,
    output  logic [ 3 : 0 ]                 o_gc_cr_ddr_hash_config_reg1_row_id_bit20       ,
    output  logic [ 3 : 0 ]                 o_gc_cr_ddr_hash_config_reg1_row_id_bit21       ,
    output  logic [ 3 : 0 ]                 o_gc_cr_ddr_hash_config_reg1_row_id_bit22       ,
    output  logic [ 3 : 0 ]                 o_gc_cr_ddr_hash_config_reg1_row_id_bit23       ,
    output  logic [ 1 : 0]                  o_gc_cr_l2_function_enable_hash_mode            ,
    output  logic [ 4 : 0 ]                 o_gc_cr_pwr_man_hysteresis_value,
    output  logic [ 1 : 0 ]                 o_gc_cr_crm_reset_clk_ctrl,
    output  logic                           o_gc_cr_cu_lms_fp32_denormal_en,
    output  logic                           o_gc_cr_l2_cfi_operation_notify,
    output  logic                           o_gc_cr_l2_cfi_operation_rdnotify,
    output  logic                           o_gc_cr_l2_cmd_notify,
    output  logic                           o_gc_cr_l2_cmd_rdnotify,
    input   logic                           o_gc_cr_clk_status3_l2g,
    input   logic                           o_gc_cr_l2_cfi_statusi_l2b0_finish,
    input   logic                           o_gc_cr_l2_cfi_statusi_l2b1_finish,
    input   logic [ 1 : 0 ]                 o_gc_cr_l2g_idle_l2g,
    input   logic [ 2 : 0 ]                 o_gc_cr_l2g_error0_l2b0,
    input   logic [ 2 : 0 ]                 o_gc_cr_l2g_error0_l2b1,




    input   logic                           i_l2b0_busy                                    ,
    input   logic                           i_l2b0_fromaxi_ar_wl                           ,
    input   logic                           i_l2b0_fromaxi_ar_bl_eq0_wl                    ,
    input   logic                           i_l2b0_fromaxi_ar_bl_eq1_wl                    ,
    input   logic                           i_l2b0_fromaxi_ar_bl_eq2_wl                    ,
    input   logic                           i_l2b0_fromaxi_ar_bl_eq3_wl                    ,
    input   logic                           i_l2b0_fromaxi_ar_bp                           ,
    input   logic                           i_l2b0_toaxi_r_wl                              ,
    input   logic                           i_l2b0_toaxi_r_bp                              ,
    input   logic                           i_l2b0_fromaxi_aw_wl                           ,
    input   logic                           i_l2b0_fromaxi_aw_bl_eq0_wl                    ,
    input   logic                           i_l2b0_fromaxi_aw_bl_eq1_wl                    ,
    input   logic                           i_l2b0_fromaxi_aw_bl_eq2_wl                    ,
    input   logic                           i_l2b0_fromaxi_aw_bl_eq3_wl                    ,
    input   logic                           i_l2b0_fromaxi_aw_bp                           ,
    input   logic                           i_l2b0_fromaxi_w_wl                            ,
    input   logic                           i_l2b0_fromaxi_w_bp                            ,
    input   logic                           i_l2b0_fromaxi_smp_read_req_num                ,
    input   logic                           i_l2b0_fromaxi_smp_read_req_sum                ,
    input   logic                           i_l2b0_fromaxi_smp_write_req_num               ,
    input   logic                           i_l2b0_fromaxi_smp_write_req_sum               ,
    input   logic                           i_l2b0_fromaxi_smp_atomic_req_num              ,
    input   logic                           i_l2b0_fromaxi_smp_atomic_req_sum              ,
    input   logic                           i_l2b0_align_awdb_full                         ,
    input   logic                           i_l2b0_hittest_ht_bypass_read_wl               ,
    input   logic                           i_l2b0_hittest_ht_cache_read_wl                ,
    input   logic                           i_l2b0_hittest_ht_bypass_write_wl              ,
    input   logic                           i_l2b0_hittest_ht_cache_write_wl               ,
    input   logic                           i_l2b0_hittest_ht_atomic_wl                    ,
    input   logic                           i_l2b0_hittest_ht_bps_hit_wl                   ,
    input   logic                           i_l2b0_hittest_ht_miss_wl                      ,
    input   logic                           i_l2b0_frommemsch_nsp_rtn_wl                   ,
    input   logic                           i_l2b0_frommemsch_nsp_rtn_bp                   ,
    input   logic                           i_l2b0_tomemsch_nsp_read_bl_eq1_wl             ,
    input   logic                           i_l2b0_tomemsch_nsp_read_bl_eq3_wl             ,
    input   logic                           i_l2b0_tomemsch_nsp_read_bl_eq5_wl             ,
    input   logic                           i_l2b0_tomemsch_nsp_read_bl_eq7_wl             ,
    input   logic                           i_l2b0_tomemsch_nsp_write_bl_eq1_wl            ,
    input   logic                           i_l2b0_tomemsch_nsp_write_bl_eq3_wl            ,
    input   logic                           i_l2b0_tomemsch_nsp_write_bl_eq5_wl            ,
    input   logic                           i_l2b0_tomemsch_nsp_write_bl_eq7_wl            ,
    input   logic                           i_l2b0_memif_to_ddr_read_wl                    ,
    input   logic                           i_l2b0_memif_to_ddr_read_stall_by_rob          ,
    input   logic                           i_l2b0_memif_to_ddr_read_stall_by_ddr          ,
    input   logic                           i_l2b0_memif_to_ddr_read_stall_by_trid         ,
    input   logic                           i_l2b0_memif_to_ddr_write_wl                   ,
    input   logic                           i_l2b0_memif_to_ddr_write_stall_by_data_sync   ,
    input   logic                           i_l2b0_memif_to_ddr_write_stall_by_ddr         ,
    input   logic                           i_l2b0_memif_to_ddr_write_stall_by_trid        ,
    input   logic                           i_l2b0_memif_memreq_full                       ,
    input   logic                           i_l2b0_memif_smp_read_req_num                  ,
    input   logic                           i_l2b0_memif_smp_read_req_sum                  ,
    input   logic                           i_l2b0_reqsch_sortq_full                       ,
    input   logic                           i_l2b0_reqsch_sortq_stall_but_not_full         ,
    input   logic                           i_l2b0_reqsch_disp_wl                          ,
    input   logic                           i_l2b0_reqsch_disp_stall                       ,
    input   logic                           i_l2b0_ramctrl_0_reqarb_wl                     ,
    input   logic                           i_l2b0_ramctrl_0_reqarb_stall_by_sram          ,
    input   logic                           i_l2b0_ramctrl_0_data_sram_read_wl             ,
    input   logic                           i_l2b0_ramctrl_0_data_sram_write_wl            ,
    input   logic                           i_l2b0_ramctrl_1_reqarb_wl                     ,
    input   logic                           i_l2b0_ramctrl_1_reqarb_stall_by_sram          ,
    input   logic                           i_l2b0_ramctrl_1_data_sram_read_wl             ,
    input   logic                           i_l2b0_ramctrl_1_data_sram_write_wl            ,

    output  logic                           o_l2b0_busy                                    ,
    output  logic                           o_l2b0_fromaxi_ar_wl                           ,
    output  logic                           o_l2b0_fromaxi_ar_bl_eq0_wl                    ,
    output  logic                           o_l2b0_fromaxi_ar_bl_eq1_wl                    ,
    output  logic                           o_l2b0_fromaxi_ar_bl_eq2_wl                    ,
    output  logic                           o_l2b0_fromaxi_ar_bl_eq3_wl                    ,
    output  logic                           o_l2b0_fromaxi_ar_bp                           ,
    output  logic                           o_l2b0_toaxi_r_wl                              ,
    output  logic                           o_l2b0_toaxi_r_bp                              ,
    output  logic                           o_l2b0_fromaxi_aw_wl                           ,
    output  logic                           o_l2b0_fromaxi_aw_bl_eq0_wl                    ,
    output  logic                           o_l2b0_fromaxi_aw_bl_eq1_wl                    ,
    output  logic                           o_l2b0_fromaxi_aw_bl_eq2_wl                    ,
    output  logic                           o_l2b0_fromaxi_aw_bl_eq3_wl                    ,
    output  logic                           o_l2b0_fromaxi_aw_bp                           ,
    output  logic                           o_l2b0_fromaxi_w_wl                            ,
    output  logic                           o_l2b0_fromaxi_w_bp                            ,
    output  logic                           o_l2b0_fromaxi_smp_read_req_num                ,
    output  logic                           o_l2b0_fromaxi_smp_read_req_sum                ,
    output  logic                           o_l2b0_fromaxi_smp_write_req_num               ,
    output  logic                           o_l2b0_fromaxi_smp_write_req_sum               ,
    output  logic                           o_l2b0_fromaxi_smp_atomic_req_num              ,
    output  logic                           o_l2b0_fromaxi_smp_atomic_req_sum              ,
    output  logic                           o_l2b0_align_awdb_full                         ,
    output  logic                           o_l2b0_hittest_ht_bypass_read_wl               ,
    output  logic                           o_l2b0_hittest_ht_cache_read_wl                ,
    output  logic                           o_l2b0_hittest_ht_bypass_write_wl              ,
    output  logic                           o_l2b0_hittest_ht_cache_write_wl               ,
    output  logic                           o_l2b0_hittest_ht_atomic_wl                    ,
    output  logic                           o_l2b0_hittest_ht_bps_hit_wl                   ,
    output  logic                           o_l2b0_hittest_ht_miss_wl                      ,
    output  logic                           o_l2b0_frommemsch_nsp_rtn_wl                   ,
    output  logic                           o_l2b0_frommemsch_nsp_rtn_bp                   ,
    output  logic                           o_l2b0_tomemsch_nsp_read_bl_eq1_wl             ,
    output  logic                           o_l2b0_tomemsch_nsp_read_bl_eq3_wl             ,
    output  logic                           o_l2b0_tomemsch_nsp_read_bl_eq5_wl             ,
    output  logic                           o_l2b0_tomemsch_nsp_read_bl_eq7_wl             ,
    output  logic                           o_l2b0_tomemsch_nsp_write_bl_eq1_wl            ,
    output  logic                           o_l2b0_tomemsch_nsp_write_bl_eq3_wl            ,
    output  logic                           o_l2b0_tomemsch_nsp_write_bl_eq5_wl            ,
    output  logic                           o_l2b0_tomemsch_nsp_write_bl_eq7_wl            ,
    output  logic                           o_l2b0_memif_to_ddr_read_wl                    ,
    output  logic                           o_l2b0_memif_to_ddr_read_stall_by_rob          ,
    output  logic                           o_l2b0_memif_to_ddr_read_stall_by_ddr          ,
    output  logic                           o_l2b0_memif_to_ddr_read_stall_by_trid         ,
    output  logic                           o_l2b0_memif_to_ddr_write_wl                   ,
    output  logic                           o_l2b0_memif_to_ddr_write_stall_by_data_sync   ,
    output  logic                           o_l2b0_memif_to_ddr_write_stall_by_ddr         ,
    output  logic                           o_l2b0_memif_to_ddr_write_stall_by_trid        ,
    output  logic                           o_l2b0_memif_memreq_full                       ,
    output  logic                           o_l2b0_memif_smp_read_req_num                  ,
    output  logic                           o_l2b0_memif_smp_read_req_sum                  ,
    output  logic                           o_l2b0_reqsch_sortq_full                       ,
    output  logic                           o_l2b0_reqsch_sortq_stall_but_not_full         ,
    output  logic                           o_l2b0_reqsch_disp_wl                          ,
    output  logic                           o_l2b0_reqsch_disp_stall                       ,
    output  logic                           o_l2b0_ramctrl_0_reqarb_wl                     ,
    output  logic                           o_l2b0_ramctrl_0_reqarb_stall_by_sram          ,
    output  logic                           o_l2b0_ramctrl_0_data_sram_read_wl             ,
    output  logic                           o_l2b0_ramctrl_0_data_sram_write_wl            ,
    output  logic                           o_l2b0_ramctrl_1_reqarb_wl                     ,
    output  logic                           o_l2b0_ramctrl_1_reqarb_stall_by_sram          ,
    output  logic                           o_l2b0_ramctrl_1_data_sram_read_wl             ,
    output  logic                           o_l2b0_ramctrl_1_data_sram_write_wl            ,

    input   logic                           i_l2b1_busy                                    ,
    input   logic                           i_l2b1_fromaxi_ar_wl                           ,
    input   logic                           i_l2b1_fromaxi_ar_bl_eq0_wl                    ,
    input   logic                           i_l2b1_fromaxi_ar_bl_eq1_wl                    ,
    input   logic                           i_l2b1_fromaxi_ar_bl_eq2_wl                    ,
    input   logic                           i_l2b1_fromaxi_ar_bl_eq3_wl                    ,
    input   logic                           i_l2b1_fromaxi_ar_bp                           ,
    input   logic                           i_l2b1_toaxi_r_wl                              ,
    input   logic                           i_l2b1_toaxi_r_bp                              ,
    input   logic                           i_l2b1_fromaxi_aw_wl                           ,
    input   logic                           i_l2b1_fromaxi_aw_bl_eq0_wl                    ,
    input   logic                           i_l2b1_fromaxi_aw_bl_eq1_wl                    ,
    input   logic                           i_l2b1_fromaxi_aw_bl_eq2_wl                    ,
    input   logic                           i_l2b1_fromaxi_aw_bl_eq3_wl                    ,
    input   logic                           i_l2b1_fromaxi_aw_bp                           ,
    input   logic                           i_l2b1_fromaxi_w_wl                            ,
    input   logic                           i_l2b1_fromaxi_w_bp                            ,
    input   logic                           i_l2b1_fromaxi_smp_read_req_num                ,
    input   logic                           i_l2b1_fromaxi_smp_read_req_sum                ,
    input   logic                           i_l2b1_fromaxi_smp_write_req_num               ,
    input   logic                           i_l2b1_fromaxi_smp_write_req_sum               ,
    input   logic                           i_l2b1_fromaxi_smp_atomic_req_num              ,
    input   logic                           i_l2b1_fromaxi_smp_atomic_req_sum              ,
    input   logic                           i_l2b1_align_awdb_full                         ,
    input   logic                           i_l2b1_hittest_ht_bypass_read_wl               ,
    input   logic                           i_l2b1_hittest_ht_cache_read_wl                ,
    input   logic                           i_l2b1_hittest_ht_bypass_write_wl              ,
    input   logic                           i_l2b1_hittest_ht_cache_write_wl               ,
    input   logic                           i_l2b1_hittest_ht_atomic_wl                    ,
    input   logic                           i_l2b1_hittest_ht_bps_hit_wl                   ,
    input   logic                           i_l2b1_hittest_ht_miss_wl                      ,
    input   logic                           i_l2b1_frommemsch_nsp_rtn_wl                   ,
    input   logic                           i_l2b1_frommemsch_nsp_rtn_bp                   ,
    input   logic                           i_l2b1_tomemsch_nsp_read_bl_eq1_wl             ,
    input   logic                           i_l2b1_tomemsch_nsp_read_bl_eq3_wl             ,
    input   logic                           i_l2b1_tomemsch_nsp_read_bl_eq5_wl             ,
    input   logic                           i_l2b1_tomemsch_nsp_read_bl_eq7_wl             ,
    input   logic                           i_l2b1_tomemsch_nsp_write_bl_eq1_wl            ,
    input   logic                           i_l2b1_tomemsch_nsp_write_bl_eq3_wl            ,
    input   logic                           i_l2b1_tomemsch_nsp_write_bl_eq5_wl            ,
    input   logic                           i_l2b1_tomemsch_nsp_write_bl_eq7_wl            ,
    input   logic                           i_l2b1_memif_to_ddr_read_wl                    ,
    input   logic                           i_l2b1_memif_to_ddr_read_stall_by_rob          ,
    input   logic                           i_l2b1_memif_to_ddr_read_stall_by_ddr          ,
    input   logic                           i_l2b1_memif_to_ddr_read_stall_by_trid         ,
    input   logic                           i_l2b1_memif_to_ddr_write_wl                   ,
    input   logic                           i_l2b1_memif_to_ddr_write_stall_by_data_sync   ,
    input   logic                           i_l2b1_memif_to_ddr_write_stall_by_ddr         ,
    input   logic                           i_l2b1_memif_to_ddr_write_stall_by_trid        ,
    input   logic                           i_l2b1_memif_memreq_full                       ,
    input   logic                           i_l2b1_memif_smp_read_req_num                  ,
    input   logic                           i_l2b1_memif_smp_read_req_sum                  ,
    input   logic                           i_l2b1_reqsch_sortq_full                       ,
    input   logic                           i_l2b1_reqsch_sortq_stall_but_not_full         ,
    input   logic                           i_l2b1_reqsch_disp_wl                          ,
    input   logic                           i_l2b1_reqsch_disp_stall                       ,
    input   logic                           i_l2b1_ramctrl_0_reqarb_wl                     ,
    input   logic                           i_l2b1_ramctrl_0_reqarb_stall_by_sram          ,
    input   logic                           i_l2b1_ramctrl_0_data_sram_read_wl             ,
    input   logic                           i_l2b1_ramctrl_0_data_sram_write_wl            ,
    input   logic                           i_l2b1_ramctrl_1_reqarb_wl                     ,
    input   logic                           i_l2b1_ramctrl_1_reqarb_stall_by_sram          ,
    input   logic                           i_l2b1_ramctrl_1_data_sram_read_wl             ,
    input   logic                           i_l2b1_ramctrl_1_data_sram_write_wl            ,

    output  logic                           o_l2b1_busy                                    ,
    output  logic                           o_l2b1_fromaxi_ar_wl                           ,
    output  logic                           o_l2b1_fromaxi_ar_bl_eq0_wl                    ,
    output  logic                           o_l2b1_fromaxi_ar_bl_eq1_wl                    ,
    output  logic                           o_l2b1_fromaxi_ar_bl_eq2_wl                    ,
    output  logic                           o_l2b1_fromaxi_ar_bl_eq3_wl                    ,
    output  logic                           o_l2b1_fromaxi_ar_bp                           ,
    output  logic                           o_l2b1_toaxi_r_wl                              ,
    output  logic                           o_l2b1_toaxi_r_bp                              ,
    output  logic                           o_l2b1_fromaxi_aw_wl                           ,
    output  logic                           o_l2b1_fromaxi_aw_bl_eq0_wl                    ,
    output  logic                           o_l2b1_fromaxi_aw_bl_eq1_wl                    ,
    output  logic                           o_l2b1_fromaxi_aw_bl_eq2_wl                    ,
    output  logic                           o_l2b1_fromaxi_aw_bl_eq3_wl                    ,
    output  logic                           o_l2b1_fromaxi_aw_bp                           ,
    output  logic                           o_l2b1_fromaxi_w_wl                            ,
    output  logic                           o_l2b1_fromaxi_w_bp                            ,
    output  logic                           o_l2b1_fromaxi_smp_read_req_num                ,
    output  logic                           o_l2b1_fromaxi_smp_read_req_sum                ,
    output  logic                           o_l2b1_fromaxi_smp_write_req_num               ,
    output  logic                           o_l2b1_fromaxi_smp_write_req_sum               ,
    output  logic                           o_l2b1_fromaxi_smp_atomic_req_num              ,
    output  logic                           o_l2b1_fromaxi_smp_atomic_req_sum              ,
    output  logic                           o_l2b1_align_awdb_full                         ,
    output  logic                           o_l2b1_hittest_ht_bypass_read_wl               ,
    output  logic                           o_l2b1_hittest_ht_cache_read_wl                ,
    output  logic                           o_l2b1_hittest_ht_bypass_write_wl              ,
    output  logic                           o_l2b1_hittest_ht_cache_write_wl               ,
    output  logic                           o_l2b1_hittest_ht_atomic_wl                    ,
    output  logic                           o_l2b1_hittest_ht_bps_hit_wl                   ,
    output  logic                           o_l2b1_hittest_ht_miss_wl                      ,
    output  logic                           o_l2b1_frommemsch_nsp_rtn_wl                   ,
    output  logic                           o_l2b1_frommemsch_nsp_rtn_bp                   ,
    output  logic                           o_l2b1_tomemsch_nsp_read_bl_eq1_wl             ,
    output  logic                           o_l2b1_tomemsch_nsp_read_bl_eq3_wl             ,
    output  logic                           o_l2b1_tomemsch_nsp_read_bl_eq5_wl             ,
    output  logic                           o_l2b1_tomemsch_nsp_read_bl_eq7_wl             ,
    output  logic                           o_l2b1_tomemsch_nsp_write_bl_eq1_wl            ,
    output  logic                           o_l2b1_tomemsch_nsp_write_bl_eq3_wl            ,
    output  logic                           o_l2b1_tomemsch_nsp_write_bl_eq5_wl            ,
    output  logic                           o_l2b1_tomemsch_nsp_write_bl_eq7_wl            ,
    output  logic                           o_l2b1_memif_to_ddr_read_wl                    ,
    output  logic                           o_l2b1_memif_to_ddr_read_stall_by_rob          ,
    output  logic                           o_l2b1_memif_to_ddr_read_stall_by_ddr          ,
    output  logic                           o_l2b1_memif_to_ddr_read_stall_by_trid         ,
    output  logic                           o_l2b1_memif_to_ddr_write_wl                   ,
    output  logic                           o_l2b1_memif_to_ddr_write_stall_by_data_sync   ,
    output  logic                           o_l2b1_memif_to_ddr_write_stall_by_ddr         ,
    output  logic                           o_l2b1_memif_to_ddr_write_stall_by_trid        ,
    output  logic                           o_l2b1_memif_memreq_full                       ,
    output  logic                           o_l2b1_memif_smp_read_req_num                  ,
    output  logic                           o_l2b1_memif_smp_read_req_sum                  ,
    output  logic                           o_l2b1_reqsch_sortq_full                       ,
    output  logic                           o_l2b1_reqsch_sortq_stall_but_not_full         ,
    output  logic                           o_l2b1_reqsch_disp_wl                          ,
    output  logic                           o_l2b1_reqsch_disp_stall                       ,
    output  logic                           o_l2b1_ramctrl_0_reqarb_wl                     ,
    output  logic                           o_l2b1_ramctrl_0_reqarb_stall_by_sram          ,
    output  logic                           o_l2b1_ramctrl_0_data_sram_read_wl             ,
    output  logic                           o_l2b1_ramctrl_0_data_sram_write_wl            ,
    output  logic                           o_l2b1_ramctrl_1_reqarb_wl                     ,
    output  logic                           o_l2b1_ramctrl_1_reqarb_stall_by_sram          ,
    output  logic                           o_l2b1_ramctrl_1_data_sram_read_wl             ,
    output  logic                           o_l2b1_ramctrl_1_data_sram_write_wl            ,

    input   logic                           clk,
    input   logic                           resetn
);



// ----------------------------------------------------------------------------------------------
//  AXI interface pipeline
// ----------------------------------------------------------------------------------------------
gpc_gfx_timing_buffer_pipe_ #(
    .BUFFER_TYPE    (L2_BANK_INT_AXI_PIPE_TYPE          ),
    .PIPE_STAGES    (L2_BANK_WRAP_AXI_PIPE_STAGES[BANK_WRAP] ),
    .WIDTH          (AXI5_AR_DATA_BUS_BITS              )
) i_tb_l2_bank_wrap_axi_slv_0_ar (
    .clk                (clk                            ),  // I
    .resetn             (resetn                         ),  // I
    .tbuff_in_valid     (i_axi_slv_0_arvalid            ),  // I
    .tbuff_in_enable    (i_axi_slv_0_arready            ),  // O
    .tbuff_in_data      (i_axi_slv_0_ar_rec             ),  // I
    .tbuff_out_valid    (o_axi_slv_0_arvalid            ),  // O
    .tbuff_out_enable   (o_axi_slv_0_arready            ),  // I
    .tbuff_out_data     (o_axi_slv_0_ar_rec             )   // O
);


gpc_gfx_timing_buffer_pipe_ #(
    .BUFFER_TYPE    (L2_BANK_INT_AXI_PIPE_TYPE          ),
    .PIPE_STAGES    (L2_BANK_WRAP_AXI_PIPE_STAGES[BANK_WRAP]        ),
    .WIDTH          (AXI5_R_DATA_BUS_BITS               )
) i_tb_l2_bank_wrap_axi_slv_0_r (
    .clk                (clk                            ),  // I
    .resetn             (resetn                         ),  // I
    .tbuff_in_valid     (o_axi_slv_0_rvalid             ),  // I
    .tbuff_in_enable    (o_axi_slv_0_rready             ),  // O
    .tbuff_in_data      (o_axi_slv_0_r_rec              ),  // I
    .tbuff_out_valid    (i_axi_slv_0_rvalid             ),  // O
    .tbuff_out_enable   (i_axi_slv_0_rready             ),  // I
    .tbuff_out_data     (i_axi_slv_0_r_rec              )   // O
);


gpc_gfx_timing_buffer_pipe_ #(
    .BUFFER_TYPE    (L2_BANK_INT_AXI_PIPE_TYPE          ),
    .PIPE_STAGES    (L2_BANK_WRAP_AXI_PIPE_STAGES[BANK_WRAP]      ),
    .WIDTH          (AXI5_AW_DATA_BUS_BITS              )
) i_tb_l2_bank_wrap_axi_slv_0_aw (
    .clk                (clk                            ),  // I
    .resetn             (resetn                         ),  // I
    .tbuff_in_valid     (i_axi_slv_0_awvalid            ),  // I
    .tbuff_in_enable    (i_axi_slv_0_awready            ),  // O
    .tbuff_in_data      (i_axi_slv_0_aw_rec             ),  // I
    .tbuff_out_valid    (o_axi_slv_0_awvalid            ),  // O
    .tbuff_out_enable   (o_axi_slv_0_awready            ),  // I
    .tbuff_out_data     (o_axi_slv_0_aw_rec             )   // O
);


gpc_gfx_timing_buffer_pipe_ #(
    .BUFFER_TYPE    (L2_BANK_INT_AXI_PIPE_TYPE          ),
    .PIPE_STAGES    (L2_BANK_WRAP_AXI_PIPE_STAGES[BANK_WRAP]        ),
    .WIDTH          (AXI5_W_DATA_BUS_BITS               )
) i_tb_l2_bank_wrap_axi_slv_0_w (
    .clk                (clk                            ),  // I
    .resetn             (resetn                         ),  // I
    .tbuff_in_valid     (i_axi_slv_0_wvalid             ),  // I
    .tbuff_in_enable    (i_axi_slv_0_wready             ),  // O
    .tbuff_in_data      (i_axi_slv_0_w_rec              ),  // I
    .tbuff_out_valid    (o_axi_slv_0_wvalid             ),  // O
    .tbuff_out_enable   (o_axi_slv_0_wready             ),  // I
    .tbuff_out_data     (o_axi_slv_0_w_rec              )   // O
);


gpc_gfx_timing_buffer_pipe_ #(
    .BUFFER_TYPE    (L2_BANK_INT_AXI_PIPE_TYPE                  ),
    .PIPE_STAGES    (L2_BANK_WRAP_AXI_PIPE_STAGES[BANK_WRAP]                                         ),
    .WIDTH          (AXI5_B_DATA_BUS_BITS                       )
) i_tb_l2_bank_wrap_axi_slv_0_b (
    .clk                (clk                                    ),  // I
    .resetn             (resetn                                 ),  // I
    .tbuff_in_valid     (o_axi_slv_0_bvalid                     ),  // I
    .tbuff_in_enable    (o_axi_slv_0_bready                     ),  // O
    .tbuff_in_data      (o_axi_slv_0_b_rec                      ),  // I
    .tbuff_out_valid    (i_axi_slv_0_bvalid                     ),  // O
    .tbuff_out_enable   (i_axi_slv_0_bready                     ),  // I
    .tbuff_out_data     (i_axi_slv_0_b_rec                      )   // O
);

gpc_gfx_timing_buffer_pipe_ #(
    .BUFFER_TYPE    (L2_BANK_INT_AXI_PIPE_TYPE          ),
    .PIPE_STAGES    (L2_BANK_WRAP_AXI_PIPE_STAGES[BANK_WRAP]        ),
    .WIDTH          (AXI5_AR_DATA_BUS_BITS              )
) i_tb_l2_bank_wrap_axi_slv_1_ar (
    .clk                (clk                            ),  // I
    .resetn             (resetn                         ),  // I
    .tbuff_in_valid     (i_axi_slv_1_arvalid            ),  // I
    .tbuff_in_enable    (i_axi_slv_1_arready            ),  // O
    .tbuff_in_data      (i_axi_slv_1_ar_rec             ),  // I
    .tbuff_out_valid    (o_axi_slv_1_arvalid            ),  // O
    .tbuff_out_enable   (o_axi_slv_1_arready            ),  // I
    .tbuff_out_data     (o_axi_slv_1_ar_rec             )   // O
);


gpc_gfx_timing_buffer_pipe_ #(
    .BUFFER_TYPE    (L2_BANK_INT_AXI_PIPE_TYPE          ),
    .PIPE_STAGES    (L2_BANK_WRAP_AXI_PIPE_STAGES[BANK_WRAP]),
    .WIDTH          (AXI5_R_DATA_BUS_BITS               )
) i_tb_l2_bank_wrap_axi_slv_1_r (
    .clk                (clk                            ),  // I
    .resetn             (resetn                         ),  // I
    .tbuff_in_valid     (o_axi_slv_1_rvalid             ),  // I
    .tbuff_in_enable    (o_axi_slv_1_rready             ),  // O
    .tbuff_in_data      (o_axi_slv_1_r_rec              ),  // I
    .tbuff_out_valid    (i_axi_slv_1_rvalid             ),  // O
    .tbuff_out_enable   (i_axi_slv_1_rready             ),  // I
    .tbuff_out_data     (i_axi_slv_1_r_rec              )   // O
);


gpc_gfx_timing_buffer_pipe_ #(
    .BUFFER_TYPE    (L2_BANK_INT_AXI_PIPE_TYPE          ),
    .PIPE_STAGES    (L2_BANK_WRAP_AXI_PIPE_STAGES[BANK_WRAP]        ),
    .WIDTH          (AXI5_AW_DATA_BUS_BITS              )
) i_tb_l2_bank_wrap_axi_slv_1_aw (
    .clk                (clk                            ),  // I
    .resetn             (resetn                         ),  // I
    .tbuff_in_valid     (i_axi_slv_1_awvalid            ),  // I
    .tbuff_in_enable    (i_axi_slv_1_awready            ),  // O
    .tbuff_in_data      (i_axi_slv_1_aw_rec             ),  // I
    .tbuff_out_valid    (o_axi_slv_1_awvalid            ),  // O
    .tbuff_out_enable   (o_axi_slv_1_awready            ),  // I
    .tbuff_out_data     (o_axi_slv_1_aw_rec             )   // O
);


gpc_gfx_timing_buffer_pipe_ #(
    .BUFFER_TYPE    (L2_BANK_INT_AXI_PIPE_TYPE          ),
    .PIPE_STAGES    (L2_BANK_WRAP_AXI_PIPE_STAGES[BANK_WRAP]        ),
    .WIDTH          (AXI5_W_DATA_BUS_BITS               )
) i_tb_l2_bank_wrap_axi_slv_1_w (
    .clk                (clk                            ),  // I
    .resetn             (resetn                         ),  // I
    .tbuff_in_valid     (i_axi_slv_1_wvalid             ),  // I
    .tbuff_in_enable    (i_axi_slv_1_wready             ),  // O
    .tbuff_in_data      (i_axi_slv_1_w_rec              ),  // I
    .tbuff_out_valid    (o_axi_slv_1_wvalid             ),  // O
    .tbuff_out_enable   (o_axi_slv_1_wready             ),  // I
    .tbuff_out_data     (o_axi_slv_1_w_rec              )   // O
);


gpc_gfx_timing_buffer_pipe_ #(
    .BUFFER_TYPE    (L2_BANK_INT_AXI_PIPE_TYPE                  ),
    .PIPE_STAGES    (L2_BANK_WRAP_AXI_PIPE_STAGES[BANK_WRAP]                ),
    .WIDTH          (AXI5_B_DATA_BUS_BITS                       )
) i_tb_l2_bank_wrap_axi_slv_1_b (
    .clk                (clk                                    ),  // I
    .resetn             (resetn                                 ),  // I
    .tbuff_in_valid     (o_axi_slv_1_bvalid                     ),  // I
    .tbuff_in_enable    (o_axi_slv_1_bready                     ),  // O
    .tbuff_in_data      (o_axi_slv_1_b_rec                      ),  // I
    .tbuff_out_valid    (i_axi_slv_1_bvalid                     ),  // O
    .tbuff_out_enable   (i_axi_slv_1_bready                     ),  // I
    .tbuff_out_data     (i_axi_slv_1_b_rec                      )   // O
);

// ----------------------------------------------------------------------------------------------
//  NSP interface pipeline
// ----------------------------------------------------------------------------------------------
generate
for(genvar NSP=0; NSP<L2_XBAR_NUM_BANK; NSP++) begin
gpc_gfx_timing_buffer_pipe_ #(
    .BUFFER_TYPE    (L2_BANK_INT_NSP_PIPE_TYPE          ),
    .PIPE_STAGES    (L2_BANK_WRAP_NSP_PIPE_STAGES[BANK_WRAP]        ),
    .WIDTH          ($size(group_nsp_req_data_bus_t)    )
) i_tb_l2_bank_wrap_nsp_req (
    .clk                (clk                            ),  // I
    .resetn             (resetn                         ),  // I
    .tbuff_in_valid     (i_nsp_req_valid[NSP]           ),  // I
    .tbuff_in_enable    (i_nsp_req_ready[NSP]           ),  // O
    .tbuff_in_data      (i_nsp_req_rec  [NSP]           ),  // I
    .tbuff_out_valid    (o_nsp_req_valid[NSP]           ),  // O
    .tbuff_out_enable   (o_nsp_req_ready[NSP]           ),  // I
    .tbuff_out_data     (o_nsp_req_rec  [NSP]           )   // O
);

gpc_gfx_timing_buffer_pipe_ #(
    .BUFFER_TYPE    (L2_BANK_INT_NSP_PIPE_TYPE),
    .PIPE_STAGES    (L2_BANK_WRAP_NSP_PIPE_STAGES[BANK_WRAP]        ),
    .WIDTH          ($size(group_nsp_rsp_data_bus_t)    )
) i_tb_l2_bank_wrap_nsp_rsp (
    .clk                (clk                            ),  // I
    .resetn             (resetn                         ),  // I
    .tbuff_in_valid     (o_nsp_rsp_valid[NSP]           ),  // I
    .tbuff_in_enable    (o_nsp_rsp_ready[NSP]           ),  // O
    .tbuff_in_data      (o_nsp_rsp_rec  [NSP]           ),  // I
    .tbuff_out_valid    (i_nsp_rsp_valid[NSP]           ),  // O
    .tbuff_out_enable   (i_nsp_rsp_ready[NSP]           ),  // I
    .tbuff_out_data     (i_nsp_rsp_rec  [NSP]           )   // O
);
end
endgenerate

// ----------------------------------------------------------------------------------------------
//  l2_bank <--> sched_xbar/nsp_xbar interactive interface
// ----------------------------------------------------------------------------------------------
// gpc_gfx_timing_buffer_pipe_ #(
//     .BUFFER_TYPE    (L2_BANK_SCHED_PIPE_TYPE                    ),
//     .PIPE_STAGES    (L2_BANK_SCHED_PIPE_STAGES                  ),
//     .WIDTH          ($size(i_bank0_memif_sched_rec)             )
// ) i_tb_l2_bank0_memif_sched_req (
//     .clk                (clk                                    ),  // I
//     .resetn             (resetn                                 ),  // I
//     .tbuff_in_valid     (i_bank0_memif_sched_valid              ),  // I
//     .tbuff_in_enable    (i_bank0_memif_sched_ready              ),  // O
//     .tbuff_in_data      (i_bank0_memif_sched_rec                ),  // I
//     .tbuff_out_valid    (o_bank0_memif_sched_valid              ),  // O
//     .tbuff_out_enable   (o_bank0_memif_sched_ready              ),  // I
//     .tbuff_out_data     (o_bank0_memif_sched_rec                )   // O
// );
// 
// 
// gpc_gfx_timing_buffer_pipe_ #(
//     .BUFFER_TYPE    (L2_BANK_SCHED_PIPE_TYPE                    ),
//     .PIPE_STAGES    (L2_BANK_SCHED_PIPE_STAGES                  ),
//     .WIDTH          ($size(i_bank0_sched_memif_rec)             )
// ) i_tb_l2_bank0_sched_memif_rsp (
//     .clk                (clk                                    ),  // I
//     .resetn             (resetn                                 ),  // I
//     .tbuff_in_valid     (o_bank0_sched_memif_valid              ),  // I
//     .tbuff_in_enable    (o_bank0_sched_memif_ready              ),  // O
//     .tbuff_in_data      (o_bank0_sched_memif_rec                ),  // I
//     .tbuff_out_valid    (i_bank0_sched_memif_valid              ),  // O
//     .tbuff_out_enable   (i_bank0_sched_memif_ready              ),  // I
//     .tbuff_out_data     (i_bank0_sched_memif_rec                )   // O
// );


//gpc_gfx_timing_buffer_pipe_ #(
//    .BUFFER_TYPE    (L2_BANK_SCHED_PIPE_TYPE                    ),
//    .PIPE_STAGES    (L2_BANK_SCHED_PIPE_STAGES                  ),
//    .WIDTH          ($size(i_bank0_nsp_req_rec)                 )
//) i_tb_l2_bank0_memif_sched_nsp_req (
//    .clk                (clk                                    ),  // I
//    .resetn             (resetn                                 ),  // I
//    .tbuff_in_valid     (i_bank0_nsp_req_valid                  ),  // I
//    .tbuff_in_enable    (i_bank0_nsp_req_ready                  ),  // O
//    .tbuff_in_data      (i_bank0_nsp_req_rec                    ),  // I
//    .tbuff_out_valid    (o_bank0_nsp_req_valid                  ),  // O
//    .tbuff_out_enable   (o_bank0_nsp_req_ready                  ),  // I
//    .tbuff_out_data     (o_bank0_nsp_req_rec                    )   // O
//);
//
//
//gpc_gfx_timing_buffer_pipe_ #(
//    .BUFFER_TYPE    (L2_BANK_SCHED_PIPE_TYPE                    ),
//    .PIPE_STAGES    (L2_BANK_SCHED_PIPE_STAGES                  ),
//    .WIDTH          ($size(o_bank0_nsp_rsp_rec)                 )
//) i_tb_l2_bank0_memif_sched_nsp_rsp (
//    .clk                (clk                                    ),  // I
//    .resetn             (resetn                                 ),  // I
//    .tbuff_in_valid     (o_bank0_nsp_rsp_valid                  ),  // I
//    .tbuff_in_enable    (o_bank0_nsp_rsp_ready                  ),  // O
//    .tbuff_in_data      (o_bank0_nsp_rsp_rec                    ),  // I
//    .tbuff_out_valid    (i_bank0_nsp_rsp_valid                  ),  // O
//    .tbuff_out_enable   (i_bank0_nsp_rsp_ready                  ),  // I
//    .tbuff_out_data     (i_bank0_nsp_rsp_rec                    )   // O
//);


// gpc_gfx_timing_buffer_pipe_ #(
//     .BUFFER_TYPE    (L2_BANK_SCHED_PIPE_TYPE                    ),
//     .PIPE_STAGES    (L2_BANK_SCHED_PIPE_STAGES                  ),
//     .WIDTH          ($size(i_bank1_memif_sched_rec)             )
// ) i_tb_l2_bank1_memif_sched_req (
//     .clk                (clk                                    ),  // I
//     .resetn             (resetn                                 ),  // I
//     .tbuff_in_valid     (i_bank1_memif_sched_valid              ),  // I
//     .tbuff_in_enable    (i_bank1_memif_sched_ready              ),  // O
//     .tbuff_in_data      (i_bank1_memif_sched_rec                ),  // I
//     .tbuff_out_valid    (o_bank1_memif_sched_valid              ),  // O
//     .tbuff_out_enable   (o_bank1_memif_sched_ready              ),  // I
//     .tbuff_out_data     (o_bank1_memif_sched_rec                )   // O
// );
// 
// 
// gpc_gfx_timing_buffer_pipe_ #(
//     .BUFFER_TYPE    (L2_BANK_SCHED_PIPE_TYPE                    ),
//     .PIPE_STAGES    (L2_BANK_SCHED_PIPE_STAGES                  ),
//     .WIDTH          ($size(i_bank1_sched_memif_rec)             )
// ) i_tb_l2_bank1_sched_memif_rsp (
//     .clk                (clk                                    ),  // I
//     .resetn             (resetn                                 ),  // I
//     .tbuff_in_valid     (o_bank1_sched_memif_valid              ),  // I
//     .tbuff_in_enable    (o_bank1_sched_memif_ready              ),  // O
//     .tbuff_in_data      (o_bank1_sched_memif_rec                ),  // I
//     .tbuff_out_valid    (i_bank1_sched_memif_valid              ),  // O
//     .tbuff_out_enable   (i_bank1_sched_memif_ready              ),  // I
//     .tbuff_out_data     (i_bank1_sched_memif_rec                )   // O
// );


//gpc_gfx_timing_buffer_pipe_ #(
//    .BUFFER_TYPE    (L2_BANK_SCHED_PIPE_TYPE                    ),
//    .PIPE_STAGES    (L2_BANK_SCHED_PIPE_STAGES                  ),
//    .WIDTH          ($size(i_bank1_nsp_req_rec)                 )
//) i_tb_l2_bank1_memif_sched_nsp_req (
//    .clk                (clk                                    ),  // I
//    .resetn             (resetn                                 ),  // I
//    .tbuff_in_valid     (i_bank1_nsp_req_valid                  ),  // I
//    .tbuff_in_enable    (i_bank1_nsp_req_ready                  ),  // O
//    .tbuff_in_data      (i_bank1_nsp_req_rec                    ),  // I
//    .tbuff_out_valid    (o_bank1_nsp_req_valid                  ),  // O
//    .tbuff_out_enable   (o_bank1_nsp_req_ready                  ),  // I
//    .tbuff_out_data     (o_bank1_nsp_req_rec                    )   // O
//);


//gpc_gfx_timing_buffer_pipe_ #(
//    .BUFFER_TYPE    (L2_BANK_SCHED_PIPE_TYPE                    ),
//    .PIPE_STAGES    (L2_BANK_SCHED_PIPE_STAGES                  ),
//    .WIDTH          ($size(o_bank1_nsp_rsp_rec)                 )
//) i_tb_l2_bank1_memif_sched_nsp_rsp (
//    .clk                (clk                                    ),  // I
//    .resetn             (resetn                                 ),  // I
//    .tbuff_in_valid     (o_bank1_nsp_rsp_valid                  ),  // I
//    .tbuff_in_enable    (o_bank1_nsp_rsp_ready                  ),  // O
//    .tbuff_in_data      (o_bank1_nsp_rsp_rec                    ),  // I
//    .tbuff_out_valid    (i_bank1_nsp_rsp_valid                  ),  // O
//    .tbuff_out_enable   (i_bank1_nsp_rsp_ready                  ),  // I
//    .tbuff_out_data     (i_bank1_nsp_rsp_rec                    )   // O
//);


// ----------------------------------------------------------------------------------------------
//  configure register pipeline
// ----------------------------------------------------------------------------------------------
gpc_gfx_timing_buffer_no_handshake_pipe_ #(
    .WIDTH          (8                                      ),
    .PIPE_STAGES    (L2_BANK_INT_REG_PIPE_STAGES+2          ),
    .INI_DAT        (8'b0                                   )
) i_tb_l2_bank_cr_dynamic (
    .clk            (clk                                    ),
    .resetn         (resetn                                 ),
    .tbuff_in_data  ({  i_gc_cr_l2_cfi_operation           ,
                        i_gc_cr_l2_cmd_persistence_rst_all ,
                        i_gc_cr_l2_cmd_cfi_clr             ,
                        i_gc_cr_l2_cfi_operation_notify    ,
                        i_gc_cr_l2_cfi_operation_rdnotify  ,
                        i_gc_cr_l2_cmd_notify              ,
                        i_gc_cr_l2_cmd_rdnotify            }),
    .tbuff_out_data ({  o_gc_cr_l2_cfi_operation           ,
                        o_gc_cr_l2_cmd_persistence_rst_all ,
                        o_gc_cr_l2_cmd_cfi_clr             ,
                        o_gc_cr_l2_cfi_operation_notify    ,
                        o_gc_cr_l2_cfi_operation_rdnotify  ,
                        o_gc_cr_l2_cmd_notify              ,
                        o_gc_cr_l2_cmd_rdnotify            })
);


gpc_gfx_timing_buffer_no_handshake_pipe_ #(
    .WIDTH          (185                                ),
    .PIPE_STAGES    (L2_BANK_INT_REG_PIPE_STAGES        ),
    .INI_DAT        (185'b0                             )
) i_tb_l2_bank_cr_static_i (
    .clk            (clk                                ),
    .resetn         (resetn                             ),
    .tbuff_in_data  ({  i_gc_cr_l2_mem_sched_row_partii_row_id_bit8,
                        i_gc_cr_l2_mem_sched_row_partii_row_id_bit9,
                        i_gc_cr_l2_mem_sched_row_partii_row_id_bit10,
                        i_gc_cr_l2_mem_sched_row_partii_row_id_bit11,
                        i_gc_cr_l2_mem_sched_row_partii_row_id_bit12,
                        i_gc_cr_l2_mem_sched_row_partii_row_id_bit13,
                        i_gc_cr_l2_mem_sched_row_partii_row_id_bit14,
                        i_gc_cr_l2_mem_sched_row_partii_row_id_bit15,
                        i_gc_cr_l2_mem_sched_row_partiii_row_id_bit16,
                        i_gc_cr_l2_mem_sched_row_partiii_row_id_bit17,
                        i_gc_cr_l2_function_enable_ddr_capacity,
                        i_gc_cr_clk_ctrl3_l2g,
                        i_gc_cr_l2_buffer_mode_buffer_mode_percentage,
                        i_gc_cr_l2_persistence_reduce_enable,
                        i_gc_cr_l2_persistence_reduce_threshold,
                        i_gc_cr_l2_function_enable_mem_scheduler,
                        i_gc_cr_l2_function_enable_bypass_mode,
                        i_gc_cr_l2_mem_sched_col_offset_column_id_bit0,
                        i_gc_cr_l2_mem_sched_col_offset_column_id_bit1,
                        i_gc_cr_l2_mem_sched_col_offset_column_id_bit2,
                        i_gc_cr_l2_mem_sched_col_offset_column_id_bit3,
                        i_gc_cr_l2_mem_sched_col_offset_column_id_bit4,
                        i_gc_cr_l2_mem_sched_col_offset_column_id_bit5,
                        i_gc_cr_l2_mem_sched_bank_offset_bank_id_bit0,
                        i_gc_cr_l2_mem_sched_bank_offset_bank_id_bit1,
                        i_gc_cr_l2_mem_sched_bank_offset_bank_id_bit2,
                        i_gc_cr_l2_mem_sched_bank_offset_bank_id_bit3,
                        i_gc_cr_l2_mem_sched_bank_offset_bank_id_bit4,
                        i_gc_cr_l2_mem_sched_row_parti_row_id_bit0,
                        i_gc_cr_l2_mem_sched_row_parti_row_id_bit1,
                        i_gc_cr_l2_mem_sched_row_parti_row_id_bit2,
                        i_gc_cr_l2_mem_sched_row_parti_row_id_bit3,
                        i_gc_cr_l2_mem_sched_row_parti_row_id_bit4,
                        i_gc_cr_l2_mem_sched_row_parti_row_id_bit5,
                        i_gc_cr_l2_mem_sched_row_parti_row_id_bit6,
                        i_gc_cr_l2_mem_sched_row_parti_row_id_bit7,
                        i_gc_cr_pwr_man_hysteresis_value,
                        i_gc_cr_cu_lms_fp32_denormal_en,
                        i_gc_cr_crm_reset_clk_ctrl                      }),
    .tbuff_out_data ({  o_gc_cr_l2_mem_sched_row_partii_row_id_bit8,
                        o_gc_cr_l2_mem_sched_row_partii_row_id_bit9,
                        o_gc_cr_l2_mem_sched_row_partii_row_id_bit10,
                        o_gc_cr_l2_mem_sched_row_partii_row_id_bit11,
                        o_gc_cr_l2_mem_sched_row_partii_row_id_bit12,
                        o_gc_cr_l2_mem_sched_row_partii_row_id_bit13,
                        o_gc_cr_l2_mem_sched_row_partii_row_id_bit14,
                        o_gc_cr_l2_mem_sched_row_partii_row_id_bit15,
                        o_gc_cr_l2_mem_sched_row_partiii_row_id_bit16,
                        o_gc_cr_l2_mem_sched_row_partiii_row_id_bit17,
                        o_gc_cr_l2_function_enable_ddr_capacity,
                        o_gc_cr_clk_ctrl3_l2g,
                        o_gc_cr_l2_buffer_mode_buffer_mode_percentage,
                        o_gc_cr_l2_persistence_reduce_enable,
                        o_gc_cr_l2_persistence_reduce_threshold,
                        o_gc_cr_l2_function_enable_mem_scheduler,
                        o_gc_cr_l2_function_enable_bypass_mode,
                        o_gc_cr_l2_mem_sched_col_offset_column_id_bit0,
                        o_gc_cr_l2_mem_sched_col_offset_column_id_bit1,
                        o_gc_cr_l2_mem_sched_col_offset_column_id_bit2,
                        o_gc_cr_l2_mem_sched_col_offset_column_id_bit3,
                        o_gc_cr_l2_mem_sched_col_offset_column_id_bit4,
                        o_gc_cr_l2_mem_sched_col_offset_column_id_bit5,
                        o_gc_cr_l2_mem_sched_bank_offset_bank_id_bit0,
                        o_gc_cr_l2_mem_sched_bank_offset_bank_id_bit1,
                        o_gc_cr_l2_mem_sched_bank_offset_bank_id_bit2,
                        o_gc_cr_l2_mem_sched_bank_offset_bank_id_bit3,
                        o_gc_cr_l2_mem_sched_bank_offset_bank_id_bit4,
                        o_gc_cr_l2_mem_sched_row_parti_row_id_bit0,
                        o_gc_cr_l2_mem_sched_row_parti_row_id_bit1,
                        o_gc_cr_l2_mem_sched_row_parti_row_id_bit2,
                        o_gc_cr_l2_mem_sched_row_parti_row_id_bit3,
                        o_gc_cr_l2_mem_sched_row_parti_row_id_bit4,
                        o_gc_cr_l2_mem_sched_row_parti_row_id_bit5,
                        o_gc_cr_l2_mem_sched_row_parti_row_id_bit6,
                        o_gc_cr_l2_mem_sched_row_parti_row_id_bit7,
                        o_gc_cr_pwr_man_hysteresis_value,
                        o_gc_cr_cu_lms_fp32_denormal_en,
                        o_gc_cr_crm_reset_clk_ctrl                      })
);

gpc_gfx_timing_buffer_no_handshake_pipe_ # (
    .WIDTH                                 ( 96     ) ,
    .PIPE_STAGES                           ( L2_BANK_INT_REG_PIPE_STAGES      ) ,
    .INI_DAT                               ( 'h9999_9999_9999_9999_9999_9999     ) )
i_gc_config_reg                            (
    .clk                                   ( clk    ) ,
    .resetn                                ( resetn ) ,
    .tbuff_in_data                         ( {i_gc_cr_ddr_hash_config_reg0_row_id_bit0,
                                              i_gc_cr_ddr_hash_config_reg0_row_id_bit1,
                                              i_gc_cr_ddr_hash_config_reg0_row_id_bit2,
                                              i_gc_cr_ddr_hash_config_reg0_row_id_bit3,
                                              i_gc_cr_ddr_hash_config_reg0_row_id_bit4,
                                              i_gc_cr_ddr_hash_config_reg0_row_id_bit5,
                                              i_gc_cr_ddr_hash_config_reg0_row_id_bit6 ,
                                              i_gc_cr_ddr_hash_config_reg0_row_id_bit7 ,
                                              i_gc_cr_ddr_hash_config_reg0_row_id_bit8 ,
                                              i_gc_cr_ddr_hash_config_reg0_row_id_bit9 ,
                                              i_gc_cr_ddr_hash_config_reg0_row_id_bit10,
                                              i_gc_cr_ddr_hash_config_reg0_row_id_bit11,
                                              i_gc_cr_ddr_hash_config_reg1_row_id_bit12,
                                              i_gc_cr_ddr_hash_config_reg1_row_id_bit13,
                                              i_gc_cr_ddr_hash_config_reg1_row_id_bit14,
                                              i_gc_cr_ddr_hash_config_reg1_row_id_bit15,
                                              i_gc_cr_ddr_hash_config_reg1_row_id_bit16,
                                              i_gc_cr_ddr_hash_config_reg1_row_id_bit17,
                                              i_gc_cr_ddr_hash_config_reg1_row_id_bit18,
                                              i_gc_cr_ddr_hash_config_reg1_row_id_bit19,
                                              i_gc_cr_ddr_hash_config_reg1_row_id_bit20,
                                              i_gc_cr_ddr_hash_config_reg1_row_id_bit21,
                                              i_gc_cr_ddr_hash_config_reg1_row_id_bit22,
                                              i_gc_cr_ddr_hash_config_reg1_row_id_bit23
                                             }      ) ,
    .tbuff_out_data                        ( {o_gc_cr_ddr_hash_config_reg0_row_id_bit0,
                                              o_gc_cr_ddr_hash_config_reg0_row_id_bit1,
                                              o_gc_cr_ddr_hash_config_reg0_row_id_bit2,
                                              o_gc_cr_ddr_hash_config_reg0_row_id_bit3,
                                              o_gc_cr_ddr_hash_config_reg0_row_id_bit4,
                                              o_gc_cr_ddr_hash_config_reg0_row_id_bit5,
                                              o_gc_cr_ddr_hash_config_reg0_row_id_bit6 ,
                                              o_gc_cr_ddr_hash_config_reg0_row_id_bit7 ,
                                              o_gc_cr_ddr_hash_config_reg0_row_id_bit8 ,
                                              o_gc_cr_ddr_hash_config_reg0_row_id_bit9 ,
                                              o_gc_cr_ddr_hash_config_reg0_row_id_bit10,
                                              o_gc_cr_ddr_hash_config_reg0_row_id_bit11,
                                              o_gc_cr_ddr_hash_config_reg1_row_id_bit12,
                                              o_gc_cr_ddr_hash_config_reg1_row_id_bit13,
                                              o_gc_cr_ddr_hash_config_reg1_row_id_bit14,
                                              o_gc_cr_ddr_hash_config_reg1_row_id_bit15,
                                              o_gc_cr_ddr_hash_config_reg1_row_id_bit16,
                                              o_gc_cr_ddr_hash_config_reg1_row_id_bit17,
                                              o_gc_cr_ddr_hash_config_reg1_row_id_bit18,
                                              o_gc_cr_ddr_hash_config_reg1_row_id_bit19,
                                              o_gc_cr_ddr_hash_config_reg1_row_id_bit20,
                                              o_gc_cr_ddr_hash_config_reg1_row_id_bit21,
                                              o_gc_cr_ddr_hash_config_reg1_row_id_bit22,
                                              o_gc_cr_ddr_hash_config_reg1_row_id_bit23
                                             }      ) );
gpc_gfx_timing_buffer_no_handshake_pipe_ 
                            #(
    .WIDTH                   ( 2                                    ) ,
    .PIPE_STAGES             ( L2_BANK_INT_REG_PIPE_STAGES          ) ,
    .INI_DAT                 ( 2'd0                                 ) )
i_gc_l2_bank_function_enable (
    .clk                     ( clk                                  ) ,
    .resetn                  ( resetn                               ) ,
    .tbuff_in_data           ( i_gc_cr_l2_function_enable_hash_mode ) ,
    .tbuff_out_data          ( o_gc_cr_l2_function_enable_hash_mode ) );

// for default value 0 
gpc_gfx_timing_buffer_no_handshake_pipe_ #(
    .WIDTH          (8                                      ),
    .PIPE_STAGES    (L2_BANK_INT_REG_PIPE_STAGES            ),
    .INI_DAT        (8'h00                                  )
) i_tb_l2_bank_cr_static_o_0 (
    .clk            (clk                                    ),
    .resetn         (resetn                                 ),
    .tbuff_in_data  ({  
                        o_gc_cr_l2g_idle_l2g                ,
                        o_gc_cr_l2g_error0_l2b0             ,
                        o_gc_cr_l2g_error0_l2b1             }),
    .tbuff_out_data ({  
                        i_gc_cr_l2g_idle_l2g                ,
                        i_gc_cr_l2g_error0_l2b0             ,
                        i_gc_cr_l2g_error0_l2b1             })
);

// for default value 1 
gpc_gfx_timing_buffer_no_handshake_pipe_ #(
    .WIDTH          (3                                      ),
    .PIPE_STAGES    (L2_BANK_INT_REG_PIPE_STAGES            ),
    .INI_DAT        (3'h7                                   )
) i_tb_l2_bank_cr_static_o_1 (
    .clk            (clk                                    ),
    .resetn         (resetn                                 ),
    .tbuff_in_data  ({  
                        o_gc_cr_clk_status3_l2g             ,
                        o_gc_cr_l2_cfi_statusi_l2b0_finish  ,
                        o_gc_cr_l2_cfi_statusi_l2b1_finish  
                                                            }),
    .tbuff_out_data ({  
                        i_gc_cr_clk_status3_l2g             ,
                        i_gc_cr_l2_cfi_statusi_l2b0_finish  ,
                        i_gc_cr_l2_cfi_statusi_l2b1_finish  
                                                            })
);


gpc_gfx_timing_buffer_no_handshake_pipe_ #(
    .WIDTH          (128                                    ),
    .PIPE_STAGES    (L2_BANK_INT_REG_PIPE_STAGES            ),
    .INI_DAT        (128'b0                                 )
) i_tb_l2_bank_perf_cnt (
    .clk            (clk                                    ),
    .resetn         (resetn                                 ),
    .tbuff_in_data  ({i_l2b0_busy                                       ,
                      i_l2b0_fromaxi_ar_wl                              ,
                      i_l2b0_fromaxi_ar_bl_eq0_wl                       ,
                      i_l2b0_fromaxi_ar_bl_eq1_wl                       ,
                      i_l2b0_fromaxi_ar_bl_eq2_wl                       ,
                      i_l2b0_fromaxi_ar_bl_eq3_wl                       ,
                      i_l2b0_fromaxi_ar_bp                              ,
                      i_l2b0_toaxi_r_wl                                 ,
                      i_l2b0_toaxi_r_bp                                 ,
                      i_l2b0_fromaxi_aw_wl                              ,
                      i_l2b0_fromaxi_aw_bl_eq0_wl                       ,
                      i_l2b0_fromaxi_aw_bl_eq1_wl                       ,
                      i_l2b0_fromaxi_aw_bl_eq2_wl                       ,
                      i_l2b0_fromaxi_aw_bl_eq3_wl                       ,
                      i_l2b0_fromaxi_aw_bp                              ,
                      i_l2b0_fromaxi_w_wl                               ,
                      i_l2b0_fromaxi_w_bp                               ,
                      i_l2b0_fromaxi_smp_read_req_num                   ,
                      i_l2b0_fromaxi_smp_read_req_sum                   ,
                      i_l2b0_fromaxi_smp_write_req_num                  ,
                      i_l2b0_fromaxi_smp_write_req_sum                  ,
                      i_l2b0_fromaxi_smp_atomic_req_num                 ,
                      i_l2b0_fromaxi_smp_atomic_req_sum                 ,
                      i_l2b0_align_awdb_full                            ,
                      i_l2b0_hittest_ht_bypass_read_wl                  ,
                      i_l2b0_hittest_ht_cache_read_wl                   ,
                      i_l2b0_hittest_ht_bypass_write_wl                 ,
                      i_l2b0_hittest_ht_cache_write_wl                  ,
                      i_l2b0_hittest_ht_atomic_wl                       ,
                      i_l2b0_hittest_ht_bps_hit_wl                      ,
                      i_l2b0_hittest_ht_miss_wl                         ,
                      i_l2b0_frommemsch_nsp_rtn_wl                      ,
                      i_l2b0_frommemsch_nsp_rtn_bp                      ,
                      i_l2b0_tomemsch_nsp_read_bl_eq1_wl                ,
                      i_l2b0_tomemsch_nsp_read_bl_eq3_wl                ,
                      i_l2b0_tomemsch_nsp_read_bl_eq5_wl                ,
                      i_l2b0_tomemsch_nsp_read_bl_eq7_wl                ,
                      i_l2b0_tomemsch_nsp_write_bl_eq1_wl               ,
                      i_l2b0_tomemsch_nsp_write_bl_eq3_wl               ,
                      i_l2b0_tomemsch_nsp_write_bl_eq5_wl               ,
                      i_l2b0_tomemsch_nsp_write_bl_eq7_wl               ,
                      i_l2b0_memif_to_ddr_read_wl                       ,
                      i_l2b0_memif_to_ddr_read_stall_by_rob             ,
                      i_l2b0_memif_to_ddr_read_stall_by_ddr             ,
                      i_l2b0_memif_to_ddr_read_stall_by_trid            ,
                      i_l2b0_memif_to_ddr_write_wl                      ,
                      i_l2b0_memif_to_ddr_write_stall_by_data_sync      ,
                      i_l2b0_memif_to_ddr_write_stall_by_ddr            ,
                      i_l2b0_memif_to_ddr_write_stall_by_trid           ,
                      i_l2b0_memif_memreq_full                          ,
                      i_l2b0_memif_smp_read_req_num                     ,
                      i_l2b0_memif_smp_read_req_sum                     ,
                      i_l2b0_reqsch_sortq_full                          ,
                      i_l2b0_reqsch_sortq_stall_but_not_full            ,
                      i_l2b0_reqsch_disp_wl                             ,
                      i_l2b0_reqsch_disp_stall                          ,
                      i_l2b0_ramctrl_0_reqarb_wl                        ,
                      i_l2b0_ramctrl_0_reqarb_stall_by_sram             ,
                      i_l2b0_ramctrl_0_data_sram_read_wl                ,
                      i_l2b0_ramctrl_0_data_sram_write_wl               ,
                      i_l2b0_ramctrl_1_reqarb_wl                        ,
                      i_l2b0_ramctrl_1_reqarb_stall_by_sram             ,
                      i_l2b0_ramctrl_1_data_sram_read_wl                ,
                      i_l2b0_ramctrl_1_data_sram_write_wl               ,
                      i_l2b1_busy                                       ,
                      i_l2b1_fromaxi_ar_wl                              ,
                      i_l2b1_fromaxi_ar_bl_eq0_wl                       ,
                      i_l2b1_fromaxi_ar_bl_eq1_wl                       ,
                      i_l2b1_fromaxi_ar_bl_eq2_wl                       ,
                      i_l2b1_fromaxi_ar_bl_eq3_wl                       ,
                      i_l2b1_fromaxi_ar_bp                              ,
                      i_l2b1_toaxi_r_wl                                 ,
                      i_l2b1_toaxi_r_bp                                 ,
                      i_l2b1_fromaxi_aw_wl                              ,
                      i_l2b1_fromaxi_aw_bl_eq0_wl                       ,
                      i_l2b1_fromaxi_aw_bl_eq1_wl                       ,
                      i_l2b1_fromaxi_aw_bl_eq2_wl                       ,
                      i_l2b1_fromaxi_aw_bl_eq3_wl                       ,
                      i_l2b1_fromaxi_aw_bp                              ,
                      i_l2b1_fromaxi_w_wl                               ,
                      i_l2b1_fromaxi_w_bp                               ,
                      i_l2b1_fromaxi_smp_read_req_num                   ,
                      i_l2b1_fromaxi_smp_read_req_sum                   ,
                      i_l2b1_fromaxi_smp_write_req_num                  ,
                      i_l2b1_fromaxi_smp_write_req_sum                  ,
                      i_l2b1_fromaxi_smp_atomic_req_num                 ,
                      i_l2b1_fromaxi_smp_atomic_req_sum                 ,
                      i_l2b1_align_awdb_full                            ,
                      i_l2b1_hittest_ht_bypass_read_wl                  ,
                      i_l2b1_hittest_ht_cache_read_wl                   ,
                      i_l2b1_hittest_ht_bypass_write_wl                 ,
                      i_l2b1_hittest_ht_cache_write_wl                  ,
                      i_l2b1_hittest_ht_atomic_wl                       ,
                      i_l2b1_hittest_ht_bps_hit_wl                      ,
                      i_l2b1_hittest_ht_miss_wl                         ,
                      i_l2b1_frommemsch_nsp_rtn_wl                      ,
                      i_l2b1_frommemsch_nsp_rtn_bp                      ,
                      i_l2b1_tomemsch_nsp_read_bl_eq1_wl                ,
                      i_l2b1_tomemsch_nsp_read_bl_eq3_wl                ,
                      i_l2b1_tomemsch_nsp_read_bl_eq5_wl                ,
                      i_l2b1_tomemsch_nsp_read_bl_eq7_wl                ,
                      i_l2b1_tomemsch_nsp_write_bl_eq1_wl               ,
                      i_l2b1_tomemsch_nsp_write_bl_eq3_wl               ,
                      i_l2b1_tomemsch_nsp_write_bl_eq5_wl               ,
                      i_l2b1_tomemsch_nsp_write_bl_eq7_wl               ,
                      i_l2b1_memif_to_ddr_read_wl                       ,
                      i_l2b1_memif_to_ddr_read_stall_by_rob             ,
                      i_l2b1_memif_to_ddr_read_stall_by_ddr             ,
                      i_l2b1_memif_to_ddr_read_stall_by_trid            ,
                      i_l2b1_memif_to_ddr_write_wl                      ,
                      i_l2b1_memif_to_ddr_write_stall_by_data_sync      ,
                      i_l2b1_memif_to_ddr_write_stall_by_ddr            ,
                      i_l2b1_memif_to_ddr_write_stall_by_trid           ,
                      i_l2b1_memif_memreq_full                          ,
                      i_l2b1_memif_smp_read_req_num                     ,
                      i_l2b1_memif_smp_read_req_sum                     ,
                      i_l2b1_reqsch_sortq_full                          ,
                      i_l2b1_reqsch_sortq_stall_but_not_full            ,
                      i_l2b1_reqsch_disp_wl                             ,
                      i_l2b1_reqsch_disp_stall                          ,
                      i_l2b1_ramctrl_0_reqarb_wl                        ,
                      i_l2b1_ramctrl_0_reqarb_stall_by_sram             ,
                      i_l2b1_ramctrl_0_data_sram_read_wl                ,
                      i_l2b1_ramctrl_0_data_sram_write_wl               ,
                      i_l2b1_ramctrl_1_reqarb_wl                        ,
                      i_l2b1_ramctrl_1_reqarb_stall_by_sram             ,
                      i_l2b1_ramctrl_1_data_sram_read_wl                ,
                      i_l2b1_ramctrl_1_data_sram_write_wl             }),
    .tbuff_out_data ({o_l2b0_busy                                       ,
                      o_l2b0_fromaxi_ar_wl                              ,
                      o_l2b0_fromaxi_ar_bl_eq0_wl                       ,
                      o_l2b0_fromaxi_ar_bl_eq1_wl                       ,
                      o_l2b0_fromaxi_ar_bl_eq2_wl                       ,
                      o_l2b0_fromaxi_ar_bl_eq3_wl                       ,
                      o_l2b0_fromaxi_ar_bp                              ,
                      o_l2b0_toaxi_r_wl                                 ,
                      o_l2b0_toaxi_r_bp                                 ,
                      o_l2b0_fromaxi_aw_wl                              ,
                      o_l2b0_fromaxi_aw_bl_eq0_wl                       ,
                      o_l2b0_fromaxi_aw_bl_eq1_wl                       ,
                      o_l2b0_fromaxi_aw_bl_eq2_wl                       ,
                      o_l2b0_fromaxi_aw_bl_eq3_wl                       ,
                      o_l2b0_fromaxi_aw_bp                              ,
                      o_l2b0_fromaxi_w_wl                               ,
                      o_l2b0_fromaxi_w_bp                               ,
                      o_l2b0_fromaxi_smp_read_req_num                   ,
                      o_l2b0_fromaxi_smp_read_req_sum                   ,
                      o_l2b0_fromaxi_smp_write_req_num                  ,
                      o_l2b0_fromaxi_smp_write_req_sum                  ,
                      o_l2b0_fromaxi_smp_atomic_req_num                 ,
                      o_l2b0_fromaxi_smp_atomic_req_sum                 ,
                      o_l2b0_align_awdb_full                            ,
                      o_l2b0_hittest_ht_bypass_read_wl                  ,
                      o_l2b0_hittest_ht_cache_read_wl                   ,
                      o_l2b0_hittest_ht_bypass_write_wl                 ,
                      o_l2b0_hittest_ht_cache_write_wl                  ,
                      o_l2b0_hittest_ht_atomic_wl                       ,
                      o_l2b0_hittest_ht_bps_hit_wl                      ,
                      o_l2b0_hittest_ht_miss_wl                         ,
                      o_l2b0_frommemsch_nsp_rtn_wl                      ,
                      o_l2b0_frommemsch_nsp_rtn_bp                      ,
                      o_l2b0_tomemsch_nsp_read_bl_eq1_wl                ,
                      o_l2b0_tomemsch_nsp_read_bl_eq3_wl                ,
                      o_l2b0_tomemsch_nsp_read_bl_eq5_wl                ,
                      o_l2b0_tomemsch_nsp_read_bl_eq7_wl                ,
                      o_l2b0_tomemsch_nsp_write_bl_eq1_wl               ,
                      o_l2b0_tomemsch_nsp_write_bl_eq3_wl               ,
                      o_l2b0_tomemsch_nsp_write_bl_eq5_wl               ,
                      o_l2b0_tomemsch_nsp_write_bl_eq7_wl               ,
                      o_l2b0_memif_to_ddr_read_wl                       ,
                      o_l2b0_memif_to_ddr_read_stall_by_rob             ,
                      o_l2b0_memif_to_ddr_read_stall_by_ddr             ,
                      o_l2b0_memif_to_ddr_read_stall_by_trid            ,
                      o_l2b0_memif_to_ddr_write_wl                      ,
                      o_l2b0_memif_to_ddr_write_stall_by_data_sync      ,
                      o_l2b0_memif_to_ddr_write_stall_by_ddr            ,
                      o_l2b0_memif_to_ddr_write_stall_by_trid           ,
                      o_l2b0_memif_memreq_full                          ,
                      o_l2b0_memif_smp_read_req_num                     ,
                      o_l2b0_memif_smp_read_req_sum                     ,
                      o_l2b0_reqsch_sortq_full                          ,
                      o_l2b0_reqsch_sortq_stall_but_not_full            ,
                      o_l2b0_reqsch_disp_wl                             ,
                      o_l2b0_reqsch_disp_stall                          ,
                      o_l2b0_ramctrl_0_reqarb_wl                        ,
                      o_l2b0_ramctrl_0_reqarb_stall_by_sram             ,
                      o_l2b0_ramctrl_0_data_sram_read_wl                ,
                      o_l2b0_ramctrl_0_data_sram_write_wl               ,
                      o_l2b0_ramctrl_1_reqarb_wl                        ,
                      o_l2b0_ramctrl_1_reqarb_stall_by_sram             ,
                      o_l2b0_ramctrl_1_data_sram_read_wl                ,
                      o_l2b0_ramctrl_1_data_sram_write_wl               ,
                      o_l2b1_busy                                       ,
                      o_l2b1_fromaxi_ar_wl                              ,
                      o_l2b1_fromaxi_ar_bl_eq0_wl                       ,
                      o_l2b1_fromaxi_ar_bl_eq1_wl                       ,
                      o_l2b1_fromaxi_ar_bl_eq2_wl                       ,
                      o_l2b1_fromaxi_ar_bl_eq3_wl                       ,
                      o_l2b1_fromaxi_ar_bp                              ,
                      o_l2b1_toaxi_r_wl                                 ,
                      o_l2b1_toaxi_r_bp                                 ,
                      o_l2b1_fromaxi_aw_wl                              ,
                      o_l2b1_fromaxi_aw_bl_eq0_wl                       ,
                      o_l2b1_fromaxi_aw_bl_eq1_wl                       ,
                      o_l2b1_fromaxi_aw_bl_eq2_wl                       ,
                      o_l2b1_fromaxi_aw_bl_eq3_wl                       ,
                      o_l2b1_fromaxi_aw_bp                              ,
                      o_l2b1_fromaxi_w_wl                               ,
                      o_l2b1_fromaxi_w_bp                               ,
                      o_l2b1_fromaxi_smp_read_req_num                   ,
                      o_l2b1_fromaxi_smp_read_req_sum                   ,
                      o_l2b1_fromaxi_smp_write_req_num                  ,
                      o_l2b1_fromaxi_smp_write_req_sum                  ,
                      o_l2b1_fromaxi_smp_atomic_req_num                 ,
                      o_l2b1_fromaxi_smp_atomic_req_sum                 ,
                      o_l2b1_align_awdb_full                            ,
                      o_l2b1_hittest_ht_bypass_read_wl                  ,
                      o_l2b1_hittest_ht_cache_read_wl                   ,
                      o_l2b1_hittest_ht_bypass_write_wl                 ,
                      o_l2b1_hittest_ht_cache_write_wl                  ,
                      o_l2b1_hittest_ht_atomic_wl                       ,
                      o_l2b1_hittest_ht_bps_hit_wl                      ,
                      o_l2b1_hittest_ht_miss_wl                         ,
                      o_l2b1_frommemsch_nsp_rtn_wl                      ,
                      o_l2b1_frommemsch_nsp_rtn_bp                      ,
                      o_l2b1_tomemsch_nsp_read_bl_eq1_wl                ,
                      o_l2b1_tomemsch_nsp_read_bl_eq3_wl                ,
                      o_l2b1_tomemsch_nsp_read_bl_eq5_wl                ,
                      o_l2b1_tomemsch_nsp_read_bl_eq7_wl                ,
                      o_l2b1_tomemsch_nsp_write_bl_eq1_wl               ,
                      o_l2b1_tomemsch_nsp_write_bl_eq3_wl               ,
                      o_l2b1_tomemsch_nsp_write_bl_eq5_wl               ,
                      o_l2b1_tomemsch_nsp_write_bl_eq7_wl               ,
                      o_l2b1_memif_to_ddr_read_wl                       ,
                      o_l2b1_memif_to_ddr_read_stall_by_rob             ,
                      o_l2b1_memif_to_ddr_read_stall_by_ddr             ,
                      o_l2b1_memif_to_ddr_read_stall_by_trid            ,
                      o_l2b1_memif_to_ddr_write_wl                      ,
                      o_l2b1_memif_to_ddr_write_stall_by_data_sync      ,
                      o_l2b1_memif_to_ddr_write_stall_by_ddr            ,
                      o_l2b1_memif_to_ddr_write_stall_by_trid           ,
                      o_l2b1_memif_memreq_full                          ,
                      o_l2b1_memif_smp_read_req_num                     ,
                      o_l2b1_memif_smp_read_req_sum                     ,
                      o_l2b1_reqsch_sortq_full                          ,
                      o_l2b1_reqsch_sortq_stall_but_not_full            ,
                      o_l2b1_reqsch_disp_wl                             ,
                      o_l2b1_reqsch_disp_stall                          ,
                      o_l2b1_ramctrl_0_reqarb_wl                        ,
                      o_l2b1_ramctrl_0_reqarb_stall_by_sram             ,
                      o_l2b1_ramctrl_0_data_sram_read_wl                ,
                      o_l2b1_ramctrl_0_data_sram_write_wl               ,
                      o_l2b1_ramctrl_1_reqarb_wl                        ,
                      o_l2b1_ramctrl_1_reqarb_stall_by_sram             ,
                      o_l2b1_ramctrl_1_data_sram_read_wl                ,
                      o_l2b1_ramctrl_1_data_sram_write_wl             })
);

endmodule
