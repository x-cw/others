/*


*/

// ----------------------------------------------------------------------------------------------
// entity name: gc_l2_bank_fp32_alu
// purpose: L2 cache FP32 atomic ALU
// ----------------------------------------------------------------------------------------------

module gc_l2_bank_fp32_alu
import gc_l2_bank_pkg::*;
(
    input   logic                           clk,
    input   logic                           resetn,
    input   logic                           enable,
    input   logic                           flush_en,
    input   logic [L2_AA_OP_WIDTH - 1:0]    aa_operation,
    input   logic [31:0]                    operand_a,
    input   logic [31:0]                    operand_b,
    input   logic [31:0]                    swap_data,
    output  logic [31:0]                    fp32_result,
    output  logic                           fp32_rlt_upd
);

localparam int unsigned SIG_WIDTH = 23;
localparam int unsigned EXP_WIDTH = 8;

// ----------------------------------------------------------------------------------------------
// interanl signal define
// ----------------------------------------------------------------------------------------------
logic                   fp32_op_add;
logic                   fp32_op_sub;
logic                   fp32_op_min;
logic                   fp32_op_max;
logic                   addsub_spe_en;
logic [31:0]            y_addsub_spe;
logic [31:0]            y_min;
logic [31:0]            y_max;
logic [31:0]            y_min_norm;
logic [31:0]            y_max_norm;
logic [31:0]            y_comp;
logic                   a_sign;
logic                   b_sign;
logic                   b_sign_add;
logic [EXP_WIDTH-1 : 0] a_exp;
logic [EXP_WIDTH-1 : 0] b_exp;
logic [SIG_WIDTH-1 : 0] a_mts;
logic [SIG_WIDTH-1 : 0] b_mts;
logic                   min_upd;
logic                   max_upd;
logic                   comp_upd;
logic [31:0]            operand_b_add;
logic                   swap_data_is_denorm;

logic                   fp32_op_add_r;
logic                   fp32_op_sub_r;
logic                   fp32_op_min_r;
logic                   fp32_op_max_r;
logic                   fp32_op_comp_r;
logic                   addsub_spe_en_r;
logic [31:0]            y_addsub_spe_r;
logic [31:0]            y_addsub_norm_r;
// logic                   y_addsub_result_denorm;
logic [31:0]            y_addsub_flushed;
logic [31:0]            y_min_r;
logic [31:0]            y_max_r;
logic [31:0]            y_comp_r;
logic                   min_upd_r;
logic                   max_upd_r;
logic                   comp_upd_r;

// special number process
logic [SPE_CODE_WIDTH-1         : 0] a_special_code;
logic [SPE_CODE_WIDTH-1         : 0] b_special_code;
logic [TOTAL_SPE_CODE_WIDTH-1   : 0] add_special_code;
logic [TOTAL_SPE_CODE_WIDTH-1   : 0] cmp_special_code;

assign fp32_op_add  = (aa_operation == L2_AA_OP_FADD    ) ? 1'b1 : 1'b0;
assign fp32_op_sub  = (aa_operation == L2_AA_OP_FSUB    ) ? 1'b1 : 1'b0;
assign fp32_op_min  = (aa_operation == L2_AA_OP_FMIN    ) ? 1'b1 : 1'b0;
assign fp32_op_max  = (aa_operation == L2_AA_OP_FMAX    ) ? 1'b1 : 1'b0;
assign fp32_op_comp = (aa_operation == L2_AA_OP_FCMPXCHG) ? 1'b1 : 1'b0;

assign a_sign    = operand_a[SIG_WIDTH+EXP_WIDTH];
assign b_sign    = operand_b[SIG_WIDTH+EXP_WIDTH];
assign b_sign_add= operand_b_add[SIG_WIDTH+EXP_WIDTH];
assign a_mts     = operand_a[0 +: SIG_WIDTH];
assign b_mts     = operand_b[0 +: SIG_WIDTH];
assign a_exp     = operand_a[SIG_WIDTH +: EXP_WIDTH];
assign b_exp     = operand_b[SIG_WIDTH +: EXP_WIDTH];


assign operand_b_add = fp32_op_sub ? {~b_sign, b_exp, b_mts} : operand_b;

gc_fp32_adder_denorm_flush #(
    .ew     (EXP_WIDTH          ),
    .mw_a   (SIG_WIDTH          ),
    .mw_b   (SIG_WIDTH          ),
    .mw_y   (SIG_WIDTH          )
) i_gc_fp32_adder_denorm       (
    .clk    (clk                ),  // I
    .enable (enable             ),  // I
    .a      (operand_a          ),  // I
    .b      (operand_b_add      ),  // I
    .y      (y_addsub_norm_r    )   // O
);

// assign y_addsub_result_denorm = ~(|y_addsub_norm_r[SIG_WIDTH +: EXP_WIDTH]) & (|y_addsub_norm_r[0 +: SIG_WIDTH]);
// assign y_addsub_flushed = y_addsub_result_denorm ? {y_addsub_norm_r[SIG_WIDTH+EXP_WIDTH], {SIG_WIDTH+EXP_WIDTH{1'b0}}} :
//                                                     y_addsub_norm_r;
assign y_addsub_flushed =                              y_addsub_norm_r;
// FP32 min/max
logic           a_small;
logic           a_equ_b;
logic           min_norm_upd;
logic           max_norm_upd;
logic [31:0]    flushed_op_a;
logic [31:0]    flushed_op_b;

assign flushed_op_a = flush_en && (a_special_code == FP32_DENORM) ? (a_sign ? FP32_NUM_NZERO : FP32_NUM_PZERO) : operand_a;
assign flushed_op_b = flush_en && (b_special_code == FP32_DENORM) ? (b_sign ? FP32_NUM_NZERO : FP32_NUM_PZERO) : operand_b;

assign a_equ_b = (flushed_op_a == flushed_op_b) ? 1'b1 : 1'b0;

always_comb begin: p_fp32_cmp
    if(a_sign & b_sign) begin               // a-, b-
        if(flushed_op_a[0 +: EXP_WIDTH+SIG_WIDTH] < flushed_op_b[0 +: EXP_WIDTH+SIG_WIDTH]) begin
            a_small = 1'b0;
        end
        else begin
            a_small = 1'b1;
        end
    end
    else if((~a_sign) & (~b_sign)) begin    // a+, b+
        if(flushed_op_a[0 +: EXP_WIDTH+SIG_WIDTH] > flushed_op_b[0 +: EXP_WIDTH+SIG_WIDTH]) begin
            a_small = 1'b0;
        end
        else begin
            a_small = 1'b1;
        end
    end
    else begin
        if(a_sign) begin                    // a-, b+
            a_small = 1'b1;
        end
        else begin                          // a+, b-
            a_small = 1'b0;
        end
    end
end: p_fp32_cmp

assign min_norm_upd = ~a_small & ~a_equ_b;
assign max_norm_upd =  a_small & ~a_equ_b;
assign y_min_norm = min_norm_upd ? operand_b : operand_a;
assign y_max_norm = max_norm_upd ? operand_b : operand_a;


always_comb begin: p_special_num
    if(&a_exp) begin                // exp=2^e-1, all 1
        if(~(|a_mts)) begin         // mantissa = 0
            if(a_sign) begin        // sign=1
                a_special_code = FP32_NINF;
            end
            else begin
                a_special_code = FP32_PINF;
            end
        end
        else begin                  // mantissa != 0
            a_special_code = FP32_NAN;
        end
    end
    else if(~(|a_exp) & (|a_mts)) begin     // exp=0, mantissa != 0
        a_special_code = FP32_DENORM;
    end
    else begin
        a_special_code = FP32_NORM;
    end

    if(&b_exp) begin
        if(~(|b_mts)) begin
            if(b_sign_add) begin    // always as adder
                b_special_code = FP32_NINF;
            end
            else begin
                b_special_code = FP32_PINF;
            end
        end
        else begin
            b_special_code = FP32_NAN;
        end
    end
    else if(~(|b_exp) & (|b_mts)) begin
        b_special_code = FP32_DENORM;
    end
    else begin
        b_special_code = FP32_NORM;
    end
end: p_special_num

assign add_special_code = {FP32_ADD    , a_special_code, b_special_code};
assign cmp_special_code = {fp32_op_max , a_special_code, b_special_code};
assign addsub_spe_en    = (fp32_op_add || fp32_op_sub) && ((a_special_code != FP32_NORM) || (b_special_code != FP32_NORM));

always_comb begin: p_addsub_sel
    case(add_special_code)
        {FP32_ADD, FP32_NORM  , FP32_NAN   }: y_addsub_spe = FP32_NUM_NAN   ;
        {FP32_ADD, FP32_NAN   , FP32_NORM  }: y_addsub_spe = FP32_NUM_NAN   ;
        {FP32_ADD, FP32_PINF  , FP32_NINF  }: y_addsub_spe = FP32_NUM_NAN   ;
        {FP32_ADD, FP32_NINF  , FP32_PINF  }: y_addsub_spe = FP32_NUM_NAN   ;
        {FP32_ADD, FP32_NORM  , FP32_PINF  }: y_addsub_spe = FP32_NUM_PINF  ;
        {FP32_ADD, FP32_NORM  , FP32_NINF  }: y_addsub_spe = FP32_NUM_NINF  ;
        {FP32_ADD, FP32_PINF  , FP32_NORM  }: y_addsub_spe = FP32_NUM_PINF  ;
        {FP32_ADD, FP32_NINF  , FP32_NORM  }: y_addsub_spe = FP32_NUM_NINF  ;
        {FP32_ADD, FP32_PINF  , FP32_PINF  }: y_addsub_spe = FP32_NUM_PINF  ;
        {FP32_ADD, FP32_NINF  , FP32_NINF  }: y_addsub_spe = FP32_NUM_NINF  ;
        {FP32_ADD, FP32_DENORM, FP32_NORM  }: begin
        if((b_exp == 'b0) && (b_mts == 'b0))
                                              y_addsub_spe = {a_sign&b_sign_add, b_exp, b_mts};
        else                                  y_addsub_spe = {b_sign_add       , b_exp, b_mts};
        end
        {FP32_ADD, FP32_NORM  , FP32_DENORM}: begin
        if((a_exp == 'b0) && (a_mts == 'b0))
                                              y_addsub_spe = {a_sign&b_sign_add, a_exp, a_mts};
        else                                  y_addsub_spe = {a_sign           , a_exp, a_mts};
        end
        {FP32_ADD, FP32_DENORM, FP32_DENORM}: begin
            if(a_sign & b_sign_add)           y_addsub_spe = FP32_NUM_NZERO ;
            else                              y_addsub_spe = FP32_NUM_PZERO ;
        end
        {FP32_ADD, FP32_PINF  , FP32_DENORM}: y_addsub_spe = FP32_NUM_PINF  ;
        {FP32_ADD, FP32_NINF  , FP32_DENORM}: y_addsub_spe = FP32_NUM_NINF  ;
        {FP32_ADD, FP32_DENORM, FP32_PINF  }: y_addsub_spe = FP32_NUM_PINF  ;
        {FP32_ADD, FP32_DENORM, FP32_NINF  }: y_addsub_spe = FP32_NUM_NINF  ;
        {FP32_ADD, FP32_DENORM, FP32_NAN   }: y_addsub_spe = FP32_NUM_NAN   ;
        {FP32_ADD, FP32_NAN   , FP32_DENORM}: y_addsub_spe = FP32_NUM_NAN   ;
        {FP32_ADD, FP32_NAN   , FP32_PINF  }: y_addsub_spe = FP32_NUM_NAN   ;
        {FP32_ADD, FP32_NAN   , FP32_NINF  }: y_addsub_spe = FP32_NUM_NAN   ;
        {FP32_ADD, FP32_PINF  , FP32_NAN   }: y_addsub_spe = FP32_NUM_NAN   ;
        {FP32_ADD, FP32_NINF  , FP32_NAN   }: y_addsub_spe = FP32_NUM_NAN   ;
        {FP32_ADD, FP32_NAN   , FP32_NAN   }: y_addsub_spe = FP32_NUM_NAN   ;
        default:                              y_addsub_spe = FP32_NUM_PINF  ;
    endcase
end: p_addsub_sel

always_comb begin: p_cmp_min_sel
    case(cmp_special_code)
        {FP32_MIN, FP32_NAN   , FP32_NORM  }, 
        {FP32_MIN, FP32_NAN   , FP32_DENORM}, 
        {FP32_MIN, FP32_NAN   , FP32_PINF  }, 
        {FP32_MIN, FP32_NAN   , FP32_NINF  }, 
        {FP32_MIN, FP32_NAN   , FP32_NAN   }, 
        {FP32_MIN, FP32_NORM  , FP32_NAN   }, 
        {FP32_MIN, FP32_DENORM, FP32_NAN   }, 
        {FP32_MIN, FP32_PINF  , FP32_NAN   }, 
        {FP32_MIN, FP32_NINF  , FP32_NAN   }: begin y_min = FP32_NUM_NAN  ; min_upd = 1'b1; end
        {FP32_MIN, FP32_PINF  , FP32_PINF  }: begin y_min = FP32_NUM_PINF ; min_upd = 1'b0; end
        {FP32_MIN, FP32_NINF  , FP32_NINF  }: begin y_min = FP32_NUM_NINF ; min_upd = 1'b0; end
        {FP32_MIN, FP32_PINF  , FP32_NINF  }: begin y_min = FP32_NUM_NINF ; min_upd = 1'b1; end
        {FP32_MIN, FP32_NINF  , FP32_PINF  }: begin y_min = FP32_NUM_NINF ; min_upd = 1'b0; end
        {FP32_MIN, FP32_NORM  , FP32_PINF  },
        {FP32_MIN, FP32_DENORM, FP32_PINF  }: begin y_min = operand_a     ; min_upd = 1'b0; end
        {FP32_MIN, FP32_NORM  , FP32_NINF  },
        {FP32_MIN, FP32_DENORM, FP32_NINF  }: begin y_min = FP32_NUM_NINF ; min_upd = 1'b1; end
        {FP32_MIN, FP32_PINF  , FP32_NORM  },
        {FP32_MIN, FP32_PINF  , FP32_DENORM}: begin y_min = operand_b     ; min_upd = 1'b1; end
        {FP32_MIN, FP32_NINF  , FP32_NORM  },
        {FP32_MIN, FP32_NINF  , FP32_DENORM}: begin y_min = FP32_NUM_NINF ; min_upd = 1'b0; end
        default:                              begin y_min = y_min_norm    ; min_upd = min_norm_upd; end
    endcase
end: p_cmp_min_sel

always_comb begin: p_cmp_max_sel
    case(cmp_special_code)
        {FP32_MAX, FP32_NAN   , FP32_NORM  },
        {FP32_MAX, FP32_NAN   , FP32_DENORM},
        {FP32_MAX, FP32_NAN   , FP32_PINF  },
        {FP32_MAX, FP32_NAN   , FP32_NINF  },
        {FP32_MAX, FP32_NAN   , FP32_NAN   },
        {FP32_MAX, FP32_NORM  , FP32_NAN   },
        {FP32_MAX, FP32_DENORM, FP32_NAN   },
        {FP32_MAX, FP32_PINF  , FP32_NAN   },
        {FP32_MAX, FP32_NINF  , FP32_NAN   }: begin y_max = FP32_NUM_NAN  ; max_upd = 1'b1; end
        {FP32_MAX, FP32_PINF  , FP32_PINF  }: begin y_max = FP32_NUM_PINF ; max_upd = 1'b0; end
        {FP32_MAX, FP32_NINF  , FP32_NINF  }: begin y_max = FP32_NUM_NINF ; max_upd = 1'b0; end
        {FP32_MAX, FP32_PINF  , FP32_NINF  }: begin y_max = FP32_NUM_PINF ; max_upd = 1'b0; end
        {FP32_MAX, FP32_NINF  , FP32_PINF  }: begin y_max = FP32_NUM_PINF ; max_upd = 1'b1; end
        {FP32_MAX, FP32_NORM  , FP32_PINF  },
        {FP32_MAX, FP32_DENORM, FP32_PINF  }: begin y_max = FP32_NUM_PINF ; max_upd = 1'b1; end
        {FP32_MAX, FP32_NORM  , FP32_NINF  },
        {FP32_MAX, FP32_DENORM, FP32_NINF  }: begin y_max = operand_a     ; max_upd = 1'b0; end
        {FP32_MAX, FP32_PINF  , FP32_NORM  },
        {FP32_MAX, FP32_PINF  , FP32_DENORM}: begin y_max = FP32_NUM_PINF ; max_upd = 1'b0; end
        {FP32_MAX, FP32_NINF  , FP32_NORM  },
        {FP32_MAX, FP32_NINF  , FP32_DENORM}: begin y_max = operand_b     ; max_upd = 1'b1; end
        default:                              begin y_max = y_max_norm    ; max_upd = max_norm_upd; end
    endcase
end: p_cmp_max_sel

// FP32 compare and exchage
assign swap_data_is_denorm = ~(|swap_data[SIG_WIDTH +: EXP_WIDTH]) & (|swap_data[0 +: SIG_WIDTH]);

always_comb begin: p_cmpxchg
    if(a_special_code == FP32_NAN) begin
        y_comp  = operand_a;
        comp_upd= 1'b0;
    end
    else if(b_special_code == FP32_NAN) begin
        if((a_special_code == FP32_DENORM) && flush_en) begin
            y_comp  = flushed_op_a;
            comp_upd= 1'b1;
        end
        else begin
            y_comp  = operand_a;
            comp_upd= 1'b0;
        end
    end
    else if(flushed_op_a == flushed_op_b) begin
        if(flush_en && (a_special_code == FP32_DENORM || b_special_code == FP32_DENORM) && swap_data_is_denorm)
            y_comp = {swap_data[SIG_WIDTH+EXP_WIDTH], {SIG_WIDTH+EXP_WIDTH{1'b0}}};
        else
            y_comp = swap_data;
        comp_upd= 1'b1;
    end
    else if(flush_en && (a_special_code == FP32_DENORM)) begin      // not equal but a is denormal
        y_comp  = {operand_a[SIG_WIDTH+EXP_WIDTH], {SIG_WIDTH+EXP_WIDTH{1'b0}}};    // flush
        comp_upd= 1'b1;
    end
    else begin
        y_comp  = operand_a;
        comp_upd= 1'b0;
    end
end: p_cmpxchg

// fp32 compare and addsub special value register pipe
always_ff @(posedge clk or negedge resetn) begin
    if(!resetn) begin
        fp32_op_add_r   <= 'b0;
        fp32_op_sub_r   <= 'b0;
        fp32_op_min_r   <= 'b0;
        fp32_op_max_r   <= 'b0;
        fp32_op_comp_r  <= 'b0;
        addsub_spe_en_r <= 'b0;
        y_addsub_spe_r  <= 'b0;
        y_min_r         <= 'b0;
        y_max_r         <= 'b0;
        y_comp_r        <= 'b0;
        min_upd_r       <= 'b0;
        max_upd_r       <= 'b0;
        comp_upd_r      <= 'b0;
    end
    else if(enable) begin
        fp32_op_add_r   <= fp32_op_add  ;
        fp32_op_sub_r   <= fp32_op_sub  ;
        fp32_op_min_r   <= fp32_op_min  ;
        fp32_op_max_r   <= fp32_op_max  ;
        fp32_op_comp_r  <= fp32_op_comp ;
        addsub_spe_en_r <= addsub_spe_en;
        y_addsub_spe_r  <= y_addsub_spe ;
        y_min_r         <= y_min        ;
        y_max_r         <= y_max        ;
        y_comp_r        <= y_comp       ;
        min_upd_r       <= min_upd      ;
        max_upd_r       <= max_upd      ;
        comp_upd_r      <= comp_upd     ;
    end
end

// result select
assign fp32_result = (fp32_op_add_r | fp32_op_sub_r) ? (addsub_spe_en_r ? y_addsub_spe_r : y_addsub_flushed) :
                      fp32_op_min_r ? y_min_r :
                      fp32_op_max_r ? y_max_r : 
                      fp32_op_comp_r? y_comp_r: 32'b0;

assign fp32_rlt_upd= (fp32_op_add_r | fp32_op_sub_r) ? 1'b1:
                      fp32_op_min_r ? min_upd_r : 
                      fp32_op_max_r ? max_upd_r :
                      fp32_op_comp_r? comp_upd_r: 1'b0;

endmodule
