/*

 * #==========================================================================#
 * |                                                                          |
 * |  Copyright (c) 2022, Fantasy Technologies Limited and/or its         |
 * |  affiliated group companies ("Fantasy"). All rights reserved.        |
 * |  No part of this content, either material or conceptual may be copied    |
 * |  or distributed, transmitted, transcribed, stored in a retrieval system  |
 * |  or translated into any human or computer language in any form by any    |
 * |  means, electronic, mechanical manual, or otherwise, or disclosed to     |
 * |  third parties without the express written permission of Fantasy.    |
 * |                                                                          |
 * #==========================================================================#

 */

`ifndef GC_DEBUG_TAG_PACK_SV_DEFINE
`define GC_DEBUG_TAG_PACK_SV_DEFINE

package gc_debug_tag_pack_;

    typedef logic [2 : 0]   GC_DEBUG_TAG_dm_type;
    typedef logic [3 : 0]   GC_DEBUG_TAG_vtx_gen_type;
    typedef logic [3 : 0]   GC_DEBUG_TAG_cmp_gen_type;
    typedef logic [3 : 0]   GC_DEBUG_TAG_stm_gen_type;
    typedef logic [3 : 0]   GC_DEBUG_TAG_f2d_gen_type;
    typedef logic [3 : 0]   GC_DEBUG_TAG_pxl_gen_type;
    typedef logic [2 : 0]   GC_DEBUG_TAG_rvtx_gen_type;
    typedef logic [2 : 0]   GC_DEBUG_TAG_ray_gen_type;
    typedef logic [2 : 0]   GC_DEBUG_TAG_ray_tasktype_type;


  //Data Master Encoding 
    localparam GC_DEBUG_TAG_dm_type  GC_DEBUG_TAG_DM_VTX                       = 3'h0;  // VTX (0)
    localparam GC_DEBUG_TAG_dm_type  GC_DEBUG_TAG_DM_PXL                       = 3'h1;  // PXL (0x1)
    localparam GC_DEBUG_TAG_dm_type  GC_DEBUG_TAG_DM_CMP                       = 3'h2;  // CMP (0x2)
    localparam GC_DEBUG_TAG_dm_type  GC_DEBUG_TAG_DM_TSV                       = 3'h3;  // TSV (0x3)
    localparam GC_DEBUG_TAG_dm_type  GC_DEBUG_TAG_DM_STM                       = 3'h4;  // STM (0x4)
    localparam GC_DEBUG_TAG_dm_type  GC_DEBUG_TAG_DM_RAY                       = 3'h5;  // RAY (0x5)
    localparam GC_DEBUG_TAG_dm_type  GC_DEBUG_TAG_DM_F2D                       = 3'h7;  // F2D (0x7)


  //Generations of the VTX_DEBUG_TAG 
    localparam GC_DEBUG_TAG_vtx_gen_type  GC_DEBUG_TAG_VTX_GEN_DCE             = 4'h0;  // DCE (0)
    localparam GC_DEBUG_TAG_vtx_gen_type  GC_DEBUG_TAG_VTX_GEN_VDM             = 4'h1;  // VDM (0x1)
    localparam GC_DEBUG_TAG_vtx_gen_type  GC_DEBUG_TAG_VTX_GEN_PDS             = 4'h2;  // PDS (0x2)
    localparam GC_DEBUG_TAG_vtx_gen_type  GC_DEBUG_TAG_VTX_GEN_CU             = 4'h3;  // CU (0x3)
    localparam GC_DEBUG_TAG_vtx_gen_type  GC_DEBUG_TAG_VTX_GEN_CLIP            = 4'h4;  // CLIP (0x4)
    localparam GC_DEBUG_TAG_vtx_gen_type  GC_DEBUG_TAG_VTX_GEN_VBG             = 4'h5;  // VBG (0x5)
    localparam GC_DEBUG_TAG_vtx_gen_type  GC_DEBUG_TAG_VTX_GEN_PPP             = 4'h6;  // PPP (0x6)
    localparam GC_DEBUG_TAG_vtx_gen_type  GC_DEBUG_TAG_VTX_GEN_VCE             = 4'h7;  // VCE (0x7)
    localparam GC_DEBUG_TAG_vtx_gen_type  GC_DEBUG_TAG_VTX_GEN_TPU             = 4'h8;  // TPU (0x8)


  //Generations of the CMP_DEBUG_TAG 
    localparam GC_DEBUG_TAG_cmp_gen_type  GC_DEBUG_TAG_CMP_GEN_CPC             = 4'h0;  // CPC (0)
    localparam GC_DEBUG_TAG_cmp_gen_type  GC_DEBUG_TAG_CMP_GEN_PDS             = 4'h2;  // PDS (0x2)
    localparam GC_DEBUG_TAG_cmp_gen_type  GC_DEBUG_TAG_CMP_GEN_CU             = 4'h3;  // CU (0x3)
    localparam GC_DEBUG_TAG_cmp_gen_type  GC_DEBUG_TAG_CMP_GEN_TPU             = 4'h4;  // TPU (0x4)


  //Generations of the STM_DEBUG_TAG 
    localparam GC_DEBUG_TAG_stm_gen_type  GC_DEBUG_TAG_STM_GEN_VBG             = 4'h0;  // VBG (0)
    localparam GC_DEBUG_TAG_stm_gen_type  GC_DEBUG_TAG_STM_GEN_PDS             = 4'h1;  // PDS (0x1)


  //Generations of the F2D_DEBUG_TAG 
    localparam GC_DEBUG_TAG_f2d_gen_type  GC_DEBUG_TAG_F2D_GEN_TDM             = 4'h0;  // TDM (0)
    localparam GC_DEBUG_TAG_f2d_gen_type  GC_DEBUG_TAG_F2D_GEN_PDS             = 4'h1;  // PDS (0x1)
    localparam GC_DEBUG_TAG_f2d_gen_type  GC_DEBUG_TAG_F2D_GEN_CU_SLOT        = 4'h2;  // CU_SLOT (0x2)
    localparam GC_DEBUG_TAG_f2d_gen_type  GC_DEBUG_TAG_F2D_GEN_CU_2X2_BLOCK   = 4'h3;  // CU_2X2_BLOCK (0x3)
    localparam GC_DEBUG_TAG_f2d_gen_type  GC_DEBUG_TAG_F2D_GEN_CU_PIXEL       = 4'h4;  // CU_PIXEL (0x4)
    localparam GC_DEBUG_TAG_f2d_gen_type  GC_DEBUG_TAG_F2D_GEN_TPU             = 4'h5;  // TPU (0x5)


  //Generations of the PXL_DEBUG_TAG 
    localparam GC_DEBUG_TAG_pxl_gen_type  GC_DEBUG_TAG_PXL_GEN_IPF_FRONT       = 4'h0;  // IPF_FRONT (0)
    localparam GC_DEBUG_TAG_pxl_gen_type  GC_DEBUG_TAG_PXL_GEN_IPF_BACK        = 4'h1;  // IPF_BACK (0x1)
    localparam GC_DEBUG_TAG_pxl_gen_type  GC_DEBUG_TAG_PXL_GEN_IFPU            = 4'h2;  // IFPU (0x2)
    localparam GC_DEBUG_TAG_pxl_gen_type  GC_DEBUG_TAG_PXL_GEN_PDS             = 4'h3;  // PDS (0x3)
    localparam GC_DEBUG_TAG_pxl_gen_type  GC_DEBUG_TAG_PXL_GEN_CU_SLOT        = 4'h4;  // CU_SLOT (0x4)
    localparam GC_DEBUG_TAG_pxl_gen_type  GC_DEBUG_TAG_PXL_GEN_CU_2X2_BLOCK   = 4'h5;  // CU_2X2_BLOCK (0x5)
    localparam GC_DEBUG_TAG_pxl_gen_type  GC_DEBUG_TAG_PXL_GEN_CU_PIXEL       = 4'h6;  // CU_PIXEL (0x6)
    localparam GC_DEBUG_TAG_pxl_gen_type  GC_DEBUG_TAG_PXL_GEN_TPU             = 4'h7;  // TPU (0x7)


  //Generations of the RVTX_DEBUG_TAG 
    localparam GC_DEBUG_TAG_rvtx_gen_type  GC_DEBUG_TAG_RVTX_GEN_PDS           = 3'h2;  // PDS (0x2)
    localparam GC_DEBUG_TAG_rvtx_gen_type  GC_DEBUG_TAG_RVTX_GEN_CU           = 3'h3;  // CU (0x3)
    localparam GC_DEBUG_TAG_rvtx_gen_type  GC_DEBUG_TAG_RVTX_GEN_SHF           = 3'h4;  // SHF (0x4)
    localparam GC_DEBUG_TAG_rvtx_gen_type  GC_DEBUG_TAG_RVTX_GEN_TVB           = 3'h5;  // TVB (0x5)
    localparam GC_DEBUG_TAG_rvtx_gen_type  GC_DEBUG_TAG_RVTX_GEN_SHG           = 3'h6;  // SHG (0x6)


  //Generations of the RAY_DEBUG_TAG 
    localparam GC_DEBUG_TAG_ray_gen_type  GC_DEBUG_TAG_RAY_GEN_RCE             = 3'h0;  // RCE (0)
    localparam GC_DEBUG_TAG_ray_gen_type  GC_DEBUG_TAG_RAY_GEN_RTS             = 3'h1;  // RTS (0x1)
    localparam GC_DEBUG_TAG_ray_gen_type  GC_DEBUG_TAG_RAY_GEN_CU_INST        = 3'h2;  // CU_INST (0x2)
    localparam GC_DEBUG_TAG_ray_gen_type  GC_DEBUG_TAG_RAY_GEN_CU_BLOCK       = 3'h3;  // CU_BLOCK (0x3)
    localparam GC_DEBUG_TAG_ray_gen_type  GC_DEBUG_TAG_RAY_GEN_CU_DBLOCK      = 3'h4;  // CU_DBLOCK (0x4)
    localparam GC_DEBUG_TAG_ray_gen_type  GC_DEBUG_TAG_RAY_GEN_URI             = 3'h5;  // URI (0x5)


  //Ray Task Type of the RAY_DEBUG_TAG 
    localparam GC_DEBUG_TAG_ray_tasktype_type  GC_DEBUG_TAG_RAY_TASKTYPE_PRIMARY  = 3'h0;  // PRIMARY (0)
    localparam GC_DEBUG_TAG_ray_tasktype_type  GC_DEBUG_TAG_RAY_TASKTYPE_MISS  = 3'h1;  // MISS (0x1)
    localparam GC_DEBUG_TAG_ray_tasktype_type  GC_DEBUG_TAG_RAY_TASKTYPE_CLOSE_HIT  = 3'h2;  // CLOSE_HIT (0x2)
    localparam GC_DEBUG_TAG_ray_tasktype_type  GC_DEBUG_TAG_RAY_TASKTYPE_CALL  = 3'h3;  // CALL (0x3)
    localparam GC_DEBUG_TAG_ray_tasktype_type  GC_DEBUG_TAG_RAY_TASKTYPE_TRAVERSE  = 3'h4;  // TRAVERSE (0x4)
    localparam GC_DEBUG_TAG_ray_tasktype_type  GC_DEBUG_TAG_RAY_TASKTYPE_UNIFORM  = 3'h5;  // UNIFORM (0x5)


  // (VTX)
    localparam [2 : 0]    GC_DEBUG_TAG_VTX_DM                                   = 3'h0;
    localparam integer GC_DEBUG_TAG_VTX_DM_FIELDWIDTH = 3;
    localparam [14 : 3]   GC_DEBUG_TAG_VTX_KICK                                 = 12'h0;
    localparam integer GC_DEBUG_TAG_VTX_KICK_FIELDWIDTH = 12;
    localparam [18 : 15]   GC_DEBUG_TAG_VTX_GENERATION                          = 4'h0;
    localparam integer GC_DEBUG_TAG_VTX_GENERATION_FIELDWIDTH = 4;
    localparam [26 : 19]   GC_DEBUG_TAG_VTX_SPC                                 = 8'h0;
    localparam integer GC_DEBUG_TAG_VTX_SPC_FIELDWIDTH = 8;
    localparam [58 : 27]   GC_DEBUG_TAG_VTX_PIM                                 = 32'h0;
    localparam integer GC_DEBUG_TAG_VTX_PIM_FIELDWIDTH = 32;
    localparam [90 : 59]   GC_DEBUG_TAG_VTX_OBJECT                              = 32'h0;
    localparam integer GC_DEBUG_TAG_VTX_OBJECT_FIELDWIDTH = 32;
    localparam [122 : 91]   GC_DEBUG_TAG_VTX_BLOCK_ID                           = 32'h0;
    localparam integer GC_DEBUG_TAG_VTX_BLOCK_ID_FIELDWIDTH = 32;
    localparam [124 : 123]   GC_DEBUG_TAG_VTX_DATATYPE                          = 2'h0;
    localparam integer GC_DEBUG_TAG_VTX_DATATYPE_FIELDWIDTH = 2;
    localparam [130 : 125]   GC_DEBUG_TAG_VTX_VCECOUNT                          = 6'h0;
    localparam integer GC_DEBUG_TAG_VTX_VCECOUNT_FIELDWIDTH = 6;
    localparam [162 : 131]   GC_DEBUG_TAG_VTX_TASK                              = 32'h0;
    localparam integer GC_DEBUG_TAG_VTX_TASK_FIELDWIDTH = 32;
    localparam [169 : 163]   GC_DEBUG_TAG_VTX_INST_0                            = 7'h0;
    localparam integer GC_DEBUG_TAG_VTX_INST_0_FIELDWIDTH = 7;
    localparam [176 : 170]   GC_DEBUG_TAG_VTX_INST_1                            = 7'h0;
    localparam integer GC_DEBUG_TAG_VTX_INST_1_FIELDWIDTH = 7;
    localparam [192 : 177]   GC_DEBUG_TAG_VTX_BASE_ADDR                         = 16'h0;
    localparam integer GC_DEBUG_TAG_VTX_BASE_ADDR_FIELDWIDTH = 16;
    localparam [208 : 193]   GC_DEBUG_TAG_VTX_INSTRUCTION_ID                    = 16'h0;
    localparam integer GC_DEBUG_TAG_VTX_INSTRUCTION_ID_FIELDWIDTH = 16;
    localparam [211 : 209]   GC_DEBUG_TAG_VTX_GPU_ID                            = 3'h0;
    localparam integer GC_DEBUG_TAG_VTX_GPU_ID_FIELDWIDTH = 3;


  // (TSV)
    localparam [2 : 0]    GC_DEBUG_TAG_TSV_DM                                   = 3'h0;
    localparam integer GC_DEBUG_TAG_TSV_DM_FIELDWIDTH = 3;
    localparam [14 : 3]   GC_DEBUG_TAG_TSV_KICK                                 = 12'h0;
    localparam integer GC_DEBUG_TAG_TSV_KICK_FIELDWIDTH = 12;
    localparam [18 : 15]   GC_DEBUG_TAG_TSV_GENERATION                          = 4'h0;
    localparam integer GC_DEBUG_TAG_TSV_GENERATION_FIELDWIDTH = 4;
    localparam [26 : 19]   GC_DEBUG_TAG_TSV_SPC                                 = 8'h0;
    localparam integer GC_DEBUG_TAG_TSV_SPC_FIELDWIDTH = 8;
    localparam [58 : 27]   GC_DEBUG_TAG_TSV_PIM                                 = 32'h0;
    localparam integer GC_DEBUG_TAG_TSV_PIM_FIELDWIDTH = 32;
    localparam [90 : 59]   GC_DEBUG_TAG_TSV_OBJECT                              = 32'h0;
    localparam integer GC_DEBUG_TAG_TSV_OBJECT_FIELDWIDTH = 32;
    localparam [122 : 91]   GC_DEBUG_TAG_TSV_BLOCK_ID                           = 32'h0;
    localparam integer GC_DEBUG_TAG_TSV_BLOCK_ID_FIELDWIDTH = 32;
    localparam [124 : 123]   GC_DEBUG_TAG_TSV_DATATYPE                          = 2'h0;
    localparam integer GC_DEBUG_TAG_TSV_DATATYPE_FIELDWIDTH = 2;
    localparam [130 : 125]   GC_DEBUG_TAG_TSV_VCECOUNT                          = 6'h0;
    localparam integer GC_DEBUG_TAG_TSV_VCECOUNT_FIELDWIDTH = 6;
    localparam [162 : 131]   GC_DEBUG_TAG_TSV_TASK                              = 32'h0;
    localparam integer GC_DEBUG_TAG_TSV_TASK_FIELDWIDTH = 32;
    localparam [169 : 163]   GC_DEBUG_TAG_TSV_INST_0                            = 7'h0;
    localparam integer GC_DEBUG_TAG_TSV_INST_0_FIELDWIDTH = 7;
    localparam [176 : 170]   GC_DEBUG_TAG_TSV_INST_1                            = 7'h0;
    localparam integer GC_DEBUG_TAG_TSV_INST_1_FIELDWIDTH = 7;
    localparam [192 : 177]   GC_DEBUG_TAG_TSV_BASE_ADDR                         = 16'h0;
    localparam integer GC_DEBUG_TAG_TSV_BASE_ADDR_FIELDWIDTH = 16;
    localparam [208 : 193]   GC_DEBUG_TAG_TSV_INSTRUCTION_ID                    = 16'h0;
    localparam integer GC_DEBUG_TAG_TSV_INSTRUCTION_ID_FIELDWIDTH = 16;
    localparam [211 : 209]   GC_DEBUG_TAG_TSV_GPU_ID                            = 3'h0;
    localparam integer GC_DEBUG_TAG_TSV_GPU_ID_FIELDWIDTH = 3;


  // (CMP)
    localparam [2 : 0]    GC_DEBUG_TAG_CMP_DM                                   = 3'h0;
    localparam integer GC_DEBUG_TAG_CMP_DM_FIELDWIDTH = 3;
    localparam [14 : 3]   GC_DEBUG_TAG_CMP_KICK                                 = 12'h0;
    localparam integer GC_DEBUG_TAG_CMP_KICK_FIELDWIDTH = 12;
    localparam [18 : 15]   GC_DEBUG_TAG_CMP_GENERATION                          = 4'h0;
    localparam integer GC_DEBUG_TAG_CMP_GENERATION_FIELDWIDTH = 4;
    localparam [50 : 19]   GC_DEBUG_TAG_CMP_BLOCK_ID                            = 32'h0;
    localparam integer GC_DEBUG_TAG_CMP_BLOCK_ID_FIELDWIDTH = 32;
    localparam [82 : 51]   GC_DEBUG_TAG_CMP_GROUP_ID                            = 32'h0;
    localparam integer GC_DEBUG_TAG_CMP_GROUP_ID_FIELDWIDTH = 32;
    localparam [114 : 83]   GC_DEBUG_TAG_CMP_TASK                               = 32'h0;
    localparam integer GC_DEBUG_TAG_CMP_TASK_FIELDWIDTH = 32;
    localparam [121 : 115]   GC_DEBUG_TAG_CMP_INST_0                            = 7'h0;
    localparam integer GC_DEBUG_TAG_CMP_INST_0_FIELDWIDTH = 7;
    localparam [128 : 122]   GC_DEBUG_TAG_CMP_INST_1                            = 7'h0;
    localparam integer GC_DEBUG_TAG_CMP_INST_1_FIELDWIDTH = 7;
    localparam [144 : 129]   GC_DEBUG_TAG_CMP_BASE_ADDR                         = 16'h0;
    localparam integer GC_DEBUG_TAG_CMP_BASE_ADDR_FIELDWIDTH = 16;
    localparam [160 : 145]   GC_DEBUG_TAG_CMP_INSTRUCTION_ID                    = 16'h0;
    localparam integer GC_DEBUG_TAG_CMP_INSTRUCTION_ID_FIELDWIDTH = 16;
    localparam [163 : 161]   GC_DEBUG_TAG_CMP_GPU_ID                            = 3'h0;
    localparam integer GC_DEBUG_TAG_CMP_GPU_ID_FIELDWIDTH = 3;

    localparam [166 : 164]   GC_DEBUG_TAG_CMP_SUBGROUPID                = 3'd0;
    localparam integer       GC_DEBUG_TAG_CMP_SUBGROUPID_FIELDWIDTH     = 3;
    localparam [167 : 167]   GC_DEBUG_TAG_CMP_TEMPALLOCATED             = 1'd0;
    localparam integer       GC_DEBUG_TAG_CMP_TEMPALLOCATED_FIELDWIDTH  = 1;
    localparam [176 : 168]   GC_DEBUG_TAG_CMP_TEMPBASEADDR              = 9'd0;
    localparam integer       GC_DEBUG_TAG_CMP_TEMPBASEADDR_FIELDWIDTH   = 9;
    localparam [177 : 177]   GC_DEBUG_TAG_CMP_ATTRALLOCATED             = 1'd0;
    localparam integer       GC_DEBUG_TAG_CMP_ATTRALLOCATED_FIELDWIDTH  = 1;
    localparam [186 : 178]   GC_DEBUG_TAG_CMP_ATTRBASEADDR              = 9'd0;
    localparam integer       GC_DEBUG_TAG_CMP_ATTRBASEADDR_FIELDWIDTH   = 9;
    localparam [193 : 187]   GC_DEBUG_TAG_CMP_SHAREDBASEADDR            = 7'd0;
    localparam integer       GC_DEBUG_TAG_CMP_SHAREDBASEADDR_FIELDWIDTH = 7;
    localparam [203 : 194]   GC_DEBUG_TAG_CMP_LMSBASEADDR               = 10'd0;
    localparam integer       GC_DEBUG_TAG_CMP_LMSBASEADDR_FIELDWIDTH    = 10;
    localparam [212 : 204]   GC_DEBUG_TAG_CMP_CFSBASEADDR               = 9'd0;
    localparam integer       GC_DEBUG_TAG_CMP_CFSBASEADDR_FIELDWIDTH    = 9;
    localparam [215 : 213]   GC_DEBUG_TAG_CMP_TASKTYPE                  = 3'd0;
    localparam integer       GC_DEBUG_TAG_CMP_TASKTYPE_FIELDWIDTH       = 3;
    localparam [216 : 216]   GC_DEBUG_TAG_CMP_MULTIWG                   = 1'd0;
    localparam integer       GC_DEBUG_TAG_CMP_MULTIWG_FIELDWIDTH        = 1;
    localparam [222 : 217]   GC_DEBUG_TAG_CMP_TASKID                    = 6'd0;
    localparam integer       GC_DEBUG_TAG_CMP_TASKID_FIELDWIDTH         = 6;
    

  // (F2D)
    localparam [2 : 0]    GC_DEBUG_TAG_F2D_DM                                   = 3'h0;
    localparam integer GC_DEBUG_TAG_F2D_DM_FIELDWIDTH = 3;
    localparam [14 : 3]   GC_DEBUG_TAG_F2D_KICK                                 = 12'h0;
    localparam integer GC_DEBUG_TAG_F2D_KICK_FIELDWIDTH = 12;
    localparam [30 : 15]   GC_DEBUG_TAG_F2D_BLIT                                = 16'h0;
    localparam integer GC_DEBUG_TAG_F2D_BLIT_FIELDWIDTH = 16;
    localparam [41 : 31]   GC_DEBUG_TAG_F2D_TILE_X                              = 11'h0;
    localparam integer GC_DEBUG_TAG_F2D_TILE_X_FIELDWIDTH = 11;
    localparam [52 : 42]   GC_DEBUG_TAG_F2D_TILE_Y                              = 11'h0;
    localparam integer GC_DEBUG_TAG_F2D_TILE_Y_FIELDWIDTH = 11;
    localparam [56 : 53]   GC_DEBUG_TAG_F2D_GENERATION                          = 4'h0;
    localparam integer GC_DEBUG_TAG_F2D_GENERATION_FIELDWIDTH = 4;
    localparam [88 : 57]   GC_DEBUG_TAG_F2D_OBJECT                              = 32'h0;
    localparam integer GC_DEBUG_TAG_F2D_OBJECT_FIELDWIDTH = 32;
    localparam [120 : 89]   GC_DEBUG_TAG_F2D_TASK                               = 32'h0;
    localparam integer GC_DEBUG_TAG_F2D_TASK_FIELDWIDTH = 32;
    localparam [122 : 121]   GC_DEBUG_TAG_F2D_INST_IN_BLOCK                     = 2'h0;
    localparam integer GC_DEBUG_TAG_F2D_INST_IN_BLOCK_FIELDWIDTH = 2;
    localparam [127 : 121]   GC_DEBUG_TAG_F2D_INST_IN_TASK                      = 7'h0;
    localparam integer GC_DEBUG_TAG_F2D_INST_IN_TASK_FIELDWIDTH = 7;
    localparam [128 : 128]   GC_DEBUG_TAG_F2D_PHASE                             = 1'h0;
    localparam integer GC_DEBUG_TAG_F2D_PHASE_FIELDWIDTH = 1;
    localparam [132 : 129]   GC_DEBUG_TAG_F2D_SAMPLE                            = 4'h0;
    localparam integer GC_DEBUG_TAG_F2D_SAMPLE_FIELDWIDTH = 4;
    localparam [136 : 133]   GC_DEBUG_TAG_F2D_BLOCK_X_0                         = 4'h0;
    localparam integer GC_DEBUG_TAG_F2D_BLOCK_X_0_FIELDWIDTH = 4;
    localparam [140 : 137]   GC_DEBUG_TAG_F2D_BLOCK_Y_0                         = 4'h0;
    localparam integer GC_DEBUG_TAG_F2D_BLOCK_Y_0_FIELDWIDTH = 4;
    localparam [144 : 141]   GC_DEBUG_TAG_F2D_BLOCK_X_1                         = 4'h0;
    localparam integer GC_DEBUG_TAG_F2D_BLOCK_X_1_FIELDWIDTH = 4;
    localparam [148 : 145]   GC_DEBUG_TAG_F2D_BLOCK_Y_1                         = 4'h0;
    localparam integer GC_DEBUG_TAG_F2D_BLOCK_Y_1_FIELDWIDTH = 4;
    localparam [164 : 149]   GC_DEBUG_TAG_F2D_BASE_ADDR                         = 16'h0;
    localparam integer GC_DEBUG_TAG_F2D_BASE_ADDR_FIELDWIDTH = 16;
    localparam [180 : 165]   GC_DEBUG_TAG_F2D_INSTRUCTION_ID                    = 16'h0;
    localparam integer GC_DEBUG_TAG_F2D_INSTRUCTION_ID_FIELDWIDTH = 16;
    localparam [436 : 181]   GC_DEBUG_TAG_F2D_BLOCKS_COORDS                     = 256'h0;
    localparam integer GC_DEBUG_TAG_F2D_BLOCKS_COORDS_FIELDWIDTH = 256;
    localparam [439 : 437]   GC_DEBUG_TAG_F2D_GPU_ID                            = 3'h0;
    localparam integer GC_DEBUG_TAG_F2D_GPU_ID_FIELDWIDTH = 3;


  // (PXL)
    localparam [2 : 0]    GC_DEBUG_TAG_PXL_DM                                   = 3'h0;
    localparam integer GC_DEBUG_TAG_PXL_DM_FIELDWIDTH = 3;
    localparam [14 : 3]   GC_DEBUG_TAG_PXL_KICK                                 = 12'h0;
    localparam integer GC_DEBUG_TAG_PXL_KICK_FIELDWIDTH = 12;
    localparam [25 : 15]   GC_DEBUG_TAG_PXL_TILE_X                              = 11'h0;
    localparam integer GC_DEBUG_TAG_PXL_TILE_X_FIELDWIDTH = 11;
    localparam [36 : 26]   GC_DEBUG_TAG_PXL_TILE_Y                              = 11'h0;
    localparam integer GC_DEBUG_TAG_PXL_TILE_Y_FIELDWIDTH = 11;
    localparam [40 : 37]   GC_DEBUG_TAG_PXL_GENERATION                          = 4'h0;
    localparam integer GC_DEBUG_TAG_PXL_GENERATION_FIELDWIDTH = 4;
    localparam [72 : 41]   GC_DEBUG_TAG_PXL_OBJECT                              = 32'h0;
    localparam integer GC_DEBUG_TAG_PXL_OBJECT_FIELDWIDTH = 32;
    localparam [74 : 73]   GC_DEBUG_TAG_PXL_SUBOBJECT                           = 2'h0;
    localparam integer GC_DEBUG_TAG_PXL_SUBOBJECT_FIELDWIDTH = 2;
    localparam [106 : 75]   GC_DEBUG_TAG_PXL_TASK                               = 32'h0;
    localparam integer GC_DEBUG_TAG_PXL_TASK_FIELDWIDTH = 32;
    localparam [108 : 107]   GC_DEBUG_TAG_PXL_INST_IN_BLOCK                     = 2'h0;
    localparam integer GC_DEBUG_TAG_PXL_INST_IN_BLOCK_FIELDWIDTH = 2;
    localparam [113 : 107]   GC_DEBUG_TAG_PXL_INST_IN_TASK                      = 7'h0;
    localparam integer GC_DEBUG_TAG_PXL_INST_IN_TASK_FIELDWIDTH = 7;
    localparam [114 : 114]   GC_DEBUG_TAG_PXL_PHASE                             = 1'h0;
    localparam integer GC_DEBUG_TAG_PXL_PHASE_FIELDWIDTH = 1;
    localparam [118 : 115]   GC_DEBUG_TAG_PXL_SAMPLE                            = 4'h0;
    localparam integer GC_DEBUG_TAG_PXL_SAMPLE_FIELDWIDTH = 4;
    localparam [122 : 119]   GC_DEBUG_TAG_PXL_BLOCK_X_0                         = 4'h0;
    localparam integer GC_DEBUG_TAG_PXL_BLOCK_X_0_FIELDWIDTH = 4;
    localparam [126 : 123]   GC_DEBUG_TAG_PXL_BLOCK_Y_0                         = 4'h0;
    localparam integer GC_DEBUG_TAG_PXL_BLOCK_Y_0_FIELDWIDTH = 4;
    localparam [130 : 127]   GC_DEBUG_TAG_PXL_BLOCK_X_1                         = 4'h0;
    localparam integer GC_DEBUG_TAG_PXL_BLOCK_X_1_FIELDWIDTH = 4;
    localparam [134 : 131]   GC_DEBUG_TAG_PXL_BLOCK_Y_1                         = 4'h0;
    localparam integer GC_DEBUG_TAG_PXL_BLOCK_Y_1_FIELDWIDTH = 4;
    localparam [135 : 135]   GC_DEBUG_TAG_PXL_PUNCHTHROUGH                      = 1'h0;
    localparam integer GC_DEBUG_TAG_PXL_PUNCHTHROUGH_FIELDWIDTH = 1;
    localparam [151 : 136]   GC_DEBUG_TAG_PXL_BASE_ADDR                         = 16'h0;
    localparam integer GC_DEBUG_TAG_PXL_BASE_ADDR_FIELDWIDTH = 16;
    localparam [167 : 152]   GC_DEBUG_TAG_PXL_INSTRUCTION_ID                    = 16'h0;
    localparam integer GC_DEBUG_TAG_PXL_INSTRUCTION_ID_FIELDWIDTH = 16;
    localparam [423 : 168]   GC_DEBUG_TAG_PXL_BLOCKS_COORDS                     = 256'h0;
    localparam integer GC_DEBUG_TAG_PXL_BLOCKS_COORDS_FIELDWIDTH = 256;
    localparam [426 : 424]   GC_DEBUG_TAG_PXL_GPU_ID                            = 3'h0;
    localparam integer GC_DEBUG_TAG_PXL_GPU_ID_FIELDWIDTH = 3;


  // (RAY)
    localparam [2 : 0]    GC_DEBUG_TAG_RAY_DM                                   = 3'h0;
    localparam integer GC_DEBUG_TAG_RAY_DM_FIELDWIDTH = 3;
    localparam [14 : 3]   GC_DEBUG_TAG_RAY_KICK                                 = 12'h0;
    localparam integer GC_DEBUG_TAG_RAY_KICK_FIELDWIDTH = 12;
    localparam [17 : 15]   GC_DEBUG_TAG_RAY_GPU_ID                              = 3'h0;
    localparam integer GC_DEBUG_TAG_RAY_GPU_ID_FIELDWIDTH = 3;
    localparam [20 : 18]   GC_DEBUG_TAG_RAY_GENERATION                          = 3'h0;
    localparam integer GC_DEBUG_TAG_RAY_GENERATION_FIELDWIDTH = 3;
    localparam [23 : 21]   GC_DEBUG_TAG_RAY_TASK_TYPE                           = 3'h0;
    localparam integer GC_DEBUG_TAG_RAY_TASK_TYPE_FIELDWIDTH = 3;
    localparam [55 : 24]   GC_DEBUG_TAG_RAY_DISPATCH_ID                         = 32'h0;
    localparam integer GC_DEBUG_TAG_RAY_DISPATCH_ID_FIELDWIDTH = 32;
    localparam [56 : 56]   GC_DEBUG_TAG_RAY_BROADCAST                           = 1'h0;
    localparam integer GC_DEBUG_TAG_RAY_BROADCAST_FIELDWIDTH = 1;
    localparam [64 : 57]   GC_DEBUG_TAG_RAY_GROUP                               = 8'h0;
    localparam integer GC_DEBUG_TAG_RAY_GROUP_FIELDWIDTH = 8;
    localparam [72 : 65]   GC_DEBUG_TAG_RAY_SUB_GROUP                           = 8'h0;
    localparam integer GC_DEBUG_TAG_RAY_SUB_GROUP_FIELDWIDTH = 8;
    localparam [104 : 73]   GC_DEBUG_TAG_RAY_TASK                               = 32'h0;
    localparam integer GC_DEBUG_TAG_RAY_TASK_FIELDWIDTH = 32;
    localparam [111 : 105]   GC_DEBUG_TAG_RAY_INSTANCE_NUM                      = 7'h0;
    localparam integer GC_DEBUG_TAG_RAY_INSTANCE_NUM_FIELDWIDTH = 7;
    localparam [127 : 112]   GC_DEBUG_TAG_RAY_LAUNCH_ID_X                       = 16'h0;
    localparam integer GC_DEBUG_TAG_RAY_LAUNCH_ID_X_FIELDWIDTH = 16;
    localparam [143 : 128]   GC_DEBUG_TAG_RAY_LAUNCH_ID_Y                       = 16'h0;
    localparam integer GC_DEBUG_TAG_RAY_LAUNCH_ID_Y_FIELDWIDTH = 16;
    localparam [159 : 144]   GC_DEBUG_TAG_RAY_LAUNCH_ID_Z                       = 16'h0;
    localparam integer GC_DEBUG_TAG_RAY_LAUNCH_ID_Z_FIELDWIDTH = 16;
    localparam [160 : 160]   GC_DEBUG_TAG_RAY_NOT_DETERMINISTIC                 = 1'h0;
    localparam integer GC_DEBUG_TAG_RAY_NOT_DETERMINISTIC_FIELDWIDTH = 1;
    localparam [176 : 161]   GC_DEBUG_TAG_RAY_BASE_ADDR                         = 16'h0;
    localparam integer GC_DEBUG_TAG_RAY_BASE_ADDR_FIELDWIDTH = 16;
    localparam [192 : 177]   GC_DEBUG_TAG_RAY_INSTRUCTION_ID                    = 16'h0;
    localparam integer GC_DEBUG_TAG_RAY_INSTRUCTION_ID_FIELDWIDTH = 16;


  // (STM)
    localparam [2 : 0]    GC_DEBUG_TAG_STM_DM                                   = 3'h0;
    localparam integer GC_DEBUG_TAG_STM_DM_FIELDWIDTH = 3;
    localparam [14 : 3]   GC_DEBUG_TAG_STM_KICK                                 = 12'h0;
    localparam integer GC_DEBUG_TAG_STM_KICK_FIELDWIDTH = 12;
    localparam [18 : 15]   GC_DEBUG_TAG_STM_GENERATION                          = 4'h0;
    localparam integer GC_DEBUG_TAG_STM_GENERATION_FIELDWIDTH = 4;
    localparam [26 : 19]   GC_DEBUG_TAG_STM_SPC                                 = 8'h0;
    localparam integer GC_DEBUG_TAG_STM_SPC_FIELDWIDTH = 8;
    localparam [58 : 27]   GC_DEBUG_TAG_STM_PIM                                 = 32'h0;
    localparam integer GC_DEBUG_TAG_STM_PIM_FIELDWIDTH = 32;
    localparam [90 : 59]   GC_DEBUG_TAG_STM_BLOCK_ID                            = 32'h0;
    localparam integer GC_DEBUG_TAG_STM_BLOCK_ID_FIELDWIDTH = 32;
    localparam [122 : 91]   GC_DEBUG_TAG_STM_TASK                               = 32'h0;
    localparam integer GC_DEBUG_TAG_STM_TASK_FIELDWIDTH = 32;
    localparam [138 : 123]   GC_DEBUG_TAG_STM_BASE_ADDR                         = 16'h0;
    localparam integer GC_DEBUG_TAG_STM_BASE_ADDR_FIELDWIDTH = 16;
    localparam [154 : 139]   GC_DEBUG_TAG_STM_INSTRUCTION_ID                    = 16'h0;
    localparam integer GC_DEBUG_TAG_STM_INSTRUCTION_ID_FIELDWIDTH = 16;
    localparam [157 : 155]   GC_DEBUG_TAG_STM_GPU_ID                            = 3'h0;
    localparam integer GC_DEBUG_TAG_STM_GPU_ID_FIELDWIDTH = 3;

endpackage : gc_debug_tag_pack_

`endif // `ifndef GC_DEBUG_TAG_PACK_SV_DEFINE
