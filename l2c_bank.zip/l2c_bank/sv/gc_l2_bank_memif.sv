// ---------------------------------------------------------------------------------
// Project Name  : IC_Design
// Author        : liusm
// Email         : liusm@innosilicon.com.cn
// Create On     : 2025/01/03 15:03
// Last Modified : 2025/09/09 18:45
// File Name     : gc_l2_bank_memif.sv
// Description   :
// 
// Copyright (c) 2025 Innosilicon.
// ALL RIGHTS RESERVED
// 
// ---------------------------------------------------------------------------------
// Modification History:
// Date         By              Version                 Change Description
// ---------------------------------------------------------------------------------
// 2025/01/03   liusm           1.0                     Original
// 
// ----------------------------------------------------------------------------------


module gc_l2_bank_memif
import gc_l2_bank_pkg::*;
import gpc_gfx_timing_buffer_pack_::*;
import nsp_req_pkg::*;
import nsp_rsp_pkg::*;
import sched_bank_pkg::*;
import bank_sched_pkg::*;
(
      input    logic                               clk
,     input    logic                               resetn

,     output   logic                               memif_idle
// tagctrl interface 
,     input    logic                               tagctrl_memif_valid
,     output   logic                               tagctrl_memif_ready
,     input    tagctrl_memif_record_type           tagctrl_memif_rec

,     output   logic                               memif_tagctrl_valid
,     output   memif_tagctrl_record_type           memif_tagctrl_rec
,     input    logic                               tagctrl_memif_wb_finish


,     input    logic                               [L2_NUM_RCTRL-1:0]   rctrl_memif_wb_done_valid
,     input    rctrl_isched_record_type            [L2_NUM_RCTRL-1:0]   rctrl_memif_wb_done_rec

,     output   logic                               memif_sched_valid
,     input    logic                               memif_sched_ready
,     output   bank_sched_data_bus_t               memif_sched_rec


,     input    logic                               sched_memif_valid
,     output   logic                               sched_memif_ready
,     input    sched_bank_data_bus_t               sched_memif_rec


,     output   logic                               memif_tagctrl_cfi_decrease_valid
,     output   logic  [L2_MAX_CFI_BITS-1:0]        memif_tagctrl_cfi_id

,     output   logic                               [L2_NUM_RCTRL-1:0]   memif_rctrl_valid
,     input    logic                               [L2_NUM_RCTRL-1:0]   memif_rctrl_ready
,     output   memif_rctrl_record_type             [L2_NUM_RCTRL-1:0]   memif_rctrl_rec

,     output   logic                               memif_wdc_valid
,     input    logic                               memif_wdc_ready
,     output   memif_wdc_record_type               memif_wdc_rec

,     output   logic                               memif_align_valid
,     input    logic                               memif_align_ready
,     output   memif_align_record_type             memif_align_rec

,     input    logic                               wdc_memif_wdata_valid
,     output   logic                               wdc_memif_wdata_ready
,     input    wdc_memif_wdata_record_type         wdc_memif_wdata_rec


,     output   logic                               nsp_req_valid
,     input    logic                               nsp_req_ready
,     output   nsp_req_data_bus_t                  nsp_req_rec

,     input    logic                               nsp_rsp_valid
,     output   logic                               nsp_rsp_ready
,     input    nsp_rsp_data_bus_t                  nsp_rsp_rec

,     output   logic [2:0]                         gc_cr_l2b_error

,     output   logic                               l2b_frommemsch_nsp_rtn_wl
,     output   logic                               l2b_frommemsch_nsp_rtn_bp
,     output   logic                               l2b_tomemsch_nsp_read_bl_eq1_wl
,     output   logic                               l2b_tomemsch_nsp_read_bl_eq3_wl
,     output   logic                               l2b_tomemsch_nsp_read_bl_eq5_wl
,     output   logic                               l2b_tomemsch_nsp_read_bl_eq7_wl
,     output   logic                               l2b_tomemsch_nsp_write_bl_eq1_wl
,     output   logic                               l2b_tomemsch_nsp_write_bl_eq3_wl
,     output   logic                               l2b_tomemsch_nsp_write_bl_eq5_wl
,     output   logic                               l2b_tomemsch_nsp_write_bl_eq7_wl


,     output   logic                               l2b_memif_to_ddr_read_wl
,     output   logic                               l2b_memif_to_ddr_read_stall_by_rob
,     output   logic                               l2b_memif_to_ddr_read_stall_by_ddr
,     output   logic                               l2b_memif_to_ddr_read_stall_by_trid
,     output   logic                               l2b_memif_to_ddr_write_wl
,     output   logic                               l2b_memif_to_ddr_write_stall_by_data_sync
,     output   logic                               l2b_memif_to_ddr_write_stall_by_ddr
,     output   logic                               l2b_memif_to_ddr_write_stall_by_trid
,     output   logic                               l2b_memif_memreq_full
,     output   logic                               l2b_memif_smp_read_req_num
,     output   logic                               l2b_memif_smp_read_req_sum

,     input   logic [ 3 : 0 ]                      gc_cr_ddr_hash_config_reg0_row_id_bit0        
,     input   logic [ 3 : 0 ]                      gc_cr_ddr_hash_config_reg0_row_id_bit1        
,     input   logic [ 3 : 0 ]                      gc_cr_ddr_hash_config_reg0_row_id_bit2        
,     input   logic [ 3 : 0 ]                      gc_cr_ddr_hash_config_reg0_row_id_bit3        
,     input   logic [ 3 : 0 ]                      gc_cr_ddr_hash_config_reg0_row_id_bit4        
,     input   logic [ 3 : 0 ]                      gc_cr_ddr_hash_config_reg0_row_id_bit5        
,     input   logic [ 3 : 0 ]                      gc_cr_ddr_hash_config_reg0_row_id_bit6        
,     input   logic [ 3 : 0 ]                      gc_cr_ddr_hash_config_reg0_row_id_bit7        
,     input   logic [ 3 : 0 ]                      gc_cr_ddr_hash_config_reg0_row_id_bit8        
,     input   logic [ 3 : 0 ]                      gc_cr_ddr_hash_config_reg0_row_id_bit9        
,     input   logic [ 3 : 0 ]                      gc_cr_ddr_hash_config_reg0_row_id_bit10       
,     input   logic [ 3 : 0 ]                      gc_cr_ddr_hash_config_reg0_row_id_bit11       
,     input   logic [ 3 : 0 ]                      gc_cr_ddr_hash_config_reg1_row_id_bit12       
,     input   logic [ 3 : 0 ]                      gc_cr_ddr_hash_config_reg1_row_id_bit13       
,     input   logic [ 3 : 0 ]                      gc_cr_ddr_hash_config_reg1_row_id_bit14       
,     input   logic [ 3 : 0 ]                      gc_cr_ddr_hash_config_reg1_row_id_bit15       
,     input   logic [ 3 : 0 ]                      gc_cr_ddr_hash_config_reg1_row_id_bit16       
,     input   logic [ 3 : 0 ]                      gc_cr_ddr_hash_config_reg1_row_id_bit17       
,     input   logic [ 3 : 0 ]                      gc_cr_ddr_hash_config_reg1_row_id_bit18       
,     input   logic [ 3 : 0 ]                      gc_cr_ddr_hash_config_reg1_row_id_bit19       
,     input   logic [ 3 : 0 ]                      gc_cr_ddr_hash_config_reg1_row_id_bit20       
,     input   logic [ 3 : 0 ]                      gc_cr_ddr_hash_config_reg1_row_id_bit21       
,     input   logic [ 3 : 0 ]                      gc_cr_ddr_hash_config_reg1_row_id_bit22       
,     input   logic [ 3 : 0 ]                      gc_cr_ddr_hash_config_reg1_row_id_bit23       
,     input   logic [ 1 : 0 ]                      gc_cr_l2_function_enable_hash_mode            
,     input   logic                                gc_l2_mem_scheduler_enable

,     input    logic [ 4 : 0 ]                     gc_cr_l2_mem_sched_bank_offset_bank_id_bit0
,     input    logic [ 4 : 0 ]                     gc_cr_l2_mem_sched_bank_offset_bank_id_bit1
,     input    logic [ 4 : 0 ]                     gc_cr_l2_mem_sched_bank_offset_bank_id_bit2
,     input    logic [ 4 : 0 ]                     gc_cr_l2_mem_sched_bank_offset_bank_id_bit3
,     input    logic [ 4 : 0 ]                     gc_cr_l2_mem_sched_bank_offset_bank_id_bit4

,     input    logic [ 4 : 0 ]                     gc_cr_l2_mem_sched_row_parti_row_id_bit0
,     input    logic [ 4 : 0 ]                     gc_cr_l2_mem_sched_row_parti_row_id_bit1
,     input    logic [ 4 : 0 ]                     gc_cr_l2_mem_sched_row_parti_row_id_bit2
,     input    logic [ 4 : 0 ]                     gc_cr_l2_mem_sched_row_parti_row_id_bit3
,     input    logic [ 4 : 0 ]                     gc_cr_l2_mem_sched_row_parti_row_id_bit4
,     input    logic [ 4 : 0 ]                     gc_cr_l2_mem_sched_row_parti_row_id_bit5
,     input    logic [ 4 : 0 ]                     gc_cr_l2_mem_sched_row_parti_row_id_bit6
,     input    logic [ 4 : 0 ]                     gc_cr_l2_mem_sched_row_parti_row_id_bit7
,     input    logic [ 4 : 0 ]                     gc_cr_l2_mem_sched_row_partii_row_id_bit8
,     input    logic [ 4 : 0 ]                     gc_cr_l2_mem_sched_row_partii_row_id_bit9
,     input    logic [ 4 : 0 ]                     gc_cr_l2_mem_sched_row_partii_row_id_bit10
,     input    logic [ 4 : 0 ]                     gc_cr_l2_mem_sched_row_partii_row_id_bit11
,     input    logic [ 4 : 0 ]                     gc_cr_l2_mem_sched_row_partii_row_id_bit12
,     input    logic [ 4 : 0 ]                     gc_cr_l2_mem_sched_row_partii_row_id_bit13
,     input    logic [ 4 : 0 ]                     gc_cr_l2_mem_sched_row_partii_row_id_bit14
,     input    logic [ 4 : 0 ]                     gc_cr_l2_mem_sched_row_partii_row_id_bit15
,     input    logic [ 4 : 0 ]                     gc_cr_l2_mem_sched_row_partiii_row_id_bit16
,     input    logic [ 4 : 0 ]                     gc_cr_l2_mem_sched_row_partiii_row_id_bit17

,     input    logic [3 : 0]                       gc_cr_l2_function_enable_ddr_capacity
,     input    logic                               tst_gclkenable
// NSP interface
);

   logic                                                 tagctrl_memif_tbuff_valid   ;
   logic                                                 tagctrl_memif_tbuff_ready   ;
   tagctrl_memif_record_type                             tagctrl_memif_tbuff_rec     ;
   

   req_buffer_record_type [L2_MEM_SCHED_INSTR_DEPTH-1:0] req_buffer_entries          ;
   logic [L2_MEM_SCHED_INSTR_DEPTH-1:0]                  req_buffer_valids           ;

   logic                                                 split_stage_valid           ;
   logic                                                 split_stage_ready           ;
   req_buffer_record_type                                split_stage_rec             ;
   logic                                                 split_stage_tbuff_valid     ;
   logic                                                 split_stage_tbuff_ready     ;
   req_buffer_record_type                                split_stage_tbuff_rec       ;
   logic                                                 split_stage_wb_issued       ;

   logic                                                 req_allocate_valid          ;
   logic                                                 req_allocate_ready          ;
   logic [L2_MEM_SCHED_INSTR_BITS-1:0]                   req_allocate_index          ;
   logic                                                 req_allocated               ;
   logic [L2_MEM_SCHED_INSTR_BITS-1:0]                   req_allocated_index         ;

   logic                   [L2_NUM_NSP_ID-1:0]           nspid_valids                ;
   nsp_entry_record_type   [L2_NUM_NSP_ID-1:0]           nsp_entries                 ;
   nsp_entry_record_type   [L2_NUM_NSP_ID-1:0]           n_nsp_entries               ;


   logic                                                 read_tbuff_valid            ;
   logic                                                 read_tbuff_ready            ;
   nsp_entry_record_type                                 read_tbuff_rec              ;
   
   logic                                                 read_rob_valid              ;
   logic                                                 read_rob_ready              ;
   l2_bank_rob_pipe_record_type                          read_rob_rec                ;
   
   logic                                                 readout_valid               ;
   logic                                                 readout_ready               ;
   l2_bank_rob_readout_record_type                       readout_rec                 ;
   
   
   logic                                                 write_valid                 ;
   l2_bank_rob_write_record_type                         write_rec                   ;

   logic                                                 memory_request_valid        ;
   logic                                                 memory_request_ready        ;
   req_buffer_record_type                                memory_request_rec          ;
   logic                                                 n_memory_request_valid        ;
   logic                                                 n_memory_request_ready        ;
   req_buffer_record_type                                n_memory_request_rec          ;
   logic [L2_MEM_SCHED_INSTR_BITS-1:0]                   n_memory_request_buffer_index ;
   logic                                                 memif_wdc_issued            ;

   logic                                                 rob_index_valid             ;
   logic                                                 rob_index_ready             ;
   logic   [L2_ROB_BITS-1:0]                             rob_index                   ;
   logic [1:0]                                           rob_index_size              ;
   logic                                                 rob_index_issued            ;
   logic [L2_ROB_DEPTH-1:0]                              index_freed_mask            ;

   logic                                                 idx_assign_idle             ;
   logic                                                 rob_idle                    ;
   logic                                                 memif_sched_tbuff_valid     ;
   logic                                                 memif_sched_tbuff_ready     ;
   bank_sched_data_bus_t                                 memif_sched_tbuff_rec       ;
   logic                                                 nsp_req_tbuff_valid         ;
   logic                                                 nsp_req_tbuff_ready         ;
   nsp_req_data_bus_t                                    nsp_req_tbuff_rec           ;
   logic                                                 nsp_rsp_tbuff_valid         ;
   logic                                                 nsp_rsp_tbuff_ready         ;
   nsp_rsp_data_bus_t                                    nsp_rsp_tbuff_rec           ;
   logic                                                 sched_memif_tbuff_valid     ;
   logic                                                 sched_memif_tbuff_ready     ;
   sched_bank_data_bus_t                                 sched_memif_tbuff_rec       ;
   logic    [L2_DDR_ROW_BITS-1:0][5:0]                   gc_l2_bank_row_id_offset    ;
   logic    [L2_DDR_BANK_BITS-1:0][5:0]                  gc_l2_bank_bank_id_offset   ;

   logic [L2_NUM_NSP_ID-1:0]                             nsp_entry_mask;
   logic [L2_NSP_ID_BITS-1:0]                            previous_output_index  ;
   logic [L2_NSP_ID_BITS-1:0]                            output_index           ;
   logic                                                 nsp_entry_output_valid ;
   logic                                                 nsp_entry_output_ready ;
   nsp_entry_record_type                                 nsp_entry_output_rec   ;
   logic                                                 latency_fifo_in_valid  ;
   logic                                                 latency_fifo_in_ready  ;
   memory_latency_fifo_record_type                       latency_fifo_in_rec    ;
   logic                                                 latency_fifo_out_valid ;
   logic                                                 latency_fifo_out_ready ;
   memory_latency_fifo_record_type                       latency_fifo_out_rec   ;

   
   always_ff@(posedge clk or negedge resetn) begin 
      if (!resetn) begin
         gc_cr_l2b_error <= '0;
      end
      else if (nsp_rsp_tbuff_valid && nsp_rsp_tbuff_ready && nsp_rsp_tbuff_rec.status == 2'b10) begin
         gc_cr_l2b_error <= nsp_rsp_tbuff_rec.errcode;
      end
   end

   assign gc_l2_bank_row_id_offset[0]  = gc_cr_l2_mem_sched_row_parti_row_id_bit0    + 2'd2;
   assign gc_l2_bank_row_id_offset[1]  = gc_cr_l2_mem_sched_row_parti_row_id_bit1    + 2'd2;
   assign gc_l2_bank_row_id_offset[2]  = gc_cr_l2_mem_sched_row_parti_row_id_bit2    + 2'd2;
   assign gc_l2_bank_row_id_offset[3]  = gc_cr_l2_mem_sched_row_parti_row_id_bit3    + 2'd2;
   assign gc_l2_bank_row_id_offset[4]  = gc_cr_l2_mem_sched_row_parti_row_id_bit4    + 2'd2;
   assign gc_l2_bank_row_id_offset[5]  = gc_cr_l2_mem_sched_row_parti_row_id_bit5    + 2'd2;
   assign gc_l2_bank_row_id_offset[6]  = gc_cr_l2_mem_sched_row_parti_row_id_bit6    + 2'd2;
   assign gc_l2_bank_row_id_offset[7]  = gc_cr_l2_mem_sched_row_parti_row_id_bit7    + 2'd2;
   assign gc_l2_bank_row_id_offset[8]  = gc_cr_l2_mem_sched_row_partii_row_id_bit8   + 2'd2;
   assign gc_l2_bank_row_id_offset[9]  = gc_cr_l2_mem_sched_row_partii_row_id_bit9   + 2'd2;
   assign gc_l2_bank_row_id_offset[10] = gc_cr_l2_mem_sched_row_partii_row_id_bit10  + 2'd2;
   assign gc_l2_bank_row_id_offset[11] = gc_cr_l2_mem_sched_row_partii_row_id_bit11  + 2'd2;
   assign gc_l2_bank_row_id_offset[12] = gc_cr_l2_mem_sched_row_partii_row_id_bit12  + 2'd2;
   assign gc_l2_bank_row_id_offset[13] = gc_cr_l2_mem_sched_row_partii_row_id_bit13  + 2'd2;
   assign gc_l2_bank_row_id_offset[14] = gc_cr_l2_mem_sched_row_partii_row_id_bit14  + 2'd2;
   assign gc_l2_bank_row_id_offset[15] = gc_cr_l2_mem_sched_row_partii_row_id_bit15  + 2'd2;
   assign gc_l2_bank_row_id_offset[16] = gc_cr_l2_mem_sched_row_partiii_row_id_bit16 + 2'd2 ;
   
   assign gc_l2_bank_bank_id_offset[0] = gc_cr_l2_mem_sched_bank_offset_bank_id_bit0 + 2'd2;
   assign gc_l2_bank_bank_id_offset[1] = gc_cr_l2_mem_sched_bank_offset_bank_id_bit1 + 2'd2;
   assign gc_l2_bank_bank_id_offset[2] = gc_cr_l2_mem_sched_bank_offset_bank_id_bit2 + 2'd2;
   assign gc_l2_bank_bank_id_offset[3] = gc_cr_l2_mem_sched_bank_offset_bank_id_bit3 + 2'd2;



   assign memif_idle = ~ tagctrl_memif_tbuff_valid
                       && ~split_stage_tbuff_valid
                       && ~|req_buffer_valids
                       && ~|nspid_valids
                       && ~memif_sched_valid
                       && ~n_memory_request_valid 
                       && ~memory_request_valid
                       && ~latency_fifo_out_valid
                       && ~nsp_req_valid
                       && ~nsp_rsp_tbuff_valid
                       && ~memif_tagctrl_cfi_decrease_valid 
                       && idx_assign_idle 
                       && rob_idle 
                       && ~read_rob_valid 
                       && ~read_tbuff_valid;   
   gpc_gfx_timing_buffer_# (
       .BUFFER_TYPE        ( GPC_GFX_TIMING_BUFFER_PIPE_REG  )
      ,.WIDTH              ( $bits(tagctrl_memif_record_type ) ))
   i_tagctrl_memif_tbuf    (
      .clk                 ( clk                             )
    , .resetn              ( resetn                          )
    , .tbuff_in_valid      ( tagctrl_memif_valid             )
    , .tbuff_in_enable     ( tagctrl_memif_ready             )
    , .tbuff_in_data       ( tagctrl_memif_rec               )
    
    , .tbuff_out_valid     ( tagctrl_memif_tbuff_valid       )
    , .tbuff_out_enable    ( tagctrl_memif_tbuff_ready       )
    , .tbuff_out_data      ( tagctrl_memif_tbuff_rec         ) );
   
   req_buffer_record_type  tagctrl_wb_rec;
   req_buffer_record_type  tagctrl_normal_rec;

   assign tagctrl_wb_rec.memif_instruction     = ST;
   assign tagctrl_wb_rec.cl_instruction        = WB;
   assign tagctrl_wb_rec.axid                  = tagctrl_memif_tbuff_rec.axid;
   assign tagctrl_wb_rec.addr                  = {tagctrl_memif_tbuff_rec.wb_addr_tag, tagctrl_memif_tbuff_rec.set, 8'd0};
   assign tagctrl_wb_rec.set                   = tagctrl_memif_tbuff_rec.set;
   assign tagctrl_wb_rec.way                   = tagctrl_memif_tbuff_rec.way;
   assign tagctrl_wb_rec.start_beat            = tagctrl_memif_tbuff_rec.start_beat;
   assign tagctrl_wb_rec.blen                  = tagctrl_memif_tbuff_rec.blen;
   assign tagctrl_wb_rec.beat_dirty_mask       = tagctrl_memif_tbuff_rec.wb_dirty_mask;
   assign tagctrl_wb_rec.cfi_id                = tagctrl_memif_tbuff_rec.cfi_id;
   assign tagctrl_wb_rec.iwdb_index            = tagctrl_memif_tbuff_rec.iwdb_index;
   assign tagctrl_wb_rec.wb_check              = 1'b0;


   assign tagctrl_normal_rec.memif_instruction = tagctrl_memif_tbuff_rec.memif_instruction;
   assign tagctrl_normal_rec.cl_instruction    = tagctrl_memif_tbuff_rec.cl_instruction;
   assign tagctrl_normal_rec.axid              = tagctrl_memif_tbuff_rec.axid;
   assign tagctrl_normal_rec.addr              = {tagctrl_memif_tbuff_rec.addr_tag, tagctrl_memif_tbuff_rec.set, 8'd0};
   assign tagctrl_normal_rec.set               = tagctrl_memif_tbuff_rec.set;
   assign tagctrl_normal_rec.way               = tagctrl_memif_tbuff_rec.way;
   assign tagctrl_normal_rec.start_beat        = tagctrl_memif_tbuff_rec.memif_instruction == LF ? (tagctrl_memif_tbuff_rec.linefill_mask[0] ? 2'b00 : 2'b10) : tagctrl_memif_tbuff_rec.start_beat;
   assign tagctrl_normal_rec.blen              = tagctrl_memif_tbuff_rec.memif_instruction == LF ? (&tagctrl_memif_tbuff_rec.linefill_mask ? 2'b11: 2'b01) : tagctrl_memif_tbuff_rec.blen;
   assign tagctrl_normal_rec.beat_dirty_mask   = tagctrl_memif_tbuff_rec.beat_dirty_mask;
   assign tagctrl_normal_rec.cfi_id            = tagctrl_memif_tbuff_rec.cfi_id;
   assign tagctrl_normal_rec.iwdb_index        = tagctrl_memif_tbuff_rec.iwdb_index;
   assign tagctrl_normal_rec.wb_check          = tagctrl_memif_tbuff_rec.wb_valid;

   assign split_stage_rec = (tagctrl_memif_tbuff_rec.wb_valid && ~split_stage_wb_issued) ? tagctrl_wb_rec : tagctrl_normal_rec;
   assign split_stage_valid = tagctrl_memif_tbuff_valid;

   always_comb begin
      tagctrl_memif_tbuff_ready = 1'b0;
      if (tagctrl_memif_tbuff_valid) begin
         if (tagctrl_memif_tbuff_rec.memif_instruction == NOPE) begin
            tagctrl_memif_tbuff_ready = split_stage_ready;
         end
         else if (~tagctrl_memif_tbuff_rec.wb_valid) begin
            tagctrl_memif_tbuff_ready = split_stage_ready;
         end
         else begin
            tagctrl_memif_tbuff_ready = split_stage_wb_issued && split_stage_ready;
         end
      end
   end
   always_ff@(posedge clk or negedge resetn) begin
      if (!resetn)
         split_stage_wb_issued <= 1'b0;
      else if (tagctrl_memif_tbuff_valid & tagctrl_memif_tbuff_ready )begin
         split_stage_wb_issued <= 1'b0;
      end
      else if (split_stage_valid & split_stage_ready & tagctrl_memif_tbuff_rec.wb_valid) begin
         split_stage_wb_issued <= 1'b1;
      end
   end
    gpc_gfx_timing_buffer_# (
       .BUFFER_TYPE         ( GPC_GFX_TIMING_BUFFER_MSTL     )
      ,.WIDTH               ( $bits(req_buffer_record_type ) ))
   i_split_stage_tbuf     (
      .clk                  ( clk                            )
    , .resetn               ( resetn                         )
    , .tbuff_in_valid       ( split_stage_valid              )
    , .tbuff_in_enable      ( split_stage_ready              )
    , .tbuff_in_data        ( split_stage_rec                )
    
    , .tbuff_out_valid      ( split_stage_tbuff_valid        )
    , .tbuff_out_enable     ( split_stage_tbuff_ready        )
    , .tbuff_out_data       ( split_stage_tbuff_rec          ) );
   // ==============================================================================
   // Split wb request and store in request buffer.
   // ==============================================================================

   logic [32                 : 0 ] raw_addr     ;
   logic [L2_DDR_ROW_BITS-1  : 0 ] ddr_rowid    ;
   //logic [L2_DDR_BANK_BITS-1 : 0 ] ddr_bankid   ;
   logic [3                  : 0 ] hash_bank_id ;
   logic [63                 : 0 ] config_rowid_offset0;
   logic [63                 : 0 ] config_rowid_offset1;
   
   assign raw_addr = split_stage_tbuff_rec.addr[32:0];
   
   for (genvar ROW = 0; ROW < L2_DDR_ROW_BITS-4; ROW ++) begin
      assign ddr_rowid[ROW] = raw_addr[gc_l2_bank_row_id_offset[ROW]];
   end
   
   assign ddr_rowid[L2_DDR_ROW_BITS-1] = gc_cr_l2_function_enable_ddr_capacity == 3'd4 ?     raw_addr[gc_l2_bank_row_id_offset[L2_DDR_ROW_BITS-1]] : 1'b0; // 16th bit. capacity == 4
   assign ddr_rowid[L2_DDR_ROW_BITS-2] = gc_cr_l2_function_enable_ddr_capacity >  3'd2 ?     raw_addr[gc_l2_bank_row_id_offset[L2_DDR_ROW_BITS-2]] : 1'b0; // 15th bit. capacity == 3,4,   ignore MSB 2nd bit.
   assign ddr_rowid[L2_DDR_ROW_BITS-3] = gc_cr_l2_function_enable_ddr_capacity >  3'd1 ?     raw_addr[gc_l2_bank_row_id_offset[L2_DDR_ROW_BITS-3]] : 1'b0; // 14th bit. capacity == 2,3,4, ignore MSB 3rd bit.
   assign ddr_rowid[L2_DDR_ROW_BITS-4] = gc_cr_l2_function_enable_ddr_capacity >  3'd0 ?     raw_addr[gc_l2_bank_row_id_offset[L2_DDR_ROW_BITS-4]] : 1'b0; // 13th bit, capacity == 1,2,3,4

   assign config_rowid_offset0 = {16'd0,
                                  gc_cr_ddr_hash_config_reg0_row_id_bit11,
                                  gc_cr_ddr_hash_config_reg0_row_id_bit10,
                                  gc_cr_ddr_hash_config_reg0_row_id_bit9,
                                  gc_cr_ddr_hash_config_reg0_row_id_bit8,
                                  gc_cr_ddr_hash_config_reg0_row_id_bit7,
                                  gc_cr_ddr_hash_config_reg0_row_id_bit6,
                                  gc_cr_ddr_hash_config_reg0_row_id_bit5,
                                  gc_cr_ddr_hash_config_reg0_row_id_bit4,
                                  gc_cr_ddr_hash_config_reg0_row_id_bit3,
                                  gc_cr_ddr_hash_config_reg0_row_id_bit2,
                                  gc_cr_ddr_hash_config_reg0_row_id_bit1,
                                  gc_cr_ddr_hash_config_reg0_row_id_bit0};
   assign config_rowid_offset1 = {16'd0,
                                  gc_cr_ddr_hash_config_reg1_row_id_bit23,
                                  gc_cr_ddr_hash_config_reg1_row_id_bit22,
                                  gc_cr_ddr_hash_config_reg1_row_id_bit21,
                                  gc_cr_ddr_hash_config_reg1_row_id_bit20,
                                  gc_cr_ddr_hash_config_reg1_row_id_bit19,
                                  gc_cr_ddr_hash_config_reg1_row_id_bit18,
                                  gc_cr_ddr_hash_config_reg1_row_id_bit17,
                                  gc_cr_ddr_hash_config_reg1_row_id_bit16,
                                  gc_cr_ddr_hash_config_reg1_row_id_bit15,
                                  gc_cr_ddr_hash_config_reg1_row_id_bit14,
                                  gc_cr_ddr_hash_config_reg1_row_id_bit13,
                                  gc_cr_ddr_hash_config_reg1_row_id_bit12};

   gc_l2_bank_ddr_hash
   i_gc_l2_bank_ddr_hash (
   .ddr_capacity         ( gc_cr_l2_function_enable_ddr_capacity ) ,
   .pa                   ( raw_addr                              ) ,
   .gc_rowid_offset      ( gc_l2_bank_row_id_offset              ) ,
   .gc_bankid_offset     ( gc_l2_bank_bank_id_offset             ) ,
   .ddr_hash_mode        ( gc_cr_l2_function_enable_hash_mode    ) ,
   .config_rowid_offset0 ( config_rowid_offset0                  ) ,
   .config_rowid_offset1 ( config_rowid_offset1                  ) ,
   .hash_bank_id         ( hash_bank_id                          ) );

   assign memif_sched_tbuff_rec.pa           = {split_stage_tbuff_rec.addr[33], ddr_rowid, hash_bank_id, 6'd0, 6'd0};
   assign memif_sched_tbuff_rec.buffer_index = req_allocated ? {2'b00, req_allocated_index} : {2'b0, req_allocate_index};

   logic gc_l2_mem_scheduler_enable_r;

   always_ff@(posedge clk or negedge resetn) begin
      if(!resetn) begin
         gc_l2_mem_scheduler_enable_r <= 1'b0;          
      end
      else begin
         gc_l2_mem_scheduler_enable_r <= gc_l2_mem_scheduler_enable;
      end
   end

   always_comb begin
      split_stage_tbuff_ready = 1'b0;
      memif_sched_tbuff_valid = 1'b0;
      req_allocate_valid = 1'b0;
      if (split_stage_tbuff_valid) begin
         if (gc_l2_mem_scheduler_enable_r) begin
            memif_sched_tbuff_valid = req_allocated | req_allocate_ready;
            split_stage_tbuff_ready = (req_allocated | req_allocate_ready ) && memif_sched_tbuff_ready;
            req_allocate_valid = ~req_allocated;
         end
         else begin
            req_allocate_valid = 1'b1;
            split_stage_tbuff_ready = req_allocate_ready;
         end
      end
   end 
   req_buffer_record_type override_split_rec;
   //   logic [32:0] override_pa;
   always_comb begin :p_override_pa
      override_split_rec = split_stage_tbuff_rec;
      //override_pa = split_stage_tbuff_rec.addr;
      for (int unsigned BANK = 0; BANK < L2_DDR_BANK_BITS; BANK++) begin
         override_split_rec.addr[gc_l2_bank_bank_id_offset[BANK]] = hash_bank_id[BANK];
      end
   end
   // 
   // Allocate req buffer when enable memory scheduler. Otherwise, push
   // request into req buffer as a FIFO.
   //

   assign req_allocate_ready         = ~(&req_buffer_valids); // equal to req_buffer_valids[req_buffer_wrptr] = 1'b0 when disable memory scheduler
   always_ff@(posedge clk or negedge resetn) begin
      if (!resetn) begin
         req_allocated <= 1'b0;
         req_allocated_index <= '0;
      end
      else if (split_stage_tbuff_valid & split_stage_tbuff_ready) begin
         req_allocated <= 1'b0;
      end
      else if (req_allocate_valid & req_allocate_ready) begin
         req_allocated <= 1'b1;
         req_allocated_index <= req_allocate_index;
      end
   end
   gpc_gfx_prienc_ones_lsb
   #(
    .W                   ( L2_MEM_SCHED_INSTR_DEPTH )
   ,.OUTPUT_WIDTH        ( L2_MEM_SCHED_INSTR_BITS  ) )
   i_req_buffer_select_way (
    .vector              ( ~req_buffer_valids       )
   ,.result              ( req_allocate_index       ) );

   logic [L2_MEM_SCHED_INSTR_BITS-1:0] req_buffer_rdptr;
   logic [L2_MEM_SCHED_INSTR_BITS-1:0] req_buffer_wrptr;

   always_ff@(posedge clk or negedge resetn)begin
      if (!resetn) begin
         req_buffer_wrptr <= '0;
      end
      else if (!gc_l2_mem_scheduler_enable_r) begin
         if (req_allocate_valid && req_allocate_ready) begin
            req_buffer_wrptr <= req_buffer_wrptr + 1'b1;
         end
      end
   end

   gpc_gfx_timing_buffer_
   #(
       .BUFFER_TYPE           ( GPC_GFX_TIMING_BUFFER_RSTL         )
      ,.WIDTH                 ( $bits(bank_sched_data_bus_t)      ))
   i_memif_sched_timing_buffer   (
      .clk                    ( clk                                )
    , .resetn                 ( resetn                             )
    , .tbuff_in_valid         ( memif_sched_tbuff_valid            )
    , .tbuff_in_enable        ( memif_sched_tbuff_ready            )
    , .tbuff_in_data          ( memif_sched_tbuff_rec              )
    
    , .tbuff_out_valid        ( memif_sched_valid                  )
    , .tbuff_out_enable       ( memif_sched_ready                  )
    , .tbuff_out_data         ( memif_sched_rec                    ) );

   generate 
      for (genvar req_entry = 0; req_entry < L2_MEM_SCHED_INSTR_DEPTH; req_entry++) begin: g_update_req_buffer
         always_ff @(posedge clk or negedge resetn) begin
            if (!resetn) begin
               req_buffer_valids[req_entry] <= '0;
               req_buffer_entries[req_entry] <= '0;
            end
            else begin
               if (req_allocate_valid && req_allocate_ready && req_allocate_index == req_entry && gc_l2_mem_scheduler_enable_r) begin
                  req_buffer_valids[req_entry] <= 1'b1;
                  req_buffer_entries[req_entry] <= override_split_rec;
               end
               else if (req_allocate_valid && req_allocate_ready && req_entry == req_buffer_wrptr && !gc_l2_mem_scheduler_enable_r) begin
                  req_buffer_valids[req_entry] <= 1'b1;
                  req_buffer_entries[req_entry] <= split_stage_tbuff_rec;
               end
               else if (n_memory_request_valid && n_memory_request_ready && n_memory_request_buffer_index == req_entry) begin 
                  // it is impossible to assert the valid and deassert the valid at the same cycle.
                  req_buffer_valids[req_entry] <= 1'b0;
               end
            end
         end
      end
   endgenerate

   gpc_gfx_timing_buffer_
   #(
       .BUFFER_TYPE           ( GPC_GFX_TIMING_BUFFER_RSTL  )
      ,.WIDTH                 ( $bits(sched_bank_data_bus_t ) ))
   i_sched_memif_timing_buffer   (
      .clk                    ( clk                         )
    , .resetn                 ( resetn                      )
    , .tbuff_in_valid         ( sched_memif_valid           )
    , .tbuff_in_enable        ( sched_memif_ready           )
    , .tbuff_in_data          ( sched_memif_rec             )
    
    , .tbuff_out_valid        ( sched_memif_tbuff_valid     )
    , .tbuff_out_enable       ( sched_memif_tbuff_ready     )
    , .tbuff_out_data         ( sched_memif_tbuff_rec       ) );
   
   assign sched_memif_tbuff_ready = gc_l2_mem_scheduler_enable_r ? n_memory_request_ready : 1'b1;

   assign n_memory_request_valid = gc_l2_mem_scheduler_enable_r ? sched_memif_tbuff_valid : req_buffer_valids[req_buffer_rdptr];
   assign n_memory_request_buffer_index = gc_l2_mem_scheduler_enable_r ? sched_memif_tbuff_rec.buffer_index[L2_MEM_SCHED_INSTR_BITS-1:0] 
                                                                    : req_buffer_rdptr;
   assign n_memory_request_rec = req_buffer_entries[n_memory_request_buffer_index[L2_MEM_SCHED_INSTR_BITS-1:0]];

   gpc_gfx_timing_buffer_# (
       .BUFFER_TYPE        ( GPC_GFX_TIMING_BUFFER_PIPE_REG )
      ,.WIDTH              ( $bits(req_buffer_record_type   ) ))
   i_memory_requst_tbuff   (
      .clk                 ( clk                            )
    , .resetn              ( resetn                         )
    , .tbuff_in_valid      ( n_memory_request_valid         )
    , .tbuff_in_enable     ( n_memory_request_ready         )
    , .tbuff_in_data       ( n_memory_request_rec           )
    
    , .tbuff_out_valid     ( memory_request_valid           )
    , .tbuff_out_enable    ( memory_request_ready           )
    , .tbuff_out_data      ( memory_request_rec             ) );
   
   always_ff@(posedge clk or negedge resetn) begin
      if(!resetn) begin
         req_buffer_rdptr <= '0; 
      end
      else if (!gc_l2_mem_scheduler_enable_r && n_memory_request_valid && n_memory_request_ready)begin
         req_buffer_rdptr <= req_buffer_rdptr + 1'b1; 
      end
   end

   always_ff @(posedge clk or negedge resetn) begin
      if (!resetn) begin
         memif_wdc_issued <= '0;
      end
      else if (memory_request_valid & memory_request_ready) begin
         memif_wdc_issued <= 1'b0;
      end
      else if (memif_wdc_valid & memif_wdc_ready) begin
         memif_wdc_issued <= 1'b1;
      end
   end


   always_comb begin
      memif_wdc_valid = 1'b0;
      memory_request_ready = 1'b0;
      latency_fifo_in_valid = 1'b0;
      rob_index_valid = 1'b0;
      if (memory_request_valid) begin
         case (memory_request_rec.memif_instruction) 
            ST: begin
               memif_wdc_valid = !memif_wdc_issued;
               latency_fifo_in_valid = (memif_wdc_issued || memif_wdc_ready);
               memory_request_ready = (memif_wdc_issued || memif_wdc_ready) && latency_fifo_in_ready;
            end
            LF, BRD: begin
               memif_wdc_valid = 1'b0;
               rob_index_valid = !rob_index_issued;
               memory_request_ready = (rob_index_ready || rob_index_issued) && latency_fifo_in_ready;
               latency_fifo_in_valid = (rob_index_ready || rob_index_issued); 
            end
         endcase
      end
   end

   // ======================================================================
   // issue to WDC
   // ======================================================================
   assign memif_wdc_rec.instruction     = memory_request_rec.cl_instruction;
   assign memif_wdc_rec.set             = memory_request_rec.set;
   assign memif_wdc_rec.way             = memory_request_rec.way;
   assign memif_wdc_rec.start_beat      = memory_request_rec.start_beat;
   assign memif_wdc_rec.blen            = memory_request_rec.blen;
   assign memif_wdc_rec.beat_dirty_mask = memory_request_rec.beat_dirty_mask;
   assign memif_wdc_rec.iwdb_index      = memory_request_rec.iwdb_index;

   logic [1:0] wb_start_beat;
   logic [1:0] wb_end_beat;
   logic [L2_NUM_BEAT-1:0] cal_dirty_mask;
   assign cal_dirty_mask = (memory_request_rec.cl_instruction == WB_WR) ? l2_bank_calc_dirty_mask(memory_request_rec.beat_dirty_mask, memory_request_rec.start_beat, memory_request_rec.blen) 
                          : memory_request_rec.beat_dirty_mask;
   gpc_gfx_prienc_ones_lsb
   #(
    .W                   ( L2_NUM_BEAT                        )
   ,.OUTPUT_WIDTH        ( L2_BEAT_BITS                       ) )
   i_cal_wb_start_beat   (
    .vector              ( cal_dirty_mask                     )
   ,.result              ( wb_start_beat                      ) );
   gpc_gfx_prienc_ones_msb
   #(
    .W                   ( L2_NUM_BEAT                        )
   ,.OUTPUT_WIDTH        ( L2_BEAT_BITS                       ) )
   i_cal_wb_end_beat   (
    .vector              ( cal_dirty_mask                     )
   ,.result              ( wb_end_beat                      ) );
//   assign nsp_split_rec.axid = memory_request_rec.axid;
   logic [L2_TAG_MSB_BITS:0] wb_addr;
   logic [L2_TAG_MSB_BITS:0] normal_addr;
   logic                     is_wb_req;
   assign is_wb_req = memory_request_rec.cl_instruction == WB || memory_request_rec.cl_instruction == WB_WR || memory_request_rec.cl_instruction == FLUSH;
   assign wb_addr = {memory_request_rec.addr[L2_TAG_MSB_BITS-:L2_ADDR_TAG_BITS+L2_NUM_SET_BITS], 
                     wb_start_beat, 
                     6'd0};
   assign normal_addr = {memory_request_rec.addr[L2_TAG_MSB_BITS-:L2_ADDR_TAG_BITS+L2_NUM_SET_BITS],
                        memory_request_rec.start_beat,
                        6'd0};
   
   assign latency_fifo_in_rec.rnw        = memory_request_rec.memif_instruction == ST ? 1'b0 : 1'b1;
   assign latency_fifo_in_rec.linefill   = memory_request_rec.memif_instruction == LF;
   assign latency_fifo_in_rec.axid       = memory_request_rec.axid;
   assign latency_fifo_in_rec.addr       = is_wb_req ? wb_addr : normal_addr;
   assign latency_fifo_in_rec.start_beat = is_wb_req ? wb_start_beat : memory_request_rec.start_beat; 
   assign latency_fifo_in_rec.blen       = is_wb_req ? wb_end_beat - wb_start_beat : memory_request_rec.blen; 
   assign latency_fifo_in_rec.set        = memory_request_rec.set;
   assign latency_fifo_in_rec.way        = memory_request_rec.way;
   assign latency_fifo_in_rec.wb_check   = memory_request_rec.wb_check;
   assign latency_fifo_in_rec.cfi_id     = memory_request_rec.cfi_id;
   assign latency_fifo_in_rec.rob_index  = rob_index;


   gpc_gfx_rpfifo_ #    (
      .w                ( $bits(memory_latency_fifo_record_type ) ),
      .d                ( 12                                     ) )
   i_write_latency_fifo (
      .clk              ( clk                                   ) ,
      .resetn           ( resetn                                ) ,
      .fifo_in_valid    ( latency_fifo_in_valid                 ) ,
      .fifo_in_enable   ( latency_fifo_in_ready                 ) ,
      .fifo_in_data     ( latency_fifo_in_rec                   ) ,
      .fifo_out_valid   ( latency_fifo_out_valid                ) ,
      .fifo_out_enable  ( latency_fifo_out_ready                ) ,
      .fifo_out_data    ( latency_fifo_out_rec                  ) );


   logic nsp_id_allocate_valid;
   logic nsp_id_allocate_ready;
   logic nsp_id_allocate_issued;
   logic sync_data_last_beat;
   assign nsp_id_allocate_ready = ~&nspid_valids;

   //logic [L2_NSP_ID_BITS-1:0] previous_index;
   logic [L2_NSP_ID_BITS-1:0] nsp_allocate_index;
   logic [L2_NSP_ID_BITS-1:0] nsp_allocated_index;
   
   gpc_round_robin_index_arch1_                #(
       .width                                   ( L2_NUM_NSP_ID      ) ,
       .hold_previous                           ( 1'b0               ) )
   i_rr_allocate_nsp_id                         (
       .valids                                  ( ~nspid_valids      ) ,
       .previous_index                          ( nsp_allocated_index) ,
       .next_index                              ( nsp_allocate_index ) );


   always_ff@(posedge clk or negedge resetn) begin
      if(!resetn) begin
         nsp_allocated_index <= '0; 
      end
      else if (nsp_id_allocate_valid && nsp_id_allocate_ready ) begin
         nsp_allocated_index <= nsp_allocate_index;
      end
   end

   always_ff@(posedge clk or negedge resetn) begin
      if(!resetn) begin
         nsp_id_allocate_issued <= 1'b0;
      end
      else if (latency_fifo_out_valid && latency_fifo_out_ready) begin
         nsp_id_allocate_issued <= 1'b0;
      end
      else if (nsp_id_allocate_valid && nsp_id_allocate_ready ) begin
         nsp_id_allocate_issued <= 1'b1;
      end
   end
   // ======================================================================
   // issue to NSP: allocate rob index first. 
   // ======================================================================
  assign rob_index_size = memory_request_rec.blen; 

  gc_idx_assign              #(
       .NUM_INDICES           ( L2_ROB_DEPTH     )
      ,.INDEX_BITS            ( L2_ROB_BITS      )
      ,.BLEN_WIDTH            ( 2                ) )
   i_l2_bank_rob_index_assign (
       .clk                   ( clk              )
      ,.resetn                ( resetn           )
      ,.idx_assign_idle       ( idx_assign_idle  )
      ,.allocate_valid        ( rob_index_valid  )
      ,.allocate_size         ( rob_index_size   )
      ,.assigned_index_valid  ( rob_index_ready  )
      ,.assigned_index        ( rob_index        )
      ,.index_freed_mask      ( index_freed_mask ) );

   always_ff@(posedge clk or negedge resetn) begin
      if (!resetn) begin
         rob_index_issued <= 1'b0;
      end
      else if (memory_request_valid & memory_request_ready) begin
         rob_index_issued <= 1'b0;
      end
      else if (rob_index_valid & rob_index_ready) begin
         rob_index_issued <= 1'b1;
      end
   end
   // ======================================================================
   // split request and sync wdata
   // read request should allocate rob index first -> then allocate nsp id -> issue nsp request
   // write request should allocate nsp id first -> sync wdata -> issue nsp request 
   // ======================================================================
   always_comb begin
      wdc_memif_wdata_ready = 1'b0;
      //rob_index_valid = 1'b0;
      latency_fifo_out_ready = 1'b0;
      nsp_req_tbuff_valid = 1'b0;
      nsp_id_allocate_valid = 1'b0;
      if (latency_fifo_out_valid) begin
         case (1'b1)
            latency_fifo_out_rec.rnw: begin // read
               //rob_index_valid = !rob_index_issued;
               nsp_id_allocate_valid =  !nsp_id_allocate_issued;
               nsp_req_tbuff_valid =  (nsp_id_allocate_issued || nsp_id_allocate_ready);
               latency_fifo_out_ready = (nsp_id_allocate_issued || nsp_id_allocate_ready) && nsp_req_tbuff_ready;
            end
            ~latency_fifo_out_rec.rnw: begin // write
               nsp_id_allocate_valid = !nsp_id_allocate_issued;
               if (wdc_memif_wdata_valid) begin
                  wdc_memif_wdata_ready = sync_data_last_beat && (nsp_id_allocate_issued || nsp_id_allocate_ready) && nsp_req_tbuff_ready;
                  nsp_req_tbuff_valid = (nsp_id_allocate_issued || nsp_id_allocate_ready);
                  latency_fifo_out_ready = wdc_memif_wdata_rec.last && sync_data_last_beat && nsp_req_tbuff_ready;
               end
            end
         endcase
      end
   end

   always_ff @(posedge clk or negedge resetn) begin
      if (!resetn) begin
         sync_data_last_beat <= 1'b0;
      end
      else if (nsp_req_tbuff_valid && nsp_req_tbuff_ready && nsp_req_tbuff_rec.opc == 'd4) begin
         sync_data_last_beat <= ~sync_data_last_beat;
      end
   end



   assign nsp_req_tbuff_rec.trid   = nsp_id_allocate_issued ? nsp_allocated_index : nsp_allocate_index;
   assign nsp_req_tbuff_rec.length = {latency_fifo_out_rec.blen, 6'h3f};
   assign nsp_req_tbuff_rec.seqid  = 1'b0;
   assign nsp_req_tbuff_rec.flowid = 1'b0;
   assign nsp_req_tbuff_rec.excid  = 1'b0;
   assign nsp_req_tbuff_rec.opc    = (latency_fifo_out_rec.rnw) ? 3'd0 : 3'd4;
   assign nsp_req_tbuff_rec.addr   = latency_fifo_out_rec.addr;
   assign nsp_req_tbuff_rec.data   = (latency_fifo_out_rec.rnw) ? '0 : sync_data_last_beat ? wdc_memif_wdata_rec.wdata[256+:256] : wdc_memif_wdata_rec.wdata[0+:256];
   assign nsp_req_tbuff_rec.be     = (latency_fifo_out_rec.rnw) ? '0 : sync_data_last_beat ? wdc_memif_wdata_rec.wdata_mask[32+:32] : wdc_memif_wdata_rec.wdata_mask[0+:32];
   assign nsp_req_tbuff_rec.last   = (latency_fifo_out_rec.rnw) ? 1'b1 : wdc_memif_wdata_rec.last && sync_data_last_beat;
   
   for (genvar ENTRY = 0; ENTRY < L2_NUM_NSP_ID; ENTRY++) begin
      always_ff@(posedge clk or negedge resetn) begin
         if(!resetn) begin
            nspid_valids [ENTRY] <= 1'b0;          
         end
         else if (nsp_id_allocate_valid && nsp_id_allocate_ready && nsp_allocate_index == ENTRY )begin
            nspid_valids[ENTRY] <= 1'b1;
         end
         else if (nsp_rsp_tbuff_valid && nsp_rsp_tbuff_ready && nsp_rsp_tbuff_rec.last && nsp_rsp_tbuff_rec.trid == ENTRY && ~nsp_entries[ENTRY].rnw) begin
            nspid_valids[ENTRY] <= 1'b0;
         end
         else if (nsp_entry_output_valid && nsp_entry_output_ready && output_index == ENTRY) begin
            nspid_valids[ENTRY] <= 1'b0;
         end
      end
      always_comb begin
         n_nsp_entries[ENTRY] = nsp_entries[ENTRY];
         if (nsp_id_allocate_valid && nsp_id_allocate_ready && nsp_allocate_index == ENTRY) begin
            n_nsp_entries[ENTRY].axid       = latency_fifo_out_rec.axid;
            n_nsp_entries[ENTRY].rnw        = latency_fifo_out_rec.rnw;
            n_nsp_entries[ENTRY].set        = latency_fifo_out_rec.set;
            n_nsp_entries[ENTRY].way        = latency_fifo_out_rec.way;
            n_nsp_entries[ENTRY].start_beat = latency_fifo_out_rec.start_beat;
            n_nsp_entries[ENTRY].linefill   = latency_fifo_out_rec.linefill;
            n_nsp_entries[ENTRY].blen       = latency_fifo_out_rec.blen;
            n_nsp_entries[ENTRY].wb_check   = latency_fifo_out_rec.linefill ? ~tagctrl_memif_wb_finish : 1'b0;
            n_nsp_entries[ENTRY].cnt        = '0;
            n_nsp_entries[ENTRY].cfi_id     = latency_fifo_out_rec.cfi_id;
            n_nsp_entries[ENTRY].rob_index  = latency_fifo_out_rec.rob_index;
            n_nsp_entries[ENTRY].avaliable  = 1'b0;
         end
         else begin
            if (nsp_rsp_tbuff_valid && nsp_rsp_tbuff_ready && nsp_entries[ENTRY].rnw && nsp_rsp_tbuff_rec.trid == ENTRY) begin
               n_nsp_entries[ENTRY].cnt = nsp_entries[ENTRY].cnt + 1'b1;
               n_nsp_entries[ENTRY].avaliable = nsp_rsp_tbuff_rec.last;
            end
            if ((rctrl_memif_wb_done_valid[0] && nspid_valids[ENTRY] && nsp_entries[ENTRY].set == rctrl_memif_wb_done_rec[0].set && rctrl_memif_wb_done_rec[0].way == nsp_entries[ENTRY].way && ~rctrl_memif_wb_done_rec[0].lf_or_wb) 
               || (rctrl_memif_wb_done_valid[1] && nspid_valids[ENTRY] && nsp_entries[ENTRY].set == rctrl_memif_wb_done_rec[1].set && rctrl_memif_wb_done_rec[1].way == nsp_entries[ENTRY].way && ~rctrl_memif_wb_done_rec[1].lf_or_wb)) begin
               n_nsp_entries[ENTRY].wb_check = 1'b0;
            end 
         end
      end 

      always_ff@(posedge clk or negedge resetn) begin
         if(!resetn) begin
            nsp_entries[ENTRY] <= '0;          
         end
         else if ((nsp_id_allocate_valid && nsp_id_allocate_ready) || (nsp_rsp_tbuff_valid) || (|rctrl_memif_wb_done_valid)) begin
             nsp_entries[ENTRY] <= n_nsp_entries[ENTRY];
         end
      end
      assign nsp_entry_mask[ENTRY] = nspid_valids[ENTRY] && ~nsp_entries[ENTRY].wb_check && nsp_entries[ENTRY].avaliable && nsp_entries[ENTRY].rnw;
   end

   gpc_gfx_timing_buffer_
   #(
       .BUFFER_TYPE           ( GPC_GFX_TIMING_BUFFER_RSTL  )
      ,.WIDTH                 ( $bits(nsp_req_data_bus_t ) ))
   i_nsp_rec_timing_buffer   (
      .clk                    ( clk                         )
    , .resetn                 ( resetn                      )
    , .tbuff_in_valid         ( nsp_req_tbuff_valid         )
    , .tbuff_in_enable        ( nsp_req_tbuff_ready         )
    , .tbuff_in_data          ( nsp_req_tbuff_rec           )
    
    , .tbuff_out_valid        ( nsp_req_valid               )
    , .tbuff_out_enable       ( nsp_req_ready               )
    , .tbuff_out_data         ( nsp_req_rec                 ) );
   // ==============================================================================
   // Process NSP return 
   // ==============================================================================
  gpc_gfx_timing_buffer_vonly_ # (
         .BUFFER_TYPE            ( GPC_GFX_TIMING_BUFFER_PIPE_REG ) ,
         .WIDTH                  ( $bits(nsp_rsp_data_bus_t       ) ))
   i_nsp_rsp_timing_buffer       (
      .clk                       ( clk                            )
    , .resetn                    ( resetn                         )
    , .tbuff_in_valid            ( nsp_rsp_valid                  )
    , .tbuff_in_data             ( nsp_rsp_rec                    )
    
    , .tbuff_out_valid           ( nsp_rsp_tbuff_valid            )
    , .tbuff_out_data            ( nsp_rsp_tbuff_rec              ) );

   assign nsp_rsp_ready = 1'b1;
   always_ff@(posedge clk or negedge resetn) begin
      if (!resetn) begin
         memif_tagctrl_cfi_decrease_valid <= 1'b0;
         memif_tagctrl_cfi_id <= '0;
      end
      else if (nsp_rsp_tbuff_valid && nsp_rsp_tbuff_ready && !nsp_entries[nsp_rsp_tbuff_rec.trid].rnw) begin
         memif_tagctrl_cfi_decrease_valid <= 1'b1;
         memif_tagctrl_cfi_id <= nsp_entries[nsp_rsp_tbuff_rec.trid].cfi_id;
      end
      else if (memif_tagctrl_cfi_decrease_valid) begin
         memif_tagctrl_cfi_decrease_valid <= 1'b0;
      end
   end

   // ==============================================================================
   // It is possible that all the arid is ready and going to perform linefill
   // or bypass read. Using round robin to select an arid to return. The
   // arbiter output shall remain stable until the burst is finished.  
   // ==============================================================================
   assign nsp_rsp_tbuff_ready     = 1'b1;
   
   assign write_valid           = nsp_rsp_tbuff_valid && nsp_entries[nsp_rsp_tbuff_rec.trid].rnw;
   assign write_rec.rob_index   = (nsp_entries[nsp_rsp_tbuff_rec.trid].rob_index + {{(L2_ROB_BITS-2){1'b0}},nsp_entries[nsp_rsp_tbuff_rec.trid].cnt[2:1]}) % L2_ROB_DEPTH;
   assign write_rec.write_mask  = nsp_entries[nsp_rsp_tbuff_rec.trid].cnt[0] == 1'b0 ? 2'b10 : 2'b01; // active low
   assign write_rec.write_data  = nsp_rsp_tbuff_rec.data;
  
   assign memif_tagctrl_valid   = nsp_id_allocate_valid && latency_fifo_out_rec.linefill; 
   assign memif_tagctrl_rec.set = latency_fifo_out_rec.set;
   assign memif_tagctrl_rec.way = latency_fifo_out_rec.way;
   
   
   
   
   gpc_round_robin_index_arch1_  # (
       .width                      ( L2_NUM_NSP_ID         ) ,
       .hold_previous              ( 1'b0                  ) )
   i_rr_output_index               (
       .valids                     ( nsp_entry_mask        ) ,
       .previous_index             ( previous_output_index ) ,
       .next_index                 ( output_index          ) );

   always_ff@(posedge clk or negedge resetn) begin
      if (!resetn) begin
         previous_output_index <= '0;
      end
      else if (nsp_entry_output_valid && nsp_entry_output_ready) begin
         previous_output_index <= output_index;
      end
   end

   assign nsp_entry_output_valid = |nsp_entry_mask;
   assign nsp_entry_output_rec   = nsp_entries[output_index];

   gpc_gfx_timing_buffer_
   #(
       .BUFFER_TYPE           ( GPC_GFX_TIMING_BUFFER_RSTL      )
      ,.WIDTH                 ( $bits(nsp_entry_record_type   ) ))
   i_read_rec_timing_buffer   (
      .clk                    ( clk                            )
    , .resetn                 ( resetn                         )
    , .tbuff_in_valid         ( nsp_entry_output_valid         )
    , .tbuff_in_enable        ( nsp_entry_output_ready         )
    , .tbuff_in_data          ( nsp_entry_output_rec           )
    
    , .tbuff_out_valid        ( read_tbuff_valid               )
    , .tbuff_out_enable       ( read_tbuff_ready               )
    , .tbuff_out_data         ( read_tbuff_rec                 ) );
  

   logic [1:0] rd_pending_cnt;

   always_ff@(posedge clk or negedge resetn) begin
      if(!resetn) begin
         rd_pending_cnt <= '0; 
      end
      else if (read_tbuff_valid && read_tbuff_ready) begin
         rd_pending_cnt <= '0;
      end
      else if (read_rob_valid && read_rob_ready) begin
         rd_pending_cnt <= rd_pending_cnt + 1'b1;
      end
   end
   
   assign read_tbuff_ready         = (read_tbuff_rec.blen == rd_pending_cnt) && read_tbuff_valid && read_rob_ready;
   
   logic [1:0] sector_mask;
   logic [1:0] end_beat;
   assign end_beat                = read_tbuff_rec.start_beat + read_tbuff_rec.blen;
   assign sector_mask[0]          = ~read_tbuff_rec.start_beat[1];
   assign sector_mask[1]          = end_beat[1];

   assign read_rob_valid           = read_tbuff_valid;
   assign read_rob_rec.axid        = read_tbuff_rec.axid;
   assign read_rob_rec.set         = read_tbuff_rec.set;
   assign read_rob_rec.way         = read_tbuff_rec.way;
   assign read_rob_rec.beat        = read_tbuff_rec.start_beat + rd_pending_cnt;
   assign read_rob_rec.sector_mask = sector_mask;
   assign read_rob_rec.linefill    = read_tbuff_rec.linefill;
   assign read_rob_rec.rob_index   = (read_tbuff_rec.rob_index + {{(L2_ROB_BITS-2){1'b0}}, rd_pending_cnt}) % L2_ROB_DEPTH;
   assign read_rob_rec.last        = (read_tbuff_rec.blen == rd_pending_cnt);







   gc_l2_bank_rob
   i_l2_bank_rob
   (
       .clk             ( clk              )
      ,.resetn          ( resetn           )

      ,.rob_idle        ( rob_idle         )

      ,.read_valid      ( read_rob_valid   )
      ,.read_ready      ( read_rob_ready   )
      ,.read_rec        ( read_rob_rec     )
      
      ,.readout_valid   ( readout_valid    )
      ,.readout_ready   ( readout_ready    )
      ,.readout_rec     ( readout_rec      )
      
      ,.write_valid     ( write_valid      )
      ,.write_rec       ( write_rec        )
      
      ,.index_free_mask ( index_freed_mask )
      ,.tst_gclkenable  (tst_gclkenable    ) );
   
   assign readout_ready = readout_valid && readout_rec.linefill ? (readout_rec.set[0] ? memif_rctrl_ready[1] : memif_rctrl_ready[0] ): memif_align_ready;

   assign memif_rctrl_valid           = readout_valid && readout_rec.linefill ? {readout_rec.set[0], ~readout_rec.set[0]} : 2'b00;
   assign memif_rctrl_rec[0].set         = readout_rec.set ;
   assign memif_rctrl_rec[0].way         = readout_rec.way ;
   assign memif_rctrl_rec[0].beat        = readout_rec.beat;
   assign memif_rctrl_rec[0].data        = readout_rec.data;
   assign memif_rctrl_rec[0].sector_mask = readout_rec.sector_mask;
   assign memif_rctrl_rec[0].last        = readout_rec.last;
   assign memif_rctrl_rec[1].set         = readout_rec.set ;
   assign memif_rctrl_rec[1].way         = readout_rec.way ;
   assign memif_rctrl_rec[1].beat        = readout_rec.beat;
   assign memif_rctrl_rec[1].data        = readout_rec.data;
   assign memif_rctrl_rec[1].sector_mask = readout_rec.sector_mask;
   assign memif_rctrl_rec[1].last        = readout_rec.last;


   assign memif_align_valid    = readout_valid && ~readout_rec.linefill;
   assign memif_align_rec.data = readout_rec.data;
   assign memif_align_rec.axid = readout_rec.axid;
   assign memif_align_rec.last = readout_rec.last;
  
   logic sample_valid;
   logic [6:0] sample_arid;
   logic ready_to_sample;
   assign ready_to_sample    = (!sample_valid && latency_fifo_out_valid && latency_fifo_out_ready && latency_fifo_out_rec.rnw) 
                               || ((sample_valid && nsp_rsp_tbuff_valid && nsp_rsp_tbuff_ready && nsp_rsp_tbuff_rec.last && nsp_rsp_tbuff_rec.trid == sample_arid) && (latency_fifo_out_valid && latency_fifo_out_ready && latency_fifo_out_rec.rnw));
   always_ff@(posedge clk or negedge resetn) begin
      if (!resetn) begin
         sample_valid <= '0;
         sample_arid <= '0;
      end
      else if (ready_to_sample) begin
         sample_valid <= 1'b1;
         sample_arid <= nsp_req_tbuff_rec.trid;
      end
      else if (sample_valid &&  nsp_rsp_tbuff_valid && nsp_rsp_tbuff_ready && nsp_rsp_tbuff_rec.last && nsp_rsp_tbuff_rec.trid == sample_arid) begin
         sample_valid <= 1'b0;
      end
   end

   assign l2b_frommemsch_nsp_rtn_wl                 = sched_memif_valid && sched_memif_ready;
   assign l2b_frommemsch_nsp_rtn_bp                 = sched_memif_valid && !sched_memif_ready;
   assign l2b_tomemsch_nsp_read_bl_eq1_wl           = latency_fifo_out_valid && latency_fifo_out_ready &&  latency_fifo_out_rec.rnw && latency_fifo_out_rec.blen == 2'd0;
   assign l2b_tomemsch_nsp_read_bl_eq3_wl           = latency_fifo_out_valid && latency_fifo_out_ready &&  latency_fifo_out_rec.rnw && latency_fifo_out_rec.blen == 2'd1;
   assign l2b_tomemsch_nsp_read_bl_eq5_wl           = latency_fifo_out_valid && latency_fifo_out_ready &&  latency_fifo_out_rec.rnw && latency_fifo_out_rec.blen == 2'd2;
   assign l2b_tomemsch_nsp_read_bl_eq7_wl           = latency_fifo_out_valid && latency_fifo_out_ready &&  latency_fifo_out_rec.rnw && latency_fifo_out_rec.blen == 2'd3;
   assign l2b_tomemsch_nsp_write_bl_eq1_wl          = latency_fifo_out_valid && latency_fifo_out_ready && !latency_fifo_out_rec.rnw && latency_fifo_out_rec.blen == 2'd0;
   assign l2b_tomemsch_nsp_write_bl_eq3_wl          = latency_fifo_out_valid && latency_fifo_out_ready && !latency_fifo_out_rec.rnw && latency_fifo_out_rec.blen == 2'd1;
   assign l2b_tomemsch_nsp_write_bl_eq5_wl          = latency_fifo_out_valid && latency_fifo_out_ready && !latency_fifo_out_rec.rnw && latency_fifo_out_rec.blen == 2'd2;
   assign l2b_tomemsch_nsp_write_bl_eq7_wl          = latency_fifo_out_valid && latency_fifo_out_ready && !latency_fifo_out_rec.rnw && latency_fifo_out_rec.blen == 2'd3;

   assign l2b_memif_to_ddr_read_wl                  = latency_fifo_out_valid && latency_fifo_out_rec.rnw && latency_fifo_out_ready ;
   assign l2b_memif_to_ddr_read_stall_by_rob        = rob_index_valid && !rob_index_ready;
   assign l2b_memif_to_ddr_read_stall_by_ddr        = nsp_req_tbuff_valid && nsp_req_tbuff_rec.opc == 'd0 && !nsp_req_tbuff_ready ;
   assign l2b_memif_to_ddr_read_stall_by_trid       = latency_fifo_out_valid && latency_fifo_out_rec.rnw && nsp_id_allocate_valid && !nsp_id_allocate_ready;
   assign l2b_memif_to_ddr_write_wl                 = latency_fifo_out_valid && !latency_fifo_out_rec.rnw && latency_fifo_out_ready ;
   assign l2b_memif_to_ddr_write_stall_by_data_sync = latency_fifo_out_valid && !latency_fifo_out_rec.rnw && !wdc_memif_wdata_valid;
   assign l2b_memif_to_ddr_write_stall_by_ddr       = nsp_req_tbuff_valid && nsp_req_tbuff_rec.opc == 'd4 && !nsp_req_tbuff_ready ;
   assign l2b_memif_to_ddr_write_stall_by_trid      = latency_fifo_out_valid && !latency_fifo_out_rec.rnw && nsp_id_allocate_valid && !nsp_id_allocate_ready;
   assign l2b_memif_memreq_full                     = ~req_allocate_ready;
   assign l2b_memif_smp_read_req_sum                = sample_valid;
   always_ff@(posedge clk or negedge resetn) begin
      if(!resetn) begin
          l2b_memif_smp_read_req_num <= '0;
      end
      else begin
          l2b_memif_smp_read_req_num <= ready_to_sample;
      end
   end




   // synopsys translate_off
   default clocking cb @(posedge clk);
   endclocking
   default disable iff(!resetn);

   as__valid_memif_inst_check:
      assert property (memory_request_valid |-> memory_request_rec.memif_instruction != NOPE);
  
   for (genvar ROW = 0; ROW < 17; ROW++) begin
      as__row_id_offset_check:
         assert property (tagctrl_memif_valid && gc_l2_mem_scheduler_enable_r |-> !(gc_l2_bank_row_id_offset[ROW] inside {0, 1, 2, 3, 4, 5, 6, 7}));
   end 

   for (genvar BANK = 0; BANK < 4; BANK++) begin
      as__bank_id_offset_check:
         assert property (tagctrl_memif_valid && gc_l2_mem_scheduler_enable_r |-> !(gc_l2_bank_bank_id_offset[BANK] inside {0, 1, 2, 3, 4, 5, 6, 7}));
   end 
   // synopsys translate_on


endmodule
// Local Variables:
// verilog-library-directories:("./" ) 
// End:
