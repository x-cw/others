/*

 * #==========================================================================#
 * |                                                                          |
 * |  Copyright (c) 2022, Fantasy Technologies Limited and/or its         |
 * |  affiliated group companies ("Fantasy"). All rights reserved.        |
 * |  No part of this content, either material or conceptual may be copied    |
 * |  or distributed, transmitted, transcribed, stored in a retrieval system  |
 * |  or translated into any human or computer language in any form by any    |
 * |  means, electronic, mechanical manual, or otherwise, or disclosed to     |
 * |  third parties without the express written permission of Fantasy.    |
 * |                                                                          |
 * #==========================================================================#

 */


// ////////////////////////////////////////////////////////////////////////////-
// entity:  gpc_gfx_dpstore
//
// purpose: Dual port synchronous RAM with configurable write word partitioning
//
// +////////////////////////-+////////+////-+////-+////////+////////////////+
// | gpc_gfx_dpstore_        |        | RAM | Reg | Bypass | Design         |
// |             w,p,d,log2d | Clocks | O/P | O/P | Input  | Suitability    |
// +////////////////////////-+////////+////-+////-+////////+////////////////+
// | _.vhd & _novital.vhd    |  2:RW  | Yes |     |        | Fundamental    |<<<
// | bist.vhdm               | single | Yes |     |        | Low level only |
// | bist_async.vhdm         |  2:RW  | Yes |     |        | Low level only |
// | gen_bist_r.vhd          | single |     | Yes |        | Standard use   |
// | pipeline_gen_bist_r.vhd | single |     | Yes |        | Standard use   |
// | bypass_gen_bist_r.vhd   | single |     | Yes |  Yes   | Standard use   |
// | flexible_gen_bist_r.vhd | single | Yes | Yes |  Yes   | Standard use   |
// | flexible_gen_bist_r     |        |     |     |        |                |
// |              _async.vhd |  2:RW  | Yes | Yes |  Yes   | Standard use   |
// +////////////////////////-+////////+////-+////-+////////+////////////////+
//
// hierarchy: This is *NOT* an RTL designer's standard component
//
//        gpc_gfx_dpstore_[pipeline|bypass]_gen_bist_r
//         |
//         +- gpc_gfx_dpstore_bist
//             |
//             +- gpc_gfx_dpstore                      << YOU ARE HERE
//             |
//             +- [ gpc_gfx_bistwrap ]
//
// ////////////////////////////////////////////////////////////////////////////-

// DIMENSIONS
//   Physical generics: w, d, p, log2d
//
//                        width
//              <////////// w //////////>
//
//              +//////////////////////-+   ^
//              |_______________________|   |
//              |_______________________|   |  d
//              |_______________________|      e
//              |                       |   d  p
//              |                       |      t
//              :                       :   |  h
//              |                       |   |
//              +//////////////////////-+   v
//                         w/p *
//              <- p -><- p -> .. <- p ->
//                      partitions
//
//   All partitions are equal in size. In other words, the generic w is an
//   integer multiple of generic p.
//
//   Example partition:
//      [w = 128, p = 32] => w/p = 4 partitions => 4 write enables

// PORT A (read)
//   +////////////////////////////////////////////////-+
//   |  name  | bits  |dir| description                |
//   +////////////////////////////////////////////////-+
//   |  CLKA  |   1   | i | read clock                 |
//   |  AA    | log2d | i | read address               |
//   |  CENA  |   1   | i | read strobe (ACTIVE LOW)   |
//   |  QA    |   w   | o | read data                  |
//   +////////////////////////////////////////////////-+
// PORT B (write)
//   +////////////////////////////////////////////////-+
//   |  name  | bits  |dir| description                |
//   +////////////////////////////////////////////////-+
//   |  CLKB  |   1   | i | write clock                |
//   |  AB    | log2d | i | write address              |
//   |  DB    |   w   | i | write data ((w/p)*p bits)  |
//   |  WENB  |  w/p  | i | write enables (ACTIVE LOW) |
//   |  CENB  |   1   | i | write strobe (ACTIVE LOW)  |
//   +////////////////////////////////////////////////-+

// FUNCTIONAL MODEL
//   Read latency:  1 clock
//   Write latency: 1 clock
//
//             AA,CENA    /////////////////////////-+
//                                                  |
//                             +////+   +////-+   +////+
//             AB,CENB    /////| wr |   |     |   | rd |
//             WENB       /////|proc|-/-| mem |-/-|proc|///-> QA
//             DB         /////|    |   |     |   |    |
//                             |    |  +|>    |  +|>   |
//                             +////+  |+////-+  |+////+
//                                     |         |
//             CLKB       ////////////-+         |
//             CLKA       //////////////////////-+

// ADDITIONAL PORTS (not usually connected)
//   +////////////////////////////////////////////////-+
//   |  name  | bits  |dir| description                |
//   +////////////////////////////////////////////////-+
//   |  SRAM  |   1   | o | tied to '1'                |
//   |  L2M   |   3   | o | tied to "000"              |
//   +////////////////////////////////////////////////-+

// OPTIONAL UTILITY GENERICS
//   id       : integer value that can be assigned to each instance (default 0)
// ////////////////////////////////////////////////////////////////////////////-

module gpc_gfx_dpstore
//spyglass disable_block -rule "W240" 
//spyglass disable_block -rule "W175" 
//spyglass disable_block -rule "W241"
  #(
      parameter   w                                        = 8, // integer
      parameter   p                                        = 8, // integer
      parameter   d                                        = 8, // integer
      parameter   log2d                                    = 3, // integer
      parameter   id                                       = 0
    )
(
      input    logic                                    CLKA,
      input    logic                                    CENA,
      input    logic [ log2d - 1 : 0 ]                  AA,
      output   logic [ w - 1 : 0 ]                      QA,
      input    logic                                    CLKB,
      input    logic                                    CENB,
      input    logic [ ( w / p ) - 1 : 0 ]              WENB,
      input    logic [ log2d - 1 : 0 ]                  AB,
      input    logic [ w - 1 : 0 ]                      DB,
      input    logic                                    TE,
      output   logic [ 2 : 0 ]                          L2M,
      output   logic                                    SRAM
);


// initial begin
//   $display("memory used in gfx dp: %d,%d,%d,%d",d,w,p,id);
// //   $display("memory used in gfx dp %m: %d,%d,%d,%d",d,w,p,id);
// end

   localparam NUM_PARTITIONS = w/p;
`ifdef  EMU_2D_SRAM
//Used in FPGA and palladium env.
   logic [w-1:0]                     ram_core[d-1:0];
   //read process for port A  
   for (genvar part = 0; part<NUM_PARTITIONS; part++) begin : g_ram_rd
      always_ff@(posedge CLKA) begin : ram_rd
         if(CENA==1'b0) begin
            begin
               QA[part*p +: p] <= ram_core[AA][part*p +: p];
            end
         end         
      end
   end

   //write process for port B  
   for (genvar part = 0; part<NUM_PARTITIONS; part++) begin : g_ram_wr
      always_ff@(posedge CLKB) begin : ram_wr
         if(CENB==1'b0 && WENB[part]==1'b0) begin //COV:tag1
            begin
               //store X at targetted address for this partition
               ram_core[AB][part*p +: p] <= DB[part*p +: p];
            end
         end
      end
   end
`elsif GPU_SYNTHESIS
//Used in DC env. This file is replaced to SRAM DB in DC env.

`else
//Original RTL, used in VCS env.
   import gpc_gfx_backdoor_pkg_::*;
   logic [NUM_PARTITIONS-1:0][0:d-1][p-1:0] ram_core;

   ///////////////////////////////////////////////
   // backdoor access
   ///////////////////////////////////////////////

   ///////////////////////////////////////////////
   // END backdoor access
   ///////////////////////////////////////////////

   assign L2M = 3'b000 ;
   assign SRAM = 1'b1 ;

   //read process for port A  
   for (genvar part = 0; part<NUM_PARTITIONS; part++) begin : g_ram_rd
      always_ff@(posedge CLKA) begin : ram_rd
         if(CENA==1'b0) begin
            begin
               QA[part*p +: p] <= ram_core[part][AA];
            end
         end         
      end
   end

   //write process for port B  
   for (genvar part = 0; part<NUM_PARTITIONS; part++) begin : g_ram_wr
      always_ff@(posedge CLKB) begin : ram_wr
         if(CENB==1'b0 && WENB[part]==1'b0) begin //COV:tag1
            begin
               //store X at targetted address for this partition
               ram_core[part][AB] <= DB[part*p +: p];
            end
         end
      end
   end

// synopsys translate_off

   ////////////////////////////////////////////////   
   // CONFIGURATION CHECKS
   ////////////////////////////////////////////////   
   initial begin : p_sanity_check_l2d_clkd
      as_rtl_dpstore_log2d_valid: assert ($clog2(d) == log2d) else 
         $error("ERROR gpc_gfx_dpstore in hierarchy %m: log2d(%0d) does not match depth(%0d)", log2d, d);
      //width is an integer multiple of partition size
      as_rtl_dpstore_w_p_valid: assert ((w/p) * p == w) else
         $error("ERROR gpc_gfx_dpstore in hierarchy %m: width(%0d) is not an integer multiple of partition width(%0d)", w, p);
   end

   ////////////////////////////////////////////////   
   // READ PORT A CHECKS
   ////////////////////////////////////////////////   
   always@(posedge CLKA) begin : p_porta_checks
      //do not check at time 0
      if($time > 0) begin //--COV:tag2
         

         //CENA not X
         as_rtl_dpstore_cena_not_x: assert(~$isunknown(CENA)) else
            $error("CENA input is X in module gpc_gfx_dpstore in hierarchy %m");
         
         //address not X, or not enabled
         as_rtl_dpstore_aa_not_x: assert(CENA || ~$isunknown(AA)) else
            $error("AA input is X in module gpc_gfx_dpstore in hierarchy %m");


         //address less than depth, or not enabled (dont trigger if 'AA' is X though, covered above)
         as_rtl_dpstore_aa_in_range: assert(CENA || (AA < d) || $isunknown(AA)) else
            $error("AA input is out of range in module gpc_gfx_dpstore in hierarchy %m");

         //not reading and writing to same address (dont trigger if 'AA' is X though, covered above)
         as_rtl_dpstore_no_rd_wr_clash: assert((CENB || (&WENB)) || CENA || AA!=AB || $isunknown(AA)) else
            $error("Read and write to same address in module gpc_gfx_dpstore in hierarchy %m");

      end   
   end : p_porta_checks

   ////////////////////////////////////////////////   
   // WRITE PORT B CHECKS
   ////////////////////////////////////////////////   
   always@(posedge CLKB) begin : p_portb_checks
      //do not check at time 0
      if($time > 0) begin //--COV:tag3


         //CENB not X
         as_rtl_dpstore_cenb_not_x : assert(~$isunknown(CENB)) else
            $error("CENB input is X in module gpc_gfx_dpstore in hierarchy %m");
         
         //address not X, or not enabled
         as_rtl_dpstore_an_not_x : assert(CENB || ~$isunknown(AB)) else
            $error("AB input is X in module gpc_gfx_dpstore in hierarchy %m");

         //WENB not X, or not enabled
         as_rtl_dpstore_wenb_not_x : assert(CENB || ~$isunknown(WENB)) else
            $error("WENB input is X in module gpc_gfx_dpstore in hierarchy %m");
         //address less than depth, not not enabled (dont trigger if 'AB' is X though, covered above)
         as_rtl_dpstore_ab_in_range : assert(CENB || (AB < d) || $isunknown(AB)) else
            $error("AB input is out of range in module gpc_gfx_dpstore in hierarchy %m");


      end
      
   end : p_portb_checks
   
// synopsys translate_on

`endif

//spyglass enable_block -rule "W241"
//spyglass enable_block -rule "W175"
//spyglass enable_block -rule "W240" 

endmodule
