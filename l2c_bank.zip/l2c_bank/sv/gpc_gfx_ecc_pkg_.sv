/*

 * #==========================================================================#
 * |                                                                          |
 * |  Copyright (c) 2022, Fantasy Technologies Limited and/or its         |
 * |  affiliated group companies ("Fantasy"). All rights reserved.        |
 * |  No part of this content, either material or conceptual may be copied    |
 * |  or distributed, transmitted, transcribed, stored in a retrieval system  |
 * |  or translated into any human or computer language in any form by any    |
 * |  means, electronic, mechanical manual, or otherwise, or disclosed to     |
 * |  third parties without the express written permission of Fantasy.    |
 * |                                                                          |
 * #==========================================================================#

 */
package gpc_gfx_ecc_pkg_;





   localparam integer                                           MIN_NUMBER_PROTECTED_REGIONS             = 4                             ;    // Threshold of minimum number of detectable adjacent fault

   localparam integer                                           RAM_THRESH                               = 2048                          ;    // The number of storage bits required before a RAM is used for implementation.

// ////////////////////////////////////////////////////////////-   
// bit width calculation
// ////////////////////////////////////////////////////////////-

   //return the factorial number

   //return the number of possible combinations
   //the number of object could be a or b, whichever is larger.

   //check the number of storage bits against RAM_THRESH

   //calculate the number of parity bits required for dw data bits.

   //return the encoded word length for each word partition, when an ECC generic is also taken into account.

   //return the required width of RAM for dw data bits.
   //the size of writing mask equals to pw.
   //an ECC generic is also taken into account.

   // calculate the width of error injection mask, if w*d is smaller than the threshold, no parity bit will be added.

   //set mask width to 1 when:
   //1.there are more than one mask.(dw/pw > 1)
   //2.ECC is enabled

   //return the width of write enable

   //calculate the number of protected regions
   //if ECC=0, return w/package
   //elsewise, return ceil(MIN_NUMBER_PROTECTED_REGIONS/(w/p)) * w/p


   //calculate the number of parity bits needed according to input data width
   function automatic integer calc_parity_width;
   input  integer                                           dw ;
   input  integer                                            ECC ;
   integer                                           r                                       ;
      if ( ( ECC == 0 ) ) begin

        r = 0 ;

      end else if ( ( ECC == 1 ) ) begin

         if ( ( dw <= 1 ) ) begin
            r = 3 ;
         end else if ( ( dw <= 4 ) ) begin
            r = 4 ;
         end else if ( ( dw <= 11 ) ) begin
            r = 5 ;
         end else if ( ( dw <= 26 ) ) begin
            r = 6 ;
         end else if ( ( dw <= 57 ) ) begin
            r = 7 ;
         end else if ( ( dw <= 120 ) ) begin
            r = 8 ;
         end else if ( ( dw <= 247 ) ) begin
            r = 9 ;
         end else if ( ( dw <= 502 ) ) begin
            r = 10 ;
         end else if ( ( dw <= 1013 ) ) begin
            r = 11 ;
         end else if ( ( dw <= 2036 ) ) begin
            r = 12 ;
         end else begin
            r = 0 ;
         end

      end else if ( ( ECC == 2 ) ) begin
         // use parity, instead of SEC-DED
         r = 1 ;
      end else begin
         r = 0 ;
      end

      return r ;

   endfunction // calc_parity_width

   //return the width of each partition with parity.
   function automatic integer calc_ecc_word_size;
   input  integer                                           pw ;
   input  integer                                            ECC ;
      return ( pw + calc_parity_width ( pw,ECC ) ) ;
   endfunction // calc_ecc_word_size

   //return the width of RAM for dw data bits.
   function automatic integer calc_ram_width;
   input  integer                                           dw ;
   input  integer                                            pw ;
   input  integer                                            ECC ;
      return ( ( dw / pw ) * calc_ecc_word_size ( pw,ECC ) ) ;
   endfunction // calc_ram_width

   // calculate the width of error injection mask, if w*d is smaller than the threshold, no parity bit will be added.
   function automatic integer err_inj_mask_width;
   input  integer                                           dw ;
   input  integer                                            pw ;
   input  integer                                            depth ;
   input  integer                                            ECC ;
      integer                                           NUM_PART                                 = num_protected_region ( dw,pw,ECC );    // number of protected regions. if ECC /=0, it should be at least N.
      integer                                           NUM_SUBPART                              = NUM_PART / ( dw / pw )        ;
      integer                                           SUBPART_WIDTH                            = ( pw + NUM_SUBPART - 1 ) / NUM_SUBPART;
      integer                                           PP_SIZE                                  = SUBPART_WIDTH * NUM_SUBPART   ;    // Padded partition size
      integer                                           PD_WIDTH                                 = PP_SIZE * dw / pw             ;    // Padded data width.
      integer                                           E_RAM_WIDTH                              = calc_ram_width ( PD_WIDTH,SUBPART_WIDTH,ECC );
      if ( ( ECC == 0 ) ) begin
         return dw ;
      end else begin
         return E_RAM_WIDTH ;
      end
   endfunction // err_inj_mask_width

   //set partition size to 1 when ECC is enabled and there are multiple write masks.
   function automatic integer calc_partition_size;
   input  integer                                           dw ;
   input  integer                                            pw ;
   input  integer                                            ECC ;
   input  integer                                           single_partition;
      if ( ( ECC != 0 & dw / pw > 1 & single_partition == 0) ) begin
         return 1 ;
      end else if ( ( single_partition == 1 ) ) begin
         return calc_ram_width ( dw,pw,ECC ) ;
      end else begin
         return calc_ecc_word_size ( pw,ECC ) ;
      end
   endfunction // calc_partition_size

   // return 1 if the RAM has only 1 partition
   function automatic integer is_single_partition;
   input integer                                         dw ;
   input integer                                         pw ;
      if ( dw / pw == 1) begin
         return 1 ;
      end else begin
         return 0 ;
      end
   endfunction // is_single_partition

   //return the width of write enable signal
   function automatic integer calc_wren_width;
   input  integer                                           dw ;
   input  integer                                            pw ;
   input  integer                                            ECC ;
   input  integer                                           single_partition;
      if ( ( dw / pw == 1 | single_partition == 1) ) begin
         return 1 ;
      end else if ( ( ECC != 0 ) ) begin
         return calc_ram_width ( dw,pw,ECC ) ;
      end else begin
         return dw / pw ;
      end
   endfunction // calc_wren_width

   //calculate the number of protected regions
   function automatic integer num_protected_region;
   input  integer                                           dw ;
   input  integer                                            pw ;
   input  integer                                            ECC ;
      if ( ( ECC == 0 ) ) begin
         return dw / pw ;
      end else begin
         return ( ( MIN_NUMBER_PROTECTED_REGIONS + ( dw / pw ) - 1 ) / ( dw / pw ) ) * ( dw / pw ) ;
      end
   endfunction // num_protected_region




endpackage
