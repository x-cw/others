/*

 * #==========================================================================#
 * |                                                                          |
 * |  Copyright (c) 2022, Fantasy Technologies Limited and/or its         |
 * |  affiliated group companies ("Fantasy"). All rights reserved.        |
 * |  No part of this content, either material or conceptual may be copied    |
 * |  or distributed, transmitted, transcribed, stored in a retrieval system  |
 * |  or translated into any human or computer language in any form by any    |
 * |  means, electronic, mechanical manual, or otherwise, or disclosed to     |
 * |  third parties without the express written permission of Fantasy.    |
 * |                                                                          |
 * #==========================================================================#

 */

package gpu_core_gfx_std_func_pack_;

   // clock gate ideal fanout (set in gpu_core_technology.tcl)
   localparam GPU_CORE_CLK_GATE_FANOUT = 32;

   // /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
   // Function Name: gpu_core_log2
   // Function Type: synthesisable
   // Function Input Parameters:
   //    d - must be a static value (i.e. not driven by logic)
   // Function Return Value:
   //    log2(d)
   // Function Description:
   //    Function has been written to avoid any synthesis, compilation or linteger warnings.
   //    Function will probably not compile if input is non-static (i.e. driven by logic). This would also not be an optimal
   //    implementation for a run-time log2 function.
   // /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
   function automatic integer gpu_core_log2(integer d);
      integer tmp, COUNT;
      tmp  = 1;
      for (integer COUNT = 0; COUNT < 31; COUNT++) begin // N.B. Synopsys requires static loops.
         if (tmp >= d)
           return COUNT;
         tmp = tmp*2;
      end
      // Should never get here, but add return statement to avoid spyglass warning
      return d;
   endfunction : gpu_core_log2

   // /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
   // Function Name: gpu_core_log2_roundup
   // Function Type: synthesisable
   // Function Input Parameters:
   //    d - must be a static value (i.e. not driven by logic)
   // Function Return Value:
   //    log2(d)
   // Function Description:
   //    If d = 1, then 1 will be returned as the result rather than 0
   //    Otherwise calls gpu_core2_log2 as normal
   // /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
   function automatic integer gpu_core_log2_roundup(integer d);
      if (d <= 1)                                        // On d = 1, roundup to 1 instead of returning 0
         return 1;
      else
         return gpu_core_log2(d);
   endfunction : gpu_core_log2_roundup

   // given a positive integer, will return the
   // closest powerof2 less than or equal to
   // get_closest_pow2(7) = 4, get_closest_pow2(16) = 16
   function automatic integer get_closest_pow2(integer d);
      integer tmp = 1;
      for (integer COUNT = 0; COUNT < 31; COUNT++) begin // N.B. Synopsys requires static loops.
         if (tmp*2 <= d)
            tmp = tmp*2;
      end
      if (d == 0)
         tmp = 0;

      return tmp;
   endfunction : get_closest_pow2

   // given two positive integers a,b
   // will return ceil(a/b)
   function automatic integer get_ceil_quotient (integer a, integer b);
      if (a % b == 0)
         return a/b;
      else
         return a/b + 1;
   endfunction : get_ceil_quotient

   // /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
   // Function Name: gpu_core_max
   // Function Type: synthesisable
   // Function Input Parameters:
   //    a,b  - should be static values
   // Function Return Value:
   //    max(a,b)
   // Function Description:
   //    function implementation is trivial. It is intended for use with static values, for example to configure the width of a vector
   //    instantiation.
   //    function should not be driven by logic, as it is preferable to operate on std_logic_vectors in such cases in order to reduce
   //    reliance on optimisation by synthesis tool.
   // /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
   function automatic integer gpu_core_max(integer a, integer b);
      if (a > b)
         return a;
      else
        return b;
   endfunction : gpu_core_max
   // /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
   // Function Name: gpu_core_min
   // Function Type: synthesisable
   // Function Input Parameters:
   //    a,b  - should be static values
   // Function Return Value:
   //    min(a,b)
   // Function Description:
   //    function implementation is trivial. It is intended for use with static values, for example to configure the width of a vector
   //    instantiation.
   //    function should not be driven by logic, as it is preferable to operate on std_logic_vectors in such cases in order to reduce
   //    reliance on optimisation by synthesis tool.
   // /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
   function automatic integer gpu_core_min(integer a, integer b);
      if (a < b)
        return a;
      else
        return b;
   endfunction : gpu_core_min


endpackage : gpu_core_gfx_std_func_pack_
