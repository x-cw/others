// --------------------------------------------------------------------------------------------------------------------------------- 
// entity name: gc_bif4_pack 
// purpose: BIF Constants, Interface Types and Conversion functions 
// --------------------------------------------------------------------------------------------------------------------------------- 
package spc_bif_pack_; 
   import pkg_mh_::*; 
   import pkg_bif_::*; 
 
 
   // Enables dumping of MCU/BIF text files which allow transactions to be played back in memory subsystem TB's 
   localparam logic      DUMP_MEM_SUBSYSTEM_OUTFILES   = 1'b0; 
 
   typedef logic   [BIF_BURST_LENGTH_WIDTH - 1:0]         bif_burst_length_array; 
   typedef logic   [VADDR_BIF_WIDTH - 1:VADDR_LOW]         bif_vaddress_array; 
 
   localparam int unsigned   BIF_DEBUG_ID_READ_SPLIT        = 26; 
   localparam int unsigned   BIF_DEBUG_ID_READ_SPLIT_LAST   = 27; 
   localparam int unsigned   BIF_DEBUG_ID_READ_SPLIT_MSI    = 28; 
   localparam int unsigned   BIF_DEBUG_ID_READ_SPLIT_CI     = 29; 
   localparam int unsigned   BIF_DEBUG_ID_PP_SPLIT          = 30; 
   localparam int unsigned   BIF_DEBUG_ID_PP_SPLIT_LAST     = 31; 
 
   //----------------- 
   // REQUESTOR IDS -- 
   //----------------- 
   typedef logic [REQ_ID_BITS-1:0]     req_id_type; 
   typedef req_id_type                 req_id_array_type; 
   
   localparam req_id_array_type           SPC_BIF_MCUL1_ID_ARRAY         [6:0]   = '{ 54,53,52,51,50,49,48 }; 
   localparam req_id_type                 SPC_BIF_L2_ICACHE_ID                        = 55; 
   localparam req_id_type                 SPC_BIF_BSC_ID                        = 56; 
   localparam req_id_type                 BIF2AXI_RAW_READ_ID                  = 57;
 
   localparam int unsigned                SPC_BIF_MCUL1_ID_INDEX_NUM_BITS      = $clog2($size(SPC_BIF_MCUL1_ID_ARRAY)); 
 
   //-------------------------- 
   // SPC_BIF PARAMETERS per bif-- 
   //-------------------------- 
   localparam int unsigned                                                SPC_BIF_REQUESTOR_NUM_MAX                = 3; 
   localparam int unsigned                                                SPC_BIF_ARB_INDEX_OFFSET                 = 0; 
   localparam int unsigned                                                SPC_BIF_FIRST_BS_INDEX                   = 3; 
   localparam int unsigned                                                SPC_BIF_REQUESTOR_NUM_BITS               = $clog2(SPC_BIF_REQUESTOR_NUM); 
   localparam int unsigned                                                SPC_BIF_REQUESTOR_MAX_BITS               = $clog2(SPC_BIF_REQUESTOR_NUM_MAX); 
   localparam int unsigned                                                SPC_BIF_OS_RD_COUNTER_WIDTH              = 16; 
   localparam int unsigned                                                SPC_BIF_OS_RTN_MEM_COUNT_WIDTH           = 9; 
   // Note: The indices for non-reordered requestors should be before the ordered requestors. 
   // This is to simplify the arbiter where burst splitting is not used for non-reordered requestors 
   // The ray tracing indices are non-reordered and need an index lower than the ordered requestors. 
 
 
 
 
 
   // per requestor 
   // requestor can read  
   localparam logic [SPC_BIF_REQUESTOR_MAX_BITS-1 : 0]                     SPC_BIF_MCUL1_ARB_INDEX                    = 0 + SPC_BIF_ARB_INDEX_OFFSET; 
   localparam logic [SPC_BIF_REQUESTOR_MAX_BITS-1 : 0]                     SPC_BIF_L2_ICACHE_ARB_INDEX                    = 1 + SPC_BIF_ARB_INDEX_OFFSET; 
   localparam logic [SPC_BIF_REQUESTOR_MAX_BITS-1 : 0]                     SPC_BIF_BSC_ARB_INDEX                    = 2 + SPC_BIF_ARB_INDEX_OFFSET; 
 
   function automatic logic [0:SPC_BIF_REQUESTOR_NUM_MAX - 1] set_spc_bif_req_read ( 
   ); 
      logic [0:SPC_BIF_REQUESTOR_NUM_MAX - 1] result; 
      result[SPC_BIF_MCUL1_ARB_INDEX]      = 1'b1; 
      result[SPC_BIF_L2_ICACHE_ARB_INDEX]      = 1'b1; 
      result[SPC_BIF_BSC_ARB_INDEX]      = 1'b1; 
      return result; 
   endfunction : set_spc_bif_req_read  
   localparam logic [0:SPC_BIF_REQUESTOR_NUM_MAX-1] SPC_BIF_REQ_READ = set_spc_bif_req_read(); 
 
   // requestor can write  
   function automatic logic [0:SPC_BIF_REQUESTOR_NUM_MAX-1] set_spc_bif_req_write(); 
      logic [0:SPC_BIF_REQUESTOR_NUM_MAX-1]         result; 
      result[SPC_BIF_MCUL1_ARB_INDEX]      = 1'b1; 
      result[SPC_BIF_L2_ICACHE_ARB_INDEX]      = 1'b1; 
      result[SPC_BIF_BSC_ARB_INDEX]      = 1'b1; 
    
         return result; 
      endfunction : set_spc_bif_req_write 
   localparam logic [0:SPC_BIF_REQUESTOR_NUM_MAX-1] SPC_BIF_REQ_WRITE = set_spc_bif_req_write(); 
 
   function automatic logic [0:SPC_BIF_REQUESTOR_NUM_MAX - 1] set_spc_bif_req_rtn_mem ( 
   ); 
      logic [0:SPC_BIF_REQUESTOR_NUM_MAX - 1] result; 
      result[SPC_BIF_MCUL1_ARB_INDEX]      = 1'b1; 
      result[SPC_BIF_L2_ICACHE_ARB_INDEX]      = 1'b1; 
      result[SPC_BIF_BSC_ARB_INDEX]      = 1'b1; 
      return result; 
   endfunction : set_spc_bif_req_rtn_mem 
   // requestor have rtn_mem 
   localparam logic [0:SPC_BIF_REQUESTOR_NUM_MAX-1] SPC_BIF_REQ_RTN_MEM = set_spc_bif_req_rtn_mem(); 
 
 
   function automatic logic [0:SPC_BIF_REQUESTOR_NUM_MAX - 1] set_spc_bif_req_burst_splitting ( 
   ); 
      logic [0:SPC_BIF_REQUESTOR_NUM_MAX - 1] result; 
      result[SPC_BIF_MCUL1_ARB_INDEX]      = 1'b1; 
      result[SPC_BIF_L2_ICACHE_ARB_INDEX]      = 1'b1; 
      result[SPC_BIF_BSC_ARB_INDEX]      = 1'b1; 
      return result; 
   endfunction : set_spc_bif_req_burst_splitting 
   // requestor can split 
   localparam logic [0:SPC_BIF_REQUESTOR_NUM_MAX-1] SPC_BIF_REQ_BURST_SPLITTING = set_spc_bif_req_burst_splitting(); 
 
 
   // timing buffer constants 0=wire, 1=simple pipe, 2=RSTl, 3=RSTL LOPOWER and 4=RSTL FAST IN. 
   localparam int unsigned                                               SPC_BIF_MCUL1_REQ_TBUFF_TYPE               = 2; 
   localparam int unsigned                                               SPC_BIF_MCUL1_WRITE_TBUFF_TYPE             = 0; 
   localparam int unsigned                                               SPC_BIF_MCUL1_RTN_TBUFF_TYPE               = 0; 
   localparam int unsigned                                               SPC_BIF_L2_ICACHE_REQ_TBUFF_TYPE               = 2; 
   localparam int unsigned                                               SPC_BIF_L2_ICACHE_WRITE_TBUFF_TYPE             = 0; 
   localparam int unsigned                                               SPC_BIF_L2_ICACHE_RTN_TBUFF_TYPE               = 0; 
   localparam int unsigned                                               SPC_BIF_BSC_REQ_TBUFF_TYPE               = 2; 
   localparam int unsigned                                               SPC_BIF_BSC_WRITE_TBUFF_TYPE             = 0; 
   localparam int unsigned                                               SPC_BIF_BSC_RTN_TBUFF_TYPE               = 0; 
   localparam int unsigned                                               SPC_BIF_BIF_CVT_REQ_TBUFF_TYPE           = 1; 
   localparam int unsigned                                               SPC_BIF_BIF_CVT_RTN_TBUFF_TYPE           = 2; 
   localparam logic                                                      SPC_BIF_BIF_CVT_WRITE_FIFO               = 1'b1; 
   localparam int unsigned                                               SPC_BIF_BIF_CVT_WRITE_FIFO_DEPTH         = 4; 
   localparam int unsigned                                               SPC_BIF_BIF_CVT_WRITE_TBUFF_TYPE         = 0; 
   // --------------------------------------- 
   // RETURN MUX PARAMETERS 
   // --------------------------------------- 
   localparam int unsigned                                 RETURN_MUX_REQUESTOR_NUM            = 2; 
   localparam int unsigned                                 RETURN_MUX_REQUESTOR_NUM_BITS       = $clog2(RETURN_MUX_REQUESTOR_NUM); 
 
 
   typedef struct packed { 
      logic   [BIF_DATA_BUS_WIDTH - 1:0]     data; 
      logic   [BIF_DATA_BUS_WIDTH/8 - 1:0]   mask; 
   } req_bif_write_rec; 
   localparam   int unsigned REQ_BIF_WRITE_REC_BITS                         = BIF_DATA_BUS_WIDTH/8 + BIF_DATA_BUS_WIDTH; // mask, data 
 
      typedef struct packed { 
            logic   [BIF_DATA_BUS_WIDTH - 1:0]         data; 
            logic   [(BIF_DATA_BUS_WIDTH/8)/4 - 1:0]   dword_partial; 
            logic   [(BIF_DATA_BUS_WIDTH/8)/4 - 1:0]   dword_active; 
         } bif2axi_write_struct; 
   localparam   int unsigned BIF2AXI_WRITE_STRUCT_BITS                         = BIF_DATA_BUS_WIDTH/8/2 + BIF_DATA_BUS_WIDTH; // mask, data 
 
 
 
endpackage : spc_bif_pack_ 
