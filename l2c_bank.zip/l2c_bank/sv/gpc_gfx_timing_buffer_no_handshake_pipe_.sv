

module gpc_gfx_timing_buffer_no_handshake_pipe_
#(
      parameter int                                      WIDTH                                                        = 32             ,
      parameter int                                      PIPE_STAGES                                                  = 1              ,
      parameter logic    [WIDTH-1:0]                     INI_DAT                                                      = {WIDTH{1'b0}}
)
(
      input    logic                                                        clk                                     ,
      input    logic                                                        resetn                                  ,
      // Input V/E Interface
      input    logic [ WIDTH - 1 : 0 ]                                      tbuff_in_data                           ,
      // Output V/E Interface

      output   logic [ WIDTH - 1 : 0 ]                                      tbuff_out_data
);

   import gpc_gfx_timing_buffer_pack_::*;

   logic  [PIPE_STAGES-1 :0]               in_valid_array    ;
   logic  [PIPE_STAGES-1 :0]               in_enable_array   ;

   logic  [PIPE_STAGES-1 :0][WIDTH-1 :0]   in_data_array     ;
   logic  [PIPE_STAGES-1 :0][WIDTH-1 :0]   out_data_array    ;

   //input connect
   assign in_data_array[0]                   = tbuff_in_data                     ;

   //output connect
   assign tbuff_out_data                     = out_data_array[PIPE_STAGES-1]     ;

   //inner connect
   always_comb begin
      for (int buffer_idx=0; buffer_idx<PIPE_STAGES-1; buffer_idx++) begin
         in_data_array[buffer_idx+1]  = out_data_array[buffer_idx]      ;
      end
   end



   //generate gpc_gfx_timing_buffer_no_handshake_ instance
   genvar i;
   generate
      for (i=0; i < PIPE_STAGES; i=i+1) begin : g_gen_gpc_gfx_timing_buffer
         gpc_gfx_timing_buffer_no_handshake_
         #(
               .INI_DAT     (INI_DAT),
               .WIDTH       (WIDTH)
         )i_timing_buffer_
         (
               .clk             (clk      ),
               .resetn          (resetn   ),

               .tbuff_in_data   (in_data_array[i]   ),

               .tbuff_out_data  (out_data_array[i]  )
         );

      end
   endgenerate

endmodule // gpc_gfx_timing_buffer_no_handshake_pipe_
