/*


 */

// ---------------------------------------------------------------------------------------------------------------------------------
// entity name: gc_l2_bank_int_alu
// purpose: Combinatorial ALU capable of performing one 64-bit Atomic Operation, or two 32-bit Atomic Operations in parallel
// ---------------------------------------------------------------------------------------------------------------------------------
module gc_l2_bank_int_alu
import gc_l2_bank_pkg::*;
(
   input  logic                              aa_64bit,
   input  logic   [L2_AA_OP_WIDTH - 1:0]     aa_operation,
   input  logic   [63:0]                     aa_source,
   input  logic   [63:0]                     aa_operand_a,
   input  logic   [63:0]                     aa_operand_b,
   output logic   [ 1:0]                     aa_rlt_upd,
   output logic   [63:0]                     aa_destination
);

   // split the 64-bit operands into 32-bit data to be computed by two 32-bit ALUs
   logic [31:0]   alu0_src;
   logic [31:0]   alu0_op_a;
   logic [31:0]   alu0_op_b;
   logic [31:0]   alu1_src;
   logic [31:0]   alu1_op_a;
   logic [31:0]   alu1_op_b;
   // ALU 0 signals
   logic [32:0]   alu0_src_unsigned;
   logic [32:0]   alu0_src_signed;
   logic [32:0]   alu0_op_a_unsigned;
   logic [32:0]   alu0_op_a_unsigned_inv;
   logic [32:0]   alu0_op_a_signed_inv;
   logic [32:0]   alu0_op_a_inv;
   logic [32:0]   alu0_lhs;
   logic [32:0]   alu0_rhs;
   logic [32:0]   alu0_sum;
   logic [0:0]    alu0_cin;
   logic          alu0_cout;
   logic [31:0]   alu0_result;
   // ALU 1 signals
   logic [32:0]   alu1_src_unsigned;
   logic [32:0]   alu1_src_signed;
   logic [32:0]   alu1_op_a_unsigned;
   logic [32:0]   alu1_op_a_unsigned_inv;
   logic [32:0]   alu1_op_a_signed_inv;
   logic [32:0]   alu1_op_a_inv;
   logic [32:0]   alu1_lhs;
   logic [32:0]   alu1_rhs;
   logic [32:0]   alu1_sum;
   logic [1:0]    alu1_cin;
   logic          alu1_cout;
   logic [31:0]   alu1_result;
   logic          signed_min_or_max;
   logic          any_subtract;







   assign alu0_src = aa_source[31:0];
   assign alu0_op_a = aa_operand_a[31:0];
   assign alu0_op_b = aa_operand_b[31:0];
   assign alu1_src = aa_source[63:32];
   assign alu1_op_a = aa_operand_a[63:32];
   assign alu1_op_b = aa_operand_b[63:32];
   assign signed_min_or_max = ((aa_operation==L2_AA_OP_IMIN) || (aa_operation==L2_AA_OP_IMAX)) ? 1'b1 : 1'b0;
   assign any_subtract = ((aa_operation==L2_AA_OP_UMIN) || (aa_operation==L2_AA_OP_IMIN) || (aa_operation==L2_AA_OP_UMAX) || (aa_operation==L2_AA_OP_IMAX) || (aa_operation==L2_AA_OP_SUB)) ? 1'b1 : 1'b0;
   // ----------------------------------------------------------------------------
   // ALU0
   // ----------------------------------------------------------------------------
   assign alu0_src_unsigned = {1'b0, alu0_src};
   assign alu0_src_signed = {alu0_src[$high(alu0_src)], alu0_src};
   assign alu0_op_a_unsigned = {1'b0, alu0_op_a};
   assign alu0_op_a_unsigned_inv = ~alu0_op_a_unsigned;
   assign alu0_op_a_signed_inv = ~({alu0_op_a[$high(alu0_op_a)], alu0_op_a});
   // 32bit 
   //   signed_min_or_max == 1 -> alu0_op_a_signed_inv  , alu0_src_signed
   //   signed_min_or_max == 0 -> alu0_op_a_unsigned_inv, alu0_src_unsigned
   // 64bit 
   //   signed_min_or_max == 0/1 -> alu0_op_a_unsigned_inv, alu0_src_unsigned
   assign alu0_op_a_inv = (signed_min_or_max==1'b1 && aa_64bit==1'b0) ? alu0_op_a_signed_inv : alu0_op_a_unsigned_inv;
   assign alu0_lhs = (signed_min_or_max==1'b0 || aa_64bit==1'b1) ? alu0_src_unsigned : alu0_src_signed;
   assign alu0_rhs = any_subtract==1'b0 ? alu0_op_a_unsigned : alu0_op_a_inv;
   // Adder used to perform ADD,SUB,MAX,MIN operations
   assign alu0_cin[0] = any_subtract;
   assign alu0_sum = (alu0_lhs + alu0_rhs + {32'b0, alu0_cin});
   assign alu0_cout = alu0_sum[$high(alu0_sum)];
   // ----------------------------------------------------------------------------
   // ALU1
   // ----------------------------------------------------------------------------
   assign alu1_src_unsigned = {1'b0, alu1_src};
   assign alu1_src_signed = {alu1_src[$high(alu1_src)], alu1_src};
   assign alu1_op_a_unsigned = {1'b0, alu1_op_a};
   assign alu1_op_a_unsigned_inv = ~alu1_op_a_unsigned;
   assign alu1_op_a_signed_inv = ~({alu1_op_a[$high(alu1_op_a)], alu1_op_a});
   assign alu1_op_a_inv = signed_min_or_max==1'b1 ? alu1_op_a_signed_inv : alu1_op_a_unsigned_inv;
   assign alu1_lhs = signed_min_or_max==1'b0 ? alu1_src_unsigned : alu1_src_signed;
   assign alu1_rhs = any_subtract==1'b0 ? alu1_op_a_unsigned : alu1_op_a_inv;
   // Adder used to perform ADD,SUB,MAX,MIN operations
   assign alu1_cin[0] = aa_64bit==1'b1 ? alu0_cout ^ any_subtract : any_subtract;
   assign alu1_cin[1] = 1'b0;
   assign alu1_sum = (alu1_lhs + alu1_rhs + {31'b0, alu1_cin});
   assign alu1_cout = alu1_sum[$high(alu1_sum)];




   always_comb begin : p_alu_result_sel_comb
      alu0_result = alu0_src;
      alu1_result = alu1_src;
      aa_rlt_upd  = 2'b00;

      case(aa_operation)
         L2_AA_OP_ADD, L2_AA_OP_SUB : begin
            alu0_result = alu0_sum[31:0];
            alu1_result = alu1_sum[31:0];
            aa_rlt_upd  = 2'b11;
         end
         L2_AA_OP_XCHG : begin
            alu0_result = alu0_op_a;
            alu1_result = alu1_op_a;
            aa_rlt_upd  = 2'b11;
         end
         L2_AA_OP_CMPXCHG : begin
            if(aa_64bit==1'b1) begin
               if(alu0_src==alu0_op_a && alu1_src==alu1_op_a) begin //COV:tag0
                  alu0_result = alu0_op_b;
                  alu1_result = alu1_op_b;
                  aa_rlt_upd  = 2'b11;
               end
            end
            else begin
               if(alu0_src==alu0_op_a) begin
                  alu0_result = alu0_op_b;
                  aa_rlt_upd[0] = 1'b1;
               end
               if(alu1_src==alu1_op_a) begin
                  alu1_result = alu1_op_b;
                  aa_rlt_upd[1] = 1'b1;
               end
            end
         end
         L2_AA_OP_UMAX, L2_AA_OP_IMAX : begin
            if(aa_64bit==1'b1) begin
               if(alu1_cout==1'b1) begin
                  alu0_result = alu0_op_a;
                  alu1_result = alu1_op_a;
                  aa_rlt_upd  = ((alu0_op_a != alu0_src) || (alu1_op_a != alu1_src)) ? 2'b11 : 2'b00;
               end
            end
            else begin
               if(alu0_cout==1'b1) begin
                  alu0_result = alu0_op_a;
                  aa_rlt_upd[0] = (alu0_op_a != alu0_src) ? 1'b1 : 1'b0;
               end
               if(alu1_cout==1'b1) begin
                  alu1_result = alu1_op_a;
                  aa_rlt_upd[1] = (alu1_op_a != alu1_src) ? 1'b1 : 1'b0;
               end
            end
         end
         L2_AA_OP_UMIN, L2_AA_OP_IMIN : begin
            if(aa_64bit==1'b1) begin
               if(alu1_cout==1'b0) begin
                  alu0_result = alu0_op_a;
                  alu1_result = alu1_op_a;
                  aa_rlt_upd  = ((alu0_op_a != alu0_src) || (alu1_op_a != alu1_src)) ? 2'b11 : 2'b00;
               end
            end
            else begin
               if(alu0_cout==1'b0) begin
                  alu0_result = alu0_op_a;
                  aa_rlt_upd[0] = (alu0_op_a != alu0_src) ? 1'b1 : 1'b0;
               end
               if(alu1_cout==1'b0) begin
                  alu1_result = alu1_op_a;
                  aa_rlt_upd[1] = (alu1_op_a != alu1_src) ? 1'b1 : 1'b0;
               end
            end
         end
         L2_AA_OP_AND : begin
            alu0_result = alu0_src & alu0_op_a;
            alu1_result = alu1_src & alu1_op_a;
            aa_rlt_upd  = 2'b11;
         end
         L2_AA_OP_OR : begin
            alu0_result = alu0_src | alu0_op_a;
            alu1_result = alu1_src | alu1_op_a;
            aa_rlt_upd  = 2'b11;
         end
         L2_AA_OP_XOR : begin
            alu0_result = alu0_src ^ alu0_op_a;
            alu1_result = alu1_src ^ alu1_op_a;
            aa_rlt_upd  = 2'b11;
         end
         default : begin //reserved operation does not modify data
            alu0_result = alu0_src;
            alu1_result = alu1_src;
            aa_rlt_upd  = 2'b00;
         end
      endcase
   end : p_alu_result_sel_comb

   assign aa_destination[31:0] = alu0_result;
   assign aa_destination[63:32] = alu1_result;
endmodule
