/*

 * #==========================================================================#
 * |                                                                          |
 * |  Copyright (c) 2023, Fantasy Technologies Limited and/or its         |
 * |  affiliated group companies ("Fantasy"). All rights reserved.        |
 * |  No part of this content, either material or conceptual may be copied    |
 * |  or distributed, transmitted, transcribed, stored in a retrieval system  |
 * |  or translated into any human or computer language in any form by any    |
 * |  means, electronic, mechanical manual, or otherwise, or disclosed to     |
 * |  third parties without the express written permission of Fantasy.    |
 * |                                                                          |
 * #==========================================================================#

 */

// ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////-
// entity name: _gpu_core_mss_gfx_rffifo
// purpose: dual port register file based fifo with 0 threshold flags
// ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////-

module gpu_core_mss_gfx_rffifo_
   import gpc_gfx_rambist_pack_::*;
  #(
    parameter   ECC                                      = 0,  // integer
    parameter   id                                       = 0,  // integer
    parameter   use_gray_code                            = 0,  // integer
    parameter   use_flush                                = 0,  // integer
    parameter   w                                        = 32, // integer
    parameter   d                                        = 8,  // integer
    parameter   log2d                                    = 3   // integer
   )
   (
    input  logic                                      clk,
    input  logic                                      resetn,
    input  logic                                      flush,
    input  logic                                      fifo_in_valid,
    output logic                                      fifo_in_enable,
    input  logic [w-1 : 0]                            fifo_in_data,
    output logic                                      fifo_out_valid,
    input  logic                                      fifo_out_enable,
    output logic [w-1 : 0]                            fifo_out_data,






    // bist
    input  logic [dpstore_in (w, w, d, ECC) - 1 : 0]  bist_in,
    output logic [dpstore_out (w, w, d, ECC) - 1 : 0] bist_out,
    input  logic                                      tst_gclkenable
);

   import gpc_gfx_std_func_pack_::*;




   localparam MAXPTR = d - 1;

   logic                                              fifo_in_enable_l;
   logic                                              fifo_out_enable_l;

   // pointers to locations to write/read to in the FIFO array
   logic [log2d - 1 : 0]                              read_addr;
   logic [log2d - 1 : 0]                              n_read_addr;
   logic [log2d - 1 : 0]                              write_addr;
   logic [log2d - 1 : 0]                              n_write_addr;
   logic                                              addresses_equal;
   logic [log2d - 1 : 0]                              read_addr_encoded;
   logic [log2d - 1 : 0]                              write_addr_encoded;

   logic [0 : 0]                                      write_strobe_n;
   logic [0 : 0]                                      bypass_load;

   logic                                              disable_reads;
   logic                                              read_strobe_n;
   logic                                              read_r;
   logic                                              read_data_valid;
   logic                                              read_data_enable;
   logic [w - 1 : 0]                                  read_data;
   









   // sanity check log2d (address range) against the actual depth of the fifo
   //









   //
   // Artisan dual port register file with BIST add-on
   //
   gpu_core_mss_gfx_dpstore_bypass_gen_bist_r_
      #(
         .ECC(ECC),
         .id(id),
         .w(w),
         .p(w),
         .d(d),
         .log2d(log2d)
        ) i_gpu_core_mss_gfx_dpstore_bypass_gen_bist_r_
      (
         .clk(clk),
         .resetn(resetn),

         .rd_en(read_strobe_n),
         .rd_addr(read_addr_encoded),
         .bypass_load(bypass_load),
         .bypass_data(fifo_in_data),
         .rd_data(read_data),

         .wr_addr(write_addr_encoded),
         .wr_data(fifo_in_data),
         .wr_en(write_strobe_n),







         .bist_in(bist_in),
         .bist_out(bist_out),

         .tst_gclkenable(tst_gclkenable)
        );


   // Bypass write around the RAM when a write is received and the FIFO is empty which is detected by the enable being high and the
   // two sets of pointers being equal.
   assign bypass_load = (fifo_in_valid == 1'b1 && fifo_in_enable_l == 1'b1 && addresses_equal == 1'b1 && read_r == 1'b0 && (read_data_valid == 1'b0 || read_data_enable == 1'b1)) ? 1'b1 : 1'b0; // COV:tag11

   assign write_strobe_n = (fifo_in_valid == 1'b1 && fifo_in_enable_l == 1'b1 && bypass_load == 1'b0) ? 1'b0 : 1'b1; // COV:tag12

   assign disable_reads = ((read_r == 1'b1 && read_data_valid == 1'b1 && (read_data_enable == 1'b0 || fifo_out_enable == 1'b0)) || ((read_r == 1'b1 || read_data_valid == 1'b1) && read_data_enable == 1'b0 && fifo_out_enable == 1'b0)) ? 1'b1 : 1'b0; // COV:tag4

   assign read_strobe_n = ((addresses_equal == 1'b0 || fifo_in_enable_l == 1'b0) && disable_reads == 1'b0) ? 1'b0 : 1'b1; // COV:tag13

   // //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
   // Control signals for the FIFO and output register stage
   // //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
   always_ff@(posedge clk or  negedge resetn) begin : p_fifo_control_clkdrs
      if (resetn == 1'b0) begin
         write_addr       <= 0;
         read_addr        <= 0;
         read_r           <= 1'b0;
         read_data_valid  <= 1'b0;
         fifo_in_enable_l <= 1'b1;
      end else begin
         // flush resets the counters and flags
         if (use_flush == 1 && flush == 1'b1) begin // COV:tag1
            write_addr <= 0; // COV:tag0
            read_addr <= 0;
            read_r <= 1'b0;
            read_data_valid <= 1'b0;
            fifo_in_enable_l <= 1'b1;
         end else begin
            read_r <= !read_strobe_n;

            if (write_strobe_n == 1'b0) begin
               write_addr <= n_write_addr;
               if (n_write_addr == read_addr && read_strobe_n == 1'b1) begin // COV:tag14
                  fifo_in_enable_l <= 1'b0; // COV:tag10
               end
            end

            if (read_strobe_n == 1'b0) begin
               read_addr <= n_read_addr;
               if (fifo_in_enable_l == 1'b0) begin
                  fifo_in_enable_l <= 1'b1; // COV:tag10
               end
            end

            if (bypass_load == 1'b1 || read_r == 1'b1) begin
               read_data_valid <= 1'b1;
            end else if (read_data_enable == 1'b1) begin
               read_data_valid <= 1'b0;
            end
         end
      end
   end

   assign n_write_addr = (write_addr == MAXPTR) ? 0 : write_addr + 1'b1; // COV:tag15
   assign n_read_addr  = (read_addr  == MAXPTR) ? 0 : read_addr  + 1'b1; // COV:tag15

   assign addresses_equal = (write_addr == read_addr) ? 1'b1 : 1'b0;

   generate
      if (use_gray_code == 0) begin : g_no_use_gray_code
         assign read_addr_encoded  = read_addr;
         assign write_addr_encoded = write_addr;
      end  : g_no_use_gray_code
   endgenerate

   generate
      if (use_gray_code == 1) begin : g_use_gray_code
         gpc_gfx_gray_encode                #(.D(d))
         i_write_addr_gpc_gfx_gray_encode   (.addr_in(write_addr),
                                              .result(write_addr_encoded)  
                                             );
         gpc_gfx_gray_encode                #(.D(d))
         i_read_addr_gpc_gfx_gray_encode   (.addr_in(read_addr),
                                              .result(read_addr_encoded)  
                                             );
      end : g_use_gray_code
   endgenerate


   gpc_gfx_mstl_ #(.w(w))
   i_gpc_gfx_mstl (.clk (clk),
                   .resetn (resetn),
                   .din (read_data),
                   .vin (read_data_valid),
                   .eout (read_data_enable),
                   .dout (fifo_out_data),
                   .vout (fifo_out_valid),
                   .ein (fifo_out_enable_l)
                   );

   // assign outputs
   assign fifo_in_enable = fifo_in_enable_l;

   generate
      if (use_flush == 0) begin : g_no_flush
         assign fifo_out_enable_l  = fifo_out_enable;
      end : g_no_flush
   endgenerate

   generate
      if (use_flush == 1) begin : g_use_flush
         assign fifo_out_enable_l  = fifo_out_enable || flush; // COV:tag2
      end : g_use_flush
   endgenerate

endmodule
