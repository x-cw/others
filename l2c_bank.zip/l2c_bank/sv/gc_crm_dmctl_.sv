/*

 * #==========================================================================#
 * |                                                                          |
 * |  Copyright (c) 2022, Fantasy Technologies Limited and/or its         |
 * |  affiliated group companies ("Fantasy"). All rights reserved.        |
 * |  No part of this content, either material or conceptual may be copied    |
 * |  or distributed, transmitted, transcribed, stored in a retrieval system  |
 * |  or translated into any human or computer language in any form by any    |
 * |  means, electronic, mechanical manual, or otherwise, or disclosed to     |
 * |  third parties without the express written permission of Fantasy.    |
 * |                                                                          |
 * #==========================================================================#

 */

// ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////-
// entity name: gc_crm_dmctl_
// purpose: Supplies the control signals for a clock domain indicating when the clock may be gated.
// Reads in the idle status signals from each of the sub blocks as well as the global clock gating control registers and sorts out
// whether the clock gating signal is to be asserted or not.
// Also provides override power control capability during manual (software) register updates, so that a host can
// enable the clock domain if required.
// ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////-

module gc_crm_dmctl_
import gc_cr_global_regfields_::*;
#(
      parameter int                                      NUM_WAKEUP_SIGNALS                                           = 1,    // Number of domain wakeup event signals
      parameter int                                      NUM_IDLE_SIGNALS                                             = 1                   // Number of domain idle signals 
)
(
      input    logic                                                        core_clk_aligned,    // core clock
      input    logic                                                        domain_clk,
      input    logic                                                        core_resetn,
      input    logic [ 4 : 0 ]                                              gc_cr_pwr_man_hysteresis_value,
      input    logic [ 1 : 0 ]                                              gc_cr_crm_reset_clk_ctrl,
      input    logic                                                        soft_reset,
      // --------------------------------
      // Automatic Power Control Signals
      // --------------------------------
      input    logic [ NUM_WAKEUP_SIGNALS - 1 : 0 ]                         domain_wakeup_events,    // These signals will force the clock domain to be enabled
      input    logic [ NUM_IDLE_SIGNALS - 1 : 0 ]                           domain_idles_in,    // These signals indicate if clk domain is idle
      input    logic [ 1 : 0 ]                                              gc_cr_clk_ctrl_domain,    // Configures the clock domain
      output   logic                                                        domain_clk_en,    // Indicates if the clock is to be enabled
      // --------------------------------
      // Clock Status Signals
      // --------------------------------
      output   logic                                                        gc_cr_clk_status_domain                     // Indicates if the clock is running back to global register 
);

   localparam logic [ 1 : 0 ]                               CLK_CTRL_MODE_OFF                        = GC_CR_CLK_CTRL0_MODE_OFF;
   localparam logic [ 1 : 0 ]                               CLK_CTRL_MODE_ON                         = GC_CR_CLK_CTRL0_MODE_ON;
   localparam logic [ 1 : 0 ]                               CLK_CTRL_MODE_AUTO                       = GC_CR_CLK_CTRL0_MODE_AUTO;

   logic [ 4 : 0 ]                               max_idle_hysteresis_count;

   logic                                         domain_clk_on_req;    // request from either the host override or clock gate control (this could be manual or automatic)
   logic [ 4 : 0 ]                               idle_hysteresis_count;    // counter used to provide hysteresis before indicating domain inactive
   logic                                         domain_idle_states;    // combined and of all idle input signals
   logic                                         domain_wakeup_states;    // combined or of all valid/wakeup signals
   logic                                         gc_cr_clk_status_domain_l;    // local status signal of clock running
   logic                                         domain_active;    // Indicates when the domain is not idle

   logic [ 1 : 0 ]                               gc_cr_clk_ctrl_domain_l;

   logic                                         clk_on_reset;
   logic [ 6 : 0 ]                               reset_max_value;
   logic [ 6 : 0 ]                               reset_count;



   // combine the wakeup events and idles
   assign domain_idle_states = & domain_idles_in;

   always_ff @(posedge core_clk_aligned or negedge core_resetn) begin : p_update_hysteresis
         if ( core_resetn == 1'b0 ) begin
            max_idle_hysteresis_count <= 31;
         end else begin
            if ( domain_active == 1'b0 || idle_hysteresis_count == 0 ) begin
               max_idle_hysteresis_count <= gc_cr_pwr_man_hysteresis_value;
            end
         end
      end // p_update_hysteresis

   assign gc_cr_clk_ctrl_domain_l = gc_cr_clk_ctrl_domain;

   assign domain_wakeup_states = | domain_wakeup_events;

   // assign local signal to port
   assign gc_cr_clk_status_domain = gc_cr_clk_status_domain_l;

   assign reset_max_value = (gc_cr_crm_reset_clk_ctrl == GC_CR_CRM_RESET_CLK_CTRL_ON_16)? 16 : 
                           ((gc_cr_crm_reset_clk_ctrl == GC_CR_CRM_RESET_CLK_CTRL_ON_64)? 64 : 0);  

   always_ff @(posedge core_clk_aligned) begin : p_reset_count
      begin
         if ( soft_reset == 1'b1 ) begin
            if ( ( reset_count < reset_max_value ) ) begin    // COV:tag1
               reset_count <= reset_count + 1;    // COV:tag1
            end
         end else begin
            reset_count <= 0;
         end
      end
   end // p_reset_count

   assign clk_on_reset =   ((gc_cr_crm_reset_clk_ctrl == GC_CR_CRM_RESET_CLK_CTRL_ON) || 
                            ((gc_cr_crm_reset_clk_ctrl == GC_CR_CRM_RESET_CLK_CTRL_ON_16) && (reset_count < reset_max_value)) ||
                            ((gc_cr_crm_reset_clk_ctrl == GC_CR_CRM_RESET_CLK_CTRL_ON_64) && (reset_count < reset_max_value)) ) ? 1'b1 : 1'b0;    // COV:tag2   

   // purpose: Generates the domain clock enable signal
   // type   : sequential
   always_ff @(posedge core_clk_aligned or negedge core_resetn) begin : clk_en_reg
      if ( ( core_resetn == 1'b0 ) ) begin
         domain_clk_en <= 1'b1;    // clock is enabled during reset
      end else begin
         domain_clk_en <= domain_clk_on_req;
      end
   end // clk_en_reg


// purpose: Generates the domain clock status signal. This status register only gets updated
// when the domain clock is running (asserted one clock cycle before domain clock starts).

   always_ff @(negedge core_resetn or posedge domain_clk) begin : clk_status_reg
       // process clk_en_reg
      if ( ( core_resetn == 1'b0 ) ) begin    // asynchronous reset (active low)
         gc_cr_clk_status_domain_l <= 1'b1;    // clock_status is high during reset, since the clock gate is open
      end else begin    // rising clock edge
         gc_cr_clk_status_domain_l <= domain_clk_on_req;
      end
   end // clk_status_reg

// purpose: Controls the clock status and whether the clock is gated, on, automatic, or overridden
// type   : combinational
   always_comb begin : clk_ctrl 
      case (gc_cr_clk_ctrl_domain_l)
         CLK_CTRL_MODE_OFF:
            domain_clk_on_req = 1'b0;
         CLK_CTRL_MODE_ON:
            domain_clk_on_req = 1'b1;
         CLK_CTRL_MODE_AUTO:
            // During a soft reset: keep the clock on just for the period of time specified
            // Normal behaviour: keep the clock on if domain is active or there is a wakeup event

            // domain_wakeup_states is applied directly to the domain_active signal
            // so that when the domain is just about to go inactive the reg write or dpm req/gnt
            // stops the clock being turned off. This is due to registers stages
            // in the logic being different between core logic valids and register
            // writes and without it register writes will occur when the domain clock is off.
            domain_clk_on_req = ( ~ soft_reset & ( domain_active | domain_wakeup_states ) ) | ( soft_reset & clk_on_reset );
         default:
            domain_clk_on_req = ( ~ soft_reset & ( domain_active | domain_wakeup_states ) ) | ( soft_reset & clk_on_reset );
endcase // gc_cr_clk_ctrl_domain_l
   end // clk_ctrl

// purpose: Identifies of the clock domain is active or not based on the idle signals from the domain and the wakeup
// signals going to the domain. When all idles are true and all wakeup events are false the idle hysteresis count is started.
// If the count reaches its maximum the domain is indicated as being inactive and therefore may be clock gated.
// An inactive idle or wakeup event will reset the hysteresis counter.
// type   : sequential
   always_ff @(posedge core_clk_aligned or negedge core_resetn) begin : domain_active_gen
       // process domain_active_gen
      if ( ( core_resetn == 1'b0 ) ) begin    // asynchronous reset (active low)
         domain_active <= 1'b0;
         idle_hysteresis_count <= 0;

      end else begin    // rising clock edge

         if ( ( gc_cr_clk_ctrl_domain_l == CLK_CTRL_MODE_OFF ) ) begin
            idle_hysteresis_count <= max_idle_hysteresis_count;
            domain_active <= 1'b0;
         end else if ( ( domain_idle_states == 1'b1 && domain_wakeup_states == 1'b0 ) ) begin
            if ( ( idle_hysteresis_count >= max_idle_hysteresis_count ) ) begin
               domain_active <= 1'b0;
            end else begin
               idle_hysteresis_count <= idle_hysteresis_count + 1;
            end
         end else begin
            idle_hysteresis_count <= 0;
            domain_active <= 1'b1;
         end

      end
   end // domain_active_gen

endmodule // gc_crm_dmctl_
