// Author: jinjifang
// Date: 2024/1/8
// Description: the common flip-flop fifo

module gc_lib_reg_fifo #(
                         parameter type DTYPE = logic [7:0],
                         parameter integer DEPTH = 4
                         )(
                           input wire              clk,
                           input wire              resetn, 
                           input wire              push, 
                           input wire              pop, 
                           input DTYPE             din,
                           output wire             full, 
                           output wire             empty,  
                           output DTYPE            dout
                           );

   localparam  DEPTH_BITS      = (DEPTH == 1) ? 1 : $clog2(DEPTH);

   // user signals
   reg [DEPTH_BITS:0]                              wptr;
   reg [DEPTH_BITS:0]                              rptr;
   DTYPE                                           fifo_mem [DEPTH-1 : 0];  


   //wprt
   always @(posedge clk or negedge resetn) begin
      if (!resetn) begin
         wptr <= {(DEPTH_BITS+1){1'b0}};
   end    
      else if (push) begin
         if(wptr[DEPTH_BITS-1:0] == DEPTH - 1)
            wptr <= {!wptr[DEPTH_BITS], {DEPTH_BITS{1'b0}}};
         else
            wptr <= wptr + 1'b1;
      end
   end

   //rptr
   always @(posedge clk or negedge resetn) begin
      if (!resetn) begin
         rptr <= {(DEPTH_BITS+1){1'b0}};
   end    
      else if (pop) begin
         if(rptr[DEPTH_BITS-1:0] == DEPTH - 1)
            rptr <= {!rptr[DEPTH_BITS], {DEPTH_BITS{1'b0}}};
         else
            rptr <= rptr + 1'b1;
      end
   end

`ifdef EMU_SYNTHESIS_FIFO_RAM_NO_USE
//Used in FPGA and palladium env.
// Change 3D-Array to 2D-Array for resource opt in palladium. By Wu Cheng`en @Sep-15-2025   
   always @(posedge clk) begin
      if( push )
        fifo_mem[wptr[DEPTH_BITS-1:0]] <= din;
   end
`else
   //fifo_mem
   genvar i;
   generate
      for(i = 0; i < DEPTH; i = i + 1) begin
         always @(posedge clk) begin
            if( push & (i == wptr[DEPTH_BITS-1:0]))
              fifo_mem[i] <= din;
         end
      end
   endgenerate
`endif

   //dout
   assign  dout = fifo_mem[rptr[DEPTH_BITS-1:0]];

   // full and empty flag
   assign empty = wptr == rptr;
   assign full = (wptr[DEPTH_BITS] ^ rptr[DEPTH_BITS]) & (wptr[DEPTH_BITS-1:0] == rptr[DEPTH_BITS-1:0]);


//synopsys translate_off
   logic    push_legal;
   assign push_legal = !full | pop;
    gpu_assert_always_on_event u_assert_push(.clk(clk), .resetn(resetn), .sample(push), .expr(push_legal), .msg("push overflow"));

    logic   pop_legal;
    assign pop_legal = !empty;
    gpu_assert_always_on_event u_assert_pop(.clk(clk), .resetn(resetn), .sample(pop), .expr(pop_legal), .msg("pop underflow"));


//synopsys translate_on

endmodule
