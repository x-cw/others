package cp_arb_common_pkg;
//synopsys translate_off
import common_typedef_pkg::*;
//synopsys translate_on


//packet_type
localparam ONLY_HEAD = 2'd0;
localparam ONLY_BODY = 2'd1;
localparam HEAD_BODY = 2'd2;
localparam ONLY_CTXT = 2'd3;

//kernel_type
localparam TYPE_SHARE = 2'd0;
localparam TYPE_FREE = 2'd1;
localparam TYPE_OTHERS = 2'd2;

//CPC RQ BIT FIELD
localparam CU_NUMS_PER_SPC = 16;
localparam CPC_NUMS = 4;
localparam CPCPIPE_NUMS = 16;
localparam CPC_OUTSTANDING_KERNEL_NUMS = 64;

localparam CP_ARB_PRIORITY_BITS = 2;
localparam CP_ARB_MAX_CREDIT_BITS = 4;

localparam KERNEL_FIRST_BIT = 221;
localparam KERNEL_LAST_BIT = 220;
localparam KERNEL_SEND_ALL_BIT = 22;
localparam CTXT_SEND_ALL_BIT = 6;

//cp_arb gpc if
localparam CPC_RQ_PARTITION_WIDTH = 222;
localparam CPC_RQ_CREDIT_WIDTH    = 4;
localparam CPC_RQ_DESTID_WIDTH    = 2;
localparam CPC_RQ_CPCID_WIDTH     = 2;
localparam CPC_DOUT_CUID_WIDTH    = 4;
localparam CPC_RSP_KERNELID_WIDTH = 6;

localparam CP_ARB_IFIFO_DEPTH = 2;


//synopsys translate_off
typedef struct packed{
    debug_tag_t  dtag;
    logic [31:0] kernel_id;
    logic [31:0] partition_id;
    logic        bcast;
    logic        head;
    logic        last;
    logic        ctxt;
    logic [1:0]  cpc;
}cp_arb_internel_dbgtag_t;
//synopsys translate_on



typedef struct packed{
    logic wi_id; //0=compute 1=ctxt
    logic [1:0] kernel_type;//0=Share 1=Free others = others
    logic [CPC_RQ_PARTITION_WIDTH-1:0] data;
}cpc_rq_data_t;


localparam CPC_RQ_DATA_T_WIDTH = $bits(cpc_rq_data_t);

typedef struct packed{
    //cpc
    cpc_rq_data_t cpc_data;
    //occupy
    logic typical_sdf;
}cpc_occupy_data_t;

typedef struct packed{
    //occupy
    cpc_occupy_data_t occupy_data;
    //disptach core
    logic be_send_all;
    logic head_predict_release;
    logic [3:0] spc_id;
    logic [1:0]packet_type;
}cpc_dispatch_core_data_t;


typedef struct packed{
    //disptach core
    cpc_dispatch_core_data_t dispatch_core_data;
    //disptach
    cpc_rq_data_t kernel_header;
}cpc_dispatch_data_t;



typedef struct packed{
    logic [1:0] cpc_id;
    logic [1:0] spc_id;
    logic wi_id; //0=compute 1=ctxt
    logic [CPC_RQ_PARTITION_WIDTH-1:0] data;
}gpc_backend_data_t;

localparam GPC_BACKEND_DATA_WIDTH = $bits(gpc_backend_data_t);


typedef struct packed{
    cpc_rq_data_t kernel_header;
    logic head_predict;
    logic [3:0] head_predict_spc;
    logic kernel_send_all; 
    logic [15:0] wait_send_head_to_spc;
}cpc_status_lut;

endpackage
