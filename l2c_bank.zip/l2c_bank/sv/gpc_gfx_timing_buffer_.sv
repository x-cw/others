/*

 * #==========================================================================#
 * |                                                                          |
 * |  Copyright (c) 2022, Fantasy Technologies Limited and/or its         |
 * |  affiliated group companies ("Fantasy"). All rights reserved.        |
 * |  No part of this content, either material or conceptual may be copied    |
 * |  or distributed, transmitted, transcribed, stored in a retrieval system  |
 * |  or translated into any human or computer language in any form by any    |
 * |  means, electronic, mechanical manual, or otherwise, or disclosed to     |
 * |  third parties without the express written permission of Fantasy.    |
 * |                                                                          |
 * #==========================================================================#

 */



// ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////-
// entity name: gpc_gfx_timing_buffer
// Component Description: IMGLIB3 Generic Timing Buffer
// Generic Timing Buffer (use BUFFER_TYPE generic to instantiate a wide variety of modules)
//
// For description of each instantiated buffer type check appropriate source file.
//
// ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////-
// BUFFER TYPE     |   AREA COST   | VALID/DATA | ENABLE CHAIN | Comments
// ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////-
// Wire            |     ZERO!     | Same cycle | Not Broken   | No benefit!
// Simple Pipe reg | W x (FF)      | Delayed    | Not Broken   | Data registered but possible timing problems on the enable
// RSTL            | W x (2FF+Mux) | Delayed    | Broken       | Largest area but best for timing as everything is registered
// RSTL LOW POWER  |
// RSTL FAST IN    |
// HSTL            | W x (FF)      | Delayed    | Broken       | 50% Max throughput (use for low BW), but everything is registered
// MSTL            | W x (FF+Mux)  | Same cycle | Broken       | Data combinatorial but enable now registered to help timing
// Cascaded MSTLs  | W x 2(FF+Mux) | Same cycle | Broken       | Behaves like 2 deep FIFO with zero output latency
// ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////-
//
// Generics:
// BUFFER_TYPE - INTEGER
//             - Buffer Type to introduce - see table above, DEFAULT = 0 = Wire
// WIDTH       - INTEGER
//             - Width of Data bus Input/Output std_logic_vector
//
// Portlist:
// clk               - Clock Input
// resetn            - Active-low asynchronous Reset
// tbuff_in_data     - Data bus input (sized by generic w)
// tbuff_in_valid    - Valid input from upstream module
// tbuff_in_enable   - Enable output to upstream module
// tbuff_out_data    - Data bus output (sized by generic w)
// tbuff_out_valid   - Valid output to downstream module
// tbuff_out_enable  - Enable input from downstream module
//
// ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////-




module gpc_gfx_timing_buffer_
#(
      parameter int                                      BUFFER_TYPE                                                  = 0              ,
      parameter int                                      WIDTH                                                        = 32              
)
(
      input    logic                                                        clk                                     ,
      input    logic                                                        resetn                                  ,
      // Input V/E Interface
      input    logic                                                        tbuff_in_valid                          ,
      output   logic                                                        tbuff_in_enable                         ,
      input    logic [ WIDTH - 1 : 0 ]                                      tbuff_in_data                           ,
      // Output V/E Interface
      output   logic                                                        tbuff_out_valid                         ,
      input    logic                                                        tbuff_out_enable                        ,
      output   logic [ WIDTH - 1 : 0 ]                                      tbuff_out_data                           
);

   import gpc_gfx_timing_buffer_pack_::*;

   // Buffer type 0 : Wire
   if ( BUFFER_TYPE == GPC_GFX_TIMING_BUFFER_WIRE ) begin : g_buffer_type_0

      assign tbuff_out_valid = tbuff_in_valid ;
      assign tbuff_in_enable = tbuff_out_enable ;
      assign tbuff_out_data = tbuff_in_data ;

   end // g_buffer_type_0

   // Buffer type 1 : Pipeline register (With combinatorial enable)
   if ( BUFFER_TYPE == GPC_GFX_TIMING_BUFFER_PIPE_REG ) begin : g_buffer_type_1

      if (1) begin : b_pipe_reg

         logic                                         tbuff_out_valid_l                       ;
         logic                                         tbuff_in_enable_l                       ;


         always_ff @(posedge clk or negedge resetn) begin : p_pipeline_register_clkdrs
            if ( resetn == 1'b0 ) begin    // COV:tag0
               tbuff_out_valid_l <= 1'b0 ;    // COV:tag0
            end else begin
               if ( tbuff_in_enable_l == 1'b1 ) begin    // COV:tag0
                  tbuff_out_valid_l <= tbuff_in_valid ;    // COV:tag0
               end
            end
         end // p_pipeline_register_clkdrs

         always_ff @(posedge clk) begin : p_pipeline_register_clkd
            begin    // COV:tag0
               if ( tbuff_in_valid == 1'b1 & tbuff_in_enable_l == 1'b1 ) begin    // COV:tag1
                  tbuff_out_data <= tbuff_in_data ;    // COV:tag0
               end
            end
         end // p_pipeline_register_clkd

         assign tbuff_in_enable_l = ( ~ tbuff_out_valid_l ) | tbuff_out_enable ;    // COV:tag2
         assign tbuff_in_enable = tbuff_in_enable_l ;
         assign tbuff_out_valid = tbuff_out_valid_l ;

      end // b_pipe_reg

   end // g_buffer_type_1

   // Buffer type 2 : RSTL
   if ( BUFFER_TYPE == GPC_GFX_TIMING_BUFFER_RSTL ) begin : g_buffer_type_2

      gpc_gfx_rstl_
         #(
            .w                               (WIDTH)                                       
            )
         i_rstl
         (
            .clk                             (clk)                                        ,
            .resetn                          (resetn)                                     ,
            .din                             (tbuff_in_data)                              ,
            .vin                             (tbuff_in_valid)                             ,
            .eout                            (tbuff_in_enable)                            ,
            .dout                            (tbuff_out_data)                             ,
            .vout                            (tbuff_out_valid)                            ,
            .ein                             (tbuff_out_enable)                            
            );

   end // g_buffer_type_2

   // Buffer type 3 : RSTL LOW POWER
   if ( BUFFER_TYPE == GPC_GFX_TIMING_BUFFER_RSTL_LOWPWR ) begin : g_buffer_type_3

      gpc_gfx_rstl_lopower_
         #(
            .w                               (WIDTH)                                       
            )
         i_rstllopower
         (
            .clk                             (clk)                                        ,
            .resetn                          (resetn)                                     ,
            .din                             (tbuff_in_data)                              ,
            .vin                             (tbuff_in_valid)                             ,
            .eout                            (tbuff_in_enable)                            ,
            .dout                            (tbuff_out_data)                             ,
            .vout                            (tbuff_out_valid)                            ,
            .ein                             (tbuff_out_enable)                            
            );
   end // g_buffer_type_3

   // Buffer type 4 : RSTL FAST IN
   if ( BUFFER_TYPE == GPC_GFX_TIMING_BUFFER_RSTL_FASTIN ) begin : g_buffer_type_4

      gpc_gfx_rstl_fast_in_
         #(
            .w                               (WIDTH)                                       
            )
         i_rstlfastin
         (
            .clk                             (clk)                                        ,
            .resetn                          (resetn)                                     ,
            .din                             (tbuff_in_data)                              ,
            .vin                             (tbuff_in_valid)                             ,
            .eout                            (tbuff_in_enable)                            ,
            .dout                            (tbuff_out_data)                             ,
            .vout                            (tbuff_out_valid)                            ,
            .ein                             (tbuff_out_enable)                            
            );
   end // g_buffer_type_4

   // Buffer type 5 : HSTL
   if ( BUFFER_TYPE == GPC_GFX_TIMING_BUFFER_HSTL ) begin : g_buffer_type_5

      gpc_gfx_hstl_
         #(
         .w                               (WIDTH)                                       
         )
         i_hstl
         (
            .clk                             (clk)                                        ,
            .resetn                          (resetn)                                     ,
            .din                             (tbuff_in_data)                              ,
            .vin                             (tbuff_in_valid)                             ,
            .eout                            (tbuff_in_enable)                            ,
            .dout                            (tbuff_out_data)                             ,
            .vout                            (tbuff_out_valid)                            ,
            .ein                             (tbuff_out_enable)                            
            );

   end // g_buffer_type_5

   // Buffer type 6 : MSTL
   if ( BUFFER_TYPE == GPC_GFX_TIMING_BUFFER_MSTL ) begin : g_buffer_type_6

      gpc_gfx_mstl_
         #(
         .w                               (WIDTH)                                       
         )
         i_mstl
         (
            .clk                             (clk)                                        ,
            .resetn                          (resetn)                                     ,
            .din                             (tbuff_in_data)                              ,
            .vin                             (tbuff_in_valid)                             ,
            .eout                            (tbuff_in_enable)                            ,
            .dout                            (tbuff_out_data)                             ,
            .vout                            (tbuff_out_valid)                            ,
            .ein                             (tbuff_out_enable)                            
            );

   end // g_buffer_type_6



   // Buffer type 7: MSTLx2
   if ( BUFFER_TYPE == GPC_GFX_TIMING_BUFFER_MSTL_CASCADE ) begin : g_buffer_type_7

      if (1) begin : b_multiple_mstls

         logic                                         valid_stage1                            ;
         logic                                         enable_stage1                           ;
         logic [ WIDTH - 1 : 0 ]                       data_stage1                             ;


         gpc_gfx_mstl_
            #(
               .w                               (WIDTH)                                       
               )
            i_mstl0
            (
               .clk                             (clk)                                        ,
               .resetn                          (resetn)                                     ,
               .din                             (tbuff_in_data)                              ,
               .vin                             (tbuff_in_valid)                             ,
               .eout                            (tbuff_in_enable)                            ,
               .dout                            (data_stage1)                                ,
               .vout                            (valid_stage1)                               ,
               .ein                             (enable_stage1)                               
               );

         gpc_gfx_mstl_
            #(
               .w                               (WIDTH)                                       
               )
            i_mstl1
            (
               .clk                             (clk)                                        ,
               .resetn                          (resetn)                                     ,
               .din                             (data_stage1)                                ,
               .vin                             (valid_stage1)                               ,
               .eout                            (enable_stage1)                              ,
               .dout                            (tbuff_out_data)                             ,
               .vout                            (tbuff_out_valid)                            ,
               .ein                             (tbuff_out_enable)                            
               );

      end // b_multiple_mstls

   end // g_buffer_type_7

endmodule // gpc_gfx_timing_buffer
