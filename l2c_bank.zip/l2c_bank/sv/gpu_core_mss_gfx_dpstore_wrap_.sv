/*

 * #==========================================================================#
 * |                                                                          |
 * |  Copyright (c) 2022, Fantasy Technologies Limited and/or its         |
 * |  affiliated group companies ("Fantasy"). All rights reserved.        |
 * |  No part of this content, either material or conceptual may be copied    |
 * |  or distributed, transmitted, transcribed, stored in a retrieval system  |
 * |  or translated into any human or computer language in any form by any    |
 * |  means, electronic, mechanical manual, or otherwise, or disclosed to     |
 * |  third parties without the express written permission of Fantasy.    |
 * |                                                                          |
 * #==========================================================================#

 */

// ////////////////////////////////////////////////////////////////////////////-
// entity:  gpu_core_mss_gfx_dpstore_wrap
//
// purpose: Wrapper for RAM or FLOP based dual-port storage
//
// ////////////////////////////////////////////////////////////////////////////-

module gpu_core_mss_gfx_dpstore_wrap_ 
   import gpc_gfx_rambist_pack_::*;
  #(
    parameter w        = 32,                   // Data width
    parameter p        = 32,                   // Word partition size (bits per WEN)
    parameter d        = 32,                   // Data depth
    parameter log2d    = 5,                    // Address width
    parameter wrcen    = 0,                    // Write Port chip enable: 0=and_reduce(wr_en)
                                               //                         1=wr_en(w/p)
    parameter ECC      = 0,                    // 0=disable ECC; 1=enable SEC-DED; 2=enable Parity



    parameter id       = 0)                    // unique value per instance
   (
      input  logic                                  clk,
      input  logic                                  resetn,
      // read port
      input  logic                                  rd_en,
      input  logic [log2d-1 : 0]                    rd_addr,
      output logic [w-1 : 0]                        rd_data_ram,
      // write port
      input  logic [(w/p)+wrcen-1 : 0]              wr_en,
      input  logic [log2d-1 : 0]                    wr_addr,
      input  logic [w-1 : 0]                        wr_data,






      // bist signals
      input  logic [dpstore_in(w, p, d,ECC)-1 : 0]  bist_in,
      output logic [dpstore_out(w, p, d,ECC)-1 : 0] bist_out,
      input  logic                                  tst_gclkenable);








   ///////////////////////////////////////////////
   // backdoor access
   ///////////////////////////////////////////////





   ///////////////////////////////////////////////
   // END backdoor access
   ///////////////////////////////////////////////


   //instance a RAM macro?
   generate
      if (ram_partitioner_threshold(w, d, id)) begin : g_ram






         gpu_core_mss_gfx_dpstore_bist_
           #(.w        (w),
             .p        (p),
             .d        (d),
             .log2d    (log2d),
             .wrcen    (wrcen),
             .ECC      (ECC),



             .id       (id)
             ) i_gpu_core_mss_gfx_dpstore_bist
                (
                 .clk           (clk),
                 .resetn        (resetn),
                 .rd_en         (rd_en),
                 .rd_addr       (rd_addr),
                 .rd_data_ram   (rd_data_ram),
                 .wr_en         (wr_en),
                 .wr_addr       (wr_addr),
                 .wr_data       (wr_data),














                 // bist signals
                 .bist_in        (bist_in),
                 .bist_out       (bist_out),
                 .tst_gclkenable (tst_gclkenable)
                 );
      end : g_ram
   endgenerate

   //instance flop based RAM
   generate
      if (!ram_partitioner_threshold(w, d, id)) begin : g_flops
         logic wr_cen;






         // make a comparable write_cen
         if (wrcen == 0) begin : g_cenb_0
            // Merge all the wr_en bits into one
            assign wr_cen = &(wr_en);
         end : g_cenb_0

         if (wrcen == 1) begin : g_cenb_1
            // Use added top bit from wr_en input vector
            assign wr_cen = wr_en[w/p];
         end : g_cenb_1

         gpu_core_mss_gfx_dp_rgstore_
           #(.w     (w),
             .p     (p),
             .d     (d),
             .log2d (log2d)
             ) i_gpu_core_mss_gfx_dp_rgstore
            (
             .CLKA (clk),
             .CENA (rd_en),
             .AA   (rd_addr),
             .QA   (rd_data_ram),
             .CLKB (clk),
             .CENB (wr_cen),
             .WENB (wr_en[w/p-1 : 0]),
             .AB   (wr_addr),
             .DB   (wr_data)
             );






         assign bist_out = '{default:'0};
      end : g_flops
   endgenerate

endmodule
