/*



*/
// ----------------------------------------------------------------------------------------------
// entity name: gc_l2_bank_wrap
// purpose: instance crg, crm, ipg, int_pipe, bank(x2), mem_sched
// ----------------------------------------------------------------------------------------------

module gc_l2_bank_wrap
import group_nsp_req_pkg::*;
import group_nsp_rsp_pkg::*;
import nsp_rsp_pkg::*;
import nsp_req_pkg::*;
import bank_sched_pkg::*;
import sched_bank_pkg::*;
import axi5_ar_pkg::*;
import axi5_r_pkg::*;
import axi5_aw_pkg::*;
import axi5_w_pkg::*;
import axi5_b_pkg::*;
import gc_l2_bank_group_pkg::*;
import gc_l2_bank_pkg::*;
#(parameter BANK_WRAP = 0)
(
    input   logic                       clk                 ,
    input   logic                       resetn              ,
    input   logic                       tst_gclkenable      ,
    input   logic                       tst_rst_bypass      ,
    input   logic                       socif_wakeup        ,
    // AXI interface
    input   logic                       axi_slv_0_arvalid   ,
    output  logic                       axi_slv_0_arready   ,
    input   axi5_ar_data_bus_t          axi_slv_0_ar_rec    ,
    output  logic                       axi_slv_0_rvalid    ,
    input   logic                       axi_slv_0_rready    ,
    output  axi5_r_data_bus_t           axi_slv_0_r_rec     ,
    input   logic                       axi_slv_0_awvalid   ,
    output  logic                       axi_slv_0_awready   ,
    input   axi5_aw_data_bus_t          axi_slv_0_aw_rec    ,
    input   logic                       axi_slv_0_wvalid    ,
    output  logic                       axi_slv_0_wready    ,
    input   axi5_w_data_bus_t           axi_slv_0_w_rec     ,
    output  logic                       axi_slv_0_bvalid    ,
    input   logic                       axi_slv_0_bready    ,
    output  axi5_b_data_bus_t           axi_slv_0_b_rec     ,

    input   logic                       axi_slv_1_arvalid   ,
    output  logic                       axi_slv_1_arready   ,
    input   axi5_ar_data_bus_t          axi_slv_1_ar_rec    ,
    output  logic                       axi_slv_1_rvalid    ,
    input   logic                       axi_slv_1_rready    ,
    output  axi5_r_data_bus_t           axi_slv_1_r_rec     ,
    input   logic                       axi_slv_1_awvalid   ,
    output  logic                       axi_slv_1_awready   ,
    input   axi5_aw_data_bus_t          axi_slv_1_aw_rec    ,
    input   logic                       axi_slv_1_wvalid    ,
    output  logic                       axi_slv_1_wready    ,
    input   axi5_w_data_bus_t           axi_slv_1_w_rec     ,
    output  logic                       axi_slv_1_bvalid    ,
    input   logic                       axi_slv_1_bready    ,
    output  axi5_b_data_bus_t           axi_slv_1_b_rec     ,
    // NSP interface
    output  logic                       l2_nsp0_req_valid,
    input   logic                       l2_nsp0_req_ready,
    output  group_nsp_req_data_bus_t    l2_nsp0_req_rec  ,
    input   logic                       l2_nsp0_rsp_valid,
    output  logic                       l2_nsp0_rsp_ready,
    input   group_nsp_rsp_data_bus_t    l2_nsp0_rsp_rec  ,

    output  logic                       l2_nsp1_req_valid,
    input   logic                       l2_nsp1_req_ready,
    output  group_nsp_req_data_bus_t    l2_nsp1_req_rec  ,
    input   logic                       l2_nsp1_rsp_valid,
    output  logic                       l2_nsp1_rsp_ready,
    input   group_nsp_rsp_data_bus_t    l2_nsp1_rsp_rec  ,
    // performance counter
    output  logic                       l2b0_busy                        ,
    output  logic                       l2b0_fromaxi_ar_wl               ,
    output  logic                       l2b0_fromaxi_ar_bl_eq0_wl        ,
    output  logic                       l2b0_fromaxi_ar_bl_eq1_wl        ,
    output  logic                       l2b0_fromaxi_ar_bl_eq2_wl        ,
    output  logic                       l2b0_fromaxi_ar_bl_eq3_wl        ,
    output  logic                       l2b0_fromaxi_ar_bp               ,
    output  logic                       l2b0_toaxi_r_wl                  ,
    output  logic                       l2b0_toaxi_r_bp                  ,
    output  logic                       l2b0_fromaxi_aw_wl               ,
    output  logic                       l2b0_fromaxi_aw_bl_eq0_wl        ,
    output  logic                       l2b0_fromaxi_aw_bl_eq1_wl        ,
    output  logic                       l2b0_fromaxi_aw_bl_eq2_wl        ,
    output  logic                       l2b0_fromaxi_aw_bl_eq3_wl        ,
    output  logic                       l2b0_fromaxi_aw_bp               ,
    output  logic                       l2b0_fromaxi_w_wl                ,
    output  logic                       l2b0_fromaxi_w_bp                ,
    output  logic                       l2b0_fromaxi_smp_read_req_num    ,
    output  logic                       l2b0_fromaxi_smp_read_req_sum    ,
    output  logic                       l2b0_fromaxi_smp_write_req_num   ,
    output  logic                       l2b0_fromaxi_smp_write_req_sum   ,
    output  logic                       l2b0_fromaxi_smp_atomic_req_num  ,
    output  logic                       l2b0_fromaxi_smp_atomic_req_sum  ,
    output  logic                       l2b0_align_awdb_full             ,
    output  logic                       l2b0_hittest_ht_bypass_read_wl   ,
    output  logic                       l2b0_hittest_ht_cache_read_wl    ,
    output  logic                       l2b0_hittest_ht_bypass_write_wl  ,
    output  logic                       l2b0_hittest_ht_cache_write_wl   ,
    output  logic                       l2b0_hittest_ht_atomic_wl        ,
    output  logic                       l2b0_hittest_ht_bps_hit_wl       ,
    output  logic                       l2b0_hittest_ht_miss_wl          ,
    output  logic                       l2b0_frommemsch_nsp_rtn_wl       ,
    output  logic                       l2b0_frommemsch_nsp_rtn_bp       ,
    output  logic                       l2b0_tomemsch_nsp_read_bl_eq1_wl ,
    output  logic                       l2b0_tomemsch_nsp_read_bl_eq3_wl ,
    output  logic                       l2b0_tomemsch_nsp_read_bl_eq5_wl ,
    output  logic                       l2b0_tomemsch_nsp_read_bl_eq7_wl ,
    output  logic                       l2b0_tomemsch_nsp_write_bl_eq1_wl,
    output  logic                       l2b0_tomemsch_nsp_write_bl_eq3_wl,
    output  logic                       l2b0_tomemsch_nsp_write_bl_eq5_wl,
    output  logic                       l2b0_tomemsch_nsp_write_bl_eq7_wl,
    output  logic                       l2b0_memif_to_ddr_read_wl        ,
    output  logic                       l2b0_memif_to_ddr_read_stall_by_rob          ,
    output  logic                       l2b0_memif_to_ddr_read_stall_by_ddr          ,
    output  logic                       l2b0_memif_to_ddr_read_stall_by_trid         ,
    output  logic                       l2b0_memif_to_ddr_write_wl                   ,
    output  logic                       l2b0_memif_to_ddr_write_stall_by_data_sync   ,
    output  logic                       l2b0_memif_to_ddr_write_stall_by_ddr         ,
    output  logic                       l2b0_memif_to_ddr_write_stall_by_trid        ,
    output  logic                       l2b0_memif_memreq_full                       ,
    output  logic                       l2b0_memif_smp_read_req_num                  ,
    output  logic                       l2b0_memif_smp_read_req_sum                  ,
    output  logic                       l2b0_reqsch_sortq_full                       ,
    output  logic                       l2b0_reqsch_sortq_stall_but_not_full         ,
    output  logic                       l2b0_reqsch_disp_wl                          ,
    output  logic                       l2b0_reqsch_disp_stall                       ,
    output  logic                       l2b0_ramctrl_0_reqarb_wl                     ,
    output  logic                       l2b0_ramctrl_0_reqarb_stall_by_sram          ,
    output  logic                       l2b0_ramctrl_0_data_sram_read_wl             ,
    output  logic                       l2b0_ramctrl_0_data_sram_write_wl            ,
    output  logic                       l2b0_ramctrl_1_reqarb_wl                     ,
    output  logic                       l2b0_ramctrl_1_reqarb_stall_by_sram          ,
    output  logic                       l2b0_ramctrl_1_data_sram_read_wl             ,
    output  logic                       l2b0_ramctrl_1_data_sram_write_wl            ,
    output  logic                       l2b1_busy                        ,
    output  logic                       l2b1_fromaxi_ar_wl               ,
    output  logic                       l2b1_fromaxi_ar_bl_eq0_wl        ,
    output  logic                       l2b1_fromaxi_ar_bl_eq1_wl        ,
    output  logic                       l2b1_fromaxi_ar_bl_eq2_wl        ,
    output  logic                       l2b1_fromaxi_ar_bl_eq3_wl        ,
    output  logic                       l2b1_fromaxi_ar_bp               ,
    output  logic                       l2b1_toaxi_r_wl                  ,
    output  logic                       l2b1_toaxi_r_bp                  ,
    output  logic                       l2b1_fromaxi_aw_wl               ,
    output  logic                       l2b1_fromaxi_aw_bl_eq0_wl        ,
    output  logic                       l2b1_fromaxi_aw_bl_eq1_wl        ,
    output  logic                       l2b1_fromaxi_aw_bl_eq2_wl        ,
    output  logic                       l2b1_fromaxi_aw_bl_eq3_wl        ,
    output  logic                       l2b1_fromaxi_aw_bp               ,
    output  logic                       l2b1_fromaxi_w_wl                ,
    output  logic                       l2b1_fromaxi_w_bp                ,
    output  logic                       l2b1_fromaxi_smp_read_req_num    ,
    output  logic                       l2b1_fromaxi_smp_read_req_sum    ,
    output  logic                       l2b1_fromaxi_smp_write_req_num   ,
    output  logic                       l2b1_fromaxi_smp_write_req_sum   ,
    output  logic                       l2b1_fromaxi_smp_atomic_req_num  ,
    output  logic                       l2b1_fromaxi_smp_atomic_req_sum  ,
    output  logic                       l2b1_align_awdb_full             ,
    output  logic                       l2b1_hittest_ht_bypass_read_wl   ,
    output  logic                       l2b1_hittest_ht_cache_read_wl    ,
    output  logic                       l2b1_hittest_ht_bypass_write_wl  ,
    output  logic                       l2b1_hittest_ht_cache_write_wl   ,
    output  logic                       l2b1_hittest_ht_atomic_wl        ,
    output  logic                       l2b1_hittest_ht_bps_hit_wl       ,
    output  logic                       l2b1_hittest_ht_miss_wl          ,
    output  logic                       l2b1_frommemsch_nsp_rtn_wl       ,
    output  logic                       l2b1_frommemsch_nsp_rtn_bp       ,
    output  logic                       l2b1_tomemsch_nsp_read_bl_eq1_wl ,
    output  logic                       l2b1_tomemsch_nsp_read_bl_eq3_wl ,
    output  logic                       l2b1_tomemsch_nsp_read_bl_eq5_wl ,
    output  logic                       l2b1_tomemsch_nsp_read_bl_eq7_wl ,
    output  logic                       l2b1_tomemsch_nsp_write_bl_eq1_wl,
    output  logic                       l2b1_tomemsch_nsp_write_bl_eq3_wl,
    output  logic                       l2b1_tomemsch_nsp_write_bl_eq5_wl,
    output  logic                       l2b1_tomemsch_nsp_write_bl_eq7_wl,
    output  logic                       l2b1_memif_to_ddr_read_wl        ,
    output  logic                       l2b1_memif_to_ddr_read_stall_by_rob          ,
    output  logic                       l2b1_memif_to_ddr_read_stall_by_ddr          ,
    output  logic                       l2b1_memif_to_ddr_read_stall_by_trid         ,
    output  logic                       l2b1_memif_to_ddr_write_wl                   ,
    output  logic                       l2b1_memif_to_ddr_write_stall_by_data_sync   ,
    output  logic                       l2b1_memif_to_ddr_write_stall_by_ddr         ,
    output  logic                       l2b1_memif_to_ddr_write_stall_by_trid        ,
    output  logic                       l2b1_memif_memreq_full                       ,
    output  logic                       l2b1_memif_smp_read_req_num                  ,
    output  logic                       l2b1_memif_smp_read_req_sum                  ,
    output  logic                       l2b1_reqsch_sortq_full                       ,
    output  logic                       l2b1_reqsch_sortq_stall_but_not_full         ,
    output  logic                       l2b1_reqsch_disp_wl                          ,
    output  logic                       l2b1_reqsch_disp_stall                       ,
    output  logic                       l2b1_ramctrl_0_reqarb_wl                     ,
    output  logic                       l2b1_ramctrl_0_reqarb_stall_by_sram          ,
    output  logic                       l2b1_ramctrl_0_data_sram_read_wl             ,
    output  logic                       l2b1_ramctrl_0_data_sram_write_wl            ,
    output  logic                       l2b1_ramctrl_1_reqarb_wl                     ,
    output  logic                       l2b1_ramctrl_1_reqarb_stall_by_sram          ,
    output  logic                       l2b1_ramctrl_1_data_sram_read_wl             ,
    output  logic                       l2b1_ramctrl_1_data_sram_write_wl            ,
    // configure register
    input   logic [ 3 : 0 ]            gc_cr_ddr_hash_config_reg0_row_id_bit0        ,
    input   logic [ 3 : 0 ]            gc_cr_ddr_hash_config_reg0_row_id_bit1        ,
    input   logic [ 3 : 0 ]            gc_cr_ddr_hash_config_reg0_row_id_bit2        ,
    input   logic [ 3 : 0 ]            gc_cr_ddr_hash_config_reg0_row_id_bit3        ,
    input   logic [ 3 : 0 ]            gc_cr_ddr_hash_config_reg0_row_id_bit4        ,
    input   logic [ 3 : 0 ]            gc_cr_ddr_hash_config_reg0_row_id_bit5        ,
    input   logic [ 3 : 0 ]            gc_cr_ddr_hash_config_reg0_row_id_bit6        ,
    input   logic [ 3 : 0 ]            gc_cr_ddr_hash_config_reg0_row_id_bit7        ,
    input   logic [ 3 : 0 ]            gc_cr_ddr_hash_config_reg0_row_id_bit8        ,
    input   logic [ 3 : 0 ]            gc_cr_ddr_hash_config_reg0_row_id_bit9        ,
    input   logic [ 3 : 0 ]            gc_cr_ddr_hash_config_reg0_row_id_bit10       ,
    input   logic [ 3 : 0 ]            gc_cr_ddr_hash_config_reg0_row_id_bit11       ,
    input   logic [ 3 : 0 ]            gc_cr_ddr_hash_config_reg1_row_id_bit12       ,
    input   logic [ 3 : 0 ]            gc_cr_ddr_hash_config_reg1_row_id_bit13       ,
    input   logic [ 3 : 0 ]            gc_cr_ddr_hash_config_reg1_row_id_bit14       ,
    input   logic [ 3 : 0 ]            gc_cr_ddr_hash_config_reg1_row_id_bit15       ,
    input   logic [ 3 : 0 ]            gc_cr_ddr_hash_config_reg1_row_id_bit16       ,
    input   logic [ 3 : 0 ]            gc_cr_ddr_hash_config_reg1_row_id_bit17       ,
    input   logic [ 3 : 0 ]            gc_cr_ddr_hash_config_reg1_row_id_bit18       ,
    input   logic [ 3 : 0 ]            gc_cr_ddr_hash_config_reg1_row_id_bit19       ,
    input   logic [ 3 : 0 ]            gc_cr_ddr_hash_config_reg1_row_id_bit20       ,
    input   logic [ 3 : 0 ]            gc_cr_ddr_hash_config_reg1_row_id_bit21       ,
    input   logic [ 3 : 0 ]            gc_cr_ddr_hash_config_reg1_row_id_bit22       ,
    input   logic [ 3 : 0 ]            gc_cr_ddr_hash_config_reg1_row_id_bit23       ,
    input   logic [ 1 : 0 ]            gc_cr_l2_function_enable_hash_mode            ,

    input   logic [ 4 : 0 ]         gc_cr_l2_mem_sched_row_partii_row_id_bit8,
    input   logic [ 4 : 0 ]         gc_cr_l2_mem_sched_row_partii_row_id_bit9,
    input   logic [ 4 : 0 ]         gc_cr_l2_mem_sched_row_partii_row_id_bit10,
    input   logic [ 4 : 0 ]         gc_cr_l2_mem_sched_row_partii_row_id_bit11,
    input   logic [ 4 : 0 ]         gc_cr_l2_mem_sched_row_partii_row_id_bit12,
    input   logic [ 4 : 0 ]         gc_cr_l2_mem_sched_row_partii_row_id_bit13,
    input   logic [ 4 : 0 ]         gc_cr_l2_mem_sched_row_partii_row_id_bit14,
    input   logic [ 4 : 0 ]         gc_cr_l2_mem_sched_row_partii_row_id_bit15,
    input   logic [ 4 : 0 ]         gc_cr_l2_mem_sched_row_partiii_row_id_bit16,
    input   logic [ 4 : 0 ]         gc_cr_l2_mem_sched_row_partiii_row_id_bit17,
    input   logic [ 3 : 0 ]         gc_cr_l2_function_enable_ddr_capacity,
    input   logic [ 1 : 0 ]         gc_cr_clk_ctrl3_l2g,
    output  logic                   gc_cr_clk_status3_l2g,
    input   logic                   gc_cr_soft_reset_l2g,
    input   logic [ 1 : 0 ]         gc_cr_l2_cfi_operation,
    output  logic                   gc_cr_l2_cfi_statusi_l2b0_finish,
    output  logic                   gc_cr_l2_cfi_statusi_l2b1_finish,
    input   logic [ 1 : 0 ]         gc_cr_l2_buffer_mode_buffer_mode_percentage,
    input   logic                   gc_cr_l2_persistence_reduce_persistence_reduce_enable,
    input   logic [ 20 : 0 ]        gc_cr_l2_persistence_reduce_persistence_reduce_threshold,
    input   logic                   gc_cr_l2_cmd_persistence_rst_all,
    input   logic                   gc_cr_l2_cmd_cfi_clr,
    output  logic [ 1  :0 ]         gc_cr_l2g_idle_l2g,
    output  logic [ 2 : 0 ]         gc_cr_l2g_error0_l2b0,
    output  logic [ 2 : 0 ]         gc_cr_l2g_error0_l2b1,
    input   logic                   gc_cr_l2_function_enable_mem_scheduler,
    input   logic                   gc_cr_l2_function_enable_bypass_mode,
    input   logic [ 4 : 0 ]         gc_cr_l2_mem_sched_col_offset_column_id_bit0,
    input   logic [ 4 : 0 ]         gc_cr_l2_mem_sched_col_offset_column_id_bit1,
    input   logic [ 4 : 0 ]         gc_cr_l2_mem_sched_col_offset_column_id_bit2,
    input   logic [ 4 : 0 ]         gc_cr_l2_mem_sched_col_offset_column_id_bit3,
    input   logic [ 4 : 0 ]         gc_cr_l2_mem_sched_col_offset_column_id_bit4,
    input   logic [ 4 : 0 ]         gc_cr_l2_mem_sched_col_offset_column_id_bit5,
    input   logic [ 4 : 0 ]         gc_cr_l2_mem_sched_bank_offset_bank_id_bit0,
    input   logic [ 4 : 0 ]         gc_cr_l2_mem_sched_bank_offset_bank_id_bit1,
    input   logic [ 4 : 0 ]         gc_cr_l2_mem_sched_bank_offset_bank_id_bit2,
    input   logic [ 4 : 0 ]         gc_cr_l2_mem_sched_bank_offset_bank_id_bit3,
    input   logic [ 4 : 0 ]         gc_cr_l2_mem_sched_bank_offset_bank_id_bit4,
    input   logic [ 4 : 0 ]         gc_cr_l2_mem_sched_row_parti_row_id_bit0,
    input   logic [ 4 : 0 ]         gc_cr_l2_mem_sched_row_parti_row_id_bit1,
    input   logic [ 4 : 0 ]         gc_cr_l2_mem_sched_row_parti_row_id_bit2,
    input   logic [ 4 : 0 ]         gc_cr_l2_mem_sched_row_parti_row_id_bit3,
    input   logic [ 4 : 0 ]         gc_cr_l2_mem_sched_row_parti_row_id_bit4,
    input   logic [ 4 : 0 ]         gc_cr_l2_mem_sched_row_parti_row_id_bit5,
    input   logic [ 4 : 0 ]         gc_cr_l2_mem_sched_row_parti_row_id_bit6,
    input   logic [ 4 : 0 ]         gc_cr_l2_mem_sched_row_parti_row_id_bit7,
    input   logic [ 4 : 0 ]         gc_cr_pwr_man_hysteresis_value,
    input   logic [ 1 : 0 ]         gc_cr_crm_reset_clk_ctrl,
    input   logic                   gc_cr_cu_lms_fp32_denormal_en,
    input   logic                   gc_cr_l2_cfi_operation_notify,
    input   logic                   gc_cr_l2_cfi_operation_rdnotify,
    input   logic                   gc_cr_l2_cmd_notify,
    input   logic                   gc_cr_l2_cmd_rdnotify
);

localparam  int     L2_BANK_WRAP_NUM_IDLE   = 2;
localparam  int     L2_BANK_WRAP_NUM_WAKEUP = 2;        // MIN value is 2

// ----------------------------------------------------------------------------------------------
// internal signal define
// ----------------------------------------------------------------------------------------------
logic               crg_aligned_clk;
logic               crg_aligned_resetn;
logic               crg_unaligned_clk;
logic               crg_unaligned_resetn;
logic               crm_out_clk;
logic               crm_out_resetn;
logic               l2_bank0_idle;
logic               l2_bank1_idle;
logic               mem_sched_idle;
logic               sched_xbar_idle;
logic               nsp_xbar_idle;
logic               l2_ipg_wakeup;
// AXI interface
logic                       pipe_axi_slv_0_arvalid   ;
logic                       pipe_axi_slv_0_arready   ;
axi5_ar_data_bus_t          pipe_axi_slv_0_ar_rec    ;
logic                       pipe_axi_slv_0_rvalid    ;
logic                       pipe_axi_slv_0_rready    ;
axi5_r_data_bus_t           pipe_axi_slv_0_r_rec     ;
logic                       pipe_axi_slv_0_awvalid   ;
logic                       pipe_axi_slv_0_awready   ;
axi5_aw_data_bus_t          pipe_axi_slv_0_aw_rec    ;
logic                       pipe_axi_slv_0_wvalid    ;
logic                       pipe_axi_slv_0_wready    ;
axi5_w_data_bus_t           pipe_axi_slv_0_w_rec     ;
logic                       pipe_axi_slv_0_bvalid    ;
logic                       pipe_axi_slv_0_bready    ;
axi5_b_data_bus_t           pipe_axi_slv_0_b_rec     ;

logic                       pipe_axi_slv_1_arvalid   ;
logic                       pipe_axi_slv_1_arready   ;
axi5_ar_data_bus_t          pipe_axi_slv_1_ar_rec    ;
logic                       pipe_axi_slv_1_rvalid    ;
logic                       pipe_axi_slv_1_rready    ;
axi5_r_data_bus_t           pipe_axi_slv_1_r_rec     ;
logic                       pipe_axi_slv_1_awvalid   ;
logic                       pipe_axi_slv_1_awready   ;
axi5_aw_data_bus_t          pipe_axi_slv_1_aw_rec    ;
logic                       pipe_axi_slv_1_wvalid    ;
logic                       pipe_axi_slv_1_wready    ;
axi5_w_data_bus_t           pipe_axi_slv_1_w_rec     ;
logic                       pipe_axi_slv_1_bvalid    ;
logic                       pipe_axi_slv_1_bready    ;
axi5_b_data_bus_t           pipe_axi_slv_1_b_rec     ;

logic                       ipg_axi_slv_0_arvalid   ;
logic                       ipg_axi_slv_0_arready   ;
axi5_ar_data_bus_t          ipg_axi_slv_0_ar_rec    ;
logic                       ipg_axi_slv_0_rvalid    ;
logic                       ipg_axi_slv_0_rready    ;
axi5_r_data_bus_t           ipg_axi_slv_0_r_rec     ;
logic                       ipg_axi_slv_0_awvalid   ;
logic                       ipg_axi_slv_0_awready   ;
axi5_aw_data_bus_t          ipg_axi_slv_0_aw_rec    ;
logic                       ipg_axi_slv_0_wvalid    ;
logic                       ipg_axi_slv_0_wready    ;
axi5_w_data_bus_t           ipg_axi_slv_0_w_rec     ;
logic                       ipg_axi_slv_0_bvalid    ;
logic                       ipg_axi_slv_0_bready    ;
axi5_b_data_bus_t           ipg_axi_slv_0_b_rec     ;

logic                       ipg_axi_slv_1_arvalid   ;
logic                       ipg_axi_slv_1_arready   ;
axi5_ar_data_bus_t          ipg_axi_slv_1_ar_rec    ;
logic                       ipg_axi_slv_1_rvalid    ;
logic                       ipg_axi_slv_1_rready    ;
axi5_r_data_bus_t           ipg_axi_slv_1_r_rec     ;
logic                       ipg_axi_slv_1_awvalid   ;
logic                       ipg_axi_slv_1_awready   ;
axi5_aw_data_bus_t          ipg_axi_slv_1_aw_rec    ;
logic                       ipg_axi_slv_1_wvalid    ;
logic                       ipg_axi_slv_1_wready    ;
axi5_w_data_bus_t           ipg_axi_slv_1_w_rec     ;
logic                       ipg_axi_slv_1_bvalid    ;
logic                       ipg_axi_slv_1_bready    ;
axi5_b_data_bus_t           ipg_axi_slv_1_b_rec     ;
// NSP interface
logic                    [L2_XBAR_NUM_BANK-1:0] l2_nsp_req_valid;
logic                    [L2_XBAR_NUM_BANK-1:0] l2_nsp_req_ready;
group_nsp_req_data_bus_t [L2_XBAR_NUM_BANK-1:0] l2_nsp_req_rec  ;
logic                    [L2_XBAR_NUM_BANK-1:0] l2_nsp_rsp_valid;
logic                    [L2_XBAR_NUM_BANK-1:0] l2_nsp_rsp_ready;
group_nsp_rsp_data_bus_t [L2_XBAR_NUM_BANK-1:0] l2_nsp_rsp_rec  ;

logic                    [L2_XBAR_NUM_BANK-1:0]   pipe_nsp_req_valid;
logic                    [L2_XBAR_NUM_BANK-1:0]   pipe_nsp_req_ready;
group_nsp_req_data_bus_t [L2_XBAR_NUM_BANK-1:0]   pipe_nsp_req_rec;
logic                    [L2_XBAR_NUM_BANK-1:0]   pipe_nsp_rsp_valid;
logic                    [L2_XBAR_NUM_BANK-1:0]   pipe_nsp_rsp_ready;
group_nsp_rsp_data_bus_t [L2_XBAR_NUM_BANK-1:0]   pipe_nsp_rsp_rec;
logic                    [L2_XBAR_NUM_BANK-1:0]   ipg_nsp_req_valid;
logic                    [L2_XBAR_NUM_BANK-1:0]   ipg_nsp_req_ready;
group_nsp_req_data_bus_t [L2_XBAR_NUM_BANK-1:0]   ipg_nsp_req_rec;
logic                    [L2_XBAR_NUM_BANK-1:0]   ipg_nsp_rsp_valid;
logic                    [L2_XBAR_NUM_BANK-1:0]   ipg_nsp_rsp_ready;
group_nsp_rsp_data_bus_t [L2_XBAR_NUM_BANK-1:0]   ipg_nsp_rsp_rec;
// l2_bank <--> mem_sched interface
logic                       bank0_memif_sched_valid;
logic                       bank0_memif_sched_ready;
bank_sched_data_bus_t       bank0_memif_sched_rec;
logic                       bank0_sched_memif_valid;
logic                       bank0_sched_memif_ready;
sched_bank_data_bus_t       bank0_sched_memif_rec;
logic                       bank0_nsp_req_valid;
logic                       bank0_nsp_req_ready;
nsp_req_data_bus_t          bank0_nsp_req_rec;
logic                       bank0_nsp_rsp_valid;
logic                       bank0_nsp_rsp_ready;
nsp_rsp_data_bus_t          bank0_nsp_rsp_rec;
logic                       bank1_memif_sched_valid;
logic                       bank1_memif_sched_ready;
bank_sched_data_bus_t       bank1_memif_sched_rec;
logic                       bank1_sched_memif_valid;
logic                       bank1_sched_memif_ready;
sched_bank_data_bus_t       bank1_sched_memif_rec;
logic                       bank1_nsp_req_valid;
logic                       bank1_nsp_req_ready;
nsp_req_data_bus_t          bank1_nsp_req_rec;
logic                       bank1_nsp_rsp_valid;
logic                       bank1_nsp_rsp_ready;
nsp_rsp_data_bus_t          bank1_nsp_rsp_rec;

logic                       [L2_XBAR_NUM_BANK-1:0]  xbar_sched_req_valid;
logic                       [L2_XBAR_NUM_BANK-1:0]  xbar_sched_req_ready;
bank_group_sched_data_bus_t [L2_XBAR_NUM_BANK-1:0]  xbar_sched_req_rec  ;
logic                       [L2_XBAR_NUM_BANK-1:0]  sched_xbar_rsp_valid;
logic                       [L2_XBAR_NUM_BANK-1:0]  sched_xbar_rsp_ready;
sched_bank_group_data_bus_t [L2_XBAR_NUM_BANK-1:0]  sched_xbar_rsp_rec  ;

// configure register
logic [ 4 : 0 ]             pipe_gc_cr_l2_mem_sched_row_partii_row_id_bit8;
logic [ 4 : 0 ]             pipe_gc_cr_l2_mem_sched_row_partii_row_id_bit9;
logic [ 4 : 0 ]             pipe_gc_cr_l2_mem_sched_row_partii_row_id_bit10;
logic [ 4 : 0 ]             pipe_gc_cr_l2_mem_sched_row_partii_row_id_bit11;
logic [ 4 : 0 ]             pipe_gc_cr_l2_mem_sched_row_partii_row_id_bit12;
logic [ 4 : 0 ]             pipe_gc_cr_l2_mem_sched_row_partii_row_id_bit13;
logic [ 4 : 0 ]             pipe_gc_cr_l2_mem_sched_row_partii_row_id_bit14;
logic [ 4 : 0 ]             pipe_gc_cr_l2_mem_sched_row_partii_row_id_bit15;
logic [ 4 : 0 ]             pipe_gc_cr_l2_mem_sched_row_partiii_row_id_bit16;
logic [ 4 : 0 ]             pipe_gc_cr_l2_mem_sched_row_partiii_row_id_bit17;
logic [ 3 : 0 ]             pipe_gc_cr_l2_function_enable_ddr_capacity;
logic [ 1 : 0 ]             pipe_gc_cr_clk_ctrl3_l2g;
logic                       pipe_gc_cr_clk_status3_l2g;
logic [ 1 : 0 ]             pipe_gc_cr_l2_cfi_operation;
logic                       pipe_gc_cr_l2_cfi_statusi_l2b0_finish;
logic                       pipe_gc_cr_l2_cfi_statusi_l2b1_finish;
logic [ 1 : 0 ]             pipe_gc_cr_l2_buffer_mode_buffer_mode_percentage;
logic                       pipe_gc_cr_l2_persistence_reduce_enable;
logic [ 20 : 0 ]            pipe_gc_cr_l2_persistence_reduce_threshold;
logic                       pipe_gc_cr_l2_cmd_persistence_rst_all;
logic                       pipe_gc_cr_l2_cmd_cfi_clr;
logic [ 1 : 0 ]             pipe_gc_cr_l2g_idle_l2g;
logic [ 2 : 0 ]             pipe_gc_cr_l2g_error0_l2b0;
logic [ 2 : 0 ]             pipe_gc_cr_l2g_error0_l2b1;
logic                       pipe_gc_cr_l2_function_enable_mem_scheduler;
logic                       pipe_gc_cr_l2_function_enable_bypass_mode;
logic [ 4 : 0 ]             pipe_gc_cr_l2_mem_sched_col_offset_column_id_bit0;
logic [ 4 : 0 ]             pipe_gc_cr_l2_mem_sched_col_offset_column_id_bit1;
logic [ 4 : 0 ]             pipe_gc_cr_l2_mem_sched_col_offset_column_id_bit2;
logic [ 4 : 0 ]             pipe_gc_cr_l2_mem_sched_col_offset_column_id_bit3;
logic [ 4 : 0 ]             pipe_gc_cr_l2_mem_sched_col_offset_column_id_bit4;
logic [ 4 : 0 ]             pipe_gc_cr_l2_mem_sched_col_offset_column_id_bit5;
logic [ 4 : 0 ]             pipe_gc_cr_l2_mem_sched_bank_offset_bank_id_bit0;
logic [ 4 : 0 ]             pipe_gc_cr_l2_mem_sched_bank_offset_bank_id_bit1;
logic [ 4 : 0 ]             pipe_gc_cr_l2_mem_sched_bank_offset_bank_id_bit2;
logic [ 4 : 0 ]             pipe_gc_cr_l2_mem_sched_bank_offset_bank_id_bit3;
logic [ 4 : 0 ]             pipe_gc_cr_l2_mem_sched_bank_offset_bank_id_bit4;
logic [ 4 : 0 ]             pipe_gc_cr_l2_mem_sched_row_parti_row_id_bit0;
logic [ 4 : 0 ]             pipe_gc_cr_l2_mem_sched_row_parti_row_id_bit1;
logic [ 4 : 0 ]             pipe_gc_cr_l2_mem_sched_row_parti_row_id_bit2;
logic [ 4 : 0 ]             pipe_gc_cr_l2_mem_sched_row_parti_row_id_bit3;
logic [ 4 : 0 ]             pipe_gc_cr_l2_mem_sched_row_parti_row_id_bit4;
logic [ 4 : 0 ]             pipe_gc_cr_l2_mem_sched_row_parti_row_id_bit5;
logic [ 4 : 0 ]             pipe_gc_cr_l2_mem_sched_row_parti_row_id_bit6;
logic [ 4 : 0 ]             pipe_gc_cr_l2_mem_sched_row_parti_row_id_bit7;
logic [ 4 : 0 ]             pipe_gc_cr_pwr_man_hysteresis_value;
logic [ 1 : 0 ]             pipe_gc_cr_crm_reset_clk_ctrl;
logic                       pipe_gc_cr_cu_lms_fp32_denormal_en;
logic                       pipe_gc_cr_l2_cfi_operation_notify;
logic                       pipe_gc_cr_l2_cfi_operation_rdnotify;
logic                       pipe_gc_cr_l2_cmd_notify;
logic                       pipe_gc_cr_l2_cmd_rdnotify;

logic                       pipe_l2b0_busy                        ;
logic                       pipe_l2b0_fromaxi_ar_wl               ;
logic                       pipe_l2b0_fromaxi_ar_bl_eq0_wl        ;
logic                       pipe_l2b0_fromaxi_ar_bl_eq1_wl        ;
logic                       pipe_l2b0_fromaxi_ar_bl_eq2_wl        ;
logic                       pipe_l2b0_fromaxi_ar_bl_eq3_wl        ;
logic                       pipe_l2b0_fromaxi_ar_bp               ;
logic                       pipe_l2b0_toaxi_r_wl                  ;
logic                       pipe_l2b0_toaxi_r_bp                  ;
logic                       pipe_l2b0_fromaxi_aw_wl               ;
logic                       pipe_l2b0_fromaxi_aw_bl_eq0_wl        ;
logic                       pipe_l2b0_fromaxi_aw_bl_eq1_wl        ;
logic                       pipe_l2b0_fromaxi_aw_bl_eq2_wl        ;
logic                       pipe_l2b0_fromaxi_aw_bl_eq3_wl        ;
logic                       pipe_l2b0_fromaxi_aw_bp               ;
logic                       pipe_l2b0_fromaxi_w_wl                ;
logic                       pipe_l2b0_fromaxi_w_bp                ;
logic                       pipe_l2b0_fromaxi_smp_read_req_num    ;
logic                       pipe_l2b0_fromaxi_smp_read_req_sum    ;
logic                       pipe_l2b0_fromaxi_smp_write_req_num   ;
logic                       pipe_l2b0_fromaxi_smp_write_req_sum   ;
logic                       pipe_l2b0_fromaxi_smp_atomic_req_num  ;
logic                       pipe_l2b0_fromaxi_smp_atomic_req_sum  ;
logic                       pipe_l2b0_align_awdb_full             ;
logic                       pipe_l2b0_hittest_ht_bypass_read_wl   ;
logic                       pipe_l2b0_hittest_ht_cache_read_wl    ;
logic                       pipe_l2b0_hittest_ht_bypass_write_wl  ;
logic                       pipe_l2b0_hittest_ht_cache_write_wl   ;
logic                       pipe_l2b0_hittest_ht_atomic_wl        ;
logic                       pipe_l2b0_hittest_ht_bps_hit_wl       ;
logic                       pipe_l2b0_hittest_ht_miss_wl          ;
logic                       pipe_l2b0_frommemsch_nsp_rtn_wl       ;
logic                       pipe_l2b0_frommemsch_nsp_rtn_bp       ;
logic                       pipe_l2b0_tomemsch_nsp_read_bl_eq1_wl ;
logic                       pipe_l2b0_tomemsch_nsp_read_bl_eq3_wl ;
logic                       pipe_l2b0_tomemsch_nsp_read_bl_eq5_wl ;
logic                       pipe_l2b0_tomemsch_nsp_read_bl_eq7_wl ;
logic                       pipe_l2b0_tomemsch_nsp_write_bl_eq1_wl;
logic                       pipe_l2b0_tomemsch_nsp_write_bl_eq3_wl;
logic                       pipe_l2b0_tomemsch_nsp_write_bl_eq5_wl;
logic                       pipe_l2b0_tomemsch_nsp_write_bl_eq7_wl;
logic                       pipe_l2b0_memif_to_ddr_read_wl        ;
logic                       pipe_l2b0_memif_to_ddr_read_stall_by_rob          ;
logic                       pipe_l2b0_memif_to_ddr_read_stall_by_ddr          ;
logic                       pipe_l2b0_memif_to_ddr_read_stall_by_trid         ;
logic                       pipe_l2b0_memif_to_ddr_write_wl                   ;
logic                       pipe_l2b0_memif_to_ddr_write_stall_by_data_sync   ;
logic                       pipe_l2b0_memif_to_ddr_write_stall_by_ddr         ;
logic                       pipe_l2b0_memif_to_ddr_write_stall_by_trid        ;
logic                       pipe_l2b0_memif_memreq_full                       ;
logic                       pipe_l2b0_memif_smp_read_req_num                  ;
logic                       pipe_l2b0_memif_smp_read_req_sum                  ;
logic                       pipe_l2b0_reqsch_sortq_full                       ;
logic                       pipe_l2b0_reqsch_sortq_stall_but_not_full         ;
logic                       pipe_l2b0_reqsch_disp_wl                          ;
logic                       pipe_l2b0_reqsch_disp_stall                       ;
logic                       pipe_l2b0_ramctrl_0_reqarb_wl                     ;
logic                       pipe_l2b0_ramctrl_0_reqarb_stall_by_sram          ;
logic                       pipe_l2b0_ramctrl_0_data_sram_read_wl             ;
logic                       pipe_l2b0_ramctrl_0_data_sram_write_wl            ;
logic                       pipe_l2b0_ramctrl_1_reqarb_wl                     ;
logic                       pipe_l2b0_ramctrl_1_reqarb_stall_by_sram          ;
logic                       pipe_l2b0_ramctrl_1_data_sram_read_wl             ;
logic                       pipe_l2b0_ramctrl_1_data_sram_write_wl            ;
logic                       pipe_l2b1_busy                        ;
logic                       pipe_l2b1_fromaxi_ar_wl               ;
logic                       pipe_l2b1_fromaxi_ar_bl_eq0_wl        ;
logic                       pipe_l2b1_fromaxi_ar_bl_eq1_wl        ;
logic                       pipe_l2b1_fromaxi_ar_bl_eq2_wl        ;
logic                       pipe_l2b1_fromaxi_ar_bl_eq3_wl        ;
logic                       pipe_l2b1_fromaxi_ar_bp               ;
logic                       pipe_l2b1_toaxi_r_wl                  ;
logic                       pipe_l2b1_toaxi_r_bp                  ;
logic                       pipe_l2b1_fromaxi_aw_wl               ;
logic                       pipe_l2b1_fromaxi_aw_bl_eq0_wl        ;
logic                       pipe_l2b1_fromaxi_aw_bl_eq1_wl        ;
logic                       pipe_l2b1_fromaxi_aw_bl_eq2_wl        ;
logic                       pipe_l2b1_fromaxi_aw_bl_eq3_wl        ;
logic                       pipe_l2b1_fromaxi_aw_bp               ;
logic                       pipe_l2b1_fromaxi_w_wl                ;
logic                       pipe_l2b1_fromaxi_w_bp                ;
logic                       pipe_l2b1_fromaxi_smp_read_req_num    ;
logic                       pipe_l2b1_fromaxi_smp_read_req_sum    ;
logic                       pipe_l2b1_fromaxi_smp_write_req_num   ;
logic                       pipe_l2b1_fromaxi_smp_write_req_sum   ;
logic                       pipe_l2b1_fromaxi_smp_atomic_req_num  ;
logic                       pipe_l2b1_fromaxi_smp_atomic_req_sum  ;
logic                       pipe_l2b1_align_awdb_full             ;
logic                       pipe_l2b1_hittest_ht_bypass_read_wl   ;
logic                       pipe_l2b1_hittest_ht_cache_read_wl    ;
logic                       pipe_l2b1_hittest_ht_bypass_write_wl  ;
logic                       pipe_l2b1_hittest_ht_cache_write_wl   ;
logic                       pipe_l2b1_hittest_ht_atomic_wl        ;
logic                       pipe_l2b1_hittest_ht_bps_hit_wl       ;
logic                       pipe_l2b1_hittest_ht_miss_wl          ;
logic                       pipe_l2b1_frommemsch_nsp_rtn_wl       ;
logic                       pipe_l2b1_frommemsch_nsp_rtn_bp       ;
logic                       pipe_l2b1_tomemsch_nsp_read_bl_eq1_wl ;
logic                       pipe_l2b1_tomemsch_nsp_read_bl_eq3_wl ;
logic                       pipe_l2b1_tomemsch_nsp_read_bl_eq5_wl ;
logic                       pipe_l2b1_tomemsch_nsp_read_bl_eq7_wl ;
logic                       pipe_l2b1_tomemsch_nsp_write_bl_eq1_wl;
logic                       pipe_l2b1_tomemsch_nsp_write_bl_eq3_wl;
logic                       pipe_l2b1_tomemsch_nsp_write_bl_eq5_wl;
logic                       pipe_l2b1_tomemsch_nsp_write_bl_eq7_wl;
logic                       pipe_l2b1_memif_to_ddr_read_wl        ;
logic                       pipe_l2b1_memif_to_ddr_read_stall_by_rob          ;
logic                       pipe_l2b1_memif_to_ddr_read_stall_by_ddr          ;
logic                       pipe_l2b1_memif_to_ddr_read_stall_by_trid         ;
logic                       pipe_l2b1_memif_to_ddr_write_wl                   ;
logic                       pipe_l2b1_memif_to_ddr_write_stall_by_data_sync   ;
logic                       pipe_l2b1_memif_to_ddr_write_stall_by_ddr         ;
logic                       pipe_l2b1_memif_to_ddr_write_stall_by_trid        ;
logic                       pipe_l2b1_memif_memreq_full                       ;
logic                       pipe_l2b1_memif_smp_read_req_num                  ;
logic                       pipe_l2b1_memif_smp_read_req_sum                  ;
logic                       pipe_l2b1_reqsch_sortq_full                       ;
logic                       pipe_l2b1_reqsch_sortq_stall_but_not_full         ;
logic                       pipe_l2b1_reqsch_disp_wl                          ;
logic                       pipe_l2b1_reqsch_disp_stall                       ;
logic                       pipe_l2b1_ramctrl_0_reqarb_wl                     ;
logic                       pipe_l2b1_ramctrl_0_reqarb_stall_by_sram          ;
logic                       pipe_l2b1_ramctrl_0_data_sram_read_wl             ;
logic                       pipe_l2b1_ramctrl_0_data_sram_write_wl            ;
logic                       pipe_l2b1_ramctrl_1_reqarb_wl                     ;
logic                       pipe_l2b1_ramctrl_1_reqarb_stall_by_sram          ;
logic                       pipe_l2b1_ramctrl_1_data_sram_read_wl             ;
logic                       pipe_l2b1_ramctrl_1_data_sram_write_wl            ;
logic [ 3 : 0 ]             pipe_gc_cr_ddr_hash_config_reg0_row_id_bit0       ; 
logic [ 3 : 0 ]             pipe_gc_cr_ddr_hash_config_reg0_row_id_bit1       ; 
logic [ 3 : 0 ]             pipe_gc_cr_ddr_hash_config_reg0_row_id_bit2       ; 
logic [ 3 : 0 ]             pipe_gc_cr_ddr_hash_config_reg0_row_id_bit3       ; 
logic [ 3 : 0 ]             pipe_gc_cr_ddr_hash_config_reg0_row_id_bit4       ; 
logic [ 3 : 0 ]             pipe_gc_cr_ddr_hash_config_reg0_row_id_bit5       ; 
logic [ 3 : 0 ]             pipe_gc_cr_ddr_hash_config_reg0_row_id_bit6       ; 
logic [ 3 : 0 ]             pipe_gc_cr_ddr_hash_config_reg0_row_id_bit7       ; 
logic [ 3 : 0 ]             pipe_gc_cr_ddr_hash_config_reg0_row_id_bit8       ; 
logic [ 3 : 0 ]             pipe_gc_cr_ddr_hash_config_reg0_row_id_bit9       ; 
logic [ 3 : 0 ]             pipe_gc_cr_ddr_hash_config_reg0_row_id_bit10      ; 
logic [ 3 : 0 ]             pipe_gc_cr_ddr_hash_config_reg0_row_id_bit11      ; 
logic [ 3 : 0 ]             pipe_gc_cr_ddr_hash_config_reg1_row_id_bit12      ; 
logic [ 3 : 0 ]             pipe_gc_cr_ddr_hash_config_reg1_row_id_bit13      ; 
logic [ 3 : 0 ]             pipe_gc_cr_ddr_hash_config_reg1_row_id_bit14      ; 
logic [ 3 : 0 ]             pipe_gc_cr_ddr_hash_config_reg1_row_id_bit15      ; 
logic [ 3 : 0 ]             pipe_gc_cr_ddr_hash_config_reg1_row_id_bit16      ; 
logic [ 3 : 0 ]             pipe_gc_cr_ddr_hash_config_reg1_row_id_bit17      ; 
logic [ 3 : 0 ]             pipe_gc_cr_ddr_hash_config_reg1_row_id_bit18      ; 
logic [ 3 : 0 ]             pipe_gc_cr_ddr_hash_config_reg1_row_id_bit19      ; 
logic [ 3 : 0 ]             pipe_gc_cr_ddr_hash_config_reg1_row_id_bit20      ; 
logic [ 3 : 0 ]             pipe_gc_cr_ddr_hash_config_reg1_row_id_bit21      ; 
logic [ 3 : 0 ]             pipe_gc_cr_ddr_hash_config_reg1_row_id_bit22      ; 
logic [ 3 : 0 ]             pipe_gc_cr_ddr_hash_config_reg1_row_id_bit23      ; 
logic [ 1 : 0 ]             pipe_gc_cr_l2_function_enable_hash_mode           ; 

logic                       pipe_socif_wakeup;
// ----------------------------------------------------------------------------------------------
// CRG & CRM
// ----------------------------------------------------------------------------------------------

assign crg_aligned_clk      = clk    ;
assign crg_aligned_resetn   = resetn ;
assign crg_unaligned_clk    = clk    ;
assign crg_unaligned_resetn = resetn ;

gpc_gfx_timing_buffer_no_handshake_pipe_ #(
    .WIDTH          (1                      ),
    .PIPE_STAGES    (3                      ),
    .INI_DAT        (1'b0                   )
) i_tb_l2_bank_socif_wakeup (
    .clk            (crg_unaligned_clk      ),
    .resetn         (crg_unaligned_resetn   ),
    .tbuff_in_data  (socif_wakeup           ),
    .tbuff_out_data (pipe_socif_wakeup      )
);


gc_crm_no_delay #(
    .NUM_MODULES    (L2_BANK_WRAP_NUM_IDLE      ),
    .NUM_WAKEUPS    (L2_BANK_WRAP_NUM_WAKEUP    )
) i_l2_crm (
    .socif_wakeup               (pipe_socif_wakeup                              ),  // I
    .in_clk                     (crg_unaligned_clk                              ),  // I
    .in_resetn                  (crg_unaligned_resetn                           ),  // I
    .out_clk                    (crm_out_clk                                    ),  // O
    .out_resetn                 (crm_out_resetn                                 ),  // O
    .in_idle                    ({l2_bank0_idle, l2_bank1_idle}                 ),  // I
    .clk_ctrl                   (pipe_gc_cr_clk_ctrl3_l2g                       ),  // I
    .clk_status                 (pipe_gc_cr_clk_status3_l2g                     ),  // O
    .wakeup                     (l2_ipg_wakeup                                  ),  // I
    .soft_reset_core            (1'b0                                           ),  // I software cannt reset L2 bank because L2 bank can be accessed by PCIE or another die.
    .tst_gclkenable             (tst_gclkenable                                 ),  // I
    .tst_rst_bypass             (tst_rst_bypass                                 ),  // I
    .pwr_man_hysteresis_value   (pipe_gc_cr_pwr_man_hysteresis_value            ),  // I
    .gc_cr_crm_reset_clk_ctrl  (pipe_gc_cr_crm_reset_clk_ctrl                  ));  // I

assign pipe_gc_cr_l2g_idle_l2g = {l2_bank1_idle, l2_bank0_idle};

assign l2_nsp0_req_valid    = l2_nsp_req_valid[0] ;
assign l2_nsp0_req_rec      = l2_nsp_req_rec  [0] ;
assign l2_nsp0_rsp_ready    = l2_nsp_rsp_ready[0] ;

assign l2_nsp_req_ready[0]  = l2_nsp0_req_ready   ;
assign l2_nsp_rsp_valid[0]  = l2_nsp0_rsp_valid   ;
assign l2_nsp_rsp_rec  [0]  = l2_nsp0_rsp_rec     ;

assign l2_nsp1_req_valid    = l2_nsp_req_valid[1] ;
assign l2_nsp1_req_rec      = l2_nsp_req_rec  [1] ;
assign l2_nsp1_rsp_ready    = l2_nsp_rsp_ready[1] ;

assign l2_nsp_req_ready[1]  = l2_nsp1_req_ready   ;
assign l2_nsp_rsp_valid[1]  = l2_nsp1_rsp_valid   ;
assign l2_nsp_rsp_rec  [1]  = l2_nsp1_rsp_rec     ;


// ----------------------------------------------------------------------------------------------
// internal pipeline instance
// ----------------------------------------------------------------------------------------------
gc_l2_bank_int_pipe 
#(.BANK_WRAP(BANK_WRAP))
i_gc_l2_bank_int_pipe(
    // AXI interface
    .i_axi_slv_0_arvalid        (axi_slv_0_arvalid              ),  // I
    .i_axi_slv_0_arready        (axi_slv_0_arready              ),  // O
    .i_axi_slv_0_ar_rec         (axi_slv_0_ar_rec               ),  // I
    .i_axi_slv_0_rvalid         (axi_slv_0_rvalid               ),  // O
    .i_axi_slv_0_rready         (axi_slv_0_rready               ),  // I
    .i_axi_slv_0_r_rec          (axi_slv_0_r_rec                ),  // O
    .i_axi_slv_0_awvalid        (axi_slv_0_awvalid              ),  // I
    .i_axi_slv_0_awready        (axi_slv_0_awready              ),  // O
    .i_axi_slv_0_aw_rec         (axi_slv_0_aw_rec               ),  // I
    .i_axi_slv_0_wvalid         (axi_slv_0_wvalid               ),  // I
    .i_axi_slv_0_wready         (axi_slv_0_wready               ),  // O
    .i_axi_slv_0_w_rec          (axi_slv_0_w_rec                ),  // I
    .i_axi_slv_0_bvalid         (axi_slv_0_bvalid               ),  // O
    .i_axi_slv_0_bready         (axi_slv_0_bready               ),  // I
    .i_axi_slv_0_b_rec          (axi_slv_0_b_rec                ),  // O

    .o_axi_slv_0_arvalid        (pipe_axi_slv_0_arvalid         ),  // O
    .o_axi_slv_0_arready        (pipe_axi_slv_0_arready         ),  // I
    .o_axi_slv_0_ar_rec         (pipe_axi_slv_0_ar_rec          ),  // O
    .o_axi_slv_0_rvalid         (pipe_axi_slv_0_rvalid          ),  // I
    .o_axi_slv_0_rready         (pipe_axi_slv_0_rready          ),  // O
    .o_axi_slv_0_r_rec          (pipe_axi_slv_0_r_rec           ),  // I
    .o_axi_slv_0_awvalid        (pipe_axi_slv_0_awvalid         ),  // O
    .o_axi_slv_0_awready        (pipe_axi_slv_0_awready         ),  // I
    .o_axi_slv_0_aw_rec         (pipe_axi_slv_0_aw_rec          ),  // O
    .o_axi_slv_0_wvalid         (pipe_axi_slv_0_wvalid          ),  // O
    .o_axi_slv_0_wready         (pipe_axi_slv_0_wready          ),  // I
    .o_axi_slv_0_w_rec          (pipe_axi_slv_0_w_rec           ),  // O
    .o_axi_slv_0_bvalid         (pipe_axi_slv_0_bvalid          ),  // I
    .o_axi_slv_0_bready         (pipe_axi_slv_0_bready          ),  // O
    .o_axi_slv_0_b_rec          (pipe_axi_slv_0_b_rec           ),  // I

    .i_axi_slv_1_arvalid        (axi_slv_1_arvalid              ),  // I
    .i_axi_slv_1_arready        (axi_slv_1_arready              ),  // O
    .i_axi_slv_1_ar_rec         (axi_slv_1_ar_rec               ),  // I
    .i_axi_slv_1_rvalid         (axi_slv_1_rvalid               ),  // O
    .i_axi_slv_1_rready         (axi_slv_1_rready               ),  // I
    .i_axi_slv_1_r_rec          (axi_slv_1_r_rec                ),  // O
    .i_axi_slv_1_awvalid        (axi_slv_1_awvalid              ),  // I
    .i_axi_slv_1_awready        (axi_slv_1_awready              ),  // O
    .i_axi_slv_1_aw_rec         (axi_slv_1_aw_rec               ),  // I
    .i_axi_slv_1_wvalid         (axi_slv_1_wvalid               ),  // I
    .i_axi_slv_1_wready         (axi_slv_1_wready               ),  // O
    .i_axi_slv_1_w_rec          (axi_slv_1_w_rec                ),  // I
    .i_axi_slv_1_bvalid         (axi_slv_1_bvalid               ),  // O
    .i_axi_slv_1_bready         (axi_slv_1_bready               ),  // I
    .i_axi_slv_1_b_rec          (axi_slv_1_b_rec                ),  // O

    .o_axi_slv_1_arvalid        (pipe_axi_slv_1_arvalid         ),  // O
    .o_axi_slv_1_arready        (pipe_axi_slv_1_arready         ),  // I
    .o_axi_slv_1_ar_rec         (pipe_axi_slv_1_ar_rec          ),  // O
    .o_axi_slv_1_rvalid         (pipe_axi_slv_1_rvalid          ),  // I
    .o_axi_slv_1_rready         (pipe_axi_slv_1_rready          ),  // O
    .o_axi_slv_1_r_rec          (pipe_axi_slv_1_r_rec           ),  // I
    .o_axi_slv_1_awvalid        (pipe_axi_slv_1_awvalid         ),  // O
    .o_axi_slv_1_awready        (pipe_axi_slv_1_awready         ),  // I
    .o_axi_slv_1_aw_rec         (pipe_axi_slv_1_aw_rec          ),  // O
    .o_axi_slv_1_wvalid         (pipe_axi_slv_1_wvalid          ),  // O
    .o_axi_slv_1_wready         (pipe_axi_slv_1_wready          ),  // I
    .o_axi_slv_1_w_rec          (pipe_axi_slv_1_w_rec           ),  // O
    .o_axi_slv_1_bvalid         (pipe_axi_slv_1_bvalid          ),  // I
    .o_axi_slv_1_bready         (pipe_axi_slv_1_bready          ),  // O
    .o_axi_slv_1_b_rec          (pipe_axi_slv_1_b_rec           ),  // I
    // NSP interface
    .i_nsp_req_valid            (pipe_nsp_req_valid             ),  // I
    .i_nsp_req_ready            (pipe_nsp_req_ready             ),  // O
    .i_nsp_req_rec              (pipe_nsp_req_rec               ),  // I
    .i_nsp_rsp_valid            (pipe_nsp_rsp_valid             ),  // O
    .i_nsp_rsp_ready            (pipe_nsp_rsp_ready             ),  // I
    .i_nsp_rsp_rec              (pipe_nsp_rsp_rec               ),  // O

    .o_nsp_req_valid            (l2_nsp_req_valid               ),  // O
    .o_nsp_req_ready            (l2_nsp_req_ready               ),  // I
    .o_nsp_req_rec              (l2_nsp_req_rec                 ),  // O
    .o_nsp_rsp_valid            (l2_nsp_rsp_valid               ),  // I
    .o_nsp_rsp_ready            (l2_nsp_rsp_ready               ),  // O
    .o_nsp_rsp_rec              (l2_nsp_rsp_rec                 ),  // I
    // configure register
    .i_gc_cr_l2_mem_sched_row_partii_row_id_bit8    (gc_cr_l2_mem_sched_row_partii_row_id_bit8          ),  // I
    .i_gc_cr_l2_mem_sched_row_partii_row_id_bit9    (gc_cr_l2_mem_sched_row_partii_row_id_bit9          ),  // I
    .i_gc_cr_l2_mem_sched_row_partii_row_id_bit10   (gc_cr_l2_mem_sched_row_partii_row_id_bit10         ),  // I
    .i_gc_cr_l2_mem_sched_row_partii_row_id_bit11   (gc_cr_l2_mem_sched_row_partii_row_id_bit11         ),  // I
    .i_gc_cr_l2_mem_sched_row_partii_row_id_bit12   (gc_cr_l2_mem_sched_row_partii_row_id_bit12         ),  // I
    .i_gc_cr_l2_mem_sched_row_partii_row_id_bit13   (gc_cr_l2_mem_sched_row_partii_row_id_bit13         ),  // I
    .i_gc_cr_l2_mem_sched_row_partii_row_id_bit14   (gc_cr_l2_mem_sched_row_partii_row_id_bit14         ),  // I
    .i_gc_cr_l2_mem_sched_row_partii_row_id_bit15   (gc_cr_l2_mem_sched_row_partii_row_id_bit15         ),  // I
    .i_gc_cr_l2_mem_sched_row_partiii_row_id_bit16  (gc_cr_l2_mem_sched_row_partiii_row_id_bit16        ),  // I
    .i_gc_cr_l2_mem_sched_row_partiii_row_id_bit17  (gc_cr_l2_mem_sched_row_partiii_row_id_bit17        ),  // I
    .i_gc_cr_l2_function_enable_ddr_capacity        (gc_cr_l2_function_enable_ddr_capacity              ),  // I
    .i_gc_cr_clk_ctrl3_l2g                          (gc_cr_clk_ctrl3_l2g                                ),  // I
    .i_gc_cr_l2_cfi_operation                       (gc_cr_l2_cfi_operation                             ),  // I
    .i_gc_cr_l2_buffer_mode_buffer_mode_percentage  (gc_cr_l2_buffer_mode_buffer_mode_percentage        ),  // I
    .i_gc_cr_l2_persistence_reduce_enable           (gc_cr_l2_persistence_reduce_persistence_reduce_enable      ),  // I
    .i_gc_cr_l2_persistence_reduce_threshold        (gc_cr_l2_persistence_reduce_persistence_reduce_threshold   ),  // I
    .i_gc_cr_l2_cmd_persistence_rst_all             (gc_cr_l2_cmd_persistence_rst_all                   ),  // I
    .i_gc_cr_l2_cmd_cfi_clr                         (gc_cr_l2_cmd_cfi_clr                               ),  // I
    .i_gc_cr_l2_function_enable_mem_scheduler       (gc_cr_l2_function_enable_mem_scheduler             ),  // I
    .i_gc_cr_l2_function_enable_bypass_mode         (gc_cr_l2_function_enable_bypass_mode               ),  // I
    .i_gc_cr_l2_mem_sched_col_offset_column_id_bit0 (gc_cr_l2_mem_sched_col_offset_column_id_bit0       ),  // I
    .i_gc_cr_l2_mem_sched_col_offset_column_id_bit1 (gc_cr_l2_mem_sched_col_offset_column_id_bit1       ),  // I
    .i_gc_cr_l2_mem_sched_col_offset_column_id_bit2 (gc_cr_l2_mem_sched_col_offset_column_id_bit2       ),  // I
    .i_gc_cr_l2_mem_sched_col_offset_column_id_bit3 (gc_cr_l2_mem_sched_col_offset_column_id_bit3       ),  // I
    .i_gc_cr_l2_mem_sched_col_offset_column_id_bit4 (gc_cr_l2_mem_sched_col_offset_column_id_bit4       ),  // I
    .i_gc_cr_l2_mem_sched_col_offset_column_id_bit5 (gc_cr_l2_mem_sched_col_offset_column_id_bit5       ),  // I
    .i_gc_cr_l2_mem_sched_bank_offset_bank_id_bit0  (gc_cr_l2_mem_sched_bank_offset_bank_id_bit0        ),  // I
    .i_gc_cr_l2_mem_sched_bank_offset_bank_id_bit1  (gc_cr_l2_mem_sched_bank_offset_bank_id_bit1        ),  // I
    .i_gc_cr_l2_mem_sched_bank_offset_bank_id_bit2  (gc_cr_l2_mem_sched_bank_offset_bank_id_bit2        ),  // I
    .i_gc_cr_l2_mem_sched_bank_offset_bank_id_bit3  (gc_cr_l2_mem_sched_bank_offset_bank_id_bit3        ),  // I
    .i_gc_cr_l2_mem_sched_bank_offset_bank_id_bit4  (gc_cr_l2_mem_sched_bank_offset_bank_id_bit4        ),  // I
    .i_gc_cr_l2_mem_sched_row_parti_row_id_bit0     (gc_cr_l2_mem_sched_row_parti_row_id_bit0           ),  // I
    .i_gc_cr_l2_mem_sched_row_parti_row_id_bit1     (gc_cr_l2_mem_sched_row_parti_row_id_bit1           ),  // I
    .i_gc_cr_l2_mem_sched_row_parti_row_id_bit2     (gc_cr_l2_mem_sched_row_parti_row_id_bit2           ),  // I
    .i_gc_cr_l2_mem_sched_row_parti_row_id_bit3     (gc_cr_l2_mem_sched_row_parti_row_id_bit3           ),  // I
    .i_gc_cr_l2_mem_sched_row_parti_row_id_bit4     (gc_cr_l2_mem_sched_row_parti_row_id_bit4           ),  // I
    .i_gc_cr_l2_mem_sched_row_parti_row_id_bit5     (gc_cr_l2_mem_sched_row_parti_row_id_bit5           ),  // I
    .i_gc_cr_l2_mem_sched_row_parti_row_id_bit6     (gc_cr_l2_mem_sched_row_parti_row_id_bit6           ),  // I
    .i_gc_cr_l2_mem_sched_row_parti_row_id_bit7     (gc_cr_l2_mem_sched_row_parti_row_id_bit7           ),  // I    
    .i_gc_cr_ddr_hash_config_reg0_row_id_bit0       (gc_cr_ddr_hash_config_reg0_row_id_bit0             ),
    .i_gc_cr_ddr_hash_config_reg0_row_id_bit1       (gc_cr_ddr_hash_config_reg0_row_id_bit1             ),
    .i_gc_cr_ddr_hash_config_reg0_row_id_bit2       (gc_cr_ddr_hash_config_reg0_row_id_bit2             ),
    .i_gc_cr_ddr_hash_config_reg0_row_id_bit3       (gc_cr_ddr_hash_config_reg0_row_id_bit3             ),
    .i_gc_cr_ddr_hash_config_reg0_row_id_bit4       (gc_cr_ddr_hash_config_reg0_row_id_bit4             ),
    .i_gc_cr_ddr_hash_config_reg0_row_id_bit5       (gc_cr_ddr_hash_config_reg0_row_id_bit5             ),
    .i_gc_cr_ddr_hash_config_reg0_row_id_bit6       (gc_cr_ddr_hash_config_reg0_row_id_bit6             ),
    .i_gc_cr_ddr_hash_config_reg0_row_id_bit7       (gc_cr_ddr_hash_config_reg0_row_id_bit7             ),
    .i_gc_cr_ddr_hash_config_reg0_row_id_bit8       (gc_cr_ddr_hash_config_reg0_row_id_bit8             ),
    .i_gc_cr_ddr_hash_config_reg0_row_id_bit9       (gc_cr_ddr_hash_config_reg0_row_id_bit9             ),
    .i_gc_cr_ddr_hash_config_reg0_row_id_bit10      (gc_cr_ddr_hash_config_reg0_row_id_bit10            ),
    .i_gc_cr_ddr_hash_config_reg0_row_id_bit11      (gc_cr_ddr_hash_config_reg0_row_id_bit11            ),
    .i_gc_cr_ddr_hash_config_reg1_row_id_bit12      (gc_cr_ddr_hash_config_reg1_row_id_bit12            ),
    .i_gc_cr_ddr_hash_config_reg1_row_id_bit13      (gc_cr_ddr_hash_config_reg1_row_id_bit13            ),
    .i_gc_cr_ddr_hash_config_reg1_row_id_bit14      (gc_cr_ddr_hash_config_reg1_row_id_bit14            ),
    .i_gc_cr_ddr_hash_config_reg1_row_id_bit15      (gc_cr_ddr_hash_config_reg1_row_id_bit15            ),
    .i_gc_cr_ddr_hash_config_reg1_row_id_bit16      (gc_cr_ddr_hash_config_reg1_row_id_bit16            ),
    .i_gc_cr_ddr_hash_config_reg1_row_id_bit17      (gc_cr_ddr_hash_config_reg1_row_id_bit17            ),
    .i_gc_cr_ddr_hash_config_reg1_row_id_bit18      (gc_cr_ddr_hash_config_reg1_row_id_bit18            ),
    .i_gc_cr_ddr_hash_config_reg1_row_id_bit19      (gc_cr_ddr_hash_config_reg1_row_id_bit19            ),
    .i_gc_cr_ddr_hash_config_reg1_row_id_bit20      (gc_cr_ddr_hash_config_reg1_row_id_bit20            ),
    .i_gc_cr_ddr_hash_config_reg1_row_id_bit21      (gc_cr_ddr_hash_config_reg1_row_id_bit21            ),
    .i_gc_cr_ddr_hash_config_reg1_row_id_bit22      (gc_cr_ddr_hash_config_reg1_row_id_bit22            ),
    .i_gc_cr_ddr_hash_config_reg1_row_id_bit23      (gc_cr_ddr_hash_config_reg1_row_id_bit23            ),
    .i_gc_cr_l2_function_enable_hash_mode           (gc_cr_l2_function_enable_hash_mode                 ),


    .i_gc_cr_pwr_man_hysteresis_value               (gc_cr_pwr_man_hysteresis_value                     ),  // I
    .i_gc_cr_crm_reset_clk_ctrl                     (gc_cr_crm_reset_clk_ctrl                           ),  // I
    .i_gc_cr_cu_lms_fp32_denormal_en                (gc_cr_cu_lms_fp32_denormal_en                     ),  // I
    .i_gc_cr_l2_cfi_operation_notify                (gc_cr_l2_cfi_operation_notify                      ),  // I
    .i_gc_cr_l2_cfi_operation_rdnotify              (gc_cr_l2_cfi_operation_rdnotify                    ),  // I
    .i_gc_cr_l2_cmd_notify                          (gc_cr_l2_cmd_notify                                ),  // I
    .i_gc_cr_l2_cmd_rdnotify                        (gc_cr_l2_cmd_rdnotify                              ),  // I
    .i_gc_cr_clk_status3_l2g                        (gc_cr_clk_status3_l2g                              ),  // O
    .i_gc_cr_l2_cfi_statusi_l2b0_finish             (gc_cr_l2_cfi_statusi_l2b0_finish                   ),  // O
    .i_gc_cr_l2_cfi_statusi_l2b1_finish             (gc_cr_l2_cfi_statusi_l2b1_finish                   ),  // O
    .i_gc_cr_l2g_idle_l2g                           (gc_cr_l2g_idle_l2g                                 ),  // O
    .i_gc_cr_l2g_error0_l2b0                        (gc_cr_l2g_error0_l2b0                              ),  // O
    .i_gc_cr_l2g_error0_l2b1                        (gc_cr_l2g_error0_l2b1                              ),  // O

    .o_gc_cr_l2_mem_sched_row_partii_row_id_bit8    (pipe_gc_cr_l2_mem_sched_row_partii_row_id_bit8     ),  // O
    .o_gc_cr_l2_mem_sched_row_partii_row_id_bit9    (pipe_gc_cr_l2_mem_sched_row_partii_row_id_bit9     ),  // O
    .o_gc_cr_l2_mem_sched_row_partii_row_id_bit10   (pipe_gc_cr_l2_mem_sched_row_partii_row_id_bit10    ),  // O
    .o_gc_cr_l2_mem_sched_row_partii_row_id_bit11   (pipe_gc_cr_l2_mem_sched_row_partii_row_id_bit11    ),  // O
    .o_gc_cr_l2_mem_sched_row_partii_row_id_bit12   (pipe_gc_cr_l2_mem_sched_row_partii_row_id_bit12    ),  // O
    .o_gc_cr_l2_mem_sched_row_partii_row_id_bit13   (pipe_gc_cr_l2_mem_sched_row_partii_row_id_bit13    ),  // O
    .o_gc_cr_l2_mem_sched_row_partii_row_id_bit14   (pipe_gc_cr_l2_mem_sched_row_partii_row_id_bit14    ),  // O
    .o_gc_cr_l2_mem_sched_row_partii_row_id_bit15   (pipe_gc_cr_l2_mem_sched_row_partii_row_id_bit15    ),  // O
    .o_gc_cr_l2_mem_sched_row_partiii_row_id_bit16  (pipe_gc_cr_l2_mem_sched_row_partiii_row_id_bit16   ),  // I
    .o_gc_cr_l2_mem_sched_row_partiii_row_id_bit17  (pipe_gc_cr_l2_mem_sched_row_partiii_row_id_bit17   ),  // I
    .o_gc_cr_l2_function_enable_ddr_capacity        (pipe_gc_cr_l2_function_enable_ddr_capacity         ),  // I
    .o_gc_cr_clk_ctrl3_l2g                          (pipe_gc_cr_clk_ctrl3_l2g                           ),  // O
    .o_gc_cr_l2_cfi_operation                       (pipe_gc_cr_l2_cfi_operation                        ),  // O
    .o_gc_cr_l2_buffer_mode_buffer_mode_percentage  (pipe_gc_cr_l2_buffer_mode_buffer_mode_percentage   ),  // O
    .o_gc_cr_l2_persistence_reduce_enable           (pipe_gc_cr_l2_persistence_reduce_enable            ),  // O
    .o_gc_cr_l2_persistence_reduce_threshold        (pipe_gc_cr_l2_persistence_reduce_threshold         ),  // O
    .o_gc_cr_l2_cmd_persistence_rst_all             (pipe_gc_cr_l2_cmd_persistence_rst_all              ),  // O
    .o_gc_cr_l2_cmd_cfi_clr                         (pipe_gc_cr_l2_cmd_cfi_clr                          ),  // O
    .o_gc_cr_l2_function_enable_mem_scheduler       (pipe_gc_cr_l2_function_enable_mem_scheduler        ),  // O
    .o_gc_cr_l2_function_enable_bypass_mode         (pipe_gc_cr_l2_function_enable_bypass_mode          ),  // O
    .o_gc_cr_l2_mem_sched_col_offset_column_id_bit0 (pipe_gc_cr_l2_mem_sched_col_offset_column_id_bit0  ),  // O
    .o_gc_cr_l2_mem_sched_col_offset_column_id_bit1 (pipe_gc_cr_l2_mem_sched_col_offset_column_id_bit1  ),  // O
    .o_gc_cr_l2_mem_sched_col_offset_column_id_bit2 (pipe_gc_cr_l2_mem_sched_col_offset_column_id_bit2  ),  // O
    .o_gc_cr_l2_mem_sched_col_offset_column_id_bit3 (pipe_gc_cr_l2_mem_sched_col_offset_column_id_bit3  ),  // O
    .o_gc_cr_l2_mem_sched_col_offset_column_id_bit4 (pipe_gc_cr_l2_mem_sched_col_offset_column_id_bit4  ),  // O
    .o_gc_cr_l2_mem_sched_col_offset_column_id_bit5 (pipe_gc_cr_l2_mem_sched_col_offset_column_id_bit5  ),  // O
    .o_gc_cr_l2_mem_sched_bank_offset_bank_id_bit0  (pipe_gc_cr_l2_mem_sched_bank_offset_bank_id_bit0   ),  // O
    .o_gc_cr_l2_mem_sched_bank_offset_bank_id_bit1  (pipe_gc_cr_l2_mem_sched_bank_offset_bank_id_bit1   ),  // O
    .o_gc_cr_l2_mem_sched_bank_offset_bank_id_bit2  (pipe_gc_cr_l2_mem_sched_bank_offset_bank_id_bit2   ),  // O
    .o_gc_cr_l2_mem_sched_bank_offset_bank_id_bit3  (pipe_gc_cr_l2_mem_sched_bank_offset_bank_id_bit3   ),  // O
    .o_gc_cr_l2_mem_sched_bank_offset_bank_id_bit4  (pipe_gc_cr_l2_mem_sched_bank_offset_bank_id_bit4   ),  // O
    .o_gc_cr_l2_mem_sched_row_parti_row_id_bit0     (pipe_gc_cr_l2_mem_sched_row_parti_row_id_bit0      ),  // O
    .o_gc_cr_l2_mem_sched_row_parti_row_id_bit1     (pipe_gc_cr_l2_mem_sched_row_parti_row_id_bit1      ),  // O
    .o_gc_cr_l2_mem_sched_row_parti_row_id_bit2     (pipe_gc_cr_l2_mem_sched_row_parti_row_id_bit2      ),  // O
    .o_gc_cr_l2_mem_sched_row_parti_row_id_bit3     (pipe_gc_cr_l2_mem_sched_row_parti_row_id_bit3      ),  // O
    .o_gc_cr_l2_mem_sched_row_parti_row_id_bit4     (pipe_gc_cr_l2_mem_sched_row_parti_row_id_bit4      ),  // O
    .o_gc_cr_l2_mem_sched_row_parti_row_id_bit5     (pipe_gc_cr_l2_mem_sched_row_parti_row_id_bit5      ),  // O
    .o_gc_cr_l2_mem_sched_row_parti_row_id_bit6     (pipe_gc_cr_l2_mem_sched_row_parti_row_id_bit6      ),  // O
    .o_gc_cr_l2_mem_sched_row_parti_row_id_bit7     (pipe_gc_cr_l2_mem_sched_row_parti_row_id_bit7      ),  // O
    .o_gc_cr_pwr_man_hysteresis_value               (pipe_gc_cr_pwr_man_hysteresis_value                ),  // O
    .o_gc_cr_crm_reset_clk_ctrl                     (pipe_gc_cr_crm_reset_clk_ctrl                      ),  // O
    .o_gc_cr_cu_lms_fp32_denormal_en               (pipe_gc_cr_cu_lms_fp32_denormal_en                ),  // o
    .o_gc_cr_l2_cfi_operation_notify                (pipe_gc_cr_l2_cfi_operation_notify                 ),  // O
    .o_gc_cr_l2_cfi_operation_rdnotify              (pipe_gc_cr_l2_cfi_operation_rdnotify               ),  // O
    .o_gc_cr_l2_cmd_notify                          (pipe_gc_cr_l2_cmd_notify                           ),  // O
    .o_gc_cr_l2_cmd_rdnotify                        (pipe_gc_cr_l2_cmd_rdnotify                         ),  // O
    .o_gc_cr_clk_status3_l2g                        (pipe_gc_cr_clk_status3_l2g                         ),  // I
    .o_gc_cr_l2_cfi_statusi_l2b0_finish             (pipe_gc_cr_l2_cfi_statusi_l2b0_finish              ),  // I
    .o_gc_cr_l2_cfi_statusi_l2b1_finish             (pipe_gc_cr_l2_cfi_statusi_l2b1_finish              ),  // I
    .o_gc_cr_l2g_idle_l2g                           (pipe_gc_cr_l2g_idle_l2g                            ),  // I
    .o_gc_cr_l2g_error0_l2b0                        (pipe_gc_cr_l2g_error0_l2b0                         ),  // I
    .o_gc_cr_l2g_error0_l2b1                        (pipe_gc_cr_l2g_error0_l2b1                         ),  // I
    .o_gc_cr_ddr_hash_config_reg0_row_id_bit0       (pipe_gc_cr_ddr_hash_config_reg0_row_id_bit0        ),  // O
    .o_gc_cr_ddr_hash_config_reg0_row_id_bit1       (pipe_gc_cr_ddr_hash_config_reg0_row_id_bit1        ),  // O
    .o_gc_cr_ddr_hash_config_reg0_row_id_bit2       (pipe_gc_cr_ddr_hash_config_reg0_row_id_bit2        ),  // O
    .o_gc_cr_ddr_hash_config_reg0_row_id_bit3       (pipe_gc_cr_ddr_hash_config_reg0_row_id_bit3        ),  // O
    .o_gc_cr_ddr_hash_config_reg0_row_id_bit4       (pipe_gc_cr_ddr_hash_config_reg0_row_id_bit4        ),  // O
    .o_gc_cr_ddr_hash_config_reg0_row_id_bit5       (pipe_gc_cr_ddr_hash_config_reg0_row_id_bit5        ),  // O
    .o_gc_cr_ddr_hash_config_reg0_row_id_bit6       (pipe_gc_cr_ddr_hash_config_reg0_row_id_bit6        ),  // O
    .o_gc_cr_ddr_hash_config_reg0_row_id_bit7       (pipe_gc_cr_ddr_hash_config_reg0_row_id_bit7        ),  // O
    .o_gc_cr_ddr_hash_config_reg0_row_id_bit8       (pipe_gc_cr_ddr_hash_config_reg0_row_id_bit8        ),  // O
    .o_gc_cr_ddr_hash_config_reg0_row_id_bit9       (pipe_gc_cr_ddr_hash_config_reg0_row_id_bit9        ),  // O
    .o_gc_cr_ddr_hash_config_reg0_row_id_bit10      (pipe_gc_cr_ddr_hash_config_reg0_row_id_bit10       ),  // O
    .o_gc_cr_ddr_hash_config_reg0_row_id_bit11      (pipe_gc_cr_ddr_hash_config_reg0_row_id_bit11       ),  // O
    .o_gc_cr_ddr_hash_config_reg1_row_id_bit12      (pipe_gc_cr_ddr_hash_config_reg1_row_id_bit12       ),  // O
    .o_gc_cr_ddr_hash_config_reg1_row_id_bit13      (pipe_gc_cr_ddr_hash_config_reg1_row_id_bit13       ),  // O
    .o_gc_cr_ddr_hash_config_reg1_row_id_bit14      (pipe_gc_cr_ddr_hash_config_reg1_row_id_bit14       ),  // O
    .o_gc_cr_ddr_hash_config_reg1_row_id_bit15      (pipe_gc_cr_ddr_hash_config_reg1_row_id_bit15       ),  // O
    .o_gc_cr_ddr_hash_config_reg1_row_id_bit16      (pipe_gc_cr_ddr_hash_config_reg1_row_id_bit16       ),  // O
    .o_gc_cr_ddr_hash_config_reg1_row_id_bit17      (pipe_gc_cr_ddr_hash_config_reg1_row_id_bit17       ),  // O
    .o_gc_cr_ddr_hash_config_reg1_row_id_bit18      (pipe_gc_cr_ddr_hash_config_reg1_row_id_bit18       ),  // O
    .o_gc_cr_ddr_hash_config_reg1_row_id_bit19      (pipe_gc_cr_ddr_hash_config_reg1_row_id_bit19       ),  // O
    .o_gc_cr_ddr_hash_config_reg1_row_id_bit20      (pipe_gc_cr_ddr_hash_config_reg1_row_id_bit20       ),  // O
    .o_gc_cr_ddr_hash_config_reg1_row_id_bit21      (pipe_gc_cr_ddr_hash_config_reg1_row_id_bit21       ),  // O
    .o_gc_cr_ddr_hash_config_reg1_row_id_bit22      (pipe_gc_cr_ddr_hash_config_reg1_row_id_bit22       ),  // O
    .o_gc_cr_ddr_hash_config_reg1_row_id_bit23      (pipe_gc_cr_ddr_hash_config_reg1_row_id_bit23       ),  // O
    .o_gc_cr_l2_function_enable_hash_mode           (pipe_gc_cr_l2_function_enable_hash_mode            ),  // O

    // performance counter
    .i_l2b0_busy                                    (pipe_l2b0_busy                                     ),  // I
    .i_l2b0_fromaxi_ar_wl                           (pipe_l2b0_fromaxi_ar_wl                            ),  // I
    .i_l2b0_fromaxi_ar_bl_eq0_wl                    (pipe_l2b0_fromaxi_ar_bl_eq0_wl                     ),  // I
    .i_l2b0_fromaxi_ar_bl_eq1_wl                    (pipe_l2b0_fromaxi_ar_bl_eq1_wl                     ),  // I
    .i_l2b0_fromaxi_ar_bl_eq2_wl                    (pipe_l2b0_fromaxi_ar_bl_eq2_wl                     ),  // I
    .i_l2b0_fromaxi_ar_bl_eq3_wl                    (pipe_l2b0_fromaxi_ar_bl_eq3_wl                     ),  // I
    .i_l2b0_fromaxi_ar_bp                           (pipe_l2b0_fromaxi_ar_bp                            ),  // I
    .i_l2b0_toaxi_r_wl                              (pipe_l2b0_toaxi_r_wl                               ),  // I
    .i_l2b0_toaxi_r_bp                              (pipe_l2b0_toaxi_r_bp                               ),  // I
    .i_l2b0_fromaxi_aw_wl                           (pipe_l2b0_fromaxi_aw_wl                            ),  // I
    .i_l2b0_fromaxi_aw_bl_eq0_wl                    (pipe_l2b0_fromaxi_aw_bl_eq0_wl                     ),  // I
    .i_l2b0_fromaxi_aw_bl_eq1_wl                    (pipe_l2b0_fromaxi_aw_bl_eq1_wl                     ),  // I
    .i_l2b0_fromaxi_aw_bl_eq2_wl                    (pipe_l2b0_fromaxi_aw_bl_eq2_wl                     ),  // I
    .i_l2b0_fromaxi_aw_bl_eq3_wl                    (pipe_l2b0_fromaxi_aw_bl_eq3_wl                     ),  // I
    .i_l2b0_fromaxi_aw_bp                           (pipe_l2b0_fromaxi_aw_bp                            ),  // I
    .i_l2b0_fromaxi_w_wl                            (pipe_l2b0_fromaxi_w_wl                             ),  // I
    .i_l2b0_fromaxi_w_bp                            (pipe_l2b0_fromaxi_w_bp                             ),  // I
    .i_l2b0_fromaxi_smp_read_req_num                (pipe_l2b0_fromaxi_smp_read_req_num                 ),  // I
    .i_l2b0_fromaxi_smp_read_req_sum                (pipe_l2b0_fromaxi_smp_read_req_sum                 ),  // I
    .i_l2b0_fromaxi_smp_write_req_num               (pipe_l2b0_fromaxi_smp_write_req_num                ),  // I
    .i_l2b0_fromaxi_smp_write_req_sum               (pipe_l2b0_fromaxi_smp_write_req_sum                ),  // I
    .i_l2b0_fromaxi_smp_atomic_req_num              (pipe_l2b0_fromaxi_smp_atomic_req_num               ),  // I
    .i_l2b0_fromaxi_smp_atomic_req_sum              (pipe_l2b0_fromaxi_smp_atomic_req_sum               ),  // I
    .i_l2b0_align_awdb_full                         (pipe_l2b0_align_awdb_full                          ),  // I
    .i_l2b0_hittest_ht_bypass_read_wl               (pipe_l2b0_hittest_ht_bypass_read_wl                ),  // I
    .i_l2b0_hittest_ht_cache_read_wl                (pipe_l2b0_hittest_ht_cache_read_wl                 ),  // I
    .i_l2b0_hittest_ht_bypass_write_wl              (pipe_l2b0_hittest_ht_bypass_write_wl               ),  // I
    .i_l2b0_hittest_ht_cache_write_wl               (pipe_l2b0_hittest_ht_cache_write_wl                ),  // I
    .i_l2b0_hittest_ht_atomic_wl                    (pipe_l2b0_hittest_ht_atomic_wl                     ),  // I
    .i_l2b0_hittest_ht_bps_hit_wl                   (pipe_l2b0_hittest_ht_bps_hit_wl                    ),  // I
    .i_l2b0_hittest_ht_miss_wl                      (pipe_l2b0_hittest_ht_miss_wl                       ),  // I
    .i_l2b0_frommemsch_nsp_rtn_wl                   (pipe_l2b0_frommemsch_nsp_rtn_wl                    ),  // I
    .i_l2b0_frommemsch_nsp_rtn_bp                   (pipe_l2b0_frommemsch_nsp_rtn_bp                    ),  // I
    .i_l2b0_tomemsch_nsp_read_bl_eq1_wl             (pipe_l2b0_tomemsch_nsp_read_bl_eq1_wl              ),  // I
    .i_l2b0_tomemsch_nsp_read_bl_eq3_wl             (pipe_l2b0_tomemsch_nsp_read_bl_eq3_wl              ),  // I
    .i_l2b0_tomemsch_nsp_read_bl_eq5_wl             (pipe_l2b0_tomemsch_nsp_read_bl_eq5_wl              ),  // I
    .i_l2b0_tomemsch_nsp_read_bl_eq7_wl             (pipe_l2b0_tomemsch_nsp_read_bl_eq7_wl              ),  // I
    .i_l2b0_tomemsch_nsp_write_bl_eq1_wl            (pipe_l2b0_tomemsch_nsp_write_bl_eq1_wl             ),  // I
    .i_l2b0_tomemsch_nsp_write_bl_eq3_wl            (pipe_l2b0_tomemsch_nsp_write_bl_eq3_wl             ),  // I
    .i_l2b0_tomemsch_nsp_write_bl_eq5_wl            (pipe_l2b0_tomemsch_nsp_write_bl_eq5_wl             ),  // I
    .i_l2b0_tomemsch_nsp_write_bl_eq7_wl            (pipe_l2b0_tomemsch_nsp_write_bl_eq7_wl             ),  // I
    .i_l2b0_memif_to_ddr_read_wl                    (pipe_l2b0_memif_to_ddr_read_wl                     ),  // I
    .i_l2b0_memif_to_ddr_read_stall_by_rob          (pipe_l2b0_memif_to_ddr_read_stall_by_rob           ),  // I
    .i_l2b0_memif_to_ddr_read_stall_by_ddr          (pipe_l2b0_memif_to_ddr_read_stall_by_ddr           ),  // I
    .i_l2b0_memif_to_ddr_read_stall_by_trid         (pipe_l2b0_memif_to_ddr_read_stall_by_trid          ),  // I
    .i_l2b0_memif_to_ddr_write_wl                   (pipe_l2b0_memif_to_ddr_write_wl                    ),  // I
    .i_l2b0_memif_to_ddr_write_stall_by_data_sync   (pipe_l2b0_memif_to_ddr_write_stall_by_data_sync    ),  // I
    .i_l2b0_memif_to_ddr_write_stall_by_ddr         (pipe_l2b0_memif_to_ddr_write_stall_by_ddr          ),  // I
    .i_l2b0_memif_to_ddr_write_stall_by_trid        (pipe_l2b0_memif_to_ddr_write_stall_by_trid         ),  // I
    .i_l2b0_memif_memreq_full                       (pipe_l2b0_memif_memreq_full                        ),  // I
    .i_l2b0_memif_smp_read_req_num                  (pipe_l2b0_memif_smp_read_req_num                   ),  // I
    .i_l2b0_memif_smp_read_req_sum                  (pipe_l2b0_memif_smp_read_req_sum                   ),  // I
    .i_l2b0_reqsch_sortq_full                       (pipe_l2b0_reqsch_sortq_full                        ),  // I
    .i_l2b0_reqsch_sortq_stall_but_not_full         (pipe_l2b0_reqsch_sortq_stall_but_not_full          ),  // I
    .i_l2b0_reqsch_disp_wl                          (pipe_l2b0_reqsch_disp_wl                           ),  // I
    .i_l2b0_reqsch_disp_stall                       (pipe_l2b0_reqsch_disp_stall                        ),  // I
    .i_l2b0_ramctrl_0_reqarb_wl                     (pipe_l2b0_ramctrl_0_reqarb_wl                      ),  // I
    .i_l2b0_ramctrl_0_reqarb_stall_by_sram          (pipe_l2b0_ramctrl_0_reqarb_stall_by_sram           ),  // I
    .i_l2b0_ramctrl_0_data_sram_read_wl             (pipe_l2b0_ramctrl_0_data_sram_read_wl              ),  // I
    .i_l2b0_ramctrl_0_data_sram_write_wl            (pipe_l2b0_ramctrl_0_data_sram_write_wl             ),  // I
    .i_l2b0_ramctrl_1_reqarb_wl                     (pipe_l2b0_ramctrl_1_reqarb_wl                      ),  // I
    .i_l2b0_ramctrl_1_reqarb_stall_by_sram          (pipe_l2b0_ramctrl_1_reqarb_stall_by_sram           ),  // I
    .i_l2b0_ramctrl_1_data_sram_read_wl             (pipe_l2b0_ramctrl_1_data_sram_read_wl              ),  // I
    .i_l2b0_ramctrl_1_data_sram_write_wl            (pipe_l2b0_ramctrl_1_data_sram_write_wl             ),  // I

    .o_l2b0_busy                                    (l2b0_busy                                          ),  // O
    .o_l2b0_fromaxi_ar_wl                           (l2b0_fromaxi_ar_wl                                 ),  // O
    .o_l2b0_fromaxi_ar_bl_eq0_wl                    (l2b0_fromaxi_ar_bl_eq0_wl                          ),  // O
    .o_l2b0_fromaxi_ar_bl_eq1_wl                    (l2b0_fromaxi_ar_bl_eq1_wl                          ),  // O
    .o_l2b0_fromaxi_ar_bl_eq2_wl                    (l2b0_fromaxi_ar_bl_eq2_wl                          ),  // O
    .o_l2b0_fromaxi_ar_bl_eq3_wl                    (l2b0_fromaxi_ar_bl_eq3_wl                          ),  // O
    .o_l2b0_fromaxi_ar_bp                           (l2b0_fromaxi_ar_bp                                 ),  // O
    .o_l2b0_toaxi_r_wl                              (l2b0_toaxi_r_wl                                    ),  // O
    .o_l2b0_toaxi_r_bp                              (l2b0_toaxi_r_bp                                    ),  // O
    .o_l2b0_fromaxi_aw_wl                           (l2b0_fromaxi_aw_wl                                 ),  // O
    .o_l2b0_fromaxi_aw_bl_eq0_wl                    (l2b0_fromaxi_aw_bl_eq0_wl                          ),  // O
    .o_l2b0_fromaxi_aw_bl_eq1_wl                    (l2b0_fromaxi_aw_bl_eq1_wl                          ),  // O
    .o_l2b0_fromaxi_aw_bl_eq2_wl                    (l2b0_fromaxi_aw_bl_eq2_wl                          ),  // O
    .o_l2b0_fromaxi_aw_bl_eq3_wl                    (l2b0_fromaxi_aw_bl_eq3_wl                          ),  // O
    .o_l2b0_fromaxi_aw_bp                           (l2b0_fromaxi_aw_bp                                 ),  // O
    .o_l2b0_fromaxi_w_wl                            (l2b0_fromaxi_w_wl                                  ),  // O
    .o_l2b0_fromaxi_w_bp                            (l2b0_fromaxi_w_bp                                  ),  // O
    .o_l2b0_fromaxi_smp_read_req_num                (l2b0_fromaxi_smp_read_req_num                      ),  // O
    .o_l2b0_fromaxi_smp_read_req_sum                (l2b0_fromaxi_smp_read_req_sum                      ),  // O
    .o_l2b0_fromaxi_smp_write_req_num               (l2b0_fromaxi_smp_write_req_num                     ),  // O
    .o_l2b0_fromaxi_smp_write_req_sum               (l2b0_fromaxi_smp_write_req_sum                     ),  // O
    .o_l2b0_fromaxi_smp_atomic_req_num              (l2b0_fromaxi_smp_atomic_req_num                    ),  // O
    .o_l2b0_fromaxi_smp_atomic_req_sum              (l2b0_fromaxi_smp_atomic_req_sum                    ),  // O
    .o_l2b0_align_awdb_full                         (l2b0_align_awdb_full                               ),  // O
    .o_l2b0_hittest_ht_bypass_read_wl               (l2b0_hittest_ht_bypass_read_wl                     ),  // O
    .o_l2b0_hittest_ht_cache_read_wl                (l2b0_hittest_ht_cache_read_wl                      ),  // O
    .o_l2b0_hittest_ht_bypass_write_wl              (l2b0_hittest_ht_bypass_write_wl                    ),  // O
    .o_l2b0_hittest_ht_cache_write_wl               (l2b0_hittest_ht_cache_write_wl                     ),  // O
    .o_l2b0_hittest_ht_atomic_wl                    (l2b0_hittest_ht_atomic_wl                          ),  // O
    .o_l2b0_hittest_ht_bps_hit_wl                   (l2b0_hittest_ht_bps_hit_wl                         ),  // O
    .o_l2b0_hittest_ht_miss_wl                      (l2b0_hittest_ht_miss_wl                            ),  // O
    .o_l2b0_frommemsch_nsp_rtn_wl                   (l2b0_frommemsch_nsp_rtn_wl                         ),  // O
    .o_l2b0_frommemsch_nsp_rtn_bp                   (l2b0_frommemsch_nsp_rtn_bp                         ),  // O
    .o_l2b0_tomemsch_nsp_read_bl_eq1_wl             (l2b0_tomemsch_nsp_read_bl_eq1_wl                   ),  // O
    .o_l2b0_tomemsch_nsp_read_bl_eq3_wl             (l2b0_tomemsch_nsp_read_bl_eq3_wl                   ),  // O
    .o_l2b0_tomemsch_nsp_read_bl_eq5_wl             (l2b0_tomemsch_nsp_read_bl_eq5_wl                   ),  // O
    .o_l2b0_tomemsch_nsp_read_bl_eq7_wl             (l2b0_tomemsch_nsp_read_bl_eq7_wl                   ),  // O
    .o_l2b0_tomemsch_nsp_write_bl_eq1_wl            (l2b0_tomemsch_nsp_write_bl_eq1_wl                  ),  // O
    .o_l2b0_tomemsch_nsp_write_bl_eq3_wl            (l2b0_tomemsch_nsp_write_bl_eq3_wl                  ),  // O
    .o_l2b0_tomemsch_nsp_write_bl_eq5_wl            (l2b0_tomemsch_nsp_write_bl_eq5_wl                  ),  // O
    .o_l2b0_tomemsch_nsp_write_bl_eq7_wl            (l2b0_tomemsch_nsp_write_bl_eq7_wl                  ),  // O
    .o_l2b0_memif_to_ddr_read_wl                    (l2b0_memif_to_ddr_read_wl                          ),  // O
    .o_l2b0_memif_to_ddr_read_stall_by_rob          (l2b0_memif_to_ddr_read_stall_by_rob                ),  // O
    .o_l2b0_memif_to_ddr_read_stall_by_ddr          (l2b0_memif_to_ddr_read_stall_by_ddr                ),  // O
    .o_l2b0_memif_to_ddr_read_stall_by_trid         (l2b0_memif_to_ddr_read_stall_by_trid               ),  // O
    .o_l2b0_memif_to_ddr_write_wl                   (l2b0_memif_to_ddr_write_wl                         ),  // O
    .o_l2b0_memif_to_ddr_write_stall_by_data_sync   (l2b0_memif_to_ddr_write_stall_by_data_sync         ),  // O
    .o_l2b0_memif_to_ddr_write_stall_by_ddr         (l2b0_memif_to_ddr_write_stall_by_ddr               ),  // O
    .o_l2b0_memif_to_ddr_write_stall_by_trid        (l2b0_memif_to_ddr_write_stall_by_trid              ),  // O
    .o_l2b0_memif_memreq_full                       (l2b0_memif_memreq_full                             ),  // O
    .o_l2b0_memif_smp_read_req_num                  (l2b0_memif_smp_read_req_num                        ),  // O
    .o_l2b0_memif_smp_read_req_sum                  (l2b0_memif_smp_read_req_sum                        ),  // O
    .o_l2b0_reqsch_sortq_full                       (l2b0_reqsch_sortq_full                             ),  // O
    .o_l2b0_reqsch_sortq_stall_but_not_full         (l2b0_reqsch_sortq_stall_but_not_full               ),  // O
    .o_l2b0_reqsch_disp_wl                          (l2b0_reqsch_disp_wl                                ),  // O
    .o_l2b0_reqsch_disp_stall                       (l2b0_reqsch_disp_stall                             ),  // O
    .o_l2b0_ramctrl_0_reqarb_wl                     (l2b0_ramctrl_0_reqarb_wl                           ),  // O
    .o_l2b0_ramctrl_0_reqarb_stall_by_sram          (l2b0_ramctrl_0_reqarb_stall_by_sram                ),  // O
    .o_l2b0_ramctrl_0_data_sram_read_wl             (l2b0_ramctrl_0_data_sram_read_wl                   ),  // O
    .o_l2b0_ramctrl_0_data_sram_write_wl            (l2b0_ramctrl_0_data_sram_write_wl                  ),  // O
    .o_l2b0_ramctrl_1_reqarb_wl                     (l2b0_ramctrl_1_reqarb_wl                           ),  // O
    .o_l2b0_ramctrl_1_reqarb_stall_by_sram          (l2b0_ramctrl_1_reqarb_stall_by_sram                ),  // O
    .o_l2b0_ramctrl_1_data_sram_read_wl             (l2b0_ramctrl_1_data_sram_read_wl                   ),  // O
    .o_l2b0_ramctrl_1_data_sram_write_wl            (l2b0_ramctrl_1_data_sram_write_wl                  ),  // O

    .i_l2b1_busy                                    (pipe_l2b1_busy                                     ),  // I
    .i_l2b1_fromaxi_ar_wl                           (pipe_l2b1_fromaxi_ar_wl                            ),  // I
    .i_l2b1_fromaxi_ar_bl_eq0_wl                    (pipe_l2b1_fromaxi_ar_bl_eq0_wl                     ),  // I
    .i_l2b1_fromaxi_ar_bl_eq1_wl                    (pipe_l2b1_fromaxi_ar_bl_eq1_wl                     ),  // I
    .i_l2b1_fromaxi_ar_bl_eq2_wl                    (pipe_l2b1_fromaxi_ar_bl_eq2_wl                     ),  // I
    .i_l2b1_fromaxi_ar_bl_eq3_wl                    (pipe_l2b1_fromaxi_ar_bl_eq3_wl                     ),  // I
    .i_l2b1_fromaxi_ar_bp                           (pipe_l2b1_fromaxi_ar_bp                            ),  // I
    .i_l2b1_toaxi_r_wl                              (pipe_l2b1_toaxi_r_wl                               ),  // I
    .i_l2b1_toaxi_r_bp                              (pipe_l2b1_toaxi_r_bp                               ),  // I
    .i_l2b1_fromaxi_aw_wl                           (pipe_l2b1_fromaxi_aw_wl                            ),  // I
    .i_l2b1_fromaxi_aw_bl_eq0_wl                    (pipe_l2b1_fromaxi_aw_bl_eq0_wl                     ),  // I
    .i_l2b1_fromaxi_aw_bl_eq1_wl                    (pipe_l2b1_fromaxi_aw_bl_eq1_wl                     ),  // I
    .i_l2b1_fromaxi_aw_bl_eq2_wl                    (pipe_l2b1_fromaxi_aw_bl_eq2_wl                     ),  // I
    .i_l2b1_fromaxi_aw_bl_eq3_wl                    (pipe_l2b1_fromaxi_aw_bl_eq3_wl                     ),  // I
    .i_l2b1_fromaxi_aw_bp                           (pipe_l2b1_fromaxi_aw_bp                            ),  // I
    .i_l2b1_fromaxi_w_wl                            (pipe_l2b1_fromaxi_w_wl                             ),  // I
    .i_l2b1_fromaxi_w_bp                            (pipe_l2b1_fromaxi_w_bp                             ),  // I
    .i_l2b1_fromaxi_smp_read_req_num                (pipe_l2b1_fromaxi_smp_read_req_num                 ),  // I
    .i_l2b1_fromaxi_smp_read_req_sum                (pipe_l2b1_fromaxi_smp_read_req_sum                 ),  // I
    .i_l2b1_fromaxi_smp_write_req_num               (pipe_l2b1_fromaxi_smp_write_req_num                ),  // I
    .i_l2b1_fromaxi_smp_write_req_sum               (pipe_l2b1_fromaxi_smp_write_req_sum                ),  // I
    .i_l2b1_fromaxi_smp_atomic_req_num              (pipe_l2b1_fromaxi_smp_atomic_req_num               ),  // I
    .i_l2b1_fromaxi_smp_atomic_req_sum              (pipe_l2b1_fromaxi_smp_atomic_req_sum               ),  // I
    .i_l2b1_align_awdb_full                         (pipe_l2b1_align_awdb_full                          ),  // I
    .i_l2b1_hittest_ht_bypass_read_wl               (pipe_l2b1_hittest_ht_bypass_read_wl                ),  // I
    .i_l2b1_hittest_ht_cache_read_wl                (pipe_l2b1_hittest_ht_cache_read_wl                 ),  // I
    .i_l2b1_hittest_ht_bypass_write_wl              (pipe_l2b1_hittest_ht_bypass_write_wl               ),  // I
    .i_l2b1_hittest_ht_cache_write_wl               (pipe_l2b1_hittest_ht_cache_write_wl                ),  // I
    .i_l2b1_hittest_ht_atomic_wl                    (pipe_l2b1_hittest_ht_atomic_wl                     ),  // I
    .i_l2b1_hittest_ht_bps_hit_wl                   (pipe_l2b1_hittest_ht_bps_hit_wl                    ),  // I
    .i_l2b1_hittest_ht_miss_wl                      (pipe_l2b1_hittest_ht_miss_wl                       ),  // I
    .i_l2b1_frommemsch_nsp_rtn_wl                   (pipe_l2b1_frommemsch_nsp_rtn_wl                    ),  // I
    .i_l2b1_frommemsch_nsp_rtn_bp                   (pipe_l2b1_frommemsch_nsp_rtn_bp                    ),  // I
    .i_l2b1_tomemsch_nsp_read_bl_eq1_wl             (pipe_l2b1_tomemsch_nsp_read_bl_eq1_wl              ),  // I
    .i_l2b1_tomemsch_nsp_read_bl_eq3_wl             (pipe_l2b1_tomemsch_nsp_read_bl_eq3_wl              ),  // I
    .i_l2b1_tomemsch_nsp_read_bl_eq5_wl             (pipe_l2b1_tomemsch_nsp_read_bl_eq5_wl              ),  // I
    .i_l2b1_tomemsch_nsp_read_bl_eq7_wl             (pipe_l2b1_tomemsch_nsp_read_bl_eq7_wl              ),  // I
    .i_l2b1_tomemsch_nsp_write_bl_eq1_wl            (pipe_l2b1_tomemsch_nsp_write_bl_eq1_wl             ),  // I
    .i_l2b1_tomemsch_nsp_write_bl_eq3_wl            (pipe_l2b1_tomemsch_nsp_write_bl_eq3_wl             ),  // I
    .i_l2b1_tomemsch_nsp_write_bl_eq5_wl            (pipe_l2b1_tomemsch_nsp_write_bl_eq5_wl             ),  // I
    .i_l2b1_tomemsch_nsp_write_bl_eq7_wl            (pipe_l2b1_tomemsch_nsp_write_bl_eq7_wl             ),  // I
    .i_l2b1_memif_to_ddr_read_wl                    (pipe_l2b1_memif_to_ddr_read_wl                     ),  // I
    .i_l2b1_memif_to_ddr_read_stall_by_rob          (pipe_l2b1_memif_to_ddr_read_stall_by_rob           ),  // I
    .i_l2b1_memif_to_ddr_read_stall_by_ddr          (pipe_l2b1_memif_to_ddr_read_stall_by_ddr           ),  // I
    .i_l2b1_memif_to_ddr_read_stall_by_trid         (pipe_l2b1_memif_to_ddr_read_stall_by_trid          ),  // I
    .i_l2b1_memif_to_ddr_write_wl                   (pipe_l2b1_memif_to_ddr_write_wl                    ),  // I
    .i_l2b1_memif_to_ddr_write_stall_by_data_sync   (pipe_l2b1_memif_to_ddr_write_stall_by_data_sync    ),  // I
    .i_l2b1_memif_to_ddr_write_stall_by_ddr         (pipe_l2b1_memif_to_ddr_write_stall_by_ddr          ),  // I
    .i_l2b1_memif_to_ddr_write_stall_by_trid        (pipe_l2b1_memif_to_ddr_write_stall_by_trid         ),  // I
    .i_l2b1_memif_memreq_full                       (pipe_l2b1_memif_memreq_full                        ),  // I
    .i_l2b1_memif_smp_read_req_num                  (pipe_l2b1_memif_smp_read_req_num                   ),  // I
    .i_l2b1_memif_smp_read_req_sum                  (pipe_l2b1_memif_smp_read_req_sum                   ),  // I
    .i_l2b1_reqsch_sortq_full                       (pipe_l2b1_reqsch_sortq_full                        ),  // I
    .i_l2b1_reqsch_sortq_stall_but_not_full         (pipe_l2b1_reqsch_sortq_stall_but_not_full          ),  // I
    .i_l2b1_reqsch_disp_wl                          (pipe_l2b1_reqsch_disp_wl                           ),  // I
    .i_l2b1_reqsch_disp_stall                       (pipe_l2b1_reqsch_disp_stall                        ),  // I
    .i_l2b1_ramctrl_0_reqarb_wl                     (pipe_l2b1_ramctrl_0_reqarb_wl                      ),  // I
    .i_l2b1_ramctrl_0_reqarb_stall_by_sram          (pipe_l2b1_ramctrl_0_reqarb_stall_by_sram           ),  // I
    .i_l2b1_ramctrl_0_data_sram_read_wl             (pipe_l2b1_ramctrl_0_data_sram_read_wl              ),  // I
    .i_l2b1_ramctrl_0_data_sram_write_wl            (pipe_l2b1_ramctrl_0_data_sram_write_wl             ),  // I
    .i_l2b1_ramctrl_1_reqarb_wl                     (pipe_l2b1_ramctrl_1_reqarb_wl                      ),  // I
    .i_l2b1_ramctrl_1_reqarb_stall_by_sram          (pipe_l2b1_ramctrl_1_reqarb_stall_by_sram           ),  // I
    .i_l2b1_ramctrl_1_data_sram_read_wl             (pipe_l2b1_ramctrl_1_data_sram_read_wl              ),  // I
    .i_l2b1_ramctrl_1_data_sram_write_wl            (pipe_l2b1_ramctrl_1_data_sram_write_wl             ),  // I

    .o_l2b1_busy                                    (l2b1_busy                                          ),  // O
    .o_l2b1_fromaxi_ar_wl                           (l2b1_fromaxi_ar_wl                                 ),  // O
    .o_l2b1_fromaxi_ar_bl_eq0_wl                    (l2b1_fromaxi_ar_bl_eq0_wl                          ),  // O
    .o_l2b1_fromaxi_ar_bl_eq1_wl                    (l2b1_fromaxi_ar_bl_eq1_wl                          ),  // O
    .o_l2b1_fromaxi_ar_bl_eq2_wl                    (l2b1_fromaxi_ar_bl_eq2_wl                          ),  // O
    .o_l2b1_fromaxi_ar_bl_eq3_wl                    (l2b1_fromaxi_ar_bl_eq3_wl                          ),  // O
    .o_l2b1_fromaxi_ar_bp                           (l2b1_fromaxi_ar_bp                                 ),  // O
    .o_l2b1_toaxi_r_wl                              (l2b1_toaxi_r_wl                                    ),  // O
    .o_l2b1_toaxi_r_bp                              (l2b1_toaxi_r_bp                                    ),  // O
    .o_l2b1_fromaxi_aw_wl                           (l2b1_fromaxi_aw_wl                                 ),  // O
    .o_l2b1_fromaxi_aw_bl_eq0_wl                    (l2b1_fromaxi_aw_bl_eq0_wl                          ),  // O
    .o_l2b1_fromaxi_aw_bl_eq1_wl                    (l2b1_fromaxi_aw_bl_eq1_wl                          ),  // O
    .o_l2b1_fromaxi_aw_bl_eq2_wl                    (l2b1_fromaxi_aw_bl_eq2_wl                          ),  // O
    .o_l2b1_fromaxi_aw_bl_eq3_wl                    (l2b1_fromaxi_aw_bl_eq3_wl                          ),  // O
    .o_l2b1_fromaxi_aw_bp                           (l2b1_fromaxi_aw_bp                                 ),  // O
    .o_l2b1_fromaxi_w_wl                            (l2b1_fromaxi_w_wl                                  ),  // O
    .o_l2b1_fromaxi_w_bp                            (l2b1_fromaxi_w_bp                                  ),  // O
    .o_l2b1_fromaxi_smp_read_req_num                (l2b1_fromaxi_smp_read_req_num                      ),  // O
    .o_l2b1_fromaxi_smp_read_req_sum                (l2b1_fromaxi_smp_read_req_sum                      ),  // O
    .o_l2b1_fromaxi_smp_write_req_num               (l2b1_fromaxi_smp_write_req_num                     ),  // O
    .o_l2b1_fromaxi_smp_write_req_sum               (l2b1_fromaxi_smp_write_req_sum                     ),  // O
    .o_l2b1_fromaxi_smp_atomic_req_num              (l2b1_fromaxi_smp_atomic_req_num                    ),  // O
    .o_l2b1_fromaxi_smp_atomic_req_sum              (l2b1_fromaxi_smp_atomic_req_sum                    ),  // O
    .o_l2b1_align_awdb_full                         (l2b1_align_awdb_full                               ),  // O
    .o_l2b1_hittest_ht_bypass_read_wl               (l2b1_hittest_ht_bypass_read_wl                     ),  // O
    .o_l2b1_hittest_ht_cache_read_wl                (l2b1_hittest_ht_cache_read_wl                      ),  // O
    .o_l2b1_hittest_ht_bypass_write_wl              (l2b1_hittest_ht_bypass_write_wl                    ),  // O
    .o_l2b1_hittest_ht_cache_write_wl               (l2b1_hittest_ht_cache_write_wl                     ),  // O
    .o_l2b1_hittest_ht_atomic_wl                    (l2b1_hittest_ht_atomic_wl                          ),  // O
    .o_l2b1_hittest_ht_bps_hit_wl                   (l2b1_hittest_ht_bps_hit_wl                         ),  // O
    .o_l2b1_hittest_ht_miss_wl                      (l2b1_hittest_ht_miss_wl                            ),  // O
    .o_l2b1_frommemsch_nsp_rtn_wl                   (l2b1_frommemsch_nsp_rtn_wl                         ),  // O
    .o_l2b1_frommemsch_nsp_rtn_bp                   (l2b1_frommemsch_nsp_rtn_bp                         ),  // O
    .o_l2b1_tomemsch_nsp_read_bl_eq1_wl             (l2b1_tomemsch_nsp_read_bl_eq1_wl                   ),  // O
    .o_l2b1_tomemsch_nsp_read_bl_eq3_wl             (l2b1_tomemsch_nsp_read_bl_eq3_wl                   ),  // O
    .o_l2b1_tomemsch_nsp_read_bl_eq5_wl             (l2b1_tomemsch_nsp_read_bl_eq5_wl                   ),  // O
    .o_l2b1_tomemsch_nsp_read_bl_eq7_wl             (l2b1_tomemsch_nsp_read_bl_eq7_wl                   ),  // O
    .o_l2b1_tomemsch_nsp_write_bl_eq1_wl            (l2b1_tomemsch_nsp_write_bl_eq1_wl                  ),  // O
    .o_l2b1_tomemsch_nsp_write_bl_eq3_wl            (l2b1_tomemsch_nsp_write_bl_eq3_wl                  ),  // O
    .o_l2b1_tomemsch_nsp_write_bl_eq5_wl            (l2b1_tomemsch_nsp_write_bl_eq5_wl                  ),  // O
    .o_l2b1_tomemsch_nsp_write_bl_eq7_wl            (l2b1_tomemsch_nsp_write_bl_eq7_wl                  ),  // O
    .o_l2b1_memif_to_ddr_read_wl                    (l2b1_memif_to_ddr_read_wl                          ),  // O
    .o_l2b1_memif_to_ddr_read_stall_by_rob          (l2b1_memif_to_ddr_read_stall_by_rob                ),  // O
    .o_l2b1_memif_to_ddr_read_stall_by_ddr          (l2b1_memif_to_ddr_read_stall_by_ddr                ),  // O
    .o_l2b1_memif_to_ddr_read_stall_by_trid         (l2b1_memif_to_ddr_read_stall_by_trid               ),  // O
    .o_l2b1_memif_to_ddr_write_wl                   (l2b1_memif_to_ddr_write_wl                         ),  // O
    .o_l2b1_memif_to_ddr_write_stall_by_data_sync   (l2b1_memif_to_ddr_write_stall_by_data_sync         ),  // O
    .o_l2b1_memif_to_ddr_write_stall_by_ddr         (l2b1_memif_to_ddr_write_stall_by_ddr               ),  // O
    .o_l2b1_memif_to_ddr_write_stall_by_trid        (l2b1_memif_to_ddr_write_stall_by_trid              ),  // O
    .o_l2b1_memif_memreq_full                       (l2b1_memif_memreq_full                             ),  // O
    .o_l2b1_memif_smp_read_req_num                  (l2b1_memif_smp_read_req_num                        ),  // O
    .o_l2b1_memif_smp_read_req_sum                  (l2b1_memif_smp_read_req_sum                        ),  // O
    .o_l2b1_reqsch_sortq_full                       (l2b1_reqsch_sortq_full                             ),  // O
    .o_l2b1_reqsch_sortq_stall_but_not_full         (l2b1_reqsch_sortq_stall_but_not_full               ),  // O
    .o_l2b1_reqsch_disp_wl                          (l2b1_reqsch_disp_wl                                ),  // O
    .o_l2b1_reqsch_disp_stall                       (l2b1_reqsch_disp_stall                             ),  // O
    .o_l2b1_ramctrl_0_reqarb_wl                     (l2b1_ramctrl_0_reqarb_wl                           ),  // O
    .o_l2b1_ramctrl_0_reqarb_stall_by_sram          (l2b1_ramctrl_0_reqarb_stall_by_sram                ),  // O
    .o_l2b1_ramctrl_0_data_sram_read_wl             (l2b1_ramctrl_0_data_sram_read_wl                   ),  // O
    .o_l2b1_ramctrl_0_data_sram_write_wl            (l2b1_ramctrl_0_data_sram_write_wl                  ),  // O
    .o_l2b1_ramctrl_1_reqarb_wl                     (l2b1_ramctrl_1_reqarb_wl                           ),  // O
    .o_l2b1_ramctrl_1_reqarb_stall_by_sram          (l2b1_ramctrl_1_reqarb_stall_by_sram                ),  // O
    .o_l2b1_ramctrl_1_data_sram_read_wl             (l2b1_ramctrl_1_data_sram_read_wl                   ),  // O
    .o_l2b1_ramctrl_1_data_sram_write_wl            (l2b1_ramctrl_1_data_sram_write_wl                  ),  // O

    .clk                                            (crg_aligned_clk                                    ),  // I
    .resetn                                         (crg_aligned_resetn                                 )   // I
);


// ----------------------------------------------------------------------------------------------
// IPG instance
// ----------------------------------------------------------------------------------------------
gc_l2_bank_ipg i_gc_l2_bank_ipg (
    // AXI interface
    .pgi_axi_slv_0_arvalid      (pipe_axi_slv_0_arvalid     ),  // I
    .pgi_axi_slv_0_arready      (pipe_axi_slv_0_arready     ),  // O
    .pgi_axi_slv_0_ar_rec       (pipe_axi_slv_0_ar_rec      ),  // I
    .pgi_axi_slv_0_rvalid       (pipe_axi_slv_0_rvalid      ),  // O
    .pgi_axi_slv_0_rready       (pipe_axi_slv_0_rready      ),  // I
    .pgi_axi_slv_0_r_rec        (pipe_axi_slv_0_r_rec       ),  // O
    .pgi_axi_slv_0_awvalid      (pipe_axi_slv_0_awvalid     ),  // I
    .pgi_axi_slv_0_awready      (pipe_axi_slv_0_awready     ),  // O
    .pgi_axi_slv_0_aw_rec       (pipe_axi_slv_0_aw_rec      ),  // I
    .pgi_axi_slv_0_wvalid       (pipe_axi_slv_0_wvalid      ),  // I
    .pgi_axi_slv_0_wready       (pipe_axi_slv_0_wready      ),  // O
    .pgi_axi_slv_0_w_rec        (pipe_axi_slv_0_w_rec       ),  // I
    .pgi_axi_slv_0_bvalid       (pipe_axi_slv_0_bvalid      ),  // O
    .pgi_axi_slv_0_bready       (pipe_axi_slv_0_bready      ),  // I
    .pgi_axi_slv_0_b_rec        (pipe_axi_slv_0_b_rec       ),  // O

    .pgo_axi_slv_0_arvalid      (ipg_axi_slv_0_arvalid      ),  // O
    .pgo_axi_slv_0_arready      (ipg_axi_slv_0_arready      ),  // I
    .pgo_axi_slv_0_ar_rec       (ipg_axi_slv_0_ar_rec       ),  // O
    .pgo_axi_slv_0_rvalid       (ipg_axi_slv_0_rvalid       ),  // I
    .pgo_axi_slv_0_rready       (ipg_axi_slv_0_rready       ),  // O
    .pgo_axi_slv_0_r_rec        (ipg_axi_slv_0_r_rec        ),  // I
    .pgo_axi_slv_0_awvalid      (ipg_axi_slv_0_awvalid      ),  // O
    .pgo_axi_slv_0_awready      (ipg_axi_slv_0_awready      ),  // I
    .pgo_axi_slv_0_aw_rec       (ipg_axi_slv_0_aw_rec       ),  // O
    .pgo_axi_slv_0_wvalid       (ipg_axi_slv_0_wvalid       ),  // O
    .pgo_axi_slv_0_wready       (ipg_axi_slv_0_wready       ),  // I
    .pgo_axi_slv_0_w_rec        (ipg_axi_slv_0_w_rec        ),  // O
    .pgo_axi_slv_0_bvalid       (ipg_axi_slv_0_bvalid       ),  // I
    .pgo_axi_slv_0_bready       (ipg_axi_slv_0_bready       ),  // O
    .pgo_axi_slv_0_b_rec        (ipg_axi_slv_0_b_rec        ),  // I

    .pgi_axi_slv_1_arvalid      (pipe_axi_slv_1_arvalid     ),  // I
    .pgi_axi_slv_1_arready      (pipe_axi_slv_1_arready     ),  // O
    .pgi_axi_slv_1_ar_rec       (pipe_axi_slv_1_ar_rec      ),  // I
    .pgi_axi_slv_1_rvalid       (pipe_axi_slv_1_rvalid      ),  // O
    .pgi_axi_slv_1_rready       (pipe_axi_slv_1_rready      ),  // I
    .pgi_axi_slv_1_r_rec        (pipe_axi_slv_1_r_rec       ),  // O
    .pgi_axi_slv_1_awvalid      (pipe_axi_slv_1_awvalid     ),  // I
    .pgi_axi_slv_1_awready      (pipe_axi_slv_1_awready     ),  // O
    .pgi_axi_slv_1_aw_rec       (pipe_axi_slv_1_aw_rec      ),  // I
    .pgi_axi_slv_1_wvalid       (pipe_axi_slv_1_wvalid      ),  // I
    .pgi_axi_slv_1_wready       (pipe_axi_slv_1_wready      ),  // O
    .pgi_axi_slv_1_w_rec        (pipe_axi_slv_1_w_rec       ),  // I
    .pgi_axi_slv_1_bvalid       (pipe_axi_slv_1_bvalid      ),  // O
    .pgi_axi_slv_1_bready       (pipe_axi_slv_1_bready      ),  // I
    .pgi_axi_slv_1_b_rec        (pipe_axi_slv_1_b_rec       ),  // O

    .pgo_axi_slv_1_arvalid      (ipg_axi_slv_1_arvalid      ),  // O
    .pgo_axi_slv_1_arready      (ipg_axi_slv_1_arready      ),  // I
    .pgo_axi_slv_1_ar_rec       (ipg_axi_slv_1_ar_rec       ),  // O
    .pgo_axi_slv_1_rvalid       (ipg_axi_slv_1_rvalid       ),  // I
    .pgo_axi_slv_1_rready       (ipg_axi_slv_1_rready       ),  // O
    .pgo_axi_slv_1_r_rec        (ipg_axi_slv_1_r_rec        ),  // I
    .pgo_axi_slv_1_awvalid      (ipg_axi_slv_1_awvalid      ),  // O
    .pgo_axi_slv_1_awready      (ipg_axi_slv_1_awready      ),  // I
    .pgo_axi_slv_1_aw_rec       (ipg_axi_slv_1_aw_rec       ),  // O
    .pgo_axi_slv_1_wvalid       (ipg_axi_slv_1_wvalid       ),  // O
    .pgo_axi_slv_1_wready       (ipg_axi_slv_1_wready       ),  // I
    .pgo_axi_slv_1_w_rec        (ipg_axi_slv_1_w_rec        ),  // O
    .pgo_axi_slv_1_bvalid       (ipg_axi_slv_1_bvalid       ),  // I
    .pgo_axi_slv_1_bready       (ipg_axi_slv_1_bready       ),  // O
    .pgo_axi_slv_1_b_rec        (ipg_axi_slv_1_b_rec        ),  // I
    // NSP interface
    .pgi_nsp_req_valid          (ipg_nsp_req_valid          ),  // I
    .pgi_nsp_req_ready          (ipg_nsp_req_ready          ),  // O
    .pgi_nsp_req_rec            (ipg_nsp_req_rec            ),  // I
    .pgi_nsp_rsp_valid          (ipg_nsp_rsp_valid          ),  // O
    .pgi_nsp_rsp_ready          (ipg_nsp_rsp_ready          ),  // I
    .pgi_nsp_rsp_rec            (ipg_nsp_rsp_rec            ),  // O

    .pgo_nsp_req_valid          (pipe_nsp_req_valid         ),  // O
    .pgo_nsp_req_ready          (pipe_nsp_req_ready         ),  // I
    .pgo_nsp_req_rec            (pipe_nsp_req_rec           ),  // O
    .pgo_nsp_rsp_valid          (pipe_nsp_rsp_valid         ),  // I
    .pgo_nsp_rsp_ready          (pipe_nsp_rsp_ready         ),  // O
    .pgo_nsp_rsp_rec            (pipe_nsp_rsp_rec           ),  // I

    .l2_ipg_wakeup              (l2_ipg_wakeup              ),  // O
    .clk_status                 (pipe_gc_cr_clk_status3_l2g )   // I
);

// ----------------------------------------------------------------------------------------------
// l2_bank_0/1 instance
// ----------------------------------------------------------------------------------------------
gc_l2_bank i_gc_l2_bank0 (
    // global interface
    .clk                        (crm_out_clk                ),  // I
    .resetn                     (crm_out_resetn             ),  // I
    .l2_bank_idle               (l2_bank0_idle              ),  // O
    // AXI interface
    .axi_slv_arvalid            (ipg_axi_slv_0_arvalid      ),  // I
    .axi_slv_arready            (ipg_axi_slv_0_arready      ),  // O
    .axi_slv_ar_rec             (ipg_axi_slv_0_ar_rec       ),  // I
    .axi_slv_rvalid             (ipg_axi_slv_0_rvalid       ),  // O
    .axi_slv_rready             (ipg_axi_slv_0_rready       ),  // I
    .axi_slv_r_rec              (ipg_axi_slv_0_r_rec        ),  // O
    .axi_slv_awvalid            (ipg_axi_slv_0_awvalid      ),  // I
    .axi_slv_awready            (ipg_axi_slv_0_awready      ),  // O
    .axi_slv_aw_rec             (ipg_axi_slv_0_aw_rec       ),  // I
    .axi_slv_wvalid             (ipg_axi_slv_0_wvalid       ),  // I
    .axi_slv_wready             (ipg_axi_slv_0_wready       ),  // O
    .axi_slv_w_rec              (ipg_axi_slv_0_w_rec        ),  // I
    .axi_slv_bvalid             (ipg_axi_slv_0_bvalid       ),  // O
    .axi_slv_bready             (ipg_axi_slv_0_bready       ),  // I
    .axi_slv_b_rec              (ipg_axi_slv_0_b_rec        ),  // O
    // memory scheduler and NSP interface
    .memif_sched_valid          (bank0_memif_sched_valid    ),  // O
    .memif_sched_ready          (bank0_memif_sched_ready    ),  // I
    .memif_sched_rec            (bank0_memif_sched_rec      ),  // O
    .sched_memif_valid          (bank0_sched_memif_valid    ),  // I
    .sched_memif_ready          (bank0_sched_memif_ready    ),  // O
    .sched_memif_rec            (bank0_sched_memif_rec      ),  // I
    .nsp_req_valid              (bank0_nsp_req_valid        ),  // O
    .nsp_req_ready              (bank0_nsp_req_ready        ),  // I
    .nsp_req_rec                (bank0_nsp_req_rec          ),  // O
    .nsp_rsp_valid              (bank0_nsp_rsp_valid        ),  // I
    .nsp_rsp_ready              (bank0_nsp_rsp_ready        ),  // O
    .nsp_rsp_rec                (bank0_nsp_rsp_rec          ),  // I

    // configure register
    .gc_cr_l2_cmd_notify                            (pipe_gc_cr_l2_cmd_notify                           ),  // I
    .gc_cr_l2_cmd_persistence_rst_all               (pipe_gc_cr_l2_cmd_persistence_rst_all              ),  // I
    .gc_cr_l2_cmd_cfi_clr                           (pipe_gc_cr_l2_cmd_cfi_clr                          ),  // I
    .gc_cr_l2_cfi_operation_notify                  (pipe_gc_cr_l2_cfi_operation_notify                 ),  // I
    .gc_cr_l2_cfi_operation                         (pipe_gc_cr_l2_cfi_operation                        ),  // I
    .gc_cr_l2_buffer_mode_buffer_mode_percentage    (pipe_gc_cr_l2_buffer_mode_buffer_mode_percentage   ),  // I
    .gc_cr_l2g_error_l2b                            (pipe_gc_cr_l2g_error0_l2b0                         ),  // O
    .gc_cr_l2_cfi_statusi_l2b_finish                (pipe_gc_cr_l2_cfi_statusi_l2b0_finish              ),  // O
    .gc_cr_l2_persistence_reduce_enable             (pipe_gc_cr_l2_persistence_reduce_enable            ),  // I
    .gc_cr_l2_persistence_reduce_threshold          (pipe_gc_cr_l2_persistence_reduce_threshold         ),  // I
    .gc_cr_l2_function_enable_bypass_mode           (pipe_gc_cr_l2_function_enable_bypass_mode          ),  // I
    .gc_cr_cu_lms_fp32_denormal_en                 (pipe_gc_cr_cu_lms_fp32_denormal_en                ),  // I
    .gc_l2_mem_scheduler_enable                     (pipe_gc_cr_l2_function_enable_mem_scheduler        ),  // I 
    .gc_cr_l2_mem_sched_bank_offset_bank_id_bit0    (pipe_gc_cr_l2_mem_sched_bank_offset_bank_id_bit0   ),
    .gc_cr_l2_mem_sched_bank_offset_bank_id_bit1    (pipe_gc_cr_l2_mem_sched_bank_offset_bank_id_bit1   ),
    .gc_cr_l2_mem_sched_bank_offset_bank_id_bit2    (pipe_gc_cr_l2_mem_sched_bank_offset_bank_id_bit2   ),
    .gc_cr_l2_mem_sched_bank_offset_bank_id_bit3    (pipe_gc_cr_l2_mem_sched_bank_offset_bank_id_bit3   ),
    .gc_cr_l2_mem_sched_bank_offset_bank_id_bit4    (pipe_gc_cr_l2_mem_sched_bank_offset_bank_id_bit4   ),
    
    .gc_cr_l2_mem_sched_row_parti_row_id_bit0       (pipe_gc_cr_l2_mem_sched_row_parti_row_id_bit0     ),
    .gc_cr_l2_mem_sched_row_parti_row_id_bit1       (pipe_gc_cr_l2_mem_sched_row_parti_row_id_bit1     ),
    .gc_cr_l2_mem_sched_row_parti_row_id_bit2       (pipe_gc_cr_l2_mem_sched_row_parti_row_id_bit2     ),
    .gc_cr_l2_mem_sched_row_parti_row_id_bit3       (pipe_gc_cr_l2_mem_sched_row_parti_row_id_bit3     ),
    .gc_cr_l2_mem_sched_row_parti_row_id_bit4       (pipe_gc_cr_l2_mem_sched_row_parti_row_id_bit4     ),
    .gc_cr_l2_mem_sched_row_parti_row_id_bit5       (pipe_gc_cr_l2_mem_sched_row_parti_row_id_bit5     ),
    .gc_cr_l2_mem_sched_row_parti_row_id_bit6       (pipe_gc_cr_l2_mem_sched_row_parti_row_id_bit6     ),
    .gc_cr_l2_mem_sched_row_parti_row_id_bit7       (pipe_gc_cr_l2_mem_sched_row_parti_row_id_bit7     ),
    .gc_cr_l2_mem_sched_row_partii_row_id_bit8      (pipe_gc_cr_l2_mem_sched_row_partii_row_id_bit8    ),
    .gc_cr_l2_mem_sched_row_partii_row_id_bit9      (pipe_gc_cr_l2_mem_sched_row_partii_row_id_bit9    ),
    .gc_cr_l2_mem_sched_row_partii_row_id_bit10     (pipe_gc_cr_l2_mem_sched_row_partii_row_id_bit10   ),
    .gc_cr_l2_mem_sched_row_partii_row_id_bit11     (pipe_gc_cr_l2_mem_sched_row_partii_row_id_bit11   ),
    .gc_cr_l2_mem_sched_row_partii_row_id_bit12     (pipe_gc_cr_l2_mem_sched_row_partii_row_id_bit12   ),
    .gc_cr_l2_mem_sched_row_partii_row_id_bit13     (pipe_gc_cr_l2_mem_sched_row_partii_row_id_bit13   ),
    .gc_cr_l2_mem_sched_row_partii_row_id_bit14     (pipe_gc_cr_l2_mem_sched_row_partii_row_id_bit14   ),
    .gc_cr_l2_mem_sched_row_partii_row_id_bit15     (pipe_gc_cr_l2_mem_sched_row_partii_row_id_bit15   ),
    .gc_cr_l2_mem_sched_row_partiii_row_id_bit16    (pipe_gc_cr_l2_mem_sched_row_partiii_row_id_bit16  ),
    .gc_cr_l2_mem_sched_row_partiii_row_id_bit17    (pipe_gc_cr_l2_mem_sched_row_partiii_row_id_bit17  ),
    .gc_cr_l2_function_enable_ddr_capacity          (pipe_gc_cr_l2_function_enable_ddr_capacity        ),   // I
    .gc_cr_ddr_hash_config_reg0_row_id_bit0         (pipe_gc_cr_ddr_hash_config_reg0_row_id_bit0        ),  // I
    .gc_cr_ddr_hash_config_reg0_row_id_bit1         (pipe_gc_cr_ddr_hash_config_reg0_row_id_bit1        ),  // I
    .gc_cr_ddr_hash_config_reg0_row_id_bit2         (pipe_gc_cr_ddr_hash_config_reg0_row_id_bit2        ),  // I
    .gc_cr_ddr_hash_config_reg0_row_id_bit3         (pipe_gc_cr_ddr_hash_config_reg0_row_id_bit3        ),  // I
    .gc_cr_ddr_hash_config_reg0_row_id_bit4         (pipe_gc_cr_ddr_hash_config_reg0_row_id_bit4        ),  // I
    .gc_cr_ddr_hash_config_reg0_row_id_bit5         (pipe_gc_cr_ddr_hash_config_reg0_row_id_bit5        ),  // I
    .gc_cr_ddr_hash_config_reg0_row_id_bit6         (pipe_gc_cr_ddr_hash_config_reg0_row_id_bit6        ),  // I
    .gc_cr_ddr_hash_config_reg0_row_id_bit7         (pipe_gc_cr_ddr_hash_config_reg0_row_id_bit7        ),  // I
    .gc_cr_ddr_hash_config_reg0_row_id_bit8         (pipe_gc_cr_ddr_hash_config_reg0_row_id_bit8        ),  // I
    .gc_cr_ddr_hash_config_reg0_row_id_bit9         (pipe_gc_cr_ddr_hash_config_reg0_row_id_bit9        ),  // I
    .gc_cr_ddr_hash_config_reg0_row_id_bit10        (pipe_gc_cr_ddr_hash_config_reg0_row_id_bit10       ),  // I
    .gc_cr_ddr_hash_config_reg0_row_id_bit11        (pipe_gc_cr_ddr_hash_config_reg0_row_id_bit11       ),  // I
    .gc_cr_ddr_hash_config_reg1_row_id_bit12        (pipe_gc_cr_ddr_hash_config_reg1_row_id_bit12       ),  // I
    .gc_cr_ddr_hash_config_reg1_row_id_bit13        (pipe_gc_cr_ddr_hash_config_reg1_row_id_bit13       ),  // I
    .gc_cr_ddr_hash_config_reg1_row_id_bit14        (pipe_gc_cr_ddr_hash_config_reg1_row_id_bit14       ),  // I
    .gc_cr_ddr_hash_config_reg1_row_id_bit15        (pipe_gc_cr_ddr_hash_config_reg1_row_id_bit15       ),  // I
    .gc_cr_ddr_hash_config_reg1_row_id_bit16        (pipe_gc_cr_ddr_hash_config_reg1_row_id_bit16       ),  // I
    .gc_cr_ddr_hash_config_reg1_row_id_bit17        (pipe_gc_cr_ddr_hash_config_reg1_row_id_bit17       ),  // I
    .gc_cr_ddr_hash_config_reg1_row_id_bit18        (pipe_gc_cr_ddr_hash_config_reg1_row_id_bit18       ),  // I
    .gc_cr_ddr_hash_config_reg1_row_id_bit19        (pipe_gc_cr_ddr_hash_config_reg1_row_id_bit19       ),  // I
    .gc_cr_ddr_hash_config_reg1_row_id_bit20        (pipe_gc_cr_ddr_hash_config_reg1_row_id_bit20       ),  // I
    .gc_cr_ddr_hash_config_reg1_row_id_bit21        (pipe_gc_cr_ddr_hash_config_reg1_row_id_bit21       ),  // I
    .gc_cr_ddr_hash_config_reg1_row_id_bit22        (pipe_gc_cr_ddr_hash_config_reg1_row_id_bit22       ),  // I
    .gc_cr_ddr_hash_config_reg1_row_id_bit23        (pipe_gc_cr_ddr_hash_config_reg1_row_id_bit23       ),  // I
    .gc_cr_l2_function_enable_hash_mode             (pipe_gc_cr_l2_function_enable_hash_mode            ),  // I

    .l2b_busy                                       (pipe_l2b0_busy                                     ),  // O
    .l2b_fromaxi_ar_wl                              (pipe_l2b0_fromaxi_ar_wl                            ),  // O
    .l2b_fromaxi_ar_bl_eq0_wl                       (pipe_l2b0_fromaxi_ar_bl_eq0_wl                     ),  // O
    .l2b_fromaxi_ar_bl_eq1_wl                       (pipe_l2b0_fromaxi_ar_bl_eq1_wl                     ),  // O
    .l2b_fromaxi_ar_bl_eq2_wl                       (pipe_l2b0_fromaxi_ar_bl_eq2_wl                     ),  // O
    .l2b_fromaxi_ar_bl_eq3_wl                       (pipe_l2b0_fromaxi_ar_bl_eq3_wl                     ),  // O
    .l2b_fromaxi_ar_bp                              (pipe_l2b0_fromaxi_ar_bp                            ),  // O
    .l2b_toaxi_r_wl                                 (pipe_l2b0_toaxi_r_wl                               ),  // O
    .l2b_toaxi_r_bp                                 (pipe_l2b0_toaxi_r_bp                               ),  // O
    .l2b_fromaxi_aw_wl                              (pipe_l2b0_fromaxi_aw_wl                            ),  // O
    .l2b_fromaxi_aw_bl_eq0_wl                       (pipe_l2b0_fromaxi_aw_bl_eq0_wl                     ),  // O
    .l2b_fromaxi_aw_bl_eq1_wl                       (pipe_l2b0_fromaxi_aw_bl_eq1_wl                     ),  // O
    .l2b_fromaxi_aw_bl_eq2_wl                       (pipe_l2b0_fromaxi_aw_bl_eq2_wl                     ),  // O
    .l2b_fromaxi_aw_bl_eq3_wl                       (pipe_l2b0_fromaxi_aw_bl_eq3_wl                     ),  // O
    .l2b_fromaxi_aw_bp                              (pipe_l2b0_fromaxi_aw_bp                            ),  // O
    .l2b_fromaxi_w_wl                               (pipe_l2b0_fromaxi_w_wl                             ),  // O
    .l2b_fromaxi_w_bp                               (pipe_l2b0_fromaxi_w_bp                             ),  // O
    .l2b_fromaxi_smp_read_req_num                   (pipe_l2b0_fromaxi_smp_read_req_num                 ),  // O
    .l2b_fromaxi_smp_read_req_sum                   (pipe_l2b0_fromaxi_smp_read_req_sum                 ),  // O
    .l2b_fromaxi_smp_write_req_num                  (pipe_l2b0_fromaxi_smp_write_req_num                ),  // O
    .l2b_fromaxi_smp_write_req_sum                  (pipe_l2b0_fromaxi_smp_write_req_sum                ),  // O
    .l2b_fromaxi_smp_atomic_req_num                 (pipe_l2b0_fromaxi_smp_atomic_req_num               ),  // O
    .l2b_fromaxi_smp_atomic_req_sum                 (pipe_l2b0_fromaxi_smp_atomic_req_sum               ),  // O
    .l2b_align_awdb_full                            (pipe_l2b0_align_awdb_full                          ),  // O
    .l2b_hittest_ht_bypass_read_wl                  (pipe_l2b0_hittest_ht_bypass_read_wl                ),  // O
    .l2b_hittest_ht_cache_read_wl                   (pipe_l2b0_hittest_ht_cache_read_wl                 ),  // O
    .l2b_hittest_ht_bypass_write_wl                 (pipe_l2b0_hittest_ht_bypass_write_wl               ),  // O
    .l2b_hittest_ht_cache_write_wl                  (pipe_l2b0_hittest_ht_cache_write_wl                ),  // O
    .l2b_hittest_ht_atomic_wl                       (pipe_l2b0_hittest_ht_atomic_wl                     ),  // O
    .l2b_hittest_ht_bps_hit_wl                      (pipe_l2b0_hittest_ht_bps_hit_wl                    ),  // O
    .l2b_hittest_ht_miss_wl                         (pipe_l2b0_hittest_ht_miss_wl                       ),  // O
    .l2b_frommemsch_nsp_rtn_wl                      (pipe_l2b0_frommemsch_nsp_rtn_wl                    ),  // O
    .l2b_frommemsch_nsp_rtn_bp                      (pipe_l2b0_frommemsch_nsp_rtn_bp                    ),  // O
    .l2b_tomemsch_nsp_read_bl_eq1_wl                (pipe_l2b0_tomemsch_nsp_read_bl_eq1_wl              ),  // O
    .l2b_tomemsch_nsp_read_bl_eq3_wl                (pipe_l2b0_tomemsch_nsp_read_bl_eq3_wl              ),  // O
    .l2b_tomemsch_nsp_read_bl_eq5_wl                (pipe_l2b0_tomemsch_nsp_read_bl_eq5_wl              ),  // O
    .l2b_tomemsch_nsp_read_bl_eq7_wl                (pipe_l2b0_tomemsch_nsp_read_bl_eq7_wl              ),  // O
    .l2b_tomemsch_nsp_write_bl_eq1_wl               (pipe_l2b0_tomemsch_nsp_write_bl_eq1_wl             ),  // O
    .l2b_tomemsch_nsp_write_bl_eq3_wl               (pipe_l2b0_tomemsch_nsp_write_bl_eq3_wl             ),  // O
    .l2b_tomemsch_nsp_write_bl_eq5_wl               (pipe_l2b0_tomemsch_nsp_write_bl_eq5_wl             ),  // O
    .l2b_tomemsch_nsp_write_bl_eq7_wl               (pipe_l2b0_tomemsch_nsp_write_bl_eq7_wl             ),  // O
    .l2b_memif_to_ddr_read_wl                       (pipe_l2b0_memif_to_ddr_read_wl                     ),  // O
    .l2b_memif_to_ddr_read_stall_by_rob             (pipe_l2b0_memif_to_ddr_read_stall_by_rob           ),  // O
    .l2b_memif_to_ddr_read_stall_by_ddr             (pipe_l2b0_memif_to_ddr_read_stall_by_ddr           ),  // O
    .l2b_memif_to_ddr_read_stall_by_trid            (pipe_l2b0_memif_to_ddr_read_stall_by_trid          ),  // O
    .l2b_memif_to_ddr_write_wl                      (pipe_l2b0_memif_to_ddr_write_wl                    ),  // O
    .l2b_memif_to_ddr_write_stall_by_data_sync      (pipe_l2b0_memif_to_ddr_write_stall_by_data_sync    ),  // O
    .l2b_memif_to_ddr_write_stall_by_ddr            (pipe_l2b0_memif_to_ddr_write_stall_by_ddr          ),  // O
    .l2b_memif_to_ddr_write_stall_by_trid           (pipe_l2b0_memif_to_ddr_write_stall_by_trid         ),  // O
    .l2b_memif_memreq_full                          (pipe_l2b0_memif_memreq_full                        ),  // O
    .l2b_memif_smp_read_req_num                     (pipe_l2b0_memif_smp_read_req_num                   ),  // O
    .l2b_memif_smp_read_req_sum                     (pipe_l2b0_memif_smp_read_req_sum                   ),  // O
    .l2b_reqsch_sortq_full                          (pipe_l2b0_reqsch_sortq_full                        ),  // O
    .l2b_reqsch_sortq_stall_but_not_full            (pipe_l2b0_reqsch_sortq_stall_but_not_full          ),  // O
    .l2b_reqsch_disp_wl                             (pipe_l2b0_reqsch_disp_wl                           ),  // O
    .l2b_reqsch_disp_stall                          (pipe_l2b0_reqsch_disp_stall                        ),  // O
    .l2b_ramctrl_0_reqarb_wl                        (pipe_l2b0_ramctrl_0_reqarb_wl                      ),  // O
    .l2b_ramctrl_0_reqarb_stall_by_sram             (pipe_l2b0_ramctrl_0_reqarb_stall_by_sram           ),  // O
    .l2b_ramctrl_0_data_sram_read_wl                (pipe_l2b0_ramctrl_0_data_sram_read_wl              ),  // O
    .l2b_ramctrl_0_data_sram_write_wl               (pipe_l2b0_ramctrl_0_data_sram_write_wl             ),  // O
    .l2b_ramctrl_1_reqarb_wl                        (pipe_l2b0_ramctrl_1_reqarb_wl                      ),  // O
    .l2b_ramctrl_1_reqarb_stall_by_sram             (pipe_l2b0_ramctrl_1_reqarb_stall_by_sram           ),  // O
    .l2b_ramctrl_1_data_sram_read_wl                (pipe_l2b0_ramctrl_1_data_sram_read_wl              ),  // O
    .l2b_ramctrl_1_data_sram_write_wl               (pipe_l2b0_ramctrl_1_data_sram_write_wl             ),  // O

    .tst_gclkenable                                 (tst_gclkenable                                     )   // I
);

gc_l2_bank i_gc_l2_bank1 (
    // global interface
    .clk                        (crm_out_clk                ),  // I
    .resetn                     (crm_out_resetn             ),  // I
    .l2_bank_idle               (l2_bank1_idle              ),  // O
    // AXI interface
    .axi_slv_arvalid            (ipg_axi_slv_1_arvalid      ),  // I
    .axi_slv_arready            (ipg_axi_slv_1_arready      ),  // O
    .axi_slv_ar_rec             (ipg_axi_slv_1_ar_rec       ),  // I
    .axi_slv_rvalid             (ipg_axi_slv_1_rvalid       ),  // O
    .axi_slv_rready             (ipg_axi_slv_1_rready       ),  // I
    .axi_slv_r_rec              (ipg_axi_slv_1_r_rec        ),  // O
    .axi_slv_awvalid            (ipg_axi_slv_1_awvalid      ),  // I
    .axi_slv_awready            (ipg_axi_slv_1_awready      ),  // O
    .axi_slv_aw_rec             (ipg_axi_slv_1_aw_rec       ),  // I
    .axi_slv_wvalid             (ipg_axi_slv_1_wvalid       ),  // I
    .axi_slv_wready             (ipg_axi_slv_1_wready       ),  // O
    .axi_slv_w_rec              (ipg_axi_slv_1_w_rec        ),  // I
    .axi_slv_bvalid             (ipg_axi_slv_1_bvalid       ),  // O
    .axi_slv_bready             (ipg_axi_slv_1_bready       ),  // I
    .axi_slv_b_rec              (ipg_axi_slv_1_b_rec        ),  // O
    // memory scheduler and NSP interface
    .memif_sched_valid          (bank1_memif_sched_valid    ),  // O
    .memif_sched_ready          (bank1_memif_sched_ready    ),  // I
    .memif_sched_rec            (bank1_memif_sched_rec      ),  // O
    .sched_memif_valid          (bank1_sched_memif_valid    ),  // I
    .sched_memif_ready          (bank1_sched_memif_ready    ),  // O
    .sched_memif_rec            (bank1_sched_memif_rec      ),  // I
    .nsp_req_valid              (bank1_nsp_req_valid        ),  // O
    .nsp_req_ready              (bank1_nsp_req_ready        ),  // I
    .nsp_req_rec                (bank1_nsp_req_rec          ),  // O
    .nsp_rsp_valid              (bank1_nsp_rsp_valid        ),  // I
    .nsp_rsp_ready              (bank1_nsp_rsp_ready        ),  // O
    .nsp_rsp_rec                (bank1_nsp_rsp_rec          ),  // I
    
    // configure register
    .gc_cr_l2_cmd_notify                            (pipe_gc_cr_l2_cmd_notify                           ),  // I
    .gc_cr_l2_cmd_persistence_rst_all               (pipe_gc_cr_l2_cmd_persistence_rst_all              ),  // I
    .gc_cr_l2_cmd_cfi_clr                           (pipe_gc_cr_l2_cmd_cfi_clr                          ),  // I
    .gc_cr_l2_cfi_operation_notify                  (pipe_gc_cr_l2_cfi_operation_notify                 ),  // I
    .gc_cr_l2_cfi_operation                         (pipe_gc_cr_l2_cfi_operation                        ),  // I
    .gc_cr_l2_buffer_mode_buffer_mode_percentage    (pipe_gc_cr_l2_buffer_mode_buffer_mode_percentage   ),  // I
    .gc_cr_l2g_error_l2b                            (pipe_gc_cr_l2g_error0_l2b1                         ),  // O
    .gc_cr_l2_cfi_statusi_l2b_finish                (pipe_gc_cr_l2_cfi_statusi_l2b1_finish              ),  // O
    .gc_cr_l2_persistence_reduce_enable             (pipe_gc_cr_l2_persistence_reduce_enable            ),  // I
    .gc_cr_l2_persistence_reduce_threshold          (pipe_gc_cr_l2_persistence_reduce_threshold         ),  // I
    .gc_cr_l2_function_enable_bypass_mode           (pipe_gc_cr_l2_function_enable_bypass_mode          ),  // I
    .gc_cr_cu_lms_fp32_denormal_en                 (pipe_gc_cr_cu_lms_fp32_denormal_en                ),  // I
    .gc_l2_mem_scheduler_enable                     (pipe_gc_cr_l2_function_enable_mem_scheduler        ),  // I 
    .gc_cr_l2_mem_sched_bank_offset_bank_id_bit0    (pipe_gc_cr_l2_mem_sched_bank_offset_bank_id_bit0   ),  // I   
    .gc_cr_l2_mem_sched_bank_offset_bank_id_bit1    (pipe_gc_cr_l2_mem_sched_bank_offset_bank_id_bit1   ),  // I 
    .gc_cr_l2_mem_sched_bank_offset_bank_id_bit2    (pipe_gc_cr_l2_mem_sched_bank_offset_bank_id_bit2   ),  // I 
    .gc_cr_l2_mem_sched_bank_offset_bank_id_bit3    (pipe_gc_cr_l2_mem_sched_bank_offset_bank_id_bit3   ),  // I 
    .gc_cr_l2_mem_sched_bank_offset_bank_id_bit4    (pipe_gc_cr_l2_mem_sched_bank_offset_bank_id_bit4   ),  // I 
    
    .gc_cr_l2_mem_sched_row_parti_row_id_bit0       (pipe_gc_cr_l2_mem_sched_row_parti_row_id_bit0     ),   // I 
    .gc_cr_l2_mem_sched_row_parti_row_id_bit1       (pipe_gc_cr_l2_mem_sched_row_parti_row_id_bit1     ),   // I 
    .gc_cr_l2_mem_sched_row_parti_row_id_bit2       (pipe_gc_cr_l2_mem_sched_row_parti_row_id_bit2     ),   // I 
    .gc_cr_l2_mem_sched_row_parti_row_id_bit3       (pipe_gc_cr_l2_mem_sched_row_parti_row_id_bit3     ),   // I 
    .gc_cr_l2_mem_sched_row_parti_row_id_bit4       (pipe_gc_cr_l2_mem_sched_row_parti_row_id_bit4     ),   // I 
    .gc_cr_l2_mem_sched_row_parti_row_id_bit5       (pipe_gc_cr_l2_mem_sched_row_parti_row_id_bit5     ),   // I 
    .gc_cr_l2_mem_sched_row_parti_row_id_bit6       (pipe_gc_cr_l2_mem_sched_row_parti_row_id_bit6     ),   // I 
    .gc_cr_l2_mem_sched_row_parti_row_id_bit7       (pipe_gc_cr_l2_mem_sched_row_parti_row_id_bit7     ),   // I 
    .gc_cr_l2_mem_sched_row_partii_row_id_bit8      (pipe_gc_cr_l2_mem_sched_row_partii_row_id_bit8    ),   // I 
    .gc_cr_l2_mem_sched_row_partii_row_id_bit9      (pipe_gc_cr_l2_mem_sched_row_partii_row_id_bit9    ),   // I 
    .gc_cr_l2_mem_sched_row_partii_row_id_bit10     (pipe_gc_cr_l2_mem_sched_row_partii_row_id_bit10   ),   // I 
    .gc_cr_l2_mem_sched_row_partii_row_id_bit11     (pipe_gc_cr_l2_mem_sched_row_partii_row_id_bit11   ),   // I 
    .gc_cr_l2_mem_sched_row_partii_row_id_bit12     (pipe_gc_cr_l2_mem_sched_row_partii_row_id_bit12   ),   // I 
    .gc_cr_l2_mem_sched_row_partii_row_id_bit13     (pipe_gc_cr_l2_mem_sched_row_partii_row_id_bit13   ),   // I 
    .gc_cr_l2_mem_sched_row_partii_row_id_bit14     (pipe_gc_cr_l2_mem_sched_row_partii_row_id_bit14   ),   // I 
    .gc_cr_l2_mem_sched_row_partii_row_id_bit15     (pipe_gc_cr_l2_mem_sched_row_partii_row_id_bit15   ),   // I 
    .gc_cr_l2_mem_sched_row_partiii_row_id_bit16    (pipe_gc_cr_l2_mem_sched_row_partiii_row_id_bit16  ),   // I 
    .gc_cr_l2_mem_sched_row_partiii_row_id_bit17    (pipe_gc_cr_l2_mem_sched_row_partiii_row_id_bit17  ),   // I 
    .gc_cr_l2_function_enable_ddr_capacity          (pipe_gc_cr_l2_function_enable_ddr_capacity        ),   // I
    .gc_cr_ddr_hash_config_reg0_row_id_bit0         (pipe_gc_cr_ddr_hash_config_reg0_row_id_bit0        ),  // I
    .gc_cr_ddr_hash_config_reg0_row_id_bit1         (pipe_gc_cr_ddr_hash_config_reg0_row_id_bit1        ),  // I
    .gc_cr_ddr_hash_config_reg0_row_id_bit2         (pipe_gc_cr_ddr_hash_config_reg0_row_id_bit2        ),  // I
    .gc_cr_ddr_hash_config_reg0_row_id_bit3         (pipe_gc_cr_ddr_hash_config_reg0_row_id_bit3        ),  // I
    .gc_cr_ddr_hash_config_reg0_row_id_bit4         (pipe_gc_cr_ddr_hash_config_reg0_row_id_bit4        ),  // I
    .gc_cr_ddr_hash_config_reg0_row_id_bit5         (pipe_gc_cr_ddr_hash_config_reg0_row_id_bit5        ),  // I
    .gc_cr_ddr_hash_config_reg0_row_id_bit6         (pipe_gc_cr_ddr_hash_config_reg0_row_id_bit6        ),  // I
    .gc_cr_ddr_hash_config_reg0_row_id_bit7         (pipe_gc_cr_ddr_hash_config_reg0_row_id_bit7        ),  // I
    .gc_cr_ddr_hash_config_reg0_row_id_bit8         (pipe_gc_cr_ddr_hash_config_reg0_row_id_bit8        ),  // I
    .gc_cr_ddr_hash_config_reg0_row_id_bit9         (pipe_gc_cr_ddr_hash_config_reg0_row_id_bit9        ),  // I
    .gc_cr_ddr_hash_config_reg0_row_id_bit10        (pipe_gc_cr_ddr_hash_config_reg0_row_id_bit10       ),  // I
    .gc_cr_ddr_hash_config_reg0_row_id_bit11        (pipe_gc_cr_ddr_hash_config_reg0_row_id_bit11       ),  // I
    .gc_cr_ddr_hash_config_reg1_row_id_bit12        (pipe_gc_cr_ddr_hash_config_reg1_row_id_bit12       ),  // I
    .gc_cr_ddr_hash_config_reg1_row_id_bit13        (pipe_gc_cr_ddr_hash_config_reg1_row_id_bit13       ),  // I
    .gc_cr_ddr_hash_config_reg1_row_id_bit14        (pipe_gc_cr_ddr_hash_config_reg1_row_id_bit14       ),  // I
    .gc_cr_ddr_hash_config_reg1_row_id_bit15        (pipe_gc_cr_ddr_hash_config_reg1_row_id_bit15       ),  // I
    .gc_cr_ddr_hash_config_reg1_row_id_bit16        (pipe_gc_cr_ddr_hash_config_reg1_row_id_bit16       ),  // I
    .gc_cr_ddr_hash_config_reg1_row_id_bit17        (pipe_gc_cr_ddr_hash_config_reg1_row_id_bit17       ),  // I
    .gc_cr_ddr_hash_config_reg1_row_id_bit18        (pipe_gc_cr_ddr_hash_config_reg1_row_id_bit18       ),  // I
    .gc_cr_ddr_hash_config_reg1_row_id_bit19        (pipe_gc_cr_ddr_hash_config_reg1_row_id_bit19       ),  // I
    .gc_cr_ddr_hash_config_reg1_row_id_bit20        (pipe_gc_cr_ddr_hash_config_reg1_row_id_bit20       ),  // I
    .gc_cr_ddr_hash_config_reg1_row_id_bit21        (pipe_gc_cr_ddr_hash_config_reg1_row_id_bit21       ),  // I
    .gc_cr_ddr_hash_config_reg1_row_id_bit22        (pipe_gc_cr_ddr_hash_config_reg1_row_id_bit22       ),  // I
    .gc_cr_ddr_hash_config_reg1_row_id_bit23        (pipe_gc_cr_ddr_hash_config_reg1_row_id_bit23       ),  // I
    .gc_cr_l2_function_enable_hash_mode             (pipe_gc_cr_l2_function_enable_hash_mode            ),  // I
    // performance counter
    .l2b_busy                                       (pipe_l2b1_busy                                     ),  // O
    .l2b_fromaxi_ar_wl                              (pipe_l2b1_fromaxi_ar_wl                            ),  // O
    .l2b_fromaxi_ar_bl_eq0_wl                       (pipe_l2b1_fromaxi_ar_bl_eq0_wl                     ),  // O
    .l2b_fromaxi_ar_bl_eq1_wl                       (pipe_l2b1_fromaxi_ar_bl_eq1_wl                     ),  // O
    .l2b_fromaxi_ar_bl_eq2_wl                       (pipe_l2b1_fromaxi_ar_bl_eq2_wl                     ),  // O
    .l2b_fromaxi_ar_bl_eq3_wl                       (pipe_l2b1_fromaxi_ar_bl_eq3_wl                     ),  // O
    .l2b_fromaxi_ar_bp                              (pipe_l2b1_fromaxi_ar_bp                            ),  // O
    .l2b_toaxi_r_wl                                 (pipe_l2b1_toaxi_r_wl                               ),  // O
    .l2b_toaxi_r_bp                                 (pipe_l2b1_toaxi_r_bp                               ),  // O
    .l2b_fromaxi_aw_wl                              (pipe_l2b1_fromaxi_aw_wl                            ),  // O
    .l2b_fromaxi_aw_bl_eq0_wl                       (pipe_l2b1_fromaxi_aw_bl_eq0_wl                     ),  // O
    .l2b_fromaxi_aw_bl_eq1_wl                       (pipe_l2b1_fromaxi_aw_bl_eq1_wl                     ),  // O
    .l2b_fromaxi_aw_bl_eq2_wl                       (pipe_l2b1_fromaxi_aw_bl_eq2_wl                     ),  // O
    .l2b_fromaxi_aw_bl_eq3_wl                       (pipe_l2b1_fromaxi_aw_bl_eq3_wl                     ),  // O
    .l2b_fromaxi_aw_bp                              (pipe_l2b1_fromaxi_aw_bp                            ),  // O
    .l2b_fromaxi_w_wl                               (pipe_l2b1_fromaxi_w_wl                             ),  // O
    .l2b_fromaxi_w_bp                               (pipe_l2b1_fromaxi_w_bp                             ),  // O
    .l2b_fromaxi_smp_read_req_num                   (pipe_l2b1_fromaxi_smp_read_req_num                 ),  // O
    .l2b_fromaxi_smp_read_req_sum                   (pipe_l2b1_fromaxi_smp_read_req_sum                 ),  // O
    .l2b_fromaxi_smp_write_req_num                  (pipe_l2b1_fromaxi_smp_write_req_num                ),  // O
    .l2b_fromaxi_smp_write_req_sum                  (pipe_l2b1_fromaxi_smp_write_req_sum                ),  // O
    .l2b_fromaxi_smp_atomic_req_num                 (pipe_l2b1_fromaxi_smp_atomic_req_num               ),  // O
    .l2b_fromaxi_smp_atomic_req_sum                 (pipe_l2b1_fromaxi_smp_atomic_req_sum               ),  // O
    .l2b_align_awdb_full                            (pipe_l2b1_align_awdb_full                          ),  // O
    .l2b_hittest_ht_bypass_read_wl                  (pipe_l2b1_hittest_ht_bypass_read_wl                ),  // O
    .l2b_hittest_ht_cache_read_wl                   (pipe_l2b1_hittest_ht_cache_read_wl                 ),  // O
    .l2b_hittest_ht_bypass_write_wl                 (pipe_l2b1_hittest_ht_bypass_write_wl               ),  // O
    .l2b_hittest_ht_cache_write_wl                  (pipe_l2b1_hittest_ht_cache_write_wl                ),  // O
    .l2b_hittest_ht_atomic_wl                       (pipe_l2b1_hittest_ht_atomic_wl                     ),  // O
    .l2b_hittest_ht_bps_hit_wl                      (pipe_l2b1_hittest_ht_bps_hit_wl                    ),  // O
    .l2b_hittest_ht_miss_wl                         (pipe_l2b1_hittest_ht_miss_wl                       ),  // O
    .l2b_frommemsch_nsp_rtn_wl                      (pipe_l2b1_frommemsch_nsp_rtn_wl                    ),  // O
    .l2b_frommemsch_nsp_rtn_bp                      (pipe_l2b1_frommemsch_nsp_rtn_bp                    ),  // O
    .l2b_tomemsch_nsp_read_bl_eq1_wl                (pipe_l2b1_tomemsch_nsp_read_bl_eq1_wl              ),  // O
    .l2b_tomemsch_nsp_read_bl_eq3_wl                (pipe_l2b1_tomemsch_nsp_read_bl_eq3_wl              ),  // O
    .l2b_tomemsch_nsp_read_bl_eq5_wl                (pipe_l2b1_tomemsch_nsp_read_bl_eq5_wl              ),  // O
    .l2b_tomemsch_nsp_read_bl_eq7_wl                (pipe_l2b1_tomemsch_nsp_read_bl_eq7_wl              ),  // O
    .l2b_tomemsch_nsp_write_bl_eq1_wl               (pipe_l2b1_tomemsch_nsp_write_bl_eq1_wl             ),  // O
    .l2b_tomemsch_nsp_write_bl_eq3_wl               (pipe_l2b1_tomemsch_nsp_write_bl_eq3_wl             ),  // O
    .l2b_tomemsch_nsp_write_bl_eq5_wl               (pipe_l2b1_tomemsch_nsp_write_bl_eq5_wl             ),  // O
    .l2b_tomemsch_nsp_write_bl_eq7_wl               (pipe_l2b1_tomemsch_nsp_write_bl_eq7_wl             ),  // O
    .l2b_memif_to_ddr_read_wl                       (pipe_l2b1_memif_to_ddr_read_wl                     ),  // O
    .l2b_memif_to_ddr_read_stall_by_rob             (pipe_l2b1_memif_to_ddr_read_stall_by_rob           ),  // O
    .l2b_memif_to_ddr_read_stall_by_ddr             (pipe_l2b1_memif_to_ddr_read_stall_by_ddr           ),  // O
    .l2b_memif_to_ddr_read_stall_by_trid            (pipe_l2b1_memif_to_ddr_read_stall_by_trid          ),  // O
    .l2b_memif_to_ddr_write_wl                      (pipe_l2b1_memif_to_ddr_write_wl                    ),  // O
    .l2b_memif_to_ddr_write_stall_by_data_sync      (pipe_l2b1_memif_to_ddr_write_stall_by_data_sync    ),  // O
    .l2b_memif_to_ddr_write_stall_by_ddr            (pipe_l2b1_memif_to_ddr_write_stall_by_ddr          ),  // O
    .l2b_memif_to_ddr_write_stall_by_trid           (pipe_l2b1_memif_to_ddr_write_stall_by_trid         ),  // O
    .l2b_memif_memreq_full                          (pipe_l2b1_memif_memreq_full                        ),  // O
    .l2b_memif_smp_read_req_num                     (pipe_l2b1_memif_smp_read_req_num                   ),  // O
    .l2b_memif_smp_read_req_sum                     (pipe_l2b1_memif_smp_read_req_sum                   ),  // O
    .l2b_reqsch_sortq_full                          (pipe_l2b1_reqsch_sortq_full                        ),  // O
    .l2b_reqsch_sortq_stall_but_not_full            (pipe_l2b1_reqsch_sortq_stall_but_not_full          ),  // O
    .l2b_reqsch_disp_wl                             (pipe_l2b1_reqsch_disp_wl                           ),  // O
    .l2b_reqsch_disp_stall                          (pipe_l2b1_reqsch_disp_stall                        ),  // O
    .l2b_ramctrl_0_reqarb_wl                        (pipe_l2b1_ramctrl_0_reqarb_wl                      ),  // O
    .l2b_ramctrl_0_reqarb_stall_by_sram             (pipe_l2b1_ramctrl_0_reqarb_stall_by_sram           ),  // O
    .l2b_ramctrl_0_data_sram_read_wl                (pipe_l2b1_ramctrl_0_data_sram_read_wl              ),  // O
    .l2b_ramctrl_0_data_sram_write_wl               (pipe_l2b1_ramctrl_0_data_sram_write_wl             ),  // O
    .l2b_ramctrl_1_reqarb_wl                        (pipe_l2b1_ramctrl_1_reqarb_wl                      ),  // O
    .l2b_ramctrl_1_reqarb_stall_by_sram             (pipe_l2b1_ramctrl_1_reqarb_stall_by_sram           ),  // O
    .l2b_ramctrl_1_data_sram_read_wl                (pipe_l2b1_ramctrl_1_data_sram_read_wl              ),  // O
    .l2b_ramctrl_1_data_sram_write_wl               (pipe_l2b1_ramctrl_1_data_sram_write_wl             ),  // O

    .tst_gclkenable                                 (tst_gclkenable                                 )   // I
);

// ----------------------------------------------------------------------------------------------
// mem_sched instance
// ----------------------------------------------------------------------------------------------
// bank to mem_sched xbar
gc_l2_bank_sched_xbar_wrap i_gc_l2_bank_sched_xbar(
    .clk                        (crm_out_clk                                        ) ,  // I
    .resetn                     (crm_out_resetn                                     ) ,  // I
    .idle                       (sched_xbar_idle                                    ) ,  // O
    .memif_xbar_req_valid       ({bank1_memif_sched_valid, bank0_memif_sched_valid} ) ,  // I
    .memif_xbar_req_ready       ({bank1_memif_sched_ready, bank0_memif_sched_ready} ) ,  // O
    .memif_xbar_req_rec         ({bank1_memif_sched_rec  , bank0_memif_sched_rec  } ) ,  // I
    .xbar_sched_req_valid       (xbar_sched_req_valid                               ) ,  // O
    .xbar_sched_req_ready       (xbar_sched_req_ready                               ) ,  // I
    .xbar_sched_req_rec         (xbar_sched_req_rec                                 ) ,  // O
    .xbar_memif_rsp_valid       ({bank1_sched_memif_valid, bank0_sched_memif_valid} ) ,  // O
    .xbar_memif_rsp_ready       ({bank1_sched_memif_ready, bank0_sched_memif_ready} ) ,  // I
    .xbar_memif_rsp_rec         ({bank1_sched_memif_rec  , bank0_sched_memif_rec  } ) ,  // O
    .sched_xbar_rsp_valid       (sched_xbar_rsp_valid                               ) ,  // I
    .sched_xbar_rsp_ready       (sched_xbar_rsp_ready                               ) ,  // O
    .sched_xbar_rsp_rec         (sched_xbar_rsp_rec                                 ) );// I


// mem_sched
gc_l2_bank_mem_sched i_gc_l2_bank_mem_sched(
    .clk                        (crm_out_clk                    ),  // I
    .resetn                     (crm_out_resetn                 ),  // I
    .mem_sched_idle             (mem_sched_idle                 ),  // O

    .bank0_memif_sched_valid    (xbar_sched_req_valid[0]        ),  // I
    .bank0_memif_sched_ready    (xbar_sched_req_ready[0]        ),  // O
    .bank0_memif_sched_rec      (xbar_sched_req_rec  [0]        ),  // I
    .bank0_sched_memif_valid    (sched_xbar_rsp_valid[0]        ),  // O
    .bank0_sched_memif_ready    (sched_xbar_rsp_ready[0]        ),  // I
    .bank0_sched_memif_rec      (sched_xbar_rsp_rec  [0]        ),  // O

    .bank1_memif_sched_valid    (xbar_sched_req_valid[1]        ),  // I
    .bank1_memif_sched_ready    (xbar_sched_req_ready[1]        ),  // O
    .bank1_memif_sched_rec      (xbar_sched_req_rec  [1]        ),  // I
    .bank1_sched_memif_valid    (sched_xbar_rsp_valid[1]        ),  // O
    .bank1_sched_memif_ready    (sched_xbar_rsp_ready[1]        ),  // I
    .bank1_sched_memif_rec      (sched_xbar_rsp_rec  [1]        )  // O
);

// bank to nsp xbar
gc_l2_bank_nsp_xbar_wrap i_gc_l2_bank_nsp_xbar(
    .clk                        (crm_out_clk                                ) ,  // I
    .resetn                     (crm_out_resetn                             ) ,  // I
    .idle                       (nsp_xbar_idle                              ) ,  // O
    .memif_xbar_req_valid       ({bank1_nsp_req_valid, bank0_nsp_req_valid} ) ,  // I
    .memif_xbar_req_ready       ({bank1_nsp_req_ready, bank0_nsp_req_ready} ) ,  // O
    .memif_xbar_req_rec         ({bank1_nsp_req_rec  , bank0_nsp_req_rec  } ) ,  // I
    .xbar_nsp_req_valid         (ipg_nsp_req_valid                          ) ,  // O
    .xbar_nsp_req_ready         (ipg_nsp_req_ready                          ) ,  // I
    .xbar_nsp_req_rec           (ipg_nsp_req_rec                            ) ,  // O
    .xbar_memif_rsp_valid       ({bank1_nsp_rsp_valid, bank0_nsp_rsp_valid} ) ,  // O
    .xbar_memif_rsp_ready       ({bank1_nsp_rsp_ready, bank0_nsp_rsp_ready} ) ,  // I
    .xbar_memif_rsp_rec         ({bank1_nsp_rsp_rec  , bank0_nsp_rsp_rec  } ) ,  // O
    .nsp_xbar_rsp_valid         (ipg_nsp_rsp_valid                          ) ,  // I
    .nsp_xbar_rsp_ready         (ipg_nsp_rsp_ready                          ) ,  // O
    .nsp_xbar_rsp_rec           (ipg_nsp_rsp_rec                            ) // I
);

endmodule
