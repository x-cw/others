// ---------------------------------------------------------------------------------
// Project Name  : IC_Design
// Author        : liusm
// Email         : liusm@innosilicon.com.cn
// Create On     : 2025/06/09 17:20
// Last Modified : 2025/09/05 16:25
// File Name     : gc_l2_bank_ddr_hash.sv
// Description   :
// 
// Copyright (c) 2025 Innosilicon.
// ALL RIGHTS RESERVED
// 
// ---------------------------------------------------------------------------------
// Modification History:
// Date         By              Version                 Change Description
// ---------------------------------------------------------------------------------
// 2025/06/09   liusm           1.0                     Original
// 
// ----------------------------------------------------------------------------------


module gc_l2_bank_ddr_hash(
   input    logic [3:0 ]             ddr_capacity         ,
   input    logic [32:0]             pa                   ,
   input    logic [16:0] [5:0]       gc_rowid_offset      ,
   input    logic [3:0 ] [5:0]       gc_bankid_offset     ,
   input    logic [1:0 ]             ddr_hash_mode        ,
   input    logic [63:0]             config_rowid_offset0 ,
   input    logic [63:0]             config_rowid_offset1 ,
   output   logic [3:0 ]             hash_bank_id
);

logic [4:0]    reg_sdram_row_size       ;
logic          reg_ddrc_addrmap_hash_en ;
logic [17:0]   am_row                   ;
logic [3:0]    am_ba                    ;
logic [3:0]    pvr_hash_bank            ;
logic [3:0]    config_bank              ;




assign reg_sdram_row_size = ddr_capacity == 'd0 ? 5'd13 :
                            ddr_capacity == 'd1 ? 5'd14 :
                            ddr_capacity == 'd2 ? 5'd15 :
                            ddr_capacity == 'd3 ? 5'd16 : 
                            5'd17;
assign reg_ddrc_addrmap_hash_en = (ddr_hash_mode == 2'd3) ? 1'b1 : 1'b0;



for (genvar IDX = 0; IDX < 17-4; IDX ++) begin
   assign am_row[IDX] = pa[gc_rowid_offset[IDX]];
end
assign am_row[17] = 1'b0;

assign am_row[17-1] = ddr_capacity == 3'd4 ?    pa[gc_rowid_offset[17-1]] : 1'b0; // 16th bit. capacity == 4
assign am_row[17-2] = ddr_capacity >  3'd2 ?    pa[gc_rowid_offset[17-2]] : 1'b0; // 15th bit. capacity == 3 or 4, ignore MSB 2nd bit.
assign am_row[17-3] = ddr_capacity >  3'd1 ?    pa[gc_rowid_offset[17-3]] : 1'b0; // 14th bit. capacity == 2,3,4 , ignore MSB 3rd bit.
assign am_row[17-4] = ddr_capacity >  3'd0 ?    pa[gc_rowid_offset[17-4]] : 1'b0; // 13th bit. capacity == 1,2,3,4,ignore MSB 4th bit 

for (genvar IDX = 0 ; IDX < 4; IDX ++) begin
   assign am_ba[IDX] = pa[gc_bankid_offset[IDX]];
end

gc_l2_bank_pvr_hash
#(
    .BANK_BITS                ( 4                        )
   ,.ROW_BITS                 ( 18                       ) )
i_ddr_pvr_hash                (
    .reg_sdram_row_size       ( reg_sdram_row_size       )
   ,.reg_ddrc_addrmap_hash_en ( reg_ddrc_addrmap_hash_en )
   ,.am_row                   ( am_row                   )
   ,.am_ba                    ( am_ba                    )
   ,.hash_bank                ( pvr_hash_bank            ) );
//assign pvr_hash_bank = '0;

// 
// configurable hash
logic [3:0] hash_mask;
logic [23:0] rowid_array;
logic [11:0] [4:0] config_offset0_ar;
logic [11:0] [4:0] config_offset1_ar;

for (genvar IDX = 0; IDX < 12; IDX ++) begin
   assign config_offset0_ar[IDX] = config_rowid_offset0[IDX*4+:4] + 4'h8;
   assign config_offset1_ar[IDX] = config_rowid_offset1[IDX*4+:4] + 4'h8;
   assign rowid_array[IDX]    = config_rowid_offset0[IDX*4+:4] >= 'h9 ? '0 : am_row[config_offset0_ar[IDX]];
   assign rowid_array[12+IDX] = config_rowid_offset1[IDX*4+:4] >= 'h9 ? '0 : am_row[config_offset1_ar[IDX]];
end



assign hash_mask[0] = am_row[0] ^ am_row[7] ^ rowid_array[0] ^ rowid_array[1] ^ rowid_array[2] ^ rowid_array[3] ^ rowid_array[4] ^ rowid_array[5];
assign hash_mask[1] = am_row[1] ^ am_row[6] ^ rowid_array[6] ^ rowid_array[7] ^ rowid_array[8] ^ rowid_array[9] ^ rowid_array[10] ^ rowid_array[11];
assign hash_mask[2] = am_row[2] ^ am_row[5] ^ rowid_array[12] ^ rowid_array[13] ^ rowid_array[14] ^ rowid_array[15] ^ rowid_array[16] ^ rowid_array[17];
assign hash_mask[3] = am_row[3] ^ am_row[4] ^ rowid_array[18] ^ rowid_array[19] ^ rowid_array[20] ^ rowid_array[21] ^ rowid_array[22] ^ rowid_array[23] ;


assign config_bank = am_ba ^ hash_mask;

assign hash_bank_id = ddr_hash_mode == 2'b10 ? config_bank :
                      ddr_hash_mode == 2'b00 ? am_ba :
                      pvr_hash_bank;



endmodule
// Local Variables:
// verilog-library-directories:("./" ) 
// End:
