/*

 * #==========================================================================#
 * |                                                                          |
 * |  Copyright (c) 2022, Fantasy Technologies Limited and/or its         |
 * |  affiliated group companies ("Fantasy"). All rights reserved.        |
 * |  No part of this content, either material or conceptual may be copied    |
 * |  or distributed, transmitted, transcribed, stored in a retrieval system  |
 * |  or translated into any human or computer language in any form by any    |
 * |  means, electronic, mechanical manual, or otherwise, or disclosed to     |
 * |  third parties without the express written permission of Fantasy.    |
 * |                                                                          |
 * #==========================================================================#

 */

// ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////-
// entity name: gpc_gfx_spstore_read_write_pipeline
// purpose: Create a wrapper for a single port-RAM which exposes separate Read and Write interfaces so that it can be both Read and
// Written on the same cycle to give higher throughput compared to a standard single port-RAM which would otherwise suffer from RAM
// contention/clashes.
//
// Internally the module implements a Write Queue inside flops which is used to hide RAM contention and then the Write Queue is
// drained on cycles where the RAM would otherwise be idle. The idea of the module is that it is transparent for any external logic
// which can just assume it is instantaneously Reading and Writing to an array. To do this the component must implement hazard
// detection and write forwarding to ensure that you can never read back stale data due to reading an address for which a Write is
// still in-flight (which now includes the Write Queue), the critical point though is that the intricacies of this are hidden from
// the module driving this component making integration simple.
//
// WR_AFFECT_PREV_RD is used to control whether a Write should only be reflected in the values of data read back by future Reads, or
// when set to true it allows the value being written to be updated in any Reads which are already in-flight (including any return
// data sat on the "read_data" output pins which has not been accepted yet ie read_data_enable is low).
// ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////-



module gpu_core_sp_gfx_spstore_read_write_pipeline_
   import gpc_gfx_rambist_pack_::*;
#(
      parameter int                                      ECC                                                          = 0              ,    // ECC enable : 0=disable ECC; 1=enable ECC



      parameter int                                      id                                                           = 0              ,
      parameter int                                      W                                                            = 64             ,    // Width of write data and read data
      parameter int                                      P                                                            = 32             ,    // Partition width for use by the write enable signal
      parameter int                                      D                                                            = 64             ,    // Depth of ram
      parameter int                                      WQ_D                                                         = 2              ,    // Write Queue Depth
      parameter int                                      RD_DATA_EN                                                   = 0              ,    // Whether the read data enable signal can be toggled by downstream component, 0 indicates it must be held high
      parameter int                                      WR_AFFECT_PREV_RD                                            = 0              ,    // Whether a Write should update a Read which has already been requested and is in the pipeline, 0 indicates that it will not be affected
      parameter int                                      REGISTERED_RD_EN                                             = 0                   // Whether there is a combinatorial path from the Write interface to the Read Enable pin
)
(
      input    logic                                                        clk                                     ,
      input    logic                                                        resetn                                  ,
      input    logic                                                        flush                                   ,
      // Stallable Read Interface
      input    logic                                                        read_valid                              ,
      output   logic                                                        read_enable                             ,
      input    logic [ $clog2 ( D ) - 1 : 0 ]                               read_addr                               ,
      // Return Data (this interface should only be stalled in exceptional circumstances)
      output   logic                                                        read_data_valid                         ,
      input    logic                                                        read_data_enable                        ,
      output   logic [ W - 1 : 0 ]                                          read_data                               ,
      // Non-Stallable Write Interface
      input    logic                                                        write_valid                             ,
      input    logic [ W / P - 1 : 0 ]                                      write_wen                               ,
      input    logic [ $clog2 ( D ) - 1 : 0 ]                               write_addr                              ,
      input    logic [ W - 1 : 0 ]                                          write_data                              ,
      // BIST & Scan






      input    logic [ spstore_in ( W , P , D , ECC ) - 1 : 0 ]             bist_in                                 ,
      output   logic [ spstore_out ( W , P , D , ECC ) - 1 : 0 ]            bist_out                                ,
      input    logic                                                        tst_gclkenable                            
);









   logic                                         read_enable_l                           ;


   logic                                         ram_c_en                                ;
   logic [ W / P - 1 : 0 ]                       ram_wr_en                               ;
   logic                                         ram_rd_en                               ;
   logic [ $clog2 ( D ) - 1 : 0 ]                ram_addr                                ;
   logic [ W - 1 : 0 ]                           ram_wr_data                             ;

   logic [ W / P - 1 : 0 ]                       bypass_load                             ;
   logic [ W - 1 : 0 ]                           bypass_data                             ;

   logic                                         prev_read_valid                         ;
   logic [ $clog2 ( D ) - 1 : 0 ]                prev_read_addr                          ;
   logic [ $clog2 ( D ) - 1 : 0 ]                n_prev_read_addr                        ;

   typedef struct packed { 
         logic  [ W - 1 : 0 ]                                         wdata                                   ;
         logic  [ $clog2 ( D ) - 1 : 0 ]                              addr                                    ;
      } write_queue_entry_record;

   write_queue_entry_record [ WQ_D - 1 : 0 ]     wq_entries                              ;

   logic [ WQ_D - 1 : 0 ] [ W / P - 1 : 0 ]      wq_valid_array                          ;


   logic                                         wq_flush                                ;
   logic [$clog2(WQ_D)-1:0]                      wq_flush_entry                          ;
   logic                                         wq_write_hit                            ;
   logic [$clog2(WQ_D)-1:0]                      wq_write_hit_entry                      ;
   logic                                         wq_full                                 ;
   logic [$clog2(WQ_D)-1:0]                      wq_free_entry                           ;

   logic                                         read_data_valid_l                       ;
   logic                                         read_data_cken                          ;

   logic [ W / P - 1 : 0 ]                       bypass_load_override                    ;
   logic [ W - 1 : 0 ]                           bypass_data_override                    ;
   logic                                         store_stalled_ram_data_valid            ;

   logic                                         stalled_ram_rd_data_valid               ;


   ///////////////////////////////////////////////
   // backdoor access
   ///////////////////////////////////////////////



   ///////////////////////////////////////////////
   ///////////////////////////////////////////////
   // END backdoor access
   ///////////////////////////////////////////////

   // Write Queue Pipeline
   // The following cases exist:
   // 1) Writing a RAM location which is already present in the Write Queue
   // 2) Writing a RAM location which is not in the Write Queue and there is space to write it
   // 3) Writing a RAM location which is not in the Write Queue and there is no free space in the queue to write it

   always_comb begin : p_write_queue_comb
      wq_flush = 1'b0 ;
      wq_flush_entry = 0 ;
      wq_write_hit = 1'b0 ;
      wq_write_hit_entry = 0 ;
      wq_full = 1'b1 ;
      wq_free_entry = 0 ;
      for ( int entry = WQ_D - 1 ; entry >= 0 ; entry = entry - 1 ) begin
         if ( ( | ( wq_valid_array [ entry ] ) ) == 1'b1 ) begin
            wq_flush = 1'b1 ;
            wq_flush_entry = $unsigned(entry);
            if ( write_addr == wq_entries [ entry ] .addr ) begin
               wq_write_hit = 1'b1 ;
               wq_write_hit_entry = $unsigned(entry) ;
            end
         end else begin
            wq_full = 1'b0 ;
            wq_free_entry = $unsigned(entry) ;
         end
      end
   end // p_write_queue_comb

   always_ff @(posedge clk or negedge resetn) begin : p_write_queue_clkdrs
      if ( resetn == 1'b0 ) begin
         wq_valid_array <= '0 ;
      end else begin
         if ( ( & ram_wr_en ) == 1'b0 ) begin
            wq_valid_array [ wq_flush_entry ] <= '0 ;
         end
         if ( write_valid == 1'b1 ) begin
            if ( wq_write_hit == 1'b1 ) begin
               if(wq_write_hit_entry < WQ_D) begin
                  wq_valid_array [ wq_write_hit_entry ] <= wq_valid_array [ wq_write_hit_entry ] | ~ write_wen ;    // COV:tag16
               end
            end else if(wq_free_entry < WQ_D) begin
               wq_valid_array [ wq_free_entry ] <= ~ write_wen ;
            end
         end
         if ( flush == 1'b1 ) begin    // COV:tag8
            wq_valid_array <= '0 ;    // COV:tag1
         end
      end
   end // p_write_queue_clkdrs

   always_ff @(posedge clk) begin : p_write_queue_clkd
      begin
         if ( write_valid == 1'b1 & wq_write_hit == 1'b1 ) begin    // COV:tag23
            for ( int entry = WQ_D - 1 ; entry >= 0 ; entry = entry - 1 ) begin    // COV:tag14
               if ( entry == wq_write_hit_entry ) begin    // COV:tag14
                  for ( int word = W / P - 1 ; word >= 0 ; word = word - 1 ) begin    // COV:tag14
                     if ( write_wen [ word ] == 1'b0 ) begin    // COV:tag14
                        wq_entries [ entry ] .wdata [ word * P  +: P ] <= write_data [ word * P  +: P ] ;    // COV:tag14
                     end
                  end
               end
            end
         end else if ( write_valid == 1'b1 ) begin
            for ( int entry = WQ_D - 1 ; entry >= 0 ; entry = entry - 1 ) begin
               if ( entry == wq_free_entry ) begin
                  wq_entries [ entry ] .addr <= write_addr ;
                  for ( int word = W / P - 1 ; word >= 0 ; word = word - 1 ) begin
                     if ( write_wen [ word ] == 1'b0 ) begin
                        wq_entries [ entry ] .wdata [ word * P  +: P ] <= write_data [ word * P  +: P ] ;
                     end
                  end
               end
            end
         end
      end
   end // p_write_queue_clkd

   // Read Pipeline
   // The following cases exist:
   // 1) Reading a RAM location which is waiting to be updated by a Write Queue entry
   // 2) Reading a RAM location which is written to on this clock cycle
   // 3) There is no contention over RAM addresses at all

   assign n_prev_read_addr = read_valid == 1'b1 & read_enable_l == 1'b1 ? read_addr : prev_read_addr  ;    // COV:tag12 


   if ( WR_AFFECT_PREV_RD == 0 ) begin : g_no_wr_affect_prev_rd

      always_ff @(posedge clk or negedge resetn) begin : p_read_pipeline_clkdrs
         if ( resetn == 1'b0 ) begin
            prev_read_valid <= 1'b0 ;
            prev_read_addr <= '0 ;
            read_data_valid_l <= 1'b0 ;
         end else begin
            if ( ( read_valid == 1'b1 & read_enable_l == 1'b1 ) | prev_read_valid == 1'b1 | read_data_valid_l == 1'b1 ) begin    // COV:tag11
               prev_read_valid <= ( read_valid & read_enable_l ) | ( prev_read_valid & read_data_valid_l & ~ read_data_enable & ~ store_stalled_ram_data_valid ) ;    // COV:tag17
               prev_read_addr <= n_prev_read_addr ;
               read_data_valid_l <= prev_read_valid | stalled_ram_rd_data_valid | ( read_data_valid_l & ~ read_data_enable ) ;    // COV:tag18
            end
         end
      end // p_read_pipeline_clkdrs

   end // g_no_wr_affect_prev_rd

   if ( WR_AFFECT_PREV_RD == 1 ) begin : g_wr_affect_prev_rd

      always_ff @(posedge clk or negedge resetn) begin : p_read_pipeline_clkdrs
         if ( resetn == 1'b0 ) begin
            prev_read_valid <= 1'b0 ;
            prev_read_addr <= '0 ;
            read_data_valid_l <= 1'b0 ;
         end else begin
            if ( ( read_valid == 1'b1 & read_enable_l == 1'b1 ) | prev_read_valid == 1'b1 | read_data_valid_l == 1'b1 ) begin    // COV:tag10
               prev_read_valid <= ( read_valid & read_enable_l ) | ( prev_read_valid & read_data_valid_l & ~ read_data_enable & ~ store_stalled_ram_data_valid ) ;    // COV:tag3
               prev_read_addr <= n_prev_read_addr ;
               read_data_valid_l <= prev_read_valid | stalled_ram_rd_data_valid | ( read_data_valid_l & ~ read_data_enable ) ;    // COV:tag5
            end
         end
      end // p_read_pipeline_clkdrs

   end // g_wr_affect_prev_rd

   always_comb begin : p_read_pipeline_comb  
      bypass_load = '0 ;
      bypass_data = wq_entries [ 0 ] .wdata ;
      // Examine all the entries in the Write Queue on the cycle that the Read is about to be registered, if any entries contain data
      // for the same address then use these to forward the data onto the read pins so that it is updated with the queued write data
      if ( prev_read_valid == 1'b1 & wq_flush == 1'b1 ) begin
         for ( int entry = WQ_D - 1 ; entry >= 0 ; entry = entry - 1 ) begin
            if ( ( | ( wq_valid_array [ entry ] ) ) == 1'b1 & prev_read_addr == wq_entries [ entry ] .addr ) begin
               for ( int word = W / P - 1 ; word >= 0 ; word = word - 1 ) begin
                  if ( wq_valid_array [ entry ] [ word ] == 1'b1 ) begin
                     bypass_load [ word ] = 1'b1 ;
                  end
               end
               bypass_data = wq_entries [ entry ] .wdata ;
            end
         end
      end
      if ( prev_read_valid == 1'b1 & write_valid == 1'b1 & prev_read_addr == write_addr & WR_AFFECT_PREV_RD == 1 ) begin    // COV:tag13
         for ( int word = W / P - 1 ; word >= 0 ; word = word - 1 ) begin    // COV:tag10
            if ( write_wen [ word ] == 1'b0 ) begin    // COV:tag9
               bypass_load [ word ] = 1'b1 ;    // COV:tag10
               bypass_data [ word * P  +: P ] = write_data [ word * P  +: P ] ;
            end
         end
      end
   end // p_read_pipeline_comb

   if ( RD_DATA_EN == 0 ) begin : g_no_rdata_enable







      assign bypass_load_override = bypass_load ;
      assign bypass_data_override = bypass_data ;
      assign stalled_ram_rd_data_valid = 1'b0 ;
      assign store_stalled_ram_data_valid = 1'b0 ;

      gpu_core_sp_gfx_spstore_flexible_gen_bist_r_
         #(
            .w                               (W)                                          ,
            .p                               (P)                                          ,
            .d                               (D)                                          ,
            .log2d                           ($clog2 ( D ))                               ,
            .ECC                             (ECC)                                        ,



            .id                              (id)                                         ,
            .bypass_requires_cken            (0)                                           
            )
         i_gpu_core_sp_gfx_spstore_flexible_gen_bist_r
         (
            .clk                             (clk)                                        ,
            .resetn                          (resetn)                                     ,
            // read/write port
            .c_en                            (ram_c_en)                                   ,
            .wr_en                           (ram_wr_en)                                  ,
            .rd_en                           (ram_rd_en)                                  ,
            .addr                            (ram_addr)                                   ,
            .wr_data                         (ram_wr_data)                                ,
            // unregistered output
            .ram_data                        ()                                           ,
            // registered output and associated controls
            .bypass_load                     (bypass_load_override)                       ,
            .bypass_data                     (bypass_data_override)                       ,
            .rd_data_cken                    (read_data_cken)                             ,
            .rd_data                         (read_data)                                  ,
            // BIST & Scan






            .bist_in                         (bist_in)                                    ,
            .bist_out                        (bist_out)                                   ,
            .tst_gclkenable                  (tst_gclkenable)                               
            );

   end // g_no_rdata_enable

   if ( RD_DATA_EN == 1 ) begin : g_rdata_enable
      logic                                         write_to_addr_on_read_data_pins         ;
      logic [ W - 1 : 0 ]                           ram_rd_data                             ;
      logic [ $clog2 ( D ) - 1 : 0 ]                stalled_ram_rd_addr                     ;
      logic [ W - 1 : 0 ]                           stalled_ram_rd_data                     ;






    
      if ( WR_AFFECT_PREV_RD == 0 ) begin : g_rd_data_en_and_no_wr_affect_prev_rd
         assign write_to_addr_on_read_data_pins = 1'b0 ;
      end // g_rd_data_en_and_no_wr_affect_prev_rd

      if ( WR_AFFECT_PREV_RD == 1 ) begin : g_rd_data_en_and_wr_affect_prev_rd
         logic [ $clog2 ( D ) - 1 : 0 ]                read_data_addr                          ;
         logic [ $clog2 ( D ) - 1 : 0 ]                n_read_data_addr                        ;

         assign n_read_data_addr = read_data_valid_l == 1'b1 & read_data_enable == 1'b0 ? read_data_addr : stalled_ram_rd_data_valid == 1'b1 ? stalled_ram_rd_addr : prev_read_addr   ;    // COV:tag10 COV:tag20 

         always_ff @(posedge clk or negedge resetn) begin : p_read_pipeline_clkdrs
            if ( resetn == 1'b0 ) begin    // COV:tag10
               read_data_addr <= '0 ;    // COV:tag10
            end else begin
               if ( ( read_valid == 1'b1 & read_enable_l == 1'b1 ) | prev_read_valid == 1'b1 | read_data_valid_l == 1'b1 ) begin    // COV:tag10
                  read_data_addr <= n_read_data_addr ;    // COV:tag10
               end
            end
         end // p_read_pipeline_clkdrs

         assign write_to_addr_on_read_data_pins = read_data_valid_l == 1'b1 & read_data_enable == 1'b0 & read_data_addr == write_addr ? write_valid : 1'b0  ;    // COV:tag10 
      end // g_rd_data_en_and_wr_affect_prev_rd



      // Store the data on the RAM pins either when it is about to be destroyed by a write from the write queue being flushed out or
      // when the address being written matches a previous read and the generic is set to false to ensure the forwarding logic
      // cannot update the contents of the read
      assign store_stalled_ram_data_valid = ( wq_flush == 1'b1 | ( prev_read_addr == write_addr & write_valid == 1'b1 & WR_AFFECT_PREV_RD == 0 ) ) ? prev_read_valid & read_data_valid_l & ~ read_data_enable : 1'b0  ;    // COV:tag21  

      always_ff @(posedge clk or negedge resetn) begin : p_stalled_ram_data_clkdrs
         if ( resetn == 1'b0 ) begin
            stalled_ram_rd_data_valid <= 1'b0 ;
            stalled_ram_rd_addr <= '0 ;
         end else begin

            if ( store_stalled_ram_data_valid == 1'b1 ) begin    // COV:tag7
               stalled_ram_rd_data_valid <= 1'b1 ;    // COV:tag7
               stalled_ram_rd_addr <= prev_read_addr ;
            end else if ( stalled_ram_rd_data_valid == 1'b1 & read_data_enable == 1'b1 ) begin    // COV:tag22
               stalled_ram_rd_data_valid <= 1'b0 ;    // COV:tag7
               stalled_ram_rd_addr <= prev_read_addr ;
            end

         end
      end // p_stalled_ram_data_clkdrs

      always_ff @(posedge clk) begin : p_stalled_ram_data_clkd
         begin

            if ( store_stalled_ram_data_valid == 1'b1 ) begin    // COV:tag7
               stalled_ram_rd_data <= ram_rd_data ;    // COV:tag7
               for ( int word = W / P - 1 ; word >= 0 ; word = word - 1 ) begin
                  if ( bypass_load [ word ] == 1'b1 ) begin    // COV:tag7
                     stalled_ram_rd_data [ word * P  +: P ] <= bypass_data [ word * P  +: P ] ;    // COV:tag7
                  end
               end
            end

            // Update registers if a Write with the same address comes in whilst contents are valid
            if ( stalled_ram_rd_data_valid == 1'b1 & write_valid == 1'b1 & stalled_ram_rd_addr == write_addr & WR_AFFECT_PREV_RD == 1 & read_data_enable == 1'b0 ) begin    // COV:tag24
               for ( int word = W / P - 1 ; word >= 0 ; word = word - 1 ) begin    // COV:tag29
                  if ( write_wen [ word ] == 1'b0 ) begin    // COV:tag30
                     stalled_ram_rd_data [ word * P  +: P ] <= write_data [ word * P  +: P ] ;    // COV:tag30
                  end
               end
            end

         end
      end // p_stalled_ram_data_clkd

      always_comb begin : p_bypass_override_comb      
         bypass_load_override = '0 ;
         if ( read_data_cken == 1'b1 ) begin
            bypass_load_override = bypass_load ;
         end
         bypass_data_override = bypass_data ;
         if ( stalled_ram_rd_data_valid == 1'b1 & read_data_cken == 1'b1 ) begin    // COV:tag25
            bypass_load_override = '1 ;    // COV:tag7
            bypass_data_override = stalled_ram_rd_data ;
         end
         if ( stalled_ram_rd_data_valid == 1'b1 & write_valid == 1'b1 & stalled_ram_rd_addr == write_addr & WR_AFFECT_PREV_RD == 1 ) begin    // COV:tag26
            for ( int word = W / P - 1 ; word >= 0 ; word = word - 1 ) begin    // COV:tag10
               if ( write_wen [ word ] == 1'b0 ) begin    // COV:tag7
                  bypass_data_override [ word * P  +: P ] = write_data [ word * P  +: P ] ;    // COV:tag10
               end
            end
         end
         if ( write_to_addr_on_read_data_pins == 1'b1 ) begin
            for ( int word = W / P - 1 ; word >= 0 ; word = word - 1 ) begin    // COV:tag7
               if ( write_wen [ word ] == 1'b0 ) begin    // COV:tag7
                  // This is the one occasion where we do want to update the data even though read_data_cken is low
                  bypass_load_override [ word ] = 1'b1 ;    // COV:tag7
                  bypass_data_override [ word * P  +: P ] = write_data [ word * P  +: P ] ;
               end
            end
         end
      end // p_bypass_override_comb

      gpu_core_sp_gfx_spstore_flexible_gen_bist_r_
         #(
            .w                               (W)                                          ,
            .p                               (P)                                          ,
            .d                               (D)                                          ,
            .log2d                           ($clog2 ( D ))                               ,
            .ECC                             (ECC)                                        ,



            .id                              (id)                                         ,
            .bypass_requires_cken            (0)                                           
            )
         i_gpu_core_sp_gfx_spstore_flexible_gen_bist_r
         (
            .clk                             (clk)                                        ,
            .resetn                          (resetn)                                     ,
            // read/write port
            .c_en                            (ram_c_en)                                   ,
            .wr_en                           (ram_wr_en)                                  ,
            .rd_en                           (ram_rd_en)                                  ,
            .addr                            (ram_addr)                                   ,
            .wr_data                         (ram_wr_data)                                ,
            // unregistered output
            .ram_data                        (ram_rd_data)                                ,
            // registered output and associated controls
            .bypass_load                     (bypass_load_override)                       ,
            .bypass_data                     (bypass_data_override)                       ,
            .rd_data_cken                    (read_data_cken)                             ,
            .rd_data                         (read_data)                                  ,
            // BIST & Scan






            .bist_in                         (bist_in)                                    ,
            .bist_out                        (bist_out)                                   ,
            .tst_gclkenable                  (tst_gclkenable)                               
            );

   end // g_rdata_enable

   if ( REGISTERED_RD_EN == 0 ) begin : g_combinatorial_paths_from_write_valid
      logic                                         write_when_wq_full                      ;


      assign write_when_wq_full = write_valid == 1'b1 & wq_write_hit == 1'b0 & wq_full == 1'b1 ? 1'b1 : 1'b0  ;    // COV:tag15

      // Stall reading when writes occur and the write queue is full, or if the output enable drops, otherwise allow to proceed
      assign read_enable_l = write_when_wq_full == 1'b1 | read_data_enable == 1'b0 ? 1'b0 : 1'b1  ;    // COV:tag27

      always_comb begin
         ram_wr_en   = '1;
         ram_addr    = read_addr;
         ram_rd_en   = 1'b0;
         
         if((wq_flush_entry < WQ_D) && (write_when_wq_full == 1'b1 || read_valid == 1'b0 || read_data_enable == 1'b0)) begin
            ram_wr_en   = ~wq_valid_array[wq_flush_entry];
            ram_addr    = wq_entries[wq_flush_entry].addr;
            ram_rd_en   = 1'b1;
         end
      end

   end // g_combinatorial_paths_from_write_valid
   
   else begin : g_decouple_write_valid_from_reads //REGISTERED_RD_EN == 1

      // Stall reading when write queue is full, or if the output enable drops, otherwise allow to proceed
      assign read_enable_l = wq_full == 1'b1 | read_data_enable == 1'b0 ? 1'b0 : 1'b1  ;    // COV:tag4

      always_comb begin
         ram_wr_en   = '1;
         ram_addr    = read_addr;
         ram_rd_en   = 1'b0;
         
         if((wq_flush_entry < WQ_D) && (wq_full == 1'b1 || read_valid == 1'b0 || read_data_enable == 1'b0)) begin
            ram_wr_en   = ~wq_valid_array[wq_flush_entry];
            ram_addr    = wq_entries[wq_flush_entry].addr;
            ram_rd_en   = 1'b1;
         end
      end

   end // g_decouple_write_valid_from_reads

   assign read_enable = read_enable_l ;

   // RAM Control signals
   assign ram_c_en = ( read_valid == 1'b1 & read_data_enable == 1'b1 ) | wq_flush == 1'b1 ? 1'b0 : 1'b1  ;    // COV:tag2

   assign ram_wr_data = wq_flush_entry < WQ_D ? wq_entries[wq_flush_entry].wdata : {W{1'b0}};

   assign read_data_cken = read_data_enable | ~ read_data_valid_l ;    // COV:tag6

   // Assign output from local copy
   assign read_data_valid = read_data_valid_l ;

endmodule // gpc_gfx_spstore_read_write_pipeline
