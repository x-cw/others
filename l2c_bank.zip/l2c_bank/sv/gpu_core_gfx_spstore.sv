/*

 * #==========================================================================#
 * |                                                                          |
 * |  Copyright (c) 2022, Fantasy Technologies Limited and/or its         |
 * |  affiliated group companies ("Fantasy"). All rights reserved.        |
 * |  No part of this content, either material or conceptual may be copied    |
 * |  or distributed, transmitted, transcribed, stored in a retrieval system  |
 * |  or translated into any human or computer language in any form by any    |
 * |  means, electronic, mechanical manual, or otherwise, or disclosed to     |
 * |  third parties without the express written permission of Fantasy.    |
 * |                                                                          |
 * #==========================================================================#

 */

module gpu_core_gfx_spstore
//spyglass disable_block -rule "W240"
//spyglass disable_block -rule "W175"
//spyglass disable_block -rule "W241"
#(
      parameter w       = 8,  // Data width
      parameter p       = 8,  // Word partition size (data bits per WEN)
      parameter d       = 8,  // Data depth
      parameter log2d   = 3,  // Address width
      parameter id      = 0   // unique value per instance
 )
 (
     input  logic             CLK,
     input  logic             CEN,
     input  logic [(w/p)-1:0] WEN,
     input  logic [log2d-1:0] A,
     input  logic [w-1:0]     DI,
     output logic [w-1:0]     Q,
     input  logic             TE,
     output logic [2:0]       L2M,//log2(Mux width)
     output logic             SRAM// Ram type is sram
);

// initial begin
//   $display("memory used in gfx sp: %d,%d,%d,%d",d,w,p,id);
// //   $display("memory used in gfx sp %m: %d,%d,%d,%d",d,w,p,id);
// end

   localparam NUM_PARTITIONS = w/p;
`ifdef  EMU_2D_SRAM
// Change 3D-Array to 2D-Array for resource opt in palladium. By Wu Cheng`en @May-6-2025
//Used in FPGA and palladium env.
   logic [w-1:0]                     ram_core[d-1:0];
   //read process   
   for (genvar part = 0; part<NUM_PARTITIONS; part++) begin : g_ram_rd
      always_ff@(posedge CLK) begin : ram_rd
         if(CEN==1'b0 && WEN[part]==1'b1) begin
            Q[part*p +: p] <= ram_core[A][part*p +: p];
         end         
      end
   end

   //write process   
   for (genvar part = 0; part<NUM_PARTITIONS; part++) begin : g_ram_wr
      always_ff@(posedge CLK) begin : ram_wr
         if(CEN==1'b0 && WEN[part]==1'b0) begin //COV:tag1
            begin
               //store X at targetted address for this partition
               ram_core[A][part*p +: p] <= DI[part*p +: p];
            end
         end
      end
   end
`elsif GPU_SYNTHESIS
//Used in DC env. This file is replaced to SRAM DB in DC env.

`else
//Original RTL, used in VCS env.
   import gpu_core_gfx_backdoor_pkg_::*;
   logic [NUM_PARTITIONS-1:0][d-1:0][p-1:0] ram_core;

   ///////////////////////////////////////////////
   // backdoor access
   ///////////////////////////////////////////////  

   ///////////////////////////////////////////////
   // END backdoor access
   ///////////////////////////////////////////////

   assign L2M = 3'b0;
   assign SRAM = 1'b1;

   //read process   
   for (genvar part = 0; part<NUM_PARTITIONS; part++) begin : g_ram_rd
      always_ff@(posedge CLK) begin : ram_rd
         if(CEN==1'b0 && WEN[part]==1'b1) begin
            Q[part*p +: p] <= ram_core[part][A];
         end         
      end
   end

   //write process   
   for (genvar part = 0; part<NUM_PARTITIONS; part++) begin : g_ram_wr
      always_ff@(posedge CLK) begin : ram_wr
         if(CEN==1'b0 && WEN[part]==1'b0) begin //COV:tag1
            begin
               //store X at targetted address for this partition
               ram_core[part][A] <= DI[part*p +: p];
            end
         end
      end
   end

   // synopsys translate_off

   ////////////////////////////////////////////////   
   // CONFIGURATION CHECKS
   ////////////////////////////////////////////////   
   initial begin : p_sanity_check_l2d_clkd
      as_rtl_dpstore_log2d_valid: assert ($clog2(d) == log2d) else 
         $error("ERROR gpu_core_gfx_spstore in hierarchy %m: log2d(%0d) does not match depth(%0d)", log2d, d);
      //width is an integer multiple of partition size
      as_rtl_dpstore_w_p_valid: assert (NUM_PARTITIONS * p == w) else
         $error("ERROR gpu_core_gfx_spstore in hierarchy %m: width(%0d) is not an integer multiple of partition width(%0d)", w, p);
   end

   ////////////////////////////////////////////////   
   // READ PORT A CHECKS
   ////////////////////////////////////////////////   
   always@(posedge CLK) begin : p_checks
      //do not check at time 0
      if($time > 0) begin
         

         //CEN not X
         as_rtl_spstore_cen_not_x: assert(~$isunknown(CEN)) else
            $error("CEN input is X in module gpu_core_gfx_spstore in hierarchy %m");

         //WEN not X
         as_rtl_spstore_wen_not_x: assert(CEN || ~$isunknown(WEN)) else
            $error("WEN input is X in module gpu_core_gfx_spstore in hierarchy %m");
         
         //address not X, or not enabled
         as_rtl_spstore_a_not_x: assert(CEN || ~$isunknown(A)) else
            $error("A input is X in module gpu_core_gfx_spstore in hierarchy %m");











         //address less than depth, or not enabled (dont trigger if 'A' is X though, covered above)
         as_rtl_spstore_a_in_range: assert(CEN || $isunknown(A) || (A < d) || ((id == 102000 || id == 102001 || id == 51000 || id == 64001 || id == 55000 || id == 55005))) else
            $error("A input is out of range in module gpu_core_gfx_spstore in hierarchy %m");

      end   
   end : p_checks

   
   // synopsys translate_on

`endif

//spyglass enable_block -rule "W241"
//spyglass enable_block -rule "W175"
//spyglass enable_block -rule "W240"

endmodule
