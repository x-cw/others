/*

*/

// ----------------------------------------------------------------------------------------------
// entity name: gc_l2_bank
// purpose: L2 bank top module, juset including logic module, no crm and ipg
// ----------------------------------------------------------------------------------------------

module gc_l2_bank
import axi5_ar_pkg::*;
import axi5_r_pkg::*;
import axi5_aw_pkg::*;
import axi5_w_pkg::*;
import axi5_b_pkg::*;
import gc_l2_bank_pkg::*;
import nsp_req_pkg::*;
import nsp_rsp_pkg::*;
import bank_sched_pkg::*;
import sched_bank_pkg::*;
(
    // global interface
    input   logic       clk,
    input   logic       resetn,
    output  logic       l2_bank_idle,
    // AXI slave AR-channel
    input   logic                           axi_slv_arvalid,
    output  logic                           axi_slv_arready,
    input   axi5_ar_data_bus_t              axi_slv_ar_rec,
    // AXI slave R-channel
    output  logic                           axi_slv_rvalid,
    input   logic                           axi_slv_rready,
    output  axi5_r_data_bus_t               axi_slv_r_rec,
    // AXI slave AW-channel
    input   logic                           axi_slv_awvalid,
    output  logic                           axi_slv_awready,
    input   axi5_aw_data_bus_t              axi_slv_aw_rec,
    // AXI slave W-channel
    input   logic                           axi_slv_wvalid,
    output  logic                           axi_slv_wready,
    input   axi5_w_data_bus_t               axi_slv_w_rec,
    // AXI slave B-channel
    output  logic                           axi_slv_bvalid,
    input   logic                           axi_slv_bready,
    output  axi5_b_data_bus_t               axi_slv_b_rec,
    // memory scheduler and NSP interface
    output  logic                           memif_sched_valid,
    input   logic                           memif_sched_ready,
    output  bank_sched_data_bus_t           memif_sched_rec,
    input   logic                           sched_memif_valid,
    output  logic                           sched_memif_ready,
    input   sched_bank_data_bus_t           sched_memif_rec,

    output  logic                           nsp_req_valid,
    input   logic                           nsp_req_ready,
    output  nsp_req_data_bus_t              nsp_req_rec,
    input   logic                           nsp_rsp_valid,
    output  logic                           nsp_rsp_ready,
    input   nsp_rsp_data_bus_t              nsp_rsp_rec,

    // configure register
    input   logic                           gc_cr_l2_cmd_notify,
    input   logic                           gc_cr_l2_cmd_persistence_rst_all,
    input   logic                           gc_cr_l2_cmd_cfi_clr,
    input   logic                           gc_cr_l2_cfi_operation_notify,
    input   logic [ 1 : 0 ]                 gc_cr_l2_cfi_operation,
    input   logic [ 1 : 0 ]                 gc_cr_l2_buffer_mode_buffer_mode_percentage,
    output  logic [ 2 : 0 ]                 gc_cr_l2g_error_l2b,
    output  logic                           gc_cr_l2_cfi_statusi_l2b_finish,
    input   logic                           gc_cr_l2_persistence_reduce_enable,
    input   logic [ 20 : 0 ]                gc_cr_l2_persistence_reduce_threshold,
    input   logic                           gc_cr_l2_function_enable_bypass_mode,
    input   logic                           gc_cr_cu_lms_fp32_denormal_en,
    input   logic                           gc_l2_mem_scheduler_enable,   

    input   logic [ 3 : 0 ]                 gc_cr_l2_function_enable_ddr_capacity       , 
    input   logic [ 4 : 0 ]                 gc_cr_l2_mem_sched_bank_offset_bank_id_bit0 ,
    input   logic [ 4 : 0 ]                 gc_cr_l2_mem_sched_bank_offset_bank_id_bit1 ,
    input   logic [ 4 : 0 ]                 gc_cr_l2_mem_sched_bank_offset_bank_id_bit2 ,
    input   logic [ 4 : 0 ]                 gc_cr_l2_mem_sched_bank_offset_bank_id_bit3 ,
    input   logic [ 4 : 0 ]                 gc_cr_l2_mem_sched_bank_offset_bank_id_bit4 ,
    
    input   logic [ 4 : 0 ]                 gc_cr_l2_mem_sched_row_parti_row_id_bit0    ,
    input   logic [ 4 : 0 ]                 gc_cr_l2_mem_sched_row_parti_row_id_bit1    ,
    input   logic [ 4 : 0 ]                 gc_cr_l2_mem_sched_row_parti_row_id_bit2    ,
    input   logic [ 4 : 0 ]                 gc_cr_l2_mem_sched_row_parti_row_id_bit3    ,
    input   logic [ 4 : 0 ]                 gc_cr_l2_mem_sched_row_parti_row_id_bit4    ,
    input   logic [ 4 : 0 ]                 gc_cr_l2_mem_sched_row_parti_row_id_bit5    ,
    input   logic [ 4 : 0 ]                 gc_cr_l2_mem_sched_row_parti_row_id_bit6    ,
    input   logic [ 4 : 0 ]                 gc_cr_l2_mem_sched_row_parti_row_id_bit7    ,
    input   logic [ 4 : 0 ]                 gc_cr_l2_mem_sched_row_partii_row_id_bit8   ,
    input   logic [ 4 : 0 ]                 gc_cr_l2_mem_sched_row_partii_row_id_bit9   ,
    input   logic [ 4 : 0 ]                 gc_cr_l2_mem_sched_row_partii_row_id_bit10  ,
    input   logic [ 4 : 0 ]                 gc_cr_l2_mem_sched_row_partii_row_id_bit11  ,
    input   logic [ 4 : 0 ]                 gc_cr_l2_mem_sched_row_partii_row_id_bit12  ,
    input   logic [ 4 : 0 ]                 gc_cr_l2_mem_sched_row_partii_row_id_bit13  ,
    input   logic [ 4 : 0 ]                 gc_cr_l2_mem_sched_row_partii_row_id_bit14  ,
    input   logic [ 4 : 0 ]                 gc_cr_l2_mem_sched_row_partii_row_id_bit15  ,
    input   logic [ 4 : 0 ]                 gc_cr_l2_mem_sched_row_partiii_row_id_bit16 ,
    input   logic [ 4 : 0 ]                 gc_cr_l2_mem_sched_row_partiii_row_id_bit17 ,
    input   logic [ 3 : 0 ]                 gc_cr_ddr_hash_config_reg0_row_id_bit0        ,
    input   logic [ 3 : 0 ]                 gc_cr_ddr_hash_config_reg0_row_id_bit1        ,
    input   logic [ 3 : 0 ]                 gc_cr_ddr_hash_config_reg0_row_id_bit2        ,
    input   logic [ 3 : 0 ]                 gc_cr_ddr_hash_config_reg0_row_id_bit3        ,
    input   logic [ 3 : 0 ]                 gc_cr_ddr_hash_config_reg0_row_id_bit4        ,
    input   logic [ 3 : 0 ]                 gc_cr_ddr_hash_config_reg0_row_id_bit5        ,
    input   logic [ 3 : 0 ]                 gc_cr_ddr_hash_config_reg0_row_id_bit6        ,
    input   logic [ 3 : 0 ]                 gc_cr_ddr_hash_config_reg0_row_id_bit7        ,
    input   logic [ 3 : 0 ]                 gc_cr_ddr_hash_config_reg0_row_id_bit8        ,
    input   logic [ 3 : 0 ]                 gc_cr_ddr_hash_config_reg0_row_id_bit9        ,
    input   logic [ 3 : 0 ]                 gc_cr_ddr_hash_config_reg0_row_id_bit10       ,
    input   logic [ 3 : 0 ]                 gc_cr_ddr_hash_config_reg0_row_id_bit11       ,
    input   logic [ 3 : 0 ]                 gc_cr_ddr_hash_config_reg1_row_id_bit12       ,
    input   logic [ 3 : 0 ]                 gc_cr_ddr_hash_config_reg1_row_id_bit13       ,
    input   logic [ 3 : 0 ]                 gc_cr_ddr_hash_config_reg1_row_id_bit14       ,
    input   logic [ 3 : 0 ]                 gc_cr_ddr_hash_config_reg1_row_id_bit15       ,
    input   logic [ 3 : 0 ]                 gc_cr_ddr_hash_config_reg1_row_id_bit16       ,
    input   logic [ 3 : 0 ]                 gc_cr_ddr_hash_config_reg1_row_id_bit17       ,
    input   logic [ 3 : 0 ]                 gc_cr_ddr_hash_config_reg1_row_id_bit18       ,
    input   logic [ 3 : 0 ]                 gc_cr_ddr_hash_config_reg1_row_id_bit19       ,
    input   logic [ 3 : 0 ]                 gc_cr_ddr_hash_config_reg1_row_id_bit20       ,
    input   logic [ 3 : 0 ]                 gc_cr_ddr_hash_config_reg1_row_id_bit21       ,
    input   logic [ 3 : 0 ]                 gc_cr_ddr_hash_config_reg1_row_id_bit22       ,
    input   logic [ 3 : 0 ]                 gc_cr_ddr_hash_config_reg1_row_id_bit23       ,
    input   logic [ 1 : 0 ]                 gc_cr_l2_function_enable_hash_mode            ,
    // performance counter
    output  logic                           l2b_busy                        ,
    output  logic                           l2b_fromaxi_ar_wl               ,
    output  logic                           l2b_fromaxi_ar_bl_eq0_wl        ,
    output  logic                           l2b_fromaxi_ar_bl_eq1_wl        ,
    output  logic                           l2b_fromaxi_ar_bl_eq2_wl        ,
    output  logic                           l2b_fromaxi_ar_bl_eq3_wl        ,
    output  logic                           l2b_fromaxi_ar_bp               ,
    output  logic                           l2b_toaxi_r_wl                  ,
    output  logic                           l2b_toaxi_r_bp                  ,
    output  logic                           l2b_fromaxi_aw_wl               ,
    output  logic                           l2b_fromaxi_aw_bl_eq0_wl        ,
    output  logic                           l2b_fromaxi_aw_bl_eq1_wl        ,
    output  logic                           l2b_fromaxi_aw_bl_eq2_wl        ,
    output  logic                           l2b_fromaxi_aw_bl_eq3_wl        ,
    output  logic                           l2b_fromaxi_aw_bp               ,
    output  logic                           l2b_fromaxi_w_wl                ,
    output  logic                           l2b_fromaxi_w_bp                ,
    output  logic                           l2b_fromaxi_smp_read_req_num    ,
    output  logic                           l2b_fromaxi_smp_read_req_sum    ,
    output  logic                           l2b_fromaxi_smp_write_req_num   ,
    output  logic                           l2b_fromaxi_smp_write_req_sum   ,
    output  logic                           l2b_fromaxi_smp_atomic_req_num  ,
    output  logic                           l2b_fromaxi_smp_atomic_req_sum  ,
    output  logic                           l2b_align_awdb_full             ,
    output  logic                           l2b_hittest_ht_bypass_read_wl   ,
    output  logic                           l2b_hittest_ht_cache_read_wl    ,
    output  logic                           l2b_hittest_ht_bypass_write_wl  ,
    output  logic                           l2b_hittest_ht_cache_write_wl   ,
    output  logic                           l2b_hittest_ht_atomic_wl        ,
    output  logic                           l2b_hittest_ht_bps_hit_wl       ,
    output  logic                           l2b_hittest_ht_miss_wl          ,
    output  logic                           l2b_frommemsch_nsp_rtn_wl       ,
    output  logic                           l2b_frommemsch_nsp_rtn_bp       ,
    output  logic                           l2b_tomemsch_nsp_read_bl_eq1_wl ,
    output  logic                           l2b_tomemsch_nsp_read_bl_eq3_wl ,
    output  logic                           l2b_tomemsch_nsp_read_bl_eq5_wl ,
    output  logic                           l2b_tomemsch_nsp_read_bl_eq7_wl ,
    output  logic                           l2b_tomemsch_nsp_write_bl_eq1_wl,
    output  logic                           l2b_tomemsch_nsp_write_bl_eq3_wl,
    output  logic                           l2b_tomemsch_nsp_write_bl_eq5_wl,
    output  logic                           l2b_tomemsch_nsp_write_bl_eq7_wl,
    output  logic                           l2b_memif_to_ddr_read_wl        ,
    output  logic                           l2b_memif_to_ddr_read_stall_by_rob          ,
    output  logic                           l2b_memif_to_ddr_read_stall_by_ddr          ,
    output  logic                           l2b_memif_to_ddr_read_stall_by_trid         ,
    output  logic                           l2b_memif_to_ddr_write_wl                   ,
    output  logic                           l2b_memif_to_ddr_write_stall_by_data_sync   ,
    output  logic                           l2b_memif_to_ddr_write_stall_by_ddr         ,
    output  logic                           l2b_memif_to_ddr_write_stall_by_trid        ,
    output  logic                           l2b_memif_memreq_full                       ,
    output  logic                           l2b_memif_smp_read_req_num                  ,
    output  logic                           l2b_memif_smp_read_req_sum                  ,
    output  logic                           l2b_reqsch_sortq_full                       ,
    output  logic                           l2b_reqsch_sortq_stall_but_not_full         ,
    output  logic                           l2b_reqsch_disp_wl                          ,
    output  logic                           l2b_reqsch_disp_stall                       ,
    output  logic                           l2b_ramctrl_0_reqarb_wl                     ,
    output  logic                           l2b_ramctrl_0_reqarb_stall_by_sram          ,
    output  logic                           l2b_ramctrl_0_data_sram_read_wl             ,
    output  logic                           l2b_ramctrl_0_data_sram_write_wl            ,
    output  logic                           l2b_ramctrl_1_reqarb_wl                     ,
    output  logic                           l2b_ramctrl_1_reqarb_stall_by_sram          ,
    output  logic                           l2b_ramctrl_1_data_sram_read_wl             ,
    output  logic                           l2b_ramctrl_1_data_sram_write_wl            ,

    input   logic                           tst_gclkenable
);

localparam int L2_BANK_NUM_IDLE = 8;

// ----------------------------------------------------------------------------------------------
//  internal signal define instance
// ----------------------------------------------------------------------------------------------
logic                                                   align_idle                       ;
logic                                                   tagctrl_idle                     ;
logic                                                   memif_idle                       ;
logic                                                   isched_idle                      ;
logic                                                   wdc_idle                         ;
logic                                                   iwdb_idle                        ;
logic [L2_NUM_RCTRL-1   : 0]                            rctrl_idle                       ;

logic                                                   align_iwdb_valid                ;
logic                                                   align_iwdb_ready                ;
align_iwdb_write_record_type                            align_iwdb_rec                  ;
logic                                                   iwdb_align_free_valid           ;
logic   [L2_IWDB_INDEX_BITS-1:0]                        iwdb_align_free_index           ;

logic                                                   align_tagctrl_valid             ;
logic                                                   align_tagctrl_ready             ;
align_tagctrl_record_type                               align_tagctrl_rec               ;
logic                                                   tagctrl_isched_valid            ;
logic                                                   tagctrl_isched_ready            ;
tagctrl_isched_record_type                              tagctrl_isched_rec              ;
logic                                                   tagctrl_align_cfi_complete      ;
logic                                                   tagctrl_memif_valid             ;
logic                                                   tagctrl_memif_ready             ;
tagctrl_memif_record_type                               tagctrl_memif_rec               ;
logic                                                   memif_tagctrl_valid             ;
memif_tagctrl_record_type                               memif_tagctrl_rec               ;
logic                                                   tagctrl_memif_wb_finish         ;
logic                                                   memif_tagctrl_cfi_decrease_valid;
logic [L2_MAX_CFI_BITS-1:0]                             memif_tagctrl_cfi_id            ;
logic                               [L2_NUM_RCTRL-1:0]  tagctrl_rctrl_clr_valid         ;
tagctrl_rctrl_clr_record_type       [L2_NUM_RCTRL-1:0]  tagctrl_rctrl_clr_rec           ;

logic                               [L2_NUM_RCTRL-1:0]  memif_rctrl_valid               ;
logic                               [L2_NUM_RCTRL-1:0]  memif_rctrl_ready               ;
memif_rctrl_record_type             [L2_NUM_RCTRL-1:0]  memif_rctrl_rec                 ;
logic                                                   memif_wdc_valid                 ;
logic                                                   memif_wdc_ready                 ;
memif_wdc_record_type                                   memif_wdc_rec                   ;
logic                                                   memif_align_valid               ;
logic                                                   memif_align_ready               ;
memif_align_record_type                                 memif_align_rec                 ;
logic                                                   wdc_memif_wdata_valid           ;
logic                                                   wdc_memif_wdata_ready           ;
wdc_memif_wdata_record_type                             wdc_memif_wdata_rec             ;

logic                                                   align_isched_bm_valid           ;
logic                                                   align_isched_bm_ready           ;
align_isched_bm_record_type                             align_isched_bm_rec             ;
logic                               [L2_NUM_RCTRL-1:0]  rctrl_isched_valid              ;
rctrl_isched_record_type            [L2_NUM_RCTRL-1:0]  rctrl_isched_rec                ;
logic                               [L2_NUM_RCTRL-1:0]  isched_rctrl_instr_valid        ;
logic                               [L2_NUM_RCTRL-1:0]  isched_rctrl_instr_ready        ;
isched_rctrl_record_type            [L2_NUM_RCTRL-1:0]  isched_rctrl_instr_rec          ;
logic                               [L2_NUM_RCTRL-1:0]  isched_rctrl_wdata_valid        ;
logic                               [L2_NUM_RCTRL-1:0]  isched_rctrl_wdata_ready        ;
isched_rctrl_wdata_record_type      [L2_NUM_RCTRL-1:0]  isched_rctrl_wdata_rec          ;


logic                                                   wdc_isched_wb_cmd_valid         ;
logic                                                   wdc_isched_wb_cmd_ready         ;
wdc_isched_cmd_record_type                              wdc_isched_wb_cmd_rec           ;
logic                                                   isched_wdc_cmd_valid            ;
logic                                                   isched_wdc_cmd_ready            ;
isched_wdc_record_type                                  isched_wdc_cmd_rec              ;
logic                                                   wdc_iwdb_valid                  ;
logic                                                   wdc_iwdb_ready                  ;
wdc_iwdb_cmd_record_type                                wdc_iwdb_rec                    ;
logic                                                   iwdb_wdc_valid                  ;
iwdb_wdc_wdata_record_type                              iwdb_wdc_rec                    ;
logic                                                   wdc_isched_rtn_valid            ;
logic                                                   wdc_isched_rtn_ready            ;
wdc_isched_data_record_type                             wdc_isched_rtn_rec              ;
logic                               [L2_NUM_RCTRL-1:0]  rctrl_wdc_valid                 ;
logic                               [L2_NUM_RCTRL-1:0]  rctrl_wdc_ready                 ;
rctrl_wdc_wb_record_type            [L2_NUM_RCTRL-1:0]  rctrl_wdc_data_rec              ;

logic                               [L2_NUM_RCTRL-1:0]  rctrl_align_valid               ;
logic                               [L2_NUM_RCTRL-1:0]  rctrl_align_ready               ;
memif_align_record_type             [L2_NUM_RCTRL-1:0]  rctrl_align_rec                 ;

logic                               [L2_NUM_RCTRL-1:0]  rctrl_tagctrl_valid             ;
rctrl_tagctrl_record_type           [L2_NUM_RCTRL-1:0]  rctrl_tagctrl_rec               ;

logic                               [L2_NUM_RCTRL-1:0]  l2b_ramctrl_reqarb_wl           ;
logic                               [L2_NUM_RCTRL-1:0]  l2b_ramctrl_reqarb_stall_by_sram;
logic                               [L2_NUM_RCTRL-1:0]  l2b_ramctrl_data_sram_read_wl   ;
logic                               [L2_NUM_RCTRL-1:0]  l2b_ramctrl_data_sram_write_wl  ;

assign l2b_ramctrl_0_reqarb_wl              = l2b_ramctrl_reqarb_wl           [0];
assign l2b_ramctrl_0_reqarb_stall_by_sram   = l2b_ramctrl_reqarb_stall_by_sram[0];
assign l2b_ramctrl_0_data_sram_read_wl      = l2b_ramctrl_data_sram_read_wl   [0];
assign l2b_ramctrl_0_data_sram_write_wl     = l2b_ramctrl_data_sram_write_wl  [0];
assign l2b_ramctrl_1_reqarb_wl              = l2b_ramctrl_reqarb_wl           [1];
assign l2b_ramctrl_1_reqarb_stall_by_sram   = l2b_ramctrl_reqarb_stall_by_sram[1];
assign l2b_ramctrl_1_data_sram_read_wl      = l2b_ramctrl_data_sram_read_wl   [1];
assign l2b_ramctrl_1_data_sram_write_wl     = l2b_ramctrl_data_sram_write_wl  [1];
assign l2b_busy = ~l2_bank_idle;
// ----------------------------------------------------------------------------------------------
//  gc_l2_bank_align instance
// ----------------------------------------------------------------------------------------------
gc_l2_bank_align i_gc_l2_bank_align(
    // global interface
    .clk                        (clk                        ),  // I
    .resetn                     (resetn                     ),  // I
    .l2_align_idle              (align_idle                 ),  // O
    // AXI slave AR-channel
    .axi_slv_arvalid            (axi_slv_arvalid            ),  // I
    .axi_slv_arready            (axi_slv_arready            ),  // O
    .axi_slv_ar_rec             (axi_slv_ar_rec             ),  // I
    // AXI slave R-channel
    .axi_slv_rvalid             (axi_slv_rvalid             ),  // O
    .axi_slv_rready             (axi_slv_rready             ),  // I
    .axi_slv_r_rec              (axi_slv_r_rec              ),  // O
    // AXI slave AW-channel
    .axi_slv_awvalid            (axi_slv_awvalid            ),  // I
    .axi_slv_awready            (axi_slv_awready            ),  // O
    .axi_slv_aw_rec             (axi_slv_aw_rec             ),  // I
    // AXI slave W-channel
    .axi_slv_wvalid             (axi_slv_wvalid             ),  // I
    .axi_slv_wready             (axi_slv_wready             ),  // O
    .axi_slv_w_rec              (axi_slv_w_rec              ),  // I
    // AXI slave B-channel
    .axi_slv_bvalid             (axi_slv_bvalid             ),  // O
    .axi_slv_bready             (axi_slv_bready             ),  // I
    .axi_slv_b_rec              (axi_slv_b_rec              ),  // O
    // To TAGCTRL for cacheline request
    .align_tagctrl_valid        (align_tagctrl_valid        ),  // O
    .align_tagctrl_ready        (align_tagctrl_ready        ),  // I
    .align_tagctrl_record       (align_tagctrl_rec          ),  // O
    // To ISCHED for buffer mode request
    .align_isched_bm_valid      (align_isched_bm_valid      ),  // O
    .align_isched_bm_ready      (align_isched_bm_ready      ),  // I
    .align_isched_bm_rec        (align_isched_bm_rec        ),  // O
    // write IWDB interface
    .align_iwdb_valid           (align_iwdb_valid           ),  // O
    .align_iwdb_ready           (align_iwdb_ready           ),  // I
    .align_iwdb_rec             (align_iwdb_rec             ),  // O
    .iwdb_align_free_valid      (iwdb_align_free_valid      ),  // I
    .iwdb_align_free_index      (iwdb_align_free_index      ),  // I

    // RCTRL read data return interface
    .rctrl_align_valid          (rctrl_align_valid          ),  // I
    .rctrl_align_ready          (rctrl_align_ready          ),  // O
    .rctrl_align_rec            (rctrl_align_rec            ),  // I
    // ROB read data return interface,for bypass read miss
    .memif_align_valid          (memif_align_valid          ),  // I
    .memif_align_ready          (memif_align_ready          ),  // O
    .memif_align_rec            (memif_align_rec            ),  // I
    // configure register
    .gc_cr_l2_cmd_notify                    (gc_cr_l2_cmd_notify                            ),  // I
    .gc_cr_l2_cmd_persistence_rst_all       (gc_cr_l2_cmd_persistence_rst_all               ),  // I
    .gc_cr_l2_cmd_cfi_clr                   (gc_cr_l2_cmd_cfi_clr                           ),  // I
    .gc_cr_l2_cfi_operation_notify          (gc_cr_l2_cfi_operation_notify                  ),  // I
    .gc_cr_l2_cfi_operation                 (gc_cr_l2_cfi_operation                         ),  // I
    .gc_cr_l2_buffer_mode_percentage        (gc_cr_l2_buffer_mode_buffer_mode_percentage    ),  // I
    .gc_cr_l2_cfi_status_l2b_finish         (gc_cr_l2_cfi_statusi_l2b_finish                ),  // O
    .gc_cr_l2_persistence_reduce_enable     (gc_cr_l2_persistence_reduce_enable             ),  // I
    .gc_cr_l2_persistence_reduce_threshold  (gc_cr_l2_persistence_reduce_threshold          ),  // I
    // performance counter
    .l2b_fromaxi_ar_wl                      (l2b_fromaxi_ar_wl                              ),  // O
    .l2b_fromaxi_ar_bl_eq0_wl               (l2b_fromaxi_ar_bl_eq0_wl                       ),  // O
    .l2b_fromaxi_ar_bl_eq1_wl               (l2b_fromaxi_ar_bl_eq1_wl                       ),  // O
    .l2b_fromaxi_ar_bl_eq2_wl               (l2b_fromaxi_ar_bl_eq2_wl                       ),  // O
    .l2b_fromaxi_ar_bl_eq3_wl               (l2b_fromaxi_ar_bl_eq3_wl                       ),  // O
    .l2b_fromaxi_ar_bp                      (l2b_fromaxi_ar_bp                              ),  // O
    .l2b_toaxi_r_wl                         (l2b_toaxi_r_wl                                 ),  // O
    .l2b_toaxi_r_bp                         (l2b_toaxi_r_bp                                 ),  // O
    .l2b_fromaxi_aw_wl                      (l2b_fromaxi_aw_wl                              ),  // O
    .l2b_fromaxi_aw_bl_eq0_wl               (l2b_fromaxi_aw_bl_eq0_wl                       ),  // O
    .l2b_fromaxi_aw_bl_eq1_wl               (l2b_fromaxi_aw_bl_eq1_wl                       ),  // O
    .l2b_fromaxi_aw_bl_eq2_wl               (l2b_fromaxi_aw_bl_eq2_wl                       ),  // O
    .l2b_fromaxi_aw_bl_eq3_wl               (l2b_fromaxi_aw_bl_eq3_wl                       ),  // O
    .l2b_fromaxi_aw_bp                      (l2b_fromaxi_aw_bp                              ),  // O
    .l2b_fromaxi_w_wl                       (l2b_fromaxi_w_wl                               ),  // O
    .l2b_fromaxi_w_bp                       (l2b_fromaxi_w_bp                               ),  // O
    .l2b_fromaxi_smp_read_req_num           (l2b_fromaxi_smp_read_req_num                   ),  // O
    .l2b_fromaxi_smp_read_req_sum           (l2b_fromaxi_smp_read_req_sum                   ),  // O
    .l2b_fromaxi_smp_write_req_num          (l2b_fromaxi_smp_write_req_num                  ),  // O
    .l2b_fromaxi_smp_write_req_sum          (l2b_fromaxi_smp_write_req_sum                  ),  // O
    .l2b_fromaxi_smp_atomic_req_num         (l2b_fromaxi_smp_atomic_req_num                 ),  // O
    .l2b_fromaxi_smp_atomic_req_sum         (l2b_fromaxi_smp_atomic_req_sum                 ),  // O
    .l2b_align_awdb_full                    (l2b_align_awdb_full                            ),  // O
    // CFI complete interface
    .tagctrl_align_cfi_complete             (tagctrl_align_cfi_complete                     )   // I
);

// ----------------------------------------------------------------------------------------------
//  gc_l2_bank_tagctrl instance
// ----------------------------------------------------------------------------------------------
gc_l2_bank_tagctrl i_gc_l2_bank_tagctrl
(
    .clk                                    (clk                                            ),  // I
    .resetn                                 (resetn                                         ),  // I
    .tagctrl_idle                           (tagctrl_idle                                   ),  // O

    .align_tagctrl_valid                    (align_tagctrl_valid                            ),  // I
    .align_tagctrl_ready                    (align_tagctrl_ready                            ),  // O
    .align_tagctrl_rec                      (align_tagctrl_rec                              ),  // I

    .tagctrl_isched_valid                   (tagctrl_isched_valid                           ),  // O
    .tagctrl_isched_ready                   (tagctrl_isched_ready                           ),  // I
    .tagctrl_isched_rec                     (tagctrl_isched_rec                             ),  // O

    .tagctrl_align_cfi_complete             (tagctrl_align_cfi_complete                     ),  // O

    .tagctrl_memif_valid                    (tagctrl_memif_valid                            ),  // O
    .tagctrl_memif_ready                    (tagctrl_memif_ready                            ),  // I
    .tagctrl_memif_rec                      (tagctrl_memif_rec                              ),  // O

    .memif_tagctrl_valid                    (memif_tagctrl_valid                            ),  // I
    .memif_tagctrl_rec                      (memif_tagctrl_rec                              ),  // I
    .tagctrl_memif_wb_finish                (tagctrl_memif_wb_finish                        ),  // O

    .memif_tagctrl_cfi_decrease_valid       (memif_tagctrl_cfi_decrease_valid               ),  // I
    .memif_tagctrl_cfi_id                   (memif_tagctrl_cfi_id                           ),  // I

    .rctrl_tagctrl_wb_done_valid            (rctrl_isched_valid                             ),  // I
    .rctrl_tagctrl_wb_rec                   (rctrl_isched_rec                               ),  // I

    .rctrl_tagctrl_valid                    (rctrl_tagctrl_valid                            ),  // I
    .rctrl_tagctrl_rec                      (rctrl_tagctrl_rec                              ),  // I

    .tagctrl_rctrl_clr_valid                (tagctrl_rctrl_clr_valid                        ),  // O
    .tagctrl_rctrl_clr_rec                  (tagctrl_rctrl_clr_rec                          ),  // O

    .l2b_hittest_ht_bypass_read_wl          (l2b_hittest_ht_bypass_read_wl                  ),  // O
    .l2b_hittest_ht_cache_read_wl           (l2b_hittest_ht_cache_read_wl                   ),  // O
    .l2b_hittest_ht_bypass_write_wl         (l2b_hittest_ht_bypass_write_wl                 ),  // O
    .l2b_hittest_ht_cache_write_wl          (l2b_hittest_ht_cache_write_wl                  ),  // O
    .l2b_hittest_ht_atomic_wl               (l2b_hittest_ht_atomic_wl                       ),  // O
    .l2b_hittest_ht_bps_hit_wl              (l2b_hittest_ht_bps_hit_wl                      ),  // O
    .l2b_hittest_ht_miss_wl                 (l2b_hittest_ht_miss_wl                         ),  // O

    .gc_cr_l2_buffer_mode_percentage        (gc_cr_l2_buffer_mode_buffer_mode_percentage    ),  // I
    .gc_cr_l2_function_enable_bypass_mode   (gc_cr_l2_function_enable_bypass_mode           ),  // I
    .tst_gclkenable                         (tst_gclkenable                                 )
);

// ----------------------------------------------------------------------------------------------
//  gc_l2_bank_memif instance
// ----------------------------------------------------------------------------------------------
gc_l2_bank_memif i_gc_l2_bank_memif
(
    .clk                                (clk                                    ),  // I
    .resetn                             (resetn                                 ),  // I
    .memif_idle                         (memif_idle                             ),  // O
    // tagctrl interface
    .tagctrl_memif_valid                (tagctrl_memif_valid                    ),  // I
    .tagctrl_memif_ready                (tagctrl_memif_ready                    ),  // O
    .tagctrl_memif_rec                  (tagctrl_memif_rec                      ),  // I

    .memif_tagctrl_valid                (memif_tagctrl_valid                    ),  // O
    .memif_tagctrl_rec                  (memif_tagctrl_rec                      ),  // O
    .tagctrl_memif_wb_finish            (tagctrl_memif_wb_finish                ),  // I

    .rctrl_memif_wb_done_valid          (rctrl_isched_valid                     ),  // I
    .rctrl_memif_wb_done_rec            (rctrl_isched_rec                       ),  // I

    .memif_sched_valid                  (memif_sched_valid                      ),  // O
    .memif_sched_ready                  (memif_sched_ready                      ),  // I
    .memif_sched_rec                    (memif_sched_rec                        ),  // O

    .sched_memif_valid                  (sched_memif_valid                      ),  // I
    .sched_memif_ready                  (sched_memif_ready                      ),  // O
    .sched_memif_rec                    (sched_memif_rec                        ),  // I

    .memif_tagctrl_cfi_decrease_valid   (memif_tagctrl_cfi_decrease_valid       ),  // O
    .memif_tagctrl_cfi_id               (memif_tagctrl_cfi_id                   ),  // O

    .memif_rctrl_valid                  (memif_rctrl_valid                      ),  // O
    .memif_rctrl_ready                  (memif_rctrl_ready                      ),  // O
    .memif_rctrl_rec                    (memif_rctrl_rec                        ),  // O

    .memif_wdc_valid                    (memif_wdc_valid                        ),  // O
    .memif_wdc_ready                    (memif_wdc_ready                        ),  // I
    .memif_wdc_rec                      (memif_wdc_rec                          ),  // O

    .memif_align_valid                  (memif_align_valid                      ),  // O
    .memif_align_ready                  (memif_align_ready                      ),  // I
    .memif_align_rec                    (memif_align_rec                        ),  // O

    .wdc_memif_wdata_valid              (wdc_memif_wdata_valid                  ),  // I
    .wdc_memif_wdata_ready              (wdc_memif_wdata_ready                  ),  // O
    .wdc_memif_wdata_rec                (wdc_memif_wdata_rec                    ),  // I
    // NSP interface
    .nsp_req_valid                      (nsp_req_valid                          ),  // O
    .nsp_req_ready                      (nsp_req_ready                          ),  // I
    .nsp_req_rec                        (nsp_req_rec                            ),  // O

    .nsp_rsp_valid                      (nsp_rsp_valid                          ),  // I
    .nsp_rsp_ready                      (nsp_rsp_ready                          ),  // O
    .nsp_rsp_rec                        (nsp_rsp_rec                            ),   // I
    
    .l2b_frommemsch_nsp_rtn_wl                      (l2b_frommemsch_nsp_rtn_wl                      ),  // O
    .l2b_frommemsch_nsp_rtn_bp                      (l2b_frommemsch_nsp_rtn_bp                      ),  // O
    .l2b_tomemsch_nsp_read_bl_eq1_wl                (l2b_tomemsch_nsp_read_bl_eq1_wl                ),  // O
    .l2b_tomemsch_nsp_read_bl_eq3_wl                (l2b_tomemsch_nsp_read_bl_eq3_wl                ),  // O
    .l2b_tomemsch_nsp_read_bl_eq5_wl                (l2b_tomemsch_nsp_read_bl_eq5_wl                ),  // O
    .l2b_tomemsch_nsp_read_bl_eq7_wl                (l2b_tomemsch_nsp_read_bl_eq7_wl                ),  // O
    .l2b_tomemsch_nsp_write_bl_eq1_wl               (l2b_tomemsch_nsp_write_bl_eq1_wl               ),  // O
    .l2b_tomemsch_nsp_write_bl_eq3_wl               (l2b_tomemsch_nsp_write_bl_eq3_wl               ),  // O
    .l2b_tomemsch_nsp_write_bl_eq5_wl               (l2b_tomemsch_nsp_write_bl_eq5_wl               ),  // O
    .l2b_tomemsch_nsp_write_bl_eq7_wl               (l2b_tomemsch_nsp_write_bl_eq7_wl               ),  // O
    .l2b_memif_to_ddr_read_wl                       (l2b_memif_to_ddr_read_wl                       ),  // O
    .l2b_memif_to_ddr_read_stall_by_rob             (l2b_memif_to_ddr_read_stall_by_rob             ),  // O
    .l2b_memif_to_ddr_read_stall_by_ddr             (l2b_memif_to_ddr_read_stall_by_ddr             ),  // O
    .l2b_memif_to_ddr_read_stall_by_trid            (l2b_memif_to_ddr_read_stall_by_trid            ),  // O
    .l2b_memif_to_ddr_write_wl                      (l2b_memif_to_ddr_write_wl                      ),  // O
    .l2b_memif_to_ddr_write_stall_by_data_sync      (l2b_memif_to_ddr_write_stall_by_data_sync      ),  // O
    .l2b_memif_to_ddr_write_stall_by_ddr            (l2b_memif_to_ddr_write_stall_by_ddr            ),  // O
    .l2b_memif_to_ddr_write_stall_by_trid           (l2b_memif_to_ddr_write_stall_by_trid           ),  // O
    .l2b_memif_memreq_full                          (l2b_memif_memreq_full                          ),  // O
    .l2b_memif_smp_read_req_num                     (l2b_memif_smp_read_req_num                     ),  // O
    .l2b_memif_smp_read_req_sum                     (l2b_memif_smp_read_req_sum                     ),  // O

    .gc_cr_ddr_hash_config_reg0_row_id_bit0         (gc_cr_ddr_hash_config_reg0_row_id_bit0         ),  // I 
    .gc_cr_ddr_hash_config_reg0_row_id_bit1         (gc_cr_ddr_hash_config_reg0_row_id_bit1         ),  // I 
    .gc_cr_ddr_hash_config_reg0_row_id_bit2         (gc_cr_ddr_hash_config_reg0_row_id_bit2         ),  // I 
    .gc_cr_ddr_hash_config_reg0_row_id_bit3         (gc_cr_ddr_hash_config_reg0_row_id_bit3         ),  // I 
    .gc_cr_ddr_hash_config_reg0_row_id_bit4         (gc_cr_ddr_hash_config_reg0_row_id_bit4         ),  // I 
    .gc_cr_ddr_hash_config_reg0_row_id_bit5         (gc_cr_ddr_hash_config_reg0_row_id_bit5         ),  // I 
    .gc_cr_ddr_hash_config_reg0_row_id_bit6         (gc_cr_ddr_hash_config_reg0_row_id_bit6         ),  // I 
    .gc_cr_ddr_hash_config_reg0_row_id_bit7         (gc_cr_ddr_hash_config_reg0_row_id_bit7         ),  // I 
    .gc_cr_ddr_hash_config_reg0_row_id_bit8         (gc_cr_ddr_hash_config_reg0_row_id_bit8         ),  // I 
    .gc_cr_ddr_hash_config_reg0_row_id_bit9         (gc_cr_ddr_hash_config_reg0_row_id_bit9         ),  // I 
    .gc_cr_ddr_hash_config_reg0_row_id_bit10        (gc_cr_ddr_hash_config_reg0_row_id_bit10        ),  // I 
    .gc_cr_ddr_hash_config_reg0_row_id_bit11        (gc_cr_ddr_hash_config_reg0_row_id_bit11        ),  // I 
    .gc_cr_ddr_hash_config_reg1_row_id_bit12        (gc_cr_ddr_hash_config_reg1_row_id_bit12        ),  // I 
    .gc_cr_ddr_hash_config_reg1_row_id_bit13        (gc_cr_ddr_hash_config_reg1_row_id_bit13        ),  // I 
    .gc_cr_ddr_hash_config_reg1_row_id_bit14        (gc_cr_ddr_hash_config_reg1_row_id_bit14        ),  // I 
    .gc_cr_ddr_hash_config_reg1_row_id_bit15        (gc_cr_ddr_hash_config_reg1_row_id_bit15        ),  // I 
    .gc_cr_ddr_hash_config_reg1_row_id_bit16        (gc_cr_ddr_hash_config_reg1_row_id_bit16        ),  // I 
    .gc_cr_ddr_hash_config_reg1_row_id_bit17        (gc_cr_ddr_hash_config_reg1_row_id_bit17        ),  // I 
    .gc_cr_ddr_hash_config_reg1_row_id_bit18        (gc_cr_ddr_hash_config_reg1_row_id_bit18        ),  // I 
    .gc_cr_ddr_hash_config_reg1_row_id_bit19        (gc_cr_ddr_hash_config_reg1_row_id_bit19        ),  // I 
    .gc_cr_ddr_hash_config_reg1_row_id_bit20        (gc_cr_ddr_hash_config_reg1_row_id_bit20        ),  // I 
    .gc_cr_ddr_hash_config_reg1_row_id_bit21        (gc_cr_ddr_hash_config_reg1_row_id_bit21        ),  // I 
    .gc_cr_ddr_hash_config_reg1_row_id_bit22        (gc_cr_ddr_hash_config_reg1_row_id_bit22        ),  // I 
    .gc_cr_ddr_hash_config_reg1_row_id_bit23        (gc_cr_ddr_hash_config_reg1_row_id_bit23        ),  // I 
    .gc_cr_l2_function_enable_hash_mode             (gc_cr_l2_function_enable_hash_mode             ),  // I 
    .gc_l2_mem_scheduler_enable                     (gc_l2_mem_scheduler_enable                     ),  // I
    .gc_cr_l2_mem_sched_bank_offset_bank_id_bit0    (gc_cr_l2_mem_sched_bank_offset_bank_id_bit0    ),  // I  
    .gc_cr_l2_mem_sched_bank_offset_bank_id_bit1    (gc_cr_l2_mem_sched_bank_offset_bank_id_bit1    ),  // I
    .gc_cr_l2_mem_sched_bank_offset_bank_id_bit2    (gc_cr_l2_mem_sched_bank_offset_bank_id_bit2    ),  // I
    .gc_cr_l2_mem_sched_bank_offset_bank_id_bit3    (gc_cr_l2_mem_sched_bank_offset_bank_id_bit3    ),  // I
    .gc_cr_l2_mem_sched_bank_offset_bank_id_bit4    (gc_cr_l2_mem_sched_bank_offset_bank_id_bit4    ),  // I
    
    .gc_cr_l2_mem_sched_row_parti_row_id_bit0       (gc_cr_l2_mem_sched_row_parti_row_id_bit0       ),  // I
    .gc_cr_l2_mem_sched_row_parti_row_id_bit1       (gc_cr_l2_mem_sched_row_parti_row_id_bit1       ),  // I
    .gc_cr_l2_mem_sched_row_parti_row_id_bit2       (gc_cr_l2_mem_sched_row_parti_row_id_bit2       ),  // I
    .gc_cr_l2_mem_sched_row_parti_row_id_bit3       (gc_cr_l2_mem_sched_row_parti_row_id_bit3       ),  // I
    .gc_cr_l2_mem_sched_row_parti_row_id_bit4       (gc_cr_l2_mem_sched_row_parti_row_id_bit4       ),  // I
    .gc_cr_l2_mem_sched_row_parti_row_id_bit5       (gc_cr_l2_mem_sched_row_parti_row_id_bit5       ),  // I
    .gc_cr_l2_mem_sched_row_parti_row_id_bit6       (gc_cr_l2_mem_sched_row_parti_row_id_bit6       ),  // I
    .gc_cr_l2_mem_sched_row_parti_row_id_bit7       (gc_cr_l2_mem_sched_row_parti_row_id_bit7       ),  // I
    .gc_cr_l2_mem_sched_row_partii_row_id_bit8      (gc_cr_l2_mem_sched_row_partii_row_id_bit8      ),  // I
    .gc_cr_l2_mem_sched_row_partii_row_id_bit9      (gc_cr_l2_mem_sched_row_partii_row_id_bit9      ),  // I
    .gc_cr_l2_mem_sched_row_partii_row_id_bit10     (gc_cr_l2_mem_sched_row_partii_row_id_bit10     ),  // I
    .gc_cr_l2_mem_sched_row_partii_row_id_bit11     (gc_cr_l2_mem_sched_row_partii_row_id_bit11     ),  // I
    .gc_cr_l2_mem_sched_row_partii_row_id_bit12     (gc_cr_l2_mem_sched_row_partii_row_id_bit12     ),  // I
    .gc_cr_l2_mem_sched_row_partii_row_id_bit13     (gc_cr_l2_mem_sched_row_partii_row_id_bit13     ),  // I
    .gc_cr_l2_mem_sched_row_partii_row_id_bit14     (gc_cr_l2_mem_sched_row_partii_row_id_bit14     ),  // I
    .gc_cr_l2_mem_sched_row_partii_row_id_bit15     (gc_cr_l2_mem_sched_row_partii_row_id_bit15     ),  // I
    .gc_cr_l2_mem_sched_row_partiii_row_id_bit16    (gc_cr_l2_mem_sched_row_partiii_row_id_bit16    ),  // I
    .gc_cr_l2_mem_sched_row_partiii_row_id_bit17    (gc_cr_l2_mem_sched_row_partiii_row_id_bit17    ),  // I
    .gc_cr_l2_function_enable_ddr_capacity          (gc_cr_l2_function_enable_ddr_capacity          ),  // I
    .gc_cr_l2b_error                                (gc_cr_l2g_error_l2b                            ),  // O
    .tst_gclkenable                                 (tst_gclkenable                                 )
);

// ----------------------------------------------------------------------------------------------
//  gc_l2_bank_isched instance
// ----------------------------------------------------------------------------------------------
gc_l2_bank_isched i_gc_l2_bank_isched
(
    .clk                           (clk                         ),  // I
    .resetn                        (resetn                      ),  // I
    .idle                          (isched_idle                 ),  // O
   //command from TagCtrl
   //WR,AA,RD,Prefetch
    .tagctrl_isched_valid          (tagctrl_isched_valid        ),  // I
    .tagctrl_isched_ready          (tagctrl_isched_ready        ),  // O
    .tagctrl_isched_rec            (tagctrl_isched_rec          ),  // I
   //command from WDC
   //WB,WB_WR,FLUSH
    .wdc_isched_wb_valid           (wdc_isched_wb_cmd_valid     ),  // I
    .wdc_isched_wb_ready           (wdc_isched_wb_cmd_ready     ),  // O
    .wdc_isched_wb_rec             (wdc_isched_wb_cmd_rec       ),  // I
   //command from ALIGN
   //buffer mode,WR,AA,RD
    .align_isched_bm_valid         (align_isched_bm_valid       ),  // I
    .align_isched_bm_ready         (align_isched_bm_ready       ),  // O
    .align_isched_bm_rec           (align_isched_bm_rec         ),  // I
   // ----------------------------------------------------------------------------
   // RAM Ctrl Interface
   // ----------------------------------------------------------------------------
   // Clear Waiting linefill Bit interface (either when Linefill data has returned or cacheline is ready)
   // hazard_flag Bit release and invalid the entry interface
    .rctrl_isched_valid                 (rctrl_isched_valid                     ),  // I
    .rctrl_isched_rec                   (rctrl_isched_rec                       ),  // I

    .isched_wdc_fetch_data_valid        (isched_wdc_cmd_valid                   ),  // O
    .isched_wdc_fetch_data_ready        (isched_wdc_cmd_ready                   ),  // I
    .isched_wdc_fetch_data_rec          (isched_wdc_cmd_rec                     ),  // O
    .wdc_isched_wdata_valid             (wdc_isched_rtn_valid                   ),  // I
    .wdc_isched_wdata_ready             (wdc_isched_rtn_ready                   ),  // O
    .wdc_isched_wdata_rec               (wdc_isched_rtn_rec                     ),  // I
    .isched_rctrl_instr_valid           (isched_rctrl_instr_valid               ),  // O
    .isched_rctrl_instr_ready           (isched_rctrl_instr_ready               ),  // I
    .isched_rctrl_instr_rec             (isched_rctrl_instr_rec                 ),  // O
    .isched_rctrl_wdata_valid           (isched_rctrl_wdata_valid               ),  // O
    .isched_rctrl_wdata_ready           (isched_rctrl_wdata_ready               ),  // I
    .isched_rctrl_wdata_rec             (isched_rctrl_wdata_rec                 ),  // O

    .l2b_reqsch_sortq_full              (l2b_reqsch_sortq_full                  ),  // O
    .l2b_reqsch_sortq_stall_but_not_full(l2b_reqsch_sortq_stall_but_not_full    ),  // O
    .l2b_reqsch_disp_wl                 (l2b_reqsch_disp_wl                     ),  // O
    .l2b_reqsch_disp_stall              (l2b_reqsch_disp_stall                  )   // O

);

// ----------------------------------------------------------------------------------------------
//  gc_l2_bank_wdc instance
// ----------------------------------------------------------------------------------------------
gc_l2_bank_wdc i_gc_l2_bankd_wdc
(
    .clk                        (clk                        ),  // I
    .resetn                     (resetn                     ),  // I
    .wdc_idle                   (wdc_idle                   ),  // O

    .memif_wdc_cmd_valid        (memif_wdc_valid            ),  // I
    .memif_wdc_cmd_ready        (memif_wdc_ready            ),  // O
    .memif_wdc_cmd_rec          (memif_wdc_rec              ),  // I

    .wdc_isched_wb_cmd_valid    (wdc_isched_wb_cmd_valid    ),  // O
    .wdc_isched_wb_cmd_ready    (wdc_isched_wb_cmd_ready    ),  // I
    .wdc_isched_wb_cmd_rec      (wdc_isched_wb_cmd_rec      ),  // O

    .isched_wdc_cmd_valid       (isched_wdc_cmd_valid       ),  // I
    .isched_wdc_cmd_ready       (isched_wdc_cmd_ready       ),  // O
    .isched_wdc_cmd_rec         (isched_wdc_cmd_rec         ),  // I

    .wdc_iwdb_fetch_data_valid  (wdc_iwdb_valid             ),  // O
    .wdc_iwdb_fetch_data_ready  (wdc_iwdb_ready             ),  // I
    .wdc_iwdb_fetch_data_rec    (wdc_iwdb_rec               ),  // O

    .iwdb_wdc_wdata_valid       (iwdb_wdc_valid             ),  // I
    .iwdb_wdc_wdata_rec         (iwdb_wdc_rec               ),  // I

    .wdc_isched_rtn_valid       (wdc_isched_rtn_valid       ),  // O
    .wdc_isched_rtn_ready       (wdc_isched_rtn_ready       ),  // I
    .wdc_isched_rtn_rec         (wdc_isched_rtn_rec         ),  // O

    .rctrl_wdc_wb_data_valid    (rctrl_wdc_valid            ),  // I
    .rctrl_wdc_wb_data_ready    (rctrl_wdc_ready            ),  // O
    .rctrl_wdc_wb_data_rec      (rctrl_wdc_data_rec         ),  // I

    .wdc_memif_wdata_valid      (wdc_memif_wdata_valid      ),  // O
    .wdc_memif_wdata_ready      (wdc_memif_wdata_ready      ),  // I
    .wdc_memif_wdata_rec        (wdc_memif_wdata_rec        )   // O
);

// ----------------------------------------------------------------------------------------------
//  gc_l2_bank_iwdb instance
// ----------------------------------------------------------------------------------------------
gc_l2_bank_iwdb i_gc_l2_bank_iwdb
(
    .clk                        (clk                        ),  // I
    .resetn                     (resetn                     ),  // I
    .idle                       (iwdb_idle                  ),  // O

    .wdc_iwdb_valid             (wdc_iwdb_valid             ),  // I
    .wdc_iwdb_ready             (wdc_iwdb_ready             ),  // O
    .wdc_iwdb_rec               (wdc_iwdb_rec               ),  // I
    .iwdb_wdc_valid             (iwdb_wdc_valid             ),  // O
    .iwdb_wdc_rec               (iwdb_wdc_rec               ),  // O
    .align_iwdb_valid           (align_iwdb_valid           ),  // I
    .align_iwdb_ready           (align_iwdb_ready           ),  // O
    .align_iwdb_rec             (align_iwdb_rec             ),  // I
    .iwdb_align_free_valid      (iwdb_align_free_valid      ),  // O
    .iwdb_align_free_index      (iwdb_align_free_index      ),  // O
    .tst_gclkenable             (tst_gclkenable             )
);


// ----------------------------------------------------------------------------------------------
//  gc_l2_bank_rctrl instance
// ----------------------------------------------------------------------------------------------
generate
for (genvar RC=0; RC<L2_NUM_RCTRL; RC++) begin: g_l2_bank_rctrl
gc_l2_bank_rctrl i_gc_l2_bank_rctrl
(
    // global interface
    .clk                                    (clk                                    ),  // I
    .resetn                                 (resetn                                 ),  // I
    .l2_rctrl_idle                          (rctrl_idle                         [RC]),  // O
    // cacheline instruction interface
    .isched_rctrl_valid                     (isched_rctrl_instr_valid           [RC]),  // I
    .isched_rctrl_ready                     (isched_rctrl_instr_ready           [RC]),  // O
    .isched_rctrl_instr_rec                 (isched_rctrl_instr_rec             [RC]),  // I
    .isched_rctrl_wdata_valid               (isched_rctrl_wdata_valid           [RC]),  // I
    .isched_rctrl_wdata_ready               (isched_rctrl_wdata_ready           [RC]),  // O
    .isched_rctrl_wdata_rec                 (isched_rctrl_wdata_rec             [RC]),  // I
    // linefill write request interface                                        
    .memif_rctrl_valid                      (memif_rctrl_valid                  [RC]),  // I
    .memif_rctrl_ready                      (memif_rctrl_ready                  [RC]),  // O
    .memif_rctrl_rec                        (memif_rctrl_rec                    [RC]),  // I
    // clear initial mask interface                                            
    .tagctrl_rctrl_clr_valid                (tagctrl_rctrl_clr_valid            [RC]),  // I
    .tagctrl_rctrl_clr_record               (tagctrl_rctrl_clr_rec              [RC]),  // I
    // WB data out interface                                                   
    .rctrl_wdc_valid                        (rctrl_wdc_valid                    [RC]),  // O
    .rctrl_wdc_ready                        (rctrl_wdc_ready                    [RC]),  // I
    .rctrl_wdc_data_rec                     (rctrl_wdc_data_rec                 [RC]),  // O
    // read data return interface                                              
    .rctrl_align_valid                      (rctrl_align_valid                  [RC]),  // O
    .rctrl_align_ready                      (rctrl_align_ready                  [RC]),  // I
    .rctrl_align_rec                        (rctrl_align_rec                    [RC]),  // O
    // linefill/wb response                                                    
    .rctrl_isched_valid                     (rctrl_isched_valid                 [RC]),  // O
    .rctrl_isched_rec                       (rctrl_isched_rec                   [RC]),  // O
    // instr executed                                                          
    .rctrl_tagctrl_valid                    (rctrl_tagctrl_valid                [RC]),  // O
    .rctrl_tagctrl_rec                      (rctrl_tagctrl_rec                  [RC]),  // O
    // performance counter
    .l2b_ramctrl_reqarb_wl                  (l2b_ramctrl_reqarb_wl              [RC]),  // O
    .l2b_ramctrl_reqarb_stall_by_sram       (l2b_ramctrl_reqarb_stall_by_sram   [RC]),  // O
    .l2b_ramctrl_data_sram_read_wl          (l2b_ramctrl_data_sram_read_wl      [RC]),  // O
    .l2b_ramctrl_data_sram_write_wl         (l2b_ramctrl_data_sram_write_wl     [RC]),  // O
    // configure register
    .gc_cr_cu_lms_fp32_denormal_en         (gc_cr_cu_lms_fp32_denormal_en         ),  // I
    // test interface
    .tst_gclkenable                         (tst_gclkenable                         )   // I
);
end
endgenerate

// ----------------------------------------------------------------------------------------------
//  idle generation
// ----------------------------------------------------------------------------------------------
gc_l2_bank_idle #(
    .NUM_IDLE       (L2_BANK_NUM_IDLE   ),
    .RESET_VALUE    (1'b0               ) 
) i_gc_l2_bank_idle (
    .clk            (clk                ),  // I
    .resetn         (resetn             ),  // I
    .in_idles       ({align_idle, tagctrl_idle, memif_idle, isched_idle, wdc_idle, iwdb_idle, rctrl_idle}   ),  // I
    .out_idle       (l2_bank_idle       )   // O
);

// synopsys translate_off

default clocking cb @(posedge clk);
endclocking
default disable iff(!resetn);

property valid_ready_stable (valid, ready, payload);
   valid && !ready |=> valid && $stable(payload);
endproperty 

as__isched_ring_buffer_counter_check:
   assert property (gc_l2_bank.i_gc_l2_bank_isched.i_gc_l2_bank_isched_ringbuffer.isched_xbar_instr_valid[0] 
                  |-> gc_l2_bank.i_gc_l2_bank_tagctrl.access_counter_array[gc_l2_bank.i_gc_l2_bank_isched.i_gc_l2_bank_isched_ringbuffer.isched_xbar_instr_rec[0].set][gc_l2_bank.i_gc_l2_bank_isched.i_gc_l2_bank_isched_ringbuffer.isched_xbar_instr_rec[0].way] != '0);

as__valid_ready_stable_check:
   assert property (valid_ready_stable(wdc_memif_wdata_valid, wdc_memif_wdata_ready, wdc_memif_wdata_rec));
logic [L2_WB_BUF_DEPTH-1:0] hit_wb_buf_mask;

generate
   for (genvar wb_entry = 0; wb_entry < L2_WB_BUF_DEPTH; wb_entry ++) begin
      assign hit_wb_buf_mask[wb_entry] = gc_l2_bank.i_gc_l2_bank_tagctrl.inflight_wb_valids[wb_entry] 
                                         && gc_l2_bank.i_gc_l2_bank_tagctrl.inflight_wb_entries[wb_entry].set == gc_l2_bank.i_gc_l2_bank_isched.i_gc_l2_bank_isched_ringbuffer.isched_xbar_instr_rec[0].set 
                                         && gc_l2_bank.i_gc_l2_bank_tagctrl.inflight_wb_entries[wb_entry].way == gc_l2_bank.i_gc_l2_bank_isched.i_gc_l2_bank_isched_ringbuffer.isched_xbar_instr_rec[0].way;
   end
endgenerate



as__wb_entry_check: // when request is issued from ring buffer, the cacheline can not be held in inflight wb buffer.
   assert property (gc_l2_bank.i_gc_l2_bank_isched.i_gc_l2_bank_isched_ringbuffer.isched_xbar_instr_valid[0] 
                    && gc_l2_bank.i_gc_l2_bank_isched.i_gc_l2_bank_isched_ringbuffer.isched_xbar_instr_rec[0].instruction inside {RD, WR, AA}|-> ~(|hit_wb_buf_mask)) ;  


logic [39:0] cnt_busy                                   ;
logic [39:0] cnt_fromaxi_ar_wl                          ;
logic [39:0] cnt_fromaxi_ar_bl_eq0_wl                   ;
logic [39:0] cnt_fromaxi_ar_bl_eq1_wl                   ;
logic [39:0] cnt_fromaxi_ar_bl_eq2_wl                   ;
logic [39:0] cnt_fromaxi_ar_bl_eq3_wl                   ;
logic [39:0] cnt_fromaxi_ar_bp                          ;
logic [39:0] cnt_toaxi_r_wl                             ;
logic [39:0] cnt_toaxi_r_bp                             ;
logic [39:0] cnt_fromaxi_aw_wl                          ;
logic [39:0] cnt_fromaxi_aw_bl_eq0_wl                   ;
logic [39:0] cnt_fromaxi_aw_bl_eq1_wl                   ;
logic [39:0] cnt_fromaxi_aw_bl_eq2_wl                   ;
logic [39:0] cnt_fromaxi_aw_bl_eq3_wl                   ;
logic [39:0] cnt_fromaxi_aw_bp                          ;
logic [39:0] cnt_fromaxi_w_wl                           ;
logic [39:0] cnt_fromaxi_w_bp                           ;
logic [39:0] cnt_fromaxi_smp_read_req_num               ;
logic [39:0] cnt_fromaxi_smp_read_req_sum               ;
logic [39:0] cnt_fromaxi_smp_write_req_num              ;
logic [39:0] cnt_fromaxi_smp_write_req_sum              ;
logic [39:0] cnt_fromaxi_smp_atomic_req_num             ;
logic [39:0] cnt_fromaxi_smp_atomic_req_sum             ;
logic [39:0] cnt_align_awdb_full                        ;
logic [39:0] cnt_hittest_ht_bypass_read_wl              ;
logic [39:0] cnt_hittest_ht_cache_read_wl               ;
logic [39:0] cnt_hittest_ht_bypass_write_wl             ;
logic [39:0] cnt_hittest_ht_cache_write_wl              ;
logic [39:0] cnt_hittest_ht_atomic_wl                   ;
logic [39:0] cnt_hittest_ht_bps_hit_wl                  ;
logic [39:0] cnt_hittest_ht_miss_wl                     ;
logic [39:0] cnt_frommemsch_nsp_rtn_wl                  ;
logic [39:0] cnt_frommemsch_nsp_rtn_bp                  ;
logic [39:0] cnt_tomemsch_nsp_read_bl_eq1_wl            ;
logic [39:0] cnt_tomemsch_nsp_read_bl_eq3_wl            ;
logic [39:0] cnt_tomemsch_nsp_read_bl_eq5_wl            ;
logic [39:0] cnt_tomemsch_nsp_read_bl_eq7_wl            ;
logic [39:0] cnt_tomemsch_nsp_write_bl_eq1_wl           ;
logic [39:0] cnt_tomemsch_nsp_write_bl_eq3_wl           ;
logic [39:0] cnt_tomemsch_nsp_write_bl_eq5_wl           ;
logic [39:0] cnt_tomemsch_nsp_write_bl_eq7_wl           ;
logic [39:0] cnt_memif_to_ddr_read_wl                   ;
logic [39:0] cnt_memif_to_ddr_read_stall_by_rob         ;
logic [39:0] cnt_memif_to_ddr_read_stall_by_ddr         ;
logic [39:0] cnt_memif_to_ddr_read_stall_by_trid        ;
logic [39:0] cnt_memif_to_ddr_write_wl                  ;
logic [39:0] cnt_memif_to_ddr_write_stall_by_data_sync  ;
logic [39:0] cnt_memif_to_ddr_write_stall_by_ddr        ;
logic [39:0] cnt_memif_to_ddr_write_stall_by_trid       ;
logic [39:0] cnt_memif_memreq_full                      ;
logic [39:0] cnt_memif_smp_read_req_num                 ;
logic [39:0] cnt_memif_smp_read_req_sum                 ;
logic [39:0] cnt_reqsch_sortq_full                      ;
logic [39:0] cnt_reqsch_sortq_stall_but_not_full        ;
logic [39:0] cnt_reqsch_disp_wl                         ;
logic [39:0] cnt_reqsch_disp_stall                      ;
logic [39:0] cnt_ramctrl_0_reqarb_wl                    ;
logic [39:0] cnt_ramctrl_0_reqarb_stall_by_sram         ;
logic [39:0] cnt_ramctrl_0_data_sram_read_wl            ;
logic [39:0] cnt_ramctrl_0_data_sram_write_wl           ;
logic [39:0] cnt_ramctrl_1_reqarb_wl                    ;
logic [39:0] cnt_ramctrl_1_reqarb_stall_by_sram         ;
logic [39:0] cnt_ramctrl_1_data_sram_read_wl            ;
logic [39:0] cnt_ramctrl_1_data_sram_write_wl           ;

always_ff @(posedge clk or negedge resetn) begin
    if(!resetn) begin
        cnt_busy                                        <= 'b0;
        cnt_fromaxi_ar_wl                               <= 'b0;
        cnt_fromaxi_ar_bl_eq0_wl                        <= 'b0;
        cnt_fromaxi_ar_bl_eq1_wl                        <= 'b0;
        cnt_fromaxi_ar_bl_eq2_wl                        <= 'b0;
        cnt_fromaxi_ar_bl_eq3_wl                        <= 'b0;
        cnt_fromaxi_ar_bp                               <= 'b0;
        cnt_toaxi_r_wl                                  <= 'b0;
        cnt_toaxi_r_bp                                  <= 'b0;
        cnt_fromaxi_aw_wl                               <= 'b0;
        cnt_fromaxi_aw_bl_eq0_wl                        <= 'b0;
        cnt_fromaxi_aw_bl_eq1_wl                        <= 'b0;
        cnt_fromaxi_aw_bl_eq2_wl                        <= 'b0;
        cnt_fromaxi_aw_bl_eq3_wl                        <= 'b0;
        cnt_fromaxi_aw_bp                               <= 'b0;
        cnt_fromaxi_w_wl                                <= 'b0;
        cnt_fromaxi_w_bp                                <= 'b0;
        cnt_fromaxi_smp_read_req_num                    <= 'b0;
        cnt_fromaxi_smp_read_req_sum                    <= 'b0;
        cnt_fromaxi_smp_write_req_num                   <= 'b0;
        cnt_fromaxi_smp_write_req_sum                   <= 'b0;
        cnt_fromaxi_smp_atomic_req_num                  <= 'b0;
        cnt_fromaxi_smp_atomic_req_sum                  <= 'b0;
        cnt_align_awdb_full                             <= 'b0;
        cnt_hittest_ht_bypass_read_wl                   <= 'b0;
        cnt_hittest_ht_cache_read_wl                    <= 'b0;
        cnt_hittest_ht_bypass_write_wl                  <= 'b0;
        cnt_hittest_ht_cache_write_wl                   <= 'b0;
        cnt_hittest_ht_atomic_wl                        <= 'b0;
        cnt_hittest_ht_bps_hit_wl                       <= 'b0;
        cnt_hittest_ht_miss_wl                          <= 'b0;
        cnt_frommemsch_nsp_rtn_wl                       <= 'b0;
        cnt_frommemsch_nsp_rtn_bp                       <= 'b0;
        cnt_tomemsch_nsp_read_bl_eq1_wl                 <= 'b0;
        cnt_tomemsch_nsp_read_bl_eq3_wl                 <= 'b0;
        cnt_tomemsch_nsp_read_bl_eq5_wl                 <= 'b0;
        cnt_tomemsch_nsp_read_bl_eq7_wl                 <= 'b0;
        cnt_tomemsch_nsp_write_bl_eq1_wl                <= 'b0;
        cnt_tomemsch_nsp_write_bl_eq3_wl                <= 'b0;
        cnt_tomemsch_nsp_write_bl_eq5_wl                <= 'b0;
        cnt_tomemsch_nsp_write_bl_eq7_wl                <= 'b0;
        cnt_memif_to_ddr_read_wl                        <= 'b0;
        cnt_memif_to_ddr_read_stall_by_rob              <= 'b0;
        cnt_memif_to_ddr_read_stall_by_ddr              <= 'b0;
        cnt_memif_to_ddr_read_stall_by_trid             <= 'b0;
        cnt_memif_to_ddr_write_wl                       <= 'b0;
        cnt_memif_to_ddr_write_stall_by_data_sync       <= 'b0;
        cnt_memif_to_ddr_write_stall_by_ddr             <= 'b0;
        cnt_memif_to_ddr_write_stall_by_trid            <= 'b0;
        cnt_memif_memreq_full                           <= 'b0;
        cnt_memif_smp_read_req_num                      <= 'b0;
        cnt_memif_smp_read_req_sum                      <= 'b0;
        cnt_reqsch_sortq_full                           <= 'b0;
        cnt_reqsch_sortq_stall_but_not_full             <= 'b0;
        cnt_reqsch_disp_wl                              <= 'b0;
        cnt_reqsch_disp_stall                           <= 'b0;
        cnt_ramctrl_0_reqarb_wl                         <= 'b0;
        cnt_ramctrl_0_reqarb_stall_by_sram              <= 'b0;
        cnt_ramctrl_0_data_sram_read_wl                 <= 'b0;
        cnt_ramctrl_0_data_sram_write_wl                <= 'b0;
        cnt_ramctrl_1_reqarb_wl                         <= 'b0;
        cnt_ramctrl_1_reqarb_stall_by_sram              <= 'b0;
        cnt_ramctrl_1_data_sram_read_wl                 <= 'b0;
        cnt_ramctrl_1_data_sram_write_wl                <= 'b0;
    end
    else begin
        if(l2b_busy)
            cnt_busy                                    <= cnt_busy                                  + 1'b1;
        if(l2b_fromaxi_ar_wl)
            cnt_fromaxi_ar_wl                           <= cnt_fromaxi_ar_wl                         + 1'b1;
        if(l2b_fromaxi_ar_bl_eq0_wl)
            cnt_fromaxi_ar_bl_eq0_wl                    <= cnt_fromaxi_ar_bl_eq0_wl                  + 1'b1;
        if(l2b_fromaxi_ar_bl_eq1_wl)
            cnt_fromaxi_ar_bl_eq1_wl                    <= cnt_fromaxi_ar_bl_eq1_wl                  + 1'b1;
        if(l2b_fromaxi_ar_bl_eq2_wl)
            cnt_fromaxi_ar_bl_eq2_wl                    <= cnt_fromaxi_ar_bl_eq2_wl                  + 1'b1;
        if(l2b_fromaxi_ar_bl_eq3_wl)
            cnt_fromaxi_ar_bl_eq3_wl                    <= cnt_fromaxi_ar_bl_eq3_wl                  + 1'b1;
        if(l2b_fromaxi_ar_bp)
            cnt_fromaxi_ar_bp                           <= cnt_fromaxi_ar_bp                         + 1'b1;
        if(l2b_toaxi_r_wl)
            cnt_toaxi_r_wl                              <= cnt_toaxi_r_wl                            + 1'b1;
        if(l2b_toaxi_r_bp)
            cnt_toaxi_r_bp                              <= cnt_toaxi_r_bp                            + 1'b1;
        if(l2b_fromaxi_aw_wl)
            cnt_fromaxi_aw_wl                           <= cnt_fromaxi_aw_wl                         + 1'b1;
        if(l2b_fromaxi_aw_bl_eq0_wl)
            cnt_fromaxi_aw_bl_eq0_wl                    <= cnt_fromaxi_aw_bl_eq0_wl                  + 1'b1;
        if(l2b_fromaxi_aw_bl_eq1_wl)
            cnt_fromaxi_aw_bl_eq1_wl                    <= cnt_fromaxi_aw_bl_eq1_wl                  + 1'b1;
        if(l2b_fromaxi_aw_bl_eq2_wl)
            cnt_fromaxi_aw_bl_eq2_wl                    <= cnt_fromaxi_aw_bl_eq2_wl                  + 1'b1;
        if(l2b_fromaxi_aw_bl_eq3_wl)
            cnt_fromaxi_aw_bl_eq3_wl                    <= cnt_fromaxi_aw_bl_eq3_wl                  + 1'b1;
        if(l2b_fromaxi_aw_bp)
            cnt_fromaxi_aw_bp                           <= cnt_fromaxi_aw_bp                         + 1'b1;
        if(l2b_fromaxi_w_wl)
            cnt_fromaxi_w_wl                            <= cnt_fromaxi_w_wl                          + 1'b1;
        if(l2b_fromaxi_w_bp)
            cnt_fromaxi_w_bp                            <= cnt_fromaxi_w_bp                          + 1'b1;
        if(l2b_fromaxi_smp_read_req_num)
            cnt_fromaxi_smp_read_req_num                <= cnt_fromaxi_smp_read_req_num              + 1'b1;
        if(l2b_fromaxi_smp_read_req_sum)
            cnt_fromaxi_smp_read_req_sum                <= cnt_fromaxi_smp_read_req_sum              + 1'b1;
        if(l2b_fromaxi_smp_write_req_num)
            cnt_fromaxi_smp_write_req_num               <= cnt_fromaxi_smp_write_req_num             + 1'b1;
        if(l2b_fromaxi_smp_write_req_sum)
            cnt_fromaxi_smp_write_req_sum               <= cnt_fromaxi_smp_write_req_sum             + 1'b1;
        if(l2b_fromaxi_smp_atomic_req_num)
            cnt_fromaxi_smp_atomic_req_num              <= cnt_fromaxi_smp_atomic_req_num            + 1'b1;
        if(l2b_fromaxi_smp_atomic_req_sum)
            cnt_fromaxi_smp_atomic_req_sum              <= cnt_fromaxi_smp_atomic_req_sum            + 1'b1;
        if(l2b_align_awdb_full)
            cnt_align_awdb_full                         <= cnt_align_awdb_full                       + 1'b1;
        if(l2b_hittest_ht_bypass_read_wl)
            cnt_hittest_ht_bypass_read_wl               <= cnt_hittest_ht_bypass_read_wl             + 1'b1;
        if(l2b_hittest_ht_cache_read_wl)
            cnt_hittest_ht_cache_read_wl                <= cnt_hittest_ht_cache_read_wl              + 1'b1;
        if(l2b_hittest_ht_bypass_write_wl)
            cnt_hittest_ht_bypass_write_wl              <= cnt_hittest_ht_bypass_write_wl            + 1'b1;
        if(l2b_hittest_ht_cache_write_wl)
            cnt_hittest_ht_cache_write_wl               <= cnt_hittest_ht_cache_write_wl             + 1'b1;
        if(l2b_hittest_ht_atomic_wl)
            cnt_hittest_ht_atomic_wl                    <= cnt_hittest_ht_atomic_wl                  + 1'b1;
        if(l2b_hittest_ht_bps_hit_wl)
            cnt_hittest_ht_bps_hit_wl                   <= cnt_hittest_ht_bps_hit_wl                 + 1'b1;
        if(l2b_hittest_ht_miss_wl)
            cnt_hittest_ht_miss_wl                      <= cnt_hittest_ht_miss_wl                    + 1'b1;
        if(l2b_frommemsch_nsp_rtn_wl)
            cnt_frommemsch_nsp_rtn_wl                   <= cnt_frommemsch_nsp_rtn_wl                 + 1'b1;
        if(l2b_frommemsch_nsp_rtn_bp)
            cnt_frommemsch_nsp_rtn_bp                   <= cnt_frommemsch_nsp_rtn_bp                 + 1'b1;
        if(l2b_tomemsch_nsp_read_bl_eq1_wl)
            cnt_tomemsch_nsp_read_bl_eq1_wl             <= cnt_tomemsch_nsp_read_bl_eq1_wl           + 1'b1;
        if(l2b_tomemsch_nsp_read_bl_eq3_wl)
            cnt_tomemsch_nsp_read_bl_eq3_wl             <= cnt_tomemsch_nsp_read_bl_eq3_wl           + 1'b1;
        if(l2b_tomemsch_nsp_read_bl_eq5_wl)
            cnt_tomemsch_nsp_read_bl_eq5_wl             <= cnt_tomemsch_nsp_read_bl_eq5_wl           + 1'b1;
        if(l2b_tomemsch_nsp_read_bl_eq7_wl)
            cnt_tomemsch_nsp_read_bl_eq7_wl             <= cnt_tomemsch_nsp_read_bl_eq7_wl           + 1'b1;
        if(l2b_tomemsch_nsp_write_bl_eq1_wl)
            cnt_tomemsch_nsp_write_bl_eq1_wl            <= cnt_tomemsch_nsp_write_bl_eq1_wl          + 1'b1;
        if(l2b_tomemsch_nsp_write_bl_eq3_wl)
            cnt_tomemsch_nsp_write_bl_eq3_wl            <= cnt_tomemsch_nsp_write_bl_eq3_wl          + 1'b1;
        if(l2b_tomemsch_nsp_write_bl_eq5_wl)
            cnt_tomemsch_nsp_write_bl_eq5_wl            <= cnt_tomemsch_nsp_write_bl_eq5_wl          + 1'b1;
        if(l2b_tomemsch_nsp_write_bl_eq7_wl)
            cnt_tomemsch_nsp_write_bl_eq7_wl            <= cnt_tomemsch_nsp_write_bl_eq7_wl          + 1'b1;
        if(l2b_memif_to_ddr_read_wl)
            cnt_memif_to_ddr_read_wl                    <= cnt_memif_to_ddr_read_wl                  + 1'b1;
        if(l2b_memif_to_ddr_read_stall_by_rob)
            cnt_memif_to_ddr_read_stall_by_rob          <= cnt_memif_to_ddr_read_stall_by_rob        + 1'b1;
        if(l2b_memif_to_ddr_read_stall_by_ddr)
            cnt_memif_to_ddr_read_stall_by_ddr          <= cnt_memif_to_ddr_read_stall_by_ddr        + 1'b1;
        if(l2b_memif_to_ddr_read_stall_by_trid)
            cnt_memif_to_ddr_read_stall_by_trid         <= cnt_memif_to_ddr_read_stall_by_trid       + 1'b1;
        if(l2b_memif_to_ddr_write_wl)
            cnt_memif_to_ddr_write_wl                   <= cnt_memif_to_ddr_write_wl                 + 1'b1;
        if(l2b_memif_to_ddr_write_stall_by_data_sync)
            cnt_memif_to_ddr_write_stall_by_data_sync   <= cnt_memif_to_ddr_write_stall_by_data_sync + 1'b1;
        if(l2b_memif_to_ddr_write_stall_by_ddr)
            cnt_memif_to_ddr_write_stall_by_ddr         <= cnt_memif_to_ddr_write_stall_by_ddr       + 1'b1;
        if(l2b_memif_to_ddr_write_stall_by_trid)
            cnt_memif_to_ddr_write_stall_by_trid        <= cnt_memif_to_ddr_write_stall_by_trid      + 1'b1;
        if(l2b_memif_memreq_full)
            cnt_memif_memreq_full                       <= cnt_memif_memreq_full                     + 1'b1;
        if(l2b_memif_smp_read_req_num)
            cnt_memif_smp_read_req_num                  <= cnt_memif_smp_read_req_num                + 1'b1;
        if(l2b_memif_smp_read_req_sum)
            cnt_memif_smp_read_req_sum                  <= cnt_memif_smp_read_req_sum                + 1'b1;
        if(l2b_reqsch_sortq_full)
            cnt_reqsch_sortq_full                       <= cnt_reqsch_sortq_full                     + 1'b1;
        if(l2b_reqsch_sortq_stall_but_not_full)
            cnt_reqsch_sortq_stall_but_not_full         <= cnt_reqsch_sortq_stall_but_not_full       + 1'b1;
        if(l2b_reqsch_disp_wl)
            cnt_reqsch_disp_wl                          <= cnt_reqsch_disp_wl                        + 1'b1;
        if(l2b_reqsch_disp_stall)
            cnt_reqsch_disp_stall                       <= cnt_reqsch_disp_stall                     + 1'b1;
        if(l2b_ramctrl_0_reqarb_wl)
            cnt_ramctrl_0_reqarb_wl                     <= cnt_ramctrl_0_reqarb_wl                   + 1'b1;
        if(l2b_ramctrl_0_reqarb_stall_by_sram)
            cnt_ramctrl_0_reqarb_stall_by_sram          <= cnt_ramctrl_0_reqarb_stall_by_sram        + 1'b1;
        if(l2b_ramctrl_0_data_sram_read_wl)
            cnt_ramctrl_0_data_sram_read_wl             <= cnt_ramctrl_0_data_sram_read_wl           + 1'b1;
        if(l2b_ramctrl_0_data_sram_write_wl)
            cnt_ramctrl_0_data_sram_write_wl            <= cnt_ramctrl_0_data_sram_write_wl          + 1'b1;
        if(l2b_ramctrl_1_reqarb_wl)
            cnt_ramctrl_1_reqarb_wl                     <= cnt_ramctrl_1_reqarb_wl                   + 1'b1;
        if(l2b_ramctrl_1_reqarb_stall_by_sram)
            cnt_ramctrl_1_reqarb_stall_by_sram          <= cnt_ramctrl_1_reqarb_stall_by_sram        + 1'b1;
        if(l2b_ramctrl_1_data_sram_read_wl)
            cnt_ramctrl_1_data_sram_read_wl             <= cnt_ramctrl_1_data_sram_read_wl           + 1'b1;
        if(l2b_ramctrl_1_data_sram_write_wl)
            cnt_ramctrl_1_data_sram_write_wl            <= cnt_ramctrl_1_data_sram_write_wl          + 1'b1;
    end
end

logic [39:0] cnt_fromaxi_smp_read_req_lat               ;
logic [39:0] cnt_fromaxi_smp_write_req_lat              ;
logic [39:0] cnt_fromaxi_smp_atomic_req_lat             ;
logic [39:0] cnt_memif_smp_read_req_lat                 ;
logic [39:0] cnt_hittest_ht_hit_wl                      ;

assign cnt_fromaxi_smp_read_req_lat     = cnt_fromaxi_smp_read_req_sum/cnt_fromaxi_smp_read_req_num;
assign cnt_fromaxi_smp_write_req_lat    = cnt_fromaxi_smp_write_req_sum/cnt_fromaxi_smp_read_req_num;
assign cnt_fromaxi_smp_atomic_req_lat   = cnt_fromaxi_smp_atomic_req_sum/cnt_fromaxi_smp_read_req_num;
assign cnt_memif_smp_read_req_lat       = cnt_memif_smp_read_req_sum/cnt_memif_smp_read_req_num;
assign cnt_hittest_ht_hit_wl            = cnt_fromaxi_ar_wl + cnt_fromaxi_aw_wl - cnt_hittest_ht_miss_wl;

localparam  int     AXI_ID_NUN  = 2**L2_AXI_ID_WIDTH;
localparam  int     NSP_ID_NUM  = 2**L2_NSP_ARID_WIDTH + 2**L2_NSP_AWID_WIDTH;

logic   axi_rd_req;
logic   axi_wr_req;
logic   axi_aa_req;
logic   axi_rd_rtn;
logic   axi_wr_rtn;
logic   axi_aa_rtn_b;
logic   axi_aa_rtn_r;
logic   axi_aa_rtn_br;
logic   nsp_rd_req;
logic   nsp_wr_req;
logic   nsp_rd_rtn;
logic   nsp_wr_rtn;
logic   nsp_req;
logic   nsp_rtn;
logic [AXI_ID_NUN-1 : 0]        axi_aa_b_rtn_f;
logic [AXI_ID_NUN-1 : 0]        axi_aa_r_rtn_f;
logic [AXI_ID_NUN-1 : 0]        axi_rd_id_busy;
logic [AXI_ID_NUN-1 : 0]        axi_wr_id_busy;
logic [AXI_ID_NUN-1 : 0]        axi_aa_id_busy;
logic [AXI_ID_NUN-1 : 0][63:0]  axi_rd_id_lat;
logic [AXI_ID_NUN-1 : 0][63:0]  axi_wr_id_lat;
logic [AXI_ID_NUN-1 : 0][63:0]  axi_aa_id_lat;
logic                   [63:0]  axi_rd_req_cnt;
logic                   [63:0]  axi_wr_req_cnt;
logic                   [63:0]  axi_aa_req_cnt;
logic                   [63:0]  axi_rd_lat_cnt;
logic                   [63:0]  axi_wr_lat_cnt;
logic                   [63:0]  axi_aa_lat_cnt;
logic                   [63:0]  axi_rd_avg_lat;
logic                   [63:0]  axi_wr_avg_lat;
logic                   [63:0]  axi_aa_avg_lat;
logic                   [63:0]  axi_rd_min_lat;
logic                   [63:0]  axi_wr_min_lat;
logic                   [63:0]  axi_aa_min_lat;
logic                   [63:0]  axi_rd_max_lat;
logic                   [63:0]  axi_wr_max_lat;
logic                   [63:0]  axi_aa_max_lat;
logic                   [63:0]  axi_rd_rtn_lat;
logic                   [63:0]  axi_wr_rtn_lat;
logic                   [63:0]  axi_aa_rtn_lat_b;
logic                   [63:0]  axi_aa_rtn_lat_r;

logic [NSP_ID_NUM-1 : 0]        nsp_id_busy;
logic [NSP_ID_NUM-1 : 0]        nsp_id_rd;
logic [NSP_ID_NUM-1 : 0][63:0]  nsp_rd_id_lat;
logic [NSP_ID_NUM-1 : 0][63:0]  nsp_wr_id_lat;
logic                   [63:0]  nsp_rd_req_cnt;
logic                   [63:0]  nsp_wr_req_cnt;
logic                   [63:0]  nsp_rd_lat_cnt;
logic                   [63:0]  nsp_wr_lat_cnt;
logic                   [63:0]  nsp_rd_avg_lat;
logic                   [63:0]  nsp_rd_min_lat;
logic                   [63:0]  nsp_rd_max_lat;
logic                   [63:0]  nsp_wr_avg_lat;
logic                   [63:0]  nsp_wr_min_lat;
logic                   [63:0]  nsp_wr_max_lat;

assign axi_rd_req   = axi_slv_arvalid && axi_slv_arready;
assign axi_wr_req   = axi_slv_awvalid && axi_slv_awready && (axi_slv_aw_rec.atop == 'b0);
assign axi_aa_req   = axi_slv_awvalid && axi_slv_awready && (axi_slv_aw_rec.atop != 'b0);
assign axi_rd_rtn   = axi_slv_rvalid  && axi_slv_rready  &&  axi_slv_r_rec.last && axi_rd_id_busy[axi_slv_r_rec.id];
assign axi_wr_rtn   = axi_slv_bvalid  && axi_slv_bready  &&  axi_wr_id_busy[axi_slv_b_rec.id];
assign axi_aa_rtn_b = axi_slv_bvalid  && axi_slv_bready  &&  axi_aa_id_busy[axi_slv_b_rec.id];
assign axi_aa_rtn_r = axi_slv_rvalid  && axi_slv_rready  &&  axi_aa_id_busy[axi_slv_r_rec.id];
assign axi_aa_rtn_br= axi_aa_rtn_b    && axi_aa_rtn_r    && (axi_slv_b_rec.id==axi_slv_r_rec.id);
assign nsp_req      = nsp_req_valid   && nsp_req_ready   &&  nsp_req_rec.last;
assign nsp_rtn      = nsp_rsp_valid   && nsp_rsp_ready   &&  nsp_rsp_rec.last;
assign nsp_rd_req   = nsp_req         && (nsp_req_rec.opc == 'h0);
assign nsp_wr_req   = nsp_req         && (nsp_req_rec.opc == 'h4);
assign nsp_rd_rtn   = nsp_rtn         &&  nsp_id_rd[nsp_rsp_rec.trid];
assign nsp_wr_rtn   = nsp_rtn         && ~nsp_id_rd[nsp_rsp_rec.trid];

generate
for(genvar AID=0; AID<AXI_ID_NUN; AID++) begin
    // atomic write response and read response
    always_ff @(posedge clk or negedge resetn) begin
        if(!resetn) begin
            axi_aa_b_rtn_f[AID] <= 'b0;
            axi_aa_r_rtn_f[AID] <= 'b0;
        end
        else if(axi_aa_rtn_b  && (AID==axi_slv_b_rec.id) && axi_aa_r_rtn_f[AID]) begin
            axi_aa_b_rtn_f[AID] <= 'b0;
            axi_aa_r_rtn_f[AID] <= 'b0;
        end
        else if(axi_aa_rtn_r  && (AID==axi_slv_r_rec.id) && axi_aa_b_rtn_f[AID]) begin
            axi_aa_b_rtn_f[AID] <= 'b0;
            axi_aa_r_rtn_f[AID] <= 'b0;
        end
        else if(axi_aa_rtn_br && (AID==axi_slv_r_rec.id)) begin
            axi_aa_b_rtn_f[AID] <= 'b0;
            axi_aa_r_rtn_f[AID] <= 'b0;
        end
        else begin
            if(axi_aa_rtn_b && (AID==axi_slv_b_rec.id))
                axi_aa_b_rtn_f[AID] <= 1'b1;
            if(axi_aa_rtn_r && (AID==axi_slv_r_rec.id))
                axi_aa_r_rtn_f[AID] <= 1'b1;
        end
    end

    // latency counter enable per axi id
    always_ff @(posedge clk or negedge resetn) begin
        if(!resetn) begin
            axi_rd_id_busy[AID] <= 'b0;
            axi_wr_id_busy[AID] <= 'b0;
            axi_aa_id_busy[AID] <= 'b0;
        end
        else begin
            if(axi_rd_rtn && (AID == axi_slv_r_rec.id))
                axi_rd_id_busy[AID] <= 'b0;
            else if(axi_rd_req && (AID == axi_slv_ar_rec.id))
                axi_rd_id_busy[AID] <= 'b1;

            if(axi_wr_rtn && (AID == axi_slv_b_rec.id))
                axi_wr_id_busy[AID] <= 'b0;
            else if(axi_wr_req && (AID == axi_slv_aw_rec.id))
                axi_wr_id_busy[AID] <= 'b1;

            if(axi_aa_rtn_b && (AID==axi_slv_b_rec.id) && axi_aa_r_rtn_f[AID])
                axi_aa_id_busy[AID] <= 'b0;
            else if(axi_aa_rtn_r && (AID==axi_slv_r_rec.id) && axi_aa_b_rtn_f[AID])
                axi_aa_id_busy[AID] <= 'b0;
            else if(axi_aa_rtn_br && (AID==axi_slv_r_rec.id))
                axi_aa_id_busy[AID] <= 'b0;
            else if(axi_aa_req && (AID == axi_slv_aw_rec.id))
                axi_aa_id_busy[AID] <= 'b1;
        end
    end

    // latency counter per axi id
    always_ff @(posedge clk or negedge resetn) begin
        if(!resetn) begin
            axi_rd_id_lat[AID] <= 'b0;
            axi_wr_id_lat[AID] <= 'b0;
            axi_aa_id_lat[AID] <= 'b0;
        end
        else begin
            if(axi_rd_id_busy[AID])
                axi_rd_id_lat[AID] <= axi_rd_id_lat[AID] + 1'b1;
            else
                axi_rd_id_lat[AID] <= 'b0;

            if(axi_wr_id_busy[AID])
                axi_wr_id_lat[AID] <= axi_wr_id_lat[AID] + 1'b1;
            else
                axi_wr_id_lat[AID] <= 'b0;
            
            if(axi_aa_id_busy[AID])
                axi_aa_id_lat[AID] <= axi_aa_id_lat[AID] + 1'b1;
            else
                axi_aa_id_lat[AID] <= 'b0;
        end
    end
end
endgenerate

// axi request counter and total latency counter
assign axi_rd_rtn_lat   = axi_rd_id_lat[axi_slv_r_rec.id] + 1'b1;
assign axi_wr_rtn_lat   = axi_wr_id_lat[axi_slv_b_rec.id] + 1'b1;
assign axi_aa_rtn_lat_b = axi_aa_id_lat[axi_slv_b_rec.id] + 1'b1;
assign axi_aa_rtn_lat_r = axi_aa_id_lat[axi_slv_r_rec.id] + 1'b1;
always_ff @(posedge clk or negedge resetn) begin
    if(!resetn) begin
        axi_rd_req_cnt <= 'b0;
        axi_wr_req_cnt <= 'b0;
        axi_aa_req_cnt <= 'b0;
        axi_rd_lat_cnt <= 'b0;
        axi_wr_lat_cnt <= 'b0;
        axi_aa_lat_cnt <= 'b0;
        axi_rd_min_lat <= '1;
        axi_wr_min_lat <= '1;
        axi_aa_min_lat <= '1;
        axi_rd_max_lat <= '0;
        axi_wr_max_lat <= '0;
        axi_aa_max_lat <= '0;
    end
    else begin
        if(axi_rd_req)
            axi_rd_req_cnt  <= axi_rd_req_cnt + 1'b1;
        if(axi_wr_req)
            axi_wr_req_cnt  <= axi_wr_req_cnt + 1'b1;
        if(axi_aa_req)
            axi_aa_req_cnt  <= axi_aa_req_cnt + 1'b1;

        if(axi_rd_rtn) begin
            axi_rd_lat_cnt  <= axi_rd_lat_cnt + axi_rd_rtn_lat;
            if(axi_rd_rtn_lat < axi_rd_min_lat)
                axi_rd_min_lat <= axi_rd_rtn_lat;
            if(axi_rd_rtn_lat > axi_rd_max_lat)
                axi_rd_max_lat <= axi_rd_rtn_lat;
        end

        if(axi_wr_rtn) begin
            axi_wr_lat_cnt  <= axi_wr_lat_cnt + axi_wr_rtn_lat;
            if(axi_wr_rtn_lat < axi_wr_min_lat)
                axi_wr_min_lat <= axi_wr_rtn_lat;
            if(axi_wr_rtn_lat > axi_wr_max_lat)
                axi_wr_max_lat <= axi_wr_rtn_lat;
        end

        if(axi_aa_rtn_b && (axi_aa_r_rtn_f[axi_slv_b_rec.id])) begin
            axi_aa_lat_cnt  <= axi_aa_lat_cnt + axi_aa_rtn_lat_b;
            if(axi_aa_rtn_lat_b < axi_aa_min_lat)
                axi_aa_min_lat <= axi_aa_rtn_lat_b;
            if(axi_aa_rtn_lat_b > axi_aa_max_lat)
                axi_aa_max_lat <= axi_aa_rtn_lat_b;
        end
        else if((axi_aa_rtn_r && (axi_aa_b_rtn_f[axi_slv_r_rec.id])) || axi_aa_rtn_br) begin
            axi_aa_lat_cnt  <= axi_aa_lat_cnt + axi_aa_rtn_lat_r;
            if(axi_aa_rtn_lat_r < axi_aa_min_lat)
                axi_aa_min_lat <= axi_aa_rtn_lat_r;
            if(axi_aa_rtn_lat_r > axi_aa_max_lat)
                axi_aa_max_lat <= axi_aa_rtn_lat_r;
        end
    end
end

generate
for(genvar NID=0; NID<NSP_ID_NUM; NID++) begin
    // nsp latency counter enable per id
    always_ff @(posedge clk or negedge resetn) begin
        if(!resetn) begin
            nsp_id_busy[NID] <= 'b0;
            nsp_id_rd  [NID] <= 'b0;
        end
        else begin
            if(nsp_rtn && (NID == nsp_rsp_rec.trid))
                nsp_id_busy[NID] <= 1'b0;
            else if(nsp_req && (NID == nsp_req_rec.trid))
                nsp_id_busy[NID] <= 1'b1;

            if(nsp_rd_req && (NID == nsp_req_rec.trid))
                nsp_id_rd  [NID] <= 1'b1;
            else if(nsp_wr_req && (NID == nsp_req_rec.trid))
                nsp_id_rd  [NID] <= 1'b0;
        end
    end

    // nsp latency counter per id
    always_ff @(posedge clk or negedge resetn) begin
        if(!resetn) begin
            nsp_rd_id_lat[NID] <= 'b0;
            nsp_wr_id_lat[NID] <= 'b0;
        end
        else if(nsp_id_busy[NID]) begin
            if(nsp_id_rd[NID])
                nsp_rd_id_lat[NID] <= nsp_rd_id_lat[NID] + 1'b1;
            else
                nsp_wr_id_lat[NID] <= nsp_wr_id_lat[NID] + 1'b1;
        end
        else begin
            nsp_rd_id_lat[NID] <= 'b0;
            nsp_wr_id_lat[NID] <= 'b0;
        end
    end
end
endgenerate

// nsp request counter and total/min/max latency counter
always_ff @(posedge clk or negedge resetn) begin
    if(!resetn) begin
        nsp_rd_req_cnt <= 'b0;
        nsp_wr_req_cnt <= 'b0;
        nsp_rd_lat_cnt <= 'b0;
        nsp_wr_lat_cnt <= 'b0;
        nsp_rd_min_lat <= '1;
        nsp_rd_max_lat <= 'b0;
        nsp_wr_min_lat <= '1;
        nsp_wr_max_lat <= 'b0;
    end
    else begin
        if(nsp_rd_req)
            nsp_rd_req_cnt <= nsp_rd_req_cnt + 1'b1;
        if(nsp_wr_req)
            nsp_wr_req_cnt <= nsp_wr_req_cnt + 1'b1;

        if(nsp_rd_rtn)
            nsp_rd_lat_cnt <= nsp_rd_lat_cnt + nsp_rd_id_lat[nsp_rsp_rec.trid] + 1'b1;
        if(nsp_wr_rtn)
            nsp_wr_lat_cnt <= nsp_wr_lat_cnt + nsp_wr_id_lat[nsp_rsp_rec.trid] + 1'b1;

        if(nsp_rd_rtn) begin
            if((nsp_rd_id_lat[nsp_rsp_rec.trid]+ 1'b1) < nsp_rd_min_lat)
                nsp_rd_min_lat <= nsp_rd_id_lat[nsp_rsp_rec.trid] + 1'b1;
            if((nsp_rd_id_lat[nsp_rsp_rec.trid]+ 1'b1) > nsp_rd_max_lat)
                nsp_rd_max_lat <= nsp_rd_id_lat[nsp_rsp_rec.trid] + 1'b1;
        end
        if(nsp_wr_rtn) begin
            if((nsp_wr_id_lat[nsp_rsp_rec.trid]+ 1'b1) < nsp_wr_min_lat)
                nsp_wr_min_lat <= nsp_wr_id_lat[nsp_rsp_rec.trid] + 1'b1;
            if((nsp_wr_id_lat[nsp_rsp_rec.trid]+ 1'b1) > nsp_wr_max_lat)
                nsp_wr_max_lat <= nsp_wr_id_lat[nsp_rsp_rec.trid] + 1'b1;
        end
    end
end

assign axi_rd_avg_lat = axi_rd_lat_cnt/axi_rd_req_cnt;
assign axi_wr_avg_lat = axi_wr_lat_cnt/axi_wr_req_cnt;
assign axi_aa_avg_lat = axi_aa_lat_cnt/axi_aa_req_cnt;
assign nsp_rd_avg_lat = nsp_rd_lat_cnt/nsp_rd_req_cnt;
assign nsp_wr_avg_lat = nsp_wr_lat_cnt/nsp_wr_req_cnt;

logic [L2_NUM_SET-1         : 0][31:0]  tc_req_s0_set_cnt;

generate 
for(genvar SET=0; SET<L2_NUM_SET; SET++) begin
always_ff @(posedge clk or negedge resetn) begin
    if(!resetn) begin
        tc_req_s0_set_cnt[SET]  <= 'b0;
    end
    else if(i_gc_l2_bank_tagctrl.request_stage0_valid && 
            i_gc_l2_bank_tagctrl.request_stage0_ready && 
           (i_gc_l2_bank_tagctrl.request_stage0_rec.set == SET)) begin
        tc_req_s0_set_cnt[SET]  <= tc_req_s0_set_cnt[SET] + 1'b1;
    end
end
end // end for loop
endgenerate

logic [31:0]    l2_perf_file;

// clear l2_perf_file when simulation start
initial begin
    l2_perf_file = $fopen("l2_perf_info.txt", "w+");
    $fclose(l2_perf_file);
end

final begin
    // $info   ("L2 perf info: ====================================================");
    // $display("L2 perf info: cnt_hittest_ht_hit_wl   = %6d", cnt_hittest_ht_hit_wl   );
    // $display("L2 perf info: cnt_hittest_ht_miss_wl  = %6d", cnt_hittest_ht_miss_wl  );
    // $display("L2 perf info: axi_rd_avg_lat          = %6d", axi_rd_avg_lat          );
    // $display("L2 perf info: axi_wr_avg_lat          = %6d", axi_wr_avg_lat          );
    // $display("L2 perf info: axi_aa_avg_lat          = %6d", axi_aa_avg_lat          );
    // $display("L2 perf info: nsp_rd_avg_lat          = %6d", nsp_rd_avg_lat          );
    // $display("L2 perf info: nsp_rd_min_lat          = %6d", nsp_rd_min_lat          );
    // $display("L2 perf info: nsp_rd_max_lat          = %6d", nsp_rd_max_lat          );
    // $display("L2 perf info: nsp_wr_avg_lat          = %6d", nsp_wr_avg_lat          );
    // $display("L2 perf info: nsp_wr_min_lat          = %6d", nsp_wr_min_lat          );
    // $display("L2 perf info: nsp_wr_max_lat          = %6d", nsp_wr_max_lat          );

    l2_perf_file = $fopen("l2_perf_info.txt", "a+");
    $fwrite(l2_perf_file,"======================================================\n");
    $fdisplay(l2_perf_file,"Hierarchy: %m");
    $fwrite(l2_perf_file,"======================================================\n");
    $fwrite(l2_perf_file, "hit rate                = %8f\n", (cnt_hittest_ht_hit_wl*1.0)/(cnt_hittest_ht_hit_wl+cnt_hittest_ht_miss_wl));
    $fwrite(l2_perf_file, "cnt_hittest_ht_hit_wl   = %8d\n", cnt_hittest_ht_hit_wl );
    $fwrite(l2_perf_file, "cnt_hittest_ht_miss_wl  = %8d\n", cnt_hittest_ht_miss_wl);
    $fwrite(l2_perf_file, "AXI_RD avg_lat= %5d, min_lat= %5d, max_lat= %5d\n",axi_rd_avg_lat, axi_rd_min_lat, axi_rd_max_lat);
    $fwrite(l2_perf_file, "AXI_WR avg_lat= %5d, min_lat= %5d, max_lat= %5d\n",axi_wr_avg_lat, axi_wr_min_lat, axi_wr_max_lat);
    $fwrite(l2_perf_file, "AXI_AA avg_lat= %5d, min_lat= %5d, max_lat= %5d\n",axi_aa_avg_lat, axi_aa_min_lat, axi_aa_max_lat);
    $fwrite(l2_perf_file, "NSP_RD avg_lat= %5d, min_lat= %5d, max_lat= %5d\n",nsp_rd_avg_lat, nsp_rd_min_lat, nsp_rd_max_lat);
    $fwrite(l2_perf_file, "NSP_WR avg_lat= %5d, min_lat= %5d, max_lat= %5d\n",nsp_wr_avg_lat, nsp_wr_min_lat, nsp_wr_max_lat);
    for(int SET=0; SET<L2_NUM_SET; SET++) begin
    $fwrite(l2_perf_file, "tagctrl_s0_acc_set %3d  = %8d\n", SET, tc_req_s0_set_cnt[SET]);
    end
    $fclose(l2_perf_file);

    // $display("L2 perf info: cnt_fromaxi_ar_wl                           = %6d", cnt_fromaxi_ar_wl                        );
    // $display("L2 perf info: cnt_fromaxi_aw_wl                           = %6d", cnt_fromaxi_aw_wl                        );
    // $display("L2 perf info: cnt_memif_to_ddr_read_wl                    = %6d", cnt_memif_to_ddr_read_wl                 );
    // $display("L2 perf info: cnt_memif_to_ddr_read_stall_by_rob          = %6d", cnt_memif_to_ddr_read_stall_by_rob       );
    // $display("L2 perf info: cnt_memif_to_ddr_write_wl                   = %6d", cnt_memif_to_ddr_write_wl                );
    // $display("L2 perf info: cnt_memif_to_ddr_write_stall_by_data_sync   = %6d", cnt_memif_to_ddr_write_stall_by_data_sync);
    // $display("L2 perf info: cnt_align_awdb_full                         = %6d", cnt_align_awdb_full                      );
    // $display("L2 perf info: cnt_memif_memreq_full                       = %6d", cnt_memif_memreq_full                    );
    // $display("L2 perf info: cnt_reqsch_sortq_full                       = %6d", cnt_reqsch_sortq_full                    );
    // $display("L2 perf info: cnt_reqsch_sortq_stall_but_not_full         = %6d", cnt_reqsch_sortq_stall_but_not_full      );
    // $display("L2 perf info: cnt_reqsch_disp_wl                          = %6d", cnt_reqsch_disp_wl                       );
    // $display("L2 perf info: cnt_ramctrl_0_reqarb_wl                     = %6d", cnt_ramctrl_0_reqarb_wl                  );
    // $display("L2 perf info: cnt_ramctrl_1_reqarb_wl                     = %6d", cnt_ramctrl_1_reqarb_wl                  );

end

// synopsys translate_on




endmodule

