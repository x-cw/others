/*

 * #==========================================================================#
 * |                                                                          |
 * |  Copyright (c) 2022, Fantasy Technologies Limited and/or its         |
 * |  affiliated group companies ("Fantasy"). All rights reserved.        |
 * |  No part of this content, either material or conceptual may be copied    |
 * |  or distributed, transmitted, transcribed, stored in a retrieval system  |
 * |  or translated into any human or computer language in any form by any    |
 * |  means, electronic, mechanical manual, or otherwise, or disclosed to     |
 * |  third parties without the express written permission of Fantasy.    |
 * |                                                                          |
 * #==========================================================================#

 */

// ---------------------------------------------------------------------------------------------------------------------------------
// entity name: gpc_gfx_timing_buffer_pack
// purpose: Define the buffer type constants for the gpc_gfx_timing_buffer component
// ---------------------------------------------------------------------------------------------------------------------------------

// *****************************************************************************************************************
// ****  The VHDL version gpc_gfx_timing_buffer_pack.vhd must also be updated whenever this file is modified    ****
// *****************************************************************************************************************
package gpc_gfx_timing_buffer_pack_;

   localparam GPC_GFX_TIMING_BUFFER_WIRE                 = 0;
   localparam GPC_GFX_TIMING_BUFFER_PIPE_REG             = 1;
   localparam GPC_GFX_TIMING_BUFFER_RSTL                 = 2;
   localparam GPC_GFX_TIMING_BUFFER_RSTL_LOWPWR          = 3;
   localparam GPC_GFX_TIMING_BUFFER_RSTL_FASTIN          = 4;
   localparam GPC_GFX_TIMING_BUFFER_HSTL                 = 5;
   localparam GPC_GFX_TIMING_BUFFER_MSTL                 = 6;
   localparam GPC_GFX_TIMING_BUFFER_MSTL_CASCADE         = 7;
   localparam GPC_GFX_TIMING_BUFFER_RSTL_WAKEUP          = 8;
   localparam GPC_GFX_TIMING_BUFFER_RSTL_FASTIN_WAKEUP   = 9;
   localparam GPC_GFX_TIMING_BUFFER_RSTL_WAKEUP_X2       =10;
   localparam GPC_GFX_TIMING_BUFFER_PIPE_REG_INIT        =11;

endpackage
