/*

 * #==========================================================================#
 * |                                                                          |
 * |  Copyright (c) 2022, Fantasy Technologies Limited and/or its         |
 * |  affiliated group companies ("Fantasy"). All rights reserved.        |
 * |  No part of this content, either material or conceptual may be copied    |
 * |  or distributed, transmitted, transcribed, stored in a retrieval system  |
 * |  or translated into any human or computer language in any form by any    |
 * |  means, electronic, mechanical manual, or otherwise, or disclosed to     |
 * |  third parties without the express written permission of Fantasy.    |
 * |                                                                          |
 * #==========================================================================#

 */

///////////////////////////////////////////////////////////////////////////////////////
// Finds the first '1' bit in the 'din' input vector, starting at the bit position 
// defined by 'start', wrapping as necessary. Returns the index of the first '1' bit. 
// The returned index will be all 0's if no input 'din' bits are set, but this can't
// be used to determine if any bits were found or not (use the 'found' output for that).
//
// This core algorithm only works for a power-of-2 number of bits, so the input bits
// are first padded to make a power-of-2.
//
// The algorithm repeatedly sub-divides the input bits into an upper and lower half,
// searching each half separately and then selecting the left or right half as necessary.
// Since the search always proceeds from LSB to MSB, the right (i.e. LSB) half result
// is always selected in preference to the left half result.
//
// At the leaf node of the tree (where the actual search happens), we are simply searching
// two data bits. The left/right result signals passed up the tree carry the actual search
// result (i.e. found / not found) in the LSB, and the MSBs encode which half the result
// was found in. Each level up the tree appends another MSB to the result, meaning that the
// final result at the top of the tree contains the index in the MSB:1, and the found/not
// found result in the LSB.
//
// The 'start' signals passing down the tree are used to force the search result on or off
// for each half of the search, and this has the effect of masking out any search hits
// below the starting index for the search.
//
// To implement the wrapping mode, two searches are performed in parallel. One from the start
// point up to the MSB, and the other from the LSB to the MSB. If the first search (from 
// start point) finds a hit, then that is the result, otherwise we use the result from the
// 2nd search (LSB to MSB)
//
// The tree structure allows the logic depth to be minimised, and it's possible to search
// 100's (maybe even 1000's) of bits and still meet timing.
//
///////////////////////////////////////////////////////////////////////////////////////

module gpc_gfx_find_first_ #(
   parameter BITS       = 8,
   parameter ALLOW_WRAP = 1, //if 1, the search is allowed to wrap from the MSB to LSB (assuming 'start' > 0)
   parameter INDEX_BITS = $clog2(BITS)
) (
   input  logic [BITS-1:0]          din,
   input  logic [INDEX_BITS-1:0]    start,
   output logic [INDEX_BITS-1:0]    index,
   output logic                     found
);

   localparam BITS_POW2    = 2 ** INDEX_BITS;
   //one search (from start to MSB) if ALLOW_WRAP=0
   //two searched ((from start to MSB, and from LSB to MSB) if ALLOW_WRAP=1
   localparam NUM_SEARCHES = ALLOW_WRAP+1;

   localparam TREE_DEPTH = INDEX_BITS;
   
   typedef struct packed {
      logic on_; //underscore to avoid SV reserved word
      logic off;
   } force_t;
   
   logic [NUM_SEARCHES-1:0][INDEX_BITS:0]    result;
   logic [BITS_POW2-1:0]                     din_padded;

   assign din_padded = (BITS_POW2)'(din);
   
   //iterate over the 1 or 2 searches
   for(genvar S=0; S<NUM_SEARCHES; S++) begin : g_search

      //not all of the bits of these 'tree' signals will be used, but we have to size these arrays
      //to hold the maximum number of bits associated with the leaf node level of the tree. 
      //*** THERE WILL BY SPYGLASS WARNINGS ABOUT UNUSED / UNDRIVEN SIGNALS WHICH WILL NEED TO BE WAIVED ***

      //result bits, coming up the tree
      logic    [BITS_POW2-1:0]  tree_result  [TREE_DEPTH-1:0];
      //force bits, going down the tree
      force_t  [BITS_POW2-1:0]  tree_force   [TREE_DEPTH-1:0];

      logic [INDEX_BITS-1:0]                    search_start;

      assign tree_force[0][0] = '0;
      
      if(S==0) begin
         assign search_start = start;
      end
      else begin
         assign search_start = '0;
      end

      //iterate over the levels of the tree, starting at the root (top)
      for(genvar LEVEL=0; LEVEL<TREE_DEPTH; LEVEL++) begin : g_tree_levels

         //constants for this level of the tree
         localparam NUM_INSTANCES   = 2**LEVEL;
         localparam RESULT_BITS_OUT = (INDEX_BITS + 1) - LEVEL;
         localparam RESULT_BITS_IN  = RESULT_BITS_OUT - 1;
         localparam START_BITS      = INDEX_BITS - LEVEL;

         //iterate over the instances at this level
         for(genvar INST=0; INST<NUM_INSTANCES; INST++) begin : g_tree_instances
            force_t force0;
            force_t force1;
            logic [RESULT_BITS_IN-1:0]    result0;
            logic [RESULT_BITS_IN-1:0]    result1;

            //force_off for high/low half?
            assign force0.off = tree_force[LEVEL][INST].off | (search_start[START_BITS-1] & ~tree_force[LEVEL][INST].on_);
            assign force1.off = tree_force[LEVEL][INST].off;


            //leaf of tree?
            if(LEVEL==TREE_DEPTH-1) begin : g_leaf
               assign result0 = din_padded[INST*2]    & ~force0.off; //only look at the data bit if not forced off
               assign result1 = din_padded[INST*2+1]  & ~force1.off; //as above
            end
            else begin : g_node
               //force_on for high/low half?
               assign force0.on_  = tree_force[LEVEL][INST].on_;
               assign force1.on_  = tree_force[LEVEL][INST].on_ | (~search_start[START_BITS-1] & ~tree_force[LEVEL][INST].off);

               //send the 'force' signals to the level below
               assign tree_force[LEVEL+1][INST*2]    = force0;
               assign tree_force[LEVEL+1][INST*2+1]  = force1;

               //get the results from the level below
               assign result0 = tree_result[LEVEL+1][(INST*2)*RESULT_BITS_IN +: RESULT_BITS_IN];
               assign result1 = tree_result[LEVEL+1][(INST*2+1)*RESULT_BITS_IN +: RESULT_BITS_IN];
            end

            //mux the low or high half result to the level above (coverage tag needed for non power-of-2 widths, where din is extended with zeros)
            assign tree_result[LEVEL][INST*RESULT_BITS_OUT +: RESULT_BITS_OUT] = //--COV:tag0
               result0[0] ? {1'b0, result0} : //low half found a hit? set the MSB of the result index to 0
                            {1'b1, result1};  //high half found a hit, so set the MSB of the result index to 1
         end
      end

      assign result[S] = tree_result[0][INDEX_BITS:0];
   
   end   
   

   //if wrapping is allowed, we also need to search from the bottom up
   if(ALLOW_WRAP) begin : g_allow_wrap
      //MSBs contain the index. Bit the first search result in preference to the second
      assign index = result[0][0] ? result[0][INDEX_BITS:1] : result[1][0] ? result[1][INDEX_BITS:1] : '0;      
      //LSB contains the 'found' bit
      assign found = result[0][0] | result[1][0];

   end
   else begin : g_no_wrap
      //MSBs contain the index
      assign index = result[0][0] ? result[0][INDEX_BITS:1] : '0; //--COV:tag1     
      //LSB contains the 'found' bit
      assign found = result[0][0];
   end

endmodule
