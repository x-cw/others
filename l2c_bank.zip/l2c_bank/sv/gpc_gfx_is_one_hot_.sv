/*

 * #==========================================================================#
 * |                                                                          |
 * |  Copyright (c) 2022, Fantasy Technologies Limited and/or its         |
 * |  affiliated group companies ("Fantasy"). All rights reserved.        |
 * |  No part of this content, either material or conceptual may be copied    |
 * |  or distributed, transmitted, transcribed, stored in a retrieval system  |
 * |  or translated into any human or computer language in any form by any    |
 * |  means, electronic, mechanical manual, or otherwise, or disclosed to     |
 * |  third parties without the express written permission of Fantasy.    |
 * |                                                                          |
 * #==========================================================================#

 */

module gpc_gfx_is_one_hot_
#(
      parameter int                                       W              = 4                    // Input Width of a single write
)
(
      input  logic [ W - 1 : 0 ]                          slv                           ,
      output logic                                        result
);

   localparam NUM_STAGES = $clog2(W);
   localparam LEN_2N     = 2**NUM_STAGES;       // slv'length rounded up to 2**N

   logic [LEN_2N-1:0]                 slv_2n;
   logic [NUM_STAGES-1:0][LEN_2N-1:0] v_stage;

   always_comb
   begin
      if (NUM_STAGES == 0) begin //--COV:tag0
         result = slv[0];
      end else begin
         slv_2n = LEN_2N'(slv);                     // pad with zeros
         // stage 0
         for (int ELEM = 0; ELEM < (LEN_2N/2); ELEM++) begin
            v_stage[0][2*ELEM+0] = ~(slv_2n[2*ELEM+1] | slv_2n[2*ELEM+0]);                               // = zero ones
            v_stage[0][2*ELEM+1] =   slv_2n[2*ELEM+1] ^ slv_2n[2*ELEM+0];                                // =  one one
         end
         if (NUM_STAGES > 1) begin //--COV:tag1
            // logarithmic tree
              for (int STAGE = 1; STAGE < NUM_STAGES; STAGE++) begin
                 for (int ELEM = 0; ELEM < (LEN_2N/(2**(STAGE+1))); ELEM++) begin
                  v_stage[STAGE][2*ELEM+0] =  v_stage[STAGE-1][4*ELEM+2] & v_stage[STAGE-1][4*ELEM+0];   // zero ones = (0 and 0)
                  v_stage[STAGE][2*ELEM+1] = (v_stage[STAGE-1][4*ELEM+3] & v_stage[STAGE-1][4*ELEM+0]) | // COV:tag2
                                             (v_stage[STAGE-1][4*ELEM+2] & v_stage[STAGE-1][4*ELEM+1]);  //             (0 and 1)
               end
            end
         end
         result = v_stage[NUM_STAGES-1][1];
      end
   end

endmodule
