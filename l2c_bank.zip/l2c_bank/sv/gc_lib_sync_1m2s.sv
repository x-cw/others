// Author: jinjifang
// Date: 2025/1/10
// Description: the sync of valid-enable interface, one master input and two slave output
module gc_lib_sync_1m2s #(
    parameter integer MODE = 0  //0: simple mode; 1: high performance mode
)(
    input logic                 clk,
    input logic                 resetn,
    // slave input
    input logic                 m_valid,
    output logic                m_enable,
    // master0 output
    output logic                s0_valid,
    input logic                 s0_enable,
    // master1 output
    output logic                s1_valid,
    input logic                 s1_enable
);

generate
    // simple mode
    if(MODE == 0) begin
        assign s0_valid     = m_valid & s1_enable;
        assign s1_valid     = m_valid & s0_enable;
        assign m_enable     = s0_enable & s1_enable;
    end
    // high performance mode
    else begin
        logic           is_s0_sent_q, is_s0_sent_d;
        logic           is_s1_sent_q, is_s1_sent_d;
        logic           s0_kickoff, s1_kickoff;

        assign s0_kickoff   = s0_valid & s0_enable;
        assign s1_kickoff   = s1_valid & s1_enable;

        assign s0_valid     = m_valid & !is_s0_sent_q;
        assign s1_valid     = m_valid & !is_s1_sent_q;
        assign m_enable     = (s0_kickoff | is_s0_sent_q) & (s1_kickoff | is_s1_sent_q);


        assign is_s0_sent_d = (m_valid & m_enable)  ? 1'b0          :
                               s0_kickoff           ? 1'b1          :
                                                      is_s0_sent_q  ;

        assign is_s1_sent_d = (m_valid & m_enable)  ? 1'b0          :
                               s1_kickoff           ? 1'b1          :
                                                      is_s1_sent_q  ;
        always @(posedge clk or negedge resetn) begin
            if(!resetn)
                {is_s1_sent_q, is_s0_sent_q}    <= 2'b0;
            else
                {is_s1_sent_q, is_s0_sent_q}    <= {is_s1_sent_d, is_s0_sent_d};
        end

    end


endgenerate

endmodule
