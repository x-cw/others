package gc_lsu_pkg_;



    // --------------------------------------------------------------------------------------------
    // timing buffer
    // --------------------------------------------------------------------------------------------
    localparam int TBUF_WIRE    = 0;
    localparam int TBUF_PIPEREG = 1;
    localparam int TBUF_RSTL    = 2;
    localparam int TBUF_MSTL    = 6;




    // --------------------------------------------------------------------------------------------
    // General
    // --------------------------------------------------------------------------------------------
    localparam int CU_ID_BITS                                   = 8;
    localparam int EU_ID_BITS                                   = 1;

    localparam int DW_BITS                                      = 32;     // Dword bit width

    localparam int EUS_PER_CU                                   = 2;     // Dword bit width

    localparam int INSTANCES_PER_INSTRUCTION                    = 128;
    localparam int INSTANCES_PER_INSTRUCTION_BITS               = $clog2(INSTANCES_PER_INSTRUCTION);
    localparam int INSTANCES_PER_DB                             = 8;
    localparam int INSTANCES_PER_DB_BITS                        = $clog2(INSTANCES_PER_DB);
    localparam int INSTANCES_PER_DB_GRP                         = INSTANCES_PER_DB*2;
    localparam int INSTANCES_PER_FOUR_DB                        = INSTANCES_PER_DB*4;
    localparam int DBS_PER_INSTRUCTION                          = INSTANCES_PER_INSTRUCTION/INSTANCES_PER_DB;
    localparam int DBS_PER_INSTRUCTION_BITS                     = $clog2(DBS_PER_INSTRUCTION);
    localparam int DB_GRPS_PER_INSTRUCTION                      = INSTANCES_PER_INSTRUCTION/INSTANCES_PER_DB_GRP;
    localparam int DB_GRPS_PER_INSTRUCTION_BITS                 = $clog2(DB_GRPS_PER_INSTRUCTION);
    localparam int FOUR_DBS_PER_INSTRUCTION                     = INSTANCES_PER_INSTRUCTION/INSTANCES_PER_FOUR_DB;
    localparam int FOUR_DBS_PER_INSTRUCTION_BITS                = $clog2(FOUR_DBS_PER_INSTRUCTION);

    // general feild bit width
    localparam int DEBUG_TAG_BITS               = 440;
    localparam int SET_FENCE_BITS               = 3;
    localparam int SLOT_ID_BITS                 = 5;
    localparam int DM_BITS                      = 3;
    localparam int TASK_ID_BITS                 = 6;
    localparam int PERSISTENCE_BITS             = 2;
    localparam int L1_CACHE_POLICY_BITS         = 2;
    localparam int L2_CACHE_POLICY_BITS         = 1;
    localparam int L2_PREFETCH_SIZE_BITS        = 1;
    localparam int CTXT_PASID_BITS              = 6;
    localparam int DEST_ADDR_BITS               = 18;
    localparam int BURSTLEN_BITS                = 7;

    // CU Register selection
    localparam int REG_SEL_BITS                 = 4;
    localparam int REG_INDEX_BITS               = 13;

    // Dest/Data register store selection
    localparam int LSU_RELATED_STORES           = 3; // SHS/US/LMS
    localparam int LSU_RELATED_STORES_BITS      = $clog2(LSU_RELATED_STORES);

    // Burst length for texel load and texel store instruction
    localparam int TEXEL_BURST_LEN_BITS         = 4; // 1,2,4,8,16 bytes
    localparam int TEXEL_OTHER_BITS             = 5;

    // --------------------------------------------------------------------------------------------
    // CU Register stores
    // --------------------------------------------------------------------------------------------
    localparam int SHS_ADDR_BITS                = 11;
    localparam int SLR_ADDR_BITS                = 10;
    localparam int US_ADDR_BITS                 = 9;

    localparam int SHS_WIDTH                    = 128;
    localparam int SLR_WIDTH                    = 32;
    localparam int US_WIDTH                     = 256;
    localparam int LMS_WIDTH                    = 1024;

    localparam int US_DW_WIDTH                  = US_WIDTH/DW_BITS;
    localparam int SLR_DW_WIDTH                 = SLR_WIDTH/DW_BITS;
    localparam int SHS_DW_WIDTH                 = SHS_WIDTH/DW_BITS;
    localparam int SHS_DW_WIDTH_BITS            = $clog2(SHS_DW_WIDTH);

    localparam int LMS_BYTE_WIDTH               = LMS_WIDTH/8;
    localparam int LMS_BYTE_WIDTH_BITS          = $clog2(LMS_WIDTH/8);

    localparam int SHS_MASK_BITS                = 4;

    localparam int SPAGS_PER_EU                 = 4;
    localparam int US_PER_SPAG                  = 2;
    localparam int BANKS_PER_US                 = 4;

    localparam int BANKS_PER_US_BITS            = $clog2(BANKS_PER_US);
    
    localparam int SHS_BANKS                    = 1;
    localparam int SLR_BANKS                    = 4;
    localparam int US_BANKS                     = SPAGS_PER_EU * US_PER_SPAG * BANKS_PER_US;

    localparam int SLR_BANKS_BITS               = $clog2(SLR_BANKS);
    localparam int US_BANKS_BITS                = $clog2(US_BANKS);






    // --------------------------------------------------------------------------------------------
    // CR bit width
    // --------------------------------------------------------------------------------------------
    localparam int GC_CR_CONTEXT_MAPPING_COMPUTE_BITS = 6;
    localparam int GC_CR_CU_TEMP_SPILLING_BITS       = 48;
    localparam int GC_CR_CU_EXCEPTION_BITS           = 2;




    // --------------------------------------------------------------------------------------------
    // interface data_bus width
    // --------------------------------------------------------------------------------------------
    localparam int CMN_FQ_LSU_IF_DATA_BUS_WIDTH       = 333;
    localparam int LSU_US_REQ_IF_DATA_BUS_WIDTH       = 274;
    localparam int LSU_SRS_REQ_IF_DATA_BUS_WIDTH      = 10;
    localparam int LSU_SHS_RD_IF_DATA_BUS_WIDTH       = 11;
    localparam int LSU_SHS_WR_IF_DATA_BUS_WIDTH       = 143;
    localparam int LSU_LMS_RD_IF_DATA_BUS_WIDTH       = 40;
    localparam int US_LSU_RTN_IF_DATA_BUS_WIDTH       = 256;
    localparam int LSU_SRS_RD_RTN_IF_DATA_BUS_WIDTH   = 32;
    localparam int LSU_SHS_RTN_IF_DATA_BUS_WIDTH      = 128;
    localparam int LSU_DFU_REQ_IF_DATA_BUS_WIDTH      = 937;
    localparam int LSU_L0_WDATA_IF_DATA_BUS_WIDTH     = 1024;
    localparam int LSU_L0_RTN_IF_DATA_BUS_WIDTH       = 1153;
    localparam int L0_LSU_FC_IF_DATA_BUS_WIDTH        = 18;
    localparam int TAP_CU_RTN_IF_DATA_BUS_WIDTH      = 566;
    localparam int TRM_LSU_US_WRITE_IF_DATA_BUS_WIDTH = 550;
    localparam int LSU_TS_L0_ED_IF_DATA_BUS_WIDTH     = 6;
    localparam int LSU_TS_US_ED_IF_DATA_BUS_WIDTH     = 6;
    localparam int LSU_LMS_RESP_IF_DATA_BUS_WIDTH     = 9;
    localparam int LSU_FC_IF_DATA_BUS_WIDTH           = 8;
    localparam int LSU_PRED_WR_IF_DATA_BUS_WIDTH      = 261;
    localparam int EU_L0C_PORT_IF_DATA_BUS_WIDTH      = 3;

    // Used for perf cnt logic
    localparam int CMN_FQ_LSU_IF_DATA_BUS_TMA_DMA_SEL_BITS            = 1;
    localparam int CMN_FQ_LSU_IF_DATA_BUS_TMA_DMA_SEL_LSB             = 8;
    localparam int CMN_FQ_LSU_IF_DATA_BUS_TMA_DMA_SEL_MSB             = CMN_FQ_LSU_IF_DATA_BUS_TMA_DMA_SEL_LSB + CMN_FQ_LSU_IF_DATA_BUS_TMA_DMA_SEL_BITS - 1;

    localparam int CMN_FQ_LSU_IF_DATA_BUS_DMA_OP_BITS                 = 4;
    localparam int CMN_FQ_LSU_IF_DATA_BUS_DMA_OP_LSB                  = 146;
    localparam int CMN_FQ_LSU_IF_DATA_BUS_DMA_OP_MSB                  = CMN_FQ_LSU_IF_DATA_BUS_DMA_OP_LSB + CMN_FQ_LSU_IF_DATA_BUS_DMA_OP_BITS - 1;

    localparam int CMN_FQ_LSU_IF_DATA_BUS_DMA_DST_REG_SEL_BITS        = REG_SEL_BITS;
    localparam int CMN_FQ_LSU_IF_DATA_BUS_DMA_DST_REG_SEL_LSB         = 225;
    localparam int CMN_FQ_LSU_IF_DATA_BUS_DMA_DST_REG_SEL_MSB         = CMN_FQ_LSU_IF_DATA_BUS_DMA_DST_REG_SEL_LSB + CMN_FQ_LSU_IF_DATA_BUS_DMA_DST_REG_SEL_BITS - 1;

    localparam int CMN_FQ_LSU_IF_DATA_BUS_DMA_DAT_REG_SEL_BITS        = REG_SEL_BITS;
    localparam int CMN_FQ_LSU_IF_DATA_BUS_DMA_DAT_REG_SEL_LSB         = 163;
    localparam int CMN_FQ_LSU_IF_DATA_BUS_DMA_DAT_REG_SEL_MSB         = CMN_FQ_LSU_IF_DATA_BUS_DMA_DAT_REG_SEL_LSB + CMN_FQ_LSU_IF_DATA_BUS_DMA_DAT_REG_SEL_BITS - 1;

    localparam int CMN_FQ_LSU_IF_DATA_BUS_TMA_OP_BITS                 = 4;
    localparam int CMN_FQ_LSU_IF_DATA_BUS_TMA_OP_LSB                  = 146;
    localparam int CMN_FQ_LSU_IF_DATA_BUS_TMA_OP_MSB                  = CMN_FQ_LSU_IF_DATA_BUS_TMA_OP_LSB + CMN_FQ_LSU_IF_DATA_BUS_TMA_OP_BITS - 1;

    localparam int CMN_FQ_LSU_IF_DATA_BUS_TMA_MCM_SEL_BITS            = REG_SEL_BITS;
    localparam int CMN_FQ_LSU_IF_DATA_BUS_TMA_MCM_SEL_LSB             = 178;
    localparam int CMN_FQ_LSU_IF_DATA_BUS_TMA_MCM_SEL_MSB             = CMN_FQ_LSU_IF_DATA_BUS_TMA_MCM_SEL_LSB + CMN_FQ_LSU_IF_DATA_BUS_TMA_MCM_SEL_BITS - 1;

    localparam int CMN_FQ_LSU_IF_DATA_BUS_TMA_ADDR_OFFSET_SEL_BITS    = REG_SEL_BITS;
    localparam int CMN_FQ_LSU_IF_DATA_BUS_TMA_ADDR_OFFSET_SEL_LSB     = 212;
    localparam int CMN_FQ_LSU_IF_DATA_BUS_TMA_ADDR_OFFSET_SEL_MSB     = CMN_FQ_LSU_IF_DATA_BUS_TMA_ADDR_OFFSET_SEL_LSB + CMN_FQ_LSU_IF_DATA_BUS_TMA_ADDR_OFFSET_SEL_BITS - 1;

    localparam int CMN_FQ_LSU_IF_DATA_BUS_TMA_ADDR_BASE_SEL_BITS      = REG_SEL_BITS;
    localparam int CMN_FQ_LSU_IF_DATA_BUS_TMA_ADDR_BASE_SEL_LSB       = 229;
    localparam int CMN_FQ_LSU_IF_DATA_BUS_TMA_ADDR_BASE_SEL_MSB       = CMN_FQ_LSU_IF_DATA_BUS_TMA_ADDR_BASE_SEL_LSB + CMN_FQ_LSU_IF_DATA_BUS_TMA_ADDR_BASE_SEL_BITS - 1;

    localparam int CMN_FQ_LSU_IF_DATA_BUS_TMA_STRIDE_SEL_BITS         = REG_SEL_BITS;
    localparam int CMN_FQ_LSU_IF_DATA_BUS_TMA_STRIDE_SEL_LSB          = 260;
    localparam int CMN_FQ_LSU_IF_DATA_BUS_TMA_STRIDE_SEL_MSB          = CMN_FQ_LSU_IF_DATA_BUS_TMA_STRIDE_SEL_LSB + CMN_FQ_LSU_IF_DATA_BUS_TMA_STRIDE_SEL_BITS - 1;

    localparam int CMN_FQ_LSU_IF_DATA_BUS_TMA_TID_SEL_BITS            = REG_SEL_BITS;
    localparam int CMN_FQ_LSU_IF_DATA_BUS_TMA_TID_SEL_LSB             = 277;
    localparam int CMN_FQ_LSU_IF_DATA_BUS_TMA_TID_SEL_MSB             = CMN_FQ_LSU_IF_DATA_BUS_TMA_TID_SEL_LSB + CMN_FQ_LSU_IF_DATA_BUS_TMA_TID_SEL_BITS - 1;
    localparam int CMN_FQ_LSU_IF_DATA_BUS_TMA_ROBUST_SEL_BITS         = REG_SEL_BITS;
    localparam int CMN_FQ_LSU_IF_DATA_BUS_TMA_ROBUST_SEL_LSB          = 294;
    localparam int CMN_FQ_LSU_IF_DATA_BUS_TMA_ROBUST_SEL_MSB          = CMN_FQ_LSU_IF_DATA_BUS_TMA_ROBUST_SEL_LSB + CMN_FQ_LSU_IF_DATA_BUS_TMA_ROBUST_SEL_BITS - 1;


    // --------------------------------------------------------------------------------------------
    // Interface feild bit width
    // --------------------------------------------------------------------------------------------
    // CFQ to LSU interface
    localparam int CFQ_LSU_DEBUG_TAG_BITS                       = DEBUG_TAG_BITS;
    localparam int CFQ_LSU_SET_FENCE_BITS                       = SET_FENCE_BITS;
    localparam int CFQ_LSU_DM_BITS                              = DM_BITS;
    localparam int CFQ_LSU_TASK_ID_BITS                         = TASK_ID_BITS;
    localparam int CFQ_LSU_SLOT_BITS                            = SLOT_ID_BITS;
    localparam int CFQ_LSU_TMA_DMA_SEL_BITS                     = 1;
    localparam int CFQ_LSU_INSTANCE_ACTIVE_MASK_BITS            = INSTANCES_PER_INSTRUCTION;
    localparam int CFQ_LSU_PERSISTENCE_BITS                     = PERSISTENCE_BITS;
    localparam int CFQ_LSU_L1_CACHE_POLICY_BITS                 = L1_CACHE_POLICY_BITS;
    localparam int CFQ_LSU_L2_CACHE_POLICY_BITS                 = L2_CACHE_POLICY_BITS;
    localparam int CFQ_LSU_L2_PREFETCH_SIZE_BITS                = L2_PREFETCH_SIZE_BITS;
    localparam int CFQ_LSU_SIDEBAND_DATA_BITS                   = 196;

    // CFQ to LSU interface sideband
    localparam int CFQ_LSU_SB_TMA_TID_BITS                      = 3;
    localparam int CFQ_LSU_SB_TMA_OP_BITS                       = 4;
    localparam int CFQ_LSU_SB_TMA_LAYOUT_BITS                   = 1;
    localparam int CFQ_LSU_SB_TMA_REG_SEQ                       = 1;
    localparam int CFQ_LSU_SB_TMA_MTYPE_BITS                    = 4;
    localparam int CFQ_LSU_SB_TMA_RTYPE_BITS                    = 4;
    localparam int CFQ_LSU_SB_TMA_MCS_BITS                      = 2;
    localparam int CFQ_LSU_SB_TMA_WORKGROUP_ID_BITS             = 7;
    localparam int CFQ_LSU_SB_TMA_MCM_SELECT_BITS               = REG_SEL_BITS;
    localparam int CFQ_LSU_SB_TMA_MCM_INDEX_BITS                = REG_INDEX_BITS;
    localparam int CFQ_LSU_SB_TMA_DST_SELECT_BITS               = REG_SEL_BITS;
    localparam int CFQ_LSU_SB_TMA_DST_INDEX_BITS                = REG_INDEX_BITS;
    localparam int CFQ_LSU_SB_TMA_MEMOFSET_SELECT_BITS          = REG_SEL_BITS;
    localparam int CFQ_LSU_SB_TMA_MEMOFSET_INDEX_BITS           = REG_INDEX_BITS;
    localparam int CFQ_LSU_SB_TMA_ADDR_BASE_SELECT_BITS         = REG_SEL_BITS;
    localparam int CFQ_LSU_SB_TMA_ADDR_BASE_INDEX_BITS          = REG_INDEX_BITS;
    localparam int CFQ_LSU_SB_TMA_BLX_SELECT_BITS               = REG_SEL_BITS;
    localparam int CFQ_LSU_SB_TMA_BLX_INDEX_BITS                = 3;
    localparam int CFQ_LSU_SB_TMA_BLY_SELECT_BITS               = REG_SEL_BITS;
    localparam int CFQ_LSU_SB_TMA_BLY_INDEX_BITS                = 3;
    localparam int CFQ_LSU_SB_TMA_STRIDE_SELECT_BITS            = REG_SEL_BITS;
    localparam int CFQ_LSU_SB_TMA_STRIDE_INDEX_BITS             = REG_INDEX_BITS;
    localparam int CFQ_LSU_SB_TMA_TID_SELECT_BITS               = REG_SEL_BITS;
    localparam int CFQ_LSU_SB_TMA_TID_INDEX_BITS                = REG_INDEX_BITS;
    localparam int CFQ_LSU_SB_TMA_ROBUST_SELECT_BITS            = REG_SEL_BITS;
    localparam int CFQ_LSU_SB_TMA_ROBUST_INDEX_BITS             = REG_INDEX_BITS;
    localparam int CFQ_LSU_SB_TMA_PADDING_BITS                  = 22;

    localparam int CFQ_LSU_SB_DMA_OP_BITS                       = 4;
    localparam int CFQ_LSU_SB_DMA_ATOMOP_BITS                   = 4;
    localparam int CFQ_LSU_SB_DMA_PACK_UNPACK_BITS              = 1;
    localparam int CFQ_LSU_SB_DMA_STRIDE_ADDFIRST_BITS          = 1;
    localparam int CFQ_LSU_SB_DMA_STRIDE_INSTANCE_BASED_BITS    = 1;
    localparam int CFQ_LSU_SB_DMA_DATA_REG_SELECT_BITS          = REG_SEL_BITS;
    localparam int CFQ_LSU_SB_DMA_DATA_REG_INDEX_BITS           = 13;
    localparam int CFQ_LSU_SB_DMA_INDEX_SELECT_BITS             = REG_SEL_BITS;
    localparam int CFQ_LSU_SB_DMA_INDEX_INDEX_BITS              = 9;
    localparam int CFQ_LSU_SB_DMA_ADDR_BASE_SELECT_BITS         = REG_SEL_BITS;
    localparam int CFQ_LSU_SB_DMA_ADDR_BASE_INDEX_BITS          = 13;
    localparam int CFQ_LSU_SB_DMA_MEMOFSET_SELECT_BITS          = REG_SEL_BITS;
    localparam int CFQ_LSU_SB_DMA_MEMOFSET_INDEX_BITS           = 11;
    localparam int CFQ_LSU_SB_DMA_DST_SELECT_BITS               = REG_SEL_BITS;
    localparam int CFQ_LSU_SB_DMA_DST_INDEX_BITS                = 13;
    localparam int CFQ_LSU_SB_DMA_BLX_SELECT_BITS               = REG_SEL_BITS;
    localparam int CFQ_LSU_SB_DMA_BLX_INDEX_BITS                = 13;
    localparam int CFQ_LSU_SB_DMA_BLY_SELECT_BITS               = REG_SEL_BITS;
    localparam int CFQ_LSU_SB_DMA_BLY_INDEX_BITS                = 13;
    localparam int CFQ_LSU_SB_DMA_STRIDE_SELECT_BITS            = REG_SEL_BITS;
    localparam int CFQ_LSU_SB_DMA_STRIDE_INDEX_BITS             = 13;
    localparam int CFQ_LSU_SB_DMA_ROBUST_SELECT_BITS            = REG_SEL_BITS;
    localparam int CFQ_LSU_SB_DMA_ROBUST_INDEX_BITS             = 13;
    localparam int CFQ_LSU_SB_DMA_MAX_TRANS_DWORD_BITS          = 11;
    localparam int CFQ_LSU_SB_DMA_MIN_TRANS_DWORD_BITS          = 11;
    localparam int CFQ_LSU_SB_DMA_PERF_TRACKED_BITS             = 1;

    // LSU to L0C request interface
    localparam int LSU_L0C_DEBUG_TAG_BITS                       = DEBUG_TAG_BITS;
    localparam int LSU_L0C_TMA_DMA_SEL_BITS                     = CFQ_LSU_TMA_DMA_SEL_BITS;
    localparam int LSU_L0C_DEST_STORE_BITS                      = LSU_RELATED_STORES_BITS;
    localparam int LSU_L0C_DEST_ADDR_BITS                       = DEST_ADDR_BITS;
    localparam int LSU_L0C_OP_BITS                              = CFQ_LSU_SB_DMA_OP_BITS;
    localparam int LSU_L0C_ATOMIC_OP_BITS                       = CFQ_LSU_SB_DMA_ATOMOP_BITS;
    localparam int LSU_L0C_PERSISTENCE_BITS                     = PERSISTENCE_BITS;
    localparam int LSU_L0C_L1_CACHE_POLICY_BITS                 = L1_CACHE_POLICY_BITS;
    localparam int LSU_L0C_L2_CACHE_POLICY_BITS                 = L2_CACHE_POLICY_BITS;
    localparam int LSU_L0C_PREFETCH_SIZE_BITS                   = L2_PREFETCH_SIZE_BITS;
    localparam int LSU_L0C_PACK_UNPACK_BITS                     = 1;
    localparam int LSU_L0C_CTXT_PASID_BITS                      = CTXT_PASID_BITS;
    localparam int LSU_L0C_SET_FENCE_BITS                       = SET_FENCE_BITS;
    localparam int LSU_L0C_SLOT_BITS                            = SLOT_ID_BITS;
    localparam int LSU_L0C_ROBUST_ACTIVE_BITS                   = 1;
    localparam int LSU_L0C_ROBUST_BASE_BITS                     = 48;
    localparam int LSU_L0C_ROBUST_SIZE_BITS                     = 32;
    localparam int LSU_L0C_LAST_OF_128V_BITS                    = 1;
    localparam int LSU_L0C_INSTR_END_BITS                       = 1;
    localparam int LSU_L0C_LAYOUT_BITS                          = 4;
    localparam int LSU_L0C_DM_BITS                              = DM_BITS;
    localparam int LSU_L0C_TASK_ID_BITS                         = TASK_ID_BITS;
    localparam int LSU_L0C_PAYLOAD_INFO_BITS                    = 792;

    // LSU to L0C payload info
    localparam int LSU_L0C_PAYLOAD_INFO_VA_ACTIVE_MASK_BITS     = INSTANCES_PER_DB_GRP;
    localparam int LSU_L0C_PAYLOAD_INFO_VA_BITS                 = 48;
    localparam int LSU_L0C_PAYLOAD_INFO_BURST_LEN_BITS          = 8;  // up to 1K-bits

    localparam int LSU_L0C_PAYLOAD_INFO_WORKGOURP_ID_BITS       = 6;
    localparam int LSU_L0C_PAYLOAD_INFO_TASK_ID_BITS            = 6;
    localparam int LSU_L0C_PAYLOAD_INFO_TMA_OP_BITS             = 2;
    localparam int LSU_L0C_PAYLOAD_INFO_MAT_LAYOUT_BITS         = 1;
    localparam int LSU_L0C_PAYLOAD_INFO_REG_SEQ_BITS            = 1;
    localparam int LSU_L0C_PAYLOAD_INFO_MCS_BITS                = 2;
    localparam int LSU_L0C_PAYLOAD_INFO_MTYPE_BITS              = 4;
    localparam int LSU_L0C_PAYLOAD_INFO_RTYPE_BITS              = 4;
    localparam int LSU_L0C_PAYLOAD_INFO_MCM_BITS                = 8;
    localparam int LSU_L0C_PAYLOAD_INFO_TID_BITS                = 3;
    localparam int LSU_L0C_PAYLOAD_INFO_BL_X_BITS               = 3;
    localparam int LSU_L0C_PAYLOAD_INFO_BL_Y_BITS               = 3;
    localparam int LSU_L0C_PAYLOAD_INFO_STRIDE_BITS             = 32;
    localparam int LSU_L0C_PAYLOAD_INFO_ADDR_BASE_BITS          = 48;
    localparam int LSU_L0C_PAYLOAD_INFO_ADDR_OFFSET_BITS        = 32;

    localparam int LSU_L0C_PAYLOAD_INFO_TMA_RESERVED_BITS       = 637;
    localparam int LSU_L0C_PAYLOAD_INFO_DMA_1V_RESERVED_BITS    = 720;
    localparam int LSU_L0C_PAYLOAD_INFO_DMA_8V4D_RESERVED_BITS  = 384;
    localparam int LSU_L0C_PAYLOAD_INFO_DMA_8V4DT_RESERVED_BITS = 352;



    // LSU CCB24 add constant
    localparam int LSU_OP1_SEL_NONE_BITS                        = 1;
    localparam int LSU_OP0_SEL_NONE_BITS                        = 1;
    localparam int LSU_INDEX_SEL_NONE_BITS                      = 1;
    localparam int LSU_STRIDE_SEL_NONE_BITS                     = 1;
    localparam int LSU_ROBUST_SEL_NONE_BITS                     = 1;
    localparam int LSU_TMA_DMA_SEL_BITS                         = 1;
    localparam int LSU_FIRST_FOUR_DB_ID                         = 2;







    // --------------------------------------------------------------------------------------------
    // Encoding
    // --------------------------------------------------------------------------------------------
    // Register selection encoding
    localparam logic [4-1:0]                          REG_SEL_NONE              = 4'd0;
    localparam logic [4-1:0]                          REG_SEL_SLR               = 4'd2;
    localparam logic [4-1:0]                          REG_SEL_TMP               = 4'd4;
    localparam logic [4-1:0]                          REG_SEL_A                 = 4'd5;
    localparam logic [4-1:0]                          REG_SEL_SHS               = 4'd7;
    localparam logic [4-1:0]                          REG_SEL_LMS               = 4'd9;
    localparam logic [4-1:0]                          REG_SEL_IMM               = 4'd12;
    localparam logic [4-1:0]                          REG_SEL_CR                = 4'd14;

    // DMA OP encoding
    localparam logic [CFQ_LSU_SB_DMA_OP_BITS-1:0]     OP_CFI_INVAL              = 0;
    localparam logic [CFQ_LSU_SB_DMA_OP_BITS-1:0]     OP_CFI_FLUSH              = 1;
    localparam logic [CFQ_LSU_SB_DMA_OP_BITS-1:0]     OP_CFI_FLUSHINV           = 2;
    localparam logic [CFQ_LSU_SB_DMA_OP_BITS-1:0]     OP_BARRIER                = 3;
    localparam logic [CFQ_LSU_SB_DMA_OP_BITS-1:0]     OP_ST                     = 4;
    localparam logic [CFQ_LSU_SB_DMA_OP_BITS-1:0]     OP_LD                     = 5;
    localparam logic [CFQ_LSU_SB_DMA_OP_BITS-1:0]     OP_ATOMIC_32              = 6;
    localparam logic [CFQ_LSU_SB_DMA_OP_BITS-1:0]     OP_ATOMIC_64              = 7;
    localparam logic [CFQ_LSU_SB_DMA_OP_BITS-1:0]     OP_IDF                    = 8;
    localparam logic [CFQ_LSU_SB_DMA_OP_BITS-1:0]     OP_TILEDST                = 9;
    localparam logic [CFQ_LSU_SB_DMA_OP_BITS-1:0]     OP_TEXELST                = 10;
    localparam logic [CFQ_LSU_SB_DMA_OP_BITS-1:0]     OP_TEXELLD                = 11;
    localparam logic [CFQ_LSU_SB_DMA_OP_BITS-1:0]     OP_ATOMIC_F32             = 12;
    localparam logic [CFQ_LSU_SB_DMA_OP_BITS-1:0]     OP_LD_PAIR                = 13;
    localparam logic [CFQ_LSU_SB_DMA_OP_BITS-1:0]     OP_ST_PAIR                = 14;

    // TMA OP encoding
    localparam logic [CFQ_LSU_SB_TMA_OP_BITS-1:0]     OP_LDA_16X32              = 0;
    localparam logic [CFQ_LSU_SB_TMA_OP_BITS-1:0]     OP_LDB_32X16              = 1;
    localparam logic [CFQ_LSU_SB_TMA_OP_BITS-1:0]     OP_LDA_16X16              = 2;
    localparam logic [CFQ_LSU_SB_TMA_OP_BITS-1:0]     OP_LDB_16X16              = 3;
    // DMA  MEM Hier OP encoding
    localparam logic [CFQ_LSU_SB_DMA_OP_BITS-1:0]     MH_LOAD              = 0;
    localparam logic [CFQ_LSU_SB_DMA_OP_BITS-1:0]     MH_TOUCH             = 1;
    localparam logic [CFQ_LSU_SB_DMA_OP_BITS-1:0]     MH_STORE             = 4;
    localparam logic [CFQ_LSU_SB_DMA_OP_BITS-1:0]     MH_ATOMIC32          = 5;
    localparam logic [CFQ_LSU_SB_DMA_OP_BITS-1:0]     MH_ATOMIC64          = 6;
    localparam logic [CFQ_LSU_SB_DMA_OP_BITS-1:0]     MH_ATOMICST          = 7;
    localparam logic [CFQ_LSU_SB_DMA_OP_BITS-1:0]     MH_WR_FENCE          = 8;
    localparam logic [CFQ_LSU_SB_DMA_OP_BITS-1:0]     MH_BARRIER           = 9;
    localparam logic [CFQ_LSU_SB_DMA_OP_BITS-1:0]     MH_ATOMICFP32        = 10;
    localparam logic [CFQ_LSU_SB_DMA_OP_BITS-1:0]     MH_CCM_EVICT         = 12;
    localparam logic [CFQ_LSU_SB_DMA_OP_BITS-1:0]     MH_INVAL             = 13;
    localparam logic [CFQ_LSU_SB_DMA_OP_BITS-1:0]     MH_FLUSH             = 14;
    localparam logic [CFQ_LSU_SB_DMA_OP_BITS-1:0]     MH_FLUSHINV          = 15;



    localparam logic [CFQ_LSU_SB_DMA_ATOMOP_BITS-1:0] ATOMOP_ADD                = 4'd0;
    localparam logic [CFQ_LSU_SB_DMA_ATOMOP_BITS-1:0] ATOMOP_SUB                = 4'd1;
    localparam logic [CFQ_LSU_SB_DMA_ATOMOP_BITS-1:0] ATOMOP_XCHG               = 4'd2;
    localparam logic [CFQ_LSU_SB_DMA_ATOMOP_BITS-1:0] ATOMOP_CMPXCHG            = 4'd3;
    localparam logic [CFQ_LSU_SB_DMA_ATOMOP_BITS-1:0] ATOMOP_UMIN               = 4'd4;
    localparam logic [CFQ_LSU_SB_DMA_ATOMOP_BITS-1:0] ATOMOP_SMIN               = 4'd5;
    localparam logic [CFQ_LSU_SB_DMA_ATOMOP_BITS-1:0] ATOMOP_UMAX               = 4'd6;
    localparam logic [CFQ_LSU_SB_DMA_ATOMOP_BITS-1:0] ATOMOP_SMAX               = 4'd7;
    localparam logic [CFQ_LSU_SB_DMA_ATOMOP_BITS-1:0] ATOMOP_AND                = 4'd8;
    localparam logic [CFQ_LSU_SB_DMA_ATOMOP_BITS-1:0] ATOMOP_OR                 = 4'd9;
    localparam logic [CFQ_LSU_SB_DMA_ATOMOP_BITS-1:0] ATOMOP_XOR                = 4'd10;


    // DMA/TAM instruction selection encoding
    localparam logic                                  TMA_DMA_SEL_DMA           = 1'b0;
    localparam logic                                  TMA_DMA_SEL_TMA           = 1'b1;


    localparam logic [LSU_RELATED_STORES_BITS-1:0]    DATA_DST_REG_SEL_US       = 2'd0;
    localparam logic [LSU_RELATED_STORES_BITS-1:0]    DATA_DST_REG_SEL_LMS      = 2'd1;
    localparam logic [LSU_RELATED_STORES_BITS-1:0]    DATA_DST_REG_SEL_SHS      = 2'd2;
    localparam logic [LSU_RELATED_STORES_BITS-1:0]    DATA_DST_REG_SEL_NONE     = 2'd3;
    
    // LSU to L0C request layout encoding
    localparam logic [LSU_L0C_LAYOUT_BITS-1:0]        LSU_L0C_LAYOUT_1V0D       = 4'b0000;
    localparam logic [LSU_L0C_LAYOUT_BITS-1:0]        LSU_L0C_LAYOUT_1V32D      = 4'b0001;
    localparam logic [LSU_L0C_LAYOUT_BITS-1:0]        LSU_L0C_LAYOUT_2V16D      = 4'b0010;
    localparam logic [LSU_L0C_LAYOUT_BITS-1:0]        LSU_L0C_LAYOUT_16V2D      = 4'b0011;
    localparam logic [LSU_L0C_LAYOUT_BITS-1:0]        LSU_L0C_LAYOUT_8V4D       = 4'b0100;
    localparam logic [LSU_L0C_LAYOUT_BITS-1:0]        LSU_L0C_LAYOUT_8V4DT      = 4'b0101;
    localparam logic [LSU_L0C_LAYOUT_BITS-1:0]        LSU_L0C_LAYOUT_16V1D      = 4'b0110; // internal used in LSU





    // --------------------------------------------------------------------------------------------
    // Operand bit width
    // --------------------------------------------------------------------------------------------
    localparam int LSU_OP_BUFFER_OPS_NUM       = 8;
    // DMA operand bits
    localparam int LSU_OP_DMA_BLY_BITS          = 11;
    localparam int LSU_OP_DMA_BLX_BITS          = 16;
    localparam int LSU_OP_STRIDE_BITS           = 32;
    localparam int LSU_OP_INDEX_BITS            = 18;
    localparam int LSU_OP_ROBUST_BASE_BITS      = 48;
    localparam int LSU_OP_ROBUST_SIZE_BITS      = 32;
    localparam int LSU_OP_ADDR_BASE_LO_BITS     = 32;
    localparam int LSU_OP_ADDR_BASE_HI_BITS     = 16;
    localparam int LSU_OP_MEMOFFSET_BITS        = 32;
    localparam int LSU_OP_TEXEL_OTHER_BITS      = 5;

    localparam int LSU_OP_DMA_IMM_BLY_BITS      = 10;
    localparam int LSU_OP_DMA_IMM_BLX_BITS      = 10;
    localparam int LSU_OP_DMA_IMM_STRIDE_BITS   = 11;

    localparam int LSU_OP_ADDR_BASE_BITS = LSU_OP_ADDR_BASE_LO_BITS + LSU_OP_ADDR_BASE_HI_BITS;
    localparam int LSU_OP_ROBUST_BITS    = LSU_OP_ROBUST_BASE_BITS + LSU_OP_ROBUST_SIZE_BITS;

    localparam int LSU_OP_DMA_STRIDE_BITS      = 16;


    localparam int LSU_OP_DMA_TOTAL_BITS     = 
                       LSU_OP_DMA_BLY_BITS       + 
                       LSU_OP_DMA_BLX_BITS       + 
                       LSU_OP_STRIDE_BITS    + 
                       LSU_OP_INDEX_BITS     + 
                       LSU_OP_ROBUST_BITS    + 
                       LSU_OP_ADDR_BASE_BITS + 
                       LSU_OP_MEMOFFSET_BITS;

    // TMA operand bits
    localparam int LSU_OP_TMA_TID_BITS       = 3;
    localparam int LSU_OP_TMA_MCM_BITS       = 8;

    localparam int LSU_OP_TMA_TOTAL_BITS     = 
                       LSU_OP_TMA_TID_BITS       +
                       LSU_OP_TMA_MCM_BITS       +
                       LSU_OP_STRIDE_BITS    +
                       LSU_OP_INDEX_BITS     +
                       LSU_OP_ADDR_BASE_BITS +
                       LSU_OP_MEMOFFSET_BITS +
                       LSU_OP_ROBUST_BITS;





    // --------------------------------------------------------------------------------------------
    // Struct
    // --------------------------------------------------------------------------------------------
    // LSU to L0C payload info for TMA
    typedef struct packed {
        logic [LSU_L0C_PAYLOAD_INFO_WORKGOURP_ID_BITS-1:0] workgroup_id;
        logic [LSU_L0C_PAYLOAD_INFO_TASK_ID_BITS-1:0]      task_id;
        logic [LSU_L0C_PAYLOAD_INFO_TMA_OP_BITS-1:0]       tma_op;
        logic [LSU_L0C_PAYLOAD_INFO_MAT_LAYOUT_BITS-1:0]   mat_layout;
        logic [LSU_L0C_PAYLOAD_INFO_MAT_LAYOUT_BITS-1:0]   reg_seq;
        logic [LSU_L0C_PAYLOAD_INFO_MCS_BITS-1:0]          mcs;
        logic [LSU_L0C_PAYLOAD_INFO_MTYPE_BITS-1:0]        mtype;
        logic [LSU_L0C_PAYLOAD_INFO_RTYPE_BITS-1:0]        rtype;
        logic [LSU_L0C_PAYLOAD_INFO_MCM_BITS-1:0]          mcm;
        logic [LSU_L0C_PAYLOAD_INFO_TID_BITS-1:0]          tid;
        logic [LSU_L0C_PAYLOAD_INFO_BL_X_BITS-1:0]         bl_x;
        logic [LSU_L0C_PAYLOAD_INFO_BL_Y_BITS-1:0]         bl_y;
        logic [LSU_L0C_PAYLOAD_INFO_STRIDE_BITS-1:0]       stride;
        logic [LSU_L0C_PAYLOAD_INFO_ADDR_BASE_BITS-1:0]    addr_base;
        logic [LSU_L0C_PAYLOAD_INFO_ADDR_OFFSET_BITS-1:0]  addr_offset;
    } t_op_buff_vac_sb;

    typedef struct packed {
        logic [LSU_L0C_PAYLOAD_INFO_TMA_RESERVED_BITS-1:0] reserved;
        logic [LSU_L0C_PAYLOAD_INFO_ADDR_OFFSET_BITS-1:0]  addr_offset;
        logic [LSU_L0C_PAYLOAD_INFO_ADDR_BASE_BITS-1:0]    addr_base;
        logic [LSU_L0C_PAYLOAD_INFO_STRIDE_BITS-1:0]       stride;
        logic [LSU_L0C_PAYLOAD_INFO_BL_Y_BITS-1:0]         bl_y;
        logic [LSU_L0C_PAYLOAD_INFO_BL_X_BITS-1:0]         bl_x;
        logic [LSU_L0C_PAYLOAD_INFO_TID_BITS-1:0]          tid;
        logic [LSU_L0C_PAYLOAD_INFO_MCM_BITS-1:0]          mcm;
        logic [LSU_L0C_PAYLOAD_INFO_RTYPE_BITS-1:0]        rtype;
        logic [LSU_L0C_PAYLOAD_INFO_MTYPE_BITS-1:0]        mtype;
        logic [LSU_L0C_PAYLOAD_INFO_MCS_BITS-1:0]          mcs;
        logic [LSU_L0C_PAYLOAD_INFO_MAT_LAYOUT_BITS-1:0]   reg_seq;
        logic [LSU_L0C_PAYLOAD_INFO_MAT_LAYOUT_BITS-1:0]   mat_layout;
        logic [LSU_L0C_PAYLOAD_INFO_TMA_OP_BITS-1:0]       tma_op;
        logic [LSU_L0C_PAYLOAD_INFO_TASK_ID_BITS-1:0]      task_id;
        logic [LSU_L0C_PAYLOAD_INFO_WORKGOURP_ID_BITS-1:0] workgroup_id;
    } t_lsu_l0c_req_payload_info_tma;


    typedef struct packed {
        logic [LSU_L0C_PAYLOAD_INFO_DMA_1V_RESERVED_BITS-1:0]   reserved;
        logic [LSU_L0C_PAYLOAD_INFO_VA_BITS-1:0]                va0;
        logic [LSU_L0C_PAYLOAD_INFO_BURST_LEN_BITS-1:0]         trans_len;
        logic [LSU_L0C_PAYLOAD_INFO_VA_ACTIVE_MASK_BITS-1:0]    va_active_mask;
    } t_lsu_l0c_req_payload_info_dma_1v;


    typedef struct packed {
        logic [LSU_L0C_PAYLOAD_INFO_DMA_8V4D_RESERVED_BITS-1:0] reserved;
        logic [LSU_L0C_PAYLOAD_INFO_VA_BITS-1:0]                va7;
        logic [LSU_L0C_PAYLOAD_INFO_VA_BITS-1:0]                va6;
        logic [LSU_L0C_PAYLOAD_INFO_VA_BITS-1:0]                va5;
        logic [LSU_L0C_PAYLOAD_INFO_VA_BITS-1:0]                va4;
        logic [LSU_L0C_PAYLOAD_INFO_VA_BITS-1:0]                va3;
        logic [LSU_L0C_PAYLOAD_INFO_VA_BITS-1:0]                va2;
        logic [LSU_L0C_PAYLOAD_INFO_VA_BITS-1:0]                va1;
        logic [LSU_L0C_PAYLOAD_INFO_VA_BITS-1:0]                va0;
        logic [LSU_L0C_PAYLOAD_INFO_BURST_LEN_BITS-1:0]         trans_len;
        logic [LSU_L0C_PAYLOAD_INFO_VA_ACTIVE_MASK_BITS-1:0]    va_active_mask;
    } t_lsu_l0c_req_payload_info_dma_8v4d;

    typedef struct packed {
        logic [LSU_L0C_PAYLOAD_INFO_DMA_8V4DT_RESERVED_BITS-1:0]reserved;
        logic [5-1:0]                                           burst_len7;
        logic [5-1:0]                                           burst_len6;
        logic [5-1:0]                                           burst_len5;
        logic [5-1:0]                                           burst_len4;
        logic [5-1:0]                                           burst_len3;
        logic [5-1:0]                                           burst_len2;
        logic [5-1:0]                                           burst_len1;
        logic [5-1:0]                                           burst_len0;
        logic [LSU_L0C_PAYLOAD_INFO_VA_BITS-1:0]                va7;
        logic [LSU_L0C_PAYLOAD_INFO_VA_BITS-1:0]                va6;
        logic [LSU_L0C_PAYLOAD_INFO_VA_BITS-1:0]                va5;
        logic [LSU_L0C_PAYLOAD_INFO_VA_BITS-1:0]                va4;
        logic [LSU_L0C_PAYLOAD_INFO_VA_BITS-1:0]                va3;
        logic [LSU_L0C_PAYLOAD_INFO_VA_BITS-1:0]                va2;
        logic [LSU_L0C_PAYLOAD_INFO_VA_BITS-1:0]                va1;
        logic [LSU_L0C_PAYLOAD_INFO_VA_BITS-1:0]                va0;
        logic [LSU_L0C_PAYLOAD_INFO_VA_ACTIVE_MASK_BITS-1:0]    va_active_mask;
    } t_lsu_l0c_req_payload_info_dma_8v4dt;


    typedef struct packed {
        logic [LSU_L0C_PAYLOAD_INFO_VA_BITS-1:0]                va15;
        logic [LSU_L0C_PAYLOAD_INFO_VA_BITS-1:0]                va14;
        logic [LSU_L0C_PAYLOAD_INFO_VA_BITS-1:0]                va13;
        logic [LSU_L0C_PAYLOAD_INFO_VA_BITS-1:0]                va12;
        logic [LSU_L0C_PAYLOAD_INFO_VA_BITS-1:0]                va11;
        logic [LSU_L0C_PAYLOAD_INFO_VA_BITS-1:0]                va10;
        logic [LSU_L0C_PAYLOAD_INFO_VA_BITS-1:0]                va9;
        logic [LSU_L0C_PAYLOAD_INFO_VA_BITS-1:0]                va8;
        logic [LSU_L0C_PAYLOAD_INFO_VA_BITS-1:0]                va7;
        logic [LSU_L0C_PAYLOAD_INFO_VA_BITS-1:0]                va6;
        logic [LSU_L0C_PAYLOAD_INFO_VA_BITS-1:0]                va5;
        logic [LSU_L0C_PAYLOAD_INFO_VA_BITS-1:0]                va4;
        logic [LSU_L0C_PAYLOAD_INFO_VA_BITS-1:0]                va3;
        logic [LSU_L0C_PAYLOAD_INFO_VA_BITS-1:0]                va2;
        logic [LSU_L0C_PAYLOAD_INFO_VA_BITS-1:0]                va1;
        logic [LSU_L0C_PAYLOAD_INFO_VA_BITS-1:0]                va0;
        logic [LSU_L0C_PAYLOAD_INFO_BURST_LEN_BITS-1:0]         trans_len;
        logic [LSU_L0C_PAYLOAD_INFO_VA_ACTIVE_MASK_BITS-1:0]    va_active_mask;
    } t_lsu_l0c_req_payload_info_dma_16v2d;


    // TMA insruction sideband struct
    typedef struct packed {
        logic [CFQ_LSU_SB_TMA_PADDING_BITS-1:0]                 padding;
        logic [CFQ_LSU_SB_TMA_ROBUST_INDEX_BITS-1:0]            robust_index;
        logic [CFQ_LSU_SB_TMA_ROBUST_SELECT_BITS-1:0]           robust_select;
        logic [CFQ_LSU_SB_TMA_TID_INDEX_BITS-1:0]               tid_index;
        logic [CFQ_LSU_SB_TMA_TID_SELECT_BITS-1:0]              tid_select;
        logic [CFQ_LSU_SB_TMA_STRIDE_INDEX_BITS-1:0]            stride_index;
        logic [CFQ_LSU_SB_TMA_STRIDE_SELECT_BITS-1:0]           stride_select;
        logic [CFQ_LSU_SB_TMA_BLY_INDEX_BITS-1:0]               bly_index;
        logic [CFQ_LSU_SB_TMA_BLY_SELECT_BITS-1:0]              bly_select;
        logic [CFQ_LSU_SB_TMA_BLX_INDEX_BITS-1:0]               blx_index;
        logic [CFQ_LSU_SB_TMA_BLX_SELECT_BITS-1:0]              blx_select;
        logic [CFQ_LSU_SB_TMA_ADDR_BASE_INDEX_BITS-1:0]         addr_base_index;
        logic [CFQ_LSU_SB_TMA_ADDR_BASE_SELECT_BITS-1:0]        addr_base_select;
        logic [CFQ_LSU_SB_TMA_MEMOFSET_INDEX_BITS-1:0]          memoffset_index;
        logic [CFQ_LSU_SB_TMA_MEMOFSET_SELECT_BITS-1:0]         memoffset_select;
        logic [CFQ_LSU_SB_TMA_DST_INDEX_BITS-1:0]               dst_index;
        logic [CFQ_LSU_SB_TMA_DST_SELECT_BITS-1:0]              dst_select;
        logic [CFQ_LSU_SB_TMA_MCM_INDEX_BITS-1:0]               mcm_index;
        logic [CFQ_LSU_SB_TMA_MCM_SELECT_BITS-1:0]              mcm_select;
        logic [CFQ_LSU_SB_TMA_WORKGROUP_ID_BITS-1:0]            workgroup_id;
        logic [CFQ_LSU_DM_BITS-1:0]                             dm;
        logic [CFQ_LSU_L2_PREFETCH_SIZE_BITS-1:0]               l2_prefetch_size;
        logic [CFQ_LSU_L2_CACHE_POLICY_BITS-1:0]                l2_cache_policy;
        logic [CFQ_LSU_L1_CACHE_POLICY_BITS-1:0]                l1_cache_policy;
        logic [CFQ_LSU_PERSISTENCE_BITS-1:0]                    persistence;
        logic [CFQ_LSU_SB_TMA_MCS_BITS-1:0]                     mcs;
        logic [CFQ_LSU_SB_TMA_RTYPE_BITS-1:0]                   rtype;
        logic [CFQ_LSU_SB_TMA_MTYPE_BITS-1:0]                   mtype;
        logic [CFQ_LSU_SB_TMA_REG_SEQ-1:0]                      reg_seq;
        logic [CFQ_LSU_SB_TMA_LAYOUT_BITS-1:0]                  layout;
        logic [CFQ_LSU_SB_TMA_OP_BITS-1:0]                      op;
        logic [CFQ_LSU_SB_TMA_TID_BITS-1:0]                     tid;
        logic [CFQ_LSU_TASK_ID_BITS-1:0]                        task_id;

    } cfq_lsu_tma_instr_sb_t;

    // DMA insruction sideband struct
    typedef struct packed {
        logic [CFQ_LSU_SB_DMA_PERF_TRACKED_BITS-1:0]            performance_tracked;
        logic [CFQ_LSU_SB_DMA_MIN_TRANS_DWORD_BITS-1:0]         min_transfer_dword;
        logic [CFQ_LSU_SB_DMA_MAX_TRANS_DWORD_BITS-1:0]         max_transfer_dword;
        logic [CFQ_LSU_SB_DMA_ROBUST_INDEX_BITS-1:0]            robust_index;
        logic [CFQ_LSU_SB_DMA_ROBUST_SELECT_BITS-1:0]           robust_select;
        logic [CFQ_LSU_SB_DMA_STRIDE_INDEX_BITS-1:0]            stride_index;
        logic [CFQ_LSU_SB_DMA_STRIDE_SELECT_BITS-1:0]           stride_select;
        logic [CFQ_LSU_SB_DMA_BLY_INDEX_BITS-1:0]               blx_index;
        logic [CFQ_LSU_SB_DMA_BLY_SELECT_BITS-1:0]              blx_select;
        logic [CFQ_LSU_SB_DMA_BLX_INDEX_BITS-1:0]               bly_index;
        logic [CFQ_LSU_SB_DMA_BLX_SELECT_BITS-1:0]              bly_select;
        logic [CFQ_LSU_SB_DMA_DST_INDEX_BITS-1:0]               dst_index;
        logic [CFQ_LSU_SB_DMA_DST_SELECT_BITS-1:0]              dst_select;
        logic [CFQ_LSU_SB_DMA_MEMOFSET_INDEX_BITS-1:0]          memoffset_index;
        logic [CFQ_LSU_SB_DMA_MEMOFSET_SELECT_BITS-1:0]         memoffset_select;
        logic [CFQ_LSU_SB_DMA_ADDR_BASE_INDEX_BITS-1:0]         addr_base_index;
        logic [CFQ_LSU_SB_DMA_ADDR_BASE_SELECT_BITS-1:0]        addr_base_select;
        logic [CFQ_LSU_SB_DMA_INDEX_INDEX_BITS-1:0]             index_index;
        logic [CFQ_LSU_SB_DMA_INDEX_SELECT_BITS-1:0]            index_select;
        logic [CFQ_LSU_SB_DMA_DATA_REG_INDEX_BITS-1:0]          data_reg_index;
        logic [CFQ_LSU_SB_DMA_DATA_REG_SELECT_BITS-1:0]         data_reg_select;
        logic [CFQ_LSU_SB_DMA_PACK_UNPACK_BITS-1:0]             pack_unpack;
        logic [CFQ_LSU_L2_PREFETCH_SIZE_BITS-1:0]               l2_prefetch_size;
        logic [CFQ_LSU_L2_CACHE_POLICY_BITS-1:0]                l2_cache_policy;
        logic [CFQ_LSU_L1_CACHE_POLICY_BITS-1:0]                l1_cache_policy;
        logic [CFQ_LSU_PERSISTENCE_BITS-1:0]                    persistence;
        logic [CFQ_LSU_SB_DMA_STRIDE_INSTANCE_BASED_BITS-1:0]   stride_instance_based;
        logic [CFQ_LSU_SB_DMA_STRIDE_ADDFIRST_BITS-1:0]         stride_addfirst;
        logic [CFQ_LSU_SB_DMA_ATOMOP_BITS-1:0]                  atomop;
        logic [CFQ_LSU_SB_DMA_OP_BITS-1:0]                      op;
        logic [CFQ_LSU_DM_BITS-1:0]                             dm;
        logic [CFQ_LSU_TASK_ID_BITS-1:0]                        task_id;
    } cfq_lsu_dma_instr_sb_t;

    
    // ccb24 vac/rac sideband struct
    typedef struct packed {
        logic                                                   pair_buff_high      ;    
        logic [INSTANCES_PER_DB_BITS-1:0]                       first_active_inst   ;    
        logic [DBS_PER_INSTRUCTION_BITS-1:0]                    first_active_db     ;    
        logic                                                   instr_rept          ;    
        logic                                                   instr_cut           ;    
        logic [LSU_OP_TMA_TID_BITS-1:0]                         tma_tid             ;    
        logic [CFQ_LSU_SB_TMA_BLY_INDEX_BITS-1:0]               tma_bl_y            ;    
        logic [CFQ_LSU_SB_TMA_BLX_INDEX_BITS-1:0]               tma_bl_x            ;    
        logic [CFQ_LSU_SB_TMA_MCS_BITS-1:0]                     tma_mcs             ;    
        logic [CFQ_LSU_SB_TMA_MTYPE_BITS-1:0]                   tma_mtype           ;    
        logic [CFQ_LSU_SB_TMA_RTYPE_BITS-1:0]                   tma_rtype           ;    
        logic [CFQ_LSU_SB_TMA_LAYOUT_BITS-1:0]                  tma_mat_layout      ;    
        logic [CFQ_LSU_SB_TMA_REG_SEQ-1:0]                      tma_reg_seq         ;    
        logic [CFQ_LSU_SB_TMA_WORKGROUP_ID_BITS-1:0]            tma_work_group_id   ;
        logic [LSU_ROBUST_SEL_NONE_BITS-1:0]                    robust_sel_none     ;    
        logic                                                   stride_sel_imm      ;    
        logic                                                   op0_sel_cr          ;    
        logic                                                   op1_sel_imm         ;    
        logic                                                   op0_sel_imm         ;    
        logic [LSU_OP1_SEL_NONE_BITS-1:0]                       op1_sel_none        ;    
        logic [LSU_OP0_SEL_NONE_BITS-1:0]                       op0_sel_none        ;    
        logic [LSU_INDEX_SEL_NONE_BITS-1:0]                     index_sel_none      ;    
        logic [LSU_STRIDE_SEL_NONE_BITS-1:0]                    stride_sel_none     ;    
        logic [CFQ_LSU_SB_DMA_MEMOFSET_SELECT_BITS-1:0]         memoffset_select    ;
        logic [CFQ_LSU_SB_DMA_ADDR_BASE_SELECT_BITS-1:0]        addr_base_select    ;
        logic [CFQ_LSU_SB_DMA_DATA_REG_SELECT_BITS-1:0]         data_select         ;
        logic [CFQ_LSU_SB_DMA_DST_SELECT_BITS-1:0]              dst_select          ;
        logic [CFQ_LSU_SB_DMA_DST_INDEX_BITS-1:0]               dst_index           ;
        logic [CFQ_LSU_SB_DMA_MAX_TRANS_DWORD_BITS-1:0]         max_transfer_dword  ;
        logic [CFQ_LSU_SB_DMA_MIN_TRANS_DWORD_BITS-1:0]         min_transfer_dword  ;
        logic [LSU_FIRST_FOUR_DB_ID-1:0]                        first_four_db_id    ;
        logic [DBS_PER_INSTRUCTION-1:0]                         db_active_mask      ;
        logic [INSTANCES_PER_INSTRUCTION-1:0]                   inst_active_mask    ;
        logic [CFQ_LSU_SB_DMA_PACK_UNPACK_BITS-1:0]             pack_unpack         ;
        logic [CFQ_LSU_SB_DMA_STRIDE_ADDFIRST_BITS-1:0]         stride_addfirst     ;
        logic [CFQ_LSU_SB_DMA_ATOMOP_BITS-1:0]                  atomop              ;
        logic [CFQ_LSU_SB_DMA_OP_BITS-1:0]                      op                  ;
        logic [CFQ_LSU_DM_BITS-1:0]                             dm                  ;
        logic [CFQ_LSU_TASK_ID_BITS-1:0]                        task_id             ;
        logic [CFQ_LSU_L2_PREFETCH_SIZE_BITS-1:0]               l2_prefetch_size    ;
        logic [CFQ_LSU_L2_CACHE_POLICY_BITS-1:0]                l2_cache_policy     ;
        logic [CFQ_LSU_L1_CACHE_POLICY_BITS-1:0]                l1_cache_policy     ;
        logic [CFQ_LSU_PERSISTENCE_BITS-1:0]                    persistence         ;
        logic [CFQ_LSU_SLOT_BITS-1:0]                           slot                ;    
        logic [CFQ_LSU_SET_FENCE_BITS-1:0]                      set_fence           ;    
        logic [LSU_L0C_LAYOUT_BITS-1:0]                         layout              ;    
        logic [LSU_TMA_DMA_SEL_BITS-1:0]                        tma_dma_sel         ;    
    } t_op_dispatch_vac_instr_sb;
    
    typedef struct packed {
        logic [DBS_PER_INSTRUCTION_BITS-1:0]                    first_active_db     ;    
        logic                                                   instr_rept          ;    
        logic                                                   instr_cut           ;    
        logic [INSTANCES_PER_INSTRUCTION-1:0]                   inst_active_mask    ;
        logic [CFQ_LSU_TASK_ID_BITS-1:0]                        task_id             ;
        logic                                                   op0_sel_cr          ;    
        logic                                                   op1_sel_imm         ;    
        logic                                                   op0_sel_imm         ;    
        logic [LSU_OP1_SEL_NONE_BITS-1:0]                       op1_sel_none        ;    
        logic [LSU_OP0_SEL_NONE_BITS-1:0]                       op0_sel_none        ;    
        logic [LSU_INDEX_SEL_NONE_BITS-1:0]                     index_sel_none      ;    
        logic [CFQ_LSU_SB_DMA_MAX_TRANS_DWORD_BITS-1:0]         max_transfer_dword  ;
        logic [CFQ_LSU_SB_DMA_MIN_TRANS_DWORD_BITS-1:0]         min_transfer_dword  ;
        logic [CFQ_LSU_SB_DMA_MEMOFSET_SELECT_BITS-1:0]         memoffset_select    ;
        logic [CFQ_LSU_SB_DMA_ADDR_BASE_SELECT_BITS-1:0]        addr_base_select    ;
        logic [CFQ_LSU_SB_DMA_DATA_REG_SELECT_BITS-1:0]         data_select         ;
        logic [CFQ_LSU_SB_DMA_DATA_REG_INDEX_BITS-1:0]          data_index          ;
        logic [CFQ_LSU_SB_DMA_DST_SELECT_BITS-1:0]              dst_select          ;
        logic [CFQ_LSU_SB_DMA_DST_INDEX_BITS-1:0]               dst_index           ;
        logic [CFQ_LSU_SLOT_BITS-1:0]                           slot                ;    
        logic [CFQ_LSU_SET_FENCE_BITS-1:0]                      set_fence           ;    
        logic [DBS_PER_INSTRUCTION-1:0]                         db_active_mask      ;
        logic [CFQ_LSU_SB_DMA_ATOMOP_BITS-1:0]                  atomop              ;
        logic [CFQ_LSU_SB_DMA_OP_BITS-1:0]                      op                  ;
        logic [LSU_L0C_LAYOUT_BITS-1:0]                         layout              ;    
        logic [LSU_TMA_DMA_SEL_BITS-1:0]                        tma_dma_sel         ;     
    } t_op_dispatch_rac_instr_sb;




    // --------------------------------------------------------------------------------------------
    // Internal interface bit width
    // --------------------------------------------------------------------------------------------
    // OP_BUFF to VAC
    localparam int OP_BUFF_VAC_SB_BITS    = 143;
    localparam int OP_BUFF_VAC_DB_ID_BITS = DBS_PER_INSTRUCTION_BITS * 8;

    // RAC/VAC Loop
    localparam int BYTES_PER_X_BITS = 8; // up to 32dw(i.e 32*4 bytes)

    // Payload fetch
    localparam int PLD_FETCH_US_BANKS_IN_PARALLEL               = 4;
    localparam int PLD_FETCH_US_BANKS_IN_PARALLEL_BITS          = $clog2(PLD_FETCH_US_BANKS_IN_PARALLEL);
    localparam int PLD_FETCH_SHS_MAX_DWS_PER_REQ                = 32;
    localparam int PLD_FETCH_SHS_MAX_DWS_PER_REQ_BITS           = $clog2(PLD_FETCH_SHS_MAX_DWS_PER_REQ);
    localparam int PLD_FETCH_V2H_BUFF_DW_WIDTH                  = 32; // 32 Dwords
    localparam int PLD_FETCH_V2H_BUFF_DW_WIDTH_BITS             = $clog2(PLD_FETCH_V2H_BUFF_DW_WIDTH);
    localparam int PLD_FETCH_V2H_BUFF_DEPTH                     = 2;
    localparam int PLD_FETCH_V2H_BUFF_DEPTH_BITS                = $clog2(PLD_FETCH_V2H_BUFF_DEPTH);
    localparam int PLD_FETCH_CREDIT_BITS                        = PLD_FETCH_V2H_BUFF_DEPTH_BITS+1;

    // Used for SHS pld fetching, counting total SHS request nums
    localparam int TAIL_DW_BITS     = $clog2(3 + PLD_FETCH_SHS_MAX_DWS_PER_REQ);
    localparam int TAIL_DW_ROW_BITS = $clog2(PLD_FETCH_SHS_MAX_DWS_PER_REQ/4) + 1;


    typedef struct packed {
        logic                                                       tma_dma_sel;
        logic [CFQ_LSU_SB_DMA_OP_BITS-1:0]                          dma_op;
        logic [CFQ_LSU_SB_DMA_ATOMOP_BITS-1:0]                      dma_atomic_op;
        logic [REG_SEL_BITS-1:0]                                    dst_reg_sel;
        logic [LSU_OP_INDEX_BITS-1:0]                               index;
        logic [LSU_OP_DMA_BLX_BITS+1-1:0]                           bl_x;
        logic [LSU_OP_DMA_BLY_BITS+1-1:0]                           bl_y;
        logic [CFQ_LSU_SB_DMA_MAX_TRANS_DWORD_BITS-1:0]             max_transfer_dword;
        logic [CFQ_LSU_SB_DMA_MIN_TRANS_DWORD_BITS-1:0]             min_transfer_dword;
    } t_drop_dect_mul_in;

    typedef struct packed {
        logic                                                       drop_dect_on;
        logic [CFQ_LSU_SB_DMA_MAX_TRANS_DWORD_BITS-1:0]             max_transfer_dword;
        logic [CFQ_LSU_SB_DMA_MIN_TRANS_DWORD_BITS-1:0]             min_transfer_dword;
        logic [LSU_OP_INDEX_BITS-1:0]                               index;
        logic [LSU_OP_DMA_BLX_BITS+1-2+LSU_OP_DMA_BLY_BITS+1 -1:0]  blx_times_bly_dw_gran;
    } t_drop_dect_mul_out;




    // op_buff to rac_loop info
    typedef struct packed {
        logic                                                                                      need_fetch_data;
        logic                                                                                      need_rac_vac_trans;
        logic                                                                                      is_atomic_instr;
        logic                                                                                      is_st_pair_instr;
        logic [LSU_RELATED_STORES_BITS-1:0]                                                        dst_data_reg_sel;
        logic [DBS_PER_INSTRUCTION-1:0]                                                            db_active_mask;
        logic [REG_INDEX_BITS-1:0]                                                                 dst_data_reg;
        logic [LSU_OP_INDEX_BITS-1:0]                                                              index;
        logic [LSU_OP_DMA_BLX_BITS+1-1:0]                                                          bl_x;
        logic [LSU_OP_DMA_BLY_BITS+1-1:0]                                                          bl_y;
        logic [LSU_L0C_LAYOUT_BITS-1:0]                                                            layout;
        logic [CFQ_LSU_SET_FENCE_BITS-1:0]                                                         set_fence;
        logic [CFQ_LSU_SLOT_BITS-1:0]                                                              slot;
        logic [CFQ_LSU_TASK_ID_BITS-1:0]                                                           task_id;
    } t_op_buff_rac_loop_info;

    // op_buff to vac_loop info
    typedef struct packed {
        logic [CFQ_LSU_TMA_DMA_SEL_BITS-1:0]                                                       tma_dma_sel;
        logic [CFQ_LSU_SB_DMA_OP_BITS-1:0]                                                         op;
        logic [CFQ_LSU_INSTANCE_ACTIVE_MASK_BITS-1:0]                                              inst_active_mask;
        logic [LSU_L0C_LAYOUT_BITS-1:0]                                                            layout;
        logic [CFQ_LSU_SET_FENCE_BITS-1:0]                                                         set_fence;
        logic [CFQ_LSU_SLOT_BITS-1:0]                                                              slot;
        logic [CFQ_LSU_PERSISTENCE_BITS-1:0]                                                       persistence;
        logic [CFQ_LSU_L1_CACHE_POLICY_BITS-1:0]                                                   l1_cache_policy;
        logic [CFQ_LSU_L2_CACHE_POLICY_BITS-1:0]                                                   l2_cache_policy;
        logic [CFQ_LSU_L2_PREFETCH_SIZE_BITS-1:0]                                                  l2_prefetch_size;
        logic [TASK_ID_BITS-1:0]                                                                   task_id;
        logic [DM_BITS-1:0]                                                                        dm;
        logic [CFQ_LSU_SB_DMA_ATOMOP_BITS-1:0]                                                     atomic_op;
        logic                                                                                      addfirst;
        logic                                                                                      pack_unpack;
        logic [REG_INDEX_BITS-1:0]                                                                 dst_reg;
        logic                                                                                      need_rac;
        logic                                                                                      lms_related;
        logic                                                                                      need_wr_ctrl_trans;
        logic [LSU_RELATED_STORES_BITS-1:0]                                                        dest_store;
        logic [LSU_OP_DMA_BLX_BITS+1-1:0]                                                          bl_x;
        logic [LSU_OP_DMA_BLY_BITS+1-1:0]                                                          bl_y;
        logic [LSU_OP_DMA_STRIDE_BITS+1-1:0]                                                       stride;
        logic [LSU_OP_INDEX_BITS-1:0]                                                              index;
        logic                                                                                      robust_active;
        logic [LSU_OP_ROBUST_BASE_BITS-1:0]                                                        robust_base;
        logic [LSU_OP_ROBUST_SIZE_BITS-1:0]                                                        robust_size;
        logic                                                                                      addr_base_is_inst_based;
        logic                                                                                      memoffset_is_inst_based;
        logic                                                                                      instr_rept;
        logic                                                                                      is_ld_st_pair_instr;
        logic                                                                                      pair_buff_high;
    } t_op_buff_vac_loop_info;


    // rac_loop to rac_ac info
    typedef struct packed {
        logic                                                                                      need_fetch_data;
        logic                                                                                      need_rac_vac_trans;
        logic                                                                                      is_atomic_instr;
        logic                                                                                      is_st_pair_instr;
        logic [LSU_RELATED_STORES_BITS-1:0]                                                        dst_data_reg_sel;
        logic [DBS_PER_INSTRUCTION-1:0]                                                            db_active_mask;
        logic [REG_INDEX_BITS-1:0]                                                                 dst_data_reg;
        logic [LSU_OP_INDEX_BITS-1:0]                                                              index;
        logic [LSU_OP_DMA_BLX_BITS+1-1:0]                                                          bl_x;
        logic [LSU_L0C_LAYOUT_BITS-1:0]                                                            layout;
        logic [CFQ_LSU_SET_FENCE_BITS-1:0]                                                         set_fence;
        logic [CFQ_LSU_SLOT_BITS-1:0]                                                              slot;
        logic [CFQ_LSU_TASK_ID_BITS-1:0]                                                           task_id;
        logic [LSU_OP_DMA_BLX_BITS-1:0]                                                            x;
        logic                                                                                      last_x_in_y;
        logic                                                                                      last_in_instruction;
        logic                                                                                      instr_repetition_last;
    } t_rac_loop_rac_ac_info;

    // vac_loop to vac_ac info
    typedef struct packed {
        logic                                                                                      instr_repetition_last;
        logic                                                                                      pack_unpack;
        logic [LSU_L0C_DEST_STORE_BITS-1:0]                                                        dest_store;
        logic [REG_INDEX_BITS-1:0]                                                                 dst_reg;
        logic [LSU_OP_INDEX_BITS-1:0]                                                              index;
        logic                                                                                      need_rac;
        logic                                                                                      lms_related;
        logic                                                                                      addfirst;
        logic [LSU_OP_DMA_BLX_BITS-1:0]                                                            x;
        logic [2-1:0] [INSTANCES_PER_DB-1:0] [LSU_OP_ADDR_BASE_BITS-1:0]                           addr_base;
        logic [2-1:0] [INSTANCES_PER_DB-1:0] [LSU_OP_MEMOFFSET_BITS-1:0]                           memoffset;
        logic                                                                                      last_x_in_y;
        logic                                                                                      last_z_in_x;
        logic                                                                                      last_in_instruction;
        logic [INSTANCES_PER_DB_GRP-1:0]                                                           inst_active_mask;
        logic [CFQ_LSU_TMA_DMA_SEL_BITS-1:0]                                                       tma_dma_sel;
        logic [LSU_OP_DMA_BLX_BITS+1-1:0]                                                          bl_x;
        logic [LSU_OP_DMA_STRIDE_BITS+1-1:0]                                                       stride;
        logic [LSU_L0C_LAYOUT_BITS-1:0]                                                            layout;
        logic [CFQ_LSU_SET_FENCE_BITS-1:0]                                                         set_fence;
        logic [CFQ_LSU_SLOT_BITS-1:0]                                                              slot;
        logic [CFQ_LSU_PERSISTENCE_BITS-1:0]                                                       persistence;
        logic [CFQ_LSU_L1_CACHE_POLICY_BITS-1:0]                                                   l1_cache_policy;
        logic [CFQ_LSU_L2_CACHE_POLICY_BITS-1:0]                                                   l2_cache_policy;
        logic [CFQ_LSU_L2_PREFETCH_SIZE_BITS-1:0]                                                  l2_prefetch_size;
        logic [TASK_ID_BITS-1:0]                                                                   task_id;
        logic [DM_BITS-1:0]                                                                        dm;
        logic [CFQ_LSU_SB_DMA_OP_BITS-1:0]                                                         op;
        logic [CFQ_LSU_SB_DMA_ATOMOP_BITS-1:0]                                                     atomic_op;
        logic                                                                                      robust_active;
        logic [LSU_OP_ROBUST_BASE_BITS-1:0]                                                        robust_base;
        logic [LSU_OP_ROBUST_SIZE_BITS-1:0]                                                        robust_size;
    } t_vac_loop_vac_ac_info;

    // rac_ac output info
    typedef struct packed {
        logic                                                                                      drop;
        logic                                                                                      need_fetch_data;
        logic                                                                                      need_rac_vac_trans;
        logic                                                                                      is_atomic_instr;
        logic                                                                                      is_st_pair_instr;
        logic [LSU_RELATED_STORES_BITS-1:0]                                                        dst_data_reg_sel;
        logic [LSU_L0C_DEST_ADDR_BITS-1:0]                                                         reg_index;
        logic [BYTES_PER_X_BITS-1:0]                                                               burst_len;
        logic [DBS_PER_INSTRUCTION-1:0]                                                            db_active_mask;
        logic [LSU_L0C_LAYOUT_BITS-1:0]                                                            layout;
        logic [CFQ_LSU_SET_FENCE_BITS-1:0]                                                         set_fence;
        logic [CFQ_LSU_SLOT_BITS-1:0]                                                              slot;
        logic [CFQ_LSU_TASK_ID_BITS-1:0]                                                           task_id;
        logic                                                                                      last_in_instruction;
    } t_rac_ac_out_info;

    // vac_ac output info
    typedef struct packed {
        logic                                                                                      pack_unpack;
        logic                                                                                      need_rac;
        logic                                                                                      lms_related;
        logic [LSU_L0C_DEST_STORE_BITS-1:0]                                                        dest_store;
        logic [LSU_L0C_DEST_ADDR_BITS-1:0]                                                         dest_addr;
        logic [2-1:0][INSTANCES_PER_DB-1:0] [LSU_L0C_PAYLOAD_INFO_VA_BITS-1:0]                     mem_addr;
        logic [LSU_L0C_PAYLOAD_INFO_BURST_LEN_BITS-1:0]                                            burst_len;
        logic [LSU_L0C_PAYLOAD_INFO_VA_ACTIVE_MASK_BITS-1:0]                                       inst_active_mask;
        logic [LSU_L0C_TMA_DMA_SEL_BITS-1:0]                                                       tma_dma_sel;
        logic [LSU_L0C_LAYOUT_BITS-1:0]                                                            layout;
        logic [LSU_L0C_SET_FENCE_BITS-1:0]                                                         set_fence;
        logic [LSU_L0C_SLOT_BITS-1:0]                                                              slot;
        logic [LSU_L0C_PERSISTENCE_BITS-1:0]                                                       persistence;
        logic [LSU_L0C_L1_CACHE_POLICY_BITS-1:0]                                                   l1_cache_policy;
        logic [LSU_L0C_L2_CACHE_POLICY_BITS-1:0]                                                   l2_cache_policy;
        logic [LSU_L0C_PREFETCH_SIZE_BITS-1:0]                                                     l2_prefetch_size;
        logic [TASK_ID_BITS-1:0]                                                                   task_id;
        logic [DM_BITS-1:0]                                                                        dm;
        logic [LSU_L0C_OP_BITS-1:0]                                                                op;
        logic [LSU_L0C_ATOMIC_OP_BITS-1:0]                                                         atomic_op;
        logic [LSU_L0C_ROBUST_ACTIVE_BITS-1:0]                                                     robust_active;
        logic [LSU_L0C_ROBUST_BASE_BITS-1:0]                                                       robust_base;
        logic [LSU_L0C_ROBUST_SIZE_BITS-1:0]                                                       robust_size;
        logic                                                                                      last_of_128v;
        logic                                                                                      instr_end;
        logic                                                                                      drop;
    } t_vac_ac_out_info;

    // rac to pld_fetch info
    typedef struct packed {
        logic                                                                                      is_atomic_instr;
        logic                                                                                      is_st_pair_instr;
        logic [LSU_RELATED_STORES_BITS-1:0]                                                        data_reg_sel;
        logic [LSU_L0C_DEST_ADDR_BITS-1:0]                                                         reg_index;
        logic [BYTES_PER_X_BITS-1:0]                                                               burst_len;
        logic [DBS_PER_INSTRUCTION-1:0]                                                            db_active_mask;
        logic [LSU_L0C_LAYOUT_BITS-1:0]                                                            layout;
        logic [CFQ_LSU_SET_FENCE_BITS-1:0]                                                         set_fence;
        logic [CFQ_LSU_SLOT_BITS-1:0]                                                              slot;
        logic [CFQ_LSU_TASK_ID_BITS-1:0]                                                           task_id;
        logic                                                                                      last_in_instruction;
    } t_rac_pld_fetch_info;


    typedef struct packed {
        logic [2-1:0] [INSTANCES_PER_DB-1:0] [LSU_OP_ADDR_BASE_BITS-1:0]                           addr_base;
        logic [2-1:0] [INSTANCES_PER_DB-1:0] [LSU_OP_MEMOFFSET_BITS-1:0]                           memoffset;
    } t_vac_loop_op_buff_lookup_data;

    typedef struct packed {
        logic [INSTANCES_PER_DB-1:0] [TEXEL_BURST_LEN_BITS-1:0]                                    texel_burst_len;
    } t_rac_loop_op_buff_lookup_data;


    typedef struct packed {
        logic [PLD_FETCH_V2H_BUFF_DW_WIDTH-1:0] [DW_BITS-1:0] data;
        logic [DBS_PER_INSTRUCTION_BITS-1:0]                  copy_cnt_minus1;
        logic                                                 last_in_instruction;
        logic [CFQ_LSU_SET_FENCE_BITS-1:0]                    set_fence;
        logic [CFQ_LSU_SLOT_BITS-1:0]                         slot;
        logic                                                 is_atomic_instr;
        logic  [2-1:0]                                        pack_source;
        logic  [2-1:0]                                        pack_style;
    } t_v2h_buff_entry;

    typedef struct packed {
        logic                                                 last_in_instruction;
        logic                                                 is_atomic_instr;
        logic  [2-1:0]                                        pack_source;
        logic  [2-1:0]                                        pack_style;
        logic [CFQ_LSU_SET_FENCE_BITS-1:0]                    set_fence;
        logic [CFQ_LSU_SLOT_BITS-1:0]                         slot;
        logic [DBS_PER_INSTRUCTION_BITS-1:0]                  copy_cnt_minus1;
    } t_v2h_buff_entry_sb;

    typedef struct packed {
        logic [4-1:0]                                           req_mask;
        logic [4-1:0] [US_BANKS_BITS-1:0]                       bank_id;
    } t_pld_fetch_v2h_entry_info_us;



    typedef struct packed {
        logic [DBS_PER_INSTRUCTION_BITS-1:0]                    copy_cnt_minus1;
    } t_pld_fetch_v2h_entry_info_shs;

    typedef struct packed {
        logic [2-1:0]                                                                source                              ;
        logic                                                                        is_atomic_instr                     ;
        logic                                                                        last_in_instr                       ;
        logic [SET_FENCE_BITS-1:0]                                                   set_fence                           ;
        logic [SLOT_ID_BITS-1:0]                                                     slot                                ;
        logic [2-1:0]                                                                pack_style                          ;
        logic [PLD_FETCH_US_BANKS_IN_PARALLEL-1:0] [US_BANKS_BITS-1:0]               bank_id                             ;
        logic [PLD_FETCH_US_BANKS_IN_PARALLEL-1:0]                                   req_mask                            ;
        logic [DBS_PER_INSTRUCTION_BITS-1:0]                                         copy_cnt                            ;
    } t_v2h_buff_entry_info;





    localparam logic [2-1:0]    PACK_STYLE_16V2D   = 2'd0;
    localparam logic [2-1:0]    PACK_STYLE_8V4D    = 2'd1;
    localparam logic [2-1:0]    PACK_STYLE_1V32D   = 2'd2;
    localparam logic [2-1:0]    PACK_STYLE_ST_PAIR = 2'd3;

    localparam logic [2-1:0]    PACK_SOURCE_US     = 2'd0;
    localparam logic [2-1:0]    PACK_SOURCE_SHS    = 2'd1;
    localparam logic [2-1:0]    PACK_SOURCE_NONE   = 2'd2;

    //---------------------------------------------------------------------------------
    // Function: find leading 1
    //---------------------------------------------------------------------------------
    function automatic logic f_find_lead_one_1 (logic [1-1:0] in_data);
        return 1'b0;
    endfunction
    
    function automatic logic f_find_lead_one_2 (logic [2-1:0] in_data);
        logic res;
        res = 0;
        for(int i = 2-1; i >= 0; i--) begin
            if(in_data[i] == 1'b1) res = i;
        end
        return res;
    endfunction
    
    function automatic logic [2-1:0] f_find_lead_one_4 (logic [4-1:0] in_data);
        logic [2-1:0] res;
        res = 0;
        for(int i = 4-1; i >= 0; i--) begin
            if(in_data[i] == 1'b1) res = i;
        end
        return res;
    endfunction
    
    function automatic logic [3-1:0] f_find_lead_one_8 (logic [8-1:0] in_data);
        logic [3-1:0] res;
        res = 0;
        for(int i = 8-1; i >= 0; i--) begin
            if(in_data[i] == 1'b1) res = i;
        end
        return res;
    endfunction

    
    function automatic logic [4-1:0] f_find_lead_one_16 (logic [16-1:0] in_data);
        logic [4-1:0] res;
        res = 0;
        for(int i = 16-1; i >= 0; i--) begin
            if(in_data[i] == 1'b1) res = i;
        end
        return res;
    endfunction
    
    function automatic logic [5-1:0] f_find_lead_one_32 (logic [32-1:0] in_data);
        logic [5-1:0] res;
        res = 0;
        for(int i = 32-1; i >= 0; i--) begin
            if(in_data[i] == 1'b1) res = i;
        end
        return res;
    endfunction

    function automatic logic [7-1:0] f_find_lead_one_128 (logic [128-1:0] in_data);
        logic [7-1:0] res;

        logic [16-1:0]  [8-1:0]     in_data_per_8bits;
        logic [16-1:0]              or_reduced_per_8bits;
        logic [4-1:0]               or_reduced_per_8bits_lead_one;
        logic [16-1:0]  [3-1:0]     in_data_per_8bits_lead_one;

        res = 0;

        for(int i = 0; i < 16; i++) begin
            in_data_per_8bits          [i] = in_data[i*8+:8];
            or_reduced_per_8bits       [i] = |(in_data_per_8bits [i]);
            in_data_per_8bits_lead_one [i] = f_find_lead_one_8(in_data_per_8bits[i]);
        end

        or_reduced_per_8bits_lead_one = f_find_lead_one_16(or_reduced_per_8bits);

        res = {or_reduced_per_8bits_lead_one, in_data_per_8bits_lead_one[or_reduced_per_8bits_lead_one]};

        return res;
    endfunction

    function automatic logic [3-1:0] f_find_last_one_8 (logic [8-1:0] in_data);
        logic [3-1:0] res;
        res = 0;
        for(int i = 0; i < 8; i++) begin
            if(in_data[i] == 1'b1) res = i;
        end
        return res;
    endfunction
    
    function automatic logic [2-1:0] f_count_ones_2 (logic [2-1:0] in_data);
        logic [2-1:0] res;
        res = 0;
        for(int i = 0; i < 2; i++) begin
            if(in_data[i] == 1'b1) res = res + 1;
        end
        return res;
    endfunction
    
    function automatic logic [3-1:0] f_count_ones_4 (logic [4-1:0] in_data);
        logic [3-1:0] res;
        res = 0;
        for(int i = 0; i < 4; i++) begin
            if(in_data[i] == 1'b1) res = res + 1;
        end
        return res;
    endfunction
    
    function automatic logic [4-1:0] f_count_ones_8 (logic [8-1:0] in_data);
        logic [4-1:0] res;
        res = 0;
        for(int i = 0; i < 8; i++) begin
            if(in_data[i] == 1'b1) res = res + 1;
        end
        return res;
    endfunction

    function automatic logic [5-1:0] f_count_ones_16 (logic [16-1:0] in_data);
        logic [5-1:0] res;
        res = 0;
        for(int i = 0; i < 16; i++) begin
            if(in_data[i] == 1'b1) res = res + 1;
        end
        return res;
    endfunction

    

    
    //---------------------------------------------------------------------------------
    // Function: US Bank hash funtion
    //---------------------------------------------------------------------------------
    function automatic logic [DB_GRPS_PER_INSTRUCTION_BITS-1:0] f_get_db_pair(logic [$clog2(SPAGS_PER_EU)-1:0] spag, logic [$clog2(US_PER_SPAG)-1:0] us);
    logic [DB_GRPS_PER_INSTRUCTION_BITS-1:0] db_index;
        // The DB pair can be described as below
        // 0 --> DB0 and DB8
        // 1 --> DB1 and DB9
        // 2 --> DB2 and DB10
        // 3 --> DB3 and DB11
        // 4 --> DB4 and DB12
        // 5 --> DB5 and DB13
        // 6 --> DB6 and DB14
        // 7 --> DB7 and DB15
        case(spag)
            0 :      db_index = us == 1'b0 ? 0 : 4;
            1 :      db_index = us == 1'b0 ? 2 : 6;
            2 :      db_index = us == 1'b0 ? 1 : 5;
            default: db_index = us == 1'b0 ? 3 : 7;
        endcase
        return db_index;
    endfunction
    
    
    function automatic logic [3-1:0] f_get_us_pos_for_db(logic [3:0] db);
        logic [2:0] spag_us;
        case(db[2:0])
            0 :       spag_us = {2'h0, 1'h0};
            1 :       spag_us = {2'h2, 1'h0};
            2 :       spag_us = {2'h1, 1'h0};
            3 :       spag_us = {2'h3, 1'h0};
            4 :       spag_us = {2'h0, 1'h1};
            5 :       spag_us = {2'h2, 1'h1};
            6 :       spag_us = {2'h1, 1'h1};
            default : spag_us = {2'h3, 1'h1};
        endcase
        return spag_us;
    endfunction
    
    function automatic logic [1:0] f_get_us_bank(logic [1:0] index_2_lsb, logic hash_key, logic segment);
        return index_2_lsb ^ {1'b0, hash_key} ^ {segment, 1'b0};
    endfunction
    
    
    
    
    //---------------------------------------------------------------------------------
    // Function: Pack the store sel and index for all the operands
    //---------------------------------------------------------------------------------
    function automatic logic [7:0] [3:0] f_gen_tma_op_st_sel(cfq_lsu_tma_instr_sb_t tma_instr_sb);
        logic [7:0] [3:0] st_sel_list;
        st_sel_list[0]    = tma_instr_sb.tid_select;
        st_sel_list[1]    = tma_instr_sb.mcm_select;
        st_sel_list[2]    = tma_instr_sb.stride_select;
        st_sel_list[3]    = '0;                            // not used
        st_sel_list[4]    = tma_instr_sb.robust_select;
        st_sel_list[5]    = tma_instr_sb.addr_base_select;
        st_sel_list[6]    = tma_instr_sb.addr_base_select;
        st_sel_list[7]    = tma_instr_sb.memoffset_select;
        return st_sel_list;
    endfunction
    
    function automatic logic [7:0] [12:0] f_gen_tma_op_index(cfq_lsu_tma_instr_sb_t tma_instr_sb);
        logic [7:0] [12:0] index_list;
        index_list[0]  = tma_instr_sb.tid_index;
        index_list[1]  = tma_instr_sb.mcm_index;
        index_list[2]  = tma_instr_sb.stride_index;
        index_list[3]  = '0;                               // not used
        index_list[4]  = tma_instr_sb.robust_index;
        index_list[5]  = tma_instr_sb.addr_base_index;
        index_list[6]  = tma_instr_sb.addr_base_index + 1'b1;
        index_list[7]  = tma_instr_sb.memoffset_index;
        return index_list;
    endfunction
    
    function automatic logic [7:0] [3:0] f_gen_dma_op_st_sel(cfq_lsu_dma_instr_sb_t dma_instr_sb);
        logic [7:0] [3:0] st_sel_list;
        st_sel_list[0]   = dma_instr_sb.blx_select;
        st_sel_list[1]   = dma_instr_sb.bly_select;
        st_sel_list[2]   = dma_instr_sb.stride_select;
        st_sel_list[3]   = dma_instr_sb.index_select;
        st_sel_list[4]   = dma_instr_sb.robust_select;
        st_sel_list[5]   = dma_instr_sb.addr_base_select;
        st_sel_list[6]   = dma_instr_sb.addr_base_select;
        st_sel_list[7]   = dma_instr_sb.memoffset_select;
        return st_sel_list;
    endfunction
    
    function automatic logic [7:0] [12:0] f_gen_dma_op_index(cfq_lsu_dma_instr_sb_t dma_instr_sb);
        logic [7:0] [12:0] index_list;
        index_list[0] = dma_instr_sb.blx_index;
        index_list[1] = dma_instr_sb.bly_index;
        index_list[2] = dma_instr_sb.stride_index;
        index_list[3] = {(13-CFQ_LSU_SB_DMA_INDEX_INDEX_BITS)'(0),dma_instr_sb.index_index};
        index_list[4] = dma_instr_sb.robust_index;
        index_list[5] = dma_instr_sb.addr_base_index;
        index_list[6] = dma_instr_sb.addr_base_index + 'b1;
        index_list[7] = {(13-CFQ_LSU_SB_DMA_MEMOFSET_INDEX_BITS)'(0), dma_instr_sb.memoffset_index};
        return index_list;
    endfunction
    
    
    
    //---------------------------------------------------------------------------------
    // Function: Adjust the CFQ op, layout to L0C op
    //---------------------------------------------------------------------------------
    function automatic logic [LSU_L0C_OP_BITS-1:0] f_op_adjust(logic is_dma_instruction, logic [LSU_L0C_OP_BITS-1:0] op);
        logic [LSU_L0C_OP_BITS-1:0] res;
        if(is_dma_instruction) begin
            case(op)
                OP_CFI_INVAL    : res = MH_INVAL;
                OP_CFI_FLUSH    : res = MH_FLUSH;
                OP_CFI_FLUSHINV : res = MH_FLUSHINV;
                OP_ST           : res = MH_STORE;
                OP_TEXELST      : res = MH_STORE;
                OP_LD           : res = MH_LOAD;
                OP_TEXELLD      : res = MH_LOAD;
                OP_IDF          : res = MH_WR_FENCE;
                OP_ATOMIC_32    : res = MH_ATOMIC32;
                OP_ATOMIC_64    : res = MH_ATOMIC64;
                OP_ATOMIC_F32   : res = MH_ATOMICFP32;
                OP_LD_PAIR      : res = MH_LOAD;
                OP_ST_PAIR      : res = MH_STORE;
                default         : res = '0;
            endcase
        end else begin
            res = MH_LOAD;
        end
        return res;
    endfunction

    function automatic logic [LSU_L0C_LAYOUT_BITS-1:0] f_layout_adjust(logic [LSU_L0C_LAYOUT_BITS-1:0] layout, logic [LSU_L0C_OP_BITS-1:0] op);
        logic [LSU_L0C_LAYOUT_BITS-1:0] res;
        if     (layout == LSU_L0C_LAYOUT_16V1D                   ) res = LSU_L0C_LAYOUT_16V2D; // for texel-ld
        else if(layout == LSU_L0C_LAYOUT_8V4D && op == OP_TEXELST) res = LSU_L0C_LAYOUT_8V4DT; // for texel-st
        else                                                       res = layout;
        return res;
    endfunction

    function automatic logic [LSU_L0C_LAYOUT_BITS-1:0] f_layout_req_rtn_path_adjust(logic [LSU_L0C_LAYOUT_BITS-1:0] layout, logic [LSU_L0C_OP_BITS-1:0] op);
        logic [LSU_L0C_LAYOUT_BITS-1:0] res;
        if(layout == LSU_L0C_LAYOUT_8V4D && op == OP_TEXELST)      res = LSU_L0C_LAYOUT_8V4DT; // for texel-st
        else                                                       res = layout;
        return res;
    endfunction

    //---------------------------------------------------------------------------------
    // Function: Determine whether a instruction is instance-based
    //---------------------------------------------------------------------------------
    function automatic logic f_is_inst_base_instruction (
           logic                                is_dma_instruction  ,
           logic [CFQ_LSU_SB_DMA_OP_BITS-1:0]   op                  ,
           logic                                dst_reg_is_us       , 
           logic                                data_reg_is_us      ,
           logic [REG_SEL_BITS-1:0]             addr_base_sel       ,
           logic [REG_SEL_BITS-1:0]             memoffset_sel        
    );
        logic res;

        // DMA instruction
        if(is_dma_instruction) begin
            // For Load instruction, if load to US, then the instruction is instance-based
            if(op ==  OP_LD) begin
                if(dst_reg_is_us) res = 1'b1;
                else              res = 1'b0;
            end else if(op == OP_ST) begin
                // If one of addr_base and memoffset is fetched from US or temp_spilling happends, the instruction is instance-based
                if(addr_base_sel != REG_SEL_CR && addr_base_sel != REG_SEL_TMP && addr_base_sel != REG_SEL_A && memoffset_sel == REG_SEL_NONE)
                    res = 1'b0;
                else
                    res = 1'b1;
            end else if(op == OP_TEXELLD || op == OP_TEXELST || op == OP_ATOMIC_32 || op == OP_ATOMIC_64 || op ==  OP_ATOMIC_F32 || op ==  OP_LD_PAIR || op ==  OP_ST_PAIR) begin
                res = 1'b1;
            end else begin
                res = 1'b0;
            end
        // TMA instruction
        end else begin
            res = 1'b0;
        end

        return res;
    endfunction

    //---------------------------------------------------------------------------------
    // Function: Determine whether a instruction needs to fetch data
    //---------------------------------------------------------------------------------
    function automatic logic f_instr_need_fetch_data (
        logic                              tma_dma_sel,
        logic [CFQ_LSU_SB_DMA_OP_BITS-1:0] dma_op
    );
        logic res;
        res = (tma_dma_sel == TMA_DMA_SEL_DMA) && (dma_op == OP_ST || dma_op == OP_ST_PAIR  || dma_op == OP_ATOMIC_32  || dma_op == OP_ATOMIC_64  || dma_op == OP_ATOMIC_F32);
        return res;
    endfunction
    //---------------------------------------------------------------------------------
    // Function: Determine whether a instruction needs RAC to VAC trans
    //---------------------------------------------------------------------------------
    function automatic logic f_instr_need_rac_vac_trans (
        logic                               tma_dma_sel,
        logic [CFQ_LSU_SB_DMA_OP_BITS-1:0]  dma_op,
        logic [REG_SEL_BITS-1:0]            data_reg_sel
    );
        logic res;
        res = (tma_dma_sel == TMA_DMA_SEL_DMA) && ((dma_op == OP_LD || dma_op == OP_LD_PAIR) || (dma_op == OP_ST && data_reg_sel == REG_SEL_LMS));
        return res;
    endfunction
    //---------------------------------------------------------------------------------
    // Function: Determine whether a instruction needs push req to rtn path fifo
    //---------------------------------------------------------------------------------
    function automatic logic f_instr_need_req_to_rtn_sb (
        logic                               tma_dma_sel,
        logic [CFQ_LSU_SB_DMA_OP_BITS-1:0]  dma_op,
        logic [REG_SEL_BITS-1:0]            dst_reg_sel
    );
        logic res;
        res = (tma_dma_sel == TMA_DMA_SEL_DMA && dst_reg_sel != REG_SEL_LMS) && (dma_op == OP_LD || dma_op == OP_LD_PAIR  || dma_op == OP_ATOMIC_32  || dma_op == OP_ATOMIC_64  || dma_op == OP_ATOMIC_F32 || dma_op == OP_IDF);
        return res;
    endfunction
    //---------------------------------------------------------------------------------
    // Function: Determine whether a instruction is an atomic instruction
    //---------------------------------------------------------------------------------
    function automatic logic f_is_atomic_instruction (
        logic                               tma_dma_sel,
        logic [CFQ_LSU_SB_DMA_OP_BITS-1:0]  dma_op
    );
        logic res;
        res = (tma_dma_sel == TMA_DMA_SEL_DMA) && (dma_op == OP_ATOMIC_32  || dma_op == OP_ATOMIC_64  || dma_op == OP_ATOMIC_F32);
        return res;
    endfunction
    //---------------------------------------------------------------------------------
    // Function: Determine whether a instruction is an ld/st_pair instruction
    //---------------------------------------------------------------------------------
    function automatic logic f_is_st_pair_instruction (
        logic                               tma_dma_sel,
        logic [CFQ_LSU_SB_DMA_OP_BITS-1:0]  dma_op
    );
        logic res;
        res = (tma_dma_sel == TMA_DMA_SEL_DMA) && (dma_op == OP_ST_PAIR);
        return res;
    endfunction
    function automatic logic f_is_ld_pair_instruction (
        logic                               tma_dma_sel,
        logic [CFQ_LSU_SB_DMA_OP_BITS-1:0]  dma_op
    );
        logic res;
        res = (tma_dma_sel == TMA_DMA_SEL_DMA) && (dma_op == OP_LD_PAIR);
        return res;
    endfunction
    //---------------------------------------------------------------------------------
    // Function: Determine whether a instruction is LMS related
    //---------------------------------------------------------------------------------
    function automatic logic f_is_lms_related_instuction (
        logic                               tma_dma_sel,
        logic [CFQ_LSU_SB_DMA_OP_BITS-1:0]  dma_op,
        logic [REG_SEL_BITS-1:0]            dst_reg_sel,
        logic [REG_SEL_BITS-1:0]            data_reg_sel
    );
        logic res;
        res = (tma_dma_sel == TMA_DMA_SEL_DMA) && ((dma_op == OP_LD && dst_reg_sel == REG_SEL_LMS) || (dma_op == OP_ST && data_reg_sel == REG_SEL_LMS));
        return res;
    endfunction
    //---------------------------------------------------------------------------------
    // Function: Change the REG_SEL encoding to US/SHS/LMS/NONE encoding
    //---------------------------------------------------------------------------------
    function automatic logic [LSU_L0C_DEST_STORE_BITS-1:0] f_get_dest_data_reg_store (logic [REG_SEL_BITS-1:0] dst_data_reg_sel);
        logic [LSU_L0C_DEST_STORE_BITS-1:0] res;
        case(dst_data_reg_sel)
            REG_SEL_A   : res = DATA_DST_REG_SEL_US;
            REG_SEL_TMP : res = DATA_DST_REG_SEL_US;
            REG_SEL_SHS : res = DATA_DST_REG_SEL_SHS;
            REG_SEL_LMS : res = DATA_DST_REG_SEL_LMS;
            default     : res = DATA_DST_REG_SEL_NONE;
        endcase
        return res;
    endfunction
    //---------------------------------------------------------------------------------
    // Function: Determine whether a instruction is a 1v32d multi-instance mode instruction
    //---------------------------------------------------------------------------------
    function automatic logic f_is_repetition_instr (
           logic                                tma_dma_sel         ,
           logic [CFQ_LSU_SB_DMA_OP_BITS-1:0]   op                  ,
           logic [REG_SEL_BITS-1:0]             data_reg_sel      ,
           logic [REG_SEL_BITS-1:0]             addr_base_sel       ,
           logic [REG_SEL_BITS-1:0]             memoffset_sel        
    );
        logic res;

        res = tma_dma_sel == TMA_DMA_SEL_DMA && op == OP_ST && !(data_reg_sel == REG_SEL_TMP || data_reg_sel == REG_SEL_A)
                             && !(addr_base_sel != REG_SEL_CR && addr_base_sel != REG_SEL_TMP && addr_base_sel != REG_SEL_A && memoffset_sel == REG_SEL_NONE);

        return res;
    endfunction
    //---------------------------------------------------------------------------------
    // Function: Determine whether a instruction is need to be cut to 1 inst for US
    //---------------------------------------------------------------------------------
    function automatic logic f_is_cut_instr (
           logic                                tma_dma_sel         ,
           logic [CFQ_LSU_SB_DMA_OP_BITS-1:0]   op                  ,
           logic [REG_SEL_BITS-1:0]             data_reg_sel      ,
           logic [REG_SEL_BITS-1:0]             addr_base_sel       ,
           logic [REG_SEL_BITS-1:0]             memoffset_sel        
    );
        logic res;
        res = tma_dma_sel == TMA_DMA_SEL_DMA && (op == OP_ST) && (data_reg_sel == REG_SEL_A || data_reg_sel == REG_SEL_TMP) && 
              (
                (addr_base_sel == REG_SEL_NONE || addr_base_sel == REG_SEL_SLR || addr_base_sel == REG_SEL_SHS) &&
                (memoffset_sel == REG_SEL_NONE)
              );
        return res;
    endfunction

    //---------------------------------------------------------------------------------
    // Function: Determine whether a Operand is instance-based
    //---------------------------------------------------------------------------------
    function automatic logic [LSU_OP_BUFFER_OPS_NUM-1:0] f_is_inst_base_op(logic is_inst_base_instruction);
        logic [LSU_OP_BUFFER_OPS_NUM-1:0] res;

        res = '0;

        if(!is_inst_base_instruction) begin
            res = '0;
        end else begin
            res[0]   = 0; // blx
            res[1]   = 0; // bly
            res[2]   = 0; // stride
            res[3]   = 0; // index
            res[4]   = 0; // robust
            res[5]   = 1; // addr_base_lo
            res[6]   = 1; // addr_base_hi
            res[7]   = 1; // memoffset
        end
        return res;
    endfunction

    //---------------------------------------------------------------------------------
    // Function: Determine whether no Operand of the instruction needs to be fetched.
    //---------------------------------------------------------------------------------
    function automatic logic f_is_no_op_fetch_instr(logic is_dma_instruction, cfq_lsu_dma_instr_sb_t dma_instr_sb);
        logic res;

        res = 1'b0;

        if(is_dma_instruction) begin
            // CFI and IDF
            if(dma_instr_sb.op == OP_CFI_INVAL || dma_instr_sb.op == OP_CFI_FLUSH || dma_instr_sb.op == OP_CFI_FLUSHINV || dma_instr_sb.op == OP_IDF) begin
                res = 1'b1;
            // load, store with no operand needs to be fetched
            end else if(dma_instr_sb.op == OP_LD || dma_instr_sb.op == OP_ST) begin
                if(
                   (dma_instr_sb.addr_base_select == REG_SEL_CR                                               ) &&
                   (dma_instr_sb.memoffset_select == REG_SEL_NONE                                             ) &&
                   (dma_instr_sb.blx_select       == REG_SEL_IMM                                              ) &&
                   (dma_instr_sb.bly_select       == REG_SEL_IMM                                              ) &&
                   (dma_instr_sb.stride_select    == REG_SEL_IMM || dma_instr_sb.stride_select == REG_SEL_NONE) &&
                   (dma_instr_sb.index_select     == REG_SEL_NONE                                             ) &&
                   (dma_instr_sb.robust_select    == REG_SEL_NONE                                             )   
                ) begin
                    res = 1'b1;
                end
            end
        end
        return res;
    endfunction

    //---------------------------------------------------------------------------------
    // Function: Hack the input instruction sideband for some operation(e.g CFI and IDF)
    //---------------------------------------------------------------------------------
    function automatic logic [CFQ_LSU_SIDEBAND_DATA_BITS-1:0] f_instr_sb_hack(logic is_dma_instruction, logic [CFQ_LSU_SIDEBAND_DATA_BITS-1:0] instr_sb_vec);
        logic [CFQ_LSU_SIDEBAND_DATA_BITS-1:0]      res;
        cfq_lsu_dma_instr_sb_t                      instr_dma_sb_struct;
        // DMA instruction
        if(is_dma_instruction) begin
            instr_dma_sb_struct = instr_sb_vec;
            // For IDF and CFI, data_reg_sel and dst_reg_sel to NONE
            // For Load type instruction,  the data_reg_sel is hacked to NONE
            // For Store type instruction, the dst_reg_sel is hacked to NONE
            if(instr_dma_sb_struct.op == OP_CFI_INVAL || instr_dma_sb_struct.op == OP_CFI_FLUSH || instr_dma_sb_struct.op == OP_CFI_FLUSHINV || instr_dma_sb_struct.op == OP_IDF) begin
                instr_dma_sb_struct.data_reg_select     = REG_SEL_NONE;
                instr_dma_sb_struct.dst_select          = REG_SEL_NONE;
            end else if(instr_dma_sb_struct.op == OP_LD || instr_dma_sb_struct.op == OP_TEXELLD || instr_dma_sb_struct.op == OP_LD_PAIR) begin
                instr_dma_sb_struct.data_reg_select     = REG_SEL_NONE;
            end else if(instr_dma_sb_struct.op == OP_ST || instr_dma_sb_struct.op == OP_TEXELST || instr_dma_sb_struct.op == OP_ST_PAIR) begin
                instr_dma_sb_struct.dst_select          = REG_SEL_NONE;
            end

            // For IDF and CFI, hack all the operand selector to NONE
            // For Texel-st/Texel-ld, bl_x_sel and stride_sel are hacked to NONE
            if(instr_dma_sb_struct.op == OP_CFI_INVAL || instr_dma_sb_struct.op == OP_CFI_FLUSH || instr_dma_sb_struct.op == OP_CFI_FLUSHINV || instr_dma_sb_struct.op == OP_IDF) begin
                instr_dma_sb_struct.robust_select       = REG_SEL_NONE;
                instr_dma_sb_struct.stride_select       = REG_SEL_NONE;
                instr_dma_sb_struct.blx_select          = REG_SEL_NONE;
                instr_dma_sb_struct.bly_select          = REG_SEL_NONE;
                instr_dma_sb_struct.memoffset_select    = REG_SEL_NONE;
                instr_dma_sb_struct.addr_base_select    = REG_SEL_NONE;
                instr_dma_sb_struct.index_select        = REG_SEL_NONE;
            end else if(instr_dma_sb_struct.op == OP_TEXELLD || instr_dma_sb_struct.op == OP_TEXELST) begin
                instr_dma_sb_struct.blx_select          = REG_SEL_NONE;
                instr_dma_sb_struct.stride_select       = REG_SEL_NONE;
            end
            res = instr_dma_sb_struct;
        // TMA instruction
        end else begin
            res = instr_sb_vec;
        end
        return res;
    endfunction





//---------------------------------------------------------------------------------
// Used for debug
//---------------------------------------------------------------------------------
// synopsys translate_off
typedef enum logic [4-1:0] {
    INSTR_DMA_LD          = 0      , 
    INSTR_DMA_ST          = 1      , 
    INSTR_DMA_TEXEL_LD    = 2      , 
    INSTR_DMA_TEXEL_ST    = 3      , 
    INSTR_DMA_ATOMIC_32   = 4      , 
    INSTR_DMA_ATOMIC_F32  = 5      , 
    INSTR_DMA_ATOMIC_64   = 6      , 
    INSTR_DMA_IDF         = 7      , 
    INSTR_DMA_CFI         = 8      , 
    INSTR_TMA             = 9      ,
    INSTR_NONE            = 10       
} e_instr_type;

typedef enum logic [4-1:0] {
    ST_SEL_A     = REG_SEL_A       , 
    ST_SEL_TMP   = REG_SEL_TMP     , 
    ST_SEL_SRS   = REG_SEL_SLR     ,
    ST_SEL_SHS   = REG_SEL_SHS     ,
    ST_SEL_LMS   = REG_SEL_LMS     ,
    ST_SEL_CR    = REG_SEL_CR      ,
    ST_SEL_IMM   = REG_SEL_IMM     ,
    ST_SEL_NONE  = REG_SEL_NONE
} e_st_sel;

typedef struct {
        e_st_sel   bl_x_sel         ;
        e_st_sel   bl_y_sel         ;
        e_st_sel   stride_sel       ;
        e_st_sel   index_sel        ;
        e_st_sel   addr_base_sel    ;
        e_st_sel   memoffset_sel    ;
        e_st_sel   robust_sel       ;
} t_debug_dma_op_st_sel;

typedef struct {
        e_st_sel   tid_sel         ;
        e_st_sel   mcm_sel         ;
        e_st_sel   stride_sel      ;
        e_st_sel   addr_base_sel   ;
        e_st_sel   memoffset_sel   ;
        e_st_sel   robust_sel      ;
} t_debug_tma_op_st_sel;

typedef struct packed {
        logic [LSU_OP_DMA_BLX_BITS+1-1:0]                                       bl_x            ;
        logic [LSU_OP_DMA_BLY_BITS+1-1:0]                                       bl_y            ;
        logic [LSU_OP_DMA_STRIDE_BITS+1-1:0]                                    stride          ;
        logic signed [LSU_OP_INDEX_BITS+1-1:0]                                  index           ;
        logic [2-1:0] [INSTANCES_PER_DB-1:0] [LSU_OP_ADDR_BASE_BITS-1:0]        addr_base;
        logic signed [2-1:0] [INSTANCES_PER_DB-1:0] [LSU_OP_MEMOFFSET_BITS-1:0] memoffset       ;
        logic [LSU_OP_ROBUST_BASE_BITS-1:0]                                     robust_base     ;
        logic [LSU_OP_ROBUST_SIZE_BITS-1:0]                                     robust_size     ;
} t_debug_dma_op_value;

typedef struct packed {
        logic [LSU_OP_TMA_TID_BITS-1:0]                                         tid             ;
        logic [LSU_OP_TMA_MCM_BITS-1:0]                                         mcm             ;
        logic [LSU_OP_STRIDE_BITS-1:0]                                          stride          ;
        logic [LSU_OP_ADDR_BASE_BITS-1:0]                                       addr_base       ;
        logic signed  [LSU_OP_MEMOFFSET_BITS-1:0]                               memoffset       ;
        logic [LSU_OP_ROBUST_BASE_BITS-1:0]                                     robust_base     ;
        logic [LSU_OP_ROBUST_SIZE_BITS-1:0]                                     robust_size     ;
} t_debug_tma_op_value;

function automatic e_instr_type f_get_debug_instr_type(
    logic                                   valid, 
    logic                                   is_dma_instruction, 
    logic [CFQ_LSU_SB_DMA_OP_BITS-1:0]      op  
);
    e_instr_type  res;

    if(valid) begin
        if(is_dma_instruction) begin
            case(op)
                OP_LD            : res = INSTR_DMA_LD;
                OP_ST            : res = INSTR_DMA_ST;
                OP_TEXELLD       : res = INSTR_DMA_TEXEL_LD;
                OP_TEXELST       : res = INSTR_DMA_TEXEL_ST;
                OP_ATOMIC_32     : res = INSTR_DMA_ATOMIC_32;
                OP_ATOMIC_64     : res = INSTR_DMA_ATOMIC_64;
                OP_ATOMIC_F32    : res = INSTR_DMA_ATOMIC_F32;
                OP_CFI_INVAL     : res = INSTR_DMA_CFI;
                OP_CFI_FLUSH     : res = INSTR_DMA_CFI;
                OP_CFI_FLUSHINV  : res = INSTR_DMA_CFI;
                OP_IDF           : res = INSTR_DMA_IDF;
                default          : res = INSTR_NONE;
            endcase
        end else begin
            res = INSTR_TMA;
        end
    end else begin
        res = INSTR_NONE;
    end

    return res;
endfunction


function automatic t_debug_dma_op_st_sel f_get_debug_dma_op_st_sel(cfq_lsu_dma_instr_sb_t dma_sb);
    t_debug_dma_op_st_sel  res;

    res.bl_x_sel            = e_st_sel'(dma_sb.blx_select);
    res.bl_y_sel            = e_st_sel'(dma_sb.bly_select);
    res.stride_sel          = e_st_sel'(dma_sb.stride_select);
    res.index_sel           = e_st_sel'(dma_sb.index_select);
    res.addr_base_sel       = e_st_sel'(dma_sb.addr_base_select);
    res.memoffset_sel       = e_st_sel'(dma_sb.memoffset_select);
    res.robust_sel          = e_st_sel'(dma_sb.robust_select);

    return res;
endfunction

function automatic t_debug_tma_op_st_sel f_get_debug_tma_op_st_sel(cfq_lsu_tma_instr_sb_t tma_sb);
    t_debug_tma_op_st_sel  res;

    res.tid_sel             = e_st_sel'(tma_sb.tid_select);
    res.mcm_sel             = e_st_sel'(tma_sb.mcm_select);
    res.stride_sel          = e_st_sel'(tma_sb.stride_select);
    res.addr_base_sel       = e_st_sel'(tma_sb.addr_base_select);
    res.memoffset_sel       = e_st_sel'(tma_sb.memoffset_select);
    res.robust_sel          = e_st_sel'(tma_sb.robust_select);

    return res;
endfunction

function automatic t_debug_dma_op_value f_get_debug_dma_op_value(
        logic [LSU_OP_DMA_BLX_BITS+1-1:0]                                       out_mux_bl_x            ,
        logic [LSU_OP_DMA_BLY_BITS+1-1:0]                                       out_mux_bl_y            ,
        logic [LSU_OP_DMA_STRIDE_BITS+1-1:0]                                    out_mux_stride          ,
        logic [LSU_OP_INDEX_BITS-1:0]                                           out_mux_index           ,
        logic [2-1:0] [INSTANCES_PER_DB-1:0][LSU_OP_ADDR_BASE_BITS-1:0]         out_mux_addr_base       ,
        logic [2-1:0] [INSTANCES_PER_DB-1:0][LSU_OP_MEMOFFSET_BITS-1:0]         out_mux_memoffset       ,
        logic [LSU_OP_ROBUST_BASE_BITS-1:0]                                     out_mux_robust_base     ,
        logic [LSU_OP_ROBUST_SIZE_BITS-1:0]                                     out_mux_robust_size      
);
    t_debug_dma_op_value  res;

    res.bl_x            = out_mux_bl_x;
    res.bl_y            = out_mux_bl_y;
    res.stride          = out_mux_stride;
    res.index           = $signed(out_mux_index);
    res.addr_base       = out_mux_addr_base;
    res.memoffset       = $signed(out_mux_memoffset);
    res.robust_base     = out_mux_robust_base;
    res.robust_size     = out_mux_robust_size;

    for(int db = 0; db < 2; db++) begin
        for(int inst = 0; inst < INSTANCES_PER_DB; inst++) begin
            res.addr_base[db][inst] =  out_mux_addr_base[db][inst];
            res.memoffset[db][inst] =  $signed(out_mux_memoffset[db][inst]);
        end
    end

    return res;
endfunction


function automatic t_debug_tma_op_value f_get_debug_tma_op_value(
        logic [LSU_OP_TMA_TID_BITS-1:0]                                         tid             ,
        logic [LSU_OP_TMA_MCM_BITS-1:0]                                         mcm             ,
        logic [LSU_OP_STRIDE_BITS-1:0]                                          stride          ,
        logic [LSU_OP_ADDR_BASE_BITS-1:0]                                       addr_base       ,
        logic [LSU_OP_MEMOFFSET_BITS-1:0]                                       memoffset       ,
        logic [LSU_OP_ROBUST_BASE_BITS-1:0]                                     robust_base     ,
        logic [LSU_OP_ROBUST_SIZE_BITS-1:0]                                     robust_size      
);
    t_debug_tma_op_value  res;

    res.tid             = tid;
    res.mcm             = mcm;
    res.stride          = stride;
    res.addr_base       = addr_base;
    res.memoffset       = $signed(memoffset);
    res.robust_base     = robust_base;
    res.robust_size     = robust_size;

    return res;
endfunction


// synopsys translate_on

endpackage
