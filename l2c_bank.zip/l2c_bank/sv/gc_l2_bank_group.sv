// ---------------------------------------------------------------------------------
// Project Name  : IC_Design
// Author        : liusm
// Email         : liusm@innosilicon.com.cn
// Create On     : 2025/01/20 16:33
// Last Modified : 2025/09/03 18:34
// File Name     : gc_l2_bank_group.sv
// Description   :
// 
// Copyright (c) 2025 Innosilicon.
// ALL RIGHTS RESERVED
// 
// ---------------------------------------------------------------------------------
// Modification History:
// Date         By              Version                 Change Description
// ---------------------------------------------------------------------------------
// 2025/01/20   liusm           1.0                     Original
// 
// ----------------------------------------------------------------------------------


module gc_l2_bank_group
import axi5_ar_pkg::*;
import axi5_aw_pkg::*;
import axi5_b_pkg::*;
import axi5_r_pkg::*;
import axi5_w_pkg::*;
import nsp_req_pkg::*;
import nsp_rsp_pkg::*;
import socif_regbank_w_pkg::*;
import socif_regbank_r_pkg::*;
import group_nsp_req_pkg::*;
import group_nsp_rsp_pkg::*;
(
      input    logic                                  clk
,     input    logic                                  resetn


,     input    logic                    [ 2:0 ]       l2g_number_id
,     output   logic                    [63:0]        l2g_perf_event

,     input    logic                                  socif_wakeup

,     input    logic                                  socif_valid
,     input    socif_regbank_w_data_bus_t             socif_rec

,     output   logic                                  socif_rvalid
,     output   socif_regbank_r_data_bus_t             socif_rdata


,     input    logic                    [ 9:0 ]       axi5_arvalid
,     output   logic                    [ 9:0 ]       axi5_arready
,     input    axi5_ar_data_bus_t       [ 9:0 ]       axi5_arrec

,     input    logic                    [ 9:0 ]       axi5_awvalid
,     output   logic                    [ 9:0 ]       axi5_awready
,     input    axi5_aw_data_bus_t       [ 9:0 ]       axi5_awrec

,     output   logic                    [ 9:0 ]       axi5_rvalid
,     input    logic                    [ 9:0 ]       axi5_rready
,     output   axi5_r_data_bus_t        [ 9:0 ]       axi5_rrec

,     input    logic                    [ 9:0 ]       axi5_wvalid
,     output   logic                    [ 9:0 ]       axi5_wready
,     input    axi5_w_data_bus_t        [ 9:0 ]       axi5_wrec

,     output   logic                    [ 9:0 ]       axi5_bvalid
,     input    logic                    [ 9:0 ]       axi5_bready
,     output   axi5_b_data_bus_t        [ 9:0 ]       axi5_brec




,     output   logic                    [ 9:0 ]       nsp_req_valid
,     input    logic                    [ 9:0 ]       nsp_req_ready
,     output   group_nsp_req_data_bus_t [ 9:0 ]       nsp_req_rec


,     input    logic                    [ 9:0 ]       nsp_rsp_valid
,     output   logic                    [ 9:0 ]       nsp_rsp_ready
,     input    group_nsp_rsp_data_bus_t [ 9:0 ]       nsp_rsp_rec

,     input    logic                                  tst_gclkenable
,     input    logic                                  tst_rst_bypass

);

logic [2:0]             regbank_instance                                         ;

logic [9:0]             gc_cr_l2g_idle_l2g                                       ;
logic                   gc_cr_cu_lms_fp32_denormal_en                           ;
logic [7:0][1:0]        gc_cr_clk_ctrl3_l2g                                      ;
logic [4:0]             gc_cr_clk_status_l2g                                     ;
logic                   gc_cr_soft_reset_l2g                                     ;
logic [1:0]             gc_cr_l2_cfi_operation                                   ;

logic [1:0]             gc_cr_l2_buffer_mode_buffer_mode_percentage              ;
logic                   gc_cr_l2_persistence_reduce_persistence_reduce_enable    ;
logic [20:0]            gc_cr_l2_persistence_reduce_persistence_reduce_threshold ;
logic                   gc_cr_l2_cmd_persistence_rst_all                         ;
logic                   gc_cr_l2_cmd_cfi_clr                                     ;
logic [9:0]             gc_cr_l2_cfi_status_l                                    ;
logic [9:0][2:0]        gc_cr_l2g_error_l2b                                      ;

logic [ 4 : 0 ]            gc_cr_l2_mem_sched_row_parti_row_id_bit0              ;
logic [ 4 : 0 ]            gc_cr_l2_mem_sched_row_parti_row_id_bit1              ;
logic [ 4 : 0 ]            gc_cr_l2_mem_sched_row_parti_row_id_bit2              ;
logic [ 4 : 0 ]            gc_cr_l2_mem_sched_row_parti_row_id_bit3              ;
logic [ 4 : 0 ]            gc_cr_l2_mem_sched_row_parti_row_id_bit4              ;
logic [ 4 : 0 ]            gc_cr_l2_mem_sched_row_parti_row_id_bit5              ;
logic [ 4 : 0 ]            gc_cr_l2_mem_sched_row_parti_row_id_bit6              ;
logic [ 4 : 0 ]            gc_cr_l2_mem_sched_row_parti_row_id_bit7              ;
logic [ 4 : 0 ]            gc_cr_l2_mem_sched_row_partii_row_id_bit8             ;
logic [ 4 : 0 ]            gc_cr_l2_mem_sched_row_partii_row_id_bit9             ;
logic [ 4 : 0 ]            gc_cr_l2_mem_sched_row_partii_row_id_bit10            ;
logic [ 4 : 0 ]            gc_cr_l2_mem_sched_row_partii_row_id_bit11            ;
logic [ 4 : 0 ]            gc_cr_l2_mem_sched_row_partii_row_id_bit12            ;
logic [ 4 : 0 ]            gc_cr_l2_mem_sched_row_partii_row_id_bit13            ;
logic [ 4 : 0 ]            gc_cr_l2_mem_sched_row_partii_row_id_bit14            ;
logic [ 4 : 0 ]            gc_cr_l2_mem_sched_row_partii_row_id_bit15            ;
logic [ 4 : 0 ]            gc_cr_l2_mem_sched_row_partiii_row_id_bit16           ;
logic [ 4 : 0 ]            gc_cr_l2_mem_sched_row_partiii_row_id_bit17           ;
logic [ 4 : 0 ]            gc_cr_l2_mem_sched_bank_offset_bank_id_bit0           ;
logic [ 4 : 0 ]            gc_cr_l2_mem_sched_bank_offset_bank_id_bit1           ;
logic [ 4 : 0 ]            gc_cr_l2_mem_sched_bank_offset_bank_id_bit2           ;
logic [ 4 : 0 ]            gc_cr_l2_mem_sched_bank_offset_bank_id_bit3           ;
logic [ 4 : 0 ]            gc_cr_l2_mem_sched_bank_offset_bank_id_bit4           ;
logic [ 4 : 0 ]            gc_cr_l2_mem_sched_col_offset_column_id_bit0          ;
logic [ 4 : 0 ]            gc_cr_l2_mem_sched_col_offset_column_id_bit1          ;
logic [ 4 : 0 ]            gc_cr_l2_mem_sched_col_offset_column_id_bit2          ;
logic [ 4 : 0 ]            gc_cr_l2_mem_sched_col_offset_column_id_bit3          ;
logic [ 4 : 0 ]            gc_cr_l2_mem_sched_col_offset_column_id_bit4          ;
logic [ 4 : 0 ]            gc_cr_l2_mem_sched_col_offset_column_id_bit5          ;
logic [ 4 : 0 ]            gc_cr_l2_mem_sched_col_offset_column_id_bit6          ;
logic [ 4 : 0 ]            gc_cr_l2_mem_sched_col_offset_column_id_bit7          ;
logic                      gc_cr_l2_function_enable_mem_scheduler                ;
logic                      gc_cr_l2_function_enable_bypass_mode                  ;
logic [ 3 : 0 ]            gc_cr_l2_function_enable_ddr_capacity                 ;
logic [ 4 : 0 ]            gc_cr_pwr_man_hysteresis_value                        ;
logic [ 1 : 0 ]            gc_cr_crm_reset_clk_ctrl                              ;
logic                      gc_cr_l2_cfi_operation_notify                         ;
logic                      gc_cr_l2_cfi_operation_rdnotify                       ;
logic                      gc_cr_l2_cmd_notify                                   ;
logic                      gc_cr_l2_cmd_rdnotify                                 ;
logic                      gc_cr_perf_mon1_enable                                ;
logic [4:0]                gc_cr_perf_mon4_l2g_group_id                          ;


logic                      o_gc_cr_l2_cfi_operation_notify                       ;
logic                      o_gc_cr_l2_cmd_notify                                 ;
logic [9:0] [63:0]         bank_perf_event                                       ;
logic [4:0]                bank_perf_sel                                         ;
logic                      crg_aligned_clk                                       ;
logic                      crg_aligned_resetn                                    ;
logic                      crg_unaligned_clk                                     ;
logic                      crg_unaligned_resetn                                  ;

logic [ 3 : 0 ]            gc_cr_ddr_hash_config_reg0_row_id_bit0                ;
logic [ 3 : 0 ]            gc_cr_ddr_hash_config_reg0_row_id_bit1                ;
logic [ 3 : 0 ]            gc_cr_ddr_hash_config_reg0_row_id_bit2                ;
logic [ 3 : 0 ]            gc_cr_ddr_hash_config_reg0_row_id_bit3                ;
logic [ 3 : 0 ]            gc_cr_ddr_hash_config_reg0_row_id_bit4                ;
logic [ 3 : 0 ]            gc_cr_ddr_hash_config_reg0_row_id_bit5                ;
logic [ 3 : 0 ]            gc_cr_ddr_hash_config_reg0_row_id_bit6                ;
logic [ 3 : 0 ]            gc_cr_ddr_hash_config_reg0_row_id_bit7                ;
logic [ 3 : 0 ]            gc_cr_ddr_hash_config_reg0_row_id_bit8                ;
logic [ 3 : 0 ]            gc_cr_ddr_hash_config_reg0_row_id_bit9                ;
logic [ 3 : 0 ]            gc_cr_ddr_hash_config_reg0_row_id_bit10               ;
logic [ 3 : 0 ]            gc_cr_ddr_hash_config_reg0_row_id_bit11               ;
logic [ 3 : 0 ]            gc_cr_ddr_hash_config_reg1_row_id_bit12               ;
logic [ 3 : 0 ]            gc_cr_ddr_hash_config_reg1_row_id_bit13               ;
logic [ 3 : 0 ]            gc_cr_ddr_hash_config_reg1_row_id_bit14               ;
logic [ 3 : 0 ]            gc_cr_ddr_hash_config_reg1_row_id_bit15               ;
logic [ 3 : 0 ]            gc_cr_ddr_hash_config_reg1_row_id_bit16               ;
logic [ 3 : 0 ]            gc_cr_ddr_hash_config_reg1_row_id_bit17               ;
logic [ 3 : 0 ]            gc_cr_ddr_hash_config_reg1_row_id_bit18               ;
logic [ 3 : 0 ]            gc_cr_ddr_hash_config_reg1_row_id_bit19               ;
logic [ 3 : 0 ]            gc_cr_ddr_hash_config_reg1_row_id_bit20               ;
logic [ 3 : 0 ]            gc_cr_ddr_hash_config_reg1_row_id_bit21               ;
logic [ 3 : 0 ]            gc_cr_ddr_hash_config_reg1_row_id_bit22               ;
logic [ 3 : 0 ]            gc_cr_ddr_hash_config_reg1_row_id_bit23               ;
logic [ 1 : 0 ]            gc_cr_l2_function_enable_hash_mode                    ;

logic [7:0]                gc_cr_clk_status3_l2g;
logic [79:0]               gc_cr_l2_idle;


assign bank_perf_sel = gc_cr_perf_mon4_l2g_group_id;
assign gc_cr_soft_reset_l2g = 1'b0;

assign crg_aligned_clk      = clk;
assign crg_aligned_resetn   = resetn;
assign crg_unaligned_clk    = clk;
assign crg_unaligned_resetn = resetn;

// gc_crg_core_no_delay i_l2_crg_core_no_delay (
//     .core_clk           (clk                        ),  // I
//     .core_resetn        (resetn                     ),  // I
//     .soft_reset_core    (1'b0                       ),  // I software cannt reset L2 bank because L2 bank can be accessed by PCIE or another die.
//     .tst_rst_bypass     (tst_rst_bypass             ),  // I
//     .aligned_clk        (crg_aligned_clk            ),  // O
//     .aligned_resetn     (crg_aligned_resetn         ),  // O
//     .unaligned_clk      (crg_unaligned_clk          ),  // O
//     .unaligned_resetn   (crg_unaligned_resetn       )   // O
//  );
generate 
   for (genvar bank_wrap_idx = 0; bank_wrap_idx < 5; bank_wrap_idx ++) begin: g_bank_wrap_instance
      `ifdef SIM_NO_SOC_L2G_BANK
      gc_l2_bank_wrap_empty
      `else
      gc_l2_bank_wrap
      `endif
      #(.BANK_WRAP(bank_wrap_idx))
      i_gc_l2_bank_wrap
      (
              .clk                                                      ( crg_unaligned_clk                                        ) ,
              .resetn                                                   ( crg_unaligned_resetn                                     ) ,
              .tst_gclkenable                                           ( tst_gclkenable                                           ) ,
              .tst_rst_bypass                                           ( tst_rst_bypass                                           ) ,
              .socif_wakeup                                             ( socif_wakeup                                             ) ,
          
              .axi_slv_0_arvalid                                        ( axi5_arvalid     [2*bank_wrap_idx]                       ) ,
              .axi_slv_0_arready                                        ( axi5_arready     [2*bank_wrap_idx]                       ) ,
              .axi_slv_0_ar_rec                                         ( axi5_arrec       [2*bank_wrap_idx]                       ) ,
              .axi_slv_0_rvalid                                         ( axi5_rvalid      [2*bank_wrap_idx]                       ) ,
              .axi_slv_0_rready                                         ( axi5_rready      [2*bank_wrap_idx]                       ) ,
              .axi_slv_0_r_rec                                          ( axi5_rrec        [2*bank_wrap_idx]                       ) ,
              .axi_slv_0_awvalid                                        ( axi5_awvalid     [2*bank_wrap_idx]                       ) ,
              .axi_slv_0_awready                                        ( axi5_awready     [2*bank_wrap_idx]                       ) ,
              .axi_slv_0_aw_rec                                         ( axi5_awrec       [2*bank_wrap_idx]                       ) ,
              .axi_slv_0_wvalid                                         ( axi5_wvalid      [2*bank_wrap_idx]                       ) ,
              .axi_slv_0_wready                                         ( axi5_wready      [2*bank_wrap_idx]                       ) ,
              .axi_slv_0_w_rec                                          ( axi5_wrec        [2*bank_wrap_idx]                       ) ,
              .axi_slv_0_bvalid                                         ( axi5_bvalid      [2*bank_wrap_idx]                       ) ,
              .axi_slv_0_bready                                         ( axi5_bready      [2*bank_wrap_idx]                       ) ,
              .axi_slv_0_b_rec                                          ( axi5_brec        [2*bank_wrap_idx]                       ) ,
      
              .axi_slv_1_arvalid                                        ( axi5_arvalid     [2*bank_wrap_idx+1]                     ) ,
              .axi_slv_1_arready                                        ( axi5_arready     [2*bank_wrap_idx+1]                     ) ,
              .axi_slv_1_ar_rec                                         ( axi5_arrec       [2*bank_wrap_idx+1]                     ) ,
              .axi_slv_1_rvalid                                         ( axi5_rvalid      [2*bank_wrap_idx+1]                     ) ,
              .axi_slv_1_rready                                         ( axi5_rready      [2*bank_wrap_idx+1]                     ) ,
              .axi_slv_1_r_rec                                          ( axi5_rrec        [2*bank_wrap_idx+1]                     ) ,
              .axi_slv_1_awvalid                                        ( axi5_awvalid     [2*bank_wrap_idx+1]                     ) ,
              .axi_slv_1_awready                                        ( axi5_awready     [2*bank_wrap_idx+1]                     ) ,
              .axi_slv_1_aw_rec                                         ( axi5_awrec       [2*bank_wrap_idx+1]                     ) ,
              .axi_slv_1_wvalid                                         ( axi5_wvalid      [2*bank_wrap_idx+1]                     ) ,
              .axi_slv_1_wready                                         ( axi5_wready      [2*bank_wrap_idx+1]                     ) ,
              .axi_slv_1_w_rec                                          ( axi5_wrec        [2*bank_wrap_idx+1]                     ) ,
              .axi_slv_1_bvalid                                         ( axi5_bvalid      [2*bank_wrap_idx+1]                     ) ,
              .axi_slv_1_bready                                         ( axi5_bready      [2*bank_wrap_idx+1]                     ) ,
              .axi_slv_1_b_rec                                          ( axi5_brec        [2*bank_wrap_idx+1]                     ) ,
          
              .l2_nsp0_req_valid                                        ( nsp_req_valid    [2*bank_wrap_idx]                       ) ,
              .l2_nsp0_req_ready                                        ( nsp_req_ready    [2*bank_wrap_idx]                       ) ,
              .l2_nsp0_req_rec                                          ( nsp_req_rec      [2*bank_wrap_idx]                       ) ,
                     
              .l2_nsp0_rsp_valid                                        ( nsp_rsp_valid    [2*bank_wrap_idx]                       ) ,
              .l2_nsp0_rsp_ready                                        ( nsp_rsp_ready    [2*bank_wrap_idx]                       ) ,
              .l2_nsp0_rsp_rec                                          ( nsp_rsp_rec      [2*bank_wrap_idx]                       ) ,

              .l2_nsp1_req_valid                                        ( nsp_req_valid    [2*bank_wrap_idx+1]                     ) ,
              .l2_nsp1_req_ready                                        ( nsp_req_ready    [2*bank_wrap_idx+1]                     ) ,
              .l2_nsp1_req_rec                                          ( nsp_req_rec      [2*bank_wrap_idx+1]                     ) ,
                                                                                                           
              .l2_nsp1_rsp_valid                                        ( nsp_rsp_valid    [2*bank_wrap_idx+1]                     ) ,
              .l2_nsp1_rsp_ready                                        ( nsp_rsp_ready    [2*bank_wrap_idx+1]                     ) ,
              .l2_nsp1_rsp_rec                                          ( nsp_rsp_rec      [2*bank_wrap_idx+1]                     ) ,
          
              .gc_cr_l2_mem_sched_row_partii_row_id_bit8                ( gc_cr_l2_mem_sched_row_partii_row_id_bit8                ) ,
              .gc_cr_l2_mem_sched_row_partii_row_id_bit9                ( gc_cr_l2_mem_sched_row_partii_row_id_bit9                ) ,
              .gc_cr_l2_mem_sched_row_partii_row_id_bit10               ( gc_cr_l2_mem_sched_row_partii_row_id_bit10               ) ,
              .gc_cr_l2_mem_sched_row_partii_row_id_bit11               ( gc_cr_l2_mem_sched_row_partii_row_id_bit11               ) ,
              .gc_cr_l2_mem_sched_row_partii_row_id_bit12               ( gc_cr_l2_mem_sched_row_partii_row_id_bit12               ) ,
              .gc_cr_l2_mem_sched_row_partii_row_id_bit13               ( gc_cr_l2_mem_sched_row_partii_row_id_bit13               ) ,
              .gc_cr_l2_mem_sched_row_partii_row_id_bit14               ( gc_cr_l2_mem_sched_row_partii_row_id_bit14               ) ,
              .gc_cr_l2_mem_sched_row_partii_row_id_bit15               ( gc_cr_l2_mem_sched_row_partii_row_id_bit15               ) ,
              .gc_cr_l2_mem_sched_row_partiii_row_id_bit16              ( gc_cr_l2_mem_sched_row_partiii_row_id_bit16              ) ,
              .gc_cr_l2_mem_sched_row_partiii_row_id_bit17              ( gc_cr_l2_mem_sched_row_partiii_row_id_bit17              ) ,
              .gc_cr_l2_function_enable_ddr_capacity                    ( gc_cr_l2_function_enable_ddr_capacity                    ) ,
              .gc_cr_clk_ctrl3_l2g                                      ( gc_cr_clk_ctrl3_l2g[l2g_number_id]                       ) ,
              .gc_cr_clk_status3_l2g                                    ( gc_cr_clk_status_l2g[bank_wrap_idx]                      ) ,
              .gc_cr_soft_reset_l2g                                     ( gc_cr_soft_reset_l2g                                     ) ,
              .gc_cr_l2_cfi_operation                                   ( gc_cr_l2_cfi_operation                                   ) ,
              .gc_cr_l2_cfi_statusi_l2b0_finish                         ( gc_cr_l2_cfi_status_l[2*bank_wrap_idx]                     ) ,
              .gc_cr_l2_cfi_statusi_l2b1_finish                         ( gc_cr_l2_cfi_status_l[2*bank_wrap_idx+1]                   ) ,
              .gc_cr_l2_buffer_mode_buffer_mode_percentage              ( gc_cr_l2_buffer_mode_buffer_mode_percentage              ) ,
              .gc_cr_l2_persistence_reduce_persistence_reduce_enable    ( gc_cr_l2_persistence_reduce_persistence_reduce_enable    ) ,
              .gc_cr_l2_persistence_reduce_persistence_reduce_threshold ( gc_cr_l2_persistence_reduce_persistence_reduce_threshold ) ,
              .gc_cr_l2_cmd_persistence_rst_all                         ( gc_cr_l2_cmd_persistence_rst_all                         ) ,
              .gc_cr_l2_cmd_cfi_clr                                     ( gc_cr_l2_cmd_cfi_clr                                     ) ,
              .gc_cr_l2g_idle_l2g                                       ( gc_cr_l2g_idle_l2g[2*bank_wrap_idx+:2]                        ) ,
              .gc_cr_l2g_error0_l2b0                                    ( gc_cr_l2g_error_l2b[2*bank_wrap_idx+0]                      ) ,
              .gc_cr_l2g_error0_l2b1                                    ( gc_cr_l2g_error_l2b[2*bank_wrap_idx+1]                      ) ,
              .gc_cr_l2_function_enable_mem_scheduler                   ( gc_cr_l2_function_enable_mem_scheduler                   ) ,
              .gc_cr_l2_function_enable_bypass_mode                     ( gc_cr_l2_function_enable_bypass_mode                     ) ,
              .gc_cr_l2_mem_sched_col_offset_column_id_bit0             ( gc_cr_l2_mem_sched_col_offset_column_id_bit0             ) ,
              .gc_cr_l2_mem_sched_col_offset_column_id_bit1             ( gc_cr_l2_mem_sched_col_offset_column_id_bit1             ) ,
              .gc_cr_l2_mem_sched_col_offset_column_id_bit2             ( gc_cr_l2_mem_sched_col_offset_column_id_bit2             ) ,
              .gc_cr_l2_mem_sched_col_offset_column_id_bit3             ( gc_cr_l2_mem_sched_col_offset_column_id_bit3             ) ,
              .gc_cr_l2_mem_sched_col_offset_column_id_bit4             ( gc_cr_l2_mem_sched_col_offset_column_id_bit4             ) ,
              .gc_cr_l2_mem_sched_col_offset_column_id_bit5             ( gc_cr_l2_mem_sched_col_offset_column_id_bit5             ) ,
              .gc_cr_l2_mem_sched_bank_offset_bank_id_bit0              ( gc_cr_l2_mem_sched_bank_offset_bank_id_bit0              ) ,
              .gc_cr_l2_mem_sched_bank_offset_bank_id_bit1              ( gc_cr_l2_mem_sched_bank_offset_bank_id_bit1              ) ,
              .gc_cr_l2_mem_sched_bank_offset_bank_id_bit2              ( gc_cr_l2_mem_sched_bank_offset_bank_id_bit2              ) ,
              .gc_cr_l2_mem_sched_bank_offset_bank_id_bit3              ( gc_cr_l2_mem_sched_bank_offset_bank_id_bit3              ) ,
              .gc_cr_l2_mem_sched_bank_offset_bank_id_bit4              ( gc_cr_l2_mem_sched_bank_offset_bank_id_bit4              ) ,
              .gc_cr_l2_mem_sched_row_parti_row_id_bit0                 ( gc_cr_l2_mem_sched_row_parti_row_id_bit0                 ) ,
              .gc_cr_l2_mem_sched_row_parti_row_id_bit1                 ( gc_cr_l2_mem_sched_row_parti_row_id_bit1                 ) ,
              .gc_cr_l2_mem_sched_row_parti_row_id_bit2                 ( gc_cr_l2_mem_sched_row_parti_row_id_bit2                 ) ,
              .gc_cr_l2_mem_sched_row_parti_row_id_bit3                 ( gc_cr_l2_mem_sched_row_parti_row_id_bit3                 ) ,
              .gc_cr_l2_mem_sched_row_parti_row_id_bit4                 ( gc_cr_l2_mem_sched_row_parti_row_id_bit4                 ) ,
              .gc_cr_l2_mem_sched_row_parti_row_id_bit5                 ( gc_cr_l2_mem_sched_row_parti_row_id_bit5                 ) ,
              .gc_cr_l2_mem_sched_row_parti_row_id_bit6                 ( gc_cr_l2_mem_sched_row_parti_row_id_bit6                 ) ,
              .gc_cr_l2_mem_sched_row_parti_row_id_bit7                 ( gc_cr_l2_mem_sched_row_parti_row_id_bit7                 ) ,
              .gc_cr_pwr_man_hysteresis_value                           ( gc_cr_pwr_man_hysteresis_value                           ) ,
              .gc_cr_crm_reset_clk_ctrl                                 ( gc_cr_crm_reset_clk_ctrl                                 ) ,
              .gc_cr_l2_cfi_operation_notify                            ( o_gc_cr_l2_cfi_operation_notify                          ) ,
              .gc_cr_l2_cfi_operation_rdnotify                          ( gc_cr_l2_cfi_operation_rdnotify                          ) ,
              .gc_cr_l2_cmd_notify                                      ( o_gc_cr_l2_cmd_notify                                    ) ,
              .gc_cr_l2_cmd_rdnotify                                    ( gc_cr_l2_cmd_rdnotify                                    ) ,
              .gc_cr_cu_lms_fp32_denormal_en                           ( gc_cr_cu_lms_fp32_denormal_en                           ) ,
              .gc_cr_ddr_hash_config_reg0_row_id_bit0                   ( gc_cr_ddr_hash_config_reg0_row_id_bit0                   ) ,
              .gc_cr_ddr_hash_config_reg0_row_id_bit1                   ( gc_cr_ddr_hash_config_reg0_row_id_bit1                   ) ,
              .gc_cr_ddr_hash_config_reg0_row_id_bit2                   ( gc_cr_ddr_hash_config_reg0_row_id_bit2                   ) ,
              .gc_cr_ddr_hash_config_reg0_row_id_bit3                   ( gc_cr_ddr_hash_config_reg0_row_id_bit3                   ) ,
              .gc_cr_ddr_hash_config_reg0_row_id_bit4                   ( gc_cr_ddr_hash_config_reg0_row_id_bit4                   ) ,
              .gc_cr_ddr_hash_config_reg0_row_id_bit5                   ( gc_cr_ddr_hash_config_reg0_row_id_bit5                   ) ,
              .gc_cr_ddr_hash_config_reg0_row_id_bit6                   ( gc_cr_ddr_hash_config_reg0_row_id_bit6                   ) ,
              .gc_cr_ddr_hash_config_reg0_row_id_bit7                   ( gc_cr_ddr_hash_config_reg0_row_id_bit7                   ) ,
              .gc_cr_ddr_hash_config_reg0_row_id_bit8                   ( gc_cr_ddr_hash_config_reg0_row_id_bit8                   ) ,
              .gc_cr_ddr_hash_config_reg0_row_id_bit9                   ( gc_cr_ddr_hash_config_reg0_row_id_bit9                   ) ,
              .gc_cr_ddr_hash_config_reg0_row_id_bit10                  ( gc_cr_ddr_hash_config_reg0_row_id_bit10                  ) ,
              .gc_cr_ddr_hash_config_reg0_row_id_bit11                  ( gc_cr_ddr_hash_config_reg0_row_id_bit11                  ) ,
              .gc_cr_ddr_hash_config_reg1_row_id_bit12                  ( gc_cr_ddr_hash_config_reg1_row_id_bit12                  ) ,
              .gc_cr_ddr_hash_config_reg1_row_id_bit13                  ( gc_cr_ddr_hash_config_reg1_row_id_bit13                  ) ,
              .gc_cr_ddr_hash_config_reg1_row_id_bit14                  ( gc_cr_ddr_hash_config_reg1_row_id_bit14                  ) ,
              .gc_cr_ddr_hash_config_reg1_row_id_bit15                  ( gc_cr_ddr_hash_config_reg1_row_id_bit15                  ) ,
              .gc_cr_ddr_hash_config_reg1_row_id_bit16                  ( gc_cr_ddr_hash_config_reg1_row_id_bit16                  ) ,
              .gc_cr_ddr_hash_config_reg1_row_id_bit17                  ( gc_cr_ddr_hash_config_reg1_row_id_bit17                  ) ,
              .gc_cr_ddr_hash_config_reg1_row_id_bit18                  ( gc_cr_ddr_hash_config_reg1_row_id_bit18                  ) ,
              .gc_cr_ddr_hash_config_reg1_row_id_bit19                  ( gc_cr_ddr_hash_config_reg1_row_id_bit19                  ) ,
              .gc_cr_ddr_hash_config_reg1_row_id_bit20                  ( gc_cr_ddr_hash_config_reg1_row_id_bit20                  ) ,
              .gc_cr_ddr_hash_config_reg1_row_id_bit21                  ( gc_cr_ddr_hash_config_reg1_row_id_bit21                  ) ,
              .gc_cr_ddr_hash_config_reg1_row_id_bit22                  ( gc_cr_ddr_hash_config_reg1_row_id_bit22                  ) ,
              .gc_cr_ddr_hash_config_reg1_row_id_bit23                  ( gc_cr_ddr_hash_config_reg1_row_id_bit23                  ) ,
              .gc_cr_l2_function_enable_hash_mode                       ( gc_cr_l2_function_enable_hash_mode                       ) ,
              // performance counter
              .l2b0_busy                                  ( bank_perf_event[bank_wrap_idx*2][0])    ,
              .l2b0_fromaxi_ar_wl                         ( bank_perf_event[bank_wrap_idx*2][1])   ,
              .l2b0_fromaxi_ar_bl_eq0_wl                  ( bank_perf_event[bank_wrap_idx*2][2])    ,
              .l2b0_fromaxi_ar_bl_eq1_wl                  ( bank_perf_event[bank_wrap_idx*2][3])   ,
              .l2b0_fromaxi_ar_bl_eq2_wl                  ( bank_perf_event[bank_wrap_idx*2][4])   ,
              .l2b0_fromaxi_ar_bl_eq3_wl                  ( bank_perf_event[bank_wrap_idx*2][5])   ,
              .l2b0_fromaxi_ar_bp                         ( bank_perf_event[bank_wrap_idx*2][6])   ,
              .l2b0_toaxi_r_wl                            ( bank_perf_event[bank_wrap_idx*2][7])   ,
              .l2b0_toaxi_r_bp                            ( bank_perf_event[bank_wrap_idx*2][8])   ,
              .l2b0_fromaxi_aw_wl                         ( bank_perf_event[bank_wrap_idx*2][9])   ,
              .l2b0_fromaxi_aw_bl_eq0_wl                  ( bank_perf_event[bank_wrap_idx*2][10])   ,
              .l2b0_fromaxi_aw_bl_eq1_wl                  ( bank_perf_event[bank_wrap_idx*2][11])   ,
              .l2b0_fromaxi_aw_bl_eq2_wl                  ( bank_perf_event[bank_wrap_idx*2][12])   ,
              .l2b0_fromaxi_aw_bl_eq3_wl                  ( bank_perf_event[bank_wrap_idx*2][13])   ,
              .l2b0_fromaxi_aw_bp                         ( bank_perf_event[bank_wrap_idx*2][14])   ,
              .l2b0_fromaxi_w_wl                          ( bank_perf_event[bank_wrap_idx*2][15])   ,
              .l2b0_fromaxi_w_bp                          ( bank_perf_event[bank_wrap_idx*2][16])   ,
              .l2b0_fromaxi_smp_read_req_num              ( bank_perf_event[bank_wrap_idx*2][17])    ,
              .l2b0_fromaxi_smp_read_req_sum              ( bank_perf_event[bank_wrap_idx*2][18])    ,
              .l2b0_fromaxi_smp_write_req_num             ( bank_perf_event[bank_wrap_idx*2][19])    ,
              .l2b0_fromaxi_smp_write_req_sum             ( bank_perf_event[bank_wrap_idx*2][20])    ,
              .l2b0_fromaxi_smp_atomic_req_num            ( bank_perf_event[bank_wrap_idx*2][21])    ,
              .l2b0_fromaxi_smp_atomic_req_sum            ( bank_perf_event[bank_wrap_idx*2][22])    ,
              .l2b0_frommemsch_nsp_rtn_wl                 ( bank_perf_event[bank_wrap_idx*2][23])   ,
              .l2b0_frommemsch_nsp_rtn_bp                 ( bank_perf_event[bank_wrap_idx*2][24])   ,
              .l2b0_tomemsch_nsp_read_bl_eq1_wl           ( bank_perf_event[bank_wrap_idx*2][25])   ,
              .l2b0_tomemsch_nsp_read_bl_eq3_wl           ( bank_perf_event[bank_wrap_idx*2][26])   ,
              .l2b0_tomemsch_nsp_read_bl_eq5_wl           ( bank_perf_event[bank_wrap_idx*2][27])   ,
              .l2b0_tomemsch_nsp_read_bl_eq7_wl           ( bank_perf_event[bank_wrap_idx*2][28])   ,
              .l2b0_tomemsch_nsp_write_bl_eq1_wl          ( bank_perf_event[bank_wrap_idx*2][29])   ,
              .l2b0_tomemsch_nsp_write_bl_eq3_wl          ( bank_perf_event[bank_wrap_idx*2][30])   ,
              .l2b0_tomemsch_nsp_write_bl_eq5_wl          ( bank_perf_event[bank_wrap_idx*2][31])   ,
              .l2b0_tomemsch_nsp_write_bl_eq7_wl          ( bank_perf_event[bank_wrap_idx*2][32])   ,
              .l2b0_hittest_ht_bypass_read_wl             ( bank_perf_event[bank_wrap_idx*2][33])   ,
              .l2b0_hittest_ht_cache_read_wl              ( bank_perf_event[bank_wrap_idx*2][34])   ,
              .l2b0_hittest_ht_bypass_write_wl            ( bank_perf_event[bank_wrap_idx*2][35])   ,
              .l2b0_hittest_ht_cache_write_wl             ( bank_perf_event[bank_wrap_idx*2][36])   ,
              .l2b0_hittest_ht_atomic_wl                  ( bank_perf_event[bank_wrap_idx*2][37])   ,
              .l2b0_hittest_ht_bps_hit_wl                 ( bank_perf_event[bank_wrap_idx*2][38])   ,
              .l2b0_hittest_ht_miss_wl                    ( bank_perf_event[bank_wrap_idx*2][39])   ,
              .l2b0_reqsch_sortq_full                     ( bank_perf_event[bank_wrap_idx*2][40])   ,
              .l2b0_reqsch_sortq_stall_but_not_full       ( bank_perf_event[bank_wrap_idx*2][41])   ,
              .l2b0_reqsch_disp_wl                        ( bank_perf_event[bank_wrap_idx*2][42])   ,
              .l2b0_reqsch_disp_stall                     ( bank_perf_event[bank_wrap_idx*2][43])   ,
              .l2b0_ramctrl_0_reqarb_wl                   ( bank_perf_event[bank_wrap_idx*2][44])   ,
              .l2b0_ramctrl_1_reqarb_wl                   ( bank_perf_event[bank_wrap_idx*2][45])   ,
              .l2b0_ramctrl_0_reqarb_stall_by_sram        ( bank_perf_event[bank_wrap_idx*2][46])   ,
              .l2b0_ramctrl_1_reqarb_stall_by_sram        ( bank_perf_event[bank_wrap_idx*2][47])   ,
              .l2b0_ramctrl_0_data_sram_read_wl           ( bank_perf_event[bank_wrap_idx*2][48])   ,
              .l2b0_ramctrl_1_data_sram_read_wl           ( bank_perf_event[bank_wrap_idx*2][49])   ,
              .l2b0_ramctrl_0_data_sram_write_wl          ( bank_perf_event[bank_wrap_idx*2][50])   ,
              .l2b0_ramctrl_1_data_sram_write_wl          ( bank_perf_event[bank_wrap_idx*2][51])   ,
              .l2b0_memif_to_ddr_read_wl                  ( bank_perf_event[bank_wrap_idx*2][52])   ,
              .l2b0_memif_to_ddr_read_stall_by_rob        ( bank_perf_event[bank_wrap_idx*2][53])   ,
              .l2b0_memif_to_ddr_read_stall_by_ddr        ( bank_perf_event[bank_wrap_idx*2][54])   ,
              .l2b0_memif_to_ddr_read_stall_by_trid       ( bank_perf_event[bank_wrap_idx*2][55])   ,
              .l2b0_memif_to_ddr_write_wl                 ( bank_perf_event[bank_wrap_idx*2][56])   ,
              .l2b0_memif_to_ddr_write_stall_by_data_sync ( bank_perf_event[bank_wrap_idx*2][57])   ,
              .l2b0_memif_to_ddr_write_stall_by_trid      ( bank_perf_event[bank_wrap_idx*2][58])   ,
              .l2b0_memif_to_ddr_write_stall_by_ddr       ( bank_perf_event[bank_wrap_idx*2][59])   ,
              .l2b0_memif_memreq_full                     ( bank_perf_event[bank_wrap_idx*2][60])   ,
              .l2b0_memif_smp_read_req_num                ( bank_perf_event[bank_wrap_idx*2][61])    ,
              .l2b0_memif_smp_read_req_sum                ( bank_perf_event[bank_wrap_idx*2][62])    ,
              .l2b0_align_awdb_full                       ( bank_perf_event[bank_wrap_idx*2][63])   ,
              
              .l2b1_busy                                  ( bank_perf_event[bank_wrap_idx*2+1][0])    ,
              .l2b1_fromaxi_ar_wl                         ( bank_perf_event[bank_wrap_idx*2+1][1])   ,
              .l2b1_fromaxi_ar_bl_eq0_wl                  ( bank_perf_event[bank_wrap_idx*2+1][2])    ,
              .l2b1_fromaxi_ar_bl_eq1_wl                  ( bank_perf_event[bank_wrap_idx*2+1][3])   ,
              .l2b1_fromaxi_ar_bl_eq2_wl                  ( bank_perf_event[bank_wrap_idx*2+1][4])   ,
              .l2b1_fromaxi_ar_bl_eq3_wl                  ( bank_perf_event[bank_wrap_idx*2+1][5])   ,
              .l2b1_fromaxi_ar_bp                         ( bank_perf_event[bank_wrap_idx*2+1][6])   ,
              .l2b1_toaxi_r_wl                            ( bank_perf_event[bank_wrap_idx*2+1][7])   ,
              .l2b1_toaxi_r_bp                            ( bank_perf_event[bank_wrap_idx*2+1][8])   ,
              .l2b1_fromaxi_aw_wl                         ( bank_perf_event[bank_wrap_idx*2+1][9])   ,
              .l2b1_fromaxi_aw_bl_eq0_wl                  ( bank_perf_event[bank_wrap_idx*2+1][10])   ,
              .l2b1_fromaxi_aw_bl_eq1_wl                  ( bank_perf_event[bank_wrap_idx*2+1][11])   ,
              .l2b1_fromaxi_aw_bl_eq2_wl                  ( bank_perf_event[bank_wrap_idx*2+1][12])   ,
              .l2b1_fromaxi_aw_bl_eq3_wl                  ( bank_perf_event[bank_wrap_idx*2+1][13])   ,
              .l2b1_fromaxi_aw_bp                         ( bank_perf_event[bank_wrap_idx*2+1][14])   ,
              .l2b1_fromaxi_w_wl                          ( bank_perf_event[bank_wrap_idx*2+1][15])   ,
              .l2b1_fromaxi_w_bp                          ( bank_perf_event[bank_wrap_idx*2+1][16])   ,
              .l2b1_fromaxi_smp_read_req_num              ( bank_perf_event[bank_wrap_idx*2+1][17])    ,
              .l2b1_fromaxi_smp_read_req_sum              ( bank_perf_event[bank_wrap_idx*2+1][18])    ,
              .l2b1_fromaxi_smp_write_req_num             ( bank_perf_event[bank_wrap_idx*2+1][19])    ,
              .l2b1_fromaxi_smp_write_req_sum             ( bank_perf_event[bank_wrap_idx*2+1][20])    ,
              .l2b1_fromaxi_smp_atomic_req_num            ( bank_perf_event[bank_wrap_idx*2+1][21])    ,
              .l2b1_fromaxi_smp_atomic_req_sum            ( bank_perf_event[bank_wrap_idx*2+1][22])    ,
              .l2b1_frommemsch_nsp_rtn_wl                 ( bank_perf_event[bank_wrap_idx*2+1][23])   ,
              .l2b1_frommemsch_nsp_rtn_bp                 ( bank_perf_event[bank_wrap_idx*2+1][24])   ,
              .l2b1_tomemsch_nsp_read_bl_eq1_wl           ( bank_perf_event[bank_wrap_idx*2+1][25])   ,
              .l2b1_tomemsch_nsp_read_bl_eq3_wl           ( bank_perf_event[bank_wrap_idx*2+1][26])   ,
              .l2b1_tomemsch_nsp_read_bl_eq5_wl           ( bank_perf_event[bank_wrap_idx*2+1][27])   ,
              .l2b1_tomemsch_nsp_read_bl_eq7_wl           ( bank_perf_event[bank_wrap_idx*2+1][28])   ,
              .l2b1_tomemsch_nsp_write_bl_eq1_wl          ( bank_perf_event[bank_wrap_idx*2+1][29])   ,
              .l2b1_tomemsch_nsp_write_bl_eq3_wl          ( bank_perf_event[bank_wrap_idx*2+1][30])   ,
              .l2b1_tomemsch_nsp_write_bl_eq5_wl          ( bank_perf_event[bank_wrap_idx*2+1][31])   ,
              .l2b1_tomemsch_nsp_write_bl_eq7_wl          ( bank_perf_event[bank_wrap_idx*2+1][32])   ,
              .l2b1_hittest_ht_bypass_read_wl             ( bank_perf_event[bank_wrap_idx*2+1][33])   ,
              .l2b1_hittest_ht_cache_read_wl              ( bank_perf_event[bank_wrap_idx*2+1][34])   ,
              .l2b1_hittest_ht_bypass_write_wl            ( bank_perf_event[bank_wrap_idx*2+1][35])   ,
              .l2b1_hittest_ht_cache_write_wl             ( bank_perf_event[bank_wrap_idx*2+1][36])   ,
              .l2b1_hittest_ht_atomic_wl                  ( bank_perf_event[bank_wrap_idx*2+1][37])   ,
              .l2b1_hittest_ht_bps_hit_wl                 ( bank_perf_event[bank_wrap_idx*2+1][38])   ,
              .l2b1_hittest_ht_miss_wl                    ( bank_perf_event[bank_wrap_idx*2+1][39])   ,
              .l2b1_reqsch_sortq_full                     ( bank_perf_event[bank_wrap_idx*2+1][40])   ,
              .l2b1_reqsch_sortq_stall_but_not_full       ( bank_perf_event[bank_wrap_idx*2+1][41])   ,
              .l2b1_reqsch_disp_wl                        ( bank_perf_event[bank_wrap_idx*2+1][42])   ,
              .l2b1_reqsch_disp_stall                     ( bank_perf_event[bank_wrap_idx*2+1][43])   ,
              .l2b1_ramctrl_0_reqarb_wl                   ( bank_perf_event[bank_wrap_idx*2+1][44])   ,
              .l2b1_ramctrl_1_reqarb_wl                   ( bank_perf_event[bank_wrap_idx*2+1][45])   ,
              .l2b1_ramctrl_0_reqarb_stall_by_sram        ( bank_perf_event[bank_wrap_idx*2+1][46])   ,
              .l2b1_ramctrl_1_reqarb_stall_by_sram        ( bank_perf_event[bank_wrap_idx*2+1][47])   ,
              .l2b1_ramctrl_0_data_sram_read_wl           ( bank_perf_event[bank_wrap_idx*2+1][48])   ,
              .l2b1_ramctrl_1_data_sram_read_wl           ( bank_perf_event[bank_wrap_idx*2+1][49])   ,
              .l2b1_ramctrl_0_data_sram_write_wl          ( bank_perf_event[bank_wrap_idx*2+1][50])   ,
              .l2b1_ramctrl_1_data_sram_write_wl          ( bank_perf_event[bank_wrap_idx*2+1][51])   ,
              .l2b1_memif_to_ddr_read_wl                  ( bank_perf_event[bank_wrap_idx*2+1][52])   ,
              .l2b1_memif_to_ddr_read_stall_by_rob        ( bank_perf_event[bank_wrap_idx*2+1][53])   ,
              .l2b1_memif_to_ddr_read_stall_by_ddr        ( bank_perf_event[bank_wrap_idx*2+1][54])   ,
              .l2b1_memif_to_ddr_read_stall_by_trid       ( bank_perf_event[bank_wrap_idx*2+1][55])   ,
              .l2b1_memif_to_ddr_write_wl                 ( bank_perf_event[bank_wrap_idx*2+1][56])   ,
              .l2b1_memif_to_ddr_write_stall_by_data_sync ( bank_perf_event[bank_wrap_idx*2+1][57])   ,
              .l2b1_memif_to_ddr_write_stall_by_trid      ( bank_perf_event[bank_wrap_idx*2+1][58])   ,
              .l2b1_memif_to_ddr_write_stall_by_ddr       ( bank_perf_event[bank_wrap_idx*2+1][59])   ,
              .l2b1_memif_memreq_full                     ( bank_perf_event[bank_wrap_idx*2+1][60])   ,
              .l2b1_memif_smp_read_req_num                ( bank_perf_event[bank_wrap_idx*2+1][61])    ,
              .l2b1_memif_smp_read_req_sum                ( bank_perf_event[bank_wrap_idx*2+1][62])    ,
              .l2b1_align_awdb_full                       ( bank_perf_event[bank_wrap_idx*2+1][63])   
      );






   end
endgenerate



logic [79:0] gc_cr_l2_cfi_status;
logic [63:0][2:0] gc_cr_l2g_error;

gc_l2_bank_misc
i_gc_l2_bank_misc           (
    .clk                    ( crg_aligned_clk        )
   ,.resetn                 ( crg_aligned_resetn     )
   ,.l2g_number_id          ( l2g_number_id          )
   ,.bank_perf_enable       ( gc_cr_perf_mon1_enable )
   ,.bank_perf_event        ( bank_perf_event        )
   ,.bank_perf_sel          ( bank_perf_sel          )
   ,.l2g_perf_event         ( l2g_perf_event         )
   ,.gc_cr_clk_status_l2g   ( gc_cr_clk_status_l2g   )
   ,.gc_cr_clk_status3_l2g  ( gc_cr_clk_status3_l2g  )
   ,.gc_cr_l2_cfi_status_l  ( gc_cr_l2_cfi_status_l  )
   ,.gc_cr_l2_cfi_status    ( gc_cr_l2_cfi_status    )
   ,.gc_cr_l2g_idle_l2g     ( gc_cr_l2g_idle_l2g     )
   ,.gc_cr_l2_idle          ( gc_cr_l2_idle          )

   ,.gc_cr_l2g_error_l2b    ( gc_cr_l2g_error_l2b    )
   ,.gc_cr_l2g_error        ( gc_cr_l2g_error        )
   
   ,.regbank_instance       ( regbank_instance       ) );



gc_cr_l2g_regbank_
i_gc_cr_l2g_regbank                                        (
 .clk                                                      ( crg_aligned_clk                                          )
,.resetn                                                   ( crg_aligned_resetn                                       )

,.regbank_valid                                            ( socif_valid                                              )
,.regbank_addr                                             ( socif_rec.addr                                           )
,.regbank_wdata                                            ( socif_rec.wdata                                          )
,.regbank_wmask                                            ( socif_rec.wmask                                          )
,.regbank_rdnwr                                            ( socif_rec.rdnwr                                          )

,.regbank_rvalid                                           ( socif_rvalid                                             )
,.regbank_rdata                                            ( socif_rdata                                              )
,.regbank_instance                                         ( regbank_instance                                         )

,.gc_cr_clk_ctrl3_l2g0                                     ( gc_cr_clk_ctrl3_l2g[0]                                   )
,.gc_cr_clk_ctrl3_l2g1                                     ( gc_cr_clk_ctrl3_l2g[1]                                   )
,.gc_cr_clk_ctrl3_l2g2                                     ( gc_cr_clk_ctrl3_l2g[2]                                   )
,.gc_cr_clk_ctrl3_l2g3                                     ( gc_cr_clk_ctrl3_l2g[3]                                   )
,.gc_cr_clk_ctrl3_l2g4                                     ( gc_cr_clk_ctrl3_l2g[4]                                   )
,.gc_cr_clk_ctrl3_l2g5                                     ( gc_cr_clk_ctrl3_l2g[5]                                   )
,.gc_cr_clk_ctrl3_l2g6                                     ( gc_cr_clk_ctrl3_l2g[6]                                   )
,.gc_cr_clk_ctrl3_l2g7                                     ( gc_cr_clk_ctrl3_l2g[7]                                   )
,.gc_cr_clk_status3_l2g0                                   ( gc_cr_clk_status3_l2g[0]                                 )
,.gc_cr_clk_status3_l2g1                                   ( gc_cr_clk_status3_l2g[1]                                 )
,.gc_cr_clk_status3_l2g2                                   ( gc_cr_clk_status3_l2g[2]                                 )
,.gc_cr_clk_status3_l2g3                                   ( gc_cr_clk_status3_l2g[3]                                 )
,.gc_cr_clk_status3_l2g4                                   ( gc_cr_clk_status3_l2g[4]                                 )
,.gc_cr_clk_status3_l2g5                                   ( gc_cr_clk_status3_l2g[5]                                 )
,.gc_cr_clk_status3_l2g6                                   ( gc_cr_clk_status3_l2g[6]                                 )
,.gc_cr_clk_status3_l2g7                                   ( gc_cr_clk_status3_l2g[7]                                 )
,.gc_cr_l2_cfi_operation                                   ( gc_cr_l2_cfi_operation                                   )


    
,.gc_cr_l2_cfi_statusi_l2b0                                ( gc_cr_l2_cfi_status[0 ]                                  )
,.gc_cr_l2_cfi_statusi_l2b1                                ( gc_cr_l2_cfi_status[1 ]                                  )
,.gc_cr_l2_cfi_statusi_l2b2                                ( gc_cr_l2_cfi_status[2 ]                                  )
,.gc_cr_l2_cfi_statusi_l2b3                                ( gc_cr_l2_cfi_status[3 ]                                  )
,.gc_cr_l2_cfi_statusi_l2b4                                ( gc_cr_l2_cfi_status[4 ]                                  )
,.gc_cr_l2_cfi_statusi_l2b5                                ( gc_cr_l2_cfi_status[5 ]                                  )
,.gc_cr_l2_cfi_statusi_l2b6                                ( gc_cr_l2_cfi_status[6 ]                                  )
,.gc_cr_l2_cfi_statusi_l2b7                                ( gc_cr_l2_cfi_status[7 ]                                  )
,.gc_cr_l2_cfi_statusi_l2b8                               ( gc_cr_l2_cfi_status[8 ]                                  )
,.gc_cr_l2_cfi_statusi_l2b9                               ( gc_cr_l2_cfi_status[9 ]                                  )
,.gc_cr_l2_cfi_statusi_l2b10                               ( gc_cr_l2_cfi_status[10]                                  )
,.gc_cr_l2_cfi_statusi_l2b11                               ( gc_cr_l2_cfi_status[11]                                  )
,.gc_cr_l2_cfi_statusi_l2b12                               ( gc_cr_l2_cfi_status[12]                                  )
,.gc_cr_l2_cfi_statusi_l2b13                               ( gc_cr_l2_cfi_status[13]                                  )
,.gc_cr_l2_cfi_statusi_l2b14                               ( gc_cr_l2_cfi_status[14]                                  )
,.gc_cr_l2_cfi_statusi_l2b15                               ( gc_cr_l2_cfi_status[15]                                  )
,.gc_cr_l2_cfi_statusi_l2b16                               ( gc_cr_l2_cfi_status[16]                                  )
,.gc_cr_l2_cfi_statusi_l2b17                               ( gc_cr_l2_cfi_status[17]                                  )
,.gc_cr_l2_cfi_statusi_l2b18                               ( gc_cr_l2_cfi_status[18]                                  )
,.gc_cr_l2_cfi_statusi_l2b19                               ( gc_cr_l2_cfi_status[19]                                  )
,.gc_cr_l2_cfi_statusi_l2b20                               ( gc_cr_l2_cfi_status[20]                                  )
,.gc_cr_l2_cfi_statusi_l2b21                               ( gc_cr_l2_cfi_status[21]                                  )
,.gc_cr_l2_cfi_statusi_l2b22                               ( gc_cr_l2_cfi_status[22]                                  )
,.gc_cr_l2_cfi_statusi_l2b23                               ( gc_cr_l2_cfi_status[23]                                  )
,.gc_cr_l2_cfi_statusi_l2b24                               ( gc_cr_l2_cfi_status[24]                                  )
,.gc_cr_l2_cfi_statusi_l2b25                               ( gc_cr_l2_cfi_status[25]                                  )
,.gc_cr_l2_cfi_statusi_l2b26                               ( gc_cr_l2_cfi_status[26]                                  )
,.gc_cr_l2_cfi_statusi_l2b27                               ( gc_cr_l2_cfi_status[27]                                  )
,.gc_cr_l2_cfi_statusi_l2b28                               ( gc_cr_l2_cfi_status[28]                                  )
,.gc_cr_l2_cfi_statusi_l2b29                               ( gc_cr_l2_cfi_status[29]                                  )
,.gc_cr_l2_cfi_statusi_l2b30                               ( gc_cr_l2_cfi_status[30]                                  )
,.gc_cr_l2_cfi_statusi_l2b31                               ( gc_cr_l2_cfi_status[31]                                  )
,.gc_cr_l2_cfi_statusi_l2b32                               ( gc_cr_l2_cfi_status[32]                                  )
,.gc_cr_l2_cfi_statusi_l2b33                               ( gc_cr_l2_cfi_status[33]                                  )
,.gc_cr_l2_cfi_statusi_l2b34                               ( gc_cr_l2_cfi_status[34]                                  )
,.gc_cr_l2_cfi_statusi_l2b35                               ( gc_cr_l2_cfi_status[35]                                  )
,.gc_cr_l2_cfi_statusi_l2b36                               ( gc_cr_l2_cfi_status[36]                                  )
,.gc_cr_l2_cfi_statusi_l2b37                               ( gc_cr_l2_cfi_status[37]                                  )
,.gc_cr_l2_cfi_statusi_l2b38                               ( gc_cr_l2_cfi_status[38]                                  )
,.gc_cr_l2_cfi_statusi_l2b39                               ( gc_cr_l2_cfi_status[39]                                  )
,.gc_cr_l2_cfi_statusi_l2b40                               ( gc_cr_l2_cfi_status[40]                                  )
,.gc_cr_l2_cfi_statusi_l2b41                               ( gc_cr_l2_cfi_status[41]                                  )
,.gc_cr_l2_cfi_statusi_l2b42                               ( gc_cr_l2_cfi_status[42]                                  )
,.gc_cr_l2_cfi_statusi_l2b43                               ( gc_cr_l2_cfi_status[43]                                  )
,.gc_cr_l2_cfi_statusi_l2b44                               ( gc_cr_l2_cfi_status[44]                                  )
,.gc_cr_l2_cfi_statusi_l2b45                               ( gc_cr_l2_cfi_status[45]                                  )
,.gc_cr_l2_cfi_statusi_l2b46                               ( gc_cr_l2_cfi_status[46]                                  )
,.gc_cr_l2_cfi_statusi_l2b47                               ( gc_cr_l2_cfi_status[47]                                  )
,.gc_cr_l2_cfi_statusi_l2b48                               ( gc_cr_l2_cfi_status[48]                                  )
,.gc_cr_l2_cfi_statusi_l2b49                               ( gc_cr_l2_cfi_status[49]                                  )
,.gc_cr_l2_cfi_statusi_l2b50                               ( gc_cr_l2_cfi_status[50]                                  )
,.gc_cr_l2_cfi_statusi_l2b51                               ( gc_cr_l2_cfi_status[51]                                  )
,.gc_cr_l2_cfi_statusi_l2b52                               ( gc_cr_l2_cfi_status[52]                                  )
,.gc_cr_l2_cfi_statusi_l2b53                               ( gc_cr_l2_cfi_status[53]                                  )
,.gc_cr_l2_cfi_statusi_l2b54                               ( gc_cr_l2_cfi_status[54]                                  )
,.gc_cr_l2_cfi_statusi_l2b55                               ( gc_cr_l2_cfi_status[55]                                  )
,.gc_cr_l2_cfi_statusi_l2b56                               ( gc_cr_l2_cfi_status[56]                                  )
,.gc_cr_l2_cfi_statusi_l2b57                               ( gc_cr_l2_cfi_status[57]                                  )
,.gc_cr_l2_cfi_statusi_l2b58                               ( gc_cr_l2_cfi_status[58]                                  )
,.gc_cr_l2_cfi_statusi_l2b59                               ( gc_cr_l2_cfi_status[59]                                  )
,.gc_cr_l2_cfi_statusi_l2b60                               ( gc_cr_l2_cfi_status[60]                                  )
,.gc_cr_l2_cfi_statusi_l2b61                               ( gc_cr_l2_cfi_status[61]                                  )
,.gc_cr_l2_cfi_statusi_l2b62                               ( gc_cr_l2_cfi_status[62]                                  )
,.gc_cr_l2_cfi_statusi_l2b63                               ( gc_cr_l2_cfi_status[63]                                  )
,.gc_cr_l2_cfi_statusii_l2b64                              ( gc_cr_l2_cfi_status[64]                                  )
,.gc_cr_l2_cfi_statusii_l2b65                              ( gc_cr_l2_cfi_status[65]                                  )
,.gc_cr_l2_cfi_statusii_l2b66                              ( gc_cr_l2_cfi_status[66]                                  )
,.gc_cr_l2_cfi_statusii_l2b67                              ( gc_cr_l2_cfi_status[67]                                  )
,.gc_cr_l2_cfi_statusii_l2b68                              ( gc_cr_l2_cfi_status[68]                                  )
,.gc_cr_l2_cfi_statusii_l2b69                              ( gc_cr_l2_cfi_status[69]                                  )
,.gc_cr_l2_cfi_statusii_l2b70                              ( gc_cr_l2_cfi_status[70]                                  )
,.gc_cr_l2_cfi_statusii_l2b71                              ( gc_cr_l2_cfi_status[71]                                  )
,.gc_cr_l2_cfi_statusii_l2b72                              ( gc_cr_l2_cfi_status[72]                                  )
,.gc_cr_l2_cfi_statusii_l2b73                              ( gc_cr_l2_cfi_status[73]                                  )
,.gc_cr_l2_cfi_statusii_l2b74                              ( gc_cr_l2_cfi_status[74]                                  )
,.gc_cr_l2_cfi_statusii_l2b75                              ( gc_cr_l2_cfi_status[75]                                  )
,.gc_cr_l2_cfi_statusii_l2b76                              ( gc_cr_l2_cfi_status[76]                                  )
,.gc_cr_l2_cfi_statusii_l2b77                              ( gc_cr_l2_cfi_status[77]                                  )
,.gc_cr_l2_cfi_statusii_l2b78                              ( gc_cr_l2_cfi_status[78]                                  )
,.gc_cr_l2_cfi_statusii_l2b79                              ( gc_cr_l2_cfi_status[79]                                  )

    
,.gc_cr_l2_buffer_mode_buffer_mode_percentage              ( gc_cr_l2_buffer_mode_buffer_mode_percentage              )

,.gc_cr_l2_persistence_reduce_persistence_reduce_enable    ( gc_cr_l2_persistence_reduce_persistence_reduce_enable    )
,.gc_cr_l2_persistence_reduce_persistence_reduce_threshold ( gc_cr_l2_persistence_reduce_persistence_reduce_threshold )
    
,.gc_cr_l2_cmd_persistence_rst_all                         ( gc_cr_l2_cmd_persistence_rst_all                         )
,.gc_cr_l2_cmd_cfi_clr                                     ( gc_cr_l2_cmd_cfi_clr                                     )

,.gc_cr_l2g_idle_l2b0                                      ( gc_cr_l2_idle[0 ]                                        )
,.gc_cr_l2g_idle_l2b1                                      ( gc_cr_l2_idle[1 ]                                        )
,.gc_cr_l2g_idle_l2b2                                      ( gc_cr_l2_idle[2 ]                                        )
,.gc_cr_l2g_idle_l2b3                                      ( gc_cr_l2_idle[3 ]                                        )
,.gc_cr_l2g_idle_l2b4                                      ( gc_cr_l2_idle[4 ]                                        )
,.gc_cr_l2g_idle_l2b5                                      ( gc_cr_l2_idle[5 ]                                        )
,.gc_cr_l2g_idle_l2b6                                      ( gc_cr_l2_idle[6 ]                                        )
,.gc_cr_l2g_idle_l2b7                                      ( gc_cr_l2_idle[7 ]                                        )
,.gc_cr_l2g_idle_l2b8                                      ( gc_cr_l2_idle[8 ]                                        )
,.gc_cr_l2g_idle_l2b9                                      ( gc_cr_l2_idle[9 ]                                        )
,.gc_cr_l2g_idle_l2b10                                     ( gc_cr_l2_idle[10]                                        )
,.gc_cr_l2g_idle_l2b11                                     ( gc_cr_l2_idle[11]                                        )
,.gc_cr_l2g_idle_l2b12                                     ( gc_cr_l2_idle[12]                                        )
,.gc_cr_l2g_idle_l2b13                                     ( gc_cr_l2_idle[13]                                        )
,.gc_cr_l2g_idle_l2b14                                     ( gc_cr_l2_idle[14]                                        )
,.gc_cr_l2g_idle_l2b15                                     ( gc_cr_l2_idle[15]                                        )
,.gc_cr_l2g_idle_l2b16                                     ( gc_cr_l2_idle[16]                                        )
,.gc_cr_l2g_idle_l2b17                                     ( gc_cr_l2_idle[17]                                        )
,.gc_cr_l2g_idle_l2b18                                     ( gc_cr_l2_idle[18]                                        )
,.gc_cr_l2g_idle_l2b19                                     ( gc_cr_l2_idle[19]                                        )
,.gc_cr_l2g_idle_l2b20                                     ( gc_cr_l2_idle[20]                                        )
,.gc_cr_l2g_idle_l2b21                                     ( gc_cr_l2_idle[21]                                        )
,.gc_cr_l2g_idle_l2b22                                     ( gc_cr_l2_idle[22]                                        )
,.gc_cr_l2g_idle_l2b23                                     ( gc_cr_l2_idle[23]                                        )
,.gc_cr_l2g_idle_l2b24                                     ( gc_cr_l2_idle[24]                                        )
,.gc_cr_l2g_idle_l2b25                                     ( gc_cr_l2_idle[25]                                        )
,.gc_cr_l2g_idle_l2b26                                     ( gc_cr_l2_idle[26]                                        )
,.gc_cr_l2g_idle_l2b27                                     ( gc_cr_l2_idle[27]                                        )
,.gc_cr_l2g_idle_l2b28                                     ( gc_cr_l2_idle[28]                                        )
,.gc_cr_l2g_idle_l2b29                                     ( gc_cr_l2_idle[29]                                        )
,.gc_cr_l2g_idle_l2b30                                     ( gc_cr_l2_idle[30]                                        )
,.gc_cr_l2g_idle_l2b31                                     ( gc_cr_l2_idle[31]                                        )
,.gc_cr_l2g_idle_l2b32                                     ( gc_cr_l2_idle[32]                                        )
,.gc_cr_l2g_idle_l2b33                                     ( gc_cr_l2_idle[33]                                        )
,.gc_cr_l2g_idle_l2b34                                     ( gc_cr_l2_idle[34]                                        )
,.gc_cr_l2g_idle_l2b35                                     ( gc_cr_l2_idle[35]                                        )
,.gc_cr_l2g_idle_l2b36                                     ( gc_cr_l2_idle[36]                                        )
,.gc_cr_l2g_idle_l2b37                                     ( gc_cr_l2_idle[37]                                        )
,.gc_cr_l2g_idle_l2b38                                     ( gc_cr_l2_idle[38]                                        )
,.gc_cr_l2g_idle_l2b39                                     ( gc_cr_l2_idle[39]                                        )
,.gc_cr_l2g_idle_l2b40                                     ( gc_cr_l2_idle[40]                                        )
,.gc_cr_l2g_idle_l2b41                                     ( gc_cr_l2_idle[41]                                        )
,.gc_cr_l2g_idle_l2b42                                     ( gc_cr_l2_idle[42]                                        )
,.gc_cr_l2g_idle_l2b43                                     ( gc_cr_l2_idle[43]                                        )
,.gc_cr_l2g_idle_l2b44                                     ( gc_cr_l2_idle[44]                                        )
,.gc_cr_l2g_idle_l2b45                                     ( gc_cr_l2_idle[45]                                        )
,.gc_cr_l2g_idle_l2b46                                     ( gc_cr_l2_idle[46]                                        )
,.gc_cr_l2g_idle_l2b47                                     ( gc_cr_l2_idle[47]                                        )
,.gc_cr_l2g_idle_l2b48                                     ( gc_cr_l2_idle[48]                                        )
,.gc_cr_l2g_idle_l2b49                                     ( gc_cr_l2_idle[49]                                        )
,.gc_cr_l2g_idle_l2b50                                     ( gc_cr_l2_idle[50]                                        )
,.gc_cr_l2g_idle_l2b51                                     ( gc_cr_l2_idle[51]                                        )
,.gc_cr_l2g_idle_l2b52                                     ( gc_cr_l2_idle[52]                                        )
,.gc_cr_l2g_idle_l2b53                                     ( gc_cr_l2_idle[53]                                        )
,.gc_cr_l2g_idle_l2b54                                     ( gc_cr_l2_idle[54]                                        )
,.gc_cr_l2g_idle_l2b55                                     ( gc_cr_l2_idle[55]                                        )
,.gc_cr_l2g_idle_l2b56                                     ( gc_cr_l2_idle[56]                                        )
,.gc_cr_l2g_idle_l2b57                                     ( gc_cr_l2_idle[57]                                        )
,.gc_cr_l2g_idle_l2b58                                     ( gc_cr_l2_idle[58]                                        )
,.gc_cr_l2g_idle_l2b59                                     ( gc_cr_l2_idle[59]                                        )
,.gc_cr_l2g_idle_l2b60                                     ( gc_cr_l2_idle[60]                                        )
,.gc_cr_l2g_idle_l2b61                                     ( gc_cr_l2_idle[61]                                        )
,.gc_cr_l2g_idle_l2b62                                     ( gc_cr_l2_idle[62]                                        )
,.gc_cr_l2g_idle_l2b63                                     ( gc_cr_l2_idle[63]                                        )
,.gc_cr_l2g_idleii_l2b64                                   ( gc_cr_l2_idle[64]                                        )
,.gc_cr_l2g_idleii_l2b65                                   ( gc_cr_l2_idle[65]                                        )
,.gc_cr_l2g_idleii_l2b66                                   ( gc_cr_l2_idle[66]                                        )
,.gc_cr_l2g_idleii_l2b67                                   ( gc_cr_l2_idle[67]                                        )
,.gc_cr_l2g_idleii_l2b68                                   ( gc_cr_l2_idle[68]                                        )
,.gc_cr_l2g_idleii_l2b69                                   ( gc_cr_l2_idle[69]                                        )
,.gc_cr_l2g_idleii_l2b70                                   ( gc_cr_l2_idle[70]                                        )
,.gc_cr_l2g_idleii_l2b71                                   ( gc_cr_l2_idle[71]                                        )
,.gc_cr_l2g_idleii_l2b72                                   ( gc_cr_l2_idle[72]                                        )
,.gc_cr_l2g_idleii_l2b73                                   ( gc_cr_l2_idle[73]                                        )
,.gc_cr_l2g_idleii_l2b74                                   ( gc_cr_l2_idle[74]                                        )
,.gc_cr_l2g_idleii_l2b75                                   ( gc_cr_l2_idle[75]                                        )
,.gc_cr_l2g_idleii_l2b76                                   ( gc_cr_l2_idle[76]                                        )
,.gc_cr_l2g_idleii_l2b77                                   ( gc_cr_l2_idle[77]                                        )
,.gc_cr_l2g_idleii_l2b78                                   ( gc_cr_l2_idle[78]                                        )
,.gc_cr_l2g_idleii_l2b79                                   ( gc_cr_l2_idle[79]                                        )

    
,.gc_cr_l2g_error0_l2b0                                    ( gc_cr_l2g_error[0 ]                                      )
,.gc_cr_l2g_error0_l2b1                                    ( gc_cr_l2g_error[1 ]                                      )
,.gc_cr_l2g_error0_l2b2                                    ( gc_cr_l2g_error[2 ]                                      )
,.gc_cr_l2g_error0_l2b3                                    ( gc_cr_l2g_error[3 ]                                      )
,.gc_cr_l2g_error0_l2b4                                    ( gc_cr_l2g_error[4 ]                                      )
,.gc_cr_l2g_error0_l2b5                                    ( gc_cr_l2g_error[5 ]                                      )
,.gc_cr_l2g_error0_l2b6                                    ( gc_cr_l2g_error[6 ]                                      )
,.gc_cr_l2g_error0_l2b7                                    ( gc_cr_l2g_error[7 ]                                      )
,.gc_cr_l2g_error0_l2b8                                    ( gc_cr_l2g_error[8 ]                                      )
,.gc_cr_l2g_error0_l2b9                                    ( gc_cr_l2g_error[9 ]                                      )
,.gc_cr_l2g_error0_l2b10                                   ( gc_cr_l2g_error[10]                                      )
,.gc_cr_l2g_error0_l2b11                                   ( gc_cr_l2g_error[11]                                      )
,.gc_cr_l2g_error0_l2b12                                   ( gc_cr_l2g_error[12]                                      )
,.gc_cr_l2g_error0_l2b13                                   ( gc_cr_l2g_error[13]                                      )
,.gc_cr_l2g_error0_l2b14                                   ( gc_cr_l2g_error[14]                                      )
,.gc_cr_l2g_error0_l2b15                                   ( gc_cr_l2g_error[15]                                      )
,.gc_cr_l2g_error0_l2b16                                   ( gc_cr_l2g_error[16]                                      )
,.gc_cr_l2g_error0_l2b17                                   ( gc_cr_l2g_error[17]                                      )
,.gc_cr_l2g_error0_l2b18                                   ( gc_cr_l2g_error[18]                                      )
,.gc_cr_l2g_error0_l2b19                                   ( gc_cr_l2g_error[19]                                      )
,.gc_cr_l2g_error0_l2b20                                   ( gc_cr_l2g_error[20]                                      )
,.gc_cr_l2g_error1_l2b21                                   ( gc_cr_l2g_error[21]                                      )
,.gc_cr_l2g_error1_l2b22                                   ( gc_cr_l2g_error[22]                                      )
,.gc_cr_l2g_error1_l2b23                                   ( gc_cr_l2g_error[23]                                      )
,.gc_cr_l2g_error1_l2b24                                   ( gc_cr_l2g_error[24]                                      )
,.gc_cr_l2g_error1_l2b25                                   ( gc_cr_l2g_error[25]                                      )
,.gc_cr_l2g_error1_l2b26                                   ( gc_cr_l2g_error[26]                                      )
,.gc_cr_l2g_error1_l2b27                                   ( gc_cr_l2g_error[27]                                      )
,.gc_cr_l2g_error1_l2b28                                   ( gc_cr_l2g_error[28]                                      )
,.gc_cr_l2g_error1_l2b29                                   ( gc_cr_l2g_error[29]                                      )
,.gc_cr_l2g_error1_l2b30                                   ( gc_cr_l2g_error[30]                                      )
,.gc_cr_l2g_error1_l2b31                                   ( gc_cr_l2g_error[31]                                      )
,.gc_cr_l2g_error1_l2b32                                   ( gc_cr_l2g_error[32]                                      )
,.gc_cr_l2g_error1_l2b33                                   ( gc_cr_l2g_error[33]                                      )
,.gc_cr_l2g_error1_l2b34                                   ( gc_cr_l2g_error[34]                                      )
,.gc_cr_l2g_error1_l2b35                                   ( gc_cr_l2g_error[35]                                      )
,.gc_cr_l2g_error1_l2b36                                   ( gc_cr_l2g_error[36]                                      )
,.gc_cr_l2g_error1_l2b37                                   ( gc_cr_l2g_error[37]                                      )
,.gc_cr_l2g_error1_l2b38                                   ( gc_cr_l2g_error[38]                                      )
,.gc_cr_l2g_error1_l2b39                                   ( gc_cr_l2g_error[39]                                      )
,.gc_cr_l2g_error1_l2b40                                   ( gc_cr_l2g_error[40]                                      )
,.gc_cr_l2g_error1_l2b41                                   ( gc_cr_l2g_error[41]                                      )
,.gc_cr_l2g_error2_l2b42                                   ( gc_cr_l2g_error[42]                                      )
,.gc_cr_l2g_error2_l2b43                                   ( gc_cr_l2g_error[43]                                      )
,.gc_cr_l2g_error2_l2b44                                   ( gc_cr_l2g_error[44]                                      )
,.gc_cr_l2g_error2_l2b45                                   ( gc_cr_l2g_error[45]                                      )
,.gc_cr_l2g_error2_l2b46                                   ( gc_cr_l2g_error[46]                                      )
,.gc_cr_l2g_error2_l2b47                                   ( gc_cr_l2g_error[47]                                      )
,.gc_cr_l2g_error2_l2b48                                   ( gc_cr_l2g_error[48]                                      )
,.gc_cr_l2g_error2_l2b49                                   ( gc_cr_l2g_error[49]                                      )
,.gc_cr_l2g_error2_l2b50                                   ( gc_cr_l2g_error[50]                                      )
,.gc_cr_l2g_error2_l2b51                                   ( gc_cr_l2g_error[51]                                      )
,.gc_cr_l2g_error2_l2b52                                   ( gc_cr_l2g_error[52]                                      )
,.gc_cr_l2g_error2_l2b53                                   ( gc_cr_l2g_error[53]                                      )
,.gc_cr_l2g_error2_l2b54                                   ( gc_cr_l2g_error[54]                                      )
,.gc_cr_l2g_error2_l2b55                                   ( gc_cr_l2g_error[55]                                      )
,.gc_cr_l2g_error2_l2b56                                   ( gc_cr_l2g_error[56]                                      )
,.gc_cr_l2g_error2_l2b57                                   ( gc_cr_l2g_error[57]                                      )
,.gc_cr_l2g_error2_l2b58                                   ( gc_cr_l2g_error[58]                                      )
,.gc_cr_l2g_error2_l2b59                                   ( gc_cr_l2g_error[59]                                      )
,.gc_cr_l2g_error2_l2b60                                   ( gc_cr_l2g_error[60]                                      )
,.gc_cr_l2g_error2_l2b61                                   ( gc_cr_l2g_error[61]                                      )
,.gc_cr_l2g_error2_l2b62                                   ( gc_cr_l2g_error[62]                                      )
,.gc_cr_l2g_error3_l2b63                                   ( gc_cr_l2g_error[63]                                      )


,.gc_cr_ddr_hash_config_reg0_row_id_bit0                   ( gc_cr_ddr_hash_config_reg0_row_id_bit0                   )
,.gc_cr_ddr_hash_config_reg0_row_id_bit1                   ( gc_cr_ddr_hash_config_reg0_row_id_bit1                   )
,.gc_cr_ddr_hash_config_reg0_row_id_bit2                   ( gc_cr_ddr_hash_config_reg0_row_id_bit2                   )
,.gc_cr_ddr_hash_config_reg0_row_id_bit3                   ( gc_cr_ddr_hash_config_reg0_row_id_bit3                   )
,.gc_cr_ddr_hash_config_reg0_row_id_bit4                   ( gc_cr_ddr_hash_config_reg0_row_id_bit4                   )
,.gc_cr_ddr_hash_config_reg0_row_id_bit5                   ( gc_cr_ddr_hash_config_reg0_row_id_bit5                   )
,.gc_cr_ddr_hash_config_reg0_row_id_bit6                   ( gc_cr_ddr_hash_config_reg0_row_id_bit6                   )
,.gc_cr_ddr_hash_config_reg0_row_id_bit7                   ( gc_cr_ddr_hash_config_reg0_row_id_bit7                   )
,.gc_cr_ddr_hash_config_reg0_row_id_bit8                   ( gc_cr_ddr_hash_config_reg0_row_id_bit8                   )
,.gc_cr_ddr_hash_config_reg0_row_id_bit9                   ( gc_cr_ddr_hash_config_reg0_row_id_bit9                   )
,.gc_cr_ddr_hash_config_reg0_row_id_bit10                  ( gc_cr_ddr_hash_config_reg0_row_id_bit10                  )
,.gc_cr_ddr_hash_config_reg0_row_id_bit11                  ( gc_cr_ddr_hash_config_reg0_row_id_bit11                  )
,.gc_cr_ddr_hash_config_reg1_row_id_bit12                  ( gc_cr_ddr_hash_config_reg1_row_id_bit12                  )
,.gc_cr_ddr_hash_config_reg1_row_id_bit13                  ( gc_cr_ddr_hash_config_reg1_row_id_bit13                  )
,.gc_cr_ddr_hash_config_reg1_row_id_bit14                  ( gc_cr_ddr_hash_config_reg1_row_id_bit14                  )
,.gc_cr_ddr_hash_config_reg1_row_id_bit15                  ( gc_cr_ddr_hash_config_reg1_row_id_bit15                  )
,.gc_cr_ddr_hash_config_reg1_row_id_bit16                  ( gc_cr_ddr_hash_config_reg1_row_id_bit16                  )
,.gc_cr_ddr_hash_config_reg1_row_id_bit17                  ( gc_cr_ddr_hash_config_reg1_row_id_bit17                  )
,.gc_cr_ddr_hash_config_reg1_row_id_bit18                  ( gc_cr_ddr_hash_config_reg1_row_id_bit18                  )
,.gc_cr_ddr_hash_config_reg1_row_id_bit19                  ( gc_cr_ddr_hash_config_reg1_row_id_bit19                  )
,.gc_cr_ddr_hash_config_reg1_row_id_bit20                  ( gc_cr_ddr_hash_config_reg1_row_id_bit20                  )
,.gc_cr_ddr_hash_config_reg1_row_id_bit21                  ( gc_cr_ddr_hash_config_reg1_row_id_bit21                  )
,.gc_cr_ddr_hash_config_reg1_row_id_bit22                  ( gc_cr_ddr_hash_config_reg1_row_id_bit22                  )
,.gc_cr_ddr_hash_config_reg1_row_id_bit23                  ( gc_cr_ddr_hash_config_reg1_row_id_bit23                  )
    
,.gc_cr_l2_function_enable_mem_scheduler                   ( gc_cr_l2_function_enable_mem_scheduler                   )
,.gc_cr_l2_function_enable_bypass_mode                     ( gc_cr_l2_function_enable_bypass_mode                     )
,.gc_cr_l2_function_enable_ddr_capacity                    ( gc_cr_l2_function_enable_ddr_capacity                    )
,.gc_cr_l2_function_enable_hash_mode                       ( gc_cr_l2_function_enable_hash_mode                       )

    
,.gc_cr_l2_mem_sched_col_offset_column_id_bit0             ( gc_cr_l2_mem_sched_col_offset_column_id_bit0             )
,.gc_cr_l2_mem_sched_col_offset_column_id_bit1             ( gc_cr_l2_mem_sched_col_offset_column_id_bit1             )
,.gc_cr_l2_mem_sched_col_offset_column_id_bit2             ( gc_cr_l2_mem_sched_col_offset_column_id_bit2             )
,.gc_cr_l2_mem_sched_col_offset_column_id_bit3             ( gc_cr_l2_mem_sched_col_offset_column_id_bit3             )
,.gc_cr_l2_mem_sched_col_offset_column_id_bit4             ( gc_cr_l2_mem_sched_col_offset_column_id_bit4             )
,.gc_cr_l2_mem_sched_col_offset_column_id_bit5             ( gc_cr_l2_mem_sched_col_offset_column_id_bit5             )
,.gc_cr_l2_mem_sched_col_offset_column_id_bit6             ( gc_cr_l2_mem_sched_col_offset_column_id_bit6             )
,.gc_cr_l2_mem_sched_col_offset_column_id_bit7             ( gc_cr_l2_mem_sched_col_offset_column_id_bit7             )
    
,.gc_cr_l2_mem_sched_bank_offset_bank_id_bit0              ( gc_cr_l2_mem_sched_bank_offset_bank_id_bit0              )
,.gc_cr_l2_mem_sched_bank_offset_bank_id_bit1              ( gc_cr_l2_mem_sched_bank_offset_bank_id_bit1              )
,.gc_cr_l2_mem_sched_bank_offset_bank_id_bit2              ( gc_cr_l2_mem_sched_bank_offset_bank_id_bit2              )
,.gc_cr_l2_mem_sched_bank_offset_bank_id_bit3              ( gc_cr_l2_mem_sched_bank_offset_bank_id_bit3              )
,.gc_cr_l2_mem_sched_bank_offset_bank_id_bit4              ( gc_cr_l2_mem_sched_bank_offset_bank_id_bit4              )
    
,.gc_cr_l2_mem_sched_row_parti_row_id_bit0                 ( gc_cr_l2_mem_sched_row_parti_row_id_bit0                 )
,.gc_cr_l2_mem_sched_row_parti_row_id_bit1                 ( gc_cr_l2_mem_sched_row_parti_row_id_bit1                 )
,.gc_cr_l2_mem_sched_row_parti_row_id_bit2                 ( gc_cr_l2_mem_sched_row_parti_row_id_bit2                 )
,.gc_cr_l2_mem_sched_row_parti_row_id_bit3                 ( gc_cr_l2_mem_sched_row_parti_row_id_bit3                 )
,.gc_cr_l2_mem_sched_row_parti_row_id_bit4                 ( gc_cr_l2_mem_sched_row_parti_row_id_bit4                 )
,.gc_cr_l2_mem_sched_row_parti_row_id_bit5                 ( gc_cr_l2_mem_sched_row_parti_row_id_bit5                 )
,.gc_cr_l2_mem_sched_row_parti_row_id_bit6                 ( gc_cr_l2_mem_sched_row_parti_row_id_bit6                 )
,.gc_cr_l2_mem_sched_row_parti_row_id_bit7                 ( gc_cr_l2_mem_sched_row_parti_row_id_bit7                 )
,.gc_cr_l2_mem_sched_row_partii_row_id_bit8                ( gc_cr_l2_mem_sched_row_partii_row_id_bit8                )
,.gc_cr_l2_mem_sched_row_partii_row_id_bit9                ( gc_cr_l2_mem_sched_row_partii_row_id_bit9                )
,.gc_cr_l2_mem_sched_row_partii_row_id_bit10               ( gc_cr_l2_mem_sched_row_partii_row_id_bit10               )
,.gc_cr_l2_mem_sched_row_partii_row_id_bit11               ( gc_cr_l2_mem_sched_row_partii_row_id_bit11               )
,.gc_cr_l2_mem_sched_row_partii_row_id_bit12               ( gc_cr_l2_mem_sched_row_partii_row_id_bit12               )
,.gc_cr_l2_mem_sched_row_partii_row_id_bit13               ( gc_cr_l2_mem_sched_row_partii_row_id_bit13               )
,.gc_cr_l2_mem_sched_row_partii_row_id_bit14               ( gc_cr_l2_mem_sched_row_partii_row_id_bit14               )
,.gc_cr_l2_mem_sched_row_partii_row_id_bit15               ( gc_cr_l2_mem_sched_row_partii_row_id_bit15               )
,.gc_cr_l2_mem_sched_row_partiii_row_id_bit16              ( gc_cr_l2_mem_sched_row_partiii_row_id_bit16              )
,.gc_cr_l2_mem_sched_row_partiii_row_id_bit17              ( gc_cr_l2_mem_sched_row_partiii_row_id_bit17              )

,.gc_cr_pwr_man_hysteresis_value                           ( gc_cr_pwr_man_hysteresis_value                           )

,.gc_cr_crm_reset_clk_ctrl                                 ( gc_cr_crm_reset_clk_ctrl                                 )

,.gc_cr_l2_cfi_operation_notify                            ( gc_cr_l2_cfi_operation_notify                            )
,.gc_cr_l2_cfi_operation_rdnotify                          ( gc_cr_l2_cfi_operation_rdnotify                          )
,.gc_cr_l2_cmd_notify                                      ( gc_cr_l2_cmd_notify                                      )
,.gc_cr_l2_cmd_rdnotify                                    ( gc_cr_l2_cmd_rdnotify                                    )
,.gc_cr_cu_lms_fp32_denormal_en                            ( gc_cr_cu_lms_fp32_denormal_en                            )
,.gc_cr_perf_mon1_enable                                   ( gc_cr_perf_mon1_enable                                   )
,.gc_cr_perf_mon1_time_stamp_enable                        (                                                          )
,.gc_cr_perf_mon1_time_slot                                (                                                          )
,.gc_cr_perf_mon1_fence_interval                           (                                                          )


// register gc_cr_perf_mon4 (0x4720)
,.gc_cr_perf_mon4_cu_group_id                              (                                                          )
,.gc_cr_perf_mon4_spc_group_id                             (                                                          )
,.gc_cr_perf_mon4_gpc_group_id                             (                                                          )
,.gc_cr_perf_mon4_l2g_group_id                             ( gc_cr_perf_mon4_l2g_group_id                             )
,.gc_cr_perf_mon4_cp_group_id                              (                                                          )
,.gc_cr_perf_mon4_ce_group_id                              (                                                          ) ) ;

gc_l2_bank_notify_maskout
i_gc_l2_bank_notify_maskout      (
.clk                             ( crg_aligned_clk                 ) ,
.resetn                          ( crg_aligned_resetn              ) ,

.socif_valid                     ( socif_valid                     ) ,
.socif_rec                       ( socif_rec                       ) ,

.i_gc_cr_l2_cfi_operation_notify ( gc_cr_l2_cfi_operation_notify   ) ,
.i_gc_cr_l2_cmd_notify           ( gc_cr_l2_cmd_notify             ) ,
.o_gc_cr_l2_cfi_operation_notify ( o_gc_cr_l2_cfi_operation_notify ) ,
.o_gc_cr_l2_cmd_notify           ( o_gc_cr_l2_cmd_notify           ));
endmodule
// Local Variables:
// verilog-library-directories:("./" ) 
// End:
