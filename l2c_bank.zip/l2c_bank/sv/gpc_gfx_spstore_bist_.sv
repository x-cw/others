/*

 * #==========================================================================#
 * |                                                                          |
 * |  Copyright (c) 2022, Fantasy Technologies Limited and/or its         |
 * |  affiliated group companies ("Fantasy"). All rights reserved.        |
 * |  No part of this content, either material or conceptual may be copied    |
 * |  or distributed, transmitted, transcribed, stored in a retrieval system  |
 * |  or translated into any human or computer language in any form by any    |
 * |  means, electronic, mechanical manual, or otherwise, or disclosed to     |
 * |  third parties without the express written permission of Fantasy.    |
 * |                                                                          |
 * #==========================================================================#

 */

// ////////////////////////////////////////////////////////////////////////////-
// entity:  gpc_gfx_spstore_bist
//
// purpose: Single port synchronous RAM with configurable write word partitions
//          and enabling the optional inclusion of a BIST wrapper.
//
// +////////////////////////-+////-+////-+////////+////////////////+
// | gpc_gfx_spstore_        | RAM | Reg | Bypass | Design         |
// |             w,p,d,log2d | O/P | O/P | Input  | Suitability    |
// +////////////////////////-+////-+////-+////////+////////////////+
// | _.vhd & _novital.vhd    | Yes |     |        | Fundamental    |
// | bist.vhdm               | Yes |     |        | Low level only |<<<
// | gen_bist_r.vhd          |     | Yes |        | Standard use   |
// | pipeline_gen_bist_r.vhd |     | Yes |        | Standard use   |
// | bypass_gen_bist_r.vhd   | Yes | Yes |  Yes   | Standard use   |
// | bpout_gen_bist_r.vhd    | Yes | Yes |        | Standard use   |
// | flexible_gen_bist_r.vhd | Yes | Yes |  Yes   | Standard use   |
// +////////////////////////-+////-+////-+////////+////////////////+
//
// hierarchy: This is *NOT* an RTL designer's standard component
//
//        gpc_gfx_spstore_[pipeline|bypass]_gen_bist_r
//         |
//         +- gpc_gfx_spstore_bist                     << YOU ARE HERE
//             |
//             +- gpc_gfx_spstore
//             |
//             +- [ gpc_gfx_bistwrap_sing ]
//
// ////////////////////////////////////////////////////////////////////////////-

// DIMENSIONS
//   Physical generics: w, d, p, log2d
//
//                        width
//              <////////// w //////////>
//
//              +//////////////////////-+   ^
//              |_______________________|   |
//              |_______________________|   |  d
//              |_______________________|      e
//              |                       |   d  p
//              |                       |      t
//              :                       :   |  h
//              |                       |   |
//              +//////////////////////-+   v
//                         w/p *
//              <- p -><- p -> .. <- p ->
//                      partitions
//
//   All partitions are equal in size. In other words, the generic w is an
//   integer multiple of generic p.
//
//   Example partition:
//      [w = 128, p = 32] => w/p = 4 partitions => 4 write enables

// PORTS
//   +////////////////////////////////////////////////////////-+
//   | name          |  bits  |dir| description                |
//   +////////////////////////////////////////////////////////-+
//   | addr          | log2d  | i | address                    |
//   | c_en          |   1    | i | chip enable (ACTIVE LOW)   |
//   | rd_data_ram   |   w    | o | read data                  |
//   |               |        |   |                            |
//   | wr_data       |   w    | i | write data ((w/p)*p bits)  |
//   | wr_en         |  w/p   | i | write enables (ACTIVE LOW) |
//   |               |        |   |                            |
//   | clk           |   1    | i | common r/w clock           |
//   | resetn        |   1    | i | reset to BIST (ACTIVE LOW) |
//   |               |        |   |                            |
//   | bist_in       |f(w,p,d)| i | input from BIST controller |
//   | bist_out      |f(w,p,d)| o | result to BIST controller  |
//   +////////////////////////////////////////////////////////-+

// BEHAVIOURIAL MODEL
//   Functional behaviour is similar to gpc_gfx_spstore but this hierarchical level
//   renames the ports and optionally adds the BIST wrapper
//
//   Read latency:  1 clock
//   Write latency: 1 clock
//
//                      +////////////////////////////-+
//                      |     gpc_gfx_spstore         |
//                      |                             |
//         addr     ///-|-*///////////////////////.   |
//         c_en     ////|-|//-*//////////////////.|   |
//                      | |   |                  ||   |
//                      | | +////+   +////-+   +////+ |
//                      | '-| wr |   |     |   | rd | |
//         wr_en    ///-|//-|proc|-/-| mem |-/-|proc|-|///-> rd_data_ram
//         wr_data  ///-|//-|    |   |     |   |    | |
//                      |   |    |  +|>    |  +|>   | |
//                      |   +////+  |+////-+  |+////+ |
//                      |           |         |       |
//         clk      //*-|//////////-*////////-'       |
//                    | +////////////////////////////-+
//                    | +////////////////////////////-+
//                    '-|                             |
//         bist_in  ///-|  [ gpc_gfx_bistwrap_sing ]  |///-> bist_out
//         resetn   ////|                             |
//                      +////////////////////////////-+
//   Notes:
//   + In addition to wr_en, writes require c_en to be asserted (low)
//   + There is no writethrough transparency. The value on wr_data does not
//     appear on rd_data_ram after a write.

// OPTIONAL UTILITY GENERIC
//   id : integer value that can be assigned to each instance (default 0)
//                                                                      -=:PB=-
// ////////////////////////////////////////////////////////////////////////////-

module gpc_gfx_spstore_bist_
   import gpc_gfx_rambist_pack_::*;



#(
      parameter int                                      w                                                            = 32             ,
      parameter int                                      p                                                            = 32             ,
      parameter int                                      d                                                            = 8              ,
      parameter int                                      log2d                                                        = 3              ,
      parameter int                                      ECC                                                          = 0              ,    // 0=disable ECC; 1=enable SEC-DED; 2=enable Parity



      parameter int                                      id                                                           = 0                   // unique value per instance 
)
(
      input    logic                                                        clk                                     ,
   
      //W240 relates to inputs that are not used. This is the case for the resetn input in certain configurations
      //where MEMBIST or ECC is not enabled.
      //spyglass disable_block -rule "W240"
      input    logic                                                        resetn                                  ,
      //spyglass enable_block -rule "W240"

      input    logic                                                        c_en                                    ,
      input    logic [ ( w / p ) - 1 : 0 ]                                  wr_en                                   ,
      input    logic [ log2d - 1 : 0 ]                                      addr                                    ,
      input    logic [ w - 1 : 0 ]                                          wr_data                                 ,
      output   logic [ w - 1 : 0 ]                                          rd_data_ram                             ,














      // bist signals
      input    logic [ spstore_in ( w , p , d , ECC ) - 1 : 0 ]             bist_in                                 ,
      output   logic [ spstore_out ( w , p , d , ECC ) - 1 : 0 ]            bist_out                                ,
      input    logic                                                        tst_gclkenable                           
);
   //synopsys translate_off
   import gpc_gfx_backdoor_pkg_::*;
   //synopsys translate_on












   ///////////////////////////////////////////////
   // backdoor access
   ///////////////////////////////////////////////
   //synopsys translate_off






    `ifndef SRAM_MODEL_SIM
         //point to the backdoor acccess class in the sub-module   
         backdoor_access_fwd #(.w(w)) backdoor = new();
         initial backdoor.inst = str.backdoor;
    `endif



































































   //synopsys translate_on
   ///////////////////////////////////////////////
   // END backdoor access
   ///////////////////////////////////////////////












































































































































































































































































   logic [ ( w / p ) - 1 : 0 ]                   wen_mux                                 ;
   logic [ w - 1 : 0 ]                           q_ram                                   ;
   logic [ w - 1 : 0 ]                           di_mux                                  ;



   logic                                         cen_mux                                 ;
//   signal wen_mux  : std_logic_vector((w/p)-1 downto 0);
   logic [ log2d - 1 : 0 ]                       addr_mux                                ;




   

   // CUSTOMER BIST IMPLEMENTATION EXPECTED HERE


































   assign di_mux = wr_data ;
   assign rd_data_ram = q_ram ;
   assign wen_mux = wr_en ;
   assign cen_mux = c_en ;
   assign addr_mux = addr ;


   assign bist_out = '0 ;

   gpc_gfx_spstore
      #(





         .w                               (w)                                          ,
         .p                               (p)                                          ,

         .d                               (d)                                          ,
         .log2d                           (log2d)                                      ,
         .id                              (id)                                           
         )
      str
      (
         .CLK                             (clk)                                        ,
         .CEN                             (cen_mux)                                    ,
         .WEN                             (wen_mux)                                    ,
         .A                               (addr_mux)                                   ,
         .DI                              (di_mux)                                     ,
         .Q                               (q_ram)                                      ,
         .L2M                             ()                                           ,
         .SRAM                            ()                                           ,
         .TE                              (tst_gclkenable)                               
         );






























































































































































































































































































































































































































































































































































































































































endmodule // gpc_gfx_spstore_bist

