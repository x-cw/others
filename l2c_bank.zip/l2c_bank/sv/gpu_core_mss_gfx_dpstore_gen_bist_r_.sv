/*

 * #==========================================================================#
 * |                                                                          |
 * |  Copyright (c) 2022, Fantasy Technologies Limited and/or its         |
 * |  affiliated group companies ("Fantasy"). All rights reserved.        |
 * |  No part of this content, either material or conceptual may be copied    |
 * |  or distributed, transmitted, transcribed, stored in a retrieval system  |
 * |  or translated into any human or computer language in any form by any    |
 * |  means, electronic, mechanical manual, or otherwise, or disclosed to     |
 * |  third parties without the express written permission of Fantasy.    |
 * |                                                                          |
 * #==========================================================================#

 */

// ////////////////////////////////////////////////////////////////////////////-
// entity:  gpu_core_mss_gfx_dpstore_gen_bist_r
//
// purpose: Dual port synchronous RAM with configurable write word partitions
//          and back end read register to help achieve timing closure
//
// +////////////////////////-+////////+////-+////-+////////+////////////////+
// | gpu_core_gfx_dpstore_        |        | RAM | Reg | Bypass | Design         |
// |             w,p,d,log2d | Clocks | O/P | O/P | Input  | Suitability    |
// +////////////////////////-+////////+////-+////-+////////+////////////////+
// | _.vhd & _novital.vhd    |  2:RW  | Yes |     |        | Fundamental    |
// | bist.vhdm               | single | Yes |     |        | Low level only |
// | bist_async.vhdm         |  2:RW  | Yes |     |        | Low level only |
// | gen_bist_r.vhd          | single |     | Yes |        | Standard use   |<<<
// | pipeline_gen_bist_r.vhd | single |     | Yes |        | Standard use   |
// | bypass_gen_bist_r.vhd   | single |     | Yes |  Yes   | Standard use   |
// | flexible_gen_bist_r.vhd | single | Yes | Yes |  Yes   | Standard use   |
// | flexible_gen_bist_r     |        |     |     |        |                |
// |              _async.vhd |  2:RW  | Yes | Yes |  Yes   | Standard use   |
// +////////////////////////-+////////+////-+////-+////////+////////////////+
//
// hierarchy: This is an RTL designer's standard component
//
//        gpu_core_gfx_dpstore_gen_bist_r              << YOU ARE HERE
//         |
//         +- gpu_core_gfx_dpstore_bist
//             |
//             +- gpu_core_gfx_dpstore
//             |
//             +- [ gpu_core_gfx_bistwrap ]
//
// ////////////////////////////////////////////////////////////////////////////-

// DIMENSIONS
//   Physical generics: w, d, p, log2d, wrcen(*), write_skid, read_skid
//
//                        width
//              <////////// w //////////>
//
//              +//////////////////////-+   ^
//              |_______________________|   |
//              |_______________________|   |  d
//              |_______________________|      e
//              |                       |   d  p
//              |                       |      t
//              :                       :   |  h
//              |                       |   |
//              +//////////////////////-+   v
//                         w/p *
//              <- p -><- p -> .. <- p ->
//                      partitions
//
//   All partitions are equal in size. In other words, the generic w is an
//   integer multiple of generic p.
//
//   Example partition:
//      [w = 128, p = 32] => w/p = 4 partitions => 4 write enables
//
//   Skid registers:
//      Added when either or both write_skid/read_skid = '1'

// PORTS
//   +////////////////////////////////////////////////////////-+
//   | name          |  bits  |dir| description                |
//   +////////////////////////////////////////////////////////-+
//   | rd_addr       | log2d  | i | read address               |
//   | rd_en         |   1    | i | read strobe (ACTIVE LOW)   |
//   | rd_data       |   w    | o | read data                  |
//   |               |        |   |                            |
//   | wr_addr       | log2d  | i | write address              |
//   | wr_data       |   w    | i | write data ((w/p)*p bits)  |
//   | wr_en *       |(w/p)+1*| i | write enables*(ACTIVE LOW) |
//   |               |        |   |                            |
//   | clk           |   1    | i | common r/w clock           |
//   | resetn        |   1    | i | reset to BIST (ACTIVE LOW) |
//   |               |        |   |                            |
//   | bist_in       |f(w,p,d)| i | input from BIST controller |
//   | bist_out      |f(w,p,d)| o | result to BIST controller  |
//   +////////////////////////////////////////////////////////-+
//
//  (*) - wr_en width can be configured with generic wrcen to have an extra bit:
//
//    wrcen
//      0 : w/p bits => one ACTIVE LOW write enable per word partition (default)
//      1 : w/p+1 bits => one ADDITIONAL (ACTIVE LOW) write enable
//
//      If configured, the extra bit indicates that any one of the per word
//      partition write enables is asserted.

// BEHAVIOURIAL MODEL
//   Functional behaviour is similar to gpu_core_gfx_dpstore_bist but this hierarchical
//   level adds a back end read data register for timing purposes
//
//   Read latency:  2 clocks
//   Write latency: 1 clock
//
//                     +////////////////////////////////-+
//                     |      gpu_core_gfx_dpstore_bist       |
//                     |                                 |
//                     |  +//////////////////////////-+  |
//                     |  |     gpu_core_gfx_dpstore       |  |
//                     |  |                           |  |
//      rd_addr, rd_en-|//|//////////////////////.    |  |
//                     |  |                      |    |  |
//                     |  | +////+   +////-+   +////+ |  |  +////+
//      wr_addr    ///-|//|-| wr |   |     |   | rd | |  |  |    |
//      wr_en      ///-|//|-|proc|-/-| mem |-/-|proc|-|//|//|    |///-> rd_data
//      wr_data    ///-|//|-|    |   |     |   |    | |  |  |    |
//                     |  | |    |  +|>    |  +|>   | |  | +|>   |
//                     |  | +////+  |+////-+  |+////+ |  | |+////+
//                     |  |         |         |       |  | |
//      clk        ////|//|////////-*////////-*//////-|//|-'
//                     |  +//////////////////////////-+  |
//                     |  +//////////////////////////-+  |
//                     |  |                           |  |
//      bist_in    ///-|//|   [ gpu_core_gfx_bistwrap ]    |//|///////////-> bist_out
//      resetn     ////|//|                           |  |
//                     |  +//////////////////////////-+  |
//                     +////////////////////////////////-+
//
// Read Skid Register
//   The current read address is compared against the cached last read address.
//   If it matches, then the data in the output register can be re-used without
//   having to access the RAM. This saves power.
//
//   The read skid register is updated on a miss i.e. when a RAM macro read
//   was required.
//
// Write Skid Register
//   Unmasked writes are cached. If a read address subsequently matches the
//   cached value, the read data can be supplied from the register rather than
//   the RAM. This can save power.
//
//   The write skid register is updated on new unmasked write, and invalidated
//   altogether on a masked write.

// OPTIONAL UTILITY GENERICS
//   id       : integer value that can be assigned to each instance (default 0)
//                                                                      -=:PB=-
// ////////////////////////////////////////////////////////////////////////////-

module gpu_core_mss_gfx_dpstore_gen_bist_r_ 
   import gpc_gfx_rambist_pack_::*;
  #(
    parameter int   w = 32,
    parameter int   p = 32,
    parameter int   d = 16,
    parameter int   log2d = 4,
    parameter int   wrcen = 0,
    parameter int   ECC = 0,



    parameter int   id = 0,
    parameter logic write_skid = 1'b0,
    parameter logic read_skid = 1'b0
   )
   (
    input  logic                                      clk,
    input  logic                                      resetn,
    input  logic                                      rd_en,
    input  logic [log2d - 1 : 0]                      rd_addr,
    output logic [w - 1 : 0]                          rd_data,
    input  logic [(w / p) + wrcen - 1 : 0]            wr_en,
    input  logic [log2d - 1 : 0]                      wr_addr,
    input  logic [w - 1 : 0]                          wr_data,






    input  logic [dpstore_in (w, p, d, ECC) - 1 : 0]  bist_in,
    output logic [dpstore_out (w, p, d, ECC) - 1 : 0] bist_out,
    input  logic                                      tst_gclkenable
);

   








   logic                                              rd_en_r;
   logic [w - 1 : 0]                                  rd_data_ram;
   logic [w - 1 : 0]                                  rd_data_ram_r;
   // Write-triggered skid signals
   logic                                              rd_wr_skid;
   // Read-triggered skid signals
   logic                                              rd_rd_skid;
   // Global skid signals
   logic                                              gated_rd_en;
   logic [w - 1 : 0]                                  rd_data_mux;

   ///////////////////////////////////////////////
   // backdoor access
   ///////////////////////////////////////////////




   ///////////////////////////////////////////////
   ///////////////////////////////////////////////
   // END backdoor access
   ///////////////////////////////////////////////


   gpu_core_mss_gfx_dpstore_wrap_
     #(
       .w(w),
       .p(p),
       .d(d),
       .log2d(log2d),
       .wrcen(wrcen),
       .ECC(ECC),



       .id(id)
       )
       i_gpu_core_mss_gfx_dpstore_wrap
        (
         .clk(clk),
         .resetn(resetn),
         .rd_en(gated_rd_en),
         .rd_addr(rd_addr),
         .rd_data_ram(rd_data_ram),
         .wr_en(wr_en),
         .wr_addr(wr_addr),
         .wr_data(wr_data),






         .bist_in(bist_in),
         .bist_out(bist_out),
         .tst_gclkenable(tst_gclkenable)
        );

   // //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
   // Skid register additions
   // //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
   // rd_skid is active high and rd_en is active low; gated_rd_en is active low.
   assign gated_rd_en = rd_en | rd_rd_skid | rd_wr_skid;


   // write-triggered skid registers
   generate
      if ((write_skid == 1'b1)) begin : g_write_skid
         logic                 full_write;
         logic                 masked_write;
         logic [w - 1 : 0]     data_wr_skid;
         logic [log2d - 1 : 0] addr_wr_skid;
         logic                 valid_wr_skid;
         logic                 rd_wr_skid_r;













         // asserted when the write is full
         always_comb begin : p_full_write
            if (((| wr_en) == 1'b0)) begin
               full_write = 1'b1;
            end else begin
               full_write = 1'b0;
            end
         end : p_full_write


         // asserted when the write is masked
         if ((wrcen == 1)) begin : g_wrcen_masked
            always_comb begin : p_masked_write
               if (((full_write == 1'b0) & ((& wr_en [ w / p - 1 : 0 ]) == 1'b0) & (wr_en [ w / p ] == 1'b0))) begin
                  masked_write = 1'b1;
               end else begin
                  masked_write = 1'b0;
               end
            end : p_masked_write
         end : g_wrcen_masked

         if ((wrcen == 0)) begin : g_nowrcen_masked
            always_comb begin : p_masked_write
               if (((full_write == 1'b0) & ((& wr_en) == 1'b0))) begin
                  masked_write = 1'b1;
               end else begin
                  masked_write = 1'b0;
               end
            end : p_masked_write
         end : g_nowrcen_masked

         // skid register
         always_ff@(posedge clk or negedge  resetn) begin : p_wr_skid
            if ((resetn == 1'b0)) begin
               data_wr_skid <= ('0);
               addr_wr_skid <= ('0);
            end else begin
               if (((full_write == 1'b1) & (rd_wr_skid == 1'b0))) begin
                  addr_wr_skid <= wr_addr;
               end
               if (((full_write == 1'b1) & ((rd_wr_skid == 1'b0) | (wr_addr == addr_wr_skid)))) begin
                  data_wr_skid <= wr_data;
               end
            end
         end : p_wr_skid

         // valid skid register
         always_ff@(posedge clk or negedge  resetn) begin : p_valid_wr_skid
            if ((resetn == 1'b0)) begin
               valid_wr_skid <= 1'b0;
            end else begin
               if (((full_write == 1'b1) & (rd_wr_skid == 1'b0))) begin
                  valid_wr_skid <= 1'b1;
               end else if (((masked_write == 1'b1) & (wr_addr == addr_wr_skid))) begin
                  valid_wr_skid <= 1'b0;
               end
            end
         end : p_valid_wr_skid

         // read skid signal, asserted when skid register can be read
         always_comb begin : p_rd_wr_skid
            if (((rd_addr == addr_wr_skid) & (valid_wr_skid == 1'b1) & (rd_en == 1'b0))) begin
               rd_wr_skid = 1'b1;
            end else begin
               rd_wr_skid = 1'b0;
            end
         end : p_rd_wr_skid

         // registered read skid signal for timing purposes
         always_ff@(posedge clk or negedge  resetn) begin : p_rd_wr_skid_r
            if ((resetn == 1'b0)) begin
               rd_wr_skid_r <= 1'b0;
            end else begin
               if ((rd_wr_skid_r != rd_wr_skid)) begin
                  rd_wr_skid_r <= rd_wr_skid;
               end
            end
         end : p_rd_wr_skid_r

         // read data multiplexer
         assign rd_data_mux = (rd_wr_skid_r == 1'b1) ? data_wr_skid : rd_data_ram ;

      end : g_write_skid

      if ((write_skid == 1'b0)) begin : g_no_write_skid

         assign rd_wr_skid = 1'b0;
         assign rd_data_mux = rd_data_ram;

      end : g_no_write_skid


      // generate for read-triggered skid registers
      if ((read_skid == 1'b1)) begin : g_read_skid
         logic                 read_en_r;
         logic [log2d - 1 : 0] addr_rd_skid;
         logic                 valid_rd_skid;

         always_ff@(posedge clk or negedge  resetn) begin : p_read_en_r
            if ((resetn == 1'b0)) begin
               read_en_r <= 1'b0;
            end else begin
               if ((read_en_r != rd_en)) begin
                  read_en_r <= rd_en;
               end
            end
         end : p_read_en_r

         always_ff@(posedge clk or negedge  resetn) begin : p_addr_rd_skid
            if ((resetn == 1'b0)) begin
               addr_rd_skid <= ('0);
            end else begin
               if (((rd_addr != addr_rd_skid) & (rd_en == 1'b0))) begin
                  addr_rd_skid <= rd_addr;
               end
            end
         end : p_addr_rd_skid

         always_comb begin : p_rd_rd_skid
            rd_rd_skid = 1'b0;

            if (((valid_rd_skid == 1'b1) & (rd_en == 1'b0) & (read_en_r == 1'b0) & (rd_addr == addr_rd_skid))) begin
               rd_rd_skid = 1'b1;
            end
         end : p_rd_rd_skid

         always_ff@(posedge clk or negedge  resetn) begin : p_valid_rd_skid
            if ((resetn == 1'b0)) begin
               valid_rd_skid <= 1'b0;
            end else begin
               if ((((wr_addr == addr_rd_skid) | ((wr_addr == rd_addr) & (rd_en == 1'b0))) & ((& wr_en) == 1'b0))) begin
                  valid_rd_skid <= 1'b0;
               end else if ((rd_en == 1'b0)) begin
                  valid_rd_skid <= 1'b1;
               end
            end
         end : p_valid_rd_skid
      end : g_read_skid

      if ((read_skid == 1'b0)) begin : g_no_read_skid
         assign rd_rd_skid = 1'b0;
      end : g_no_read_skid
   endgenerate

   // //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
   // end of skid register additions
   // //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

   // //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
   // Reset Read enable register to fix X-prop issues in GLS
   // //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

   always_ff@(posedge clk or negedge  resetn) begin
      if (resetn == 1'b0) begin
         rd_en_r <= 1'b1;
      end else begin
         rd_en_r <= rd_en | rd_rd_skid;
      end
   end

   // //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
   // Register the Ram Data for timing
   // //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
   always_ff@(posedge clk) begin
      if (rd_en_r == 1'b0) begin
         rd_data_ram_r <= rd_data_mux;
      end
   end

   assign rd_data = rd_data_ram_r;

endmodule
