module mutex_ctrl  
import pkg_cp_top::*; 
#(
parameter MUTEX_CTRL_REQ_NUM =8  // spc_mutex_ctrl =8; gpc_mutex_ctrl =2;
)
(
    input  clk,
    input  resetn,
    output idle,

    mutexctrl_req_if.slave       mutexctrl_req_slv     [ MUTEX_CTRL_REQ_NUM-1:0] ,
    mutexctrl_release_if.slave   mutexctrl_release_slv [ MUTEX_CTRL_REQ_NUM-1:0] ,
    mutexctrl_grant_if.master    mutexctrl_grant_mst   [ MUTEX_CTRL_REQ_NUM-1:0] ,

    mutexctrl_req_if.master      mutexctrl_req_mst     , 
    mutexctrl_release_if.master  mutexctrl_release_mst , 
    mutexctrl_grant_if.slave     mutexctrl_grant_slv    
);


logic [MUTEX_CTRL_REQ_NUM -1 : 0]                        slv_mutexctrl_req_valid;
//logic [MUTEX_CTRL_REQ_NUM -1 : 0]                        slv_mutexctrl_req_enable;
logic [MUTEX_CTRL_REQ_NUM -1 : 0][MUTEX_NUM_LOG2 -1:0]   slv_mutexctrl_req_sel;
logic [MUTEX_CTRL_REQ_NUM -1 : 0]                        slv_mutexctrl_release_valid;
logic [MUTEX_CTRL_REQ_NUM -1 : 0][MUTEX_NUM -1:0]        slv_mutexctrl_release_sel; 
logic [MUTEX_CTRL_REQ_NUM -1 : 0]                        mst_mutexctrl_grant_valid;
logic [MUTEX_CTRL_REQ_NUM -1 : 0][MUTEX_NUM -1:0]        mst_mutexctrl_grant_grant; 

logic                         mst_mutexctrl_req_valid;
logic                         mst_mutexctrl_req_enable;
logic [MUTEX_NUM_LOG2 -1:0]   mst_mutexctrl_req_sel;
logic                         mst_mutexctrl_release_valid;
logic [MUTEX_NUM -1:0]        mst_mutexctrl_release_sel; 
logic                         mst_mutexctrl_release_valid_comb;
logic [MUTEX_NUM -1:0]        mst_mutexctrl_release_sel_comb; 
logic                         slv_mutexctrl_grant_valid;
logic [MUTEX_NUM -1:0]        slv_mutexctrl_grant_grant;  


typedef enum logic [1:0] {
   MUTEX_UNLOCK = 2'd0,
   MUTEX_WAIT_GNT = 2'd1, // wait grant
   MUTEX_LOCK = 2'd2
}mutex_state_type;

localparam REQ_NUM = MUTEX_CTRL_REQ_NUM;
localparam REQ_NUM_LOG2 = $clog2(REQ_NUM);

logic [REQ_NUM -1 :0 ] [MUTEX_NUM -1:0]      mutex_req_valid_pending_buffer; 
logic [MUTEX_NUM -1 : 0] [REQ_NUM -1 : 0] each_mutex_valids_vector;
mutex_state_type [MUTEX_NUM -1 : 0] mutex_state,n_mutex_state;
logic [MUTEX_NUM -1 : 0] send_to_nxt_req_valids_vector;
logic [MUTEX_NUM_LOG2 -1 : 0] send_to_nxt_previous_selected_req, send_to_nxt_current_selected_req;
logic [MUTEX_NUM -1 : 0][REQ_NUM_LOG2 -1 : 0] each_mutex_previous_selected_req,each_mutex_current_selected_req; 
logic [MUTEX_NUM -1 : 0] each_mutexctrl_grant_valid;
logic [MUTEX_NUM -1 : 0] valid_i, ready_i;
logic  out_bif_req_state, n_out_bif_req_state;


// interface 
generate
   for(genvar i=0; i<MUTEX_CTRL_REQ_NUM; i++)begin 
      assign slv_mutexctrl_req_valid[i]      = mutexctrl_req_slv[i].valid        ; 
      assign mutexctrl_req_slv[i].enable     = 1'b1;//slv_mutexctrl_req_enable[i]       ;// 
      assign slv_mutexctrl_req_sel[i]        = mutexctrl_req_slv[i].data_bus     ; 
      assign slv_mutexctrl_release_valid[i]  = mutexctrl_release_slv[i].valid    ; 
      assign slv_mutexctrl_release_sel[i]    = mutexctrl_release_slv[i].data_bus ; 
      assign mutexctrl_grant_mst[i].valid    = mst_mutexctrl_grant_valid[i]      ; 
      assign mutexctrl_grant_mst[i].data_bus = mst_mutexctrl_grant_grant[i]      ; 
   end 
endgenerate 

assign mutexctrl_req_mst.valid        = mst_mutexctrl_req_valid      ; 
assign mst_mutexctrl_req_enable       = mutexctrl_req_mst.enable     ; 
assign mutexctrl_req_mst.data_bus     = mst_mutexctrl_req_sel        ; 
assign mutexctrl_release_mst.valid    = mst_mutexctrl_release_valid  ; 
assign mutexctrl_release_mst.data_bus = mst_mutexctrl_release_sel    ; 
assign slv_mutexctrl_grant_valid      = mutexctrl_grant_slv.valid    ; 
assign slv_mutexctrl_grant_grant      = mutexctrl_grant_slv.data_bus ; 

logic [MUTEX_NUM-1 :0] [MUTEX_CTRL_REQ_NUM -1 :0] slv_mutexctrl_release_sel_t;
always_comb begin 
   for(integer i=0; i<MUTEX_NUM; i++)begin 
      for(integer j=0; j<MUTEX_CTRL_REQ_NUM; j++)begin 
         slv_mutexctrl_release_sel_t[i][j] = slv_mutexctrl_release_sel[j][i] & slv_mutexctrl_release_valid[j];
      end
   end
end

// release or operation
assign mst_mutexctrl_release_valid_comb = |slv_mutexctrl_release_valid;
always_comb begin 
   for(integer i=0; i<MUTEX_NUM; i++)begin 
      mst_mutexctrl_release_sel_comb[i] = | slv_mutexctrl_release_sel_t[i];
   end
end 

always_ff @(posedge clk or negedge resetn)begin
   if(resetn == 1'b0)begin
      mst_mutexctrl_release_valid <= 1'b0;
      mst_mutexctrl_release_sel   <= 'b0;
   end else begin
      mst_mutexctrl_release_valid <= mst_mutexctrl_release_valid_comb;
      mst_mutexctrl_release_sel   <= mst_mutexctrl_release_sel_comb;
   end
end


logic [MUTEX_CTRL_REQ_NUM -1 :0] [MUTEX_NUM -1 :0] grant_valid_array;

always_comb begin
   for(integer i=0; i<MUTEX_CTRL_REQ_NUM; i++)begin 
      //grant_valid_array[i] = '0; 
      for(integer j=0; j<MUTEX_NUM; j++)begin 
         grant_valid_array[i][j] =  ( (each_mutexctrl_grant_valid[j] == 1'b1) && ( each_mutex_current_selected_req[j] == i )) ;
      end
   end 
end

// grant to requestor 
always_comb begin 
   // mst_mutexctrl_grant_valid = '0; 
   for(integer i=0; i<MUTEX_CTRL_REQ_NUM; i++)begin 
      //mst_mutexctrl_grant_grant[i] = '0;
      mst_mutexctrl_grant_valid[i] = | grant_valid_array[i]; 
      for(integer j=0; j<MUTEX_NUM; j++)begin 
         mst_mutexctrl_grant_grant[i][j] = (each_mutexctrl_grant_valid[j] && each_mutex_current_selected_req[j] == i) ? 1'b1 : 1'b0;
      end 
   end 
end 

always_ff @(posedge clk or negedge resetn) begin : req_pending_buffer_array // req and grant cannot both equal 1 at the same time ,is guaranteed by requestor
   if(resetn == 1'b0)begin
      for(integer i =0 ;i<REQ_NUM ; i++)begin
         mutex_req_valid_pending_buffer[i] <= '0;
      end
   end else begin
      for(integer i =0 ;i<REQ_NUM ; i++)begin
         for(integer j =0; j<MUTEX_NUM ; j++)begin  
            if(slv_mutexctrl_req_valid[i] == 1'b1 && (slv_mutexctrl_req_sel[i] == j))begin
               mutex_req_valid_pending_buffer[i][j] <= 1'b1;
            end else if(mst_mutexctrl_grant_valid[i] == 1'b1 && mst_mutexctrl_grant_grant[i][j] == 1'b1)begin
               mutex_req_valid_pending_buffer[i][j] <= 1'b0;
            end
         end
      end
   end
end

generate 
   for(genvar i=0; i<MUTEX_NUM; i++)begin : g_each_mutex_logic

      always_ff @(posedge clk or negedge resetn)begin
         if(resetn == 1'b0)begin
            mutex_state[i] <= MUTEX_UNLOCK;
         end else begin
            mutex_state[i] <= n_mutex_state[i];
         end
      end 
      
      always_comb begin
         case (mutex_state[i]) 
            MUTEX_UNLOCK: begin
               if( valid_i[i] & ready_i[i])begin
                  n_mutex_state[i] = MUTEX_WAIT_GNT;
               end else begin
                  n_mutex_state[i] = mutex_state[i];
               end
            end 
            MUTEX_WAIT_GNT:begin
               if(slv_mutexctrl_grant_valid == 1'b1 && (slv_mutexctrl_grant_grant[i] == 1'b1))begin
                  //    n_mutex_state[i] = MUTEX_LOCK;
                  // if(mst_mutexctrl_release_valid_comb == 1'b1 && (mst_mutexctrl_release_sel_comb[i] == 1'b1))begin
                  //    n_mutex_state[i] = MUTEX_UNLOCK;
                  // end else begin
                  n_mutex_state[i] = MUTEX_LOCK;
                  // end
               end else begin
                  n_mutex_state[i] = mutex_state[i];
               end 
            end 
            default : begin  // MUTEX_LOCK
               if(mst_mutexctrl_release_valid_comb == 1'b1 && (mst_mutexctrl_release_sel_comb[i] == 1'b1))begin
                  n_mutex_state[i] = MUTEX_UNLOCK;
               end else begin
                  n_mutex_state[i] = mutex_state[i];
               end 
            end 
         endcase 
      end 
      assign  each_mutexctrl_grant_valid[i] = (mutex_state[i] == MUTEX_WAIT_GNT && (slv_mutexctrl_grant_valid == 1'b1 && (slv_mutexctrl_grant_grant[i] == 1'b1)) ) ? 1'b1 : 1'b0;

      always_ff @(posedge clk or negedge resetn)begin
         if(resetn == 1'b0)begin
            each_mutex_previous_selected_req[i] <= 'b0;
         end else if(each_mutexctrl_grant_valid[i] == 1'b1) begin
            each_mutex_previous_selected_req[i] <= each_mutex_current_selected_req[i];
         end
      end
 
      always_comb begin
         for (integer j=0; j<REQ_NUM; j++)begin
            each_mutex_valids_vector[i][j] = mutex_req_valid_pending_buffer[j][i] ; // valid =1 hold data
         end
      end 

       
      gpc_round_robin_index_arch1_ #( 
         .width         (REQ_NUM), 
         .hold_previous (1'b0) 
      ) i_gpc_round_robin_index_arch1_for_each_mutex ( 
         .valids           (each_mutex_valids_vector[i]), 
         .previous_index   (each_mutex_previous_selected_req[i]), 
         .next_index       (each_mutex_current_selected_req[i]) 
      );   
      
      // for send to next      
      assign valid_i[i] = (|each_mutex_valids_vector[i]) & (mutex_state[i] == MUTEX_UNLOCK) ;
      assign ready_i[i] = (out_bif_req_state == 'd0 & send_to_nxt_current_selected_req == i) | (out_bif_req_state == 'd1 & mst_mutexctrl_req_enable & (mst_mutexctrl_req_sel == i | send_to_nxt_current_selected_req == i));
      //always_ff @(posedge clk or negedge resetn)begin
      //   send_to_nxt_req_valids_vector[i] <= |each_mutex_valids_vector[i] && (mutex_state[i] == MUTEX_UNLOCK);
      //end
   end 
endgenerate


always_ff @(posedge clk or negedge resetn)begin
   if(~resetn)begin
      out_bif_req_state <= 'b0;
   end else begin
      out_bif_req_state <= n_out_bif_req_state;
   end
end

always_comb begin
   n_out_bif_req_state = out_bif_req_state;
   case (out_bif_req_state)
      'd0:begin // idle
         if(|valid_i)begin
            n_out_bif_req_state = 'd1;
         end 
      end
      default:begin // send 
         if(mst_mutexctrl_req_enable)begin
            if(|valid_i)begin
               n_out_bif_req_state = 'd1;
            end else begin
               n_out_bif_req_state = 'd0;
            end
         end
      end
   endcase
end
always_ff @(posedge clk or negedge resetn)begin
   if(~resetn)begin
      mst_mutexctrl_req_valid <= 'd0;
      mst_mutexctrl_req_sel <= 'd0;
      send_to_nxt_previous_selected_req <= 'b0;
   end else begin
      case (out_bif_req_state)
         'd0: begin
            if(|valid_i)begin
               mst_mutexctrl_req_valid <= 'd1;
               mst_mutexctrl_req_sel <= send_to_nxt_current_selected_req;
            end 
         end
         default: begin
            if(mst_mutexctrl_req_enable)begin
               send_to_nxt_previous_selected_req <= send_to_nxt_current_selected_req;
               //mst_mutexctrl_req_valid <= 'd0;
               if(|(valid_i))begin
                  mst_mutexctrl_req_valid <= 'd1;
                  mst_mutexctrl_req_sel <= send_to_nxt_current_selected_req;
               end else begin
                  mst_mutexctrl_req_valid <= 'd0;
               end 
            end
         end
      endcase
   end 
end

assign send_to_nxt_req_valids_vector = valid_i;
gpc_round_robin_index_arch1_ #( 
   .width         (MUTEX_NUM), 
   .hold_previous (1'b0) 
) i_gpc_round_robin_index_arch1_for_send_to_next ( 
   .valids           (send_to_nxt_req_valids_vector), 
   .previous_index   (send_to_nxt_previous_selected_req), 
   .next_index       (send_to_nxt_current_selected_req) 
);   




//always_ff @(posedge clk or negedge resetn)begin
//   if(resetn == 1'b0)begin
//      mst_mutexctrl_req_valid <= 1'b0;
//      mst_mutexctrl_req_sel   <= 'b0;
//   end else if()begin
      
logic [MUTEX_NUM-1 :0] each_mutex_idle;
logic mutex_idle;
logic [REQ_NUM-1 :0] pending_buffer_idle;
always_comb begin
   for (integer i=0; i<MUTEX_NUM; i++)begin
      each_mutex_idle[i] = mutex_state[i] == MUTEX_UNLOCK; 
   end
end 
assign mutex_idle = &each_mutex_idle;

always_comb begin
   for (integer i=0; i<REQ_NUM; i++)begin
      pending_buffer_idle[i] = | mutex_req_valid_pending_buffer[i];
   end
end 

assign idle= ~mst_mutexctrl_req_valid & ~(|valid_i) & mutex_idle  & ~(|pending_buffer_idle) & ~(|slv_mutexctrl_req_valid) & ~(mst_mutexctrl_release_valid | mst_mutexctrl_release_valid_comb);

// synopsys translate_off
// for debug  
logic [MUTEX_NUM-1:0][$clog2(MUTEX_CTRL_REQ_NUM):0]grant_mutex_id; // when mutex_lock bit is high ,grant_mutex_id is valid;
logic [MUTEX_NUM-1:0]mutex_lock ;
always_comb begin 
   mutex_lock= '0; 
   for(integer j=0; j<MUTEX_NUM; j++)begin 
      if(mutex_state[j] == MUTEX_LOCK)
         mutex_lock[j]= 1'b1; 
      else  
         mutex_lock[j]= 1'b0; 
   end 
end 

// grant to requestor 
always_ff@(posedge clk or negedge resetn) begin 
   if(~resetn)begin
      for(integer j=0; j<MUTEX_NUM; j++)begin 
         grant_mutex_id[j] = '1; 
      end
   end else begin
      for(integer j=0; j<MUTEX_NUM; j++)begin 
         if(each_mutexctrl_grant_valid[j])
            grant_mutex_id[j] = each_mutex_current_selected_req[j];
         else if(mst_mutexctrl_release_valid_comb & mst_mutexctrl_release_sel_comb[j]) 
            grant_mutex_id[j] = '1;
      end 
   end
end 

// synopsys translate_on



endmodule
