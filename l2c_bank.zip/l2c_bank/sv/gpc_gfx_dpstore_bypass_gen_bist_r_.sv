/*

 * #==========================================================================#
 * |                                                                          |
 * |  Copyright (c) 2023, Fantasy Technologies Limited and/or its         |
 * |  affiliated group companies ("Fantasy"). All rights reserved.        |
 * |  No part of this content, either material or conceptual may be copied    |
 * |  or distributed, transmitted, transcribed, stored in a retrieval system  |
 * |  or translated into any human or computer language in any form by any    |
 * |  means, electronic, mechanical manual, or otherwise, or disclosed to     |
 * |  third parties without the express written permission of Fantasy.    |
 * |                                                                          |
 * #==========================================================================#

 */

// ////////////////////////////////////////////////////////////////////////////-
// entity:  gpc_gfx_dpstore_bypass_gen_bist_r
//
// purpose: Dual port synchronous RAM with configurable write word partitioning,
//          a back end read register to help achieve timing closure, and a
//          bypass data path enabling provision of writethrough transparency (at
//          word partition granularity)
//
// +////////////////////////-+////////+////-+////-+////////+////////////////+
// | gpc_gfx_dpstore_        |        | RAM | Reg | Bypass | Design         |
// |             w,p,d,log2d | Clocks | O/P | O/P | Input  | Suitability    |
// +////////////////////////-+////////+////-+////-+////////+////////////////+
// | _.vhd & _novital.vhd    |  2:RW  | Yes |     |        | Fundamental    |
// | bist.vhdm               | single | Yes |     |        | Low level only |
// | bist_async.vhdm         |  2:RW  | Yes |     |        | Low level only |
// | gen_bist_r.vhd          | single |     | Yes |        | Standard use   |
// | pipeline_gen_bist_r.vhd | single |     | Yes |        | Standard use   |
// | bypass_gen_bist_r.vhd   | single |     | Yes |  Yes   | Standard use   |<<<
// | flexible_gen_bist_r.vhd | single | Yes | Yes |  Yes   | Standard use   |
// | flexible_gen_bist_r     |        |     |     |        |                |
// |              _async.vhd |  2:RW  | Yes | Yes |  Yes   | Standard use   |
// +////////////////////////-+////////+////-+////-+////////+////////////////+
//
//
//        gpc_gfx_dpstore_bypass_gen_bist_r       << YOU ARE HERE
//         |
//         +- gpc_gfx_dpstore_bist
//             |
//             +- gpc_gfx_dpstore
//             |
//             +- [gpc_gfx_bistwrap]
//
// ////////////////////////////////////////////////////////////////////////////-

// DIMENSIONS
//   Physical generics: w, d, p, log2d, wrcen*
//
//                        width
//              <////////// w //////////>
//
//              +//////////////////////-+   ^
//              |_______________________|   |
//              |_______________________|   |  d
//              |_______________________|      e
//              |                       |   d  p
//              |                       |      t
//              :                       :   |  h
//              |                       |   |
//              +//////////////////////-+   v
//                         w/p *
//              <- p -><- p -> .. <- p ->
//                      partitions
//
//   All partitions are equal in size. In other words, the generic w is an
//   integer multiple of generic p.
//
//   Example partition:
//      [w = 128, p = 32] => w/p = 4 partitions => 4 write enables

// PORTS
//   +////////////////////////////////////////////////////////////+
//   | name          |  bits  |dir| description                   |
//   +////////////////////////////////////////////////////////////+
//   | rd_addr       | log2d  | i | read address                  |
//   | rd_en         |   1    | i | read strobe (ACTIVE LOW)      |
//   | rd_data       |   w    | o | read data                     |
//   | bypass_load   |  w/p   | i | bypass data partition enables |
//   | bypass_data   |   w    | i | bypass data ((w/p)*p bits)    |
//   |               |        |   |                               |
//   | wr_addr       | log2d  | i | write address                 |
//   | wr_data       |   w    | i | write data ((w/p)*p bits)     |
//   | wr_en *       |(w/p)+1*| i | write enables*(ACTIVE LOW)    |
//   |               |        |   |                               |
//   | clk           |   1    | i | common r/w clock              |
//   | resetn        |   1    | i | reset to BIST (ACTIVE LOW)    |
//   |               |        |   |                               |
//   | bist_in       |f(w,p,d)| i | input from BIST controller    |
//   | bist_out      |f(w,p,d)| o | result to BIST controller     |
//   +////////////////////////////////////////////////////////////+
//
//  * - wr_en width can be configured with generic wrcen to have an extra bit:
//
//    wrcen
//      0 : w/p bits => one ACTIVE LOW write enable per word partition (default)
//      1 : w/p+1 bits => one ADDITIONAL (ACTIVE LOW) write enable
//
//      If configured, the extra bit indicates that any one of the per word
//      partition write enables is asserted low.

// BEHAVIOURIAL MODEL
//   Functional behaviour is similar to gpc_gfx_dpstore_bist but this hierarchical
//   level adds a back end read data register for timing purposes. The back end
//   register also takes bypass data or RAM data, each on a partition
//   basis as dictated by the bypass_load signals. This can be used where
//   writethrough transparency is required.
//
//   Where bypass data and RAM data partitions are interleaved, the rd_en read
//   strobe is delayed one clock to align it with the RAM output data before
//   using it as the selector into the final register stage. If no read was
//   performed, bypass data partitions are interleaved with old RAM output
//   which is potentially junk.
//
//   Read latency:   2 clocks
//   Write latency:  1 clock
//   Bypass latency: 1 clock
//
//  bypass_load ///////////////////////////////////////////.
//  bypass_data ///////////////////////////////////////.   |
//                 +////////////////////////////////-+ |   |
//                 |      gpc_gfx_dpstore_bist       | |   |
//                 |                                 | |   |
//                 |  +//////////////////////////-+  | |,  |,
//                 |  |     gpc_gfx_dpstore       |  | /   /
//                 |  |                        dly|  | |   |
//  rd_addr, rd_en-|//|//////////////////////*//%-|//|-|//+|
//                 |  |                      |    |  | | +//-+
//  wr_addr    ///-|//|-| wr |   |     |   | rd | |  |   |   |_|    |
//  wr_en      ///-|//|-|proc|-/-| mem |-/-|proc|-|//|-/-|0  | |    |///->
//  wr_data    ///-|//|-|    |   |     |   |    | |  |   +//-+ |    |   rd_data
//                 |  | |    |  +|>    |  +|>   | |  |        +|>   |
//                 |  | +////+  |+////-+  |+////+ |  |        |+////+
//                 |  |         |         |       |  |        |
//                 |  +//////////////////////////-+  |
//                 |  +//////////////////////////-+  |
//                 |  |                           |  |
//  bist_in    ///-|//|   [gpc_gfx_bistwrap]    |//|////////////-/-> bist_out
//  resetn     ////|//|                           |  |
//                 |  +//////////////////////////-+  |
//                 +////////////////////////////////-+

// OPTIONAL UTILITY GENERICS
//   id       : integer value that can be assigned to each instance (default 0)
//                                                                      -=:PB=-
// ////////////////////////////////////////////////////////////////////////////-

module gpc_gfx_dpstore_bypass_gen_bist_r_ 
   import gpc_gfx_rambist_pack_::*;
  #(parameter   w        = 32, // integer
    parameter   p        = 32, // integer
    parameter   d        = 8,  // integer
    parameter   log2d    = 3,  // integer
    parameter   wrcen    = 0,  // integer
    parameter   ECC      = 0,  // integer



    parameter   id       = 0   // integer
    )
   (input  logic                                      clk,
    input  logic                                      resetn,
    // read port
    input  logic                                      rd_en,
    input  logic [log2d - 1 : 0]                      rd_addr,
    input  logic [(w / p) - 1 : 0]                    bypass_load,
    input  logic [w - 1 : 0]                          bypass_data,
    output logic [w - 1 : 0]                          rd_data,
      // write port
    input  logic [(w / p) + wrcen - 1 : 0]            wr_en,
    input  logic [log2d - 1 : 0]                      wr_addr,
    input  logic [w - 1 : 0]                          wr_data,






      // bist signals
    input logic [dpstore_in (w, p, d, ECC) - 1 : 0]   bist_in,
    output logic [dpstore_out (w, p, d, ECC) - 1 : 0] bist_out,
    input logic                                       tst_gclkenable
    );

   








   logic                                              rd_en_r;
   logic [w - 1 : 0]                                  rd_data_ram;
   logic [w - 1 : 0]                                  rd_data_ram_r;


   ///////////////////////////////////////////////
   // backdoor access
   ///////////////////////////////////////////////




   ///////////////////////////////////////////////
   ///////////////////////////////////////////////
   // END backdoor access
   ///////////////////////////////////////////////


   gpc_gfx_dpstore_wrap_ #(.w(w),
                          .p(p),
                          .d(d),
                          .log2d(log2d),
                          .wrcen(wrcen),
                          .ECC(ECC),



                          .id(id))
   i_gpc_gfx_dpstore_wrap (.clk(clk),
                           .resetn(resetn),
                           .rd_en(rd_en),
                           .rd_addr(rd_addr),
                           .rd_data_ram(rd_data_ram),
                           .wr_en(wr_en),
                           .wr_addr(wr_addr),
                           .wr_data(wr_data),






                           .bist_in(bist_in),
                           .bist_out(bist_out),
                           .tst_gclkenable(tst_gclkenable));

   // //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
   // Register the Ram Data for timing (This variant has a bypass interface to optionally register alternative data)
   // //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
   always_ff@(posedge clk or negedge resetn) begin
      if (resetn == 1'b0) begin
         rd_en_r <= 1'b1;
      end else begin
         rd_en_r <= rd_en;
      end
   end

   genvar i;
   generate
      for(i = 0; i < w/p; i++) begin : p_qa_i

         always_ff@(posedge clk) begin
            if (bypass_load[i] == 1'b1 || rd_en_r == 1'b0) begin
               if (bypass_load[i] == 1'b0) begin
                  rd_data_ram_r[(i+1)*p-1 : i*p] <= rd_data_ram[(i+1)*p-1 : i*p];
               end else begin
                  rd_data_ram_r[(i+1)*p-1 : i*p] <= bypass_data [(i+1)*p-1 : i*p];
               end
            end
         end

      end : p_qa_i
   endgenerate

   assign rd_data = rd_data_ram_r;

endmodule
