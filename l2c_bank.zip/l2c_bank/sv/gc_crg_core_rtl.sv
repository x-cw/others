/*

 * #==========================================================================#
 * |                                                                          |
 * |  Copyright (c) 2023, Fantasy Technologies Limited and/or its         |
 * |  affiliated group companies ("Fantasy"). All rights reserved.        |
 * |  No part of this content, either material or conceptual may be copied    |
 * |  or distributed, transmitted, transcribed, stored in a retrieval system  |
 * |  or translated into any human or computer language in any form by any    |
 * |  means, electronic, mechanical manual, or otherwise, or disclosed to     |
 * |  third parties without the express written permission of Fantasy.    |
 * |                                                                          |
 * #==========================================================================#

 */

module gc_crg_core_rtl

import pkg_crm_::*;
import gc_clock_gate_pack_::*;  // CLK_ALIGN_DELAY
import pkg_rogue4_::*;           // RESYNC_SDEPTH

(
      // ----------------------------------------------------------------------------------------------------------------------------------
      // Interface: clock, clock enable and reset interface
      // ----------------------------------------------------------------------------------------------------------------------------------
      input    logic                                                        core_clk                                ,
      input    logic                                                        core_resetn                             ,
      // ----------------------------------------------------------------------------------------------------------------------------------
      // Interface: Soft Reset Interface
      // ----------------------------------------------------------------------------------------------------------------------------------
      input    logic                                                        soft_reset_core                         ,
      // ----------------------------------------------------------------------------------------------------------------------------------
      // Interface: Reset Synchronisers Bypass
      // ----------------------------------------------------------------------------------------------------------------------------------
      input    logic                                                        tst_rst_bypass                          ,
      // ----------------------------------------------------------------------------------------------------------------------------------
      // Interface: Clock & Reset Interface
      // ----------------------------------------------------------------------------------------------------------------------------------
      output   logic                                                        aligned_clk                             ,
      output   logic                                                        aligned_resetn                          ,
      // ----------------------------------------------------------------------------------------------------------------------------------
      // Interface: Clock & Reset Interface
      // ----------------------------------------------------------------------------------------------------------------------------------
      output   logic                                                        unaligned_clk                           ,
      output   logic                                                        unaligned_resetn                         
);

   logic resetn_l;                               

   assign 
`ifndef GPU_SYNTHESIS
   #CLK_ALIGN_DELAY 
`endif
   aligned_clk = core_clk;
   assign unaligned_clk = core_clk;

   gpc_gfx_resetn_ip_async_ #(
      .sdepth                          (RESYNC_SDEPTH)                               
   ) i_resetn_ip_async (
      .soft_reset                      (soft_reset_core),
      .ipin_resetn                     (core_resetn),
      .clk                             (aligned_clk),
      .resetn_sync                     (resetn_l),
      .tst_scan_mode                   (tst_rst_bypass)                              
   );

   assign unaligned_resetn = resetn_l;
   assign aligned_resetn   = resetn_l;

endmodule : gc_crg_core_rtl
