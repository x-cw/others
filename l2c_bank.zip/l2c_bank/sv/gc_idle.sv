/*

 * #==========================================================================#
 * |                                                                          |
 * |  Copyright (c) 2023, Fantasy Technologies Limited and/or its         |
 * |  affiliated group companies ("Fantasy"). All rights reserved.        |
 * |  No part of this content, either material or conceptual may be copied    |
 * |  or distributed, transmitted, transcribed, stored in a retrieval system  |
 * |  or translated into any human or computer language in any form by any    |
 * |  means, electronic, mechanical manual, or otherwise, or disclosed to     |
 * |  third parties without the express written permission of Fantasy.    |
 * |                                                                          |
 * #==========================================================================#

 */

module gc_idle
#(
   parameter int NUM_IDLES   = 1
)
(
    // -----------------------------------------------------------
    //  Interface
    // -----------------------------------------------------------
      input  logic                   clk ,
      input  logic                   resetn,
    // -----------------------------------------------------------
    // in_idle Interface
    // -----------------------------------------------------------
      input  logic                   [ NUM_IDLES-1 : 0 ]  in_idle,
    // -----------------------------------------------------------
    // out_idle Interface
    // -----------------------------------------------------------
      output logic                   out_idle    
);

   always_ff@(posedge clk or negedge resetn) begin : p_idle
      if(resetn==1'b0) begin
         out_idle <= 1'b1;
      end
      else begin
         out_idle <= (&(in_idle));
      end
   end : p_idle





endmodule : gc_idle
