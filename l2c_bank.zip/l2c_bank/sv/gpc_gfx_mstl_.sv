/*

 * #==========================================================================#
 * |                                                                          |
 * |  Copyright (c) 2022, Fantasy Technologies Limited and/or its         |
 * |  affiliated group companies ("Fantasy"). All rights reserved.        |
 * |  No part of this content, either material or conceptual may be copied    |
 * |  or distributed, transmitted, transcribed, stored in a retrieval system  |
 * |  or translated into any human or computer language in any form by any    |
 * |  means, electronic, mechanical manual, or otherwise, or disclosed to     |
 * |  third parties without the express written permission of Fantasy.    |
 * |                                                                          |
 * #==========================================================================#

 */

// ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////-
// entity name: gpc_gfx_mstl
// Component Description: IMGLIB3 Multiplexer Staller
// Inserts a register in the enable path from the downstream (ein) and upstream modules (eout) in order to break a timing path.
// Data from the upstream module is passed directly from upstream to downstream module if we have no data stored locally and the
// downstream enable is set.
// If the downstream enable is not set, then the data will be stored in the local holding register stage if empty, and the
// downstream stall will be hidden from the upstream interface, the enable upstream will be driven and the data loaded into the
// holding register.
// Until emptied the holding register data will be multiplexed onto the output data bus, and the output valid held high, any
// further data presented by the upstream interface will be stalled until the register stage is emptied by the downstream enable
//
// Generics:
// w           - INTEGER
//             - Width of Data bus Input/Output std_logic_vector
// collapse_bb - Collapse bubbles BOOLEAN
//             - (TRUE-default) Remove bubbles seen downstream from the upstream interface if the MSTL can hide them.
//             - (FALSE)        Don't remove bubbles.
//
// Portlist:
// clk     - Clock Input
// resetn  - Active-low asynchronous Reset
// din     - Data bus input (sized by generic w)
// vin     - Valid input from upstream module
// eout    - Enable output to upstream module
// dout    - Data bus output (sized by generic w)
// vout    - Valid output to downstream module
// ein     - Enable input from downstream module
// ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////-


module gpc_gfx_mstl_
  #(
    parameter   w           = 2,
    parameter   collapse_bb = 1
    )
   (
    input  logic         clk,
    input  logic         resetn,
    input  logic [w-1:0] din,
    input  logic         vin,
    output logic         eout,
    output logic [w-1:0] dout,
    output logic         vout,
    input  logic         ein
    );

   logic [w-1 : 0]       hld_din;
   logic                 hld_vin;
   logic                 nxt_hld_vin;
   logic                 eout_i;
   logic                 nxt_eout;


   // hld_vin register is set when the register stage hld_din has been updated with data from din to be held until
   // downstream enable is set
   // eout_i register is set when we can accept data on the next cycle (if downstream enable is set, or holding stage is empty)
   always_ff@(posedge clk or negedge resetn) begin : rctrl
      if (resetn == 1'b0) begin
         hld_vin <= 1'b0;
         eout_i  <= 1'b1;
      end else begin
         hld_vin <= nxt_hld_vin;
         eout_i  <= nxt_eout;
      end
   end

   // //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
   // Register input data in holding register when it cannot be propagated directly to the output interface
   // eout_i will be deasserted if data is already been held in the register to prevent overwrite
   always_ff@(posedge clk) begin : ctrl
      if (ein == 1'b0 && eout_i == 1'b1 && vin == 1'b1) begin
         hld_din <= din;
      end
   end

   assign eout = eout_i;

   // if input data is valid but downstream enable is low, then put into holding register if empty
   // keep the valid in current state if enable downstream is not set, but the upstream valid or the upstream enable are not set
   // i.e. wont be accepting or transferring data
   // if the downstream enable is set, the holding register will be emptied if full, so set the valid low for the next cycle
   assign nxt_hld_vin = (~ein & vin & eout_i) ? 1'b1 : ein ? 1'b0 : hld_vin;

   // can set the upstream enable in next clock cycle if downstream enable is active or the holding register has space and there is
   // no valid data coming in. i.e. we have space in the pipeline
   assign nxt_eout = ein | (collapse_bb & (~hld_vin & ~vin));

   assign dout = ~hld_vin ? din : hld_din;

   // valid downstream is set if holding register is valid or we are transferring data
   assign vout = ~hld_vin ? (eout_i & vin) : 1'b1;

endmodule
