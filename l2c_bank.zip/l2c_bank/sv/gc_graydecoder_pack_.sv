/*

 * #==========================================================================#
 * |                                                                          |
 * |  Copyright (c) 2022, Fantasy Technologies Limited and/or its         |
 * |  affiliated group companies ("Fantasy"). All rights reserved.        |
 * |  No part of this content, either material or conceptual may be copied    |
 * |  or distributed, transmitted, transcribed, stored in a retrieval system  |
 * |  or translated into any human or computer language in any form by any    |
 * |  means, electronic, mechanical manual, or otherwise, or disclosed to     |
 * |  third parties without the express written permission of Fantasy.    |
 * |                                                                          |
 * #==========================================================================#

 */

package gc_graydecoder_pack_;

// library ieee;
// use ieee.std_logic_1164.all;
// use ieee.std_logic_arith.all;

// library work;
import gpu_core_gfx_std_func_pack_::*;

// ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////-
// entity name: gc_graydecoder_pack
// purpose: Defines function to convert Gray to Binary
// ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////-


  

   // basic behavioural model
   function automatic logic [63:0] conv_gray_binary;    // convert from gray to binary   
   input  int                                           var_size ;
   input  logic [ 63 : 0 ]                               var_gray ;
      logic [ 63 : 0 ]                              result                                  ;
      result = var_gray ;
      for ( int i = var_size ; i >= 1 ; i = i - 1 ) begin
         result [ i - 1 ] = result [ i ] ^ var_gray [ i - 1 ] ;
      end
      return ( result ) ;
   endfunction // conv_gray_binary   conv_gray_binary

   // 64x64-bit 2D array
   typedef logic [ 63 : 0 ][ 63 : 0 ] xor_string_type ;

   // optimised logarithmic xor tree model
   //gray to binary converter function
   function automatic logic [63:0] conv_gray_binary2;   
   input  int                                           var_size ;
   input  logic [63:0]                             var_gray ;
      xor_string_type                               xor_string                              ;
      logic [ 63 : 0 ]                              result                                  ;
      result = 64'b0;
      initial_assign : for ( int t = var_size - 1 ; t >= 0 ; t = t - 1 ) begin
         xor_string [ t ] [ t ] = var_gray [ var_size - 1 - t ] ;
      end
      level : for ( int i = 1 ; i <= 6 ; i = i + 1 ) begin
         set : for ( int j = 0 ; j <= 2 ** ( 6 - i ) - 1 ; j = j + 1 ) begin
            length : for ( int k = 2 ** ( i - 1 ) ; k <= ( 2 ** i ) - 1 ; k = k + 1 ) begin
               xor_string [ k + j * ( 2 ** i ) ] [ j * ( 2 ** i ) ] = xor_string [ k + j * ( 2 ** i ) ] [ ( 2 * j + 1 ) * ( 2 ** ( i - 1 ) ) ] ^ xor_string [ ( 2 * j + 1 ) * ( 2 ** ( i - 1 ) ) - 1 ] [ j * ( 2 ** i ) ] ;
            end
         end
      end
      final_assign : for ( int r = 0 ; r <= var_size - 1 ; r = r + 1 ) begin
         result [ r ] = xor_string [ var_size - 1 - r ] [ 0 ] ;
      end
      return ( result ) ;
   endfunction // conv_gray_binary2

endpackage
