/*



*/
// ----------------------------------------------------------------------------------------------
// entity name: gc_l2_bank_wrap
// purpose: instance crg, crm, ipg, int_pipe, bank(x2), mem_sched
// ----------------------------------------------------------------------------------------------

module gc_l2_bank_wrap_empty
import group_nsp_req_pkg::*;
import group_nsp_rsp_pkg::*;
import nsp_rsp_pkg::*;
import nsp_req_pkg::*;
import bank_sched_pkg::*;
import sched_bank_pkg::*;
import axi5_ar_pkg::*;
import axi5_r_pkg::*;
import axi5_aw_pkg::*;
import axi5_w_pkg::*;
import axi5_b_pkg::*;
import gc_l2_bank_group_pkg::*;
import gc_l2_bank_pkg::*;
(
    input   logic                       clk                 ,
    input   logic                       resetn              ,
    input   logic                       tst_gclkenable      ,
    input   logic                       tst_rst_bypass      ,
    input   logic                       socif_wakeup        ,
    // AXI interface
    input   logic                       axi_slv_0_arvalid   ,
    output  logic                       axi_slv_0_arready   ,
    input   axi5_ar_data_bus_t          axi_slv_0_ar_rec    ,
    output  logic                       axi_slv_0_rvalid    ,
    input   logic                       axi_slv_0_rready    ,
    output  axi5_r_data_bus_t           axi_slv_0_r_rec     ,
    input   logic                       axi_slv_0_awvalid   ,
    output  logic                       axi_slv_0_awready   ,
    input   axi5_aw_data_bus_t          axi_slv_0_aw_rec    ,
    input   logic                       axi_slv_0_wvalid    ,
    output  logic                       axi_slv_0_wready    ,
    input   axi5_w_data_bus_t           axi_slv_0_w_rec     ,
    output  logic                       axi_slv_0_bvalid    ,
    input   logic                       axi_slv_0_bready    ,
    output  axi5_b_data_bus_t           axi_slv_0_b_rec     ,

    input   logic                       axi_slv_1_arvalid   ,
    output  logic                       axi_slv_1_arready   ,
    input   axi5_ar_data_bus_t          axi_slv_1_ar_rec    ,
    output  logic                       axi_slv_1_rvalid    ,
    input   logic                       axi_slv_1_rready    ,
    output  axi5_r_data_bus_t           axi_slv_1_r_rec     ,
    input   logic                       axi_slv_1_awvalid   ,
    output  logic                       axi_slv_1_awready   ,
    input   axi5_aw_data_bus_t          axi_slv_1_aw_rec    ,
    input   logic                       axi_slv_1_wvalid    ,
    output  logic                       axi_slv_1_wready    ,
    input   axi5_w_data_bus_t           axi_slv_1_w_rec     ,
    output  logic                       axi_slv_1_bvalid    ,
    input   logic                       axi_slv_1_bready    ,
    output  axi5_b_data_bus_t           axi_slv_1_b_rec     ,
    // NSP interface
    output  logic                       l2_nsp0_req_valid,
    input   logic                       l2_nsp0_req_ready,
    output  group_nsp_req_data_bus_t    l2_nsp0_req_rec  ,
    input   logic                       l2_nsp0_rsp_valid,
    output  logic                       l2_nsp0_rsp_ready,
    input   group_nsp_rsp_data_bus_t    l2_nsp0_rsp_rec  ,

    output  logic                       l2_nsp1_req_valid,
    input   logic                       l2_nsp1_req_ready,
    output  group_nsp_req_data_bus_t    l2_nsp1_req_rec  ,
    input   logic                       l2_nsp1_rsp_valid,
    output  logic                       l2_nsp1_rsp_ready,
    input   group_nsp_rsp_data_bus_t    l2_nsp1_rsp_rec  ,
    // performance counter
    output  logic                       l2b0_busy                        ,
    output  logic                       l2b0_fromaxi_ar_wl               ,
    output  logic                       l2b0_fromaxi_ar_bl_eq0_wl        ,
    output  logic                       l2b0_fromaxi_ar_bl_eq1_wl        ,
    output  logic                       l2b0_fromaxi_ar_bl_eq2_wl        ,
    output  logic                       l2b0_fromaxi_ar_bl_eq3_wl        ,
    output  logic                       l2b0_fromaxi_ar_bp               ,
    output  logic                       l2b0_toaxi_r_wl                  ,
    output  logic                       l2b0_toaxi_r_bp                  ,
    output  logic                       l2b0_fromaxi_aw_wl               ,
    output  logic                       l2b0_fromaxi_aw_bl_eq0_wl        ,
    output  logic                       l2b0_fromaxi_aw_bl_eq1_wl        ,
    output  logic                       l2b0_fromaxi_aw_bl_eq2_wl        ,
    output  logic                       l2b0_fromaxi_aw_bl_eq3_wl        ,
    output  logic                       l2b0_fromaxi_aw_bp               ,
    output  logic                       l2b0_fromaxi_w_wl                ,
    output  logic                       l2b0_fromaxi_w_bp                ,
    output  logic                       l2b0_fromaxi_smp_read_req_num    ,
    output  logic                       l2b0_fromaxi_smp_read_req_sum    ,
    output  logic                       l2b0_fromaxi_smp_write_req_num   ,
    output  logic                       l2b0_fromaxi_smp_write_req_sum   ,
    output  logic                       l2b0_fromaxi_smp_atomic_req_num  ,
    output  logic                       l2b0_fromaxi_smp_atomic_req_sum  ,
    output  logic                       l2b0_align_awdb_full             ,
    output  logic                       l2b0_hittest_ht_bypass_read_wl   ,
    output  logic                       l2b0_hittest_ht_cache_read_wl    ,
    output  logic                       l2b0_hittest_ht_bypass_write_wl  ,
    output  logic                       l2b0_hittest_ht_cache_write_wl   ,
    output  logic                       l2b0_hittest_ht_atomic_wl        ,
    output  logic                       l2b0_hittest_ht_bps_hit_wl       ,
    output  logic                       l2b0_hittest_ht_miss_wl          ,
    output  logic                       l2b0_frommemsch_nsp_rtn_wl       ,
    output  logic                       l2b0_frommemsch_nsp_rtn_bp       ,
    output  logic                       l2b0_tomemsch_nsp_read_bl_eq1_wl ,
    output  logic                       l2b0_tomemsch_nsp_read_bl_eq3_wl ,
    output  logic                       l2b0_tomemsch_nsp_read_bl_eq5_wl ,
    output  logic                       l2b0_tomemsch_nsp_read_bl_eq7_wl ,
    output  logic                       l2b0_tomemsch_nsp_write_bl_eq1_wl,
    output  logic                       l2b0_tomemsch_nsp_write_bl_eq3_wl,
    output  logic                       l2b0_tomemsch_nsp_write_bl_eq5_wl,
    output  logic                       l2b0_tomemsch_nsp_write_bl_eq7_wl,
    output  logic                       l2b0_memif_to_ddr_read_wl        ,
    output  logic                       l2b0_memif_to_ddr_read_stall_by_rob          ,
    output  logic                       l2b0_memif_to_ddr_read_stall_by_ddr          ,
    output  logic                       l2b0_memif_to_ddr_read_stall_by_trid         ,
    output  logic                       l2b0_memif_to_ddr_write_wl                   ,
    output  logic                       l2b0_memif_to_ddr_write_stall_by_data_sync   ,
    output  logic                       l2b0_memif_to_ddr_write_stall_by_ddr         ,
    output  logic                       l2b0_memif_to_ddr_write_stall_by_trid        ,
    output  logic                       l2b0_memif_memreq_full                       ,
    output  logic                       l2b0_memif_smp_read_req_num                  ,
    output  logic                       l2b0_memif_smp_read_req_sum                  ,
    output  logic                       l2b0_reqsch_sortq_full                       ,
    output  logic                       l2b0_reqsch_sortq_stall_but_not_full         ,
    output  logic                       l2b0_reqsch_disp_wl                          ,
    output  logic                       l2b0_reqsch_disp_stall                       ,
    output  logic                       l2b0_ramctrl_0_reqarb_wl                     ,
    output  logic                       l2b0_ramctrl_0_reqarb_stall_by_sram          ,
    output  logic                       l2b0_ramctrl_0_data_sram_read_wl             ,
    output  logic                       l2b0_ramctrl_0_data_sram_write_wl            ,
    output  logic                       l2b0_ramctrl_1_reqarb_wl                     ,
    output  logic                       l2b0_ramctrl_1_reqarb_stall_by_sram          ,
    output  logic                       l2b0_ramctrl_1_data_sram_read_wl             ,
    output  logic                       l2b0_ramctrl_1_data_sram_write_wl            ,
    output  logic                       l2b1_busy                        ,
    output  logic                       l2b1_fromaxi_ar_wl               ,
    output  logic                       l2b1_fromaxi_ar_bl_eq0_wl        ,
    output  logic                       l2b1_fromaxi_ar_bl_eq1_wl        ,
    output  logic                       l2b1_fromaxi_ar_bl_eq2_wl        ,
    output  logic                       l2b1_fromaxi_ar_bl_eq3_wl        ,
    output  logic                       l2b1_fromaxi_ar_bp               ,
    output  logic                       l2b1_toaxi_r_wl                  ,
    output  logic                       l2b1_toaxi_r_bp                  ,
    output  logic                       l2b1_fromaxi_aw_wl               ,
    output  logic                       l2b1_fromaxi_aw_bl_eq0_wl        ,
    output  logic                       l2b1_fromaxi_aw_bl_eq1_wl        ,
    output  logic                       l2b1_fromaxi_aw_bl_eq2_wl        ,
    output  logic                       l2b1_fromaxi_aw_bl_eq3_wl        ,
    output  logic                       l2b1_fromaxi_aw_bp               ,
    output  logic                       l2b1_fromaxi_w_wl                ,
    output  logic                       l2b1_fromaxi_w_bp                ,
    output  logic                       l2b1_fromaxi_smp_read_req_num    ,
    output  logic                       l2b1_fromaxi_smp_read_req_sum    ,
    output  logic                       l2b1_fromaxi_smp_write_req_num   ,
    output  logic                       l2b1_fromaxi_smp_write_req_sum   ,
    output  logic                       l2b1_fromaxi_smp_atomic_req_num  ,
    output  logic                       l2b1_fromaxi_smp_atomic_req_sum  ,
    output  logic                       l2b1_align_awdb_full             ,
    output  logic                       l2b1_hittest_ht_bypass_read_wl   ,
    output  logic                       l2b1_hittest_ht_cache_read_wl    ,
    output  logic                       l2b1_hittest_ht_bypass_write_wl  ,
    output  logic                       l2b1_hittest_ht_cache_write_wl   ,
    output  logic                       l2b1_hittest_ht_atomic_wl        ,
    output  logic                       l2b1_hittest_ht_bps_hit_wl       ,
    output  logic                       l2b1_hittest_ht_miss_wl          ,
    output  logic                       l2b1_frommemsch_nsp_rtn_wl       ,
    output  logic                       l2b1_frommemsch_nsp_rtn_bp       ,
    output  logic                       l2b1_tomemsch_nsp_read_bl_eq1_wl ,
    output  logic                       l2b1_tomemsch_nsp_read_bl_eq3_wl ,
    output  logic                       l2b1_tomemsch_nsp_read_bl_eq5_wl ,
    output  logic                       l2b1_tomemsch_nsp_read_bl_eq7_wl ,
    output  logic                       l2b1_tomemsch_nsp_write_bl_eq1_wl,
    output  logic                       l2b1_tomemsch_nsp_write_bl_eq3_wl,
    output  logic                       l2b1_tomemsch_nsp_write_bl_eq5_wl,
    output  logic                       l2b1_tomemsch_nsp_write_bl_eq7_wl,
    output  logic                       l2b1_memif_to_ddr_read_wl        ,
    output  logic                       l2b1_memif_to_ddr_read_stall_by_rob          ,
    output  logic                       l2b1_memif_to_ddr_read_stall_by_ddr          ,
    output  logic                       l2b1_memif_to_ddr_read_stall_by_trid         ,
    output  logic                       l2b1_memif_to_ddr_write_wl                   ,
    output  logic                       l2b1_memif_to_ddr_write_stall_by_data_sync   ,
    output  logic                       l2b1_memif_to_ddr_write_stall_by_ddr         ,
    output  logic                       l2b1_memif_to_ddr_write_stall_by_trid        ,
    output  logic                       l2b1_memif_memreq_full                       ,
    output  logic                       l2b1_memif_smp_read_req_num                  ,
    output  logic                       l2b1_memif_smp_read_req_sum                  ,
    output  logic                       l2b1_reqsch_sortq_full                       ,
    output  logic                       l2b1_reqsch_sortq_stall_but_not_full         ,
    output  logic                       l2b1_reqsch_disp_wl                          ,
    output  logic                       l2b1_reqsch_disp_stall                       ,
    output  logic                       l2b1_ramctrl_0_reqarb_wl                     ,
    output  logic                       l2b1_ramctrl_0_reqarb_stall_by_sram          ,
    output  logic                       l2b1_ramctrl_0_data_sram_read_wl             ,
    output  logic                       l2b1_ramctrl_0_data_sram_write_wl            ,
    output  logic                       l2b1_ramctrl_1_reqarb_wl                     ,
    output  logic                       l2b1_ramctrl_1_reqarb_stall_by_sram          ,
    output  logic                       l2b1_ramctrl_1_data_sram_read_wl             ,
    output  logic                       l2b1_ramctrl_1_data_sram_write_wl            ,
    // configure register    
    input   logic [ 3 : 0 ]            gc_cr_ddr_hash_config_reg0_row_id_bit0        ,
    input   logic [ 3 : 0 ]            gc_cr_ddr_hash_config_reg0_row_id_bit1        ,
    input   logic [ 3 : 0 ]            gc_cr_ddr_hash_config_reg0_row_id_bit2        ,
    input   logic [ 3 : 0 ]            gc_cr_ddr_hash_config_reg0_row_id_bit3        ,
    input   logic [ 3 : 0 ]            gc_cr_ddr_hash_config_reg0_row_id_bit4        ,
    input   logic [ 3 : 0 ]            gc_cr_ddr_hash_config_reg0_row_id_bit5        ,
    input   logic [ 3 : 0 ]            gc_cr_ddr_hash_config_reg0_row_id_bit6        ,
    input   logic [ 3 : 0 ]            gc_cr_ddr_hash_config_reg0_row_id_bit7        ,
    input   logic [ 3 : 0 ]            gc_cr_ddr_hash_config_reg0_row_id_bit8        ,
    input   logic [ 3 : 0 ]            gc_cr_ddr_hash_config_reg0_row_id_bit9        ,
    input   logic [ 3 : 0 ]            gc_cr_ddr_hash_config_reg0_row_id_bit10       ,
    input   logic [ 3 : 0 ]            gc_cr_ddr_hash_config_reg0_row_id_bit11       ,
    input   logic [ 3 : 0 ]            gc_cr_ddr_hash_config_reg1_row_id_bit12       ,
    input   logic [ 3 : 0 ]            gc_cr_ddr_hash_config_reg1_row_id_bit13       ,
    input   logic [ 3 : 0 ]            gc_cr_ddr_hash_config_reg1_row_id_bit14       ,
    input   logic [ 3 : 0 ]            gc_cr_ddr_hash_config_reg1_row_id_bit15       ,
    input   logic [ 3 : 0 ]            gc_cr_ddr_hash_config_reg1_row_id_bit16       ,
    input   logic [ 3 : 0 ]            gc_cr_ddr_hash_config_reg1_row_id_bit17       ,
    input   logic [ 3 : 0 ]            gc_cr_ddr_hash_config_reg1_row_id_bit18       ,
    input   logic [ 3 : 0 ]            gc_cr_ddr_hash_config_reg1_row_id_bit19       ,
    input   logic [ 3 : 0 ]            gc_cr_ddr_hash_config_reg1_row_id_bit20       ,
    input   logic [ 3 : 0 ]            gc_cr_ddr_hash_config_reg1_row_id_bit21       ,
    input   logic [ 3 : 0 ]            gc_cr_ddr_hash_config_reg1_row_id_bit22       ,
    input   logic [ 3 : 0 ]            gc_cr_ddr_hash_config_reg1_row_id_bit23       ,
    input   logic [ 1 : 0 ]            gc_cr_l2_function_enable_hash_mode            ,
    input   logic [ 4 : 0 ]         gc_cr_l2_mem_sched_row_partii_row_id_bit8,
    input   logic [ 4 : 0 ]         gc_cr_l2_mem_sched_row_partii_row_id_bit9,
    input   logic [ 4 : 0 ]         gc_cr_l2_mem_sched_row_partii_row_id_bit10,
    input   logic [ 4 : 0 ]         gc_cr_l2_mem_sched_row_partii_row_id_bit11,
    input   logic [ 4 : 0 ]         gc_cr_l2_mem_sched_row_partii_row_id_bit12,
    input   logic [ 4 : 0 ]         gc_cr_l2_mem_sched_row_partii_row_id_bit13,
    input   logic [ 4 : 0 ]         gc_cr_l2_mem_sched_row_partii_row_id_bit14,
    input   logic [ 4 : 0 ]         gc_cr_l2_mem_sched_row_partii_row_id_bit15,
    input   logic [ 4 : 0 ]         gc_cr_l2_mem_sched_row_partiii_row_id_bit16,
    input   logic [ 4 : 0 ]         gc_cr_l2_mem_sched_row_partiii_row_id_bit17,
    input   logic [ 1 : 0 ]         gc_cr_l2_function_enable_ddr_capacity,
    input   logic [ 1 : 0 ]         gc_cr_clk_ctrl3_l2g,
    output  logic                   gc_cr_clk_status3_l2g,
    input   logic                   gc_cr_soft_reset_l2g,
    input   logic [ 1 : 0 ]         gc_cr_l2_cfi_operation,
    output  logic                   gc_cr_l2_cfi_statusi_l2b0_finish,
    output  logic                   gc_cr_l2_cfi_statusi_l2b1_finish,
    input   logic [ 1 : 0 ]         gc_cr_l2_buffer_mode_buffer_mode_percentage,
    input   logic                   gc_cr_l2_persistence_reduce_persistence_reduce_enable,
    input   logic [ 20 : 0 ]        gc_cr_l2_persistence_reduce_persistence_reduce_threshold,
    input   logic                   gc_cr_l2_cmd_persistence_rst_all,
    input   logic                   gc_cr_l2_cmd_cfi_clr,
    output  logic                   gc_cr_l2g_idle_l2g,
    output  logic [ 2 : 0 ]         gc_cr_l2g_error0_l2b0,
    output  logic [ 2 : 0 ]         gc_cr_l2g_error0_l2b1,
    input   logic                   gc_cr_l2_function_enable_mem_scheduler,
    input   logic                   gc_cr_l2_function_enable_bypass_mode,
    input   logic [ 4 : 0 ]         gc_cr_l2_mem_sched_col_offset_column_id_bit0,
    input   logic [ 4 : 0 ]         gc_cr_l2_mem_sched_col_offset_column_id_bit1,
    input   logic [ 4 : 0 ]         gc_cr_l2_mem_sched_col_offset_column_id_bit2,
    input   logic [ 4 : 0 ]         gc_cr_l2_mem_sched_col_offset_column_id_bit3,
    input   logic [ 4 : 0 ]         gc_cr_l2_mem_sched_col_offset_column_id_bit4,
    input   logic [ 4 : 0 ]         gc_cr_l2_mem_sched_col_offset_column_id_bit5,
    input   logic [ 4 : 0 ]         gc_cr_l2_mem_sched_bank_offset_bank_id_bit0,
    input   logic [ 4 : 0 ]         gc_cr_l2_mem_sched_bank_offset_bank_id_bit1,
    input   logic [ 4 : 0 ]         gc_cr_l2_mem_sched_bank_offset_bank_id_bit2,
    input   logic [ 4 : 0 ]         gc_cr_l2_mem_sched_bank_offset_bank_id_bit3,
    input   logic [ 4 : 0 ]         gc_cr_l2_mem_sched_bank_offset_bank_id_bit4,
    input   logic [ 4 : 0 ]         gc_cr_l2_mem_sched_row_parti_row_id_bit0,
    input   logic [ 4 : 0 ]         gc_cr_l2_mem_sched_row_parti_row_id_bit1,
    input   logic [ 4 : 0 ]         gc_cr_l2_mem_sched_row_parti_row_id_bit2,
    input   logic [ 4 : 0 ]         gc_cr_l2_mem_sched_row_parti_row_id_bit3,
    input   logic [ 4 : 0 ]         gc_cr_l2_mem_sched_row_parti_row_id_bit4,
    input   logic [ 4 : 0 ]         gc_cr_l2_mem_sched_row_parti_row_id_bit5,
    input   logic [ 4 : 0 ]         gc_cr_l2_mem_sched_row_parti_row_id_bit6,
    input   logic [ 4 : 0 ]         gc_cr_l2_mem_sched_row_parti_row_id_bit7,
    input   logic [ 4 : 0 ]         gc_cr_pwr_man_hysteresis_value,
    input   logic [ 1 : 0 ]         gc_cr_crm_reset_clk_ctrl,
    input   logic                   gc_cr_cu_lms_fp32_denormal_en,
    input   logic                   gc_cr_l2_cfi_operation_notify,
    input   logic                   gc_cr_l2_cfi_operation_rdnotify,
    input   logic                   gc_cr_l2_cmd_notify,
    input   logic                   gc_cr_l2_cmd_rdnotify
);




    assign axi_slv_0_arready                          = '0;   
    assign axi_slv_0_rvalid                           = '0;
    assign axi_slv_0_r_rec                            = '0;
    assign axi_slv_0_awready                          = '0;
    assign axi_slv_0_wready                           = '0;
    assign axi_slv_0_bvalid                           = '0;
    assign axi_slv_0_b_rec                            = '0;
    assign axi_slv_1_arready                          = '0;
    assign axi_slv_1_rvalid                           = '0;
    assign axi_slv_1_r_rec                            = '0;
    assign axi_slv_1_awready                          = '0;
    assign axi_slv_1_wready                           = '0;
    assign axi_slv_1_bvalid                           = '0;
    assign axi_slv_1_b_rec                            = '0;
    assign l2_nsp0_req_valid                          = '0;
    assign l2_nsp0_req_rec                            = '0;
    assign l2_nsp0_rsp_ready                          = '0;
    assign l2_nsp1_req_valid                          = '0;
    assign l2_nsp1_req_rec                            = '0;
    assign l2_nsp1_rsp_ready                          = '0;
    assign l2b0_busy                                  = '0;
    assign l2b0_fromaxi_ar_wl                         = '0;
    assign l2b0_fromaxi_ar_bl_eq0_wl                  = '0;
    assign l2b0_fromaxi_ar_bl_eq1_wl                  = '0;
    assign l2b0_fromaxi_ar_bl_eq2_wl                  = '0;
    assign l2b0_fromaxi_ar_bl_eq3_wl                  = '0;
    assign l2b0_fromaxi_ar_bp                         = '0;
    assign l2b0_toaxi_r_wl                            = '0;
    assign l2b0_toaxi_r_bp                            = '0;
    assign l2b0_fromaxi_aw_wl                         = '0;
    assign l2b0_fromaxi_aw_bl_eq0_wl                  = '0;
    assign l2b0_fromaxi_aw_bl_eq1_wl                  = '0;
    assign l2b0_fromaxi_aw_bl_eq2_wl                  = '0;
    assign l2b0_fromaxi_aw_bl_eq3_wl                  = '0;
    assign l2b0_fromaxi_aw_bp                         = '0;
    assign l2b0_fromaxi_w_wl                          = '0;
    assign l2b0_fromaxi_w_bp                          = '0;
    assign l2b0_fromaxi_smp_read_req_num              = '0;
    assign l2b0_fromaxi_smp_read_req_sum              = '0;
    assign l2b0_fromaxi_smp_write_req_num             = '0;
    assign l2b0_fromaxi_smp_write_req_sum             = '0;
    assign l2b0_fromaxi_smp_atomic_req_num            = '0;
    assign l2b0_fromaxi_smp_atomic_req_sum            = '0;
    assign l2b0_align_awdb_full                       = '0;
    assign l2b0_hittest_ht_bypass_read_wl             = '0;
    assign l2b0_hittest_ht_cache_read_wl              = '0;
    assign l2b0_hittest_ht_bypass_write_wl            = '0;
    assign l2b0_hittest_ht_cache_write_wl             = '0;
    assign l2b0_hittest_ht_atomic_wl                  = '0;
    assign l2b0_hittest_ht_bps_hit_wl                 = '0;
    assign l2b0_hittest_ht_miss_wl                    = '0;
    assign l2b0_frommemsch_nsp_rtn_wl                 = '0;
    assign l2b0_frommemsch_nsp_rtn_bp                 = '0;
    assign l2b0_tomemsch_nsp_read_bl_eq1_wl           = '0;
    assign l2b0_tomemsch_nsp_read_bl_eq3_wl           = '0;
    assign l2b0_tomemsch_nsp_read_bl_eq5_wl           = '0;
    assign l2b0_tomemsch_nsp_read_bl_eq7_wl           = '0;
    assign l2b0_tomemsch_nsp_write_bl_eq1_wl          = '0;
    assign l2b0_tomemsch_nsp_write_bl_eq3_wl          = '0;
    assign l2b0_tomemsch_nsp_write_bl_eq5_wl          = '0;
    assign l2b0_tomemsch_nsp_write_bl_eq7_wl          = '0;
    assign l2b0_memif_to_ddr_read_wl                  = '0;
    assign l2b0_memif_to_ddr_read_stall_by_rob        = '0;
    assign l2b0_memif_to_ddr_read_stall_by_ddr        = '0;
    assign l2b0_memif_to_ddr_read_stall_by_trid       = '0;
    assign l2b0_memif_to_ddr_write_wl                 = '0;
    assign l2b0_memif_to_ddr_write_stall_by_data_sync = '0;
    assign l2b0_memif_to_ddr_write_stall_by_ddr       = '0;
    assign l2b0_memif_to_ddr_write_stall_by_trid      = '0;
    assign l2b0_memif_memreq_full                     = '0;
    assign l2b0_memif_smp_read_req_num                = '0;
    assign l2b0_memif_smp_read_req_sum                = '0;
    assign l2b0_reqsch_sortq_full                     = '0;
    assign l2b0_reqsch_sortq_stall_but_not_full       = '0;
    assign l2b0_reqsch_disp_wl                        = '0;
    assign l2b0_reqsch_disp_stall                     = '0;
    assign l2b0_ramctrl_0_reqarb_wl                   = '0;
    assign l2b0_ramctrl_0_reqarb_stall_by_sram        = '0;
    assign l2b0_ramctrl_0_data_sram_read_wl           = '0;
    assign l2b0_ramctrl_0_data_sram_write_wl          = '0;
    assign l2b0_ramctrl_1_reqarb_wl                   = '0;
    assign l2b0_ramctrl_1_reqarb_stall_by_sram        = '0;
    assign l2b0_ramctrl_1_data_sram_read_wl           = '0;
    assign l2b0_ramctrl_1_data_sram_write_wl          = '0;
    assign l2b1_busy                                  = '0;
    assign l2b1_fromaxi_ar_wl                         = '0;
    assign l2b1_fromaxi_ar_bl_eq0_wl                  = '0;
    assign l2b1_fromaxi_ar_bl_eq1_wl                  = '0;
    assign l2b1_fromaxi_ar_bl_eq2_wl                  = '0;
    assign l2b1_fromaxi_ar_bl_eq3_wl                  = '0;
    assign l2b1_fromaxi_ar_bp                         = '0;
    assign l2b1_toaxi_r_wl                            = '0;
    assign l2b1_toaxi_r_bp                            = '0;
    assign l2b1_fromaxi_aw_wl                         = '0;
    assign l2b1_fromaxi_aw_bl_eq0_wl                  = '0;
    assign l2b1_fromaxi_aw_bl_eq1_wl                  = '0;
    assign l2b1_fromaxi_aw_bl_eq2_wl                  = '0;
    assign l2b1_fromaxi_aw_bl_eq3_wl                  = '0;
    assign l2b1_fromaxi_aw_bp                         = '0;
    assign l2b1_fromaxi_w_wl                          = '0;
    assign l2b1_fromaxi_w_bp                          = '0;
    assign l2b1_fromaxi_smp_read_req_num              = '0;
    assign l2b1_fromaxi_smp_read_req_sum              = '0;
    assign l2b1_fromaxi_smp_write_req_num             = '0;
    assign l2b1_fromaxi_smp_write_req_sum             = '0;
    assign l2b1_fromaxi_smp_atomic_req_num            = '0;
    assign l2b1_fromaxi_smp_atomic_req_sum            = '0;
    assign l2b1_align_awdb_full                       = '0;
    assign l2b1_hittest_ht_bypass_read_wl             = '0;
    assign l2b1_hittest_ht_cache_read_wl              = '0;
    assign l2b1_hittest_ht_bypass_write_wl            = '0;
    assign l2b1_hittest_ht_cache_write_wl             = '0;
    assign l2b1_hittest_ht_atomic_wl                  = '0;
    assign l2b1_hittest_ht_bps_hit_wl                 = '0;
    assign l2b1_hittest_ht_miss_wl                    = '0;
    assign l2b1_frommemsch_nsp_rtn_wl                 = '0;
    assign l2b1_frommemsch_nsp_rtn_bp                 = '0;
    assign l2b1_tomemsch_nsp_read_bl_eq1_wl           = '0;
    assign l2b1_tomemsch_nsp_read_bl_eq3_wl           = '0;
    assign l2b1_tomemsch_nsp_read_bl_eq5_wl           = '0;
    assign l2b1_tomemsch_nsp_read_bl_eq7_wl           = '0;
    assign l2b1_tomemsch_nsp_write_bl_eq1_wl          = '0;
    assign l2b1_tomemsch_nsp_write_bl_eq3_wl          = '0;
    assign l2b1_tomemsch_nsp_write_bl_eq5_wl          = '0;
    assign l2b1_tomemsch_nsp_write_bl_eq7_wl          = '0;
    assign l2b1_memif_to_ddr_read_wl                  = '0;
    assign l2b1_memif_to_ddr_read_stall_by_rob        = '0;
    assign l2b1_memif_to_ddr_read_stall_by_ddr        = '0;
    assign l2b1_memif_to_ddr_read_stall_by_trid       = '0;
    assign l2b1_memif_to_ddr_write_wl                 = '0;
    assign l2b1_memif_to_ddr_write_stall_by_data_sync = '0;
    assign l2b1_memif_to_ddr_write_stall_by_ddr       = '0;
    assign l2b1_memif_to_ddr_write_stall_by_trid      = '0;
    assign l2b1_memif_memreq_full                     = '0;
    assign l2b1_memif_smp_read_req_num                = '0;
    assign l2b1_memif_smp_read_req_sum                = '0;
    assign l2b1_reqsch_sortq_full                     = '0;
    assign l2b1_reqsch_sortq_stall_but_not_full       = '0;
    assign l2b1_reqsch_disp_wl                        = '0;
    assign l2b1_reqsch_disp_stall                     = '0;
    assign l2b1_ramctrl_0_reqarb_wl                   = '0;
    assign l2b1_ramctrl_0_reqarb_stall_by_sram        = '0;
    assign l2b1_ramctrl_0_data_sram_read_wl           = '0;
    assign l2b1_ramctrl_0_data_sram_write_wl          = '0;
    assign l2b1_ramctrl_1_reqarb_wl                   = '0;
    assign l2b1_ramctrl_1_reqarb_stall_by_sram        = '0;
    assign l2b1_ramctrl_1_data_sram_read_wl           = '0;
    assign l2b1_ramctrl_1_data_sram_write_wl          = '0;
    assign gc_cr_clk_status3_l2g                      = '0;
    assign gc_cr_l2_cfi_statusi_l2b0_finish           = '0;
    assign gc_cr_l2_cfi_statusi_l2b1_finish           = '0;
    assign gc_cr_l2g_idle_l2g                         = '1;
    assign gc_cr_l2g_error0_l2b0                      = '0;
    assign gc_cr_l2g_error0_l2b1                      = '0;

endmodule
