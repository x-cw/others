/*


*/
package gc_l2_bank_group_pkg;


localparam int unsigned L2_BANK_WRAP_AXI_PIPE_STAGES [4:0] = '{1, 2, 3, 3, 1};
localparam int unsigned L2_BANK_WRAP_NSP_PIPE_STAGES [4:0] = '{4, 2, 1, 2, 4};



// Based on floorplan, bank wrap 2 and bank wrap 1 are close to NSP. 
// bank wrap 0 and bank wrap 3 are far away from NSP.
//
// bank wrap      NSP port pipes      AXI port pipes
// 0              4                   1
// 1              2                   3
// 2              1                   3
// 3              2                   2              
// 4              4                   1

// AXI interface pipe control
localparam int unsigned L2_BANK_INT_AXI_PIPE_TYPE       = gpc_gfx_timing_buffer_pack_::GPC_GFX_TIMING_BUFFER_RSTL;

// NSP interface pipe control
localparam int unsigned L2_BANK_INT_NSP_PIPE_TYPE       = gpc_gfx_timing_buffer_pack_::GPC_GFX_TIMING_BUFFER_RSTL;

// configure register pipe control
localparam int unsigned L2_BANK_INT_REG_PIPE_STAGES     = 3;

endpackage: gc_l2_bank_group_pkg

