/*

 * #==========================================================================#
 * |                                                                          |
 * |  Copyright (c) 2022, Fantasy Technologies Limited and/or its         |
 * |  affiliated group companies ("Fantasy"). All rights reserved.        |
 * |  No part of this content, either material or conceptual may be copied    |
 * |  or distributed, transmitted, transcribed, stored in a retrieval system  |
 * |  or translated into any human or computer language in any form by any    |
 * |  means, electronic, mechanical manual, or otherwise, or disclosed to     |
 * |  third parties without the express written permission of Fantasy.    |
 * |                                                                          |
 * #==========================================================================#

 */


// ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////-
// entity name: gpc_gfx_rstl_fast_in 
// Component Description: IMGLIB3 Registered Staller
// Inserts a register in the valid, enable and data path between upstream and downstream modules in order to break a timing path.
// Data from the upstream module is always subject to at least a cycle delay as a result of inserting an RSTL into the path.
//
// The multiplexer is moved from input of component to output for better timing/reduced fanout on the input. Functionality otherwise
// identical to an gpc_gfx_rstl.
//
// The gpc_gfx_rstl effectively operates as a 2-entry FIFO; when empty, data will be loaded directly into the input_register
// stage, where it will be presented to the downstream module on the following cycle with vout asserted. If the downstream enable is
// set, then the data from input_register will be transferred downstream. If the downstream enable is low, the data will be
// clocked into hld_register. If more data is presented upstream on the same cycle this will replace the data in input_register.
//
// The output multiplexer selects whether data is presented to the downstream module from input_register or hld_register depending
// on whether 1 or 2 beats of data are resident in the RSTL.
//
// The area cost associated with adding a Registered Staller into the design is the 2 register stages of width W plus the muxing
// logic, however valid and data downstream, and enable upstream are all registered breaking any timing path across the interface.
//
// Generics:
// w           - INTEGER
//             - Width of Data bus Input/Output std_logic_vector
//
// Portlist:
// clk     - Clock Input
// resetn  - Active-low asynchronous Reset
// din     - Data bus input (sized by generic w)
// vin     - Valid input from upstream module
// eout    - Enable output to upstream module
// dout    - Data bus output (sized by generic w)
// vout    - Valid output to downstream module
// ein     - Enable input from downstream module
// ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////-
//
//            input_register       hld_register
//               +//////+            +//////+
//               |      |            |      |
// din +////////-+      +////+//////-+      +//-+
//               |      |    |       |      |   |
//               |      |    |       |      |   |    +-
//               |\     |    |       |\     |   |    | \
//           +//-+/     |    |    +//+/     |   |    |  \
//           |   |      |    |    |  |      |   +////+   |
//           |   +//////+    |    |  +//////+        |   |
//           |               |    |                  |   +//////-+ dout
//           |               |    |                  |   |
//           |               |    |                  |   |
//           |               +//////////////////////-+   |
//           |                    |                  |  /
//           |                    |                  | /
// clk +////-+////////////////////+                  +-
//
// ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////-



module gpc_gfx_rstl_fast_in_
#(
   parameter int                                      w                                                            = 2               
)
(
   input    logic                                                        clk                                     ,
        input    logic                                                        resetn                                  ,
        // upstream signals
        input    logic [ w - 1 : 0 ]                                          din                                     ,
        input    logic                                                        vin                                     ,
        output   logic                                                        eout                                    ,
        // downstream signals
        output   logic [ w - 1 : 0 ]                                          dout                                    ,
        output   logic                                                        vout                                    ,
        input    logic                                                        ein                                       
);
   
   logic [ w - 1 : 0 ]                           input_register                          ;
   logic [ w - 1 : 0 ]                           hld_register                            ;
   
   logic                                         eout_l                                  ;
   logic                                         input_valid                             ;
   logic                                         hld_valid                               ;
   logic                                         input_enable                            ;
   

//                                                  ______
//                                                 |      |
//                                                 |      | hld_valid
//                                                 |      |
//                                                 |      | hld_register
//                                                 |      | 
//           ______                                |      | 
//          |      |                               |______|
//     vin  |      |  input_valid     
//          |      |
//     din  |      |  input_register
//          |      |
//    eout  |      |  input_enable
//          |______|
//
//
//
//
//
   
   always_ff @(posedge clk) begin : p_input_register
      begin
         if ( vin == 1'b1 & eout_l == 1'b1 ) begin    // COV:tag0
            input_register <= din ;
         end
      end
   end // p_input_register
   
   always_ff @(posedge clk) begin : p_hld_register
      begin
         // update the holding register if enable in is low, there is data on the input valid and the register is empty
         if ( ( input_valid == 1'b1 & ( input_enable == 1'b0 ) ) & hld_valid == 1'b0 ) begin
            hld_register <= input_register ;
         end
      end
   end // p_hld_register
   
   always_ff @(posedge clk or negedge resetn) begin : p_input_valid
      if ( resetn == 1'b0 ) begin
         input_valid <= 1'b0 ;
      end else begin
         // 
         if ( eout_l == 1'b1 & ( vin == 1'b1 | input_valid == 1'b1 ) ) begin
            input_valid <= vin ;
         end
      end
   end // p_input_valid
   
   always_ff @(posedge clk or negedge resetn) begin : p_hld_valid
      if ( resetn == 1'b0 ) begin
         hld_valid <= 1'b0 ;
      end else begin
         // the holding register has valid data if enable in drops, and there is valid data on the input register at this time.
         if ( input_valid == 1'b1 & ( input_enable == 1'b0 ) ) begin
            hld_valid <= input_valid ;
         // the holding register valid will be absorbed when enable rises, however eout will still be low so no new data
         // is accepted by the module.
         end else if ( hld_valid == 1'b1 & ( input_enable == 1'b1 ) ) begin
            hld_valid <= 1'b0 ;
         end
      end
   end // p_hld_valid
   
   always_ff @(posedge clk or negedge resetn) begin : p_eout_l
      if ( resetn == 1'b0 ) begin
         eout_l <= 1'b1 ;
      end else begin
         eout_l <= input_enable | ~ ( input_valid | hld_valid ) | ~ ( hld_valid | vin ) | ~ ( input_valid | vin ) ;
      end
   end // p_eout_l
   
   // allow an enable on the next cycle if either the input register or the holding register is empty
   // and the clk is currently on.
   assign input_enable = ein ;
   
   
   
   assign vout = hld_valid | input_valid ;
   // use holding register by preference.
   assign dout = hld_valid == 1'b1 ? hld_register : input_register  ;
   assign eout = eout_l ;
   
endmodule // gpc_gfx_rstl_fast_in
