/*

 * #==========================================================================#
 * |                                                                          |
 * |  Copyright (c) 2022, Fantasy Technologies Limited and/or its         |
 * |  affiliated group companies ("Fantasy"). All rights reserved.        |
 * |  No part of this content, either material or conceptual may be copied    |
 * |  or distributed, transmitted, transcribed, stored in a retrieval system  |
 * |  or translated into any human or computer language in any form by any    |
 * |  means, electronic, mechanical manual, or otherwise, or disclosed to     |
 * |  third parties without the express written permission of Fantasy.    |
 * |                                                                          |
 * #==========================================================================#

 */


// ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////-
// Entity name: gpc_gfx_round_robin_select
//
// Component Description:
//    Round robin mux between NUM_INPUTS vectors of VEC_WIDTH bits implemented as priority_select with 2 priority levels
//    If any valid input is marked as high priority, the one with lowest index is muxed. If there are no valid inputs with high
//    priority, the valid input with low priority with the lowest index is muxed.
//    Propagation delay to vec_out should be significantly better than an equivalent implementation using round_robin function
//    followed by a mux - should be approximately the same as the mux alone. Area should also be less.
//    Implementation is commented inline.
//
// Generics:
//    VEC_WIDTH  - width of vectors being multiplexed
//    NUM_INPUTS - number of input vectors being multiplexed
//
// Portlist:
//    vecs_in    - vectors to be multiplexed. Vectors should be concatenated into a single std_logic_vector.
//    valids_in  - valid for each vector.
//    high_priority  - priority mask. 1 bit for each input. E.g.: a mask like 111100 would mean that inputs bits 2,3,4,5 have higher
//                       priority. Set to 0x0 at the beginning (it would behave as priority_select).
//                       Note: having high_priority(i)='1' and high_priority(j)='0', with i<j, (e.g. 111101000)
//                       will result in incorrect behaviour
//                       The designer is not required to drive this input with anything else than:
//                          * 0x0 at the beginning
//                          * a registered version of next_high_priority, after a request has been accepted
//    vec_out    - first valid vector. Will select most significant vector if there are no valid_in bits.
//    valid_out  - valid bit for vec_out = or_reduce(valids_in)
//    index      - index of vector selected. Will be (others => '1') if there are no valid_in bits.
//    enables_in - one-hot encoding of the selected index, i.e. the enables to send to the requester (assuming the downstream accepts the
//                        selected data.
//    next_high_priority - priority mask to use in the next iteration in order to have a round robin behaviour. E.g. if input 3 is
//                       selected (so index=0x3), next_high_priority is 111...1110000
//
// Example usage, 8-bit 4-input round robin select:
//    type t_array8 is array (natural range <>) of std_logic_vector(7 downto 0);
//    signal in_data        : t_array8(3 downto 0);
//    signal in_valids      : std_logic_vector(3 downto 0);
//    signal in_enables     : std_logic_vector(3 downto 0);
//    signal in_data_concat : std_logic_vector(8*4-1 downto 0);
//    signal selected_data  : std_logic_vector(7 downto 0);
//    signal out_valid      : std_logic;
//    signal selected_index : std_logic_vector(2 downto 0);
//    signal high_priority_mask      : std_logic_vector(3 downto 0);
//    signal next_high_priority_mask : std_logic_vector(3 downto 0);
//    [...]
//
//    in_data_concat <= in_data(3) & in_data(2) & in_data(1) & in_data(0);
//
//    i_gpc_gfx_round_robin_select: gpc_gfx_round_robin_select
//       generic map (
//          VEC_WIDTH  => 8,
//          NUM_INPUTS => 4)
//       port map (
//          vecs_in            => in_data_concat,
//          valids_in          => in_valids,
//          high_priority      => high_priority_mask,
//          vec_out            => selected_data,
//          valid_out          => out_valid,
//          index              => selected_index,
//          enables_in         => in_enables,
//          next_high_priority => next_high_priority_mask);
//
//    p_high_priority_mask_reg : process(clk, resetn)
//    begin
//       if resetn = '0' then
//          high_priority_mask  <= (others => '0');         // Round-robin input value must have a reset value
//       elsif (rising_edge(clk)) then
//          if out_valid = '1' and downstream_enable = '1' then  // i.e. the output of the RR select has been accepted by the downstream
//             high_priority_mask <= next_high_priority_mask;
//          end if;
//       end if;
//    end process p_high_priority_mask_reg;
// 
// ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////-


module gpc_gfx_round_robin_select_
#(
      parameter int                                      VEC_WIDTH                                                    = 32             ,
      parameter int                                      NUM_INPUTS                                                   = 8                
)
(
      input    logic [ VEC_WIDTH * NUM_INPUTS - 1 : 0 ]                     vecs_in                                 ,
      input    logic [ NUM_INPUTS - 1 : 0 ]                                 valids_in                               ,
      input    logic [ NUM_INPUTS - 1 : 0 ]                                 high_priority                           ,
      output   logic [ VEC_WIDTH - 1 : 0 ]                                  vec_out                                 ,
      output   logic                                                        valid_out                               ,
      output   logic [ $clog2 ( NUM_INPUTS ) - 1 : 0 ]                      index                                   ,
      output   logic [ NUM_INPUTS - 1 : 0 ]                                 enables_in                              ,
      output   logic [ NUM_INPUTS - 1 : 0 ]                                 next_high_priority                        
);
   import gpc_gfx_std_func_pack_::*;

   localparam int                                           NUM_STAGES                               = $clog2 ( NUM_INPUTS )         ;    // number of 2:1 mux stages
   localparam int                                           NUM_ELEMS                                = 2 ** NUM_STAGES               ;    // =NUM_INPUTS rounded up to next power of 2

   // array is NUM_ELEMS wide (rather than NUM_INPUTS) to allow a regular mux tree to be created.
   // STAGE0 is the input, hence NUM_STAGES+1 elements in the arrays

   typedef logic [ NUM_ELEMS - 1 : 0 ] [ VEC_WIDTH - 1 : 0 ] t_data_array ;
   typedef t_data_array [ NUM_STAGES : 0 ] t_data_stages ;
   typedef logic [ NUM_STAGES : 0 ] [ NUM_ELEMS - 1 : 0 ] t_valid_stages ;
   typedef logic [ NUM_ELEMS - 1 : 0 ] [ $clog2 ( NUM_INPUTS ) - 1 : 0 ] t_index_array ;
   typedef t_index_array [ NUM_STAGES : 0 ] t_index_stages ;
   typedef logic [ NUM_ELEMS - 1 : 0 ] [ NUM_INPUTS - 1 : 0 ] t_one_hot_selected_array ;
   typedef t_one_hot_selected_array [ NUM_STAGES : 0 ] t_one_hot_stages ;


   always_comb begin : p_vec_out
      t_data_stages                                 data_stages                             ;
      t_valid_stages                                valid_stage                             ;
      t_valid_stages                                high_priority_stage                     ;
      t_index_stages                                index_stage                             ;
      t_one_hot_stages                              next_high_priority_stages               ;
      t_one_hot_stages                              enables_stage                           ;
      // Redundant default assignments to avoid spcrious "read but not set" Spyglass warnings
      data_stages = '0;
      valid_stage = '0;
      index_stage = '0;
      high_priority_stage = '0;
      next_high_priority_stages = '0;
      enables_stage = '0;

      // Default assignment for unused inputs in the tree to the MS element (should cause unneeded muxes to disappear; c=v?a:a <=> c=a)
      for (int i = NUM_INPUTS; i < NUM_ELEMS; i++) begin
         data_stages [ 0 ][ i ] = vecs_in [ VEC_WIDTH * ( NUM_INPUTS ) - 1 : VEC_WIDTH * ( NUM_INPUTS - 1 ) ];
      end 
      valid_stage [ 0 ] = '0;
      index_stage [ 0 ] = '0;

      // Assign one-hot encoding of selected index
      for ( int ELEM = 0 ; ELEM <= NUM_INPUTS - 1 ; ELEM = ELEM + 1 ) begin
         data_stages [ 0 ] [ ELEM ] = vecs_in [ VEC_WIDTH * ELEM +: VEC_WIDTH ] ;
      end

      // next_high_priority_stages will be muxed in the tree in order to provide next_high_priority
      // next_high_priority_stages(0)(0) = "1111...1110";
      // next_high_priority_stages(0)(1) = "1111...1100";
      // ...
      // next_high_priority_stages(0)(NUM_INPUTS-1) = "0000...0000";
      //
      // i.e.
      // If the i-th input is selected, the next cycle the inputs from (i+1) to NUM_INPUTS-1 will need to have higher priority in
      // order to guarantee the fairness of the round-robin mechanism.
      // So next_high_priority will need to have '1' in all the bits from NUM_INPUTS-1 down to (i+1)
      // next_high_priority(0) cannot be 1, so next_high_priority_stages(0)(*)(0) is always 0
      for ( int ELEM = 0 ; ELEM <= NUM_INPUTS - 2 ; ELEM = ELEM + 1 ) begin    // no need to set any '1' in next_high_priority_stages(0)(NUM_INPUTS-1) as when the last input
         // is selected, the round-robin will start from the first element and so next_high_priority will be 0x0
         next_high_priority_stages[0][ELEM] = {NUM_INPUTS{1'b1}} << (ELEM+1);
      end

      valid_stage [ 0 ] [ NUM_INPUTS - 1 : 0 ] = valids_in ;

      high_priority_stage [ 0 ] [ NUM_INPUTS - 1 : 0 ] = high_priority [ NUM_INPUTS - 1 : 0 ] ;

      // Assign one-hot encoding of input index to 0th array stage. It will be used to infer in_enables
      // (i.e. the one-hot encoding of selected_index)
      for ( int ELEM = 0 ; ELEM <= NUM_INPUTS - 1 ; ELEM = ELEM + 1 ) begin
         enables_stage [ 0 ] [ ELEM ] [ ELEM ] = 1'b1 ;
      end

      // Mux elements as below (each stage has the same number of elements, but the MS ones are
      // progressively not used);
      // STAGE   0   1   2   3
      //         7-+
      // E       6-+-3-+
      // L             |
      // E       5-+   |
      // M       4-+-2-+-1-+
      //                   |
      //         3-+       |
      //         2-+-1-+   |
      //               |   |
      //         1-+   |   |
      //         0-+-0-+-0-+-0
      //
      // Valids are ORed together in pairs for each element of each stage, to generate a valid for the next stage
      //
      // Index is generated per element, one bit per stage. Each stage passes through bits from earlier stages, adding its own bit to the top.

      for ( int STAGE = 1 ; STAGE <= NUM_STAGES ; STAGE = STAGE + 1 ) begin
         for ( int ELEM = 0 ; ELEM <= ( NUM_ELEMS / ( 2 ** STAGE ) ) - 1 ; ELEM = ELEM + 1 ) begin
            //report "data_stages(" & integer'image(STAGE)   & ")(" & integer'image(ELEM)     & ") = " &
            //       "data_stages(" & integer'image(STAGE-1) & ")(" & integer'image(2*ELEM)   & ") or " &
            //       "data_stages(" & integer'image(STAGE-1) & ")(" & integer'image(2*ELEM+1) & ")";

            // The first element of a node is muxed when:
            // the second element is not valid OR
            // (the first element is valid AND the second element doesn't have higher priority than the first one, so either the 
            // first one has high priority already or the second one has lower priority)
            if ( valid_stage [ STAGE - 1 ] [ 2 * ELEM + 1 ] == 1'b0 | ( valid_stage [ STAGE - 1 ] [ 2 * ELEM ] == 1'b1 & ( high_priority_stage [ STAGE - 1 ] [ 2 * ELEM ] == 1'b1 | high_priority_stage [ STAGE - 1 ] [ 2 * ELEM + 1 ] == 1'b0 ) ) ) begin    // COV:tag0   
               data_stages [ STAGE ] [ ELEM ] = data_stages [ STAGE - 1 ] [ 2 * ELEM ] ;
               index_stage [ STAGE ] [ ELEM ] = index_stage [ STAGE - 1 ] [ 2 * ELEM ] ;
               index_stage [ STAGE ] [ ELEM ] [ STAGE - 1 ] = 1'b0 ;
               next_high_priority_stages [ STAGE ] [ ELEM ] = next_high_priority_stages [ STAGE - 1 ] [ 2 * ELEM ] ;
               enables_stage [ STAGE ] [ ELEM ] = enables_stage [ STAGE - 1 ] [ 2 * ELEM ] ;
            end else begin
               data_stages [ STAGE ] [ ELEM ] = data_stages [ STAGE - 1 ] [ 2 * ELEM + 1 ] ;
               index_stage [ STAGE ] [ ELEM ] = index_stage [ STAGE - 1 ] [ 2 * ELEM + 1 ] ;
               index_stage [ STAGE ] [ ELEM ] [ STAGE - 1 ] = 1'b1 ;
               next_high_priority_stages [ STAGE ] [ ELEM ] = next_high_priority_stages [ STAGE - 1 ] [ 2 * ELEM + 1 ] ;
               enables_stage [ STAGE ] [ ELEM ] = enables_stage [ STAGE - 1 ] [ 2 * ELEM + 1 ] ;
            end
            valid_stage [ STAGE ] [ ELEM ] = valid_stage [ STAGE - 1 ] [ 2 * ELEM ] | valid_stage [ STAGE - 1 ] [ 2 * ELEM + 1 ] ; 

            // infer if the node has highest priority
            high_priority_stage [ STAGE ] [ ELEM ] = high_priority_stage [ STAGE - 1 ] [ 2 * ELEM ] | ( high_priority_stage [ STAGE - 1 ] [ 2 * ELEM + 1 ] & valid_stage [ STAGE - 1 ] [ 2 * ELEM + 1 ] ) ;    // COV:tag1 
         end

      end

      // outputs from last stage
      vec_out = data_stages [ NUM_STAGES ] [ 0 ] ;
      valid_out = valid_stage [ NUM_STAGES ] [ 0 ] ;
      index = index_stage [ NUM_STAGES ] [ 0 ] ;
      next_high_priority = next_high_priority_stages [ NUM_STAGES ] [ 0 ] ;
      enables_in = enables_stage [ NUM_STAGES ] [ 0 ] ;
   end // p_vec_out

endmodule // gpc_gfx_round_robin_select
