module ecc_top #(
    parameter data_width =  32,
    parameter ecc_width =  5,
    parameter min_mask = 8,
    parameter ram_width = 52
) (
    input     [data_width-1:0]             encoder_data_in, 
    output    [ram_width-1:0]              encoder_data_out,
    input     [ram_width-1:0]              decoder_data_in,
    output    [data_width-1:0]             decoder_data_out
);

    generate 
         for(genvar i=0;i<=data_width/min_mask-1;i=i+1)begin:ram_gen
             assign encoder_data_out[i*(min_mask+ecc_width)+:min_mask]=encoder_data_in[i*min_mask+:min_mask]; 
             ecc_encoder #(min_mask,ecc_width)  ecc_encoder_inst (.data(encoder_data_in[i*min_mask+:min_mask]),.ecc(encoder_data_out[((i+1)*(min_mask+ecc_width)-1)-:ecc_width]));
             ecc_decoder #(min_mask,ecc_width)  ecc_decoder_inst (.data(decoder_data_in[i*(min_mask+ecc_width)+:min_mask]),.ecc(decoder_data_in[((i+1)*(min_mask+ecc_width)-1)-:ecc_width]), .ecc_enable(1'b1), .data_out(decoder_data_out[i*min_mask+:min_mask]), .cor_err(), .unc_err());
         end
    endgenerate

endmodule

