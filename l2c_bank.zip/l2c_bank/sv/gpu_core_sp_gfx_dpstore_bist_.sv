/*

 * #==========================================================================#
 * |                                                                          |
 * |  Copyright (c) 2022, Fantasy Technologies Limited and/or its         |
 * |  affiliated group companies ("Fantasy"). All rights reserved.        |
 * |  No part of this content, either material or conceptual may be copied    |
 * |  or distributed, transmitted, transcribed, stored in a retrieval system  |
 * |  or translated into any human or computer language in any form by any    |
 * |  means, electronic, mechanical manual, or otherwise, or disclosed to     |
 * |  third parties without the express written permission of Fantasy.    |
 * |                                                                          |
 * #==========================================================================#

 */

// ////////////////////////////////////////////////////////////////////////////-
// entity:  gpu_core_sp_gfx_dpstore_bist_
//
// purpose: Dual port synchronous RAM with configurable write word partitions
//          and enabling the optional inclusion of a BIST wrapper.
//
// +////////////////////////-+////////+////-+////-+////////+////////////////+
// | gpu_core_sp_gfx_dpstore_        |        | RAM | Reg | Bypass | Design         |
// |             w,p,d,log2d | Clocks | O/P | O/P | Input  | Suitability    |
// +////////////////////////-+////////+////-+////-+////////+////////////////+
// | _.vhd & _novital.vhd    |  2:RW  | Yes |     |        | Fundamental    |
// | bist.vhdm               | single | Yes |     |        | Low level only |<<<
// | bist_async.vhdm         |  2:RW  | Yes |     |        | Low level only |
// | gen_bist_r.vhd          | single |     | Yes |        | Standard use   |
// | pipeline_gen_bist_r.vhd | single |     | Yes |        | Standard use   |
// | bypass_gen_bist_r.vhd   | single |     | Yes |  Yes   | Standard use   |
// | flexible_gen_bist_r.vhd | single | Yes | Yes |  Yes   | Standard use   |
// | flexible_gen_bist_r     |        |     |     |        |                |
// |              _async.vhd |  2:RW  | Yes | Yes |  Yes   | Standard use   |
// +////////////////////////-+////////+////-+////-+////////+////////////////+
//
//
//        gpu_core_sp_gfx_dpstore_[pipeline|bypass]_gen_bist_r
//         |
//         +- gpu_core_sp_gfx_dpstore_bist                      << YOU ARE HERE
//             |
//             +- gpu_core_sp_gfx_dpstore
//             |
//             +- [ gpu_core_sp_gfx_bistwrap ]
//
// ////////////////////////////////////////////////////////////////////////////-

// DIMENSIONS
//   Physical generics: w, d, p, log2d, wrcen*
//
//                        width
//              <////////// w //////////>
//
//              +//////////////////////-+   ^
//              |_______________________|   |
//              |_______________________|   |  d
//              |_______________________|      e
//              |                       |   d  p
//              |                       |      t
//              :                       :   |  h
//              |                       |   |
//              +//////////////////////-+   v
//                         w/p *
//              <- p -><- p -> .. <- p ->
//                      partitions
//
//   All partitions are equal in size. In other words, the generic w is an
//   integer multiple of generic p.
//
//   Example partition:
//      [w = 128, p = 32] => w/p = 4 partitions => 4 write enables

// PORTS
//   +////////////////////////////////////////////////////////-+
//   | name          |  bits  |dir| description                |
//   +////////////////////////////////////////////////////////-+
//   | rd_addr       | log2d  | i | read address               |
//   | rd_en         |   1    | i | read strobe (ACTIVE LOW)   |
//   | rd_data_ram   |   w    | o | read data                  |
//   |               |        |   |                            |
//   | wr_addr       | log2d  | i | write address              |
//   | wr_data       |   w    | i | write data ((w/p)*p bits)  |
//   | wr_en *       |(w/p)+1*| i | write enables*(ACTIVE LOW) |
//   |               |        |   |                            |
//   | clk           |   1    | i | common r/w clock           |
//   | resetn        |   1    | i | reset to BIST (ACTIVE LOW) |
//   |               |        |   |                            |
//   | bist_in       |f(w,p,d)| i | input from BIST controller |
//   | bist_out      |f(w,p,d)| o | result to BIST controller  |
//   +////////////////////////////////////////////////////////-+
//
//  * - wr_en width can be configured with generic wrcen to have an extra bit:
//
//    wrcen
//      0 : w/p bits => one ACTIVE LOW write enable per word partition (default)
//      1 : w/p+1 bits => one ADDITIONAL (ACTIVE LOW) write enable
//
//      If configured, the extra bit indicates that any one of the per word
//      partition write enables is asserted.

// BEHAVIOURIAL MODEL
//   Functional behaviour is similar to gpu_core_sp_gfx_dpstore but this hierarchical level
//   renames the read and write ports and rationalises the soft macro clock line
//   into a single signal.
//
//   Read latency:  1 clock
//   Write latency: 1 clock
//
//                            +//////////////////////////-+
//                            |       gpu_core_sp_gfx_dpstore     |
//                            |                           |
//             rd_addr, rd_en-|//////////////////////.    |
//                            |                      |    |
//                            | +////+   +////-+   +////+ |
//             wr_addr    ///-|-| wr |   |     |   | rd | |
//             wr_en      ///-|-|proc|-/-| mem |-/-|proc|-|///-> rd_data_ram
//             wr_data    ///-|-|    |   |     |   |    | |
//                            | |    |  +|>    |  +|>   | |
//                            | +////+  |+////-+  |+////+ |
//                            |         |         |       |
//                          | +//////////////////////////-+
//                          | +//////////////////////////-+
//             bist_in    ///-|   [ gpu_core_sp_gfx_bistwrap ]    |///-> bist_out
//             resetn     ////|                           |
//                            +//////////////////////////-+

// OPTIONAL UTILITY GENERICS
//   id       : integer value that can be assigned to each instance (default 0)
//                                                                      -=:PB=-
// ////////////////////////////////////////////////////////////////////////////-

module gpu_core_sp_gfx_dpstore_bist_ 
   import gpc_gfx_rambist_pack_::*;



   #(
    parameter   w        = 32, // integer
    parameter   p        = 32, // integer
    parameter   d        = 32, // integer
    parameter   log2d    = 5,  // integer
    parameter   wrcen    = 0,  // integer
    parameter   ECC      = 0,  // integer



    parameter   id       = 0   // integer
    )
(
      input    logic                                   clk,
      //W240 relates to inputs that are not used. This is the case for the resetn input in certain configurations
      //where MEMBIST or ECC is not enabled.
      //spyglass disable_block -rule "W240"
      input    logic                                   resetn,
      //spyglass enable_block -rule "W240"
      input    logic                                   rd_en,
      input    logic [ log2d - 1 : 0 ]                 rd_addr,
      output   logic [ w - 1 : 0 ]                     rd_data_ram,
      input    logic [ ( w / p ) + wrcen - 1 : 0 ]     wr_en,
      input    logic [ log2d - 1 : 0 ]                 wr_addr,
      input    logic [ w - 1 : 0 ]                     wr_data,














      input    logic [dpstore_in(w, p, d, ECC)-1 : 0]  bist_in,
      output   logic [dpstore_out(w, p, d, ECC)-1 : 0] bist_out,
      input    logic                                   tst_gclkenable
);















   ///////////////////////////////////////////////
   // backdoor access
   ///////////////////////////////////////////////












































































   ///////////////////////////////////////////////
   // END backdoor access
   ///////////////////////////////////////////////




































































































































































































































































   logic [ w - 1 : 0 ]                    qa_ram;
   logic [ w - 1 : 0 ]                    db_mux;
   logic [ ( w / p ) - 1 : 0 ]            wenb_mux;


   logic                                  cena_mux;
   logic                                  cenb_mux;
   logic                                  cenb;
   logic [ log2d - 1 : 0 ]                aa_mux;
   logic [ log2d - 1 : 0 ]                ab_mux;






   generate
      if (wrcen == 0) begin : g_cenb_0
         assign cenb = &(wr_en);
      end
   endgenerate

   generate
      if (wrcen == 1) begin : g_cenb_1
         assign cenb = wr_en[w/p];
      end
   endgenerate

   // CUSTOMER BIST IMPLEMENTATION EXPECTED HERE
   assign cena_mux = rd_en;
   assign aa_mux   = rd_addr;




































   assign db_mux = wr_data ;
   assign rd_data_ram = qa_ram ;
   assign wenb_mux = wr_en[(w/p)-1:0] ;
   assign cenb_mux = cenb ;
   assign ab_mux = wr_addr ;


   assign bist_out = 0 ;

   gpu_core_sp_gfx_dpstore
     #(





       .w(w),
       .p(p),

       .d(d),
       .log2d(log2d),
       .id(id)
       ) str
      (
       .CLKA(clk),
       .CENA(cena_mux),
       .AA(aa_mux),
       .QA(qa_ram),
       .CLKB(clk),
       .CENB(cenb_mux),
       .WENB(wenb_mux),
       .AB(ab_mux),
       .DB(db_mux),
       .TE(tst_gclkenable),
       .L2M(),
       .SRAM()
       );

























































































































































































































































































































































































































































































































































































endmodule
