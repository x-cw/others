/*

 * #==========================================================================#
 * |                                                                          |
 * |  Copyright (c) 2023, Fantasy Technologies Limited and/or its         |
 * |  affiliated group companies ("Fantasy"). All rights reserved.        |
 * |  No part of this content, either material or conceptual may be copied    |
 * |  or distributed, transmitted, transcribed, stored in a retrieval system  |
 * |  or translated into any human or computer language in any form by any    |
 * |  means, electronic, mechanical manual, or otherwise, or disclosed to     |
 * |  third parties without the express written permission of Fantasy.    |
 * |                                                                          |
 * #==========================================================================#

 */

module gc_idx_assign 
   import gpc_gfx_std_func_pack_::*;
   //import gpc_dpg_pkg_::*;
   // ---------------------------------------------------------------------------------------------------------------------------------
   // module name: gc_idx_assign
   // purpose: Manage and assign a pool of Indices
   // ---------------------------------------------------------------------------------------------------------------------------------
#(
   parameter      NUM_INDICES = 32,
   parameter      INDEX_BITS  = 5,
   parameter      BLEN_WIDTH  = 3
)(
   input  logic      clk,
   input  logic      resetn,
   output logic      idx_assign_idle,
   // ----------------------------------------------------------------------------
   // Allocate Indices
   // ----------------------------------------------------------------------------
   input  logic                                    allocate_valid,
   input  logic   [BLEN_WIDTH - 1:0]               allocate_size,
   output logic                                    assigned_index_valid,
   output logic   [INDEX_BITS - 1:0]               assigned_index,
   // ----------------------------------------------------------------------------
   // Free Indices
   // ----------------------------------------------------------------------------
   input  logic   [NUM_INDICES - 1:0]  index_freed_mask
);

   logic [7:0]                allocate_mask;
   logic [NUM_INDICES + 6:0]  current_mask_wrap;
   logic [NUM_INDICES - 1:0]  fit_posn_mask;
   logic                      assigned_index_valid_l;
   logic [INDEX_BITS - 1:0]   assigned_index_l;
   logic [INDEX_BITS - 1:0]   assigned_index_rr;
   logic [INDEX_BITS - 1:0]   prev_assigned_index;
   logic [INDEX_BITS - 1:0]   coarse_prev_assigned_index;
   logic [NUM_INDICES - 1:0]  index_used_mask;
   logic [NUM_INDICES - 1:0]  n_index_used_mask;


   assign idx_assign_idle = ~(|(index_used_mask));
   // ----------------------------------------------------------------------------
   // Generate an allocation mask (max burst length = 0x7, 8 indices)
   // ----------------------------------------------------------------------------
   assign allocate_mask = ~((8'b11111110 << (allocate_size)));
   // ----------------------------------------------------------------------------
   // Find out where within our mask the new allocation mask can fit
   // ----------------------------------------------------------------------------
   assign current_mask_wrap = {index_used_mask[6:0], index_used_mask};

   always_comb begin : p_allocate_mask_comb

      for(int unsigned p=0; p<=NUM_INDICES - 1; p++) begin
         // Set the bit corresponding to position p low if any of the next 8 bits in the current mask starting at p and working
         // upwards are set along with the corresponding bit in the 8-bit allocation mask
         fit_posn_mask[p] = (~|(current_mask_wrap[p +: 8] & allocate_mask)); // COV:t0
      end

   end : p_allocate_mask_comb

   assign assigned_index_valid_l = allocate_valid & (|(fit_posn_mask));

   gpc_round_robin_index_arch1_ #(
      .width         (NUM_INDICES),
      .hold_previous (1'b0)
   ) i_gpc_round_robin_index_arch1_assigned_index (
      .valids           (fit_posn_mask),
      .previous_index   (coarse_prev_assigned_index),
      .next_index       (assigned_index_rr)
   );
  
   

   assign assigned_index_l = allocate_valid==1'b1 ? assigned_index_rr : prev_assigned_index;
   assign coarse_prev_assigned_index[INDEX_BITS - 2 +: 2] = prev_assigned_index[INDEX_BITS - 2 +: 2];
   assign coarse_prev_assigned_index[INDEX_BITS - 3:0] = '0;

   always_ff@(posedge clk or negedge resetn) begin : p_index_used_mask_clkdrs
      if(resetn==1'b0) begin
         prev_assigned_index <= '0;
         index_used_mask <= '0;
      end
      else begin
         if(assigned_index_valid_l==1'b1) begin
            prev_assigned_index <= assigned_index_l;
         end
         if(assigned_index_valid_l==1'b1 || (|(index_freed_mask))==1'b1) begin
            index_used_mask <= n_index_used_mask;
         end
      end
   end : p_index_used_mask_clkdrs

   always_comb begin : p_next_index_used_mask_comb
      // Indices which are not being freed this cycle remain high if already set
      n_index_used_mask = index_used_mask & ~index_freed_mask; // COV:t1
      if(assigned_index_valid_l==1'b1) begin
         n_index_used_mask[(assigned_index_l)] = 1'b1;

         for(int unsigned size=1; size<=7; size++) begin
            if(size<=(allocate_size)) begin
               n_index_used_mask[((assigned_index_l) + size)%NUM_INDICES] = 1'b1;
            end
         end

      end
   end : p_next_index_used_mask_comb

   // Assign local copies to outputs
   assign assigned_index_valid = assigned_index_valid_l;
   assign assigned_index = assigned_index_l;
endmodule : gc_idx_assign
