/*

 * #==========================================================================#
 * |                                                                          |
 * |  Copyright (c) 2023, Fantasy Technologies Limited and/or its         |
 * |  affiliated group companies ("Fantasy"). All rights reserved.        |
 * |  No part of this content, either material or conceptual may be copied    |
 * |  or distributed, transmitted, transcribed, stored in a retrieval system  |
 * |  or translated into any human or computer language in any form by any    |
 * |  means, electronic, mechanical manual, or otherwise, or disclosed to     |
 * |  third parties without the express written permission of Fantasy.    |
 * |                                                                          |
 * #==========================================================================#

 */
// Author       : wuce01(SH gpu de group)
// Created On   : 2025-2-12
// Last Modified: 
// Description  : The main function of this module is: add 1ps delay on core_clk
//
module gc_clk_delay
   import gc_clock_gate_pack_::*; //CLK_ALIGN_DELAY
(
    // -----------------------------------------------------------
    // core Interface
    // -----------------------------------------------------------
      input  logic                   core_clk,
    // -----------------------------------------------------------
    // core_resetn Interface
    // -----------------------------------------------------------
      input  logic                   core_resetn,
    // -----------------------------------------------------------
    // aligned Interface
    // -----------------------------------------------------------
      output logic                   aligned_clk,
      output logic                   aligned_resetn,
    // -----------------------------------------------------------
    // unaligned Interface
    // -----------------------------------------------------------
      output logic                   unaligned_clk,
      output logic                   unaligned_resetn

);
   
  `ifndef GPU_SYNTHESIS
     assign #CLK_ALIGN_DELAY aligned_clk = core_clk;
  `else 
     assign aligned_clk = core_clk;
  `endif
  
   assign unaligned_clk    = core_clk;

   assign unaligned_resetn = core_resetn;
   assign aligned_resetn   = core_resetn;

endmodule
