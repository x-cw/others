// +FHDR----------------------------------------------------------------------------
// Copyright (c) 2024, Innosilicon, Inc. Confidential Proprietary
// PROJECT NAME  : xxx
// DEPARTMENT    : GPU core gp3
// AUTHOR        : luoml01
// EMAIL         : luoml01@innosilicon.com.cn
// CREATE ON     : 2024/12/31 14:42
// FILE NAME     : gc_l2_bank_isched.sv
// DESCRIPTION   :          
//         
// Copyright (c) 2024 Innosilicon.
// ALL RIGHTS RESERVED
// 
// ---------------------------------------------------------------------------------
// Modification History:
// Date         By              Version                 Change Description
// ---------------------------------------------------------------------------------
// 2024/12/31   luoml01         1.0                     Original
// 
// -FHDR----------------------------------------------------------------------------


module gc_l2_bank_isched
import gpc_gfx_timing_buffer_pack_::*;
import gc_l2_bank_pkg::*;   
(
   input  logic                                                    clk,
   input  logic                                                    resetn,
   output logic                                                    idle,

   //command from TagCtrl
   //WR, AA, RD, Prefetch
   input  logic                                                    tagctrl_isched_valid,
   output logic                                                    tagctrl_isched_ready,
   input  tagctrl_isched_record_type                               tagctrl_isched_rec,

   //command from WDC
   //WB, WB_WR, FLUSH
   input  logic                                                    wdc_isched_wb_valid,
   output logic                                                    wdc_isched_wb_ready,
   input  wdc_isched_cmd_record_type                               wdc_isched_wb_rec,

   //command from ALIGN
   //buffer mode, WR, AA, RD
   input  logic                                                    align_isched_bm_valid,
   output logic                                                    align_isched_bm_ready,
   input  align_isched_bm_record_type                              align_isched_bm_rec,


   // when isched execute all instr of a sector


   // ----------------------------------------------------------------------------
   // RAM Ctrl Interface
   // ----------------------------------------------------------------------------

   input  logic                    [L2_NUM_RCTRL-1:0]              rctrl_isched_valid,
   input  rctrl_isched_record_type [L2_NUM_RCTRL-1:0]              rctrl_isched_rec,




   output logic                                                    isched_wdc_fetch_data_valid,
   input  logic                                                    isched_wdc_fetch_data_ready,
   output isched_wdc_record_type                                   isched_wdc_fetch_data_rec,


   input logic                                                     wdc_isched_wdata_valid,
   output logic                                                    wdc_isched_wdata_ready,
   input  wdc_isched_data_record_type                              wdc_isched_wdata_rec,

   output logic [ L2_NUM_RCTRL-1:0]                                isched_rctrl_instr_valid,
   input  logic [ L2_NUM_RCTRL-1:0]                                isched_rctrl_instr_ready,
   output isched_rctrl_record_type  [ L2_NUM_RCTRL-1:0]            isched_rctrl_instr_rec,



   output logic [ L2_NUM_RCTRL-1:0]                                isched_rctrl_wdata_valid,
   input  logic [ L2_NUM_RCTRL-1:0]                                isched_rctrl_wdata_ready,
   output isched_rctrl_wdata_record_type  [ L2_NUM_RCTRL-1:0]      isched_rctrl_wdata_rec,


   // ----------------------------------------------------------------------------
   //GDM
   // ----------------------------------------------------------------------------
   
   output logic l2b_reqsch_sortq_full,
   output logic l2b_reqsch_sortq_stall_but_not_full,
   output logic l2b_reqsch_disp_wl,
   output logic l2b_reqsch_disp_stall

);

logic                                                                                                                 l2_bank_isched_rb_idle;
logic                                                                                                                 l2_bank_isched_xbar_idle ;
logic                    [L2_NUM_RCTRL-1:0]                                                                           isched_xbar_instr_valid;
logic                    [L2_NUM_RCTRL-1:0]                                                                           isched_xbar_instr_ready;
isched_xbar_record_type  [L2_NUM_RCTRL-1:0]                                                                           isched_xbar_instr_rec;

logic [L2_NUM_RCTRL-1:0]                                                                                              isched_splitter_valid, isched_splitter_ready;
logic [L2_NUM_RCTRL-1:0]                                                                                              isched_splitter_tbuff_valid, isched_splitter_tbuff_ready;
isched_splitter_record_type [L2_NUM_RCTRL-1:0]                                                                        isched_splitter_rec;
isched_splitter_record_type [L2_NUM_RCTRL-1:0]                                                                        isched_splitter_tbuff_rec;

//logic [3+L2_AXI_ID_WIDTH+L2_NUM_SET_BITS+L2_NUM_WAY_BITS+2+2+L2_IWDB_INDEX_BITS+L2_ISCHED_RB_ENTRY_BITS+4+1-1:0]      isched_splitter_slv[L2_NUM_RCTRL-1 : 0];
//logic [3+L2_AXI_ID_WIDTH+L2_NUM_SET_BITS+L2_NUM_WAY_BITS+2+2+L2_IWDB_INDEX_BITS+L2_ISCHED_RB_ENTRY_BITS+4+1-1:0]      isched_splitter_tbuff_slv[L2_NUM_RCTRL-1 : 0];


logic [L2_NUM_RCTRL-1:0]                                                                                              isched_wdc_cmd_valid;
logic [L2_NUM_RCTRL-1:0]                                                                                              isched_wdc_cmd_ready;
isched_wdc_cmd_tbuff_record_type [L2_NUM_RCTRL-1:0]                                                                   isched_wdc_cmd_rec;
isched_wdc_cmd_tbuff_record_type [L2_NUM_RCTRL-1:0]                                                                   isched_wdc_cmd_tbuff_rec;
logic [L2_NUM_RCTRL-1:0]                                                                                              isched_wdc_cmd_tbuff_valid;
logic [L2_NUM_RCTRL-1:0]                                                                                              isched_wdc_cmd_tbuff_ready;



logic [L2_NUM_RCTRL-1:0]                                                                                              isched_rctrl_waiting_out_valid;
logic [L2_NUM_RCTRL-1:0]                                                                                              isched_rctrl_waiting_out_ready;
isched_waiting_record_type [L2_NUM_RCTRL-1:0]                                                                         isched_rctrl_waiting_out_rec;

logic [L2_NUM_RCTRL-1:0]                                                                                              isched_cmd_valid;
logic [L2_NUM_RCTRL-1:0]                                                                                              isched_cmd_ready;
isched_waiting_record_type [L2_NUM_RCTRL-1:0]                                                                         isched_cmd_rec;


logic [L2_NUM_RCTRL-1:0]                                                                                              isched_iwdb_valid;
logic [L2_NUM_RCTRL-1:0]                                                                                              isched_iwdb_ready;
isched_iwdb_record_type [L2_NUM_RCTRL-1:0]                                                                            isched_iwdb_rec;

logic                                                                                                                 prev_selected_rctrl;
logic                                                                                                                 selected_rctrl;

logic  [L2_NUM_RCTRL-1:0]                                                                                             l2_bank_isched_splitter_idle;

logic  [1:0]                                                                                                          request_end_beat; 

logic                                                             wdc_isched_wb_tbuff_valid      ;
logic                                                             wdc_isched_wb_tbuff_ready      ;
wdc_isched_cmd_record_type                                        wdc_isched_wb_tbuff_rec        ;


logic [L2_NUM_RCTRL-1:0]    [2:0]                                 isched_iwdb_credit_counter     ;
logic [L2_NUM_RCTRL-1:0]                                          isched_iwdb_credit_avaliable   ;
logic [L2_NUM_RCTRL-1:0]                                          isched_wdc_cmd_tbuff_arb_valid ;
logic [L2_NUM_RCTRL-1:0]                                          isched_wdc_cmd_tbuff_arb_ready ;
logic [L2_NUM_RCTRL-1:0]                                          wdc_isched_wdata_fifo_in_valid ;
logic [L2_NUM_RCTRL-1:0]                                          wdc_isched_wdata_fifo_in_ready ;
isched_rctrl_wdata_record_type [L2_NUM_RCTRL-1:0]                 wdc_isched_wdata_fifo_in_rec   ;

assign idle = (&l2_bank_isched_splitter_idle) 
              && (l2_bank_isched_rb_idle) 
              && (l2_bank_isched_xbar_idle) 
              && (|isched_splitter_valid == 1'b0) 
              && (|isched_splitter_tbuff_valid == 1'b0)
              && (|isched_wdc_cmd_valid==1'b0) 
              && (|isched_wdc_cmd_tbuff_valid==1'b0) 
              && (|isched_rctrl_waiting_out_valid == 1'b0) 
              && (wdc_isched_wdata_valid==1'b0) 
              && (isched_rctrl_wdata_valid==1'b0)
              && (wdc_isched_wb_valid==1'b0)
              && (wdc_isched_wb_tbuff_valid==1'b0)
              ;


   


gc_l2_bank_isched_ringbuffer
i_gc_l2_bank_isched_ringbuffer       (
.clk                                 ( clk                                 ) ,
.resetn                              ( resetn                              ) ,
.l2_bank_isched_rb_idle              ( l2_bank_isched_rb_idle              ) ,

.tagctrl_isched_valid                ( tagctrl_isched_valid                ) ,
.tagctrl_isched_ready                ( tagctrl_isched_ready                ) ,
.tagctrl_isched_rec                  ( tagctrl_isched_rec                  ) ,


.isched_xbar_instr_valid             ( isched_xbar_instr_valid             ) ,
.isched_xbar_instr_ready             ( isched_xbar_instr_ready             ) ,
.isched_xbar_instr_rec               ( isched_xbar_instr_rec               ) ,


.rctrl_isched_valid                  ( rctrl_isched_valid                  ) ,
.rctrl_isched_rec                    ( rctrl_isched_rec                    ) ,

.l2b_reqsch_sortq_full               ( l2b_reqsch_sortq_full               ) ,
.l2b_reqsch_sortq_stall_but_not_full ( l2b_reqsch_sortq_stall_but_not_full ));





isched_xbar_record_type align_isched_bm_xbar_rec;

assign align_isched_bm_xbar_rec.instruction            = align_isched_bm_rec.instruction;
assign align_isched_bm_xbar_rec.axid                   = align_isched_bm_rec.axid;
assign align_isched_bm_xbar_rec.set                    = align_isched_bm_rec.set;
assign align_isched_bm_xbar_rec.way                    = align_isched_bm_rec.way;
assign align_isched_bm_xbar_rec.start_beat             = align_isched_bm_rec.start_beat;
assign align_isched_bm_xbar_rec.blen                   = align_isched_bm_rec.blen;
assign align_isched_bm_xbar_rec.iwdb_index             = align_isched_bm_rec.iwdb_index;

assign request_end_beat = align_isched_bm_rec.start_beat + align_isched_bm_rec.blen; 
assign align_isched_bm_xbar_rec.sector_mask[0]         = ~align_isched_bm_rec.start_beat[1];
assign align_isched_bm_xbar_rec.sector_mask[1]         = request_end_beat[1];
assign align_isched_bm_xbar_rec.check_partial          = 2'b0;


gpc_gfx_timing_buffer_#  (
.WIDTH                   ( $bits(wdc_isched_wb_rec                              ) ),
.BUFFER_TYPE             ( GPC_GFX_TIMING_BUFFER_RSTL                           ) )
i_tbuff_isched_wb_req    (
.clk                     ( clk                                                  ) ,
.resetn                  ( resetn                                               ) ,
.tbuff_in_data           ( wdc_isched_wb_rec                                    ) ,
.tbuff_in_valid          ( wdc_isched_wb_valid                                  ) ,
.tbuff_in_enable         ( wdc_isched_wb_ready                                  ) ,
.tbuff_out_data          ( wdc_isched_wb_tbuff_rec                              ) ,
.tbuff_out_valid         ( wdc_isched_wb_tbuff_valid                            ) ,
.tbuff_out_enable        ( wdc_isched_wb_tbuff_ready                            ) );


gc_l2_bank_isched_xbar
i_gc_l2_bank_isched_xbar (
.clk                     ( clk                                                  ) ,
.resetn                  ( resetn                                               ) ,
.idle                    ( l2_bank_isched_xbar_idle                             ) ,

.req_xbar_valid          ( {isched_xbar_instr_valid, align_isched_bm_valid    } ) ,
.req_xbar_ready          ( {isched_xbar_instr_ready, align_isched_bm_ready    } ) ,
.req_xbar_rec            ( {isched_xbar_instr_rec  , align_isched_bm_xbar_rec } ) ,

.memif_wb_req_valid      ( wdc_isched_wb_tbuff_valid                            ) ,
.memif_wb_req_ready      ( wdc_isched_wb_tbuff_ready                            ) ,
.memif_wb_req_rec        ( wdc_isched_wb_tbuff_rec                              ) ,

.isched_splitter_valid   ( isched_splitter_valid                                ) ,
.isched_splitter_ready   ( isched_splitter_ready                                ) ,
.isched_splitter_rec     ( isched_splitter_rec                                  ) );

generate
   for(genvar RCTRL_NUM=0; RCTRL_NUM<= L2_NUM_RCTRL-1; RCTRL_NUM++)begin : g_split_req_to_diff_rctrl
   gpc_gfx_timing_buffer_# (
      .WIDTH               ( $bits(isched_splitter_rec[0]            ) ),
      .BUFFER_TYPE         ( GPC_GFX_TIMING_BUFFER_RSTL              ) )
   i_tbuff_isched_splitter
                           (
      .clk                 ( clk                                     ) ,
      .resetn              ( resetn                                  ) ,
      .tbuff_in_data       ( isched_splitter_rec         [RCTRL_NUM] ) ,
      .tbuff_in_valid      ( isched_splitter_valid       [RCTRL_NUM] ) ,
      .tbuff_in_enable     ( isched_splitter_ready       [RCTRL_NUM] ) ,
      .tbuff_out_data      ( isched_splitter_tbuff_rec   [RCTRL_NUM] ) ,
      .tbuff_out_valid     ( isched_splitter_tbuff_valid [RCTRL_NUM] ) ,
      .tbuff_out_enable    ( isched_splitter_tbuff_ready [RCTRL_NUM] ) );
   
   gc_l2_bank_isched_splitter
   i_gc_l2_bank_isched_splitter (
         .clk                   ( clk                                      ) ,
         .resetn                ( resetn                                   ) ,
         .idle                  ( l2_bank_isched_splitter_idle [RCTRL_NUM] ) ,
         .req_splitter_valid    ( isched_splitter_tbuff_valid  [RCTRL_NUM] ) ,
         .req_splitter_ready    ( isched_splitter_tbuff_ready  [RCTRL_NUM] ) ,
         .req_splitter_rec      ( isched_splitter_tbuff_rec    [RCTRL_NUM] ) ,

         .isched_cmd_valid      ( isched_cmd_valid             [RCTRL_NUM] ) ,
         .isched_cmd_ready      ( isched_cmd_ready             [RCTRL_NUM] ) ,
         .isched_cmd_rec        ( isched_cmd_rec               [RCTRL_NUM] ) ,

         .isched_iwdb_valid     ( isched_iwdb_valid            [RCTRL_NUM] ) ,
         .isched_iwdb_ready     ( isched_iwdb_ready            [RCTRL_NUM] ) ,
         .isched_iwdb_rec       ( isched_iwdb_rec              [RCTRL_NUM] ));
   
   
   
   assign isched_iwdb_ready[RCTRL_NUM]             = isched_wdc_cmd_ready[RCTRL_NUM];
   assign isched_wdc_cmd_valid[RCTRL_NUM]          = isched_iwdb_valid[RCTRL_NUM];
   
   assign isched_wdc_cmd_rec[RCTRL_NUM].iwdb_index = isched_iwdb_rec[RCTRL_NUM].iwdb_index;
   assign isched_wdc_cmd_rec[RCTRL_NUM].atomic     = isched_iwdb_rec[RCTRL_NUM].instruction==AA ? 1'b1 : 1'b0;
   assign isched_wdc_cmd_rec[RCTRL_NUM].last       = isched_iwdb_rec[RCTRL_NUM].last;

// synopsys translate_off
   assign isched_wdc_cmd_rec[RCTRL_NUM].set        = isched_iwdb_rec[RCTRL_NUM].set;
   assign isched_wdc_cmd_rec[RCTRL_NUM].way        = isched_iwdb_rec[RCTRL_NUM].way;
   assign isched_wdc_cmd_rec[RCTRL_NUM].axid       = isched_iwdb_rec[RCTRL_NUM].axid;
   assign isched_wdc_cmd_rec[RCTRL_NUM].beat       = isched_iwdb_rec[RCTRL_NUM].beat;
// synopsys translate_on
   
   
   gpc_gfx_timing_buffer_ # (
      .WIDTH                ( $bits(isched_wdc_cmd_rec[RCTRL_NUM]     ) ),
      .BUFFER_TYPE          ( GPC_GFX_TIMING_BUFFER_WIRE              ) )
   i_isched_iwdb_cmd_fifo   (
      .clk                  ( clk                                     ) ,
      .resetn               ( resetn                                  ) ,
      .tbuff_in_valid       ( isched_wdc_cmd_valid       [ RCTRL_NUM] ) ,
      .tbuff_in_enable      ( isched_wdc_cmd_ready       [ RCTRL_NUM] ) ,
      .tbuff_in_data        ( isched_wdc_cmd_rec         [ RCTRL_NUM] ) ,
      .tbuff_out_valid      ( isched_wdc_cmd_tbuff_valid [ RCTRL_NUM] ) ,
      .tbuff_out_enable     ( isched_wdc_cmd_tbuff_ready [ RCTRL_NUM] ) ,
      .tbuff_out_data       ( isched_wdc_cmd_tbuff_rec   [ RCTRL_NUM] ) );
   
  // credit control 
  assign isched_iwdb_credit_avaliable[RCTRL_NUM] = |isched_iwdb_credit_counter[RCTRL_NUM];

  assign isched_wdc_cmd_tbuff_arb_valid[RCTRL_NUM] = isched_wdc_cmd_tbuff_valid[RCTRL_NUM] && isched_iwdb_credit_avaliable[RCTRL_NUM];
  assign isched_wdc_cmd_tbuff_ready [ RCTRL_NUM] = isched_wdc_cmd_tbuff_arb_ready[RCTRL_NUM];
  assign  isched_wdc_cmd_tbuff_arb_ready[RCTRL_NUM] = isched_wdc_cmd_tbuff_arb_valid[RCTRL_NUM] && selected_rctrl == RCTRL_NUM && isched_wdc_fetch_data_ready;

  always_ff@(posedge clk or negedge resetn) begin
     if(!resetn) begin
        isched_iwdb_credit_counter[RCTRL_NUM] <= L2_ISCHED_DATA_RETURN_FIFO_DEPTH/2; 
     end
     else if (isched_wdc_cmd_tbuff_valid[RCTRL_NUM] && isched_wdc_cmd_tbuff_ready[RCTRL_NUM]) begin
        if (!(isched_rctrl_wdata_valid[RCTRL_NUM] && isched_rctrl_wdata_ready[RCTRL_NUM]))
          isched_iwdb_credit_counter[RCTRL_NUM] <= isched_iwdb_credit_counter[RCTRL_NUM] - 1'b1;
     end
     else if (isched_rctrl_wdata_valid[RCTRL_NUM] && isched_rctrl_wdata_ready[RCTRL_NUM]) begin
        isched_iwdb_credit_counter[RCTRL_NUM] <= isched_iwdb_credit_counter[RCTRL_NUM] + 1'b1;
     end
  end

  assign wdc_isched_wdata_fifo_in_valid[RCTRL_NUM] = wdc_isched_wdata_valid && wdc_isched_wdata_rec.src == RCTRL_NUM;
  assign wdc_isched_wdata_fifo_in_rec[RCTRL_NUM].data = wdc_isched_wdata_rec.data;
  assign wdc_isched_wdata_fifo_in_rec[RCTRL_NUM].strb = wdc_isched_wdata_rec.strb;
  // synopsys translate_off
  assign wdc_isched_wdata_fifo_in_rec[RCTRL_NUM].axid = wdc_isched_wdata_rec.axid;
  assign wdc_isched_wdata_fifo_in_rec[RCTRL_NUM].set  = wdc_isched_wdata_rec.set;
  assign wdc_isched_wdata_fifo_in_rec[RCTRL_NUM].way  = wdc_isched_wdata_rec.way;
  assign wdc_isched_wdata_fifo_in_rec[RCTRL_NUM].beat = wdc_isched_wdata_rec.beat;
 // synopsys translate_on
 
 
 
 
  gpc_gfx_rpfifo_ #    (
      .w               ( $bits(isched_rctrl_wdata_record_type       ) ),
      .d               ( 4                                          ) )
   i_isched_iwdb_wdata_fifo 
                       (
      .clk             ( clk                                        ) ,
      .resetn          ( resetn                                     ) ,
      .fifo_in_valid   ( wdc_isched_wdata_fifo_in_valid [RCTRL_NUM] ) ,
      .fifo_in_enable  ( wdc_isched_wdata_fifo_in_ready [RCTRL_NUM] ) ,
      .fifo_in_data    ( wdc_isched_wdata_fifo_in_rec   [RCTRL_NUM] ) ,
      .fifo_out_valid  ( isched_rctrl_wdata_valid       [RCTRL_NUM] ) ,
      .fifo_out_enable ( isched_rctrl_wdata_ready       [RCTRL_NUM] ) ,
      .fifo_out_data   ( isched_rctrl_wdata_rec         [RCTRL_NUM] ) );


   
   //gpc_gfx_rpfifo_ #   (
   //   .w               ( $bits(isched_cmd_rec[RCTRL_NUM]            ) ),
   //   .d               ( 4                                          ))
   //i_isched_latency_fifo 
   //                    (
   //   .clk             ( clk                                        ) ,
   //   .resetn          ( resetn                                     ) ,
   //   .fifo_in_valid   ( isched_cmd_valid               [RCTRL_NUM] ) ,
   //   .fifo_in_enable  ( isched_cmd_ready               [RCTRL_NUM] ) ,
   //   .fifo_in_data    ( isched_cmd_rec                 [RCTRL_NUM] ) ,
   //   .fifo_out_valid  ( isched_rctrl_waiting_out_valid [RCTRL_NUM] ) ,
   //   .fifo_out_enable ( isched_rctrl_waiting_out_ready [RCTRL_NUM] ) ,
   //   .fifo_out_data   ( isched_rctrl_waiting_out_rec   [RCTRL_NUM] ));
   assign isched_rctrl_waiting_out_valid [RCTRL_NUM] = isched_cmd_valid               [RCTRL_NUM] ;
   assign isched_cmd_ready               [RCTRL_NUM] = isched_rctrl_waiting_out_ready [RCTRL_NUM];
   assign isched_rctrl_waiting_out_rec   [RCTRL_NUM] = isched_cmd_rec                 [RCTRL_NUM] ;
   
   
   always_comb begin : p_isched_rctrl_instr_drive_comb
      isched_rctrl_instr_valid[RCTRL_NUM]              = 1'b0;
      isched_rctrl_waiting_out_ready[RCTRL_NUM]        = ~isched_rctrl_waiting_out_valid[RCTRL_NUM];
      
      isched_rctrl_instr_rec[RCTRL_NUM].instruction    = isched_rctrl_waiting_out_rec[RCTRL_NUM].instruction;
      isched_rctrl_instr_rec[RCTRL_NUM].set            = isched_rctrl_waiting_out_rec[RCTRL_NUM].set;
      isched_rctrl_instr_rec[RCTRL_NUM].way            = isched_rctrl_waiting_out_rec[RCTRL_NUM].way;
      isched_rctrl_instr_rec[RCTRL_NUM].sector_mask    = isched_rctrl_waiting_out_rec[RCTRL_NUM].sector_mask;
      isched_rctrl_instr_rec[RCTRL_NUM].beat           = isched_rctrl_waiting_out_rec[RCTRL_NUM].beat;
      isched_rctrl_instr_rec[RCTRL_NUM].axid           = isched_rctrl_waiting_out_rec[RCTRL_NUM].axid;
      isched_rctrl_instr_rec[RCTRL_NUM].last           = isched_rctrl_waiting_out_rec[RCTRL_NUM].last;
      isched_rctrl_instr_rec[RCTRL_NUM].is_buffer_mode = isched_rctrl_waiting_out_rec[RCTRL_NUM].is_buffer_mode;
      isched_rctrl_instr_rec[RCTRL_NUM].check_partial  = isched_rctrl_waiting_out_rec[RCTRL_NUM].check_partial;
         
   
      if(isched_rctrl_waiting_out_valid[RCTRL_NUM]==1'b1)begin
         isched_rctrl_instr_valid[RCTRL_NUM] =1'b1;
         isched_rctrl_waiting_out_ready[RCTRL_NUM] = isched_rctrl_instr_ready[RCTRL_NUM];
      end
   end : p_isched_rctrl_instr_drive_comb

end : g_split_req_to_diff_rctrl
endgenerate

// use round robin arbitration on the per requester mask to chose which rctrl returns data to which requester
gpc_round_robin_index_arch1_ # (
   .width                      ( L2_NUM_RCTRL                   ) ,
   .hold_previous              ( 1'b0                           ) )
i_round_robin_select_rctrl     (
   .valids                     ( isched_wdc_cmd_tbuff_arb_valid ) ,
   .previous_index             ( prev_selected_rctrl            ) ,
   .next_index                 ( selected_rctrl                 ) );


assign isched_wdc_fetch_data_valid          = |isched_wdc_cmd_tbuff_arb_valid;
assign isched_wdc_fetch_data_rec.src        = selected_rctrl;
assign isched_wdc_fetch_data_rec.iwdb_index = |isched_wdc_cmd_tbuff_valid==1'b1 ? isched_wdc_cmd_tbuff_rec[selected_rctrl].iwdb_index : '0   ;
assign isched_wdc_fetch_data_rec.atomic     = |isched_wdc_cmd_tbuff_valid==1'b1 ? isched_wdc_cmd_tbuff_rec[selected_rctrl].atomic     : 1'b0 ;
assign isched_wdc_fetch_data_rec.last       = |isched_wdc_cmd_tbuff_valid==1'b1 ? isched_wdc_cmd_tbuff_rec[selected_rctrl].last       : 1'b0 ;

assign wdc_isched_wdata_ready = 1'b1;


always_ff@(posedge clk or negedge resetn) begin : p_reg_prev_selected_rctrl
   if(resetn==1'b0)begin
      prev_selected_rctrl <= 1'b0;
   end
   else begin
      if(isched_wdc_fetch_data_valid ==1'b1 && isched_wdc_fetch_data_ready == 1'b1 && isched_wdc_fetch_data_rec.last)begin
         prev_selected_rctrl <= selected_rctrl;
      end
      else if(isched_wdc_fetch_data_valid ==1'b1 && isched_wdc_fetch_data_ready == 1'b1)begin
         prev_selected_rctrl <= selected_rctrl - 1'b1;
      end
   end
end : p_reg_prev_selected_rctrl

assign l2b_reqsch_disp_wl     = 1'b0;
assign l2b_reqsch_disp_stall  = 1'b0;


// synopsys translate_off                                             
                                                                      
assign isched_wdc_fetch_data_rec.set        = |isched_wdc_cmd_tbuff_valid==1'b1 ? isched_wdc_cmd_tbuff_rec[selected_rctrl].set        : '0   ;
assign isched_wdc_fetch_data_rec.way        = |isched_wdc_cmd_tbuff_valid==1'b1 ? isched_wdc_cmd_tbuff_rec[selected_rctrl].way        : '0   ;
assign isched_wdc_fetch_data_rec.beat       = |isched_wdc_cmd_tbuff_valid==1'b1 ? isched_wdc_cmd_tbuff_rec[selected_rctrl].beat       : '0   ;
assign isched_wdc_fetch_data_rec.axid       = |isched_wdc_cmd_tbuff_valid==1'b1 ? isched_wdc_cmd_tbuff_rec[selected_rctrl].axid       : '0   ;

// synopsys translate_on



endmodule
// Local Variables:
// verilog-library-flags:("-y ./ -y ../")
// verilog-auto-inst-param-value:t
// End:
