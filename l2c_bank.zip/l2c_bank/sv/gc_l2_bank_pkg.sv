// ---------------------------------------------------------------------------------
// Project Name  : IC_Design
// Author        : liusm
// Email         : liusm@innosilicon.com.cn
// Create On     : 2024/12/16 17:35
// Last Modified : 2025/09/12 16:25
// File Name     : gc_l2_bank_pkg.sv
// Description   :
// 
// Copyright (c) 2024 Innosilicon.
// ALL RIGHTS RESERVED
// 
// ---------------------------------------------------------------------------------
// Modification History:
// Date         By              Version                 Change Description
// ---------------------------------------------------------------------------------
// 2024/12/16   liusm           1.0                     Original
// 
// ----------------------------------------------------------------------------------

package gc_l2_bank_pkg;
   localparam int L2_REGBANK_ADDR_WIDTH     = 17;
   localparam int L2_AXI_ID_WIDTH           = 9;
   localparam int L2_AXI_BUS_WIDTH          = 512;
   localparam int L2_AXI_ADDR_WIDTH         = 34;
   localparam int L2_AXI_LEN_WIDTH          = 2;
   localparam int L2_AXI_USER_WIDTH         = 10;

   localparam int L2_ISCHED_INSTR_DEPTH     = 256;
   localparam int L2_NUM_RCTRL              = 2;
   localparam int L2_NUM_RCTRL_BITS         = $clog2(L2_NUM_RCTRL);
   localparam int L2_MEM_SCHED_INSTR_DEPTH  = 32;
   localparam int L2_MEM_SCHED_INSTR_BITS   = $clog2(L2_MEM_SCHED_INSTR_DEPTH);
   localparam int L2_IWDB_DEPTH             = 48;
   localparam int L2_IWDB_INDEX_BITS        = $clog2(L2_IWDB_DEPTH);
   localparam int L2_ADDR_BITS              = L2_AXI_ADDR_WIDTH;
   localparam int L2_ISCHED_NUM_RB_ENTRY    = L2_ISCHED_INSTR_DEPTH;
   localparam int L2_ISCHED_RB_ENTRY_BITS   = $clog2(L2_ISCHED_NUM_RB_ENTRY);
   localparam int L2_NUM_SECTOR             = 2;
   localparam int L2_NUM_SECTOR_BITS        = $clog2(L2_NUM_SECTOR);
   localparam int L2_WB_BUF_DEPTH           = 32;
   localparam int L2_WB_BUF_INDEX_BITS      = $clog2(L2_WB_BUF_DEPTH);
   localparam int L2_ISCHED_RCTRL_SB_WIDTH  = L2_AXI_ID_WIDTH+1;  // buffer_mode
   localparam int L2_ISCHED_NUM_INPUT       = 4;// ALIGN, WDC, Tagctrl
   localparam int L2_TAGRAM_P_BITS          = 9;   
   localparam int L2_REF_CNT_BITS           = 6;
   localparam int L2_XBAR_NUM_BANK          = 2;
   //====================================================================== 
   // Cacheline parameters
   //======================================================================
   localparam int L2_CACHELINE_SIZE                      = 2048;     // bit
   localparam int L2_CACHELINE_BITS                      = $clog2(2048/8);     // bit
   localparam int L2_BEAT_WIDTH                          = 512                              ;
   localparam int L2_BEAT_ALIGN_BITS                     = $clog2(L2_BEAT_WIDTH/8)          ;
   localparam int L2_BEAT_STRB_WIDTH                     = L2_BEAT_WIDTH/8                  ;
   localparam int L2_NUM_BEAT                            = L2_CACHELINE_SIZE/L2_BEAT_WIDTH  ;
   localparam int L2_BEAT_BITS                           = $clog2(L2_NUM_BEAT)              ;
   localparam int L2_SECTOR_NUM_BEAT                     = L2_NUM_BEAT/L2_NUM_SECTOR        ;
   localparam int L2_NUM_SET                             = 128                              ;
   localparam int L2_NUM_SET_BITS                        = $clog2(L2_NUM_SET)               ;
   localparam int L2_NUM_WAY                             = 8                                ;
   localparam int L2_NUM_WAY_BITS                        = $clog2(L2_NUM_WAY)               ;
   localparam int L2_PLRU_BITS                           = L2_NUM_WAY-1;
   localparam int L2_ADDR_TAG_BITS                       = L2_ADDR_BITS-L2_BEAT_ALIGN_BITS-L2_NUM_SET_BITS-L2_BEAT_BITS;
   localparam int L2_TAGRAM_P                            = L2_NUM_SECTOR + L2_NUM_BEAT + 2 + L2_ADDR_TAG_BITS + 1; // valid[1:0], beat_dirty_mask[3:0], persistence, addr_tag , touched mask
   localparam int L2_TAGRAM_WIDTH                        =  (L2_NUM_WAY+1) * (L2_NUM_SECTOR + L2_NUM_BEAT + 2 + L2_ADDR_TAG_BITS + 1); // L2_PLRU_BITS + L2_NUM_WAY * (L2_NUM_SECTOR + L2_NUM_BEAT + 2 + L2_ADDR_TAG_BITS);

   localparam int L2_TAG_LSB_BITS                        = L2_ADDR_BITS-L2_ADDR_TAG_BITS;
   localparam int L2_TAG_MSB_BITS                        = L2_ADDR_BITS-1;
   localparam int ISCHED_RING_BUFFER_RAM_WIDTH           = L2_IWDB_INDEX_BITS + L2_AXI_ID_WIDTH + 2 + 2 + 3 + 2 ;


   localparam int L2_ISCHED_DATA_RETURN_FIFO_DEPTH       = 8                                                ;
   localparam int L2_ISCHED_DATA_RETURN_FIFO_DEPTH_WIDTH = $clog2(L2_ISCHED_DATA_RETURN_FIFO_DEPTH)         ;

   localparam int WT_DATA_FIFO_DEPTH                     = 2                                                ; //WT instruction's wdata from iwdb is store this fifo;
   localparam int WT_DATA_FIFO_DEPTH_BITS                = $clog2(WT_DATA_FIFO_DEPTH)                       ;
   localparam int RC_WB_FIFO_DEPTH                       = 4    ;

   localparam int L2_NUM_MAX_CFI                         = 2;
   localparam int L2_MAX_CFI_BITS                        = $clog2(L2_NUM_MAX_CFI);
   localparam int L2_NUM_NSP_ARID                        = 64;
   localparam int L2_NSP_ARID_WIDTH                      = 6;
   localparam int L2_NUM_NSP_AWID                        = 64;
   localparam int L2_NSP_AWID_WIDTH                      = 6;
   localparam int L2_NUM_NSP_ID                          = 128;
   localparam int L2_NSP_ID_BITS                         = $clog2(L2_NUM_NSP_ID);
   localparam int L2_ROB_DEPTH                           = 160;
   localparam int L2_ROB_BITS                            = $clog2(L2_ROB_DEPTH);
   localparam int L2_BANK_TRID_BITS                      = 7;
   localparam int L2_NSP_DATA_BITS                       = 256;
   
   //====================================================================== 
   // RAM parameters
   //======================================================================
   localparam int L2_RCTRL_MRAM_ID      = 30006;
   localparam int L2_RCTRL_MRAM_P       = 1;        // write dirty mask per bit
   localparam int L2_RCTRL_MRAM_WIDTH   = L2_BEAT_STRB_WIDTH*(L2_NUM_BEAT/L2_NUM_SECTOR);
   localparam int L2_RCTRL_MRAM_DEPTH   = L2_NUM_SET*L2_NUM_WAY*L2_NUM_SECTOR/L2_NUM_RCTRL;

   localparam int L2_RCTRL_DRAM_ID      = 30005;
   localparam int L2_RCTRL_DRAM_P       = 8;
   localparam int L2_RCTRL_DRAM_WIDTH   = L2_BEAT_WIDTH;
   localparam int L2_RCTRL_DRAM_DEPTH   = L2_NUM_SET*L2_NUM_WAY*L2_NUM_BEAT/L2_NUM_RCTRL;
   //====================================================================== 
   // atomic parameters
   //======================================================================
   localparam logic [1 :0] L2_AA_SIZE_32        = 2'b00;
   localparam logic [1 :0] L2_AA_SIZE_64        = 2'b01;
   localparam logic [1 :0] L2_AA_SIZE_128       = 2'b10;
   localparam logic [1 :0] L2_AA_EXT_NORM       = 2'b00;
   localparam logic [1 :0] L2_AA_EXT_SUB        = 2'b01;
   localparam logic [1 :0] L2_AA_EXT_AND        = 2'b10;
   localparam logic [2 :0] L2_AA_ATOP_ADD       = 3'b000;
   localparam logic [2 :0] L2_AA_ATOP_EOR       = 3'b010;
   localparam logic [2 :0] L2_AA_ATOP_SMAX      = 3'b100;
   localparam logic [2 :0] L2_AA_ATOP_SMIN      = 3'b101;
   localparam logic [2 :0] L2_AA_ATOP_UMAX      = 3'b110;
   localparam logic [5 :0] L2_AA_ATOP_SWAP      = 6'b110000;
   localparam logic [5 :0] L2_AA_ATOP_COMP      = 6'b110001;
   
   localparam int unsigned                 L2_AA_OP_WIDTH      = 5;
   localparam logic [L2_AA_OP_WIDTH-1 : 0] L2_AA_OP_ADD        = 5'h0_0;
   localparam logic [L2_AA_OP_WIDTH-1 : 0] L2_AA_OP_SUB        = 5'h0_1;
   localparam logic [L2_AA_OP_WIDTH-1 : 0] L2_AA_OP_XCHG       = 5'h0_2;
   localparam logic [L2_AA_OP_WIDTH-1 : 0] L2_AA_OP_CMPXCHG    = 5'h0_3;
   localparam logic [L2_AA_OP_WIDTH-1 : 0] L2_AA_OP_UMIN       = 5'h0_4;
   localparam logic [L2_AA_OP_WIDTH-1 : 0] L2_AA_OP_IMIN       = 5'h0_5;
   localparam logic [L2_AA_OP_WIDTH-1 : 0] L2_AA_OP_UMAX       = 5'h0_6;
   localparam logic [L2_AA_OP_WIDTH-1 : 0] L2_AA_OP_IMAX       = 5'h0_7;
   localparam logic [L2_AA_OP_WIDTH-1 : 0] L2_AA_OP_AND        = 5'h0_8;
   localparam logic [L2_AA_OP_WIDTH-1 : 0] L2_AA_OP_OR         = 5'h0_9;
   localparam logic [L2_AA_OP_WIDTH-1 : 0] L2_AA_OP_XOR        = 5'h0_A;
   
   localparam logic [L2_AA_OP_WIDTH-1 : 0] L2_AA_OP_FADD       = 5'h1_0;
   localparam logic [L2_AA_OP_WIDTH-1 : 0] L2_AA_OP_FSUB       = 5'h1_1;
   localparam logic [L2_AA_OP_WIDTH-1 : 0] L2_AA_OP_FMIN       = 5'h1_5;
   localparam logic [L2_AA_OP_WIDTH-1 : 0] L2_AA_OP_FMAX       = 5'h1_7;
   localparam logic [L2_AA_OP_WIDTH-1 : 0] L2_AA_OP_FCMPXCHG   = 5'h1_3;

   localparam int unsigned                 SPE_CODE_WIDTH      = 3;
   localparam int unsigned                 TOTAL_SPE_CODE_WIDTH= (SPE_CODE_WIDTH*2)+1;
   localparam logic                        FP32_ADD            = 1'b0;
   localparam logic                        FP32_SUB            = 1'b1;
   localparam logic                        FP32_MIN            = 1'b0;
   localparam logic                        FP32_MAX            = 1'b1;
   localparam logic [SPE_CODE_WIDTH-1 : 0] FP32_NORM           = 3'b000;
   localparam logic [SPE_CODE_WIDTH-1 : 0] FP32_NAN            = 3'b001;
   localparam logic [SPE_CODE_WIDTH-1 : 0] FP32_PINF           = 3'b010;
   localparam logic [SPE_CODE_WIDTH-1 : 0] FP32_NINF           = 3'b011;
   localparam logic [SPE_CODE_WIDTH-1 : 0] FP32_DENORM         = 3'b100;
   localparam logic [ 31 : 0]              FP32_NUM_CONT_1     = 32'h3F80_0000;
   localparam logic [ 31 : 0]              FP32_NUM_NAN        = 32'h7FC0_0000;
   localparam logic [ 31 : 0]              FP32_NUM_PINF       = 32'h7F80_0000;
   localparam logic [ 31 : 0]              FP32_NUM_NINF       = 32'hFF80_0000;
   localparam logic [ 31 : 0]              FP32_NUM_PZERO      = 32'h0000_0000;
   localparam logic [ 31 : 0]              FP32_NUM_NZERO      = 32'h8000_0000;

   //====================================================================== 
   // typedef struct
   //======================================================================
   typedef enum logic [2:0]{
      AXI_RD             = 3'd0  ,
      AXI_WR             = 3'd1  ,
      AXI_AA             = 3'd2  ,
      CFG_INVALID        = 3'd3  ,
      CFG_FLUSH          = 3'd4  ,
      CFG_FLUSH_INVALID  = 3'd5  ,
      CFG_REDUCE_PERSIST = 3'd6  ,
      CFG_RST_PERSIST    = 3'd7 
   
   } l2_bank_instr_type;
   localparam int AXI_INST_WIDTH            = $bits(l2_bank_instr_type);

   typedef enum logic [2:0] {
      LF                      = 3'd0   ,
      BRD                     = 3'd1   ,
      ST                               ,
      NOPE                             
   } l2_bank_memif_instr_type;


   typedef enum logic [2:0] {
      RD                = 3'd0   ,
      WR                = 3'd1   ,
      AA                = 3'd2   ,
      WT                = 3'd3   ,
      FLUSH             = 3'd4   ,
      WB                = 3'd5   ,
      WB_WR             = 3'd6   ,
      PREFETCH          = 3'd7
   } l2_bank_cacheline_instr_type;

   typedef enum logic [1:0] {
      INVALID           = 2'd0   ,
      CLEAN             = 2'd1   ,
      DIRTY             = 2'd2   ,
      PARTIAL           = 2'd3
   } l2_bank_cl_status_record_type;

   typedef struct                                        packed {
      logic                                              valid           ;
      logic    [1:0]                                     beat_dirty_mask ;
      logic                                              partial         ;
   }sector_status_record_type;

   typedef struct                                        packed {
      logic    [1:0]                                     valid           ;
      logic    [3:0]                                     beat_dirty_mask ;
      logic    [1:0]                                     partial         ;
      logic                                              touched_mask    ;
      logic    [L2_REF_CNT_BITS-1:0]                     access_counter   ;
      logic    [L2_TAG_MSB_BITS:L2_TAG_LSB_BITS]                  addr_tag        ;
      logic    [1:0]                                     persistence     ;
   } cacheline_status_record_type;

   typedef struct                                        packed {
      logic    [L2_PLRU_BITS-1:0]                        plru_bits       ;
      logic    [L2_NUM_WAY-1:0][L2_TAG_MSB_BITS:L2_TAG_LSB_BITS]  addr_tag        ;
      logic    [L2_NUM_WAY-1:0][ 1: 0]                   persistence     ;
      logic    [L2_NUM_WAY-1:0][ 3: 0]                   beat_dirty_mask ;
      logic    [L2_NUM_WAY-1:0][ 1: 0]                   valid           ;
      logic    [L2_NUM_WAY-1:0]                          touched_mask;
   } tagctrl_ram_data_record_type;

   typedef struct                                                                packed{
      logic    [L2_PLRU_BITS-1:0]                                                plru_bits;
      logic    [L2_NUM_WAY-1:0]  [L2_TAG_MSB_BITS:L2_TAG_LSB_BITS]                        addr_tag;
      logic    [L2_NUM_WAY-1:0]  [ 1: 0]                                         persistence;
      logic    [L2_NUM_WAY-1:0]  [ 3: 0]                                         beat_dirty_mask;
      logic    [L2_NUM_WAY-1:0]  [ 1: 0]                                         partial;
      logic    [L2_NUM_WAY-1:0]  [ 1: 0]                                         valid;
      logic    [L2_NUM_WAY-1:0]  [ L2_REF_CNT_BITS-1: 0]                         access_counter;
      logic    [L2_NUM_WAY-1:0]                                                  touched_mask;
   } tagctrl_cacheline_status_record_type;



   typedef struct                                           packed {
      cacheline_status_record_type  [L2_NUM_WAY-1:0]        cacheline_status ;
      logic [L2_PLRU_BITS-1:0]                              plru_bits;
   } selected_set_cacheline_status_record_type;


   typedef struct                            packed{
      l2_bank_instr_type                     instruction;
      logic [L2_AXI_ID_WIDTH-1:0]            axid;
      logic [L2_TAG_MSB_BITS:L2_TAG_LSB_BITS]              addr_tag;
      logic [1:0]                            start_beat;
      logic [L2_NUM_SET_BITS-1:0]            set;
      logic [L2_IWDB_INDEX_BITS-1:0]         iwdb_index;
      logic [1:0]                            blen;
      logic [1:0]                            burst; // incr, fixed, wrap
      logic                                  cache_policy;
      logic [1:0]                            persistence;
      logic                                  prefetch_size;
   } tagctrl_pipeline_record_type;

   typedef struct                            packed{
      l2_bank_instr_type                     instruction;
      logic [L2_AXI_ID_WIDTH-1:0]            axid;
      logic [L2_ADDR_BITS-1:0]               addr;
      logic [L2_IWDB_INDEX_BITS-1:0]         iwdb_index;
      logic [1:0]                            blen;
      logic [1:0]                            burst; // incr, fixed, wrap
      logic [3:0]                            axcache;
      logic [1:0]                            persistence;
      logic                                  prefetch_size;
   } align_tagctrl_record_type;

   typedef struct                            packed {
      l2_bank_cacheline_instr_type           instruction;
      logic [L2_AXI_ID_WIDTH-1:0]            axid;
      logic [L2_NUM_SET_BITS-1:0]            set;
      logic [L2_NUM_WAY_BITS-1:0]            way;
      logic [1:0]                            start_beat;
      logic [1:0]                            burst;
      logic [1:0]                            blen;
      logic [L2_IWDB_INDEX_BITS-1:0]         iwdb_index;
      logic [1:0]                            linefill_waiting;
      logic                                  wb_waiting;
      logic [1:0]                            sector_mask; 
      logic [1:0]                            check_partial;
   } tagctrl_isched_record_type;

   typedef struct                            packed {
      logic [L2_NUM_SET_BITS-1:0]            set;
      logic [L2_NUM_WAY_BITS-1:0]            way;
      logic [1:0]                            sector_mask;
   } isched_tagctrl_clr_record_type;


   typedef struct                            packed {
      logic [L2_NUM_SET_BITS-1:0]            set;
      logic [L2_NUM_WAY_BITS-1:0]            way;
      logic [1:0]                            sector_mask;
   } tagctrl_rctrl_clr_record_type;



   typedef struct                            packed {
      logic [L2_NUM_SET_BITS-1:0]            set;
      logic [L2_NUM_WAY_BITS-1:0]            way;
      logic [1:0]                            beat;
      logic [511:0]                          data;
      logic [1:0]                            sector_mask;
      logic                                  last;
   } memif_rctrl_record_type;


   typedef struct                            packed {
      l2_bank_cacheline_instr_type           instruction;
      logic [L2_NUM_SET_BITS-1:0]            set;
      logic [L2_NUM_WAY_BITS-1:0]            way;
      logic [1:0]                            start_beat;
      logic [1:0]                            blen;
      logic [3:0]                            beat_dirty_mask; 
      logic [L2_IWDB_INDEX_BITS-1:0]         iwdb_index;
   } memif_wdc_record_type;


   typedef memif_wdc_record_type wdc_isched_cmd_record_type;


   typedef struct                            packed {
      logic [63:0]                           wdata_mask;
      logic [511:0]                          wdata;
      logic                                  last;
   } wdc_memif_wdata_record_type;

   typedef struct                            packed {
      logic [511:0]                          data;
      logic [L2_AXI_ID_WIDTH-1:0]            axid;
      logic                                  last;
   } memif_align_record_type;

   typedef struct                            packed {
      logic [L2_ADDR_BITS-1:0]               addr;
      logic [L2_MEM_SCHED_INSTR_BITS-1:0]    buffer_index;   
   } memif_sched_record_type;

   typedef struct                            packed {
      logic [L2_ADDR_BITS-1:0]               addr;
      logic [L2_MEM_SCHED_INSTR_BITS-1:0]    buffer_index;  
   } sched_memif_record_type;

   typedef struct                            packed {
      logic [L2_AXI_ID_WIDTH-1:0]            axid;
      l2_bank_memif_instr_type               memif_instruction;
      l2_bank_cacheline_instr_type           cl_instruction;
      logic [L2_TAG_MSB_BITS:L2_TAG_LSB_BITS]              addr_tag;
      logic [1:0]                            start_beat;
      logic [1:0]                            blen;
      logic [1:0]                            linefill_mask;
      
      logic [L2_NUM_SET_BITS-1:0]            set;
      logic [L2_NUM_WAY_BITS-1:0]            way;
      logic [L2_IWDB_INDEX_BITS-1:0]         iwdb_index;
      logic [3:0]                            beat_dirty_mask; // used for bypass write hit dirty cacheline
      logic                                  cfi_id;

      logic                                  wb_valid;
      logic [L2_TAG_MSB_BITS:L2_TAG_LSB_BITS]              wb_addr_tag; 
      logic [3:0]                            wb_dirty_mask;
      
   } tagctrl_memif_record_type;

   typedef struct                            packed {
      logic [L2_NUM_SET_BITS-1:0]            set;
      logic [L2_NUM_WAY_BITS-1:0]            way;
   } memif_tagctrl_record_type;

   typedef struct                            packed{
      logic                                  lf_or_wb;
      logic [L2_NUM_SET_BITS-1:0]            set;
      logic [L2_NUM_WAY_BITS-1:0]            way;
      logic [1:0]                            sector_mask;
   } rctrl_isched_record_type;

   typedef struct                            packed{
      logic [L2_NUM_SET_BITS-1:0]            set;
      logic [L2_NUM_WAY_BITS-1:0]            way;
      logic [1:0]                            sector_mask;
   } rctrl_isched_lf_done_record_type;



   typedef struct                            packed{
      logic [L2_NUM_SET_BITS-1:0]            set;
      logic [L2_NUM_WAY_BITS-1:0]            way;
   } rctrl_isched_wb_done_record_type;


   typedef struct                            packed{
      l2_bank_cacheline_instr_type           instruction;
      logic [L2_AXI_ID_WIDTH-1:0]            axid;
      logic [L2_NUM_SET_BITS-1:0]            set;
      logic [L2_NUM_WAY_BITS-1:0]            way;
      logic [1:0]                            sector_mask;
      logic [1:0]                            beat;
      logic                                  last;
      logic                                  is_buffer_mode;
      logic [1:0]                            check_partial;
   } isched_rctrl_record_type;



   typedef struct                            packed{
      logic [L2_BEAT_WIDTH-1:0]              data;
      logic [L2_BEAT_STRB_WIDTH-1:0]         strb;


// synopsys translate_off

      logic [L2_NUM_SET_BITS-1:0]            set;
      logic [L2_NUM_WAY_BITS-1:0]            way;
      logic [1:0]                            beat;
      logic [L2_AXI_ID_WIDTH-1:0]            axid;
// synopsys translate_on

   } isched_rctrl_wdata_record_type;

   
   typedef struct                            packed{

      l2_bank_cacheline_instr_type           instruction;
      logic [1:0]                            blen;
      logic                                  src;  


// synopsys translate_off

      logic [L2_NUM_SET_BITS-1:0]            set;
      logic [L2_NUM_WAY_BITS-1:0]            way;
// synopsys translate_on

   } wdc_waiting_wdata_order_record_type;




   typedef struct                            packed{
      logic [L2_IWDB_INDEX_BITS-1:0]         iwdb_index;
      logic                                  atomic;
      logic                                  last;
// synopsys translate_off

      logic [L2_NUM_SET_BITS-1:0]            set;
      logic [L2_NUM_WAY_BITS-1:0]            way;
      logic [1:0]                            beat;
      logic [L2_AXI_ID_WIDTH-1:0]            axid;
// synopsys translate_on

   } isched_wdc_cmd_tbuff_record_type;


   typedef struct                            packed{
      logic                                  src;  //WT or WB
      logic                                  rctrl; //which RCTRL
// synopsys translate_off

      logic [L2_NUM_SET_BITS-1:0]            set;
      logic [L2_NUM_WAY_BITS-1:0]            way;
      logic [1:0]                            beat;
      logic [L2_AXI_ID_WIDTH-1:0]            axid;
// synopsys translate_on

   } rtn_wdata_order_record_type;


    typedef struct packed {
        logic [8 - 1:0] buffer_index;
        logic [34 - 1:0] pa;
    } bank_group_sched_data_bus_t;

   
    typedef struct packed {
        logic [8 - 1:0] buffer_index;
        logic [34 - 1:0] pa;
    } sched_bank_group_data_bus_t;


   typedef struct                            packed{
      logic [L2_IWDB_INDEX_BITS-1:0]         iwdb_index;
      logic                                  src;
      logic                                  atomic;
      logic                                  last;
// synopsys translate_off
      logic [L2_NUM_SET_BITS-1:0]            set;
      logic [L2_NUM_WAY_BITS-1:0]            way;
      logic [1:0]                            beat;
      logic [L2_AXI_ID_WIDTH-1:0]            axid;
// synopsys translate_on



   } isched_wdc_record_type;

   typedef struct                            packed{
      logic [L2_BEAT_WIDTH-1:0]              data;
      logic [L2_BEAT_STRB_WIDTH-1:0]         strb;
      logic                                  src;

// synopsys translate_off

      logic [L2_NUM_SET_BITS-1:0]            set;
      logic [L2_NUM_WAY_BITS-1:0]            way;
      logic [1:0]                            beat;
      logic [L2_AXI_ID_WIDTH-1:0]            axid;
// synopsys translate_on
   } wdc_isched_data_record_type;

   //typedef struct                            packed {
   //   l2_bank_cacheline_instr_type           instruction; //WB, WB_WR, FLUSH
   //   logic [L2_NUM_SET_BITS-1:0]            set;
   //   logic [L2_NUM_WAY_BITS-1:0]            way;
   //   logic [1:0]                            start_beat;
   //   logic [1:0]                            blen;
   //   logic [3:0]                            beat_dirty_mask; 
   //   logic [L2_IWDB_INDEX_BITS-1:0]         iwdb_index;
   //} wdc_isched_cmd_record_type;


   typedef struct                            packed{
      logic [L2_IWDB_INDEX_BITS-1:0]         iwdb_index;
      logic                                  atomic;
   } wdc_iwdb_cmd_record_type;


   typedef struct                            packed{
      logic [L2_BEAT_WIDTH-1:0]              data;
      logic [L2_BEAT_STRB_WIDTH-1:0]         strb;
      logic                                  last;
// synopsys translate_off

      logic [L2_NUM_SET_BITS-1:0]            set;
      logic [L2_NUM_WAY_BITS-1:0]            way;
      logic [1:0]                            beat;
      logic [L2_AXI_ID_WIDTH-1:0]            axid;
// synopsys translate_on
   } rctrl_wdc_wb_record_type;

   typedef struct                            packed{
      l2_bank_cacheline_instr_type           instruction;
      logic [L2_AXI_ID_WIDTH-1:0]            axid;
      logic [L2_NUM_SET_BITS-1:0]            set;
      logic [L2_NUM_WAY_BITS-1:0]            way;
      logic [1:0]                            start_beat;
      logic [1:0]                            burst;
      logic [1:0]                            blen;
      logic [L2_IWDB_INDEX_BITS-1:0]         iwdb_index;

   } align_isched_bm_record_type;

   typedef struct                            packed{
      logic [L2_IWDB_INDEX_BITS-1:0]         iwdb_index;
      logic [L2_BEAT_WIDTH-1:0]              data;
      logic [(L2_BEAT_STRB_WIDTH/2)-1:0]     strb;
      logic                                  atomic;
   } align_iwdb_write_record_type;

   typedef struct                            packed{
      logic [L2_BEAT_WIDTH-1:0]              data;
      logic [L2_BEAT_STRB_WIDTH-1:0]         strb;
   } iwdb_wdc_wdata_record_type;


   //typedef struct                            packed{
   //   l2_bank_cacheline_instr_type           instruction;
   //   logic [L2_AXI_ID_WIDTH-1:0]            axid;
   //   logic [L2_NUM_SET_BITS-1:0]            set;
   //   logic [L2_NUM_WAY_BITS-1:0]            way;
   //   logic [1:0]                            start_beat;
   //   logic [1:0]                            burst;
   //   logic [1:0]                            blen;
   //   logic [L2_IWDB_INDEX_BITS-1:0]         iwdb_index;
   //   logic [1:0]                            linefill_waiting;
   //   logic                                  wb_waiting;
   //   logic [1:0]                            sector_mask; 
   //   logic [1:0]                            check_partial;
   //} ring_buffer_entries_record_type;
   typedef tagctrl_isched_record_type ring_buffer_entries_record_type;

   typedef struct                            packed {
      l2_bank_cacheline_instr_type           instruction;
      logic [L2_AXI_ID_WIDTH-1:0]            axid;
      logic [L2_NUM_SET_BITS-1:0]            set;
      logic [L2_NUM_WAY_BITS-1:0]            way;
      logic [1:0]                            start_beat;
      logic [1:0]                            blen;
      logic [L2_IWDB_INDEX_BITS-1:0]         iwdb_index;
      logic [1:0]                            sector_mask; 
      logic [1:0]                            check_partial;
   } isched_xbar_record_type;

   typedef struct                            packed {
      l2_bank_cacheline_instr_type           instruction;
      logic [L2_AXI_ID_WIDTH-1:0]            axid;
      logic [L2_NUM_SET_BITS-1:0]            set;
      logic [L2_NUM_WAY_BITS-1:0]            way;
      logic [1:0]                            sector_mask;
      logic [1:0]                            start_beat;
      logic [1:0]                            blen;
      logic [L2_IWDB_INDEX_BITS-1:0]         iwdb_index;
      logic [3:0]                            beat_dirty_mask;
      logic                                  is_buffer_mode;
      logic [1:0]                            check_partial;
   } isched_splitter_record_type;



   typedef struct                            packed {
      l2_bank_cacheline_instr_type           instruction;
      logic [L2_AXI_ID_WIDTH-1:0]            axid;
      logic [L2_NUM_SET_BITS-1:0]            set;
      logic [L2_NUM_WAY_BITS-1:0]            way;
      logic [1:0]                            sector_mask;
      logic [1:0]                            start_beat;
      logic                                  is_buffer_mode;
      logic [1:0]                            check_partial;
      logic [3:0]                            beat_dirty_mask;
      logic [1:0]                            blen;
   } isched_split_req_cmd_record_t;



   typedef struct                            packed {

      //synopsys translate_off
      logic [L2_AXI_ID_WIDTH-1:0]            axid;
      logic [L2_NUM_SET_BITS-1:0]            set;
      logic [L2_NUM_WAY_BITS-1:0]            way;
      logic [1:0]                            beat;
      //synopsys translate_on
      
      l2_bank_cacheline_instr_type           instruction;
      logic [L2_IWDB_INDEX_BITS-1:0]         iwdb_index;
      logic                                  last;
   } isched_iwdb_record_type;
   
   typedef struct                            packed {

      //synopsys translate_off
      logic [L2_AXI_ID_WIDTH-1:0]            axid;
      logic [L2_NUM_SET_BITS-1:0]            set;
      logic [L2_NUM_WAY_BITS-1:0]            way;
      logic [1:0]                            start_beat;
      //synopsys translate_on
      
      l2_bank_cacheline_instr_type           instruction;
      logic [L2_IWDB_INDEX_BITS-1:0]         iwdb_index;
      logic [1:0]                            blen;
   } isched_split_req_iwdb_record_t;









   typedef struct                            packed {
      l2_bank_cacheline_instr_type           instruction;
      logic [L2_AXI_ID_WIDTH-1:0]            axid;
      logic [L2_NUM_SET_BITS-1:0]            set;
      logic [L2_NUM_WAY_BITS-1:0]            way;
      logic [1:0]                            beat;
      logic [1:0]                            sector_mask;
      logic                                  is_buffer_mode;
      logic                                  last;
      logic [1:0]                            check_partial;
   } isched_waiting_record_type;

   typedef struct                            packed{
      l2_bank_cacheline_instr_type           instruction;
      logic[1:0]                             start_beat;
      logic [1:0]                            blen;
      logic [L2_IWDB_INDEX_BITS-1:0]         iwdb_index;
   } wt_cmd_record_type;
   


   typedef  memif_tagctrl_record_type wb_buffer_type;
   typedef  memif_tagctrl_record_type rctrl_tagctrl_record_type;


   typedef struct                            packed {
      logic [L2_AXI_ID_WIDTH-1:0]            axid        ;
      logic [L2_NUM_SET_BITS-1:0]            set         ;
      logic [L2_NUM_WAY_BITS-1:0]            way         ;
      logic [1:0]                            beat        ;
      logic [1:0]                            sector_mask ;
      logic                                  linefill    ;
      logic [L2_ROB_BITS-1:0]                rob_index   ;
      logic                                  last        ;
   } l2_bank_rob_pipe_record_type;


   typedef struct                            packed {
      logic [L2_AXI_ID_WIDTH-1:0]            axid        ;
      logic [L2_NUM_SET_BITS-1:0]            set         ;
      logic [L2_NUM_WAY_BITS-1:0]            way         ;
      logic [1:0]                            beat        ;
      logic [1:0]                            sector_mask ;
      logic                                  linefill    ;
      logic                                  last        ;
      logic [511:0]                          data        ;
   } l2_bank_rob_readout_record_type;

   
   typedef struct                            packed {
      logic [L2_ROB_BITS-1:0]                rob_index;
      logic [1:0]                            write_mask; //  active low; indicate which 256 bits the data should be written into.       
      logic [255:0]                          write_data;
   } l2_bank_rob_write_record_type;



   typedef struct                            packed {
      logic [L2_NUM_SET_BITS-1:0]            set;
      logic [L2_NUM_WAY_BITS-1:0]            way;
      logic [L2_NUM_SECTOR-1:0]              sector_mask;
   
   
   } l2_bank_isched_execute_instruction_record_type;

    function automatic logic update_plru_bits_2ways(logic [1:0] hit_valids, logic plru_bit);
      logic updated_plru_bit;
      logic oldest_node;
    begin
      updated_plru_bit = plru_bit;

      // this is the node pointed by the current node
      oldest_node = updated_plru_bit;

      // if the node that is least recently used contain one hit and the other node does not
      // then the current node should change its bit
      if(hit_valids[oldest_node] == 1'b1 && (hit_valids[1] != hit_valids[0]))
         updated_plru_bit = ~updated_plru_bit;

      return updated_plru_bit;
    end
    endfunction : update_plru_bits_2ways

   function automatic logic [2:0] update_plru_bits_4ways(logic [3:0] hit_valids, logic [2:0] plru_bits);
      logic [1:0] updated_plru_bits;
      logic [1:0] next_hit_valids;
      logic       next_plru_bit;
      logic [3:0] oldest_node;
   begin
      updated_plru_bits = plru_bits[1:0];

      for(int unsigned node=0; node<2; node++) begin

         next_hit_valids[node] = hit_valids[2*node+1] | hit_valids[2*node];
         // this is the node pointed by the current node
         if(updated_plru_bits[node] == 1'b0)
            oldest_node = 2*node;
         else
            oldest_node = 2*node + 1;

         // if the node that is least recently used contain one hit and the other node does not
         // then the current node should change its bit
         if(hit_valids[oldest_node] == 1'b1 && (hit_valids[2*node+1] != hit_valids[2*node]))
            updated_plru_bits[node] = ~updated_plru_bits[node];

      end

      next_plru_bit = plru_bits[2];
      return {update_plru_bits_2ways(next_hit_valids, next_plru_bit) , updated_plru_bits};

   end
   endfunction : update_plru_bits_4ways
   
   function automatic logic [6:0] update_plru_bits_8ways(logic [7:0] hit_valids, logic [6:0] plru_bits);
      logic [3:0] updated_plru_bits;
      logic [3:0] next_hit_valids;
      logic [2:0] next_plru_bits;
      logic [7:0] oldest_node;
   begin
      updated_plru_bits = plru_bits[3:0];

      for(int unsigned node=0; node<4; node++) begin

         next_hit_valids[node] = hit_valids[2*node+1] | hit_valids[2*node];
         // this is the node pointed by the current node
         if(updated_plru_bits[node] == 1'b0)
            oldest_node = 2*node;
         else
            oldest_node = 2*node + 1;

         // if the node that is least recently used contain one hit and the other node does not
         // then the current node should change its bit
         if(hit_valids[oldest_node] == 1'b1 && (hit_valids[2*node+1] != hit_valids[2*node]))
            updated_plru_bits[node] = ~updated_plru_bits[node];
      end

      next_plru_bits = plru_bits[6:4];
      return {update_plru_bits_4ways(next_hit_valids, next_plru_bits) , updated_plru_bits};

   end
   endfunction : update_plru_bits_8ways

//                              plru_bits[6]
//                            /              \
//                           /                \
//                          /                  \
//              plru_bits[4]               plru_bits[5]
//              /        \                  /       \
//             /          \                /         \
//     plru_bits[0]   plru_bits[1]   plru_bits[2]   plru_bits[3]
//        /   \         /   \         /   \         /   \
//       /     \       /     \       /     \       /     \
//    [0]      [1]    [2]    [3]    [4]    [5]    [6]    [7] 


   function automatic logic [2:0] func_plru_find_8ways(logic [7:0] way_valids, logic [6:0] plru_bits); // 0 means can be replaced
      logic [2:0] result;
   begin
      result[2] =  (plru_bits[6] && !(&way_valids[7:4])) || (!plru_bits[6] && (&way_valids[3:0]));
      if (result[2]) begin
         result[1] = (plru_bits[5] && !(&way_valids[7:6])) || (!plru_bits[5] && (&way_valids[5:4]));
      end
      else begin
         result[1] = (plru_bits[4] && !(&way_valids[3:2])) || (!plru_bits[4] && (&way_valids[1:0]));
      end

      case (result[2:1]) 
         2'b00: result[0] = (plru_bits[0] && !way_valids[1]) || ((!plru_bits[0]) && way_valids[0]);
         2'b01: result[0] = (plru_bits[1] && !way_valids[3]) || ((!plru_bits[1]) && way_valids[2]);
         2'b10: result[0] = (plru_bits[2] && !way_valids[5]) || ((!plru_bits[2]) && way_valids[4]);
         2'b11: result[0] = (plru_bits[3] && !way_valids[7]) || ((!plru_bits[3]) && way_valids[6]);
      endcase
      return result;
   end
   endfunction: func_plru_find_8ways

   function automatic logic [2:0] func_onehot_to_binary_8bits (logic [7:0] onehot);
      logic [2:0] result;
      result[2] = onehot[4] | onehot[5] | onehot[6] | onehot[7];
      result[1] = onehot[2] | onehot[3] | onehot[6] | onehot[7];
      result[0] = onehot[1] | onehot[3] | onehot[5] | onehot[7];
      return result;
   endfunction


   function automatic logic [7:0] func_binary_to_onehot_8bits (logic [2:0] binary) ;
      logic [7:0] result;
      result[0] = !binary[2] && !binary[1] && !binary[0];
      result[1] = !binary[2] && !binary[1] &&  binary[0];
      result[2] = !binary[2] &&  binary[1] && !binary[0];
      result[3] = !binary[2] &&  binary[1] &&  binary[0];
      result[4] =  binary[2] && !binary[1] && !binary[0];
      result[5] =  binary[2] && !binary[1] &&  binary[0];
      result[6] =  binary[2] &&  binary[1] && !binary[0];
      result[7] =  binary[2] &&  binary[1] &&  binary[0];
      return result;
   endfunction

   function automatic logic [255:0] func_binary_to_onehot_256bits(logic [7:0] binary);
      logic [255:0] result;
      for (int unsigned index = 0; index < 256; index ++) begin
         result[index] = (binary == index);
      end
      return result;
   endfunction

   function automatic logic [127:0] func_binary_to_onehot_128bits(logic [6:0] binary);
      logic [127:0] result;
      for (int unsigned index = 0; index < 128; index ++) begin
         result[index] = (binary == index);
      end
      return result;
   endfunction

   function automatic logic [31:0] func_binary_to_onehot_32bits(logic [4:0] binary);
      logic [31:0] result;
      for (int unsigned index = 0; index < 32; index ++) begin
         result[index] = (binary == index);
      end
      return result;
   endfunction


   function automatic tagctrl_cacheline_status_record_type func_tagctrl_tagram_selected_cacheline_packed(tagctrl_ram_data_record_type data_rec, 
                                                                                                    logic [L2_NUM_WAY-1:0][L2_REF_CNT_BITS-1:0] selected_access_counter_array , 
                                                                                                    logic [L2_NUM_WAY-1:0][L2_NUM_SECTOR-1:0] selected_partial_array);
      tagctrl_cacheline_status_record_type result;
      result.plru_bits = data_rec.plru_bits;
      for (int way = 0; way < L2_NUM_WAY; way ++) begin
         result.touched_mask    [way]  = data_rec.touched_mask[way];
         result.addr_tag        [way]  = data_rec.addr_tag[way];
         result.persistence     [way]  = data_rec.persistence[way];
         result.valid           [way]  = data_rec.valid[way];
         result.partial         [way]  = selected_partial_array[way];
         result.access_counter  [way]  = selected_access_counter_array[way];
         result.beat_dirty_mask [way]  = data_rec.beat_dirty_mask[way];
      end
      return result;

   endfunction
                   
   function automatic  tagctrl_ram_data_record_type  func_tagctrl_cacheline_status_to_ram_data(tagctrl_cacheline_status_record_type data_rec);
      tagctrl_ram_data_record_type result;
      result.plru_bits = data_rec.plru_bits;
      for (int way = 0; way < L2_NUM_WAY; way ++) begin
         result.addr_tag        [way]  = data_rec.addr_tag[way];
         result.persistence     [way]  = data_rec.persistence[way];
         result.valid           [way]  = data_rec.valid[way];
         result.beat_dirty_mask [way]  = data_rec.beat_dirty_mask[way];
         result.touched_mask    [way]  = data_rec.touched_mask[way];
      end
      return result;
   endfunction

   function automatic logic [L2_TAGRAM_WIDTH-1:0] func_tagctrl_ram_data_rec2slv(tagctrl_ram_data_record_type data_rec);
      logic [L2_TAGRAM_WIDTH-1:0]   result;
      result = '0;
      result[L2_NUM_WAY*L2_TAGRAM_P+:L2_PLRU_BITS] = data_rec.plru_bits;
      for (int unsigned way = 0; way < L2_NUM_WAY; way++) begin
         result[(way)*L2_TAGRAM_P+:L2_TAGRAM_P] = { data_rec.addr_tag       [way], 
                                                    data_rec.persistence    [way], 
                                                    data_rec.beat_dirty_mask[way], 
                                                    data_rec.touched_mask   [way], 
                                                    data_rec.valid          [way]};

      end
      return result;
   endfunction 

   function automatic tagctrl_ram_data_record_type func_tagctrl_ram_data_slv2rec(logic [L2_TAGRAM_WIDTH-1:0] data_slv);
      tagctrl_ram_data_record_type result;
      result.plru_bits       = data_slv[L2_NUM_WAY*L2_TAGRAM_P+:L2_PLRU_BITS];
      for (int way = 0; way < L2_NUM_WAY; way ++) begin
         {result.addr_tag       [way], 
          result.persistence    [way], 
          result.beat_dirty_mask[way],
          result.touched_mask   [way], 
          result.valid          [way]} = data_slv[(way)*L2_TAGRAM_P+:L2_TAGRAM_P];
      end
      return result;
   endfunction

   function automatic l2_bank_axcahe_cache_policy(logic [3:0] axcache, logic gc_cr_l2_function_enable_bypass_mode);
      logic policy;
      policy = gc_cr_l2_function_enable_bypass_mode ? 1'b1 : ~axcache[0]; // 0 for writeback; 1 for write through
      return policy;
   endfunction
   
   function automatic logic l2_bank_operation_need_unroll(l2_bank_instr_type instruction); 
      if (instruction == CFG_INVALID | instruction == CFG_FLUSH | instruction == CFG_FLUSH_INVALID | 
          instruction == CFG_RST_PERSIST | instruction == CFG_REDUCE_PERSIST) 
         return 1'b1;
      else 
         return 1'b0;
   endfunction

   function automatic logic l2_cacheline_instruction_needs_wdata(l2_bank_cacheline_instr_type instruction); 
      if (instruction == WR | instruction == WB_WR | instruction == AA | 
          instruction == WT) 
         return 1'b1;
      else 
         return 1'b0;
   endfunction


   function automatic logic [3:0] l2_bank_calc_dirty_mask(logic [3:0] beat_dirty_mask, logic [1:0] start_beat, logic [1:0] blen);
     logic [3:0] blen_mask;
     logic [3:0] n_beat_dirty_mask;
     logic [3:0] result;
     case (blen)
        2'b00: blen_mask = 4'b0001;
        2'b01: blen_mask = 4'b0011;
        2'b10: blen_mask = 4'b0111;
        2'b11: blen_mask = 4'b1111;
     endcase
     n_beat_dirty_mask = blen_mask << start_beat;
     result = n_beat_dirty_mask | beat_dirty_mask;
     return result;
   endfunction

   localparam int L2_DDR_BANK_BITS = 4;
   localparam int L2_DDR_ROW_BITS  = 17; 
   //function automatic logic [L2_DDR_BANK_BITS-1:0] l2_bank_slice_bank_id_from_pa(logic [L2_AXI_ADDR_WIDTH-1:0] pa, logic [4:0] bank_id_offset [4:0]);
   //   logic [4:0] bank_id;
   //   bank_id[0] = pa[bank_id_offset[0]];
   //   bank_id[1] = pa[bank_id_offset[1]];
   //   bank_id[2] = pa[bank_id_offset[2]];
   //   bank_id[3] = pa[bank_id_offset[3]];
   //   return bank_id;
   //endfunction 

   // function automatic logic [L2_DDR_ROW_BITS-1:0] l2_bank_slice_row_id_from_pa(logic [L2_AXI_ADDR_WIDTH-1:0] pa, logic [4:0] row_id_offset [L2_DDR_ROW_BITS-1:0]);
   //    logic [L2_DDR_ROW_BITS:0] row_id;
   //    for (int unsigned index = 0; index < L2_DDR_ROW_BITS; index ++) begin
   //       row_id[index] = pa[row_id_offset[index]];
   //    end
   //    return row_id;
   // endfunction
   
   typedef struct                            packed {
      l2_bank_cacheline_instr_type           instruction    ;
      logic [L2_AXI_ID_WIDTH-1:0]            axid           ;
      logic [L2_NUM_SET_BITS-1:0]            set            ;
      logic [L2_NUM_WAY_BITS-1:0]            way            ;
      logic [1:0]                            beat           ;
      logic                                  last           ;
      logic                                  is_buffer_mode ;
      logic                                  initial_mask   ;
      logic [L2_NUM_SECTOR-1:0]              sector_mask    ;
      logic [L2_BEAT_STRB_WIDTH-1:0]         wstrb          ;
      logic [L2_BEAT_WIDTH-1:0]              wdata          ;
   } rctrl_pipeline_record_type;

   function automatic logic [15:0] func_slice_row_id_from_pa (logic [31:0] pa, logic [15:0][31:0] row_id_offset_onehot);
      logic [15:0] result;
      for (int unsigned index = 0; index < 16; index ++) begin
         result[index] = |(pa & row_id_offset_onehot[index]);
      end
      return result;
   endfunction 
   
   
   function automatic logic [4:0] func_slice_bank_id_from_pa(logic [31:0] pa, logic [4:0][31:0] bank_id_offset_onehot);
      logic [4:0] result;
      for (int unsigned index = 0; index < 5; index ++) begin
         result[index] = |(pa & bank_id_offset_onehot[index]);
      end
      return result;
   endfunction


// write strob compress, reduce the half of write strobe
function automatic logic [((L2_AXI_BUS_WIDTH/16)+L2_AXI_BUS_WIDTH)-1 : 0] f_wd_compress (
    logic[ L2_AXI_BUS_WIDTH-1       : 0]    wdata,
    logic[(L2_AXI_BUS_WIDTH/8)-1    : 0]    wstrb,        // active high
    logic                                   is_aa
);
    logic [((L2_AXI_BUS_WIDTH/16)+L2_AXI_BUS_WIDTH)-1 : 0]  compressed_wd;
    logic [(L2_AXI_BUS_WIDTH/32)-1  : 0] f_dword_active;
    logic [(L2_AXI_BUS_WIDTH/32)-1  : 0] f_dword_partial;

    compressed_wd[                  0   +: L2_AXI_BUS_WIDTH     ] = wdata;
    if(is_aa) begin     // discard high-half of write strob
        compressed_wd[L2_AXI_BUS_WIDTH  +: L2_AXI_BUS_WIDTH/16  ] = wstrb[0 +: L2_AXI_BUS_WIDTH/16];
    end
    else begin          //For Non Atomic Access, overwrite output
        for(int unsigned b=0; b<=L2_AXI_BUS_WIDTH/32 - 1; b++) begin
            // 1: at least one of the 4-bits of wstrb is 1, at least 1-byte data is valid
            // 0: all 4-bits wstrb is 0, all 4-bytes data are invalid
            f_dword_active[b]   = (|(wstrb[4*b +: 4]));
            // 1: at least one of the 4-bits of wstrb is 0, at least 1-byte data is invalid
            // 0: all 4-bits wstrb is 1, all 4-bytes data are valid
            f_dword_partial[b]  = (~(&(wstrb[4*b +: 4])));
        end

        for(int unsigned d=0; d<=L2_AXI_BUS_WIDTH/32 - 1; d++) begin // Cycle through all dwords
            // All upper nibbles in each byte are unchanged
            // Only the lower nibbles in partial dwords are altered to compress the wmask
            if(f_dword_partial[d]==1'b1) begin
                // The low nibble of byte 0 is always the byte-granular mask
                compressed_wd[32*d +: 4] = wstrb[4*d +: 4];
                // For bytes 1-3, if the byte is masked then the low nibble is overloaded with the low nibble of byte 0
                for(int unsigned b=1; b<=3; b++) begin
                    if(wstrb[d*4 + b]==1'b0) begin
                        compressed_wd[8*b + 32*d +: 4] = wdata[32*d +: 4];
                    end
                end
            end
        end
        compressed_wd[L2_AXI_BUS_WIDTH  +: L2_AXI_BUS_WIDTH/16  ] = {f_dword_partial, f_dword_active};
    end
    return compressed_wd;
endfunction : f_wd_compress


function automatic iwdb_wdc_wdata_record_type f_wd_decompress (
   logic       [L2_BEAT_WIDTH-1:0]      wdata,
   logic       [L2_BEAT_WIDTH/16-1:0]   wstrb,
   logic                                atomic
);
   logic [L2_BEAT_WIDTH/16/2-1:0]                 dword_active; 
   // 1 bit is associated with 32-bits in wdata; total 16 bits. 1 indicates the corresponse 32-bits data is valid. 0 indicated the 32-bits data is invalid .
   logic [L2_BEAT_WIDTH/16/2-1:0]                 dword_partial; 
   // 1 bit is associated with 32-bits in wdata. 1 indicates the some bits in the 32-bits are invalid. 0 indicates the 32-bits are all valid.

   // |active | partial
   // |  0    |   0     : Invalid combination. assert (partial |-> active);
   // |  0    |   1     : Invalid combination
   // |  1    |   0     : all 32-bits are valid
   // |  1    |   1     : There exist invalid bytes in 32bits. There exist valid bytes in 32 bits
   
   iwdb_wdc_wdata_record_type result;
   result.data = wdata;
   result.strb = '0;
   result.strb[L2_BEAT_WIDTH/16-1:0] = wstrb;


   {dword_partial, dword_active} = wstrb;
   // For atomic wdata, the upper 32bits of wstrb[63:0] is always tied to
   // zero's. The lower 32 bits of wstrb[63:0] is always  connected to strb
   if (atomic == 1'b0) begin
      for (int unsigned dword = 0; dword < L2_BEAT_WIDTH/32; dword++) begin
         if (dword_partial[dword]) begin //
            result.strb[4*dword+:4] = wdata[32*dword+:4]; // for the partial dword, the wstrb is hiden in the first 4 bits in wdata
            for (int unsigned bytes = 1; bytes < 4; bytes ++ ) begin
               if (wdata[32*dword+bytes] == 1'b0) begin
                  result.data[dword*32+:4] = wdata[32*dword + bytes*8+:4];
               end
            end
         end
         else begin // wstrb[3:0] 
            result.strb[4*dword+:4] = {4{dword_active[dword]}};
         end
      end
   end
   return result; 
endfunction

   typedef struct                                        packed{
      l2_bank_memif_instr_type                           memif_instruction                       ;
      logic [L2_AXI_ID_WIDTH-1:0]                        axid                                    ;
      logic [L2_TAG_MSB_BITS:0]                          addr                                    ;
      logic [L2_NUM_SET_BITS-1:0]                        set                                     ;
      logic [1:0]                                        start_beat                              ;
      logic [L2_NUM_WAY_BITS-1:0]                        way                                     ;
      logic [3:0]                                        beat_dirty_mask                         ;
      logic                                              cfi_id                                  ;
      logic [1:0]                                        blen                                    ;
      logic [L2_IWDB_INDEX_BITS-1:0]                     iwdb_index                              ;
      logic                                              wb_check                                ;
      l2_bank_cacheline_instr_type                       cl_instruction                          ; // to fetch write data
   } req_buffer_record_type                                                                      ;

   typedef struct                                        packed{
      logic [L2_AXI_ID_WIDTH-1:0]                        axid                                    ;
      logic [L2_NUM_SET_BITS-1:0]                        set                                     ;
      logic [L2_NUM_WAY_BITS-1:0]                        way                                     ;
      logic [1:0]                                        start_beat                              ;
      logic                                              linefill                                ;
      logic [1:0]                                        blen                                    ; // align to 512-bit width
      logic [2:0]                                        cnt                                     ; // receive nsp counter
      logic [L2_ROB_BITS-1:0]                            rob_index                               ; // The LSB is always 0;
      logic                                              wb_check                                ; // asserted when tagctrl return
      logic                                              avaliable                               ;
   } arid_entry_record_type                                                                      ;

   typedef struct                                        packed{
      logic [L2_AXI_ID_WIDTH-1:0]                        axid                                    ;
      logic                                              rnw                                     ; 
      logic [L2_NUM_SET_BITS-1:0]                        set                                     ;
      logic [L2_NUM_WAY_BITS-1:0]                        way                                     ;
      logic [1:0]                                        start_beat                              ;
      logic                                              linefill                                ;
      logic [1:0]                                        blen                                    ; // align to 512-bit width
      logic [2:0]                                        cnt                                     ; // receive nsp counter
      logic [L2_ROB_BITS-1:0]                            rob_index                               ; // The LSB is always 0;
      logic                                              wb_check                                ; // asserted when tagctrl return
      logic                                              avaliable                               ;
      logic                                              cfi_id                                  ;
   } nsp_entry_record_type                                                                      ;

typedef struct                                        packed{
      logic                                              rnw                                     ; 
      logic                                              linefill                                ;
      logic [L2_AXI_ID_WIDTH-1:0]                        axid                                    ;
      logic [L2_TAG_MSB_BITS:0]                          addr                                    ;
      logic [L2_NUM_SET_BITS-1:0]                        set                                     ;
      logic [L2_NUM_WAY_BITS-1:0]                        way                                     ;
      logic [1:0]                                        blen                                    ; // align to 512-bit width
      logic [1:0]                                        start_beat                              ;
      logic                                              wb_check                                ; // asserted when tagctrl return
      logic                                              cfi_id                                  ;
      logic [L2_ROB_BITS-1:0]                            rob_index                               ;
   } memory_latency_fifo_record_type                                                             ;

   typedef struct                                        packed{
      logic                                              rnw                                     ; // 1 for read; 0 for write
      logic    [L2_ADDR_BITS-1:0]                        addr                                    ;
      logic    [1:0]                                     blen                                    ; // calculated in 512-bits;
      logic    [L2_BANK_TRID_BITS-1:0]                   trid                                    ;
   } nsp_split_record_type                                                                       ;
   typedef struct                                        packed{
   // synopsys translate_off
      logic [L2_AXI_ID_WIDTH-1:0]                        axid                                    ;
      logic [L2_NUM_SET_BITS-1:0]                        set                                     ;
      logic [L2_NUM_WAY_BITS-1:0]                        way                                     ;
   // synopsys translate_on
      logic                                              cfi_id                                  ;
   } awid_entry_record_type; 



endpackage

// Local Variables:
// verilog-library-directories:("./" ) 
// End:
