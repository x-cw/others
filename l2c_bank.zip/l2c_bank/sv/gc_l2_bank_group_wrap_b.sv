// ---------------------------------------------------------------------------------
// Project Name  : IC_Design
// Author        : liusm
// Email         : liusm@innosilicon.com.cn
// Create On     : 2025/01/20 17:09
// Last Modified : 2025/11/26 14:59
// File Name     : gc_l2_bank_group_wrap_liusm.sv
// Description   :
// 
// Copyright (c) 2025 Innosilicon.
// ALL RIGHTS RESERVED
// 
// ---------------------------------------------------------------------------------
// Modification History:
// Date         By              Version                 Change Description
// ---------------------------------------------------------------------------------
// 2025/01/20   liusm           1.0                     Original
// 
// ----------------------------------------------------------------------------------


module gc_l2_bank_group_wrap_b
import axi5_ar_pkg::*;
import axi5_aw_pkg::*;
import axi5_b_pkg::*;
import axi5_r_pkg::*;
import axi5_w_pkg::*;
import nsp_req_pkg::*;
import nsp_rsp_pkg::*;
import gc_l2_bank_pkg::*;
import group_nsp_req_pkg::*;
import group_nsp_rsp_pkg::*;
import socif_regbank_w_pkg::*;
import socif_regbank_r_pkg::*;
(
      input  logic                                     aclk,
      input  logic                                     aresetn,

      input  logic                                     pclk,                   
      input  logic                                     presetn, 

      
      input  logic                                     dft_test_mode,
      
      input  logic                                     tst_gclkenable,
      input  logic                                     tst_rst_bypass,

      input  logic [2:0]                               l2g_number_id,
      output logic [63:0]                              l2g_perf_event,

      output logic                                     l2g_clk,
      output logic                                     l2g_resetn,
      input  logic [63:0]                              l2g_a_in_perf_event,
      output logic [63:0]                              l2g_a_out_perf_event,


      // socif interface
      
      input  logic                                    socif_wakeup,
      input  logic                                    socif_valid,
      input  logic [L2_REGBANK_ADDR_WIDTH-1   : 0 ]   socif_addr,
      input  logic [ 63 : 0 ]                         socif_wdata,
      input  logic [  7 : 0 ]                         socif_wmask,
      input  logic                                    socif_rdnwr,
      output logic                                    socif_rvalid,
      output logic [ 63 : 0 ]                         socif_rdata,

      output logic                                    nsp_clk,
      output logic                                    nsp_resetn,


      output logic                                    nsp0_req_valid      ,
      input  logic                                    nsp0_req_ready      ,
      output logic  [  2 : 0]                         nsp0_req_opc        ,
      output logic  [  7 : 0]                         nsp0_req_req_length ,
      output logic  [ 32 : 0]                         nsp0_req_req_addr   ,
      output logic                                    nsp0_req_req_flowid ,
      output logic                                    nsp0_req_req_seqid  ,
      output logic  [  7 : 0]                         nsp0_req_req_trid   ,
      output logic                                    nsp0_req_req_excid  ,
      output logic  [255 : 0]                         nsp0_req_req_data   ,
      output logic  [ 31 : 0]                         nsp0_req_req_be	    ,
      output logic                                    nsp0_req_req_last   ,
      
      input  logic                                    nsp0_rsp_valid      ,
      output logic                                    nsp0_rsp_ready      ,
      input  logic  [  7 : 0]                         nsp0_rsp_trid       ,
      input  logic                                    nsp0_rsp_last       ,
      input  logic                                    nsp0_rsp_cont       ,
      input  logic  [  1 : 0]                         nsp0_rsp_status	    ,
      input  logic  [  2 : 0]                         nsp0_rsp_errcode    ,
      input  logic  [255 : 0]                         nsp0_rsp_data       ,

      output logic                                    nsp1_req_valid      ,
      input  logic                                    nsp1_req_ready      ,
      output logic  [  2 : 0]                         nsp1_req_opc        ,
      output logic  [  7 : 0]                         nsp1_req_req_length ,
      output logic  [ 32 : 0]                         nsp1_req_req_addr   ,
      output logic                                    nsp1_req_req_flowid ,
      output logic                                    nsp1_req_req_seqid  ,
      output logic  [  7 : 0]                         nsp1_req_req_trid   ,
      output logic                                    nsp1_req_req_excid  ,
      output logic  [255 : 0]                         nsp1_req_req_data   ,
      output logic  [ 31 : 0]                         nsp1_req_req_be	    ,
      output logic                                    nsp1_req_req_last   ,
      
      input  logic                                    nsp1_rsp_valid      ,
      output logic                                    nsp1_rsp_ready      ,
      input  logic  [  7 : 0]                         nsp1_rsp_trid       ,
      input  logic                                    nsp1_rsp_last       ,
      input  logic                                    nsp1_rsp_cont       ,
      input  logic  [  1 : 0]                         nsp1_rsp_status	    ,
      input  logic  [  2 : 0]                         nsp1_rsp_errcode    ,
      input  logic  [255 : 0]                         nsp1_rsp_data       ,

      output logic                                    nsp2_req_valid      ,
      input  logic                                    nsp2_req_ready      ,
      output logic  [  2 : 0]                         nsp2_req_opc        ,
      output logic  [  7 : 0]                         nsp2_req_req_length ,
      output logic  [ 32 : 0]                         nsp2_req_req_addr   ,
      output logic                                    nsp2_req_req_flowid ,
      output logic                                    nsp2_req_req_seqid  ,
      output logic  [  7 : 0]                         nsp2_req_req_trid   ,
      output logic                                    nsp2_req_req_excid  ,
      output logic  [255 : 0]                         nsp2_req_req_data   ,
      output logic  [ 31 : 0]                         nsp2_req_req_be	    ,
      output logic                                    nsp2_req_req_last   ,
      
      input  logic                                    nsp2_rsp_valid      ,
      output logic                                    nsp2_rsp_ready      ,
      input  logic  [  7 : 0]                         nsp2_rsp_trid       ,
      input  logic                                    nsp2_rsp_last       ,
      input  logic                                    nsp2_rsp_cont       ,
      input  logic  [  1 : 0]                         nsp2_rsp_status	    ,
      input  logic  [  2 : 0]                         nsp2_rsp_errcode    ,
      input  logic  [255 : 0]                         nsp2_rsp_data       ,

      output logic                                    nsp3_req_valid      ,
      input  logic                                    nsp3_req_ready      ,
      output logic  [  2 : 0]                         nsp3_req_opc        ,
      output logic  [  7 : 0]                         nsp3_req_req_length ,
      output logic  [ 32 : 0]                         nsp3_req_req_addr   ,
      output logic                                    nsp3_req_req_flowid ,
      output logic                                    nsp3_req_req_seqid  ,
      output logic  [  7 : 0]                         nsp3_req_req_trid   ,
      output logic                                    nsp3_req_req_excid  ,
      output logic  [255 : 0]                         nsp3_req_req_data   ,
      output logic  [ 31 : 0]                         nsp3_req_req_be	    ,
      output logic                                    nsp3_req_req_last   ,
      
      input  logic                                    nsp3_rsp_valid      ,
      output logic                                    nsp3_rsp_ready      ,
      input  logic  [  7 : 0]                         nsp3_rsp_trid       ,
      input  logic                                    nsp3_rsp_last       ,
      input  logic                                    nsp3_rsp_cont       ,
      input  logic  [  1 : 0]                         nsp3_rsp_status	    ,
      input  logic  [  2 : 0]                         nsp3_rsp_errcode    ,
      input  logic  [255 : 0]                         nsp3_rsp_data       ,


      output logic                                    nsp4_req_valid      ,
      input  logic                                    nsp4_req_ready      ,
      output logic  [  2 : 0]                         nsp4_req_opc        ,
      output logic  [  7 : 0]                         nsp4_req_req_length ,
      output logic  [ 32 : 0]                         nsp4_req_req_addr   ,
      output logic                                    nsp4_req_req_flowid ,
      output logic                                    nsp4_req_req_seqid  ,
      output logic  [  7 : 0]                         nsp4_req_req_trid   ,
      output logic                                    nsp4_req_req_excid  ,
      output logic  [255 : 0]                         nsp4_req_req_data   ,
      output logic  [ 31 : 0]                         nsp4_req_req_be	    ,
      output logic                                    nsp4_req_req_last   ,
      
      input  logic                                    nsp4_rsp_valid      ,
      output logic                                    nsp4_rsp_ready      ,
      input  logic  [  7 : 0]                         nsp4_rsp_trid       ,
      input  logic                                    nsp4_rsp_last       ,
      input  logic                                    nsp4_rsp_cont       ,
      input  logic  [  1 : 0]                         nsp4_rsp_status	    ,
      input  logic  [  2 : 0]                         nsp4_rsp_errcode    ,
      input  logic  [255 : 0]                         nsp4_rsp_data       ,


      output logic                                    nsp5_req_valid      ,
      input  logic                                    nsp5_req_ready      ,
      output logic  [  2 : 0]                         nsp5_req_opc        ,
      output logic  [  7 : 0]                         nsp5_req_req_length ,
      output logic  [ 32 : 0]                         nsp5_req_req_addr   ,
      output logic                                    nsp5_req_req_flowid ,
      output logic                                    nsp5_req_req_seqid  ,
      output logic  [  7 : 0]                         nsp5_req_req_trid   ,
      output logic                                    nsp5_req_req_excid  ,
      output logic  [255 : 0]                         nsp5_req_req_data   ,
      output logic  [ 31 : 0]                         nsp5_req_req_be	    ,
      output logic                                    nsp5_req_req_last   ,
      
      input  logic                                    nsp5_rsp_valid      ,
      output logic                                    nsp5_rsp_ready      ,
      input  logic  [  7 : 0]                         nsp5_rsp_trid       ,
      input  logic                                    nsp5_rsp_last       ,
      input  logic                                    nsp5_rsp_cont       ,
      input  logic  [  1 : 0]                         nsp5_rsp_status	    ,
      input  logic  [  2 : 0]                         nsp5_rsp_errcode    ,
      input  logic  [255 : 0]                         nsp5_rsp_data       ,


      output logic                                    nsp6_req_valid      ,
      input  logic                                    nsp6_req_ready      ,
      output logic  [  2 : 0]                         nsp6_req_opc        ,
      output logic  [  7 : 0]                         nsp6_req_req_length ,
      output logic  [ 32 : 0]                         nsp6_req_req_addr   ,
      output logic                                    nsp6_req_req_flowid ,
      output logic                                    nsp6_req_req_seqid  ,
      output logic  [  7 : 0]                         nsp6_req_req_trid   ,
      output logic                                    nsp6_req_req_excid  ,
      output logic  [255 : 0]                         nsp6_req_req_data   ,
      output logic  [ 31 : 0]                         nsp6_req_req_be	    ,
      output logic                                    nsp6_req_req_last   ,
      
      input  logic                                    nsp6_rsp_valid      ,
      output logic                                    nsp6_rsp_ready      ,
      input  logic  [  7 : 0]                         nsp6_rsp_trid       ,
      input  logic                                    nsp6_rsp_last       ,
      input  logic                                    nsp6_rsp_cont       ,
      input  logic  [  1 : 0]                         nsp6_rsp_status	    ,
      input  logic  [  2 : 0]                         nsp6_rsp_errcode    ,
      input  logic  [255 : 0]                         nsp6_rsp_data       ,


      output logic                                    nsp7_req_valid      ,
      input  logic                                    nsp7_req_ready      ,
      output logic  [  2 : 0]                         nsp7_req_opc        ,
      output logic  [  7 : 0]                         nsp7_req_req_length ,
      output logic  [ 32 : 0]                         nsp7_req_req_addr   ,
      output logic                                    nsp7_req_req_flowid ,
      output logic                                    nsp7_req_req_seqid  ,
      output logic  [  7 : 0]                         nsp7_req_req_trid   ,
      output logic                                    nsp7_req_req_excid  ,
      output logic  [255 : 0]                         nsp7_req_req_data   ,
      output logic  [ 31 : 0]                         nsp7_req_req_be	    ,
      output logic                                    nsp7_req_req_last   ,
      
      input  logic                                    nsp7_rsp_valid      ,
      output logic                                    nsp7_rsp_ready      ,
      input  logic  [  7 : 0]                         nsp7_rsp_trid       ,
      input  logic                                    nsp7_rsp_last       ,
      input  logic                                    nsp7_rsp_cont       ,
      input  logic  [  1 : 0]                         nsp7_rsp_status	    ,
      input  logic  [  2 : 0]                         nsp7_rsp_errcode    ,
      input  logic  [255 : 0]                         nsp7_rsp_data       ,

      output logic                                    nsp8_req_valid      ,
      input  logic                                    nsp8_req_ready      ,
      output logic  [  2 : 0]                         nsp8_req_opc        ,
      output logic  [  7 : 0]                         nsp8_req_req_length ,
      output logic  [ 32 : 0]                         nsp8_req_req_addr   ,
      output logic                                    nsp8_req_req_flowid ,
      output logic                                    nsp8_req_req_seqid  ,
      output logic  [  7 : 0]                         nsp8_req_req_trid   ,
      output logic                                    nsp8_req_req_excid  ,
      output logic  [255 : 0]                         nsp8_req_req_data   ,
      output logic  [ 31 : 0]                         nsp8_req_req_be	    ,
      output logic                                    nsp8_req_req_last   ,
      
      input  logic                                    nsp8_rsp_valid      ,
      output logic                                    nsp8_rsp_ready      ,
      input  logic  [  7 : 0]                         nsp8_rsp_trid       ,
      input  logic                                    nsp8_rsp_last       ,
      input  logic                                    nsp8_rsp_cont       ,
      input  logic  [  1 : 0]                         nsp8_rsp_status	    ,
      input  logic  [  2 : 0]                         nsp8_rsp_errcode    ,
      input  logic  [255 : 0]                         nsp8_rsp_data       ,


      output logic                                    nsp9_req_valid      ,
      input  logic                                    nsp9_req_ready      ,
      output logic  [  2 : 0]                         nsp9_req_opc        ,
      output logic  [  7 : 0]                         nsp9_req_req_length ,
      output logic  [ 32 : 0]                         nsp9_req_req_addr   ,
      output logic                                    nsp9_req_req_flowid ,
      output logic                                    nsp9_req_req_seqid  ,
      output logic  [  7 : 0]                         nsp9_req_req_trid   ,
      output logic                                    nsp9_req_req_excid  ,
      output logic  [255 : 0]                         nsp9_req_req_data   ,
      output logic  [ 31 : 0]                         nsp9_req_req_be	    ,
      output logic                                    nsp9_req_req_last   ,
      
      input  logic                                    nsp9_rsp_valid      ,
      output logic                                    nsp9_rsp_ready      ,
      input  logic  [  7 : 0]                         nsp9_rsp_trid       ,
      input  logic                                    nsp9_rsp_last       ,
      input  logic                                    nsp9_rsp_cont       ,
      input  logic  [  1 : 0]                         nsp9_rsp_status	    ,
      input  logic  [  2 : 0]                         nsp9_rsp_errcode    ,
      input  logic  [255 : 0]                         nsp9_rsp_data       ,







      input  logic [46:0]                                                                  adb_apb3_cbus_fw_payld_async,
      input  logic [5:0]                                                                   adb_apb3_cbus_fw_wr_ptr_async,
      input  logic [5:0]                                                                   adb_apb3_cbus_rv_rd_ptr_async,
      input  logic [5:0]                                                                   adb_apb3_cbus_rv_rd_ptr_sync,
      input  logic                                                                         adb_apb3_cbus_si_to_mi_wakeup_async,
      input  logic                                                                         adb_apb3_cbus_slvcandenyreqn_async,
      input  logic                                                                         adb_apb3_cbus_slvmustacceptreqn_async,
      output logic [5:0]                                                                   adb_apb3_cbus_fw_rd_ptr_async,
      output logic [5:0]                                                                   adb_apb3_cbus_fw_rd_ptr_sync,
      output logic                                                                         adb_apb3_cbus_mi_to_si_wakeup_async,
      output logic [32:0]                                                                  adb_apb3_cbus_rv_payld_async,
      output logic [5:0]                                                                   adb_apb3_cbus_rv_wr_ptr_async,
      output logic                                                                         adb_apb3_cbus_slvacceptn_async,
      output logic                                                                         adb_apb3_cbus_slvdeny_async,



      // 14 = arregion[3:0] + arlen[7:2] + arlock + arprot[2:0]
      // bank0
      input logic [AXI5_AR_DATA_BUS_BITS+14-1:0]                                          adb_l2c_0_dbus_ar_payld_async,
      input logic [5:0]                                                                   adb_l2c_0_dbus_ar_wr_ptr_async,
      input logic [AXI5_AW_DATA_BUS_BITS+14-1:0]                                          adb_l2c_0_dbus_aw_payld_async,
      input logic [5:0]                                                                   adb_l2c_0_dbus_aw_wr_ptr_async,
      input logic [5:0]                                                                   adb_l2c_0_dbus_b_rd_ptr_async,
      input logic [5:0]                                                                   adb_l2c_0_dbus_b_rd_ptr_sync,
      input logic [5:0]                                                                   adb_l2c_0_dbus_r_rd_ptr_async,
      input logic [5:0]                                                                   adb_l2c_0_dbus_r_rd_ptr_sync,
      input logic                                                                         adb_l2c_0_dbus_si_to_mi_wakeup_async,
      input logic                                                                         adb_l2c_0_dbus_slvcandenyreqn_async,
      input logic                                                                         adb_l2c_0_dbus_slvmustacceptreqn_async,
      input logic [AXI5_W_DATA_BUS_BITS+L2_AXI_USER_WIDTH-1:0]                            adb_l2c_0_dbus_w_payld_async,
      input logic [5:0]                                                                   adb_l2c_0_dbus_w_wr_ptr_async,
      
      output logic [5:0]                                                                  adb_l2c_0_dbus_ar_rd_ptr_async,
      output logic [5:0]                                                                  adb_l2c_0_dbus_ar_rd_ptr_sync,
      output logic [5:0]                                                                  adb_l2c_0_dbus_aw_rd_ptr_async,
      output logic [5:0]                                                                  adb_l2c_0_dbus_aw_rd_ptr_sync,
      output logic [AXI5_B_DATA_BUS_BITS+L2_AXI_USER_WIDTH-1:0]                           adb_l2c_0_dbus_b_payld_async,
      output logic [5:0]                                                                  adb_l2c_0_dbus_b_wr_ptr_async,
      output logic                                                                        adb_l2c_0_dbus_mi_to_si_wakeup_async,
      output logic [AXI5_R_DATA_BUS_BITS+L2_AXI_USER_WIDTH-1:0]                           adb_l2c_0_dbus_r_payld_async,
      output logic [5:0]                                                                  adb_l2c_0_dbus_r_wr_ptr_async,
      output logic                                                                        adb_l2c_0_dbus_slvacceptn_async,
      output logic                                                                        adb_l2c_0_dbus_slvdeny_async,
      output logic [5:0]                                                                  adb_l2c_0_dbus_w_rd_ptr_async,
      output logic [5:0]                                                                  adb_l2c_0_dbus_w_rd_ptr_sync,

      // 14 = arregion[3:0] + arlen[7:2] + arlock + arprot[2:0]
      // bank1
      input logic [AXI5_AR_DATA_BUS_BITS+14-1:0]                                          adb_l2c_1_dbus_ar_payld_async,
      input logic [5:0]                                                                   adb_l2c_1_dbus_ar_wr_ptr_async,
      input logic [AXI5_AW_DATA_BUS_BITS+14-1:0]                                          adb_l2c_1_dbus_aw_payld_async,
      input logic [5:0]                                                                   adb_l2c_1_dbus_aw_wr_ptr_async,
      input logic [5:0]                                                                   adb_l2c_1_dbus_b_rd_ptr_async,
      input logic [5:0]                                                                   adb_l2c_1_dbus_b_rd_ptr_sync,
      input logic [5:0]                                                                   adb_l2c_1_dbus_r_rd_ptr_async,
      input logic [5:0]                                                                   adb_l2c_1_dbus_r_rd_ptr_sync,
      input logic                                                                         adb_l2c_1_dbus_si_to_mi_wakeup_async,
      input logic                                                                         adb_l2c_1_dbus_slvcandenyreqn_async,
      input logic                                                                         adb_l2c_1_dbus_slvmustacceptreqn_async,
      input logic [AXI5_W_DATA_BUS_BITS+L2_AXI_USER_WIDTH-1:0]                            adb_l2c_1_dbus_w_payld_async,
      input logic [5:0]                                                                   adb_l2c_1_dbus_w_wr_ptr_async,
      
      output logic [5:0]                                                                  adb_l2c_1_dbus_ar_rd_ptr_async,
      output logic [5:0]                                                                  adb_l2c_1_dbus_ar_rd_ptr_sync,
      output logic [5:0]                                                                  adb_l2c_1_dbus_aw_rd_ptr_async,
      output logic [5:0]                                                                  adb_l2c_1_dbus_aw_rd_ptr_sync,
      output logic [AXI5_B_DATA_BUS_BITS+L2_AXI_USER_WIDTH-1:0]                           adb_l2c_1_dbus_b_payld_async,
      output logic [5:0]                                                                  adb_l2c_1_dbus_b_wr_ptr_async,
      output logic                                                                        adb_l2c_1_dbus_mi_to_si_wakeup_async,
      output logic [AXI5_R_DATA_BUS_BITS+L2_AXI_USER_WIDTH-1:0]                           adb_l2c_1_dbus_r_payld_async,
      output logic [5:0]                                                                  adb_l2c_1_dbus_r_wr_ptr_async,
      output logic                                                                        adb_l2c_1_dbus_slvacceptn_async,
      output logic                                                                        adb_l2c_1_dbus_slvdeny_async,
      output logic [5:0]                                                                  adb_l2c_1_dbus_w_rd_ptr_async,
      output logic [5:0]                                                                  adb_l2c_1_dbus_w_rd_ptr_sync,

      // 14 = arregion[3:0] + arlen[7:2] + arlock + arprot[2:0]
      // bank2
      input logic [AXI5_AR_DATA_BUS_BITS+14-1:0]                                          adb_l2c_2_dbus_ar_payld_async,
      input logic [5:0]                                                                   adb_l2c_2_dbus_ar_wr_ptr_async,
      input logic [AXI5_AW_DATA_BUS_BITS+14-1:0]                                          adb_l2c_2_dbus_aw_payld_async,
      input logic [5:0]                                                                   adb_l2c_2_dbus_aw_wr_ptr_async,
      input logic [5:0]                                                                   adb_l2c_2_dbus_b_rd_ptr_async,
      input logic [5:0]                                                                   adb_l2c_2_dbus_b_rd_ptr_sync,
      input logic [5:0]                                                                   adb_l2c_2_dbus_r_rd_ptr_async,
      input logic [5:0]                                                                   adb_l2c_2_dbus_r_rd_ptr_sync,
      input logic                                                                         adb_l2c_2_dbus_si_to_mi_wakeup_async,
      input logic                                                                         adb_l2c_2_dbus_slvcandenyreqn_async,
      input logic                                                                         adb_l2c_2_dbus_slvmustacceptreqn_async,
      input logic [AXI5_W_DATA_BUS_BITS+L2_AXI_USER_WIDTH-1:0]                            adb_l2c_2_dbus_w_payld_async,
      input logic [5:0]                                                                   adb_l2c_2_dbus_w_wr_ptr_async,
      
      output logic [5:0]                                                                  adb_l2c_2_dbus_ar_rd_ptr_async,
      output logic [5:0]                                                                  adb_l2c_2_dbus_ar_rd_ptr_sync,
      output logic [5:0]                                                                  adb_l2c_2_dbus_aw_rd_ptr_async,
      output logic [5:0]                                                                  adb_l2c_2_dbus_aw_rd_ptr_sync,
      output logic [AXI5_B_DATA_BUS_BITS+L2_AXI_USER_WIDTH-1:0]                           adb_l2c_2_dbus_b_payld_async,
      output logic [5:0]                                                                  adb_l2c_2_dbus_b_wr_ptr_async,
      output logic                                                                        adb_l2c_2_dbus_mi_to_si_wakeup_async,
      output logic [AXI5_R_DATA_BUS_BITS+L2_AXI_USER_WIDTH-1:0]                           adb_l2c_2_dbus_r_payld_async,
      output logic [5:0]                                                                  adb_l2c_2_dbus_r_wr_ptr_async,
      output logic                                                                        adb_l2c_2_dbus_slvacceptn_async,
      output logic                                                                        adb_l2c_2_dbus_slvdeny_async,
      output logic [5:0]                                                                  adb_l2c_2_dbus_w_rd_ptr_async,
      output logic [5:0]                                                                  adb_l2c_2_dbus_w_rd_ptr_sync,

      // 14 = arregion[3:0] + arlen[7:2] + arlock + arprot[2:0]
      // bank3
      input logic [AXI5_AR_DATA_BUS_BITS+14-1:0]                                          adb_l2c_3_dbus_ar_payld_async,
      input logic [5:0]                                                                   adb_l2c_3_dbus_ar_wr_ptr_async,
      input logic [AXI5_AW_DATA_BUS_BITS+14-1:0]                                          adb_l2c_3_dbus_aw_payld_async,
      input logic [5:0]                                                                   adb_l2c_3_dbus_aw_wr_ptr_async,
      input logic [5:0]                                                                   adb_l2c_3_dbus_b_rd_ptr_async,
      input logic [5:0]                                                                   adb_l2c_3_dbus_b_rd_ptr_sync,
      input logic [5:0]                                                                   adb_l2c_3_dbus_r_rd_ptr_async,
      input logic [5:0]                                                                   adb_l2c_3_dbus_r_rd_ptr_sync,
      input logic                                                                         adb_l2c_3_dbus_si_to_mi_wakeup_async,
      input logic                                                                         adb_l2c_3_dbus_slvcandenyreqn_async,
      input logic                                                                         adb_l2c_3_dbus_slvmustacceptreqn_async,
      input logic [AXI5_W_DATA_BUS_BITS+L2_AXI_USER_WIDTH-1:0]                            adb_l2c_3_dbus_w_payld_async,
      input logic [5:0]                                                                   adb_l2c_3_dbus_w_wr_ptr_async,
      
      output logic [5:0]                                                                  adb_l2c_3_dbus_ar_rd_ptr_async,
      output logic [5:0]                                                                  adb_l2c_3_dbus_ar_rd_ptr_sync,
      output logic [5:0]                                                                  adb_l2c_3_dbus_aw_rd_ptr_async,
      output logic [5:0]                                                                  adb_l2c_3_dbus_aw_rd_ptr_sync,
      output logic [AXI5_B_DATA_BUS_BITS+L2_AXI_USER_WIDTH-1:0]                           adb_l2c_3_dbus_b_payld_async,
      output logic [5:0]                                                                  adb_l2c_3_dbus_b_wr_ptr_async,
      output logic                                                                        adb_l2c_3_dbus_mi_to_si_wakeup_async,
      output logic [AXI5_R_DATA_BUS_BITS+L2_AXI_USER_WIDTH-1:0]                           adb_l2c_3_dbus_r_payld_async,
      output logic [5:0]                                                                  adb_l2c_3_dbus_r_wr_ptr_async,
      output logic                                                                        adb_l2c_3_dbus_slvacceptn_async,
      output logic                                                                        adb_l2c_3_dbus_slvdeny_async,
      output logic [5:0]                                                                  adb_l2c_3_dbus_w_rd_ptr_async,
      output logic [5:0]                                                                  adb_l2c_3_dbus_w_rd_ptr_sync,

      // 14 = arregion[3:0] + arlen[7:2] + arlock + arprot[2:0]
      // bank4
      input logic [AXI5_AR_DATA_BUS_BITS+14-1:0]                                          adb_l2c_4_dbus_ar_payld_async,
      input logic [5:0]                                                                   adb_l2c_4_dbus_ar_wr_ptr_async,
      input logic [AXI5_AW_DATA_BUS_BITS+14-1:0]                                          adb_l2c_4_dbus_aw_payld_async,
      input logic [5:0]                                                                   adb_l2c_4_dbus_aw_wr_ptr_async,
      input logic [5:0]                                                                   adb_l2c_4_dbus_b_rd_ptr_async,
      input logic [5:0]                                                                   adb_l2c_4_dbus_b_rd_ptr_sync,
      input logic [5:0]                                                                   adb_l2c_4_dbus_r_rd_ptr_async,
      input logic [5:0]                                                                   adb_l2c_4_dbus_r_rd_ptr_sync,
      input logic                                                                         adb_l2c_4_dbus_si_to_mi_wakeup_async,
      input logic                                                                         adb_l2c_4_dbus_slvcandenyreqn_async,
      input logic                                                                         adb_l2c_4_dbus_slvmustacceptreqn_async,
      input logic [AXI5_W_DATA_BUS_BITS+L2_AXI_USER_WIDTH-1:0]                            adb_l2c_4_dbus_w_payld_async,
      input logic [5:0]                                                                   adb_l2c_4_dbus_w_wr_ptr_async,
      
      output logic [5:0]                                                                  adb_l2c_4_dbus_ar_rd_ptr_async,
      output logic [5:0]                                                                  adb_l2c_4_dbus_ar_rd_ptr_sync,
      output logic [5:0]                                                                  adb_l2c_4_dbus_aw_rd_ptr_async,
      output logic [5:0]                                                                  adb_l2c_4_dbus_aw_rd_ptr_sync,
      output logic [AXI5_B_DATA_BUS_BITS+L2_AXI_USER_WIDTH-1:0]                           adb_l2c_4_dbus_b_payld_async,
      output logic [5:0]                                                                  adb_l2c_4_dbus_b_wr_ptr_async,
      output logic                                                                        adb_l2c_4_dbus_mi_to_si_wakeup_async,
      output logic [AXI5_R_DATA_BUS_BITS+L2_AXI_USER_WIDTH-1:0]                           adb_l2c_4_dbus_r_payld_async,
      output logic [5:0]                                                                  adb_l2c_4_dbus_r_wr_ptr_async,
      output logic                                                                        adb_l2c_4_dbus_slvacceptn_async,
      output logic                                                                        adb_l2c_4_dbus_slvdeny_async,
      output logic [5:0]                                                                  adb_l2c_4_dbus_w_rd_ptr_async,
      output logic [5:0]                                                                  adb_l2c_4_dbus_w_rd_ptr_sync,

      // 14 = arregion[3:0] + arlen[7:2] + arlock + arprot[2:0]
      // bank5
      input logic [AXI5_AR_DATA_BUS_BITS+14-1:0]                                          adb_l2c_5_dbus_ar_payld_async,
      input logic [5:0]                                                                   adb_l2c_5_dbus_ar_wr_ptr_async,
      input logic [AXI5_AW_DATA_BUS_BITS+14-1:0]                                          adb_l2c_5_dbus_aw_payld_async,
      input logic [5:0]                                                                   adb_l2c_5_dbus_aw_wr_ptr_async,
      input logic [5:0]                                                                   adb_l2c_5_dbus_b_rd_ptr_async,
      input logic [5:0]                                                                   adb_l2c_5_dbus_b_rd_ptr_sync,
      input logic [5:0]                                                                   adb_l2c_5_dbus_r_rd_ptr_async,
      input logic [5:0]                                                                   adb_l2c_5_dbus_r_rd_ptr_sync,
      input logic                                                                         adb_l2c_5_dbus_si_to_mi_wakeup_async,
      input logic                                                                         adb_l2c_5_dbus_slvcandenyreqn_async,
      input logic                                                                         adb_l2c_5_dbus_slvmustacceptreqn_async,
      input logic [AXI5_W_DATA_BUS_BITS+L2_AXI_USER_WIDTH-1:0]                            adb_l2c_5_dbus_w_payld_async,
      input logic [5:0]                                                                   adb_l2c_5_dbus_w_wr_ptr_async,
      
      output logic [5:0]                                                                  adb_l2c_5_dbus_ar_rd_ptr_async,
      output logic [5:0]                                                                  adb_l2c_5_dbus_ar_rd_ptr_sync,
      output logic [5:0]                                                                  adb_l2c_5_dbus_aw_rd_ptr_async,
      output logic [5:0]                                                                  adb_l2c_5_dbus_aw_rd_ptr_sync,
      output logic [AXI5_B_DATA_BUS_BITS+L2_AXI_USER_WIDTH-1:0]                           adb_l2c_5_dbus_b_payld_async,
      output logic [5:0]                                                                  adb_l2c_5_dbus_b_wr_ptr_async,
      output logic                                                                        adb_l2c_5_dbus_mi_to_si_wakeup_async,
      output logic [AXI5_R_DATA_BUS_BITS+L2_AXI_USER_WIDTH-1:0]                           adb_l2c_5_dbus_r_payld_async,
      output logic [5:0]                                                                  adb_l2c_5_dbus_r_wr_ptr_async,
      output logic                                                                        adb_l2c_5_dbus_slvacceptn_async,
      output logic                                                                        adb_l2c_5_dbus_slvdeny_async,
      output logic [5:0]                                                                  adb_l2c_5_dbus_w_rd_ptr_async,
      output logic [5:0]                                                                  adb_l2c_5_dbus_w_rd_ptr_sync,

      // 14 = arregion[3:0] + arlen[7:2] + arlock + arprot[2:0]
      // bank6
      input logic [AXI5_AR_DATA_BUS_BITS+14-1:0]                                          adb_l2c_6_dbus_ar_payld_async,
      input logic [5:0]                                                                   adb_l2c_6_dbus_ar_wr_ptr_async,
      input logic [AXI5_AW_DATA_BUS_BITS+14-1:0]                                          adb_l2c_6_dbus_aw_payld_async,
      input logic [5:0]                                                                   adb_l2c_6_dbus_aw_wr_ptr_async,
      input logic [5:0]                                                                   adb_l2c_6_dbus_b_rd_ptr_async,
      input logic [5:0]                                                                   adb_l2c_6_dbus_b_rd_ptr_sync,
      input logic [5:0]                                                                   adb_l2c_6_dbus_r_rd_ptr_async,
      input logic [5:0]                                                                   adb_l2c_6_dbus_r_rd_ptr_sync,
      input logic                                                                         adb_l2c_6_dbus_si_to_mi_wakeup_async,
      input logic                                                                         adb_l2c_6_dbus_slvcandenyreqn_async,
      input logic                                                                         adb_l2c_6_dbus_slvmustacceptreqn_async,
      input logic [AXI5_W_DATA_BUS_BITS+L2_AXI_USER_WIDTH-1:0]                            adb_l2c_6_dbus_w_payld_async,
      input logic [5:0]                                                                   adb_l2c_6_dbus_w_wr_ptr_async,
      
      output logic [5:0]                                                                  adb_l2c_6_dbus_ar_rd_ptr_async,
      output logic [5:0]                                                                  adb_l2c_6_dbus_ar_rd_ptr_sync,
      output logic [5:0]                                                                  adb_l2c_6_dbus_aw_rd_ptr_async,
      output logic [5:0]                                                                  adb_l2c_6_dbus_aw_rd_ptr_sync,
      output logic [AXI5_B_DATA_BUS_BITS+L2_AXI_USER_WIDTH-1:0]                           adb_l2c_6_dbus_b_payld_async,
      output logic [5:0]                                                                  adb_l2c_6_dbus_b_wr_ptr_async,
      output logic                                                                        adb_l2c_6_dbus_mi_to_si_wakeup_async,
      output logic [AXI5_R_DATA_BUS_BITS+L2_AXI_USER_WIDTH-1:0]                           adb_l2c_6_dbus_r_payld_async,
      output logic [5:0]                                                                  adb_l2c_6_dbus_r_wr_ptr_async,
      output logic                                                                        adb_l2c_6_dbus_slvacceptn_async,
      output logic                                                                        adb_l2c_6_dbus_slvdeny_async,
      output logic [5:0]                                                                  adb_l2c_6_dbus_w_rd_ptr_async,
      output logic [5:0]                                                                  adb_l2c_6_dbus_w_rd_ptr_sync,

      // 14 = arregion[3:0] + arlen[7:2] + arlock + arprot[2:0]
      // bank7
      input logic [AXI5_AR_DATA_BUS_BITS+14-1:0]                                          adb_l2c_7_dbus_ar_payld_async,
      input logic [5:0]                                                                   adb_l2c_7_dbus_ar_wr_ptr_async,
      input logic [AXI5_AW_DATA_BUS_BITS+14-1:0]                                          adb_l2c_7_dbus_aw_payld_async,
      input logic [5:0]                                                                   adb_l2c_7_dbus_aw_wr_ptr_async,
      input logic [5:0]                                                                   adb_l2c_7_dbus_b_rd_ptr_async,
      input logic [5:0]                                                                   adb_l2c_7_dbus_b_rd_ptr_sync,
      input logic [5:0]                                                                   adb_l2c_7_dbus_r_rd_ptr_async,
      input logic [5:0]                                                                   adb_l2c_7_dbus_r_rd_ptr_sync,
      input logic                                                                         adb_l2c_7_dbus_si_to_mi_wakeup_async,
      input logic                                                                         adb_l2c_7_dbus_slvcandenyreqn_async,
      input logic                                                                         adb_l2c_7_dbus_slvmustacceptreqn_async,
      input logic [AXI5_W_DATA_BUS_BITS+L2_AXI_USER_WIDTH-1:0]                            adb_l2c_7_dbus_w_payld_async,
      input logic [5:0]                                                                   adb_l2c_7_dbus_w_wr_ptr_async,
      
      output logic [5:0]                                                                  adb_l2c_7_dbus_ar_rd_ptr_async,
      output logic [5:0]                                                                  adb_l2c_7_dbus_ar_rd_ptr_sync,
      output logic [5:0]                                                                  adb_l2c_7_dbus_aw_rd_ptr_async,
      output logic [5:0]                                                                  adb_l2c_7_dbus_aw_rd_ptr_sync,
      output logic [AXI5_B_DATA_BUS_BITS+L2_AXI_USER_WIDTH-1:0]                           adb_l2c_7_dbus_b_payld_async,
      output logic [5:0]                                                                  adb_l2c_7_dbus_b_wr_ptr_async,
      output logic                                                                        adb_l2c_7_dbus_mi_to_si_wakeup_async,
      output logic [AXI5_R_DATA_BUS_BITS+L2_AXI_USER_WIDTH-1:0]                           adb_l2c_7_dbus_r_payld_async,
      output logic [5:0]                                                                  adb_l2c_7_dbus_r_wr_ptr_async,
      output logic                                                                        adb_l2c_7_dbus_slvacceptn_async,
      output logic                                                                        adb_l2c_7_dbus_slvdeny_async,
      output logic [5:0]                                                                  adb_l2c_7_dbus_w_rd_ptr_async,
      output logic [5:0]                                                                  adb_l2c_7_dbus_w_rd_ptr_sync,

      // 14 = arregion[3:0] + arlen[7:2] + arlock + arprot[2:0]
      // bank7
      input logic [AXI5_AR_DATA_BUS_BITS+14-1:0]                                          adb_l2c_8_dbus_ar_payld_async,
      input logic [5:0]                                                                   adb_l2c_8_dbus_ar_wr_ptr_async,
      input logic [AXI5_AW_DATA_BUS_BITS+14-1:0]                                          adb_l2c_8_dbus_aw_payld_async,
      input logic [5:0]                                                                   adb_l2c_8_dbus_aw_wr_ptr_async,
      input logic [5:0]                                                                   adb_l2c_8_dbus_b_rd_ptr_async,
      input logic [5:0]                                                                   adb_l2c_8_dbus_b_rd_ptr_sync,
      input logic [5:0]                                                                   adb_l2c_8_dbus_r_rd_ptr_async,
      input logic [5:0]                                                                   adb_l2c_8_dbus_r_rd_ptr_sync,
      input logic                                                                         adb_l2c_8_dbus_si_to_mi_wakeup_async,
      input logic                                                                         adb_l2c_8_dbus_slvcandenyreqn_async,
      input logic                                                                         adb_l2c_8_dbus_slvmustacceptreqn_async,
      input logic [AXI5_W_DATA_BUS_BITS+L2_AXI_USER_WIDTH-1:0]                            adb_l2c_8_dbus_w_payld_async,
      input logic [5:0]                                                                   adb_l2c_8_dbus_w_wr_ptr_async,
      
      output logic [5:0]                                                                  adb_l2c_8_dbus_ar_rd_ptr_async,
      output logic [5:0]                                                                  adb_l2c_8_dbus_ar_rd_ptr_sync,
      output logic [5:0]                                                                  adb_l2c_8_dbus_aw_rd_ptr_async,
      output logic [5:0]                                                                  adb_l2c_8_dbus_aw_rd_ptr_sync,
      output logic [AXI5_B_DATA_BUS_BITS+L2_AXI_USER_WIDTH-1:0]                           adb_l2c_8_dbus_b_payld_async,
      output logic [5:0]                                                                  adb_l2c_8_dbus_b_wr_ptr_async,
      output logic                                                                        adb_l2c_8_dbus_mi_to_si_wakeup_async,
      output logic [AXI5_R_DATA_BUS_BITS+L2_AXI_USER_WIDTH-1:0]                           adb_l2c_8_dbus_r_payld_async,
      output logic [5:0]                                                                  adb_l2c_8_dbus_r_wr_ptr_async,
      output logic                                                                        adb_l2c_8_dbus_slvacceptn_async,
      output logic                                                                        adb_l2c_8_dbus_slvdeny_async,
      output logic [5:0]                                                                  adb_l2c_8_dbus_w_rd_ptr_async,
      output logic [5:0]                                                                  adb_l2c_8_dbus_w_rd_ptr_sync,
      
      // 14 = arregion[3:0] + arlen[7:2] + arlock + arprot[2:0]
      // bank7
      input logic [AXI5_AR_DATA_BUS_BITS+14-1:0]                                          adb_l2c_9_dbus_ar_payld_async,
      input logic [5:0]                                                                   adb_l2c_9_dbus_ar_wr_ptr_async,
      input logic [AXI5_AW_DATA_BUS_BITS+14-1:0]                                          adb_l2c_9_dbus_aw_payld_async,
      input logic [5:0]                                                                   adb_l2c_9_dbus_aw_wr_ptr_async,
      input logic [5:0]                                                                   adb_l2c_9_dbus_b_rd_ptr_async,
      input logic [5:0]                                                                   adb_l2c_9_dbus_b_rd_ptr_sync,
      input logic [5:0]                                                                   adb_l2c_9_dbus_r_rd_ptr_async,
      input logic [5:0]                                                                   adb_l2c_9_dbus_r_rd_ptr_sync,
      input logic                                                                         adb_l2c_9_dbus_si_to_mi_wakeup_async,
      input logic                                                                         adb_l2c_9_dbus_slvcandenyreqn_async,
      input logic                                                                         adb_l2c_9_dbus_slvmustacceptreqn_async,
      input logic [AXI5_W_DATA_BUS_BITS+L2_AXI_USER_WIDTH-1:0]                            adb_l2c_9_dbus_w_payld_async,
      input logic [5:0]                                                                   adb_l2c_9_dbus_w_wr_ptr_async,
      
      output logic [5:0]                                                                  adb_l2c_9_dbus_ar_rd_ptr_async,
      output logic [5:0]                                                                  adb_l2c_9_dbus_ar_rd_ptr_sync,
      output logic [5:0]                                                                  adb_l2c_9_dbus_aw_rd_ptr_async,
      output logic [5:0]                                                                  adb_l2c_9_dbus_aw_rd_ptr_sync,
      output logic [AXI5_B_DATA_BUS_BITS+L2_AXI_USER_WIDTH-1:0]                           adb_l2c_9_dbus_b_payld_async,
      output logic [5:0]                                                                  adb_l2c_9_dbus_b_wr_ptr_async,
      output logic                                                                        adb_l2c_9_dbus_mi_to_si_wakeup_async,
      output logic [AXI5_R_DATA_BUS_BITS+L2_AXI_USER_WIDTH-1:0]                           adb_l2c_9_dbus_r_payld_async,
      output logic [5:0]                                                                  adb_l2c_9_dbus_r_wr_ptr_async,
      output logic                                                                        adb_l2c_9_dbus_slvacceptn_async,
      output logic                                                                        adb_l2c_9_dbus_slvdeny_async,
      output logic [5:0]                                                                  adb_l2c_9_dbus_w_rd_ptr_async,
      output logic [5:0]                                                                  adb_l2c_9_dbus_w_rd_ptr_sync
   );


   logic                [9:0]    axi5_arvalid  ;
   logic                [9:0]    axi5_arready  ;
   axi5_ar_data_bus_t   [9:0]    axi5_arrec    ;
   
   logic                [9:0]    axi5_awvalid  ;
   logic                [9:0]    axi5_awready  ;
   axi5_aw_data_bus_t   [9:0]    axi5_awrec    ;
   
   logic                [9:0]    axi5_rvalid   ;
   logic                [9:0]    axi5_rready   ;
   axi5_r_data_bus_t    [9:0]    axi5_rrec     ;
   
   logic                [9:0]    axi5_wvalid   ;
   logic                [9:0]    axi5_wready   ;
   axi5_w_data_bus_t    [9:0]    axi5_wrec     ;
   
   logic                [9:0]    axi5_bvalid   ;
   logic                [9:0]    axi5_bready   ;
   axi5_b_data_bus_t    [9:0]    axi5_brec     ;
   
   
   
   
   logic                      [9:0]    nsp_req_valid ;
   logic                      [9:0]    nsp_req_ready ;
   group_nsp_req_data_bus_t   [9:0]    nsp_req_rec   ;
   
   
   logic                      [9:0]    nsp_rsp_valid ;
   logic                      [9:0]    nsp_rsp_ready ;
   group_nsp_rsp_data_bus_t   [9:0]    nsp_rsp_rec   ;
   
   logic [31:0]                        in_expand_ports     ;
   logic [31:0]                        out_expand_ports    ;

   logic [63:0]                        l2g_a_in_perf_event_r0;
   logic [63:0]                        l2g_a_in_perf_event_r1;
   logic [63:0]                        l2g_a_in_perf_event_r2;
   
   assign in_expand_ports = 'b0;
   assign nsp_clk         = aclk;
   assign nsp_resetn      = aresetn;

   assign nsp0_req_valid      = nsp_req_valid[0]       ;
   assign nsp_req_ready[0]    = nsp0_req_ready         ;
   assign nsp0_req_opc        = nsp_req_rec[0].opc     ;
   assign nsp0_req_req_length = nsp_req_rec[0].length ;
   assign nsp0_req_req_addr   = nsp_req_rec[0].addr   ;
   assign nsp0_req_req_flowid = nsp_req_rec[0].flowid ;
   assign nsp0_req_req_seqid  = nsp_req_rec[0].seqid  ;
   assign nsp0_req_req_trid   = nsp_req_rec[0].trid   ;
   assign nsp0_req_req_excid  = nsp_req_rec[0].excid  ;
   assign nsp0_req_req_data   = nsp_req_rec[0].data   ;
   assign nsp0_req_req_be     = nsp_req_rec[0].be     ;
   assign nsp0_req_req_last   = nsp_req_rec[0].last   ;
   
   
   assign nsp1_req_valid      = nsp_req_valid[1]       ;
   assign nsp_req_ready[1]    = nsp1_req_ready         ;
   assign nsp1_req_opc        = nsp_req_rec[1].opc     ;
   assign nsp1_req_req_length = nsp_req_rec[1].length ;
   assign nsp1_req_req_addr   = nsp_req_rec[1].addr   ;
   assign nsp1_req_req_flowid = nsp_req_rec[1].flowid ;
   assign nsp1_req_req_seqid  = nsp_req_rec[1].seqid  ;
   assign nsp1_req_req_trid   = nsp_req_rec[1].trid   ;
   assign nsp1_req_req_excid  = nsp_req_rec[1].excid  ;
   assign nsp1_req_req_data   = nsp_req_rec[1].data   ;
   assign nsp1_req_req_be     = nsp_req_rec[1].be     ;
   assign nsp1_req_req_last   = nsp_req_rec[1].last   ;
   
   assign nsp2_req_valid      = nsp_req_valid[2]       ;
   assign nsp_req_ready[2]    = nsp2_req_ready         ;
   assign nsp2_req_opc        = nsp_req_rec[2].opc     ;
   assign nsp2_req_req_length = nsp_req_rec[2].length ;
   assign nsp2_req_req_addr   = nsp_req_rec[2].addr   ;
   assign nsp2_req_req_flowid = nsp_req_rec[2].flowid ;
   assign nsp2_req_req_seqid  = nsp_req_rec[2].seqid  ;
   assign nsp2_req_req_trid   = nsp_req_rec[2].trid   ;
   assign nsp2_req_req_excid  = nsp_req_rec[2].excid  ;
   assign nsp2_req_req_data   = nsp_req_rec[2].data   ;
   assign nsp2_req_req_be     = nsp_req_rec[2].be     ;
   assign nsp2_req_req_last   = nsp_req_rec[2].last   ;
   
   assign nsp3_req_valid      = nsp_req_valid[3]       ;
   assign nsp_req_ready[3]    = nsp3_req_ready         ;
   assign nsp3_req_opc        = nsp_req_rec[3].opc     ;
   assign nsp3_req_req_length = nsp_req_rec[3].length ;
   assign nsp3_req_req_addr   = nsp_req_rec[3].addr   ;
   assign nsp3_req_req_flowid = nsp_req_rec[3].flowid ;
   assign nsp3_req_req_seqid  = nsp_req_rec[3].seqid  ;
   assign nsp3_req_req_trid   = nsp_req_rec[3].trid   ;
   assign nsp3_req_req_excid  = nsp_req_rec[3].excid  ;
   assign nsp3_req_req_data   = nsp_req_rec[3].data   ;
   assign nsp3_req_req_be     = nsp_req_rec[3].be     ;
   assign nsp3_req_req_last   = nsp_req_rec[3].last   ;

   assign nsp4_req_valid      = nsp_req_valid[4]       ;
   assign nsp_req_ready[4]    = nsp4_req_ready         ;
   assign nsp4_req_opc        = nsp_req_rec[4].opc     ;
   assign nsp4_req_req_length = nsp_req_rec[4].length ;
   assign nsp4_req_req_addr   = nsp_req_rec[4].addr   ;
   assign nsp4_req_req_flowid = nsp_req_rec[4].flowid ;
   assign nsp4_req_req_seqid  = nsp_req_rec[4].seqid  ;
   assign nsp4_req_req_trid   = nsp_req_rec[4].trid   ;
   assign nsp4_req_req_excid  = nsp_req_rec[4].excid  ;
   assign nsp4_req_req_data   = nsp_req_rec[4].data   ;
   assign nsp4_req_req_be     = nsp_req_rec[4].be     ;
   assign nsp4_req_req_last   = nsp_req_rec[4].last   ;
   
   
   assign nsp5_req_valid      = nsp_req_valid[5]       ;
   assign nsp_req_ready[5]    = nsp5_req_ready         ;
   assign nsp5_req_opc        = nsp_req_rec[5].opc     ;
   assign nsp5_req_req_length = nsp_req_rec[5].length ;
   assign nsp5_req_req_addr   = nsp_req_rec[5].addr   ;
   assign nsp5_req_req_flowid = nsp_req_rec[5].flowid ;
   assign nsp5_req_req_seqid  = nsp_req_rec[5].seqid  ;
   assign nsp5_req_req_trid   = nsp_req_rec[5].trid   ;
   assign nsp5_req_req_excid  = nsp_req_rec[5].excid  ;
   assign nsp5_req_req_data   = nsp_req_rec[5].data   ;
   assign nsp5_req_req_be     = nsp_req_rec[5].be     ;
   assign nsp5_req_req_last   = nsp_req_rec[5].last   ;
   
   assign nsp6_req_valid      = nsp_req_valid[6]       ;
   assign nsp_req_ready[6]    = nsp6_req_ready         ;
   assign nsp6_req_opc        = nsp_req_rec[6].opc     ;
   assign nsp6_req_req_length = nsp_req_rec[6].length ;
   assign nsp6_req_req_addr   = nsp_req_rec[6].addr   ;
   assign nsp6_req_req_flowid = nsp_req_rec[6].flowid ;
   assign nsp6_req_req_seqid  = nsp_req_rec[6].seqid  ;
   assign nsp6_req_req_trid   = nsp_req_rec[6].trid   ;
   assign nsp6_req_req_excid  = nsp_req_rec[6].excid  ;
   assign nsp6_req_req_data   = nsp_req_rec[6].data   ;
   assign nsp6_req_req_be     = nsp_req_rec[6].be     ;
   assign nsp6_req_req_last   = nsp_req_rec[6].last   ;
   
   assign nsp7_req_valid      = nsp_req_valid[7]       ;
   assign nsp_req_ready[7]    = nsp7_req_ready         ;
   assign nsp7_req_opc        = nsp_req_rec[7].opc     ;
   assign nsp7_req_req_length = nsp_req_rec[7].length ;
   assign nsp7_req_req_addr   = nsp_req_rec[7].addr   ;
   assign nsp7_req_req_flowid = nsp_req_rec[7].flowid ;
   assign nsp7_req_req_seqid  = nsp_req_rec[7].seqid  ;
   assign nsp7_req_req_trid   = nsp_req_rec[7].trid   ;
   assign nsp7_req_req_excid  = nsp_req_rec[7].excid  ;
   assign nsp7_req_req_data   = nsp_req_rec[7].data   ;
   assign nsp7_req_req_be     = nsp_req_rec[7].be     ;
   assign nsp7_req_req_last   = nsp_req_rec[7].last   ;

   assign nsp8_req_valid      = nsp_req_valid[8]       ;
   assign nsp_req_ready[8]    = nsp8_req_ready         ;
   assign nsp8_req_opc        = nsp_req_rec[8].opc     ;
   assign nsp8_req_req_length = nsp_req_rec[8].length ;
   assign nsp8_req_req_addr   = nsp_req_rec[8].addr   ;
   assign nsp8_req_req_flowid = nsp_req_rec[8].flowid ;
   assign nsp8_req_req_seqid  = nsp_req_rec[8].seqid  ;
   assign nsp8_req_req_trid   = nsp_req_rec[8].trid   ;
   assign nsp8_req_req_excid  = nsp_req_rec[8].excid  ;
   assign nsp8_req_req_data   = nsp_req_rec[8].data   ;
   assign nsp8_req_req_be     = nsp_req_rec[8].be     ;
   assign nsp8_req_req_last   = nsp_req_rec[8].last   ;

   assign nsp9_req_valid      = nsp_req_valid[9]       ;
   assign nsp_req_ready[9]    = nsp9_req_ready         ;
   assign nsp9_req_opc        = nsp_req_rec[9].opc     ;
   assign nsp9_req_req_length = nsp_req_rec[9].length ;
   assign nsp9_req_req_addr   = nsp_req_rec[9].addr   ;
   assign nsp9_req_req_flowid = nsp_req_rec[9].flowid ;
   assign nsp9_req_req_seqid  = nsp_req_rec[9].seqid  ;
   assign nsp9_req_req_trid   = nsp_req_rec[9].trid   ;
   assign nsp9_req_req_excid  = nsp_req_rec[9].excid  ;
   assign nsp9_req_req_data   = nsp_req_rec[9].data   ;
   assign nsp9_req_req_be     = nsp_req_rec[9].be     ;
   assign nsp9_req_req_last   = nsp_req_rec[9].last   ;

   assign nsp_rsp_valid[0]       = nsp0_rsp_valid;
   assign nsp0_rsp_ready         = nsp_rsp_ready[0];
   assign nsp_rsp_rec[0].data    = nsp0_rsp_data;
   assign nsp_rsp_rec[0].errcode = nsp0_rsp_errcode;
   assign nsp_rsp_rec[0].status  = nsp0_rsp_status;
   assign nsp_rsp_rec[0].cont    = nsp0_rsp_cont;
   assign nsp_rsp_rec[0].last    = nsp0_rsp_last;
   assign nsp_rsp_rec[0].trid    = nsp0_rsp_trid;

   assign nsp_rsp_valid[1]       = nsp1_rsp_valid;
   assign nsp1_rsp_ready         = nsp_rsp_ready[1];
   assign nsp_rsp_rec[1].data    = nsp1_rsp_data;
   assign nsp_rsp_rec[1].errcode = nsp1_rsp_errcode;
   assign nsp_rsp_rec[1].status  = nsp1_rsp_status;
   assign nsp_rsp_rec[1].cont    = nsp1_rsp_cont;
   assign nsp_rsp_rec[1].last    = nsp1_rsp_last;
   assign nsp_rsp_rec[1].trid    = nsp1_rsp_trid;

   assign nsp_rsp_valid[2]       = nsp2_rsp_valid;
   assign nsp2_rsp_ready         = nsp_rsp_ready[2];
   assign nsp_rsp_rec[2].data    = nsp2_rsp_data;
   assign nsp_rsp_rec[2].errcode = nsp2_rsp_errcode;
   assign nsp_rsp_rec[2].status  = nsp2_rsp_status;
   assign nsp_rsp_rec[2].cont    = nsp2_rsp_cont;
   assign nsp_rsp_rec[2].last    = nsp2_rsp_last;
   assign nsp_rsp_rec[2].trid    = nsp2_rsp_trid;

   assign nsp_rsp_valid[3]       = nsp3_rsp_valid;
   assign nsp3_rsp_ready         = nsp_rsp_ready[3];
   assign nsp_rsp_rec[3].data    = nsp3_rsp_data;
   assign nsp_rsp_rec[3].errcode = nsp3_rsp_errcode;
   assign nsp_rsp_rec[3].status  = nsp3_rsp_status;
   assign nsp_rsp_rec[3].cont    = nsp3_rsp_cont;
   assign nsp_rsp_rec[3].last    = nsp3_rsp_last;
   assign nsp_rsp_rec[3].trid    = nsp3_rsp_trid;

   assign nsp_rsp_valid[4]       = nsp4_rsp_valid;
   assign nsp4_rsp_ready         = nsp_rsp_ready[4];
   assign nsp_rsp_rec[4].data    = nsp4_rsp_data;
   assign nsp_rsp_rec[4].errcode = nsp4_rsp_errcode;
   assign nsp_rsp_rec[4].status  = nsp4_rsp_status;
   assign nsp_rsp_rec[4].cont    = nsp4_rsp_cont;
   assign nsp_rsp_rec[4].last    = nsp4_rsp_last;
   assign nsp_rsp_rec[4].trid    = nsp4_rsp_trid;

   assign nsp_rsp_valid[5]       = nsp5_rsp_valid;
   assign nsp5_rsp_ready         = nsp_rsp_ready[5];
   assign nsp_rsp_rec[5].data    = nsp5_rsp_data;
   assign nsp_rsp_rec[5].errcode = nsp5_rsp_errcode;
   assign nsp_rsp_rec[5].status  = nsp5_rsp_status;
   assign nsp_rsp_rec[5].cont    = nsp5_rsp_cont;
   assign nsp_rsp_rec[5].last    = nsp5_rsp_last;
   assign nsp_rsp_rec[5].trid    = nsp5_rsp_trid;

   assign nsp_rsp_valid[6]       = nsp6_rsp_valid;
   assign nsp6_rsp_ready         = nsp_rsp_ready[6];
   assign nsp_rsp_rec[6].data    = nsp6_rsp_data;
   assign nsp_rsp_rec[6].errcode = nsp6_rsp_errcode;
   assign nsp_rsp_rec[6].status  = nsp6_rsp_status;
   assign nsp_rsp_rec[6].cont    = nsp6_rsp_cont;
   assign nsp_rsp_rec[6].last    = nsp6_rsp_last;
   assign nsp_rsp_rec[6].trid    = nsp6_rsp_trid;

   assign nsp_rsp_valid[7]       = nsp7_rsp_valid;
   assign nsp7_rsp_ready         = nsp_rsp_ready[7];
   assign nsp_rsp_rec[7].data    = nsp7_rsp_data;
   assign nsp_rsp_rec[7].errcode = nsp7_rsp_errcode;
   assign nsp_rsp_rec[7].status  = nsp7_rsp_status;
   assign nsp_rsp_rec[7].cont    = nsp7_rsp_cont;
   assign nsp_rsp_rec[7].last    = nsp7_rsp_last;
   assign nsp_rsp_rec[7].trid    = nsp7_rsp_trid;

   assign nsp_rsp_valid[8]       = nsp8_rsp_valid;
   assign nsp8_rsp_ready         = nsp_rsp_ready[8];
   assign nsp_rsp_rec[8].data    = nsp8_rsp_data;
   assign nsp_rsp_rec[8].errcode = nsp8_rsp_errcode;
   assign nsp_rsp_rec[8].status  = nsp8_rsp_status;
   assign nsp_rsp_rec[8].cont    = nsp8_rsp_cont;
   assign nsp_rsp_rec[8].last    = nsp8_rsp_last;
   assign nsp_rsp_rec[8].trid    = nsp8_rsp_trid;

   assign nsp_rsp_valid[9]       = nsp9_rsp_valid;
   assign nsp9_rsp_ready         = nsp_rsp_ready[9];
   assign nsp_rsp_rec[9].data    = nsp9_rsp_data;
   assign nsp_rsp_rec[9].errcode = nsp9_rsp_errcode;
   assign nsp_rsp_rec[9].status  = nsp9_rsp_status;
   assign nsp_rsp_rec[9].cont    = nsp9_rsp_cont;
   assign nsp_rsp_rec[9].last    = nsp9_rsp_last;
   assign nsp_rsp_rec[9].trid    = nsp9_rsp_trid;


   socif_regbank_w_data_bus_t socif_rec;
   assign socif_rec.addr  = socif_addr;
   assign socif_rec.wdata = socif_wdata;
   assign socif_rec.wmask = socif_wmask;
   assign socif_rec.rdnwr = socif_rdnwr;

   
   always_ff@(posedge aclk or negedge aresetn) begin
      if (!aresetn) begin
         l2g_a_in_perf_event_r0 <= '0;
         l2g_a_in_perf_event_r1 <= '0;
         l2g_a_in_perf_event_r2 <= '0;
         l2g_a_out_perf_event   <= '0;
      end
      else begin
         l2g_a_in_perf_event_r0 <= l2g_a_in_perf_event;
         l2g_a_in_perf_event_r1 <= l2g_a_in_perf_event_r0;
         l2g_a_in_perf_event_r2 <= l2g_a_in_perf_event_r1;
         l2g_a_out_perf_event   <= l2g_a_in_perf_event_r2;
      end
   end
   assign l2g_clk = aclk;
   assign l2g_resetn = aresetn;






   gc_l2_bank_group
   i_gc_l2_bank_group
   (
       .clk             ( aclk          )
      ,.resetn          ( aresetn       )
      
      ,.l2g_number_id   ( l2g_number_id ) 
      ,.l2g_perf_event  ( l2g_perf_event)

      ,.socif_wakeup    (socif_wakeup   ) 
      ,.socif_valid     (socif_valid    )
      ,.socif_rec       (socif_rec      )
      
      ,.socif_rvalid    (socif_rvalid   )
      ,.socif_rdata     (socif_rdata    )
      
      ,.axi5_arvalid    ( axi5_arvalid  ) 
      ,.axi5_arready    ( axi5_arready  ) 
      ,.axi5_arrec      ( axi5_arrec    ) 
      
      ,.axi5_awvalid    ( axi5_awvalid  ) 
      ,.axi5_awready    ( axi5_awready  ) 
      ,.axi5_awrec      ( axi5_awrec    ) 
      
      ,.axi5_rvalid     ( axi5_rvalid   ) 
      ,.axi5_rready     ( axi5_rready   ) 
      ,.axi5_rrec       ( axi5_rrec     ) 
      
      ,.axi5_wvalid     ( axi5_wvalid   ) 
      ,.axi5_wready     ( axi5_wready   ) 
      ,.axi5_wrec       ( axi5_wrec     ) 
      
      ,.axi5_bvalid     ( axi5_bvalid   ) 
      ,.axi5_bready     ( axi5_bready   ) 
      ,.axi5_brec       ( axi5_brec     ) 
      
      ,.nsp_req_valid   ( nsp_req_valid ) 
      ,.nsp_req_ready   ( nsp_req_ready ) 
      ,.nsp_req_rec     ( nsp_req_rec   ) 
      
      
      ,.nsp_rsp_valid   ( nsp_rsp_valid ) 
      ,.nsp_rsp_ready   ( nsp_rsp_ready ) 
      ,.nsp_rsp_rec     ( nsp_rsp_rec   ) 
   
   
      ,.tst_gclkenable  (tst_gclkenable)
      ,.tst_rst_bypass  (tst_rst_bypass)
   
   );


l2c_cross_bus_wrap #(
    .AXI5_ADDR_WIDTH    (gc_l2_bank_pkg::L2_AXI_ADDR_WIDTH  ),
    .AXI5_DATA_WIDTH    (gc_l2_bank_pkg::L2_AXI_BUS_WIDTH   ),
    .AXI5_ID_WIDTH      (gc_l2_bank_pkg::L2_AXI_ID_WIDTH    ),
    .AXI5_USER_WIDTH    (gc_l2_bank_pkg::L2_AXI_USER_WIDTH  ),
    .AXI5_LEN_WIDTH     (gc_l2_bank_pkg::L2_AXI_LEN_WIDTH   ) 
)
i_l2c_cross_bus_wrap (
    .dft_test_mode              (dft_test_mode              ),  // I

    .aclk                       (aclk                       ),  // I
    .aresetn                    (aresetn                    ),  // I

    .in_expand_ports            (in_expand_ports            ),  // I
    .out_expand_ports           (out_expand_ports           ),  // O
    .pclk                       (pclk                       ),  // I
    .presetn                    (presetn                    ),  // I
   
    //.ref_clk                    (ref_clk                        ),
    //.TV_VBG                     (TV_VBG                         ),
    // bank 0
    .l2c_0_dbus_awvalid         (axi5_awvalid     [0]           ),  // O
    .l2c_0_dbus_awready         (axi5_awready     [0]           ),  // I
    .l2c_0_dbus_awaddr          (axi5_awrec       [0].addr      ),  // O
    .l2c_0_dbus_awatop          (axi5_awrec       [0].atop      ),  // O
    .l2c_0_dbus_awburst         (axi5_awrec       [0].burst     ),  // O
    .l2c_0_dbus_awcache         (axi5_awrec       [0].cache     ),  // O
    .l2c_0_dbus_awid            (axi5_awrec       [0].id        ),  // O
    .l2c_0_dbus_awlen           (axi5_awrec       [0].len       ),  // O
    .l2c_0_dbus_awqos           (axi5_awrec       [0].qos       ),  // O
    .l2c_0_dbus_awsize          (axi5_awrec       [0].size      ),  // O
    .l2c_0_dbus_awuser          (axi5_awrec       [0].user      ),  // O
    .l2c_0_dbus_awlock          (                               ),  // O
    .l2c_0_dbus_awprot          (                               ),  // O

    .l2c_0_dbus_wvalid          (axi5_wvalid      [0]           ),  // O
    .l2c_0_dbus_wready          (axi5_wready      [0]           ),  // I
    .l2c_0_dbus_wdata           (axi5_wrec        [0].data      ),  // O
    .l2c_0_dbus_wlast           (axi5_wrec        [0].last      ),  // O
    .l2c_0_dbus_wstrb           (axi5_wrec        [0].strb      ),  // O
    .l2c_0_dbus_wuser           (                               ),  // O

    .l2c_0_dbus_bvalid          (axi5_bvalid      [0]           ),  // I
    .l2c_0_dbus_bready          (axi5_bready      [0]           ),  // O
    .l2c_0_dbus_bid             (axi5_brec        [0].id        ),  // I
    .l2c_0_dbus_bresp           (axi5_brec        [0].resp      ),  // I
    .l2c_0_dbus_buser           ('0                             ),  // I

    .l2c_0_dbus_arvalid         (axi5_arvalid     [0]           ),  // O
    .l2c_0_dbus_arready         (axi5_arready     [0]           ),  // I
    .l2c_0_dbus_araddr          (axi5_arrec       [0].addr      ),  // O
    .l2c_0_dbus_arburst         (axi5_arrec       [0].burst     ),  // O
    .l2c_0_dbus_arcache         (axi5_arrec       [0].cache     ),  // O
    .l2c_0_dbus_arid            (axi5_arrec       [0].id        ),  // O
    .l2c_0_dbus_arlen           (axi5_arrec       [0].len       ),  // O
    .l2c_0_dbus_arqos           (axi5_arrec       [0].qos       ),  // O
    .l2c_0_dbus_arsize          (axi5_arrec       [0].size      ),  // O
    .l2c_0_dbus_aruser          (axi5_arrec       [0].user      ),  // O
    .l2c_0_dbus_arlock          (                               ),  // O
    .l2c_0_dbus_arprot          (                               ),  // O

    .l2c_0_dbus_rvalid          (axi5_rvalid      [0]           ),  // I
    .l2c_0_dbus_rready          (axi5_rready      [0]           ),  // O
    .l2c_0_dbus_rdata           (axi5_rrec        [0].data      ),  // I
    .l2c_0_dbus_rid             (axi5_rrec        [0].id        ),  // I
    .l2c_0_dbus_rlast           (axi5_rrec        [0].last      ),  // I
    .l2c_0_dbus_rresp           (axi5_rrec        [0].resp      ),  // I
    .l2c_0_dbus_ruser           ('0                             ),  // I

    // bank 1
    .l2c_1_dbus_awvalid         (axi5_awvalid     [1]           ),  // O
    .l2c_1_dbus_awready         (axi5_awready     [1]           ),  // I
    .l2c_1_dbus_awaddr          (axi5_awrec       [1].addr      ),  // O
    .l2c_1_dbus_awatop          (axi5_awrec       [1].atop      ),  // O
    .l2c_1_dbus_awburst         (axi5_awrec       [1].burst     ),  // O
    .l2c_1_dbus_awcache         (axi5_awrec       [1].cache     ),  // O
    .l2c_1_dbus_awid            (axi5_awrec       [1].id        ),  // O
    .l2c_1_dbus_awlen           (axi5_awrec       [1].len       ),  // O
    .l2c_1_dbus_awqos           (axi5_awrec       [1].qos       ),  // O
    .l2c_1_dbus_awsize          (axi5_awrec       [1].size      ),  // O
    .l2c_1_dbus_awuser          (axi5_awrec       [1].user      ),  // O
    .l2c_1_dbus_awlock          (                               ),  // O
    .l2c_1_dbus_awprot          (                               ),  // O

    .l2c_1_dbus_wvalid          (axi5_wvalid      [1]           ),  // O
    .l2c_1_dbus_wready          (axi5_wready      [1]           ),  // I
    .l2c_1_dbus_wdata           (axi5_wrec        [1].data      ),  // O
    .l2c_1_dbus_wlast           (axi5_wrec        [1].last      ),  // O
    .l2c_1_dbus_wstrb           (axi5_wrec        [1].strb      ),  // O
    .l2c_1_dbus_wuser           (                               ),  // O

    .l2c_1_dbus_bvalid          (axi5_bvalid      [1]           ),  // I
    .l2c_1_dbus_bready          (axi5_bready      [1]           ),  // O
    .l2c_1_dbus_bid             (axi5_brec        [1].id        ),  // I
    .l2c_1_dbus_bresp           (axi5_brec        [1].resp      ),  // I
    .l2c_1_dbus_buser           ('0                             ),  // I

    .l2c_1_dbus_arvalid         (axi5_arvalid     [1]           ),  // O
    .l2c_1_dbus_arready         (axi5_arready     [1]           ),  // I
    .l2c_1_dbus_araddr          (axi5_arrec       [1].addr      ),  // O
    .l2c_1_dbus_arburst         (axi5_arrec       [1].burst     ),  // O
    .l2c_1_dbus_arcache         (axi5_arrec       [1].cache     ),  // O
    .l2c_1_dbus_arid            (axi5_arrec       [1].id        ),  // O
    .l2c_1_dbus_arlen           (axi5_arrec       [1].len       ),  // O
    .l2c_1_dbus_arqos           (axi5_arrec       [1].qos       ),  // O
    .l2c_1_dbus_arsize          (axi5_arrec       [1].size      ),  // O
    .l2c_1_dbus_aruser          (axi5_arrec       [1].user      ),  // O
    .l2c_1_dbus_arlock          (                               ),  // O
    .l2c_1_dbus_arprot          (                               ),  // O

    .l2c_1_dbus_rvalid          (axi5_rvalid      [1]           ),  // I
    .l2c_1_dbus_rready          (axi5_rready      [1]           ),  // O
    .l2c_1_dbus_rdata           (axi5_rrec        [1].data      ),  // I
    .l2c_1_dbus_rid             (axi5_rrec        [1].id        ),  // I
    .l2c_1_dbus_rlast           (axi5_rrec        [1].last      ),  // I
    .l2c_1_dbus_rresp           (axi5_rrec        [1].resp      ),  // I
    .l2c_1_dbus_ruser           ('0                             ),  // I

    // bank 2
    .l2c_2_dbus_awvalid         (axi5_awvalid     [2]           ),  // O
    .l2c_2_dbus_awready         (axi5_awready     [2]           ),  // I
    .l2c_2_dbus_awaddr          (axi5_awrec       [2].addr      ),  // O
    .l2c_2_dbus_awatop          (axi5_awrec       [2].atop      ),  // O
    .l2c_2_dbus_awburst         (axi5_awrec       [2].burst     ),  // O
    .l2c_2_dbus_awcache         (axi5_awrec       [2].cache     ),  // O
    .l2c_2_dbus_awid            (axi5_awrec       [2].id        ),  // O
    .l2c_2_dbus_awlen           (axi5_awrec       [2].len       ),  // O
    .l2c_2_dbus_awqos           (axi5_awrec       [2].qos       ),  // O
    .l2c_2_dbus_awsize          (axi5_awrec       [2].size      ),  // O
    .l2c_2_dbus_awuser          (axi5_awrec       [2].user      ),  // O
    .l2c_2_dbus_awlock          (                               ),  // O
    .l2c_2_dbus_awprot          (                               ),  // O

    .l2c_2_dbus_wvalid          (axi5_wvalid      [2]           ),  // O
    .l2c_2_dbus_wready          (axi5_wready      [2]           ),  // I
    .l2c_2_dbus_wdata           (axi5_wrec        [2].data      ),  // O
    .l2c_2_dbus_wlast           (axi5_wrec        [2].last      ),  // O
    .l2c_2_dbus_wstrb           (axi5_wrec        [2].strb      ),  // O
    .l2c_2_dbus_wuser           (                               ),  // O

    .l2c_2_dbus_bvalid          (axi5_bvalid      [2]           ),  // I
    .l2c_2_dbus_bready          (axi5_bready      [2]           ),  // O
    .l2c_2_dbus_bid             (axi5_brec        [2].id        ),  // I
    .l2c_2_dbus_bresp           (axi5_brec        [2].resp      ),  // I
    .l2c_2_dbus_buser           ('0                             ),  // I

    .l2c_2_dbus_arvalid         (axi5_arvalid     [2]           ),  // O
    .l2c_2_dbus_arready         (axi5_arready     [2]           ),  // I
    .l2c_2_dbus_araddr          (axi5_arrec       [2].addr      ),  // O
    .l2c_2_dbus_arburst         (axi5_arrec       [2].burst     ),  // O
    .l2c_2_dbus_arcache         (axi5_arrec       [2].cache     ),  // O
    .l2c_2_dbus_arid            (axi5_arrec       [2].id        ),  // O
    .l2c_2_dbus_arlen           (axi5_arrec       [2].len       ),  // O
    .l2c_2_dbus_arqos           (axi5_arrec       [2].qos       ),  // O
    .l2c_2_dbus_arsize          (axi5_arrec       [2].size      ),  // O
    .l2c_2_dbus_aruser          (axi5_arrec       [2].user      ),  // O
    .l2c_2_dbus_arlock          (                               ),  // O
    .l2c_2_dbus_arprot          (                               ),  // O

    .l2c_2_dbus_rvalid          (axi5_rvalid      [2]           ),  // I
    .l2c_2_dbus_rready          (axi5_rready      [2]           ),  // O
    .l2c_2_dbus_rdata           (axi5_rrec        [2].data      ),  // I
    .l2c_2_dbus_rid             (axi5_rrec        [2].id        ),  // I
    .l2c_2_dbus_rlast           (axi5_rrec        [2].last      ),  // I
    .l2c_2_dbus_rresp           (axi5_rrec        [2].resp      ),  // I
    .l2c_2_dbus_ruser           ('0                             ),  // I

    // bank 3
    .l2c_3_dbus_awvalid         (axi5_awvalid     [3]           ),  // O
    .l2c_3_dbus_awready         (axi5_awready     [3]           ),  // I
    .l2c_3_dbus_awaddr          (axi5_awrec       [3].addr      ),  // O
    .l2c_3_dbus_awatop          (axi5_awrec       [3].atop      ),  // O
    .l2c_3_dbus_awburst         (axi5_awrec       [3].burst     ),  // O
    .l2c_3_dbus_awcache         (axi5_awrec       [3].cache     ),  // O
    .l2c_3_dbus_awid            (axi5_awrec       [3].id        ),  // O
    .l2c_3_dbus_awlen           (axi5_awrec       [3].len       ),  // O
    .l2c_3_dbus_awqos           (axi5_awrec       [3].qos       ),  // O
    .l2c_3_dbus_awsize          (axi5_awrec       [3].size      ),  // O
    .l2c_3_dbus_awuser          (axi5_awrec       [3].user      ),  // O
    .l2c_3_dbus_awlock          (                               ),  // O
    .l2c_3_dbus_awprot          (                               ),  // O

    .l2c_3_dbus_wvalid          (axi5_wvalid      [3]           ),  // O
    .l2c_3_dbus_wready          (axi5_wready      [3]           ),  // I
    .l2c_3_dbus_wdata           (axi5_wrec        [3].data      ),  // O
    .l2c_3_dbus_wlast           (axi5_wrec        [3].last      ),  // O
    .l2c_3_dbus_wstrb           (axi5_wrec        [3].strb      ),  // O
    .l2c_3_dbus_wuser           (                               ),  // O

    .l2c_3_dbus_bvalid          (axi5_bvalid      [3]           ),  // I
    .l2c_3_dbus_bready          (axi5_bready      [3]           ),  // O
    .l2c_3_dbus_bid             (axi5_brec        [3].id        ),  // I
    .l2c_3_dbus_bresp           (axi5_brec        [3].resp      ),  // I
    .l2c_3_dbus_buser           ('0                             ),  // I

    .l2c_3_dbus_arvalid         (axi5_arvalid     [3]           ),  // O
    .l2c_3_dbus_arready         (axi5_arready     [3]           ),  // I
    .l2c_3_dbus_araddr          (axi5_arrec       [3].addr      ),  // O
    .l2c_3_dbus_arburst         (axi5_arrec       [3].burst     ),  // O
    .l2c_3_dbus_arcache         (axi5_arrec       [3].cache     ),  // O
    .l2c_3_dbus_arid            (axi5_arrec       [3].id        ),  // O
    .l2c_3_dbus_arlen           (axi5_arrec       [3].len       ),  // O
    .l2c_3_dbus_arqos           (axi5_arrec       [3].qos       ),  // O
    .l2c_3_dbus_arsize          (axi5_arrec       [3].size      ),  // O
    .l2c_3_dbus_aruser          (axi5_arrec       [3].user      ),  // O
    .l2c_3_dbus_arlock          (                               ),  // O
    .l2c_3_dbus_arprot          (                               ),  // O

    .l2c_3_dbus_rvalid          (axi5_rvalid      [3]           ),  // I
    .l2c_3_dbus_rready          (axi5_rready      [3]           ),  // O
    .l2c_3_dbus_rdata           (axi5_rrec        [3].data      ),  // I
    .l2c_3_dbus_rid             (axi5_rrec        [3].id        ),  // I
    .l2c_3_dbus_rlast           (axi5_rrec        [3].last      ),  // I
    .l2c_3_dbus_rresp           (axi5_rrec        [3].resp      ),  // I
    .l2c_3_dbus_ruser           ('0                             ),  // I

    // bank 4
    .l2c_4_dbus_awvalid         (axi5_awvalid     [4]           ),  // O
    .l2c_4_dbus_awready         (axi5_awready     [4]           ),  // I
    .l2c_4_dbus_awaddr          (axi5_awrec       [4].addr      ),  // O
    .l2c_4_dbus_awatop          (axi5_awrec       [4].atop      ),  // O
    .l2c_4_dbus_awburst         (axi5_awrec       [4].burst     ),  // O
    .l2c_4_dbus_awcache         (axi5_awrec       [4].cache     ),  // O
    .l2c_4_dbus_awid            (axi5_awrec       [4].id        ),  // O
    .l2c_4_dbus_awlen           (axi5_awrec       [4].len       ),  // O
    .l2c_4_dbus_awqos           (axi5_awrec       [4].qos       ),  // O
    .l2c_4_dbus_awsize          (axi5_awrec       [4].size      ),  // O
    .l2c_4_dbus_awuser          (axi5_awrec       [4].user      ),  // O
    .l2c_4_dbus_awlock          (                               ),  // O
    .l2c_4_dbus_awprot          (                               ),  // O

    .l2c_4_dbus_wvalid          (axi5_wvalid      [4]           ),  // O
    .l2c_4_dbus_wready          (axi5_wready      [4]           ),  // I
    .l2c_4_dbus_wdata           (axi5_wrec        [4].data      ),  // O
    .l2c_4_dbus_wlast           (axi5_wrec        [4].last      ),  // O
    .l2c_4_dbus_wstrb           (axi5_wrec        [4].strb      ),  // O
    .l2c_4_dbus_wuser           (                               ),  // O

    .l2c_4_dbus_bvalid          (axi5_bvalid      [4]           ),  // I
    .l2c_4_dbus_bready          (axi5_bready      [4]           ),  // O
    .l2c_4_dbus_bid             (axi5_brec        [4].id        ),  // I
    .l2c_4_dbus_bresp           (axi5_brec        [4].resp      ),  // I
    .l2c_4_dbus_buser           ('0                             ),  // I

    .l2c_4_dbus_arvalid         (axi5_arvalid     [4]           ),  // O
    .l2c_4_dbus_arready         (axi5_arready     [4]           ),  // I
    .l2c_4_dbus_araddr          (axi5_arrec       [4].addr      ),  // O
    .l2c_4_dbus_arburst         (axi5_arrec       [4].burst     ),  // O
    .l2c_4_dbus_arcache         (axi5_arrec       [4].cache     ),  // O
    .l2c_4_dbus_arid            (axi5_arrec       [4].id        ),  // O
    .l2c_4_dbus_arlen           (axi5_arrec       [4].len       ),  // O
    .l2c_4_dbus_arqos           (axi5_arrec       [4].qos       ),  // O
    .l2c_4_dbus_arsize          (axi5_arrec       [4].size      ),  // O
    .l2c_4_dbus_aruser          (axi5_arrec       [4].user      ),  // O
    .l2c_4_dbus_arlock          (                               ),  // O
    .l2c_4_dbus_arprot          (                               ),  // O

    .l2c_4_dbus_rvalid          (axi5_rvalid      [4]           ),  // I
    .l2c_4_dbus_rready          (axi5_rready      [4]           ),  // O
    .l2c_4_dbus_rdata           (axi5_rrec        [4].data      ),  // I
    .l2c_4_dbus_rid             (axi5_rrec        [4].id        ),  // I
    .l2c_4_dbus_rlast           (axi5_rrec        [4].last      ),  // I
    .l2c_4_dbus_rresp           (axi5_rrec        [4].resp      ),  // I
    .l2c_4_dbus_ruser           ('0                             ),  // I

    // bank 5
    .l2c_5_dbus_awvalid         (axi5_awvalid     [5]           ),  // O
    .l2c_5_dbus_awready         (axi5_awready     [5]           ),  // I
    .l2c_5_dbus_awaddr          (axi5_awrec       [5].addr      ),  // O
    .l2c_5_dbus_awatop          (axi5_awrec       [5].atop      ),  // O
    .l2c_5_dbus_awburst         (axi5_awrec       [5].burst     ),  // O
    .l2c_5_dbus_awcache         (axi5_awrec       [5].cache     ),  // O
    .l2c_5_dbus_awid            (axi5_awrec       [5].id        ),  // O
    .l2c_5_dbus_awlen           (axi5_awrec       [5].len       ),  // O
    .l2c_5_dbus_awqos           (axi5_awrec       [5].qos       ),  // O
    .l2c_5_dbus_awsize          (axi5_awrec       [5].size      ),  // O
    .l2c_5_dbus_awuser          (axi5_awrec       [5].user      ),  // O
    .l2c_5_dbus_awlock          (                               ),  // O
    .l2c_5_dbus_awprot          (                               ),  // O

    .l2c_5_dbus_wvalid          (axi5_wvalid      [5]           ),  // O
    .l2c_5_dbus_wready          (axi5_wready      [5]           ),  // I
    .l2c_5_dbus_wdata           (axi5_wrec        [5].data      ),  // O
    .l2c_5_dbus_wlast           (axi5_wrec        [5].last      ),  // O
    .l2c_5_dbus_wstrb           (axi5_wrec        [5].strb      ),  // O
    .l2c_5_dbus_wuser           (                               ),  // O

    .l2c_5_dbus_bvalid          (axi5_bvalid      [5]           ),  // I
    .l2c_5_dbus_bready          (axi5_bready      [5]           ),  // O
    .l2c_5_dbus_bid             (axi5_brec        [5].id        ),  // I
    .l2c_5_dbus_bresp           (axi5_brec        [5].resp      ),  // I
    .l2c_5_dbus_buser           ('0                             ),  // I

    .l2c_5_dbus_arvalid         (axi5_arvalid     [5]           ),  // O
    .l2c_5_dbus_arready         (axi5_arready     [5]           ),  // I
    .l2c_5_dbus_araddr          (axi5_arrec       [5].addr      ),  // O
    .l2c_5_dbus_arburst         (axi5_arrec       [5].burst     ),  // O
    .l2c_5_dbus_arcache         (axi5_arrec       [5].cache     ),  // O
    .l2c_5_dbus_arid            (axi5_arrec       [5].id        ),  // O
    .l2c_5_dbus_arlen           (axi5_arrec       [5].len       ),  // O
    .l2c_5_dbus_arqos           (axi5_arrec       [5].qos       ),  // O
    .l2c_5_dbus_arsize          (axi5_arrec       [5].size      ),  // O
    .l2c_5_dbus_aruser          (axi5_arrec       [5].user      ),  // O
    .l2c_5_dbus_arlock          (                               ),  // O
    .l2c_5_dbus_arprot          (                               ),  // O

    .l2c_5_dbus_rvalid          (axi5_rvalid      [5]           ),  // I
    .l2c_5_dbus_rready          (axi5_rready      [5]           ),  // O
    .l2c_5_dbus_rdata           (axi5_rrec        [5].data      ),  // I
    .l2c_5_dbus_rid             (axi5_rrec        [5].id        ),  // I
    .l2c_5_dbus_rlast           (axi5_rrec        [5].last      ),  // I
    .l2c_5_dbus_rresp           (axi5_rrec        [5].resp      ),  // I
    .l2c_5_dbus_ruser           ('0                             ),  // I

    // bank 6
    .l2c_6_dbus_awvalid         (axi5_awvalid     [6]           ),  // O
    .l2c_6_dbus_awready         (axi5_awready     [6]           ),  // I
    .l2c_6_dbus_awaddr          (axi5_awrec       [6].addr      ),  // O
    .l2c_6_dbus_awatop          (axi5_awrec       [6].atop      ),  // O
    .l2c_6_dbus_awburst         (axi5_awrec       [6].burst     ),  // O
    .l2c_6_dbus_awcache         (axi5_awrec       [6].cache     ),  // O
    .l2c_6_dbus_awid            (axi5_awrec       [6].id        ),  // O
    .l2c_6_dbus_awlen           (axi5_awrec       [6].len       ),  // O
    .l2c_6_dbus_awqos           (axi5_awrec       [6].qos       ),  // O
    .l2c_6_dbus_awsize          (axi5_awrec       [6].size      ),  // O
    .l2c_6_dbus_awuser          (axi5_awrec       [6].user      ),  // O
    .l2c_6_dbus_awlock          (                               ),  // O
    .l2c_6_dbus_awprot          (                               ),  // O

    .l2c_6_dbus_wvalid          (axi5_wvalid      [6]           ),  // O
    .l2c_6_dbus_wready          (axi5_wready      [6]           ),  // I
    .l2c_6_dbus_wdata           (axi5_wrec        [6].data      ),  // O
    .l2c_6_dbus_wlast           (axi5_wrec        [6].last      ),  // O
    .l2c_6_dbus_wstrb           (axi5_wrec        [6].strb      ),  // O
    .l2c_6_dbus_wuser           (                               ),  // O

    .l2c_6_dbus_bvalid          (axi5_bvalid      [6]           ),  // I
    .l2c_6_dbus_bready          (axi5_bready      [6]           ),  // O
    .l2c_6_dbus_bid             (axi5_brec        [6].id        ),  // I
    .l2c_6_dbus_bresp           (axi5_brec        [6].resp      ),  // I
    .l2c_6_dbus_buser           ('0                             ),  // I

    .l2c_6_dbus_arvalid         (axi5_arvalid     [6]           ),  // O
    .l2c_6_dbus_arready         (axi5_arready     [6]           ),  // I
    .l2c_6_dbus_araddr          (axi5_arrec       [6].addr      ),  // O
    .l2c_6_dbus_arburst         (axi5_arrec       [6].burst     ),  // O
    .l2c_6_dbus_arcache         (axi5_arrec       [6].cache     ),  // O
    .l2c_6_dbus_arid            (axi5_arrec       [6].id        ),  // O
    .l2c_6_dbus_arlen           (axi5_arrec       [6].len       ),  // O
    .l2c_6_dbus_arqos           (axi5_arrec       [6].qos       ),  // O
    .l2c_6_dbus_arsize          (axi5_arrec       [6].size      ),  // O
    .l2c_6_dbus_aruser          (axi5_arrec       [6].user      ),  // O
    .l2c_6_dbus_arlock          (                               ),  // O
    .l2c_6_dbus_arprot          (                               ),  // O

    .l2c_6_dbus_rvalid          (axi5_rvalid      [6]           ),  // I
    .l2c_6_dbus_rready          (axi5_rready      [6]           ),  // O
    .l2c_6_dbus_rdata           (axi5_rrec        [6].data      ),  // I
    .l2c_6_dbus_rid             (axi5_rrec        [6].id        ),  // I
    .l2c_6_dbus_rlast           (axi5_rrec        [6].last      ),  // I
    .l2c_6_dbus_rresp           (axi5_rrec        [6].resp      ),  // I
    .l2c_6_dbus_ruser           ('0                             ),  // I

    // bank 7
    .l2c_7_dbus_awvalid         (axi5_awvalid     [7]           ),  // O
    .l2c_7_dbus_awready         (axi5_awready     [7]           ),  // I
    .l2c_7_dbus_awaddr          (axi5_awrec       [7].addr      ),  // O
    .l2c_7_dbus_awatop          (axi5_awrec       [7].atop      ),  // O
    .l2c_7_dbus_awburst         (axi5_awrec       [7].burst     ),  // O
    .l2c_7_dbus_awcache         (axi5_awrec       [7].cache     ),  // O
    .l2c_7_dbus_awid            (axi5_awrec       [7].id        ),  // O
    .l2c_7_dbus_awlen           (axi5_awrec       [7].len       ),  // O
    .l2c_7_dbus_awqos           (axi5_awrec       [7].qos       ),  // O
    .l2c_7_dbus_awsize          (axi5_awrec       [7].size      ),  // O
    .l2c_7_dbus_awuser          (axi5_awrec       [7].user      ),  // O
    .l2c_7_dbus_awlock          (                               ),  // O
    .l2c_7_dbus_awprot          (                               ),  // O

    .l2c_7_dbus_wvalid          (axi5_wvalid      [7]           ),  // O
    .l2c_7_dbus_wready          (axi5_wready      [7]           ),  // I
    .l2c_7_dbus_wdata           (axi5_wrec        [7].data      ),  // O
    .l2c_7_dbus_wlast           (axi5_wrec        [7].last      ),  // O
    .l2c_7_dbus_wstrb           (axi5_wrec        [7].strb      ),  // O
    .l2c_7_dbus_wuser           (                               ),  // O

    .l2c_7_dbus_bvalid          (axi5_bvalid      [7]           ),  // I
    .l2c_7_dbus_bready          (axi5_bready      [7]           ),  // O
    .l2c_7_dbus_bid             (axi5_brec        [7].id        ),  // I
    .l2c_7_dbus_bresp           (axi5_brec        [7].resp      ),  // I
    .l2c_7_dbus_buser           ('0                             ),  // I

    .l2c_7_dbus_arvalid         (axi5_arvalid     [7]           ),  // O
    .l2c_7_dbus_arready         (axi5_arready     [7]           ),  // I
    .l2c_7_dbus_araddr          (axi5_arrec       [7].addr      ),  // O
    .l2c_7_dbus_arburst         (axi5_arrec       [7].burst     ),  // O
    .l2c_7_dbus_arcache         (axi5_arrec       [7].cache     ),  // O
    .l2c_7_dbus_arid            (axi5_arrec       [7].id        ),  // O
    .l2c_7_dbus_arlen           (axi5_arrec       [7].len       ),  // O
    .l2c_7_dbus_arqos           (axi5_arrec       [7].qos       ),  // O
    .l2c_7_dbus_arsize          (axi5_arrec       [7].size      ),  // O
    .l2c_7_dbus_aruser          (axi5_arrec       [7].user      ),  // O
    .l2c_7_dbus_arlock          (                               ),  // O
    .l2c_7_dbus_arprot          (                               ),  // O

    .l2c_7_dbus_rvalid          (axi5_rvalid      [7]           ),  // I
    .l2c_7_dbus_rready          (axi5_rready      [7]           ),  // O
    .l2c_7_dbus_rdata           (axi5_rrec        [7].data      ),  // I
    .l2c_7_dbus_rid             (axi5_rrec        [7].id        ),  // I
    .l2c_7_dbus_rlast           (axi5_rrec        [7].last      ),  // I
    .l2c_7_dbus_rresp           (axi5_rrec        [7].resp      ),  // I
    .l2c_7_dbus_ruser           ('0                             ),  // I

    // bank 8
    .l2c_8_dbus_awvalid         (axi5_awvalid     [8]           ),  // O
    .l2c_8_dbus_awready         (axi5_awready     [8]           ),  // I
    .l2c_8_dbus_awaddr          (axi5_awrec       [8].addr      ),  // O
    .l2c_8_dbus_awatop          (axi5_awrec       [8].atop      ),  // O
    .l2c_8_dbus_awburst         (axi5_awrec       [8].burst     ),  // O
    .l2c_8_dbus_awcache         (axi5_awrec       [8].cache     ),  // O
    .l2c_8_dbus_awid            (axi5_awrec       [8].id        ),  // O
    .l2c_8_dbus_awlen           (axi5_awrec       [8].len       ),  // O
    .l2c_8_dbus_awqos           (axi5_awrec       [8].qos       ),  // O
    .l2c_8_dbus_awsize          (axi5_awrec       [8].size      ),  // O
    .l2c_8_dbus_awuser          (axi5_awrec       [8].user      ),  // O
    .l2c_8_dbus_awlock          (                               ),  // O
    .l2c_8_dbus_awprot          (                               ),  // O

    .l2c_8_dbus_wvalid          (axi5_wvalid      [8]           ),  // O
    .l2c_8_dbus_wready          (axi5_wready      [8]           ),  // I
    .l2c_8_dbus_wdata           (axi5_wrec        [8].data      ),  // O
    .l2c_8_dbus_wlast           (axi5_wrec        [8].last      ),  // O
    .l2c_8_dbus_wstrb           (axi5_wrec        [8].strb      ),  // O
    .l2c_8_dbus_wuser           (                               ),  // O

    .l2c_8_dbus_bvalid          (axi5_bvalid      [8]           ),  // I
    .l2c_8_dbus_bready          (axi5_bready      [8]           ),  // O
    .l2c_8_dbus_bid             (axi5_brec        [8].id        ),  // I
    .l2c_8_dbus_bresp           (axi5_brec        [8].resp      ),  // I
    .l2c_8_dbus_buser           ('0                             ),  // I

    .l2c_8_dbus_arvalid         (axi5_arvalid     [8]           ),  // O
    .l2c_8_dbus_arready         (axi5_arready     [8]           ),  // I
    .l2c_8_dbus_araddr          (axi5_arrec       [8].addr      ),  // O
    .l2c_8_dbus_arburst         (axi5_arrec       [8].burst     ),  // O
    .l2c_8_dbus_arcache         (axi5_arrec       [8].cache     ),  // O
    .l2c_8_dbus_arid            (axi5_arrec       [8].id        ),  // O
    .l2c_8_dbus_arlen           (axi5_arrec       [8].len       ),  // O
    .l2c_8_dbus_arqos           (axi5_arrec       [8].qos       ),  // O
    .l2c_8_dbus_arsize          (axi5_arrec       [8].size      ),  // O
    .l2c_8_dbus_aruser          (axi5_arrec       [8].user      ),  // O
    .l2c_8_dbus_arlock          (                               ),  // O
    .l2c_8_dbus_arprot          (                               ),  // O

    .l2c_8_dbus_rvalid          (axi5_rvalid      [8]           ),  // I
    .l2c_8_dbus_rready          (axi5_rready      [8]           ),  // O
    .l2c_8_dbus_rdata           (axi5_rrec        [8].data      ),  // I
    .l2c_8_dbus_rid             (axi5_rrec        [8].id        ),  // I
    .l2c_8_dbus_rlast           (axi5_rrec        [8].last      ),  // I
    .l2c_8_dbus_rresp           (axi5_rrec        [8].resp      ),  // I
    .l2c_8_dbus_ruser           ('0                             ),  // I

    // bank 8
    .l2c_9_dbus_awvalid         (axi5_awvalid     [9]           ),  // O
    .l2c_9_dbus_awready         (axi5_awready     [9]           ),  // I
    .l2c_9_dbus_awaddr          (axi5_awrec       [9].addr      ),  // O
    .l2c_9_dbus_awatop          (axi5_awrec       [9].atop      ),  // O
    .l2c_9_dbus_awburst         (axi5_awrec       [9].burst     ),  // O
    .l2c_9_dbus_awcache         (axi5_awrec       [9].cache     ),  // O
    .l2c_9_dbus_awid            (axi5_awrec       [9].id        ),  // O
    .l2c_9_dbus_awlen           (axi5_awrec       [9].len       ),  // O
    .l2c_9_dbus_awqos           (axi5_awrec       [9].qos       ),  // O
    .l2c_9_dbus_awsize          (axi5_awrec       [9].size      ),  // O
    .l2c_9_dbus_awuser          (axi5_awrec       [9].user      ),  // O
    .l2c_9_dbus_awlock          (                               ),  // O
    .l2c_9_dbus_awprot          (                               ),  // O

    .l2c_9_dbus_wvalid          (axi5_wvalid      [9]           ),  // O
    .l2c_9_dbus_wready          (axi5_wready      [9]           ),  // I
    .l2c_9_dbus_wdata           (axi5_wrec        [9].data      ),  // O
    .l2c_9_dbus_wlast           (axi5_wrec        [9].last      ),  // O
    .l2c_9_dbus_wstrb           (axi5_wrec        [9].strb      ),  // O
    .l2c_9_dbus_wuser           (                               ),  // O

    .l2c_9_dbus_bvalid          (axi5_bvalid      [9]           ),  // I
    .l2c_9_dbus_bready          (axi5_bready      [9]           ),  // O
    .l2c_9_dbus_bid             (axi5_brec        [9].id        ),  // I
    .l2c_9_dbus_bresp           (axi5_brec        [9].resp      ),  // I
    .l2c_9_dbus_buser           ('0                             ),  // I

    .l2c_9_dbus_arvalid         (axi5_arvalid     [9]           ),  // O
    .l2c_9_dbus_arready         (axi5_arready     [9]           ),  // I
    .l2c_9_dbus_araddr          (axi5_arrec       [9].addr      ),  // O
    .l2c_9_dbus_arburst         (axi5_arrec       [9].burst     ),  // O
    .l2c_9_dbus_arcache         (axi5_arrec       [9].cache     ),  // O
    .l2c_9_dbus_arid            (axi5_arrec       [9].id        ),  // O
    .l2c_9_dbus_arlen           (axi5_arrec       [9].len       ),  // O
    .l2c_9_dbus_arqos           (axi5_arrec       [9].qos       ),  // O
    .l2c_9_dbus_arsize          (axi5_arrec       [9].size      ),  // O
    .l2c_9_dbus_aruser          (axi5_arrec       [9].user      ),  // O
    .l2c_9_dbus_arlock          (                               ),  // O
    .l2c_9_dbus_arprot          (                               ),  // O

    .l2c_9_dbus_rvalid          (axi5_rvalid      [9]           ),  // I
    .l2c_9_dbus_rready          (axi5_rready      [9]           ),  // O
    .l2c_9_dbus_rdata           (axi5_rrec        [9].data      ),  // I
    .l2c_9_dbus_rid             (axi5_rrec        [9].id        ),  // I
    .l2c_9_dbus_rlast           (axi5_rrec        [9].last      ),  // I
    .l2c_9_dbus_rresp           (axi5_rrec        [9].resp      ),  // I
    .l2c_9_dbus_ruser           ('0                             ),  // I
    .adb_apb3_cbus_fw_payld_async           ( adb_apb3_cbus_fw_payld_async           ) ,
    .adb_apb3_cbus_fw_wr_ptr_async          ( adb_apb3_cbus_fw_wr_ptr_async          ) ,
    .adb_apb3_cbus_rv_rd_ptr_async          ( adb_apb3_cbus_rv_rd_ptr_async          ) ,
    .adb_apb3_cbus_rv_rd_ptr_sync           ( adb_apb3_cbus_rv_rd_ptr_sync           ) ,
    .adb_apb3_cbus_si_to_mi_wakeup_async    ( adb_apb3_cbus_si_to_mi_wakeup_async    ) ,
    .adb_apb3_cbus_slvcandenyreqn_async     ( adb_apb3_cbus_slvcandenyreqn_async     ) ,
    .adb_apb3_cbus_slvmustacceptreqn_async  ( adb_apb3_cbus_slvmustacceptreqn_async  ) ,
                                             
    .adb_l2c_0_dbus_ar_payld_async          ( adb_l2c_0_dbus_ar_payld_async          ) ,
    .adb_l2c_0_dbus_ar_wr_ptr_async         ( adb_l2c_0_dbus_ar_wr_ptr_async         ) ,
    .adb_l2c_0_dbus_aw_payld_async          ( adb_l2c_0_dbus_aw_payld_async          ) ,
    .adb_l2c_0_dbus_aw_wr_ptr_async         ( adb_l2c_0_dbus_aw_wr_ptr_async         ) ,
    .adb_l2c_0_dbus_b_rd_ptr_async          ( adb_l2c_0_dbus_b_rd_ptr_async          ) ,
    .adb_l2c_0_dbus_b_rd_ptr_sync           ( adb_l2c_0_dbus_b_rd_ptr_sync           ) ,
    .adb_l2c_0_dbus_r_rd_ptr_async          ( adb_l2c_0_dbus_r_rd_ptr_async          ) ,
    .adb_l2c_0_dbus_r_rd_ptr_sync           ( adb_l2c_0_dbus_r_rd_ptr_sync           ) ,
    .adb_l2c_0_dbus_si_to_mi_wakeup_async   ( adb_l2c_0_dbus_si_to_mi_wakeup_async   ) ,
    .adb_l2c_0_dbus_slvcandenyreqn_async    ( adb_l2c_0_dbus_slvcandenyreqn_async    ) ,
    .adb_l2c_0_dbus_slvmustacceptreqn_async ( adb_l2c_0_dbus_slvmustacceptreqn_async ) ,
    .adb_l2c_0_dbus_w_payld_async           ( adb_l2c_0_dbus_w_payld_async           ) ,
    .adb_l2c_0_dbus_w_wr_ptr_async          ( adb_l2c_0_dbus_w_wr_ptr_async          ) ,
                                             
                                             
    .adb_l2c_1_dbus_ar_payld_async          ( adb_l2c_1_dbus_ar_payld_async          ) ,
    .adb_l2c_1_dbus_ar_wr_ptr_async         ( adb_l2c_1_dbus_ar_wr_ptr_async         ) ,
    .adb_l2c_1_dbus_aw_payld_async          ( adb_l2c_1_dbus_aw_payld_async          ) ,
    .adb_l2c_1_dbus_aw_wr_ptr_async         ( adb_l2c_1_dbus_aw_wr_ptr_async         ) ,
    .adb_l2c_1_dbus_b_rd_ptr_async          ( adb_l2c_1_dbus_b_rd_ptr_async          ) ,
    .adb_l2c_1_dbus_b_rd_ptr_sync           ( adb_l2c_1_dbus_b_rd_ptr_sync           ) ,
    .adb_l2c_1_dbus_r_rd_ptr_async          ( adb_l2c_1_dbus_r_rd_ptr_async          ) ,
    .adb_l2c_1_dbus_r_rd_ptr_sync           ( adb_l2c_1_dbus_r_rd_ptr_sync           ) ,
    .adb_l2c_1_dbus_si_to_mi_wakeup_async   ( adb_l2c_1_dbus_si_to_mi_wakeup_async   ) ,
    .adb_l2c_1_dbus_slvcandenyreqn_async    ( adb_l2c_1_dbus_slvcandenyreqn_async    ) ,
    .adb_l2c_1_dbus_slvmustacceptreqn_async ( adb_l2c_1_dbus_slvmustacceptreqn_async ) ,
    .adb_l2c_1_dbus_w_payld_async           ( adb_l2c_1_dbus_w_payld_async           ) ,
    .adb_l2c_1_dbus_w_wr_ptr_async          ( adb_l2c_1_dbus_w_wr_ptr_async          ) ,
                                             
                                             
    .adb_l2c_2_dbus_ar_payld_async          ( adb_l2c_2_dbus_ar_payld_async          ) ,
    .adb_l2c_2_dbus_ar_wr_ptr_async         ( adb_l2c_2_dbus_ar_wr_ptr_async         ) ,
    .adb_l2c_2_dbus_aw_payld_async          ( adb_l2c_2_dbus_aw_payld_async          ) ,
    .adb_l2c_2_dbus_aw_wr_ptr_async         ( adb_l2c_2_dbus_aw_wr_ptr_async         ) ,
    .adb_l2c_2_dbus_b_rd_ptr_async          ( adb_l2c_2_dbus_b_rd_ptr_async          ) ,
    .adb_l2c_2_dbus_b_rd_ptr_sync           ( adb_l2c_2_dbus_b_rd_ptr_sync           ) ,
    .adb_l2c_2_dbus_r_rd_ptr_async          ( adb_l2c_2_dbus_r_rd_ptr_async          ) ,
    .adb_l2c_2_dbus_r_rd_ptr_sync           ( adb_l2c_2_dbus_r_rd_ptr_sync           ) ,
    .adb_l2c_2_dbus_si_to_mi_wakeup_async   ( adb_l2c_2_dbus_si_to_mi_wakeup_async   ) ,
    .adb_l2c_2_dbus_slvcandenyreqn_async    ( adb_l2c_2_dbus_slvcandenyreqn_async    ) ,
    .adb_l2c_2_dbus_slvmustacceptreqn_async ( adb_l2c_2_dbus_slvmustacceptreqn_async ) ,
    .adb_l2c_2_dbus_w_payld_async           ( adb_l2c_2_dbus_w_payld_async           ) ,
    .adb_l2c_2_dbus_w_wr_ptr_async          ( adb_l2c_2_dbus_w_wr_ptr_async          ) ,
                                             
                                             
    .adb_l2c_3_dbus_ar_payld_async          ( adb_l2c_3_dbus_ar_payld_async          ) ,
    .adb_l2c_3_dbus_ar_wr_ptr_async         ( adb_l2c_3_dbus_ar_wr_ptr_async         ) ,
    .adb_l2c_3_dbus_aw_payld_async          ( adb_l2c_3_dbus_aw_payld_async          ) ,
    .adb_l2c_3_dbus_aw_wr_ptr_async         ( adb_l2c_3_dbus_aw_wr_ptr_async         ) ,
    .adb_l2c_3_dbus_b_rd_ptr_async          ( adb_l2c_3_dbus_b_rd_ptr_async          ) ,
    .adb_l2c_3_dbus_b_rd_ptr_sync           ( adb_l2c_3_dbus_b_rd_ptr_sync           ) ,
    .adb_l2c_3_dbus_r_rd_ptr_async          ( adb_l2c_3_dbus_r_rd_ptr_async          ) ,
    .adb_l2c_3_dbus_r_rd_ptr_sync           ( adb_l2c_3_dbus_r_rd_ptr_sync           ) ,
    .adb_l2c_3_dbus_si_to_mi_wakeup_async   ( adb_l2c_3_dbus_si_to_mi_wakeup_async   ) ,
    .adb_l2c_3_dbus_slvcandenyreqn_async    ( adb_l2c_3_dbus_slvcandenyreqn_async    ) ,
    .adb_l2c_3_dbus_slvmustacceptreqn_async ( adb_l2c_3_dbus_slvmustacceptreqn_async ) ,
    .adb_l2c_3_dbus_w_payld_async           ( adb_l2c_3_dbus_w_payld_async           ) ,
    .adb_l2c_3_dbus_w_wr_ptr_async          ( adb_l2c_3_dbus_w_wr_ptr_async          ) ,
                                             
                                             
    .adb_l2c_4_dbus_ar_payld_async          ( adb_l2c_4_dbus_ar_payld_async          ) ,
    .adb_l2c_4_dbus_ar_wr_ptr_async         ( adb_l2c_4_dbus_ar_wr_ptr_async         ) ,
    .adb_l2c_4_dbus_aw_payld_async          ( adb_l2c_4_dbus_aw_payld_async          ) ,
    .adb_l2c_4_dbus_aw_wr_ptr_async         ( adb_l2c_4_dbus_aw_wr_ptr_async         ) ,
    .adb_l2c_4_dbus_b_rd_ptr_async          ( adb_l2c_4_dbus_b_rd_ptr_async          ) ,
    .adb_l2c_4_dbus_b_rd_ptr_sync           ( adb_l2c_4_dbus_b_rd_ptr_sync           ) ,
    .adb_l2c_4_dbus_r_rd_ptr_async          ( adb_l2c_4_dbus_r_rd_ptr_async          ) ,
    .adb_l2c_4_dbus_r_rd_ptr_sync           ( adb_l2c_4_dbus_r_rd_ptr_sync           ) ,
    .adb_l2c_4_dbus_si_to_mi_wakeup_async   ( adb_l2c_4_dbus_si_to_mi_wakeup_async   ) ,
    .adb_l2c_4_dbus_slvcandenyreqn_async    ( adb_l2c_4_dbus_slvcandenyreqn_async    ) ,
    .adb_l2c_4_dbus_slvmustacceptreqn_async ( adb_l2c_4_dbus_slvmustacceptreqn_async ) ,
    .adb_l2c_4_dbus_w_payld_async           ( adb_l2c_4_dbus_w_payld_async           ) ,
    .adb_l2c_4_dbus_w_wr_ptr_async          ( adb_l2c_4_dbus_w_wr_ptr_async          ) ,
                                             
                                             
    .adb_l2c_5_dbus_ar_payld_async          ( adb_l2c_5_dbus_ar_payld_async          ) ,
    .adb_l2c_5_dbus_ar_wr_ptr_async         ( adb_l2c_5_dbus_ar_wr_ptr_async         ) ,
    .adb_l2c_5_dbus_aw_payld_async          ( adb_l2c_5_dbus_aw_payld_async          ) ,
    .adb_l2c_5_dbus_aw_wr_ptr_async         ( adb_l2c_5_dbus_aw_wr_ptr_async         ) ,
    .adb_l2c_5_dbus_b_rd_ptr_async          ( adb_l2c_5_dbus_b_rd_ptr_async          ) ,
    .adb_l2c_5_dbus_b_rd_ptr_sync           ( adb_l2c_5_dbus_b_rd_ptr_sync           ) ,
    .adb_l2c_5_dbus_r_rd_ptr_async          ( adb_l2c_5_dbus_r_rd_ptr_async          ) ,
    .adb_l2c_5_dbus_r_rd_ptr_sync           ( adb_l2c_5_dbus_r_rd_ptr_sync           ) ,
    .adb_l2c_5_dbus_si_to_mi_wakeup_async   ( adb_l2c_5_dbus_si_to_mi_wakeup_async   ) ,
    .adb_l2c_5_dbus_slvcandenyreqn_async    ( adb_l2c_5_dbus_slvcandenyreqn_async    ) ,
    .adb_l2c_5_dbus_slvmustacceptreqn_async ( adb_l2c_5_dbus_slvmustacceptreqn_async ) ,
    .adb_l2c_5_dbus_w_payld_async           ( adb_l2c_5_dbus_w_payld_async           ) ,
    .adb_l2c_5_dbus_w_wr_ptr_async          ( adb_l2c_5_dbus_w_wr_ptr_async          ) ,
                                             
                                             
    .adb_l2c_6_dbus_ar_payld_async          ( adb_l2c_6_dbus_ar_payld_async          ) ,
    .adb_l2c_6_dbus_ar_wr_ptr_async         ( adb_l2c_6_dbus_ar_wr_ptr_async         ) ,
    .adb_l2c_6_dbus_aw_payld_async          ( adb_l2c_6_dbus_aw_payld_async          ) ,
    .adb_l2c_6_dbus_aw_wr_ptr_async         ( adb_l2c_6_dbus_aw_wr_ptr_async         ) ,
    .adb_l2c_6_dbus_b_rd_ptr_async          ( adb_l2c_6_dbus_b_rd_ptr_async          ) ,
    .adb_l2c_6_dbus_b_rd_ptr_sync           ( adb_l2c_6_dbus_b_rd_ptr_sync           ) ,
    .adb_l2c_6_dbus_r_rd_ptr_async          ( adb_l2c_6_dbus_r_rd_ptr_async          ) ,
    .adb_l2c_6_dbus_r_rd_ptr_sync           ( adb_l2c_6_dbus_r_rd_ptr_sync           ) ,
    .adb_l2c_6_dbus_si_to_mi_wakeup_async   ( adb_l2c_6_dbus_si_to_mi_wakeup_async   ) ,
    .adb_l2c_6_dbus_slvcandenyreqn_async    ( adb_l2c_6_dbus_slvcandenyreqn_async    ) ,
    .adb_l2c_6_dbus_slvmustacceptreqn_async ( adb_l2c_6_dbus_slvmustacceptreqn_async ) ,
    .adb_l2c_6_dbus_w_payld_async           ( adb_l2c_6_dbus_w_payld_async           ) ,
    .adb_l2c_6_dbus_w_wr_ptr_async          ( adb_l2c_6_dbus_w_wr_ptr_async          ) ,
                                             
                                             
    .adb_l2c_7_dbus_ar_payld_async          ( adb_l2c_7_dbus_ar_payld_async          ) ,
    .adb_l2c_7_dbus_ar_wr_ptr_async         ( adb_l2c_7_dbus_ar_wr_ptr_async         ) ,
    .adb_l2c_7_dbus_aw_payld_async          ( adb_l2c_7_dbus_aw_payld_async          ) ,
    .adb_l2c_7_dbus_aw_wr_ptr_async         ( adb_l2c_7_dbus_aw_wr_ptr_async         ) ,
    .adb_l2c_7_dbus_b_rd_ptr_async          ( adb_l2c_7_dbus_b_rd_ptr_async          ) ,
    .adb_l2c_7_dbus_b_rd_ptr_sync           ( adb_l2c_7_dbus_b_rd_ptr_sync           ) ,
    .adb_l2c_7_dbus_r_rd_ptr_async          ( adb_l2c_7_dbus_r_rd_ptr_async          ) ,
    .adb_l2c_7_dbus_r_rd_ptr_sync           ( adb_l2c_7_dbus_r_rd_ptr_sync           ) ,
    .adb_l2c_7_dbus_si_to_mi_wakeup_async   ( adb_l2c_7_dbus_si_to_mi_wakeup_async   ) ,
    .adb_l2c_7_dbus_slvcandenyreqn_async    ( adb_l2c_7_dbus_slvcandenyreqn_async    ) ,
    .adb_l2c_7_dbus_slvmustacceptreqn_async ( adb_l2c_7_dbus_slvmustacceptreqn_async ) ,
    .adb_l2c_7_dbus_w_payld_async           ( adb_l2c_7_dbus_w_payld_async           ) ,
    .adb_l2c_7_dbus_w_wr_ptr_async          ( adb_l2c_7_dbus_w_wr_ptr_async          ) ,
                                             
    .adb_l2c_8_dbus_ar_payld_async          ( adb_l2c_8_dbus_ar_payld_async          ) ,
    .adb_l2c_8_dbus_ar_wr_ptr_async         ( adb_l2c_8_dbus_ar_wr_ptr_async         ) ,
    .adb_l2c_8_dbus_aw_payld_async          ( adb_l2c_8_dbus_aw_payld_async          ) ,
    .adb_l2c_8_dbus_aw_wr_ptr_async         ( adb_l2c_8_dbus_aw_wr_ptr_async         ) ,
    .adb_l2c_8_dbus_b_rd_ptr_async          ( adb_l2c_8_dbus_b_rd_ptr_async          ) ,
    .adb_l2c_8_dbus_b_rd_ptr_sync           ( adb_l2c_8_dbus_b_rd_ptr_sync           ) ,
    .adb_l2c_8_dbus_r_rd_ptr_async          ( adb_l2c_8_dbus_r_rd_ptr_async          ) ,
    .adb_l2c_8_dbus_r_rd_ptr_sync           ( adb_l2c_8_dbus_r_rd_ptr_sync           ) ,
    .adb_l2c_8_dbus_si_to_mi_wakeup_async   ( adb_l2c_8_dbus_si_to_mi_wakeup_async   ) ,
    .adb_l2c_8_dbus_slvcandenyreqn_async    ( adb_l2c_8_dbus_slvcandenyreqn_async    ) ,
    .adb_l2c_8_dbus_slvmustacceptreqn_async ( adb_l2c_8_dbus_slvmustacceptreqn_async ) ,
    .adb_l2c_8_dbus_w_payld_async           ( adb_l2c_8_dbus_w_payld_async           ) ,
    .adb_l2c_8_dbus_w_wr_ptr_async          ( adb_l2c_8_dbus_w_wr_ptr_async          ) ,
                                             
                                             
    .adb_l2c_9_dbus_ar_payld_async          ( adb_l2c_9_dbus_ar_payld_async          ) ,
    .adb_l2c_9_dbus_ar_wr_ptr_async         ( adb_l2c_9_dbus_ar_wr_ptr_async         ) ,
    .adb_l2c_9_dbus_aw_payld_async          ( adb_l2c_9_dbus_aw_payld_async          ) ,
    .adb_l2c_9_dbus_aw_wr_ptr_async         ( adb_l2c_9_dbus_aw_wr_ptr_async         ) ,
    .adb_l2c_9_dbus_b_rd_ptr_async          ( adb_l2c_9_dbus_b_rd_ptr_async          ) ,
    .adb_l2c_9_dbus_b_rd_ptr_sync           ( adb_l2c_9_dbus_b_rd_ptr_sync           ) ,
    .adb_l2c_9_dbus_r_rd_ptr_async          ( adb_l2c_9_dbus_r_rd_ptr_async          ) ,
    .adb_l2c_9_dbus_r_rd_ptr_sync           ( adb_l2c_9_dbus_r_rd_ptr_sync           ) ,
    .adb_l2c_9_dbus_si_to_mi_wakeup_async   ( adb_l2c_9_dbus_si_to_mi_wakeup_async   ) ,
    .adb_l2c_9_dbus_slvcandenyreqn_async    ( adb_l2c_9_dbus_slvcandenyreqn_async    ) ,
    .adb_l2c_9_dbus_slvmustacceptreqn_async ( adb_l2c_9_dbus_slvmustacceptreqn_async ) ,
    .adb_l2c_9_dbus_w_payld_async           ( adb_l2c_9_dbus_w_payld_async           ) ,
    .adb_l2c_9_dbus_w_wr_ptr_async          ( adb_l2c_9_dbus_w_wr_ptr_async          ) ,
                                             
                                             
    .adb_apb3_cbus_fw_rd_ptr_async          ( adb_apb3_cbus_fw_rd_ptr_async          ) ,
    .adb_apb3_cbus_fw_rd_ptr_sync           ( adb_apb3_cbus_fw_rd_ptr_sync           ) ,
    .adb_apb3_cbus_mi_to_si_wakeup_async    ( adb_apb3_cbus_mi_to_si_wakeup_async    ) ,
    .adb_apb3_cbus_rv_payld_async           ( adb_apb3_cbus_rv_payld_async           ) ,
    .adb_apb3_cbus_rv_wr_ptr_async          ( adb_apb3_cbus_rv_wr_ptr_async          ) ,
    .adb_apb3_cbus_slvacceptn_async         ( adb_apb3_cbus_slvacceptn_async         ) ,
    .adb_apb3_cbus_slvdeny_async            ( adb_apb3_cbus_slvdeny_async            ) ,
                                             
                                             
    .adb_l2c_0_dbus_ar_rd_ptr_async         ( adb_l2c_0_dbus_ar_rd_ptr_async         ) ,
    .adb_l2c_0_dbus_ar_rd_ptr_sync          ( adb_l2c_0_dbus_ar_rd_ptr_sync          ) ,
    .adb_l2c_0_dbus_aw_rd_ptr_async         ( adb_l2c_0_dbus_aw_rd_ptr_async         ) ,
    .adb_l2c_0_dbus_aw_rd_ptr_sync          ( adb_l2c_0_dbus_aw_rd_ptr_sync          ) ,
    .adb_l2c_0_dbus_b_payld_async           ( adb_l2c_0_dbus_b_payld_async           ) ,
    .adb_l2c_0_dbus_b_wr_ptr_async          ( adb_l2c_0_dbus_b_wr_ptr_async          ) ,
    .adb_l2c_0_dbus_mi_to_si_wakeup_async   ( adb_l2c_0_dbus_mi_to_si_wakeup_async   ) ,
    .adb_l2c_0_dbus_r_payld_async           ( adb_l2c_0_dbus_r_payld_async           ) ,
    .adb_l2c_0_dbus_r_wr_ptr_async          ( adb_l2c_0_dbus_r_wr_ptr_async          ) ,
    .adb_l2c_0_dbus_slvacceptn_async        ( adb_l2c_0_dbus_slvacceptn_async        ) ,
    .adb_l2c_0_dbus_slvdeny_async           ( adb_l2c_0_dbus_slvdeny_async           ) ,
    .adb_l2c_0_dbus_w_rd_ptr_async          ( adb_l2c_0_dbus_w_rd_ptr_async          ) ,
    .adb_l2c_0_dbus_w_rd_ptr_sync           ( adb_l2c_0_dbus_w_rd_ptr_sync           ) ,
                                             
                                             
    .adb_l2c_1_dbus_ar_rd_ptr_async         ( adb_l2c_1_dbus_ar_rd_ptr_async         ) ,
    .adb_l2c_1_dbus_ar_rd_ptr_sync          ( adb_l2c_1_dbus_ar_rd_ptr_sync          ) ,
    .adb_l2c_1_dbus_aw_rd_ptr_async         ( adb_l2c_1_dbus_aw_rd_ptr_async         ) ,
    .adb_l2c_1_dbus_aw_rd_ptr_sync          ( adb_l2c_1_dbus_aw_rd_ptr_sync          ) ,
    .adb_l2c_1_dbus_b_payld_async           ( adb_l2c_1_dbus_b_payld_async           ) ,
    .adb_l2c_1_dbus_b_wr_ptr_async          ( adb_l2c_1_dbus_b_wr_ptr_async          ) ,
    .adb_l2c_1_dbus_mi_to_si_wakeup_async   ( adb_l2c_1_dbus_mi_to_si_wakeup_async   ) ,
    .adb_l2c_1_dbus_r_payld_async           ( adb_l2c_1_dbus_r_payld_async           ) ,
    .adb_l2c_1_dbus_r_wr_ptr_async          ( adb_l2c_1_dbus_r_wr_ptr_async          ) ,
    .adb_l2c_1_dbus_slvacceptn_async        ( adb_l2c_1_dbus_slvacceptn_async        ) ,
    .adb_l2c_1_dbus_slvdeny_async           ( adb_l2c_1_dbus_slvdeny_async           ) ,
    .adb_l2c_1_dbus_w_rd_ptr_async          ( adb_l2c_1_dbus_w_rd_ptr_async          ) ,
    .adb_l2c_1_dbus_w_rd_ptr_sync           ( adb_l2c_1_dbus_w_rd_ptr_sync           ) ,
                                             
                                             
    .adb_l2c_2_dbus_ar_rd_ptr_async         ( adb_l2c_2_dbus_ar_rd_ptr_async         ) ,
    .adb_l2c_2_dbus_ar_rd_ptr_sync          ( adb_l2c_2_dbus_ar_rd_ptr_sync          ) ,
    .adb_l2c_2_dbus_aw_rd_ptr_async         ( adb_l2c_2_dbus_aw_rd_ptr_async         ) ,
    .adb_l2c_2_dbus_aw_rd_ptr_sync          ( adb_l2c_2_dbus_aw_rd_ptr_sync          ) ,
    .adb_l2c_2_dbus_b_payld_async           ( adb_l2c_2_dbus_b_payld_async           ) ,
    .adb_l2c_2_dbus_b_wr_ptr_async          ( adb_l2c_2_dbus_b_wr_ptr_async          ) ,
    .adb_l2c_2_dbus_mi_to_si_wakeup_async   ( adb_l2c_2_dbus_mi_to_si_wakeup_async   ) ,
    .adb_l2c_2_dbus_r_payld_async           ( adb_l2c_2_dbus_r_payld_async           ) ,
    .adb_l2c_2_dbus_r_wr_ptr_async          ( adb_l2c_2_dbus_r_wr_ptr_async          ) ,
    .adb_l2c_2_dbus_slvacceptn_async        ( adb_l2c_2_dbus_slvacceptn_async        ) ,
    .adb_l2c_2_dbus_slvdeny_async           ( adb_l2c_2_dbus_slvdeny_async           ) ,
    .adb_l2c_2_dbus_w_rd_ptr_async          ( adb_l2c_2_dbus_w_rd_ptr_async          ) ,
    .adb_l2c_2_dbus_w_rd_ptr_sync           ( adb_l2c_2_dbus_w_rd_ptr_sync           ) ,
                                             
                                             
    .adb_l2c_3_dbus_ar_rd_ptr_async         ( adb_l2c_3_dbus_ar_rd_ptr_async         ) ,
    .adb_l2c_3_dbus_ar_rd_ptr_sync          ( adb_l2c_3_dbus_ar_rd_ptr_sync          ) ,
    .adb_l2c_3_dbus_aw_rd_ptr_async         ( adb_l2c_3_dbus_aw_rd_ptr_async         ) ,
    .adb_l2c_3_dbus_aw_rd_ptr_sync          ( adb_l2c_3_dbus_aw_rd_ptr_sync          ) ,
    .adb_l2c_3_dbus_b_payld_async           ( adb_l2c_3_dbus_b_payld_async           ) ,
    .adb_l2c_3_dbus_b_wr_ptr_async          ( adb_l2c_3_dbus_b_wr_ptr_async          ) ,
    .adb_l2c_3_dbus_mi_to_si_wakeup_async   ( adb_l2c_3_dbus_mi_to_si_wakeup_async   ) ,
    .adb_l2c_3_dbus_r_payld_async           ( adb_l2c_3_dbus_r_payld_async           ) ,
    .adb_l2c_3_dbus_r_wr_ptr_async          ( adb_l2c_3_dbus_r_wr_ptr_async          ) ,
    .adb_l2c_3_dbus_slvacceptn_async        ( adb_l2c_3_dbus_slvacceptn_async        ) ,
    .adb_l2c_3_dbus_slvdeny_async           ( adb_l2c_3_dbus_slvdeny_async           ) ,
    .adb_l2c_3_dbus_w_rd_ptr_async          ( adb_l2c_3_dbus_w_rd_ptr_async          ) ,
    .adb_l2c_3_dbus_w_rd_ptr_sync           ( adb_l2c_3_dbus_w_rd_ptr_sync           ) ,
                                             
                                             
    .adb_l2c_4_dbus_ar_rd_ptr_async         ( adb_l2c_4_dbus_ar_rd_ptr_async         ) ,
    .adb_l2c_4_dbus_ar_rd_ptr_sync          ( adb_l2c_4_dbus_ar_rd_ptr_sync          ) ,
    .adb_l2c_4_dbus_aw_rd_ptr_async         ( adb_l2c_4_dbus_aw_rd_ptr_async         ) ,
    .adb_l2c_4_dbus_aw_rd_ptr_sync          ( adb_l2c_4_dbus_aw_rd_ptr_sync          ) ,
    .adb_l2c_4_dbus_b_payld_async           ( adb_l2c_4_dbus_b_payld_async           ) ,
    .adb_l2c_4_dbus_b_wr_ptr_async          ( adb_l2c_4_dbus_b_wr_ptr_async          ) ,
    .adb_l2c_4_dbus_mi_to_si_wakeup_async   ( adb_l2c_4_dbus_mi_to_si_wakeup_async   ) ,
    .adb_l2c_4_dbus_r_payld_async           ( adb_l2c_4_dbus_r_payld_async           ) ,
    .adb_l2c_4_dbus_r_wr_ptr_async          ( adb_l2c_4_dbus_r_wr_ptr_async          ) ,
    .adb_l2c_4_dbus_slvacceptn_async        ( adb_l2c_4_dbus_slvacceptn_async        ) ,
    .adb_l2c_4_dbus_slvdeny_async           ( adb_l2c_4_dbus_slvdeny_async           ) ,
    .adb_l2c_4_dbus_w_rd_ptr_async          ( adb_l2c_4_dbus_w_rd_ptr_async          ) ,
    .adb_l2c_4_dbus_w_rd_ptr_sync           ( adb_l2c_4_dbus_w_rd_ptr_sync           ) ,
                                             
                                             
    .adb_l2c_5_dbus_ar_rd_ptr_async         ( adb_l2c_5_dbus_ar_rd_ptr_async         ) ,
    .adb_l2c_5_dbus_ar_rd_ptr_sync          ( adb_l2c_5_dbus_ar_rd_ptr_sync          ) ,
    .adb_l2c_5_dbus_aw_rd_ptr_async         ( adb_l2c_5_dbus_aw_rd_ptr_async         ) ,
    .adb_l2c_5_dbus_aw_rd_ptr_sync          ( adb_l2c_5_dbus_aw_rd_ptr_sync          ) ,
    .adb_l2c_5_dbus_b_payld_async           ( adb_l2c_5_dbus_b_payld_async           ) ,
    .adb_l2c_5_dbus_b_wr_ptr_async          ( adb_l2c_5_dbus_b_wr_ptr_async          ) ,
    .adb_l2c_5_dbus_mi_to_si_wakeup_async   ( adb_l2c_5_dbus_mi_to_si_wakeup_async   ) ,
    .adb_l2c_5_dbus_r_payld_async           ( adb_l2c_5_dbus_r_payld_async           ) ,
    .adb_l2c_5_dbus_r_wr_ptr_async          ( adb_l2c_5_dbus_r_wr_ptr_async          ) ,
    .adb_l2c_5_dbus_slvacceptn_async        ( adb_l2c_5_dbus_slvacceptn_async        ) ,
    .adb_l2c_5_dbus_slvdeny_async           ( adb_l2c_5_dbus_slvdeny_async           ) ,
    .adb_l2c_5_dbus_w_rd_ptr_async          ( adb_l2c_5_dbus_w_rd_ptr_async          ) ,
    .adb_l2c_5_dbus_w_rd_ptr_sync           ( adb_l2c_5_dbus_w_rd_ptr_sync           ) ,
                                       
                                       
    .adb_l2c_6_dbus_ar_rd_ptr_async         ( adb_l2c_6_dbus_ar_rd_ptr_async         ) ,
    .adb_l2c_6_dbus_ar_rd_ptr_sync          ( adb_l2c_6_dbus_ar_rd_ptr_sync          ) ,
    .adb_l2c_6_dbus_aw_rd_ptr_async         ( adb_l2c_6_dbus_aw_rd_ptr_async         ) ,
    .adb_l2c_6_dbus_aw_rd_ptr_sync          ( adb_l2c_6_dbus_aw_rd_ptr_sync          ) ,
    .adb_l2c_6_dbus_b_payld_async           ( adb_l2c_6_dbus_b_payld_async           ) ,
    .adb_l2c_6_dbus_b_wr_ptr_async          ( adb_l2c_6_dbus_b_wr_ptr_async          ) ,
    .adb_l2c_6_dbus_mi_to_si_wakeup_async   ( adb_l2c_6_dbus_mi_to_si_wakeup_async   ) ,
    .adb_l2c_6_dbus_r_payld_async           ( adb_l2c_6_dbus_r_payld_async           ) ,
    .adb_l2c_6_dbus_r_wr_ptr_async          ( adb_l2c_6_dbus_r_wr_ptr_async          ) ,
    .adb_l2c_6_dbus_slvacceptn_async        ( adb_l2c_6_dbus_slvacceptn_async        ) ,
    .adb_l2c_6_dbus_slvdeny_async           ( adb_l2c_6_dbus_slvdeny_async           ) ,
    .adb_l2c_6_dbus_w_rd_ptr_async          ( adb_l2c_6_dbus_w_rd_ptr_async          ) ,
    .adb_l2c_6_dbus_w_rd_ptr_sync           ( adb_l2c_6_dbus_w_rd_ptr_sync           ) ,
                                            
                                            
    .adb_l2c_7_dbus_ar_rd_ptr_async         ( adb_l2c_7_dbus_ar_rd_ptr_async         ) ,
    .adb_l2c_7_dbus_ar_rd_ptr_sync          ( adb_l2c_7_dbus_ar_rd_ptr_sync          ) ,
    .adb_l2c_7_dbus_aw_rd_ptr_async         ( adb_l2c_7_dbus_aw_rd_ptr_async         ) ,
    .adb_l2c_7_dbus_aw_rd_ptr_sync          ( adb_l2c_7_dbus_aw_rd_ptr_sync          ) ,
    .adb_l2c_7_dbus_b_payld_async           ( adb_l2c_7_dbus_b_payld_async           ) ,
    .adb_l2c_7_dbus_b_wr_ptr_async          ( adb_l2c_7_dbus_b_wr_ptr_async          ) ,
    .adb_l2c_7_dbus_mi_to_si_wakeup_async   ( adb_l2c_7_dbus_mi_to_si_wakeup_async   ) ,
    .adb_l2c_7_dbus_r_payld_async           ( adb_l2c_7_dbus_r_payld_async           ) ,
    .adb_l2c_7_dbus_r_wr_ptr_async          ( adb_l2c_7_dbus_r_wr_ptr_async          ) ,
    .adb_l2c_7_dbus_slvacceptn_async        ( adb_l2c_7_dbus_slvacceptn_async        ) ,
    .adb_l2c_7_dbus_slvdeny_async           ( adb_l2c_7_dbus_slvdeny_async           ) ,
    .adb_l2c_7_dbus_w_rd_ptr_async          ( adb_l2c_7_dbus_w_rd_ptr_async          ) ,
    .adb_l2c_7_dbus_w_rd_ptr_sync           ( adb_l2c_7_dbus_w_rd_ptr_sync           ) , 
    
    .adb_l2c_8_dbus_ar_rd_ptr_async         ( adb_l2c_8_dbus_ar_rd_ptr_async         ) ,
    .adb_l2c_8_dbus_ar_rd_ptr_sync          ( adb_l2c_8_dbus_ar_rd_ptr_sync          ) ,
    .adb_l2c_8_dbus_aw_rd_ptr_async         ( adb_l2c_8_dbus_aw_rd_ptr_async         ) ,
    .adb_l2c_8_dbus_aw_rd_ptr_sync          ( adb_l2c_8_dbus_aw_rd_ptr_sync          ) ,
    .adb_l2c_8_dbus_b_payld_async           ( adb_l2c_8_dbus_b_payld_async           ) ,
    .adb_l2c_8_dbus_b_wr_ptr_async          ( adb_l2c_8_dbus_b_wr_ptr_async          ) ,
    .adb_l2c_8_dbus_mi_to_si_wakeup_async   ( adb_l2c_8_dbus_mi_to_si_wakeup_async   ) ,
    .adb_l2c_8_dbus_r_payld_async           ( adb_l2c_8_dbus_r_payld_async           ) ,
    .adb_l2c_8_dbus_r_wr_ptr_async          ( adb_l2c_8_dbus_r_wr_ptr_async          ) ,
    .adb_l2c_8_dbus_slvacceptn_async        ( adb_l2c_8_dbus_slvacceptn_async        ) ,
    .adb_l2c_8_dbus_slvdeny_async           ( adb_l2c_8_dbus_slvdeny_async           ) ,
    .adb_l2c_8_dbus_w_rd_ptr_async          ( adb_l2c_8_dbus_w_rd_ptr_async          ) ,
    .adb_l2c_8_dbus_w_rd_ptr_sync           ( adb_l2c_8_dbus_w_rd_ptr_sync           ) , 
    
    .adb_l2c_9_dbus_ar_rd_ptr_async         ( adb_l2c_9_dbus_ar_rd_ptr_async         ) ,
    .adb_l2c_9_dbus_ar_rd_ptr_sync          ( adb_l2c_9_dbus_ar_rd_ptr_sync          ) ,
    .adb_l2c_9_dbus_aw_rd_ptr_async         ( adb_l2c_9_dbus_aw_rd_ptr_async         ) ,
    .adb_l2c_9_dbus_aw_rd_ptr_sync          ( adb_l2c_9_dbus_aw_rd_ptr_sync          ) ,
    .adb_l2c_9_dbus_b_payld_async           ( adb_l2c_9_dbus_b_payld_async           ) ,
    .adb_l2c_9_dbus_b_wr_ptr_async          ( adb_l2c_9_dbus_b_wr_ptr_async          ) ,
    .adb_l2c_9_dbus_mi_to_si_wakeup_async   ( adb_l2c_9_dbus_mi_to_si_wakeup_async   ) ,
    .adb_l2c_9_dbus_r_payld_async           ( adb_l2c_9_dbus_r_payld_async           ) ,
    .adb_l2c_9_dbus_r_wr_ptr_async          ( adb_l2c_9_dbus_r_wr_ptr_async          ) ,
    .adb_l2c_9_dbus_slvacceptn_async        ( adb_l2c_9_dbus_slvacceptn_async        ) ,
    .adb_l2c_9_dbus_slvdeny_async           ( adb_l2c_9_dbus_slvdeny_async           ) ,
    .adb_l2c_9_dbus_w_rd_ptr_async          ( adb_l2c_9_dbus_w_rd_ptr_async          ) ,
    .adb_l2c_9_dbus_w_rd_ptr_sync           ( adb_l2c_9_dbus_w_rd_ptr_sync           ) 
     );
// synopsys translate_off

logic [63:0] timeout_cnt;

always_ff@(posedge aclk or negedge aresetn) begin
   if(!aresetn) begin
      timeout_cnt <= '0; 
   end
   else if ( (|axi5_arvalid) | (|axi5_awvalid) | (|nsp_req_valid) | (|nsp_rsp_valid) | (|axi5_rvalid) | (|axi5_wvalid)) begin
      timeout_cnt <= '0;
   end
   else begin
      timeout_cnt <= timeout_cnt + 1'b1;
   end
end


// default clocking cb@(posedge aclk);
// endclocking
// default disable iff(!aresetn);
// as__timeout_check:
//    assert property (timeout_cnt <= 'd100_0000) else $fatal("%dth L2G time out", l2g_number_id);
// synopsys translate_on







     
endmodule
 // Local Variables:
 // verilog-library-directories:("./" ) 
 // End:
