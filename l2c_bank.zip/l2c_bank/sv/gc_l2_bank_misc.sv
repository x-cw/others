// ---------------------------------------------------------------------------------
// Project Name  : IC_Design
// Author        : liusm
// Email         : liusm@innosilicon.com.cn
// Create On     : 2025/02/05 16:19
// Last Modified : 2025/08/04 14:14
// File Name     : gc_l2_bank_misc.sv
// Description   :
// 
// Copyright (c) 2025 Innosilicon.
// ALL RIGHTS RESERVED
// 
// ---------------------------------------------------------------------------------
// Modification History:
// Date         By              Version                 Change Description
// ---------------------------------------------------------------------------------
// 2025/02/05   liusm           1.0                     Original
// 
// ----------------------------------------------------------------------------------


module gc_l2_bank_misc(
      input    logic                   clk
,     input    logic                   resetn

,     input    logic [ 2:0  ]          l2g_number_id

,     input    logic                   bank_perf_enable
,     input    logic [ 9:0  ] [63:0]   bank_perf_event
,     input    logic [ 4:0  ]          bank_perf_sel
,     output   logic [ 63:0 ]          l2g_perf_event

,     input    logic [ 9:0  ]          gc_cr_l2_cfi_status_l
,     output   logic [ 79:0 ]          gc_cr_l2_cfi_status
,     input    logic [ 4:0  ]          gc_cr_clk_status_l2g
,     output   logic [ 7:0  ]          gc_cr_clk_status3_l2g

,     input    logic [ 9:0  ]          gc_cr_l2g_idle_l2g
,     output   logic [ 79:0 ]          gc_cr_l2_idle


,     input    logic [ 9:0 ][ 2:0  ]   gc_cr_l2g_error_l2b

,     output   logic [ 63:0 ] [2:0]    gc_cr_l2g_error
,     output   logic [ 2:0  ]          regbank_instance
);




for (genvar L2G = 0; L2G < 8; L2G ++) begin: g_bank_group_select
   assign gc_cr_l2_idle           [ 10*L2G+:10 ] = l2g_number_id == L2G ? gc_cr_l2g_idle_l2g      : '0;
   assign gc_cr_l2_cfi_status     [ 10*L2G+:10 ] = l2g_number_id == L2G ? gc_cr_l2_cfi_status_l   : '0;
   assign gc_cr_l2g_error         [ 8*L2G+:8   ] = l2g_number_id == L2G ? gc_cr_l2g_error_l2b[7:0]     : '0;
   assign gc_cr_clk_status3_l2g   [L2G]          = l2g_number_id == L2G ? |gc_cr_clk_status_l2g   : '0;
end
assign regbank_instance = l2g_number_id;



logic [63:0] l2g_perf_event_sel0;
logic [63:0] l2g_perf_event_sel1;
logic [63:0] l2g_perf_event_sel12;
logic [63:0] l2g_perf_event_sel13;
logic [63:0] l2g_perf_event_sel31;


for (genvar BANK = 0; BANK < 8; BANK ++) begin: g_perf_event
   assign l2g_perf_event_sel0  [ BANK    ] = bank_perf_event[BANK][17]; // l2b0_fromaxi_smp_read_req_num
   assign l2g_perf_event_sel0  [ 8+BANK  ] = bank_perf_event[BANK][18]; // l2b0_fromaxi_smp_read_req_sum
   assign l2g_perf_event_sel0  [ 16+BANK ] = bank_perf_event[BANK][19]; // l2b0_fromaxi_smp_write_req_num
   assign l2g_perf_event_sel0  [ 24+BANK ] = bank_perf_event[BANK][20]; // l2b0_fromaxi_smp_write_req_sum
   assign l2g_perf_event_sel0  [ 32+BANK ] = bank_perf_event[BANK][21]; // l2b0_fromaxi_smp_atomic_req_num
   assign l2g_perf_event_sel0  [ 40+BANK ] = bank_perf_event[BANK][22]; // l2b0_fromaxi_smp_atomic_req_sum
   assign l2g_perf_event_sel0  [ 48+BANK ] = bank_perf_event[BANK][61]; // l2b0_memif_smp_read_req_num
   assign l2g_perf_event_sel0  [ 56+BANK ] = bank_perf_event[BANK][62]; // l2b0_memif_smp_read_req_sum
   
   if (BANK == 0 || BANK == 1) begin:g_bank8_9
      assign l2g_perf_event_sel1  [ BANK    ] = bank_perf_event[BANK+8][17] ; // l2b0_fromaxi_smp_read_req_num
      assign l2g_perf_event_sel1  [ 8+BANK  ] = bank_perf_event[BANK+8][18] ; // l2b0_fromaxi_smp_read_req_sum
      assign l2g_perf_event_sel1  [ 16+BANK ] = bank_perf_event[BANK+8][19] ; // l2b0_fromaxi_smp_write_req_num
      assign l2g_perf_event_sel1  [ 24+BANK ] = bank_perf_event[BANK+8][20] ; // l2b0_fromaxi_smp_write_req_sum
      assign l2g_perf_event_sel1  [ 32+BANK ] = bank_perf_event[BANK+8][21] ; // l2b0_fromaxi_smp_atomic_req_num
      assign l2g_perf_event_sel1  [ 40+BANK ] = bank_perf_event[BANK+8][22] ; // l2b0_fromaxi_smp_atomic_req_sum
      assign l2g_perf_event_sel1  [ 48+BANK ] = bank_perf_event[BANK+8][61] ; // l2b0_memif_smp_read_req_num
      assign l2g_perf_event_sel1  [ 56+BANK ] = bank_perf_event[BANK+8][62] ; // l2b0_memif_smp_read_req_sum

      assign l2g_perf_event_sel13  [ BANK    ] = bank_perf_event[BANK+8][1] ;  // l2b0_fromaxi_ar_wl
      assign l2g_perf_event_sel13  [ 8+BANK  ] = bank_perf_event[BANK+8][6] ;  // l2b0_fromaxi_ar_bp
      assign l2g_perf_event_sel13  [ 16+BANK ] = bank_perf_event[BANK+8][7] ;  // l2b0_toaxi_r_wl
      assign l2g_perf_event_sel13  [ 24+BANK ] = bank_perf_event[BANK+8][9] ;  // l2b0_fromaxi_aw_wl
      assign l2g_perf_event_sel13  [ 32+BANK ] = bank_perf_event[BANK+8][14]; // l2b0_fromaxi_aw_bp
      assign l2g_perf_event_sel13  [ 40+BANK ] = bank_perf_event[BANK+8][15]; // l2b0_fromaxi_w_wl
      assign l2g_perf_event_sel13  [ 48+BANK ] = bank_perf_event[BANK+8][61]; // l2b0_memif_smp_read_req_num
      assign l2g_perf_event_sel13  [ 56+BANK ] = bank_perf_event[BANK+8][62]; // l2b0_memif_smp_read_req_sum
   end
   else begin:g_bank_10_15
      assign l2g_perf_event_sel1  [ BANK    ] =  1'b0; // l2b0_fromaxi_smp_read_req_num
      assign l2g_perf_event_sel1  [ 8+BANK  ] =  1'b0; // l2b0_fromaxi_smp_read_req_sum
      assign l2g_perf_event_sel1  [ 16+BANK ] =  1'b0; // l2b0_fromaxi_smp_write_req_num
      assign l2g_perf_event_sel1  [ 24+BANK ] =  1'b0; // l2b0_fromaxi_smp_write_req_sum
      assign l2g_perf_event_sel1  [ 32+BANK ] =  1'b0; // l2b0_fromaxi_smp_atomic_req_num
      assign l2g_perf_event_sel1  [ 40+BANK ] =  1'b0; // l2b0_fromaxi_smp_atomic_req_sum
      assign l2g_perf_event_sel1  [ 48+BANK ] =  1'b0; // l2b0_memif_smp_read_req_num
      assign l2g_perf_event_sel1  [ 56+BANK ] =  1'b0; // l2b0_memif_smp_read_req_sum

      assign l2g_perf_event_sel13  [ BANK    ] = 1'b0;  // l2b0_fromaxi_ar_wl
      assign l2g_perf_event_sel13  [ 8+BANK  ] = 1'b0;  // l2b0_fromaxi_ar_bp
      assign l2g_perf_event_sel13  [ 16+BANK ] = 1'b0;  // l2b0_toaxi_r_wl
      assign l2g_perf_event_sel13  [ 24+BANK ] = 1'b0;  // l2b0_fromaxi_aw_wl
      assign l2g_perf_event_sel13  [ 32+BANK ] = 1'b0; // l2b0_fromaxi_aw_bp
      assign l2g_perf_event_sel13  [ 40+BANK ] = 1'b0; // l2b0_fromaxi_w_wl
      assign l2g_perf_event_sel13  [ 48+BANK ] = 1'b0; // l2b0_memif_smp_read_req_num
      assign l2g_perf_event_sel13  [ 56+BANK ] = 1'b0; // l2b0_memif_smp_read_req_sum
   end
   assign l2g_perf_event_sel12  [ BANK    ] = bank_perf_event[BANK][1];  // l2b0_fromaxi_ar_wl
   assign l2g_perf_event_sel12  [ 8+BANK  ] = bank_perf_event[BANK][6];  // l2b0_fromaxi_ar_bp
   assign l2g_perf_event_sel12  [ 16+BANK ] = bank_perf_event[BANK][7];  // l2b0_toaxi_r_wl
   assign l2g_perf_event_sel12  [ 24+BANK ] = bank_perf_event[BANK][9];  // l2b0_fromaxi_aw_wl
   assign l2g_perf_event_sel12  [ 32+BANK ] = bank_perf_event[BANK][14]; // l2b0_fromaxi_aw_bp
   assign l2g_perf_event_sel12  [ 40+BANK ] = bank_perf_event[BANK][15]; // l2b0_fromaxi_w_wl
   assign l2g_perf_event_sel12  [ 48+BANK ] = bank_perf_event[BANK][61]; // l2b0_memif_smp_read_req_num
   assign l2g_perf_event_sel12  [ 56+BANK ] = bank_perf_event[BANK][62]; // l2b0_memif_smp_read_req_sum

end

for (genvar BANK = 0; BANK < 10; BANK++) begin 
   assign l2g_perf_event_sel31 [ BANK    ] = bank_perf_event[BANK][6];  // l2b0_fromaxi_ar_bp
   assign l2g_perf_event_sel31 [ 10+BANK ] = bank_perf_event[BANK][7];  // l2b0_toaxi_r_wl
   assign l2g_perf_event_sel31 [ 20+BANK ] = bank_perf_event[BANK][14]; // l2b0_fromaxi_aw_bp
   assign l2g_perf_event_sel31 [ 30+BANK ] = bank_perf_event[BANK][15]; // l2b0_fromaxi_w_wl
   assign l2g_perf_event_sel31 [ 40+BANK ] = bank_perf_event[BANK][61]; // l2b0_memif_smp_read_req_num
   assign l2g_perf_event_sel31 [ 50+BANK ] = bank_perf_event[BANK][62]; // l2b0_memif_smp_read_req_sum
end
assign l2g_perf_event_sel31[63:60] = '0;

logic [4:0] bank_perf_sel_r;
logic bank_perf_enable_r;
always_ff@(posedge clk or negedge resetn) begin
   if(!resetn) begin
      bank_perf_sel_r <= '0; 
      bank_perf_enable_r <= 1'b0;
   end
   else begin
      bank_perf_sel_r <= bank_perf_sel;
      bank_perf_enable_r <= bank_perf_enable;
   end
end

always_ff@(posedge clk or negedge resetn) begin: p_sel_perf_event
   if(!resetn) begin
      l2g_perf_event <= '0; 
   end
   else if (bank_perf_enable_r) begin
      case (bank_perf_sel_r)
         5'd0: l2g_perf_event    <= l2g_perf_event_sel0;
         5'd1: l2g_perf_event    <= l2g_perf_event_sel1;
         5'd2: l2g_perf_event    <= bank_perf_event[0];
         5'd3: l2g_perf_event    <= bank_perf_event[1];
         5'd4: l2g_perf_event    <= bank_perf_event[2];
         5'd5: l2g_perf_event    <= bank_perf_event[3];
         5'd6: l2g_perf_event    <= bank_perf_event[4];
         5'd7: l2g_perf_event    <= bank_perf_event[5];
         5'd8: l2g_perf_event    <= bank_perf_event[6];
         5'd9: l2g_perf_event    <= bank_perf_event[7];
         5'd10:l2g_perf_event    <= bank_perf_event[8];
         5'd11:l2g_perf_event    <= bank_perf_event[9];
         5'd12:l2g_perf_event    <= l2g_perf_event_sel12;
         5'd13:l2g_perf_event    <= l2g_perf_event_sel13;
         5'd31:l2g_perf_event    <= l2g_perf_event_sel31;
         default: l2g_perf_event <= l2g_perf_event_sel0;
      endcase
   end
   else begin
      l2g_perf_event <= '0;
   end
end









endmodule
// Local Variables:
// verilog-library-directories:("./" ) 
// End:
