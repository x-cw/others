/*

 * #==========================================================================#
 * |                                                                          |
 * |  Copyright (c) 2022, Fantasy Technologies Limited and/or its         |
 * |  affiliated group companies ("Fantasy"). All rights reserved.        |
 * |  No part of this content, either material or conceptual may be copied    |
 * |  or distributed, transmitted, transcribed, stored in a retrieval system  |
 * |  or translated into any human or computer language in any form by any    |
 * |  means, electronic, mechanical manual, or otherwise, or disclosed to     |
 * |  third parties without the express written permission of Fantasy.    |
 * |                                                                          |
 * #==========================================================================#

 */


package gpc_round_robin_index_arch1_gateway_pkg_;

   // This function is used to check if the generics are within specified bounds
  function automatic int gpc_round_robin_index_arch1_gateway_fail(input integer width, input hold_previous);
     if ((hold_previous  | ! hold_previous) && (width >= 1) && (width <= 512))
       return 0;
     else
       return 1;
   endfunction : gpc_round_robin_index_arch1_gateway_fail
endpackage
