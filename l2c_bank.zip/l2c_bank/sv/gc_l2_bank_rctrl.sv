/*


*/

// ----------------------------------------------------------------------------------------------
// entity name: gc_l2_bank_rctrl
// purpose: L2 RAM control, access dirty mask RAM and data RAM
//          receive request from isched, return data to align or wdc
// ----------------------------------------------------------------------------------------------


module gc_l2_bank_rctrl
import gpc_gfx_timing_buffer_pack_::*;
import gc_l2_bank_pkg::*;
(
    // global interface
    input   logic       clk,
    input   logic       resetn,
    output  logic       l2_rctrl_idle,
    // cacheline instruction interface
    input   logic                                   isched_rctrl_valid,
    output  logic                                   isched_rctrl_ready,
    input   isched_rctrl_record_type                isched_rctrl_instr_rec,

    input   logic                                   isched_rctrl_wdata_valid,
    output  logic                                   isched_rctrl_wdata_ready,
    input   isched_rctrl_wdata_record_type          isched_rctrl_wdata_rec,
    // linefill write request interface
    input   logic                                   memif_rctrl_valid,
    output  logic                                   memif_rctrl_ready,
    input   memif_rctrl_record_type                 memif_rctrl_rec,
    // clear initial mask interface
    input   logic                                   tagctrl_rctrl_clr_valid,
    input   tagctrl_rctrl_clr_record_type           tagctrl_rctrl_clr_record,
    // WB data out interface
    output  logic                                   rctrl_wdc_valid,
    input   logic                                   rctrl_wdc_ready,
    output  rctrl_wdc_wb_record_type                rctrl_wdc_data_rec,
    // read data return interface
    output  logic                                   rctrl_align_valid,
    input   logic                                   rctrl_align_ready,
    output  memif_align_record_type                 rctrl_align_rec,
    // instruction complete interface
    output  logic                                   rctrl_isched_valid,
    output  rctrl_isched_record_type                rctrl_isched_rec,
   
    output  logic                                   rctrl_tagctrl_valid,
    output  rctrl_tagctrl_record_type               rctrl_tagctrl_rec,

    // performance counter
    output  logic                                   l2b_ramctrl_reqarb_wl,
    output  logic                                   l2b_ramctrl_reqarb_stall_by_sram,
    output  logic                                   l2b_ramctrl_data_sram_read_wl,
    output  logic                                   l2b_ramctrl_data_sram_write_wl,
    input   logic                                   gc_cr_cu_lms_fp32_denormal_en,
    // test interface
    input   logic                                   tst_gclkenable
);

localparam int RC_WB_FIFO_WIDTH    = L2_BEAT_WIDTH+L2_BEAT_STRB_WIDTH+1; // data+strb+last
localparam int RC_WB_FIFO_DBG_WIDTH= L2_NUM_SET_BITS+L2_NUM_WAY_BITS+L2_BEAT_BITS+L2_AXI_ID_WIDTH; // set+way+beat+axid

logic [L2_NUM_SECTOR-1:0] initial_mask_array[L2_NUM_SET/L2_NUM_RCTRL-1:0][L2_NUM_WAY-1:0];
logic [L2_NUM_SECTOR-1:0] initial_mask_comb [L2_NUM_SET/L2_NUM_RCTRL-1:0][L2_NUM_WAY-1:0];
logic                     arbiter_init_up;

logic                                       data_ram_write_valid;
logic [L2_BEAT_WIDTH/8-1:0]                 data_ram_write_en;
logic [$clog2(L2_RCTRL_DRAM_DEPTH)-1:0]     data_ram_write_addr;
logic [L2_BEAT_WIDTH-1:0]                   data_ram_write_data;
logic                                       data_ram_read_valid;
logic                                       data_ram_read_ready;
logic [$clog2(L2_RCTRL_DRAM_DEPTH)-1:0]     data_ram_read_addr;
logic                                       data_ram_readout_valid;
logic                                       data_ram_readout_ready;
logic [L2_BEAT_WIDTH-1:0]                   data_ram_readout_data;

logic                                       mask_ram_write_valid;
logic [L2_BEAT_STRB_WIDTH*2-1:0]            mask_ram_write_en;
logic [$clog2(L2_RCTRL_MRAM_DEPTH)-1:0]     mask_ram_write_addr;
logic [L2_BEAT_STRB_WIDTH*2-1:0]            mask_ram_write_data;
logic                                       mask_ram_read_valid;
logic                                       mask_ram_read_ready;
logic [$clog2(L2_RCTRL_MRAM_DEPTH)-1:0]     mask_ram_read_addr;
logic                                       mask_ram_readout_valid;
logic                                       mask_ram_readout_ready;
logic [L2_BEAT_STRB_WIDTH*2-1:0]            mask_ram_readout_data;

logic                                       mask_ram_read_issued;
logic                                       data_ram_read_issued;

logic                                       arbiter_valid;
logic                                       arbiter_ready;
rctrl_pipeline_record_type                  arbiter_rec;

logic                                       request_stage0_valid;
logic                                       request_stage0_ready;
rctrl_pipeline_record_type                  request_stage0_rec;

logic                                       request_stage1_valid;
logic                                       request_stage1_ready;
rctrl_pipeline_record_type                  request_stage1_rec;

logic                                       request_stage2_valid;
logic                                       request_stage2_ready;
rctrl_pipeline_record_type                  request_stage2_rec;

logic                                       request_stage2_sync_en;
logic                                       request_stage2_sync_valid;
logic                                       request_stage2_sync_ready;

logic                                       request_stage3_valid;
rctrl_pipeline_record_type                  request_stage3_rec;

logic                                       stage0_read_mask_ram_enable;
logic                                       stage0_read_data_ram_enable;
logic                                       raw_mask_ram_hazard;
logic                                       raw_data_ram_hazard;
logic                                       no_raw_ram_hazard;
logic                                       stage1_write_mask_ram;
logic                                       stage1_write_data_ram;
logic                                       stage2_write_mask_ram;
logic                                       stage2_write_data_ram;
logic [$clog2(L2_RCTRL_DRAM_DEPTH)-1:0]     stage0_data_ram_addr;
logic [$clog2(L2_RCTRL_MRAM_DEPTH)-1:0]     stage0_mask_ram_addr;
logic [$clog2(L2_RCTRL_DRAM_DEPTH)-1:0]     stage1_data_ram_addr;
logic [$clog2(L2_RCTRL_MRAM_DEPTH)-1:0]     stage1_mask_ram_addr;
logic [$clog2(L2_RCTRL_DRAM_DEPTH)-1:0]     stage2_data_ram_addr;
logic [$clog2(L2_RCTRL_MRAM_DEPTH)-1:0]     stage2_mask_ram_addr;
logic [$clog2(L2_RCTRL_DRAM_DEPTH)-1:0]     stage3_data_ram_addr;
logic [$clog2(L2_RCTRL_MRAM_DEPTH)-1:0]     stage3_mask_ram_addr;

logic                                       isched_pipeline_instr_valid;
rctrl_pipeline_record_type                  isched_pipeline_instr_rec;

logic                                       lf_pipeline_instr_valid;
rctrl_pipeline_record_type                  lf_pipeline_instr_rec;

logic                                       rctrl_inst_cmpl_en;
logic                                       rctrl_isched_valid_tb;
rctrl_isched_record_type                    rctrl_isched_rec_tb;
logic                                       rctrl_tagctrl_valid_tb;
rctrl_tagctrl_record_type                   rctrl_tagctrl_rec_tb;

logic                                       rctrl_wdc_fifo_valid;
logic                                       rctrl_wdc_fifo_ready;
rctrl_wdc_wb_record_type                    rctrl_wdc_fifo_data_rec;

logic [L2_BEAT_WIDTH-1:0]                   merged_wb_data;
logic [L2_BEAT_STRB_WIDTH-1:0]              request_stage2_wstrb;

logic                                       aa_enable       ;
logic                                       aa_wrap         ;
logic [1                    : 0 ]           aa_len          ;
logic [L2_BEAT_WIDTH/32-1   : 0 ]           dword_active    ;
logic [L2_BEAT_WIDTH/32-1   : 0 ]           org_dword_active;
logic [L2_AA_OP_WIDTH-1     : 0 ]           aa_operation    ;
logic [L2_BEAT_WIDTH-1      : 0 ]           source_data     ;
logic [L2_BEAT_WIDTH-1      : 0 ]           aa_result       ;
logic [L2_BEAT_WIDTH-1      : 0 ]           aa_result_fp32  ;
logic [L2_BEAT_WIDTH-1      : 0 ]           operand_a       ;
logic [L2_BEAT_STRB_WIDTH-1 : 0 ]           aa_result_strb  ;

logic                                       mask_ram_pipe_idle;
logic                                       data_ram_pipe_idle;

function automatic logic l2_cacheline_instr_read_mask_ram (
   l2_bank_cacheline_instr_type instr, 
   logic initial_mask,
   logic check_partial);
   
   logic result;
   result = 1'b0;
   if (((instr == WR) && check_partial) | instr == FLUSH | ((instr == WB | instr == WB_WR | instr == PREFETCH) && initial_mask))
      result = 1'b1;
   else 
      result = 1'b0;
   return result;      
endfunction

function automatic logic l2_cacheline_instr_read_data_ram (l2_bank_cacheline_instr_type instr, logic initial_mask); 
   logic result;
   if (instr == RD | instr == AA | instr == FLUSH | ((instr == WB | instr == WB_WR) && initial_mask))
      result = 1'b1;
   else 
      result = 1'b0;
   return result;
endfunction

function automatic logic l2_cacheline_instr_write_mask_ram (l2_bank_cacheline_instr_type instr, logic initial_mask); 
   logic result;
   if (instr == WR | instr == AA | instr == FLUSH | (instr == PREFETCH && ~initial_mask))
      result = 1'b1;
   else 
      result = 1'b0;
   return result;
endfunction

function automatic logic l2_cacheline_instr_write_data_ram (l2_bank_cacheline_instr_type instr); 
   logic result;
   if (instr == WR | instr == AA | instr == PREFETCH)
      result = 1'b1;
   else 
      result = 1'b0;
   return result;
endfunction

assign lf_pipeline_instr_valid                  = memif_rctrl_valid;
assign lf_pipeline_instr_rec.instruction        = PREFETCH; // Linefill is overrided as PREFETCH because PREFETCH can not be issued to RCTRL.
assign lf_pipeline_instr_rec.axid               = '0;
assign lf_pipeline_instr_rec.set                = memif_rctrl_rec.set;
assign lf_pipeline_instr_rec.way                = memif_rctrl_rec.way;
assign lf_pipeline_instr_rec.beat               = memif_rctrl_rec.beat;
assign lf_pipeline_instr_rec.last               = memif_rctrl_rec.last;
assign lf_pipeline_instr_rec.is_buffer_mode     = 1'b0;
assign lf_pipeline_instr_rec.initial_mask       = memif_rctrl_rec.beat[1] ? 
                                                  initial_mask_array[memif_rctrl_rec.set[L2_NUM_SET_BITS-1:L2_NUM_RCTRL_BITS]][memif_rctrl_rec.way][1] : 
                                                  initial_mask_array[memif_rctrl_rec.set[L2_NUM_SET_BITS-1:L2_NUM_RCTRL_BITS]][memif_rctrl_rec.way][0];
assign lf_pipeline_instr_rec.sector_mask        = memif_rctrl_rec.sector_mask;
assign lf_pipeline_instr_rec.wstrb              = '1;
assign lf_pipeline_instr_rec.wdata              = memif_rctrl_rec.data;

assign isched_pipeline_instr_valid              = isched_rctrl_valid;
assign isched_pipeline_instr_rec.instruction    = isched_rctrl_instr_rec.instruction;
assign isched_pipeline_instr_rec.axid           = isched_rctrl_instr_rec.axid;
assign isched_pipeline_instr_rec.set            = isched_rctrl_instr_rec.set;
assign isched_pipeline_instr_rec.way            = isched_rctrl_instr_rec.way;
assign isched_pipeline_instr_rec.beat           = isched_rctrl_instr_rec.beat;
assign isched_pipeline_instr_rec.last           = isched_rctrl_instr_rec.last;
assign isched_pipeline_instr_rec.is_buffer_mode = isched_rctrl_instr_rec.is_buffer_mode;
assign isched_pipeline_instr_rec.initial_mask   = isched_rctrl_instr_rec.beat[1]? 
                                                  initial_mask_array[isched_rctrl_instr_rec.set[L2_NUM_SET_BITS-1:L2_NUM_RCTRL_BITS]][isched_rctrl_instr_rec.way][1] : 
                                                  initial_mask_array[isched_rctrl_instr_rec.set[L2_NUM_SET_BITS-1:L2_NUM_RCTRL_BITS]][isched_rctrl_instr_rec.way][0];
assign isched_pipeline_instr_rec.sector_mask    = isched_rctrl_instr_rec.sector_mask;
assign isched_pipeline_instr_rec.wstrb          = 'b0;
assign isched_pipeline_instr_rec.wdata          = 'b0;


// fix priority arbiter: the linefill request always takes priority


assign arbiter_ready = ~request_stage0_valid | request_stage0_ready;
assign request_stage1_ready = ~request_stage2_valid | request_stage2_ready;

assign arbiter_valid = isched_pipeline_instr_valid | lf_pipeline_instr_valid;
assign arbiter_rec = lf_pipeline_instr_valid ? lf_pipeline_instr_rec  : isched_pipeline_instr_rec;
assign memif_rctrl_ready = lf_pipeline_instr_valid ? arbiter_ready : 1'b0;
assign isched_rctrl_ready = lf_pipeline_instr_valid ? 1'b0 : arbiter_ready;

assign arbiter_init_up = (arbiter_rec.instruction == WR) || (arbiter_rec.instruction == PREFETCH) || 
                         (arbiter_rec.instruction == WB) || (arbiter_rec.instruction == WB_WR);
generate 
   for (genvar way = 0; way < L2_NUM_WAY ; way ++) begin: g_update_per_way_initial_mask
      for (genvar set = 0; set < L2_NUM_SET/L2_NUM_RCTRL; set ++) begin: g_update_per_set_initial_mask

         // initial_mask_comb for arbiter request
         always_comb begin: p_initial_mask_comb
            if (arbiter_valid && arbiter_ready && set == arbiter_rec.set[L2_NUM_SET_BITS-1:L2_NUM_RCTRL_BITS] && way == arbiter_rec.way) begin
               case (arbiter_rec.instruction)
                  WR: begin
                     if (arbiter_rec.beat[1]) begin
                        initial_mask_comb[set][way][0] = initial_mask_array[set][way][0];
                        initial_mask_comb[set][way][1] = 1'b1;
                     end
                     else begin
                        initial_mask_comb[set][way][0] = 1'b1;
                        initial_mask_comb[set][way][1] = initial_mask_array[set][way][1];
                     end
                  end
                  PREFETCH: begin    // linefill
                     if (arbiter_rec.beat[0]) begin     // update after one sector linefill done
                        if (arbiter_rec.beat[1]) begin
                           initial_mask_comb[set][way][0] = initial_mask_array[set][way][0];
                           initial_mask_comb[set][way][1] = 1'b1;
                        end
                        else begin
                           initial_mask_comb[set][way][0] = 1'b1;
                           initial_mask_comb[set][way][1] = initial_mask_array[set][way][1];
                        end
                     end
                     else begin
                        initial_mask_comb[set][way] = initial_mask_array[set][way];
                     end
                  end
                  WB, WB_WR: begin
                     if (arbiter_rec.last) begin
                        initial_mask_comb[set][way] = 'b0;
                     end
                     else begin
                        initial_mask_comb[set][way] = initial_mask_array[set][way];
                     end
                  end
                  default: initial_mask_comb[set][way] = initial_mask_array[set][way];
               endcase
            end
            else begin
               initial_mask_comb[set][way] = initial_mask_array[set][way];
            end
         end: p_initial_mask_comb

         always_ff@(posedge clk or negedge resetn) begin
            if (!resetn) begin
               initial_mask_array[set][way] <= '0;
            end
            else if (arbiter_valid && arbiter_ready && tagctrl_rctrl_clr_valid) begin
               if (set == arbiter_rec.set[L2_NUM_SET_BITS-1:L2_NUM_RCTRL_BITS] && way == arbiter_rec.way && arbiter_init_up) begin
                  initial_mask_array[set][way] <= initial_mask_comb[set][way];
               end
               else if(set == tagctrl_rctrl_clr_record.set[L2_NUM_SET_BITS-1:L2_NUM_RCTRL_BITS] && way == tagctrl_rctrl_clr_record.way) begin
                  initial_mask_array[set][way] <= 'b0;
               end
            end
            else if (arbiter_valid && arbiter_ready) begin
               if (set == arbiter_rec.set[L2_NUM_SET_BITS-1:L2_NUM_RCTRL_BITS] && way == arbiter_rec.way && arbiter_init_up) begin
                  initial_mask_array[set][way] <= initial_mask_comb[set][way];
               end
            end
            else if (tagctrl_rctrl_clr_valid && tagctrl_rctrl_clr_record.set[L2_NUM_SET_BITS-1:L2_NUM_RCTRL_BITS] == set && tagctrl_rctrl_clr_record.way == way ) begin
               initial_mask_array[set][way] <= 'b0;
            end
         end
      end
   end
endgenerate

always_ff@(posedge clk or negedge resetn) begin
   if (!resetn) begin
      request_stage0_valid <= 1'b0;
      request_stage0_rec <= '0;
   end
   else if (arbiter_valid && arbiter_ready) begin
      request_stage0_valid <= 1'b1;
      request_stage0_rec <= arbiter_rec;
   end
   else if (request_stage0_valid && request_stage0_ready) begin
      request_stage0_valid <= 1'b0;
   end
end


always_ff@(posedge clk or negedge resetn) begin
   if (!resetn) begin
      request_stage1_valid <= 1'b0;
      request_stage1_rec <= '0;
   end
   else if (request_stage0_valid && request_stage0_ready) begin
      request_stage1_valid <= 1'b1;
      request_stage1_rec <= request_stage0_rec;
   end
   else if (request_stage1_valid && request_stage1_ready) begin
      request_stage1_valid <= 1'b0;
   end
end


always_ff@(posedge clk or negedge resetn) begin
   if (!resetn) begin
      request_stage2_valid <= 1'b0;
      request_stage2_rec <= '0;
   end
   else if (request_stage1_valid && request_stage1_ready) begin
      request_stage2_valid <= 1'b1;
      request_stage2_rec <= request_stage1_rec;
   end
   else if (request_stage2_sync_valid && request_stage2_sync_ready) begin
      request_stage2_valid <= 1'b0;
   end
end

always_ff@(posedge clk or negedge resetn) begin
   if (!resetn) begin
      request_stage3_valid <= 1'b0;
      request_stage3_rec <= '0;
   end
   else if (request_stage2_sync_valid && request_stage2_sync_ready) begin
      request_stage3_valid <= 1'b1;
      request_stage3_rec <= request_stage2_rec;
      if((request_stage2_rec.instruction == PREFETCH) && (request_stage2_rec.initial_mask == 1'b1)) begin
         if (~request_stage2_rec.beat[0])   // store and overwrite strb
            request_stage3_rec.wstrb <= mask_ram_readout_data[0+:L2_BEAT_STRB_WIDTH];
         else
            request_stage3_rec.wstrb <= mask_ram_readout_data[L2_BEAT_STRB_WIDTH+:L2_BEAT_STRB_WIDTH];
      end
      else if(request_stage2_sync_en) begin
          request_stage3_rec.wstrb <= isched_rctrl_wdata_rec.strb;
      end

      if(request_stage2_sync_en) begin
          request_stage3_rec.wdata <= isched_rctrl_wdata_rec.data;
      end
   end
   else if (request_stage3_valid) begin // request_stage3_valid && request_stage3_ready
      request_stage3_valid <= 1'b0;
   end
end

always_ff@(posedge clk or negedge resetn) begin
   if (~resetn) begin
      mask_ram_read_issued <= 1'b0;
   end
   else if (request_stage0_valid && request_stage0_ready) begin
      mask_ram_read_issued <= 1'b0;
   end
   else if (mask_ram_read_valid && mask_ram_read_ready) begin
      mask_ram_read_issued <= 1'b1;
   end
end

assign stage0_read_mask_ram_enable = l2_cacheline_instr_read_mask_ram(request_stage0_rec.instruction, request_stage0_rec.initial_mask, '0);

assign stage0_read_data_ram_enable = l2_cacheline_instr_read_data_ram(request_stage0_rec.instruction, request_stage0_rec.initial_mask);


// read after write hazard
assign stage1_write_mask_ram = l2_cacheline_instr_write_mask_ram(request_stage1_rec.instruction, request_stage1_rec.initial_mask);
assign stage2_write_mask_ram = l2_cacheline_instr_write_mask_ram(request_stage2_rec.instruction, request_stage2_rec.initial_mask);

assign stage1_write_data_ram = l2_cacheline_instr_write_data_ram(request_stage1_rec.instruction);
assign stage2_write_data_ram = l2_cacheline_instr_write_data_ram(request_stage2_rec.instruction);

assign stage0_data_ram_addr = {request_stage0_rec.way, request_stage0_rec.set[L2_NUM_SET_BITS-1:L2_NUM_RCTRL_BITS], request_stage0_rec.beat};
assign stage1_data_ram_addr = {request_stage1_rec.way, request_stage1_rec.set[L2_NUM_SET_BITS-1:L2_NUM_RCTRL_BITS], request_stage1_rec.beat};
assign stage2_data_ram_addr = {request_stage2_rec.way, request_stage2_rec.set[L2_NUM_SET_BITS-1:L2_NUM_RCTRL_BITS], request_stage2_rec.beat};
assign stage3_data_ram_addr = {request_stage3_rec.way, request_stage3_rec.set[L2_NUM_SET_BITS-1:L2_NUM_RCTRL_BITS], request_stage3_rec.beat};

assign stage0_mask_ram_addr = {request_stage0_rec.way, request_stage0_rec.set[L2_NUM_SET_BITS-1:L2_NUM_RCTRL_BITS], request_stage0_rec.beat[1]};
assign stage1_mask_ram_addr = {request_stage1_rec.way, request_stage1_rec.set[L2_NUM_SET_BITS-1:L2_NUM_RCTRL_BITS], request_stage1_rec.beat[1]};
assign stage2_mask_ram_addr = {request_stage2_rec.way, request_stage2_rec.set[L2_NUM_SET_BITS-1:L2_NUM_RCTRL_BITS], request_stage2_rec.beat[1]};
assign stage3_mask_ram_addr = {request_stage3_rec.way, request_stage3_rec.set[L2_NUM_SET_BITS-1:L2_NUM_RCTRL_BITS], request_stage3_rec.beat[1]};

assign raw_mask_ram_hazard = request_stage0_valid && stage0_read_mask_ram_enable &&
                           ((request_stage1_valid && stage1_write_mask_ram && (stage1_mask_ram_addr == stage0_mask_ram_addr)) ||
                            (request_stage2_valid && stage2_write_mask_ram && (stage2_mask_ram_addr == stage0_mask_ram_addr)) );
assign raw_data_ram_hazard = request_stage0_valid && stage0_read_data_ram_enable &&
                           ((request_stage1_valid && stage1_write_data_ram && (stage1_data_ram_addr == stage0_data_ram_addr)) ||
                            (request_stage2_valid && stage2_write_data_ram && (stage2_data_ram_addr == stage0_data_ram_addr)) );
assign no_raw_ram_hazard   = ~raw_mask_ram_hazard & ~raw_data_ram_hazard;


assign request_stage0_ready =    (!stage0_read_mask_ram_enable | (stage0_read_mask_ram_enable && no_raw_ram_hazard && (mask_ram_read_ready | mask_ram_read_issued)) ) 
                              && (!stage0_read_data_ram_enable | (stage0_read_data_ram_enable && no_raw_ram_hazard && (data_ram_read_ready | data_ram_read_issued))) 
                              && (~request_stage1_valid | request_stage1_ready);

assign mask_ram_read_valid = request_stage0_valid && stage0_read_mask_ram_enable ? (~mask_ram_read_issued & no_raw_ram_hazard) : 1'b0;
assign data_ram_read_valid = request_stage0_valid && stage0_read_data_ram_enable ? (~data_ram_read_issued & no_raw_ram_hazard) : 1'b0; 
assign mask_ram_read_addr  = stage0_mask_ram_addr;
assign data_ram_read_addr  = stage0_data_ram_addr;
                                                                              
assign mask_ram_write_addr = stage3_mask_ram_addr;
assign data_ram_write_addr = stage3_data_ram_addr;

gc_l2_bank_rctrl_spram_pipeline
#(
      .id                   ( L2_RCTRL_MRAM_ID              ) ,
      .w                    ( L2_RCTRL_MRAM_WIDTH           ) ,    // Width of write data and read data
      .p                    ( L2_RCTRL_MRAM_P               ) ,    // Partition width for use by the write enable signal
      .d                    ( L2_RCTRL_MRAM_DEPTH           ) ,    // Depth of ram
      .log2d                ( $clog2(L2_RCTRL_MRAM_DEPTH )  )
                                                            )
i_mask_ram_spstore_pipeline (
      .clk                  ( clk                           ) ,
      .resetn               ( resetn                        ) ,
      .te                   ( tst_gclkenable                ) ,
      .idle                 ( mask_ram_pipe_idle            ) ,
      
      .read_valid           ( mask_ram_read_valid           ) ,
      .read_ready           ( mask_ram_read_ready           ) ,
      .read_addr            ( mask_ram_read_addr            ) ,
      
      .readout_valid        ( mask_ram_readout_valid        ) ,
      .readout_ready        ( mask_ram_readout_ready        ) ,
      .readout_data         ( mask_ram_readout_data         ) ,
      
      .write_valid          ( mask_ram_write_valid          ) ,
      .write_en             ( mask_ram_write_en             ) ,     // active low
      .write_addr           ( mask_ram_write_addr           ) ,
      .write_data           ( mask_ram_write_data           ) );


always_ff@(posedge clk or negedge resetn) begin
   if (!resetn) begin
      data_ram_read_issued <= 1'b0;
   end
   else if (request_stage0_valid && request_stage0_ready) begin
      data_ram_read_issued <= 1'b0;
   end
   else if (data_ram_read_valid && data_ram_read_ready) begin
      data_ram_read_issued <= 1'b1;
   end
end

 
gc_l2_bank_rctrl_spram_pipeline
#(
      .id                   ( L2_RCTRL_DRAM_ID              ) ,
      .w                    ( L2_RCTRL_DRAM_WIDTH           ) ,    // Width of write data and read data
      .p                    ( L2_RCTRL_DRAM_P               ) ,    // Partition width for use by the write enable signal
      .d                    ( L2_RCTRL_DRAM_DEPTH           ) ,    // Depth of ram
      .log2d                ( $clog2(L2_RCTRL_DRAM_DEPTH )  )
                                                            )
i_data_ram_spstore_pipeline (
      .clk                  ( clk                           ) ,
      .resetn               ( resetn                        ) ,
      .te                   ( tst_gclkenable                ) ,
      .idle                 ( data_ram_pipe_idle            ) ,
      
      .read_valid           ( data_ram_read_valid           ) ,
      .read_ready           ( data_ram_read_ready           ) ,
      .read_addr            ( data_ram_read_addr            ) ,
      
      .readout_valid        ( data_ram_readout_valid        ) ,
      .readout_ready        ( data_ram_readout_ready        ) ,
      .readout_data         ( data_ram_readout_data         ) ,
      
      .write_valid          ( data_ram_write_valid          ) ,
      .write_en             ( data_ram_write_en             ) ,     // active low
      .write_addr           ( data_ram_write_addr           ) ,
      .write_data           ( data_ram_write_data           ) );


// stage2 write data sync
assign request_stage2_sync_en    = (request_stage2_rec.instruction == WR) || (request_stage2_rec.instruction == AA) || 
                                   (request_stage2_rec.instruction == WB_WR);
assign request_stage2_sync_valid = request_stage2_sync_en ? request_stage2_valid & isched_rctrl_wdata_valid : request_stage2_valid;

assign request_stage2_ready      = request_stage2_sync_ready;
assign isched_rctrl_wdata_ready  = request_stage2_sync_ready & request_stage2_sync_en;

// stage2 process
always_comb begin
   request_stage2_sync_ready = 1'b0;
   rctrl_align_valid         = 1'b0;
   data_ram_readout_ready    = 1'b0;
   mask_ram_readout_ready    = 1'b0;
   rctrl_wdc_fifo_valid      = 1'b0;
   if (request_stage2_sync_valid) begin
      case (request_stage2_rec.instruction)
         RD: begin
            rctrl_align_valid           = 1'b1;
            request_stage2_sync_ready   = rctrl_align_ready;
            data_ram_readout_ready      = rctrl_align_ready;
         end
         WR: begin
            request_stage2_sync_ready   = 1'b1;
         end
         AA: begin
            rctrl_align_valid           = data_ram_readout_valid;       // 2 -> 1, maybe has bubble
            request_stage2_sync_ready   = data_ram_readout_valid & rctrl_align_ready;
            data_ram_readout_ready      = data_ram_readout_valid & rctrl_align_ready;
         end
         FLUSH: begin
            rctrl_wdc_fifo_valid        = 1'b1;
            request_stage2_sync_ready   = rctrl_wdc_fifo_ready;
            data_ram_readout_ready      = rctrl_wdc_fifo_ready;
            mask_ram_readout_ready      = rctrl_wdc_fifo_ready;
         end
         WB: begin
            rctrl_wdc_fifo_valid        = 1'b1;
            request_stage2_sync_ready   = rctrl_wdc_fifo_ready;
            data_ram_readout_ready      = rctrl_wdc_fifo_ready & request_stage2_rec.initial_mask;
            mask_ram_readout_ready      = rctrl_wdc_fifo_ready & request_stage2_rec.initial_mask;
         end
         WB_WR: begin
            rctrl_wdc_fifo_valid        = 1'b1;
            request_stage2_sync_ready   = rctrl_wdc_fifo_ready;
            data_ram_readout_ready      = rctrl_wdc_fifo_ready & request_stage2_rec.initial_mask;
            mask_ram_readout_ready      = rctrl_wdc_fifo_ready & request_stage2_rec.initial_mask;
         end
         PREFETCH: begin            // linefill
            request_stage2_sync_ready   = 1'b1;
            if (request_stage2_rec.initial_mask)
               mask_ram_readout_ready   = 1'b1;
         end
      endcase
   end
end


always_comb begin
   mask_ram_write_valid     = 1'b0;
   mask_ram_write_en        = '1;
   mask_ram_write_data      = '0;
   data_ram_write_valid     = 1'b0;
   data_ram_write_en        = '0;
   data_ram_write_data      = '0;
   if (request_stage3_valid) begin
      case (request_stage3_rec.instruction)
         WR: begin
            mask_ram_write_valid = 1'b1;
            if (request_stage3_rec.initial_mask) begin
               if (~request_stage3_rec.beat[0]) begin // the first beat
                  mask_ram_write_en[0+:L2_BEAT_STRB_WIDTH] = ~request_stage3_rec.wstrb;
                  mask_ram_write_data[0+:L2_BEAT_STRB_WIDTH] = request_stage3_rec.wstrb;
               end
               else begin 
                  mask_ram_write_en[L2_BEAT_STRB_WIDTH+:L2_BEAT_STRB_WIDTH] = ~request_stage3_rec.wstrb;
                  mask_ram_write_data[L2_BEAT_STRB_WIDTH+:L2_BEAT_STRB_WIDTH] = request_stage3_rec.wstrb;
               end
            end
            else begin
               mask_ram_write_en = '0;
               if (~request_stage3_rec.beat[0]) // the first beat
                  mask_ram_write_data = {{L2_BEAT_STRB_WIDTH{1'b0}}, request_stage3_rec.wstrb};
               else
                  mask_ram_write_data = {request_stage3_rec.wstrb, {L2_BEAT_STRB_WIDTH{1'b0}}};
            end
            data_ram_write_valid = 1'b1;
            data_ram_write_en = ~request_stage3_rec.wstrb;
            data_ram_write_data = request_stage3_rec.wdata;
         end
         AA: begin
            data_ram_write_valid = 1'b1;
            data_ram_write_en    = ~aa_result_strb;
            data_ram_write_data  = request_stage3_rec.wstrb[20] ? aa_result_fp32 : aa_result;
            mask_ram_write_valid = 1'b1;
            if (~request_stage3_rec.beat[0]) begin  // the first beat
               mask_ram_write_en   = {{L2_BEAT_STRB_WIDTH{1'b1}}, ~aa_result_strb};
               mask_ram_write_data = {{L2_BEAT_STRB_WIDTH{1'b0}},  aa_result_strb};
            end
            else begin
               mask_ram_write_en   = {~aa_result_strb, {L2_BEAT_STRB_WIDTH{1'b1}}};
               mask_ram_write_data = { aa_result_strb, {L2_BEAT_STRB_WIDTH{1'b0}}};
            end
         end
         FLUSH: begin
            mask_ram_write_valid = 1'b1;
            mask_ram_write_data = '0;
            if (~request_stage3_rec.beat[0])
               mask_ram_write_en[0+:L2_BEAT_STRB_WIDTH] = '0; 
            else 
               mask_ram_write_en[L2_BEAT_STRB_WIDTH+:L2_BEAT_STRB_WIDTH] = '0; 
         end
         PREFETCH: begin            // linefill
            mask_ram_write_valid = ~request_stage3_rec.initial_mask;
            if (~request_stage3_rec.beat[0])
               mask_ram_write_en[0+:L2_BEAT_STRB_WIDTH] = '0; 
            else 
               mask_ram_write_en[L2_BEAT_STRB_WIDTH+:L2_BEAT_STRB_WIDTH] = '0;
            mask_ram_write_data = '0;
            data_ram_write_valid = 1'b1;
            data_ram_write_data = request_stage3_rec.wdata; 
            if (request_stage3_rec.initial_mask) begin
               data_ram_write_en = request_stage3_rec.wstrb;
            end
            else begin
               data_ram_write_en = '0;
            end
         end
         default: begin     // no operation for other instruction at stage3
         end
      endcase
   end
end

assign rctrl_align_rec.data = data_ram_readout_data;
assign rctrl_align_rec.axid = request_stage2_rec.axid;
assign rctrl_align_rec.last = request_stage2_rec.last;


assign request_stage2_wstrb = request_stage2_rec.beat[0] ? mask_ram_readout_data[L2_BEAT_STRB_WIDTH+:L2_BEAT_STRB_WIDTH] : mask_ram_readout_data[0+:L2_BEAT_STRB_WIDTH];

generate 
   for (genvar bytes = 0; bytes < L2_BEAT_STRB_WIDTH; bytes ++) begin: g_merge_write_and_cacheline_data
      always_comb begin
         if(request_stage2_rec.instruction == PREFETCH)
            merged_wb_data[bytes*8+:8] = request_stage2_rec.wdata[bytes*8+:8];
         else
            merged_wb_data[bytes*8+:8] = isched_rctrl_wdata_rec.strb[bytes] ? isched_rctrl_wdata_rec.data[bytes*8+:8] : data_ram_readout_data[bytes*8+:8];
      end
   end
endgenerate

// rctrl to wdc WB data 
always_comb begin
    if(request_stage2_rec.instruction == WB_WR) begin
        if(request_stage2_rec.initial_mask)
            rctrl_wdc_fifo_data_rec.strb = isched_rctrl_wdata_rec.strb | request_stage2_wstrb;   // merge request strb and mask ram strb
        else
            rctrl_wdc_fifo_data_rec.strb = isched_rctrl_wdata_rec.strb;      // request strb only
    end
    else if(request_stage2_rec.instruction == WB) begin
        if(request_stage2_rec.initial_mask)
            rctrl_wdc_fifo_data_rec.strb = request_stage2_wstrb;             // mask ram strb only
        else
            rctrl_wdc_fifo_data_rec.strb = 'b0;                              // write with strb is all 0
    end
    else begin  // FLUSH
        rctrl_wdc_fifo_data_rec.strb = request_stage2_wstrb;
    end
end
    
assign rctrl_wdc_fifo_data_rec.last = request_stage2_rec.last;

generate 
   for (genvar bytes = 0; bytes < L2_BEAT_STRB_WIDTH ; bytes++) begin
        assign rctrl_wdc_fifo_data_rec.data[bytes*8 +: 8] = rctrl_wdc_fifo_data_rec.strb[bytes] ? (request_stage2_rec.instruction == WB_WR ? merged_wb_data[bytes*8 +: 8] : data_ram_readout_data[bytes*8 +: 8]) : 'b0;
   end
endgenerate

gpc_gfx_rpfifo_ #(
    .w                  (RC_WB_FIFO_WIDTH       ),
    .d                  (RC_WB_FIFO_DEPTH       ),
    .registered_enable  (1                      ) 
) i_rc_wb_data_fifo (
    .clk                (clk                                                                                        ),  // I
    .resetn             (resetn                                                                                     ),  // I
    .fifo_in_valid      (rctrl_wdc_fifo_valid                                                                       ),  // I
    .fifo_in_enable     (rctrl_wdc_fifo_ready                                                                       ),  // O
    .fifo_in_data       ({rctrl_wdc_fifo_data_rec.data, rctrl_wdc_fifo_data_rec.strb, rctrl_wdc_fifo_data_rec.last} ),  // I
    .fifo_out_valid     (rctrl_wdc_valid                                                                            ),  // O
    .fifo_out_enable    (rctrl_wdc_ready                                                                            ),  // I
    .fifo_out_data      ({rctrl_wdc_data_rec.data     , rctrl_wdc_data_rec.strb     , rctrl_wdc_data_rec.last     } )   // O
);

// synopsys translate_off
assign rctrl_wdc_fifo_data_rec.set   = request_stage2_rec.set ;
assign rctrl_wdc_fifo_data_rec.way   = request_stage2_rec.way ;
assign rctrl_wdc_fifo_data_rec.beat  = request_stage2_rec.beat;
assign rctrl_wdc_fifo_data_rec.axid  = request_stage2_rec.axid;


gpc_gfx_rpfifo_ #(
    .w                  (RC_WB_FIFO_DBG_WIDTH   ),
    .d                  (RC_WB_FIFO_DEPTH       ),
    .registered_enable  (1                      ) 
) i_rc_wb_data_dbg_fifo (
    .clk                (clk                                                                                        ),  // I
    .resetn             (resetn                                                                                     ),  // I
    .fifo_in_valid      (rctrl_wdc_fifo_valid                                                                       ),  // I
    .fifo_in_enable     (                                                                                           ),  // O
    .fifo_in_data       ({rctrl_wdc_fifo_data_rec.set, rctrl_wdc_fifo_data_rec.way, rctrl_wdc_fifo_data_rec.beat, rctrl_wdc_fifo_data_rec.axid} ),  // I
    .fifo_out_valid     (                                                                                           ),  // O
    .fifo_out_enable    (rctrl_wdc_ready                                                                            ),  // I
    .fifo_out_data      ({rctrl_wdc_data_rec.set     , rctrl_wdc_data_rec.way     , rctrl_wdc_data_rec.beat     , rctrl_wdc_data_rec.axid     } )   // O
);

// synopsys translate_on


// rctrl to tagctrl/isched complete
assign rctrl_inst_cmpl_en              = request_stage2_sync_valid && request_stage2_sync_ready && 
                                         request_stage2_rec.last   && ~request_stage2_rec.is_buffer_mode;
assign rctrl_isched_valid_tb           = rctrl_inst_cmpl_en && 
                                        (request_stage2_rec.instruction == WB    | request_stage2_rec.instruction == PREFETCH | 
                                         request_stage2_rec.instruction == WB_WR | request_stage2_rec.instruction == FLUSH);
assign rctrl_isched_rec_tb.set         = request_stage2_rec.set;
assign rctrl_isched_rec_tb.way         = request_stage2_rec.way;
assign rctrl_isched_rec_tb.sector_mask = request_stage2_rec.sector_mask;
assign rctrl_isched_rec_tb.lf_or_wb    = (request_stage2_rec.instruction == PREFETCH);


assign rctrl_tagctrl_valid_tb =  rctrl_inst_cmpl_en &&
                                (request_stage2_rec.instruction == RD | request_stage2_rec.instruction == WR | 
                                 request_stage2_rec.instruction == AA);
assign rctrl_tagctrl_rec_tb.set = request_stage2_rec.set;
assign rctrl_tagctrl_rec_tb.way = request_stage2_rec.way;

gpc_gfx_timing_buffer_vonly_ #(
    .BUFFER_TYPE (GPC_GFX_TIMING_BUFFER_PIPE_REG    ),
    .WIDTH       ($size(rctrl_isched_rec)           )
) i_tb_rctrl_isched (
    .clk             (clk                           ),
    .resetn          (resetn                        ),
    .tbuff_in_valid  (rctrl_isched_valid_tb         ),
    .tbuff_in_data   (rctrl_isched_rec_tb           ),
    .tbuff_out_valid (rctrl_isched_valid            ),
    .tbuff_out_data  (rctrl_isched_rec              )
);

gpc_gfx_timing_buffer_vonly_ #(
    .BUFFER_TYPE (GPC_GFX_TIMING_BUFFER_PIPE_REG    ),
    .WIDTH       ($size(rctrl_tagctrl_rec)          )
) i_tb_rctrl_tagctrl (
    .clk             (clk                           ),
    .resetn          (resetn                        ),
    .tbuff_in_valid  (rctrl_tagctrl_valid_tb        ),
    .tbuff_in_data   (rctrl_tagctrl_rec_tb          ),
    .tbuff_out_valid (rctrl_tagctrl_valid           ),
    .tbuff_out_data  (rctrl_tagctrl_rec             )
);


assign aa_enable        = request_stage2_sync_valid & request_stage2_sync_ready & (request_stage2_rec.instruction == AA);
assign aa_wrap          = aa_enable ? isched_rctrl_wdata_rec.strb[23]       : 'b0;
assign aa_len           = aa_enable ? isched_rctrl_wdata_rec.strb[21 +:  2] : 'b0;
assign aa_operation     = aa_enable ? isched_rctrl_wdata_rec.strb[16 +:  5] : 'b0;
assign org_dword_active = aa_enable ? isched_rctrl_wdata_rec.strb[ 0 +: 16] : 'b0;
assign operand_a        = aa_enable ? isched_rctrl_wdata_rec.data           : 'b0;
assign source_data      = aa_enable ? data_ram_readout_data                 : 'b0;

gc_l2_bank_alu_wrap i_gc_l2_bank_alu_wrap(
    .clk            (clk            ),  // I
    .resetn         (resetn         ),  // I
    .enable         (aa_enable      ),  // I
    .aa_len         (aa_len         ),  // I, 0-32, 1-64, 2-128
    .aa_operation   (aa_operation   ),  // I
    .dword_active   (dword_active   ),  // I
    .source_data    (source_data    ),  // I
    .operand_a      (operand_a      ),  // I
    .aa_result      (aa_result      ),  // O
    .aa_result_fp32 (aa_result_fp32 ),  // O, add for timing optimization
    .aa_result_strb (aa_result_strb ),  // O, active high
    .flush_en       (gc_cr_cu_lms_fp32_denormal_en)    // I
);

always_comb begin: p_dword_active
    if((aa_operation == L2_AA_OP_CMPXCHG) || (aa_operation == L2_AA_OP_FCMPXCHG)) begin
        if(aa_wrap) begin
            if(aa_len == L2_AA_SIZE_32) begin
                for(int i=0; i<L2_BEAT_WIDTH/32/2; i++) begin
                dword_active[i*2 +: 2] = org_dword_active[i*2 +: 2] & (org_dword_active[i*2 +: 2]<<1);
                end
            end
            else if(aa_len == L2_AA_SIZE_64) begin
                for(int i=0; i<L2_BEAT_WIDTH/32/4; i++) begin
                dword_active[i*4 +: 4] = org_dword_active[i*4 +: 4] & (org_dword_active[i*4 +: 4]<<2);
                end
            end
            else begin
                for(int i=0; i<L2_BEAT_WIDTH/32/8; i++) begin
                dword_active[i*8 +: 8] = org_dword_active[i*8 +: 8] & (org_dword_active[i*8 +: 8]<<4);
                end
            end
        end
        else begin
            if(aa_len == L2_AA_SIZE_32) begin
                for(int i=0; i<L2_BEAT_WIDTH/32/2; i++) begin
                dword_active[i*2 +: 2] = org_dword_active[i*2 +: 2] & (org_dword_active[i*2 +: 2]>>1);
                end
            end
            else if(aa_len == L2_AA_SIZE_64) begin
                for(int i=0; i<L2_BEAT_WIDTH/32/4; i++) begin
                dword_active[i*4 +: 4] = org_dword_active[i*4 +: 4] & (org_dword_active[i*4 +: 4]>>2);
                end
            end
            else begin
                for(int i=0; i<L2_BEAT_WIDTH/32/8; i++) begin
                dword_active[i*8 +: 8] = org_dword_active[i*8 +: 8] & (org_dword_active[i*8 +: 8]>>4);
                end
            end
        end
    end
    else begin
        dword_active = org_dword_active;
    end
end: p_dword_active


assign l2_rctrl_idle = ~(request_stage0_valid | request_stage1_valid | request_stage2_valid | request_stage3_valid |
                         rctrl_wdc_fifo_valid | rctrl_wdc_valid) & mask_ram_pipe_idle & data_ram_pipe_idle;

// -------------------------------------------------------------------------------------------------
// performance counter
// -------------------------------------------------------------------------------------------------
assign l2b_ramctrl_reqarb_wl            = isched_rctrl_valid   &  isched_rctrl_ready ;
// assign l2b_ramctrl_reqarb_stall_by_sram = request_stage0_valid & ~no_raw_ram_hazard  ;
assign l2b_ramctrl_reqarb_stall_by_sram = request_stage0_valid & ~request_stage0_ready & (~request_stage1_valid | request_stage1_ready);  // stage0 stall but no downstream stall, stage0 stall because raw hazard or RAM read/write conflict
assign l2b_ramctrl_data_sram_read_wl    = data_ram_read_valid  &  data_ram_read_ready;
assign l2b_ramctrl_data_sram_write_wl   = data_ram_write_valid ;

// -------------------------------------------------------------------------------------------------
// assertions
// -------------------------------------------------------------------------------------------------
// synopsys translate_off
// property wdata_sync_check(wdata_sync_en, request_stage2_rec, isched_rctrl_wdata_rec);
//     disable iff(!resetn)
//     @(posedge clk) (wdata_sync_en) |-> ((request_stage2_rec.set  == isched_rctrl_wdata_rec.set ) &&
//                                         (request_stage2_rec.way  == isched_rctrl_wdata_rec.way ) &&
//                                         (request_stage2_rec.beat == isched_rctrl_wdata_rec.beat) &&
//                                         (request_stage2_rec.axid == isched_rctrl_wdata_rec.axid) );
// endproperty

logic               wdata_sync_en;
logic [L2_AXI_ID_WIDTH+L2_NUM_SET_BITS+L2_NUM_WAY_BITS+2-1  : 0] request_stage2_rec_sb;
logic [L2_AXI_ID_WIDTH+L2_NUM_SET_BITS+L2_NUM_WAY_BITS+2-1  : 0] isched_rctrl_wdata_sb;
logic               isched_rctrl_sync_req;
logic   [31:0]      isched_rctrl_sreq_cnt;
logic   [31:0]      isched_rctrl_data_cnt;

assign wdata_sync_en = request_stage2_sync_valid & request_stage2_sync_ready & request_stage2_sync_en;
assign request_stage2_rec_sb = {request_stage2_rec.set, request_stage2_rec.way, request_stage2_rec.beat, request_stage2_rec.axid};
assign isched_rctrl_wdata_sb = {isched_rctrl_wdata_rec.set, isched_rctrl_wdata_rec.way, isched_rctrl_wdata_rec.beat, isched_rctrl_wdata_rec.axid};
property wdata_sync_check(wdata_sync_en, request_stage2_rec_sb, isched_rctrl_wdata_sb);
    disable iff(!resetn)
    @(posedge clk) (wdata_sync_en) |-> (request_stage2_rec_sb == isched_rctrl_wdata_sb);
endproperty
a_wdata_sync_check : assert property(wdata_sync_check(wdata_sync_en, request_stage2_rec_sb, isched_rctrl_wdata_sb))
                     else $error("ishced_rctrl write data sync sideband information mismatch");

// the number of sync request and data check
assign isched_rctrl_sync_req = (isched_rctrl_instr_rec.instruction == WR) || (isched_rctrl_instr_rec.instruction == AA) || 
                               (isched_rctrl_instr_rec.instruction == WB_WR);
always_ff @(posedge clk or negedge resetn) begin
    if(!resetn) begin
        isched_rctrl_sreq_cnt   <= 'b0;
        isched_rctrl_data_cnt   <= 'b0;
    end
    else begin
        if(isched_rctrl_valid & isched_rctrl_ready & isched_rctrl_sync_req)
            isched_rctrl_sreq_cnt   <= isched_rctrl_sreq_cnt + 1'b1;
        if(isched_rctrl_wdata_valid & isched_rctrl_wdata_ready)
            isched_rctrl_data_cnt   <= isched_rctrl_data_cnt + 1'b1;
    end
end

property init_mask_check(valid, cl_inst, initial_mask);
    disable iff(!resetn)
    @(posedge clk) (valid && ((cl_inst == RD) || (cl_inst == AA) || (cl_inst == FLUSH))) |-> initial_mask;
endproperty

a_init_mask_check  : assert property(init_mask_check(isched_pipeline_instr_valid, isched_pipeline_instr_rec.instruction, isched_pipeline_instr_rec.initial_mask))
                     else $error("illegal initial_mask for current cacheline instruction");

// counter for number of invalid write
logic               all_write;
logic               invalid_write;
logic   [31:0]      invalid_write_cnt;
logic   [31:0]      all_write_cnt;

assign all_write     = rctrl_wdc_valid & rctrl_wdc_ready;
assign invalid_write = rctrl_wdc_valid & rctrl_wdc_ready & (~|rctrl_wdc_data_rec.strb);

always_ff @(posedge clk or negedge resetn) begin
    if(!resetn) begin
        all_write_cnt     <= 'b0;
        invalid_write_cnt <= 'b0;
    end
    else begin 
        if(all_write)
            all_write_cnt     <= all_write_cnt + 1'b1;
        if(invalid_write)
            invalid_write_cnt <= invalid_write_cnt + 1'b1;
    end
end

// set/way conflict check between tagctrl_rctrl_clr_valid, isched_rctrl_valid, memif_rctrl_valid
logic       init_mask_cft_check_en;

assign init_mask_cft_check_en = arbiter_valid & arbiter_ready & tagctrl_rctrl_clr_valid;

property set_way_cft_check(valid, set0, way0, set1, way1);
    disable iff(!resetn)
    @(posedge clk) (valid) |-> ((set0 != set1) || (way0 != way1));
endproperty

a_init_mask_set_way_cft_check: assert property(set_way_cft_check(init_mask_cft_check_en, arbiter_rec.set, arbiter_rec.way, tagctrl_rctrl_clr_record.set, tagctrl_rctrl_clr_record.way))
                    else $error("isched and tagctrl want to update initial_mask of same set and way");

// request_stage2 mask_ram_readout_valid check
logic request_stage2_need_mask;

assign request_stage2_need_mask = request_stage2_sync_valid &&
                                ((request_stage2_rec.instruction == FLUSH                                      ) ||
                                 (request_stage2_rec.instruction == WB       && request_stage2_rec.initial_mask) ||
                                 (request_stage2_rec.instruction == WB_WR    && request_stage2_rec.initial_mask) ||
                                 (request_stage2_rec.instruction == PREFETCH && request_stage2_rec.initial_mask) );

property req_s2_mask_valid(request_stage2_need_mask, mask_ram_readout_valid);
    disable iff(!resetn)
    @(posedge clk) (request_stage2_need_mask) |-> (mask_ram_readout_valid);
endproperty
a_req_s2_mask_valid_check : assert property(req_s2_mask_valid(request_stage2_need_mask, mask_ram_readout_valid))
                            else $error("mask_ram_readout_valid no set when need it");

final begin
isched_rctrl_sync_check: assert(isched_rctrl_sreq_cnt == isched_rctrl_data_cnt) 
    else $error("the number of sync request and data mismatch");

if(invalid_write_cnt != 'b0)
    $info("L2 performance info: all_write_cnt = %d; invalid_write_cnt = %d", all_write_cnt, invalid_write_cnt);

end

// synopsys translate_on

endmodule

