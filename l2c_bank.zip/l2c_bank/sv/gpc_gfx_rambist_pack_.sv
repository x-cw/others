/*

 * #==========================================================================#
 * |                                                                          |
 * |  Copyright (c) 2023, Fantasy Technologies Limited and/or its         |
 * |  affiliated group companies ("Fantasy"). All rights reserved.        |
 * |  No part of this content, either material or conceptual may be copied    |
 * |  or distributed, transmitted, transcribed, stored in a retrieval system  |
 * |  or translated into any human or computer language in any form by any    |
 * |  means, electronic, mechanical manual, or otherwise, or disclosed to     |
 * |  third parties without the express written permission of Fantasy.    |
 * |                                                                          |
 * #==========================================================================#

 */
package gpc_gfx_rambist_pack_;

   import gpc_gfx_ecc_pkg_::*;
   import gpc_gfx_std_func_pack_::*;
   import gpc_memory_partitioner_pkg_::*;
// ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////-
// entity name: gpc_gfx_rambist_pack
// purpose: Control over RAM's and BIST technology used within the design
// ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////-



   // Set to true in order to dump out a text file with the activity of RAMs within the design
   // NB Warning this has a dramatic affect on simulation runtime
   localparam logic                                         RAM_STATS_ON                             = 0                             ;
   localparam int                                           MEM_ID0                                  = 0                             ;

   // FUNCTIONS USED IN CODE
   
   //returns True if the width and depth of the RAM exceeds the threshold (from gc_memory_partitioner_pkg)

  
   
   // This file contains VHDL functions to define the width for BIST in/out signals.
   // If these functions are being modified, their Verilog counterpart needs to be updated as well.















































































   //
   function automatic int spstore_in;
   input  int                                           w ;
   input  int                                            p ;
   input  int                                            d ;
   input  int                                            ECC ;
      int                                           SINGLE_PART                              = is_single_partition( w , p );
      int                                           NUM_PART                                 = num_protected_region ( w , p , ECC );    // number of protected regions. if ECC /=0, it should be at least N.
      int                                           NUM_SUBPART                              = NUM_PART / ( w / p )          ;
      int                                           SUBPART_WIDTH                            = ( p + NUM_SUBPART - 1 ) / NUM_SUBPART;
      int                                           PP_SIZE                                  = SUBPART_WIDTH * NUM_SUBPART   ;    // Padded partition size
      int                                           PD_WIDTH                                 = PP_SIZE * w / p               ;    // Padded data width.
      int                                           E_RAM_WIDTH                              = calc_ram_width ( PD_WIDTH , SUBPART_WIDTH , ECC );
      int                                           E_RAM_EN_WIDTH                           = calc_wren_width ( PD_WIDTH , SUBPART_WIDTH , ECC , SINGLE_PART);
      return ( 1 + gpc_log2_roundup ( d ) + 1 + E_RAM_WIDTH + E_RAM_EN_WIDTH ) ;    // bist_mode address ram_enable write_data write_enable 
   endfunction // spstore_in

   //
   function automatic int spstore_out;
   input  int                                           w ;
   input  int                                            p ;
   input  int                                            d ;
   input  int                                            ECC ;
      int                                           NUM_PART                                 = num_protected_region ( w , p , ECC );    // number of protected regions. if ECC /=0, it should be at least N.
      int                                           NUM_SUBPART                              = NUM_PART / ( w / p )          ;
      int                                           SUBPART_WIDTH                            = ( p + NUM_SUBPART - 1 ) / NUM_SUBPART;
      int                                           PP_SIZE                                  = SUBPART_WIDTH * NUM_SUBPART   ;    // Padded partition size
      int                                           PD_WIDTH                                 = PP_SIZE * w / p               ;    // Padded data width.
      int                                           E_RAM_WIDTH                              = calc_ram_width ( PD_WIDTH , SUBPART_WIDTH , ECC );
      // output data
      return ( E_RAM_WIDTH ) ;
   endfunction // spstore_out

   //
   function automatic int dpstore_in;
   input  int                                           w ;
   input  int                                            p ;
   input  int                                            d ;
   input  int                                            ECC ;
      int                                           SINGLE_PART                              = is_single_partition( w , p );
      int                                           NUM_PART                                 = num_protected_region ( w , p , ECC );    // number of protected regions. if ECC /=0, it should be at least N.
      int                                           NUM_SUBPART                              = NUM_PART / ( w / p )          ;
      int                                           SUBPART_WIDTH                            = ( p + NUM_SUBPART - 1 ) / NUM_SUBPART;
      int                                           PP_SIZE                                  = SUBPART_WIDTH * NUM_SUBPART   ;    // Padded partition size
      int                                           PD_WIDTH                                 = PP_SIZE * w / p               ;    // Padded data width.
      int                                           E_RAM_WIDTH                              = calc_ram_width ( PD_WIDTH , SUBPART_WIDTH , ECC );
      int                                           E_RAM_EN_WIDTH                           = calc_wren_width ( PD_WIDTH , SUBPART_WIDTH , ECC , SINGLE_PART);
      return ( 1 + gpc_log2_roundup ( d ) + gpc_log2_roundup ( d ) + 1 + E_RAM_WIDTH + E_RAM_EN_WIDTH ) ;    // bist_mode read_address write_address ram_enable write_data write_enable 
   endfunction // dpstore_in

   //
   function automatic int dpstore_out;
   input  int                                           w ;
   input  int                                            p ;
   input  int                                            d ;
   input  int                                            ECC ;
      int                                           NUM_PART                                 = num_protected_region ( w , p , ECC );    // number of protected regions. if ECC /=0, it should be at least N.
      int                                           NUM_SUBPART                              = NUM_PART / ( w / p )          ;
      int                                           SUBPART_WIDTH                            = ( p + NUM_SUBPART - 1 ) / NUM_SUBPART;
      int                                           PP_SIZE                                  = SUBPART_WIDTH * NUM_SUBPART   ;    // Padded partition size
      int                                           PD_WIDTH                                 = PP_SIZE * w / p               ;    // Padded data width.
      int                                           E_RAM_WIDTH                              = calc_ram_width ( PD_WIDTH , SUBPART_WIDTH , ECC );
      // output data
      return ( E_RAM_WIDTH ) ;
   endfunction // dpstore_out


   //returns True if the width and depth of the RAM exceeds the threshold (from gc_memory_partitioner_pkg)
   function automatic logic ram_partitioner_threshold;
   input  int                                           w ;
   input  int                                            d ;
   input  int                                            id ;
      //is the MEM_ID in the list of MEM_IDs to force as Flops?
      for ( int n = 0 ; n <= RG_ID_COUNT - 1 ; n = n + 1 ) begin
         if ( RG_MEM_IDS[n] == id & RG_MEM_IDS[n] != 0 ) begin
            return 0 ;
         end
      end

      //is the MEM_ID in the list of MEM_IDs to force as RAMS?
      for ( int n = 0 ; n <= NO_RG_ID_COUNT - 1 ; n = n + 1 ) begin
         if ( NO_RG_MEM_IDS[n] == id & NO_RG_MEM_IDS[n] != 0 ) begin
            return 1 ;
         end
      end

      //is the total number of bits >= threshold for RAM?      
      return ( w * d ) >= RG_THRESHOLD ;
   endfunction // ram_partitioner_threshold


endpackage
