/*

 * #==========================================================================#
 * |                                                                          |
 * |  Copyright (c) 2022, Fantasy Technologies Limited and/or its         |
 * |  affiliated group companies ("Fantasy"). All rights reserved.        |
 * |  No part of this content, either material or conceptual may be copied    |
 * |  or distributed, transmitted, transcribed, stored in a retrieval system  |
 * |  or translated into any human or computer language in any form by any    |
 * |  means, electronic, mechanical manual, or otherwise, or disclosed to     |
 * |  third parties without the express written permission of Fantasy.    |
 * |                                                                          |
 * #==========================================================================#

 */


// ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////-
// entity name: gpc_gfx_timing_buffer_vonly
// Component Description: IMGLIB3 Generic Timing Buffer for Valid Only interfaces
// Generic Timing Buffer (use BUFFER_TYPE generic to instantiate a wide variety of modules)
//
// For description of each instantiated buffer type check appropriate source file.
//
// ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////-
// BUFFER TYPE     |   AREA COST   | VALID/DATA | ENABLE CHAIN | Comments
// ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////-
// Wire            |     ZERO!     | Same cycle | N/A          | No benefit!
// Simple Pipe reg | W x (FF)      | Delayed    | N/A          | Data registered
// ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////-
//
// Generics:
// BUFFER_TYPE - INTEGER
//             - Buffer Type to introduce - see table above, DEFAULT = 0 = Wire
// WIDTH       - INTEGER
//             - Width of Data bus Input/Output std_logic_vector
//
// Portlist:
// clk               - Clock Input
// resetn            - Active-low asynchronous Reset
// tbuff_in_data     - Data bus input (sized by generic w)
// tbuff_in_valid    - Valid input from upstream module
// tbuff_out_data    - Data bus output (sized by generic w)
// tbuff_out_valid   - Valid output to downstream module
//
// ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////-




module gpc_gfx_timing_buffer_vonly_
#(
      parameter                                          INIT_VALUE                                                   = 0              ,
      parameter int                                      BUFFER_TYPE                                                  = 0              ,
      parameter int                                      WIDTH                                                        = 32              
)
(
      input    logic                                                        clk                                     ,
      input    logic                                                        resetn                                  ,
      // Input V/E Interface
      input    logic                                                        tbuff_in_valid                          ,
      input    logic [ WIDTH - 1 : 0 ]                                      tbuff_in_data                           ,
      // Output V/E Interface
      output   logic                                                        tbuff_out_valid                         ,
      output   logic [ WIDTH - 1 : 0 ]                                      tbuff_out_data                           
);

   import gpc_gfx_timing_buffer_pack_::*;


   // Buffer type 0 : Wire
   if ( BUFFER_TYPE == GPC_GFX_TIMING_BUFFER_WIRE ) begin : g_buffer_type_0

      assign tbuff_out_valid = tbuff_in_valid ;
      assign tbuff_out_data = tbuff_in_data ;


   end // g_buffer_type_0

   // Buffer type 1 : Pipeline register (With combinatorial enable)
   if ( BUFFER_TYPE == GPC_GFX_TIMING_BUFFER_PIPE_REG ) begin : g_buffer_type_1

      if (1) begin : b_pipe_reg

         logic                                         tbuff_out_valid_l                       ;


         always_ff @(posedge clk or negedge resetn) begin : p_pipeline_register_clkdrs
            if ( resetn == 1'b0 ) begin    // COV:tag0
               tbuff_out_valid_l <= 1'b0 ;    // COV:tag0
            end else begin
               tbuff_out_valid_l <= tbuff_in_valid ;    // COV:tag0
            end
         end // p_pipeline_register_clkdrs

         always_ff @(posedge clk) begin : p_pipeline_register_clkd
            begin    // COV:tag0
               if ( tbuff_in_valid == 1'b1 ) begin    // COV:tag1
                  tbuff_out_data <= tbuff_in_data ;    // COV:tag0
               end
            end
         end // p_pipeline_register_clkd

         assign tbuff_out_valid = tbuff_out_valid_l ;

      end // b_pipe_reg

   end // g_buffer_type_1

   // Buffer type 1 : Pipeline register (With combinatorial enable)
   if ( BUFFER_TYPE == GPC_GFX_TIMING_BUFFER_PIPE_REG_INIT ) begin : g_buffer_type_11

      if (1) begin : b_pipe_reg

         logic                                         tbuff_out_valid_l                       ;


         always_ff @(posedge clk or negedge resetn) begin : p_pipeline_register_clkdrs
            if ( resetn == 1'b0 ) begin    // COV:tag0
               tbuff_out_valid_l <= 1'b0 ;    // COV:tag0
            end else begin
               tbuff_out_valid_l <= tbuff_in_valid ;    // COV:tag0
            end
         end // p_pipeline_register_clkdrs

         always_ff @(posedge clk or negedge resetn) begin : p_pipeline_register_clkd
            if ( resetn == 1'b0 ) begin    // COV:tag0
               tbuff_out_data <= INIT_VALUE ;    // COV:tag0
            end else if(tbuff_in_valid) begin
               tbuff_out_data <= tbuff_in_data ;    // COV:tag0
            end
         end // p_pipeline_register_clkd

         assign tbuff_out_valid = tbuff_out_valid_l ;

      end // b_pipe_reg

   end // g_buffer_type_1


endmodule // gpc_gfx_timing_buffer_vonly
