/*

 * #==========================================================================#
 * |                                                                          |
 * |  Copyright (c) 2023, Fantasy Technologies Limited and/or its         |
 * |  affiliated group companies ("Fantasy"). All rights reserved.        |
 * |  No part of this content, either material or conceptual may be copied    |
 * |  or distributed, transmitted, transcribed, stored in a retrieval system  |
 * |  or translated into any human or computer language in any form by any    |
 * |  means, electronic, mechanical manual, or otherwise, or disclosed to     |
 * |  third parties without the express written permission of Fantasy.    |
 * |                                                                          |
 * #==========================================================================#

 */

// ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////-
// entity name: gc_crm
// purpose:
// ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////-

module gc_crm
import gc_clock_gate_pack_::*;
import pkg_crm_::*;
import pkg_rogue4_::*;
#(
   parameter NUM_MODULES   = 1,
   parameter NUM_WAKEUPS   = 2
)
(
    // -----------------------------------------------------------
    // socif_wakeup Interface
    // -----------------------------------------------------------
      input  logic                   socif_wakeup,
    // -----------------------------------------------------------
    // in Interface
    // -----------------------------------------------------------
      input  logic                   in_clk,
      input  logic                   in_resetn,
    // -----------------------------------------------------------
    // out Interface
    // -----------------------------------------------------------
      output logic                   out_clk,
      output logic                   out_resetn,
    // -----------------------------------------------------------
    // in_idle Interface
    // -----------------------------------------------------------
      input  logic                   [ NUM_MODULES-1 : 0 ]  in_idle,
    // -----------------------------------------------------------
    // clk_ctrl Interface
    // -----------------------------------------------------------
      input  logic                   [ 1 : 0 ]  clk_ctrl,
    // -----------------------------------------------------------
    // clk_status Interface
    // -----------------------------------------------------------
      output logic                   clk_status,
    // -----------------------------------------------------------
    // wakeup Interface
    // -----------------------------------------------------------
      input  logic                   [ NUM_WAKEUPS-1-1 : 0 ]  wakeup,
    // -----------------------------------------------------------
    // soft_reset Interface
    // -----------------------------------------------------------
      input  logic                   soft_reset_core,
    // -----------------------------------------------------------
    //  Interface
    // -----------------------------------------------------------
      input  logic                   tst_gclkenable,
    // -----------------------------------------------------------
    //  Interface
    // -----------------------------------------------------------
      input  logic                   tst_rst_bypass,
    // -----------------------------------------------------------
    // pwr_man_hysteresis Interface
    // -----------------------------------------------------------
      input  logic                   [ 4 : 0 ]  pwr_man_hysteresis_value,
    // -----------------------------------------------------------
    // gc_cr_crm_reset_clk Interface
    // -----------------------------------------------------------
      input  logic                   [ 1 : 0 ]  gc_cr_crm_reset_clk_ctrl
);

   logic                         gated_clk_l;
   logic                         domain_clk_l;
   logic                         domain_clk_en_l;
   logic [ NUM_WAKEUPS - 1 : 0 ] wakeups;
   logic                         in_clk_aligned_l;
   logic                         clk_status_l;






































   assign wakeups = {wakeup, socif_wakeup};

   gc_crm_dmctl_
      #(
         .NUM_WAKEUP_SIGNALS              (NUM_WAKEUPS),
         .NUM_IDLE_SIGNALS                (NUM_MODULES)
         )
      i_gc_crm_dmctl
      (
         .core_clk_aligned                (in_clk_aligned_l),
         .domain_clk                      (domain_clk_l),
         .core_resetn                     (in_resetn),
         .gc_cr_pwr_man_hysteresis_value (pwr_man_hysteresis_value),
         .gc_cr_crm_reset_clk_ctrl       (gc_cr_crm_reset_clk_ctrl),
         .soft_reset                      (soft_reset_core),
         .domain_wakeup_events            (wakeups),
         .domain_idles_in                 (in_idle),
         .gc_cr_clk_ctrl_domain          (clk_ctrl),
         .domain_clk_en                   (domain_clk_en_l),
         .gc_cr_clk_status_domain        (clk_status_l)
         );

   gpc2_clock_gate
      #(
         .tiw                             (TIW),
         .tow                             (TOW)
         )
      i_gpc2_clock_gate
      (
         .te                              (tst_gclkenable),
         .cp                              (in_clk),
         .e                               (domain_clk_en_l),
         .q                               (gated_clk_l),
         .tin                             (1'b0),
         .tout                            ()
         );

   gpc_gfx_resetn_ip_async_
      #(
         .sdepth                          (RESYNC_SDEPTH)
         )
      i_resetn_ip_async
      (
         .soft_reset                      (soft_reset_core),
         .ipin_resetn                     (in_resetn),
         .clk                             (in_clk_aligned_l),
         .resetn_sync                     (out_resetn),
         .tst_scan_mode                   (tst_rst_bypass)
         );


   `ifndef GPU_SYNTHESIS
   assign #CLK_ALIGN_DELAY domain_clk_l = gated_clk_l;
   `else 
   assign domain_clk_l = gated_clk_l;
   `endif

   `ifndef GPU_SYNTHESIS
   assign #CLK_ALIGN_DELAY in_clk_aligned_l = in_clk;
   `else 
   assign in_clk_aligned_l = in_clk;
   `endif

   assign out_clk = domain_clk_l;
   assign clk_status = clk_status_l;






endmodule // gc_crm
