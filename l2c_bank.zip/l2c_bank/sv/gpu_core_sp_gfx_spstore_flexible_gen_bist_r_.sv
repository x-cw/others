/*

 * #==========================================================================#
 * |                                                                          |
 * |  Copyright (c) 2022, Fantasy Technologies Limited and/or its         |
 * |  affiliated group companies ("Fantasy"). All rights reserved.        |
 * |  No part of this content, either material or conceptual may be copied    |
 * |  or distributed, transmitted, transcribed, stored in a retrieval system  |
 * |  or translated into any human or computer language in any form by any    |
 * |  means, electronic, mechanical manual, or otherwise, or disclosed to     |
 * |  third parties without the express written permission of Fantasy.    |
 * |                                                                          |
 * #==========================================================================#

 */

// ////////////////////////////////////////////////////////////////////////////-
// entity:  gpu_core_sp_gfx_spstore_flexible_gen_bist_r
//
// purpose: Single port synchronous RAM with configurable write word partitions
//          and back end read register to help achieve timing closure
//
// +////////////////////////-+////-+////-+////////+////////////////+
// | gpc_gfx_spstore_        | RAM | Reg | Bypass | Design         |
// |             w,p,d,log2d | O/P | O/P | Input  | Suitability    |
// +////////////////////////-+////-+////-+////////+////////////////+
// | _.vhd & _novital.vhd    | Yes |     |        | Fundamental    |
// | bist.vhdm               | Yes |     |        | Low level only |
// | gen_bist_r.vhd          |     | Yes |        | Standard use   |
// | pipeline_gen_bist_r.vhd |     | Yes |        | Standard use   |
// | bypass_gen_bist_r.vhd   | Yes | Yes |  Yes   | Standard use   |
// | bpout_gen_bist_r.vhd    | Yes | Yes |        | Standard use   |
// | flexible_gen_bist_r.vhd | Yes | Yes |  Yes   | Standard use   |<<<
// +////////////////////////-+////-+////-+////////+////////////////+
//
// hierarchy: This is an RTL designer's standard component
//
//        gpu_core_sp_gfx_spstore_flexible_gen_bist_r   << YOU ARE HERE
//         |
//         +- gpc_gfx_spstore_bist
//             |
//             +- gpc_gfx_spstore
//             |
//             +- [ gpc_gfx_bistwrap_sing ]
//
// ////////////////////////////////////////////////////////////////////////////-

// DIMENSIONS
//   Physical generics: w, d, p, log2d
//
//                        width
//              <////////// w //////////>
//
//              +//////////////////////-+   ^
//              |_______________________|   |
//              |_______________________|   |  d
//              |_______________________|      e
//              |                       |   d  p
//              |                       |      t
//              :                       :   |  h
//              |                       |   |
//              +//////////////////////-+   v
//                         w/p *
//              <- p -><- p -> .. <- p ->
//                      partitions
//
//   All partitions are equal in size. In other words, the generic w is an
//   integer multiple of generic p.
//
//   Example partition:
//      [w = 128, p = 32] => w/p = 4 partitions => 4 write enables

// PORTS
//   +////////////////////////////////////////////////////////////+
//   | name          |  bits  |dir| description                   |
//   +////////////////////////////////////////////////////////////+
//   | addr          | log2d  | i | address                       |
//   | c_en          |   1    | i | chip enable (ACTIVE LOW)      |
//   | rd_en         |   1    | i | read enable (ACTIVE LOW)      |
//   | ram_data      |   w    | o | read data out of RAM macro    |
//   | rd_data       |   w    | o | read data off register        |
//   | rd_data_cken  |   1    | i | read register clock enable    |
//   | bypass_load   |  w/p   | i | bypass data partition enables |
//   | bypass_data   |   w    | i | bypass data ((w/p)*p bits)    |
//   |               |        |   |                               |
//   | wr_data       |   w    | i | write data ((w/p)*p bits)     |
//   | wr_en         |  w/p   | i | write enables (ACTIVE LOW)    |
//   |               |        |   |                               |
//   | clk           |   1    | i | common r/w clock              |
//   | resetn        |   1    | i | reset to BIST (ACTIVE LOW)    |
//   |               |        |   |                               |
//   | bist_in       |f(w,p,d)| i | input from BIST controller    |
//   | bist_out      |f(w,p,d)| o | result to BIST controller     |
//   +////////////////////////////////////////////////////////////+

// BEHAVIOURIAL MODEL
//   Functional behaviour is similar to gpc_gfx_spstore_bist but this hierarchical
//   level adds a back end read data register for timing purposes. The back end
//   register also takes bypass data. This can be used where writethrough
//   transparency is required.
//
//   Read latency:   2 clocks (1 if using ram_data)
//   Write latency:  1 clock
//   Bypass latency: 1 clock
//
//   rd_data_cken //////////////////////////////////////////-.
//   bypass_load ///////////////////////////////////////////.|
//   bypass_data ///////////////////////////////////////.   ||
//                +//////////////////////////////////-+ |   ||
//                |      gpc_gfx_spstore_bist         | |   ||
//                |                                   | |   ||
//                |  +////////////////////////////-+  | |   ||
//                |  |     gpc_gfx_spstore         |  | |   ||
//                |  |                          dly|  | /   /|
//   c_en, rd_en//|//|////-*//////////////////-*-%-|//|-|//.||
//   addr    /////|//|-*//-|/////////////////-.|   |  | |  |||
//                |  | |   |                  ||   |  | | +//-+
//                |  | | +////+   +////-+   +////+ |  | '-|1  | +////+
//                |  | '-| wr |   |     |   | rd | |  |   |   |_|    |
//   wr_en   /////|//|//-|proc|-/-| mem |-/-|proc|-|//|-*-|0  | |    |///->
//   wr_data /////|//|//-|    |   |     |   |    | |  | | +//-+ |    |  rd_data
//                |  |   |    |  +|>    |  +|>   | |  | |      +|>   |
//                |  |   +////+  |+////-+  |+////+ |  | |      |+////+
//                |  |           |         |       |  | '//////|/////////->
//   clk     ////-|//|//////////-*////////-*//////-|//|////////'       ram_data
//                |  +////////////////////////////-+  |
//                |  +////////////////////////////-+  |
//                |  |                             |  |
//   bist_in /////|//|  [ gpc_gfx_bistwrap_sing ]  |//|/////////////-> bist_out
//   resetn  ////-|//|                             |  |
//                |  +////////////////////////////-+  |
//                +//////////////////////////////////-+
//
//   Notes:
//   + Writes require wr_en and c_en both to be asserted (low)
//   + Reads require rd_en, c_en to be asserted (low) and wr_en inactive (high)

// OPTIONAL BEHAVIOUR GENERIC
//   bypass_requires_cken : used to define whether the bypass_load input only takes effect
//                          when the rd_data_cken pin is high (default 1)

// OPTIONAL UTILITY GENERIC
//   id : integer value that can be assigned to each instance (default 0)
//                                                                      -=:PB=-
// ////////////////////////////////////////////////////////////////////////////-

module gpu_core_sp_gfx_spstore_flexible_gen_bist_r_
   import gpc_gfx_rambist_pack_::*;
#(
      parameter int                                      w                                                            = 0              ,
      parameter int                                      p                                                            = 0              ,
      parameter int                                      d                                                            = 0              ,
      parameter int                                      log2d                                                        = 0              ,
      parameter int                                      ECC                                                          = 0              ,    // ECC enable : 0=disable ECC; 1=enable ECC



      parameter int                                      id                                                           = 0              ,    // unique value per instance
      parameter int                                      bypass_requires_cken                                         = 1              ,
      parameter logic                                    write_skid                                                   = 1'b0                // write-triggered skid enable 
)
(
      input    logic                                                        clk                                     ,
      input    logic                                                        resetn                                  ,
      // read/write port
      input    logic                                                        c_en                                    ,
      input    logic [ ( w / p ) - 1 : 0 ]                                  wr_en                                   ,
      input    logic                                                        rd_en                                   ,
      input    logic [ log2d - 1 : 0 ]                                      addr                                    ,
      input    logic [ w - 1 : 0 ]                                          wr_data                                 ,
      // unregistered output
      output   logic [ w - 1 : 0 ]                                          ram_data                                ,
      // registered output and associated controls
      input    logic [ ( w / p ) - 1 : 0 ]                                  bypass_load                             ,
      input    logic [ w - 1 : 0 ]                                          bypass_data                             ,
      input    logic                                                        rd_data_cken                            ,    // clk enable on rd_data register
      output   logic [ w - 1 : 0 ]                                          rd_data                                 ,
      // bist signals






      input    logic [ spstore_in ( w , p , d , ECC ) - 1 : 0 ]             bist_in                                 ,
      output   logic [ spstore_out ( w , p , d , ECC ) - 1 : 0 ]            bist_out                                ,
      input    logic                                                        tst_gclkenable                            
);








   logic [ ( w / p ) - 1 : 0 ]                   rd_en_r                                 ;
   logic [ w - 1 : 0 ]                           rd_data_ram                             ;
   logic [ w - 1 : 0 ]                           rd_data_ram_r                           ;
   // Write-triggered skid signals
   logic                                         rd_wr_skid                              ;
   // Global skid signals
   logic                                         gated_c_en                              ;
   logic [ w - 1 : 0 ]                           rd_data_mux                             ;

   ///////////////////////////////////////////////
   // backdoor access
   ///////////////////////////////////////////////




   ///////////////////////////////////////////////
   ///////////////////////////////////////////////
   // END backdoor access
   ///////////////////////////////////////////////

   gpu_core_sp_gfx_spstore_wrap_
      #(
         .w                               (w)                                          ,
         .p                               (p)                                          ,
         .d                               (d)                                          ,
         .log2d                           (log2d)                                      ,
         .ECC                             (ECC)                                        ,



         .id                              (id)                                          
         )
      i_gpu_core_sp_gfx_spstore_wrap
      (
         .clk                             (clk)                                        ,
         .resetn                          (resetn)                                     ,
         .c_en                            (gated_c_en)                                 ,
         .wr_en                           (wr_en)                                      ,
         .addr                            (addr)                                       ,
         .wr_data                         (wr_data)                                    ,
         .rd_data_ram                     (rd_data_ram)                                ,






         .bist_in                         (bist_in)                                    ,
         .bist_out                        (bist_out)                                   ,
         .tst_gclkenable                  (tst_gclkenable)                               
         );

   always_ff @(posedge clk or negedge resetn) begin
      if ( resetn == 1'b0 ) begin
         rd_en_r <= '1 ;
      end else begin
         if ( c_en == 1'b0 & ( | wr_en ) == 1'b1 ) begin    // COV:tag1
            rd_en_r <= ( ~ wr_en ) | ( { ( ( w / p ) - 1 - 0 + 1 ) { rd_en } } ) ;
         end else if ( ( & rd_en_r ) != 1'b1 & rd_data_cken == 1'b1 ) begin    // changed from = '0' to handle 'U' and 'X' values when running X Prop COV:tag6
            rd_en_r <= '1 ;
         end
      end
   end



   // //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
   // Start of skid register additions
   // //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
   // chip enable is active low and rd_wr_skid is active high
   assign gated_c_en = c_en | rd_wr_skid ;    // COV:tag2


   // if skids are active, generate skid registers (write triggered)
   if ( ( write_skid == 1'b1 ) ) begin : g_write_skid

      logic                                         read_en                                 ;
      logic                                         full_write                              ;
      logic                                         masked_write                            ;
      logic [ w - 1 : 0 ]                           data_wr_skid                            ;
      logic [ log2d - 1 : 0 ]                       addr_wr_skid                            ;
      logic                                         valid_wr_skid                           ;
      logic                                         rd_wr_skid_r                            ;


      // asserted when read is performed
      always_comb begin : p_read_en
         if ( ( ( ( & wr_en ) == 1'b1 ) & ( c_en == 1'b0 ) ) ) begin    // COV:tag7
            read_en = 1'b1 ;
         end else begin
            read_en = 1'b0 ;
         end
      end // p_read_en


      // asserted when full write is performed
      always_comb begin : p_full_write
         if ( ( ( ( | wr_en ) == 1'b0 ) & ( c_en == 1'b0 ) ) ) begin    // COV:tag7
            full_write = 1'b1 ;
         end else begin
            full_write = 1'b0 ;
         end
      end // p_full_write


      // asserted when masked write is performed
      always_comb begin : p_masked_write
         if ( ( ( full_write == 1'b0 ) & ( ( & wr_en ) == 1'b0 ) ) ) begin    // COV:tag7
            masked_write = 1'b1 ;
         end else begin
            masked_write = 1'b0 ;
         end
      end // p_masked_write


      // skid registers
      always_ff @(posedge clk or negedge resetn) begin : p_wr_skid
         if ( ( resetn == 1'b0 ) ) begin
            data_wr_skid <= '0 ;
            addr_wr_skid <= '0 ;

         end else begin
            if ( ( full_write == 1'b1 ) ) begin
               data_wr_skid <= wr_data ;
               addr_wr_skid <= addr ;
            end
         end
      end // p_wr_skid


      // valid skid register
      always_ff @(posedge clk or negedge resetn) begin : p_valid_wr_skid
         if ( ( resetn == 1'b0 ) ) begin
            valid_wr_skid <= 1'b0 ;

         end else begin
            if ( ( full_write == 1'b1 ) ) begin
               valid_wr_skid <= 1'b1 ;

            end else if ( ( ( masked_write == 1'b1 ) & ( addr == addr_wr_skid ) ) ) begin    // COV:tag7
               valid_wr_skid <= 1'b0 ;
            end
         end
      end // p_valid_wr_skid


      // signal is asserted when skid contains valid data and read is performed
      always_comb begin : p_rd_wr_skid
         if ( ( ( addr == addr_wr_skid ) & ( valid_wr_skid == 1'b1 ) & ( read_en == 1'b1 ) ) ) begin    // COV:tag7
            rd_wr_skid = 1'b1 ;
         end else begin
            rd_wr_skid = 1'b0 ;
         end
      end // p_rd_wr_skid


      // registered rd_wr_skid signal required for timing
      always_ff @(posedge clk or negedge resetn) begin : p_rd_wr_skid_r
         if ( resetn == 1'b0 ) begin
            rd_wr_skid_r <= 1'b0 ;
         end else begin
            if ( ( ( rd_wr_skid_r != rd_wr_skid ) & ( c_en == 1'b0 ) ) ) begin    // COV:tag7
               rd_wr_skid_r <= rd_wr_skid ;
            end
         end
      end // p_rd_wr_skid_r


      // read data multiplexer
   always_comb begin
      rd_data_mux = ( rd_wr_skid_r == 1'b1 ) ? data_wr_skid : rd_data_ram  ;    // COV:tag7


   end // always
   end // g_write_skid



   if ( ( write_skid == 1'b0 ) ) begin : g_no_write_skid

      assign rd_wr_skid = 1'b0 ;
      assign rd_data_mux = rd_data_ram ;

   end // g_no_write_skid
   // //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
   // End of skid register additions
   // //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

   // //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
   // Register the Ram Data for timing
   // This variant includes the following features:
   // 1) A bypass interface to optionally register alternative data via a mux
   // 2) A clock enable signal which can be used to avoid clocking the output register leaving it unchanged.
   //    Care must be taken when this happens to ensure any RAM accesses currently in progress are not lost
   //    ie any reads need to be issued again
   // //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
   genvar i;
   for (  i = ( w / p ) - 1 ; i >= 0 ; i = i - 1 ) begin : p_qa_i

      if ( bypass_requires_cken == 1 ) begin : g_bypass_requires_cken

         always_ff @(posedge clk) begin
            begin
               if ( ( bypass_load [ i ] == 1'b1 | rd_en_r [ i ] == 1'b0 ) & rd_data_cken == 1'b1 ) begin    // COV:tag4
                  if ( bypass_load [ i ] == 1'b1 ) begin
                     rd_data_ram_r [ ( i + 1 ) * p - 1 : i * p ] <= bypass_data [ ( i + 1 ) * p - 1 : i * p ] ;
                  end else begin
                     rd_data_ram_r [ ( i + 1 ) * p - 1 : i * p ] <= rd_data_mux [ ( i + 1 ) * p - 1 : i * p ] ;
                  end
               end
            end
         end

      end // g_bypass_requires_cken

      if ( bypass_requires_cken == 0 ) begin : g_bypass_overrides_cken

         always_ff @(posedge clk) begin
            begin
               if ( bypass_load [ i ] == 1'b1 | ( rd_en_r [ i ] == 1'b0 & rd_data_cken == 1'b1 ) ) begin    // COV:tag5
                  if ( bypass_load [ i ] == 1'b1 ) begin
                     rd_data_ram_r [ ( i + 1 ) * p - 1 : i * p ] <= bypass_data [ ( i + 1 ) * p - 1 : i * p ] ;
                  end else begin
                     rd_data_ram_r [ ( i + 1 ) * p - 1 : i * p ] <= rd_data_mux [ ( i + 1 ) * p - 1 : i * p ] ;
                  end
               end
            end
         end

      end // g_bypass_overrides_cken

   end // p_qa_i

   assign rd_data = rd_data_ram_r ;

   // //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
   // Feed data direct from RAM to optional output port
   // //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
   // Anything using this output in addition to the standard flops should register the data immediately or after minimal logic

   assign ram_data = rd_data_mux ;


endmodule // gpu_core_sp_gfx_spstore_flexible_gen_bist_r

