// Author: jinjifang
// Date: 2024/1/5
// Description: the flip-flop with reset and enable

module gc_lib_reg_en_rst(/*AUTOARG*/
   // Outputs
   q,
   // Inputs
   clk, resetn, d, en
   );

   parameter      WIDTH = 1;
   parameter      INIT = {WIDTH{1'b0}};

   input wire                    clk;
   input wire                    resetn;

   input wire [WIDTH-1:0]        d;
   input wire                    en;
   output reg [WIDTH-1:0]        q;

   always @(posedge clk or negedge resetn) begin
      if(!resetn)
         q <= INIT;
      else if(en)
         q <= d;
   end

endmodule

