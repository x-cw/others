// ---------------------------------------------------------------------------------
// Project Name  : IC_Design
// Author        : liusm
// Email         : liusm@innosilicon.com.cn
// Create On     : 2025/02/25 14:04
// Last Modified : 2025/02/25 17:43
// File Name     : gc_l2_bank_onehot_select.sv
// Description   :
// 
// Copyright (c) 2025 Innosilicon.
// ALL RIGHTS RESERVED
// 
// ---------------------------------------------------------------------------------
// Modification History:
// Date         By              Version                 Change Description
// ---------------------------------------------------------------------------------
// 2025/02/25   liusm           1.0                     Original
// 
// ----------------------------------------------------------------------------------


module gc_l2_bank_onehot_select
#(
   parameter MASK_WIDTH = 256,
   parameter DIMENSION2 = 8,
   parameter DIMENSION3 = 3      )
(
   input    logic [MASK_WIDTH-1:0]                                      mask
,  input    logic [MASK_WIDTH-1:0][DIMENSION2-1:0][DIMENSION3-1:0]      recs 
,  output   logic [DIMENSION2-1:0][DIMENSION3-1:0]                      result
);



logic [MASK_WIDTH-1:0][DIMENSION2-1:0][DIMENSION3-1:0] tmp;
logic [DIMENSION2-1:0][DIMENSION3-1:0][MASK_WIDTH-1:0] reverse;

generate
   for (genvar index2 = 0; index2 < DIMENSION2; index2++) begin:g_mask_out_per_dimension2
      for (genvar index = 0; index < MASK_WIDTH; index++) begin: g_mask_out_per_bit
         
         assign tmp[index][index2] = {{DIMENSION3{mask[index]}} & recs[index][index2]};

         for (genvar width = 0; width < DIMENSION3; width ++) begin: g_revers_result
            assign reverse[index2][width][index] = tmp[index][index2][width];
         end

      end
   end
endgenerate

generate
   for (genvar width = 0; width < DIMENSION3; width++) begin: g_or_reduece_per_dimension3
      for (genvar index2 = 0; index2 < DIMENSION2; index2++) begin: g_or_reduece_per_dimension2
         assign result[index2][width] = |reverse[index2][width] ;
      end
   end
endgenerate





endmodule
// Local Variables:
// verilog-library-directories:("./" ) 
// End:
