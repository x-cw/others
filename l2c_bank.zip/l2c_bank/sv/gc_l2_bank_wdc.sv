// +FHDR----------------------------------------------------------------------------
// Copyright (c) 2025, Innosilicon, Inc. Confidential Proprietary
// PROJECT NAME  : xxx
// DEPARTMENT    : Digtal Frontend SOC
// AUTHOR        : luoml01
// EMAIL         : luoml01@innosilicon.com.cn
// CREATE ON     : 2025/01/07 10:43
// FILE NAME     : gc_l2_bank_wdc.sv
// DESCRIPTION   :          
//         
// Copyright (c) 2025 Innosilicon.
// ALL RIGHTS RESERVED
// 
// ---------------------------------------------------------------------------------
// Modification History:
// Date         By              Version                 Change Description
// ---------------------------------------------------------------------------------
// 2025/01/07   luoml01         1.0                     Original
// 
// -FHDR----------------------------------------------------------------------------


module gc_l2_bank_wdc
import gpc_gfx_timing_buffer_pack_::*;
import gc_l2_bank_pkg::*;
(
   input  logic                                       clk,
   input  logic                                       resetn,
   output logic                                       wdc_idle,
   
   input  logic                                       memif_wdc_cmd_valid,
   output logic                                       memif_wdc_cmd_ready,
   input  memif_wdc_record_type                       memif_wdc_cmd_rec,

   output logic                                       wdc_isched_wb_cmd_valid,
   input  logic                                       wdc_isched_wb_cmd_ready,
   output wdc_isched_cmd_record_type                  wdc_isched_wb_cmd_rec,
   
   
   input  logic                                       isched_wdc_cmd_valid,
   output logic                                       isched_wdc_cmd_ready,
   input  isched_wdc_record_type                      isched_wdc_cmd_rec,
   
   
   
   output logic                                       wdc_iwdb_fetch_data_valid,
   input  logic                                       wdc_iwdb_fetch_data_ready,
   output wdc_iwdb_cmd_record_type                    wdc_iwdb_fetch_data_rec,
   
   
   input  logic                                       iwdb_wdc_wdata_valid,
   input  iwdb_wdc_wdata_record_type                  iwdb_wdc_wdata_rec,
   
   output logic                                       wdc_isched_rtn_valid,
   input  logic                                       wdc_isched_rtn_ready,
   output wdc_isched_data_record_type                 wdc_isched_rtn_rec,
   
   input  logic [L2_NUM_RCTRL-1:0]                    rctrl_wdc_wb_data_valid,
   output logic [L2_NUM_RCTRL-1:0]                    rctrl_wdc_wb_data_ready,
   input  rctrl_wdc_wb_record_type [L2_NUM_RCTRL-1:0] rctrl_wdc_wb_data_rec,
   
   output logic                                       wdc_memif_wdata_valid,
   input  logic                                       wdc_memif_wdata_ready,
   output wdc_memif_wdata_record_type                 wdc_memif_wdata_rec
);


logic                                    wdc_waiting_data_order_fifo_valid;
logic                                    wdc_waiting_data_order_fifo_ready;
logic                                    wdc_waiting_data_order_out_valid;
logic                                    wdc_waiting_data_order_out_ready;
wdc_waiting_wdata_order_record_type      wdc_waiting_data_order_fifo_rec;
wdc_waiting_wdata_order_record_type      wdc_waiting_data_order_out_rec;

logic                                    wt_cmd_valid;
logic                                    wt_cmd_ready;
logic                                    wt_cmd_tbuff_valid;
logic                                    wt_cmd_tbuff_ready;



logic [2:0]                              wt_cmd_instruction_num;
logic [3+2+2+L2_IWDB_INDEX_BITS-1:0]   wt_cmd_slv;
logic [3+2+2+L2_IWDB_INDEX_BITS-1:0]   wt_cmd_tbuff_slv;

wt_cmd_record_type                       wt_cmd_rec;
wt_cmd_record_type                       wt_cmd_tbuff_rec;

logic [2:0]                              wt_cmd_tbuff_instruction_num;

logic                                    wt_cmd_spl_valid;
logic                                    wt_cmd_spl_ready;
logic [L2_IWDB_INDEX_BITS-1:0]           wt_cmd_spl_iwdb_index;
logic                                    wt_cmd_spl_last;

logic                                    wt_iwdb_rtn_wdata_valid;
logic                                    wt_iwdb_rtn_wdata_ready;
logic                                    wt_iwdb_rtn_wdata_out_valid;
logic                                    wt_iwdb_rtn_wdata_out_ready;
iwdb_wdc_wdata_record_type               wt_iwdb_rtn_wdata_rec;
iwdb_wdc_wdata_record_type               wt_iwdb_rtn_wdata_out_rec;

logic                                    wt_cmd_credit_incr;
logic                                    wt_cmd_credit_decr;

logic [WT_DATA_FIFO_DEPTH_BITS:0]        wt_cmd_credit_counter;

logic                                    wt_cmd_available_to_request;

logic [1:0]                              iwdb_fetch_data_req_mask;

logic                                    prev_selected_req;
logic                                    selected_req;

logic                                    wdc_iwdb_arb_valid;
logic                                    wdc_iwdb_arb_ready;
logic                                    wdc_iwdb_arb_last;

logic                                    rtn_wdata_order_valid;
logic                                    rtn_wdata_order_ready;
logic                                    rtn_wdata_order_out_valid;
logic                                    rtn_wdata_order_out_ready;

rtn_wdata_order_record_type              rtn_wdata_order_rec;
rtn_wdata_order_record_type              rtn_wdata_order_out_rec;


logic                                    l2_bank_wdc_splitter_idle;

logic [1:0]                              wt_beat_count;
logic [1:0]                              n_wt_beat_count;

logic [L2_NUM_BEAT -1 :0]                beat_wt_wb_mask;
logic [L2_NUM_BEAT -1 :0]                wt_beat_mask;

logic [L2_BEAT_BITS - 1:0]               beat_wt_wb_mask_msb_index;
logic [L2_BEAT_BITS - 1:0]               beat_wt_wb_mask_lsb_index;
logic [1:0]                              beat_wt_wb_mask_blen;


   
assign wdc_idle = (wdc_waiting_data_order_fifo_valid==1'b0) && (wdc_waiting_data_order_out_valid==1'b0) && (wt_cmd_valid==1'b0) && (wt_cmd_tbuff_valid==1'b0) && (l2_bank_wdc_splitter_idle==1'b1) && (wt_iwdb_rtn_wdata_valid==1'b0)
                   && (wt_cmd_credit_counter==WT_DATA_FIFO_DEPTH) && (rtn_wdata_order_valid==1'b0) && (rtn_wdata_order_out_valid==1'b0);









always_comb begin: p_wt_start_beat_to_mask
   wt_beat_mask = '0;
   case(memif_wdc_cmd_rec.blen)
      2'b00: wt_beat_mask = 4'b1 << memif_wdc_cmd_rec.start_beat;
      2'b01: wt_beat_mask = 4'b11 << memif_wdc_cmd_rec.start_beat;
      2'b10: wt_beat_mask = 4'b111 << memif_wdc_cmd_rec.start_beat;
      2'b11: wt_beat_mask = 4'b1111;
      default : wt_beat_mask = 4'b0;
   endcase
end : p_wt_start_beat_to_mask





assign beat_wt_wb_mask = wt_beat_mask | memif_wdc_cmd_rec.beat_dirty_mask; //this signal indicate how many beat need to be output to rctrl


gpc_gfx_prienc_ones_msb_ #(
   .W            ( L2_NUM_BEAT               ) ,
   .OUTPUT_WIDTH ( L2_BEAT_BITS              )
                                             )
i_wt_dirty_mask_prienc_ones_msb 
                 (
   .vector       ( beat_wt_wb_mask           ) ,
   .result       ( beat_wt_wb_mask_msb_index )
);

gpc_gfx_prienc_ones_lsb #(
   .W            ( L2_NUM_BEAT               ) ,
   .OUTPUT_WIDTH ( L2_BEAT_BITS              )
                                             )
i_wt_dirty_mask_prienc_ones_lsb 
                 (
   .vector       ( beat_wt_wb_mask           ) ,
   .result       ( beat_wt_wb_mask_lsb_index )
);


assign beat_wt_wb_mask_blen =  beat_wt_wb_mask_msb_index - beat_wt_wb_mask_lsb_index;
                  

always_comb begin : p_receive_cmd_from_memif
   wdc_waiting_data_order_fifo_valid = 1'b0;
   wdc_isched_wb_cmd_valid = 1'b0;
   wt_cmd_valid =1'b0;

   memif_wdc_cmd_ready = ~memif_wdc_cmd_valid;

   wdc_waiting_data_order_fifo_rec.instruction = memif_wdc_cmd_rec.instruction;
   wdc_waiting_data_order_fifo_rec.src  = memif_wdc_cmd_rec.set[0];
   wdc_waiting_data_order_fifo_rec.blen = memif_wdc_cmd_rec.blen;

//synopsys translate_off
   wdc_waiting_data_order_fifo_rec.set = memif_wdc_cmd_rec.set;
   wdc_waiting_data_order_fifo_rec.way = memif_wdc_cmd_rec.way;


//synopsys translate_on






   wdc_isched_wb_cmd_rec = memif_wdc_cmd_rec;

   wt_cmd_rec.instruction =    memif_wdc_cmd_rec.instruction;
   wt_cmd_rec.start_beat  =    memif_wdc_cmd_rec.start_beat ;
   wt_cmd_rec.blen        =    memif_wdc_cmd_rec.blen       ;
   wt_cmd_rec.iwdb_index  =    memif_wdc_cmd_rec.iwdb_index ;




   if(memif_wdc_cmd_valid==1'b1)begin
      if(memif_wdc_cmd_rec.instruction==WT)begin
         wdc_waiting_data_order_fifo_valid = wt_cmd_ready;
         wt_cmd_valid = wdc_waiting_data_order_fifo_ready;

         memif_wdc_cmd_ready = wt_cmd_ready & wdc_waiting_data_order_fifo_ready;
      end
      else begin
         wdc_waiting_data_order_fifo_valid = wdc_isched_wb_cmd_ready;
         wdc_isched_wb_cmd_valid = wdc_waiting_data_order_fifo_ready;

         memif_wdc_cmd_ready = wdc_isched_wb_cmd_ready & wdc_waiting_data_order_fifo_ready;

         if(memif_wdc_cmd_rec.instruction==WB_WR)begin
            wdc_waiting_data_order_fifo_rec.blen = beat_wt_wb_mask_blen;
         end
      end

   end
end : p_receive_cmd_from_memif




gpc_gfx_rpfifo_ #(
   .w                   ($bits(wdc_waiting_data_order_fifo_rec)),
   .d                   (8),
   .registered_enable   (1)
) i_wdc_waiting_data_order_fifo (
   .clk             ( clk                               ) ,
   .resetn          ( resetn                            ) ,
   .fifo_in_valid   ( wdc_waiting_data_order_fifo_valid ) ,
   .fifo_in_enable  ( wdc_waiting_data_order_fifo_ready ) ,
   .fifo_in_data    ( wdc_waiting_data_order_fifo_rec   ) ,
   .fifo_out_valid  ( wdc_waiting_data_order_out_valid  ) ,
   .fifo_out_enable ( wdc_waiting_data_order_out_ready  ) ,
   .fifo_out_data   ( wdc_waiting_data_order_out_rec    )
);




assign wt_cmd_instruction_num = 3'(wt_cmd_rec.instruction);
assign wt_cmd_slv = {wt_cmd_instruction_num, wt_cmd_rec.start_beat, wt_cmd_rec.blen, wt_cmd_rec.iwdb_index};
assign {wt_cmd_tbuff_instruction_num, wt_cmd_tbuff_rec.start_beat, wt_cmd_tbuff_rec.blen, wt_cmd_tbuff_rec.iwdb_index} = wt_cmd_tbuff_slv;
assign wt_cmd_tbuff_rec.instruction = l2_bank_cacheline_instr_type'(wt_cmd_tbuff_instruction_num);

gpc_gfx_timing_buffer_ #(
   .BUFFER_TYPE   (GPC_GFX_TIMING_BUFFER_RSTL),
   .WIDTH         (3+2+2+L2_IWDB_INDEX_BITS)
) i_wt_cmd_timing_buffer (
   .clk              (clk                ) ,
   .resetn           (resetn             ) ,
   .tbuff_in_valid   (wt_cmd_valid       ) ,
   .tbuff_in_enable  (wt_cmd_ready       ) ,
   .tbuff_in_data    (wt_cmd_slv         ) ,
   .tbuff_out_valid  (wt_cmd_tbuff_valid ) ,
   .tbuff_out_enable (wt_cmd_tbuff_ready ) ,
   .tbuff_out_data   (wt_cmd_tbuff_slv   )
);


gc_l2_bank_wdc_splitter
i_gc_l2_bank_wdc_splitter(
      .clk                     ( clk                       ) ,
      .resetn                  ( resetn                    ) ,
      .idle                    ( l2_bank_wdc_splitter_idle ) ,
      .req_splitter_valid      ( wt_cmd_tbuff_valid        ) ,
      .req_splitter_ready      ( wt_cmd_tbuff_ready        ) ,
      .req_splitter_rec        ( wt_cmd_tbuff_rec          ) ,
      .splitter_req_valid      ( wt_cmd_spl_valid          ) ,//wcc for write cmd control
      .splitter_req_ready      ( wt_cmd_spl_ready          ) ,
      .splitter_req_iwdb_index ( wt_cmd_spl_iwdb_index     ) ,
      .splitter_req_last       ( wt_cmd_spl_last           )
);





gpc_gfx_rpfifo_ #(
   .w                   (L2_BEAT_WIDTH+L2_BEAT_STRB_WIDTH),
   .d                   (WT_DATA_FIFO_DEPTH),
   .registered_enable   (1)
) i_wt_data_fifo (
   .clk             ( clk                                                              ) ,
   .resetn          ( resetn                                                           ) ,
   .fifo_in_valid   ( wt_iwdb_rtn_wdata_valid                                          ) ,
   .fifo_in_enable  ( wt_iwdb_rtn_wdata_ready                                          ) ,
   .fifo_in_data    ( {wt_iwdb_rtn_wdata_rec.data, wt_iwdb_rtn_wdata_rec.strb}         ) ,
   .fifo_out_valid  ( wt_iwdb_rtn_wdata_out_valid                                      ) ,
   .fifo_out_enable ( wt_iwdb_rtn_wdata_out_ready                                      ) ,
   .fifo_out_data   ( {wt_iwdb_rtn_wdata_out_rec.data, wt_iwdb_rtn_wdata_out_rec.strb} )
);


assign  wt_cmd_credit_incr = wt_iwdb_rtn_wdata_out_valid & wt_iwdb_rtn_wdata_out_ready;

assign  wt_cmd_credit_decr = wt_cmd_spl_valid & wt_cmd_spl_ready;


always_ff@(posedge clk or negedge resetn) begin : p_reg_credit_counter
   if(!resetn)begin
      wt_cmd_credit_counter <= WT_DATA_FIFO_DEPTH;
   end
   else if(wt_cmd_credit_incr==1'b1 && wt_cmd_credit_decr == 1'b0)begin
      wt_cmd_credit_counter <= wt_cmd_credit_counter + 1;
   end
   else if(wt_cmd_credit_incr==1'b0 && wt_cmd_credit_decr == 1'b1)begin
      wt_cmd_credit_counter <= wt_cmd_credit_counter - 1;
   end
end : p_reg_credit_counter

assign wt_cmd_available_to_request = wt_cmd_credit_counter != '0 || wt_cmd_credit_incr;






// use round robin arbitration on the per requester mask to chose which rctrl returns data to which requester
gpc_round_robin_index_arch1_ #(
   .width          ( 2                        ) ,
   .hold_previous  ( 1'b0                     )
                                              )
i_gpc_round_robin_index_arch1_wt_and_isched 
                   (
   .valids         ( iwdb_fetch_data_req_mask ) ,
   .previous_index ( prev_selected_req        ) ,
   .next_index     ( selected_req             )
);

assign iwdb_fetch_data_req_mask[0] = wt_cmd_spl_valid && wt_cmd_available_to_request;
assign iwdb_fetch_data_req_mask[1] = isched_wdc_cmd_valid;

always_ff@(posedge clk or negedge resetn) begin: p_reg_arb_previous_selected_req
   if(!resetn)begin
      prev_selected_req <= '0;
   end
   else if(wdc_iwdb_arb_valid && wdc_iwdb_arb_ready && wdc_iwdb_arb_last)begin
      prev_selected_req <= selected_req;
   end
   else if(wdc_iwdb_arb_valid && wdc_iwdb_arb_ready)begin
      prev_selected_req <= selected_req - 1'b1;
   end
end

assign wdc_iwdb_arb_valid = |iwdb_fetch_data_req_mask;


always_comb begin : p_receive_cmd_from_arb_comb
   wdc_iwdb_arb_ready                 = ~wdc_iwdb_arb_valid;
   
   rtn_wdata_order_valid              = 1'b0;
   wdc_iwdb_fetch_data_valid          = 1'b0;

   wdc_iwdb_fetch_data_rec.iwdb_index = '0;
   wdc_iwdb_fetch_data_rec.atomic     = 1'b0;

   rtn_wdata_order_rec.src            = selected_req;
   rtn_wdata_order_rec.rctrl          = 1'b0;

   wdc_iwdb_arb_last                  = 1'b0;

//synopsys translate_off
   rtn_wdata_order_rec.set            = '0;
   rtn_wdata_order_rec.way            = '0;
   rtn_wdata_order_rec.beat           = '0;
   rtn_wdata_order_rec.axid           = '0;
//synopsys translate_on


   if(wdc_iwdb_arb_valid==1'b1)begin

      wdc_iwdb_arb_ready        = rtn_wdata_order_ready & wdc_iwdb_fetch_data_ready;
      rtn_wdata_order_valid     = wdc_iwdb_fetch_data_ready;
      wdc_iwdb_fetch_data_valid = rtn_wdata_order_ready;

      if(selected_req == 1'b0)begin
         wdc_iwdb_fetch_data_rec.iwdb_index = wt_cmd_spl_iwdb_index;

         wdc_iwdb_arb_last                  = wt_cmd_spl_last;
      end
      else begin
         wdc_iwdb_fetch_data_rec.iwdb_index = isched_wdc_cmd_rec.iwdb_index;
         wdc_iwdb_fetch_data_rec.atomic     = isched_wdc_cmd_rec.atomic;
         rtn_wdata_order_rec.rctrl          = isched_wdc_cmd_rec.src;

         wdc_iwdb_arb_last                  = isched_wdc_cmd_rec.last;

//synopsys translate_off
         rtn_wdata_order_rec.set            = isched_wdc_cmd_rec.set;
         rtn_wdata_order_rec.way            = isched_wdc_cmd_rec.way;
         rtn_wdata_order_rec.beat           = isched_wdc_cmd_rec.beat;
         rtn_wdata_order_rec.axid           = isched_wdc_cmd_rec.axid;
//synopsys translate_on
         
      end
   end
end : p_receive_cmd_from_arb_comb


assign wt_cmd_spl_ready = (selected_req==1'b0)? wdc_iwdb_arb_ready : 1'b0;

assign isched_wdc_cmd_ready = (selected_req==1'b1)? wdc_iwdb_arb_ready : 1'b0;


gpc_gfx_rpfifo_ #(
   .w                 ( $bits(rtn_wdata_order_rec ) ),
   .d                 ( 3                         ) ,
   .registered_enable ( 1                         )
                                                  )
i_iwdb_rtn_wdata_order_fifo 
                      (
   .clk               ( clk                       ) ,
   .resetn            ( resetn                    ) ,
   .fifo_in_valid     ( rtn_wdata_order_valid     ) ,
   .fifo_in_enable    ( rtn_wdata_order_ready     ) ,
   .fifo_in_data      ( rtn_wdata_order_rec       ) ,
   .fifo_out_valid    ( rtn_wdata_order_out_valid ) ,
   .fifo_out_enable   ( rtn_wdata_order_out_ready ) ,
   .fifo_out_data     ( rtn_wdata_order_out_rec   )
) ;




always_comb begin : p_iwdb_rtn_data_to_resync_comb
   wdc_isched_rtn_valid      = 1'b0;
   wt_iwdb_rtn_wdata_valid   = 1'b0;

   rtn_wdata_order_out_ready = ~rtn_wdata_order_out_valid;

   wt_iwdb_rtn_wdata_rec     = iwdb_wdc_wdata_rec;
   wdc_isched_rtn_rec.data   = iwdb_wdc_wdata_rec.data;
   wdc_isched_rtn_rec.strb   = iwdb_wdc_wdata_rec.strb;
   wdc_isched_rtn_rec.src    = rtn_wdata_order_out_rec.rctrl;

//synopsys translate_off
   wdc_isched_rtn_rec.set    = '0;
   wdc_isched_rtn_rec.way    = '0;
   wdc_isched_rtn_rec.beat   = '0;
   wdc_isched_rtn_rec.axid   = '0;
//synopsys translate_on

   if(rtn_wdata_order_out_valid==1'b1)begin
      if(iwdb_wdc_wdata_valid==1'b1)begin
         if(rtn_wdata_order_out_rec.src == 1'b0)begin
            wt_iwdb_rtn_wdata_valid = 1'b1;
            rtn_wdata_order_out_ready = wt_iwdb_rtn_wdata_ready; //in fact, here always equal to 1, because credit counter make the fifo always available
         end
         else begin
            wdc_isched_rtn_valid = 1'b1;
            rtn_wdata_order_out_ready = wdc_isched_rtn_ready; //in fact, here always equal to 1, because credit counter make the fifo always available

//synopsys translate_off
            wdc_isched_rtn_rec.set    = rtn_wdata_order_out_rec.set;
            wdc_isched_rtn_rec.way    = rtn_wdata_order_out_rec.way;
            wdc_isched_rtn_rec.beat   = rtn_wdata_order_out_rec.beat;
            wdc_isched_rtn_rec.axid   = rtn_wdata_order_out_rec.axid;
//synopsys translate_on

         end
      end
   end
end : p_iwdb_rtn_data_to_resync_comb


always_comb begin : p_memif_req_to_sync_data_comb
   wdc_memif_wdata_valid            = 1'b0;
   wdc_memif_wdata_rec              = '{default : '0};

   wt_iwdb_rtn_wdata_out_ready      = ~wt_iwdb_rtn_wdata_out_valid;
   rctrl_wdc_wb_data_ready          = ~rctrl_wdc_wb_data_valid;

   wdc_waiting_data_order_out_ready = ~wdc_waiting_data_order_out_valid;
   n_wt_beat_count                  = wt_beat_count;
   

   if(wdc_waiting_data_order_out_valid == 1'b1)begin
      if(wdc_waiting_data_order_out_rec.instruction==WT)begin
         if(wt_iwdb_rtn_wdata_out_valid==1'b1)begin
            wdc_memif_wdata_valid          = 1'b1;
            wdc_memif_wdata_rec.wdata      = wt_iwdb_rtn_wdata_out_rec.data;
            wdc_memif_wdata_rec.wdata_mask = wt_iwdb_rtn_wdata_out_rec.strb;

            wt_iwdb_rtn_wdata_out_ready    = wdc_memif_wdata_ready;


            if(wt_beat_count==wdc_waiting_data_order_out_rec.blen)begin
               n_wt_beat_count = '0;
               wdc_memif_wdata_rec.last = 1'b1;
               wdc_waiting_data_order_out_ready = wdc_memif_wdata_ready;
            end
            else if(wdc_memif_wdata_ready==1'b1)begin
               n_wt_beat_count = wt_beat_count + 1;
            end
         end
      end
      else if(rctrl_wdc_wb_data_valid[wdc_waiting_data_order_out_rec.src]==1'b1) begin
         wdc_memif_wdata_valid                                   = 1'b1;
         wdc_memif_wdata_rec.wdata                               = rctrl_wdc_wb_data_rec[wdc_waiting_data_order_out_rec.src].data;
         wdc_memif_wdata_rec.last                                = rctrl_wdc_wb_data_rec[wdc_waiting_data_order_out_rec.src].last;
         wdc_memif_wdata_rec.wdata_mask                          = rctrl_wdc_wb_data_rec[wdc_waiting_data_order_out_rec.src].strb;
         rctrl_wdc_wb_data_ready[wdc_waiting_data_order_out_rec.src] = wdc_memif_wdata_ready;
         if(rctrl_wdc_wb_data_rec[wdc_waiting_data_order_out_rec.src].last==1'b1)begin
            wdc_waiting_data_order_out_ready = wdc_memif_wdata_ready;
         end
         
      end
   end
end : p_memif_req_to_sync_data_comb


always_ff@(posedge clk or negedge resetn) begin : p_data_to_resync_clkdrs
   if(!resetn) begin
      wt_beat_count <= '0;
   end
   else begin
      if(wdc_memif_wdata_valid==1'b1 && wdc_memif_wdata_ready==1'b1) begin
         wt_beat_count <= n_wt_beat_count;
      end
   end
end : p_data_to_resync_clkdrs




endmodule
// Local Variables:
// verilog-library-flags:("-y ./ -y ../")
// verilog-auto-inst-param-value:t
// End:
