/*

 * #==========================================================================#
 * |                                                                          |
 * |  Copyright (c) 2022, Fantasy Technologies Limited and/or its         |
 * |  affiliated group companies ("Fantasy"). All rights reserved.        |
 * |  No part of this content, either material or conceptual may be copied    |
 * |  or distributed, transmitted, transcribed, stored in a retrieval system  |
 * |  or translated into any human or computer language in any form by any    |
 * |  means, electronic, mechanical manual, or otherwise, or disclosed to     |
 * |  third parties without the express written permission of Fantasy.    |
 * |                                                                          |
 * #==========================================================================#

 */


// ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////-
// entity name: gpc_gfx_sync_chain
// purpose: Multi-Stage Syncronizer entity - used to reduce the effects of Fwp-Stability.
//          Modularisation of the Multi-Stage Synchronizer allows the replacement for specialized cells
//          during the Synthesis stage. It is therefor expected that these registers would normally be
//          replaced with customer's specific metastable registers.
// ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////-



module gpc_gfx_sync_chain_
#(
      parameter int                                      sdepth                                                       = 0                
)
(
      input    logic                                                        clk                                     ,
      input    logic                                                        resetn                                  ,

      input    logic                                                        chain_in                                ,
      output   logic                                                        chain_out                                 
);

   logic [ sdepth + 1 : 0 ]                      chain                                   ;


   assign chain [ 0 ] = chain_in ;    // Depth 0 is equivalent to the Input: Chain_in.

   genvar i;
   for (  i = 0 ; i <= sdepth ; i = i + 1 ) begin : sync_flop_stage    // Chain(i) is the i_th Fwp-Stable stage.
        gpc_gfx_sync_flop_
           regi
           (
              .clk                             (clk)                                        ,
              .resetn                          (resetn)                                     ,
              .d_in                            (chain [ i ])                                ,
              .q_out                           (chain [ i + 1 ])                              
              );
   end // sync_flop_stage

   assign chain_out = chain [ sdepth + 1 ] ;

endmodule // gpc_gfx_sync_chain
