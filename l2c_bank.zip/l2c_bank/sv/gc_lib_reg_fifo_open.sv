// Author: jinjifang
// Date: 2024/1/8
// Description: the common flip-flop open fifo

module gc_lib_reg_fifo_open #(
                         parameter type DTYPE = logic [7:0],
                         parameter integer DEPTH = 4
                         )(
                           input logic                  clk,
                           input logic                  resetn, 
                           // fifo common push and pop ports
                           input logic                  push, 
                           input logic                  pop, 
                           input DTYPE                  din,
                           output logic                 full, 
                           output logic                 empty,  
                           output DTYPE                 dout,
                           // fifo data
                           output DTYPE [DEPTH-1:0]     fifo_mem,
                           output logic [DEPTH-1:0]     fifo_mask
                           );

    localparam  DEPTH_BITS      = (DEPTH == 1) ? 1 : $clog2(DEPTH);

    // user signals
    logic [DEPTH_BITS:0]                             wptr;
    logic [DEPTH_BITS:0]                             rptr;


    //wprt
    always @(posedge clk or negedge resetn) begin
       if (!resetn) begin
          wptr <= {(DEPTH_BITS+1){1'b0}};
    end    
       else if (push) begin
          if(wptr[DEPTH_BITS-1:0] == DEPTH - 1)
             wptr <= {!wptr[DEPTH_BITS], {DEPTH_BITS{1'b0}}};
          else
             wptr <= wptr + 1'b1;
       end
    end

    //rptr
    always @(posedge clk or negedge resetn) begin
       if (!resetn) begin
          rptr <= {(DEPTH_BITS+1){1'b0}};
    end    
       else if (pop) begin
          if(rptr[DEPTH_BITS-1:0] == DEPTH - 1)
             rptr <= {!rptr[DEPTH_BITS], {DEPTH_BITS{1'b0}}};
          else
             rptr <= rptr + 1'b1;
       end
    end

    //fifo_mem
    genvar i;
    generate
       for(i = 0; i < DEPTH; i = i + 1) begin

          // fifo mem data
          always @(posedge clk) begin
             if( push & (i == wptr[DEPTH_BITS-1:0]))
               fifo_mem[i] <= din;
          end

          // fifo valid mask
         always @(posedge clk or negedge resetn) begin
             if(!resetn)
                 fifo_mask[i] <= 1'b0;
             else if(push & (i == wptr[DEPTH_BITS-1:0]))
                 fifo_mask[i] <= 1'b1;
             else if(pop & (i == rptr[DEPTH_BITS-1:0]))
                 fifo_mask[i] <= 1'b0;
         end

       end
    endgenerate

    //dout
    assign  dout = fifo_mem[rptr[DEPTH_BITS-1:0]];

    // full and empty flag
    assign empty = wptr == rptr;
    assign full = (wptr[DEPTH_BITS] ^ rptr[DEPTH_BITS]) & (wptr[DEPTH_BITS-1:0] == rptr[DEPTH_BITS-1:0]);


//synopsys translate_off
   logic    push_legal;
   assign push_legal = !full | pop;
    gpu_assert_always_on_event u_assert_push(.clk(clk), .resetn(resetn), .sample(push), .expr(push_legal), .msg("push overflow"));

    logic   pop_legal;
    assign pop_legal = !empty;
    gpu_assert_always_on_event u_assert_pop(.clk(clk), .resetn(resetn), .sample(pop), .expr(pop_legal), .msg("pop underflow"));

//synopsys translate_on


endmodule
