// +FHDR----------------------------------------------------------------------------
// Copyright (c) 2025, Innosilicon, Inc. Confidential Proprietary
// PROJECT NAME  : xxx
// DEPARTMENT    : Digtal Frontend SOC
// AUTHOR        : luoml01
// EMAIL         : luoml01@innosilicon.com.cn
// CREATE ON     : 2025/01/03 09:19
// FILE NAME     : gc_l2_bank_isched_splitter.sv
// DESCRIPTION   :          
//         
// Copyright (c) 2025 Innosilicon.
// ALL RIGHTS RESERVED
// 
// ---------------------------------------------------------------------------------
// Modification History:
// Date         By              Version                 Change Description
// ---------------------------------------------------------------------------------
// 2025/01/03   luoml01         1.0                     Original
// 
// -FHDR----------------------------------------------------------------------------


module gc_l2_bank_wdc_splitter
import gc_l2_bank_pkg::*;
import gpc_gfx_timing_buffer_pack_::*;
(
      input                                  clk,
      input                                  resetn,
      output                                 idle,
      
      
      input  logic                           req_splitter_valid,
      output logic                           req_splitter_ready,
      input  wt_cmd_record_type              req_splitter_rec,
      
      //wcc for write command controller
      output logic                           splitter_req_valid,
      input  logic                           splitter_req_ready,
      output logic  [L2_IWDB_INDEX_BITS-1:0] splitter_req_iwdb_index,
      output logic                           splitter_req_last
);



   logic [L2_BEAT_BITS-1:0] n_split_beat_count;
   logic [L2_BEAT_BITS-1:0] split_beat_count;


   

   assign idle = req_splitter_valid == 1'b0 ? 1'b1:1'b0;


 
   always_comb begin: p_command_split_comb

      splitter_req_valid      = 1'b0;
      req_splitter_ready      = ~req_splitter_valid;
      n_split_beat_count      = split_beat_count;
      splitter_req_iwdb_index = (req_splitter_rec.iwdb_index + split_beat_count >= L2_IWDB_DEPTH)? req_splitter_rec.iwdb_index + split_beat_count - L2_IWDB_DEPTH : req_splitter_rec.iwdb_index + split_beat_count ;
      splitter_req_last       = 1'b0;

      if(req_splitter_valid==1'b1)begin
         splitter_req_valid = 1'b1;
         if(split_beat_count==req_splitter_rec.blen)begin
            req_splitter_ready = splitter_req_ready;
            n_split_beat_count = '0;
            splitter_req_last  = 1'b1;
         end
         else if(splitter_req_ready==1'b1)begin
            n_split_beat_count = split_beat_count +1;
         end
      end
   end : p_command_split_comb




   always_ff@(posedge clk or negedge resetn) begin : p_counter_for_split_clkdrs
      if(resetn==1'b0) begin
         split_beat_count <= '0;
      end
      else begin
         if((splitter_req_valid==1'b1 && splitter_req_ready==1'b1) ) begin
            split_beat_count <= n_split_beat_count;
         end
      end
   end : p_counter_for_split_clkdrs


endmodule
// Local Variables:
// verilog-library-flags:("-y ./ -y ../")
// verilog-auto-inst-param-value:t
// End:
