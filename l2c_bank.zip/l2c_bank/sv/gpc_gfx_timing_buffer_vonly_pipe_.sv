// ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////-
// entity name: gpc_gfx_timing_buffer_vonly
// Component Description: IMGLIB3 Generic Timing Buffer for Valid Only interfaces
// Generic Timing Buffer (use BUFFER_TYPE generic to instantiate a wide variety of modules)
//
// For description of each instantiated buffer type check appropriate source file.
//
// ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////-
// BUFFER TYPE     |   AREA COST   | VALID/DATA | ENABLE CHAIN | Comments
// ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////-
// Wire            |     ZERO!     | Same cycle | N/A          | No benefit!
// Simple Pipe reg | W x (FF)      | Delayed    | N/A          | Data registered
// ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////-
//
// Generics:
// BUFFER_TYPE - INTEGER
//             - Buffer Type to introduce - see table above, DEFAULT = 0 = Wire
// WIDTH       - INTEGER
//             - Width of Data bus Input/Output std_logic_vector
//
// Portlist:
// clk               - Clock Input
// resetn            - Active-low asynchronous Reset
// tbuff_in_data     - Data bus input (sized by generic w)
// tbuff_in_valid    - Valid input from upstream module
// tbuff_out_data    - Data bus output (sized by generic w)
// tbuff_out_valid   - Valid output to downstream module
//
// ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////-




module gpc_gfx_timing_buffer_vonly_pipe_
#(
      parameter                                          INIT_VALUE                                                   = 0              ,
      parameter int                                      BUFFER_TYPE                                                  = 0              ,
      parameter int                                      WIDTH                                                        = 32             ,
      parameter int                                      PIPE_STAGES                                                  = 1
)
(
      input    logic                                                        clk                                     ,
      input    logic                                                        resetn                                  ,
      // Input V/E Interface
      input    logic                                                        tbuff_in_valid                          ,
      input    logic [ WIDTH - 1 : 0 ]                                      tbuff_in_data                           ,
      // Output V/E Interface
      output   logic                                                        tbuff_out_valid                         ,
      output   logic [ WIDTH - 1 : 0 ]                                      tbuff_out_data
);

   import gpc_gfx_timing_buffer_pack_::*;

   logic  [PIPE_STAGES-1 :0]               in_valid_array    ;

   logic  [PIPE_STAGES-1 :0][WIDTH-1 :0]   in_data_array     ;
   logic  [PIPE_STAGES-1 :0]               out_valid_array   ;

   logic  [PIPE_STAGES-1 :0][WIDTH-1 :0]   out_data_array    ;

   //input connect
   assign in_valid_array[0]                  = tbuff_in_valid                    ;
   assign in_data_array[0]                   = tbuff_in_data                     ;

   //output connect
   assign tbuff_out_valid                    = out_valid_array[PIPE_STAGES-1]    ;
   assign tbuff_out_data                     = out_data_array[PIPE_STAGES-1]     ;

   //inner connect
   always_comb begin
      for (int buffer_idx=0; buffer_idx<PIPE_STAGES-1; buffer_idx++) begin
         in_valid_array[buffer_idx+1] = out_valid_array[buffer_idx]     ;
         in_data_array[buffer_idx+1]  = out_data_array[buffer_idx]    ;
      end
   end



   //generate gpc_gfx_timing_buffer_ instance
   genvar i;
   generate
      for (i=0; i < PIPE_STAGES; i=i+1) begin : g_gen_gpc_gfx_timing_buffer
         gpc_gfx_timing_buffer_vonly_
         #(
               .INIT_VALUE  (INIT_VALUE ) ,
               .BUFFER_TYPE (BUFFER_TYPE) ,
               .WIDTH       (WIDTH)
         )i_timing_buffer_vonly_
         (
               .clk             (clk      ),
               .resetn          (resetn   ),

               .tbuff_in_valid  (in_valid_array[i]  ),
               .tbuff_in_data   (in_data_array[i]   ),

               .tbuff_out_valid (out_valid_array[i] ),
               .tbuff_out_data  (out_data_array[i]  )
         );

      end
   endgenerate


endmodule // gpc_gfx_timing_buffer_vonly_pipe_
