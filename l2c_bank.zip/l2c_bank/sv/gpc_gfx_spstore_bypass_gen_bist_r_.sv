/*

 * #==========================================================================#
 * |                                                                          |
 * |  Copyright (c) 2023, Fantasy Technologies Limited and/or its         |
 * |  affiliated group companies ("Fantasy"). All rights reserved.        |
 * |  No part of this content, either material or conceptual may be copied    |
 * |  or distributed, transmitted, transcribed, stored in a retrieval system  |
 * |  or translated into any human or computer language in any form by any    |
 * |  means, electronic, mechanical manual, or otherwise, or disclosed to     |
 * |  third parties without the express written permission of Fantasy.    |
 * |                                                                          |
 * #==========================================================================#

 */

// ////////////////////////////////////////////////////////////////////////////-
// entity:  gpc_gfx_spstore_bypass_gen_bist_r
//
// purpose: Single port synchronous RAM with configurable write word partitions
//          and back end read register to help achieve timing closure
//
// +////////////////////////-+////-+////-+////////+////////////////+
// | gpc_gfx_spstore_        | RAM | Reg | Bypass | Design         |
// |             w,p,d,log2d | O/P | O/P | Input  | Suitability    |
// +////////////////////////-+////-+////-+////////+////////////////+
// | _.vhd & _novital.vhd    | Yes |     |        | Fundamental    |
// | bist.vhdm               | Yes |     |        | Low level only |
// | gen_bist_r.vhd          |     | Yes |        | Standard use   |
// | pipeline_gen_bist_r.vhd |     | Yes |        | Standard use   |
// | bypass_gen_bist_r.vhd   | Yes | Yes |  Yes   | Standard use   |<<<
// | bpout_gen_bist_r.vhd    | Yes | Yes |        | Standard use   |
// | flexible_gen_bist_r.vhd | Yes | Yes |  Yes   | Standard use   |
// +////////////////////////-+////-+////-+////////+////////////////+
//
// hierarchy: This is an RTL designer's standard component
//
//        gpc_gfx_spstore_[pipeline|bypass]_gen_bist_r   << YOU ARE HERE
//         |
//         +- gpc_gfx_spstore_bist
//             |
//             +- gpc_gfx_spstore
//             |
//             +- [ gpc_gfx_bistwrap_sing ]
//
// ////////////////////////////////////////////////////////////////////////////-

// DIMENSIONS
//   Physical generics: w, d, p, log2d, byp_in
//
//                        width
//              <////////// w //////////>
//
//              +//////////////////////-+   ^
//              |_______________________|   |
//              |_______________________|   |  d
//              |_______________________|      e
//              |                       |   d  p
//              |                       |      t
//              :                       :   |  h
//              |                       |   |
//              +//////////////////////-+   v
//                         w/p *
//              <- p -><- p -> .. <- p ->
//                      partitions
//
//   All partitions are equal in size. In other words, the generic w is an
//   integer multiple of generic p.
//
//   Example partition:
//      [w = 128, p = 32] => w/p = 4 partitions => 4 write enables

// PORTS
//   +////////////////////////////////////////////////////////////+
//   | name          |  bits  |dir| description                   |
//   +////////////////////////////////////////////////////////////+
//   | addr          | log2d  | i | address                       |
//   | c_en          |   1    | i | chip enable (ACTIVE LOW)      |
//   | rd_en         |   1    | i | read enable (ACTIVE LOW)      |
//   | ram_data      |   w    | o | read data out of RAM macro    |
//   | rd_data       |   w    | o | read data off register        |
//   | bypass_load   |  w/p   | i | bypass data partition enables |
//   | bypass_data   |   w    | i | bypass data ((w/p)*p bits)    |
//   |               |        |   |                               |
//   | wr_data       |   w    | i | write data ((w/p)*p bits)     |
//   | wr_en         |  w/p   | i | write enables (ACTIVE LOW)    |
//   |               |        |   |                               |
//   | clk           |   1    | i | common r/w clock              |
//   | resetn        |   1    | i | reset to BIST (ACTIVE LOW)    |
//   |               |        |   |                               |
//   | bist_in       |f(w,p,d)| i | input from BIST controller    |
//   | bist_out      |f(w,p,d)| o | result to BIST controller     |
//   +////////////////////////////////////////////////////////////+

// BEHAVIOURIAL MODEL
//   Functional behaviour is similar to gpc_gfx_spstore_bist but this hierarchical
//   level adds a back end read data register for timing purposes. The back end
//   register also takes bypass data. This can be used where writethrough
//   transparency is required.
//
//   Read latency:   2 clocks (1 if using ram_data)
//   Write latency:  1 clock
//   Bypass latency: 1 clock
//
//   bypass_load ///////////////////////////////////////////.
//   bypass_data ///////////////////////////////////////.   |
//                +//////////////////////////////////-+ |   |
//                |      gpc_gfx_spstore_bist         | |   |
//                |                                   | |   |
//                |  +////////////////////////////-+  | |   |
//                |  |     gpc_gfx_spstore         |  | |   |
//                |  |                          dly|  | /   /
//   c_en, rd_en//|//|////-*//////////////////-*-%-|//|-|//.| ,byp_in
//   addr    /////|//|-*//-|/////////////////-.|   |  | |  ||/
//                |  | |   |                  ||   |  | | +//-+
//                |  | | +////+   +////-+   +////+ |  | '-|1  | +////+
//                |  | '-| wr |   |     |   | rd | |  |   |   |_|    |
//   wr_en   /////|//|//-|proc|-/-| mem |-/-|proc|-|//|-*-|0  | |    |///->
//   wr_data /////|//|//-|    |   |     |   |    | |  | | +//-+ |    |  rd_data
//                |  |   |    |  +|>    |  +|>   | |  | |      +|>   |
//                |  |   +////+  |+////-+  |+////+ |  | |      |+////+
//                |  |           |         |       |  | '//////|/////////->
//   clk     ////-|//|//////////-*////////-*//////-|//|////////'       ram_data
//                |  +////////////////////////////-+  |
//                |  +////////////////////////////-+  |
//                |  |                             |  |
//   bist_in /////|//|  [ gpc_gfx_bistwrap_sing ]  |//|/////////////-> bist_out
//   resetn  ////-|//|                             |  |
//                |  +////////////////////////////-+  |
//                +//////////////////////////////////-+
//
//   Notes:
//   + Writes require wr_en and c_en both to be asserted (low)
//   + Reads require rd_en, c_en to be asserted (low) and wr_en inactive (high)
//   + Generic "byp_in" (integer)
//     0 : (default) the back end register takes ONLY bypass_data and access to
//         the spstore data is SOLELY via ram_data. An external register stage
//         will probably be required in order to meet timing.
//     1 : Bypass data and RAM data can be interleaved at word partition
//         granularity as determined by bypass_load.

// OPTIONAL UTILITY GENERIC
//   id : integer value that can be assigned to each instance (default 0)
//                                                                      -=:PB=-
// ////////////////////////////////////////////////////////////////////////////-

module gpc_gfx_spstore_bypass_gen_bist_r_
   import gpc_gfx_rambist_pack_::*;
#(
      parameter int                                      w                                                            = 0              ,
      parameter int                                      p                                                            = 0              ,
      parameter int                                      d                                                            = 0              ,
      parameter int                                      log2d                                                        = 0              ,
      parameter int                                      ECC                                                          = 0              ,    // ECC enable : 0=disable ECC; 1=enable ECC



      parameter int                                      id                                                           = 0              ,    // unique value per instance
      parameter int                                      byp_in                                                       = 0                
)
(
      input    logic                                                        clk                                     ,
      input    logic                                                        resetn                                  ,
      input    logic                                                        c_en                                    ,
      input    logic [ ( w / p ) - 1 : 0 ]                                  wr_en                                   ,
      input    logic                                                        rd_en                                   ,
      input    logic [ log2d - 1 : 0 ]                                      addr                                    ,
      input    logic [ w - 1 : 0 ]                                          wr_data                                 ,
      input    logic [ ( w / p ) - 1 : 0 ]                                  bypass_load                             ,
      input    logic [ w - 1 : 0 ]                                          bypass_data                             ,
      output   logic [ w - 1 : 0 ]                                          rd_data                                 ,
      output   logic [ w - 1 : 0 ]                                          ram_data                                ,
      // bist signals






      input    logic [ spstore_in ( w , p , d , ECC ) - 1 : 0 ]             bist_in                                 ,
      output   logic [ spstore_out ( w , p , d , ECC ) - 1 : 0 ]            bist_out                                ,
      input    logic                                                        tst_gclkenable                            
);








   
   logic [ ( w / p ) - 1 : 0 ]                   rd_en_r                                 ;
   logic [ w - 1 : 0 ]                           rd_data_ram                             ;
   logic [ w - 1 : 0 ]                           rd_data_ram_r                           ;

   ///////////////////////////////////////////////
   // backdoor access
   ///////////////////////////////////////////////




   ///////////////////////////////////////////////
   ///////////////////////////////////////////////
   // END backdoor access
   ///////////////////////////////////////////////

   gpc_gfx_spstore_wrap_
      #(
         .w                               (w)                                          ,
         .p                               (p)                                          ,
         .d                               (d)                                          ,
         .log2d                           (log2d)                                      ,
         .ECC                             (ECC)                                        ,



         .id                              (id)                                          
         )
      i_gpc_gfx_spstore_wrap
      (
         .clk                             (clk)                                        ,
         .resetn                          (resetn)                                     ,
         .c_en                            (c_en)                                       ,
         .wr_en                           (wr_en)                                      ,
         .addr                            (addr)                                       ,
         .wr_data                         (wr_data)                                    ,
         .rd_data_ram                     (rd_data_ram)                                ,






         .bist_in                         (bist_in)                                    ,
         .bist_out                        (bist_out)                                   ,
         .tst_gclkenable                  (tst_gclkenable)                               
         );

   // //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
   // Register the Ram Data for timing (This variant has a bypass interface to optionally register alternative data)
   // //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
   always_ff @(posedge clk or negedge resetn) begin
      if ( resetn == 1'b0 ) begin
         rd_en_r <= '1 ;
      end else begin
         if ( c_en == 1'b0 & ( | wr_en ) == 1'b1 ) begin    // COV:tag2
            rd_en_r <= ( ~ wr_en ) | ( { ( ( w / p ) - 1 - 0 + 1 ) { rd_en } } ) ;
         end else if ( ( & rd_en_r ) != 1'b1 ) begin    // changed from = '0' to handle 'U' and 'X' values when running X Prop
            rd_en_r <= '1 ;
         end
      end
   end
   
   assign ram_data = rd_data_ram ;
         
   genvar i;
   for (  i = ( w / p ) - 1 ; i >= 0 ; i = i - 1 ) begin : p_qa_i

      always_ff @(posedge clk) begin
         begin
            if ( bypass_load [ i ] == 1'b1 | rd_en_r [ i ] == 1'b0 ) begin
               if ( bypass_load [ i ] == 1'b0 & byp_in == 1 ) begin    // COV:tag3
                  rd_data_ram_r [ ( i + 1 ) * p - 1 : i * p ] <= rd_data_ram [ ( i + 1 ) * p - 1 : i * p ] ;
               end else begin
                  rd_data_ram_r [ ( i + 1 ) * p - 1 : i * p ] <= bypass_data [ ( i + 1 ) * p - 1 : i * p ] ;
               end
            end
         end
      end
      
   end // p_qa_i

   assign rd_data = rd_data_ram_r ;

endmodule // gpc_gfx_spstore_bypass_gen_bist_r

