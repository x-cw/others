// ---------------------------------------------------------------------------------
// Project Name  : IC_Design
// Author        : liusm
// Email         : liusm@innosilicon.com.cn
// Create On     : 2025/01/07 13:34
// Last Modified : 2025/08/04 14:13
// File Name     : gc_l2_bank_mem_sched_ring_buf.sv
// Description   :
// 
// Copyright (c) 2025 Innosilicon.
// ALL RIGHTS RESERVED
// 
// ---------------------------------------------------------------------------------
// Modification History:
// Date         By              Version                 Change Description
// ---------------------------------------------------------------------------------
// 2025/01/07   liusm           1.0                     Original
// 
// ----------------------------------------------------------------------------------


module gc_l2_bank_mem_sched_ring_buf
import gc_l2_bank_pkg::*;
import gpc_gfx_timing_buffer_pack_::*;
(
      input    logic                            clk
,     input    logic                            resetn

,     output   logic                            idle

,     input    logic                            memif_sched_valid
,     output   logic                            memif_sched_ready
,     input    bank_group_sched_data_bus_t      memif_sched_rec



,     output   logic                            ring_buf_valid
,     input    logic                            ring_buf_ready
,     output   bank_group_sched_data_bus_t      ring_buf_rec

);


   localparam DDR_BANK_GROUPS_NUM = 8;
   localparam DDR_BANK_GROUPS_BITS = 3;
   
   typedef     struct                           packed{
      logic                                     bank;
      logic [L2_DDR_ROW_BITS-1:0]               ddr_row;
      logic [L2_DDR_BANK_BITS-1:0]              ddr_bank;
      logic [5:0]                               ddr_column;
      logic [7:0]                               buffer_index;
   } l2_bank_mem_sched_ring_buffer_entry_t;
   
      logic [L2_MEM_SCHED_INSTR_DEPTH-1:0][L2_MEM_SCHED_INSTR_BITS-1:0]       sub_cnt;
   
   function automatic l2_bank_mem_sched_ring_buffer_entry_t func_bank_group_sched_2_ring_buffer_entry(bank_group_sched_data_bus_t rec);
      l2_bank_mem_sched_ring_buffer_entry_t result;
      
      {result.bank, result.ddr_row,result.ddr_bank, result.ddr_column} = rec.pa[33:6];
      result.buffer_index = rec.buffer_index;
      
      return result;
   endfunction
   
   
   logic                                    [ L2_MEM_SCHED_INSTR_BITS-1:0]                req_queue_select_row_index  ;
   l2_bank_mem_sched_ring_buffer_entry_t    [ L2_MEM_SCHED_INSTR_DEPTH-1:0]               req_queue_entries           ;
   logic                                    [ L2_MEM_SCHED_INSTR_DEPTH-1:0]               req_queue_valids            ;
   logic                                                                                  select_output_valid         ;
   logic                                                                                  select_output_ready         ;
   l2_bank_mem_sched_ring_buffer_entry_t                                                  select_output_buf_rec       ;
   logic                         [ L2_MEM_SCHED_INSTR_BITS-1:0]                           select_output_index         ;
   logic                                                                                  ddr_valid                   ;
   logic                         [L2_DDR_ROW_BITS-1:0]                                    ddr_row_id                  ;
   logic                         [L2_DDR_BANK_BITS-1:0]                                   ddr_bank_id                 ;
   
   logic                                                                                  same_row_output_valid       ;
   logic                         [ L2_MEM_SCHED_INSTR_DEPTH-1:0]                          req_queue_same_row_mask     ;
   
   logic                         [DDR_BANK_GROUPS_NUM-1:0] [L2_MEM_SCHED_INSTR_DEPTH-1:0] req_queue_diff_bank_mask    ;
   logic                         [DDR_BANK_GROUPS_NUM-1:0] [L2_MEM_SCHED_INSTR_BITS-1:0]  req_queue_select_bank_index ;
   logic                         [DDR_BANK_GROUPS_NUM-1:0] [DDR_BANK_GROUPS_BITS-1:0]     bank_group_order            ;
   logic                         [DDR_BANK_GROUPS_NUM-1:0]                                diff_bank_output_valid      ;
   logic                                                                                  select_en                   ;
   logic                         [2:0]                                                    select_bank_group           ;
   logic [L2_MEM_SCHED_INSTR_BITS-1:0]                                                    pa_queue_empty_entry        ;
   
   assign memif_sched_ready = ~&req_queue_valids;
   // if entry 0 and entry 31 are valid, but the memif_sched_ready is high.
   // shift the register 
   gpc_gfx_prienc_ones_lsb
   #(
    .W                   ( L2_MEM_SCHED_INSTR_DEPTH )
   ,.OUTPUT_WIDTH        ( L2_MEM_SCHED_INSTR_BITS  ) )
   i_pa_queu_empty_entry (
   .vector               ( ~req_queue_valids        ) ,
   .result               ( pa_queue_empty_entry     ) );
   gpc_gfx_prienc_ones_lsb
   #(
    .W                   ( L2_MEM_SCHED_INSTR_DEPTH )
   ,.OUTPUT_WIDTH        ( L2_MEM_SCHED_INSTR_BITS  ) )
   i_select_row (
   .vector               ( req_queue_same_row_mask        ) ,
   .result               ( req_queue_select_row_index     ) );
   generate 
      for (genvar ENTRY = 0; ENTRY < L2_MEM_SCHED_INSTR_DEPTH-1; ENTRY++) begin: g_update_drop_queue
         always_ff@(posedge clk or negedge resetn) begin
            if (!resetn) begin
               req_queue_valids[ENTRY] <= 1'b0;
               req_queue_entries[ENTRY] <= '0;
               sub_cnt[ENTRY] <= '0;
            end
            else if (select_output_valid && select_output_ready && ENTRY >= select_output_index ) begin
               if (req_queue_valids[ENTRY+1]) begin
                  req_queue_valids[ENTRY] <= req_queue_valids[ENTRY+1];
                  req_queue_entries[ENTRY] <= req_queue_entries[ENTRY+1];
                  sub_cnt[ENTRY] <= sub_cnt[ENTRY+1];
               end
               else begin
                  req_queue_valids[ENTRY] <= 1'b0;
               end
            end
            else if (select_output_valid && select_output_ready && ENTRY < select_output_index) begin
               if (ENTRY >= pa_queue_empty_entry) begin
                  if (select_output_index == ENTRY + 1) begin
                     req_queue_valids[ENTRY] <= 1'b0;
                  end
                  else begin 
                     req_queue_valids[ENTRY] <= req_queue_valids[ENTRY+1];
                     if (req_queue_valids[ENTRY+1]) begin
                        req_queue_entries[ENTRY] <= req_queue_entries[ENTRY+1];
                        sub_cnt[ENTRY] <= sub_cnt[ENTRY+1] - 1'b1;
                     end
                  end
               end
               else if (req_queue_valids[ENTRY]) begin
                  sub_cnt[ENTRY] <= sub_cnt[ENTRY]-1'b1;
               end
            end
            else if (memif_sched_valid && memif_sched_ready && ENTRY >= pa_queue_empty_entry ) begin
               req_queue_valids[ENTRY] <= req_queue_valids[ENTRY+1];
               req_queue_entries[ENTRY] <= req_queue_entries[ENTRY+1];
               sub_cnt[ENTRY] <= sub_cnt[ENTRY+1];
            end
         end
      end
   endgenerate 
   
   always_ff@(posedge clk or negedge resetn) begin: p_update_head_entry
      if (!resetn) begin
         req_queue_valids[L2_MEM_SCHED_INSTR_DEPTH-1] <= 1'b0;
         req_queue_entries[L2_MEM_SCHED_INSTR_DEPTH-1] <= '0;
         sub_cnt[L2_MEM_SCHED_INSTR_DEPTH-1] <= L2_MEM_SCHED_INSTR_DEPTH-1;
      end
      else if (memif_sched_valid && memif_sched_ready) begin
         req_queue_valids[L2_MEM_SCHED_INSTR_DEPTH-1] <= 1'b1;
         req_queue_entries[L2_MEM_SCHED_INSTR_DEPTH-1] <= func_bank_group_sched_2_ring_buffer_entry(memif_sched_rec);
         sub_cnt[L2_MEM_SCHED_INSTR_DEPTH-1] <= L2_MEM_SCHED_INSTR_DEPTH-1;
      end
      else if (select_output_valid && select_output_ready ) begin
         req_queue_valids[L2_MEM_SCHED_INSTR_DEPTH-1] <= 1'b0;
      end
   end

   for (genvar ENTRY = 0; ENTRY < L2_MEM_SCHED_INSTR_DEPTH; ENTRY++) begin: g_lookup_same_bank_same_row
      assign req_queue_same_row_mask[ENTRY] = req_queue_valids[ENTRY] && req_queue_entries[ENTRY].ddr_row == ddr_row_id && req_queue_entries[ENTRY].ddr_bank == ddr_bank_id && ddr_valid;
   end

   logic [DDR_BANK_GROUPS_NUM+2-1:0] priority_valids;
   logic [DDR_BANK_GROUPS_NUM+2-1:0] [L2_MEM_SCHED_INSTR_BITS-1:0]priority_index;

   for (genvar DDR_BANK_GROUP = 0; DDR_BANK_GROUP < DDR_BANK_GROUPS_NUM; DDR_BANK_GROUP++) begin:g_update_diff_bank_priority
      assign diff_bank_output_valid[DDR_BANK_GROUP] = |req_queue_diff_bank_mask[DDR_BANK_GROUP];
      gpc_gfx_prienc_ones_lsb
      #(
       .W                   ( L2_MEM_SCHED_INSTR_DEPTH )
      ,.OUTPUT_WIDTH        ( L2_MEM_SCHED_INSTR_BITS  ) )
      i_select_ddr_bank (
      .vector               ( req_queue_diff_bank_mask[DDR_BANK_GROUP]        ) ,
      .result               ( req_queue_select_bank_index[DDR_BANK_GROUP]     ) );
      assign priority_valids[2+DDR_BANK_GROUP] = diff_bank_output_valid[DDR_BANK_GROUP];
      assign priority_index[2+DDR_BANK_GROUP] = req_queue_select_bank_index[DDR_BANK_GROUP];
      for (genvar ENTRY = 0; ENTRY < L2_MEM_SCHED_INSTR_DEPTH; ENTRY++) begin
         assign req_queue_diff_bank_mask[DDR_BANK_GROUP][ENTRY] = req_queue_valids[ENTRY] && req_queue_entries[ENTRY].ddr_bank[3:1] == bank_group_order[DDR_BANK_GROUP] ;
      end
   end
   assign same_row_output_valid = |req_queue_same_row_mask;


   assign priority_valids[0] = req_queue_valids[0] && sub_cnt[0] == '0;
   assign priority_valids[1] = same_row_output_valid;
   assign priority_index[0] = '0;
   assign priority_index[1] = req_queue_select_row_index;

   always_comb begin
      select_output_index = '0;
      for (int unsigned INDEX = 0; INDEX < DDR_BANK_GROUPS_NUM+2 ; INDEX ++) begin
         if (priority_valids[DDR_BANK_GROUPS_NUM+2-1-INDEX]) 
           select_output_index = priority_index[DDR_BANK_GROUPS_NUM+2-1-INDEX]; 
      end
   end

   assign select_output_buf_rec = req_queue_entries[select_output_index];

 

   assign select_output_valid = |req_queue_valids;
   bank_group_sched_data_bus_t  select_output_rec;
   assign select_output_rec.buffer_index = select_output_buf_rec.buffer_index;
   assign select_output_rec.pa = {select_output_buf_rec.bank, select_output_buf_rec.ddr_row, select_output_buf_rec.ddr_bank,select_output_buf_rec.ddr_column, 6'd0};
   
   gpc_gfx_timing_buffer_#  (
       .BUFFER_TYPE         ( GPC_GFX_TIMING_BUFFER_RSTL        )
      ,.WIDTH               ( $bits(bank_group_sched_data_bus_t )))
   memory_req_timing_buffer (
      .clk                  ( clk                               )
    , .resetn               ( resetn                            )
    , .tbuff_in_valid       ( select_output_valid               )
    , .tbuff_in_enable      ( select_output_ready               )
    , .tbuff_in_data        ( select_output_rec                 )
    
    , .tbuff_out_valid      ( ring_buf_valid                    )
    , .tbuff_out_enable     ( ring_buf_ready                    )
    , .tbuff_out_data       ( ring_buf_rec                      ) );
   
   
   always_ff@(posedge clk or negedge resetn) begin
      if(!resetn) begin
         ddr_valid <= '0;
         ddr_row_id <= '0;
         ddr_bank_id <= '0;
      end
      else if (select_output_valid && select_output_ready) begin
         ddr_valid <= 1'b1;
         ddr_row_id <= select_output_buf_rec.ddr_row;
         ddr_bank_id <= select_output_buf_rec.ddr_bank;
      end
   end
   
   
   assign idle = ~(ring_buf_valid) && ~select_output_valid;
   
   
   assign select_en = select_output_valid && select_output_ready;
   assign select_bank_group = select_output_buf_rec.ddr_bank[3:1];
   
   
   
   
   gc_l2_bank_lru       # (
     .BANK_GROUP_NUM      ( DDR_BANK_GROUPS_NUM                 ) ,
     .BANK_GROUP_BITS     ( DDR_BANK_GROUPS_BITS                 ))
   i_gc_l2_bank_lru       (
      .clk                ( clk               ) ,
      .resetn             ( resetn            ) ,
      
      .select_en          ( select_en         ) ,
      .select_bank_group  ( select_bank_group ) ,
      
      
      .bank_group_order0  ( bank_group_order[0] ) ,
      .bank_group_order1  ( bank_group_order[1] ) ,
      .bank_group_order2  ( bank_group_order[2] ) ,
      .bank_group_order3  ( bank_group_order[3] ) , 
      .bank_group_order4  ( bank_group_order[4] ) ,
      .bank_group_order5  ( bank_group_order[5] ) ,
      .bank_group_order6  ( bank_group_order[6] ) ,
      .bank_group_order7  ( bank_group_order[7] ) );
   

//  synopsys translate_off
default clocking cb@(posedge clk);
endclocking
default disable iff(!resetn);

as__diff_bank_check:
   assert property (ddr_valid && select_output_valid |-> |diff_bank_output_valid);



//  synopsys translate_on
endmodule
// Local Variables:
// verilog-library-directories:("./" ) 
// End:
