/*

 * #==========================================================================#
 * |                                                                          |
 * |  Copyright (c) 2023, Fantasy Technologies Limited and/or its         |
 * |  affiliated group companies ("Fantasy"). All rights reserved.        |
 * |  No part of this content, either material or conceptual may be copied    |
 * |  or distributed, transmitted, transcribed, stored in a retrieval system  |
 * |  or translated into any human or computer language in any form by any    |
 * |  means, electronic, mechanical manual, or otherwise, or disclosed to     |
 * |  third parties without the express written permission of Fantasy.    |
 * |                                                                          |
 * #==========================================================================#

 */

// ---------------------------------------------------------------------------------------------------------------------------------
// Function Name: gpc_prienc_onehot
// Function Type: synthesisable
// Function Input Parameters:
//    vector - any std_logic_vector
// Function Return Value:
//    returns a std_logic_vector with an unsigned value representing the position of the first set bit in the vector, from LSB up
//    width of return vector is log2(input vector length).
// Function Description:
//    The function returns the location of the first set bit in a vector from the LSB upwards
//    If no bits are set, returns all zeroes.
//    If more than one bit is set, the return value is undefined.
//    Examples:
//       gpc_prienc_onehot("00000010") = "001"
//       gpc_prienc_onehot("00000000") = "000"
//    The implementation relies on the input data having no more than 1 bit set, and will have better QoR than gpc_prienc_ones_lsb
//    Whilst written as a recursive function, the implementation is actually a trivial set of OR reductions. e.g. for 8 bit input;
//       result(2)  = or_reduce(vector(7) & vector(6) & vector(5) & vector(4)                                                )
//       result(1)  = or_reduce(vector(7) & vector(6)                         & vector(3) & vector(2)                        )
//       result(0)  = or_reduce(vector(7)             & vector(5)             & vector(3) &           & vector(1)            )
// ---------------------------------------------------------------------------------------------------------------------------------


module gpc_gfx_prienc_onehot #(
      parameter int INPUT_WIDTH = 4
) (
      input  logic [INPUT_WIDTH-1:0]            vector,
      output logic [$clog2(INPUT_WIDTH)-1:0]    result     
);
   //iterate over output bits
   for(genvar b=0; b<$clog2(INPUT_WIDTH); b++) begin : g_output_bits
      localparam b_pow2 = 2**b;
      
      always_comb begin : or_reduce
         logic or_reduce;

         or_reduce = 1'b0;
         //iterate over input bits
         for(int n=0; n<INPUT_WIDTH; n++) begin
            if((n % (2*b_pow2)) >= b_pow2) begin
               or_reduce = or_reduce | vector[n];
            end
         end
         result[b] = or_reduce;       
      end            
   end

endmodule
