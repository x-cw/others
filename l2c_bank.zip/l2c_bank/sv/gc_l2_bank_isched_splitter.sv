// +FHDR----------------------------------------------------------------------------
// Copyright (c) 2025, Innosilicon, Inc. Confidential Proprietary
// PROJECT NAME  : xxx
// DEPARTMENT    : Digtal Frontend GPU MSS
// AUTHOR        : luoml01
// EMAIL         : luoml01@innosilicon.com.cn
// CREATE ON     : 2025/01/03 09:19
// FILE NAME     : gc_l2_bank_isched_splitter.sv
// DESCRIPTION   :          
//         
// Copyright (c) 2025 Innosilicon.
// ALL RIGHTS RESERVED
// 
// ---------------------------------------------------------------------------------
// Modification History:
// Date         By              Version                 Change Description
// ---------------------------------------------------------------------------------
// 2025/01/03   luoml01         1.0                     Original
// 
// -FHDR----------------------------------------------------------------------------


module gc_l2_bank_isched_splitter
import gc_l2_bank_pkg::*;
import gpc_gfx_timing_buffer_pack_::*;
(
      input  logic                        clk,
      input  logic                        resetn,
      output  logic                       idle,
      
      
      input  logic                        req_splitter_valid,
      output logic                        req_splitter_ready,
      input  isched_splitter_record_type  req_splitter_rec,
      
      //cmd to RCTRL
      output logic                        isched_cmd_valid,
      input  logic                        isched_cmd_ready,
      output isched_waiting_record_type   isched_cmd_rec,



      output logic                        isched_iwdb_valid,
      input  logic                        isched_iwdb_ready,
      output isched_iwdb_record_type      isched_iwdb_rec

);

logic [L2_NUM_BEAT -1 :0] wt_beat_mask;
logic [L2_NUM_BEAT -1 :0] beat_wt_wb_mask;
logic [L2_NUM_BEAT -1 :0] wt_wb_full_beat_mask;

logic [L2_BEAT_BITS - 1:0] beat_wt_wb_mask_msb_index;
logic [L2_BEAT_BITS - 1:0] beat_wt_wb_mask_lsb_index;
logic [1:0]                beat_wt_wb_mask_blen;

//logic [L2_BEAT_BITS -1 :0] n_split_beat_count;
logic [L2_BEAT_BITS -1 :0] split_beat_count;
logic [L2_BEAT_BITS -1 :0] current_beat_index;
logic [L2_BEAT_BITS -1 :0] iwdb_split_beat_count;
//logic [L2_BEAT_BITS -1 :0] n_wt_iwdb_index_count;

logic [L2_BEAT_BITS - 1:0] beat_wb_mask_msb_index;
logic [L2_BEAT_BITS - 1:0] beat_wb_mask_lsb_index;
logic [1:0]                beat_wb_mask_blen;
logic                      req_iwdb_already_sent;
               

logic req_cmd_valid;
logic req_cmd_ready;
isched_split_req_cmd_record_t req_cmd_rec;

logic req_cmd_out_valid;
logic req_cmd_out_ready;
isched_split_req_cmd_record_t req_cmd_out_rec;

logic req_iwdb_valid;
logic req_iwdb_ready;
isched_split_req_iwdb_record_t req_iwdb_rec;

logic req_iwdb_out_valid;
logic req_iwdb_out_ready;
isched_split_req_iwdb_record_t req_iwdb_out_rec;




   assign idle  = (req_splitter_valid==1'b0 ? 1'b1:1'b0) && 
                   req_cmd_out_valid==1'b0 && 
                   req_iwdb_out_valid==1'b0;
   
   
   
   always_comb begin: p_wt_start_beat_to_mask
      wt_beat_mask = '0;
      case(req_cmd_out_rec.blen)
         2'b00: wt_beat_mask = 4'b1   << req_cmd_out_rec.start_beat;
         2'b01: wt_beat_mask = 4'b11  << req_cmd_out_rec.start_beat;
         2'b10: wt_beat_mask = 4'b111 << req_cmd_out_rec.start_beat;
         2'b11: wt_beat_mask = 4'b1111;
         default : wt_beat_mask = 4'b0;
      endcase
   end : p_wt_start_beat_to_mask
   
   
   always_comb begin: p_wt_wb_full_beat_to_mask
      wt_wb_full_beat_mask = '0;
      case(beat_wt_wb_mask_blen)
         2'b00: wt_wb_full_beat_mask = 4'b1   << beat_wt_wb_mask_lsb_index;
         2'b01: wt_wb_full_beat_mask = 4'b11  << beat_wt_wb_mask_lsb_index;
         2'b10: wt_wb_full_beat_mask = 4'b111 << beat_wt_wb_mask_lsb_index;
         2'b11: wt_wb_full_beat_mask = 4'b1111;
         default : wt_wb_full_beat_mask = 4'b0;
      endcase
   end : p_wt_wb_full_beat_to_mask
   
   
   
   assign beat_wt_wb_mask = wt_beat_mask | req_cmd_out_rec.beat_dirty_mask; //this signal indicate how many beat need to be output to rctrl
   
   gpc_gfx_prienc_ones_msb_ #(
      .W            ( L2_NUM_BEAT               ) ,
      .OUTPUT_WIDTH ( L2_BEAT_BITS              )
                                                )
   i_wt_dirty_mask_prienc_ones_msb 
                    (
      .vector       ( beat_wt_wb_mask           ) ,
      .result       ( beat_wt_wb_mask_msb_index )
   );
   
   gpc_gfx_prienc_ones_lsb #(
      .W            ( L2_NUM_BEAT               ) ,
      .OUTPUT_WIDTH ( L2_BEAT_BITS              )
                                                )
   i_wt_dirty_mask_prienc_ones_lsb 
                    (
      .vector       ( beat_wt_wb_mask           ) ,
      .result       ( beat_wt_wb_mask_lsb_index )
   );
   
   
   assign beat_wt_wb_mask_blen =  beat_wt_wb_mask_msb_index - beat_wt_wb_mask_lsb_index;
   
   gpc_gfx_prienc_ones_msb_ #(
      .W            ( L2_NUM_BEAT                      ) ,
      .OUTPUT_WIDTH ( L2_BEAT_BITS                     )
                                                       )
   i_wb_dirty_mask_prienc_ones_msb 
                    (
      .vector       ( req_cmd_out_rec.beat_dirty_mask ) ,
      .result       ( beat_wb_mask_msb_index           )
   );
   
   gpc_gfx_prienc_ones_lsb #(
      .W            ( L2_NUM_BEAT                      ) ,
      .OUTPUT_WIDTH ( L2_BEAT_BITS                     )
                                                       )
   i_wb_dirty_mask_prienc_ones_lsb 
                    (
      .vector       ( req_cmd_out_rec.beat_dirty_mask ) ,
      .result       ( beat_wb_mask_lsb_index           )
   );
   
   
   
   
   assign beat_wb_mask_blen = beat_wb_mask_msb_index - beat_wb_mask_lsb_index;


   //decouple the req to RCTRL and IWDB


   always_comb begin : p_split_req_to_cmd_iwdb

      req_splitter_ready          = ~req_splitter_valid;

      req_cmd_valid               = 1'b0;
      req_cmd_rec.start_beat      = req_splitter_rec.start_beat;
      req_cmd_rec.axid            = req_splitter_rec.axid;
      req_cmd_rec.set             = req_splitter_rec.set;
      req_cmd_rec.way             = req_splitter_rec.way;
      req_cmd_rec.is_buffer_mode  = req_splitter_rec.is_buffer_mode;
      req_cmd_rec.instruction     = req_splitter_rec.instruction;
      req_cmd_rec.sector_mask     = req_splitter_rec.sector_mask;
      req_cmd_rec.beat_dirty_mask = req_splitter_rec.beat_dirty_mask;
      req_cmd_rec.check_partial   = req_splitter_rec.check_partial;
      req_cmd_rec.blen            = req_splitter_rec.blen;


      req_iwdb_valid              = 1'b0;
      req_iwdb_rec.iwdb_index     = req_splitter_rec.iwdb_index;
      req_iwdb_rec.instruction    = req_splitter_rec.instruction;
      req_iwdb_rec.blen           = req_splitter_rec.blen;

   //synopsys translate_off
      req_iwdb_rec.axid           = req_splitter_rec.axid;
      req_iwdb_rec.set            = req_splitter_rec.set;
      req_iwdb_rec.way            = req_splitter_rec.way;
      req_iwdb_rec.start_beat     = req_splitter_rec.start_beat;
   //synopsys translate_on     
      
      if(req_splitter_valid==1'b1)begin
         case(req_splitter_rec.instruction)

            WR, AA, WB_WR: begin : p_need_wdata_instruction
               req_cmd_valid = req_iwdb_already_sent | req_iwdb_ready;
               req_iwdb_valid = ~req_iwdb_already_sent;

               req_splitter_ready = req_cmd_ready && (req_iwdb_already_sent || req_iwdb_ready);
            end

            WB, FLUSH, RD: begin : p_not_need_wdata_instrcution
               req_cmd_valid = 1'b1;
               
               req_splitter_ready = req_cmd_ready;
            end
         endcase
      end

   end : p_split_req_to_cmd_iwdb



   always_ff @(posedge clk or negedge resetn)begin
      if(!resetn)begin
         req_iwdb_already_sent <= 1'b0;
      end
      else if(req_cmd_valid && req_cmd_ready)begin
         req_iwdb_already_sent <= 1'b0;
      end
      else if(req_iwdb_valid && req_iwdb_ready)begin
         req_iwdb_already_sent <= 1'b1;
      end
   end



/////////////////////////////////////////////
//RCTRL req split
/////////////////////////////////////////////

   gpc_gfx_rpfifo_ #   (
      .w               ( $bits(req_cmd_rec ) ),
      .d               ( 8                 ) )
   i_tbuff_req_cmd_issue
                       (
      .clk             ( clk               ) ,
      .resetn          ( resetn            ) ,
      .fifo_in_data    ( req_cmd_rec       ) ,
      .fifo_in_valid   ( req_cmd_valid     ) ,
      .fifo_in_enable  ( req_cmd_ready     ) ,
      .fifo_out_data   ( req_cmd_out_rec   ) ,
      .fifo_out_valid  ( req_cmd_out_valid ) ,
      .fifo_out_enable ( req_cmd_out_ready ) );
   



   always_comb begin : p_req_cmd_split_comb

      isched_cmd_valid              = 1'b0;
      isched_cmd_rec.beat           = req_cmd_out_rec.start_beat + split_beat_count;
      isched_cmd_rec.axid           = req_cmd_out_rec.axid;
      isched_cmd_rec.set            = req_cmd_out_rec.set;
      isched_cmd_rec.way            = req_cmd_out_rec.way;
      isched_cmd_rec.sector_mask    = req_cmd_out_rec.sector_mask;
      isched_cmd_rec.is_buffer_mode = req_cmd_out_rec.is_buffer_mode;
      isched_cmd_rec.instruction    = req_cmd_out_rec.instruction;
      isched_cmd_rec.last           = 1'b0;
      isched_cmd_rec.check_partial  = '0;

      req_cmd_out_ready             = ~req_cmd_out_valid;

      if(req_cmd_out_valid==1'b1)begin

         isched_cmd_valid = 1'b1;

         case(req_cmd_out_rec.instruction)
            WB_WR : begin 
               isched_cmd_rec.last = (split_beat_count==beat_wt_wb_mask_blen);
               isched_cmd_rec.beat = beat_wt_wb_mask_lsb_index + split_beat_count;
               
               if(wt_beat_mask[current_beat_index]==1'b1)begin          //in the range of WT, it must be WB_WR, even if the beat is not dirty
                  if(split_beat_count==beat_wt_wb_mask_blen)begin
                     req_cmd_out_ready = isched_cmd_ready;
                  end

                  isched_cmd_rec.instruction = WB_WR;
               end
               else if(wt_wb_full_beat_mask[current_beat_index]==1'b1)begin   //except the WT beat, the rest of valid beat must be WB, even if the beat is not dirty

                  if(split_beat_count==beat_wt_wb_mask_blen)begin
                     req_cmd_out_ready = isched_cmd_ready;
                  end

                  isched_cmd_rec.instruction = WB;
               end
            end

            WB, FLUSH : begin 
               isched_cmd_rec.beat = beat_wb_mask_lsb_index + split_beat_count;

               if(split_beat_count==beat_wb_mask_blen)begin
                  isched_cmd_rec.last = 1'b1;
                  req_cmd_out_ready = isched_cmd_ready;
               end
            end

            default : begin  //WR, AA, RD
               isched_cmd_rec.check_partial = req_cmd_out_rec.check_partial;
               isched_cmd_rec.beat = req_cmd_out_rec.start_beat + split_beat_count;

               if(split_beat_count==req_cmd_out_rec.blen)begin
                  isched_cmd_rec.last = 1'b1;
                  req_cmd_out_ready = isched_cmd_ready;
               end
            end
         endcase
      end
   end : p_req_cmd_split_comb


   assign current_beat_index = beat_wt_wb_mask_lsb_index + split_beat_count;



   always_ff@(posedge clk or negedge resetn) begin : p_counter_for_split_clkdrs
      if(resetn==1'b0) begin
         split_beat_count <= '0;
         iwdb_split_beat_count <= '0;
      end
      else begin
         if (req_cmd_out_valid && req_cmd_out_ready) begin
            split_beat_count <= '0;
         end
         else if (isched_cmd_valid && isched_cmd_ready) begin
            split_beat_count <= split_beat_count + 1'b1;
         end
   
         if (req_iwdb_out_valid && req_iwdb_out_ready) begin
            iwdb_split_beat_count <= '0;
         end
         else if (isched_iwdb_valid && isched_iwdb_ready) begin
            iwdb_split_beat_count <= iwdb_split_beat_count + 1'b1;
         end
      end
   end : p_counter_for_split_clkdrs

   




/////////////////////////////////////////////
//iwdb req split
/////////////////////////////////////////////


   gpc_gfx_rpfifo_ #(
      .w               ( $bits(req_iwdb_rec ) ),
      .d               ( 8                  )
                                            )
   i_isched_iwdb_cmd_fifo 
                       (
      .clk             ( clk                ) ,
      .resetn          ( resetn             ) ,
      .fifo_in_valid   ( req_iwdb_valid     ) ,
      .fifo_in_enable  ( req_iwdb_ready     ) ,
      .fifo_in_data    ( req_iwdb_rec       ) ,
      .fifo_out_valid  ( req_iwdb_out_valid ) ,
      .fifo_out_enable ( req_iwdb_out_ready ) ,
      .fifo_out_data   ( req_iwdb_out_rec   )
   );



   always_comb begin : p_iwdb_cmd_split_comb
      isched_iwdb_rec.iwdb_index  = ((req_iwdb_out_rec.iwdb_index + iwdb_split_beat_count) >= L2_IWDB_DEPTH) ? req_iwdb_out_rec.iwdb_index + iwdb_split_beat_count - L2_IWDB_DEPTH : req_iwdb_out_rec.iwdb_index + iwdb_split_beat_count;
      isched_iwdb_rec.instruction = req_iwdb_out_rec.instruction;
      isched_iwdb_rec.last        = 1'b0;

      isched_iwdb_valid           = 1'b0;

      req_iwdb_out_ready          = ~req_iwdb_out_valid;

      //synopsys translate_off
      isched_iwdb_rec.axid        = req_iwdb_out_rec.axid;
      isched_iwdb_rec.set         = req_iwdb_out_rec.set;
      isched_iwdb_rec.way         = req_iwdb_out_rec.way;
      isched_iwdb_rec.beat        = req_iwdb_out_rec.start_beat + iwdb_split_beat_count;
      //synopsys translate_on

      if(req_iwdb_out_valid==1'b1)begin
         isched_iwdb_valid = 1'b1;

         if(iwdb_split_beat_count==req_iwdb_out_rec.blen)begin
            isched_iwdb_rec.last = 1'b1;
            req_iwdb_out_ready = isched_iwdb_ready;
         end
      end
   end : p_iwdb_cmd_split_comb




   




endmodule
// Local Variables:
// verilog-library-flags:("-y ./ -y ../")
// verilog-auto-inst-param-value:t
// End:
