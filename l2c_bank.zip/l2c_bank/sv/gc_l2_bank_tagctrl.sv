// ---------------------------------------------------------------------------------
// Project Name  : IC_Design
// Author        : liusm
// Email         : liusm@innosilicon.com.cn
// Create On     : 2024/12/18 10:07
// Last Modified : 2025/09/16 17:51
// File Name     : gc_l2_bank_tagctrl.sv
// Description   :
// 
// Copyright (c) 2024 Innosilicon.
// ALL RIGHTS RESERVED
// 
// ---------------------------------------------------------------------------------
// Modification History:
// Date         By              Version                 Change Description
// ---------------------------------------------------------------------------------
// 2024/12/18   liusm           1.0                     Original
// 
// ----------------------------------------------------------------------------------


module gc_l2_bank_tagctrl
import gc_l2_bank_pkg::*;
(
      input    logic                                                       clk
,     input    logic                                                       resetn

,     output   logic                                                       tagctrl_idle


,     input    logic                                                       align_tagctrl_valid
,     output   logic                                                       align_tagctrl_ready
,     input    align_tagctrl_record_type                                   align_tagctrl_rec

,     output   logic                                                       tagctrl_isched_valid
,     input    logic                                                       tagctrl_isched_ready
,     output   tagctrl_isched_record_type                                  tagctrl_isched_rec

,     output   logic                                                       tagctrl_align_cfi_complete

,     output   logic                                                       tagctrl_memif_valid
,     input    logic                                                       tagctrl_memif_ready
,     output   tagctrl_memif_record_type                                   tagctrl_memif_rec



,     input    logic                                                       memif_tagctrl_valid
,     input    memif_tagctrl_record_type                                   memif_tagctrl_rec 
,     output   logic                                                       tagctrl_memif_wb_finish

,     input    logic                                                       memif_tagctrl_cfi_decrease_valid
,     input    logic [L2_MAX_CFI_BITS-1:0]                                 memif_tagctrl_cfi_id


,     input    logic                            [L2_NUM_RCTRL-1:0]         rctrl_tagctrl_wb_done_valid
,     input    rctrl_isched_record_type         [L2_NUM_RCTRL-1:0]         rctrl_tagctrl_wb_rec

,     output   logic                            [L2_NUM_RCTRL-1:0]         tagctrl_rctrl_clr_valid
,     output   tagctrl_rctrl_clr_record_type    [L2_NUM_RCTRL-1:0]         tagctrl_rctrl_clr_rec

,     input    logic                            [L2_NUM_RCTRL-1:0]         rctrl_tagctrl_valid
,     input    rctrl_tagctrl_record_type        [L2_NUM_RCTRL-1:0]         rctrl_tagctrl_rec

,     output   logic                                                       l2b_hittest_ht_bypass_read_wl
,     output   logic                                                       l2b_hittest_ht_cache_read_wl
,     output   logic                                                       l2b_hittest_ht_bypass_write_wl
,     output   logic                                                       l2b_hittest_ht_cache_write_wl
,     output   logic                                                       l2b_hittest_ht_atomic_wl
,     output   logic                                                       l2b_hittest_ht_bps_hit_wl
,     output   logic                                                       l2b_hittest_ht_miss_wl

,     input    logic  [1:0]                                                gc_cr_l2_buffer_mode_percentage
,     input    logic                                                       gc_cr_l2_function_enable_bypass_mode

,     input    logic                                                       tst_gclkenable
);

 // input arbiter has three sources: align request, overflow fifo, hazard
 // table
 // overflow fifo request will block the align request. 

   logic                                        hazard_table_request_valid                                     ;
   logic                                        hazard_table_request_ready                                     ;
   tagctrl_pipeline_record_type                 hazard_table_rec                                               ;

   logic                                        overflow_fifo_valid                                            ;
   logic                                        overflow_fifo_ready                                            ;
   tagctrl_pipeline_record_type                 overflow_fifo_rec                                              ;


   logic                                        arbiter_valid                                                  ;
   logic                                        arbiter_ready                                                  ;
   tagctrl_pipeline_record_type                 arbiter_request_rec                                            ;

   logic                                        n_overflow_fifo_valid                                          ;
   logic                                        request_pipe_empty                                             ;
   logic                                        hazard_table_empty                                             ;

   logic                                        stage0_vs_stage3_hazard                                        ;
   logic                                        stage1_vs_stage3_hazard                                        ;
   logic                                        stage2_vs_stage1_hazard                                        ;

   tagctrl_pipeline_record_type                 n_request_stage0_rec                                           ;

   logic                                        request_stage0_valid                                           ;
   logic                                        request_stage0_ready                                           ;
   tagctrl_pipeline_record_type                 request_stage0_rec                                             ;


   logic                                        request_stage1_valid                                           ;
   logic                                        request_stage1_ready                                           ;
   tagctrl_pipeline_record_type                 request_stage1_rec                                             ;
   logic [L2_TAGRAM_WIDTH-1:0]                  request_stage1_data                                            ;

   logic                                        stalled_stage1_data_valid                                      ;
   logic [L2_TAGRAM_WIDTH-1:0]                  stalled_stage1_data                                            ;

   logic                                        request_stage2_valid                                           ;
   logic                                        request_stage2_ready                                           ;
   tagctrl_pipeline_record_type                 request_stage2_rec                                             ;
   logic [L2_TAGRAM_WIDTH-1:0]                  request_stage2_data                                            ;
   logic [L2_TAGRAM_WIDTH-1:0]                  n_request_stage2_data                                          ;
   logic                                        request_stage2_hit                                             ;
   logic [L2_NUM_WAY_BITS-1:0]                  request_stage2_hit_way                                         ;

   logic [L2_NUM_SET-1:0][L2_NUM_WAY-1:0] [L2_REF_CNT_BITS-1:0]             access_counter_array                 ;
   logic [L2_NUM_SET-1:0][L2_NUM_WAY-1:0] [L2_REF_CNT_BITS-1:0]             n_access_counter_array               ;
   logic [L2_NUM_SET-1:0][L2_NUM_WAY-1:0] [L2_NUM_SECTOR-1:0]               partial_array                        ;
   logic [L2_NUM_SET-1:0][L2_NUM_WAY-1:0] [L2_NUM_SECTOR-1:0]               n_partial_array                      ;
   logic [L2_NUM_WAY-1:0] [L2_REF_CNT_BITS-1:0]                             selected_access_counter_array        ;
   logic [L2_NUM_WAY-1:0] [L2_REF_CNT_BITS-1:0]                             masked_selected_access_counter_array ;
   logic [L2_NUM_WAY-1:0] [L2_NUM_SECTOR-1:0]   selected_partial_array                                         ;
   logic [L2_NUM_WAY-1:0]                       cacheline_enable                                               ;
   logic [L2_NUM_WAY-1:0]                       request_stage2_hit_mask                                        ;
   

   logic [L2_NUM_WAY-1:0]                       avaliable_cachelines_for_replace                               ;
   logic [L2_NUM_WAY-1:0]                       request_stage2_cfi_done_mask                                   ;
   logic [L2_NUM_WAY-1:0]                       request_stage2_cfi_need_mask                                   ;
   tagctrl_ram_data_record_type                 request_stage2_tag_ram_rec                                     ;
   tagctrl_cacheline_status_record_type         selected_cacheline_status                                      ;
   logic                                        request_stage2_replace_valid                                   ;
   logic [L2_NUM_WAY_BITS-1:0]                  request_stage2_replace_way                                     ;
   logic [L2_NUM_WAY_BITS-1:0]                  request_stage2_evict_way                                       ;
   logic [L2_NUM_WAY-1:0]                       request_stage2_replace_mask                                    ;
   logic [L2_NUM_WAY-2:0 ]                      n_plru_bits_when_hit                                           ;
   logic [L2_NUM_WAY-2:0]                       n_plru_bits_when_replace                                       ;
   cacheline_status_record_type                 request_stage2_hit_way_status                                  ;
   logic [L2_NUM_SECTOR-1:0]                    request_stage2_sector_access_mask                              ;
   logic [1:0]                                  request_stage2_end_beat                                        ;
   logic [1:0]                                  n_request_stage2_partial_when_load                             ;
   sector_status_record_type                    request_stage2_hit_sector0_status                              ;
   sector_status_record_type                    request_stage2_hit_sector1_status                              ;
   sector_status_record_type                    request_stage2_hit_sector                                      ; // only usefull when access one sector
   sector_status_record_type                    request_stage2_miss_sector                                     ; // another sector. only used when access one sector but care about anther sector status
   l2_bank_cl_status_record_type                request_stage2_hit_sector_status                               ;
   l2_bank_cl_status_record_type                request_stage2_miss_sector_status                              ;
   logic                                        request_stage2_replace_dirty                                   ;
   logic                                        request_stage2_hit_dirty                                       ;
   logic                                        request_stage2_wb_valid                                        ;
   logic                                        request_stage2_hazard_valid                                    ;
   logic [L2_NUM_SET-1:0]                       request_stage2_set_mask          ;
   logic [L2_NUM_SET-1:0]                       n_request_stage2_set_mask        ;
   tagctrl_cacheline_status_record_type         n_request_stage3_tag_ram_rec                                   ;
   logic                                        request_stage2_cfi_inc                                         ;
   logic [1:0]                                  request_stage2_linefill_waiting                                ;
   logic                                        request_stage2_wb_waiting                                      ; 
   logic [L2_WB_BUF_DEPTH-1:0]                  request_stage2_lookup_wb_buf_mask                         ;
   logic                                        request_stage2_clr_valid                                       ; 
   logic                                        request_stage3_valid                                           ;
   logic [L2_TAGRAM_P_BITS-1:0]                 request_stage3_wen                                             ;
   tagctrl_pipeline_record_type                 request_stage3_rec                                             ;
   logic [L2_TAGRAM_WIDTH-1:0]                  request_stage3_data                                            ;
   tagctrl_pipeline_record_type                 n_request_stage3_rec                                           ;
   logic [L2_TAGRAM_WIDTH-1:0]                  n_request_stage3_data                                          ;
   logic                                        n_request_stage3_valid                                         ;
   logic [L2_TAGRAM_P_BITS-1:0]                 n_request_stage3_wen                                           ;
   
   logic [L2_TAGRAM_WIDTH-1:0]                  forward_request_stage3_stage0                                  ;
   logic [L2_TAGRAM_WIDTH-1:0]                  sram_output                                                    ;
   logic                                        readen                                                         ;


   l2_bank_cacheline_instr_type                 request_stage2_cl_instruction                                  ;
   logic [L2_NUM_WAY_BITS-1:0]                  request_stage2_cfi_selected_way                                ;
   logic [L2_NUM_WAY-1:0]                       n_request_stage2_cfi_done_mask                                 ;

   logic                                        memif_req_issued                                               ;
   logic                                        isched_req_issued                                              ;


   logic [L2_WB_BUF_DEPTH-1:0]                  inflight_wb_valids                                             ;
   logic                                        inflight_wb_allocate_valid                                     ;
   logic                                        inflight_wb_allocate_ready                                     ;
   logic [L2_WB_BUF_INDEX_BITS-1:0]             inflight_wb_allocate_index                                     ;
   wb_buffer_type [L2_WB_BUF_DEPTH-1:0]         inflight_wb_entries                                            ;
   logic                                        inflight_wb_allocated                                          ;
   logic [L2_NUM_WAY_BITS-1:0]                  inflight_wb_allocated_way                                      ;

   logic [7:0]                                  cfi_counters [L2_NUM_MAX_CFI-1:0]                              ;
   logic [L2_MAX_CFI_BITS-1:0]                  cfi_pointer                                                    ;


   logic                                        cfi_fifo_in_valid                                              ;
   logic                                        cfi_fifo_in_ready                                              ;
   logic [L2_MAX_CFI_BITS+AXI_INST_WIDTH-1:0]   cfi_fifo_in_data                                               ;
   logic                                        cfi_fifo_out_valid                                             ;
   logic                                        cfi_fifo_out_ready                                             ;
   logic [L2_MAX_CFI_BITS+AXI_INST_WIDTH-1:0]   cfi_fifo_out_data                                              ;
   l2_bank_instr_type                           cfi_fifo_out_instruction                                       ;
   logic [L2_MAX_CFI_BITS-1:0]                  cfi_fifo_out_pointer                                           ;
   

   logic [L2_WB_BUF_DEPTH-1:0]                                    memif_lookup_wb_buf_mask;
   logic [L2_WB_BUF_DEPTH-1:0][L2_NUM_RCTRL-1:0]                  rctrl_lookup_wb_buf_mask   ;

   logic [L2_NUM_WAY-1:0][L2_REF_CNT_BITS-1:0]  n_selected_access_counter;
   logic [L2_NUM_WAY-1:0][L2_REF_CNT_BITS-1:0]  n_stage3_access_counter;



   assign tagctrl_idle = ~(request_stage0_valid | request_stage1_valid | request_stage2_valid | request_stage3_valid | cfi_fifo_out_valid | (|(inflight_wb_valids))  );

   // ==============================================================================
   // input arbiter:  arbiter among align request, overflow fifo request,
   // hazard table request
   // ==============================================================================
   logic is_bypass_read;
   assign is_bypass_read = align_tagctrl_rec.instruction == AXI_RD && l2_bank_axcahe_cache_policy(align_tagctrl_rec.axcache, gc_cr_l2_function_enable_bypass_mode);
   always_comb begin
      align_tagctrl_ready        = 1'b0;
      hazard_table_request_ready = 1'b0;
      overflow_fifo_ready        = 1'b0;
      arbiter_valid              = 1'b0;
      arbiter_request_rec        = '0;
      if (overflow_fifo_valid) begin
         if (hazard_table_request_valid) begin
            arbiter_valid = 1'b1;
            hazard_table_request_ready = arbiter_ready;
            arbiter_request_rec = hazard_table_rec;
         end
         else if(hazard_table_empty) begin
            arbiter_valid  = 1'b1;
            overflow_fifo_ready = arbiter_ready;
            arbiter_request_rec = overflow_fifo_rec;
         end
      end
      else if (hazard_table_request_valid) begin
         arbiter_valid = 1'b1;
         hazard_table_request_ready = arbiter_ready;
         arbiter_request_rec = hazard_table_rec;
      end
      else if (n_overflow_fifo_valid == 1'b0 && align_tagctrl_valid) begin
         arbiter_request_rec.instruction   = align_tagctrl_rec.instruction;
         arbiter_request_rec.axid          = align_tagctrl_rec.axid;
         arbiter_request_rec.addr_tag      = align_tagctrl_rec.addr[L2_TAG_MSB_BITS:L2_TAG_LSB_BITS];
         arbiter_request_rec.set           = align_tagctrl_rec.addr[L2_TAG_LSB_BITS-1-:L2_NUM_SET_BITS];
         arbiter_request_rec.start_beat    = align_tagctrl_rec.addr[L2_BEAT_ALIGN_BITS+:L2_BEAT_BITS];
         arbiter_request_rec.iwdb_index    = align_tagctrl_rec.iwdb_index;
         arbiter_request_rec.blen          = align_tagctrl_rec.blen;
         arbiter_request_rec.burst         = align_tagctrl_rec.burst;
         arbiter_request_rec.cache_policy  = l2_bank_axcahe_cache_policy(align_tagctrl_rec.axcache, gc_cr_l2_function_enable_bypass_mode); 
         arbiter_request_rec.persistence   = align_tagctrl_rec.persistence;
         arbiter_request_rec.prefetch_size = is_bypass_read ? 1'b0 : align_tagctrl_rec.prefetch_size;
         if (l2_bank_operation_need_unroll(align_tagctrl_rec.instruction)) begin
            if (request_pipe_empty == 1'b1 && hazard_table_empty && overflow_fifo_valid == 1'b0) begin // CFI can be executed when the pipeline, hazard table and overflow fifo are empty.
               arbiter_valid = 1'b1;
               align_tagctrl_ready = arbiter_ready;
            end
         end 
         else begin
            arbiter_valid = align_tagctrl_valid;
            align_tagctrl_ready = arbiter_ready;
         end
      end
   end
   assign request_pipe_empty = ~(request_stage0_valid | request_stage1_valid | request_stage2_valid);
   // ==============================================================================
   // unroll: 
   // cfi and persistence reset, all the pipeline shall be cleared
   // including hazard_table and overflow fifo
   // arbiter_valid, arbiter_ready -> request0_valid, request0_ready
   // ==============================================================================
   logic n_request_stage0_valid;
   always_comb begin    // cfi unroll
      arbiter_ready = ~request_stage0_valid | request_stage0_ready;
      n_request_stage0_rec = arbiter_request_rec;
      n_request_stage0_valid = arbiter_valid;
      if (request_stage0_valid & request_stage0_ready) begin 
         if (l2_bank_operation_need_unroll(request_stage0_rec.instruction)) begin
            if (!(&request_stage0_rec.set)) begin// the last cycle to unroll cfi
               n_request_stage0_rec = request_stage0_rec;
               n_request_stage0_rec.set = request_stage0_rec.set + 1'b1;
               arbiter_ready = 1'b0;
               n_request_stage0_valid = request_stage0_valid;
            end
            else begin
               if (l2_bank_operation_need_unroll(arbiter_request_rec.instruction))
                  n_request_stage0_rec.set = 8'h0; // for continuous cfi instruction
            end
         end
         else if (arbiter_valid)begin
            if (l2_bank_operation_need_unroll(arbiter_request_rec.instruction)) begin
               n_request_stage0_rec.set = 8'h0;
            end
         end
      end
      else if (arbiter_valid) begin // the first cycle to unroll cfi
         if (l2_bank_operation_need_unroll(arbiter_request_rec.instruction)) begin // the first cycle to unroll cfi
            n_request_stage0_rec.set = 8'h0;
         end
      end
   end

   // here use a regiter to beak the timing path of valid and data. But maybe it is needed to break the ready path or valid-ready path
   always_ff@(posedge clk or negedge resetn) begin
      if (!resetn) begin
         request_stage0_valid <= 1'b0;
         request_stage0_rec <= '0;
      end
      else if ((request_stage0_valid & request_stage0_ready) | (arbiter_valid & arbiter_ready)) begin
         request_stage0_valid <= n_request_stage0_valid;
         request_stage0_rec <= n_request_stage0_rec;
      end
   end


   assign request_stage0_ready = !request_stage1_valid | request_stage1_ready;

   // ==============================================================================
   // stage 1:  read sram 
   // ==============================================================================

   assign readen = (request_stage0_valid ) & !(request_stage3_valid && request_stage0_rec.set == request_stage3_rec.set);
   gpu_core_mss_gfx_dpstore
   #(
       .w     ( L2_TAGRAM_WIDTH        ) ,
       .p     ( L2_TAGRAM_P            ) ,
       .d     ( L2_NUM_SET             ) ,
       .log2d ( L2_NUM_SET_BITS        ) ,
       .id    ( 30002                  )
                                       )
   i_tagram_dpsram     (
    .CLKA     ( clk                    )
   ,.CENA     ( !readen                )
   ,.AA       ( request_stage0_rec.set )
   ,.QA       ( sram_output            )
   ,.CLKB     ( clk                    )
   ,.CENB     ( !request_stage3_valid  )
   ,.WENB     ( request_stage3_wen     )
   ,.AB       ( request_stage3_rec.set )
   ,.DB       ( request_stage3_data    )
   ,.TE       ( tst_gclkenable         )
   ,.L2M      (                        )
   ,.SRAM     (                        )
   );
   
   // forward stage 3 data to stage 0
   assign stage0_vs_stage3_hazard = request_stage0_valid    && request_stage0_ready &&  request_stage3_valid && request_stage0_rec.set == request_stage3_rec.set;
   assign stage1_vs_stage3_hazard = request_stage1_valid    && request_stage3_valid &&  request_stage1_rec.set == request_stage3_rec.set;
   assign stage2_vs_stage1_hazard = n_request_stage3_valid  && request_stage1_valid &&  n_request_stage3_rec.set == request_stage1_rec.set ;
   
   logic forward_stage3_to_stage0_en;
   always_ff@(posedge clk or negedge resetn) begin
      if (!resetn) begin
         forward_stage3_to_stage0_en <= 1'b0;
         forward_request_stage3_stage0 <= '0;
      end
      else if (stage0_vs_stage3_hazard) begin
         forward_stage3_to_stage0_en <= 1'b1;
         forward_request_stage3_stage0 <= request_stage3_data;
      end 
      else begin
         forward_stage3_to_stage0_en <= 1'b0;
      end
   end


   always_ff@(posedge clk or negedge resetn) begin
      if (!resetn) begin
         request_stage1_valid <= 1'b0;
         request_stage1_rec <= '0;
      end
      else if (request_stage0_valid & request_stage0_ready) begin
         request_stage1_valid <= 1'b1;
         request_stage1_rec <= request_stage0_rec;
      end 
      else if (request_stage1_valid & request_stage1_ready) begin
         request_stage1_valid <= 1'b0;
      end
   end
   // register the data when pipeline is stalled
   always_ff@(posedge clk or negedge resetn) begin
      if (!resetn) begin
         stalled_stage1_data_valid <= 1'b0;
         stalled_stage1_data <= '0;
      end
      else if (request_stage1_valid & !request_stage1_ready) begin
         stalled_stage1_data_valid <= 1'b1;
         stalled_stage1_data <= request_stage1_data;
      end 
      else if (request_stage1_valid & request_stage1_ready) begin
         stalled_stage1_data_valid <= 1'b0;
      end
   end


   assign request_stage1_data = (stage2_vs_stage1_hazard ) ? n_request_stage3_data : // forward stage 2 to stage 1
                                (stage1_vs_stage3_hazard    )? request_stage3_data : // forward stage 3 to stage 1;
                                (stalled_stage1_data_valid  )? stalled_stage1_data : // stalled;
                                (forward_stage3_to_stage0_en)? forward_request_stage3_stage0 : // forward stage 3 to stage 0
                                sram_output;

   assign request_stage1_ready = !request_stage2_valid | request_stage2_ready;

   // ==============================================================================
   // stage 2: perform hit test 
   // ==============================================================================
  

   assign n_request_stage2_data =request_stage1_data;
   
   if (L2_NUM_SET == 256) begin
      assign n_request_stage2_set_mask = func_binary_to_onehot_256bits(request_stage1_rec.set);
   end
   if (L2_NUM_SET == 128) begin
      assign n_request_stage2_set_mask = func_binary_to_onehot_128bits(request_stage1_rec.set);
   end
   
   always_ff@(posedge clk or negedge resetn) begin
      if (!resetn) begin
         request_stage2_valid <= 1'b0;
         request_stage2_rec <= '0;
         request_stage2_data <= '0;
         request_stage2_set_mask <= 1;
      end
      else if (request_stage1_valid & request_stage1_ready) begin
         request_stage2_valid <= 1'b1;
         request_stage2_rec <= request_stage1_rec;
         request_stage2_data <= n_request_stage2_data;
         request_stage2_set_mask <= n_request_stage2_set_mask;
      end 
      else if (request_stage2_valid & request_stage2_ready) begin
         request_stage2_valid <= 1'b0;
      end
   end
   
   always_ff@(posedge clk or negedge resetn) begin
      if(!resetn) begin
         for (int unsigned WAY = 0; WAY < L2_NUM_WAY; WAY++) begin
            selected_access_counter_array[WAY] <= '0;
         end
      end
      else if (request_stage1_valid && request_stage1_ready) begin
         selected_access_counter_array <= n_selected_access_counter;
      end
      else if (request_stage2_valid) begin
         selected_access_counter_array <= n_stage3_access_counter;
      end
   end


   always_ff@(posedge clk or negedge resetn) begin
      if(!resetn) begin
         for (int unsigned WAY = 0; WAY < L2_NUM_WAY; WAY++) begin
            selected_partial_array[WAY] <= '0;
         end          
      end
      else if (request_stage1_valid && request_stage1_ready) begin
         if (n_request_stage3_valid && n_request_stage3_rec.set == request_stage1_rec.set)
            selected_partial_array <= n_request_stage3_tag_ram_rec.partial; 
         else begin
            selected_partial_array <= partial_array[request_stage1_rec.set];
         end
      end
      else if (n_request_stage3_valid && n_request_stage3_rec.set == request_stage1_rec.set) begin
          selected_partial_array <= n_request_stage3_tag_ram_rec.partial; 
      end
   end

   // ==============================================================================
   // stage 2: trasfer the tag ram data to record 
   // ==============================================================================
   
   always_ff@(posedge clk or negedge resetn) begin
      if(!resetn) begin
         cacheline_enable <= '0; 
      end
      else begin
          case (gc_cr_l2_buffer_mode_percentage)
            2'b00: cacheline_enable <= 8'd0; // active low
            2'b01: cacheline_enable <= 8'b1100_0000;
            2'b10: cacheline_enable <= 8'b1111_0000;
            2'b11: cacheline_enable <= 8'b1111_1100;
          endcase
      end
   end
   //always_comb begin
   //   case (gc_cr_l2_buffer_mode_percentage)
   //      2'b00: cacheline_enable = 8'd0; // active low
   //      2'b01: cacheline_enable = 8'b1100_0000;
   //      2'b10: cacheline_enable = 8'b1111_0000;
   //      2'b11: cacheline_enable = 8'b1111_1100;
   //   endcase
   //end
    
   generate 
      for (genvar way = 0; way < L2_NUM_WAY; way ++) begin: g_lookup_stage
         assign masked_selected_access_counter_array[way] = selected_access_counter_array[way] | {L2_REF_CNT_BITS{cacheline_enable[way]}};
         assign avaliable_cachelines_for_replace[way] = masked_selected_access_counter_array[way] == '0 ; // 1 means the cacheline can be replaced; 0 means the cacheline cannt be replaced
         assign request_stage2_hit_mask[way]          = selected_cacheline_status.addr_tag[way] == request_stage2_rec.addr_tag && (request_stage2_tag_ram_rec.valid[way] != 2'b00);
         assign request_stage2_cfi_need_mask[way]     = request_stage2_tag_ram_rec.valid[way] != 2'b00;
      end
   endgenerate

   assign request_stage2_hit = |request_stage2_hit_mask;
   assign request_stage2_hit_way = func_onehot_to_binary_8bits(request_stage2_hit_mask);

   // selecte a cacheline to replace when miss. The cacheline can be replaced
   // only when access_counter == 0
   // 1. empty cacheline
   // 2. cacheline with persistence == 0
   // 3. cacheline with persistence == 1
   // 4. cacheline with persistence == 2
   // 5. cacheline with persistence == 3
   gc_l2_bank_cal_plru     
   i_cal_stage2_plru       (
      .avaliable_cacheline ( avaliable_cachelines_for_replace      ) , // 0 means cacheline can be replaced. 1 means cannot be replaced
      .ways_valids         ( request_stage2_tag_ram_rec.valid      ) ,
      .persistences        ( selected_cacheline_status.persistence ) ,
      .plru_bits           ( request_stage2_tag_ram_rec.plru_bits  ) ,
      .replace_way         ( request_stage2_evict_way              ) );

   logic [L2_NUM_WAY_BITS-1:0] request_stage2_allocated_way;
   logic request_stage2_allocated_valid;
   
   // when a clean/invalid cacheline is allocated and issued to isched, it is possible that the replace way still changes.  It is illegal to issue another way to memif. register the replaced way. 
   always_ff@(posedge clk or negedge resetn) begin
      if(!resetn) begin
         request_stage2_allocated_way <= '0;
         request_stage2_allocated_valid <= '0;         
      end
      else if (request_stage2_valid && request_stage2_ready)begin
          request_stage2_allocated_valid <= 1'b0;
      end
      else if (tagctrl_isched_valid && tagctrl_isched_ready && ~request_stage2_hit) begin 
          request_stage2_allocated_valid <= 1'b1;
          request_stage2_allocated_way <= request_stage2_evict_way;
      end
   end


   assign request_stage2_replace_valid =  (|avaliable_cachelines_for_replace || inflight_wb_allocated || request_stage2_allocated_valid);
   assign request_stage2_replace_way = (inflight_wb_allocated) ? inflight_wb_allocated_way : (request_stage2_allocated_valid) ?  request_stage2_allocated_way : request_stage2_evict_way;
   assign request_stage2_replace_mask = func_binary_to_onehot_8bits(request_stage2_replace_way); 
   
   // bypass request doesnt update plru bits
   assign n_plru_bits_when_hit = update_plru_bits_8ways(request_stage2_hit_mask, request_stage2_tag_ram_rec.plru_bits); 
   assign n_plru_bits_when_replace = update_plru_bits_8ways(request_stage2_replace_mask, request_stage2_tag_ram_rec.plru_bits); 



   assign request_stage2_tag_ram_rec = func_tagctrl_ram_data_slv2rec(request_stage2_data);
   assign selected_cacheline_status = func_tagctrl_tagram_selected_cacheline_packed(request_stage2_tag_ram_rec, 
                                                                                    masked_selected_access_counter_array, 
                                                                                    selected_partial_array);
   assign request_stage2_hit_way_status.valid           = selected_cacheline_status.valid           [request_stage2_hit_way];
   assign request_stage2_hit_way_status.beat_dirty_mask = selected_cacheline_status.beat_dirty_mask [request_stage2_hit_way];
   assign request_stage2_hit_way_status.partial         = selected_cacheline_status.partial         [request_stage2_hit_way];
   assign request_stage2_hit_way_status.touched_mask    = selected_cacheline_status.touched_mask    [request_stage2_hit_way];
   assign request_stage2_hit_way_status.access_counter  = selected_cacheline_status.access_counter  [request_stage2_hit_way];
   assign request_stage2_hit_way_status.addr_tag        = selected_cacheline_status.addr_tag        [request_stage2_hit_way];
   assign request_stage2_hit_way_status.persistence     = selected_cacheline_status.persistence     [request_stage2_hit_way];

   assign request_stage2_end_beat = request_stage2_rec.start_beat + request_stage2_rec.blen; // start_beat + blen is constranted to less than 4 
   assign request_stage2_sector_access_mask[0] = ~request_stage2_rec.start_beat[1];
   assign request_stage2_sector_access_mask[1] = request_stage2_end_beat[1];

     
   always_comb begin
      n_request_stage2_partial_when_load = 2'b00;
      if (request_stage2_hit) 
         if (request_stage2_rec.prefetch_size)
            n_request_stage2_partial_when_load = 2'b00;
         else
            n_request_stage2_partial_when_load = ~request_stage2_sector_access_mask & request_stage2_hit_way_status.partial;
   end 
   assign request_stage2_hit_sector0_status = sector_status_record_type'{request_stage2_hit_way_status.valid[0], 
                                                                         request_stage2_hit_way_status.beat_dirty_mask[1:0], 
                                                                         request_stage2_hit_way_status.partial[0]}; 

   assign request_stage2_hit_sector1_status = sector_status_record_type'{request_stage2_hit_way_status.valid[1], 
                                                                         request_stage2_hit_way_status.beat_dirty_mask[3:2], 
                                                                         request_stage2_hit_way_status.partial[1]}; 

   assign request_stage2_hit_sector = request_stage2_sector_access_mask[0] ? request_stage2_hit_sector0_status : request_stage2_hit_sector1_status; 
   assign request_stage2_hit_sector_status   = request_stage2_hit_sector.valid == 0 ? INVALID : request_stage2_hit_sector.partial ?  PARTIAL: request_stage2_hit_sector.beat_dirty_mask == '0 ? CLEAN : DIRTY;
   
   assign request_stage2_miss_sector = request_stage2_sector_access_mask[0] ? request_stage2_hit_sector1_status : request_stage2_hit_sector0_status;
   assign request_stage2_miss_sector_status  = request_stage2_miss_sector.valid == 0 ? INVALID : request_stage2_miss_sector.partial ?  PARTIAL: request_stage2_miss_sector.beat_dirty_mask == '0 ? CLEAN : DIRTY;

   assign request_stage2_replace_dirty = (selected_cacheline_status.valid[request_stage2_replace_way] != 2'd0) & (selected_cacheline_status.beat_dirty_mask[request_stage2_replace_way] != 4'd0);

   assign request_stage2_hit_dirty = selected_cacheline_status.beat_dirty_mask[request_stage2_hit_way] != 4'b0000;

   l2_bank_memif_instr_type request_stage2_memif_instr;

   // two cases are treated as hazard
   // read/atomic hit inflight partial cacheline
   // bypass write hit inflight partial/dirty/clean cacheline TODO: inflight clean   
   
   //assign request_stage2_hazard_valid = (request_stage2_hit_way_status.access_counter != 'd0 && request_stage2_hit) 
   //                                    && (((request_stage2_rec.instruction == AXI_RD | request_stage2_rec.instruction == AXI_AA) && (request_stage2_hit_way_status.partial != 2'b00)) 
   //                                        || (request_stage2_rec.instruction == AXI_WR && request_stage2_rec.cache_policy == 1'b1 && request_stage2_hit_way_status.beat_dirty_mask != 4'd0));
   always_comb begin
      request_stage2_hazard_valid = 1'b0;
      if (request_stage2_hit && request_stage2_hit_way_status.access_counter != 'd0) begin
         if (request_stage2_rec.instruction == AXI_RD | request_stage2_rec.instruction == AXI_AA) begin
            // if (request_stage2_rec.prefetch_size) begin
            //    request_stage2_hazard_valid = |request_stage2_hit_way_status.partial;
            // end
            // else begin
            //    request_stage2_hazard_valid = |(request_stage2_hit_way_status.partial & request_stage2_sector_access_mask);
            // end
            request_stage2_hazard_valid = 1'b0;
         end
         else if (request_stage2_rec.instruction == AXI_WR) begin
            request_stage2_hazard_valid = (request_stage2_rec.cache_policy && request_stage2_hit_way_status.beat_dirty_mask != 4'd0);
         end
      end
   end
   

   always_comb begin: p_lookup_stage2_and_issue_req
      request_stage2_ready = 1'b0;
      n_request_stage3_valid = 1'b0;
      n_request_stage3_rec  = request_stage2_rec;
      n_request_stage3_tag_ram_rec = selected_cacheline_status;
      n_request_stage3_wen = '1;
      request_stage2_cl_instruction = RD;
      tagctrl_memif_valid = 1'b0;
      tagctrl_isched_valid = 1'b0;
      request_stage2_cfi_inc = 1'b0;
      n_request_stage2_cfi_done_mask = request_stage2_cfi_done_mask;
      request_stage2_wb_valid = 1'b0;
      request_stage2_linefill_waiting = request_stage2_sector_access_mask;
      inflight_wb_allocate_valid = 1'b0;
      request_stage2_clr_valid = 1'b0;
      if (request_stage2_valid) begin
         case (request_stage2_rec.instruction)
            AXI_RD: begin: p_process_axi_rd
                 
               if (request_stage2_hazard_valid | ( request_stage2_hit && request_stage2_hit_way_status.access_counter == '1)) begin: p_process_axi_rd_hazard_and_max_counter
                  n_request_stage3_valid = 1'b0;
                  tagctrl_memif_valid = 1'b0;
                  tagctrl_isched_valid = 1'b0;
                  request_stage2_ready = 1'b0;
               end 
               else if (request_stage2_hit)  begin: p_process_axi_rd_hit //  dont care about cache policy
                  for (int unsigned way = 0; way < L2_NUM_WAY; way++) begin
                     if (way == request_stage2_hit_way) begin
                        n_request_stage3_tag_ram_rec.partial       [way] = n_request_stage2_partial_when_load;
                        n_request_stage3_tag_ram_rec.valid         [way] = (request_stage2_rec.prefetch_size? 2'b11: request_stage2_sector_access_mask) | selected_cacheline_status.valid[way] ;
                        n_request_stage3_tag_ram_rec.persistence   [way] = request_stage2_rec.persistence;
                        n_request_stage3_tag_ram_rec.access_counter[way] = selected_cacheline_status.access_counter[way] + 1'b1; ; 
                        n_request_stage3_tag_ram_rec.touched_mask  [way] = 1'b1;
                        n_request_stage3_wen                       [way] = 1'b0;
                     end
                  end
                  n_request_stage3_tag_ram_rec.plru_bits                 = n_plru_bits_when_hit;
                  n_request_stage3_wen                       [L2_NUM_WAY]= 1'b0;
                  // access one sector
                  if (request_stage2_sector_access_mask == 2'b01 | request_stage2_sector_access_mask == 2'b10) begin: p_process_axi_rd_hit_one_sector
                     if (request_stage2_rec.prefetch_size == 1'b0) begin: p_process_axi_rd_prefetch_one_sector
                        case(request_stage2_hit_sector_status)
                           INVALID: begin
                              request_stage2_cl_instruction = RD;
                              tagctrl_isched_valid = !isched_req_issued;
                              tagctrl_memif_valid = (isched_req_issued | tagctrl_isched_ready) & !memif_req_issued; // request must be issued to isched then memif
                              
                              request_stage2_ready = (memif_req_issued | tagctrl_memif_ready) & (isched_req_issued | tagctrl_isched_ready );
                              n_request_stage3_valid = (memif_req_issued | tagctrl_memif_ready) & (isched_req_issued | tagctrl_isched_ready );
                           end
                           CLEAN, DIRTY: begin
                              request_stage2_cl_instruction = RD;
                              tagctrl_isched_valid = !isched_req_issued;
                              
                              request_stage2_ready = isched_req_issued | tagctrl_isched_ready;
                              n_request_stage3_valid = isched_req_issued | tagctrl_isched_ready;
                              request_stage2_linefill_waiting = 2'b00;
                           end
                           PARTIAL: begin
                              request_stage2_cl_instruction = RD;
                              tagctrl_isched_valid = !isched_req_issued;
                              tagctrl_memif_valid = (isched_req_issued | tagctrl_isched_ready) & !memif_req_issued; // request must be issued to isched then memif
                              
                              request_stage2_ready = (memif_req_issued | tagctrl_memif_ready) & (isched_req_issued | tagctrl_isched_ready );
                              n_request_stage3_valid = (memif_req_issued | tagctrl_memif_ready) & (isched_req_issued | tagctrl_isched_ready );
                           end
                        endcase 
                     end
                     else begin: p_process_axi_rd_prefetch_two_sector// access one sector and prefetch anothe sector
                        request_stage2_linefill_waiting = (~request_stage2_hit_way_status.valid) | request_stage2_hit_way_status.partial;
                        case({request_stage2_hit_sector_status, request_stage2_miss_sector_status} )
                           {INVALID, INVALID}: begin
                           end
                           {INVALID, PARTIAL} : begin
                              tagctrl_isched_valid = !isched_req_issued;
                              tagctrl_memif_valid = (isched_req_issued | tagctrl_isched_ready) & !memif_req_issued; // request must be issued to isched then memif
                              
                              request_stage2_ready = (memif_req_issued | tagctrl_memif_ready) & (isched_req_issued | tagctrl_isched_ready );
                              n_request_stage3_valid = (memif_req_issued | tagctrl_memif_ready) & (isched_req_issued | tagctrl_isched_ready );
                              //request_stage2_linefill_waiting = 2'b11;
                           end
                           {INVALID, CLEAN}, {INVALID, DIRTY}: begin
                              tagctrl_isched_valid = !isched_req_issued;
                              tagctrl_memif_valid = (isched_req_issued | tagctrl_isched_ready) & !memif_req_issued; // request must be issued to isched then memif
                              
                              request_stage2_ready = (memif_req_issued | tagctrl_memif_ready) & (isched_req_issued | tagctrl_isched_ready );
                              n_request_stage3_valid = (memif_req_issued | tagctrl_memif_ready) & (isched_req_issued | tagctrl_isched_ready );
                           end
                           {CLEAN, INVALID}, {CLEAN, PARTIAL}: begin // issue prefetch first, then issue rd
                              tagctrl_isched_valid = !isched_req_issued;
                              tagctrl_memif_valid = (isched_req_issued | tagctrl_isched_ready) & !memif_req_issued; 
                              
                              request_stage2_ready = (memif_req_issued | tagctrl_memif_ready) & (isched_req_issued | tagctrl_isched_ready );
                              n_request_stage3_valid = (memif_req_issued | tagctrl_memif_ready) & (isched_req_issued | tagctrl_isched_ready );
                              //request_stage2_linefill_waiting = ~request_stage2_sector_access_mask;

                           end
                           {CLEAN, DIRTY}, {CLEAN, CLEAN}: begin
                              tagctrl_isched_valid = !isched_req_issued;
                              //request_stage2_linefill_waiting = 2'b00;
                              
                              request_stage2_ready =  isched_req_issued | tagctrl_isched_ready ;
                              n_request_stage3_valid = isched_req_issued | tagctrl_isched_ready ;
                           end
                           {PARTIAL, INVALID}, {PARTIAL, PARTIAL}: begin // blen == 3
                              tagctrl_isched_valid = !isched_req_issued;
                              tagctrl_memif_valid = (isched_req_issued | tagctrl_isched_ready) & !memif_req_issued; // request must be issued to isched then memif
                              
                              request_stage2_ready = (memif_req_issued | tagctrl_memif_ready) & (isched_req_issued | tagctrl_isched_ready );
                              n_request_stage3_valid = (memif_req_issued | tagctrl_memif_ready) & (isched_req_issued | tagctrl_isched_ready );
                              //request_stage2_linefill_waiting = 2'b11;
                           end
                           {PARTIAL, DIRTY}, {PARTIAL, CLEAN}: begin // blen == 1
                              tagctrl_isched_valid = !isched_req_issued;
                              tagctrl_memif_valid = (isched_req_issued | tagctrl_isched_ready) & !memif_req_issued; // request must be issued to isched then memif
                              
                              request_stage2_ready = (memif_req_issued | tagctrl_memif_ready) & (isched_req_issued | tagctrl_isched_ready );
                              n_request_stage3_valid = (memif_req_issued | tagctrl_memif_ready) & (isched_req_issued | tagctrl_isched_ready );
                           end
                           {DIRTY, INVALID}, {DIRTY, PARTIAL}: begin
                              tagctrl_isched_valid = !isched_req_issued;
                              tagctrl_memif_valid = (isched_req_issued | tagctrl_isched_ready) & !memif_req_issued; 
                              
                              request_stage2_ready = (memif_req_issued | tagctrl_memif_ready) & (isched_req_issued | tagctrl_isched_ready );
                              n_request_stage3_valid = (memif_req_issued | tagctrl_memif_ready) & (isched_req_issued | tagctrl_isched_ready );
                              // request_stage2_linefill_waiting = ~request_stage2_sector_access_mask;
                           end
                           {DIRTY, CLEAN}, {DIRTY, DIRTY}: begin
                              tagctrl_isched_valid = !isched_req_issued;
                              request_stage2_ready = isched_req_issued | tagctrl_isched_ready;
                              n_request_stage3_valid = isched_req_issued | tagctrl_isched_ready;
                              // request_stage2_linefill_waiting = 2'b00;
                           end
                        endcase 
                     end
                  end
                  else begin: p_process_axi_rd_hit_two_sector // access two sector
                     request_stage2_linefill_waiting = (~request_stage2_hit_way_status.valid) | request_stage2_hit_way_status.partial;
                     case({request_stage2_hit_sector_status, request_stage2_miss_sector_status} )
                        {INVALID, INVALID}: begin
                        end
                        {INVALID, PARTIAL} : begin
                           tagctrl_isched_valid = !isched_req_issued;
                           tagctrl_memif_valid = (isched_req_issued | tagctrl_isched_ready) & !memif_req_issued; // request must be issued to isched then memif
                           
                           request_stage2_ready = (memif_req_issued | tagctrl_memif_ready) & (isched_req_issued | tagctrl_isched_ready );
                           n_request_stage3_valid = (memif_req_issued | tagctrl_memif_ready) & (isched_req_issued | tagctrl_isched_ready );
                           //request_stage2_linefill_waiting = 2'b11;
                        end
                        {INVALID, CLEAN}, {INVALID, DIRTY}: begin
                           tagctrl_isched_valid = !isched_req_issued;
                           tagctrl_memif_valid = (isched_req_issued | tagctrl_isched_ready) & !memif_req_issued; // request must be issued to isched then memif
                           
                           request_stage2_ready = (memif_req_issued | tagctrl_memif_ready) & (isched_req_issued | tagctrl_isched_ready );
                           n_request_stage3_valid = (memif_req_issued | tagctrl_memif_ready) & (isched_req_issued | tagctrl_isched_ready );

                           //request_stage2_linefill_waiting = ~request_stage2_hit_way_status.valid;
                        end
                        {CLEAN, INVALID}, {CLEAN, PARTIAL}: begin // issue prefetch first, then issue rd
                           tagctrl_isched_valid = !isched_req_issued;
                           tagctrl_memif_valid = (isched_req_issued | tagctrl_isched_ready) & !memif_req_issued; 
                           
                           request_stage2_ready = (memif_req_issued | tagctrl_memif_ready) & (isched_req_issued | tagctrl_isched_ready );
                           n_request_stage3_valid = (memif_req_issued | tagctrl_memif_ready) & (isched_req_issued | tagctrl_isched_ready );
                        end
                        {CLEAN, DIRTY}, {CLEAN, CLEAN}: begin
                           tagctrl_isched_valid = !isched_req_issued;

                           request_stage2_ready = (isched_req_issued | tagctrl_isched_ready);
                           n_request_stage3_valid = (isched_req_issued | tagctrl_isched_ready);
                           //request_stage2_linefill_waiting = 2'b00;
                        end
                        {PARTIAL, INVALID}, {PARTIAL, PARTIAL}: begin // blen == 3
                           tagctrl_isched_valid = !isched_req_issued;
                           tagctrl_memif_valid = (isched_req_issued | tagctrl_isched_ready) & !memif_req_issued; // request must be issued to isched then memif
                           
                           request_stage2_ready = (memif_req_issued | tagctrl_memif_ready) & (isched_req_issued | tagctrl_isched_ready );
                           n_request_stage3_valid = (memif_req_issued | tagctrl_memif_ready) & (isched_req_issued | tagctrl_isched_ready );
                           //request_stage2_linefill_waiting = 2'b11;
                        end
                        {PARTIAL, DIRTY}, {PARTIAL, CLEAN}: begin // blen == 1
                           tagctrl_isched_valid = !isched_req_issued;
                           tagctrl_memif_valid = (isched_req_issued | tagctrl_isched_ready) & !memif_req_issued; // request must be issued to isched then memif
                           
                           request_stage2_ready = (memif_req_issued | tagctrl_memif_ready) & (isched_req_issued | tagctrl_isched_ready );
                           n_request_stage3_valid = (memif_req_issued | tagctrl_memif_ready) & (isched_req_issued | tagctrl_isched_ready );
                        end
                        {DIRTY, INVALID}, {DIRTY, PARTIAL}: begin
                           tagctrl_isched_valid = !isched_req_issued;
                           tagctrl_memif_valid = (isched_req_issued | tagctrl_isched_ready) & !memif_req_issued; 
                           
                           request_stage2_ready = (memif_req_issued | tagctrl_memif_ready) & (isched_req_issued | tagctrl_isched_ready );
                           n_request_stage3_valid = (memif_req_issued | tagctrl_memif_ready) & (isched_req_issued | tagctrl_isched_ready );
                           //request_stage2_linefill_waiting = ~request_stage2_sector_access_mask;
                        end
                        {DIRTY, CLEAN}, {DIRTY, DIRTY}: begin
                           tagctrl_isched_valid = !isched_req_issued;
                           
                           request_stage2_ready = (isched_req_issued | tagctrl_isched_ready);
                           n_request_stage3_valid = (isched_req_issued | tagctrl_isched_ready);
                           //request_stage2_linefill_waiting = 2'b00;
                        end
                     endcase 
                  end
               end
               else begin: p_process_axi_rd_miss
                  if (request_stage2_rec.cache_policy) begin: p_process_axi_bypass_rd_miss // bypass request
                     // dont update tag ram. just issue brd to mem_if 
                     //tagctrl_isched_valid = (!memif_req_issued | tagctrl_memif_ready) & !isched_req_issued; // request must be issued to isched then memif
                     tagctrl_memif_valid = !memif_req_issued;
                     request_stage2_ready = tagctrl_memif_ready | memif_req_issued;
                  end
                  else  begin: p_process_axi_cache_rd_miss // cache read
                     request_stage2_linefill_waiting = (request_stage2_rec.prefetch_size) ? 2'b11 : request_stage2_sector_access_mask;
                     if (request_stage2_replace_valid) begin: p_process_axi_rd_repalce
                        if (request_stage2_replace_dirty) begin: p_process_axi_rd_repalce_dirty_cacheline
                           request_stage2_ready       = (tagctrl_memif_ready | memif_req_issued) & (tagctrl_isched_ready | isched_req_issued) & (inflight_wb_allocated | inflight_wb_allocate_ready);
                           tagctrl_isched_valid       = !isched_req_issued && (inflight_wb_allocated || inflight_wb_allocate_ready); // request must be issued to isched then memif
                           tagctrl_memif_valid        = !memif_req_issued && (isched_req_issued || tagctrl_isched_ready) && (inflight_wb_allocated || inflight_wb_allocate_ready);
                           request_stage2_wb_valid    = 1'b1; 
                           n_request_stage3_valid     = (tagctrl_memif_ready || memif_req_issued) && (tagctrl_isched_ready || isched_req_issued) && (inflight_wb_allocated || inflight_wb_allocate_ready);
                           inflight_wb_allocate_valid = !inflight_wb_allocated;
                        end 
                        else begin: p_process_axi_rd_repalce_clean_cacheline
                           request_stage2_ready       = (tagctrl_memif_ready | memif_req_issued) & (tagctrl_isched_ready | isched_req_issued);
                           tagctrl_isched_valid       = !isched_req_issued;
                           tagctrl_memif_valid        = (!memif_req_issued) && (tagctrl_isched_ready | isched_req_issued);
                           request_stage2_clr_valid    = (tagctrl_memif_ready | memif_req_issued) & (tagctrl_isched_ready | isched_req_issued); 
                           request_stage2_wb_valid    = 1'b0; 
                           n_request_stage3_valid     = (tagctrl_memif_ready | memif_req_issued) & (tagctrl_isched_ready | isched_req_issued) ;
                           inflight_wb_allocate_valid = 1'b0;
                        end
                        n_request_stage3_wen          [L2_NUM_WAY] = 1'b0;
                        n_request_stage3_tag_ram_rec.plru_bits     = n_plru_bits_when_replace;
                        for (int unsigned way = 0; way < L2_NUM_WAY; way ++ ) begin
                           if (way == request_stage2_replace_way) begin
                              n_request_stage3_wen                         [way] = 1'b0;
                              n_request_stage3_tag_ram_rec.addr_tag        [way] = request_stage2_rec.addr_tag;
                              n_request_stage3_tag_ram_rec.persistence     [way] = request_stage2_rec.persistence;
                              n_request_stage3_tag_ram_rec.valid           [way] = request_stage2_rec.prefetch_size? 2'b11: request_stage2_sector_access_mask;// influenced by prefetch size
                              n_request_stage3_tag_ram_rec.partial         [way] = 2'b00;
                              n_request_stage3_tag_ram_rec.beat_dirty_mask [way] = 4'b0000;
                              n_request_stage3_tag_ram_rec.access_counter  [way] = 1; 
                              n_request_stage3_tag_ram_rec.touched_mask    [way] = 1'b0;
                           end
                        end
                     end
                  end
               end
            end
            AXI_WR: begin: p_process_axi_wr
               request_stage2_linefill_waiting = 2'b00;
               if (request_stage2_hazard_valid | ( request_stage2_hit && request_stage2_hit_way_status.access_counter == '1)) begin: p_process_axi_wr_hazard_and_max_counter
                  n_request_stage3_valid = 1'b0;
                  tagctrl_memif_valid = 1'b0;
                  tagctrl_isched_valid = 1'b0;
                  request_stage2_ready = 1'b0;
               end 
               else if (request_stage2_hit) begin: p_process_axi_wr_hit
                  if (request_stage2_rec.cache_policy) begin: p_process_axi_bypass_wr_hit// bypass hit dirty cacheline
                     if (request_stage2_hit_dirty) begin: p_process_axi_bypass_wr_hit_dirty
                        tagctrl_memif_valid = !memif_req_issued & (inflight_wb_allocate_ready | inflight_wb_allocated);
                        inflight_wb_allocate_valid = !inflight_wb_allocated;
                        request_stage2_cl_instruction = WB_WR;
                        request_stage2_ready = (memif_req_issued | tagctrl_memif_ready) & (inflight_wb_allocate_ready | inflight_wb_allocated);
                        n_request_stage3_valid = (memif_req_issued | tagctrl_memif_ready) & (inflight_wb_allocate_ready | inflight_wb_allocated);
                     end
                     else begin: p_process_axi_bypass_wr_hit_clean
                        tagctrl_memif_valid = !memif_req_issued ;
                        inflight_wb_allocate_valid = 1'b0;
                        request_stage2_cl_instruction = WT;
                        request_stage2_ready = memif_req_issued | tagctrl_memif_ready;
                        n_request_stage3_valid = memif_req_issued | tagctrl_memif_ready;
                     end
                     n_request_stage3_wen                         [L2_NUM_WAY]= 1'b0;
                     n_request_stage3_tag_ram_rec.plru_bits                   = n_plru_bits_when_hit;
                     for (int unsigned way = 0; way < L2_NUM_WAY; way ++) begin
                        if (request_stage2_hit_way == way) begin
                           n_request_stage3_wen                         [way] = 1'b0;
                           n_request_stage3_tag_ram_rec.valid           [way] = 2'b00;
                           n_request_stage3_tag_ram_rec.partial         [way] = 2'b00;
                           n_request_stage3_tag_ram_rec.persistence     [way] = 2'b00;
                           n_request_stage3_tag_ram_rec.beat_dirty_mask [way] = 4'b0000;
                           n_request_stage3_tag_ram_rec.access_counter  [way] = '0;//request_stage2_sector_access_mask;
                           n_request_stage3_tag_ram_rec.touched_mask    [way] = 1'b0;
                        end
                     end
                  end
                  else begin: p_process_axi_cache_wr_hit //  cache write hit dirty cacheline
                     request_stage2_ready = isched_req_issued | tagctrl_isched_ready;
                     n_request_stage3_valid = isched_req_issued | tagctrl_isched_ready;
                     for (int unsigned way = 0; way < L2_NUM_WAY; way++) begin
                        if (way == request_stage2_hit_way) begin
                           n_request_stage3_wen                         [way] = 1'b0;
                           n_request_stage3_tag_ram_rec.persistence     [way] = request_stage2_rec.persistence;
                           n_request_stage3_tag_ram_rec.valid           [way] = request_stage2_sector_access_mask | selected_cacheline_status.valid[way];
                           n_request_stage3_tag_ram_rec.beat_dirty_mask [way] = l2_bank_calc_dirty_mask(selected_cacheline_status.beat_dirty_mask[way], request_stage2_rec.start_beat, request_stage2_rec.blen);
                           n_request_stage3_tag_ram_rec.access_counter  [way] = selected_cacheline_status.access_counter[way] + 1'b1 ; 
                           n_request_stage3_tag_ram_rec.touched_mask    [way] = 1'b1;
                           if (!(selected_cacheline_status.valid[way][0] && !selected_cacheline_status.partial[way][0]) && request_stage2_sector_access_mask[0]) begin // can not transfer clean/dirty cacheline to partial cacheline
                              n_request_stage3_tag_ram_rec.partial[way][0] = 1'b1;
                           end
                           if (!(selected_cacheline_status.valid[way][1] && !selected_cacheline_status.partial[way][1]) && request_stage2_sector_access_mask[1]) begin
                              n_request_stage3_tag_ram_rec.partial[way][1] = 1'b1;
                           end
                        end
                     end
                     n_request_stage3_wen        [L2_NUM_WAY  ]   = 1'b0;
                     n_request_stage3_tag_ram_rec.plru_bits       = n_plru_bits_when_hit;
                     request_stage2_cl_instruction = WR;
                     tagctrl_isched_valid = !isched_req_issued;
                  end
               end
               else begin: p_process_axi_wr_miss
                  if (request_stage2_rec.cache_policy) begin: p_process_axi_bypass_wr_miss// bypass request miss and bypass to memif
                     tagctrl_memif_valid = !memif_req_issued;
                     request_stage2_cl_instruction = WT;
                     request_stage2_ready = memif_req_issued | tagctrl_memif_ready;
                     n_request_stage3_valid = 1'b0;
                    // dont update tag ram 
                  end
                  else begin: p_process_axi_cache_wr_miss // cache write miss and allocate cacheline 
                     if (request_stage2_replace_valid) begin: p_process_axi_cache_wr_replace
                        if (request_stage2_replace_dirty) begin: p_process_axi_cache_wr_replace_dirty_cacheline
                           inflight_wb_allocate_valid = !inflight_wb_allocated;
                           tagctrl_isched_valid = !isched_req_issued; //TODO: isched may be independent on the wb buffer allocated. take care of this logic 
                           tagctrl_memif_valid =  !memif_req_issued & (isched_req_issued | tagctrl_isched_ready) & (inflight_wb_allocate_ready | inflight_wb_allocated);
                           request_stage2_cl_instruction = WR;
                           request_stage2_wb_valid = 1'b1;
                           request_stage2_ready = (isched_req_issued | tagctrl_isched_ready) & (memif_req_issued | tagctrl_memif_ready ) & (inflight_wb_allocate_ready | inflight_wb_allocated);
                           n_request_stage3_valid = (isched_req_issued | tagctrl_isched_ready) & (memif_req_issued | tagctrl_memif_ready) & (inflight_wb_allocate_ready | inflight_wb_allocated);
                        end
                        else begin: p_process_axi_wr_replace_clean_cacheline
                           request_stage2_clr_valid = (isched_req_issued | tagctrl_isched_ready);
                           tagctrl_memif_valid =  1'b0; 
                           tagctrl_isched_valid = !isched_req_issued; // request must be issued to isched then memif
                           request_stage2_cl_instruction = WR;
                           request_stage2_wb_valid = 1'b0;
                           request_stage2_ready = (isched_req_issued | tagctrl_isched_ready) ;
                           n_request_stage3_valid = (isched_req_issued | tagctrl_isched_ready) ;

                        end
                        n_request_stage3_tag_ram_rec.plru_bits = n_plru_bits_when_replace;
                        n_request_stage3_wen                         [L2_NUM_WAY] = 1'b0;
                        for (int unsigned way = 0; way < L2_NUM_WAY; way ++) begin
                           if (request_stage2_replace_way == way) begin
                              n_request_stage3_tag_ram_rec.addr_tag        [way] = request_stage2_rec.addr_tag;
                              n_request_stage3_tag_ram_rec.persistence     [way] = request_stage2_rec.persistence;
                              n_request_stage3_tag_ram_rec.valid           [way] = request_stage2_sector_access_mask;
                              n_request_stage3_tag_ram_rec.partial         [way] = request_stage2_sector_access_mask;
                              n_request_stage3_tag_ram_rec.beat_dirty_mask [way] = l2_bank_calc_dirty_mask(4'b0000, request_stage2_rec.start_beat, request_stage2_rec.blen);
                              n_request_stage3_tag_ram_rec.access_counter  [way] = 1;
                              n_request_stage3_tag_ram_rec.touched_mask    [way] = 1'b0;
                              n_request_stage3_wen                         [way] = 1'b0;
                           end
                        end
                     end 
                  end
               end
            end
            AXI_AA: begin: p_process_axi_aa
               request_stage2_cl_instruction = AA;
               if (request_stage2_hazard_valid | ( request_stage2_hit && request_stage2_hit_way_status.access_counter == '1)) begin: p_process_axi_aa_hazard_and_max_counter
                  n_request_stage3_valid = 1'b0;
                  tagctrl_memif_valid = 1'b0;
                  tagctrl_isched_valid = 1'b0;
                  request_stage2_ready = 1'b0;
               end 
               else if (request_stage2_hit) begin: p_process_axi_aa_hit
                  n_request_stage3_tag_ram_rec.plru_bits                                  = n_plru_bits_when_hit;
                  n_request_stage3_wen                         [ L2_NUM_WAY             ] = 1'b0;
                  for (int unsigned way = 0; way < L2_NUM_WAY; way++) begin
                     if (request_stage2_hit_way == way) begin
                        n_request_stage3_wen                         [ way ] = 1'b0;
                        n_request_stage3_tag_ram_rec.valid           [ way ] = (request_stage2_rec.prefetch_size? 2'b11: request_stage2_sector_access_mask) | selected_cacheline_status.valid[way];
                        n_request_stage3_tag_ram_rec.persistence     [ way ] = request_stage2_rec.persistence;
                        n_request_stage3_tag_ram_rec.partial         [ way ] = n_request_stage2_partial_when_load;
                        n_request_stage3_tag_ram_rec.beat_dirty_mask [ way ] = l2_bank_calc_dirty_mask(selected_cacheline_status.beat_dirty_mask[way], request_stage2_rec.start_beat, request_stage2_rec.blen);
                        n_request_stage3_tag_ram_rec.access_counter  [ way ] = selected_cacheline_status.access_counter[way] + 1'b1; 
                        n_request_stage3_tag_ram_rec.touched_mask    [ way ] = 1'b1;
                     end
                  end 
                  if (request_stage2_rec.prefetch_size) begin: p_process_axi_aa_prefetch_two_sector// access one sector but prefetch another sector 
                     request_stage2_linefill_waiting = (~request_stage2_hit_way_status.valid) | request_stage2_hit_way_status.partial;
                     case({request_stage2_hit_sector_status, request_stage2_miss_sector_status}) 
                        {INVALID, INVALID}: begin
                        end
                        {INVALID, CLEAN}, {INVALID, DIRTY}:begin // blen == 1
                           tagctrl_isched_valid = !isched_req_issued;
                           tagctrl_memif_valid = (isched_req_issued | tagctrl_isched_ready) & !memif_req_issued; // request must be issued to isched then memif
                           
                           request_stage2_ready = (memif_req_issued | tagctrl_memif_ready) & (isched_req_issued | tagctrl_isched_ready);
                           n_request_stage3_valid = (memif_req_issued | tagctrl_memif_ready) & (isched_req_issued | tagctrl_isched_ready);
                        end
                        {INVALID, PARTIAL}: begin // blen == 3
                           tagctrl_isched_valid = !isched_req_issued;
                           tagctrl_memif_valid = (isched_req_issued | tagctrl_isched_ready) & !memif_req_issued; // request must be issued to isched then memif
                           
                           request_stage2_ready = (memif_req_issued | tagctrl_memif_ready) & (isched_req_issued | tagctrl_isched_ready);
                           n_request_stage3_valid = (memif_req_issued | tagctrl_memif_ready) & (isched_req_issued | tagctrl_isched_ready);
                        end
                        {CLEAN, INVALID}, {CLEAN, PARTIAL}: begin
                           tagctrl_isched_valid = !isched_req_issued;
                           tagctrl_memif_valid = (isched_req_issued | tagctrl_isched_ready) & !memif_req_issued; // request must be issued to isched then memif
                           
                           request_stage2_ready = (memif_req_issued | tagctrl_memif_ready) & (isched_req_issued | tagctrl_isched_ready);
                           n_request_stage3_valid = (memif_req_issued | tagctrl_memif_ready) & (isched_req_issued | tagctrl_isched_ready);
                        end
                        {CLEAN, CLEAN}, {CLEAN, DIRTY}: begin
                           tagctrl_isched_valid = !isched_req_issued;
                           
                           request_stage2_ready = isched_req_issued | tagctrl_isched_ready;
                           n_request_stage3_valid = isched_req_issued | tagctrl_isched_ready;
                        end
                        {PARTIAL, INVALID}, {PARTIAL, PARTIAL}: begin // blen == 3
                           tagctrl_isched_valid = !isched_req_issued;
                           tagctrl_memif_valid = (isched_req_issued | tagctrl_isched_ready) & !memif_req_issued; // request must be issued to isched then memif
                           
                           request_stage2_ready = (memif_req_issued | tagctrl_memif_ready) & (isched_req_issued | tagctrl_isched_ready);
                           n_request_stage3_valid = (memif_req_issued | tagctrl_memif_ready) & (isched_req_issued | tagctrl_isched_ready);
                        end
                        {PARTIAL, CLEAN}, {PARTIAL, DIRTY}: begin // blen == 1 
                           tagctrl_isched_valid = !isched_req_issued;
                           tagctrl_memif_valid = (isched_req_issued | tagctrl_isched_ready) & !memif_req_issued; // request must be issued to isched then memif
                           
                           request_stage2_ready = (memif_req_issued | tagctrl_memif_ready) & (isched_req_issued | tagctrl_isched_ready);
                           n_request_stage3_valid = (memif_req_issued | tagctrl_memif_ready) & (isched_req_issued | tagctrl_isched_ready);
                        end
                        {DIRTY, INVALID}, {DIRTY, PARTIAL}: begin
                           tagctrl_isched_valid = !isched_req_issued;
                           tagctrl_memif_valid = (isched_req_issued | tagctrl_isched_ready) & !memif_req_issued; // request must be issued to isched then memif
                           
                           request_stage2_ready = (memif_req_issued | tagctrl_memif_ready) & (isched_req_issued | tagctrl_isched_ready);
                           n_request_stage3_valid = (memif_req_issued | tagctrl_memif_ready) & (isched_req_issued | tagctrl_isched_ready);
                        end
                        {DIRTY, CLEAN}, {DIRTY, DIRTY}: begin
                           tagctrl_isched_valid = !isched_req_issued;
                           
                           request_stage2_ready = isched_req_issued | tagctrl_isched_ready;
                           n_request_stage3_valid = isched_req_issued | tagctrl_isched_ready;
                        end
                     endcase
                  end
                  else begin: p_process_axi_aa_prefetch_one_sector // access one sector
                     case (request_stage2_hit_sector_status) 
                        INVALID, PARTIAL: begin
                           tagctrl_isched_valid = !isched_req_issued;
                           tagctrl_memif_valid = (isched_req_issued | tagctrl_isched_ready) & !memif_req_issued; // request must be issued to isched then memif
                           
                           request_stage2_ready = (memif_req_issued | tagctrl_memif_ready) & (isched_req_issued | tagctrl_isched_ready);
                           n_request_stage3_valid = (memif_req_issued | tagctrl_memif_ready) & (isched_req_issued | tagctrl_isched_ready);
                        end
                        CLEAN, DIRTY: begin
                           tagctrl_isched_valid = !isched_req_issued;
                           request_stage2_ready = isched_req_issued | tagctrl_isched_ready;
                           n_request_stage3_valid = isched_req_issued | tagctrl_isched_ready;
                           request_stage2_linefill_waiting = 2'b00;
                        end
                     endcase
                  end
               end
               else begin: p_process_axi_aa_miss
                  request_stage2_linefill_waiting = request_stage2_rec.prefetch_size ? 2'b11 : request_stage2_sector_access_mask;
                  if (request_stage2_replace_valid) begin
                     for (int unsigned way = 0 ; way < L2_NUM_WAY; way ++) begin
                        if (way == request_stage2_replace_way) begin
                           n_request_stage3_tag_ram_rec.addr_tag        [ way ] = request_stage2_rec.addr_tag;
                           n_request_stage3_tag_ram_rec.persistence     [ way ] = request_stage2_rec.persistence;
                           n_request_stage3_tag_ram_rec.valid           [ way ] = request_stage2_rec.prefetch_size? 2'b11: request_stage2_sector_access_mask;
                           n_request_stage3_tag_ram_rec.partial         [ way ] = 2'b00;//request_stage2_sector_access_mask;
                           n_request_stage3_tag_ram_rec.beat_dirty_mask [ way ] = l2_bank_calc_dirty_mask(4'b0000, request_stage2_rec.start_beat, request_stage2_rec.blen);
                           n_request_stage3_tag_ram_rec.access_counter  [ way ] = 1;
                           n_request_stage3_tag_ram_rec.touched_mask    [ way ] = 1'b0;
                           n_request_stage3_wen                         [ way ] = 1'b0;
                        end
                     end
                     n_request_stage3_tag_ram_rec.plru_bits                                      = n_plru_bits_when_replace;
                     n_request_stage3_wen                         [ L2_NUM_WAY                 ] = 1'b0;
                     if (request_stage2_replace_dirty) begin: p_process_axi_aa_replace_dirty_cacheline
                        request_stage2_ready = (isched_req_issued | tagctrl_isched_ready) && (memif_req_issued | tagctrl_memif_ready) && (inflight_wb_allocated | inflight_wb_allocate_ready);
                        n_request_stage3_valid = (isched_req_issued | tagctrl_isched_ready) && (memif_req_issued | tagctrl_memif_ready) && (inflight_wb_allocated | inflight_wb_allocate_ready);
                        request_stage2_wb_valid = 1'b1;
                        inflight_wb_allocate_valid = ~inflight_wb_allocated; 
                        tagctrl_isched_valid = !isched_req_issued;
                        tagctrl_memif_valid = !memif_req_issued && (isched_req_issued | tagctrl_isched_ready) && (inflight_wb_allocated | inflight_wb_allocate_ready);
                     end
                     else begin: p_process_axi_aa_replace_clean_cacheline
                        request_stage2_ready = (isched_req_issued | tagctrl_isched_ready) && (memif_req_issued | tagctrl_memif_ready);
                        n_request_stage3_valid = (isched_req_issued | tagctrl_isched_ready) && (memif_req_issued | tagctrl_memif_ready);
                        request_stage2_wb_valid = 1'b0;
                        request_stage2_clr_valid = (isched_req_issued | tagctrl_isched_ready) && (memif_req_issued | tagctrl_memif_ready);
                        inflight_wb_allocate_valid = 1'b0; 
                        tagctrl_isched_valid = !isched_req_issued;
                        tagctrl_memif_valid = !memif_req_issued && (isched_req_issued | tagctrl_isched_ready);
                     end
                  end
               end
            end
            CFG_INVALID: begin: p_process_cfi_invalid// invalid doesnt trigger any request to isched, or memif, rctrl
               request_stage2_ready = 1'b1;
               n_request_stage3_valid = 1'b1;
               n_request_stage3_wen[L2_NUM_WAY] = 1'b0; 
               n_request_stage3_tag_ram_rec.plru_bits = '0;
               for (int unsigned way = 0; way < L2_NUM_WAY; way++) begin: g_invalid_all_cacheline
                  //if (request_stage2_cfi_done_mask[way]) begin
                  n_request_stage3_tag_ram_rec.addr_tag        [way] = '0;
                  n_request_stage3_tag_ram_rec.persistence     [way] = '0;
                  n_request_stage3_tag_ram_rec.valid           [way] = '0;
                  n_request_stage3_tag_ram_rec.partial         [way] = '0;
                  n_request_stage3_tag_ram_rec.beat_dirty_mask [way] = '0;
                  n_request_stage3_tag_ram_rec.touched_mask    [way] = '0;
                  n_request_stage3_wen                         [way] = 1'b0;
                  //end
               end
            end
            CFG_FLUSH: begin: p_process_cfi_flush// flush doesn update plru bits. flush only issue FLUSH to memif or WB for partial cacheline to memif
               request_stage2_linefill_waiting = 2'b00;
               if (&request_stage2_cfi_done_mask) begin
                  request_stage2_ready = 1'b1;//tagctrl_memif_ready | memif_req_issued;
                  n_request_stage3_valid = 1'b1;
               end
               else begin 
                  if (selected_cacheline_status.access_counter[request_stage2_cfi_selected_way] == '0) begin
                     tagctrl_memif_valid = !memif_req_issued & (inflight_wb_allocated | inflight_wb_allocate_ready);
                     inflight_wb_allocate_valid = !inflight_wb_allocated;
                     request_stage2_cfi_inc = (tagctrl_memif_ready | memif_req_issued)  & (inflight_wb_allocated | inflight_wb_allocate_ready);
                     n_request_stage2_cfi_done_mask[request_stage2_cfi_selected_way] = 1'b1;
                     if (request_stage2_cfi_selected_way == 3'h7) begin
                        request_stage2_ready = (tagctrl_memif_ready | memif_req_issued) & (inflight_wb_allocated | inflight_wb_allocate_ready);
                        n_request_stage3_valid = (tagctrl_memif_ready | memif_req_issued) & (inflight_wb_allocated | inflight_wb_allocate_ready);
                     end
                  end
                  if (selected_cacheline_status.partial[request_stage2_cfi_selected_way]!= 2'b00) begin // partial -> WB. dirty -> FLUSH. clean -> none
                     request_stage2_cl_instruction = WB;
                  end
                  else begin
                     request_stage2_cl_instruction = FLUSH;
                  end
               end
               
               for (int unsigned way = 0; way < L2_NUM_WAY; way ++) begin: g_flush_cacheline
                  if (request_stage2_cfi_need_mask[way]) begin
                     n_request_stage3_tag_ram_rec.valid[way] = (selected_cacheline_status.partial[way] != 2'b00) ? 2'b00: selected_cacheline_status.valid[way]; // valid is cleared only when the cacheline is partial cacheline 
                     n_request_stage3_tag_ram_rec.partial[way] = '0;
                     n_request_stage3_tag_ram_rec.beat_dirty_mask[way] = '0;
                     n_request_stage3_wen[way] = 1'b0;
                  end
               end
            end
            CFG_FLUSH_INVALID: begin: p_process_cfi_flush_invalid // flushinvalid doesnt need to update plru bits
               request_stage2_linefill_waiting = 2'b00;
               request_stage2_cl_instruction = WB;
               if (&request_stage2_cfi_done_mask) begin
                  request_stage2_ready = 1'b1;
                  n_request_stage3_valid = 1'b1; // perhaps doesnt need to update the tag ram when all cacheline is not needed to flushed.
               end
               else begin
                  if (selected_cacheline_status.access_counter[request_stage2_cfi_selected_way] == '0) begin
                     inflight_wb_allocate_valid = !inflight_wb_allocated;
                     tagctrl_memif_valid = !memif_req_issued & (inflight_wb_allocate_ready | inflight_wb_allocated);
                     request_stage2_cfi_inc = (tagctrl_memif_ready | memif_req_issued) & (inflight_wb_allocate_ready | inflight_wb_allocated);
                     n_request_stage2_cfi_done_mask[request_stage2_cfi_selected_way] = 1'b1;
                     //if (request_stage2_cfi_selected_way == 3'd7) begin
                     //   request_stage2_ready = (tagctrl_memif_ready | memif_req_issued) & (inflight_wb_allocate_ready | inflight_wb_allocated);
                     //   n_request_stage3_valid = (tagctrl_memif_ready | memif_req_issued)& (inflight_wb_allocate_ready | inflight_wb_allocated);
                     //end
                  end
                  request_stage2_cl_instruction = WB;
               end

               for (int unsigned way = 0; way < L2_NUM_WAY; way ++) begin: g_flush_invalid_cacheline
                  if (request_stage2_cfi_need_mask[way]) begin
                     n_request_stage3_tag_ram_rec.valid[way] = 2'b00;  
                     n_request_stage3_tag_ram_rec.partial[way] = '0;
                     n_request_stage3_tag_ram_rec.beat_dirty_mask[way] = '0;
                     n_request_stage3_tag_ram_rec.addr_tag[way] = '0;
                     n_request_stage3_tag_ram_rec.persistence[way] = '0;
                     n_request_stage3_wen[way] = 1'b0;
                  end
               end
            end
            CFG_REDUCE_PERSIST: begin: p_process_persistence_reduce // reduce the persistence value when touched_mask is 0. if the persistence is zero, keep unchanged.
               for (int unsigned way = 0; way < L2_NUM_WAY; way++) begin: g_reduce_cacheline_persistence
                  if (~selected_cacheline_status.touched_mask[way] && selected_cacheline_status.persistence[way] != 2'b00) begin
                     n_request_stage3_tag_ram_rec.persistence[way] = selected_cacheline_status.persistence[way] - 1'b1;
                  end
                  n_request_stage3_wen[way] = ~((selected_cacheline_status.touched_mask[way]) || (~selected_cacheline_status.touched_mask[way] && selected_cacheline_status.persistence[way] != 2'b00));
                  n_request_stage3_tag_ram_rec.touched_mask[way] = 1'b0;
               end 
               request_stage2_ready = 1'b1;
               n_request_stage3_valid = 1'b1;
            end
            CFG_RST_PERSIST: begin: p_process_persistence_rst
               for (int unsigned way = 0; way < L2_NUM_WAY; way++) begin: g_rst_cacheline_persistence
                  if (selected_cacheline_status.persistence[way] != 2'b00 || selected_cacheline_status.touched_mask[way]) begin
                     n_request_stage3_tag_ram_rec.persistence[way] = 2'b00;
                     n_request_stage3_tag_ram_rec.touched_mask[way] = 1'b0;
                     n_request_stage3_wen[way] = 1'b0;
                  end
               end 
               request_stage2_ready = 1'b1;
               n_request_stage3_valid = 1'b1;
            end
         endcase
      end
   end
   // flag to track if request is issued to memif or isched or ramctrl.

   always_ff@(posedge clk or negedge resetn) begin
      if (!resetn) begin
         memif_req_issued <= 1'b0;
      end
      else if (request_stage2_valid & request_stage2_ready) begin
         memif_req_issued <= 1'b0;
      end
      else if (request_stage2_valid & request_stage2_cfi_inc & l2_bank_operation_need_unroll(request_stage2_rec.instruction)) begin
         memif_req_issued <= 1'b0;
      end
      else if (tagctrl_memif_valid & tagctrl_memif_ready ) begin
         memif_req_issued <= 1'b1;
      end
   end

   always_ff@(posedge clk or negedge resetn) begin
      if (!resetn) begin
         isched_req_issued <= 1'b0;
      end
      else if (request_stage2_valid & request_stage2_ready) 
         isched_req_issued <= 1'b0;
      else if (tagctrl_isched_valid & tagctrl_isched_ready )
         isched_req_issued <= 1'b1;
   end



   // process cfi/persistence unroll
   gpc_gfx_prienc_ones_lsb
   #( 
     .W            ( L2_NUM_WAY                      ) ,
     .OUTPUT_WIDTH ( L2_NUM_WAY_BITS                 )
                                                     )
   i_cfi_select_way(
      .vector      ( ~request_stage2_cfi_done_mask   )
     ,.result      ( request_stage2_cfi_selected_way )
                                                     ) ;

   tagctrl_ram_data_record_type n_request_stage2_tag_ram_rec;
   assign n_request_stage2_tag_ram_rec = func_tagctrl_ram_data_slv2rec(n_request_stage2_data);


   always_ff@(posedge clk or negedge resetn) begin: p_update_cfi_done_mask
      if (!resetn) begin
         request_stage2_cfi_done_mask <= '0; // 1 means cacheline is proccessed by cfi. 0 means the cacheline waiting for cfi process
      end
      else if (request_stage1_valid & request_stage1_ready) begin
         if (request_stage1_rec.instruction == CFG_FLUSH || request_stage1_rec.instruction == CFG_FLUSH_INVALID) begin
            for (int unsigned way = 0; way < L2_NUM_WAY; way ++) begin: g_unroll_all_way_for_cfi_done_mask
               if (n_request_stage2_tag_ram_rec.valid[way] == 2'b00 || n_request_stage2_tag_ram_rec.beat_dirty_mask[way] == '0) // 0 means doesnt need to flush the cacheline
                  request_stage2_cfi_done_mask[way] <= 1'b1;
               else
                  request_stage2_cfi_done_mask[way] <= 1'b0;
            end
         end
         // else begin // flushinvalid will invalid all cacheline, dont need mark the clean cacheline    
         //    for (int unsigned way = 0; way < L2_NUM_WAY; way ++) 
         //       request_stage2_cfi_done_mask[way] <= n_request_stage2_tag_ram_rec.valid[way] == 2'b00;
         // end
      end 
      else if (request_stage2_valid & l2_bank_operation_need_unroll(request_stage2_rec.instruction) & request_stage2_cfi_inc) begin
         request_stage2_cfi_done_mask <= n_request_stage2_cfi_done_mask;
      end
   end

   assign n_request_stage3_data = func_tagctrl_ram_data_rec2slv(func_tagctrl_cacheline_status_to_ram_data(n_request_stage3_tag_ram_rec));

   always_comb begin
      request_stage2_memif_instr = LF;
      if (request_stage2_valid) begin
         case (request_stage2_rec.instruction)
            AXI_RD: begin
               if (!request_stage2_hit & request_stage2_rec.cache_policy)
                 request_stage2_memif_instr = BRD; 
            end
            AXI_WR: begin
               request_stage2_memif_instr = ST;
               if (!request_stage2_hit & !request_stage2_rec.cache_policy)
                  request_stage2_memif_instr = NOPE;
            end
            AXI_AA: begin
               request_stage2_memif_instr = LF;
            end
            CFG_FLUSH, CFG_FLUSH_INVALID: begin
               request_stage2_memif_instr = ST;
            end
            default: begin
               request_stage2_memif_instr = LF;
            end
         endcase
      end
   end




   assign tagctrl_memif_rec.memif_instruction = request_stage2_memif_instr;
   assign tagctrl_memif_rec.cl_instruction    = request_stage2_cl_instruction;
   assign tagctrl_memif_rec.addr_tag          = l2_bank_operation_need_unroll(request_stage2_rec.instruction)? selected_cacheline_status.addr_tag[request_stage2_cfi_selected_way] : request_stage2_rec.addr_tag;
   assign tagctrl_memif_rec.start_beat        = request_stage2_rec.start_beat;
   assign tagctrl_memif_rec.axid              = request_stage2_rec.axid;
   assign tagctrl_memif_rec.blen              = request_stage2_rec.blen;
   assign tagctrl_memif_rec.set               = request_stage2_rec.set;
   assign tagctrl_memif_rec.way               = l2_bank_operation_need_unroll(request_stage2_rec.instruction) ? 
                                                request_stage2_cfi_selected_way : (request_stage2_hit) ? request_stage2_hit_way : request_stage2_replace_way;
   assign tagctrl_memif_rec.iwdb_index        = request_stage2_rec.iwdb_index;
   assign tagctrl_memif_rec.beat_dirty_mask   = l2_bank_operation_need_unroll(request_stage2_rec.instruction)? 
                                                selected_cacheline_status.beat_dirty_mask[request_stage2_cfi_selected_way] :  
                                                selected_cacheline_status.beat_dirty_mask[request_stage2_hit_way];
   assign tagctrl_memif_rec.linefill_mask     = request_stage2_linefill_waiting;
   assign tagctrl_memif_rec.wb_valid          = request_stage2_wb_valid;
   assign tagctrl_memif_rec.wb_addr_tag       = selected_cacheline_status.addr_tag[request_stage2_replace_way] ;
   assign tagctrl_memif_rec.wb_dirty_mask     = selected_cacheline_status.beat_dirty_mask[request_stage2_replace_way] ; 
   assign tagctrl_memif_rec.cfi_id            = cfi_pointer;

   assign tagctrl_isched_rec.instruction      = request_stage2_cl_instruction;
   assign tagctrl_isched_rec.axid             = request_stage2_rec.axid;
   assign tagctrl_isched_rec.set              = request_stage2_rec.set;
   assign tagctrl_isched_rec.way              = (request_stage2_hit) ? request_stage2_hit_way : request_stage2_replace_way;
   assign tagctrl_isched_rec.start_beat       = request_stage2_rec.start_beat;  // ignore the start_beat when prefetch
   assign tagctrl_isched_rec.burst            = request_stage2_rec.burst;
   assign tagctrl_isched_rec.blen             = request_stage2_rec.blen;
   assign tagctrl_isched_rec.iwdb_index       = request_stage2_rec.iwdb_index;
   assign tagctrl_isched_rec.linefill_waiting = request_stage2_linefill_waiting;
   assign tagctrl_isched_rec.wb_waiting       = request_stage2_wb_waiting; 
   assign tagctrl_isched_rec.sector_mask      = request_stage2_sector_access_mask;
   assign tagctrl_isched_rec.check_partial    = 2'b00;

   assign tagctrl_rctrl_clr_valid[0]           = request_stage2_clr_valid && ~|(request_stage2_lookup_wb_buf_mask) && ~request_stage2_rec.set[0];
   assign tagctrl_rctrl_clr_rec[0].set         = request_stage2_rec.set;
   assign tagctrl_rctrl_clr_rec[0].way         = request_stage2_replace_way;
   assign tagctrl_rctrl_clr_rec[0].sector_mask = 2'b11;

   assign tagctrl_rctrl_clr_valid[1]           = request_stage2_clr_valid && ~|(request_stage2_lookup_wb_buf_mask) && request_stage2_rec.set[0];
   assign tagctrl_rctrl_clr_rec[1].set         = request_stage2_rec.set;
   assign tagctrl_rctrl_clr_rec[1].way         = request_stage2_replace_way;
   assign tagctrl_rctrl_clr_rec[1].sector_mask = 2'b11;

   // ==============================================================================
   // stage 3: Update tag ram 
   // ==============================================================================

   always_ff@(posedge clk or negedge resetn) begin
      if (!resetn) begin
         request_stage3_valid <= 1'b0;
         request_stage3_wen   <= '1;
         request_stage3_rec   <= '0;
         request_stage3_data  <= '0;
      end
      else if (n_request_stage3_valid) begin
         request_stage3_valid <= 1'b1;
         request_stage3_data  <= n_request_stage3_data;
         request_stage3_rec   <= n_request_stage3_rec;
         request_stage3_wen   <= n_request_stage3_wen;
      end 
      else begin
         request_stage3_valid <= 1'b0;
      end
   end
   
   logic access_counter_increase;
   logic access_counter_decrease[L2_NUM_SET-1:0] [L2_NUM_WAY-1:0];
   always_comb begin
      access_counter_increase = 1'b0;
      if (request_stage2_valid) begin
         case (request_stage2_rec.instruction)
            AXI_RD: begin
               if (~request_stage2_hit && request_stage2_rec.cache_policy && ~request_stage2_hazard_valid) 
                  access_counter_increase = 1'b0;
               else begin
                  access_counter_increase = 1'b1;
               end
            end
            AXI_WR: begin
               if (~request_stage2_rec.cache_policy && ~request_stage2_hazard_valid) begin // cache read hit. cache read miss
                  access_counter_increase = 1'b1;
               end
            end 
            AXI_AA: begin
               if (~request_stage2_hazard_valid)
                  access_counter_increase = 1'b1; // increase counter no matter hit/miss
            end
         endcase
      end
   end

   logic [L2_NUM_WAY-1:0]  request_stage1_cnt_dec;
   logic [L2_NUM_WAY-1:0]  request_stage2_cnt_dec;
   for (genvar WAY = 0; WAY < L2_NUM_WAY; WAY++) begin
      assign request_stage1_cnt_dec[WAY] = (request_stage1_rec.set == rctrl_tagctrl_rec[0].set && rctrl_tagctrl_rec[0].way == WAY && rctrl_tagctrl_valid[0]) 
                                           || (request_stage1_rec.set == rctrl_tagctrl_rec[1].set && rctrl_tagctrl_rec[1].way == WAY && rctrl_tagctrl_valid[1]);
      assign request_stage2_cnt_dec[WAY] = (request_stage2_rec.set == rctrl_tagctrl_rec[0].set && rctrl_tagctrl_rec[0].way == WAY && rctrl_tagctrl_valid[0]) 
                                           || (request_stage2_rec.set == rctrl_tagctrl_rec[1].set && rctrl_tagctrl_rec[1].way == WAY && rctrl_tagctrl_valid[1]);
      //assign n_selected_access_counter[WAY] = access_counter_array[request_stage1_rec.set][WAY] - request_stage1_cnt_dec[WAY];
      always_comb begin
         if (n_request_stage3_valid && n_request_stage3_rec.set == request_stage1_rec.set) begin
            n_selected_access_counter[WAY] = n_stage3_access_counter[WAY];
         end
         else begin
            n_selected_access_counter[WAY] = access_counter_array[request_stage1_rec.set][WAY] - request_stage1_cnt_dec[WAY];
         end
      end
      always_comb begin
         if (!n_request_stage3_wen[WAY] && n_request_stage3_valid) begin
            if (access_counter_increase) begin
               if (request_stage2_cnt_dec[WAY]) begin
                  n_stage3_access_counter[WAY] = selected_access_counter_array[WAY];
               end
               else begin
                  n_stage3_access_counter[WAY] = selected_access_counter_array[WAY] + 1'b1;
               end
            end
            else if (request_stage2_cnt_dec[WAY]) begin
               n_stage3_access_counter[WAY] = selected_access_counter_array[WAY] - 1'b1;
            end
            else begin
               n_stage3_access_counter[WAY] = selected_access_counter_array[WAY];
            end
         end
         else if (request_stage2_cnt_dec[WAY]) begin
            n_stage3_access_counter[WAY] = selected_access_counter_array[WAY] - 1'b1;
         end
         else begin
            n_stage3_access_counter[WAY] = selected_access_counter_array[WAY];
         end
      end
   end

   generate 
      for (genvar way = 0; way < L2_NUM_WAY; way ++) begin: g_update_all_cacheline_way_flops
         for (genvar set = 0;set < L2_NUM_SET; set ++) begin: g_update_all_cacheline_set_flops
            always_comb begin
               if (n_request_stage3_valid && !n_request_stage3_wen[way] && request_stage2_set_mask[set]) begin
                  n_partial_array[set][way] = n_request_stage3_tag_ram_rec.partial[way];
               end
               else begin
                  n_partial_array[set][way] = partial_array[set][way];
               end
            end
            always_ff@(posedge clk or negedge resetn) begin
               if (!resetn) begin
                  partial_array[set][way] <= '0;
               end
               else if (n_request_stage3_valid) begin
                  partial_array[set][way] <= n_partial_array[set][way];
               end
            end
            if (set[0] == 1'b0) begin // even set
               assign access_counter_decrease[set][way] = rctrl_tagctrl_valid[0] && rctrl_tagctrl_rec[0].set == set && rctrl_tagctrl_rec[0].way == way;
            end
            else begin // odd set
               assign access_counter_decrease[set][way] = rctrl_tagctrl_valid[1] && rctrl_tagctrl_rec[1].set == set && rctrl_tagctrl_rec[1].way == way;
            end

            always_comb begin
               if (n_request_stage3_valid && request_stage2_set_mask[set] && !n_request_stage3_wen[way] ) begin
                  if (access_counter_increase) begin
                     if (~access_counter_decrease[set][way]) begin
                        n_access_counter_array[set][way] = access_counter_array[set][way] + 1'b1;
                     end
                     else begin
                        n_access_counter_array[set][way] = access_counter_array[set][way];
                     end
                  end
                  else if (access_counter_decrease[set][way]) begin
                     n_access_counter_array[set][way] = access_counter_array[set][way] - 1'b1;
                  end
                  else begin
                     n_access_counter_array[set][way] = access_counter_array[set][way];
                  end
               end
               else if (access_counter_decrease[set][way]) begin
                  n_access_counter_array[set][way] = access_counter_array[set][way] - 1'b1;
               end
               else begin
                  n_access_counter_array[set][way] = access_counter_array[set][way];
               end
            end

            always_ff@(posedge clk or negedge resetn) begin
               if (!resetn) begin
                  access_counter_array [set][way] <= '0;
               end
               else if (n_request_stage3_valid | (|rctrl_tagctrl_valid)) begin
                  access_counter_array[set][way] <= n_access_counter_array [set][way];
               end
            end
            
            // always_ff@(posedge clk or negedge resetn) begin
            //    if (!resetn) begin
            //       touched_mask[set][way] <= '0;
            //    end
            //    else if (n_request_stage3_valid && request_stage2_set_mask[set] && !n_request_stage3_wen[way] ) begin
            //       touched_mask[set][way] <= n_request_stage3_tag_ram_rec.touched_mask[way];
            //    end
            // end
         end
      end
   endgenerate

   // Manage inflight writeback buffer. FLUSH, WB, WB_WR need to allocate
   // the wb buffer to hanlde the writeback hazard


   logic [L2_NUM_WAY_BITS-1:0] request_stage2_target_way;
   assign request_stage2_target_way = request_stage2_hit ? request_stage2_hit_way : request_stage2_replace_way;

   always_ff@(posedge clk or negedge resetn) begin
      if (!resetn) begin
         inflight_wb_allocated <= 1'b0;
         inflight_wb_allocated_way <= '0;
      end
      else if (request_stage2_valid & l2_bank_operation_need_unroll(request_stage2_rec.instruction) & request_stage2_cfi_inc) begin
         inflight_wb_allocated <= 1'b0;
      end
      else if (request_stage2_valid & request_stage2_ready) begin
         inflight_wb_allocated <= 1'b0;
      end
      else if (inflight_wb_allocate_valid & inflight_wb_allocate_ready) begin
         inflight_wb_allocated <= 1'b1;
         inflight_wb_allocated_way <= request_stage2_target_way;
      end
   end
   assign inflight_wb_allocate_ready = ~(&inflight_wb_valids);
   
   gpc_gfx_prienc_ones_lsb
   #( 
     .W            ( L2_WB_BUF_DEPTH            ) ,
     .OUTPUT_WIDTH ( L2_WB_BUF_INDEX_BITS       )
                                                )
   i_allocate_wb_index  (
      .vector      ( ~inflight_wb_valids        )
     ,.result      ( inflight_wb_allocate_index )
                                                ) ;
   //logic [L2_NUM_RCTRL-1:0]   memif_lookup_wb_buf_collision_with_rctrl;
   //logic [L2_NUM_RCTRL-1:0]   isched_lookup_wb_buf_collision_with_rctrl;
   generate 
      for (genvar WB_ENTRY = 0; WB_ENTRY < L2_WB_BUF_DEPTH; WB_ENTRY ++)  begin: g_update_wb_buffer 
         always_ff@(posedge clk or negedge resetn) begin
            if (!resetn) begin
               inflight_wb_valids[WB_ENTRY] <= 1'b0;
               inflight_wb_entries[WB_ENTRY] <= '0;
            end
            else if (inflight_wb_allocate_valid && inflight_wb_allocate_ready && WB_ENTRY == inflight_wb_allocate_index) begin
               inflight_wb_valids[WB_ENTRY] <= 1'b1;
               inflight_wb_entries[WB_ENTRY].set <= request_stage2_rec.set;
               if (l2_bank_operation_need_unroll(request_stage2_rec.instruction))
                  inflight_wb_entries[WB_ENTRY].way <= request_stage2_cfi_selected_way;
               else 
                  inflight_wb_entries[WB_ENTRY].way <= request_stage2_target_way;
            end
            else if (|rctrl_lookup_wb_buf_mask[WB_ENTRY]) begin
                  inflight_wb_valids[WB_ENTRY] <= 1'b0;
            end
         end
         assign request_stage2_lookup_wb_buf_mask[WB_ENTRY]  = inflight_wb_valids[WB_ENTRY] 
                                                               &&  !(|(rctrl_lookup_wb_buf_mask[WB_ENTRY])) // donesnt clr the wb entry
                                                               && (inflight_wb_entries[WB_ENTRY].set == request_stage2_rec.set) 
                                                               && (inflight_wb_entries[WB_ENTRY].way == request_stage2_target_way); 
         assign memif_lookup_wb_buf_mask[WB_ENTRY]  = inflight_wb_valids[WB_ENTRY] 
                                                      &&  !(|(rctrl_lookup_wb_buf_mask[WB_ENTRY])) // donesnt clr the wb entry
                                                      && (inflight_wb_entries[WB_ENTRY].set == memif_tagctrl_rec.set ) 
                                                      && (inflight_wb_entries[WB_ENTRY].way == memif_tagctrl_rec.way);
         for (genvar RCTRL = 0; RCTRL < L2_NUM_RCTRL; RCTRL++) begin 
            assign rctrl_lookup_wb_buf_mask[WB_ENTRY][RCTRL]  = inflight_wb_valids[WB_ENTRY]
                                                                && rctrl_tagctrl_wb_done_valid[RCTRL]
                                                                && (~rctrl_tagctrl_wb_rec[RCTRL].lf_or_wb)
                                                                && (inflight_wb_entries[WB_ENTRY].set == rctrl_tagctrl_wb_rec[RCTRL].set ) 
                                                                && (inflight_wb_entries[WB_ENTRY].way == rctrl_tagctrl_wb_rec[RCTRL].way); 
         end
      end
   endgenerate
   // when rctrl response is going to clr wb entry, and the request is stalled
   // on tagctrl-isched interface or ready to issue to isched, the wb_waiting
   // is cleared immediatly
   assign request_stage2_wb_waiting = (~request_stage2_hit && request_stage2_replace_dirty) || (|(request_stage2_lookup_wb_buf_mask));
   assign tagctrl_memif_wb_finish = memif_tagctrl_valid && (~|memif_lookup_wb_buf_mask); 
   // ==============================================================================
   // cfi counters: maxium two counters. Each counter can reach max value of 128
   // ==============================================================================

   generate
      for (genvar CFI_ENTRY = 0; CFI_ENTRY < L2_NUM_MAX_CFI; CFI_ENTRY++) begin: g_update_cfi_counters
         always_ff@(posedge clk or negedge resetn) begin: p_update_cfi_counters
            if(!resetn) begin
               cfi_counters[CFI_ENTRY] <= '0;
            end
            else begin
               if (tagctrl_memif_valid & tagctrl_memif_ready & tagctrl_memif_rec.memif_instruction == ST && CFI_ENTRY == cfi_pointer) begin
                  if (memif_tagctrl_cfi_decrease_valid & memif_tagctrl_cfi_id == CFI_ENTRY) begin
                     cfi_counters[CFI_ENTRY] <= cfi_counters[CFI_ENTRY];
                  end
                  else begin
                     cfi_counters[CFI_ENTRY] <= cfi_counters[CFI_ENTRY] + 1'b1;
                  end
               end
               else if (tagctrl_memif_valid & tagctrl_memif_ready & tagctrl_memif_rec.wb_valid && CFI_ENTRY == cfi_pointer) begin
                  if (memif_tagctrl_cfi_decrease_valid & memif_tagctrl_cfi_id == CFI_ENTRY) begin
                     cfi_counters[CFI_ENTRY] <= cfi_counters[CFI_ENTRY];
                  end
                  else begin
                     cfi_counters[CFI_ENTRY] <= cfi_counters[CFI_ENTRY] + 1'b1;
                  end
               end
               else if (memif_tagctrl_cfi_decrease_valid && CFI_ENTRY == memif_tagctrl_cfi_id) begin
                  cfi_counters[CFI_ENTRY] <= cfi_counters[CFI_ENTRY] - 1'b1;
               end
            end
         end
      end
   endgenerate


   always_ff@(posedge clk or negedge resetn) begin
      if (!resetn) begin
         cfi_pointer <= '0;
      end
      else if (request_stage2_valid & request_stage2_ready & (request_stage2_rec.instruction == CFG_FLUSH | request_stage2_rec.instruction == CFG_FLUSH_INVALID) & (&request_stage2_rec.set)) begin
         cfi_pointer <= cfi_pointer + 1'b1;
      end
   end


   gpc_gfx_rpfifo_
   #(
      .w               ( L2_MAX_CFI_BITS+AXI_INST_WIDTH ) ,
      .d               ( L2_NUM_MAX_CFI                 ) )
   i_cfi_order_fifo      (
      .clk             ( clk                            )
     ,.resetn          ( resetn                           )
     ,.fifo_in_valid   ( cfi_fifo_in_valid              )
     ,.fifo_in_enable  ( cfi_fifo_in_ready              )
     ,.fifo_in_data    ( cfi_fifo_in_data               )
   
     ,.fifo_out_valid  ( cfi_fifo_out_valid             )
     ,.fifo_out_enable ( cfi_fifo_out_ready             )
     ,.fifo_out_data   ( cfi_fifo_out_data              )
   );
   
   assign cfi_fifo_in_valid = request_stage2_valid & request_stage2_ready & (&request_stage2_rec.set) & (request_stage2_rec.instruction == CFG_INVALID | request_stage2_rec.instruction == CFG_FLUSH | request_stage2_rec.instruction == CFG_FLUSH_INVALID);
   assign cfi_fifo_in_data[AXI_INST_WIDTH-1:0]              = 3'(request_stage2_rec.instruction);
   assign cfi_fifo_in_data[AXI_INST_WIDTH+:L2_MAX_CFI_BITS] = cfi_pointer;
   assign cfi_fifo_out_instruction                          = l2_bank_instr_type'(cfi_fifo_out_data[AXI_INST_WIDTH-1:0]);
   assign cfi_fifo_out_pointer                              = cfi_fifo_out_data[AXI_INST_WIDTH+:L2_MAX_CFI_BITS];

   always_comb begin
      cfi_fifo_out_ready = 1'b0;
      if (cfi_fifo_out_valid) begin
         case(cfi_fifo_out_instruction)
            CFG_INVALID: cfi_fifo_out_ready = 1'b1;
            CFG_FLUSH, CFG_FLUSH_INVALID: cfi_fifo_out_ready = (cfi_counters[cfi_fifo_out_pointer] == 'd0);
            default: cfi_fifo_out_ready = 1'b1;
         endcase
      end
   end


   logic pending_initial;
   always_ff@(posedge clk or negedge resetn) begin
      if(!resetn) begin
         pending_initial <= 1'b1;          
      end
      else if (cfi_fifo_out_valid && cfi_fifo_out_ready) begin
          pending_initial <= 1'b0;
      end
   end

   always_ff@(posedge clk or negedge resetn) begin
      if (!resetn) begin
         tagctrl_align_cfi_complete <= 1'b0;
      end
      else if (cfi_fifo_out_valid && cfi_fifo_out_ready && !pending_initial) begin
        tagctrl_align_cfi_complete <= 1'b1;
     end
     else if (tagctrl_align_cfi_complete) begin
        tagctrl_align_cfi_complete <= 1'b0; 
     end
   end

   // ==============================================================================
   // hazard_table and overflow FIFO : TODO
   // ==============================================================================
   
   assign hazard_table_request_valid = 1'b0;
   assign overflow_fifo_valid = 1'b0;
   assign hazard_table_rec = '0;
   assign overflow_fifo_rec = '0;
   assign hazard_table_empty = 1'b1;
   assign n_overflow_fifo_valid = 1'b0;


   // ==============================================================================
   // performance counter 
   // ==============================================================================

  assign l2b_hittest_ht_bypass_read_wl  = request_stage2_valid && request_stage2_ready && request_stage2_rec.instruction == AXI_RD && request_stage2_rec.cache_policy ;
  assign l2b_hittest_ht_cache_read_wl   = request_stage2_valid && request_stage2_ready && request_stage2_rec.instruction == AXI_RD && !request_stage2_rec.cache_policy ;
  assign l2b_hittest_ht_bypass_write_wl = request_stage2_valid && request_stage2_ready && request_stage2_rec.instruction == AXI_WR && request_stage2_rec.cache_policy;
  assign l2b_hittest_ht_cache_write_wl  = request_stage2_valid && request_stage2_ready && request_stage2_rec.instruction == AXI_WR && !request_stage2_rec.cache_policy;
  assign l2b_hittest_ht_atomic_wl       = request_stage2_valid && request_stage2_ready && request_stage2_rec.instruction == AXI_AA ;
  assign l2b_hittest_ht_bps_hit_wl      = request_stage2_valid && request_stage2_ready && (request_stage2_rec.instruction == AXI_RD || request_stage2_rec.instruction == AXI_WR) && request_stage2_rec.cache_policy && request_stage2_hit;
  assign l2b_hittest_ht_miss_wl         = request_stage2_valid && request_stage2_ready && (request_stage2_rec.instruction == AXI_RD || request_stage2_rec.instruction == AXI_WR || request_stage2_rec.instruction == AXI_AA) && !request_stage2_hit;
















   // synopsys translate_off
   default clocking cb@(posedge clk);
   endclocking
   default disable iff(!resetn);
   as__cfi_os_equal_1: 
      assert property (cfi_fifo_in_ready == 1'b1);
   as__replace_cacheline_check: 
      assert property (request_stage2_valid && !l2_bank_operation_need_unroll(request_stage2_rec.instruction) && request_stage2_replace_valid |-> selected_access_counter_array[request_stage2_replace_way] == '0);
   as__stage2_hit_mask_onehot_check: 
      assert property (request_stage2_valid |-> $onehot0(request_stage2_hit_mask));
   as__arbiter_valid_ready_check: 
      assert property (arbiter_valid & !arbiter_ready |=> arbiter_valid && $stable(arbiter_request_rec));
   as__miss_lookup_wb_buffer_onehot_check: 
      assert property (request_stage2_valid |-> $onehot0(request_stage2_lookup_wb_buf_mask));
   as__wb_allocate_deallocate_check: // the cacheline can't be allocated and deallocated at the same cycle
      assert property (inflight_wb_allocate_valid & inflight_wb_allocate_ready & rctrl_tagctrl_wb_done_valid[0] && ~rctrl_tagctrl_wb_rec[0].lf_or_wb
                      |-> !(request_stage2_rec.set == rctrl_tagctrl_wb_rec[0].set && 
                           (l2_bank_operation_need_unroll(request_stage2_rec.instruction) ? request_stage2_cfi_selected_way : request_stage2_target_way )
                           == rctrl_tagctrl_wb_rec[0].way)); 
   as__wb_allocate_deallocate_check1: // the cacheline can't be allocated and deallocated at the same cycle
      assert property (inflight_wb_allocate_valid & inflight_wb_allocate_ready & rctrl_tagctrl_wb_done_valid[1] && ~rctrl_tagctrl_wb_rec[1].lf_or_wb
                      |-> !(request_stage2_rec.set == rctrl_tagctrl_wb_rec[1].set && 
                           (l2_bank_operation_need_unroll(request_stage2_rec.instruction) ? request_stage2_cfi_selected_way : request_stage2_target_way )
                           == rctrl_tagctrl_wb_rec[1].way));
   logic [L2_NUM_RCTRL-1:0][L2_WB_BUF_DEPTH-1:0] rctrl_hit_wb_buffer_mask;
   generate
      for (genvar wb_entry =0; wb_entry < 16; wb_entry++) begin
         assign rctrl_hit_wb_buffer_mask[0][wb_entry] = rctrl_lookup_wb_buf_mask[wb_entry][0];
         assign rctrl_hit_wb_buffer_mask[1][wb_entry] = rctrl_lookup_wb_buf_mask[wb_entry][1];
      end
   endgenerate
   logic [L2_NUM_SET-1:0][L2_NUM_WAY-1:0]                touched_mask                        ;
   for (genvar WAY = 0; WAY < L2_NUM_WAY; WAY++) begin
      for (genvar SET = 0; SET < L2_NUM_SET; SET++) begin
         always_ff@(posedge clk or negedge resetn) begin
            if(!resetn) begin
               touched_mask[SET][WAY] <= '0; 
            end
            else if (n_request_stage3_valid && ~n_request_stage3_wen[WAY] && request_stage2_set_mask[SET])begin
               touched_mask[SET][WAY] <= n_request_stage3_tag_ram_rec.touched_mask[WAY];
            end
         end
      end
   end
   as_wb_lookup_onehot_check0:
      assert property (rctrl_tagctrl_wb_done_valid[0] && ~rctrl_tagctrl_wb_rec[0].lf_or_wb |-> $onehot0(rctrl_hit_wb_buffer_mask[0])); 
   as_wb_lookup_onehot_check1:
      assert property (rctrl_tagctrl_wb_done_valid[1] && ~rctrl_tagctrl_wb_rec[1].lf_or_wb |-> $onehot0(rctrl_hit_wb_buffer_mask[1])); 
   as__check_aa_blen:
      assert property (request_stage2_valid && request_stage2_rec.instruction == AXI_AA |-> request_stage2_rec.blen == 2'b00 );
   as__check_hit_cl_status:
      assert property (request_stage2_valid && request_stage2_rec.instruction inside {AXI_RD, AXI_WR, AXI_AA} && request_stage2_hit |-> {request_stage2_hit_sector_status, request_stage2_miss_sector_status} != {INVALID, INVALID});
   as__check_axi_operation:
      assert property (request_stage2_valid |-> request_stage2_rec.instruction inside {AXI_RD, AXI_WR, AXI_AA, CFG_FLUSH, CFG_FLUSH_INVALID, CFG_INVALID, CFG_RST_PERSIST, CFG_REDUCE_PERSIST});
   as__check_cfi_operation:
      assert property (cfi_fifo_out_valid |-> cfi_fifo_out_instruction inside {CFG_INVALID, CFG_FLUSH, CFG_FLUSH_INVALID});
   as__stage2_onehot_check:
      assert property (request_stage2_valid |-> $onehot0(request_stage2_set_mask) && request_stage2_set_mask[request_stage2_rec.set] == 1'b1);
   as__stage2_select_check:
      assert property (request_stage2_valid |-> selected_partial_array == partial_array[request_stage2_rec.set] && selected_access_counter_array == access_counter_array[request_stage2_rec.set]);
   as__touched_mask_select_check:
      assert property (request_stage2_valid  && ~pending_initial |-> selected_cacheline_status.touched_mask == touched_mask[request_stage2_rec.set]);
   as__stage1_stall_vs_stage3:
      assert property (stalled_stage1_data_valid |-> ~request_stage3_valid);
   as__lf_isched_dependency_check:
      assert property (tagctrl_memif_valid && tagctrl_memif_rec.memif_instruction == LF |-> (tagctrl_isched_ready | isched_req_issued));
   as__st_replace_dirty_isched_dependency_check:
      assert property (tagctrl_memif_valid && tagctrl_memif_rec.memif_instruction == NOPE && tagctrl_memif_rec.wb_valid |-> (tagctrl_isched_ready | isched_req_issued));
   // synopsys translate_on
endmodule
// Local Variables:
// verilog-library-directories:("./" ) 
// End:
