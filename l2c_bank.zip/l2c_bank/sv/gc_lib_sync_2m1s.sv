// Author: jinjifang
// Date: 2025/1/10
// Description: the sync of valid-enable interface, two master input and one slave output
module gc_lib_sync_2m1s(
    // slave0 input
    input logic         m0_valid,
    output logic        m0_enable,
    // slave1 input
    input logic         m1_valid,
    output logic        m1_enable,
    // master output
    output logic        s_valid,
    input logic         s_enable
);

    assign s_valid      = m0_valid & m1_valid;
    assign m0_enable    = s_enable & m1_valid;
    assign m1_enable    = s_enable & m0_valid;

endmodule
