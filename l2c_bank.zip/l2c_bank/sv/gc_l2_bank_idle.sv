/*


*/

// ----------------------------------------------------------------------------------------------
// entity name: gc_l2_bank_idle
// purpose: L2 bank idle generation, default reset value is 0
// ----------------------------------------------------------------------------------------------


module gc_l2_bank_idle #(
    parameter int   NUM_IDLE    = 4,
    parameter logic RESET_VALUE = 1'b0
) (
    input   logic                   clk,
    input   logic                   resetn,
    input   logic [NUM_IDLE-1   :0] in_idles,
    output  logic                   out_idle
);

always_ff @(posedge clk or negedge resetn) begin: p_out_idle_reg
    if(!resetn) begin
        out_idle <= RESET_VALUE;
    end
    else if(&in_idles) begin
        out_idle <= 1'b1;
    end
    else begin
        out_idle <= 1'b0;
    end
end: p_out_idle_reg

endmodule
