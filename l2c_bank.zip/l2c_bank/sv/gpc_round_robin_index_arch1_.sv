/*

 * #==========================================================================#
 * |                                                                          |
 * |  Copyright (c) 2022, Fantasy Technologies Limited and/or its         |
 * |  affiliated group companies ("Fantasy"). All rights reserved.        |
 * |  No part of this content, either material or conceptual may be copied    |
 * |  or distributed, transmitted, transcribed, stored in a retrieval system  |
 * |  or translated into any human or computer language in any form by any    |
 * |  means, electronic, mechanical manual, or otherwise, or disclosed to     |
 * |  third parties without the express written permission of Fantasy.    |
 * |                                                                          |
 * #==========================================================================#

 */

module gpc_round_robin_index_arch1_
  import gpc_round_robin_index_arch1_gateway_pkg_::*;
  import gpc_dpg_pkg_::*;
  #(
    parameter int   width = 2,
    parameter logic hold_previous = 0
   )
   (
    input  logic [width-1 : 0]                     valids,
    input  logic [dpg_max(1, $clog2(width))-1 : 0] previous_index,
    output logic [dpg_max(1, $clog2(width))-1 : 0] next_index
    );

   logic [0 : 0]                                   fail_signal;

   // invalid input assertions
   // synopsys translate_off
   // pragma coverage off
   localparam logic                                assert_disable = 1'b0;
   logic                                           assert_inputs_ok;
   logic                                           assert_index_less_than_width;
   logic                                           assert_prev_index_disable;
   // pragma coverage on
   // synopsys translate_on

   assign fail_signal[gpc_round_robin_index_arch1_gateway_fail(width, hold_previous)] = 1'b0;

// invalid input assertions
// synopsys translate_off
// pragma coverage off
   assign assert_prev_index_disable = ($isunknown (previous_index)) ? 1'b1 : 1'b0;
   assign assert_index_less_than_width = ((previous_index) < width) ? 1'b1 : assert_disable;
   assign #5 assert_inputs_ok                         = assert_prev_index_disable || assert_index_less_than_width;
   always_comb begin
      as_inputs_ok : assert (assert_inputs_ok !== 1'b0) else
        $fatal(1, "The input previous_index >= width. This is an invalid input into this component.");
   end
// pragma coverage on
// synopsys translate_on

   // If the width is 1, a special case is needed, since vector widths would not match up otherwise
   generate
      if ((width == 1)) begin : width_equals_1
         assign next_index[0] = 1'b0;
      end
   endgenerate

   // Normal case, arbitration is required
   generate
      if ((width > 1)) begin : width_greater_than_1
         logic [width-1 : 0]                                      mask;
         logic [width-1 : 0]                                      prio;
         localparam int                                           n    = 2 * width;
         localparam int                                           top  = $clog2(n)-1;
         logic [n-2 : 0][top-1 : 0]                               sig;
         logic [n-1 : 0]                                          x;

         // Create a trailing one mask based on the input. It is done slightly differently depending on the value of hold_previous
         if (hold_previous) begin : hold_index
            assign mask = ({(width) {1'b1}}) << previous_index;
         end

         if (!hold_previous) begin : drop_index
            assign mask =  ({{(width-1) {1'b1}}, 1'b0}) << previous_index;
         end

         // Construct vector for the trailing zero count.
         assign prio = mask & valids;
         assign x = {{1'b1, valids[width-2 : 0]}, prio};

         //    Do the trailing zero count.
         assign sig[0] = width - 1;

         genvar i;
         for (i = 1; i < n-1; i++) begin : next_high_bit
            assign sig[i]  = (x[n-1-i] == 1'b1) ? ((n-1-i) % width) : sig[i-1];
         end : next_high_bit
         //    Final selection for the output index
         assign next_index = (x[0] == 1'b1) ? 0 : sig[n-2];
      end : width_greater_than_1
   endgenerate
endmodule
