

module gpc_gfx_timing_buffer_wakeup_pipe_
#(
      parameter                      BUFFER_TYPE                                            = 0             ,
      parameter                      WIDTH                                                  = 32            ,
      parameter                      PIPE_STAGES                                            = 1
)
(
      input    logic                                                        clk                                     ,
      input    logic                                                        resetn                                  ,

      input    logic                                                        tbuff_in_valid                          ,
      output   logic                                                        tbuff_in_enable                         ,
      input    logic [ WIDTH - 1 : 0 ]                                      tbuff_in_data                           ,

      output   logic                                                        tbuff_out_valid                         ,
      input    logic                                                        tbuff_out_enable                        ,
      output   logic [ WIDTH - 1 : 0 ]                                      tbuff_out_data                          ,

      input    logic                                                        wakeup_in                               ,
      output   logic                                                        wakeup_out                              
);

gpc_gfx_timing_buffer_wakeup_pipe #(
     .BUFFER_TYPE (BUFFER_TYPE),
     .WIDTH       (WIDTH),
     .PIPE_STAGES (PIPE_STAGES)    
)i_gpc_gfx_timing_buffer_wakeup_pipe (
     .clk                       (clk               ),
     .resetn                    (resetn            ),
                                                  
     .tbuff_in_valid            (tbuff_in_valid    ),
     .tbuff_in_enable           (tbuff_in_enable   ),
     .tbuff_in_data             (tbuff_in_data     ),
                                                  
     .tbuff_out_valid           (tbuff_out_valid   ),
     .tbuff_out_enable          (tbuff_out_enable  ),
     .tbuff_out_data            (tbuff_out_data    ),
                                                  
     .wakeup_in                 (wakeup_in         ),
     .wakeup_out                (wakeup_out        )
);

endmodule // gpc_gfx_timing_buffer_wakeup_pipe_
