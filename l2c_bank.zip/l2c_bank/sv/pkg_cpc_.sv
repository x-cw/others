


package pkg_cpc_;



//GP3
   localparam int                 C_CPC_ADDR_WIDTH                                   = 48;
   localparam int                 C_CLUSTER                                          = 64;
   localparam int                 C_CSD_CTG_ID_WIDTH                                 = 3;
   localparam int                 C_CSD_CTG_DATA_WIDTH                               = 32;
   localparam int                 C_CSD_CTG_COUNT_WIDTH                              = 5;
   localparam int                 C_KERNEL_ID_WIDTH                                  = 6;
   localparam int                 C_CU_ALLOC_SIZE_WIDTH                             = 11;
   localparam int                 C_WORK_ITEM_MODE_WIDTH                             = 2;
   localparam int                 C_SD_TYPE_WIDTH                                    = 2;
   localparam int                 C_WORKGROUP_SIZE_WIDTH                             = 10;
   localparam int                 C_WORKITEM_MODE_WIDTH                              = 2;
   localparam int                 C_CU_UNIFIED_SIZE_WIDTH                           = 7;
   localparam int                 C_CU_TEMP_SIZE_WIDTH                              = 7;
   localparam int                 C_INSTANCE_MAX_WIDTH                               = 7;
   localparam int                 C_DOUT_PARTTERN_WIDTH                              = 5;
   localparam int                 C_SHARE_ACCESS_POLICT_WIDTH                        = 6;
   localparam int                 C_SHARED_STORE_OFFEST_WIDTH                        = 13;
   localparam int                 C_SHARED_SIZE_WIDTH                                = 12;
   localparam int                 C_SHARED_BASE_ADDRESS_WIDTH                        = 48;
   localparam int                 C_CU_PC_WIDTH                                      = 30;
   localparam int                 C_UNIFIED_STORE_OFFEST_WIDTH                       = 13;
   localparam int                 C_WG_NEED_DIM_WIDTH                                = 3;
   localparam int                 C_WI_NEED_DIM_WIDTH                                = 3;
   localparam int                 C_BARRIER_VALUE_WIDTH                              = 4;
   localparam int                 C_PARTITION_ID_WIDTH                               = 32;
   localparam int                 C_PARTITION_SIZE_WIDTH                             = 32;
   localparam int                 C_CPC_BIF_ADDRESS_WIDTH                            = 48;
   localparam int                 C_CPC_BIF_ADDRESS_ALIGN                            = 6;
   localparam int                 C_CPC_BIF_BURST_LENGTH_WIDTH                       = 2;
   localparam int                 C_CPC_BIF_TAG_WIDTH                                = 4;
   localparam int                 C_CPC_BIF_WMASK_WIDTH                              = 64;
   localparam int                 C_CPC_BIF_DATA_WIDTH                               = 512;
   
   localparam int                 C_CTG_PARTITION_DIM_WIDTH                          = 2;
   localparam int                 C_CTG_DOUT_PARRTEN_WIDTH                           = 5;
   localparam int                 C_WORKGROUP_ID_WIDTH                               = 32;
   localparam int                 C_SHARED_BASE_ADDRESS_LSB_WIDTH                    = 16;
   localparam int                 C_SHARED_BASE_ADDRESS_MSB_WIDTH                    = 32;
   localparam int                 C_OBJECT_ATOMIC_OP_WIDTH                           = 4;
   localparam int                 C_OBJECT_DATA_WIDTH                                = 64;
   localparam int                 C_TIMESTAMP_ADDRESS_WIDTH                          = 48;
   localparam int                 C_FENCE_SUB_OPCODE_WIDTH                           = 2;
   localparam int                 C_FENCE_EVNET_ID_WIDTH                             = 12;
   localparam int                 C_FENCE_CACHE_CTRL_WIDTH                           = 2;
   localparam int                 C_FENCE_COMPARSION_MODE_WIDTH                      = 3;

   localparam int                 C_FENCE_DATA_MSB_WIDTH                             = 32;
   localparam int                 C_FENCE_DATA_WIDTH                                 = 64;


   localparam                     C_COMPUTE_ID_NUM                                   = 64;
   localparam int                 C_KERNEL_TYPE                                      = 2;
   localparam int                 C_CONTEXT_NUM_DWORDS                               = 30;

   localparam                     CONTEXT_NUM_BIF_TX                                 = 2;
   localparam int                 C_MAX_PARITION_PER_KERNEL_WIDTH                    = 16;
   localparam int                 C_PT_DECREMENT_PER_KERNEL_WIDTH                    = 6;
   localparam int                 C_NUM_GPC                                          = 4;
   localparam int                 C_MSS_MMU_AUTO_CACHE_OPS_WIDTH                     = 2;
   localparam int                 C_PIM_RTN_FINISH_STATUS_WIDTH                      = 128;
   localparam int                 C_PIM_ADDRESS_WIDTH                                = 48;
   localparam int                 C_PIM_MAX_OUTSTANDING_WIDTH                        = 5;
   localparam int                 C_PIM_KERNEL_ID_MAX_NUM                            = 32;
   



//end





   //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
   //   Enumerators
   //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

   typedef enum logic [2 : 0] {
      E_CSD_CTG_ID_COMPUTE_KERNEL         = 3'b000,
      E_CSD_CTG_ID_STREAM_TERM            = 3'b001,
      E_CSD_CTG_ID_COMPUTE_FENCE_KERNEL   = 3'b010,
      E_CSD_CTG_ID_FENCE_KERNEL           = 3'b011,
      E_CSD_CTG_ID_PIM_KERNEL             = 3'b100
   } t_e_csd_ctg_id;

   typedef enum logic [4 : 0] {
      E_COMPUTE_KERNEL_COUNTER0           = 5'd0,
      E_COMPUTE_KERNEL_COUNTER1           = 5'd1,
      E_COMPUTE_KERNEL_COUNTER2           = 5'd2,
      E_COMPUTE_KERNEL_COUNTER3           = 5'd3,
      E_COMPUTE_KERNEL_COUNTER4           = 5'd4,
      E_COMPUTE_KERNEL_COUNTER5           = 5'd5,
      E_COMPUTE_KERNEL_COUNTER6           = 5'd6,
      E_COMPUTE_KERNEL_COUNTER7           = 5'd7,
      E_COMPUTE_KERNEL_COUNTER8           = 5'd8,
      E_COMPUTE_KERNEL_COUNTER9           = 5'd9,
      E_COMPUTE_KERNEL_COUNTER10          = 5'd10,
      E_COMPUTE_KERNEL_COUNTER11          = 5'd11,
      E_COMPUTE_KERNEL_COUNTER12          = 5'd12,
      E_COMPUTE_KERNEL_COUNTER13          = 5'd13,
      E_COMPUTE_KERNEL_COUNTER14          = 5'd14,
      E_COMPUTE_KERNEL_COUNTER15          = 5'd15,
      E_COMPUTE_KERNEL_COUNTER16          = 5'd16,
      E_COMPUTE_KERNEL_COUNTER17          = 5'd17,
      E_COMPUTE_KERNEL_COUNTER18          = 5'd18

   } t_e_csd_ctg_compute_counter;

   typedef enum logic [4 : 0] {
      E_FENCE_KERNEL_COUNTER0           = 5'd0,
      E_FENCE_KERNEL_COUNTER1           = 5'd1,
      E_FENCE_KERNEL_COUNTER2           = 5'd2,
      E_FENCE_KERNEL_COUNTER3           = 5'd3,
      E_FENCE_KERNEL_COUNTER4           = 5'd4
   } t_e_csd_ctg_fence_counter;

   typedef enum logic [4 : 0] {
      E_PIM_KERNEL_COUNTER0           = 5'd0,
      E_PIM_KERNEL_COUNTER1           = 5'd1,
      E_PIM_KERNEL_COUNTER2           = 5'd2,
      E_PIM_KERNEL_COUNTER3           = 5'd3,
      E_PIM_KERNEL_COUNTER4           = 5'd4,
      E_PIM_KERNEL_COUNTER5           = 5'd5,
      E_PIM_KERNEL_COUNTER6           = 5'd6,
      E_PIM_KERNEL_COUNTER7           = 5'd7,
      E_PIM_KERNEL_COUNTER8           = 5'd8,
      E_PIM_KERNEL_COUNTER9           = 5'd9,
      E_PIM_KERNEL_COUNTER10          = 5'd10,
      E_PIM_KERNEL_COUNTER11          = 5'd11,
      E_PIM_KERNEL_COUNTER12          = 5'd12,
      E_PIM_KERNEL_COUNTER13          = 5'd13

   } t_e_csd_ctg_pim_counter;


   typedef enum logic [3 : 0] {
      E_CTG_BIF_TAG_EVT                 = 4'b0000,
      E_CTG_BIF_TAG_CTX                 = 4'b0001,
      E_CTG_BIF_TAG_SIGR                = 4'b0010,
      E_CTG_BIF_TAG_SIGW                = 4'b0011,
      E_CTG_BIF_TAG_SIG_FENCE_FLUINV    = 4'b0100,
      E_CTG_BIF_TAG_FLUSH_FLU           = 4'b0101,
      E_CTG_BIF_TAG_SIG_FENCE_FLU       = 4'b0110,
      E_CTG_BIF_TAG_FLUSH_FLUINV        = 4'b0111,
      E_CTG_BIF_TAG_FLUSH_INV           = 4'b1000,
      E_CTG_BIF_TAG_PROFILING           = 4'b1001,
      E_CTG_BIF_TAG_UP_FENCE_ATOMIC     = 4'b1010,
      E_CTG_BIF_TAG_UP_FENCE_W          = 4'b1011,
      E_CTG_BIF_TAG_DE_R                = 4'b1100,
      E_CTG_BIF_TAG_PIM                 = 4'b1101

   } t_e_ctg_bif_tag;

   typedef enum logic [2 : 0] {
      E_DMA_BIF_TAG_PDB0    = 3'b000,
      E_DMA_BIF_TAG_ID      = 3'b001,
      E_DMA_BIF_TAG_CB      = 3'b010,
      E_DMA_BIF_TAG_PDB1    = 3'b011,
      E_DMA_BIF_TAG_STK     = 3'b100,
      E_DMA_BIF_TAG_PRED    = 3'b101, 
      E_DMA_BIF_TAG_IDB     = 3'b111
   } t_e_dma_bif_tag;



   typedef enum logic [4 : 0] {
      E_CPC_BIF_TAG_EVT                 = 5'b00001,
      E_CPC_BIF_TAG_CTX                 = 5'b00011,
      E_CPC_BIF_TAG_SIGR                = 5'b00101,
      E_CPC_BIF_TAG_SIGW                = 5'b00111,
      E_CPC_BIF_TAG_SIG_FENCE_FLUINV    = 5'b01001,
      E_CPC_BIF_TAG_FLUSH_FLU           = 5'b01011,
      E_CPC_BIF_TAG_SIG_FENCE_FLU       = 5'b01101,
      E_CPC_BIF_TAG_FLUSH_FLUINV        = 5'b01111,
      E_CPC_BIF_TAG_FLUSH_INV           = 5'b10001,
      E_CPC_BIF_TAG_PROFILING           = 5'b10011,
      E_CPC_BIF_TAG_UP_FENCE_ATOMIC     = 5'b10101,
      E_CPC_BIF_TAG_UP_FENCE_W          = 5'b10111,
      E_CPC_BIF_TAG_DE_R                = 5'b11001,
      E_CPC_BIF_TAG_PIM                 = 5'b11011,
      E_CPC_BIF_TAG_PDB0                = 5'b00000,
      E_CPC_BIF_TAG_ID                  = 5'b00010,
      E_CPC_BIF_TAG_CB                  = 5'b00100,
      E_CPC_BIF_TAG_PDB1                = 5'b00110,
      E_CPC_BIF_TAG_STK                 = 5'b01000,
      E_CPC_BIF_TAG_PRED                = 5'b01010, 
      E_CPC_BIF_TAG_IDB                 = 5'b01110
   } t_e_cpc_bif_tag;

   typedef enum logic [2 : 0] {
      E_CPC_DEPENDENCY_FENCE_COMP_LT          = 3'b001,
      E_CPC_DEPENDENCY_FENCE_COMP_EQ          = 3'b010,
      E_CPC_DEPENDENCY_FENCE_COMP_LT_OR_EQ    = 3'b011,
      E_CPC_DEPENDENCY_FENCE_COMP_GT          = 3'b100,
      E_CPC_DEPENDENCY_FENCE_COMP_NOT_EQ      = 3'b101,
      E_CPC_DEPENDENCY_FENCE_COMP_GT_OR_EQ    = 3'b110,
      E_CPC_DEPENDENCY_FENCE_COMP_ALL_PASS    = 3'b111

   } t_e_cpc_dependency_fence_comparision_mode;

   typedef enum logic [1 : 0] {
        E_CPC_UPDATE_FENCE_OPCODE_WRITE        = 2'b00,
        E_CPC_UPDATE_FENCE_OPCODE_ATOMIC_ADD   = 2'b01,
        E_CPC_UPDATE_FENCE_OPCODE_ATOMIC_SUB   = 2'b10

   } t_e_cpc_update_fence_opcode;

   typedef enum logic [1 : 0] {
        E_CPC_SHARE_TYPE_KERNEL        = 2'b00,
        E_CPC_FREE_TYPE_KERNEL         = 2'b01,
        E_CPC_OTHERS_TYPE_KERNEL       = 2'b10

   } t_e_cpc_kernel_type;




   typedef enum logic [2 : 0] {
      E_CTG_OBJ_TAG_EVT                 = 3'b000,
      E_CTG_OBJ_TAG_SIGNW               = 3'b001,

      E_CTG_OBJ_TAG_SINGNR              = 3'b010,
      E_CTG_OBJ_TAG_DEP_R               = 3'b011,     

      E_CTG_OBJ_TAG_PROFILING           = 3'b100

   } t_e_ctg_obj_tag;


   typedef enum logic [3 : 0] {
        E_CPC_ATOMIC_OP_ADD        = 4'b0000,
        E_CPC_ATOMIC_OP_SUB        = 4'b0001


   } t_e_cpc_atomic_op;


   typedef struct packed {
     
        logic  [pkg_cpc_::C_CPC_BIF_ADDRESS_WIDTH-1 : pkg_cpc_::C_CPC_BIF_ADDRESS_ALIGN ] addr ;
        logic  [pkg_cpc_::C_CPC_BIF_TAG_WIDTH-1 : 0]                                      tag  ;
        logic  [pkg_cpc_::C_CPC_BIF_DATA_WIDTH-1 : 0]                                     wdata;
        logic  [pkg_cpc_::C_CPC_BIF_WMASK_WIDTH-1 : 0]                                    wmask;  
        logic                                                                             rnw  ;
        logic                                                                             fence;
        logic  [5 : 0]                                                                    ctxt_pasid;     

   } t_cpc_bif_cmd;



endpackage
