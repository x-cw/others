// ---------------------------------------------------------------------------------
// Project Name  : IC_Design
// Author        : liusm
// Email         : liusm@innosilicon.com.cn
// Create On     : 2025/02/11 15:45
// Last Modified : 2025/02/11 15:45
// File Name     : gc_l2_bank_rctrl_spram_pipeline.sv
// Description   :
// 
// Copyright (c) 2025 Innosilicon.
// ALL RIGHTS RESERVED
// 
// ---------------------------------------------------------------------------------
// Modification History:
// Date         By              Version                 Change Description
// ---------------------------------------------------------------------------------
// 2025/02/11   liusm           1.0                     Original
// 
// ----------------------------------------------------------------------------------


module gc_l2_bank_rctrl_spram_pipeline
#(
   parameter   w                                        = 8, // integer
   parameter   p                                        = 8, // integer
   parameter   d                                        = 8, // integer
   parameter   log2d                                    = 3, // integer
   parameter   id                                       = 0
 )
(
      input    logic    clk
,     input    logic    resetn
,     input    logic    te
,     output   logic    idle

,     input    logic                      read_valid
,     output   logic                      read_ready
,     input    logic  [log2d-1:0]         read_addr

,     output   logic                      readout_valid
,     input    logic                      readout_ready
,     output   logic  [w-1:0]             readout_data

,     input    logic                      write_valid
,     input    logic  [w/p-1:0]           write_en
,     input    logic  [log2d-1:0]         write_addr
,     input    logic  [w-1:0]             write_data
);

localparam BUF_DEPTH      = 4;
localparam BUF_DEPTH_BITS = $clog2(BUF_DEPTH);

logic                               request_stage1_valid;
logic                               request_stage1_ready;
logic [log2d-1:0]                   request_stage1_addr;
logic [w-1:0]                       request_stage1_data;

logic                               request_stage2_valid;
logic                               request_stage2_ready;
logic [log2d-1:0]                   request_stage2_addr;
logic [w-1:0]                       request_stage2_data;

logic                               request_stage3_valid;
logic [log2d-1:0]                   request_stage3_addr;
logic [w-1:0]                       request_stage3_data;

logic                               request_stage4_valid ;
logic [w/p-1:0]                     request_stage4_wen   ;
logic [log2d-1:0]                   request_stage4_addr  ;
logic [w-1:0]                       request_stage4_data  ;

logic                               request_stage1_stall_valid;
logic [w-1:0]                       request_stage1_stall_data;

logic                               forward_stage3_to_stage1_valid;

logic                               forward_stage3_to_stage2_rd_valid;
logic [w-1:0]                       forward_stage3_to_stage2_rd_data;

logic                               forward_stage4_to_stage0_valid;
logic [w-1:0]                       forward_stage4_to_stage0_data;

logic                               forward_stage4_to_stage1_valid;
logic [w-1:0]                       forward_stage4_to_stage1_data;
logic [w/p-1:0]                     forward_stage4_to_stage1_wen;

logic                               buf_in_valid    ;
logic                               buf_out_valid   ;
logic                               buf_out_ready   ;
logic                               buf_full    ;
logic                               buf_empty   ;
logic [BUF_DEPTH_BITS-1 : 0]        n_buf_wrptr ;
logic [BUF_DEPTH_BITS-1 : 0]        n_buf_rdptr ;
logic [BUF_DEPTH_BITS-1 : 0]        buf_wrptr   ;
logic [BUF_DEPTH_BITS-1 : 0]        buf_rdptr   ;
logic [BUF_DEPTH-1 : 0]             buf_valid   ;
logic [BUF_DEPTH-1 : 0] [w/p-1:0]   buf_wen     ;
logic [BUF_DEPTH-1 : 0] [log2d-1:0] buf_addr    ;
logic [BUF_DEPTH-1 : 0] [w-1:0]     buf_data    ;
logic [BUF_DEPTH-1 : 0]             wr_addr_hit ;
logic [BUF_DEPTH_BITS-1 : 0]        wr_hit_idx  ;
logic                               wr_merge_en ;
logic [BUF_DEPTH-1 : 0]             rd_addr_hit ;
logic [BUF_DEPTH_BITS-1 : 0]        rd_hit_idx  ;
logic                               rd_hit_all_byte;
logic [BUF_DEPTH-1 : 0]             rd_s1_addr_hit ;
logic [BUF_DEPTH_BITS-1 : 0]        rd_s1_hit_idx  ;
logic                               rd_fwd;

logic                               cen;
logic [w/p-1:0]                     wen;
logic [log2d-1:0]                   a;
logic [w-1:0]                       di;
logic [w-1:0]                       q;


// -------------------------------------------------------------------------------------------------
// pipelines
// -------------------------------------------------------------------------------------------------
// buffer read address for forward
always_ff@(posedge clk or negedge resetn) begin
   if (!resetn) begin
      request_stage1_valid <= 1'b0;
      request_stage1_addr  <= '0;
   end
   else if (read_valid && read_ready) begin
      request_stage1_valid <= 1'b1;
      request_stage1_addr  <= read_addr;
   end
   else if (request_stage1_valid && request_stage1_ready) begin
      request_stage1_valid <= 1'b0;
   end
end

// buffer stage1 data if stage 2 back pressure
always_ff@(posedge clk or negedge resetn) begin
   if (!resetn) begin
      request_stage1_stall_valid <= 1'b0;
      request_stage1_stall_data  <= '0;
   end
   else if (request_stage1_valid && !request_stage1_ready) begin
      request_stage1_stall_valid <= 1'b1;
      request_stage1_stall_data  <= request_stage1_data;
   end
   else if (request_stage1_valid && request_stage1_ready) begin
      request_stage1_stall_valid <= 1'b0;
   end
end

// register for sram output
always_ff@(posedge clk or negedge resetn) begin
   if (!resetn) begin
      request_stage2_valid <= 1'b0;
      request_stage2_addr  <= '0;
      request_stage2_data  <= '0;
   end
   else if (request_stage1_valid && request_stage1_ready) begin
      request_stage2_valid <= 1'b1;
      request_stage2_addr  <= request_stage1_addr;
      request_stage2_data  <= request_stage1_data;
   end
   // hold forward data
   else if((forward_stage3_to_stage2_rd_valid) && ~request_stage2_ready) begin
       request_stage2_data <= readout_data;
   end
   else if (request_stage2_valid && request_stage2_ready) begin
      request_stage2_valid <= 1'b0;
   end
end

always_ff@(posedge clk or negedge resetn) begin
   if (!resetn) begin
      request_stage3_valid  <= 1'b0;
      request_stage3_addr   <= '0;
      request_stage3_data   <= '0;
   end
   else if (request_stage2_valid && request_stage2_ready) begin
      request_stage3_valid  <= 1'b1;
      request_stage3_addr   <= request_stage2_addr;
      request_stage3_data   <= readout_data;
   end
   else if (request_stage3_valid) begin
      request_stage3_valid  <= 1'b0;
   end
end


// -------------------------------------------------------------------------------------------------
// add write data buffer to store write data, reduce read/write conflict
// -------------------------------------------------------------------------------------------------
assign buf_in_valid  = write_valid & (~wr_merge_en);
assign buf_out_valid = ~buf_empty;
// write SRAM if buffer full, no read request or read request doesn't need to read SRAM
assign buf_out_ready = buf_full | (~read_valid) | (read_valid & rd_fwd);

assign buf_full      = &buf_valid;
assign buf_empty     = ~|buf_valid;
// not merge if write hit current write index
assign wr_merge_en   = (|wr_addr_hit) & ~(buf_out_valid && buf_out_ready && (buf_rdptr == wr_hit_idx));

assign n_buf_wrptr   = buf_wrptr + 1'b1;
assign n_buf_rdptr   = buf_rdptr + 1'b1;

always_ff @(posedge clk or negedge resetn) begin
    if(!resetn) begin
        buf_wrptr <= 'b0;
        buf_rdptr <= 'b0;
    end
    else begin
        if(buf_in_valid) begin
            if(n_buf_wrptr == BUF_DEPTH)
                buf_wrptr <= 'b0;
            else
                buf_wrptr <= n_buf_wrptr;
        end

        if(buf_out_valid && buf_out_ready) begin
            if(n_buf_rdptr == BUF_DEPTH)
                buf_rdptr <= 'b0;
            else
                buf_rdptr <= n_buf_rdptr;
        end
    end
end

generate
for(genvar IDX=0; IDX<BUF_DEPTH; IDX++) begin: g_wr_buf
    always_ff @(posedge clk or negedge resetn) begin
        if(!resetn) begin
            buf_valid[IDX] <= 'b0;
            buf_wen  [IDX] <= 'b0;
            buf_addr [IDX] <= 'b0;
            buf_data [IDX] <= 'b0;
        end
        else begin
            if(write_valid && wr_merge_en && (IDX == wr_hit_idx)) begin
                buf_wen  [IDX] <= buf_wen[IDX] & write_en  ;
                for (int unsigned partition=0; partition<w/p; partition++) begin
                buf_data [IDX][partition*p+:p] <= ~write_en[partition] ? write_data[partition*p+:p] : buf_data[IDX][partition*p+:p];
                end
            end
            else if(buf_in_valid && (IDX == buf_wrptr)) begin
                buf_wen  [IDX] <= write_en  ;
                buf_addr [IDX] <= write_addr;
                buf_data [IDX] <= write_data;
            end

            if(buf_out_valid && buf_out_ready && (IDX == buf_rdptr)) begin
                if(buf_in_valid && (IDX == buf_wrptr))
                    buf_valid[IDX] <= 1'b1  ;   // out and in
                else
                    buf_valid[IDX] <= 1'b0  ;   // out only
            end
            else if(buf_in_valid && (IDX == buf_wrptr)) begin
                    buf_valid[IDX] <= 1'b1  ;   // in  only
            end
        end
    end
end

for(genvar IDX=0; IDX<BUF_DEPTH; IDX++) begin: g_addr_lookup
    always_comb begin
        if(buf_valid[IDX] && write_valid && (buf_addr[IDX] == write_addr))
            wr_addr_hit[IDX] = 1'b1;
        else
            wr_addr_hit[IDX] = 1'b0;

        if(buf_valid[IDX] && read_valid  && (buf_addr[IDX] == read_addr ))
            rd_addr_hit[IDX] = 1'b1;
        else
            rd_addr_hit[IDX] = 1'b0;

        if(buf_valid[IDX] && request_stage1_valid  && (buf_addr[IDX] == request_stage1_addr))
            rd_s1_addr_hit[IDX] = 1'b1;
        else
            rd_s1_addr_hit[IDX] = 1'b0;
    end
end
endgenerate

gpc_gfx_prienc_ones_lsb_ #(
    .W              (BUF_DEPTH      ),
    .OUTPUT_WIDTH   (BUF_DEPTH_BITS )
) i_wr_hit_index (
    .vector(wr_addr_hit             ),
    .result(wr_hit_idx              )
);

gpc_gfx_prienc_ones_lsb_ #(
    .W              (BUF_DEPTH      ),
    .OUTPUT_WIDTH   (BUF_DEPTH_BITS )
) i_rd_hit_index (
    .vector(rd_addr_hit             ),
    .result(rd_hit_idx              )
);

gpc_gfx_prienc_ones_lsb_ #(
    .W              (BUF_DEPTH      ),
    .OUTPUT_WIDTH   (BUF_DEPTH_BITS )
) i_rd_s1_hit_index (
    .vector(rd_s1_addr_hit          ),
    .result(rd_s1_hit_idx           )
);

assign rd_hit_all_byte      = (|rd_addr_hit) && (~|buf_wen[rd_hit_idx]);

// generate write SRAM request
assign request_stage4_valid = buf_out_valid & buf_out_ready;
assign request_stage4_wen   = buf_wen [buf_rdptr];
assign request_stage4_addr  = buf_addr[buf_rdptr];
assign request_stage4_data  = buf_data[buf_rdptr];


// -------------------------------------------------------------------------------------------------
// forward path
// -------------------------------------------------------------------------------------------------
// stage3 to stage1 forward, read only
assign forward_stage3_to_stage1_valid = request_stage3_valid && request_stage1_valid && (request_stage3_addr == request_stage1_addr);

// stage3 to stage2 forward, read only
assign forward_stage3_to_stage2_rd_data  = request_stage3_data;
// move address compare to previsous stage for timing optimization
always_ff @(posedge clk or negedge resetn) begin
    if(!resetn)
        forward_stage3_to_stage2_rd_valid <= 1'b0;
    else if(request_stage1_valid && request_stage2_valid && request_stage2_ready && (request_stage2_addr == request_stage1_addr))
        forward_stage3_to_stage2_rd_valid <= 1'b1;
    else if(forward_stage3_to_stage2_rd_valid)
        forward_stage3_to_stage2_rd_valid <= 1'b0;
end


// stage4 to stage0 forward, write to read
// forward previous write data to read out
always_ff@(posedge clk or negedge resetn) begin
   if (!resetn) begin
      forward_stage4_to_stage0_valid <= 1'b0;
      forward_stage4_to_stage0_data  <= '0;
   end
   // read hit current write index and all byte valid
   else if (read_valid && rd_hit_all_byte && (buf_rdptr == rd_hit_idx) && buf_out_valid && buf_out_ready) begin
      forward_stage4_to_stage0_valid <= 1'b1;
      forward_stage4_to_stage0_data  <= request_stage4_data;
   end
   else begin
      forward_stage4_to_stage0_valid <= 1'b0;
   end
end

// stage4 to stage1 forward, write to read
// forward data from data buffer to read out
assign forward_stage4_to_stage1_valid = |rd_s1_addr_hit;
assign forward_stage4_to_stage1_data  = buf_data[rd_s1_hit_idx];
assign forward_stage4_to_stage1_wen   = buf_wen [rd_s1_hit_idx];


generate 
   for (genvar partition = 0; partition < w/p ; partition ++) begin
      // select stage1 data
      assign request_stage1_data[partition*p+:p] = (request_stage1_stall_valid) ? request_stage1_stall_data[partition*p+:p] :
                                                   (forward_stage4_to_stage1_valid && ~forward_stage4_to_stage1_wen[partition]) ? forward_stage4_to_stage1_data[partition*p+:p]: 
                                                   (forward_stage4_to_stage0_valid) ? forward_stage4_to_stage0_data[partition*p+:p] :
                                                   (forward_stage3_to_stage1_valid) ? request_stage3_data[partition*p+:p] : q[partition*p+:p];

      // select readout data
      assign readout_data[partition*p+:p] = (forward_stage3_to_stage2_rd_valid) ? forward_stage3_to_stage2_rd_data[partition*p+:p] : request_stage2_data[partition*p+:p];
   end
endgenerate


// -------------------------------------------------------------------------------------------------
// interface control and SRAM instance
// -------------------------------------------------------------------------------------------------
// no write or read request doesn't need to read SRAM, return read ready when next stage ready
assign read_ready = ((~request_stage4_valid) || rd_fwd) && (~request_stage1_valid || request_stage1_ready);

assign request_stage1_ready = ~request_stage2_valid | request_stage2_ready;

assign request_stage2_ready = readout_ready;
assign readout_valid = request_stage2_valid;

// forward all data to read out, this read request doesn't need to read SRAM
assign rd_fwd   = (read_valid && request_stage1_valid && (read_addr == request_stage1_addr)) ||     // s1(rd) to 0(rd) forward
                  (read_valid && request_stage2_valid && (read_addr == request_stage2_addr)) ||     // s2(rd) to 0(rd) forward
                  (read_valid && write_valid && (read_addr == write_addr) && (write_en == 'b0)) ||  // wr     to 0(rd) forward
                  (read_valid && rd_hit_all_byte);                                                  // wr_buf to 0(rd) forward

// access SRAM when read can't forward or write
assign cen  = ((read_valid && read_ready && (~rd_fwd)) || request_stage4_valid) ? 1'b0 : 1'b1;
assign wen  = request_stage4_valid ? request_stage4_wen  : '1;
assign a    = request_stage4_valid ? request_stage4_addr : read_addr;
assign di   = request_stage4_data;

assign idle = ~(request_stage1_valid | request_stage1_stall_valid | request_stage2_valid | request_stage3_valid |
                request_stage4_valid | read_valid | write_valid | (|buf_valid));

gpu_core_mss_gfx_spstore
#(
  .w              ( w     ) ,
  .p              ( p     ) ,
  .d              ( d     ) ,
  .log2d          ( log2d ) ,
  .id             ( id    ) )
i_pipeline_spsram (
   .CLK           ( clk   ) ,
   .CEN           ( cen   ) ,
   .WEN           ( wen   ) ,
   .A             ( a     ) ,
   .DI            ( di    ) ,
   .Q             ( q     ) ,
   .TE            ( te    ) ,
   .L2M           (       ) ,
   .SRAM          (       ) );


// -------------------------------------------------------------------------------------------------
// assertions
// -------------------------------------------------------------------------------------------------
// synopsys translate_off
logic                           wr_hit;
logic                           rd_hit;
logic                           rd_s1_hit;
logic [BUF_DEPTH_BITS-1 : 0]    hit_ones;
logic [BUF_DEPTH_BITS-1 : 0]    wr_hit_ones;
logic [BUF_DEPTH_BITS-1 : 0]    rd_hit_ones;
logic [BUF_DEPTH_BITS-1 : 0]    rd_s1_hit_ones;

gpc_gfx_count_ones_ #(.W(BUF_DEPTH), .RESULT_BITS(BUF_DEPTH_BITS)) i_wr_count   (.vector(wr_addr_hit   ), .result(wr_hit_ones   ));
gpc_gfx_count_ones_ #(.W(BUF_DEPTH), .RESULT_BITS(BUF_DEPTH_BITS)) i_rd_count   (.vector(rd_addr_hit   ), .result(rd_hit_ones   ));
gpc_gfx_count_ones_ #(.W(BUF_DEPTH), .RESULT_BITS(BUF_DEPTH_BITS)) i_rd_s1_count(.vector(rd_s1_addr_hit), .result(rd_s1_hit_ones));

assign wr_hit   = write_valid           & (|wr_addr_hit     );
assign rd_hit   = read_valid            & (|rd_addr_hit     );
assign rd_s1_hit= request_stage1_valid  & (|rd_s1_addr_hit  );

property buf_hit_check(valid, hit_ones);
    disable iff(!resetn)
    @(posedge clk) (valid) |-> (hit_ones == 1);
endproperty

a_wr_hit_check      : assert property(buf_hit_check(wr_hit   , wr_hit_ones      ))
                    else $error("write address hit more than once in write data buffer");
a_rd_hit_check      : assert property(buf_hit_check(rd_hit   ,  rd_hit_ones     ))
                    else $error("read address hit more than once in write data buffer");
a_rd_s1_hit_check   : assert property(buf_hit_check(rd_s1_hit, rd_s1_hit_ones   ))
                    else $error("read stage1 address hit more than once in write data buffer");


property buf_ovfl_check(buf_in_valid, buf_out_ready, buf_full);
    disable iff(!resetn)
    @(posedge clk) (buf_in_valid) |-> (~buf_full | buf_out_ready);
endproperty

a_buf_ovfl_check    : assert property(buf_ovfl_check(buf_in_valid, buf_out_ready, buf_full))
                    else $error("write data buffer overflow");

// stage4 to stage1 forward must cover stage4 to stage2/3 forward
// if there is stage4 to stage2/3 forward, there must be stage4 to stage1 forward at before for the same read request
logic               forward_s4_to_s2_valid;
logic               forward_s4_to_s3_valid;
logic               forward_s4_to_s1_valid_to_s2;
logic               forward_s4_to_s1_valid_to_s3;
logic [log2d-1:0]   forward_s4_to_s1_addr_to_s2 ;
logic [log2d-1:0]   forward_s4_to_s1_addr_to_s3 ;

assign forward_s4_to_s2_valid = request_stage4_valid && request_stage2_valid && (request_stage4_addr == request_stage2_addr);
assign forward_s4_to_s3_valid = request_stage4_valid && request_stage3_valid && (request_stage4_addr == request_stage3_addr);

always_ff @(posedge clk or negedge resetn) begin
    if(!resetn) begin
        forward_s4_to_s1_valid_to_s2 <= 1'b0;
        forward_s4_to_s1_valid_to_s3 <= 1'b0;
        forward_s4_to_s1_addr_to_s2  <= 'b0;
        forward_s4_to_s1_addr_to_s3  <= 'b0;
    end
    else begin
        if(request_stage1_valid & request_stage1_ready) begin
            forward_s4_to_s1_valid_to_s2 <= forward_stage4_to_stage1_valid;
            forward_s4_to_s1_addr_to_s2  <= request_stage1_addr           ;
        end
        else if(request_stage2_valid & request_stage2_ready) begin
            forward_s4_to_s1_valid_to_s2 <= 1'b0;
        end

        if(request_stage2_valid & request_stage2_ready) begin
            forward_s4_to_s1_valid_to_s3 <= forward_s4_to_s1_valid_to_s2  ;
            forward_s4_to_s1_addr_to_s3  <= forward_s4_to_s1_addr_to_s2   ;
        end
        else if(request_stage3_valid) begin
            forward_s4_to_s1_valid_to_s3 <= 1'b0;
        end
    end
end

property fwd_overlap_check(forward_valid, forward_valid_dly, request_stage4_addr, request_stage1_addr);
    disable iff(!resetn)
    @(posedge clk) (forward_valid) |-> (forward_valid_dly && (request_stage4_addr == request_stage1_addr));
endproperty

a_fwd_s4_s2_check   : assert property(fwd_overlap_check(forward_s4_to_s2_valid, forward_s4_to_s1_valid_to_s2, request_stage4_addr, forward_s4_to_s1_addr_to_s2))
                    else $error("forward_s4_to_s2_valid but this forward not happen at forward_stage4_to_stage1_valid");
a_fwd_s4_s3_check   : assert property(fwd_overlap_check(forward_s4_to_s3_valid, forward_s4_to_s1_valid_to_s3, request_stage4_addr, forward_s4_to_s1_addr_to_s3))
                    else $error("forward_s4_to_s3_valid but this forward not happen at forward_stage4_to_stage1_valid");

logic [39:0]    cnt_req_num;
logic [39:0]    cnt_cen_num;
logic [39:0]    cnt_nosram_num;

always_ff @(posedge clk or negedge resetn) begin
    if(!resetn) begin
        cnt_req_num     <= 'b0;
        cnt_cen_num     <= 'b0;
        cnt_nosram_num  <= 'b0;
    end
    else begin
        cnt_req_num     <= cnt_req_num + (read_valid & read_ready) + write_valid;
        cnt_nosram_num  <= cnt_nosram_num + (read_valid & read_ready & rd_fwd) + (write_valid & wr_merge_en);
        if(~cen)
        cnt_cen_num     <= cnt_cen_num + 1'b1;
    end
end

property sram_acc_check(idle, cnt_req_num, cnt_cen_num, cnt_nosram_num);
    disable iff(!resetn)
    @(posedge clk) (idle) |-> (cnt_req_num == (cnt_cen_num + cnt_nosram_num));
endproperty

a_sram_acc_check    : assert property(sram_acc_check(idle, cnt_req_num, cnt_cen_num, cnt_nosram_num))
                    else $error("the number of read and write request mismatch with sram access");

// synopsys translate_on


endmodule
// Local Variables:
// verilog-library-directories:("./" ) 
// End:
