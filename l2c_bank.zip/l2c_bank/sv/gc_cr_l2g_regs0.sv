//-----------------------------------------------------------------------------------------------------------------
//
//                file : gc_cr_l2g_regs0_.sv
//
//           copyright : 2001-2020 by Imagination Technologies Limited. All rights
//                       reserved. No part of this hardware description, either
//                       material or conceptual may be copied or distributed,
//                       transmitted, transcribed, stored in a retrieval system
//                       or translated into any human or computer language in
//                       any form by any means, electronic, mechanical, manual
//                       or otherwise, or disclosed to third parties without
//                       the express written permission of Imagination
//                       Technologies Limited, Home Park Estate, Kings Langley,
//                       Hertfordshire, WD4 8LZ, U.K.
//
//     generated from : (null)
//                 by : regconv.c REL/1@6006852 
//-----------------------------------------------------------------------------------------------------------------

module gc_cr_l2g_regs0
import gc_cr_global_regpack_::*;
(

    input  logic              clk,
    input  logic              resetn,

    // external register access (via router) N.B. no flow control

    input  logic [ 16 : 0 ]   sys_addr,
    input  logic [ 63 : 0 ]   sys_wdata,
    input  logic [ 7 : 0 ]    sys_wmask,
    input  logic              sys_wr,
    input  logic              sys_rd,

    output logic [ 63 : 0 ]   sys_rdata,
    output logic              sys_rd_val,
    input  logic [  2 : 0 ]    regbank_instance,
    input logic [ 15 : 0 ]               gc_cr_l2_cfi_statusii,
    output logic [ 15 : 0 ]              gc_cr_clk_ctrl3,
    input logic [ 7 : 0 ]                gc_cr_clk_status3,
    output logic                         gc_cr_cu_lms_fp32_denormal_en,
    output logic [ 23 : 0 ]              gc_cr_perf_mon1,
    output logic [ 29 : 0 ]              gc_cr_perf_mon4,
    output logic [ 1 : 0 ]               gc_cr_l2_cfi_operation,
    input logic [ 63 : 0 ]               gc_cr_l2_cfi_statusi,
    output logic [ 1 : 0 ]               gc_cr_l2_buffer_mode,
    output logic [ 21 : 0 ]              gc_cr_l2_persistence_reduce,
    output logic [ 1 : 0 ]               gc_cr_l2_cmd,
    input logic [ 63 : 0 ]               gc_cr_l2g_idle,
    input logic [ 62 : 0 ]               gc_cr_l2g_error0,
    input logic [ 62 : 0 ]               gc_cr_l2g_error1,
    input logic [ 62 : 0 ]               gc_cr_l2g_error2,
    input logic [ 2 : 0 ]                gc_cr_l2g_error3,
    output logic [ 7 : 0 ]               gc_cr_l2_function_enable,
    output logic [ 39 : 0 ]              gc_cr_l2_mem_sched_col_offset,
    output logic [ 24 : 0 ]              gc_cr_l2_mem_sched_bank_offset,
    output logic [ 39 : 0 ]              gc_cr_l2_mem_sched_row_parti,
    output logic [ 39 : 0 ]              gc_cr_l2_mem_sched_row_partii,
    output logic [ 9 : 0 ]               gc_cr_l2_mem_sched_row_partiii,
    output logic [ 47 : 0 ]              gc_cr_ddr_hash_config_reg0,
    output logic [ 47 : 0 ]              gc_cr_ddr_hash_config_reg1,
    input logic [ 15 : 0 ]               gc_cr_l2g_idleii,
    output logic [ 4 : 0 ]               gc_cr_pwr_man_hysteresis,
    output logic [ 1 : 0 ]               gc_cr_crm_reset_clk,
    output logic                         gc_cr_l2_cfi_operation_notify,
    output logic                         gc_cr_l2_cfi_operation_rdnotify,
    output logic                         gc_cr_l2_cmd_notify,
    output logic                         gc_cr_l2_cmd_rdnotify
 );
    logic [ 15 : 0 ]                     gc_cr_l2_cfi_statusii_reg ;
    logic [ 15 : 0 ]                     gc_cr_clk_ctrl3_reg ;
    logic [ 7 : 0 ]                      gc_cr_clk_status3_reg ;
    logic                                gc_cr_cu_lms_fp32_denormal_en_reg ;
    logic [ 23 : 0 ]                     gc_cr_perf_mon1_reg ;
    logic [ 29 : 0 ]                     gc_cr_perf_mon4_reg ;
    logic [ 1 : 0 ]                      gc_cr_l2_cfi_operation_reg ;
    logic [ 63 : 0 ]                     gc_cr_l2_cfi_statusi_reg ;
    logic [ 1 : 0 ]                      gc_cr_l2_buffer_mode_reg ;
    logic [ 21 : 0 ]                     gc_cr_l2_persistence_reduce_reg ;
    logic [ 1 : 0 ]                      gc_cr_l2_cmd_reg ;
    logic [ 63 : 0 ]                     gc_cr_l2g_idle_reg ;
    logic [ 62 : 0 ]                     gc_cr_l2g_error0_reg ;
    logic [ 62 : 0 ]                     gc_cr_l2g_error1_reg ;
    logic [ 62 : 0 ]                     gc_cr_l2g_error2_reg ;
    logic [ 2 : 0 ]                      gc_cr_l2g_error3_reg ;
    logic [ 7 : 0 ]                      gc_cr_l2_function_enable_reg ;
    logic [ 39 : 0 ]                     gc_cr_l2_mem_sched_col_offset_reg ;
    logic [ 24 : 0 ]                     gc_cr_l2_mem_sched_bank_offset_reg ;
    logic [ 39 : 0 ]                     gc_cr_l2_mem_sched_row_parti_reg ;
    logic [ 39 : 0 ]                     gc_cr_l2_mem_sched_row_partii_reg ;
    logic [ 9 : 0 ]                      gc_cr_l2_mem_sched_row_partiii_reg ;
    logic [ 47 : 0 ]                     gc_cr_ddr_hash_config_reg0_reg ;
    logic [ 47 : 0 ]                     gc_cr_ddr_hash_config_reg1_reg ;
    logic [ 15 : 0 ]                     gc_cr_l2g_idleii_reg ;
    logic [ 4 : 0 ]                      gc_cr_pwr_man_hysteresis_reg ;
    logic [ 1 : 0 ]                      gc_cr_crm_reset_clk_reg ;
    logic [ 2 : 0 ]                      gc_cr_l2g_indirect_reg ;

    logic                                n_gc_cr_l2_cfi_operation_notify;
    logic                                n_gc_cr_l2_cfi_operation_rdnotify;

    logic                                n_gc_cr_l2_cmd_notify;
    logic                                n_gc_cr_l2_cmd_rdnotify;

    logic [ 63 : 0 ]  rdata_tmp ;
    logic [ 16 : 0 ]  addr;
    logic             rd;
    logic             wr;
    logic [ 63 : 0 ]  wdata;
    logic [ 7 : 0 ]    wmask;
    logic             rd_val;

    //}}



    //{{ internal signals
    assign rd    = sys_rd;
    assign wr    = sys_wr;
    assign addr  = sys_addr;
    assign wdata = sys_wdata;
    assign wmask = sys_wmask;
    //}}

    //{{ excluded registers tied to default reset state
    //}}

    //{{ write registers
    always_ff @(posedge clk, negedge resetn)
    begin : wreg
        //{{ Reset values
        if (~resetn) begin
            gc_cr_clk_ctrl3_reg                            <= 16'haaaa;
            gc_cr_cu_lms_fp32_denormal_en_reg              <= 1'h0;
            gc_cr_perf_mon1_reg                            <= 24'h0;
            gc_cr_perf_mon4_reg                            <= 30'h0;
            gc_cr_l2_cfi_operation_reg                     <= 2'h0;
            gc_cr_l2_buffer_mode_reg                       <= 2'h0;
            gc_cr_l2_persistence_reduce_reg                <= 22'h0;
            gc_cr_l2_cmd_reg                               <= 2'h0;
            gc_cr_l2_function_enable_reg                   <= 8'h0;
            gc_cr_l2_mem_sched_col_offset_reg              <= 40'h0;
            gc_cr_l2_mem_sched_bank_offset_reg             <= 25'h0;
            gc_cr_l2_mem_sched_row_parti_reg               <= 40'h0;
            gc_cr_l2_mem_sched_row_partii_reg              <= 40'h0;
            gc_cr_l2_mem_sched_row_partiii_reg             <= 10'h0;
            gc_cr_ddr_hash_config_reg0_reg                 <= 48'h999999999999;
            gc_cr_ddr_hash_config_reg1_reg                 <= 48'h999999999999;
            gc_cr_pwr_man_hysteresis_reg                   <= 5'h1f;
            gc_cr_crm_reset_clk_reg                        <= 2'h0;
            gc_cr_l2g_indirect_reg                         <= 3'h0;
            gc_cr_l2_cfi_operation_notify                    <= 1'b0;
            gc_cr_l2_cfi_operation_rdnotify                  <= 1'b0;
            gc_cr_l2_cmd_notify                              <= 1'b0;
            gc_cr_l2_cmd_rdnotify                            <= 1'b0;
        //}}

        end else begin
            //{{ Write only registers - self clearing
            //}}
            //{{ Read only registers
            //}}
            //{{ Software writes to register value
            if (wr) begin  //do a write
                case (addr)
                //spyglass disable_block -rule "STARC05-2.2.3.3"
                    GC_CR_CLK_CTRL3_ADD : begin // Masked write
                           if ( ~wmask[0] ) begin
                              gc_cr_clk_ctrl3_reg[7 : 0]  <=  { wdata[7 : 0] } ;
                           end

                           if ( ~wmask[1] ) begin
                              gc_cr_clk_ctrl3_reg[15 : 8]  <=  { wdata[15 : 8] } ;
                           end

                    end
                    GC_CR_CU_LMS_FP32_DENORMAL_EN_ADD : begin // Masked write
                           if ( ~wmask[0] ) begin
                              gc_cr_cu_lms_fp32_denormal_en_reg  <=  { wdata[0] } ;
                           end

                    end
                    GC_CR_PERF_MON1_ADD : begin // Masked write
                           if ( ~wmask[0] ) begin
                              gc_cr_perf_mon1_reg[7 : 0]  <=  { wdata[7 : 0] } ;
                           end

                           if ( ~wmask[1] ) begin
                              gc_cr_perf_mon1_reg[15 : 8]  <=  { wdata[15 : 8] } ;
                           end

                           if ( ~wmask[2] ) begin
                              gc_cr_perf_mon1_reg[23 : 16]  <=  { wdata[23 : 16] } ;
                           end

                    end
                    GC_CR_PERF_MON4_ADD : begin // Masked write
                           if ( ~wmask[0] ) begin
                              gc_cr_perf_mon4_reg[7 : 0]  <=  { wdata[7 : 0] } ;
                           end

                           if ( ~wmask[1] ) begin
                              gc_cr_perf_mon4_reg[15 : 8]  <=  { wdata[15 : 8] } ;
                           end

                           if ( ~wmask[2] ) begin
                              gc_cr_perf_mon4_reg[23 : 16]  <=  { wdata[23 : 16] } ;
                           end

                           if ( ~wmask[3] ) begin
                              gc_cr_perf_mon4_reg[29 : 24]  <=  { wdata[29 : 24] } ;
                           end

                    end
                    GC_CR_L2_CFI_OPERATION_ADD : begin // Masked write
                           if ( ~wmask[0] ) begin
                              gc_cr_l2_cfi_operation_reg[1 : 0]  <=  { wdata[1 : 0] } ;
                           end

                    end
                    GC_CR_L2_BUFFER_MODE_ADD : begin // Masked write
                           if ( ~wmask[0] ) begin
                              gc_cr_l2_buffer_mode_reg[1 : 0]  <=  { wdata[1 : 0] } ;
                           end

                    end
                    GC_CR_L2_PERSISTENCE_REDUCE_ADD : begin // Masked write
                           if ( ~wmask[0] ) begin
                              gc_cr_l2_persistence_reduce_reg[7 : 0]  <=  { wdata[7 : 0] } ;
                           end

                           if ( ~wmask[1] ) begin
                              gc_cr_l2_persistence_reduce_reg[15 : 8]  <=  { wdata[15 : 8] } ;
                           end

                           if ( ~wmask[2] ) begin
                              gc_cr_l2_persistence_reduce_reg[21 : 16]  <=  { wdata[21 : 16] } ;
                           end

                    end
                    GC_CR_L2_CMD_ADD : begin // Masked write
                           if ( ~wmask[0] ) begin
                              gc_cr_l2_cmd_reg[1 : 0]  <=  { wdata[1 : 0] } ;
                           end

                    end
                    GC_CR_L2_FUNCTION_ENABLE_ADD : begin // Masked write
                           if ( ~wmask[0] ) begin
                              gc_cr_l2_function_enable_reg[7 : 0]  <=  { wdata[7 : 0] } ;
                           end

                    end
                    GC_CR_L2_MEM_SCHED_COL_OFFSET_ADD : begin // Masked write
                           if ( ~wmask[0] ) begin
                              gc_cr_l2_mem_sched_col_offset_reg[4 : 0]  <=  { wdata[4 : 0] } ;
                           end

                           if ( ~wmask[1] ) begin
                              gc_cr_l2_mem_sched_col_offset_reg[9 : 5]  <=  { wdata[12 : 8] } ;
                           end

                           if ( ~wmask[2] ) begin
                              gc_cr_l2_mem_sched_col_offset_reg[14 : 10]  <=  { wdata[20 : 16] } ;
                           end

                           if ( ~wmask[3] ) begin
                              gc_cr_l2_mem_sched_col_offset_reg[19 : 15]  <=  { wdata[28 : 24] } ;
                           end

                           if ( ~wmask[4] ) begin
                              gc_cr_l2_mem_sched_col_offset_reg[24 : 20]  <=  { wdata[36 : 32] } ;
                           end

                           if ( ~wmask[5] ) begin
                              gc_cr_l2_mem_sched_col_offset_reg[29 : 25]  <=  { wdata[44 : 40] } ;
                           end

                           if ( ~wmask[6] ) begin
                              gc_cr_l2_mem_sched_col_offset_reg[34 : 30]  <=  { wdata[52 : 48] } ;
                           end

                           if ( ~wmask[7] ) begin
                              gc_cr_l2_mem_sched_col_offset_reg[39 : 35]  <=  { wdata[60 : 56] } ;
                           end

                    end
                    GC_CR_L2_MEM_SCHED_BANK_OFFSET_ADD : begin // Masked write
                           if ( ~wmask[0] ) begin
                              gc_cr_l2_mem_sched_bank_offset_reg[4 : 0]  <=  { wdata[4 : 0] } ;
                           end

                           if ( ~wmask[1] ) begin
                              gc_cr_l2_mem_sched_bank_offset_reg[9 : 5]  <=  { wdata[12 : 8] } ;
                           end

                           if ( ~wmask[2] ) begin
                              gc_cr_l2_mem_sched_bank_offset_reg[14 : 10]  <=  { wdata[20 : 16] } ;
                           end

                           if ( ~wmask[3] ) begin
                              gc_cr_l2_mem_sched_bank_offset_reg[19 : 15]  <=  { wdata[28 : 24] } ;
                           end

                           if ( ~wmask[4] ) begin
                              gc_cr_l2_mem_sched_bank_offset_reg[24 : 20]  <=  { wdata[36 : 32] } ;
                           end

                    end
                    GC_CR_L2_MEM_SCHED_ROW_PARTI_ADD : begin // Masked write
                           if ( ~wmask[0] ) begin
                              gc_cr_l2_mem_sched_row_parti_reg[4 : 0]  <=  { wdata[4 : 0] } ;
                           end

                           if ( ~wmask[1] ) begin
                              gc_cr_l2_mem_sched_row_parti_reg[9 : 5]  <=  { wdata[12 : 8] } ;
                           end

                           if ( ~wmask[2] ) begin
                              gc_cr_l2_mem_sched_row_parti_reg[14 : 10]  <=  { wdata[20 : 16] } ;
                           end

                           if ( ~wmask[3] ) begin
                              gc_cr_l2_mem_sched_row_parti_reg[19 : 15]  <=  { wdata[28 : 24] } ;
                           end

                           if ( ~wmask[4] ) begin
                              gc_cr_l2_mem_sched_row_parti_reg[24 : 20]  <=  { wdata[36 : 32] } ;
                           end

                           if ( ~wmask[5] ) begin
                              gc_cr_l2_mem_sched_row_parti_reg[29 : 25]  <=  { wdata[44 : 40] } ;
                           end

                           if ( ~wmask[6] ) begin
                              gc_cr_l2_mem_sched_row_parti_reg[34 : 30]  <=  { wdata[52 : 48] } ;
                           end

                           if ( ~wmask[7] ) begin
                              gc_cr_l2_mem_sched_row_parti_reg[39 : 35]  <=  { wdata[60 : 56] } ;
                           end

                    end
                    GC_CR_L2_MEM_SCHED_ROW_PARTII_ADD : begin // Masked write
                           if ( ~wmask[0] ) begin
                              gc_cr_l2_mem_sched_row_partii_reg[4 : 0]  <=  { wdata[4 : 0] } ;
                           end

                           if ( ~wmask[1] ) begin
                              gc_cr_l2_mem_sched_row_partii_reg[9 : 5]  <=  { wdata[12 : 8] } ;
                           end

                           if ( ~wmask[2] ) begin
                              gc_cr_l2_mem_sched_row_partii_reg[14 : 10]  <=  { wdata[20 : 16] } ;
                           end

                           if ( ~wmask[3] ) begin
                              gc_cr_l2_mem_sched_row_partii_reg[19 : 15]  <=  { wdata[28 : 24] } ;
                           end

                           if ( ~wmask[4] ) begin
                              gc_cr_l2_mem_sched_row_partii_reg[24 : 20]  <=  { wdata[36 : 32] } ;
                           end

                           if ( ~wmask[5] ) begin
                              gc_cr_l2_mem_sched_row_partii_reg[29 : 25]  <=  { wdata[44 : 40] } ;
                           end

                           if ( ~wmask[6] ) begin
                              gc_cr_l2_mem_sched_row_partii_reg[34 : 30]  <=  { wdata[52 : 48] } ;
                           end

                           if ( ~wmask[7] ) begin
                              gc_cr_l2_mem_sched_row_partii_reg[39 : 35]  <=  { wdata[60 : 56] } ;
                           end

                    end
                    GC_CR_L2_MEM_SCHED_ROW_PARTIII_ADD : begin // Masked write
                           if ( ~wmask[0] ) begin
                              gc_cr_l2_mem_sched_row_partiii_reg[4 : 0]  <=  { wdata[4 : 0] } ;
                           end

                           if ( ~wmask[1] ) begin
                              gc_cr_l2_mem_sched_row_partiii_reg[9 : 5]  <=  { wdata[12 : 8] } ;
                           end

                    end
                    GC_CR_DDR_HASH_CONFIG_REG0_ADD : begin // Masked write
                           if ( ~wmask[0] ) begin
                              gc_cr_ddr_hash_config_reg0_reg[7 : 0]  <=  { wdata[7 : 0] } ;
                           end

                           if ( ~wmask[1] ) begin
                              gc_cr_ddr_hash_config_reg0_reg[15 : 8]  <=  { wdata[15 : 8] } ;
                           end

                           if ( ~wmask[2] ) begin
                              gc_cr_ddr_hash_config_reg0_reg[23 : 16]  <=  { wdata[23 : 16] } ;
                           end

                           if ( ~wmask[3] ) begin
                              gc_cr_ddr_hash_config_reg0_reg[31 : 24]  <=  { wdata[31 : 24] } ;
                           end

                           if ( ~wmask[4] ) begin
                              gc_cr_ddr_hash_config_reg0_reg[39 : 32]  <=  { wdata[39 : 32] } ;
                           end

                           if ( ~wmask[5] ) begin
                              gc_cr_ddr_hash_config_reg0_reg[47 : 40]  <=  { wdata[47 : 40] } ;
                           end

                    end
                    GC_CR_DDR_HASH_CONFIG_REG1_ADD : begin // Masked write
                           if ( ~wmask[0] ) begin
                              gc_cr_ddr_hash_config_reg1_reg[7 : 0]  <=  { wdata[7 : 0] } ;
                           end

                           if ( ~wmask[1] ) begin
                              gc_cr_ddr_hash_config_reg1_reg[15 : 8]  <=  { wdata[15 : 8] } ;
                           end

                           if ( ~wmask[2] ) begin
                              gc_cr_ddr_hash_config_reg1_reg[23 : 16]  <=  { wdata[23 : 16] } ;
                           end

                           if ( ~wmask[3] ) begin
                              gc_cr_ddr_hash_config_reg1_reg[31 : 24]  <=  { wdata[31 : 24] } ;
                           end

                           if ( ~wmask[4] ) begin
                              gc_cr_ddr_hash_config_reg1_reg[39 : 32]  <=  { wdata[39 : 32] } ;
                           end

                           if ( ~wmask[5] ) begin
                              gc_cr_ddr_hash_config_reg1_reg[47 : 40]  <=  { wdata[47 : 40] } ;
                           end

                    end
                    GC_CR_PWR_MAN_HYSTERESIS_ADD : begin // Masked write
                           if ( ~wmask[0] ) begin
                              gc_cr_pwr_man_hysteresis_reg[4 : 0]  <=  { wdata[4 : 0] } ;
                           end

                    end
                    GC_CR_CRM_RESET_CLK_ADD : begin // Masked write
                           if ( ~wmask[0] ) begin
                              gc_cr_crm_reset_clk_reg[1 : 0]  <=  { wdata[1 : 0] } ;
                           end

                    end
                    GC_CR_L2G_INDIRECT_ADD : begin // Masked write
                           if ( ~wmask[0] ) begin
                              gc_cr_l2g_indirect_reg[2 : 0]  <=  { wdata[2 : 0] } ;
                           end

                    end
                    default :
                        ;
                //spyglass enable_block -rule "STARC05-2.2.3.3"
                endcase
            end
        //}}
        //{{ External notify wiring
        gc_cr_l2_cfi_operation_notify                        <= n_gc_cr_l2_cfi_operation_notify;
        gc_cr_l2_cfi_operation_rdnotify                      <= n_gc_cr_l2_cfi_operation_rdnotify;
        gc_cr_l2_cmd_notify                                  <= n_gc_cr_l2_cmd_notify;
        gc_cr_l2_cmd_rdnotify                                <= n_gc_cr_l2_cmd_rdnotify;
        //}}
        end
    end // wreg
    //}}

    //{{ readonly register assignments
    assign gc_cr_l2_cfi_statusii_reg                         = gc_cr_l2_cfi_statusii;
    assign gc_cr_clk_status3_reg                             = gc_cr_clk_status3;
    assign gc_cr_l2_cfi_statusi_reg                          = gc_cr_l2_cfi_statusi;
    assign gc_cr_l2g_idle_reg                                = gc_cr_l2g_idle;
    assign gc_cr_l2g_error0_reg                              = gc_cr_l2g_error0;
    assign gc_cr_l2g_error1_reg                              = gc_cr_l2g_error1;
    assign gc_cr_l2g_error2_reg                              = gc_cr_l2g_error2;
    assign gc_cr_l2g_error3_reg                              = gc_cr_l2g_error3;
    assign gc_cr_l2g_idleii_reg                              = gc_cr_l2g_idleii;
    //}}

    //{{ read registers & without notify flags 00
    always_comb
    begin : rreg00
        rd_val    = 'b0;
        rdata_tmp = 'b0;
        n_gc_cr_l2_cfi_operation_rdnotify                    = 1'b0;
        n_gc_cr_l2_cmd_rdnotify                              = 1'b0;

        case (addr)
            GC_CR_L2_CFI_STATUSII_ADD : begin
                rdata_tmp[15:0] = gc_cr_l2_cfi_statusii_reg[15:0];
                rd_val = rd;
            end
            GC_CR_CLK_CTRL3_ADD : begin
                rdata_tmp[15:0] = gc_cr_clk_ctrl3_reg[15:0];
                rd_val = rd;
            end
            GC_CR_CLK_STATUS3_ADD : begin
                rdata_tmp[7:0] = gc_cr_clk_status3_reg[7:0];
                rd_val = rd;
            end
            GC_CR_CU_LMS_FP32_DENORMAL_EN_ADD : begin
                rdata_tmp[0] = gc_cr_cu_lms_fp32_denormal_en_reg;
                rd_val = rd;
            end
            GC_CR_PERF_MON1_ADD : begin
                rdata_tmp[23:0] = gc_cr_perf_mon1_reg[23:0];
                rd_val = rd;
            end
            GC_CR_PERF_MON4_ADD : begin
                rdata_tmp[29:0] = gc_cr_perf_mon4_reg[29:0];
                rd_val = rd;
            end
            GC_CR_L2_CFI_OPERATION_ADD : begin
                rdata_tmp[1:0] = gc_cr_l2_cfi_operation_reg[1:0];
                rd_val = rd;
                n_gc_cr_l2_cfi_operation_rdnotify = rd;
            end
            GC_CR_L2_CFI_STATUSI_ADD : begin
                rdata_tmp[63:0] = gc_cr_l2_cfi_statusi_reg[63:0];
                rd_val = rd;
            end
            GC_CR_L2_BUFFER_MODE_ADD : begin
                rdata_tmp[1:0] = gc_cr_l2_buffer_mode_reg[1:0];
                rd_val = rd;
            end
            GC_CR_L2_PERSISTENCE_REDUCE_ADD : begin
                rdata_tmp[21:0] = gc_cr_l2_persistence_reduce_reg[21:0];
                rd_val = rd;
            end
            GC_CR_L2_CMD_ADD : begin
                rdata_tmp[1:0] = gc_cr_l2_cmd_reg[1:0];
                rd_val = rd;
                n_gc_cr_l2_cmd_rdnotify = rd;
            end
            GC_CR_L2G_IDLE_ADD : begin
                rdata_tmp[63:0] = gc_cr_l2g_idle_reg[63:0];
                rd_val = rd;
            end
            GC_CR_L2G_ERROR0_ADD : begin
                rdata_tmp[62:0] = gc_cr_l2g_error0_reg[62:0];
                rd_val = rd;
            end
            GC_CR_L2G_ERROR1_ADD : begin
                rdata_tmp[62:0] = gc_cr_l2g_error1_reg[62:0];
                rd_val = rd;
            end
            GC_CR_L2G_ERROR2_ADD : begin
                rdata_tmp[62:0] = gc_cr_l2g_error2_reg[62:0];
                rd_val = rd;
            end
            GC_CR_L2G_ERROR3_ADD : begin
                rdata_tmp[2:0] = gc_cr_l2g_error3_reg[2:0];
                rd_val = rd;
            end
            GC_CR_L2_FUNCTION_ENABLE_ADD : begin
                rdata_tmp[7:0] = gc_cr_l2_function_enable_reg[7:0];
                rd_val = rd;
            end
            GC_CR_L2_MEM_SCHED_COL_OFFSET_ADD : begin
                rdata_tmp[4:0] = gc_cr_l2_mem_sched_col_offset_reg[4:0];
                rdata_tmp[12:8] = gc_cr_l2_mem_sched_col_offset_reg[9:5];
                rdata_tmp[20:16] = gc_cr_l2_mem_sched_col_offset_reg[14:10];
                rdata_tmp[28:24] = gc_cr_l2_mem_sched_col_offset_reg[19:15];
                rdata_tmp[36:32] = gc_cr_l2_mem_sched_col_offset_reg[24:20];
                rdata_tmp[44:40] = gc_cr_l2_mem_sched_col_offset_reg[29:25];
                rdata_tmp[52:48] = gc_cr_l2_mem_sched_col_offset_reg[34:30];
                rdata_tmp[60:56] = gc_cr_l2_mem_sched_col_offset_reg[39:35];
                rd_val = rd;
            end
            GC_CR_L2_MEM_SCHED_BANK_OFFSET_ADD : begin
                rdata_tmp[4:0] = gc_cr_l2_mem_sched_bank_offset_reg[4:0];
                rdata_tmp[12:8] = gc_cr_l2_mem_sched_bank_offset_reg[9:5];
                rdata_tmp[20:16] = gc_cr_l2_mem_sched_bank_offset_reg[14:10];
                rdata_tmp[28:24] = gc_cr_l2_mem_sched_bank_offset_reg[19:15];
                rdata_tmp[36:32] = gc_cr_l2_mem_sched_bank_offset_reg[24:20];
                rd_val = rd;
            end
            GC_CR_L2_MEM_SCHED_ROW_PARTI_ADD : begin
                rdata_tmp[4:0] = gc_cr_l2_mem_sched_row_parti_reg[4:0];
                rdata_tmp[12:8] = gc_cr_l2_mem_sched_row_parti_reg[9:5];
                rdata_tmp[20:16] = gc_cr_l2_mem_sched_row_parti_reg[14:10];
                rdata_tmp[28:24] = gc_cr_l2_mem_sched_row_parti_reg[19:15];
                rdata_tmp[36:32] = gc_cr_l2_mem_sched_row_parti_reg[24:20];
                rdata_tmp[44:40] = gc_cr_l2_mem_sched_row_parti_reg[29:25];
                rdata_tmp[52:48] = gc_cr_l2_mem_sched_row_parti_reg[34:30];
                rdata_tmp[60:56] = gc_cr_l2_mem_sched_row_parti_reg[39:35];
                rd_val = rd;
            end
            GC_CR_L2_MEM_SCHED_ROW_PARTII_ADD : begin
                rdata_tmp[4:0] = gc_cr_l2_mem_sched_row_partii_reg[4:0];
                rdata_tmp[12:8] = gc_cr_l2_mem_sched_row_partii_reg[9:5];
                rdata_tmp[20:16] = gc_cr_l2_mem_sched_row_partii_reg[14:10];
                rdata_tmp[28:24] = gc_cr_l2_mem_sched_row_partii_reg[19:15];
                rdata_tmp[36:32] = gc_cr_l2_mem_sched_row_partii_reg[24:20];
                rdata_tmp[44:40] = gc_cr_l2_mem_sched_row_partii_reg[29:25];
                rdata_tmp[52:48] = gc_cr_l2_mem_sched_row_partii_reg[34:30];
                rdata_tmp[60:56] = gc_cr_l2_mem_sched_row_partii_reg[39:35];
                rd_val = rd;
            end
            GC_CR_L2_MEM_SCHED_ROW_PARTIII_ADD : begin
                rdata_tmp[4:0] = gc_cr_l2_mem_sched_row_partiii_reg[4:0];
                rdata_tmp[12:8] = gc_cr_l2_mem_sched_row_partiii_reg[9:5];
                rd_val = rd;
            end
            GC_CR_DDR_HASH_CONFIG_REG0_ADD : begin
                rdata_tmp[47:0] = gc_cr_ddr_hash_config_reg0_reg[47:0];
                rd_val = rd;
            end
            GC_CR_DDR_HASH_CONFIG_REG1_ADD : begin
                rdata_tmp[47:0] = gc_cr_ddr_hash_config_reg1_reg[47:0];
                rd_val = rd;
            end
            GC_CR_L2G_IDLEII_ADD : begin
                rdata_tmp[15:0] = gc_cr_l2g_idleii_reg[15:0];
                rd_val = rd;
            end
            GC_CR_PWR_MAN_HYSTERESIS_ADD : begin
                rdata_tmp[4:0] = gc_cr_pwr_man_hysteresis_reg[4:0];
                rd_val = rd;
            end
            GC_CR_CRM_RESET_CLK_ADD : begin
                rdata_tmp[1:0] = gc_cr_crm_reset_clk_reg[1:0];
                rd_val = rd;
            end
            GC_CR_L2G_INDIRECT_ADD : begin
                rdata_tmp[2:0] = gc_cr_l2g_indirect_reg[2:0];
                rd_val = rd;
            end
            default: begin
                rd_val    = 'b0;
                rdata_tmp = 'b0;
            end
        endcase

    end // rreg00
    //}}

    //{{ assign outputs
    assign sys_rdata  = rdata_tmp;
    assign sys_rd_val = rd_val;
    //}}

    //{{ wire up bits
    //}}

    //{{ notify flags 11
    always_comb
    begin : rreg11
        n_gc_cr_l2_cfi_operation_notify                      = 1'b0;
        n_gc_cr_l2_cmd_notify                                = 1'b0;

        case (addr)
            GC_CR_L2_CFI_OPERATION_ADD : begin
                n_gc_cr_l2_cfi_operation_notify = wr;
            end
            GC_CR_L2_CMD_ADD : begin
                n_gc_cr_l2_cmd_notify = wr;
            end
            default: begin
            end
        endcase

    end // rreg11
    //}}

    assign gc_cr_clk_ctrl3    = gc_cr_clk_ctrl3_reg;
    assign gc_cr_cu_lms_fp32_denormal_en = gc_cr_cu_lms_fp32_denormal_en_reg;
    assign gc_cr_perf_mon1    = gc_cr_perf_mon1_reg;
    assign gc_cr_perf_mon4    = gc_cr_perf_mon4_reg;
    assign gc_cr_l2_cfi_operation = gc_cr_l2_cfi_operation_reg;
    assign gc_cr_l2_buffer_mode = gc_cr_l2_buffer_mode_reg;
    assign gc_cr_l2_persistence_reduce = gc_cr_l2_persistence_reduce_reg;
    assign gc_cr_l2_cmd       = gc_cr_l2_cmd_reg;
    assign gc_cr_l2_function_enable = gc_cr_l2_function_enable_reg;
    assign gc_cr_l2_mem_sched_col_offset = gc_cr_l2_mem_sched_col_offset_reg;
    assign gc_cr_l2_mem_sched_bank_offset = gc_cr_l2_mem_sched_bank_offset_reg;
    assign gc_cr_l2_mem_sched_row_parti = gc_cr_l2_mem_sched_row_parti_reg;
    assign gc_cr_l2_mem_sched_row_partii = gc_cr_l2_mem_sched_row_partii_reg;
    assign gc_cr_l2_mem_sched_row_partiii = gc_cr_l2_mem_sched_row_partiii_reg;
    assign gc_cr_ddr_hash_config_reg0 = gc_cr_ddr_hash_config_reg0_reg;
    assign gc_cr_ddr_hash_config_reg1 = gc_cr_ddr_hash_config_reg1_reg;
    assign gc_cr_pwr_man_hysteresis = gc_cr_pwr_man_hysteresis_reg;
    assign gc_cr_crm_reset_clk = gc_cr_crm_reset_clk_reg;
    //}}

endmodule
