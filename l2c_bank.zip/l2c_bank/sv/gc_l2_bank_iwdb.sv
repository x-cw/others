// ---------------------------------------------------------------------------------
// Project Name  : IC_Design
// Author        : liusm
// Email         : liusm@innosilicon.com.cn
// Create On     : 2025/01/13 13:57
// Last Modified : 2025/08/07 16:48
// File Name     : gc_l2_bank_iwdb.sv
// Description   :
// 
// Copyright (c) 2025 Innosilicon.
// ALL RIGHTS RESERVED
// 
// ---------------------------------------------------------------------------------
// Modification History:
// Date         By              Version                 Change Description
// ---------------------------------------------------------------------------------
// 2025/01/13   liusm           1.0                     Original
// 
// ----------------------------------------------------------------------------------


module gc_l2_bank_iwdb
import gc_l2_bank_pkg::*;
import gpc_gfx_timing_buffer_pack_::*;
(
      input    logic                                  clk
,     input    logic                                  resetn

,     output   logic                                  idle

,     input    logic                                  wdc_iwdb_valid
,     output   logic                                  wdc_iwdb_ready
,     input    wdc_iwdb_cmd_record_type               wdc_iwdb_rec


,     output   logic                                  iwdb_wdc_valid
,     output   iwdb_wdc_wdata_record_type             iwdb_wdc_rec

,     input    logic                                  align_iwdb_valid
,     output   logic                                  align_iwdb_ready
,     input    align_iwdb_write_record_type           align_iwdb_rec 


,     output   logic                                  iwdb_align_free_valid
,     output   logic   [L2_IWDB_INDEX_BITS-1:0]       iwdb_align_free_index


,     input    logic                                  tst_gclkenable
);


localparam int L2_BANK_IWDB_WIDTH = L2_AXI_BUS_WIDTH+L2_AXI_BUS_WIDTH/16; // data + strb + atomic 

logic                                     iwdb_wdc_tbuff_out_valid  ;
logic                                     iwdb_wdc_tbuff_out_atomic ;
logic [L2_BANK_IWDB_WIDTH-1:0]            iwdb_wdc_tbuff_out_data   ;
logic [L2_IWDB_DEPTH-1:0]                 iwdb_index_used_mask      ;
logic                                     request_stage1_valid      ;
logic                                     request_stage1_ready      ;
wdc_iwdb_cmd_record_type                  request_stage1_rec        ;
logic [L2_BANK_IWDB_WIDTH-1:0]            request_stage1_data       ;

logic                                     cena                      ;
logic [L2_IWDB_INDEX_BITS-1:0]            aa                        ;
logic [L2_BANK_IWDB_WIDTH-1:0]            qa                        ;

logic                                     cenb                      ;
logic                                     wenb                      ;
logic [L2_IWDB_INDEX_BITS-1:0]            ab                        ;
logic [L2_BANK_IWDB_WIDTH-1:0]            db                        ;

assign align_iwdb_ready = 1'b1;


always_ff@(posedge clk or negedge resetn) begin
   if (!resetn) begin
      iwdb_index_used_mask <= '0;
   end
   else begin 
      if (align_iwdb_valid) begin
         iwdb_index_used_mask[align_iwdb_rec.iwdb_index] <= 1'b1;
      end
      if (request_stage1_valid && request_stage1_ready ) begin
         iwdb_index_used_mask[request_stage1_rec.iwdb_index] <= 1'b0;
      end
   end
end



assign cenb = ! align_iwdb_valid;
assign wenb = ! align_iwdb_valid;
assign ab   = align_iwdb_rec.iwdb_index;
assign db   = {align_iwdb_rec.data, align_iwdb_rec.strb};


assign cena = !(wdc_iwdb_valid && wdc_iwdb_ready);
assign aa   = wdc_iwdb_rec.iwdb_index;

generate
   if (L2_IWDB_DEPTH > 16) begin: g_macro
      gpu_core_mss_gfx_dpstore
         #(
             .w     ( L2_BANK_IWDB_WIDTH     ) ,
             .p     ( L2_BANK_IWDB_WIDTH     ) ,
             .d     ( L2_IWDB_DEPTH          ) ,
             .log2d ( L2_IWDB_INDEX_BITS     ) ,
             .id    ( 30007                  )
                                             )
      i_iwdb_dpsram     (
          .CLKA     ( clk                    )
         ,.CENA     ( cena                   )
         ,.AA       ( aa                     )
         ,.QA       ( qa                     )
         ,.CLKB     ( clk                    )
         ,.CENB     ( cenb                   )
         ,.WENB     ( wenb                   )
         ,.AB       ( ab                     )
         ,.DB       ( db                     )
         ,.TE       ( tst_gclkenable         )
         ,.L2M      (                        )
         ,.SRAM     (                        )
                                          ) ;
   end
   if (L2_IWDB_DEPTH <= 16) begin: g_flops
      logic [L2_IWDB_DEPTH-1:0] [L2_BANK_IWDB_WIDTH-1:0] pending_iwdb_data;
      logic [L2_IWDB_INDEX_BITS-1:0] pending_aa;

      for (genvar IWDB_INDEX = 0; IWDB_INDEX< L2_IWDB_DEPTH; IWDB_INDEX++) begin
         always_ff@(posedge clk) begin
            if (!cenb && !wenb && ab == IWDB_INDEX) begin
               pending_iwdb_data[IWDB_INDEX] <= db;
            end
         end
      end
       
      always_ff@(posedge clk or negedge resetn) begin
         if (!resetn) begin
            pending_aa <= '0;
         end
         else if (!cena) begin
            pending_aa <= aa;
         end
      end
      assign qa = pending_iwdb_data[pending_aa];
      // always_ff@(posedge clk) begin
      //    if (!cena ) begin
      //       qa <= pending_iwdb_data[aa];
      //    end
      // end
   end 
endgenerate
                                          


assign wdc_iwdb_ready = (wdc_iwdb_valid && iwdb_index_used_mask[wdc_iwdb_rec.iwdb_index]) ? request_stage1_ready : 1'b0;

always_ff@(posedge clk or negedge resetn) begin
   if (!resetn) begin
      request_stage1_valid <= 1'b0;
      request_stage1_rec <= '0;
   end
   else if (wdc_iwdb_valid && wdc_iwdb_ready) begin
      request_stage1_valid <= 1'b1;
      request_stage1_rec <= wdc_iwdb_rec;
   end
   else if (request_stage1_valid && request_stage1_ready) begin
      request_stage1_valid <= 1'b0;
   end
end
assign request_stage1_data = qa;
assign request_stage1_ready = 1'b1;



gpc_gfx_timing_buffer_vonly_
#(
   .BUFFER_TYPE   ( GPC_GFX_TIMING_BUFFER_PIPE_REG                       )
  ,.WIDTH         ( L2_BANK_IWDB_WIDTH + 1                               ) )
i_iwdb_wdc_data   (
 .clk             ( clk                                                  )
,.resetn          ( resetn                                               )

,.tbuff_in_valid  ( request_stage1_valid                                 )
,.tbuff_in_data   ( {request_stage1_data, request_stage1_rec.atomic}     )

,.tbuff_out_valid ( iwdb_wdc_tbuff_out_valid                             )
,.tbuff_out_data  ( {iwdb_wdc_tbuff_out_data, iwdb_wdc_tbuff_out_atomic} ) );

assign  iwdb_wdc_valid     = iwdb_wdc_tbuff_out_valid;
assign  iwdb_wdc_rec       = f_wd_decompress(iwdb_wdc_tbuff_out_data[L2_BEAT_WIDTH/16+:L2_BEAT_WIDTH], iwdb_wdc_tbuff_out_data[L2_BEAT_WIDTH/16-1:0], iwdb_wdc_tbuff_out_atomic);

assign idle = ~request_stage1_valid && ~iwdb_wdc_tbuff_out_valid;
                                       
assign iwdb_align_free_valid = request_stage1_valid;
assign iwdb_align_free_index = request_stage1_rec.iwdb_index;





















endmodule
// Local Variables:
// verilog-library-directories:("./" ) 
// End:
