
####################group operation########################
###########################################################
viaSetupL1Apps


## initial
npiDlSym -func via_hm_init -dir HM_GROUP_DIR
#npiDlSym -func via_hm_init -shared



## group operation
npiDlSym -func via_hm_group -target_scope {top} -target_inst {sub_b_inst} {sub_c_inst} -group_mod {sub_bc_top_wrap} -group_inst {sub_bc_top_wrap_inst} -group_mod_file {sub_bc_top_wrap.v}

## compare
#set work_dir_path [pwd]
#npiDlSym -func via_hm_diff {./rtl/top.v} {./HM_GROUP_DIR/$work_dir_path/rtl/top.v}


## Export designs
npiDlSym -func via_hm_export 

#debExit

###########################################################
###########################################################
