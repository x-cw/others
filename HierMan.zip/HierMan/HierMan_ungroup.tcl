

#####################ungroup operation#####################
###########################################################
viaSetupL1Apps

## initial
npiDlSym -func via_hm_init -dir HM_UNGROUP_DIR
#npiDlSym -func via_hm_init -shared

## ungroup operation
npiDlSym -func via_hm_ungroup -inst {top.sub_a_inst} -delimiter {_}



## Export designs
npiDlSym -func via_hm_export 

#debExit
###########################################################
###########################################################
