
####################uniquify operation#####################
###########################################################
viaSetupL1Apps

## initial
npiDlSym -func via_hm_init -dir HM_UNIQUIFY_DIR
#npiDlSym -func via_hm_init -shared

## uniquify operation
npiDlSym -func via_hm_uniquify -inst {top.sub_a_inst.pmu_inst} 



## Export designs
npiDlSym -func via_hm_export 

#debExit
###########################################################
###########################################################
