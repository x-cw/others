echo "start"
######################operation#####################
###########################################################
#viaSetupL1Apps
#file mkdir ./signal_temp

set mod_hdl [npi_handle_by_name -name "top.sub_a_inst" -scope ""]
echo "mod_hdl : $mod_hdl"

if { $mod_hdl != ""} {
  set mod_full_name [npi_get_str -property npiFullName -object $mod_hdl]
  echo "mod_full_name : $mod_full_name"

  set mod_name [npi_get_str -property npiName -object $mod_hdl]
  echo "mod_name : $mod_name"
  
  set scope [npi_handle -type npiScope -refHandle $mod_hdl]
  echo "scope : $scope"
  

  set sub_mod_it [npi_iterate -type npiInternalScope -refHandle $mod_hdl]
  echo "sub_mod_it : $sub_mod_it"

  set i  0
  while { [set sub_mod_hdl [npi_scan -iterator $sub_mod_it]] != "" } {
      echo "sub_mod_hdl $i : $sub_mod_hdl"

      set sub_mod_name [npi_get_str -property npiName -object $sub_mod_hdl]
      echo "sub_mod_name $i : $sub_mod_name"

      set i [expr $i + 1]
  }

  set port_it [npi_iterate -type npiPort -refHandle $mod_hdl]
  echo "port_it : $port_it"

  set port_hdl [npi_scan -iterator $port_it]
  echo "port_hdl : $port_hdl"


  set i  0
  while { [set port_hdl [npi_scan -iterator $port_it]] != "" } {
    echo "port_hdl $i : $port_hdl"

    set port_size [npi_get -property npiSize -object $port_hdl]
    echo "port_size : $port_size"

    set port_name [npi_get_str -property npiName -object $port_hdl]
    echo "port_name : $port_name"

    set port_dir [npi_get_str -property npiDirection -object $port_hdl]
    echo "port_dir : $port_dir"

    set i [expr $i + 1]


    npi_release_handle -object $port_hdl
  }
    
    echo "port number : $i"

} else {
  echo "Error: mod_hdl is empty"
} 






#debExit
###########################################################
###########################################################


echo "end"
