
######################rename operation#####################
###########################################################
viaSetupL1Apps

file mkdir ./signal_temp
#exec cat "" > ./signal_temp/signal_pm.list


## rename operation
echo "start"
#npiImport -f ./rtl/top.f

#npiSrcFind [-delim delim] [-signal|-inst] [-case on|off] [-fullHierarchy on|off] [-libCell on|off] name -output outFileNamep

npiSrcFind -signal top.sub_a_inst.pmu_inst.* -output ./signal_temp/signal.list



set signal_list "
ctrl_pm_sub_a_off
ctrl_pm_sub_b_off
ctrl_pm_sub_c_off
"
foreach signal $signal_list {
  npiSrcFind -signal top.sub_a_inst.pmu_inst.$signal  -output ./signal_temp/${signal}_signal.list
  exec cat ./signal_temp/${signal}_signal.list >> ./signal_temp/signal_pm.list

}

#npiSrcTraceConnectivity [-delim delim] [-r][-range start end] signalName -output outFileName
npiSrcTraceConnectivity "top.sub_a_inst.pmu_inst.ctrl_on" -output ./signal_temp/drvLoad.list

#npiSrcTraceFanIn -src -sch signalName -output outFileName




#set instHDL [npi_dm_handle_by_name -name top.sub_a_inst.pmu_inst -scope ""]
#echo $instHDL



echo "end"





## Export designs
#npiDlSym -func via_hm_export 

#debExit
###########################################################
###########################################################
