
########################move operation#####################
###########################################################
viaSetupL1Apps

## initial
npiDlSym -func via_hm_init -dir HM_MOVE_DIR
#npiDlSym -func via_hm_init -shared

## move operation
npiDlSym -func via_hm_move -from {top.sub_b_inst} -to {top.sub_a_inst}


## Export designs
npiDlSym -func via_hm_export 

#debExit
###########################################################
###########################################################
