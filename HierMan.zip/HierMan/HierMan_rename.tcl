
######################rename operation#####################
###########################################################
viaSetupL1Apps

## initial
npiDlSym -func via_hm_init -dir HM_RENAME_DIR
#npiDlSym -func via_hm_init -shared

## rename operation
npiDlSym -func via_hm_rename -inst {top.sub_a_inst.pmu_inst} -name {pmu_u0} 



## Export designs
npiDlSym -func via_hm_export 

#debExit
###########################################################
###########################################################
