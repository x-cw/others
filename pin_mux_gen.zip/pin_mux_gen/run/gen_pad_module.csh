#!/bin/user/csh
set pads = ( \
PADS_RESETN \
PADS_MODE_SEL0 \
PADS_MODE_SEL1 \
PADS_MODE_SEL2 \
PADS_SECURE_BOOT \
PADS_GPUID_0 \
PADS_GPUID_1 \
PADS_GPUID_2 \
PADS_CLKREQ0_N \
PADS_FLASH_CS \
PADS_FLASH_HOLD \
PADS_FLASH_WP \
PADS_FLASH_MISO \
PADS_FLASH_MOSI \
PADS_FLASH_CLK \
PADS_PWM_FAN \
PADS_PWM_VID \
PADS_PM0_SDA \
PADS_PM0_SCL \
PADS_PM0_CTRL \
PADS_PM0_ALERT \
PADS_PM1_SDA \
PADS_PM1_SCL \
PADS_PM1_CTRL \
PADS_PM1_ALERT \
PADS_PM2_SDA \
PADS_PM2_SCL \
PADS_PM3_SDA \
PADS_PM3_SCL \
PADS_PM4_SDA \
PADS_PM4_SCL \
PADS_SCRAMBLE_EN \
PADS_EC_ADDR_HBIT \
PADS_EC_SCL \
PADS_EC_SDA \
PADS_UART0_RX \
PADS_UART0_TX \
PADS_UART1_RX \
PADS_UART1_TX \
PADS_GPIO1 \
PADS_GPIO2 \
PADS_GPIO3 \
PADS_GPIO4 \
PADS_GPIO5 \
PADS_GPIO6 \
PADS_GPIO7 \
PADS_GPIO8 \
PADS_GPIO9 \
PADS_GPIO10 \
PADS_GPIO11 \
PADS_GPIO12 \
PADS_GPIO13 \
PADS_GPIO14 \
PADS_GPIO15 \
PADS_GPIO16 \
PADS_CPU_JTAG_TCLK \
PADS_CPU_JTAG_TMS \
PADS_CPU_JTAG_TDI \
PADS_CPU_JTAG_TDO \
PADS_CPU_JTAG_RSTN \
PADS_CS_JTAG_TCLK \
PADS_CS_JTAG_TMS \
PADS_CS_JTAG_TDI \
PADS_CS_JTAG_TDO \
PADS_CS_JTAG_RSTN \
);

    echo "//begin pads reg input" > input_temp.txt
    echo "input dft_mbist_mode;" >> input_temp.txt
    echo "input dft_scan_mode;\n\n" >> input_temp.txt
    echo "output gp3_pad_lsbias;" >> input_temp.txt
    echo "output gp3_pad_rtn;" >> input_temp.txt
    echo "output gp3_pad_sps;\n\n" >> input_temp.txt
    #    echo 'output			VREFN;' >> input_temp.txt
    #    echo 'output			VREFP;' >> input_temp.txt
    #    echo 'output			VSW;' >> input_temp.txt

    echo "\n\n//begin poctie wire " > wire_temp.txt
    echo '`ifndef PAD_SYNTHSIS ' >> wire_temp.txt
    echo "assign gp3_pad_lsbias = 1'b1;" >> wire_temp.txt
    echo "assign gp3_pad_rtn = 1'b1;" >> wire_temp.txt
    echo "assign gp3_pad_sps = 1'b1;" >> wire_temp.txt
    #    echo "assign VREFN = 1'b1;" >> wire_temp.txt
    #    echo "assign VREFP =1'b1;" >> wire_temp.txt
    #    echo "assign VSW = 1'b1;" >> wire_temp.txt
    echo '`endif  \n\n' >> wire_temp.txt

    echo '`ifdef PAD_SYNTHSIS \ndont_touch_block_pads dont_touch_block_pads_inst0 (.gp3_pad_lsbias(gp3_pad_lsbias), .gp3_pad_rtn(gp3_pad_rtn), .gp3_pad_sps(gp3_pad_sps) );\n//dont_touch_block_pads dont_touch_block_pads_inst1 (.gp3_pad_lsbias(VREFN), .gp3_pad_rtn(VREFP), .gp3_pad_sps(VSW) );\n\n`endif \n\n' >> wire_temp.txt  



    echo "//begin pads reg temp wire " >> wire_temp.txt
    echo "//begin pads reg dft assign for dft demands for maximum strength " > dft_temp.txt

    echo '\n\n/*PBNT_12_H auto_template "\(.*\)_inst"(\n .RTN(gp3_pad_rtn), \n .SPS(gp3_pad_sps), \n .LSBIAS(gp3_pad_lsbias),\n .PO      (),\n .Y       (@_i),\n .A       (@_o),\n .DS     ({@_ds1_tmp,@_ds0_tmp}),\n .IE      (1'\''b1),\n .IS      (@_is_tmp),\n .OE      (@_oe),\n .PE      (@_pe_tmp),\n .POE     (@_poe_tmp),\n .PS      (@_ps_tmp), \n  .VREFN      (VREFN),//autonohookup \n   .VREFP      (VREFP),//autonohookup \n    .VSW      (VSW),//autonohookup \n );*/' > autogen_temp.txt

foreach pad ($pads)
    echo "processing $pad"
    set pad_lower = `echo $pad | tr '[:upper:]' '[:lower:]'`
    echo $pad_lower
    
#=======================================================
#                       input
##=====================================================
    echo "input wire ${pad_lower}_ds0;" >> input_temp.txt
    echo "input wire ${pad_lower}_ds1;" >> input_temp.txt
    #echo "input wire ${pad_lower}_ds2;" >> input_temp.txt
    echo "input wire ${pad_lower}_ps;" >> input_temp.txt
    echo "input wire ${pad_lower}_pe;" >> input_temp.txt
    echo "input wire ${pad_lower}_ie;" >> input_temp.txt
    echo "input wire ${pad_lower}_is;" >> input_temp.txt
    echo "input wire ${pad_lower}_poe;" >> input_temp.txt
#=======================================================
#                       wire
##=====================================================
    echo "wire ${pad_lower}_ds0_tmp;" >> wire_temp.txt
    echo "wire ${pad_lower}_ds1_tmp;" >> wire_temp.txt
    #echo "wire ${pad_lower}_ds2_tmp;" >> wire_temp.txt
    echo "wire ${pad_lower}_ps_tmp;" >> wire_temp.txt
    echo "wire ${pad_lower}_pe_tmp;" >> wire_temp.txt
    echo "wire ${pad_lower}_ie_tmp;" >> wire_temp.txt
    echo "wire ${pad_lower}_is_tmp;" >> wire_temp.txt
    echo "wire ${pad_lower}_poe_tmp;" >> wire_temp.txt
#=======================================================
#                       dft_assign
##=====================================================
    echo "\n//for $pad" >> dft_temp.txt
    echo "assign ${pad_lower}_ds0_tmp = (dft_mbist_mode || dft_scan_mode) ? 1'b1: ${pad_lower}_ds0;" >> dft_temp.txt
    echo "assign ${pad_lower}_ds1_tmp = (dft_mbist_mode || dft_scan_mode) ? 1'b1: ${pad_lower}_ds1;" >> dft_temp.txt
    #echo "assign ${pad_lower}_ds2_tmp = (dft_mbist_mode || dft_scan_mode) ? 1'b0: ${pad_lower}_ds2;" >> dft_temp.txt
    echo "assign ${pad_lower}_ps_tmp  = (dft_mbist_mode || dft_scan_mode) ? 1'b0: ${pad_lower}_ps;" >> dft_temp.txt
    echo "assign ${pad_lower}_pe_tmp  = (dft_mbist_mode || dft_scan_mode) ? 1'b0: ${pad_lower}_pe;" >> dft_temp.txt
    echo "assign ${pad_lower}_ie_tmp  = (dft_mbist_mode || dft_scan_mode) ? 1'b1: ${pad_lower}_ie;" >> dft_temp.txt
    echo "assign ${pad_lower}_is_tmp  = (dft_mbist_mode || dft_scan_mode) ? 1'b0: ${pad_lower}_is;" >> dft_temp.txt
    echo "assign ${pad_lower}_poe_tmp = (dft_mbist_mode || dft_scan_mode) ? 1'b0: ${pad_lower}_poe;" >> dft_temp.txt

#=======================================================
#                       auto gen
##=====================================================
    if (`echo $pad | grep -c "PADS_SECURE_BOOT"` > 0) then
    echo '\n\n/*PBNT_12_H auto_template "\(.*\)_inst"(\n .RTN(gp3_pad_rtn), \n .SPS(gp3_pad_sps), \n .LSBIAS(gp3_pad_lsbias),\n .PO      (),\n .Y       (@_i),\n .A       (@_o),\n .DS     ({@_ds1_tmp,@_ds0_tmp}),\n .IE      (@_ie_tmp),\n .IS      (@_is_tmp),\n .OE      (@_oe),\n .PE      (@_pe_tmp),\n .POE     (@_poe_tmp),\n .PS      (@_ps_tmp), \n  .VREFN      (VREFN),//autonohookup \n   .VREFP      (VREFP),//autonohookup \n    .VSW      (VSW),//autonohookup \n  );*/' >> autogen_temp.txt
    endif

    if (`echo $pad | grep -c "PADS_SCRAMBLE_EN"` > 0) then
    echo '\n\n/*PBNT_12_H auto_template "\(.*\)_inst"(\n .RTN(gp3_pad_rtn), \n .SPS(gp3_pad_sps), \n .LSBIAS(gp3_pad_lsbias),\n .PO      (),\n .Y       (@_i),\n .A       (@_o),\n .DS     ({@_ds1_tmp,@_ds0_tmp}),\n .IE      (@_ie_tmp),\n .IS      (@_is_tmp),\n .OE      (@_oe),\n .PE      (@_pe_tmp),\n .POE     (@_poe_tmp),\n .PS      (@_ps_tmp), \n  .VREFN      (VREFN),//autonohookup \n   .VREFP      (VREFP),//autonohookup \n    .VSW      (VSW),//autonohookup \n  );*/' >> autogen_temp.txt
    endif

    echo "\n\nPBNT_12_H ${pad_lower}_inst (\n                   // Inouts\n                   .PAD    ($pad),\n                   /*autoinst*/);\n" >> autogen_temp.txt
end



#gen general pad

#echo "\n\n/*POCTIE_18_H auto_template (\n .RTN(gp3_pad_rtn), \n .SPS(gp3_pad_sps), \n .LSBIAS(gp3_pad_lsbias),\n);*/" >>autogen_temp.txt
#echo "POCTIE_18_H GP3_PAD_POCTIE(/*autoinst*/);" >>autogen_temp.txt
#echo "\n\n/*POCTIE_18_H auto_template (\n .RTN(gp3_pad_rtn1), \n .SPS(gp3_pad_sps1), \n .LSBIAS(gp3_pad_lsbias1),\n);*/" >>autogen_temp.txt
#echo "POCTIE_18_H GP3_PAD_POCTIE1(/*autoinst*/);" >>autogen_temp.txt

#gen pad module
    set file = "gp3_pad"
    set file_name = "gp3_pad.v"
    echo "module $file (" > $file_name
    echo "/*autoarg*/" >> $file_name
    echo ");" >> $file_name
    echo "/*autoinput*/" >> $file_name
    echo "/*autooutput*/" >> $file_name
    echo '/*autoinout(".*GPIO.*")*/' >> $file_name
    echo '/*autoinout(".*PM.*\|.*PWM.*")*/' >> $file_name
    echo '/*autoinout(".*\(FLASH\|QSPI\|SCRAMBLE\|EC\|UART\).*")*/' >> $file_name
    echo '/*autoinout(".*\(MODE\|RESETN\|REMOTE\|CHIP\|CLKREQ\|BOOT\).*")*/' >> $file_name
    echo '/*autoinout*/' >> $file_name
    echo "/*autowire*/" >> $file_name

    cat input_temp.txt wire_temp.txt dft_temp.txt autogen_temp.txt > all_temp.txt
    sed -i "/autowire/r all_temp.txt" $file_name
    echo '\n\nendmodule\n//local variables:\n// verilog-library-directories:("./")\n// verilog-library-flags:("/Foundry/ARM/samsung_4lpp/Standard_IO/samsung/ln04lpp_gpio_lib_1p2v_V1.24_pkg/FE-Common/FE-Common_sec250704_0016/MODEL/ln04lpp_gpio_lib_t12.v")\n//verilog-auto-tieoff-declaration:"assign"\n//end:' >> $file_name

    emacs -batch -l ~/.vim/elisp/verilog-mode.el $file_name -f verilog-batch-auto

    rm *_temp.txt
    cp gp3_pad.v $GP3_RTL/scp/rtl/pin_mux

     
