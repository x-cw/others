#!/usr/bin/python
# -*- coding: UTF-8 -*- 

from ivl2verilog import gen_module_list

__DESCRIPTION__ = '''
=====================================
# IVL - Improved VerilogHDL Language #
=====================================
//                                                                          
//  ivl_parse.py - IVL parser.                              
//                                      
//                                                                          
//  This library is free software; you can redistribute it and/or           
//  modify it under the terms of the GNU Lesser General Public              
//  License as published by the Free Software Foundation; either            
//  version 2.1 of the License, or (at your option) any later version.      
//                                                                          
//  This library is distributed in the hope that it will be useful,         
//  but WITHOUT ANY WARRANTY; without even the implied warranty of          
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU       
//  Lesser General Public License for more details.                         
//                                                                          
//  Full details of the license can be found in the file LGPL.TXT.          
//                                                                          
//  You should have received a copy of the GNU Lesser General Public        
//  License along with this library; if not, write to the Free Software     
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
//                                                                          
'''


#++++++++++++++++++++++++++++++++++++++++++++++++
#++++++++++++++++++++++++++++++++++++++++++++++++ 
   
def ivl_parse (ivl_file) :

    #read out all lines in the ivl files, and store them into a list.
    #then close the ivl file.
    with open(ivl_file, 'r') as f:
        IvlLines = f.readlines()
    
    
    #Create a Veriloog file with the module name( same as IVL file name). 
    module_name = ivl_file.split('.', 1)[0] 
    VerFile = open(module_name + '.v', 'w')
        
    #parse ivl file.
    line_num = 0
    while (line_num < len(IvlLines) ) : #parse statement till to the end of IVL file. 
        line_num, ModuleList = gen_module_list(line_num, IvlLines)
        VerFile.writelines(ModuleList)
    VerFile.close() #close Verilog file.
        
    return module_name        
    
#++++++++++++++++++++++++++++++++++++++++++++++++
#++++++++++++++++++++++++++++++++++++++++++++++++ 
               

 
if __name__ == '__main__' :

    import argparse
    
    parser = argparse.ArgumentParser(description='python argparse cookbook')
    parser.add_argument('ivl',  help="ivl file to be parsed")
    parser.add_argument('-f', '--file_list', help="ivl file list to be parsed")
    args = parser.parse_args()
    
       
    ivl_file = args.ivl
    
    module_name = ivl_parse (ivl_file) 
    print ("A verilog module [%s] is generated!"%(module_name))
        
            
