#!/usr/bin/python
# -*- coding: UTF-8 -*- 
    
import re
import xlrd

from ivlconst import *
from reg_table_parse import * #read_a_reg_table, gen_a_reg_code, search_in_sheet
from datetime import datetime

__DESCRIPTION__ = '''
=====================================
# IVL - Improved VerilogHDL Language #
=====================================
//                                                                          
//  reg_table_parse.py - python code for parsing excel table.                              
//                                      
//                                                                          
//  This library is free software; you can redistribute it and/or           
//  modify it under the terms of the GNU Lesser General Public              
//  License as published by the Free Software Foundation; either            
//  version 2.1 of the License, or (at your option) any later version.      
//                                                                          
//  This library is distributed in the hope that it will be useful,         
//  but WITHOUT ANY WARRANTY; without even the implied warranty of          
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU       
//  Lesser General Public License for more details.                         
//                                                                          
//  Full details of the license can be found in the file LGPL.TXT.          
//                                                                          
//  You should have received a copy of the GNU Lesser General Public        
//  License along with this library; if not, write to the Free Software     
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
//                                                                          
'''

version_number = "ver0.2"

def reg_module_gen (excel_file) :
    
    port_signal_list  = [] 
    port_def_list     = []
    signal_def_list   = []
    write_init_list   = []
    write_assign_list = []
    reg_struct_list   = []
    read_assign_list  = []
    pulse_init_list   = []  
    pulse_assign_list = [] 
    pulse_cross_list  = []
    input_sync_list   = []
    def_addr_list     = []
    write_dtouch_list = []
    inter_reg_list    = []
    pads_default_in_list = []
    pads_default_oe_list = []
    pads_default_out_list = []
    pads_default_in_alist = []
    pads_default_oe_alist = []
    pads_default_out_alist = []
        
    #open a excel file
    data = xlrd.open_workbook(excel_file)   
    sheet = data.sheet_by_index(1)
    module_name = data.sheet_names()[1]
    #========================================
    # Extract configuration information
    #========================================
    
    maininfo_sheet = data.sheet_by_index(0)
    
    # If set, function description will be used as comments
    # following the signal definition.
    flag, row, col = search_in_sheet(maininfo_sheet, 0, 0, 'REG COMMENTS')
    if (flag) :
        comment_sel = maininfo_sheet.cell(row, col+1).value
    else :
        comment_sel = 0 


    # read out author and date
    flag, row, col = search_in_sheet(maininfo_sheet, 0, 0, 'AUTHOR')
    if (flag) :
        author_name = maininfo_sheet.cell(row, col+1).value
    else :
        author_name = ' ' 
        
    flag, row, col = search_in_sheet(maininfo_sheet, 0, 0, 'DATE')
     
    if (flag) :
        date_list = list(xlrd.xldate_as_tuple(maininfo_sheet.cell(row, col+1).value,0)[0:3])
        date_flag = repr(date_list[0]) + "-" + repr(date_list[1])+ "-" + repr(date_list[2])
    else :
        date_flag = ' ' 
    
    
    # If set, a file header will be added into output verilog file.
    flag, row, col = search_in_sheet(maininfo_sheet, 0, 0, 'FILE HEADER')
    if (flag) :
        add_fileheader = maininfo_sheet.cell(row, col+1).value
    else :
        add_fileheader = 0
    if (add_fileheader) :
        print('###module=',module_name,'; author_name=',author_name,'; date_flag =',date_flag);
        header_string = data.sheet_by_name("fileheader").cell(0,0).value % (module_name, author_name, date_flag) + "\n" 
    else :
        header_string = "\n"    
        
    
    # Read out the global parameter of offset address width.
    flag, row, col = search_in_sheet(maininfo_sheet, 0, 0, 'DIG PAD NUM')
    if (flag) :
        dig_pad_num = repr(int(maininfo_sheet.cell(row, col+1).value))
    else :
        dig_pad_num = '40'
    
    # Read out the global parameter of offset address width.
    flag, row, col = search_in_sheet(maininfo_sheet, 0, 0, 'SCAN IN LEN')
    if (flag) :
        scan_in_len = repr(int(maininfo_sheet.cell(row, col+1).value))
    else :
        scan_in_len = '16'

    # Read out the global parameter of offset address width.
    flag, row, col = search_in_sheet(maininfo_sheet, 0, 0, 'SCAN OUT LEN')
    if (flag) :
        scan_out_len = repr(int(maininfo_sheet.cell(row, col+1).value))
    else :
        scan_out_len = '16'
    
    # Read out the global parameter of offset address width.
    flag, row, col = search_in_sheet(maininfo_sheet, 0, 0, 'SCAN GROUP NUM')
    if (flag) :
        scan_grp_sel = repr(int(maininfo_sheet.cell(row, col+1).value))
    else :
        scan_grp_sel = '16'
    
    # Read out the global parameter of offset address width.
    flag, row, col = search_in_sheet(maininfo_sheet, 0, 0, 'ACTIVE OUTPUT ENABLE')
    if (flag) :
        active_oe = repr(int(maininfo_sheet.cell(row, col+1).value))
    else :
        active_oe = '1'
    
    
    #=====================================   
    #read out all register table and parse them.
    #=====================================   
    col = 0
    pads_oe_list = []
    pads_out_list = []
    pads_in_list = []
    pads_oe_alist = []
    pads_out_alist = []
    pads_in_alist = []
    inout_pname_alist = []

    reg_code_list_port = []
    #print('The Register size:', sheet.ncols, sheet.nrows)
    reg_dict_list_input = []
    reg_dict_list_output = []
    reg_dict_list_oe = []
    reg_dict_list_dname = []
    reg_dict_list_direction = []
    reg_dict_list_pname = []
    top_port_list = []
    top_port = []
    top_port_tmp = []
    top_port_sort = []
    dont_touch = []
    ass_pads = []
    input_sig_name = []
    output_sig_name = []
    direction_sig_name = []
    pads_in = []
    pads_out = []
    pads_oe = []
    assign_pads_in = []
    assign_pads_out = []
    assign_pads_oe = []
    ass_pads_in = []
    ass_pads_out = []
    ass_pads_oe = []
    scan_comb_init_list = []
    scan_seq_init_list = []
    scan_comb_list = []
    scan_seq_list = []
    inout_pname_list = []
    scan_port_list = []
    scan_reg_def_list = []
    reg_def_list = []
    wire_name_list = []
    wire_name_alist = []
    input_name_init = []
    input_name_init_alist = []
    name_init_tmp = []
    name_init = []
    scan_seq_init_str = []
    scan_seq_str = []
    scan_reg_def_str = []

    while (col < sheet.ncols) : 
      print('The list:', col, sheet.cell_type(0,col), sheet.cell(0,col))
      if(sheet.cell_type(0,col) == 1) :
        if(sheet.cell(0,col).value.strip()== 'TOP_PADS'):
          lastrow, reg_dict_list_input, reg_dict_list_output, reg_dict_list_oe = read_top_table(sheet, col, sheet.cell(0,col).value.strip())

          for i in range(0, len(reg_dict_list_input)): #process data row by row
            input_sig_name.append(reg_dict_list_input[i])
            output_sig_name.append( reg_dict_list_output[i])
            direction_sig_name.append(reg_dict_list_oe[i])
          print('assign oe:',direction_sig_name, 'ass o:',output_sig_name, 'ass in:', input_sig_name)
          for i in range(1, len(input_sig_name)): #process data row by row
            pads_in.append('input'  + INDENT_SP + input_sig_name[i] + ';\n')
            pads_out.append('output'  + INDENT_SP + output_sig_name[i] + ';\n')
            pads_oe.append('output'  + INDENT_SP + direction_sig_name[i] + ';\n')
            if(i < len(input_sig_name) - 1):
                assign_pads_in.append(INDENT_SP*2 +  input_sig_name[i] + ',\n')
                assign_pads_out.append(INDENT_SP*2 +  output_sig_name[i] + ',\n')
                assign_pads_oe.append(INDENT_SP*2 +  direction_sig_name[i] + ',\n')
            else:
                assign_pads_in.append(INDENT_SP*2 +  input_sig_name[i] + '\n')
                assign_pads_out.append(INDENT_SP*2 + output_sig_name[i] + '\n')
                assign_pads_oe.append(INDENT_SP*2 +  direction_sig_name[i] + '\n')

          i_asssig = "".join(assign_pads_in)
          o_asssig = "".join(assign_pads_out)
          oe_assig = "".join(assign_pads_oe)
          pads_in_str = "".join(pads_in)
          pads_out_str = "".join(pads_out)
          pads_oe_str = "".join(pads_oe)
          top_port.append(pads_in_str)
          top_port.append(pads_out_str)
          top_port.append(pads_oe_str)
          ass_pads.append ( '\n assign { \n' + oe_assig + '} = pads_oe;\n ') 
          ass_pads.append ( '\n assign { \n' + o_asssig + '} = pads_o;\n ') 
          ass_pads.append ('\nassign pads_i = { \n' + i_asssig + '};\n') 	

        else:
          lastrow, reg_dict_list_input, reg_dict_list_output, reg_dict_list_dname, reg_dict_list_direction = read_a_reg_table(sheet, col, sheet.cell(0,col).value.strip())
    
          if (reg_dict_list_input != []) :   
            pads_oe_list, pads_out_list, pads_in_list, inout_pname_list, wire_name_list, pads_default_oe_list, pads_default_out_list, pads_default_in_list, input_name_init = gen_a_reg_code(reg_dict_list_input, reg_dict_list_output, reg_dict_list_dname, reg_dict_list_direction, active_oe, sheet.cell(0,col).value.strip())
        #print('ass oe:',ass_pads)

      if(pads_oe_list != []):
        pads_oe_alist.append(pads_oe_list)
      if(pads_out_list != []):
        pads_out_alist.append(pads_out_list)
      if(pads_in_list != []):
        pads_in_alist.append(pads_in_list)
      if(inout_pname_list != []):
        inout_pname_alist.append(inout_pname_list)
      if(wire_name_list != []):
        wire_name_alist.append(wire_name_list)
      if(pads_default_oe_list != []):
        pads_default_oe_alist.append(pads_default_oe_list)
      if(pads_default_out_list != []):
        pads_default_out_alist.append(pads_default_out_list)
      if(pads_default_in_list != []):
        pads_default_in_alist.append(pads_default_in_list)
      if(input_name_init != []):
        for item in input_name_init:
          item_str = "".join(item)
          if item_str not in input_name_init_alist:
            input_name_init_alist.append(item_str)
        print('alist:',pads_out_list)

        #input_name_init_alist.append(input_name_init)
        
      pads_oe_list = []
      pads_out_list = []
      pads_in_list = []
      inout_pname_list = []
      wire_name_list = []
      pads_default_oe_list = []
      pads_default_out_list = []
      pads_default_in_list = []
      input_name_init = []
      col += 1  #next row for search
      #port_signal_list.append(inout_pname_alist)
      #for i in range(0,len(inout_pname_alist)):
        #print('top_port_list:',inout_pname_alist[i])
        #top_port_list.extend(inout_pname_alist[i])

    #scan_comb_init_list, scan_seq_init_list, scan_comb_list,  scan_seq_list, scan_port_list, scan_reg_def_list = gen_scan_chain(scan_in_len, scan_out_len, scan_grp_sel)
    scan_comb_init_list,  scan_comb_list,   scan_port_list = gen_scan_chain(scan_in_len, scan_out_len, scan_grp_sel)
    #scan_reg_def_str = "".join(scan_reg_def_list)
    #print('top_port_alist:',inout_pname_alist)
    inout_pname_str = "".join(inout_pname_alist)
    top_port_sort = inout_pname_str.split('\n')
    #print('top_port_sort:',top_port_sort)

    for item in input_name_init_alist:
      name_init.append('\n' + INDENT_SP*2 + item + INDENT_SP*2 + '= 1\'b0;')
    name_init.append('\n' + INDENT_SP*2 + 'Mode_Null_In' + INDENT_SP*2 + '= {(DIG_PAD_NUM){1\'b0}};')

    for item in top_port_sort:
      #print('top_port_list:',item)
      if item not in top_port_tmp:
        top_port_tmp.append(item)


    for item in top_port_tmp:
      top_port.append(item + '\n')
    top_port.append(scan_port_list)
    top_port_str = "".join(top_port)
    #print('top_port:',top_port)
    ass_pads_str = "".join(ass_pads)
    #print('top_port_str:',top_port_str)
    #print('ass pads str:', ass_pads_str)
    #=====================================        
    #assembly the verilog code. 
    #=====================================
    #print('seq_init: ' , scan_seq_init_list , '\n\nseq_: ' , scan_seq_list , '\n\ncomb_init: ',   scan_comb_init_list, '\n\ncomb: ', scan_comb_list)
    scan_comb_init_str = "".join(scan_comb_init_list)
    scan_comb_str = "".join(scan_comb_list)
    #scan_seq_init_str = "".join(scan_seq_init_list)
    #scan_seq_str = "".join(scan_seq_list)
    # remove the ',' in last line of port signal.
    #print('seq_init: ' + scan_seq_init_str + '\n\nseq_: ' + scan_seq_str + '\n\ncomb_init: ' + scan_comb_init_str + '\n\ncomb: ' + scan_comb_str)
    pads_default_oe_str = "".join(pads_default_oe_alist)
    pads_default_out_str = "".join(pads_default_out_alist)
    pads_default_in_str = "".join(pads_default_in_alist)

    #print('input:', pads_in_alist,'\n', 'oe:', pads_oe_alist, '\n', 'out:',pads_out_alist)
    pads_oe_str = "".join(pads_oe_alist)
    pads_out_str = "".join(pads_out_alist)
    pads_in_str = "".join(pads_in_alist)
    scan_wire_name_str = "".join(wire_name_alist)
    name_init_str = "".join(name_init)

    #print('input:', pads_in_str,'\n', 'oe:', pads_oe_str, '\n', 'out:',pads_out_str)
    #Select the bus interface: APB, AHB, SRAM
    #TBD
    # read the MainInfo sheet and get the BUS INTERFACE parameter.
    bus_interface = BUS_IF_APBSLV
    
    # combine statement blocks.
    if module_name !=  '' :     
        bus_if_str = bus_interface %(\
                                    module_name, \
                                    '/*autoarg*/', \
                                    dig_pad_num, \
                                    '', \
                                    top_port_str \
                                    )
    else :
        bus_if_str = ''
    
    # combine statement blocks.
    if  scan_seq_init_str != '' :  
        write_reg_block = WRITE_REG_BLOCK %(\
                                    scan_seq_init_str, \
                                    scan_seq_str \
                                    )
    else :
        write_reg_block = ''
     
    # combine statement blocks.   
    scan_width = int(scan_grp_sel) 
    if (scan_width > 1):
      if  scan_comb_init_str != '' :                              
          scan_comb_block = ALWAYS_COM_BLOCK %(\
                                      scan_comb_init_str, \
                                      'scan_grp_sel', \
                                      scan_comb_str)
      else :
          scan_comb_block = ''
    else:
      scan_comb_block = scan_comb_str
    # combine statement blocks.   
    if  pads_in_str != '' :                              
        pads_in_comb_block = ALWAYS_COM_BLOCK %(\
                                    name_init_str, \
                                    'pads_chip_modes', \
                                    pads_in_str)
    else :
        pads_in_comb_block = ''
        
    # combine statement blocks.   
    if  pads_oe_str != '' :                              
        pads_oe_comb_block = ALWAYS_COM_BLOCK %(\
                                    pads_default_oe_str, \
                                    'pads_chip_modes', \
                                    pads_oe_str)
    else :
        pads_oe_comb_block = ''
        
    # combine statement blocks.   
    if  pads_out_str != '' :                              
        pads_out_comb_block = ALWAYS_COM_BLOCK %(\
                                    pads_default_out_str, \
                                    'pads_chip_modes', \
                                    pads_out_str)
    else :
        pads_out_comb_block = ''
        
        
#    # combine statement blocks.
#    if  pulse_init != '' :                            
#        pulse_trig_block = PULSE_TRIG_BLOCK %(\
#                                    pulse_init,\
#                                    pulse_assign)
#    else :    
#        pulse_trig_block = ''
#        
#        
     # combine statement blocks.
    if  ass_pads_str != '' :                            
        ass_cross_block = ASSIGN_CROSS_BLOCK %(\
                                    ass_pads_str)
    else :    
        ass_cross_block = ''

     # combine statement blocks.
    if  scan_reg_def_str != '' :                            
        input_reg_def_block = INPUT_SYNC_BLOCK %(\
                                    scan_reg_def_str)
    else :    
        input_reg_def_block = ''

     # combine statement blocks.
    if  scan_wire_name_str != '' :                            
        scan_wire_def_block = INPUT_SYNC_BLOCK %(\
                                    scan_wire_name_str)
    else :    
        scan_wire_def_block = ''


     # combine statement blocks.
    dont_touch_edt_clk = 'tessent_persistent_cell_edt_clock_dont_touch'
    if  dont_touch_edt_clk != '' :                            
        dont_touch_edt_clk_block = DONT_TOUCH_ICG_BLOCK %(\
                                    dont_touch_edt_clk, \
                                    'dft_edt_clk', \
                                    'dft_test_clk_i', \
                                    'dft_scan_se_i', \
                                    'dft_scan_se_i'
                                    )
    else :    
        dont_touch_edt_clk_block = ''

    dont_touch_shift_clk = 'tessent_persistent_cell_shift_capture_clock_dont_touch'
    if  dont_touch_shift_clk != '' :                            
        dont_touch_shift_clk_block = DONT_TOUCH_BUFF_BLOCK %(\
                                    dont_touch_shift_clk, \
                                    'dft_test_clk_for_occ', \
                                    'dft_test_clk_i' 
                                    )
    else :    
        dont_touch_shift_clk_block = ''

    scan_mode_str = '\
                        //chip modes \
                        assign  dft_normal_mode           = pads_chip_modes ==  3\'b000 ;\n \
                        assign  dft_mbist_mode            = pads_chip_modes ==  3\'b001 ;\n \
                        assign  dft_scan_mode             = pads_chip_modes ==  3\'b010 ;\n \
                        assign  dft_ip_test_mode0_mode    = pads_chip_modes ==  3\'b011 ;\n \
                        assign  dft_pll_test_mode         = pads_chip_modes ==  3\'b100 ;\n \
                        assign  dft_ip_test_mode2_mode    = pads_chip_modes ==  3\'b101 ;\n \
                        assign  dft_ip_test_mode3_mode    = pads_chip_modes ==  3\'b110 ;\n \
                        assign  dft_normal_debug_cpu_mode = pads_chip_modes ==  3\'b111 ;\n \
    '
     # combine statement blocks.
    if  scan_mode_str != '' :                            
        scan_mode_block = INPUT_SYNC_BLOCK %(\
                                    scan_mode_str)
    else :    
        scan_mode_block = ''


    #module ending
    module_end = "\n endmodule \n \n"    
    
    #write verilog code to file.
    VerFile = open(module_name + '.v', 'w', encoding='utf-8') 
    VerFile.write(header_string)    
    VerFile.write(bus_if_str)
#    VerFile.write(input_reg_def_block) 
    VerFile.write(scan_wire_def_block) 
    VerFile.write(ass_cross_block)
#    VerFile.write(write_reg_block)
    VerFile.write(scan_comb_block) 
    VerFile.write(pads_in_comb_block) 
    VerFile.write(pads_oe_comb_block) 
    VerFile.write(pads_out_comb_block) 
#    VerFile.write(pulse_cross_block) 
#    VerFile.write(dont_touch_edt_clk_block) 
#    VerFile.write(dont_touch_shift_clk_block) 

    VerFile.write(module_end) 
    
    VerFile.close() #close Verilog file.
    
    return module_name
 
 
 
 
if __name__ == '__main__' :

    import argparse   
    
    parser = argparse.ArgumentParser(description='python argparse cookbook')    
    parser.add_argument('excel',  help="excel file to be parsed")
    parser.add_argument('-f', '--file_list', help="excel file list to be parsed")    
    args = parser.parse_args()
           
    excel_file = args.excel  
    print (f"Generate register module from excel table: {excel_file}. Version =", version_number)
    module_name = reg_module_gen (excel_file)
    print ("Register module [%s] has been generated!"%(module_name) )    
