//******************************************************************************
//
//   Copyright (c) 2020 Innosilicon. All rights reserved.
//
//   THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF INNOSILICON
//   The copyright notice above does not evidence any actual or intended
//   publication of such source code.
//
//    Module name: pin_mux
//    Create by: Huck He
//    Create time: 2020-6-16
//
//    Change List:
// 
//
//
//******************************************************************************

module pin_mux (  /*autoarg*/
   // Outputs
   pad_resetn_o, pad_ref_clk1_o, pad_ref_clk2_o, pad_mode_sel0_o,
   pad_mode_sel1_o, pad_mode_sel2_o, pad_pm0_sda_o, pad_pm0_scl_o,
   pad_pm0_slv_ctrl_o, pad_pm0_slv_alert_o, pad_pm1_sda_o,
   pad_pm1_scl_o, pad_flash_cs_o, pad_flash_hold_o, pad_flash_wp_o,
   pad_flash_miso_o, pad_flash_mosi_o, pad_flash_sclk_o, pad_pwm_0_o,
   pad_pwm_1_o, pad_debug_en_o, pad_boot_sel_o, pad_ec_scl_o,
   pad_ec_sda_o, pad_clkreq_n_o, pad_gpio_1_o, pad_gpio_2_o,
   pad_gpio_3_o, pad_gpio_4_o, pad_gpio_5_o, pad_gpio_6_o,
   pad_gpio_7_o, pad_gpio_8_o, pad_resetn_oe, pad_ref_clk1_oe,
   pad_ref_clk2_oe, pad_mode_sel0_oe, pad_mode_sel1_oe,
   pad_mode_sel2_oe, pad_pm0_sda_oe, pad_pm0_scl_oe,
   pad_pm0_slv_ctrl_oe, pad_pm0_slv_alert_oe, pad_pm1_sda_oe,
   pad_pm1_scl_oe, pad_flash_cs_oe, pad_flash_hold_oe,
   pad_flash_wp_oe, pad_flash_miso_oe, pad_flash_mosi_oe,
   pad_flash_sclk_oe, pad_pad_pwm_0_oe, pad_pwm_1_oe, pad_debug_en_oe,
   pad_boot_sel_oe, pad_ec_scl_oe, pad_ec_sda_oe, pad_clkreq_n_oe,
   pad_gpio_1_oe, pad_gpio_2_oe, pad_gpio_3_oe, pad_gpio_4_oe,
   pad_gpio_5_oe, pad_gpio_6_oe, pad_gpio_7_oe, pad_gpio_8_oe,
   hw_rstn_i, ref_crystal_clk1_i, ref_crystal_clk2_i, mode_sel_0_i,
   mode_sel_1_i, mode_sel_2_i, pmbus_sda_0_i, pmbus_scl_0_i,
   pmbus_slv_alert_0_i, pmbus_sda_1_i, pmbus_scl_1_i,
   qspi_io_iobuf_3_i, qspi_io_iobuf_2_i, qspi_io_iobuf_1_i,
   qspi_io_iobuf_0_i, debug_en_i, boot_sel_i, ec_scl_i, ec_sda_i,
   clkreq_n_i, gpio_1_i, gpio_2_i, gpio_3_i, gpio_4_i, gpio_5_i,
   gpio_6_i, gpio_7_i, gpio_8_i, dft_test_rstn_i, dft_test_clk_i,
   dft_scan_te_i, dft_scan_se_i, mb_jtag_rst_i, mb_jtag_clk_i,
   mb_jtag_tmds_i, mb_jtag_tdi_i, dft_pll_pd_i, pll_test_div_sel_0_i,
   pll_test_div_sel_1_i, pll_test_div_sel_2_i, sys_jt_tck_i,
   sys_jt_tms_i, sys_jt_tdi_i, sys_jt_rstn_i, dft_edt_update_i,
   dft_hdmi0_pin_test_sel_i, dft_hdmi0_pin_test_en_i,
   dft_hdmi1_pin_test_sel_i, dft_hdmi1_pin_test_en_i,
   dft_edp_pin_test_sel_i, dft_edp_pin_test_en_i,
   dft_vga_pin_test_sel_i, dft_vga_pin_test_en_i,
   dft_vga_pin_test_in0_i, dft_vga_pin_test_in1_i, pll1a_3_test_pd_i,
   pll1b_4_test_pd_i, pll2_5_test_pd_i, pll6_7_test_pd_i,
   pll6_7_test_pll_dacdsm_pd_i, mode_4_pll_sel_i, ddr_jtag_tdi_i,
   ddr_jtag_tck_i, ddr_jtag_tms_i, ddr_jtag_trst_i, ddr_jtag_tdo_i,
   ddr02_bist_mode_i, ddr02_bist_mux_i, ddr02_bist_start_i,
   ddr13_bist_mode_i, ddr13_bist_mux_i, ddr13_bist_start_i,
   mode_5_ddr_sel_i, dft_pcie_bist_rst_n_i, dft_pcie_bist_en_grp0_i,
   dft_pcie_bist_en_grp1_i, dft_pcie_bist_pipe_pd0_i,
   dft_pcie_bist_pipe_pd1_i, dft_pcie_bist_pipe_pd2_i,
   dft_pcie_bist_pipe_pd3_i, dft_pcie_bist_pipe_rate0_i,
   dft_pcie_bist_pipe_rate1_i, scan_in_0_grp_0, scan_in_1_grp_0,
   scan_in_2_grp_0, scan_in_3_grp_0, scan_in_4_grp_0, scan_in_5_grp_0,
   scan_in_6_grp_0, scan_in_0_grp_1, scan_in_1_grp_1, scan_in_2_grp_1,
   scan_in_3_grp_1, scan_in_4_grp_1, scan_in_5_grp_1, scan_in_6_grp_1,
   scan_in_0_grp_2, scan_in_1_grp_2, scan_in_2_grp_2, scan_in_3_grp_2,
   scan_in_4_grp_2, scan_in_5_grp_2, scan_in_6_grp_2, scan_in_0_grp_3,
   scan_in_1_grp_3, scan_in_2_grp_3, scan_in_3_grp_3, scan_in_4_grp_3,
   scan_in_5_grp_3, scan_in_6_grp_3, scan_in_0_grp_4, scan_in_1_grp_4,
   scan_in_2_grp_4, scan_in_3_grp_4, scan_in_4_grp_4, scan_in_5_grp_4,
   scan_in_6_grp_4, scan_in_0_grp_5, scan_in_1_grp_5, scan_in_2_grp_5,
   scan_in_3_grp_5, scan_in_4_grp_5, scan_in_5_grp_5, scan_in_6_grp_5,
   scan_in_0_grp_6, scan_in_1_grp_6, scan_in_2_grp_6, scan_in_3_grp_6,
   scan_in_4_grp_6, scan_in_5_grp_6, scan_in_6_grp_6, scan_in_0_grp_7,
   scan_in_1_grp_7, scan_in_2_grp_7, scan_in_3_grp_7, scan_in_4_grp_7,
   scan_in_5_grp_7, scan_in_6_grp_7, scan_in_0_grp_8, scan_in_1_grp_8,
   scan_in_2_grp_8, scan_in_3_grp_8, scan_in_4_grp_8, scan_in_5_grp_8,
   scan_in_6_grp_8, scan_in_0_grp_9, scan_in_1_grp_9, scan_in_2_grp_9,
   scan_in_3_grp_9, scan_in_4_grp_9, scan_in_5_grp_9, scan_in_6_grp_9,
   scan_in_0_grp_10, scan_in_1_grp_10, scan_in_2_grp_10,
   scan_in_3_grp_10, scan_in_4_grp_10, scan_in_5_grp_10,
   scan_in_6_grp_10, scan_in_0_grp_11, scan_in_1_grp_11,
   scan_in_2_grp_11, scan_in_3_grp_11, scan_in_4_grp_11,
   scan_in_5_grp_11, scan_in_6_grp_11, scan_in_0_grp_12,
   scan_in_1_grp_12, scan_in_2_grp_12, scan_in_3_grp_12,
   scan_in_4_grp_12, scan_in_5_grp_12, scan_in_6_grp_12,
   scan_in_0_grp_13, scan_in_1_grp_13, scan_in_2_grp_13,
   scan_in_3_grp_13, scan_in_4_grp_13, scan_in_5_grp_13,
   scan_in_6_grp_13, scan_in_0_grp_14, scan_in_1_grp_14,
   scan_in_2_grp_14, scan_in_3_grp_14, scan_in_4_grp_14,
   scan_in_5_grp_14, scan_in_6_grp_14, scan_in_0_grp_15,
   scan_in_1_grp_15, scan_in_2_grp_15, scan_in_3_grp_15,
   scan_in_4_grp_15, scan_in_5_grp_15, scan_in_6_grp_15, dft_edt_clk,
   dft_test_clk_for_occ, dft_normal_mode, dft_mbist_mode,
   dft_scan_mode, dft_ip_test_mode0_mode, dft_pll_test_mode,
   dft_ip_test_mode2_mode, dft_ip_test_mode3_mode,
   dft_normal_debug_cpu_mode,
   // Inputs
   pad_resetn_i, pad_ref_clk1_i, pad_ref_clk2_i, pad_mode_sel0_i,
   pad_mode_sel1_i, pad_mode_sel2_i, pad_pm0_sda_i, pad_pm0_scl_i,
   pad_pm0_slv_ctrl_i, pad_pm0_slv_alert_i, pad_pm1_sda_i,
   pad_pm1_scl_i, pad_flash_cs_i, pad_flash_hold_i, pad_flash_wp_i,
   pad_flash_miso_i, pad_flash_mosi_i, pad_flash_sclk_i, pad_pwm_0_i,
   pad_pwm_1_i, pad_debug_en_i, pad_boot_sel_i, pad_ec_scl_i,
   pad_ec_sda_i, pad_clkreq_n_i, pad_gpio_1_i, pad_gpio_2_i,
   pad_gpio_3_i, pad_gpio_4_i, pad_gpio_5_i, pad_gpio_6_i,
   pad_gpio_7_i, pad_gpio_8_i, pmbus_sda_0_o, pmbus_sda_0_oe,
   pmbus_scl_0_o, pmbus_scl_0_oe, pmbus_slv_ctrl_0_o, pmbus_sda_1_o,
   pmbus_sda_1_oe, pmbus_scl_1_o, pmbus_scl_1_oe, qspi_cs_iobuf_o_o,
   qspi_io_iobuf_3_o, qspi_io_iobuf_3_oe, qspi_io_iobuf_2_o,
   qspi_io_iobuf_2_oe, qspi_io_iobuf_1_o, qspi_io_iobuf_1_oe,
   qspi_io_iobuf_0_o, qspi_io_iobuf_0_oe, qspi_clk_iobuf_o_o, pwm_0_o,
   pwm_1_o, ec_scl_o, ec_scl_oe, ec_sda_o, ec_sda_oe, clkreq_n_o,
   clkreq_n_oe, gpio_1_o, gpio_1_oe, gpio_2_o, gpio_2_oe, gpio_3_o,
   gpio_3_oe, gpio_4_o, gpio_4_oe, gpio_5_o, gpio_5_oe, gpio_6_o,
   gpio_6_oe, gpio_7_o, gpio_7_oe, gpio_8_o, gpio_8_oe, mb_jtag_tdo_o,
   pll1a_test_lock_out_o, pll1b_test_lock_out_o, pll2_test_lock_out_o,
   pll3_test_lock_out_o, pll4_test_lock_out_o, pll5_test_lock_out_o,
   sys_jt_tdo_o, pll6_test_lock_out_o, pll7_test_clk_out_o,
   pll7_test_lock_out_o, dft_hdmi0_pin_test_done_o,
   dft_hdmi0_pin_test_pass_o, dft_hdmi1_pin_test_done_o,
   dft_hdmi1_pin_test_pass_o, dft_edp_pin_test_done_o,
   dft_edp_pin_test_pass_o, dft_vga_pin_test_done_o,
   dft_vga_pin_test_pass_o, pll1a_3_test_clk_out_o,
   pll1b_4_test_clk_out_o, pll2_5_test_clk_out_o,
   pll6_7_test_clk_out_o, pll1a_3_test_out_o, pll1b_4_test_out_o,
   pll2_5_test_out_o, pll6_7_test_out_o, pll4_test_clk_out_o,
   ddr_jtag_tdo_o, ddr_jtag_tdo_oe, ddr02_bist_complet_o,
   ddr02_bist_error_o, ddr13_bist_complet_o, ddr13_bist_error_o,
   dft_pcie_bist_done_grp0_o, dft_pcie_bist_done_grp1_o,
   dft_pcie_bist_pass_grp0_o, dft_pcie_bist_pass_grp1_o,
   dft_pcie_bist_phystatus0_o, dft_pcie_bist_phystatus1_o,
   dft_pcie_bist_phystatus2_o, dft_pcie_bist_phystatus3_o,
   dft_pcie_bist_phystatus4_o, dft_pcie_bist_phystatus5_o,
   dft_pcie_bist_phystatus6_0, dft_pcie_bist_phystatus7_0,
   scan_out_0_grp_0, scan_out_1_grp_0, scan_out_2_grp_0,
   scan_out_3_grp_0, scan_out_4_grp_0, scan_out_5_grp_0,
   scan_out_6_grp_0, scan_out_0_grp_1, scan_out_1_grp_1,
   scan_out_2_grp_1, scan_out_3_grp_1, scan_out_4_grp_1,
   scan_out_5_grp_1, scan_out_6_grp_1, scan_out_0_grp_2,
   scan_out_1_grp_2, scan_out_2_grp_2, scan_out_3_grp_2,
   scan_out_4_grp_2, scan_out_5_grp_2, scan_out_6_grp_2,
   scan_out_0_grp_3, scan_out_1_grp_3, scan_out_2_grp_3,
   scan_out_3_grp_3, scan_out_4_grp_3, scan_out_5_grp_3,
   scan_out_6_grp_3, scan_out_0_grp_4, scan_out_1_grp_4,
   scan_out_2_grp_4, scan_out_3_grp_4, scan_out_4_grp_4,
   scan_out_5_grp_4, scan_out_6_grp_4, scan_out_0_grp_5,
   scan_out_1_grp_5, scan_out_2_grp_5, scan_out_3_grp_5,
   scan_out_4_grp_5, scan_out_5_grp_5, scan_out_6_grp_5,
   scan_out_0_grp_6, scan_out_1_grp_6, scan_out_2_grp_6,
   scan_out_3_grp_6, scan_out_4_grp_6, scan_out_5_grp_6,
   scan_out_6_grp_6, scan_out_0_grp_7, scan_out_1_grp_7,
   scan_out_2_grp_7, scan_out_3_grp_7, scan_out_4_grp_7,
   scan_out_5_grp_7, scan_out_6_grp_7, scan_out_0_grp_8,
   scan_out_1_grp_8, scan_out_2_grp_8, scan_out_3_grp_8,
   scan_out_4_grp_8, scan_out_5_grp_8, scan_out_6_grp_8,
   scan_out_0_grp_9, scan_out_1_grp_9, scan_out_2_grp_9,
   scan_out_3_grp_9, scan_out_4_grp_9, scan_out_5_grp_9,
   scan_out_6_grp_9, scan_out_0_grp_10, scan_out_1_grp_10,
   scan_out_2_grp_10, scan_out_3_grp_10, scan_out_4_grp_10,
   scan_out_5_grp_10, scan_out_6_grp_10, scan_out_0_grp_11,
   scan_out_1_grp_11, scan_out_2_grp_11, scan_out_3_grp_11,
   scan_out_4_grp_11, scan_out_5_grp_11, scan_out_6_grp_11,
   scan_out_0_grp_12, scan_out_1_grp_12, scan_out_2_grp_12,
   scan_out_3_grp_12, scan_out_4_grp_12, scan_out_5_grp_12,
   scan_out_6_grp_12, scan_out_0_grp_13, scan_out_1_grp_13,
   scan_out_2_grp_13, scan_out_3_grp_13, scan_out_4_grp_13,
   scan_out_5_grp_13, scan_out_6_grp_13, scan_out_0_grp_14,
   scan_out_1_grp_14, scan_out_2_grp_14, scan_out_3_grp_14,
   scan_out_4_grp_14, scan_out_5_grp_14, scan_out_6_grp_14,
   scan_out_0_grp_15, scan_out_1_grp_15, scan_out_2_grp_15,
   scan_out_3_grp_15, scan_out_4_grp_15, scan_out_5_grp_15,
   scan_out_6_grp_15, scan_grp_sel
   );
             
//-----------------------------------------------------------//
//                          PARAMETERS                       //
//-----------------------------------------------------------//
localparam DIG_PAD_NUM = 33 ;
//

//-----------------------------------------------------------//
//                          REG_ADDRESS_DEFINEs              //
//-----------------------------------------------------------//



//-----------------------------------------------------------//
//                      INPUTS/OUTPUTS                       //
//-----------------------------------------------------------//  
             
input    pad_resetn_i;
input    pad_ref_clk1_i;
input    pad_ref_clk2_i;
input    pad_mode_sel0_i;
input    pad_mode_sel1_i;
input    pad_mode_sel2_i;
input    pad_pm0_sda_i;
input    pad_pm0_scl_i;
input    pad_pm0_slv_ctrl_i;
input    pad_pm0_slv_alert_i;
input    pad_pm1_sda_i;
input    pad_pm1_scl_i;
input    pad_flash_cs_i;
input    pad_flash_hold_i;
input    pad_flash_wp_i;
input    pad_flash_miso_i;
input    pad_flash_mosi_i;
input    pad_flash_sclk_i;
input    pad_pwm_0_i;
input    pad_pwm_1_i;
input    pad_debug_en_i;
input    pad_boot_sel_i;
input    pad_ec_scl_i;
input    pad_ec_sda_i;
input    pad_clkreq_n_i;
input    pad_gpio_1_i;
input    pad_gpio_2_i;
input    pad_gpio_3_i;
input    pad_gpio_4_i;
input    pad_gpio_5_i;
input    pad_gpio_6_i;
input    pad_gpio_7_i;
input    pad_gpio_8_i;
output    pad_resetn_o;
output    pad_ref_clk1_o;
output    pad_ref_clk2_o;
output    pad_mode_sel0_o;
output    pad_mode_sel1_o;
output    pad_mode_sel2_o;
output    pad_pm0_sda_o;
output    pad_pm0_scl_o;
output    pad_pm0_slv_ctrl_o;
output    pad_pm0_slv_alert_o;
output    pad_pm1_sda_o;
output    pad_pm1_scl_o;
output    pad_flash_cs_o;
output    pad_flash_hold_o;
output    pad_flash_wp_o;
output    pad_flash_miso_o;
output    pad_flash_mosi_o;
output    pad_flash_sclk_o;
output    pad_pwm_0_o;
output    pad_pwm_1_o;
output    pad_debug_en_o;
output    pad_boot_sel_o;
output    pad_ec_scl_o;
output    pad_ec_sda_o;
output    pad_clkreq_n_o;
output    pad_gpio_1_o;
output    pad_gpio_2_o;
output    pad_gpio_3_o;
output    pad_gpio_4_o;
output    pad_gpio_5_o;
output    pad_gpio_6_o;
output    pad_gpio_7_o;
output    pad_gpio_8_o;
output    pad_resetn_oe;
output    pad_ref_clk1_oe;
output    pad_ref_clk2_oe;
output    pad_mode_sel0_oe;
output    pad_mode_sel1_oe;
output    pad_mode_sel2_oe;
output    pad_pm0_sda_oe;
output    pad_pm0_scl_oe;
output    pad_pm0_slv_ctrl_oe;
output    pad_pm0_slv_alert_oe;
output    pad_pm1_sda_oe;
output    pad_pm1_scl_oe;
output    pad_flash_cs_oe;
output    pad_flash_hold_oe;
output    pad_flash_wp_oe;
output    pad_flash_miso_oe;
output    pad_flash_mosi_oe;
output    pad_flash_sclk_oe;
output    pad_pad_pwm_0_oe;
output    pad_pwm_1_oe;
output    pad_debug_en_oe;
output    pad_boot_sel_oe;
output    pad_ec_scl_oe;
output    pad_ec_sda_oe;
output    pad_clkreq_n_oe;
output    pad_gpio_1_oe;
output    pad_gpio_2_oe;
output    pad_gpio_3_oe;
output    pad_gpio_4_oe;
output    pad_gpio_5_oe;
output    pad_gpio_6_oe;
output    pad_gpio_7_oe;
output    pad_gpio_8_oe;
output reg     hw_rstn_i;
output reg     ref_crystal_clk1_i;
output reg     ref_crystal_clk2_i;
output reg     mode_sel_0_i;
output reg     mode_sel_1_i;
output reg     mode_sel_2_i;
output reg     pmbus_sda_0_i;
input    pmbus_sda_0_o;
input    pmbus_sda_0_oe;
output reg     pmbus_scl_0_i;
input    pmbus_scl_0_o;
input    pmbus_scl_0_oe;
input    pmbus_slv_ctrl_0_o;
output reg     pmbus_slv_alert_0_i;
output reg     pmbus_sda_1_i;
input    pmbus_sda_1_o;
input    pmbus_sda_1_oe;
output reg     pmbus_scl_1_i;
input    pmbus_scl_1_o;
input    pmbus_scl_1_oe;
input    qspi_cs_iobuf_o_o;
output reg     qspi_io_iobuf_3_i;
input    qspi_io_iobuf_3_o;
input    qspi_io_iobuf_3_oe;
output reg     qspi_io_iobuf_2_i;
input    qspi_io_iobuf_2_o;
input    qspi_io_iobuf_2_oe;
output reg     qspi_io_iobuf_1_i;
input    qspi_io_iobuf_1_o;
input    qspi_io_iobuf_1_oe;
output reg     qspi_io_iobuf_0_i;
input    qspi_io_iobuf_0_o;
input    qspi_io_iobuf_0_oe;
input    qspi_clk_iobuf_o_o;
input    pwm_0_o;
input    pwm_1_o;
output reg     debug_en_i;
output reg     boot_sel_i;
output reg     ec_scl_i;
input    ec_scl_o;
input    ec_scl_oe;
output reg     ec_sda_i;
input    ec_sda_o;
input    ec_sda_oe;
output reg     clkreq_n_i;
input    clkreq_n_o;
input    clkreq_n_oe;
output reg     gpio_1_i;
input    gpio_1_o;
input    gpio_1_oe;
output reg     gpio_2_i;
input    gpio_2_o;
input    gpio_2_oe;
output reg     gpio_3_i;
input    gpio_3_o;
input    gpio_3_oe;
output reg     gpio_4_i;
input    gpio_4_o;
input    gpio_4_oe;
output reg     gpio_5_i;
input    gpio_5_o;
input    gpio_5_oe;
output reg     gpio_6_i;
input    gpio_6_o;
input    gpio_6_oe;
output reg     gpio_7_i;
input    gpio_7_o;
input    gpio_7_oe;
output reg     gpio_8_i;
input    gpio_8_o;
input    gpio_8_oe;
output reg     dft_test_rstn_i;
output reg     dft_test_clk_i;
output reg     dft_scan_te_i;
output reg     dft_scan_se_i;
output reg     mb_jtag_rst_i;
output reg     mb_jtag_clk_i;
output reg     mb_jtag_tmds_i;
output reg     mb_jtag_tdi_i;
input    mb_jtag_tdo_o;
output reg     dft_pll_pd_i;
output reg     pll_test_div_sel_0_i;
output reg     pll_test_div_sel_1_i;
output reg     pll_test_div_sel_2_i;
input    pll1a_test_lock_out_o;
input    pll1b_test_lock_out_o;
input    pll2_test_lock_out_o;
input    pll3_test_lock_out_o;
input    pll4_test_lock_out_o;
input    pll5_test_lock_out_o;
output reg     sys_jt_tck_i;
output reg     sys_jt_tms_i;
output reg     sys_jt_tdi_i;
input    sys_jt_tdo_o;
output reg     sys_jt_rstn_i;
input    pll6_test_lock_out_o;
input    pll7_test_clk_out_o;
input    pll7_test_lock_out_o;
output reg     dft_edt_update_i;
output reg     dft_hdmi0_pin_test_sel_i;
output reg     dft_hdmi0_pin_test_en_i;
input    dft_hdmi0_pin_test_done_o;
input    dft_hdmi0_pin_test_pass_o;
output reg     dft_hdmi1_pin_test_sel_i;
output reg     dft_hdmi1_pin_test_en_i;
input    dft_hdmi1_pin_test_done_o;
input    dft_hdmi1_pin_test_pass_o;
output reg     dft_edp_pin_test_sel_i;
output reg     dft_edp_pin_test_en_i;
input    dft_edp_pin_test_done_o;
input    dft_edp_pin_test_pass_o;
output reg     dft_vga_pin_test_sel_i;
output reg     dft_vga_pin_test_en_i;
output reg     dft_vga_pin_test_in0_i;
output reg     dft_vga_pin_test_in1_i;
input    dft_vga_pin_test_done_o;
input    dft_vga_pin_test_pass_o;
output reg     pll1a_3_test_pd_i;
output reg     pll1b_4_test_pd_i;
output reg     pll2_5_test_pd_i;
output reg     pll6_7_test_pd_i;
output reg     pll6_7_test_pll_dacdsm_pd_i;
input    pll1a_3_test_clk_out_o;
input    pll1b_4_test_clk_out_o;
input    pll2_5_test_clk_out_o;
input    pll6_7_test_clk_out_o;
input    pll1a_3_test_out_o;
input    pll1b_4_test_out_o;
input    pll2_5_test_out_o;
input    pll6_7_test_out_o;
input    pll4_test_clk_out_o;
output reg     mode_4_pll_sel_i;
output reg     ddr_jtag_tdi_i;
output reg     ddr_jtag_tck_i;
output reg     ddr_jtag_tms_i;
output reg     ddr_jtag_trst_i;
output reg     ddr_jtag_tdo_i;
input    ddr_jtag_tdo_o;
input    ddr_jtag_tdo_oe;
output reg     ddr02_bist_mode_i;
output reg     ddr02_bist_mux_i;
output reg     ddr02_bist_start_i;
input    ddr02_bist_complet_o;
input    ddr02_bist_error_o;
output reg     ddr13_bist_mode_i;
output reg     ddr13_bist_mux_i;
output reg     ddr13_bist_start_i;
input    ddr13_bist_complet_o;
input    ddr13_bist_error_o;
output reg     mode_5_ddr_sel_i;
output reg     dft_pcie_bist_rst_n_i;
output reg     dft_pcie_bist_en_grp0_i;
output reg     dft_pcie_bist_en_grp1_i;
output reg     dft_pcie_bist_pipe_pd0_i;
output reg     dft_pcie_bist_pipe_pd1_i;
output reg     dft_pcie_bist_pipe_pd2_i;
output reg     dft_pcie_bist_pipe_pd3_i;
output reg     dft_pcie_bist_pipe_rate0_i;
output reg     dft_pcie_bist_pipe_rate1_i;
input    dft_pcie_bist_done_grp0_o;
input    dft_pcie_bist_done_grp1_o;
input    dft_pcie_bist_pass_grp0_o;
input    dft_pcie_bist_pass_grp1_o;
input    dft_pcie_bist_phystatus0_o;
input    dft_pcie_bist_phystatus1_o;
input    dft_pcie_bist_phystatus2_o;
input    dft_pcie_bist_phystatus3_o;
input    dft_pcie_bist_phystatus4_o;
input    dft_pcie_bist_phystatus5_o;
input    dft_pcie_bist_phystatus6_0;
input    dft_pcie_bist_phystatus7_0;

output reg     scan_in_0_grp_0;
input wire     scan_out_0_grp_0;
output reg     scan_in_1_grp_0;
input wire     scan_out_1_grp_0;
output reg     scan_in_2_grp_0;
input wire     scan_out_2_grp_0;
output reg     scan_in_3_grp_0;
input wire     scan_out_3_grp_0;
output reg     scan_in_4_grp_0;
input wire     scan_out_4_grp_0;
output reg     scan_in_5_grp_0;
input wire     scan_out_5_grp_0;
output reg     scan_in_6_grp_0;
input wire     scan_out_6_grp_0;
output reg     scan_in_0_grp_1;
input wire     scan_out_0_grp_1;
output reg     scan_in_1_grp_1;
input wire     scan_out_1_grp_1;
output reg     scan_in_2_grp_1;
input wire     scan_out_2_grp_1;
output reg     scan_in_3_grp_1;
input wire     scan_out_3_grp_1;
output reg     scan_in_4_grp_1;
input wire     scan_out_4_grp_1;
output reg     scan_in_5_grp_1;
input wire     scan_out_5_grp_1;
output reg     scan_in_6_grp_1;
input wire     scan_out_6_grp_1;
output reg     scan_in_0_grp_2;
input wire     scan_out_0_grp_2;
output reg     scan_in_1_grp_2;
input wire     scan_out_1_grp_2;
output reg     scan_in_2_grp_2;
input wire     scan_out_2_grp_2;
output reg     scan_in_3_grp_2;
input wire     scan_out_3_grp_2;
output reg     scan_in_4_grp_2;
input wire     scan_out_4_grp_2;
output reg     scan_in_5_grp_2;
input wire     scan_out_5_grp_2;
output reg     scan_in_6_grp_2;
input wire     scan_out_6_grp_2;
output reg     scan_in_0_grp_3;
input wire     scan_out_0_grp_3;
output reg     scan_in_1_grp_3;
input wire     scan_out_1_grp_3;
output reg     scan_in_2_grp_3;
input wire     scan_out_2_grp_3;
output reg     scan_in_3_grp_3;
input wire     scan_out_3_grp_3;
output reg     scan_in_4_grp_3;
input wire     scan_out_4_grp_3;
output reg     scan_in_5_grp_3;
input wire     scan_out_5_grp_3;
output reg     scan_in_6_grp_3;
input wire     scan_out_6_grp_3;
output reg     scan_in_0_grp_4;
input wire     scan_out_0_grp_4;
output reg     scan_in_1_grp_4;
input wire     scan_out_1_grp_4;
output reg     scan_in_2_grp_4;
input wire     scan_out_2_grp_4;
output reg     scan_in_3_grp_4;
input wire     scan_out_3_grp_4;
output reg     scan_in_4_grp_4;
input wire     scan_out_4_grp_4;
output reg     scan_in_5_grp_4;
input wire     scan_out_5_grp_4;
output reg     scan_in_6_grp_4;
input wire     scan_out_6_grp_4;
output reg     scan_in_0_grp_5;
input wire     scan_out_0_grp_5;
output reg     scan_in_1_grp_5;
input wire     scan_out_1_grp_5;
output reg     scan_in_2_grp_5;
input wire     scan_out_2_grp_5;
output reg     scan_in_3_grp_5;
input wire     scan_out_3_grp_5;
output reg     scan_in_4_grp_5;
input wire     scan_out_4_grp_5;
output reg     scan_in_5_grp_5;
input wire     scan_out_5_grp_5;
output reg     scan_in_6_grp_5;
input wire     scan_out_6_grp_5;
output reg     scan_in_0_grp_6;
input wire     scan_out_0_grp_6;
output reg     scan_in_1_grp_6;
input wire     scan_out_1_grp_6;
output reg     scan_in_2_grp_6;
input wire     scan_out_2_grp_6;
output reg     scan_in_3_grp_6;
input wire     scan_out_3_grp_6;
output reg     scan_in_4_grp_6;
input wire     scan_out_4_grp_6;
output reg     scan_in_5_grp_6;
input wire     scan_out_5_grp_6;
output reg     scan_in_6_grp_6;
input wire     scan_out_6_grp_6;
output reg     scan_in_0_grp_7;
input wire     scan_out_0_grp_7;
output reg     scan_in_1_grp_7;
input wire     scan_out_1_grp_7;
output reg     scan_in_2_grp_7;
input wire     scan_out_2_grp_7;
output reg     scan_in_3_grp_7;
input wire     scan_out_3_grp_7;
output reg     scan_in_4_grp_7;
input wire     scan_out_4_grp_7;
output reg     scan_in_5_grp_7;
input wire     scan_out_5_grp_7;
output reg     scan_in_6_grp_7;
input wire     scan_out_6_grp_7;
output reg     scan_in_0_grp_8;
input wire     scan_out_0_grp_8;
output reg     scan_in_1_grp_8;
input wire     scan_out_1_grp_8;
output reg     scan_in_2_grp_8;
input wire     scan_out_2_grp_8;
output reg     scan_in_3_grp_8;
input wire     scan_out_3_grp_8;
output reg     scan_in_4_grp_8;
input wire     scan_out_4_grp_8;
output reg     scan_in_5_grp_8;
input wire     scan_out_5_grp_8;
output reg     scan_in_6_grp_8;
input wire     scan_out_6_grp_8;
output reg     scan_in_0_grp_9;
input wire     scan_out_0_grp_9;
output reg     scan_in_1_grp_9;
input wire     scan_out_1_grp_9;
output reg     scan_in_2_grp_9;
input wire     scan_out_2_grp_9;
output reg     scan_in_3_grp_9;
input wire     scan_out_3_grp_9;
output reg     scan_in_4_grp_9;
input wire     scan_out_4_grp_9;
output reg     scan_in_5_grp_9;
input wire     scan_out_5_grp_9;
output reg     scan_in_6_grp_9;
input wire     scan_out_6_grp_9;
output reg     scan_in_0_grp_10;
input wire     scan_out_0_grp_10;
output reg     scan_in_1_grp_10;
input wire     scan_out_1_grp_10;
output reg     scan_in_2_grp_10;
input wire     scan_out_2_grp_10;
output reg     scan_in_3_grp_10;
input wire     scan_out_3_grp_10;
output reg     scan_in_4_grp_10;
input wire     scan_out_4_grp_10;
output reg     scan_in_5_grp_10;
input wire     scan_out_5_grp_10;
output reg     scan_in_6_grp_10;
input wire     scan_out_6_grp_10;
output reg     scan_in_0_grp_11;
input wire     scan_out_0_grp_11;
output reg     scan_in_1_grp_11;
input wire     scan_out_1_grp_11;
output reg     scan_in_2_grp_11;
input wire     scan_out_2_grp_11;
output reg     scan_in_3_grp_11;
input wire     scan_out_3_grp_11;
output reg     scan_in_4_grp_11;
input wire     scan_out_4_grp_11;
output reg     scan_in_5_grp_11;
input wire     scan_out_5_grp_11;
output reg     scan_in_6_grp_11;
input wire     scan_out_6_grp_11;
output reg     scan_in_0_grp_12;
input wire     scan_out_0_grp_12;
output reg     scan_in_1_grp_12;
input wire     scan_out_1_grp_12;
output reg     scan_in_2_grp_12;
input wire     scan_out_2_grp_12;
output reg     scan_in_3_grp_12;
input wire     scan_out_3_grp_12;
output reg     scan_in_4_grp_12;
input wire     scan_out_4_grp_12;
output reg     scan_in_5_grp_12;
input wire     scan_out_5_grp_12;
output reg     scan_in_6_grp_12;
input wire     scan_out_6_grp_12;
output reg     scan_in_0_grp_13;
input wire     scan_out_0_grp_13;
output reg     scan_in_1_grp_13;
input wire     scan_out_1_grp_13;
output reg     scan_in_2_grp_13;
input wire     scan_out_2_grp_13;
output reg     scan_in_3_grp_13;
input wire     scan_out_3_grp_13;
output reg     scan_in_4_grp_13;
input wire     scan_out_4_grp_13;
output reg     scan_in_5_grp_13;
input wire     scan_out_5_grp_13;
output reg     scan_in_6_grp_13;
input wire     scan_out_6_grp_13;
output reg     scan_in_0_grp_14;
input wire     scan_out_0_grp_14;
output reg     scan_in_1_grp_14;
input wire     scan_out_1_grp_14;
output reg     scan_in_2_grp_14;
input wire     scan_out_2_grp_14;
output reg     scan_in_3_grp_14;
input wire     scan_out_3_grp_14;
output reg     scan_in_4_grp_14;
input wire     scan_out_4_grp_14;
output reg     scan_in_5_grp_14;
input wire     scan_out_5_grp_14;
output reg     scan_in_6_grp_14;
input wire     scan_out_6_grp_14;
output reg     scan_in_0_grp_15;
input wire     scan_out_0_grp_15;
output reg     scan_in_1_grp_15;
input wire     scan_out_1_grp_15;
output reg     scan_in_2_grp_15;
input wire     scan_out_2_grp_15;
output reg     scan_in_3_grp_15;
input wire     scan_out_3_grp_15;
output reg     scan_in_4_grp_15;
input wire     scan_out_4_grp_15;
output reg     scan_in_5_grp_15;
input wire     scan_out_5_grp_15;
output reg     scan_in_6_grp_15;
input wire     scan_out_6_grp_15;

input [3:0] scan_grp_sel;
output      dft_edt_clk;
output      dft_test_clk_for_occ;
output      dft_normal_mode;           
output      dft_mbist_mode;            
output      dft_scan_mode;             
output      dft_ip_test_mode0_mode;    
output      dft_pll_test_mode;         
output      dft_ip_test_mode2_mode;    
output      dft_ip_test_mode3_mode;    
output      dft_normal_debug_cpu_mode; 

//-----------------------------------------------------------//
//                    REGISTERS & WIRES                      //
//-----------------------------------------------------------//

reg  [DIG_PAD_NUM-1:0] Mode_Null_In;
reg  [DIG_PAD_NUM-1:0] pads_oe;
reg  [DIG_PAD_NUM-1:0] pads_i;
reg  [DIG_PAD_NUM-1:0] pads_o;
wire [2:0] pads_chip_modes = {pad_mode_sel2_i, pad_mode_sel1_i, pad_mode_sel0_i};
//-----------------------------------------------------------//
//                          ARCHITECTURE                     //
//-----------------------------------------------------------//  



//========================
//Sync up reg/wire signals for all RO type
//========================

reg        scan_in_0_d0;
reg        scan_in_0_d1;
reg        scan_out_0_d1;
reg        scan_out_0_d0;
reg        scan_in_1_d0;
reg        scan_in_1_d1;
reg        scan_out_1_d1;
reg        scan_out_1_d0;
reg        scan_in_2_d0;
reg        scan_in_2_d1;
reg        scan_out_2_d1;
reg        scan_out_2_d0;
reg        scan_in_3_d0;
reg        scan_in_3_d1;
reg        scan_out_3_d1;
reg        scan_out_3_d0;
reg        scan_in_4_d0;
reg        scan_in_4_d1;
reg        scan_out_4_d1;
reg        scan_out_4_d0;
reg        scan_in_5_d0;
reg        scan_in_5_d1;
reg        scan_out_5_d1;
reg        scan_out_5_d0;
reg        scan_in_6_d0;
reg        scan_in_6_d1;
reg        scan_out_6_d1;
reg        scan_out_6_d0;
reg        scan_in_7_d0;
reg        scan_in_7_d1;
reg        scan_out_7_d1;
reg        scan_out_7_d0;
reg        scan_in_8_d0;
reg        scan_in_8_d1;
reg        scan_out_8_d1;
reg        scan_out_8_d0;


//========================
//Sync up reg/wire signals for all RO type
//========================

reg    scan_in_0_i;
reg    scan_out_0_o;
reg    scan_in_1_i;
reg    scan_out_1_o;
reg    scan_in_2_i;
reg    scan_out_2_o;
reg    scan_in_3_i;
reg    scan_out_3_o;
reg    scan_in_4_i;
reg    scan_out_4_o;
reg    scan_in_5_i;
reg    scan_out_5_o;
reg    scan_in_6_i;
reg    scan_out_6_o;
reg    scan_in_7_i;
reg    scan_in_8_i;


//========================
//Generate assign  
//========================


 assign { 
        pad_resetn_oe,
        pad_ref_clk1_oe,
        pad_ref_clk2_oe,
        pad_mode_sel0_oe,
        pad_mode_sel1_oe,
        pad_mode_sel2_oe,
        pad_pm0_sda_oe,
        pad_pm0_scl_oe,
        pad_pm0_slv_ctrl_oe,
        pad_pm0_slv_alert_oe,
        pad_pm1_sda_oe,
        pad_pm1_scl_oe,
        pad_flash_cs_oe,
        pad_flash_hold_oe,
        pad_flash_wp_oe,
        pad_flash_miso_oe,
        pad_flash_mosi_oe,
        pad_flash_sclk_oe,
        pad_pad_pwm_0_oe,
        pad_pwm_1_oe,
        pad_debug_en_oe,
        pad_boot_sel_oe,
        pad_ec_scl_oe,
        pad_ec_sda_oe,
        pad_clkreq_n_oe,
        pad_gpio_1_oe,
        pad_gpio_2_oe,
        pad_gpio_3_oe,
        pad_gpio_4_oe,
        pad_gpio_5_oe,
        pad_gpio_6_oe,
        pad_gpio_7_oe,
        pad_gpio_8_oe
} = pads_oe;
 
 assign { 
        pad_resetn_o,
        pad_ref_clk1_o,
        pad_ref_clk2_o,
        pad_mode_sel0_o,
        pad_mode_sel1_o,
        pad_mode_sel2_o,
        pad_pm0_sda_o,
        pad_pm0_scl_o,
        pad_pm0_slv_ctrl_o,
        pad_pm0_slv_alert_o,
        pad_pm1_sda_o,
        pad_pm1_scl_o,
        pad_flash_cs_o,
        pad_flash_hold_o,
        pad_flash_wp_o,
        pad_flash_miso_o,
        pad_flash_mosi_o,
        pad_flash_sclk_o,
        pad_pwm_0_o,
        pad_pwm_1_o,
        pad_debug_en_o,
        pad_boot_sel_o,
        pad_ec_scl_o,
        pad_ec_sda_o,
        pad_clkreq_n_o,
        pad_gpio_1_o,
        pad_gpio_2_o,
        pad_gpio_3_o,
        pad_gpio_4_o,
        pad_gpio_5_o,
        pad_gpio_6_o,
        pad_gpio_7_o,
        pad_gpio_8_o
} = pads_o;
 
assign pads_i = { 
        pad_resetn_i,
        pad_ref_clk1_i,
        pad_ref_clk2_i,
        pad_mode_sel0_i,
        pad_mode_sel1_i,
        pad_mode_sel2_i,
        pad_pm0_sda_i,
        pad_pm0_scl_i,
        pad_pm0_slv_ctrl_i,
        pad_pm0_slv_alert_i,
        pad_pm1_sda_i,
        pad_pm1_scl_i,
        pad_flash_cs_i,
        pad_flash_hold_i,
        pad_flash_wp_i,
        pad_flash_miso_i,
        pad_flash_mosi_i,
        pad_flash_sclk_i,
        pad_pwm_0_i,
        pad_pwm_1_i,
        pad_debug_en_i,
        pad_boot_sel_i,
        pad_ec_scl_i,
        pad_ec_sda_i,
        pad_clkreq_n_i,
        pad_gpio_1_i,
        pad_gpio_2_i,
        pad_gpio_3_i,
        pad_gpio_4_i,
        pad_gpio_5_i,
        pad_gpio_6_i,
        pad_gpio_7_i,
        pad_gpio_8_i
};


//========================
//scan chain operation to registers
//========================
always @ (posedge dft_test_clk_i or negedge dft_test_rstn_i)
begin
if(!dft_test_rstn_i)
begin 
        scan_in_0_d0 <= 1'b0;
        scan_in_0_d1 <= 1'b0;
        scan_in_1_d0 <= 1'b0;
        scan_in_1_d1 <= 1'b0;
        scan_in_2_d0 <= 1'b0;
        scan_in_2_d1 <= 1'b0;
        scan_in_3_d0 <= 1'b0;
        scan_in_3_d1 <= 1'b0;
        scan_in_4_d0 <= 1'b0;
        scan_in_4_d1 <= 1'b0;
        scan_in_5_d0 <= 1'b0;
        scan_in_5_d1 <= 1'b0;
        scan_in_6_d0 <= 1'b0;
        scan_in_6_d1 <= 1'b0;
        scan_in_7_d0 <= 1'b0;
        scan_in_7_d1 <= 1'b0;
        scan_in_8_d0 <= 1'b0;
        scan_in_8_d1 <= 1'b0;
        scan_out_0_o <= 1'b0;
        scan_out_0_d1 <= 1'b0;
        scan_out_1_o <= 1'b0;
        scan_out_1_d1 <= 1'b0;
        scan_out_2_o <= 1'b0;
        scan_out_2_d1 <= 1'b0;
        scan_out_3_o <= 1'b0;
        scan_out_3_d1 <= 1'b0;
        scan_out_4_o <= 1'b0;
        scan_out_4_d1 <= 1'b0;
        scan_out_5_o <= 1'b0;
        scan_out_5_d1 <= 1'b0;
        scan_out_6_o <= 1'b0;
        scan_out_6_d1 <= 1'b0;

end else
begin 
        {scan_in_0_d1, scan_in_0_d0} <= {scan_in_0_d0, scan_in_0_i};
        {scan_in_1_d1, scan_in_1_d0} <= {scan_in_1_d0, scan_in_1_i};
        {scan_in_2_d1, scan_in_2_d0} <= {scan_in_2_d0, scan_in_2_i};
        {scan_in_3_d1, scan_in_3_d0} <= {scan_in_3_d0, scan_in_3_i};
        {scan_in_4_d1, scan_in_4_d0} <= {scan_in_4_d0, scan_in_4_i};
        {scan_in_5_d1, scan_in_5_d0} <= {scan_in_5_d0, scan_in_5_i};
        {scan_in_6_d1, scan_in_6_d0} <= {scan_in_6_d0, scan_in_6_i};
        {scan_in_7_d1, scan_in_7_d0} <= {scan_in_7_d0, scan_in_7_i};
        {scan_in_8_d1, scan_in_8_d0} <= {scan_in_8_d0, scan_in_8_i};
        {scan_out_0_o, scan_out_0_d1} <= {scan_out_0_d1, scan_out_0_d0};
        {scan_out_1_o, scan_out_1_d1} <= {scan_out_1_d1, scan_out_1_d0};
        {scan_out_2_o, scan_out_2_d1} <= {scan_out_2_d1, scan_out_2_d0};
        {scan_out_3_o, scan_out_3_d1} <= {scan_out_3_d1, scan_out_3_d0};
        {scan_out_4_o, scan_out_4_d1} <= {scan_out_4_d1, scan_out_4_d0};
        {scan_out_5_o, scan_out_5_d1} <= {scan_out_5_d1, scan_out_5_d0};
        {scan_out_6_o, scan_out_6_d1} <= {scan_out_6_d1, scan_out_6_d0};

end
end  
      

//========================
//mode sel operation 
//========================
always @(*) begin
        scan_in_0_grp_0 = 1'b0;
        scan_in_1_grp_0 = 1'b0;
        scan_in_2_grp_0 = 1'b0;
        scan_in_3_grp_0 = 1'b0;
        scan_in_4_grp_0 = 1'b0;
        scan_in_5_grp_0 = 1'b0;
        scan_in_6_grp_0 = 1'b0;
        scan_in_0_grp_1 = 1'b0;
        scan_in_1_grp_1 = 1'b0;
        scan_in_2_grp_1 = 1'b0;
        scan_in_3_grp_1 = 1'b0;
        scan_in_4_grp_1 = 1'b0;
        scan_in_5_grp_1 = 1'b0;
        scan_in_6_grp_1 = 1'b0;
        scan_in_0_grp_2 = 1'b0;
        scan_in_1_grp_2 = 1'b0;
        scan_in_2_grp_2 = 1'b0;
        scan_in_3_grp_2 = 1'b0;
        scan_in_4_grp_2 = 1'b0;
        scan_in_5_grp_2 = 1'b0;
        scan_in_6_grp_2 = 1'b0;
        scan_in_0_grp_3 = 1'b0;
        scan_in_1_grp_3 = 1'b0;
        scan_in_2_grp_3 = 1'b0;
        scan_in_3_grp_3 = 1'b0;
        scan_in_4_grp_3 = 1'b0;
        scan_in_5_grp_3 = 1'b0;
        scan_in_6_grp_3 = 1'b0;
        scan_in_0_grp_4 = 1'b0;
        scan_in_1_grp_4 = 1'b0;
        scan_in_2_grp_4 = 1'b0;
        scan_in_3_grp_4 = 1'b0;
        scan_in_4_grp_4 = 1'b0;
        scan_in_5_grp_4 = 1'b0;
        scan_in_6_grp_4 = 1'b0;
        scan_in_0_grp_5 = 1'b0;
        scan_in_1_grp_5 = 1'b0;
        scan_in_2_grp_5 = 1'b0;
        scan_in_3_grp_5 = 1'b0;
        scan_in_4_grp_5 = 1'b0;
        scan_in_5_grp_5 = 1'b0;
        scan_in_6_grp_5 = 1'b0;
        scan_in_0_grp_6 = 1'b0;
        scan_in_1_grp_6 = 1'b0;
        scan_in_2_grp_6 = 1'b0;
        scan_in_3_grp_6 = 1'b0;
        scan_in_4_grp_6 = 1'b0;
        scan_in_5_grp_6 = 1'b0;
        scan_in_6_grp_6 = 1'b0;
        scan_in_0_grp_7 = 1'b0;
        scan_in_1_grp_7 = 1'b0;
        scan_in_2_grp_7 = 1'b0;
        scan_in_3_grp_7 = 1'b0;
        scan_in_4_grp_7 = 1'b0;
        scan_in_5_grp_7 = 1'b0;
        scan_in_6_grp_7 = 1'b0;
        scan_in_0_grp_8 = 1'b0;
        scan_in_1_grp_8 = 1'b0;
        scan_in_2_grp_8 = 1'b0;
        scan_in_3_grp_8 = 1'b0;
        scan_in_4_grp_8 = 1'b0;
        scan_in_5_grp_8 = 1'b0;
        scan_in_6_grp_8 = 1'b0;
        scan_in_0_grp_9 = 1'b0;
        scan_in_1_grp_9 = 1'b0;
        scan_in_2_grp_9 = 1'b0;
        scan_in_3_grp_9 = 1'b0;
        scan_in_4_grp_9 = 1'b0;
        scan_in_5_grp_9 = 1'b0;
        scan_in_6_grp_9 = 1'b0;
        scan_in_0_grp_10 = 1'b0;
        scan_in_1_grp_10 = 1'b0;
        scan_in_2_grp_10 = 1'b0;
        scan_in_3_grp_10 = 1'b0;
        scan_in_4_grp_10 = 1'b0;
        scan_in_5_grp_10 = 1'b0;
        scan_in_6_grp_10 = 1'b0;
        scan_in_0_grp_11 = 1'b0;
        scan_in_1_grp_11 = 1'b0;
        scan_in_2_grp_11 = 1'b0;
        scan_in_3_grp_11 = 1'b0;
        scan_in_4_grp_11 = 1'b0;
        scan_in_5_grp_11 = 1'b0;
        scan_in_6_grp_11 = 1'b0;
        scan_in_0_grp_12 = 1'b0;
        scan_in_1_grp_12 = 1'b0;
        scan_in_2_grp_12 = 1'b0;
        scan_in_3_grp_12 = 1'b0;
        scan_in_4_grp_12 = 1'b0;
        scan_in_5_grp_12 = 1'b0;
        scan_in_6_grp_12 = 1'b0;
        scan_in_0_grp_13 = 1'b0;
        scan_in_1_grp_13 = 1'b0;
        scan_in_2_grp_13 = 1'b0;
        scan_in_3_grp_13 = 1'b0;
        scan_in_4_grp_13 = 1'b0;
        scan_in_5_grp_13 = 1'b0;
        scan_in_6_grp_13 = 1'b0;
        scan_in_0_grp_14 = 1'b0;
        scan_in_1_grp_14 = 1'b0;
        scan_in_2_grp_14 = 1'b0;
        scan_in_3_grp_14 = 1'b0;
        scan_in_4_grp_14 = 1'b0;
        scan_in_5_grp_14 = 1'b0;
        scan_in_6_grp_14 = 1'b0;
        scan_in_0_grp_15 = 1'b0;
        scan_in_1_grp_15 = 1'b0;
        scan_in_2_grp_15 = 1'b0;
        scan_in_3_grp_15 = 1'b0;
        scan_in_4_grp_15 = 1'b0;
        scan_in_5_grp_15 = 1'b0;
        scan_in_6_grp_15 = 1'b0;
        scan_out_0_d0 = 1'b0;
        scan_out_1_d0 = 1'b0;
        scan_out_2_d0 = 1'b0;
        scan_out_3_d0 = 1'b0;
        scan_out_4_d0 = 1'b0;
        scan_out_5_d0 = 1'b0;
        scan_out_6_d0 = 1'b0;
    
case(scan_grp_sel)
'd0: begin 
        scan_out_0_d0 = scan_out_0_grp_0;
        scan_in_0_grp_0 = scan_in_0_d1;
        scan_out_1_d0 = scan_out_1_grp_0;
        scan_in_1_grp_0 = scan_in_1_d1;
        scan_out_2_d0 = scan_out_2_grp_0;
        scan_in_2_grp_0 = scan_in_2_d1;
        scan_out_3_d0 = scan_out_3_grp_0;
        scan_in_3_grp_0 = scan_in_3_d1;
        scan_out_4_d0 = scan_out_4_grp_0;
        scan_in_4_grp_0 = scan_in_4_d1;
        scan_out_5_d0 = scan_out_5_grp_0;
        scan_in_5_grp_0 = scan_in_5_d1;
        scan_out_6_d0 = scan_out_6_grp_0;
        scan_in_6_grp_0 = scan_in_6_d1;
end 
'd1: begin 
        scan_out_0_d0 = scan_out_0_grp_1;
        scan_in_0_grp_1 = scan_in_0_d1;
        scan_out_1_d0 = scan_out_1_grp_1;
        scan_in_1_grp_1 = scan_in_1_d1;
        scan_out_2_d0 = scan_out_2_grp_1;
        scan_in_2_grp_1 = scan_in_2_d1;
        scan_out_3_d0 = scan_out_3_grp_1;
        scan_in_3_grp_1 = scan_in_3_d1;
        scan_out_4_d0 = scan_out_4_grp_1;
        scan_in_4_grp_1 = scan_in_4_d1;
        scan_out_5_d0 = scan_out_5_grp_1;
        scan_in_5_grp_1 = scan_in_5_d1;
        scan_out_6_d0 = scan_out_6_grp_1;
        scan_in_6_grp_1 = scan_in_6_d1;
end 
'd2: begin 
        scan_out_0_d0 = scan_out_0_grp_2;
        scan_in_0_grp_2 = scan_in_0_d1;
        scan_out_1_d0 = scan_out_1_grp_2;
        scan_in_1_grp_2 = scan_in_1_d1;
        scan_out_2_d0 = scan_out_2_grp_2;
        scan_in_2_grp_2 = scan_in_2_d1;
        scan_out_3_d0 = scan_out_3_grp_2;
        scan_in_3_grp_2 = scan_in_3_d1;
        scan_out_4_d0 = scan_out_4_grp_2;
        scan_in_4_grp_2 = scan_in_4_d1;
        scan_out_5_d0 = scan_out_5_grp_2;
        scan_in_5_grp_2 = scan_in_5_d1;
        scan_out_6_d0 = scan_out_6_grp_2;
        scan_in_6_grp_2 = scan_in_6_d1;
end 
'd3: begin 
        scan_out_0_d0 = scan_out_0_grp_3;
        scan_in_0_grp_3 = scan_in_0_d1;
        scan_out_1_d0 = scan_out_1_grp_3;
        scan_in_1_grp_3 = scan_in_1_d1;
        scan_out_2_d0 = scan_out_2_grp_3;
        scan_in_2_grp_3 = scan_in_2_d1;
        scan_out_3_d0 = scan_out_3_grp_3;
        scan_in_3_grp_3 = scan_in_3_d1;
        scan_out_4_d0 = scan_out_4_grp_3;
        scan_in_4_grp_3 = scan_in_4_d1;
        scan_out_5_d0 = scan_out_5_grp_3;
        scan_in_5_grp_3 = scan_in_5_d1;
        scan_out_6_d0 = scan_out_6_grp_3;
        scan_in_6_grp_3 = scan_in_6_d1;
end 
'd4: begin 
        scan_out_0_d0 = scan_out_0_grp_4;
        scan_in_0_grp_4 = scan_in_0_d1;
        scan_out_1_d0 = scan_out_1_grp_4;
        scan_in_1_grp_4 = scan_in_1_d1;
        scan_out_2_d0 = scan_out_2_grp_4;
        scan_in_2_grp_4 = scan_in_2_d1;
        scan_out_3_d0 = scan_out_3_grp_4;
        scan_in_3_grp_4 = scan_in_3_d1;
        scan_out_4_d0 = scan_out_4_grp_4;
        scan_in_4_grp_4 = scan_in_4_d1;
        scan_out_5_d0 = scan_out_5_grp_4;
        scan_in_5_grp_4 = scan_in_5_d1;
        scan_out_6_d0 = scan_out_6_grp_4;
        scan_in_6_grp_4 = scan_in_6_d1;
end 
'd5: begin 
        scan_out_0_d0 = scan_out_0_grp_5;
        scan_in_0_grp_5 = scan_in_0_d1;
        scan_out_1_d0 = scan_out_1_grp_5;
        scan_in_1_grp_5 = scan_in_1_d1;
        scan_out_2_d0 = scan_out_2_grp_5;
        scan_in_2_grp_5 = scan_in_2_d1;
        scan_out_3_d0 = scan_out_3_grp_5;
        scan_in_3_grp_5 = scan_in_3_d1;
        scan_out_4_d0 = scan_out_4_grp_5;
        scan_in_4_grp_5 = scan_in_4_d1;
        scan_out_5_d0 = scan_out_5_grp_5;
        scan_in_5_grp_5 = scan_in_5_d1;
        scan_out_6_d0 = scan_out_6_grp_5;
        scan_in_6_grp_5 = scan_in_6_d1;
end 
'd6: begin 
        scan_out_0_d0 = scan_out_0_grp_6;
        scan_in_0_grp_6 = scan_in_0_d1;
        scan_out_1_d0 = scan_out_1_grp_6;
        scan_in_1_grp_6 = scan_in_1_d1;
        scan_out_2_d0 = scan_out_2_grp_6;
        scan_in_2_grp_6 = scan_in_2_d1;
        scan_out_3_d0 = scan_out_3_grp_6;
        scan_in_3_grp_6 = scan_in_3_d1;
        scan_out_4_d0 = scan_out_4_grp_6;
        scan_in_4_grp_6 = scan_in_4_d1;
        scan_out_5_d0 = scan_out_5_grp_6;
        scan_in_5_grp_6 = scan_in_5_d1;
        scan_out_6_d0 = scan_out_6_grp_6;
        scan_in_6_grp_6 = scan_in_6_d1;
end 
'd7: begin 
        scan_out_0_d0 = scan_out_0_grp_7;
        scan_in_0_grp_7 = scan_in_0_d1;
        scan_out_1_d0 = scan_out_1_grp_7;
        scan_in_1_grp_7 = scan_in_1_d1;
        scan_out_2_d0 = scan_out_2_grp_7;
        scan_in_2_grp_7 = scan_in_2_d1;
        scan_out_3_d0 = scan_out_3_grp_7;
        scan_in_3_grp_7 = scan_in_3_d1;
        scan_out_4_d0 = scan_out_4_grp_7;
        scan_in_4_grp_7 = scan_in_4_d1;
        scan_out_5_d0 = scan_out_5_grp_7;
        scan_in_5_grp_7 = scan_in_5_d1;
        scan_out_6_d0 = scan_out_6_grp_7;
        scan_in_6_grp_7 = scan_in_6_d1;
end 
'd8: begin 
        scan_out_0_d0 = scan_out_0_grp_8;
        scan_in_0_grp_8 = scan_in_0_d1;
        scan_out_1_d0 = scan_out_1_grp_8;
        scan_in_1_grp_8 = scan_in_1_d1;
        scan_out_2_d0 = scan_out_2_grp_8;
        scan_in_2_grp_8 = scan_in_2_d1;
        scan_out_3_d0 = scan_out_3_grp_8;
        scan_in_3_grp_8 = scan_in_3_d1;
        scan_out_4_d0 = scan_out_4_grp_8;
        scan_in_4_grp_8 = scan_in_4_d1;
        scan_out_5_d0 = scan_out_5_grp_8;
        scan_in_5_grp_8 = scan_in_5_d1;
        scan_out_6_d0 = scan_out_6_grp_8;
        scan_in_6_grp_8 = scan_in_6_d1;
end 
'd9: begin 
        scan_out_0_d0 = scan_out_0_grp_9;
        scan_in_0_grp_9 = scan_in_0_d1;
        scan_out_1_d0 = scan_out_1_grp_9;
        scan_in_1_grp_9 = scan_in_1_d1;
        scan_out_2_d0 = scan_out_2_grp_9;
        scan_in_2_grp_9 = scan_in_2_d1;
        scan_out_3_d0 = scan_out_3_grp_9;
        scan_in_3_grp_9 = scan_in_3_d1;
        scan_out_4_d0 = scan_out_4_grp_9;
        scan_in_4_grp_9 = scan_in_4_d1;
        scan_out_5_d0 = scan_out_5_grp_9;
        scan_in_5_grp_9 = scan_in_5_d1;
        scan_out_6_d0 = scan_out_6_grp_9;
        scan_in_6_grp_9 = scan_in_6_d1;
end 
'd10: begin 
        scan_out_0_d0 = scan_out_0_grp_10;
        scan_in_0_grp_10 = scan_in_0_d1;
        scan_out_1_d0 = scan_out_1_grp_10;
        scan_in_1_grp_10 = scan_in_1_d1;
        scan_out_2_d0 = scan_out_2_grp_10;
        scan_in_2_grp_10 = scan_in_2_d1;
        scan_out_3_d0 = scan_out_3_grp_10;
        scan_in_3_grp_10 = scan_in_3_d1;
        scan_out_4_d0 = scan_out_4_grp_10;
        scan_in_4_grp_10 = scan_in_4_d1;
        scan_out_5_d0 = scan_out_5_grp_10;
        scan_in_5_grp_10 = scan_in_5_d1;
        scan_out_6_d0 = scan_out_6_grp_10;
        scan_in_6_grp_10 = scan_in_6_d1;
end 
'd11: begin 
        scan_out_0_d0 = scan_out_0_grp_11;
        scan_in_0_grp_11 = scan_in_0_d1;
        scan_out_1_d0 = scan_out_1_grp_11;
        scan_in_1_grp_11 = scan_in_1_d1;
        scan_out_2_d0 = scan_out_2_grp_11;
        scan_in_2_grp_11 = scan_in_2_d1;
        scan_out_3_d0 = scan_out_3_grp_11;
        scan_in_3_grp_11 = scan_in_3_d1;
        scan_out_4_d0 = scan_out_4_grp_11;
        scan_in_4_grp_11 = scan_in_4_d1;
        scan_out_5_d0 = scan_out_5_grp_11;
        scan_in_5_grp_11 = scan_in_5_d1;
        scan_out_6_d0 = scan_out_6_grp_11;
        scan_in_6_grp_11 = scan_in_6_d1;
end 
'd12: begin 
        scan_out_0_d0 = scan_out_0_grp_12;
        scan_in_0_grp_12 = scan_in_0_d1;
        scan_out_1_d0 = scan_out_1_grp_12;
        scan_in_1_grp_12 = scan_in_1_d1;
        scan_out_2_d0 = scan_out_2_grp_12;
        scan_in_2_grp_12 = scan_in_2_d1;
        scan_out_3_d0 = scan_out_3_grp_12;
        scan_in_3_grp_12 = scan_in_3_d1;
        scan_out_4_d0 = scan_out_4_grp_12;
        scan_in_4_grp_12 = scan_in_4_d1;
        scan_out_5_d0 = scan_out_5_grp_12;
        scan_in_5_grp_12 = scan_in_5_d1;
        scan_out_6_d0 = scan_out_6_grp_12;
        scan_in_6_grp_12 = scan_in_6_d1;
end 
'd13: begin 
        scan_out_0_d0 = scan_out_0_grp_13;
        scan_in_0_grp_13 = scan_in_0_d1;
        scan_out_1_d0 = scan_out_1_grp_13;
        scan_in_1_grp_13 = scan_in_1_d1;
        scan_out_2_d0 = scan_out_2_grp_13;
        scan_in_2_grp_13 = scan_in_2_d1;
        scan_out_3_d0 = scan_out_3_grp_13;
        scan_in_3_grp_13 = scan_in_3_d1;
        scan_out_4_d0 = scan_out_4_grp_13;
        scan_in_4_grp_13 = scan_in_4_d1;
        scan_out_5_d0 = scan_out_5_grp_13;
        scan_in_5_grp_13 = scan_in_5_d1;
        scan_out_6_d0 = scan_out_6_grp_13;
        scan_in_6_grp_13 = scan_in_6_d1;
end 
'd14: begin 
        scan_out_0_d0 = scan_out_0_grp_14;
        scan_in_0_grp_14 = scan_in_0_d1;
        scan_out_1_d0 = scan_out_1_grp_14;
        scan_in_1_grp_14 = scan_in_1_d1;
        scan_out_2_d0 = scan_out_2_grp_14;
        scan_in_2_grp_14 = scan_in_2_d1;
        scan_out_3_d0 = scan_out_3_grp_14;
        scan_in_3_grp_14 = scan_in_3_d1;
        scan_out_4_d0 = scan_out_4_grp_14;
        scan_in_4_grp_14 = scan_in_4_d1;
        scan_out_5_d0 = scan_out_5_grp_14;
        scan_in_5_grp_14 = scan_in_5_d1;
        scan_out_6_d0 = scan_out_6_grp_14;
        scan_in_6_grp_14 = scan_in_6_d1;
end 
'd15: begin 
        scan_out_0_d0 = scan_out_0_grp_15;
        scan_in_0_grp_15 = scan_in_0_d1;
        scan_out_1_d0 = scan_out_1_grp_15;
        scan_in_1_grp_15 = scan_in_1_d1;
        scan_out_2_d0 = scan_out_2_grp_15;
        scan_in_2_grp_15 = scan_in_2_d1;
        scan_out_3_d0 = scan_out_3_grp_15;
        scan_in_3_grp_15 = scan_in_3_d1;
        scan_out_4_d0 = scan_out_4_grp_15;
        scan_in_4_grp_15 = scan_in_4_d1;
        scan_out_5_d0 = scan_out_5_grp_15;
        scan_in_5_grp_15 = scan_in_5_d1;
        scan_out_6_d0 = scan_out_6_grp_15;
        scan_in_6_grp_15 = scan_in_6_d1;
end 
        
endcase
end


//========================
//mode sel operation 
//========================
always @(*) begin

 {
        hw_rstn_i,
        ref_crystal_clk1_i,
        ref_crystal_clk2_i,
        mode_sel_0_i,
        mode_sel_1_i,
        mode_sel_2_i,
        pmbus_sda_0_i,
        pmbus_scl_0_i,
        Mode_Null_In[9],
        pmbus_slv_alert_0_i,
        pmbus_sda_1_i,
        pmbus_scl_1_i,
        Mode_Null_In[13],
        qspi_io_iobuf_3_i,
        qspi_io_iobuf_2_i,
        qspi_io_iobuf_1_i,
        qspi_io_iobuf_0_i,
        Mode_Null_In[18],
        Mode_Null_In[19],
        Mode_Null_In[20],
        debug_en_i,
        boot_sel_i,
        ec_scl_i,
        ec_sda_i,
        clkreq_n_i,
        gpio_1_i,
        gpio_2_i,
        gpio_3_i,
        gpio_4_i,
        gpio_5_i,
        gpio_6_i,
        gpio_7_i,
        gpio_8_i } = pads_i;
     
case(pads_chip_modes)
3'd0 :  begin 
 {
        hw_rstn_i,
        ref_crystal_clk1_i,
        ref_crystal_clk2_i,
        mode_sel_0_i,
        mode_sel_1_i,
        mode_sel_2_i,
        pmbus_sda_0_i,
        pmbus_scl_0_i,
        Mode_Null_In[9],
        pmbus_slv_alert_0_i,
        pmbus_sda_1_i,
        pmbus_scl_1_i,
        Mode_Null_In[13],
        qspi_io_iobuf_3_i,
        qspi_io_iobuf_2_i,
        qspi_io_iobuf_1_i,
        qspi_io_iobuf_0_i,
        Mode_Null_In[18],
        Mode_Null_In[19],
        Mode_Null_In[20],
        debug_en_i,
        boot_sel_i,
        ec_scl_i,
        ec_sda_i,
        clkreq_n_i,
        gpio_1_i,
        gpio_2_i,
        gpio_3_i,
        gpio_4_i,
        gpio_5_i,
        gpio_6_i,
        gpio_7_i,
        gpio_8_i } = pads_i;
 end 
 3'd1 : begin 
  {
        hw_rstn_i,
        ref_crystal_clk1_i,
        ref_crystal_clk2_i,
        mode_sel_0_i,
        mode_sel_1_i,
        mode_sel_2_i,
        dft_test_rstn_i,
        dft_test_clk_i,
        dft_scan_te_i,
        dft_scan_se_i,
        mb_jtag_rst_i,
        mb_jtag_clk_i,
        mb_jtag_tmds_i,
        mb_jtag_tdi_i,
        Mode_Null_In[15],
        dft_pll_pd_i,
        pll_test_div_sel_0_i,
        pll_test_div_sel_1_i,
        pll_test_div_sel_2_i,
        Mode_Null_In[20],
        Mode_Null_In[21],
        Mode_Null_In[22],
        Mode_Null_In[23],
        Mode_Null_In[24],
        Mode_Null_In[25],
        sys_jt_tck_i,
        sys_jt_tms_i,
        sys_jt_tdi_i,
        Mode_Null_In[29],
        sys_jt_rstn_i,
        Mode_Null_In[31],
        Mode_Null_In[32],
        Mode_Null_In[33] } = pads_i;
 end 
 3'd2 : begin 
  {
        hw_rstn_i,
        ref_crystal_clk1_i,
        ref_crystal_clk2_i,
        mode_sel_0_i,
        mode_sel_1_i,
        mode_sel_2_i,
        dft_test_rstn_i,
        dft_test_clk_i,
        dft_scan_te_i,
        dft_scan_se_i,
        mb_jtag_rst_i,
        mb_jtag_clk_i,
        mb_jtag_tmds_i,
        mb_jtag_tdi_i,
        Mode_Null_In[15],
        dft_pll_pd_i,
        dft_edt_update_i,
        scan_in_0_i,
        Mode_Null_In[19],
        scan_in_1_i,
        Mode_Null_In[21],
        scan_in_2_i,
        Mode_Null_In[23],
        scan_in_3_i,
        Mode_Null_In[25],
        scan_in_4_i,
        Mode_Null_In[27],
        scan_in_5_i,
        Mode_Null_In[29],
        scan_in_6_i,
        Mode_Null_In[31],
        scan_in_7_i,
        scan_in_8_i } = pads_i;
 end 
 3'd3 : begin 
  {
        hw_rstn_i,
        ref_crystal_clk1_i,
        ref_crystal_clk2_i,
        mode_sel_0_i,
        mode_sel_1_i,
        mode_sel_2_i,
        dft_test_rstn_i,
        dft_test_clk_i,
        dft_hdmi0_pin_test_sel_i,
        dft_hdmi0_pin_test_en_i,
        Mode_Null_In[11],
        Mode_Null_In[12],
        dft_hdmi1_pin_test_sel_i,
        dft_hdmi1_pin_test_en_i,
        Mode_Null_In[15],
        dft_pll_pd_i,
        Mode_Null_In[17],
        dft_edp_pin_test_sel_i,
        dft_edp_pin_test_en_i,
        Mode_Null_In[20],
        Mode_Null_In[21],
        dft_vga_pin_test_sel_i,
        dft_vga_pin_test_en_i,
        dft_vga_pin_test_in0_i,
        dft_vga_pin_test_in1_i,
        sys_jt_tck_i,
        sys_jt_tms_i,
        sys_jt_tdi_i,
        Mode_Null_In[29],
        sys_jt_rstn_i,
        Mode_Null_In[31],
        Mode_Null_In[32],
        gpio_8_i } = pads_i;
 end 
 3'd4 : begin 
  {
        hw_rstn_i,
        ref_crystal_clk1_i,
        ref_crystal_clk2_i,
        mode_sel_0_i,
        mode_sel_1_i,
        mode_sel_2_i,
        dft_test_rstn_i,
        dft_test_clk_i,
        pll_test_div_sel_0_i,
        pll_test_div_sel_1_i,
        pll_test_div_sel_2_i,
        pll1a_3_test_pd_i,
        pll1b_4_test_pd_i,
        pll2_5_test_pd_i,
        pll6_7_test_pd_i,
        pll6_7_test_pll_dacdsm_pd_i,
        Mode_Null_In[17],
        Mode_Null_In[18],
        Mode_Null_In[19],
        Mode_Null_In[20],
        Mode_Null_In[21],
        Mode_Null_In[22],
        Mode_Null_In[23],
        Mode_Null_In[24],
        Mode_Null_In[25],
        sys_jt_tck_i,
        sys_jt_tms_i,
        sys_jt_tdi_i,
        Mode_Null_In[29],
        sys_jt_rstn_i,
        gpio_6_i,
        gpio_7_i,
        mode_4_pll_sel_i } = pads_i;
  end 
3'd5 : begin 
  {
        hw_rstn_i,
        ref_crystal_clk1_i,
        ref_crystal_clk2_i,
        mode_sel_0_i,
        mode_sel_1_i,
        mode_sel_2_i,
        ddr_jtag_tdi_i,
        ddr_jtag_tck_i,
        ddr_jtag_tms_i,
        ddr_jtag_trst_i,
        ddr_jtag_tdo_i,
        ddr02_bist_mode_i,
        ddr02_bist_mux_i,
        ddr02_bist_start_i,
        Mode_Null_In[15],
        Mode_Null_In[16],
        ddr13_bist_mode_i,
        ddr13_bist_mux_i,
        ddr13_bist_start_i,
        Mode_Null_In[20],
        Mode_Null_In[21],
        gpio_3_i,
        gpio_4_i,
        gpio_5_i,
        gpio_6_i,
        sys_jt_tck_i,
        sys_jt_tms_i,
        sys_jt_tdi_i,
        Mode_Null_In[29],
        sys_jt_rstn_i,
        gpio_6_i,
        gpio_7_i,
        mode_5_ddr_sel_i } = pads_i;
 end 
3'd6 : begin 
  {
        hw_rstn_i,
        ref_crystal_clk1_i,
        ref_crystal_clk2_i,
        mode_sel_0_i,
        mode_sel_1_i,
        mode_sel_2_i,
        dft_pcie_bist_rst_n_i,
        dft_pcie_bist_en_grp0_i,
        dft_pcie_bist_en_grp1_i,
        dft_pcie_bist_pipe_pd0_i,
        dft_pcie_bist_pipe_pd1_i,
        dft_pcie_bist_pipe_pd2_i,
        dft_pcie_bist_pipe_pd3_i,
        dft_pcie_bist_pipe_rate0_i,
        dft_pcie_bist_pipe_rate1_i,
        Mode_Null_In[16],
        Mode_Null_In[17],
        Mode_Null_In[18],
        Mode_Null_In[19],
        Mode_Null_In[20],
        Mode_Null_In[21],
        Mode_Null_In[22],
        Mode_Null_In[23],
        Mode_Null_In[24],
        Mode_Null_In[25],
        sys_jt_tck_i,
        sys_jt_tms_i,
        sys_jt_tdi_i,
        Mode_Null_In[29],
        sys_jt_rstn_i,
        Mode_Null_In[31],
        Mode_Null_In[32],
        gpio_8_i } = pads_i;
 end 
3'd7 : begin 
 {
        hw_rstn_i,
        ref_crystal_clk1_i,
        ref_crystal_clk2_i,
        mode_sel_0_i,
        mode_sel_1_i,
        mode_sel_2_i,
        pmbus_sda_0_i,
        pmbus_scl_0_i,
        Mode_Null_In[9],
        pmbus_slv_alert_0_i,
        pmbus_sda_1_i,
        pmbus_scl_1_i,
        Mode_Null_In[13],
        qspi_io_iobuf_3_i,
        qspi_io_iobuf_2_i,
        qspi_io_iobuf_1_i,
        qspi_io_iobuf_0_i,
        Mode_Null_In[18],
        Mode_Null_In[19],
        Mode_Null_In[20],
        debug_en_i,
        boot_sel_i,
        ec_scl_i,
        ec_sda_i,
        clkreq_n_i,
        sys_jt_tck_i,
        sys_jt_tms_i,
        sys_jt_tdi_i,
        Mode_Null_In[29],
        sys_jt_rstn_i,
        gpio_6_i,
        gpio_7_i,
        gpio_8_i } = pads_i;
 end 
        
endcase
end


//========================
//mode sel operation 
//========================
always @(*) begin

  pads_oe = {
        0,
        0,
        0,
        0,
        0,
        0,
        pmbus_sda_0_oe,
        pmbus_scl_0_oe,
        1,
        0,
        pmbus_sda_1_oe,
        pmbus_scl_1_oe,
        1,
        qspi_io_iobuf_3_oe,
        qspi_io_iobuf_2_oe,
        qspi_io_iobuf_1_oe,
        qspi_io_iobuf_0_oe,
        1,
        1,
        1,
        0,
        0,
        ec_scl_oe,
        ec_sda_oe,
        clkreq_n_oe,
        gpio_1_oe,
        gpio_2_oe,
        gpio_3_oe,
        gpio_4_oe,
        gpio_5_oe,
        gpio_6_oe,
        gpio_7_oe,
        gpio_8_oe};
     
case(pads_chip_modes)
3'd0: begin 
  pads_oe = {
        0,
        0,
        0,
        0,
        0,
        0,
        pmbus_sda_0_oe,
        pmbus_scl_0_oe,
        1,
        0,
        pmbus_sda_1_oe,
        pmbus_scl_1_oe,
        1,
        qspi_io_iobuf_3_oe,
        qspi_io_iobuf_2_oe,
        qspi_io_iobuf_1_oe,
        qspi_io_iobuf_0_oe,
        1,
        1,
        1,
        0,
        0,
        ec_scl_oe,
        ec_sda_oe,
        clkreq_n_oe,
        gpio_1_oe,
        gpio_2_oe,
        gpio_3_oe,
        gpio_4_oe,
        gpio_5_oe,
        gpio_6_oe,
        gpio_7_oe,
        gpio_8_oe};
  end 
 3'd1: begin 
  pads_oe = {
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        1,
        0,
        0,
        0,
        0,
        1,
        1,
        1,
        1,
        1,
        1,
        0,
        0,
        0,
        1,
        0,
        1,
        1,
        1};
  end 
 3'd2: begin 
  pads_oe = {
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        1,
        0,
        0,
        0,
        1,
        0,
        1,
        0,
        1,
        0,
        1,
        0,
        1,
        0,
        1,
        0,
        1,
        0,
        0};
  end 
 3'd3: begin 
  pads_oe = {
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        1,
        1,
        0,
        0,
        1,
        0,
        1,
        0,
        0,
        1,
        1,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        1,
        0,
        1,
        1,
        gpio_8_oe};
  end 
 3'd4:  begin 
 pads_oe = {
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        1,
        1,
        1,
        1,
        1,
        1,
        1,
        1,
        1,
        0,
        0,
        0,
        1,
        0,
        gpio_6_oe,
        gpio_7_oe,
        0};
  end 
 3'd5: begin 
  pads_oe = {
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        ddr_jtag_tdo_oe,
        0,
        0,
        0,
        1,
        1,
        0,
        0,
        0,
        1,
        1,
        gpio_3_oe,
        gpio_4_oe,
        gpio_5_oe,
        gpio_6_oe,
        0,
        0,
        0,
        1,
        0,
        gpio_6_oe,
        gpio_7_oe,
        0};
  end 
3'd6: begin 
  pads_oe = {
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        1,
        1,
        1,
        1,
        1,
        1,
        1,
        1,
        1,
        1,
        0,
        0,
        0,
        1,
        0,
        1,
        1,
        gpio_8_oe};
  end 
3'd7: begin 
 pads_oe = {
        0,
        0,
        0,
        0,
        0,
        0,
        pmbus_sda_0_oe,
        pmbus_scl_0_oe,
        1,
        0,
        pmbus_sda_1_oe,
        pmbus_scl_1_oe,
        1,
        qspi_io_iobuf_3_oe,
        qspi_io_iobuf_2_oe,
        qspi_io_iobuf_1_oe,
        qspi_io_iobuf_0_oe,
        1,
        1,
        1,
        0,
        0,
        ec_scl_oe,
        ec_sda_oe,
        clkreq_n_oe,
        0,
        0,
        0,
        1,
        0,
        gpio_6_oe,
        gpio_7_oe,
        gpio_8_oe};
 end
         
endcase
end


//========================
//mode sel operation 
//========================
always @(*) begin

  pads_o = {
        0,
        0,
        0,
        0,
        0,
        0,
        pmbus_sda_0_o,
        pmbus_scl_0_o,
        pmbus_slv_ctrl_0_o,
        0,
        pmbus_sda_1_o,
        pmbus_scl_1_o,
        qspi_cs_iobuf_o_o,
        qspi_io_iobuf_3_o,
        qspi_io_iobuf_2_o,
        qspi_io_iobuf_1_o,
        qspi_io_iobuf_0_o,
        qspi_clk_iobuf_o_o,
        pwm_0_o,
        pwm_1_o,
        0,
        0,
        ec_scl_o,
        ec_sda_o,
        clkreq_n_o,
        gpio_1_o,
        gpio_2_o,
        gpio_3_o,
        gpio_4_o,
        gpio_5_o,
        gpio_6_o,
        gpio_7_o,
        gpio_8_o};
     
case(pads_chip_modes)
3'd0: begin 
  pads_o = {
        0,
        0,
        0,
        0,
        0,
        0,
        pmbus_sda_0_o,
        pmbus_scl_0_o,
        pmbus_slv_ctrl_0_o,
        0,
        pmbus_sda_1_o,
        pmbus_scl_1_o,
        qspi_cs_iobuf_o_o,
        qspi_io_iobuf_3_o,
        qspi_io_iobuf_2_o,
        qspi_io_iobuf_1_o,
        qspi_io_iobuf_0_o,
        qspi_clk_iobuf_o_o,
        pwm_0_o,
        pwm_1_o,
        0,
        0,
        ec_scl_o,
        ec_sda_o,
        clkreq_n_o,
        gpio_1_o,
        gpio_2_o,
        gpio_3_o,
        gpio_4_o,
        gpio_5_o,
        gpio_6_o,
        gpio_7_o,
        gpio_8_o};
  end 
 3'd1: begin 
  pads_o = {
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        mb_jtag_tdo_o,
        0,
        0,
        0,
        0,
        pll1a_test_lock_out_o,
        pll1b_test_lock_out_o,
        pll2_test_lock_out_o,
        pll3_test_lock_out_o,
        pll4_test_lock_out_o,
        pll5_test_lock_out_o,
        0,
        0,
        0,
        sys_jt_tdo_o,
        0,
        pll6_test_lock_out_o,
        pll7_test_clk_out_o,
        pll7_test_lock_out_o};
  end 
 3'd2: begin 
  pads_o = {
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        mb_jtag_tdo_o,
        0,
        0,
        0,
        scan_out_0_o,
        0,
        scan_out_1_o,
        0,
        scan_out_2_o,
        0,
        scan_out_3_o,
        0,
        scan_out_4_o,
        0,
        scan_out_5_o,
        0,
        scan_out_6_o,
        0,
        0};
  end 
 3'd3: begin 
  pads_o = {
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        dft_hdmi0_pin_test_done_o,
        dft_hdmi0_pin_test_pass_o,
        0,
        0,
        dft_hdmi1_pin_test_done_o,
        0,
        dft_hdmi1_pin_test_pass_o,
        0,
        0,
        dft_edp_pin_test_done_o,
        dft_edp_pin_test_pass_o,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        sys_jt_tdo_o,
        0,
        dft_vga_pin_test_done_o,
        dft_vga_pin_test_pass_o,
        gpio_8_o};
 end 
  3'd4: begin 
  pads_o = {
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        pll1a_3_test_clk_out_o,
        pll1b_4_test_clk_out_o,
        pll2_5_test_clk_out_o,
        pll6_7_test_clk_out_o,
        pll1a_3_test_out_o,
        pll1b_4_test_out_o,
        pll2_5_test_out_o,
        pll6_7_test_out_o,
        pll4_test_clk_out_o,
        0,
        0,
        0,
        sys_jt_tdo_o,
        0,
        gpio_6_o,
        gpio_7_o,
        0};
  end 
 3'd5: begin 
  pads_o = {
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        ddr_jtag_tdo_o,
        0,
        0,
        0,
        ddr02_bist_complet_o,
        ddr02_bist_error_o,
        0,
        0,
        0,
        ddr13_bist_complet_o,
        ddr13_bist_error_o,
        gpio_3_o,
        gpio_4_o,
        gpio_5_o,
        gpio_6_o,
        0,
        0,
        0,
        sys_jt_tdo_o,
        0,
        gpio_6_o,
        gpio_7_o,
        0};
  end 
3'd6: begin 
  pads_o = {
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        dft_pcie_bist_done_grp0_o,
        dft_pcie_bist_done_grp1_o,
        dft_pcie_bist_pass_grp0_o,
        dft_pcie_bist_pass_grp1_o,
        dft_pcie_bist_phystatus0_o,
        dft_pcie_bist_phystatus1_o,
        dft_pcie_bist_phystatus2_o,
        dft_pcie_bist_phystatus3_o,
        dft_pcie_bist_phystatus4_o,
        dft_pcie_bist_phystatus5_o,
        0,
        0,
        0,
        sys_jt_tdo_o,
        0,
        dft_pcie_bist_phystatus6_0,
        dft_pcie_bist_phystatus7_0,
        gpio_8_o}; 
 end 
3'd7: begin 
 pads_o = {
        0,
        0,
        0,
        0,
        0,
        0,
        pmbus_sda_0_o,
        pmbus_scl_0_o,
        pmbus_slv_ctrl_0_o,
        0,
        pmbus_sda_1_o,
        pmbus_scl_1_o,
        qspi_cs_iobuf_o_o,
        qspi_io_iobuf_3_o,
        qspi_io_iobuf_2_o,
        qspi_io_iobuf_1_o,
        qspi_io_iobuf_0_o,
        qspi_clk_iobuf_o_o,
        pwm_0_o,
        pwm_1_o,
        0,
        0,
        ec_scl_o,
        ec_sda_o,
        clkreq_n_o,
        0,
        0,
        0,
        sys_jt_tdo_o,
        0,
        gpio_6_o,
        gpio_7_o,
        gpio_8_o};
 end 
        
endcase
end


//========================
//dont touch block
//========================

PREICG_X4R_A9PP84TR_C16 tessent_persistent_cell_edt_clock_dont_touch (
.ECK   (dft_edt_clk), 
.CK    (dft_test_clk_i), 
.E     (dft_scan_se_i), 
.SE    (dft_scan_se_i)
);

//========================
//dont touch block
//========================

PREICG_X4R_A9PP84TR_C16 tessent_persistent_cell_shift_capture_clock_dont_touch (
.ECK   (dft_test_clk_for_occ), 
.CK    (dft_test_clk_i), 
.E     (~dft_edt_update_i), 
.SE    (~dft_edt_update_i)
);

 endmodule 
 
