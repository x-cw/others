#Improved VerilogHDL
import string
import re

from ivlconst import *

__DESCRIPTION__ = '''
=====================================
# IVL - Improved VerilogHDL Language #
=====================================
//                                                                          
//  ivl_parse.py - IVL parser.                              
//                                      
//                                                                          
//  This library is free software; you can redistribute it and/or           
//  modify it under the terms of the GNU Lesser General Public              
//  License as published by the Free Software Foundation; either            
//  version 2.1 of the License, or (at your option) any later version.      
//                                                                          
//  This library is distributed in the hope that it will be useful,         
//  but WITHOUT ANY WARRANTY; without even the implied warranty of          
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU       
//  Lesser General Public License for more details.                         
//                                                                          
//  Full details of the license can be found in the file LGPL.TXT.          
//                                                                          
//  You should have received a copy of the GNU Lesser General Public        
//  License along with this library; if not, write to the Free Software     
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
//                                                                          
'''


#=============================
#Function: remove_comment (string)
#remove the verilog comment (//... or /*...*/) in a string
#TBD case:
# No 
#============================= 
def remove_comment(string) :

    templine = string.split('//',1)[0] #remove comment '//xxx'
    templine = templine.split('/*', 1)[0] #remove comment '/*xxxx*/'
    return templine
    
    
#=============================
#Function: signal_width_expr (width)
#generate '[xx:0]' string
#TBD case:
# No 
#============================= 
def signal_def_expr (type, width, name, end_flag) :

    if (width -1) :
        width_string = ' [' + repr(width-1) + ':0] '
    else :          
        width_string = '       '      
    if (end_flag) :
        signal_line = type.ljust(6, ' ') + width_string.ljust(9, ' ') + name + ';\n'
    else :    
        signal_line = type.ljust(6, ' ') + width_string.ljust(9, ' ') + name
        
    return signal_line
    

#=============================
#Function: extract_width (string)
#extract the width from "[xxx:xx]"
#return: a int number (width)
# No 
#============================= 

def  extract_width(bit_num_str) :
    tempstr = bit_num_str.replace('[', '')
    tempstr = tempstr.replace(']', '')
    if (':' in tempstr) :
        high_num = int(tempstr.split(':')[0])
        low_num  = int(tempstr.split(':')[1])
        width = high_num - low_num + 1
    else :
        width = 1
    return width
    
    
        
    
#=============================
#Function: search a StRING in a LIST
#Search the string and return current line num.
#TBD case:
# No 
#============================= 
def search_string(exp_str, line_num, lines_list): 
    local_num = line_num  
    
    if ( local_num >= len(lines_list)):
        print ("Search Fail: Index is out of range in the List!") 
        search_num = len(lines_list)
    else :
        while ( local_num < len(lines_list)) : #start search since current line. 
            templine = remove_comment(lines_list[local_num]) 
            if (exp_str in templine):
                if ((exp_str != '}') or (templine.strip() == '}')) :
                    search_num = local_num #return the line num which includes the exp_str.
                    break
            elif ( local_num == (len(lines_list) -1)):
                print ("Search Fail: Can't find the expected string: ", exp_str) 
                search_num = len(lines_list) 
                break       
            local_num += 1 # next line.
    return search_num



#=============================
#Function: gen_file_header_list
#insert file header
#
#TBD case:
# Need handle `ifdef declaration. TBD
#============================= 

def   gen_file_header_list (line_num, IvlLines) :
      file_head_list = []
      local_num = line_num
      file_head_list.append(FILEHEADER)
      return local_num, file_head_list       
   
   
#=============================
#Function: gen_module_port_list
#generate port list and port def list
# parse starting from the line number of input parameter, and
#stopping at last line of current block and return the line number.
#TBD case:
# Need handle `ifdef declaration. TBD
#============================= 
def gen_module_port_list (line_num, lines_list) :
    local_num = line_num
    module_port_list = []    
    port_def_list = []
    last_port_line = 0   
    
    
    currline = 'module  '+ lines_list[local_num].split()[1] + '  (   \n'
    module_port_list.append(currline) 
    
    end_num = search_string('}', local_num, lines_list)
    while ( local_num < end_num ) :
        local_num += 1 #next line.
        templine = remove_comment(lines_list[local_num]) 
        if ( len(templine.split()) > 1)  :  #" signal 4 }//last port ", or " signal 4//last port "
            if ('}' in templine):  # " signal 4}//last port "
                mod_port = re.sub(r'}', ' ', lines_list[local_num], 1)
                port_width = int(mod_port.split()[1]) 
                mod_port = re.sub(r' \d+', ');', mod_port)
                module_port_list.append(mod_port) 
            else : # " signal 4//last port "
                mod_port = re.sub(r' \d+', ',', lines_list[local_num]) #replace the num by ','.
                module_port_list.append(mod_port)
                port_width = int(templine.split()[1])  
            last_port_line = len(module_port_list) #latest found port.
            
            port_name = templine.split()[0]            
            port_def_list.append(signal_def_expr('input', port_width, port_name, 1))
        
        elif ('{' == templine.strip()):  # {//comments. remove the '{'.
            module_port_list.append( lines_list[local_num].replace('{', "", 1))
        elif ('}' == templine.strip()) : # }//comments. end of module definition.
            if (last_port_line > 0) :
                module_port_list[last_port_line -1] = module_port_list[last_port_line -1].replace(',', "", 1)
            module_port_list.append(lines_list[local_num].replace('}', ");", 1)) 
            
        else : # "  //comments"
            module_port_list.append(lines_list[local_num])
        
    return local_num, module_port_list, port_def_list
    
    

#=============================
#Function: gen_assign_state_list
#generate assign block
# parse starting from the line number of input parameter, and
#  stopping at last line of current block and return the line number.
#TBD case:
# No
#============================= 
def gen_assign_state_list (line_num, lines_list) :
    local_num = line_num
    local_reg_list = []
    assign_state_list = []
    
    currline = lines_list[local_num].replace ('ASSIGN', '', 1)
    currline = currline.replace('{', '', 1).lstrip()
    assign_state_list.append(currline)
     
    assign_state_num = search_string('}', local_num, lines_list)
    while ( local_num < assign_state_num) :
        local_num += 1 #next line.        
        templine = remove_comment(lines_list[local_num]) 
        if ( '=' in templine)  :  #is a assign statement    
            assign_signal = lines_list[local_num].split('=',maxsplit=1)[0].split()[0]
            signal_width = int(lines_list[local_num].split('=',maxsplit=1)[0].split()[1])
            assign_expr = lines_list[local_num].split('=',maxsplit=1)[1]
            assign_state_list.append('assign  ' + assign_signal + ' =' + assign_expr) 
            indent_num = assign_state_list[-1].index('=') + 2            
            
            local_reg_list.append(signal_def_expr('wire', signal_width, assign_signal, 1))
            
            if ('}' == templine.strip()) : # end of assign block. remove the } in current assign state line.
                assign_state_list[-1] = assign_state_list[-1].replace('}', "", 1)
            
        elif ('{' == templine.strip()):  # {//comments. remove the '{'.
            assign_state_list.append( lines_list[local_num].replace('{', "", 1).lstrip())
            
        elif ('}' == templine.strip()) : # }//comments. end of assign block
            assign_state_list.append(lines_list[local_num].replace('}', " ", 1).lstrip()) 
            
        elif (templine.split() == []) : # a comments or blank line
            assign_state_list.append(lines_list[local_num].lstrip()) 
        else : #broken expression by multiline.            
            assign_state_list.append(' '*indent_num + lines_list[local_num].lstrip()) 
        
        
    local_reg_list.append('\n') 
    return local_num, assign_state_list, local_reg_list    
    
    
 
   
#=============================
#Function: gen_sig_init_list
#generate signal initilization
# parse starting from the line number of input parameter, and
#  stopping at last line of current block and return the line number.
#TBD case:
# No
#============================= 
def gen_sig_init_list (sig_flag, line_num, lines_list) :
    local_num = line_num
    local_reg_list = []
    sig_init_list = []   
    
    currline = lines_list[local_num].replace ('SIG_INIT', '', 1)
    currline = currline.replace('{', '', 1).lstrip()
    sig_init_list.append(currline) 
                
    sig_init_num = search_string('}', local_num, lines_list)
    while(local_num < sig_init_num) :
        local_num += 1 #next line.
        
        templine = remove_comment(lines_list[local_num]) 
        
        if ( len(templine.split()) > 1)  :  #is a signal statement.
            signal_name = templine.split()[0] 
            signal_width = int(templine.split()[1]) 
            
            local_reg_list.append(signal_def_expr('reg', signal_width, signal_name, 1))
            
            if (sig_flag) : #always sequence block            
                indent_num = INDENT_SP*2
                operator = ' <= '
            else : #always combination block                 
                indent_num = INDENT_SP
                operator = ' = '       
                
            if (signal_name != templine.split()[2]) :
                if (len(lines_list[local_num].split('/', 1)) == 1) : # without comments. " nxt_txstate  2 txstate\n"
                    sig_line = indent_num + signal_name + operator + templine.split()[2] +';\n'
                elif (len(lines_list[local_num].split('/', 1)) == 2) : # with comments. " nxt_txstate  2 txstate //comments\n"
                    sig_line = indent_num + signal_name + operator + templine.split()[2] + '; /' + lines_list[local_num].split('/',1)[1]
                sig_init_list.append(sig_line) 
                
            
        elif ( (templine.strip() == '{') or (templine.strip() == '}'))  : # "   { //comments"  or "   } //comments"
            sig_line = lines_list[local_num].replace('{', ' ', 1).lstrip()
            if (sig_flag) :
                sig_line = INDENT_SP + lines_list[local_num].replace('}', 'end', 1).lstrip()
            else :
                sig_line = lines_list[local_num].replace('}', ' ', 1).lstrip()
            sig_init_list.append(sig_line)
            
        else : # "  //comments"
            sig_init_list.append(lines_list[local_num].lstrip())
            
    local_reg_list.append('\n')        
    return local_num, sig_init_list, local_reg_list                
                    
                     
    
#=============================
#Function: gen_always_com_list
#generate always com block
# parse starting from the line number of input parameter, and
#  stopping at last line of current block and return the line number.
#TBD case:
#  
#============================= 
def gen_always_com_list (line_num, lines_list) :
    local_num = line_num
    local_reg_list = []
    always_com_list = []
    
    currline = lines_list[local_num].replace ('ALWAYS_COM', '', 1)
    currline = currline.replace('{', '', 1).lstrip()
    always_com_list.append(currline)
    
    always_com_list.append(ALWAYS_COM_HEAD)
    
    temp_num = search_string('}', local_num, lines_list)
    always_com_num = search_string('}', temp_num+1, lines_list)
    
    while ( local_num < always_com_num) :
        local_num += 1 #next line.
        
        templine = remove_comment(lines_list[local_num]) 
        if ('SIG_INIT' in templine) :
            local_num, com_init_list, local_reg_list = gen_sig_init_list (0, local_num, lines_list)
            always_com_list.extend(com_init_list)            
                   
        elif ( templine.strip() == '}') : # "   } //comments" . end of always blocks 
            com_line = re.sub(r'}', 'end', lines_list[local_num]).lstrip()
            always_com_list.append(com_line)
            
        else : # just a comments    
            always_com_list.append(lines_list[local_num]) 
            
    return local_num, always_com_list, local_reg_list        

    
    
#=============================
#Function: gen_always_seq_list
#generate assign block
# parse starting from the line number of input parameter, and
#  stopping at last line of current block and return the line number.
#TBD case:
# No
#============================= 
def gen_always_seq_list (line_num, lines_list) :
    local_num = line_num
    local_reg_list = []
    always_seq_list = []
    
    currline = lines_list[local_num].replace ('ALWAYS_SEQ', '', 1)
    currline = currline.replace('{', '', 1).lstrip()
    always_seq_list.append(currline)
    
    always_seq_list.append(ALWAYS_SEQ_HEAD)  
    
    temp_num = search_string('}', local_num, lines_list)
    always_seq_num = search_string('}', temp_num+1, lines_list)
    
    while ( local_num < always_seq_num) :
        local_num += 1 #next line.
        
        templine = remove_comment(lines_list[local_num]) 
        if ('SIG_INIT' in templine) :
            local_num, seq_init_list, local_reg_list = gen_sig_init_list (1, local_num, lines_list)
            always_seq_list.extend(seq_init_list)            
        
        elif (templine.strip() == '}') : # "   } //comments" . end of always blocks
            seq_line = re.sub(r'}', 'end', lines_list[local_num]).lstrip()
            always_seq_list.append(seq_line)
            
        else : # just a comments    
            always_seq_list.append(lines_list[local_num]) 
            
    return local_num, always_seq_list, local_reg_list        

    
#=============================
#Function: gen_signal_delay_list
#generate signals delay block
# parse starting from the line number of input parameter, and
#  stopping at last line of current block and return the line number.
#TBD case:
# No
#============================= 
def gen_signal_delay_list (line_num, lines_list) :
    local_num = line_num
    local_reg_list = []
    signal_delay_list = []
    
    currline = lines_list[local_num].replace ('SIGNAL_DELAY', '', 1)
    currline = currline.replace('{', '', 1).lstrip()
    signal_delay_list.append(currline)
    
    sig_init_num = search_string('}', local_num, lines_list)
    while(local_num < sig_init_num) :
        local_num += 1 #next line.
        
        templine = remove_comment(lines_list[local_num]) 
        
        if ( len(templine.split()) > 1)  :  #is a signal statement.
            signal_name = templine.split()[0] 
            signal_init_val = templine.split()[1] 
            signal_width = int(templine.split()[1].split('\'')[0])
            delay_num = templine.split()[2] 
            for i in range(int(delay_num)) :
                new_signal_name = signal_name + '_dly{0}'.format(i+1)                 
                local_reg_list.append(signal_def_expr('reg', signal_width, new_signal_name, 1) )
            
            signal_delay_list.append(ALWAYS_SEQ_HEAD) 
            for i in range(int(delay_num)) :
                currline = INDENT_SP*2 + signal_name + '_dly{0}'.format(i+1) + ' <= ' + signal_init_val + ';\n'
                signal_delay_list.append(currline)
            
            signal_delay_list.append(ALWAYS_SEQ_MID) 
            currline = INDENT_SP*2 + signal_name + '_dly1' + ' <= ' + signal_name + ';\n'
            signal_delay_list.append(currline) 
            for i in range(int(delay_num) -1) :
                currline = INDENT_SP*2 + signal_name + '_dly{0}'.format(i+2) + ' <= ' + signal_name + '_dly{0}'.format(i+1) + ';\n'
                signal_delay_list.append(currline)
        
     
            signal_delay_list.append(ALWAYS_SEQ_END)  
                        
                        
        elif (( templine.strip() == '{') or (templine.strip() =='}'))  : # "   { //comments"  or "   } //comments"
            currline = lines_list[local_num].replace('{', ' ', 1).lstrip()
            currline = lines_list[local_num].replace('}', ' ', 1).lstrip()
            signal_delay_list.append(currline)
            
        else : # "  //comments"
            signal_delay_list.append(lines_list[local_num].lstrip())
            
    local_reg_list.append('\n')        
    return local_num, signal_delay_list, local_reg_list                
     
    
    
    
#=============================
#Function: search_signal_def (ivl_list)
#search wire and reg signal definition in whole list and return a signal list.
#TBD case:
# NO
#============================= 
def search_pre_def_signal (ivl_list) :
    pre_def_signal_list = []
    local_num = 0
    while(local_num < len(ivl_list)) :
        templine = remove_comment(ivl_list[local_num])            
        is_signal_def_line = (((templine.lstrip()[0:5] == 'wire ') \
                               or (templine.lstrip()[0:5] == 'wire[')\
                               )and ('=' not in templine)\
                              ) or ((templine.lstrip()[0:4] == 'reg ') \
                                    or (templine.lstrip()[0:4] == 'reg[') \
                                   )
        if (is_signal_def_line) :
            if ('[' in templine) : # width is not 1. has [num:0] inside
                signal_type = ivl_list[local_num].lstrip().split('[', 1)[0].strip()        
                signal_name = ivl_list[local_num].lstrip().split(']', 1)[1].strip() + '\n'
                signal_width = int(ivl_list[local_num].split(':', 1)[0].split('[', 1)[1]) + 1            
            else : #width is 1.
                signal_type = ivl_list[local_num].lstrip().split(' ', 1)[0].strip()        
                signal_name = ivl_list[local_num].lstrip().split(' ', 1)[1].strip() + '\n'
                signal_width =  1            
            pre_def_signal_list.append(signal_def_expr(signal_type, signal_width, signal_name, 0))
        
        local_num += 1
        
    return pre_def_signal_list

    
    
#=============================
#Function: adjust_port_signal_def_List
#remove duplicated definition and change direction of port if wrong.
#TBD case:
# NO
#============================= 
def adjust_port_signal_def_List (PortDefList, SignalDefList) :
    NewPortDefList = []
    NewSignalDefList = []
    oldlist = []
    
    #remove duplicated signal definition.
    local_num = 0
    while(local_num < len(SignalDefList)) :
        oldline = remove_comment(SignalDefList[local_num])     
        oldlist.append(oldline.replace(' ', '') ) 
        local_num += 1
    
    local_num = 0
    while(local_num < len(oldlist)) :
        if (oldlist[local_num] not in oldlist[local_num+1 :]) :
            NewSignalDefList.append(SignalDefList[local_num]) 
        local_num += 1
    
    #adjust the port definition.
    if (PortDefList != []) :        
        for i in range(0, len(PortDefList)) :
            for j in range(0, len(SignalDefList)) :
                if (PortDefList[i].split()[-1] in SignalDefList[j]) :
                    PortDefList[i] = PortDefList[i].replace('input ', 'output')
    

    #!!! I am confused by below code. which doesnt work as above. 
    #    i = 0
    #    j = 0
    #    while( i < len(PortDefList)) :
    #        while ( j < len(SignalDefList)) :
    #            if (PortDefList[i].split()[-1] in SignalDefList[j]) :
    #                PortDefList[i] = PortDefList[i].replace('input', 'output')
    #            j += 1
    #        i += 1
            
    return PortDefList, NewSignalDefList

    
    
    
#++++++++++++++++++++++++++++++++++++++++++++++++
#Function: gen_module_list(line_num, IvlLines)
# line_num: the begining line number to be parsed 
# IvlLines: a list of source code. line by line.
# the function will return next line number after the end of current module.
#++++++++++++++++++++++++++++++++++++++++++++++++ 
   
def gen_module_list(line_num, IvlLines) :

    local_num = line_num
    FileHeaderList = []
    ModuleDefList = []
    ParameterDefList = []
    PortDefList = []
    SignalDefList = []
    ModuleBodyList = []
    ModuleList = []
    pre_def_list = []
    
    module_end_num = search_string('ENDMODULE', local_num, IvlLines)
    if (module_end_num == len(IvlLines)) : #can't find the ENDMODULE untill to end of file.
        print ("Can't find Module after line-%d in current IVL file!" %(local_num))  
        module_end_num = len(IvlLines) -1
    
    #Parse the module definition    
    while (local_num <= module_end_num ) : #parse statement till to the end of module definition. 
    
        templine = remove_comment(IvlLines[local_num]) 
        if (templine.split() != []): 
            firstword = IvlLines[local_num].split()[0]
        else :
            firstword = ''
            
        if ('FILE_HEADER' == firstword):
            # generate module_port_list 
            local_num, FileHeaderList = gen_file_header_list (local_num, IvlLines)
            ModuleDefList.extend(FileHeaderList)
            
        elif ('MODULE' == firstword):
            # generate module_port_list 
            module_start_num = local_num
            local_num, ModulePortList, PortDefList = gen_module_port_list (local_num, IvlLines)
            ModuleDefList.extend(ModulePortList)
            local_num += 1
            break # end of module definition.
            
        else : # if any other orignal verilog statements, copy to verilog file.
            ModuleDefList.append (IvlLines[local_num])        
        local_num += 1
    
    #parse the module body    
    while (local_num <= module_end_num ) : #continue to parse statement till to the end of module. 
    
        templine = remove_comment(IvlLines[local_num]) 
        if (templine.split() != []): 
            firstword = templine.split()[0]
        else :
            firstword = ''
            
        if ('ASSIGN' == firstword): 
            # generate assign_state_list 
            [local_num, AssignStateList, LocalWireList] = gen_assign_state_list (local_num, IvlLines)
            ModuleBodyList.extend(AssignStateList)
            SignalDefList.extend(LocalWireList) 
            
        elif ('ALWAYS_COM' == firstword):
            # generate always_com_state_list 
            [local_num, AlwaysComList, LocalRegDef] = gen_always_com_list (local_num, IvlLines)
            ModuleBodyList.extend(AlwaysComList)
            SignalDefList.extend(LocalRegDef) 
            
        elif ('ALWAYS_SEQ'  == firstword):
            # generate always_seq_state_list 
            [local_num, AlwaysSeqList, LocalRegDef] = gen_always_seq_list (local_num, IvlLines)
            ModuleBodyList.extend(AlwaysSeqList)
            SignalDefList.extend(LocalRegDef) 
            
        elif ('SIGNAL_DELAY' == firstword):
            # generate signal_delay_list 
            [local_num, SignalDelayList, LocalRegDef] = gen_signal_delay_list (local_num, IvlLines)
            ModuleBodyList.extend(SignalDelayList)
            SignalDefList.extend(LocalRegDef)    
                                  
        # elif ('PARAMETER_DEF' == firstword):
             # generate parameter_list 
        #    [local_num, LocalParamList] = gen_parameter_def_list (local_num, IvlLines)
        #    ParameterDefList.extent(LocalParamList)
             # VerFile.writelines(SignalDelayList) # to be done later.
        
        # elif ('SGINAL_DEF'  firstword):
             # generate reg_wire_list 
             
        elif ('ENDMODULE'  == firstword ):
            # Post process and assembly the new VerilogHDL file.  
            pre_def_list = search_pre_def_signal(IvlLines[module_start_num : module_end_num])
            SignalDefList.extend(pre_def_list)
            NewPortDefList, NewSignalDefList = adjust_port_signal_def_List (PortDefList, SignalDefList)
            
            ModuleList.extend(ModuleDefList)  
            
            ParameterDefList.insert(0, PARA_DEF_DELIMITER)
            ModuleList.extend(ParameterDefList)

            NewPortDefList.insert(0, PORT_DEF_DELIMITER)
            ModuleList.extend(NewPortDefList)
            
            NewSignalDefList.insert(0, SIGNAL_DEF_DELIMITER)            
            ModuleList.extend(NewSignalDefList)
            
            ModuleBodyList.insert(0, BODY_DEF_DELIMITER)
            ModuleList.extend(ModuleBodyList) 
                                   
            currline = re.sub (r'ENDMODULE', "endmodule", IvlLines[local_num])            
            ModuleList.append(currline)                
            ModuleList.append(' \n')  
            local_num += 1 
            break
        
        else : # if Orignal verilog statements or comments line, copy to verilog file.
            ModuleBodyList.append(IvlLines[local_num])
        
        local_num += 1  
    return local_num, ModuleList
    
    
