python3 ./gen_reg_module.py G0_Dig_pin_20220707.xlsx
