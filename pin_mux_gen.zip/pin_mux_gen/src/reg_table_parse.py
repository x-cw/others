
#!/usr/bin/python
# -*- coding: UTF-8 -*- 
import xlrd
import re
import string
import sys
import math

from ivlconst import INDENT_SP
from ivl2verilog import  extract_width, signal_def_expr


__DESCRIPTION__ = '''
=====================================
# IVL - Improved VerilogHDL Language #
=====================================
//                                                                          
//  reg_table_parse.py - python code for parsing excel table.                              
//                                      
//                                                                          
//  This library is free software; you can redistribute it and/or           
//  modify it under the terms of the GNU Lesser General Public              
//  License as published by the Free Software Foundation; either            
//  version 2.1 of the License, or (at your option) any later version.      
//                                                                          
//  This library is distributed in the hope that it will be useful,         
//  but WITHOUT ANY WARRANTY; without even the implied warranty of          
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU       
//  Lesser General Public License for more details.                         
//                                                                          
//  Full details of the license can be found in the file LGPL.TXT.          
//                                                                          
//  You should have received a copy of the GNU Lesser General Public        
//  License along with this library; if not, write to the Free Software     
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
//                                                                          
'''

#search a key and return row and col number
def search_in_sheet(sheet, startrow = 0, startcol = 0, key = 'Mode 0') :
    row = startrow
    col = startcol
    flag = 0
        
    for row in range(startrow, sheet.nrows) :
        for col in range(startcol, sheet.ncols) :
            if (sheet.cell_type(row, col) == 1) and (key in sheet.cell(row, col).value) :
                rownum = row
                colnum = col
                flag = 1
                #print('The sheet:', key, sheet.cell(row, col).value, row,col)
                break
        else : #if go through all columns, continue on next row.
            continue
        break        
    else : #go through all rows, can't find the expected string.
        flag = 0 
        rownum = startrow
        colnum = startcol        
    return flag, rownum, colnum 

#check the format of register table.
def check_reg_table_format(sheet, row = 0, col = 0) :
#cell_type: 0(empty), 1(string), 2(number), 3(data), 4(boolean), 5(error) 
    pos1 = 1 #reg offset addr: should be a string.
    pos2 = 1 # reg name: should be a string.
    
    pos3 = 1
    pos4 = 1
    pos5 = 1
    pos6 = 1
    pos7 = 1
    nxtrow = row + 1 # at the begining of the register signal definition.
    cnt = 0
    
    while (1) :
        pos3 = pos3 and (sheet.cell_type(nxtrow, col) == 1) #Bit Num.:should be a string.
        #print('Format:', sheet.cell(nxtrow, col).value)
#        pos4 = pos4 and (sheet.cell_type(nxtrow, col+1) == 1) #Name: should be a string.
#        pos5 = pos5 and ((sheet.cell_type(nxtrow, col+2) == 1) or (sheet.cell_type(nxtrow, col+2) == 2)) #Reset: should be a string.
#        pos6 = pos6 and (sheet.cell_type(nxtrow, col+3) == 1) #Attr: should be a string.
#        pos7 = pos7 and (sheet.cell_type(nxtrow, col+4) == 1) #Function: should be a string.
        #HH:debug port to know line number
        if (not (pos1 and pos2 and pos3 and pos4 and pos5 and pos6 and pos7)) : print('###ERROR line###cnt=',cnt,"nxtrow=",nxtrow," content=",sheet.cell(nxtrow, col).value) 
        sheet_index =  sheet.nrows - 1
        if (nxtrow < sheet_index ) :
            cnt += 1
            nxtrow += 1
        else :
          reg_fmt = 0
          lastrow = nxtrow
          reg_fmt = pos1 and pos2 and pos3 and pos4 and pos5 and pos6 and pos7
          if (not reg_fmt) :
              print('FMT EEROR: The format of register table in the excel file is wrong!')
              print(pos1 , pos2 , pos3 , pos4 , pos5 , pos6 , pos7)
          break 
          #print('reg_fmt:', reg_fmt,lastrow)
        
    #print('reg_fmt:', reg_fmt,lastrow)
    return reg_fmt, lastrow   
    
    
    
#read out a register table.
#return a list[] of dict{}. the dict{} collects one row info of reg table. 
def read_a_reg_table(sheet, regcol = 0, key =  'Mode_0'):
    reg_dict = {}
    reg_dict_list_input = []
    reg_dict_list_output = []
    reg_dict_list_dname = []
    reg_dict_list_direction = []
    #reg_dict_list_function = []
    
    flag, row, col = search_in_sheet(sheet, 0, regcol, key)  
    if (flag) : 
        reg_fmt, lastrow = check_reg_table_format(sheet, row, col)
    else:
        lastrow = row
    #print('read_a_reg_table:',flag ,row, col ,reg_fmt)    
    if(flag and reg_fmt) : #find out a register table and format is right.    
        reg_dict_list_input.append( sheet.cell(row+1, col).value.strip())
        reg_dict_list_output.append( sheet.cell(row+1, col+1).value.strip())
        reg_dict_list_dname.append( sheet.cell(row+1, col+2).value.strip())
        reg_dict_list_direction.append( sheet.cell(row+1, col+3).value.strip())
        #reg_dict_list_function.append( sheet.cell(row+1, col+4).value.strip())
        #print('The Register table list:', reg_dict_list)
        nxtrow = row + 2
        while (nxtrow <= lastrow) :
          reg_dict_list_input.append(sheet.cell(nxtrow, col).value.strip())               
          reg_dict_list_output.append(sheet.cell(nxtrow, col+1).value.strip())                
          reg_dict_list_dname.append(sheet.cell(nxtrow, col+2).value.strip())                
          reg_dict_list_direction.append(sheet.cell(nxtrow, col+3).value.strip())                  
          #reg_dict_list_function.append(sheet.cell(nxtrow, col+4).value.strip())

            #reg_dict['Input Signal Name']  = sheet.cell(nxtrow, col).value.strip()                
            #reg_dict['Output Signal Name']  = sheet.cell(nxtrow, col+1).value.strip()                
            #reg_dict['Direction Signal Name']  = sheet.cell(nxtrow, col+2).value.strip()                
            #reg_dict['Direction'] = sheet.cell(nxtrow, col+3).value.strip()                  
            #reg_dict['Function'] = sheet.cell(nxtrow, col+4).value.strip()                  
            #
            #reg_dict_list.append(reg_dict) #add a dict into the list.
            #reg_dict = {} # if not clear, all old reg_dict appended to list will be replaced by  current one.
          nxtrow += 1
    else :
        lastrow = row    
    #print('The Register table list:', reg_dict_list_input, reg_dict_list_output, reg_dict_list_dname, reg_dict_list_direction,reg_dict_list_function)
    return lastrow, reg_dict_list_input, reg_dict_list_output, reg_dict_list_dname, reg_dict_list_direction 
    
    
#read out a register table.
#return a list[] of dict{}. the dict{} collects one row info of reg table. 
def read_top_table(sheet, regcol = 0, key =  'TOP_PADS'):
    reg_dict_list_input = []
    reg_dict_list_output = []
    reg_dict_list_oe = []
    
    flag, row, col = search_in_sheet(sheet, 0, regcol, key)  
    if (flag) : 
        reg_fmt, lastrow = check_reg_table_format(sheet, row, col)
        print (f'check reg table format pass: {regcol} and reg_fmt and lastrow is {reg_fmt}, {lastrow}')
    else:
        lastrow = row
        print (f'check reg table format fail: {regcol}')
    print('read_a_reg_table:',flag ,row, col ,reg_fmt)    
    if(flag and reg_fmt) : #find out a register table and format is right.    
        print ("find to top table")
        reg_dict_list_input.append( sheet.cell(row+1, col+1).value.strip())
        print (f"row: {row+1}, col: {col+1}, the value is {sheet.cell(row+1, col+1).value.strip()}")
        reg_dict_list_output.append( sheet.cell(row+1, col+2).value.strip())
        print (sheet.cell(row+1, col+2).value.strip())
        reg_dict_list_oe.append( sheet.cell(row+1, col+3).value.strip())
        print (sheet.cell(row+1, col+3).value.strip())
        #print('The Register table list:', reg_dict_list)
        nxtrow = row + 2
        while (nxtrow <= lastrow) :
          reg_dict_list_input.append(sheet.cell(nxtrow, col+1).value.strip())               
          print (f"row: {nxtrow}, col: {col+1}, the value is {sheet.cell(nxtrow, col+1)}")
          reg_dict_list_output.append(sheet.cell(nxtrow, col+2).value.strip())                
          reg_dict_list_oe.append(sheet.cell(nxtrow, col+3).value.strip())                
          nxtrow += 1
    else :
        lastrow = row    
    #print('The Register table list:', reg_dict_list_input, reg_dict_list_output, reg_dict_list_dname, reg_dict_list_direction,reg_dict_list_function)
    return lastrow, reg_dict_list_input, reg_dict_list_output, reg_dict_list_oe
    
    

def  gen_a_reg_code (reg_dict_list_input, reg_dict_list_output, reg_dict_list_dname, reg_dict_list_direction, active_oe, key = 'Mode_0') :
    port_signal_list  = [] 
    port_oe_list  = [] 
    port_input_list     = []
    port_input_name     = []
    port_output_list     = []
    gen_pads_oe = []
    gen_pads_in = []
    gen_pads_out = []
    gen_pads_iname = []
    pads_oe = []
    pads_in = []
    pads_out = []
    pads_default_oe = []
    pads_default_in = []
    pads_default_out = []
    pads_oe_alist = []
    pads_out_alist = []
    pads_in_alist = []
    inout_pname = []
    wire_pname = []
    input_name_init = []

    #generate port signal list
    if(key == 'Mode_2'):
      for i in range(0, len(reg_dict_list_input)): #process data row by row
        #print("Mode_2" + str(i) +" reg_dict_list_in:" + reg_dict_list_input[i]) 
        #print("Mode_2" + str(i) +" reg_dict_list_out:" + reg_dict_list_output[i]) 
        #print("Mode_2" + str(i) +" reg_dict_list_direction:" + reg_dict_list_direction[i]) 
        #print("\r\n") 
        if(i < 8):
          input_signal_name = reg_dict_list_input[i]
          output_signal_name = reg_dict_list_output[i]
          direction_signal_name = reg_dict_list_dname[i]
          direction         = reg_dict_list_direction[i]
          #port_name = reg_dict_list_pname[i] 

          if (direction == 'input'):
            port_signal_list.append (input_signal_name) 
            port_input_list.append(input_signal_name)
            port_output_list.append('1\'b0')
            port_input_name.append(input_signal_name)
            input_name_init.append(input_signal_name)
            #input_name_init.append('\n' + INDENT_SP*2 + input_signal_name + INDENT_SP*2 + '= 1\'b0;')
            #inout_pname.append('output reg ' + INDENT_SP + input_signal_name + ';\n')
            inout_pname.append('output ' + INDENT_SP + input_signal_name + ';\n')
            if(repr(active_oe == 1)):
              port_oe_list.append('1\'b0')
            else:  
              port_oe_list.append('1\'b1')
          elif (direction == 'output'):
            port_signal_list.append (output_signal_name)     
            port_output_list.append(output_signal_name)
            port_input_list.append('1\'b0')
            port_input_name.append('Mode_Null_In[' + str(i-1) + ']')
            inout_pname.append('input' + INDENT_SP + output_signal_name + ';\n')
            if(repr(active_oe == 1)):
              port_oe_list.append('1\'b1')
            else:  
              port_oe_list.append('1\'b0')
          elif  (direction == 'inout'):
            if(direction_signal_name == 'null'):
              print('\n\nERROR!!! Inout Port Should Provide Direction Signal Name \n\n')
              sys.exit()
            else:  
              port_signal_list.append (input_signal_name) 
              port_input_list.append(input_signal_name)
              port_signal_list.append (output_signal_name)     
              port_output_list.append(output_signal_name)
              port_oe_list.append(direction_signal_name)
              port_input_name.append(input_signal_name)
              input_name_init.append(input_signal_name)
              #input_name_init.append('\n' + INDENT_SP*2 + input_signal_name + INDENT_SP*2 + '= 1\'b0;')
              #inout_pname.append('output reg ' + INDENT_SP + input_signal_name + ';\n')
              inout_pname.append('output ' + INDENT_SP + input_signal_name + ';\n')
              inout_pname.append('input'  + INDENT_SP + output_signal_name + ';\n')
          elif (direction == 'null'):
            port_input_list.append('1\'b0')
            port_output_list.append('1\'b0')
            port_input_name.append('Mode_Null_In[' + str(i-1) + ']')
            if(repr(active_oe == 1)):
              port_oe_list.append('1\'b0')
            else:  
              port_oe_list.append('1\'b1')
          print (f"mode2: {input_signal_name} {output_signal_name} {direction_signal_name} {direction}") 
        else:
          input_signal_name = reg_dict_list_input[i]
          output_signal_name = reg_dict_list_output[i]
          direction_signal_name = reg_dict_list_dname[i]
          direction         = reg_dict_list_direction[i]
          #port_name = reg_dict_list_pname[i] 

          if (direction == 'input'):
            port_signal_list.append (input_signal_name) 
            port_input_list.append(input_signal_name)
            port_output_list.append('1\'b0')
            port_input_name.append(input_signal_name)
            #input_name_init.append('\n' + INDENT_SP*2 + input_signal_name + INDENT_SP*2 + '= 1\'b0;')
            input_name_init.append(input_signal_name)
            wire_pname.append('reg' + INDENT_SP + input_signal_name + ';\n')
            if(repr(active_oe == 1)):
              port_oe_list.append('1\'b0')
            else:  
              port_oe_list.append('1\'b1')
          elif (direction == 'output'):
            port_signal_list.append (output_signal_name)     
            port_output_list.append(output_signal_name)
            port_input_list.append('1\'b0')
            port_input_name.append('Mode_Null_In[' + str(i-1) + ']')
            wire_pname.append('reg' + INDENT_SP + output_signal_name + ';\n')
            if(repr(active_oe == 1)):
              port_oe_list.append('1\'b1')
            else:  
              port_oe_list.append('1\'b0')
          elif  (direction == 'inout'):
            if(direction_signal_name == 'null'):
              print('\n\nERROR!!! Inout Port Should Provide Direction Signal Name \n\n')
              sys.exit()
            else:  
              port_signal_list.append (input_signal_name) 
              port_input_list.append(input_signal_name)
              port_signal_list.append (output_signal_name)     
              port_output_list.append(output_signal_name)
              port_oe_list.append(direction_signal_name)
              port_input_name.append(input_signal_name)
              #input_name_init.append('\n' + INDENT_SP*2 + input_signal_name + INDENT_SP*2 + '= 1\'b0;')
              input_name_init.append(input_signal_name)
              wire_pname.append('reg' + INDENT_SP + input_signal_name + ';\n')
              wire_pname.append('reg'  + INDENT_SP + output_signal_name + ';\n')
          elif (direction == 'null'):
            port_input_list.append('1\'b0')
            port_output_list.append('1\'b0')
            port_input_name.append('Mode_Null_In[' + str(i-1) + ']')
            if(repr(active_oe == 1)):
              port_oe_list.append('1\'b0')
            else:  
              port_oe_list.append('1\'b1')
      #print("Mode_2 inout_pname:" + str(inout_pname)) 
    else:  
      for i in range(0, len(reg_dict_list_input)): #process data row by row
          input_signal_name = reg_dict_list_input[i]
          output_signal_name = reg_dict_list_output[i]
          direction_signal_name = reg_dict_list_dname[i]
          direction         = reg_dict_list_direction[i]
          #port_name = reg_dict_list_pname[i] 

          if (direction == 'input'):
            port_signal_list.append (input_signal_name) 
            port_input_list.append(input_signal_name)
            port_output_list.append('1\'b0')
            port_input_name.append(input_signal_name)
            #input_name_init.append('\n' + INDENT_SP*2 + input_signal_name + INDENT_SP*2 + '= 1\'b0;')
            input_name_init.append(input_signal_name)
            #inout_pname.append('output reg ' + INDENT_SP + input_signal_name + ';\n')
            inout_pname.append('output ' + INDENT_SP + input_signal_name + ';\n')
            if(repr(active_oe == 1)):
              port_oe_list.append('1\'b0')
            else:  
              port_oe_list.append('1\'b1')
          elif (direction == 'output'):
            port_signal_list.append (output_signal_name)     
            port_output_list.append(output_signal_name)
            port_input_list.append('1\'b0')
            port_input_name.append('Mode_Null_In[' + str(i-1) + ']')
            inout_pname.append('input' + INDENT_SP + output_signal_name + ';\n')
            if(repr(active_oe == 1)):
              port_oe_list.append('1\'b1')
            else:  
              port_oe_list.append('1\'b0')
          elif  (direction == 'inout'):
            if(direction_signal_name == 'null'):
              print('\n\nERROR!!! Inout Port Should Provide Direction Signal Name \n\n')
              sys.exit()
            else:  
              port_signal_list.append (input_signal_name) 
              port_input_list.append(input_signal_name)
              port_signal_list.append (output_signal_name)     
              port_output_list.append(output_signal_name)
              port_oe_list.append(direction_signal_name)
              port_input_name.append(input_signal_name)
              #input_name_init.append('\n' + INDENT_SP*2 + input_signal_name + INDENT_SP*2 + '= 1\'b0;')
              input_name_init.append(input_signal_name)
              #inout_pname.append('output reg ' + INDENT_SP + input_signal_name + ';\n')
              inout_pname.append('output ' + INDENT_SP + input_signal_name + ';\n')
              inout_pname.append('input'  + INDENT_SP + output_signal_name + ';\n')
              inout_pname.append('input'  + INDENT_SP + direction_signal_name + ';\n')

          elif (direction == 'null'):
            port_input_list.append('1\'b0')
            port_output_list.append('1\'b0')
            port_input_name.append('Mode_Null_In[' + str(i-1) + ']')
            if(repr(active_oe == 1)):
              port_oe_list.append('1\'b0')
            else:  
              port_oe_list.append('1\'b1')
    
            print("direction Null")

    #print('port:', port_signal_list,'\n', 'dir:', port_oe_list, '\n', 'input:',port_input_list, '\n','output:',port_output_list)       
    for i in range(0, len(port_oe_list)): #process data row by row
      if(i < len(port_oe_list) - 1):
        gen_pads_in.append(INDENT_SP*2 + port_input_list[i] + ',\n')
        gen_pads_out.append(INDENT_SP*2 + port_output_list[i] + ',\n')
        gen_pads_oe.append(INDENT_SP*2 + port_oe_list[i] + ',\n')
        gen_pads_iname.append(INDENT_SP*2 + port_input_name[i] + ',\n')
      else:
        gen_pads_in.append(INDENT_SP*2 + port_input_list[i])
        gen_pads_out.append(INDENT_SP*2 + port_output_list[i])
        gen_pads_oe.append(INDENT_SP*2 + port_oe_list[i])
        gen_pads_iname.append(INDENT_SP*2 + port_input_name[i])

    if(key == 'Mode_0'): 
        input_signal = "".join(gen_pads_in)
        input_name = "".join(gen_pads_iname)
        output_signal = "".join(gen_pads_out)
        oe_signal = "".join(gen_pads_oe)
        pads_default_oe.append ( '\n  pads_oe = {\n' + oe_signal + '};\n ') 
        pads_default_out.append ( '\n  pads_o = {\n' + output_signal + '};\n ') 
        pads_default_in.append ('\n {\n' + input_name + ' } = pads_i;\n ') 	
        #input_name_init.append('\n' + INDENT_SP*2 + input_name + INDENT_SP*2 + '== 1\'b0;\n')
        pads_oe.append ( '3\'d0: begin \n  pads_oe = {\n' + oe_signal + '};\n  end \n ') 
        pads_out.append ( '3\'d0: begin \n  pads_o = {\n' + output_signal + '};\n  end \n ') 
        pads_in.append ('3\'d0 :  begin \n {\n' + input_name + ' } = pads_i;\n end \n ') 	
        #print('Mode 0: input:', pads_in,'\n', 'oe:', pads_oe, '\n', 'out:',pads_out)       
    elif(key == 'Mode_1'): 
        input_signal = "".join(gen_pads_in)
        input_name = "".join(gen_pads_iname)
        #input_name_init.append('\n' + INDENT_SP*2 + input_name + INDENT_SP*2 + '== 1\'b0;\n')
        output_signal = "".join(gen_pads_out)
        oe_signal = "".join(gen_pads_oe)
        pads_oe.append ( '3\'d1: begin \n  pads_oe = {\n' + oe_signal + '};\n  end \n ') 
        pads_out.append ( '3\'d1: begin \n  pads_o = {\n' + output_signal + '};\n  end \n ') 
        pads_in.append ('3\'d1 : begin \n  {\n' + input_name + ' } = pads_i;\n end \n ') 	
        #print('Mode 1: input:', pads_in,'\n', 'oe:', pads_oe, '\n', 'out:',pads_out)      
    elif(key == 'Mode_2'): 
        input_signal = "".join(gen_pads_in)
        input_name = "".join(gen_pads_iname)
        #input_name_init.append('\n' + INDENT_SP*2 + input_name + INDENT_SP*2 + '== 1\'b0;\n')
        output_signal = "".join(gen_pads_out)
        oe_signal = "".join(gen_pads_oe)
        pads_oe.append ( '3\'d2: begin \n  pads_oe = {\n' + oe_signal + '};\n  end \n ') 
        pads_out.append ( '3\'d2: begin \n  pads_o = {\n' + output_signal + '};\n  end \n ') 
        pads_in.append ('3\'d2 : begin \n  {\n' + input_name + ' } = pads_i;\n end \n ') 	
        #print('Mode 2: input:', pads_in,'\n', 'oe:', pads_oe, '\n', 'out:',pads_out)      
    elif(key == 'Mode_3'): 
        input_signal = "".join(gen_pads_in)
        input_name = "".join(gen_pads_iname)
        #input_name_init.append('\n' + INDENT_SP*2 + input_name + INDENT_SP*2 + '== 1\'b0;\n')
        output_signal = "".join(gen_pads_out)
        oe_signal = "".join(gen_pads_oe)
        pads_oe.append ( '3\'d3: begin \n  pads_oe = {\n' + oe_signal + '};\n  end \n ') 
        pads_out.append ( '3\'d3: begin \n  pads_o = {\n' + output_signal + '};\n end \n  ') 
        pads_in.append ('3\'d3 : begin \n  {\n' + input_name + ' } = pads_i;\n end \n ') 	
        #print('Mode 3: input:', pads_in,'\n', 'oe:', pads_oe, '\n', 'out:',pads_out)      
    elif(key == 'Mode_4'): 
        input_signal = "".join(gen_pads_in)
        input_name = "".join(gen_pads_iname)
        #input_name_init.append('\n' + INDENT_SP*2 + input_name + INDENT_SP*2 + '== 1\'b0;\n')
        output_signal = "".join(gen_pads_out)
        oe_signal = "".join(gen_pads_oe)
        pads_oe.append ( '3\'d4:  begin \n pads_oe = {\n' + oe_signal + '};\n  end \n ') 
        pads_out.append ( '3\'d4: begin \n  pads_o = {\n' + output_signal + '};\n  end \n ') 
        pads_in.append ('3\'d4 : begin \n  {\n' + input_name + ' } = pads_i;\n  end \n') 	
        #print('Mode 4: input:', pads_in,'\n', 'oe:', pads_oe, '\n', 'out:',pads_out)      
    elif(key == 'Mode_5'): 
        input_signal = "".join(gen_pads_in)
        input_name = "".join(gen_pads_iname)
        #input_name_init.append('\n' + INDENT_SP*2 + input_name + INDENT_SP*2 + '== 1\'b0;\n')
        output_signal = "".join(gen_pads_out)
        oe_signal = "".join(gen_pads_oe)
        pads_oe.append ( '3\'d5: begin \n  pads_oe = {\n' + oe_signal + '};\n  end \n') 
        pads_out.append ( '3\'d5: begin \n  pads_o = {\n' + output_signal + '};\n  end \n') 
        pads_in.append ('3\'d5 : begin \n  {\n' + input_name + ' } = pads_i;\n end \n') 	
        #print('Mode 5: input:', pads_in,'\n', 'oe:', pads_oe, '\n', 'out:',pads_out)      
    elif(key == 'Mode_6'): 
        input_signal = "".join(gen_pads_in)
        input_name = "".join(gen_pads_iname)
        #input_name_init.append('\n' + INDENT_SP*2 + input_name + INDENT_SP*2 + '== 1\'b0;\n')
        output_signal = "".join(gen_pads_out)
        oe_signal = "".join(gen_pads_oe)
        pads_oe.append ( '3\'d6: begin \n  pads_oe = {\n' + oe_signal + '};\n  end \n') 
        pads_out.append ( '3\'d6: begin \n  pads_o = {\n' + output_signal + '}; \n end \n') 
        pads_in.append ('3\'d6 : begin \n  {\n' + input_name + ' } = pads_i;\n end \n') 	
        #print('Mode 6: input:', pads_in,'\n', 'oe:', pads_oe, '\n', 'out:',pads_out)      
    elif(key == 'Mode_7'): 
        input_signal = "".join(gen_pads_in)
        input_name = "".join(gen_pads_iname)
        #input_name_init.append('\n' + INDENT_SP*2 + input_name + INDENT_SP*2 + '== 1\'b0;\n')
        output_signal = "".join(gen_pads_out)
        oe_signal = "".join(gen_pads_oe)
        pads_oe.append ( '3\'d7: begin \n pads_oe = {\n' + oe_signal + '};\n end\n ') 
        pads_out.append ( '3\'d7: begin \n pads_o = {\n' + output_signal + '};\n end \n') 
        pads_in.append ('3\'d7 : begin \n {\n' + input_name + ' } = pads_i;\n end \n') 	

        #print('Mode 7: input:', pads_in,'\n', 'oe:', pads_oe, '\n', 'out:',pads_out)      
    elif(key == 'Mode_8'): 
        input_signal = "".join(gen_pads_in)
        input_name = "".join(gen_pads_iname)
        #input_name_init.append('\n' + INDENT_SP*2 + input_name + INDENT_SP*2 + '== 1\'b0;\n')
        output_signal = "".join(gen_pads_out)
        oe_signal = "".join(gen_pads_oe)
        pads_oe.append ( '3\'d8: begin \n pads_oe = {\n' + oe_signal + '};\n end\n ') 
        pads_out.append ( '3\'d8: begin \n pads_o = {\n' + output_signal + '};\n end \n') 
        pads_in.append ('3\'d8 : begin \n {\n' + input_name + ' } = pads_i;\n end \n') 	

        #print('Mode 8: input:', pads_in,'\n', 'oe:', pads_oe, '\n', 'out:',pads_out)      
    elif(key == 'Mode_9'): 
        input_signal = "".join(gen_pads_in)
        input_name = "".join(gen_pads_iname)
        #input_name_init.append('\n' + INDENT_SP*2 + input_name + INDENT_SP*2 + '== 1\'b0;\n')
        output_signal = "".join(gen_pads_out)
        oe_signal = "".join(gen_pads_oe)
        pads_oe.append ( '3\'d9: begin \n pads_oe = {\n' + oe_signal + '};\n end\n ') 
        pads_out.append ( '3\'d9: begin \n pads_o = {\n' + output_signal + '};\n end \n') 
        pads_in.append ('3\'d9 : begin \n {\n' + input_name + ' } = pads_i;\n end \n') 	

        #print('Mode 9: input:', pads_in,'\n', 'oe:', pads_oe, '\n', 'out:',pads_out)      

    #pads_oe_alist.append(pads_oe)
    #pads_out_alist.append(pads_out)
    #pads_in_alist.append(pads_in)
    pads_default_oe_str = "".join(pads_default_oe)
    pads_default_out_str = "".join(pads_default_out)
    pads_default_in_str = "".join(pads_default_in)
    pads_oe_str = "".join(pads_oe)
    pads_out_str = "".join(pads_out)
    pads_in_str = "".join(pads_in)
    inout_pname_str = "".join(inout_pname)
    wire_name_str = "".join(wire_pname)
    #input_name_init_str = "".join(input_name_init)
    #print('input:', pads_in_str,'\n', 'oe:', pads_oe_str, '\n', 'out:',pads_out_str)      
    #return pads_oe_alist, pads_out_alist, pads_in_alist 
    #print('inout:', inout_pname_str)      
    return pads_oe_str, pads_out_str, pads_in_str, inout_pname_str, wire_name_str, pads_default_oe_str, pads_default_out_str, pads_default_in_str, input_name_init
    
def gen_scan_chain(scan_in_len, scan_out_len, scan_grp_len):
#  scan_seq_in_list = []
#  scan_seq_out_list = []
#  scan_seq_grp_list = []
#  scan_seq_init_in_list = []
#  scan_seq_init_out_list = []
  scan_comb_out_list = []
  scan_comb_in_list = []
  scan_comb_init_out_list = []
  scan_comb_init_in_list = []
  scan_comb_init_list = []
  scan_comb_list = []
#  scan_seq_init_list = []
#  scan_seq_list = []
  scan_port_list = []
  scan_reg_def_list = []
  reg_def_list = []
  #for i in range(0, int(scan_in_len)):
    #scan_seq_in_list.append(INDENT_SP*2 + '{scan_in_' + repr(i) + '_d1, scan_in_' + repr(i) + '_d0} <= {scan_in_' + repr(i) + '_d0, scan_in_' + repr(i) + '_i};\n')
    #scan_reg_def_list.append('reg' + INDENT_SP*2 + 'scan_in_' + repr(i) + '_d0;\n' )
    #scan_reg_def_list.append('reg' + INDENT_SP*2 + 'scan_in_' + repr(i) + '_d1;\n' )
    #scan_reg_def_list.append('reg' + INDENT_SP*2 + 'scan_out_' + repr(i) + '_d1;\n' )
    #scan_reg_def_list.append('reg' + INDENT_SP*2 + 'scan_out_' + repr(i) + '_d0;\n' )
    #scan_seq_init_in_list.append(INDENT_SP*2 + 'scan_in_' + repr(i) + '_d0 <= 1\'b0;\n')
    #scan_seq_init_in_list.append(INDENT_SP*2 + 'scan_in_' + repr(i) + '_d1 <= 1\'b0;\n')
#  for i in range(0, int(scan_out_len)):
    #scan_seq_out_list.append(INDENT_SP*2 + '{scan_out_' + repr(i) + '_o, scan_out_' + repr(i) + '_d1} <= {scan_out_' + repr(i) + '_d1, scan_out_' + repr(i) + '_d0};\n')
    #scan_seq_init_out_list.append(INDENT_SP*2 + 'scan_out_' + repr(i) + '_o <= 1\'b0;\n')
    #scan_seq_init_out_list.append(INDENT_SP*2 + 'scan_out_' + repr(i) + '_d1 <= 1\'b0;\n')
    #scan_comb_init_out_list.append(INDENT_SP*2 + 'scan_out_' + repr(i) + ' = 1\'b0;\n')
  scan_width = int(math.log2(int(scan_grp_len))) 
  scan_grp = int(scan_grp_len)
  if (scan_grp > 1):
    for i in range(0, int(scan_grp_len)):
      scan_comb_out_list.append(repr(scan_width) + '\'d' + repr(i) + ': begin \n')
      for j in range(0, int(scan_out_len)):
        scan_comb_out_list.append(INDENT_SP*2 + 'scan_out_' + repr(j) + '_o = ' + 'scan_out_' + repr(j) + '_grp' + repr(i) + ';\n')
        #scan_comb_out_list.append(INDENT_SP*2 + 'scan_in_' + repr(j) + '_grp' + repr(i) + ' = ' + 'scan_in_' + repr(j) + '_d1;\n')
        #scan_comb_init_in_list.append(INDENT_SP*2 + 'scan_in_' + repr(j) + '_grp' + repr(i) + ' = 1\'b0;\n')
        #scan_port_list.append('output reg ' + INDENT_SP + 'scan_in_' + repr(j) + '_grp' + repr(i)+ ';\n')
        #scan_port_list.append('output ' + INDENT_SP + 'scan_in_' + repr(j) + '_grp' + repr(i)+ ';\n')
        scan_port_list.append('input ' + INDENT_SP + 'scan_out_' + repr(j) + '_grp' + repr(i) + ';\n')
      for k in range(0, int(scan_in_len)):
        #scan_comb_out_list.append(INDENT_SP*2 + 'scan_out_' + repr(j) + '_d0 = ' + 'scan_out_' + repr(j) + '_grp' + repr(i) + ';\n')
        scan_comb_out_list.append(INDENT_SP*2 + 'scan_in_' + repr(k) + '_grp' + repr(i) + ' = ' + 'scan_in_' + repr(k) + '_i;\n')
        scan_comb_init_in_list.append(INDENT_SP*2 + 'scan_in_' + repr(k) + '_grp' + repr(i) + ' = 1\'b0;\n')
        #scan_port_list.append('output reg ' + INDENT_SP + 'scan_in_' + repr(j) + '_grp' + repr(i)+ ';\n')
        scan_port_list.append('output ' + INDENT_SP + 'scan_in_' + repr(k) + '_grp' + repr(i)+ ';\n')
        #scan_port_list.append('input wire ' + INDENT_SP + 'scan_out_' + repr(j) + '_grp' + repr(i) + ';\n')
      #scan_comb_out_list.append('end \n')
    
      scan_comb_out_list.append('end \n')

      #scan_comb_out_list.append(scan_comb_in_list)
  else :
      for j in range(0, int(scan_out_len)):
        scan_comb_out_list.append(INDENT_SP*2 + 'assign scan_out_' + repr(j) + '_o = ' + 'scan_out_' + repr(j) + ';\n')
        scan_port_list.append('input ' + INDENT_SP + 'scan_out_' + repr(j) + ';\n')
      for k in range(0, int(scan_in_len)):
        scan_comb_out_list.append(INDENT_SP*2 + 'assign scan_in_' + repr(k) + ' = ' + 'scan_in_' + repr(k) + '_i;\n')
        scan_port_list.append('output ' + INDENT_SP + 'scan_in_' + repr(k) + ';\n')
      #scan_comb_out_list.append('end \n')

  #scan_seq_init_in_str = "".join(scan_seq_init_in_list)
  #scan_seq_init_out_str = "".join(scan_seq_init_out_list)
  #scan_seq_in_str = "".join(scan_seq_in_list)
  #scan_seq_out_str = "".join(scan_seq_out_list)
  scan_comb_init_in_str = "".join(scan_comb_init_in_list)
  scan_comb_init_out_str = "".join(scan_comb_init_out_list)
  scan_comb_out_str = "".join(scan_comb_out_list)
  scan_port_str = "".join(scan_port_list)
  #scan_reg_def_str = "".join(scan_reg_def_list)
  scan_comb_init_list.append(scan_comb_init_in_str)
  scan_comb_init_list.append(scan_comb_init_out_str)
  #scan_seq_init_list.append(scan_seq_init_in_str)
  #scan_seq_init_list.append(scan_seq_init_out_str)
  #scan_comb_list.append(scan_comb_in_str)
  scan_comb_list.append(scan_comb_out_str)
  #scan_seq_list.append(scan_seq_in_str)
  #scan_seq_list.append(scan_seq_out_str)
  #reg_def_list.append(scan_reg_def_str)
  #print("scan_port_list:" + scan_port_str)
  #print('gen_scan_chain: ',scan_seq_init_list,  scan_seq_list, scan_comb_init_list , scan_comb_list)
  #return  scan_comb_init_list, scan_seq_init_list, scan_comb_list, scan_seq_list, scan_port_str, reg_def_list
  return  scan_comb_init_list, scan_comb_list, scan_port_str 


    
def deal_repeat_list(list_del_repeat, original_list):
  for i in original_list:
    if i not in list_del_repeat:
      list_del_repeat.append(i)
  #print('list_del_repeat:', original_list, list_del_repeat)
  return list_del_repeat 
 
 
