
__DESCRIPTION__ = '''
=====================================
# IVL - Improved VerilogHDL Language #
=====================================
//                                                                          
//  reg_table_parse.py - python code for parsing excel table.                              
//                                      
//                                                                          
//  This library is free software; you can redistribute it and/or           
//  modify it under the terms of the GNU Lesser General Public              
//  License as published by the Free Software Foundation; either            
//  version 2.1 of the License, or (at your option) any later version.      
//                                                                          
//  This library is distributed in the hope that it will be useful,         
//  but WITHOUT ANY WARRANTY; without even the implied warranty of          
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU       
//  Lesser General Public License for more details.                         
//                                                                          
//  Full details of the license can be found in the file LGPL.TXT.          
//                                                                          
//  You should have received a copy of the GNU Lesser General Public        
//  License along with this library; if not, write to the Free Software     
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
//                                                                          
'''



#========================================
# CONSTANT declaration
#========================================
INDENT_SP = ' '*4

FILEHEADER = '''\
//************************************************************************//
//PODES:    Processor Optimization for Deeply Embedded System                                                                 
//Web:      http://www.mcucore.org                        
//Bug report: podes.mcu@qq.com                                                                          
//Q_Q:        1740507106         
//************************************************************************//
//                                                                          
//  AMY_M0O - A demo MCU based on PODES_M0O Core                              
//  Copyright (C) 2013 PODES and www.mcucore.org                                      
//                                                                  
//************************************************************************//
// File        : ahb2apb.v
// Author      : PODES
// Date        : 20131111
// Version     : 1.0
// Description : AHB to APB bus bridge module.
//
// -----------------------------History-----------------------------------//
// Date      BY   Version  Change Description
//
// 20131111  PODES   1.0      Initial Release. 
//                                                                        
//************************************************************************//
// --- CVS information:
// ---    $Author: $
// ---    $Revision: $
// ---    $Id: $
// ---    $Log$ 
//
//************************************************************************//


'''

ALWAYS_SEQ_HEAD = '''\
always @(posedge clk or negedge rst_n) 
begin   
    if(!rst_n)
    begin
'''

ALWAYS_SEQ_MID = '''\
    end
    else
    begin
'''

ALWAYS_SEQ_END = '''\
    end  
end  
'''

ALWAYS_COM_HEAD ='''\
always @(*)
begin
'''


PARA_DEF_DELIMITER = '''\

 

 
//-----------------------------------------------------------//
//                      PARAMETERS                           //
//-----------------------------------------------------------// 
            
'''

PORT_DEF_DELIMITER = '''\

 

 
//-----------------------------------------------------------//
//                      INPUTS/OUTPUTS                       //
//-----------------------------------------------------------// 
            
'''

SIGNAL_DEF_DELIMITER = '''\



            
//-----------------------------------------------------------//
//                      WIRES/REGS                           //
//-----------------------------------------------------------// 
            
'''

BODY_DEF_DELIMITER = '''\

 

 
//-----------------------------------------------------------//
//                      ARCHITECTURE                         //
//-----------------------------------------------------------// 
            
'''



#==================================
#Below constant related to BUS interface
# and register.
#==================================

BUS_IF_APBSLV = '''
module %s (  %s  );
             
//-----------------------------------------------------------//
//                          PARAMETERS                       //
//-----------------------------------------------------------//
localparam DIG_PAD_NUM = %s ;
//

//-----------------------------------------------------------//
//                          REG_ADDRESS_DEFINEs              //
//-----------------------------------------------------------//

%s

//-----------------------------------------------------------//
//                      INPUTS/OUTPUTS                       //
//-----------------------------------------------------------//  
             
%s
//input [4:0] scan_grp_sel;
//output      dft_edt_clk;
//output      dft_test_clk_for_occ;
output      dft_normal_mode;           
output      dft_mbist_mode;             
output      dft_scan_mode;             
output      dft_pll_test_mode0;         
output      dft_pll_test_mode1;         
//output      dft_ip_test_mode0;    
output      dft_normal_debug_monitor_mode; 
output      dft_normal_debug_cpu_mode; 

//-----------------------------------------------------------//
//                    REGISTERS & WIRES                      //
//-----------------------------------------------------------//

wire                   scan_grp_sel = 1'b0;
reg  [DIG_PAD_NUM-1:0] Mode_Null_In;
reg  [DIG_PAD_NUM-1:0] pads_oe;
reg  [DIG_PAD_NUM-1:0] pads_i;
reg  [DIG_PAD_NUM-1:0] pads_o;
wire [2:0] pads_chip_modes;

/*autoreg*/
/*autowire*/

//chip modes 
assign  pads_chip_modes                 = {pad_mode_sel2_i, pad_mode_sel1_i, pad_mode_sel0_i};
assign  dft_normal_mode                 = pads_chip_modes ==  3'b000 ;
assign  dft_mbist_mode                  = pads_chip_modes ==  3'b001 ;
assign  dft_scan_mode                   = pads_chip_modes ==  3'b010 ;
assign  dft_pll_test_mode0              = pads_chip_modes ==  3'b011 ;
assign  dft_pll_test_mode1              = pads_chip_modes ==  3'b100 ;
//assign  dft_ip_test_mode0               = pads_chip_modes ==  3'b101 ;
assign  dft_normal_debug_monitor_mode   = pads_chip_modes ==  3'b101 ;
assign  dft_normal_debug_cpu_mode       = pads_chip_modes ==  3'b110 ;

//-----------------------------------------------------------//
//                          ARCHITECTURE                     //
//-----------------------------------------------------------//  


'''

WRITE_REG_BLOCK = '''
//========================
//scan chain operation to registers
//========================
always @ (posedge dft_test_clk_i or posedge edt_reset_i)
begin
if(edt_reset_i)
begin 
%s
end else
begin 
%s
end
end  
      
'''


ALWAYS_COM_BLOCK = '''
//========================
//mode sel operation 
//========================
always @(*) begin
%s    
case(%s)
%s        
endcase
end

'''

PULSE_TRIG_BLOCK = '''
//========================
//Generate trigger pulse
//========================
always @(posedge clk or negedge rst_n) 
begin   
    if(!rst_n)
    begin 
%s    end
    else
    begin 
%s    end  
end  


'''

ASSIGN_CROSS_BLOCK = '''
//========================
//Generate assign  
//========================

%s
'''

INPUT_SYNC_BLOCK = '''
//========================
//Sync up reg/wire signals for all RO type
//========================

%s
'''

INNER_REG_BLOCK = '''
//========================
//generate an inner register
//e.g: write-1 clear, triger set high.
//========================
%s
always @ (posedge clk or negedge rst_n)
begin
    if(!rst_n)
    begin 
%s    end
    else  
    begin 
%s    end
end  
      
'''

DONT_TOUCH_BUFF_BLOCK = '''
//========================
//dont touch BUFF block
//========================

BUFH_X1N_A9PP84TR_C16 %s (
.Y     (%s),
.A     (%s) 
);
'''

DONT_TOUCH_ICG_BLOCK = '''
//========================
//dont touch ICG block
//========================

PREICG_X4R_A9PP84TR_C16 %s (
.ECK   (%s), 
.CK    (%s), 
.E     (%s), 
.SE    (%s)
);
'''
