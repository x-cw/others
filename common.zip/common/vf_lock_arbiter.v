//+FHDR*************************************************************************
// 
//   Copyright (c) 2022 Innosilicon. Ltd.  All rights reserved. 
// 
//   THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF INNOSILICON
//   The copyright notice above does not evidence any actual or intended
//   publication of such source code.
// 
//************************************************************************
//    Module name: vf_lock_arb.v
//    Create by  : liufei
//    Email      : liufei@innosilicon.com.cn
//    Create time: 2023-03-14
//************************************************************************
//    Description: 
//-FHDR*************************************************************************
module vf_lock_arbiter # (

    parameter VF_NUM = 15//the num of vf

)(
    input  wire              pclk                         , 
    input  wire              prst_n                       , 
    input  wire              reg_global_virtualization_en , 
    input  wire              i_psel                       , 
    input  wire              i_penable                    , 
    input  wire              i_pwrite                     ,
    input  wire [       7:0] i_paddr                      , 
    input  wire [       4:0] i_puser                      , 
    input  wire [      31:0] i_pwdata                     , 
    output reg               o_pready                     , 
    output reg  [      31:0] o_prdata                     , 
    output reg  [  VF_NUM:0] o_vf_lock                    , 
    output wire [  VF_NUM:0] o_arb_intr                   , 
    output reg  [  VF_NUM:0] o_grt_status                 , 
    output reg  [  VF_NUM:0] o_tmo_status

);


reg [VF_NUM-1:0]      reg_vf_lock                ; //VF Lock bit
reg                   reg_pf_lock                ; //Pf lock bit
reg [VF_NUM-1:0]      reg_vf_tmo_intr_clr        ; //Time out Intr clr
reg [VF_NUM-1:0]      reg_vf_grt_intr_clr        ; //Grant Intr clr
reg [VF_NUM-1:0]      reg_pfctrl_tmo_intr_clr    ; //VF Time out Intr clr
reg [VF_NUM-1:0]      reg_pfctrl_grt_intr_clr    ; //VF Grant Intr clr
reg                   reg_pf_grt_intr_clr        ; //PF Grant Intr clr
reg [VF_NUM-1:0]      reg_vf_tmo_intr_en         ; //Time out Intr enable
reg [VF_NUM-1:0]      reg_vf_grt_intr_en         ; //Grant Intr enable
reg [VF_NUM-1:0]      reg_pfctrl_tmo_intr_en     ; //VF Time out Intr enable
reg [VF_NUM-1:0]      reg_pfctrl_grt_intr_en     ; //VF Grant Intr enable
reg                   reg_pf_tmo_intr_en         ; //Time out Intr enable
reg                   reg_pf_grt_intr_en         ; //Grant Intr enable
reg [VF_NUM-1:0]      reg_vf_tmo_intr_status     ; //Time out Intr status
reg [VF_NUM-1:0]      reg_vf_grt_intr_status     ; //Grant Intr status
reg [VF_NUM-1:0]      reg_pfctrl_tmo_intr_status ; //VF Time out Intr status
reg [VF_NUM-1:0]      reg_pfctrl_grt_intr_status ; //VF Grant Intr status
reg                   reg_pf_tmo_intr_status     ; //PF Time out Intr status
reg                   reg_pf_grt_intr_status     ; //PF Grant Intr status
reg                   reg_queue_clr              ; //Queue clear
reg                   reg_vf_tmo_intr_to_pf      ;
reg [VF_NUM-1:0]      reg_vf_lock_clr            ; //VF lock clear
reg [      31:0]      reg_lock_cnt_thd           ; //
reg [VF_NUM-1:0]      reg_vf_priority            ; //VF priority change



reg [VF_NUM-1:0][4:0] id_queue                  ;//vf req queue 
reg                   time_out                  ;//vf/pf lock vpu out of time  
reg                   time_out_dly              ; 
reg                   grant_chance              ;//change vf/pf grant 
reg                   pf_req                    ;//vpu is busy, pf have req 
reg [  VF_NUM:0]      o_vf_lock_dly             ; 
reg [       3:0]      que_value_first1_id       ;//find the first vf,state is high 
reg [VF_NUM-1:0]      flag_id_que_user_n        ;//check user is not in queue 
reg [VF_NUM-1:0]      flag_id_que_user          ;//check user is in queue 
reg [VF_NUM-1:0]      flag_priority_que         ;//check pri_id is in queue 
reg [       3:0]      priority_que_id           ;//find the first vf=user in queue 
reg [       3:0]      que_user_first1_id        ;//find the first vf=user in queue 
reg [       3:0]      priority_id               ;//the id of changed vf priority 
reg [       4:0]      find_vf_lock_first1_id    ; 
reg [      31:0]      cnt_time_out              ;
reg [VF_NUM-1:0]      flag_pf_clr_que           ;
reg [       3:0]      pf_lock_clr_id            ;
reg [       3:0]      pf_lock_clr_que_id        ;
reg [  VF_NUM:0]      grt_status                ;
reg [  VF_NUM:0]      tmo_status                ;

wire apb_write_lock_en;
wire vpu_idle_write;
wire lock_neg;
wire cnt_enable;

//=============================================================================
//                          apb write 
//=============================================================================

wire write_en;
assign write_en = i_psel && i_penable && i_pwrite && o_pready;

always @(posedge pclk or negedge prst_n)
begin
    if      (!prst_n  )       o_pready <= 1'b0;
    else if (o_pready )       o_pready <= 1'b0;
    else if (i_psel   )       o_pready <= 1'b1;
end

always @ (posedge pclk or negedge prst_n) begin
    if (!prst_n) begin
        reg_pfctrl_tmo_intr_clr <= {(VF_NUM){1'h0}};
        reg_pfctrl_grt_intr_clr <= {(VF_NUM){1'h0}};
        reg_pf_grt_intr_clr     <= 1'h0;
        reg_pfctrl_tmo_intr_en  <= {(VF_NUM){1'h1}};
        reg_pfctrl_grt_intr_en  <= {(VF_NUM){1'h1}};
        reg_pf_tmo_intr_en      <= 1'h0;
        reg_pf_grt_intr_en      <= 1'h0;
        reg_queue_clr           <= 1'h0;
        reg_vf_tmo_intr_to_pf   <= 1'h0;
        reg_vf_lock_clr         <= {(VF_NUM){1'h0}};
        reg_lock_cnt_thd        <= 32'hffff_ffff;
        reg_vf_priority         <= {(VF_NUM){1'h0}};
        reg_vf_tmo_intr_clr     <= {(VF_NUM){1'h0}};
        reg_vf_grt_intr_clr     <= {(VF_NUM){1'h0}};
        reg_vf_tmo_intr_en      <= {(VF_NUM){1'h0}};
        reg_vf_grt_intr_en      <= {(VF_NUM){1'h0}};
    end else if (write_en) begin
        if (!reg_global_virtualization_en) begin
            case (i_paddr)
                8'h4    : begin
                    reg_pfctrl_tmo_intr_clr       <= i_pwdata[VF_NUM*2+1:VF_NUM+2];
                    reg_pfctrl_grt_intr_clr       <= i_pwdata[VF_NUM+1:2];
                    reg_pf_grt_intr_clr           <= i_pwdata[0];
                end
                8'h8    : begin
                    reg_pfctrl_tmo_intr_en        <= i_pwdata[VF_NUM*2+1:VF_NUM+2];
                    reg_pfctrl_grt_intr_en        <= i_pwdata[VF_NUM+1:2];
                    reg_pf_tmo_intr_en            <= i_pwdata[1];
                    reg_pf_grt_intr_en            <= i_pwdata[0];
                end
                8'h10   : begin
                    reg_queue_clr                 <= i_pwdata[0];
                end
                8'h14   : reg_vf_lock_clr         <= i_pwdata[VF_NUM-1:0];
                8'h18   : reg_lock_cnt_thd        <= i_pwdata;
                8'h1c   : reg_vf_priority         <= i_pwdata[VF_NUM-1:0];
                8'h20   : reg_vf_tmo_intr_to_pf   <= i_pwdata[0];
                default : ;
            endcase
        end else if (i_puser[4]) begin
            case (i_paddr)
                8'h4    : begin
                    reg_pfctrl_tmo_intr_clr       <= i_pwdata[VF_NUM*2+1:VF_NUM+2];
                    reg_pfctrl_grt_intr_clr       <= i_pwdata[VF_NUM+1:2];
                    reg_pf_grt_intr_clr           <= i_pwdata[0];
                end
                8'h8    : begin
                    reg_pfctrl_tmo_intr_en        <= i_pwdata[VF_NUM*2+1:VF_NUM+2];
                    reg_pfctrl_grt_intr_en        <= i_pwdata[VF_NUM+1:2];
                    reg_pf_tmo_intr_en            <= i_pwdata[1];
                    reg_pf_grt_intr_en            <= i_pwdata[0];
                end
                8'h10   : begin
                    reg_queue_clr           <= i_pwdata[0];
                end
                8'h14   : reg_vf_lock_clr         <= i_pwdata[VF_NUM-1:0];
                8'h18   : reg_lock_cnt_thd        <= i_pwdata;
                8'h1c   : reg_vf_priority         <= i_pwdata[VF_NUM-1:0];
                8'h20   : reg_vf_tmo_intr_to_pf   <= i_pwdata[0];
                default : ;
            endcase
        end else begin
            case (i_paddr)
                8'h4    : begin
                    reg_vf_tmo_intr_clr[i_puser[3:0]] <= i_pwdata[1];
                    reg_vf_grt_intr_clr[i_puser[3:0]] <= i_pwdata[0];
                end
                8'h8    : begin
                    reg_vf_tmo_intr_en[i_puser[3:0]] <= i_pwdata[1];
                    reg_vf_grt_intr_en[i_puser[3:0]] <= i_pwdata[0];
                end
                default : ;
            endcase
        end
    end else begin
        reg_pfctrl_tmo_intr_clr <= {(VF_NUM){1'h0}};
        reg_pfctrl_grt_intr_clr <= {(VF_NUM){1'h0}};
        reg_pf_grt_intr_clr     <= 1'h0;
        reg_queue_clr           <= 1'h0;
        reg_vf_lock_clr         <= {(VF_NUM){1'h0}};
        reg_vf_tmo_intr_clr     <= {(VF_NUM){1'h0}};
        reg_vf_grt_intr_clr     <= {(VF_NUM){1'h0}};
        reg_vf_priority         <= {(VF_NUM){1'h0}};
    end
end


//=============================================================================
//                          apb read
//=============================================================================

wire read_en;
assign read_en = i_psel && (!i_pwrite);
always @ (posedge pclk or negedge prst_n) begin
    if (!prst_n) begin
        o_prdata <= 32'h0;
    end else if (read_en) begin
        if(!reg_global_virtualization_en) begin
            case(i_paddr)
                8'h0    : o_prdata <= {{(31-VF_NUM){1'h0}}, reg_vf_lock, reg_pf_lock};
                8'h8    : o_prdata <= {{(30-VF_NUM*2){1'h0}}, reg_pfctrl_tmo_intr_en, reg_pfctrl_grt_intr_en, reg_pf_tmo_intr_en, reg_pf_grt_intr_en};
                8'hc    : o_prdata <= {{(30-VF_NUM*2){1'h0}}, reg_pfctrl_tmo_intr_status, reg_pfctrl_grt_intr_status, reg_pf_tmo_intr_status, reg_pf_grt_intr_status};
                8'h18   : o_prdata <= reg_lock_cnt_thd;
                8'h20   : o_prdata <= {31'h0, reg_vf_tmo_intr_to_pf};
                default : o_prdata <= 32'h0;
            endcase
        end else if(i_puser[4]) begin
            case(i_paddr)
                8'h0    : o_prdata <= {{(31-VF_NUM){1'h0}}, reg_vf_lock, reg_pf_lock};
                8'h8    : o_prdata <= {{(30-VF_NUM*2){1'h0}}, reg_pfctrl_tmo_intr_en, reg_pfctrl_grt_intr_en, reg_pf_tmo_intr_en, reg_pf_grt_intr_en};
                8'hc    : o_prdata <= {{(30-VF_NUM*2){1'h0}}, reg_pfctrl_tmo_intr_status, reg_pfctrl_grt_intr_status, reg_pf_tmo_intr_status, reg_pf_grt_intr_status};
                8'h18   : o_prdata <= reg_lock_cnt_thd;
                8'h20   : o_prdata <= {31'h0, reg_vf_tmo_intr_to_pf};
                default : o_prdata <= 32'h0;
            endcase
        end else begin
            case(i_paddr)
                8'h0    : o_prdata <= {{31'h0}, reg_vf_lock[i_puser[3:0]]};
                8'h8    : o_prdata <= {{30'h0}, reg_vf_tmo_intr_en[i_puser[3:0]], reg_vf_grt_intr_en[i_puser[3:0]]};
                8'hc    : o_prdata <= {{30'h0}, reg_vf_tmo_intr_status[i_puser[3:0]], reg_vf_grt_intr_status[i_puser[3:0]]};
                default : o_prdata <= 32'h0;
            endcase
        end
    end
end



//=============================================================================
//                          lock
//=============================================================================
reg [VF_NUM-1:0] id_queue_state;
int i_que_state;

always @ (*) begin
    id_queue_state = {(VF_NUM){1'h0}};
    for (i_que_state=0; i_que_state<VF_NUM; i_que_state=i_que_state+1) begin
        id_queue_state[i_que_state] = id_queue[i_que_state][4];
    end
end

assign apb_write_lock_en = write_en && (i_paddr == 9'h0); // adafds
assign vpu_idle_write    = (~|o_vf_lock) && (~pf_req) && (~|id_queue_state) && apb_write_lock_en; // asefasa


always @ (posedge pclk or negedge prst_n) begin
    if (~prst_n) begin
        o_vf_lock <= {(VF_NUM+1){1'h0}};
    end else if (~reg_global_virtualization_en) begin
        o_vf_lock[VF_NUM-1:0] <= {(VF_NUM){1'h0}};
        if(apb_write_lock_en) begin
            o_vf_lock[VF_NUM] <= i_pwdata[0];
        end
    end else if (|reg_vf_lock_clr) begin
        o_vf_lock[VF_NUM-1:0] <= o_vf_lock[VF_NUM-1:0] & (~reg_vf_lock_clr); 
    end else if (time_out) begin
        o_vf_lock <= {(VF_NUM+1){1'h0}};
    end else if (vpu_idle_write) begin
        if (i_puser[4]) begin
            o_vf_lock[VF_NUM] <= i_pwdata[0];
        end else begin
            o_vf_lock[i_puser[3:0]] <= i_pwdata[0];
        end
    end else if (grant_chance) begin
        if (pf_req) begin
            o_vf_lock[VF_NUM] <= 1'h1;
        end else if (|id_queue_state) begin
            o_vf_lock[id_queue[que_value_first1_id][3:0]] <= 1'h1; 
        end
    end else if (apb_write_lock_en) begin
        if (o_vf_lock[VF_NUM] && i_puser[4]) begin
            o_vf_lock[VF_NUM] <= i_pwdata[0];
        end else if (o_vf_lock[i_puser[3:0]] && (!i_puser[4])) begin
            o_vf_lock[i_puser[3:0]] <= i_pwdata[0];
        end else begin
            o_vf_lock <= o_vf_lock;
        end
    end
end

always @ (posedge pclk or negedge prst_n) begin
    if (~prst_n) begin
        o_vf_lock_dly <= {(VF_NUM+1){1'h0}};
    end else begin
        o_vf_lock_dly <= o_vf_lock;
    end
end


always @(*) begin 
    reg_vf_lock = o_vf_lock[VF_NUM-1 : 0];
    reg_pf_lock = o_vf_lock[VF_NUM];
end


//=============================================================================
//                          id_queue
//=============================================================================

int i_cut;
int i_state;
int i_move;
int i_que_rst;
int i;
int i_que_user_first1_id;
int i_flag_que_user;
int i_que_value_first1_id;
int i_priority;

always @ (*) begin
    que_value_first1_id = 4'b0;
    for (i_que_value_first1_id=0; i_que_value_first1_id<VF_NUM; i_que_value_first1_id=i_que_value_first1_id+1) begin
        if (id_queue[i_que_value_first1_id][4]) begin
            que_value_first1_id = i_que_value_first1_id;
        end
    end
end

int i_flag_que_user_n;
genvar j;
generate for (j = 0; j<VF_NUM; j++) begin
    always @ (*) begin
        if (id_queue[j] != {1'b1,i_puser[3:0]}) begin
            flag_id_que_user_n[j] = 1'h1;
        end else begin
            flag_id_que_user_n[j] = 1'h0;
        end
    end
    
    always @ (*) begin
        if (id_queue[j] == {1'b1,i_puser[3:0]}) begin
            flag_id_que_user[j] = 1'h1;
        end else begin
            flag_id_que_user[j] = 1'h0;
        end
    end

    always @ (*) begin
        if (id_queue[j] == {1'b1,priority_id}) begin
            flag_priority_que[j] = 1'h1;
        end else begin
            flag_priority_que[j] = 1'h0;
        end
    end

    always @ (*) begin
        if (id_queue[j] == {1'b1,pf_lock_clr_id[3:0]}) begin
            flag_pf_clr_que[j] = 1'h1;
        end else begin
            flag_pf_clr_que[j] = 1'h0;
        end
    end

end
endgenerate

always @ (*) begin
    priority_que_id = 4'h0;
    for (i_flag_que_user_n = 0; i_flag_que_user_n<VF_NUM; i_flag_que_user_n=i_flag_que_user_n+1) begin
        if (id_queue[i_flag_que_user_n] == {1'b1,priority_id}) begin
            priority_que_id = i_flag_que_user_n;
        end
    end
end


always @ (*) begin
    que_user_first1_id = 4'b0;
    for (i_que_user_first1_id=0; i_que_user_first1_id<VF_NUM; i_que_user_first1_id=i_que_user_first1_id+1) begin
        if (flag_id_que_user[i_que_user_first1_id]) begin
            que_user_first1_id = i_que_user_first1_id;
        end
    end
end

int i_priority_id;
always @(*) begin 
    priority_id = 4'h0;
    for (i_priority_id=0; i_priority_id<VF_NUM; i_priority_id=i_priority_id+1) begin
        if (reg_vf_priority[i_priority_id]) begin
            priority_id = i_priority_id;
        end
    end
end


always @ (*) begin
    pf_lock_clr_id = 4'h0;
    for (i_priority_id=0; i_priority_id<VF_NUM; i_priority_id=i_priority_id+1) begin
        if (reg_vf_lock_clr[i_priority_id]) begin
            pf_lock_clr_id = i_priority_id;
        end
    end
end

always @ (*) begin
    pf_lock_clr_que_id = 4'h0;
    for (i_priority_id=0; i_priority_id<VF_NUM; i_priority_id=i_priority_id+1) begin
        if (flag_pf_clr_que[i_priority_id]) begin
            pf_lock_clr_que_id = i_priority_id;
        end
    end
end

always @ (posedge pclk or negedge prst_n) begin
    if (~prst_n) begin
        for (i_que_rst=0; i_que_rst<VF_NUM; i_que_rst=i_que_rst+1) begin
            id_queue[i_que_rst] <= 5'h0;
        end
    end
    else if (reg_queue_clr || (~reg_global_virtualization_en)) begin
        for (i=0; i<VF_NUM; i=i+1) begin
            id_queue[i] <= 5'h0;
        end
    end
    else if ((|reg_vf_priority) && (|flag_priority_que) && (que_value_first1_id>priority_que_id)) begin
        for (i_priority=0; i_priority<VF_NUM; i_priority=i_priority+1) begin
            if(i_priority < VF_NUM-1) begin
                if ((i_priority>=priority_que_id) && (i_priority<que_value_first1_id)) begin
                    id_queue[i_priority] <= id_queue[i_priority+1];
                end else if (i_priority == que_value_first1_id) begin
                    id_queue[i_priority] <= id_queue[priority_que_id];
                end
            end else begin
                if(que_value_first1_id == i_priority) begin
                    id_queue[i_priority] <= id_queue[priority_que_id];
                end
            end
        end
    end
    else if ((|reg_vf_lock_clr) && (|flag_pf_clr_que)) begin
        for (i_cut=0; i_cut<VF_NUM; i_cut=i_cut+1) begin
            if ((i_cut>=pf_lock_clr_que_id) && (i_cut<(VF_NUM-1))) begin
                id_queue[i_cut] <= id_queue[i_cut+1];
            end
            else if (i_cut == (VF_NUM-1)) begin
                id_queue[i_cut] <= 5'h0;
            end
        end
    end
    else if (apb_write_lock_en  && (|flag_id_que_user) && (o_vf_lock[VF_NUM] || ((|o_vf_lock[VF_NUM-1:0]) && (find_vf_lock_first1_id != i_puser))) && (!i_puser[4]) && (~i_pwdata[0])) begin
        for (i_cut=0; i_cut<VF_NUM; i_cut=i_cut+1) begin
            if ((i_cut>=que_user_first1_id) && (i_cut<(VF_NUM-1))) begin
                id_queue[i_cut] <= id_queue[i_cut+1];
            end
            else if (i_cut == (VF_NUM-1)) begin
                id_queue[i_cut] <= 5'h0;
            end
        end
    end
    else if (grant_chance && (~pf_req) && (|id_queue_state)) begin//req
        for (i_state=0; i_state<VF_NUM; i_state=i_state+1) begin
            if (i_state>=que_value_first1_id) begin
                id_queue[i_state][4] <= 1'b0;
            end
        end
    end
    else if (apb_write_lock_en && (~i_puser[4]) && (&flag_id_que_user_n)) begin
        if ((o_vf_lock[VF_NUM] && (~i_puser[4]) && i_pwdata[0]) ||
        ((~o_vf_lock[VF_NUM]) && (|o_vf_lock[VF_NUM-1:0]) && (~o_vf_lock[i_puser[3:0]]) && i_pwdata[0])) begin
            for (i_move=0; i_move<VF_NUM; i_move=i_move+1) begin
                if (i_move==1'h0) begin
                    id_queue[i_move] <= {1'b1,i_puser[3:0]};
                end
                else begin
                    id_queue[i_move] <= id_queue[i_move-1];
                end
            end
        end
    end
end


//===========================================================================================
//                                         pf_req
//===========================================================================================

always @(posedge pclk or negedge prst_n) begin 
    if(!prst_n) begin 
        pf_req <= 1'h0;
    end else if (~reg_global_virtualization_en) begin
        pf_req <= 1'h0;
    end else if (grant_chance && pf_req) begin
        pf_req <= 1'h0;
    end else if (apb_write_lock_en) begin
        if ((~o_vf_lock[VF_NUM]) && (|o_vf_lock) && i_puser[4] && (~i_pwdata[0])) begin
            pf_req <= 1'h0;
        end else if ((~o_vf_lock[VF_NUM]) && (|o_vf_lock) && i_puser[4] && i_pwdata[0]) begin
            pf_req <= 1'h1;
        end
    end
end


//===========================================================================================
//                                        grant_chance
//===========================================================================================

assign lock_neg = |((~(|o_vf_lock)) & (|o_vf_lock_dly));


always @ (*) begin
    grant_chance = 1'h0;
    if (~reg_global_virtualization_en) begin
        grant_chance = 1'h0;
    end else if ((pf_req || (|id_queue_state)) && lock_neg) begin
        grant_chance = 1'h1;
    end else if (time_out_dly) begin
        grant_chance = 1'h1;
    end else begin
        grant_chance = 1'h0;
    end
end


//===========================================================================================
//                                        time_out
//===========================================================================================

always @ (posedge pclk or negedge prst_n) begin
    if (~prst_n) begin
        time_out <= 1'h0;
    end else if (time_out) begin
        time_out <= 1'h0;
    end else if ((cnt_time_out >= reg_lock_cnt_thd) && (|o_vf_lock)) begin
        time_out <= 1'h1;
    end
end

always @ (posedge pclk or negedge prst_n) begin
    if (~prst_n) begin
        time_out_dly <= 1'h0;
    end else begin
        time_out_dly <= time_out;
    end
end


assign cnt_enable = (reg_lock_cnt_thd != 32'hffff_ffff) ? 1'h1 : 1'h0;


always @ (posedge pclk or negedge prst_n) begin
    if (~prst_n) begin
        cnt_time_out <= 32'h0;
    end
    else if ((|o_vf_lock[VF_NUM-1:0]) && cnt_enable) begin
        if (time_out) begin
            cnt_time_out <= 32'h0;
        end else begin
            cnt_time_out <= cnt_time_out + 1'b1;
        end
    end else begin
        cnt_time_out <= 32'h0;
    end
end


//===========================================================================================
//                                        intr
//===========================================================================================

int i_intr;

always @ (posedge pclk or negedge prst_n) begin
    if (~prst_n) begin
        reg_pf_grt_intr_status <= 1'h0;
    end else if (o_vf_lock[VF_NUM] && (~o_vf_lock_dly[VF_NUM])) begin
        reg_pf_grt_intr_status <= 1'h1;
    end else if (reg_pf_grt_intr_clr) begin
        reg_pf_grt_intr_status <= 1'h0;
    end
end


always @ (posedge pclk or negedge prst_n) begin
    if (~prst_n) begin
        reg_pf_tmo_intr_status <= 1'h0;
    end else if (reg_vf_tmo_intr_to_pf) begin
        reg_pf_tmo_intr_status <= |reg_vf_tmo_intr_status;
    end else begin
        reg_pf_tmo_intr_status <= 1'h0;
    end
end

always @ (*) begin
    reg_pfctrl_tmo_intr_status = reg_vf_tmo_intr_status;
    reg_pfctrl_grt_intr_status = reg_vf_grt_intr_status;
end

int i_lock_first1;
always @ (*) begin
    find_vf_lock_first1_id = 5'h0;
    for (i_lock_first1=0; i_lock_first1<VF_NUM+1; i_lock_first1=i_lock_first1+1) begin
        if (o_vf_lock[i_lock_first1]) begin
            find_vf_lock_first1_id = i_lock_first1;
        end
    end
end


genvar k;
generate for(k = 0; k<VF_NUM+1; k++) begin
    if(k < VF_NUM) begin
        always @ (posedge pclk or negedge prst_n) begin
            if (~prst_n) begin
                reg_vf_grt_intr_status[k] <= 1'b0;
            end else begin
                if (o_vf_lock[k] && (~o_vf_lock_dly[k])) begin
                    reg_vf_grt_intr_status[k] <= 1'h1; 
                end else if (reg_vf_grt_intr_clr[k] || reg_pfctrl_grt_intr_clr[k]) begin
                    reg_vf_grt_intr_status[k] <= 1'h0;
                end
            end
        end

        always @ (posedge pclk or negedge prst_n) begin
            if (~prst_n) begin
                reg_vf_tmo_intr_status[k] <= {1'b0};
            end else if (time_out) begin
                reg_vf_tmo_intr_status[k] <= o_vf_lock[k] | reg_vf_tmo_intr_status[k];
            end else if (reg_vf_tmo_intr_clr[k] || reg_pfctrl_tmo_intr_clr[k]) begin
                reg_vf_tmo_intr_status[k] <= 1'h0;
            end
        end

    
        always @ (*) begin
            if (reg_pfctrl_grt_intr_en[k] && reg_vf_grt_intr_en[k]) begin
                grt_status[k] = reg_vf_grt_intr_status[k];
            end else begin
                grt_status[k] = 1'b0;
            end
        end
    
        always @ (*) begin
            if (reg_pfctrl_tmo_intr_en[k] && reg_vf_tmo_intr_en[k]) begin
                tmo_status[k] = reg_vf_tmo_intr_status[k];
            end else begin
                tmo_status[k] = 1'b0;
            end
        end
    end else if(k == VF_NUM) begin
        always @ (*) begin
            if (reg_pf_grt_intr_en) begin
                grt_status[VF_NUM] = reg_pf_grt_intr_status;
            end else begin
                grt_status[k] = 1'b0;
            end
        end
    
        always @ (*) begin
            if (reg_pf_tmo_intr_en) begin
                tmo_status[VF_NUM] = reg_pf_tmo_intr_status;
            end else begin
                tmo_status[k] = 1'b0;
            end
        end
    end
end
endgenerate


always @ (*) begin
    o_grt_status = {reg_pf_grt_intr_status, reg_vf_grt_intr_status};
    o_tmo_status = {reg_pf_tmo_intr_status, reg_vf_tmo_intr_status};
end


assign o_arb_intr = tmo_status | grt_status;

endmodule
