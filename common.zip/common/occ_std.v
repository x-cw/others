//--------------------------------------------------------
//       Created on: Tue Nov 15 17:53:13 CST 2020
//--------------------------------------------------------

module occ_std (
   input  wire         func_clk,
   input  wire         dft_test_clock,
   input  wire         dft_test_se,
   input  wire         dft_scan_mode,
   input  wire         dft_fast_capture_mode,
   input  wire   [1:0] capture_cycle_width,
   output wire         clock_out,
   input  wire         occ_scan_in,
   output wire         occ_scan_out
);
  
   wire         fast_clock_en;
   wire         slow_clock_en;
   wire         slow_clock_gated;
   wire         clock_mux_select;
   wire         fast_clock_gated;

   wire         fast_clock_buf_out;
   wire         slow_clock_buf_out;
   wire         scan_en_buf_out;
   wire         test_mode_buf_out;
   wire         fast_capture_mode_buf_out;
   wire   [1:0] capture_cycle_width_buf_out;
   wire         scan_in_buf_out;
   wire         scan_out_buf_in;

///////////////////////////////////////////////TSMC12///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
`ifdef TSMC12
   CKBD4BWP6T16P96CPDLVT tessent_persistent_cell_fast_clock_buf (
      .I                                     ( func_clk                         ),
      .Z                                     ( fast_clock_buf_out               )
   );
   CKBD4BWP6T16P96CPDLVT tessent_persistent_cell_slow_clock_buf (
      .I                                     ( dft_test_clock                   ),
      .Z                                     ( slow_clock_buf_out               )
   );
   BUFFD4BWP6T16P96CPDLVT tessent_persistent_cell_scan_en_buf (
      .I                                     ( dft_test_se                      ),
      .Z                                     ( scan_en_buf_out                  )
   );
   BUFFD4BWP6T16P96CPDLVT tessent_persistent_cell_test_mode_buf (
      .I                                     ( dft_scan_mode                    ),
      .Z                                     ( test_mode_buf_out                )
   );
   BUFFD4BWP6T16P96CPDLVT tessent_persistent_cell_fast_capture_mode_buf (
      .I                                     ( dft_fast_capture_mode            ),
      .Z                                     ( fast_capture_mode_buf_out        )
   );
   BUFFD4BWP6T16P96CPDLVT tessent_persistent_cell_capture_cycle_width_buf_0 (
      .I                                     ( capture_cycle_width[0]           ),
      .Z                                     ( capture_cycle_width_buf_out[0]   )
   );
   BUFFD4BWP6T16P96CPDLVT tessent_persistent_cell_capture_cycle_width_buf_1 (
      .I                                     ( capture_cycle_width[1]           ),
      .Z                                     ( capture_cycle_width_buf_out[1]   )
   );
   BUFFD4BWP6T16P96CPDLVT tessent_persistent_cell_scan_in_buf (
      .I                                     ( occ_scan_in                      ),
      .Z                                     ( scan_in_buf_out                  )
   );
   BUFFD4BWP6T16P96CPDLVT tessent_persistent_cell_scan_out_buf (
      .I                                     ( scan_out_buf_in                  ),
      .Z                                     ( occ_scan_out                     )
   );
`endif
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////SAMSUNG14///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
`ifdef SS14
   BUFH_X4N_A9PP84TR_C16 tessent_persistent_cell_fast_clock_buf (
      .A                                     ( func_clk                         ),
      .Y                                     ( fast_clock_buf_out               )
   );
   BUFH_X4N_A9PP84TR_C16 tessent_persistent_cell_slow_clock_buf (
      .A                                     ( dft_test_clock                   ),
      .Y                                     ( slow_clock_buf_out               )
   );
   BUF_X4N_A9PP84TR_C16 tessent_persistent_cell_scan_en_buf (
      .A                                     ( dft_test_se                      ),
      .Y                                     ( scan_en_buf_out                  )
   );
   BUF_X4N_A9PP84TR_C16 tessent_persistent_cell_test_mode_buf (
      .A                                     ( dft_scan_mode                    ),
      .Y                                     ( test_mode_buf_out                )
   );
   BUF_X4N_A9PP84TR_C16 tessent_persistent_cell_fast_capture_mode_buf (
      .A                                     ( dft_fast_capture_mode            ),
      .Y                                     ( fast_capture_mode_buf_out        )
   );
   BUF_X4N_A9PP84TR_C16 tessent_persistent_cell_capture_cycle_width_buf_0 (
      .A                                     ( capture_cycle_width[0]           ),
      .Y                                     ( capture_cycle_width_buf_out[0]   )
   );
   BUF_X4N_A9PP84TR_C16 tessent_persistent_cell_capture_cycle_width_buf_1 (
      .A                                     ( capture_cycle_width[1]           ),
      .Y                                     ( capture_cycle_width_buf_out[1]   )
   );
   BUF_X4N_A9PP84TR_C16 tessent_persistent_cell_scan_in_buf (
      .A                                     ( occ_scan_in                      ),
      .Y                                     ( scan_in_buf_out                  )
   );
   BUF_X4N_A9PP84TR_C16 tessent_persistent_cell_scan_out_buf (
      .A                                     ( scan_out_buf_in                  ),
      .Y                                     ( occ_scan_out                     )
   );
`endif
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
   occ_std_control occ_control (
     .fast_clock                             ( fast_clock_buf_out               ),
     .slow_clock                             ( slow_clock_buf_out               ),
     .bypass_clock                           ( clock_out                        ),
     .scan_en                                ( scan_en_buf_out                  ),
     .test_mode                              ( test_mode_buf_out                ),
     .fast_capture_mode                      ( fast_capture_mode_buf_out        ),
     .capture_cycle_width                    ( capture_cycle_width_buf_out      ),
     .fast_clock_en                          ( fast_clock_en                    ),
     .slow_clock_en                          ( slow_clock_en                    ),
     .clock_mux_select                       ( clock_mux_select                 ),
     .scan_in                                ( scan_in_buf_out                  ),
     .scan_out                               ( scan_out_buf_in                  )
   );
 
///////////////////////////////////////////////TSMC12///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
`ifdef TSMC12
   CKLNQD4BWP6T16P96CPDLVT tessent_persistent_cell_cgc_fast_clock (
     .CP                                     ( fast_clock_buf_out               ),
     .E                                      ( fast_clock_en                    ),
     .TE                                     ( fast_clock_en                    ),
     .Q                                      ( fast_clock_gated                 )
   );
  
  
   CKLNQD4BWP6T16P96CPDLVT tessent_persistent_cell_cgc_slow_clock (
     .CP                                     ( slow_clock_buf_out               ),
     .E                                      ( slow_clock_en                    ),
     .TE                                     ( slow_clock_en                    ),
     .Q                                      ( slow_clock_gated                 )
   );
 
 
   CKMUX2D4BWP6T16P96CPDLVT tessent_persistent_cell_clock_out_mux  (
     .I0                                     ( fast_clock_gated                 ),
     .I1                                     ( slow_clock_gated                 ),
     .S                                      ( clock_mux_select                 ),
     .Z                                      ( clock_out                        )
   );
`endif
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////SAMSUNG14///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
`ifdef SS14
   PREICG_X4N_A9PP84TR_C16 tessent_persistent_cell_cgc_fast_clock (
     .CK                                     ( fast_clock_buf_out               ),
     .E                                      ( fast_clock_en                    ),
     .SE                                     ( fast_clock_en                    ),
     .ECK                                    ( fast_clock_gated                 )
   );
  
   PREICG_X4N_A9PP84TR_C16 tessent_persistent_cell_cgc_slow_clock (
     .CK                                     ( slow_clock_buf_out               ),
     .E                                      ( slow_clock_en                    ),
     .SE                                     ( slow_clock_en                    ),
     .ECK                                    ( slow_clock_gated                 )
   );
 
   MXT2_X4N_A9PP84TR_C16 tessent_persistent_cell_clock_out_mux  (
     .A                                      ( fast_clock_gated                 ),
     .B                                      ( slow_clock_gated                 ),
     .S0                                     ( clock_mux_select                 ),
     .Y                                      ( clock_out                        )
   );
`endif
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
endmodule
  
module occ_std_control (
   input  wire         fast_clock,
   input  wire         slow_clock,
   input  wire         bypass_clock,
   input  wire         scan_en,
   input  wire         test_mode,
   input  wire         fast_capture_mode,
   input  wire   [1:0] capture_cycle_width,
   output wire         slow_clock_en,
   output wire         clock_mux_select,
   output wire         fast_clock_en,
   input  wire         scan_in,
   output reg          scan_out
);
 
   wire         SCAN_EN_inv_sync;
   wire         ShiftReg_EN;
   reg          BYPASS_SHIFT_FF;
   wire         SCAN_OUT_d;
   wire         ShiftReg_SCAN_OUT;
   wire         SHIFT_REG_CLK_en;
   wire         SHIFT_REG_CLK_G;
   wire         SHIFT_REG_CLK;
 
   reg          SE_SLOW_CLK;
 
   always @ (negedge slow_clock) begin
     SE_SLOW_CLK <= scan_en;
   end
   occ_std_tessent_posedge_synchronizer_reset tessent_persistent_cell_ltest_ntc_sync_cell (
     .d                                      ( ~SE_SLOW_CLK                     ),
     .clk                                    ( fast_clock                       ),
     .rn                                     ( ~scan_en                         ),
     .q                                      ( SCAN_EN_inv_sync                 )
   );
 
   assign SHIFT_REG_CLK_en = test_mode & ShiftReg_EN & SCAN_EN_inv_sync;
 
///////////////////////////////////////////////TSMC12///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
`ifdef TSMC12
   CKLNQD4BWP6T16P96CPDLVT tessent_persistent_cell_cgc_SHIFT_REG_CLK (
     .CP                                     ( fast_clock                       ), 
     .E                                      ( SHIFT_REG_CLK_en                 ),
     .TE                                     ( SHIFT_REG_CLK_en                 ),
     .Q                                      ( SHIFT_REG_CLK_G                  )
   );
 

   CKMUX2D4BWP6T16P96CPDLVT tessent_persistent_cell_SHIFT_REG_CLK_mux (
     .I0                                     ( SHIFT_REG_CLK_G                  ), 
     .I1                                     ( slow_clock                       ),
     .S                                      ( scan_en | ~fast_capture_mode     ),
     .Z                                      ( SHIFT_REG_CLK                    )
   );
`endif
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////SAMSUNG14///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
`ifdef SS14
   PREICG_X4N_A9PP84TR_C16 tessent_persistent_cell_cgc_SHIFT_REG_CLK (
     .CK                                     ( fast_clock               ),
     .E                                      ( SHIFT_REG_CLK_en                    ),
     .SE                                     ( SHIFT_REG_CLK_en                    ),
     .ECK                                    ( SHIFT_REG_CLK_G                 )
   );

   MXT2_X4N_A9PP84TR_C16 tessent_persistent_cell_SHIFT_REG_CLK_mux  (
     .A                                      ( SHIFT_REG_CLK_G                 ),
     .B                                      ( slow_clock                      ),
     .S0                                     ( scan_en | ~fast_capture_mode    ),
     .Y                                      ( SHIFT_REG_CLK                   )
   );
`endif
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

   always @ (posedge bypass_clock) begin
     BYPASS_SHIFT_FF <= scan_in & scan_en;
   end
   assign SCAN_OUT_d = (~test_mode) ? BYPASS_SHIFT_FF : ShiftReg_SCAN_OUT;
 
   always @ (negedge bypass_clock) begin
     scan_out <= SCAN_OUT_d & scan_en;
   end
 
   occ_std_shift_reg ShiftReg (
     .clk                                    ( SHIFT_REG_CLK                    ),
     .scan_en                                ( scan_en                          ),
     .capture_cycle_width                    ( capture_cycle_width              ),
     .some_ones_left                         ( ShiftReg_EN                      ),
     .scan_in                                ( scan_in                          ),
     .scan_out                               ( ShiftReg_SCAN_OUT                )
   );
 
 
   assign fast_clock_en    = (ShiftReg_SCAN_OUT & fast_capture_mode & SCAN_EN_inv_sync) | ~test_mode;
   assign slow_clock_en    = ((ShiftReg_SCAN_OUT | scan_en) & test_mode);
   assign clock_mux_select = ((scan_en | ~fast_capture_mode) & test_mode);
 
endmodule
  
  
module occ_std_shift_reg (
   input  wire         clk,
   input  wire         scan_en,
   input  wire   [1:0] capture_cycle_width,
   output wire         some_ones_left,
   input  wire         scan_in,
   output wire         scan_out
);
   reg    [2:0] FF;
   wire         scan_in_gated;
 
   assign scan_in_gated = scan_in & scan_en;
    
   always @ (posedge clk) begin
     case (capture_cycle_width)
        2'd2: FF <= {scan_in_gated, FF[2:1]};
        2'd1: FF <= {1'b0, scan_in_gated, FF[1:1]};
        2'd0: FF <= {2'b0, scan_in_gated};
        default: FF <= {scan_in_gated, FF[2:1]};
     endcase
   end
 
   assign some_ones_left = |FF;
   assign scan_out = FF[0];
   
endmodule

module occ_std_tessent_posedge_synchronizer_reset (
  input wire rn,
  input wire d,
  input wire clk,
  output reg q
);
reg ntc_retiming_q_reg;
always @ (posedge clk or negedge rn) begin
  if (~rn) begin
    ntc_retiming_q_reg <= 1'b0;
    q <= 1'b0;
  end else begin
    ntc_retiming_q_reg <= d;
    q <= ntc_retiming_q_reg;
  end
end
endmodule
