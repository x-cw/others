`timescale 1 ns / 1 ps
module reset_sync_dft #(
    parameter ADD_BEATS = 0
) (
    dft_test_mode   ,
    dft_test_rstn   ,
    rst_n           ,
    clk             ,
    rst_n_sync
);


input  wire   dft_test_mode    ;
input  wire   dft_test_rstn    ;
input         rst_n            ;
input         clk              ;
//asynch restz active, synch restz end
output        rst_n_sync       ;

wire rst_muxed_n = dft_test_mode ? dft_test_rstn : rst_n;

//////////
wire          rst_n_sync       ;
reg           latchff_clk      ;
reg  [ADD_BEATS+1:0]    syncrstz_clk     ;


always@(posedge clk or negedge rst_muxed_n)
   if (!rst_muxed_n)
      latchff_clk <= 1'b0 ;
   else
      latchff_clk <= 1'b1 ;

always@(posedge clk or negedge rst_muxed_n) //HH: to avoid short rst_muxed_n pulse glitch
   if (!rst_muxed_n)
      syncrstz_clk[0] <= 1'b0 ;
   else
      syncrstz_clk[0] <= latchff_clk ;

always@(posedge clk)
      syncrstz_clk[ADD_BEATS+1:1] <= syncrstz_clk[ADD_BEATS:0] ;

assign    rst_n_sync  =   dft_test_mode ? dft_test_rstn : latchff_clk && (&syncrstz_clk) ;


endmodule
