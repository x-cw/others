
// +FHDR-----------------------------------------------------------------------
// Copyright (c) 2021, Innosilicon, Inc. Confidential Proprietary
// PROJECT NAME  : GPU
// BLOCK   NAME  : xxx
// DEPARTMENT    : Front-End Department
// AUTHOR        : Zhouquan
// EMAIL         : zhouq@innosilicon.com.cn
// ----------------------------------------------------------------------------
// Release History
// VERSION  DATE        AUTHOR    DESCRIPTION
// 1.0      20210924    Zhouquan  First initial
// 
// ----------------------------------------------------------------------------
// Others For More Information:
//
// -FHDR-----------------------------------------------------------------------


module aw_w_lock_buf #
    (
      parameter  SL_AW_ADDR       = 40,
      parameter  SL_AW_ID         = 10,
      parameter  SL_AW_USER       = 13, 
      
      parameter  DATA_WIDTH       = 256,
      parameter  STROB_WIDTH      = 32 
    )
    (
                aclk
               ,aresetn

               // Write Address Channel from Master
               ,awvalid_m
               ,awaddr_m
               ,awid_m
               ,awlen_m
               ,awsize_m
               ,awburst_m
               ,awlock_m
               ,awcache_m
               ,awprot_m
               ,awuser_m
               ,awqos_m
               ,awready_m
               
               // Write Address Channel to Slave
               ,awvalid_s
               ,awaddr_s
               ,awid_s
               ,awlen_s
               ,awsize_s
               ,awburst_s
               ,awlock_s
               ,awcache_s
               ,awprot_s
               ,awuser_s
               ,awqos_s
               ,awready_s

               // Write Data Channel from Master1
               ,wvalid_m
               ,wdata_m
               ,wstrb_m
               ,wlast_m
               ,wready_m

               // Write Data Channel from Slave1
               ,wvalid_s
               ,wdata_s
               ,wstrb_s
               ,wlast_s
               ,wready_s
               );

  input                          aclk;
  input                          aresetn;

// Write Address Channel from Master
  input                          awvalid_m;
  input  [SL_AW_ADDR-1:0]        awaddr_m;
  input  [SL_AW_ID-1:0]          awid_m;
  input  [4-1:0]         awlen_m;
  input  [3-1:0]         awsize_m;
  input  [2-1:0]         awburst_m;
  input                  awlock_m;
  input  [4-1:0]         awcache_m;
  input  [3-1:0]         awprot_m;
  input  [SL_AW_USER-1:0]        awuser_m;
  input  [4-1:0]         awqos_m;
  output                 awready_m;

// Write Address Channel to Slave
  output reg                     awvalid_s;
  output [SL_AW_ADDR-1:0]        awaddr_s;
  output [SL_AW_ID-1:0]          awid_s;
  output [4-1:0]         awlen_s;
  output [3-1:0]         awsize_s;
  output [2-1:0]         awburst_s;
  output                 awlock_s;
  output [4-1:0]         awcache_s;
  output [3-1:0]         awprot_s;
  output [SL_AW_USER-1:0]        awuser_s;
  output [4-1:0]         awqos_s;
  input                  awready_s;

// Write Data Channel from Master
  input                  wvalid_m;
  input  [DATA_WIDTH-1:0] wdata_m;
  input  [STROB_WIDTH-1:0]wstrb_m;
  input                  wlast_m;
  output                 wready_m;

// Write Data Channel from Slave
  output reg               wvalid_s;
  output  [DATA_WIDTH-1:0] wdata_s;
  output  [STROB_WIDTH-1:0]wstrb_s;
  output                 wlast_s;
  input                  wready_s;

  localparam  DWIDTH_FIFO = DATA_WIDTH + STROB_WIDTH + 1;

/*autowire*/
/*autoreg*/
// Beginning of automatic regs (for this module's undeclared outputs)
// End of automatics
  reg  [SL_AW_ADDR-1:0]        awaddr_m_d;
  reg  [SL_AW_ID-1:0]          awid_m_d;
  reg  [4-1:0]                 awlen_m_d;
  reg  [3-1:0]                 awsize_m_d;
  reg  [2-1:0]                 awburst_m_d;
  reg                          awlock_m_d;
  reg  [4-1:0]                 awcache_m_d;
  reg  [3-1:0]                 awprot_m_d;
  reg  [SL_AW_USER-1:0]        awuser_m_d;
  reg  [4-1:0]                 awqos_m_d;

  reg                          axi_aw_eof_m    ;
  reg                          axi_w_eof_m     ;

  wire                         fifo_wclr       ;
  wire                         fifo_wr         ;
  wire                         fifo_full       ;
  wire                         fifo_afull      ;
  wire [DWIDTH_FIFO-1:0]       fifo_wdata      ;
  wire                         fifo_rd         ;
  wire                         fifo_empty      ;
  wire                         fifo_aempty     ;
  wire [DWIDTH_FIFO-1:0]       fifo_rdata      ;

always@(posedge aclk or negedge aresetn) begin
  if(!aresetn)begin
    /*autoreset*/
    // Beginning of autoreset for uninitialized flops
    awaddr_m_d <= {SL_AW_ADDR{1'b0}};
    awburst_m_d <= {(1+(2-1)){1'b0}};
    awcache_m_d <= {(1+(4-1)){1'b0}};
    awid_m_d <= {SL_AW_ID{1'b0}};
    awlen_m_d <= {(1+(4-1)){1'b0}};
    awlock_m_d <= 1'h0;
    awprot_m_d <= {(1+(3-1)){1'b0}};
    awqos_m_d <= {(1+(4-1)){1'b0}};
    awsize_m_d <= {(1+(3-1)){1'b0}};
    awuser_m_d <= {SL_AW_USER{1'b0}};
    // End of automatics
  end
  else if(awvalid_m && awready_m)begin
    awaddr_m_d      <= awaddr_m ;
    awid_m_d        <= awid_m   ;
    awlen_m_d       <= awlen_m  ;
    awsize_m_d      <= awsize_m ;
    awburst_m_d     <= awburst_m;
    awlock_m_d      <= awlock_m ;
    awcache_m_d     <= awcache_m;
    awprot_m_d      <= awprot_m ;
    awuser_m_d      <= awuser_m ;
    awqos_m_d       <= awqos_m  ;  
  end
end

//always@(posedge aclk or negedge aresetn) begin
//  if(!aresetn) 
//    axi_w_inc_cnt <= 4'h0;
//  else if(wvalid_m && wready_m)
//    if(wlast_m)
//      axi_w_inc_cnt <= 4'h0;
//    else
//      axi_w_inc_cnt <= axi_w_inc_cnt + 4'h1;
//end

always@(posedge aclk or negedge aresetn) begin
  if(!aresetn) 
    awvalid_s <= 1'b0;
  else if(wvalid_m && wready_m && wlast_m)
    awvalid_s <= 1'b1;
  else if(awvalid_s && awready_s)
    awvalid_s <= 1'b0;
end

always@(posedge aclk or negedge aresetn) begin
  if(!aresetn) 
    axi_w_eof_m <= 1'b0;
  else if(awvalid_m && awready_m)
    axi_w_eof_m <= 1'b1;
  else if(wvalid_m && wready_m && wlast_m)
    axi_w_eof_m <= 1'b0;
end

always@(posedge aclk or negedge aresetn) begin
  if(!aresetn) 
    axi_aw_eof_m <= 1'b0;
  else if(awvalid_m && awready_m)
    axi_aw_eof_m <= 1'b1;
  else if(wvalid_s && wready_s && wlast_s)
    axi_aw_eof_m <= 1'b0;
end
//for master side
  assign awready_m   = !axi_aw_eof_m;

  assign wready_m    = !fifo_full && axi_w_eof_m;

//for slave side
  //assign awvalid_s   = axi_w_eof_m;
  assign awaddr_s    = awaddr_m_d ;
  assign awid_s      = awid_m_d   ;
  assign awlen_s     = awlen_m_d  ;
  assign awsize_s    = awsize_m_d ;
  assign awburst_s   = awburst_m_d;
  assign awlock_s    = awlock_m_d ;
  assign awcache_s   = awcache_m_d;
  assign awprot_s    = awprot_m_d ;
  assign awuser_s    = awuser_m_d ;
  assign awqos_s     = awqos_m_d  ;

always@(posedge aclk or negedge aresetn) begin
  if(!aresetn) 
    wvalid_s <= 1'b0;
  else if(awvalid_s && awready_s)
    wvalid_s <= 1'b1;
  else if(wvalid_s && wready_s && wlast_s)
    wvalid_s <= 1'b0;
end

//for fifo buffer of w channel 
  assign fifo_wr     = wvalid_m && wready_m;
  assign fifo_wdata  = {wlast_m,wstrb_m[STROB_WIDTH-1:0],wdata_m[DATA_WIDTH-1:0]};

  assign fifo_rd     = wvalid_s && wready_s;
  assign {wlast_s,wstrb_s[STROB_WIDTH-1:0],wdata_s[DATA_WIDTH-1:0]} = fifo_empty ? {DWIDTH_FIFO{1'b0}} : fifo_rdata;

  gp_fifo #(
    .AFULL_THRESH (0     ),
    .FIFO_WORDS   (16    ),
    .FIFO_WIDTH   (DWIDTH_FIFO))
  u_fifo_w_chn(
               // Outputs
               .dout                    (fifo_rdata),        
               .aempty                  (fifo_aempty),                       
               .afull                   (fifo_afull),                       
               .empty                   (fifo_empty),           
               .full                    (fifo_full),            
               .overflow                (),                       
               .underflow               (),                       
               .valid_entries           (),  
               // Inputs
               .clk                     (aclk),
               .reset_n                 (aresetn),             
               .init                    (1'b0),
               .rd_en                   (fifo_rd),             
               .wr_en                   (fifo_wr),  
               .din                     (fifo_wdata)); 

endmodule 
// Local Variables:
// verilog-library-directories:("./")  
// verilog-auto-inst-param-value:t
// End:
