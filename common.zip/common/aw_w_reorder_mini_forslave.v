module aw_w_reorder_mini_forslave #(
    parameter   D_WIDTH = 256, 
              STB_WIDTH = 32
          )   (
                aclk
               ,aresetn
               ,reg_slave_reorder_en //1 to enable this feature

               // Write Address Channel from Master1
               ,awvalid
               ,awready

               // Write Data Channel from Master1
               ,wvalid_m
               ,wdata_m
               ,wstrb_m
               ,wlast_m
               ,wready_m

               // Write Data Channel from Slave1
               ,wvalid_s
               ,wdata_s
               ,wstrb_s
               ,wlast_s
               ,wready_s
               );


  input                  aclk;
  input                  aresetn;

  input                  reg_slave_reorder_en; //1 to enable this feature

// Write Address Channel from Master
  input                  awvalid;
  input                  awready;

// Write Data Channel from Master
  input                  wvalid_m;
  input  [D_WIDTH-1:0]   wdata_m;
  input  [STB_WIDTH-1:0] wstrb_m;
  input                  wlast_m;
  output                 wready_m;

// Write Data Channel from Slave
  output                 wvalid_s;
  output [D_WIDTH-1:0]   wdata_s;
  output [STB_WIDTH-1:0] wstrb_s;
  output                 wlast_s;
  input                  wready_s;

/*autowire*/

wire          aw_trans;
wire          w_trans;

wire          wvalid_slice;
wire          wready_slice; //consider reorder, re-generate wready_s for SLICE

reg  [7:0]    axi_aw_w_inc_cnt;


assign aw_trans =  awvalid  & awready;
assign  w_trans =  wvalid_m & wready_m;


always@(posedge aclk or negedge aresetn) begin
  if(!aresetn) 
    axi_aw_w_inc_cnt <= 8'b0;
  else if(aw_trans && w_trans && wlast_s)
    axi_aw_w_inc_cnt <= axi_aw_w_inc_cnt;
  else if(aw_trans)
    axi_aw_w_inc_cnt <= axi_aw_w_inc_cnt + 8'h1;
  else if(w_trans && wlast_s)
    axi_aw_w_inc_cnt <= axi_aw_w_inc_cnt - 8'h1;
end

assign wvalid_s  = wvalid_m  & (reg_slave_reorder_en ? (axi_aw_w_inc_cnt != 8'h0) : 1'b1);
assign wready_m  = wready_s  & (reg_slave_reorder_en ? (axi_aw_w_inc_cnt != 8'h0) : 1'b1);

assign wdata_s   = wdata_m   ;
assign wstrb_s   = wstrb_m   ;
assign wlast_s   = wlast_m   ;


endmodule 
// Local Variables:
// verilog-library-directories:("./")  
// verilog-auto-inst-param-value:t
// End:
