//******************************************************************************
//
//   Copyright (c) 2020 Innosilicon. All rights reserved.
//
//   THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF INNOSILICON
//   The copyright notice above does not evidence any actual or intended
//   publication of such source code.
//
//    Module name: slice_acel_ar.v
//    Create by: Huck He
//    Create time: 2020-07-31
//
//    Change List:
// 
//
//
//******************************************************************************

module slice_acel_ar  #
  (
    parameter  SLICE_RESET_SYNC = 0,
    parameter  SL_AR_ADDR = 40     ,
    parameter  SL_AR_ID   = 10     ,
    parameter  SL_AR_USER = 13 
  )
  (
    input                     clk              ,
    input                     rst_n            ,
    //input channel
    input                     src_arvalid      ,
    input  [SL_AR_ADDR-1:0]   src_araddr       ,
    input  [SL_AR_ID-1:0]     src_arid         ,
    input  [3:0]              src_arlen        ,
    input  [2:0]              src_arsize       ,
    input  [1:0]              src_arburst      ,
    input                     src_arlock       ,
    input  [3:0]              src_arcache      ,
    input  [2:0]              src_arprot       ,
    input  [SL_AR_USER-1:0]   src_aruser       ,
    input  [3:0]              src_arqos        ,
    input  [3:0]              src_arsnoop      ,
    input  [1:0]              src_ardomain     ,
    input  [1:0]              src_arbar        ,
    output                    src_arready      ,
    //output channel
    output                    dst_arvalid      ,
    output [SL_AR_ADDR-1:0]   dst_araddr       ,
    output [SL_AR_ID-1:0]     dst_arid         ,
    output [3:0]              dst_arlen        ,
    output [2:0]              dst_arsize       ,
    output [1:0]              dst_arburst      ,
    output                    dst_arlock       ,
    output [3:0]              dst_arcache      ,
    output [2:0]              dst_arprot       ,
    output [SL_AR_USER-1:0]   dst_aruser       ,
    output [3:0]              dst_arqos        ,
    output [3:0]              dst_arsnoop      ,
    output [1:0]              dst_ardomain     ,
    output [1:0]              dst_arbar        ,
    input                     dst_arready      
  );


localparam SL_TOTAL_WIDTH = SL_AR_ADDR + SL_AR_ID + SL_AR_USER + 29;

wire [SL_TOTAL_WIDTH-1:0]  payload_src;
wire [SL_TOTAL_WIDTH-1:0]  payload_dst;

assign payload_src = {
                      src_araddr  ,//         input  [SL_AR_ADDR-1:0];
                      src_arid    ,//         input  [SL_AR_ID-1:0]  ;
                      src_arlen   ,//         input  [3:0]           ;
                      src_arsize  ,//         input  [2:0]           ;
                      src_arburst ,//         input  [1:0]           ;
                      src_arlock  ,//         input                  ;
                      src_arcache ,//         input  [3:0]           ;
                      src_arprot  ,//         input  [2:0]           ;
                      src_aruser  ,//         input  [SL_AR_USER-1:0];
                      src_arqos   ,//         input  [3:0]           ;
                      src_arsnoop ,//         input  [3:0]           ;
                      src_ardomain,//         input  [1:0]           ;
                      src_arbar    //         input  [1:0]           ;
                     };

assign {dst_araddr    ,            //         output [SL_AR_ADDR-1:0]
        dst_arid      ,            //         output [SL_AR_ID-1:0]  
        dst_arlen     ,            //         output [3:0]           
        dst_arsize    ,            //         output [2:0]           
        dst_arburst   ,            //         output [1:0]           
        dst_arlock    ,            //         output                 
        dst_arcache   ,            //         output [3:0]           
        dst_arprot    ,            //         output [2:0]           
        dst_aruser    ,            //         output [SL_AR_USER-1:0]
        dst_arqos     ,            //         output [3:0]           
        dst_arsnoop   ,            //         output [3:0]           
        dst_ardomain  ,            //         output [1:0]           
        dst_arbar                  //         output [1:0]           
       }         = payload_dst; 

full_regd_slice #(
    .SLICE_RESET_SYNC (SLICE_RESET_SYNC),
    .WIDTH            (SL_TOTAL_WIDTH)
  ) slice_ar (
    .rst_b       (rst_n             ), 
    .clk         (clk               ), 
                             
    .payload_src (payload_src       ), 
    .valid_src   (src_arvalid       ), 
    .ready_src   (src_arready       ),
    
    .payload_dst (payload_dst       ),
    .valid_dst   (dst_arvalid       ), 
    .ready_dst   (dst_arready       )  
);

endmodule
