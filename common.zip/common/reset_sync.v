`timescale 1 ns / 1 ps
module reset_sync #(
    parameter ADD_BEATS = 0
)
(
        rst_n           ,
        clk             ,
        rst_n_sync
       );


input         rst_n            ;
input         clk              ;
//asynch restz active, synch restz end
output        rst_n_sync       ;

//////////
wire          rst_n_sync       ;
reg           latchff_clk      ;
reg  [ADD_BEATS+1:0]    syncrstz_clk     ;


always@(posedge clk or negedge rst_n)
   if (!rst_n)
      latchff_clk <= 1'b0 ;
   else
      latchff_clk <= 1'b1 ;

always@(posedge clk or negedge rst_n) //HH: to avoid short rst_n pulse glitch
   if (!rst_n)
      syncrstz_clk[0] <= 1'b0 ;
   else
      syncrstz_clk[0] <= latchff_clk ;

always@(posedge clk)
      syncrstz_clk[ADD_BEATS+1:1] <= syncrstz_clk[ADD_BEATS:0] ;

assign    rst_n_sync  =   latchff_clk && (&syncrstz_clk) ;


endmodule
