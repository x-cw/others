module aw_w_lock_mini #
    (
      parameter  [1:0]  LOCK_NUM_M1      = 2'd2,
      parameter         SL_AW_ADDR       = 40,
      parameter         SL_AW_ID         = 10,
      parameter         SL_AW_USER       = 13, 
      parameter         SL_AW_LEN        = 4 ,
      
      parameter         DATA_WIDTH       = 256,
      parameter         STROB_WIDTH      = 32 
    )
    (
                aclk
               ,aresetn

               // Write Address Channel from Master
               ,awvalid_m
               ,awaddr_m
               ,awid_m
               ,awlen_m
               ,awsize_m
               ,awburst_m
               ,awlock_m
               ,awcache_m
               ,awprot_m
               ,awuser_m
               ,awqos_m
               ,awready_m
               
               // Write Address Channel to Slave
               ,awvalid_s
               ,awaddr_s
               ,awid_s
               ,awlen_s
               ,awsize_s
               ,awburst_s
               ,awlock_s
               ,awcache_s
               ,awprot_s
               ,awuser_s
               ,awqos_s
               ,awready_s

               // Write Data Channel from Master1
               ,wvalid_m
               ,wdata_m
               ,wstrb_m
               ,wlast_m
               ,wready_m

               // Write Data Channel from Slave1
               ,wvalid_s
               ,wdata_s
               ,wstrb_s
               ,wlast_s
               ,wready_s
               );

  input                  aclk;
  input                  aresetn;

// Write Address Channel from Master
  input                  awvalid_m;
  input  [SL_AW_ADDR-1:0]        awaddr_m;
  input  [SL_AW_ID-1:0]          awid_m;
  input  [SL_AW_LEN-1:0] awlen_m;
  input  [3-1:0]         awsize_m;
  input  [2-1:0]         awburst_m;
  input                  awlock_m;
  input  [4-1:0]         awcache_m;
  input  [3-1:0]         awprot_m;
  input  [SL_AW_USER-1:0]        awuser_m;
  input  [4-1:0]         awqos_m;
  output                 awready_m;

// Write Address Channel to Slave
  output                 awvalid_s;
  output [SL_AW_ADDR-1:0]        awaddr_s;
  output [SL_AW_ID-1:0]          awid_s;
  output [SL_AW_LEN-1:0] awlen_s;
  output [3-1:0]         awsize_s;
  output [2-1:0]         awburst_s;
  output                 awlock_s;
  output [4-1:0]         awcache_s;
  output [3-1:0]         awprot_s;
  output [SL_AW_USER-1:0]        awuser_s;
  output [4-1:0]         awqos_s;
  input                  awready_s;

// Write Data Channel from Master
  input                  wvalid_m;
  input  [DATA_WIDTH-1:0] wdata_m;
  input  [STROB_WIDTH-1:0]wstrb_m;
  input                  wlast_m;
  output                 wready_m;

// Write Data Channel from Slave
  output                 wvalid_s;
  output  [DATA_WIDTH-1:0] wdata_s;
  output  [STROB_WIDTH-1:0]wstrb_s;
  output                 wlast_s;
  input                  wready_s;

/*autowire*/

wire          aw_trans;
wire          w_trans;

wire          wvalid_slice;
wire          wready_slice; //consider reorder, re-generate wready_s for SLICE

wire          awvalid_slice;
wire          awready_slice;//consider reorder, re-generate awready_s for SLICE

reg  [1:0]    axi_aw_w_inc_cnt;

assign aw_trans = awvalid_s & awready_s;
assign  w_trans =  wvalid_s &  wready_s;

always@(posedge aclk or negedge aresetn) begin
  if(!aresetn) 
    axi_aw_w_inc_cnt <= 2'h0;
  else if(aw_trans && w_trans && wlast_s)
    axi_aw_w_inc_cnt <= axi_aw_w_inc_cnt;
  else if(aw_trans)
    axi_aw_w_inc_cnt <= axi_aw_w_inc_cnt + 2'h1;
  else if(w_trans && wlast_s)
    axi_aw_w_inc_cnt <= axi_aw_w_inc_cnt - 2'h1;
end

// assign wvalid_s      = wvalid_slice  & (axi_aw_w_inc_cnt != 2'h0);
// assign wready_slice  = wready_s      & (axi_aw_w_inc_cnt != 2'h0);
assign wvalid_s      = wvalid_slice  & ((axi_aw_w_inc_cnt != 2'h0) | awvalid_s & awready_s);
assign wready_slice  = wready_s      & ((axi_aw_w_inc_cnt != 2'h0) | awvalid_s & awready_s);

assign awvalid_s     = awvalid_slice & (axi_aw_w_inc_cnt <= LOCK_NUM_M1);
assign awready_slice = awready_s     & (axi_aw_w_inc_cnt <= LOCK_NUM_M1);

/*slice_acel_w auto_template (
              .clk            (aclk           ),
              .rst_n          (aresetn        ),

              .dst_wready     (wready_slice   ),
              .dst_wvalid     (wvalid_slice   ),
              .src_\(.*\)     (\1_m[]         ),
              .dst_\(.*\)     (\1_s[]         ),

);
*/
slice_acel_w #(
  .DATA_WIDTH   (DATA_WIDTH ),
  .STROB_WIDTH  (STROB_WIDTH)
) slice_lock_w_inst(/*autoinst*/
                    // Outputs
                    .src_wready         (wready_m         ),     // Templated
                    .dst_wvalid         (wvalid_slice   ),       // Templated
                    .dst_wdata          (wdata_s[DATA_WIDTH-1:0]         ), // Templated
                    .dst_wstrb          (wstrb_s[STROB_WIDTH-1:0]         ), // Templated
                    .dst_wlast          (wlast_s         ),      // Templated
                    // Inputs
                    .clk                (aclk           ),       // Templated
                    .rst_n              (aresetn        ),       // Templated
                    .src_wvalid         (wvalid_m         ),     // Templated
                    .src_wdata          (wdata_m[DATA_WIDTH-1:0]         ), // Templated
                    .src_wstrb          (wstrb_m[STROB_WIDTH-1:0]         ), // Templated
                    .src_wlast          (wlast_m         ),      // Templated
                    .dst_wready         (wready_slice   ));      // Templated


/*slice_axi_aw auto_template (
              .clk            (aclk          ),
              .rst_n          (aresetn       ),

              .dst_awready    (awready_slice ),
              .dst_awvalid    (awvalid_slice ),
              .src_\(.*\)     (\1_m[]        ),
              .dst_\(.*\)     (\1_s[]        ),

);
*/
            slice_axi_aw #(.SL_AW_ADDR(SL_AW_ADDR), .SL_AW_ID(SL_AW_ID), .SL_AW_USER(SL_AW_USER), .SL_AW_LEN(SL_AW_LEN)) 
             slice_lock_aw_inst(/*autoinst*/
                                // Outputs
                                .src_awready    (awready_m        ), // Templated
                                .dst_awvalid    (awvalid_slice ), // Templated
                                .dst_awaddr     (awaddr_s[SL_AW_ADDR-1:0]        ), // Templated
                                .dst_awid       (awid_s[SL_AW_ID-1:0]        ), // Templated
                                .dst_awlen      (awlen_s[SL_AW_LEN-1:0]        ), // Templated
                                .dst_awsize     (awsize_s[2:0]        ), // Templated
                                .dst_awburst    (awburst_s[1:0]        ), // Templated
                                .dst_awlock     (awlock_s        ), // Templated
                                .dst_awcache    (awcache_s[3:0]        ), // Templated
                                .dst_awprot     (awprot_s[2:0]        ), // Templated
                                .dst_awuser     (awuser_s[SL_AW_USER-1:0]        ), // Templated
                                .dst_awqos      (awqos_s[3:0]        ), // Templated
                                // Inputs
                                .clk            (aclk          ), // Templated
                                .rst_n          (aresetn       ), // Templated
                                .src_awvalid    (awvalid_m        ), // Templated
                                .src_awaddr     (awaddr_m[SL_AW_ADDR-1:0]        ), // Templated
                                .src_awid       (awid_m[SL_AW_ID-1:0]        ), // Templated
                                .src_awlen      (awlen_m[SL_AW_LEN-1:0]        ), // Templated
                                .src_awsize     (awsize_m[2:0]        ), // Templated
                                .src_awburst    (awburst_m[1:0]        ), // Templated
                                .src_awlock     (awlock_m        ), // Templated
                                .src_awcache    (awcache_m[3:0]        ), // Templated
                                .src_awprot     (awprot_m[2:0]        ), // Templated
                                .src_awuser     (awuser_m[SL_AW_USER-1:0]        ), // Templated
                                .src_awqos      (awqos_m[3:0]        ), // Templated
                                .dst_awready    (awready_slice )); // Templated


endmodule 
// Local Variables:
// verilog-library-directories:("./")  
// verilog-auto-inst-param-value:t
// End:
