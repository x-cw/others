
// #==========================================================================#
// |                                                                          |
// |  Copyright (c) 2021, Imagination Technologies Limited and/or its         |
// |  affiliated group companies ("Imagination"). All rights reserved.        |
// |  No part of this content, either material or conceptual may be copied    |
// |  or distributed, transmitted, transcribed, stored in a retrieval system  |
// |  or translated into any human or computer language in any form by any    |
// |  means, electronic, mechanical manual, or otherwise, or disclosed to     |
// |  third parties without the express written permission of Imagination.    |
// |                                                                          |
// #==========================================================================#


`timescale 1ns / 1ps

module img_gfx_clock_gate(
   te,
   cp,
   e,
   q,
   tin,
   tout
);

   parameter tiw=1;
   parameter tow=1;

   input  te;                // test enable 
   input  cp;                // clock input
   input  e;                 // enable
   output q;                 // gated clock out
   input [tiw - 1:0] tin;    // test bus input
   output[tow - 1:0] tout;   // test bus output
   
   wire   te;
   wire   cp;
   wire   e;
   wire   q;
   wire  [tiw - 1:0] tin;
   wire  [tow - 1:0] tout;

   wire  ED;
   



   
   wire  GE;







   
   /*
   CKLNQD2BWP20P90CPDLVT hand_latch(
      .E(e),
      .TE(te),
      .CP(cp),
      .Q(q));
   */

 PREICG_X10N_A9PP84TL_C14 hand_latch(
    .ECK                            (q     ), // 
    .CK                             (cp    ), // 
    .E                              (e     ), // 
    .SE                             (te   ));
   assign tout = {tow{1'b0}};
    
    
 //  img_gfx_random_delay i_img_gfx_random_delay(
 //     // synopsys translate_off
//      .clk(cp),
//      .resetn(resetn),
//      // synopsys translate_on
 //     .in_delay(e),
 //     .out_delay(ED));

endmodule
