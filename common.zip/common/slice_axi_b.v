//+FHDR*************************************************************************
// 
//   Copyright (c) 2023 Innosilicon. Ltd.  All rights reserved. 
// 
//   THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF INNOSILICON
//   The copyright notice above does not evidence any actual or intended
//   publication of such source code.
// 
//************************************************************************
//    Module name: slice_axi_b.v
//    Create by  : luhz
//    Email      : luhz@innosilicon.com.cn
//    Create time: 2023-05-23
//************************************************************************
//    Description: 
//-FHDR*************************************************************************
module slice_axi_b #(
    parameter SLICE_RESET_SYNC = 0,
    parameter SL_ID            = 8,
    parameter SL_USER          = 8
)(
    input                     clk              ,
    input                     rst_n            ,

    output wire               src_bready       ,
    input  wire [SL_ID  -1:0] src_bid          ,
    input  wire [2      -1:0] src_bresp        ,
    input  wire               src_bvalid       ,
    input  wire [SL_USER-1:0] src_buser        ,

    output wire [SL_ID  -1:0] dst_bid          ,
    output wire [      2-1:0] dst_bresp        ,
    output wire               dst_bvalid       ,
    output wire [SL_USER-1:0] dst_buser        ,
    input  wire               dst_bready        
);

localparam SL_TOTAL_WIDTH = SL_ID + 2 + SL_USER;

wire [SL_TOTAL_WIDTH-1:0]  payload_src;
wire [SL_TOTAL_WIDTH-1:0]  payload_dst;

assign payload_src = {
    src_bid          ,
    src_bresp        ,
    src_buser         
};

assign {
    dst_bid          ,
    dst_bresp        ,
    dst_buser         
} = payload_dst;

full_regd_slice #(
    .SLICE_RESET_SYNC (SLICE_RESET_SYNC),
    .WIDTH            (SL_TOTAL_WIDTH)
  ) slice_b (
    .rst_b       (rst_n             ), 
    .clk         (clk               ), 
                             
    .payload_src (payload_src       ), 
    .valid_src   (src_bvalid        ), 
    .ready_src   (src_bready        ),
    
    .payload_dst (payload_dst       ),
    .valid_dst   (dst_bvalid        ), 
    .ready_dst   (dst_bready        )  
);
endmodule
