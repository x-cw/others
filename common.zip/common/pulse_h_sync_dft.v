//******************************************************************************
//
//   Copyright (c) 2020 Innosilicon. All rights reserved.
//
//   THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF INNOSILICON
//   The copyright notice above does not evidence any actual or intended
//   publication of such source code.
//
//    Module name: pulse_sync
//    Create by: Huck He
//    Create time: 2020-07-03
//
//    Module Function: input posedge sync to another clk domain as a (PULSE_WID) cycles high pulse. And latency will be decided by clk frequency of both 2 clks.
//                     WARNING: If source consecutive posegdes are too close, the latter ones may be missing because of the former pulse not finised. 
//                              And output high pulse's width maybe extended because of this.
//                     expecting clk_src / clk_dst are always running during switch
//
//    Change List:
// 
//
//
//******************************************************************************


`timescale 1 ns / 1 ps
module pulse_h_sync_dft #(
    parameter PULSE_WID = 1,
    parameter IN_WID    = 1
)
(
    input                    clk_src      ,
    input                    clk_dst      ,
    input                    rst_n        ,
    input                    dft_test_mode,
    input                    dft_test_rstn,
    input  [IN_WID-1:0]      A           ,
    output reg [IN_WID-1:0]  Y 
);



//////////
wire               rst_n_dst      ;
wire               mux_rst_n_dst  ;

reg  [IN_WID-1:0]  in_d           ;

reg  [IN_WID-1:0]  in_pos_ori     ;
reg  [IN_WID-1:0]  in_pos_dst_d0  ;
reg  [IN_WID-1:0]  in_pos_dst_d1  ;
reg  [IN_WID-1:0]  in_pos_dst_d2  ;
wire [IN_WID-1:0]  in_pos_dst     ;

reg  [IN_WID-1:0]  ack_d1         ;
reg  [IN_WID-1:0]  ack_d2         ;


reg    [PULSE_WID-1:0] pulse_dst [IN_WID-1:0];

integer i;

reset_sync rst_n_dst_inst ( 
        .rst_n      (rst_n    )        ,
        .clk        (clk_dst  )        ,
        .rst_n_sync (rst_n_dst)
       );

assign mux_rst_n_dst = dft_test_mode ? dft_test_rstn : rst_n_dst;

always @(posedge clk_src or negedge rst_n)
   if (!rst_n) begin
      in_d       <= {IN_WID{1'b0}} ;
      in_pos_ori <= {IN_WID{1'b0}} ;
   end else begin
      in_d       <= A ;
      for (i=0;i<IN_WID;i=i+1)
          if (A[i] & (~in_d[i]))
              in_pos_ori[i] <= 1'b1;
          else if (ack_d2[i]) // keep until get ack from clk_dst
              in_pos_ori[i] <= 1'b0;
          else 
              in_pos_ori[i] <= in_pos_ori[i];
   end

//posedge level sync to clk_dst domain
always @(posedge clk_dst or negedge mux_rst_n_dst)
   if (!mux_rst_n_dst)
      {in_pos_dst_d2, in_pos_dst_d1, in_pos_dst_d0} <= {(IN_WID){3'b0}} ;
   else
      {in_pos_dst_d2, in_pos_dst_d1, in_pos_dst_d0} <= {in_pos_dst_d1, in_pos_dst_d0, in_pos_ori};

assign in_pos_dst = in_pos_dst_d1 & (~in_pos_dst_d2);


//ack back to clk_src domain
always @(posedge clk_src or negedge rst_n)
   if (!rst_n) begin
       {ack_d2, ack_d1} <= {(IN_WID){2'b0}};
   end else begin 
       {ack_d2, ack_d1} <= {ack_d1, in_pos_dst_d1};
   end 


//output externd and generation
always @(posedge clk_dst or negedge mux_rst_n_dst)
   if (!mux_rst_n_dst) begin
      for (i=0;i<IN_WID;i=i+1) 
          pulse_dst[i] <= {PULSE_WID{1'b0}};
          Y          <= {(IN_WID){1'b0}};
   end else begin
      for (i=0;i<IN_WID;i=i+1) begin
          pulse_dst[i] <= (pulse_dst[i]<<1 & {(PULSE_WID){32'hFFFF_FFFE}}) | in_pos_dst[i] ;
          Y[i]       <= |pulse_dst[i];
      end
   end



endmodule
