`timescale 1 ns / 1 ps
module sig_sync_nor#(
    parameter WIDTH = 1
)
(
    input                 clk          ,
    input  [WIDTH-1:0]    A           ,
    output [WIDTH-1:0]    Y
);



//////////
reg  [WIDTH-1:0]    in_d     ;
reg  [WIDTH-1:0]    in_dd    ;


always@(posedge clk)
      {in_dd,in_d} <= {in_d, A} ;


assign  Y = in_dd ;


endmodule
