//+FHDR*************************************************************************
// 
//   Copyright (c) 2023 Innosilicon. Ltd.  All rights reserved. 
// 
//   THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF INNOSILICON
//   The copyright notice above does not evidence any actual or intended
//   publication of such source code.
// 
//************************************************************************
//    Module name: slice_axi_r.v
//    Create by  : luhz
//    Email      : luhz@innosilicon.com.cn
//    Create time: 2023-05-23
//************************************************************************
//    Description: 
//-FHDR*************************************************************************
module slice_axi_r #(
    parameter SLICE_RESET_SYNC = 0  ,
    parameter SL_ID            = 8  ,
    parameter SL_USER          = 8  , 
    parameter DATA_WIDTH       = 256
)(
    input                         clk              ,
    input                         rst_n            ,

    input  wire                   dst_rready       ,
    output wire [SL_ID      -1:0] dst_rid          ,
    output wire                   dst_rvalid       ,
    output wire [DATA_WIDTH -1:0] dst_rdata        ,
    output wire [SL_USER    -1:0] dst_ruser        ,
    output wire [          2-1:0] dst_rresp        ,
    output wire                   dst_rlast        ,
    
    input  wire                   src_rvalid       ,
    input  wire [SL_ID      -1:0] src_rid          ,
    input  wire [DATA_WIDTH -1:0] src_rdata        ,
    input  wire [SL_USER    -1:0] src_ruser        ,
    input  wire [          2-1:0] src_rresp        ,
    input  wire                   src_rlast        ,
    output wire                   src_rready        
);
localparam SL_TOTAL_WIDTH = SL_ID + DATA_WIDTH + SL_USER + 2 + 1;

wire [SL_TOTAL_WIDTH-1:0]  payload_src;
wire [SL_TOTAL_WIDTH-1:0]  payload_dst;

assign payload_src = {
    src_rid          ,
    src_rdata        ,
    src_ruser        ,
    src_rresp        ,
    src_rlast        
};

assign {
    dst_rid          ,
    dst_rdata        ,
    dst_ruser        ,
    dst_rresp        ,
    dst_rlast         
} = payload_dst;

full_regd_slice #(
    .SLICE_RESET_SYNC (SLICE_RESET_SYNC),
    .WIDTH            (SL_TOTAL_WIDTH  )
  ) slice_r (
    .rst_b       (rst_n             ), 
    .clk         (clk               ), 
                             
    .payload_src (payload_src       ), 
    .valid_src   (src_rvalid        ), 
    .ready_src   (src_rready        ),
    
    .payload_dst (payload_dst       ),
    .valid_dst   (dst_rvalid        ), 
    .ready_dst   (dst_rready        )  
);

endmodule
