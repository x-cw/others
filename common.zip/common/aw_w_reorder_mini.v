module aw_w_reorder_mini(
                aclk
               ,aresetn

               // Write Address Channel from Master1
               ,awvalid
               ,awready

               // Write Data Channel from Master1
               ,wvalid_m
               ,wdata_m
               ,wstrb_m
               ,wlast_m
               ,wready_m

               // Write Data Channel from Slave1
               ,wvalid_s
               ,wdata_s
               ,wstrb_s
               ,wlast_s
               ,wready_s
               );

  input                  aclk;
  input                  aresetn;

// Write Address Channel from Master
  input                  awvalid;
  input                  awready;

// Write Data Channel from Master
  input                  wvalid_m;
  input  [256-1:0]       wdata_m;
  input  [32-1:0]        wstrb_m;
  input                  wlast_m;
  output                 wready_m;

// Write Data Channel from Slave
  output                 wvalid_s;
  output  [256-1:0]      wdata_s;
  output  [32-1:0]       wstrb_s;
  output                 wlast_s;
  input                  wready_s;

/*autowire*/

wire          aw_trans;
wire          w_trans;

wire          wvalid_slice;
wire          wready_slice; //consider reorder, re-generate wready_s for SLICE

reg  [7:0]    axi_aw_w_inc_cnt;


assign aw_trans =  awvalid  & awready;
assign  w_trans =  wvalid_s & wready_s;


always@(posedge aclk or negedge aresetn) begin
  if(!aresetn) 
    axi_aw_w_inc_cnt <= 8'b0;
  else if(aw_trans && w_trans && wlast_s)
    axi_aw_w_inc_cnt <= axi_aw_w_inc_cnt;
  else if(aw_trans)
    axi_aw_w_inc_cnt <= axi_aw_w_inc_cnt + 8'h1;
  else if(w_trans && wlast_s)
    axi_aw_w_inc_cnt <= axi_aw_w_inc_cnt - 8'h1;
end

assign wvalid_s     = wvalid_slice & (axi_aw_w_inc_cnt != 8'h0);
assign wready_slice = wready_s     & (axi_aw_w_inc_cnt != 8'h0);

/*slice_acel_w auto_template (
              .clk            (aclk           ),
              .rst_n          (aresetn        ),

              .dst_wready     (wready_slice   ),
              .dst_wvalid     (wvalid_slice   ),
              .src_\(.*\)     (\1_m[]        ),
              .dst_\(.*\)     (\1_s[]        ),

);
*/
slice_acel_w slice_reorder_w_inst(/*autoinst*/
                                  // Outputs
                                  .src_wready           (wready_m        ), // Templated
                                  .dst_wvalid           (wvalid_slice   ), // Templated
                                  .dst_wdata            (wdata_s[256-1:0]        ), // Templated
                                  .dst_wstrb            (wstrb_s[32-1:0]        ), // Templated
                                  .dst_wlast            (wlast_s        ), // Templated
                                  // Inputs
                                  .clk                  (aclk           ), // Templated
                                  .rst_n                (aresetn        ), // Templated
                                  .src_wvalid           (wvalid_m        ), // Templated
                                  .src_wdata            (wdata_m[256-1:0]        ), // Templated
                                  .src_wstrb            (wstrb_m[32-1:0]        ), // Templated
                                  .src_wlast            (wlast_m        ), // Templated
                                  .dst_wready           (wready_slice   )); // Templated


endmodule 
// Local Variables:
// verilog-library-directories:("./")  
// verilog-auto-inst-param-value:t
// End:
