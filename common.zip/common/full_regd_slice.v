

module full_regd_slice #
  (
    parameter  SLICE_RESET_SYNC = 0,
    parameter  WIDTH = 2
  )
    (
    input   wire                rst_b       , 
    input   wire                clk         , 
    

    input   wire  [WIDTH-1:0]   payload_src , 
    input   wire                valid_src   , 
    output  wire                ready_src   , 


    output  reg   [WIDTH-1:0]   payload_dst ,
    output  wire                valid_dst   , 
    input   wire                ready_dst     
    );
    
    
    //interal signal        
    wire                    rst_b_sync;
    
    wire                    enable_a;
    wire                    enable_b;
    wire                    load_sel_en;
    wire                    nxt_valid_a;
    wire                    nxt_valid_b;
    reg    [WIDTH-1:0]      payload_reg_a;
    reg    [WIDTH-1:0]      payload_reg_b;
    reg                     valid_a;
    reg                     valid_b;
    wire                    iready_src;
    wire                    ivalid_dst;
    reg                     load_b;
    reg                     sel_b;
    wire                    sel_b_en;
    
    
    assign  valid_dst  = ivalid_dst;
    assign  ready_src  = iready_src;
    
    always @(*)
        begin
            payload_dst = sel_b ? payload_reg_b : payload_reg_a;
        end
    
    assign enable_a = ~load_b & valid_src & iready_src;
    
    assign enable_b =  load_b & valid_src & iready_src;
    
    assign load_sel_en  =  valid_src & iready_src;
    
    assign nxt_valid_a = (enable_a ? 1'b1
        :((~sel_b & ivalid_dst & ready_dst)? 1'b0
        : valid_a));  
    
    assign nxt_valid_b = (enable_b ? 1'b1
        :((sel_b & ivalid_dst & ready_dst)? 1'b0
        : valid_b));  

    always @(posedge clk)
        begin
            if(enable_a)
                payload_reg_a  <= payload_src;
        end
    
    always @(posedge clk)
        begin
            if(enable_b)
                payload_reg_b  <= payload_src;
        end
    
    
    always @(posedge clk or negedge rst_b_sync)
        begin
            if(!rst_b_sync)
                valid_a <= 1'b0;
            else
                valid_a <= nxt_valid_a;
        end
    
    always @(posedge clk or negedge rst_b_sync)
        begin
            if(!rst_b_sync)
                valid_b <= 1'b0;
            else
                valid_b <= nxt_valid_b;
        end
    
    assign iready_src = ~valid_a | ~valid_b;
    
    assign ivalid_dst =  valid_a |  valid_b;
    
    
    always @(posedge clk or negedge rst_b_sync)
        begin
            if(!rst_b_sync)
                load_b <= 1'b0;
            else
                if(load_sel_en)
                    load_b <= ~load_b;
        end         
    
    assign sel_b_en = ((~sel_b & nxt_valid_b & (~valid_a | ready_dst)) |
                       ( sel_b & nxt_valid_a & (~valid_b | ready_dst)) );
    
    
    always @(posedge clk or negedge rst_b_sync)
        begin
            if(!rst_b_sync)
                sel_b <= 1'b0;
            else
            if(sel_b_en)
                sel_b <= ~sel_b;
        end            


generate 
    case (SLICE_RESET_SYNC)
        0:        //original logic for slice that do not need sync reset, it's for small module that don't need sperate rstn
            begin 
                assign  rst_b_sync = rst_b;
            end
        default:  //add reset sync logic, for SLICE_RESET_SYNC non-zero value
            begin 
                reset_sync  slice_rstn_sync (
                      .rst_n      (rst_b     ),
                      .clk        (clk       ),
                      .rst_n_sync (rst_b_sync)
                      ); 
            end
    endcase
endgenerate
    
endmodule
