//+FHDR*************************************************************************
// 
//   Copyright (c) 2023 Innosilicon. Ltd.  All rights reserved. 
// 
//   THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF INNOSILICON
//   The copyright notice above does not evidence any actual or intended
//   publication of such source code.
// 
//************************************************************************
//    Module name: axi_rsp_filter.v
//    Create by  : luhz
//    Email      : luhz@innosilicon.com.cn
//    Create time: 2023-03-01
//************************************************************************
//    Description: 
//      This module will auto fill remained w channel data when reset asserting, 
//      and filt r/b resp after reset asserted.
//-FHDR*************************************************************************
module axi_rsp_filter#(
    parameter SL_ADDR           = 40 ,
    parameter SL_ID             = 12 ,
    parameter SL_USER           = 12 , 
    parameter DATA_WIDTH        = 256,
    parameter STROB_WIDTH       = 32 
)(
    input  wire                   clk                 , // databus clock, 1300MHz or 1000MHz
    input  wire                   rst_n               , // databus rst_n, sync to aclk
    input  wire                   reg_rsp_filter_en   , // rsp filter enable, high active
    input  wire                   flr_rst_n           , // FLR request, used in virtualization
    input  wire [           31:0] reg_block_tmo_thd_lo, // block time out thd
    input  wire [            9:0] reg_block_tmo_thd_hi, // block time out thd
    input  wire                   tmo_intr_clr        , // clear signal for timeout intr
    output wire                   tmo_intr            , // timeout intr
    input  wire                   i_test_mode         , // test_mode
    input  wire                   test_mode_rstn      , // test_mode rst_n

    input  wire                   awvalid_m           , // axi interface, master side 
    input  wire [SL_ADDR    -1:0] awaddr_m            , // axi interface, master side 
    input  wire [SL_ID      -1:0] awid_m              , // axi interface, master side 
    input  wire [          8-1:0] awlen_m             , // axi interface, master side 
    input  wire [          3-1:0] awsize_m            , // axi interface, master side 
    input  wire [          2-1:0] awburst_m           , // axi interface, master side 
    input  wire                   awlock_m            , // axi interface, master side 
    input  wire [          4-1:0] awcache_m           , // axi interface, master side 
    input  wire [          3-1:0] awprot_m            , // axi interface, master side 
    input  wire [SL_USER    -1:0] awuser_m            , // axi interface, master side 
    input  wire [          4-1:0] awqos_m             , // axi interface, master side 
    output wire                   awready_m           , // axi interface, master side 

    input  wire                   wvalid_m            , // axi interface, master side 
    input  wire [DATA_WIDTH -1:0] wdata_m             , // axi interface, master side 
    input  wire [STROB_WIDTH-1:0] wstrb_m             , // axi interface, master side 
    input  wire                   wlast_m             , // axi interface, master side 
    output wire                   wready_m            , // axi interface, master side 

    input  wire                   bready_m            , // axi interface, master side
    output wire [SL_ID      -1:0] bid_m               , // axi interface, master side
    output wire [          2-1:0] bresp_m             , // axi interface, master side
    output wire                   bvalid_m            , // axi interface, master side
    output wire [SL_USER    -1:0] buser_m             , // axi interface, master side

    input  wire                   arvalid_m           , // axi interface, master side 
    input  wire [SL_ADDR    -1:0] araddr_m            , // axi interface, master side 
    input  wire [SL_ID      -1:0] arid_m              , // axi interface, master side 
    input  wire [          8-1:0] arlen_m             , // axi interface, master side 
    input  wire [          3-1:0] arsize_m            , // axi interface, master side 
    input  wire [          2-1:0] arburst_m           , // axi interface, master side 
    input  wire                   arlock_m            , // axi interface, master side 
    input  wire [          4-1:0] arcache_m           , // axi interface, master side 
    input  wire [          3-1:0] arprot_m            , // axi interface, master side 
    input  wire [SL_USER    -1:0] aruser_m            , // axi interface, master side 
    input  wire [          4-1:0] arqos_m             , // axi interface, master side 
    output wire                   arready_m           , // axi interface, master side 

    input  wire                   rready_m            , // axi interface, master side 
    output wire [SL_ID      -1:0] rid_m               , // axi interface, master side
    output wire                   rvalid_m            , // axi interface, master side 
    output wire [DATA_WIDTH -1:0] rdata_m             , // axi interface, master side 
    output wire [SL_USER    -1:0] ruser_m             , // axi interface, master side 
    output wire [          2-1:0] rresp_m             , // axi interface, master side
    output wire                   rlast_m             , // axi interface, master side 

    input  wire                   awready_s           , // axi interface, slave side
    output wire                   awvalid_s           , // axi interface, slave side
    output wire [SL_ADDR    -1:0] awaddr_s            , // axi interface, slave side
    output wire [SL_ID      -1:0] awid_s              , // axi interface, slave side
    output wire [          8-1:0] awlen_s             , // axi interface, slave side
    output wire [          3-1:0] awsize_s            , // axi interface, slave side
    output wire [          2-1:0] awburst_s           , // axi interface, slave side
    output wire                   awlock_s            , // axi interface, slave side
    output wire [          4-1:0] awcache_s           , // axi interface, slave side
    output wire [          3-1:0] awprot_s            , // axi interface, slave side
    output wire [SL_USER    -1:0] awuser_s            , // axi interface, slave side
    output wire [          4-1:0] awqos_s             , // axi interface, slave side

    input  wire                   wready_s            , // axi interface, slave side
    output wire                   wvalid_s            , // axi interface, slave side
    output wire [DATA_WIDTH -1:0] wdata_s             , // axi interface, slave side
    output wire [STROB_WIDTH-1:0] wstrb_s             , // axi interface, slave side
    output wire                   wlast_s             , // axi interface, slave side

    input  wire [SL_ID      -1:0] bid_s               , // axi interface, slave side
    input  wire [          2-1:0] bresp_s             , // axi interface, slave side
    input  wire                   bvalid_s            , // axi interface, slave side
    input  wire [SL_USER    -1:0] buser_s             , // axi interface, slave side
    output wire                   bready_s            , // axi interface, slave side

    input  wire                   arready_s           , // axi interface, slave side
    output wire                   arvalid_s           , // axi interface, slave side
    output wire [SL_ADDR    -1:0] araddr_s            , // axi interface, slave side
    output wire [SL_ID      -1:0] arid_s              , // axi interface, slave side
    output wire [          8-1:0] arlen_s             , // axi interface, slave side
    output wire [          3-1:0] arsize_s            , // axi interface, slave side
    output wire [          2-1:0] arburst_s           , // axi interface, slave side
    output wire                   arlock_s            , // axi interface, slave side
    output wire [          4-1:0] arcache_s           , // axi interface, slave side
    output wire [          3-1:0] arprot_s            , // axi interface, slave side
    output wire [SL_USER    -1:0] aruser_s            , // axi interface, slave side
    output wire [          4-1:0] arqos_s             , // axi interface, slave side

    input  wire                   rvalid_s            , // axi interface, slave side
    input  wire [SL_ID      -1:0] rid_s               , // axi interface, slave side
    input  wire [DATA_WIDTH -1:0] rdata_s             , // axi interface, slave side
    input  wire [SL_USER    -1:0] ruser_s             , // axi interface, slave side
    input  wire [          2-1:0] rresp_s             , // axi interface, slave side
    input  wire                   rlast_s             , // axi interface, slave side
    output wire                   rready_s              // axi interface, slave side
);

reg  flr_rst_sync_n                ; // 1 clk delay of flr_rst_n
reg  flr_rst_sync_n_dff1           ; // 1 clk delay
wire flr_rst_sync_n_neg            ; // negedge edge of flr_rst_sync_n

wire awready_locked;         // From aw_w_lock_mini_inst of aw_w_lock_mini.v
wire wready_locked ;         // From aw_w_lock_mini_inst of aw_w_lock_mini.v
wire                    rready_m_locked;
wire [SL_ID-1:0]        rid_m_locked;
wire                    rvalid_m_locked;
wire [DATA_WIDTH-1:0]   rdata_m_locked;
wire [SL_USER-1:0]      ruser_m_locked;
wire [1:0]              rresp_m_locked;
wire                    rlast_m_locked;
/*autowire*/
// Beginning of automatic wires (for undeclared instantiated-module outputs)
wire [SL_ADDR-1:0]      awaddr_locked;          // From aw_w_lock_mini_inst of aw_w_lock_mini.v
wire [1:0]              awburst_locked;         // From aw_w_lock_mini_inst of aw_w_lock_mini.v
wire [3:0]              awcache_locked;         // From aw_w_lock_mini_inst of aw_w_lock_mini.v
wire [SL_ID-1:0]        awid_locked;            // From aw_w_lock_mini_inst of aw_w_lock_mini.v
wire [7:0]              awlen_locked;           // From aw_w_lock_mini_inst of aw_w_lock_mini.v
wire                    awlock_locked;          // From aw_w_lock_mini_inst of aw_w_lock_mini.v
wire [2:0]              awprot_locked;          // From aw_w_lock_mini_inst of aw_w_lock_mini.v
wire [3:0]              awqos_locked;           // From aw_w_lock_mini_inst of aw_w_lock_mini.v
wire [2:0]              awsize_locked;          // From aw_w_lock_mini_inst of aw_w_lock_mini.v
wire [SL_USER-1:0]      awuser_locked;          // From aw_w_lock_mini_inst of aw_w_lock_mini.v
wire                    awvalid_locked;         // From aw_w_lock_mini_inst of aw_w_lock_mini.v
wire [DATA_WIDTH-1:0]   wdata_locked;           // From aw_w_lock_mini_inst of aw_w_lock_mini.v
wire                    wlast_locked;           // From aw_w_lock_mini_inst of aw_w_lock_mini.v
wire [STROB_WIDTH-1:0]  wstrb_locked;           // From aw_w_lock_mini_inst of aw_w_lock_mini.v
wire                    wvalid_locked;          // From aw_w_lock_mini_inst of aw_w_lock_mini.v
// End of automatics
wire                   awready_slice           ;
wire                   awvalid_slice           ;
wire [SL_ADDR    -1:0] awaddr_slice            ;
wire [SL_ID      -1:0] awid_slice              ;
wire [          8-1:0] awlen_slice             ;
wire [          3-1:0] awsize_slice            ;
wire [          2-1:0] awburst_slice           ;
wire                   awlock_slice            ;
wire [          4-1:0] awcache_slice           ;
wire [          3-1:0] awprot_slice            ;
wire [SL_USER    -1:0] awuser_slice            ;
wire [          4-1:0] awqos_slice             ;
wire                   wready_slice            ;
wire                   wvalid_slice            ;
wire [DATA_WIDTH -1:0] wdata_slice             ;
wire [STROB_WIDTH-1:0] wstrb_slice             ;
wire                   wlast_slice             ;
wire                   arready_slice           ;
wire                   arvalid_slice           ;
wire [SL_ADDR    -1:0] araddr_slice            ;
wire [SL_ID      -1:0] arid_slice              ;
wire [          8-1:0] arlen_slice             ;
wire [          3-1:0] arsize_slice            ;
wire [          2-1:0] arburst_slice           ;
wire                   arlock_slice            ;
wire [          4-1:0] arcache_slice           ;
wire [          3-1:0] arprot_slice            ;
wire [SL_USER    -1:0] aruser_slice            ;
wire [          4-1:0] arqos_slice             ;

wire                   bready_slice            ;
wire [SL_ID      -1:0] bid_slice               ;
wire [          2-1:0] bresp_slice             ;
wire                   bvalid_slice            ;
wire [SL_USER    -1:0] buser_slice             ;
wire                   rready_slice            ;
wire [SL_ID      -1:0] rid_slice               ;
wire                   rvalid_slice            ;
wire [DATA_WIDTH -1:0] rdata_slice             ;
wire [SL_USER    -1:0] ruser_slice             ;
wire [          2-1:0] rresp_slice             ;
wire                   rlast_slice             ;

wire aww_lock_rst_n;
reset_sync_dft awwlock_rst_inst(
    .dft_test_mode (i_test_mode   ),
    .dft_test_rstn (test_mode_rstn),
    .rst_n         (rst_n && (reg_rsp_filter_en ? flr_rst_n : 1'b1)),
    .clk           (clk           ),
    .rst_n_sync    (aww_lock_rst_n)
);

/*aw_w_lock_mini auto_template(
    .aclk     (clk  ),
    .aresetn  (aww_lock_rst_n),
    .\(.*_m\) (\1[]),
    .\(.*\)_s (\1_locked[]),
);
*/

aw_w_lock_mini#(
    .LOCK_NUM_M1  (2'd0          ),
    .SL_AW_ADDR   (SL_ADDR       ),
    .SL_AW_ID     (SL_ID         ),
    .SL_AW_USER   (SL_USER       ), 
    .SL_AW_LEN    (8             ),
    .DATA_WIDTH   (DATA_WIDTH    ),
    .STROB_WIDTH  (STROB_WIDTH   )
)aw_w_lock_mini_inst
   (/*autoinst*/
    // Outputs
    .awready_m                          (awready_m),             // Templated
    .awvalid_s                          (awvalid_locked),        // Templated
    .awaddr_s                           (awaddr_locked[SL_ADDR-1:0]), // Templated
    .awid_s                             (awid_locked[SL_ID-1:0]), // Templated
    .awlen_s                            (awlen_locked[7:0]),     // Templated
    .awsize_s                           (awsize_locked[2:0]),    // Templated
    .awburst_s                          (awburst_locked[1:0]),   // Templated
    .awlock_s                           (awlock_locked),         // Templated
    .awcache_s                          (awcache_locked[3:0]),   // Templated
    .awprot_s                           (awprot_locked[2:0]),    // Templated
    .awuser_s                           (awuser_locked[SL_USER-1:0]), // Templated
    .awqos_s                            (awqos_locked[3:0]),     // Templated
    .wready_m                           (wready_m),              // Templated
    .wvalid_s                           (wvalid_locked),         // Templated
    .wdata_s                            (wdata_locked[DATA_WIDTH-1:0]), // Templated
    .wstrb_s                            (wstrb_locked[STROB_WIDTH-1:0]), // Templated
    .wlast_s                            (wlast_locked),          // Templated
    // Inputs
    .aclk                               (clk  ),                 // Templated
    .aresetn                            (aww_lock_rst_n),        // Templated
    .awvalid_m                          (awvalid_m),             // Templated
    .awaddr_m                           (awaddr_m[SL_ADDR-1:0]), // Templated
    .awid_m                             (awid_m[SL_ID-1:0]),     // Templated
    .awlen_m                            (awlen_m[7:0]),          // Templated
    .awsize_m                           (awsize_m[2:0]),         // Templated
    .awburst_m                          (awburst_m[1:0]),        // Templated
    .awlock_m                           (awlock_m),              // Templated
    .awcache_m                          (awcache_m[3:0]),        // Templated
    .awprot_m                           (awprot_m[2:0]),         // Templated
    .awuser_m                           (awuser_m[SL_USER-1:0]), // Templated
    .awqos_m                            (awqos_m[3:0]),          // Templated
    .awready_s                          (awready_locked),        // Templated
    .wvalid_m                           (wvalid_m),              // Templated
    .wdata_m                            (wdata_m[DATA_WIDTH-1:0]), // Templated
    .wstrb_m                            (wstrb_m[STROB_WIDTH-1:0]), // Templated
    .wlast_m                            (wlast_m),               // Templated
    .wready_s                           (wready_locked));        // Templated


assign flr_rst_sync_n_neg = ~flr_rst_sync_n && flr_rst_sync_n_dff1;

localparam DIFF_WIDTH = 8;

reg [DIFF_WIDTH-1:0] awb_diff_cnt   ; // diff cnt for aw - b
reg [DIFF_WIDTH-1:0] arr_diff_cnt   ; // diff cnt for ar - r
reg                  awblock        ; // used to block master ready 
reg                  arblock        ; // used to block master ready

wire awvld_rdy     = awvalid_locked & awready_locked ; // axi handshake
wire wvld_rdy      = wvalid_locked  & wready_locked  ; // axi handshake
wire wvld_rdy_last = wvld_rdy       & wlast_locked   ; // axi handshake

wire bvld_rdy  = bvalid_s  & bready_s                ; // axi handshake
wire arvld_rdy = arvalid_m & arready_m               ; // axi handshake
wire rvld_rdy  = rvalid_s  & rready_s  & rlast_s     ; // axi handshake

wire awb_eq    = (awb_diff_cnt == {DIFF_WIDTH{1'b0}}); // aw == b
wire arr_eq    = (arr_diff_cnt == {DIFF_WIDTH{1'b0}}); // ar == r

reg [41:0] tmo_cnt_aw; // time out cnt
reg [41:0] tmo_cnt_ar; // time out cnt
wire       tmo_clr_aw = (tmo_cnt_aw >= {reg_block_tmo_thd_hi, reg_block_tmo_thd_lo}); // time out
wire       tmo_clr_ar = (tmo_cnt_ar >= {reg_block_tmo_thd_hi, reg_block_tmo_thd_lo}); // time out

always @(posedge clk or negedge rst_n) begin
    if(!rst_n) begin
        awblock <= 1'b0;
    end else if(reg_rsp_filter_en) begin
        if(awb_eq || tmo_clr_aw) begin
            awblock <= 1'b0;
        end else if(flr_rst_sync_n_neg && ~awb_eq) begin
            awblock <= 1'b1;
        end
    end else begin
        awblock <= 1'b0;
    end
end

always @(posedge clk or negedge rst_n) begin
    if(!rst_n) begin
        arblock <= 1'b0;
    end else if(reg_rsp_filter_en) begin
        if(arr_eq || tmo_clr_ar) begin
            arblock <= 1'b0;
        end else if(flr_rst_sync_n_neg && ~arr_eq) begin
            arblock <= 1'b1;
        end
    end else begin
        arblock <= 1'b0;
    end
end

always @(posedge clk or negedge rst_n) begin
    if(!rst_n) begin 
        tmo_cnt_aw <= 42'h0;
    end else if(awblock) begin
        if(tmo_clr_aw) begin
            tmo_cnt_aw <= 42'd0;
        end else begin
            tmo_cnt_aw <= tmo_cnt_aw + 42'd1;
        end
    end else begin
        tmo_cnt_aw <= 42'd0;
    end
end

always @(posedge clk or negedge rst_n) begin
    if(!rst_n) begin 
        tmo_cnt_ar <= 42'h0;
    end else if(arblock) begin
        if(tmo_clr_ar) begin
            tmo_cnt_ar <= 42'd0;
        end else begin
            tmo_cnt_ar <= tmo_cnt_ar + 42'd1;
        end
    end else begin
        tmo_cnt_ar <= 42'd0;
    end
end

wire tmo_intr_clr_sync;
reg  tmo_intr_clr_sync_dff1;

sig_sync tmo_intr_clr_inst(
    .clk   ( clk               ),
    .rst_n ( rst_n             ),
    .A    ( tmo_intr_clr      ),
    .Y   ( tmo_intr_clr_sync )
);

reg tmo_intr_reg;
always @(posedge clk or negedge rst_n) begin
    if(!rst_n) begin
        tmo_intr_reg <= 1'b0;
    end else if(reg_rsp_filter_en) begin
        if(tmo_clr_ar || tmo_clr_aw) begin
            tmo_intr_reg <= 1'b1;
        end else if(tmo_intr_clr_sync && ~tmo_intr_clr_sync_dff1) begin
            tmo_intr_reg <= 1'b0;
        end
    end else begin
        tmo_intr_reg <= 1'b0;
    end
end
assign tmo_intr = tmo_intr_reg;

always @(posedge clk or negedge rst_n) begin
    if(!rst_n) begin
        awb_diff_cnt <= {DIFF_WIDTH{1'b0}};
    end else if(reg_rsp_filter_en) begin
        if(tmo_clr_aw) begin
            awb_diff_cnt <= {DIFF_WIDTH{1'b0}};
        end else case({awvld_rdy, bvld_rdy})
            2'b01: if(awb_diff_cnt != {DIFF_WIDTH{1'b0}}) begin
                   awb_diff_cnt <= awb_diff_cnt - {{DIFF_WIDTH-1{1'b0}}, 1'b1};
            end
            2'b10: awb_diff_cnt <=  awb_diff_cnt + {{DIFF_WIDTH-1{1'b0}}, 1'b1};
        endcase
    end else begin
        awb_diff_cnt <= {DIFF_WIDTH{1'b0}};
    end
end

always @(posedge clk or negedge rst_n) begin
    if(!rst_n) begin
        arr_diff_cnt <= {DIFF_WIDTH{1'b0}};
    end else if(reg_rsp_filter_en) begin
        if(tmo_clr_ar) begin
            arr_diff_cnt <= {DIFF_WIDTH{1'b0}};
        end else case({arvld_rdy, rvld_rdy})
            2'b01: if(arr_diff_cnt != {DIFF_WIDTH{1'b0}}) begin
                   arr_diff_cnt <= arr_diff_cnt - {{DIFF_WIDTH-1{1'b0}}, 1'b1};
            end
            2'b10: arr_diff_cnt <=  arr_diff_cnt + {{DIFF_WIDTH-1{1'b0}}, 1'b1};
        endcase
    end else begin
        arr_diff_cnt <= {DIFF_WIDTH{1'b0}};
    end
end

reg  [3:0] awlen           ; 
reg  [3:0] awlen_flr       ; 
reg  [3:0] awlen_sec_flr   ; 
reg  [3:0] wchan_cnt       ;
reg        wlast_keep      ; 
wire       fill_finish     ; 
reg        fill_wchan      ; 
reg        sec_flr         ; 
reg        sec_flr_dly     ; 
wire [3:0] awlen_flr_mux   ;
reg        awtrans_wfill   ;

always @(posedge clk or negedge rst_n) begin
    if(!rst_n) begin
        awtrans_wfill <= 1'b0;
    end else if(fill_wchan) begin
        if(awvld_rdy) begin
            awtrans_wfill <= 1'b1;
        end
    end else begin
        awtrans_wfill <= 1'b0;
    end
end

always @(posedge clk or negedge rst_n) begin
    if(!rst_n) begin
        sec_flr <= 1'b0;
    end else if(fill_wchan) begin
        if(flr_rst_sync_n_neg) begin
            sec_flr <= 1'b1;
        end
    end else begin
        sec_flr <= 1'b0;
    end
end
always @(posedge clk or negedge rst_n) begin
    if(!rst_n) begin
        sec_flr_dly <= 1'b0;
    end else if(fill_wchan) begin
        if(fill_finish) begin
            sec_flr_dly <= sec_flr;
        end
    end else begin
        sec_flr_dly <= 1'b0;
    end
end

always @(posedge clk or negedge rst_n) begin
    if(!rst_n) begin 
        awlen  <= 4'h0;
    end else if(awvld_rdy) begin
        awlen  <= awlen_locked [3:0];
    end 
end
always @(posedge clk or negedge rst_n) begin
    if(!rst_n) begin
        awlen_flr <= 4'd0;
    end else if(flr_rst_sync_n_neg) begin
        awlen_flr <= awlen[3:0];
    end
end
always @(posedge clk or negedge rst_n) begin
    if(!rst_n) begin
        awlen_sec_flr <= 4'd0;
    end else if(fill_wchan && flr_rst_sync_n_neg) begin
        awlen_sec_flr <= awlen[3:0];
    end
end

always @(posedge clk or negedge rst_n) begin
    if(!rst_n) begin
        wlast_keep <= 1'b1;
    end else if(wvalid_slice && wready_slice) begin
        wlast_keep <= wlast_slice;
    end else if(awvalid_slice && awready_slice) begin
        wlast_keep <= 1'b0;
    end
end

always @(posedge clk or negedge rst_n) begin
    if(!rst_n) begin
        fill_wchan <= 1'b0;
    end else if(reg_rsp_filter_en) begin
        if(flr_rst_sync_n_neg && ~wlast_keep && ~wvld_rdy_last) begin
            fill_wchan <= ~fill_finish;
        end else if(fill_finish) begin
            fill_wchan <= sec_flr & (sec_flr_dly ? 1'b0 : awtrans_wfill);
        end
    end else begin
        fill_wchan <= 1'b0;
    end
end

always @(posedge clk or negedge rst_n) begin
    if(!rst_n) begin
        wchan_cnt <= 4'h0;
    end else if(reg_rsp_filter_en) begin
        if(wvalid_slice && wready_slice) begin
            if(fill_finish) begin
                wchan_cnt <= 4'd0;
            end else begin
                wchan_cnt <= wchan_cnt + 4'd1;
            end
        end
    end else begin
        wchan_cnt <= 4'd0;
    end
end

assign awlen_flr_mux = fill_wchan ? ((sec_flr && sec_flr_dly) ? awlen_sec_flr : awlen_flr) : (awvld_rdy ? awlen_locked[3:0] : awlen);
assign fill_finish   = (wchan_cnt >= awlen_flr_mux) && wvalid_slice && wready_slice;

wire wlast_fill = fill_wchan && fill_finish;
reg  wvalid_fill;
always @(posedge clk or negedge rst_n) begin
    if(!rst_n) begin
        wvalid_fill <= 1'b0;
    end else if(fill_wchan) begin
        if(~fill_finish) begin
            wvalid_fill <=  1'b1;
        end else begin
            wvalid_fill <= 1'b0;
        end
    end else begin
        wvalid_fill <= 1'b0;
    end
end

assign awready_locked = awready_slice  && ~ awblock;
assign wready_locked  = wready_slice   && ~(awblock | fill_wchan);
assign arready_m      = arready_slice  && ~ arblock;

assign rready_m_locked  = rready_m || arblock;
assign rid_m            = arblock ? '0 : rid_m_locked;
assign rvalid_m         = arblock ? '0 : rvalid_m_locked;
assign rdata_m          = arblock ? '0 : rdata_m_locked;
assign ruser_m          = arblock ? '0 : ruser_m_locked;
assign rresp_m          = arblock ? '0 : rresp_m_locked;
assign rlast_m          = arblock ? '0 : rlast_m_locked;

assign bid_slice      = bid_s                     ;
assign bresp_slice    = bresp_s                   ;
assign bvalid_slice   = bvalid_s       && ~awblock;
assign buser_slice    = buser_s                   ;
assign rvalid_slice   = rvalid_s       && ~arblock;
assign rdata_slice    = rdata_s                   ;
assign ruser_slice    = ruser_s                   ;
assign rresp_slice    = rresp_s                   ;
assign rid_slice      = rid_s                     ;
assign rlast_slice    = rlast_s                   ;

assign awvalid_slice  = awvalid_locked && ~awblock;
assign awaddr_slice   = awaddr_locked             ;
assign awid_slice     = awid_locked               ;
assign awlen_slice    = awlen_locked              ;
assign awsize_slice   = awsize_locked             ;
assign awburst_slice  = awburst_locked            ;
assign awlock_slice   = awlock_locked             ;
assign awcache_slice  = awcache_locked            ;
assign awprot_slice   = awprot_locked             ;
assign awuser_slice   = awuser_locked             ;
assign awqos_slice    = awqos_locked              ;

assign wvalid_slice   = fill_wchan ? wvalid_fill       : wvalid_locked;
assign wlast_slice    = fill_wchan ? wlast_fill        : wlast_locked ;
assign wstrb_slice    = fill_wchan ?{STROB_WIDTH{1'b0}}: wstrb_locked ;
assign wdata_slice    = fill_wchan ?{DATA_WIDTH {1'b0}}: wdata_locked ;
assign bready_s       = awblock |  bready_slice;

assign arvalid_slice  = arvalid_m && ~arblock;
assign araddr_slice   = araddr_m             ;
assign arid_slice     = arid_m               ;
assign arlen_slice    = arlen_m              ;
assign arsize_slice   = arsize_m             ;
assign arburst_slice  = arburst_m            ;
assign arlock_slice   = arlock_m             ;
assign arcache_slice  = arcache_m            ;
assign arprot_slice   = arprot_m             ;
assign aruser_slice   = aruser_m             ;
assign arqos_slice    = arqos_m              ;
assign rready_s       = arblock | rready_slice ;

/*slice_acel_w auto_template (
              .clk            (clk),
              .rst_n          (rst_n),
              .src_\(.*\)     (\1_slice[]),
              .dst_\(.*\)     (\1_s[]),
);
*/
slice_acel_w #(
  .DATA_WIDTH   (DATA_WIDTH ),
  .STROB_WIDTH  (STROB_WIDTH)
) slice_lock_w_inst
   (/*autoinst*/
    // Outputs
    .src_wready                         (wready_slice),          // Templated
    .dst_wvalid                         (wvalid_s),              // Templated
    .dst_wdata                          (wdata_s[DATA_WIDTH-1:0]), // Templated
    .dst_wstrb                          (wstrb_s[STROB_WIDTH-1:0]), // Templated
    .dst_wlast                          (wlast_s),               // Templated
    // Inputs
    .clk                                (clk),                   // Templated
    .rst_n                              (rst_n),                 // Templated
    .src_wvalid                         (wvalid_slice),          // Templated
    .src_wdata                          (wdata_slice[DATA_WIDTH-1:0]), // Templated
    .src_wstrb                          (wstrb_slice[STROB_WIDTH-1:0]), // Templated
    .src_wlast                          (wlast_slice),           // Templated
    .dst_wready                         (wready_s));             // Templated

/*slice_axi_aw auto_template (
              .clk            (clk),
              .rst_n          (rst_n),
              .src_\(.*\)     (\1_slice[]),
              .dst_\(.*\)     (\1_s[]),
);
*/
slice_axi_aw #(
    .SL_AW_ADDR(SL_ADDR), 
    .SL_AW_ID  (SL_ID  ), 
    .SL_AW_USER(SL_USER), 
    .SL_AW_LEN (8      )
) slice_lock_aw_inst
   (/*autoinst*/
    // Outputs
    .src_awready                        (awready_slice),         // Templated
    .dst_awvalid                        (awvalid_s),             // Templated
    .dst_awaddr                         (awaddr_s[SL_ADDR-1:0]), // Templated
    .dst_awid                           (awid_s[SL_ID-1:0]),     // Templated
    .dst_awlen                          (awlen_s[7:0]),          // Templated
    .dst_awsize                         (awsize_s[2:0]),         // Templated
    .dst_awburst                        (awburst_s[1:0]),        // Templated
    .dst_awlock                         (awlock_s),              // Templated
    .dst_awcache                        (awcache_s[3:0]),        // Templated
    .dst_awprot                         (awprot_s[2:0]),         // Templated
    .dst_awuser                         (awuser_s[SL_USER-1:0]), // Templated
    .dst_awqos                          (awqos_s[3:0]),          // Templated
    // Inputs
    .clk                                (clk),                   // Templated
    .rst_n                              (rst_n),                 // Templated
    .src_awvalid                        (awvalid_slice),         // Templated
    .src_awaddr                         (awaddr_slice[SL_ADDR-1:0]), // Templated
    .src_awid                           (awid_slice[SL_ID-1:0]), // Templated
    .src_awlen                          (awlen_slice[7:0]),      // Templated
    .src_awsize                         (awsize_slice[2:0]),     // Templated
    .src_awburst                        (awburst_slice[1:0]),    // Templated
    .src_awlock                         (awlock_slice),          // Templated
    .src_awcache                        (awcache_slice[3:0]),    // Templated
    .src_awprot                         (awprot_slice[2:0]),     // Templated
    .src_awuser                         (awuser_slice[SL_USER-1:0]), // Templated
    .src_awqos                          (awqos_slice[3:0]),      // Templated
    .dst_awready                        (awready_s));            // Templated

/*slice_axi_aw auto_template (
              .clk            (clk),
              .rst_n          (rst_n),
              .src_aw\(.*\)   (ar\1_slice[]),
              .dst_aw\(.*\)   (ar\1_s[]),
);
*/
slice_axi_aw #(
    .SL_AW_ADDR(SL_ADDR), 
    .SL_AW_ID  (SL_ID  ), 
    .SL_AW_USER(SL_USER), 
    .SL_AW_LEN (8      )
) slice_lock_ar_inst
   (/*autoinst*/
    // Outputs
    .src_awready                        (arready_slice),         // Templated
    .dst_awvalid                        (arvalid_s),             // Templated
    .dst_awaddr                         (araddr_s[SL_ADDR-1:0]), // Templated
    .dst_awid                           (arid_s[SL_ID-1:0]),     // Templated
    .dst_awlen                          (arlen_s[7:0]),          // Templated
    .dst_awsize                         (arsize_s[2:0]),         // Templated
    .dst_awburst                        (arburst_s[1:0]),        // Templated
    .dst_awlock                         (arlock_s),              // Templated
    .dst_awcache                        (arcache_s[3:0]),        // Templated
    .dst_awprot                         (arprot_s[2:0]),         // Templated
    .dst_awuser                         (aruser_s[SL_USER-1:0]), // Templated
    .dst_awqos                          (arqos_s[3:0]),          // Templated
    // Inputs
    .clk                                (clk),                   // Templated
    .rst_n                              (rst_n),                 // Templated
    .src_awvalid                        (arvalid_slice),         // Templated
    .src_awaddr                         (araddr_slice[SL_ADDR-1:0]), // Templated
    .src_awid                           (arid_slice[SL_ID-1:0]), // Templated
    .src_awlen                          (arlen_slice[7:0]),      // Templated
    .src_awsize                         (arsize_slice[2:0]),     // Templated
    .src_awburst                        (arburst_slice[1:0]),    // Templated
    .src_awlock                         (arlock_slice),          // Templated
    .src_awcache                        (arcache_slice[3:0]),    // Templated
    .src_awprot                         (arprot_slice[2:0]),     // Templated
    .src_awuser                         (aruser_slice[SL_USER-1:0]), // Templated
    .src_awqos                          (arqos_slice[3:0]),      // Templated
    .dst_awready                        (arready_s));            // Templated

/*slice_axi_b auto_template (
    .src_\(.*\) (\1_slice[]),
    .dst_\(.*\) (\1_m[]),
);*/

slice_axi_b #(
    .SL_ID   (SL_ID  ),
    .SL_USER (SL_USER)
)slice_axi_b_inst
   (/*autoinst*/
    // Outputs
    .src_bready                         (bready_slice),          // Templated
    .dst_bid                            (bid_m[SL_ID-1:0]),      // Templated
    .dst_bresp                          (bresp_m[1:0]),          // Templated
    .dst_bvalid                         (bvalid_m),              // Templated
    .dst_buser                          (buser_m[SL_USER-1:0]),  // Templated
    // Inputs
    .clk                                (clk),
    .rst_n                              (rst_n),
    .src_bid                            (bid_slice[SL_ID-1:0]),  // Templated
    .src_bresp                          (bresp_slice[1:0]),      // Templated
    .src_bvalid                         (bvalid_slice),          // Templated
    .src_buser                          (buser_slice[SL_USER-1:0]), // Templated
    .dst_bready                         (bready_m));             // Templated

/*slice_axi_r auto_template (
    .src_\(.*\) (\1_slice[]),
    .dst_\(.*\) (\1_m[]),
);*/

slice_axi_r #(
    .SL_ID      (SL_ID     ),
    .SL_USER    (SL_USER   ),
    .DATA_WIDTH (DATA_WIDTH)
)slice_axi_r_inst
   (/*autoinst*/
    // Outputs
    .dst_rid                            (rid_m_locked[SL_ID-1:0]),      // Templated
    .dst_rvalid                         (rvalid_m_locked),              // Templated
    .dst_rdata                          (rdata_m_locked[DATA_WIDTH-1:0]), // Templated
    .dst_ruser                          (ruser_m_locked[SL_USER-1:0]),  // Templated
    .dst_rresp                          (rresp_m_locked[1:0]),          // Templated
    .dst_rlast                          (rlast_m_locked),               // Templated
    .src_rready                         (rready_slice),          // Templated
    // Inputs
    .clk                                (clk),
    .rst_n                              (rst_n),
    //.dst_rready                         (rready_m),              // Templated
    .dst_rready                         (rready_m_locked),        // Templated
    .src_rvalid                         (rvalid_slice),          // Templated
    .src_rid                            (rid_slice[SL_ID-1:0]),  // Templated
    .src_rdata                          (rdata_slice[DATA_WIDTH-1:0]), // Templated
    .src_ruser                          (ruser_slice[SL_USER-1:0]), // Templated
    .src_rresp                          (rresp_slice[1:0]),      // Templated
    .src_rlast                          (rlast_slice));          // Templated

always @(posedge clk or negedge rst_n) begin
    if(!rst_n) begin
        flr_rst_sync_n         <= 1'b1;
        flr_rst_sync_n_dff1    <= 1'b1;
        tmo_intr_clr_sync_dff1 <= 1'b0;
    end else begin
        flr_rst_sync_n         <= flr_rst_n        ;
        flr_rst_sync_n_dff1    <= flr_rst_sync_n   ;
        tmo_intr_clr_sync_dff1 <= tmo_intr_clr_sync;
    end
end
endmodule
// Local Variables:
// verilog-library-directories:("./" )  
// verilog-auto-inst-param-value:t
// End:
