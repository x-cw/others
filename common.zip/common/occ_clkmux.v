module occ_clkmux   (
       //scan_clk_en,    //from top_dft_contrl at same power domain,all occ'scan_clk_en connect to
       scan_mode,
       mbist_mode,
       //mbist_clk_pad,
       //ac_scan_mode,
       occ_bypass,
       scan_clk,
       sw_en,
       scan_reset,
       func_clk,
       scan_se,
       clk_out,
       scan_in,
       scan_out
);

//Inputs
//input scan_clk_en;
input scan_mode;
input mbist_mode;
//input mbist_clk_pad;
//input ac_scan_mode;
input occ_bypass;
input scan_clk;
input sw_en;
input scan_reset;
input func_clk;
input scan_se;
input scan_in;

//Outputs
output clk_out;
output scan_out;
/////////////////////////////////////////////////////////
wire ac_scan_mode;
wire sw_en_sync1;
wire sw_en_sync0;
//wire ac_clk_in_inv;
wire scan_mode_gate;
wire scan_clk_gated_inv;
wire func_clk_g;
wire cap_en3;
wire cap_en2;
wire cap_en1;
wire cap_en0;
wire occ_clk_en;
wire sclk_en_or;
wire scan_clk_gated;
wire scan_clk_sel;
wire sel1;
wire sel0;
wire cap_en_0_n;
wire cap_en_1_n;
wire cap_en_2_n;
//wire cap_en_3_n;
//wire cap_en_4_n;
wire cycle2;
wire cycle2_n;
wire cycle3;
wire cycle3_n;
wire cycle3_en;
wire cycle4;
wire cycle4_n;
wire cycle4_en;
wire ac_clk;
wire ac_clk_in;
wire lockup_latch_out;
wire ac_clk_in_1;
wire scan_mode_clk;
wire pre_clk_out;
wire scan_mode_gclk;

///////////////////////////////////////////////TSMC12///////////////////////////////////////////////////
`ifdef TSMC12
//clock gater for inverted func_clk
INVD1BWP6T16P96CPD        inno_ac_scan_mode_inst (.ZN(ac_scan_mode),   .I(occ_bypass)); 
////AND2V2
AN2D1BWP6T16P96CPD         inno_scan_icg_en (.A1(ac_scan_mode),  .A2(scan_mode),   .Z(scan_mode_gate));
////CLKLANQV2
CKLNQCTD1BWP6T16P96CPD  inno_scan_icg    (.CP(func_clk),  .E(scan_mode_gate),    .Q(func_clk_g),   .TE(1'b0));


//Synchronizer
////NDRNQV2                 inno_sync_reg_1 (.RDN(scan_reset),      .CKN(func_clk_g),   .D(sw_en), .Q(sw_en_sync1));
DFNCNQD2BWP6T16P96CPD      inno_sync_reg_1 (.CDN(scan_reset),    .CPN(func_clk_g),   .D(sw_en), .Q(sw_en_sync1));

////NDRNQV2                 inno_sync_reg_0 (.RDN(scan_reset),      .CKN(func_clk_g),   .D(sw_en_sync1), .Q(sw_en_sync0));
DFNCNQD2BWP6T16P96CPD      inno_sync_reg_0 (.CDN(scan_reset),    .CPN(func_clk_g),   .D(sw_en_sync1), .Q(sw_en_sync0));

////NDRNQV2                 inno_cap_en3    (.RDN(scan_reset),      .CKN(func_clk_g),   .D(sw_en_sync0), .Q(cap_en3));
DFNCNQD2BWP6T16P96CPD      inno_cap_en3    (.CDN(scan_reset),    .CPN(func_clk_g),   .D(sw_en_sync0), .Q(cap_en3));

////NDRNQV2                 inno_cap_en2    (.RDN(scan_reset),      .CKN(func_clk_g),   .D(cap_en3), .Q(cap_en2));
DFNCNQD2BWP6T16P96CPD      inno_cap_en2    (.CDN(scan_reset),    .CPN(func_clk_g),   .D(cap_en3), .Q(cap_en2));

////NDRNQV2                 inno_cap_en1    (.RDN(scan_reset),      .CKN(func_clk_g),   .D(cap_en2), .Q(cap_en1));
DFNCNQD2BWP6T16P96CPD      inno_cap_en1    (.CDN(scan_reset),    .CPN(func_clk_g),   .D(cap_en2), .Q(cap_en1));

////NDRNQV2                 inno_cap_en0    (.RDN(scan_reset),      .CKN(func_clk_g),   .D(cap_en1), .Q(cap_en0));
DFNCNQD2BWP6T16P96CPD      inno_cap_en0    (.CDN(scan_reset),    .CPN(func_clk_g),   .D(cap_en1), .Q(cap_en0));
//////////////////////////////////////////////////
///  Generate gated scan clock  
/////////////////////////////////////////////////
////OR2V2                   inno_sclk_or    (.A1(occ_clk_en),  .A2(scan_se),  .Z(sclk_en_or) );
OR2D1BWP6T16P96CPD         inno_sclk_or    (.A1(occ_clk_en),   .A2(scan_se),   .Z(sclk_en_or) );

//xieanran changed
//////CLKNAND2V2              inno_sclk_nand  (.A1(sclk_en_or),  .A2(scan_clk), .Z(scan_clk_gated_inv) );
//SC7P5T_CKND2X2_SSC16R       inno_sclk_nand  (.EN(sclk_en_or),  .CLK(scan_clk), .Z(scan_clk_gated_inv) );
//
//////CLKINV2                 inno_sclk_inv   (.I(scan_clk_gated_inv),  .ZN(scan_clk_gated) );
//SC7P5T_CKINVX10_SSC16R      inno_sclk_inv   (.CLK(scan_clk_gated_inv),  .Z(scan_clk_gated) );
CKLNQCTD1BWP6T16P96CPD        inno_sclk_nand_icg (.CP(scan_clk),  .E(sclk_en_or),  .Q(scan_clk_gated),  .TE(1'b0));

////SDRNQV2                 inno_sel_1      (.CK(scan_clk),  .D(sel1),  .RDN(scan_reset),   .SE(scan_se),  .SI(scan_in),  .Q(sel1));
SDFCNQD2BWP6T16P96CPD      inno_sel_1      (.CP(scan_clk), .D(sel1),  .CDN(scan_reset), .SE(scan_se),  .SI(scan_in),  .Q(sel1));

////SDRNQV2                 inno_sel_0      (.CK(scan_clk),  .D(sel0),  .RDN(scan_reset),   .SE(scan_se),  .SI(sel1),  .Q(sel0));
SDFCNQD2BWP6T16P96CPD      inno_sel_0      (.CP(scan_clk),  .D(sel0), .CDN(scan_reset), .SE(scan_se),  .SI(sel1),  .Q(sel0));

 
////INV2                    inno_c2_cell1   (.ZN(cap_en_2_n),  .I(cap_en2));
INVD1BWP6T16P96CPD         inno_c2_cell1   (.ZN(cap_en_2_n),   .I(cap_en2));

////NAND2V2                 inno_c2_cell2   (.A1(cap_en_2_n),  .A2(sw_en_sync0),  .ZN(cycle2_n));
ND2D10BWP6T16P96CPD         inno_c2_cell2   (.A1(cap_en_2_n),   .A2(sw_en_sync0),   .ZN(cycle2_n));

////INV2                    inno_c2_cell3   (.ZN(cycle2),  .I(cycle2_n));
INVD1BWP6T16P96CPD         inno_c2_cell3   (.ZN(cycle2),   .I(cycle2_n));

////INV2                    inno_c3_cell1   (.ZN(cap_en_1_n),   .I(cap_en1));
INVD1BWP6T16P96CPD         inno_c3_cell1   (.ZN(cap_en_1_n),    .I(cap_en1));

////NAND2V2                 inno_c3_cell2   (.A1(cap_en_1_n),  .A2(sw_en_sync0),  .ZN(cycle3_n));
ND2D10BWP6T16P96CPD          inno_c3_cell2   (.A1(cap_en_1_n),   .A2(sw_en_sync0),    .ZN(cycle3_n));

////INV2                    inno_c3_cell3   (.ZN(cycle3),  .I(cycle3_n));
INVD1BWP6T16P96CPD         inno_c3_cell3   (.ZN(cycle3),  .I(cycle3_n));

////INV2                    inno_c4_cell1   (.ZN(cap_en_0_n),   .I(cap_en0));
INVD1BWP6T16P96CPD         inno_c4_cell1   (.ZN(cap_en_0_n),    .I(cap_en0));

////NAND2V2                 inno_c4_cell2   (.A1(cap_en_0_n),  .A2(sw_en_sync0),  .ZN(cycle4_n));
ND2D10BWP6T16P96CPD          inno_c4_cell2   (.A1(cap_en_0_n),   .A2(sw_en_sync0),   .ZN(cycle4_n));

////INV2                    inno_c4_cell3   (.ZN(cycle4),  .I(cycle4_n));
INVD1BWP6T16P96CPD         inno_c4_cell3   (.ZN(cycle4),   .I(cycle4_n));

////AND2V2
AN2D1BWP6T16P96CPD         inno_ac_clk_cell1  (.A1(cycle3),  .A2(sel1),  .Z(cycle3_en));

////AND2V2
AN2D1BWP6T16P96CPD         inno_ac_clk_cell2  (.A1(cycle4),  .A2(sel0),  .Z(cycle4_en));

////OR3V2                   inno_ac_clk_cell3  (.A1(cycle2),  .A2(cycle3_en),  .A3(cycle4_en),  .Z(ac_clk));
OR3D1BWP6T16P96CPD         inno_ac_clk_cell3  (.A1(cycle2),   .A2(cycle3_en),   .A3(cycle4_en),   .Z(ac_clk));

////SDRNQV2                 inno_occ_inst      (.CK(scan_clk),  .D(occ_clk_en),  .RDN(scan_reset),   .SE(scan_se),  .SI(sel0), .Q(occ_clk_en));
SDFCNQD2BWP6T16P96CPD      inno_occ_inst      (.CP(scan_clk),  .D(occ_clk_en), .CDN(scan_reset), .SE(scan_se),  .SI(sel0), .Q(occ_clk_en));

//Add lockup latch between last flop to scan_out
////LAHV2                   inno_lockup_latch   (.Q(lockup_latch_out),  .D(occ_clk_en),  .E(scan_clk));
//SC7P5T_LATQX2_SSC16R        inno_lockup_latch   (.Q(lockup_latch_out),  .D(occ_clk_en),  .CLK(scan_clk));  
//xieanran change    lockup should be low enable?
LNQD2BWP6T16P96CPD        inno_lockup_latch   (.Q(lockup_latch_out),  .D(occ_clk_en),  .EN(scan_clk));

////BUFV2                   inno_scan_out_buf   (.Z(scan_out),  .I(lockup_latch_out));
BUFFD1BWP6T16P96CPD         inno_scan_out_buf   (.Z(scan_out),  .I(lockup_latch_out));

////AND3V2                  inno_clk_sel_cell1  (.A1(ac_scan_mode),  .A2(sw_en),  .A3(scan_mode),  .Z(scan_clk_sel));
AN3D1BWP6T16P96CPD         inno_clk_sel_cell1  (.A1(ac_scan_mode),   .A2(sw_en),   .A3(scan_mode),   .Z(scan_clk_sel));

////AND2V2
AN2D1BWP6T16P96CPD         inno_clk_sel_cell2  (.A1(ac_clk),  .A2(occ_clk_en), .Z(ac_clk_in_1));

////CLKLANQV2 xieanran
CKLNQCTD1BWP6T16P96CPD  inno_clk_sel_icg     (.CP(func_clk),  .E(ac_clk_in_1),  .Q(ac_clk_in),  .TE(1'b0));

////CLKMUX2V2               inno_clk_sel_cell5   (.I0(scan_clk_gated),  .I1(ac_clk_in),  .S(scan_clk_sel), .Z(scan_mode_clk));
CKMUX2CTD1BWP6T16P96CPD      inno_clk_sel_cell5   (.I0(scan_clk_gated),  .I1(ac_clk_in),  .S(scan_clk_sel), .Z(scan_mode_clk));


//add clk_gating for scan_clock
////CLKLANQV2
//xieanran changed
//SC7P5T_CKGPRELATNX8_SSC16R   inno_scan_mode_clk_icg   (.CLK(scan_mode_clk),  .E(scan_clk_en),  .Z(scan_mode_gclk),  .TE(1'b0));
CKLNQCTD1BWP6T16P96CPD   inno_scan_mode_clk_icg   (.CP(scan_mode_clk),  .E(1'b1),  .Q(scan_mode_gclk),  .TE(1'b0));

////CLKMUX2V2                inno_clk_out_inst   (.I0(func_clk),  .I1(scan_mode_gclk),  .S(scan_mode), .Z(pre_clk_out));
CKMUX2CTD1BWP6T16P96CPD       inno_clk_out_inst   (.I0(func_clk),  .I1(scan_mode_gclk),  .S(scan_mode), .Z(pre_clk_out));

////BUFV2                    inno_mbist_pad_clk_buf   (.Z(mbist_clk_pad_buf),  .I(mbist_clk_pad));
//BUFFD1BWP6T16P96CPD          inno_mbist_pad_clk_buf   (.Z(mbist_clk_pad_buf),  .I(mbist_clk_pad));

////CLKMUX2V2                inno_bist_clk_mux_inst    (.I0(pre_clk_out),  .I1(mbist_clk_pad_buf),  .S(mbist_mode), .Z(clk_out));
CKMUX2CTD1BWP6T16P96CPD       inno_bist_clk_mux_inst    (.I0(pre_clk_out),  .I1(func_clk),  .S(mbist_mode), .Z(clk_out));
`endif
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


///////////////////////////////////////////////SAMSUNG14///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
`ifdef SS14
//clock gater for inverted func_clk
INV_X1N_A9PP84TR_C16      inno_ac_scan_mode_inst (.Y(ac_scan_mode),   .A(occ_bypass));
////AND2V2
AND2_X1N_A9PP84TR_C16      inno_scan_icg_en (.A(ac_scan_mode),  .B(scan_mode),   .Y(scan_mode_gate));
////CLKLANQV2
PREICG_X1N_A9PP84TR_C16  inno_scan_icg    (.CK(func_clk),  .E(scan_mode_gate),    .ECK(func_clk_g),   .SE(1'b0));

//Synchronizer
////NDRNQV2                 inno_sync_reg_1 (.RDN(scan_reset),      .CKN(func_clk_g),   .D(sw_en), .Q(sw_en_sync1));
DFFRPQ_X2N_A9PP84TR_C16    inno_sync_reg_1 (.R(~scan_reset),    .CK(~func_clk_g),   .D(sw_en), .Q(sw_en_sync1));

////NDRNQV2                 inno_sync_reg_0 (.RDN(scan_reset),      .CKN(func_clk_g),   .D(sw_en_sync1), .Q(sw_en_sync0));
DFFRPQ_X2N_A9PP84TR_C16    inno_sync_reg_0 (.R(~scan_reset),    .CK(~func_clk_g),   .D(sw_en_sync1), .Q(sw_en_sync0));

////NDRNQV2                 inno_cap_en3    (.RDN(scan_reset),      .CKN(func_clk_g),   .D(sw_en_sync0), .Q(cap_en3));
DFFRPQ_X2N_A9PP84TR_C16    inno_cap_en3 (.R(~scan_reset),    .CK(~func_clk_g),   .D(sw_en_sync0), .Q(cap_en3));

////NDRNQV2                 inno_cap_en2    (.RDN(scan_reset),      .CKN(func_clk_g),   .D(cap_en3), .Q(cap_en2));
DFFRPQ_X2N_A9PP84TR_C16    inno_cap_en2 (.R(~scan_reset),    .CK(~func_clk_g),   .D(cap_en3), .Q(cap_en2));

////NDRNQV2                 inno_cap_en1    (.RDN(scan_reset),      .CKN(func_clk_g),   .D(cap_en2), .Q(cap_en1));
DFFRPQ_X2N_A9PP84TR_C16    inno_cap_en1 (.R(~scan_reset),    .CK(~func_clk_g),   .D(cap_en2), .Q(cap_en1));

////NDRNQV2                 inno_cap_en0    (.RDN(scan_reset),      .CKN(func_clk_g),   .D(cap_en1), .Q(cap_en0));
DFFRPQ_X2N_A9PP84TR_C16    inno_cap_en0 (.R(~scan_reset),    .CK(~func_clk_g),   .D(cap_en1), .Q(cap_en0));
//////////////////////////////////////////////////
///  Generate gated scan clock  
/////////////////////////////////////////////////
////OR2V2                   inno_sclk_or    (.A1(occ_clk_en),  .A2(scan_se),  .Z(sclk_en_or) );
OR2_X1N_A9PP84TR_C16       inno_sclk_or    (.A(occ_clk_en),   .B(scan_se),   .Y(sclk_en_or) );

//xieanran changed
//////CLKNAND2V2              inno_sclk_nand  (.A1(sclk_en_or),  .A2(scan_clk), .Z(scan_clk_gated_inv) );
//SC7P5T_CKND2X2_SSC16R       inno_sclk_nand  (.EN(sclk_en_or),  .CLK(scan_clk), .Z(scan_clk_gated_inv) );
//
//////CLKINV2                 inno_sclk_inv   (.I(scan_clk_gated_inv),  .ZN(scan_clk_gated) );
//SC7P5T_CKINVX10_SSC16R      inno_sclk_inv   (.CLK(scan_clk_gated_inv),  .Z(scan_clk_gated) );
PREICG_X1N_A9PP84TR_C16  inno_sclk_nand_icg    (.CK(scan_clk),  .E(sclk_en_or),    .ECK(scan_clk_gated),   .SE(1'b0));

////SDRNQV2                 inno_sel_1      (.CK(scan_clk),  .D(sel1),  .RDN(scan_reset),   .SE(scan_se),  .SI(scan_in),  .Q(sel1));
SDFFRPQ_X2N_A9PP84TR_C16   inno_sel_1      (.CK(scan_clk), .D(sel1),  .R(~scan_reset), .SE(scan_se),  .SI(scan_in),  .Q(sel1));

////SDRNQV2                 inno_sel_0      (.CK(scan_clk),  .D(sel0),  .RDN(scan_reset),   .SE(scan_se),  .SI(sel1),  .Q(sel0));
SDFFRPQ_X2N_A9PP84TR_C16   inno_sel_0      (.CK(scan_clk), .D(sel0),  .R(~scan_reset), .SE(scan_se),  .SI(sel1),  .Q(sel0));

 
////INV2                    inno_c2_cell1   (.ZN(cap_en_2_n),  .I(cap_en2));
INV_X1N_A9PP84TR_C16        inno_c2_cell1 (.Y(cap_en_2_n),   .A(cap_en2));

////NAND2V2                 inno_c2_cell2   (.A1(cap_en_2_n),  .A2(sw_en_sync0),  .ZN(cycle2_n));
NAND2_X4N_A9PP84TR_C16      inno_c2_cell2   (.A(cap_en_2_n),   .B(sw_en_sync0),   .Y(cycle2_n));

////INV2                    inno_c2_cell3   (.ZN(cycle2),  .I(cycle2_n));
INV_X1N_A9PP84TR_C16        inno_c2_cell3 (.Y(cycle2),   .A(cycle2_n));

////INV2                    inno_c3_cell1   (.ZN(cap_en_1_n),   .I(cap_en1));
INV_X1N_A9PP84TR_C16        inno_c3_cell1 (.Y(cap_en_1_n),   .A(cap_en1));

////NAND2V2                 inno_c3_cell2   (.A1(cap_en_1_n),  .A2(sw_en_sync0),  .ZN(cycle3_n));
NAND2_X4N_A9PP84TR_C16      inno_c3_cell2   (.A(cap_en_1_n),   .B(sw_en_sync0),   .Y(cycle3_n));

////INV2                    inno_c3_cell3   (.ZN(cycle3),  .I(cycle3_n));
INV_X1N_A9PP84TR_C16        inno_c3_cell3 (.Y(cycle3),   .A(cycle3_n));

////INV2                    inno_c4_cell1   (.ZN(cap_en_0_n),   .I(cap_en0));
INV_X1N_A9PP84TR_C16        inno_c4_cell1 (.Y(cap_en_0_n),   .A(cap_en0));

////NAND2V2                 inno_c4_cell2   (.A1(cap_en_0_n),  .A2(sw_en_sync0),  .ZN(cycle4_n));
NAND2_X4N_A9PP84TR_C16      inno_c4_cell2   (.A(cap_en_0_n),   .B(sw_en_sync0),   .Y(cycle4_n));

////INV2                    inno_c4_cell3   (.ZN(cycle4),  .I(cycle4_n));
INV_X1N_A9PP84TR_C16        inno_c4_cell3 (.Y(cycle4),   .A(cycle4_n));

////AND2V2
AND2_X1N_A9PP84TR_C16      inno_ac_clk_cell1 (.A(cycle3),  .B(sel1),   .Y(cycle3_en));

////AND2V2
AND2_X1N_A9PP84TR_C16      inno_ac_clk_cell2 (.A(cycle4),  .B(sel0),   .Y(cycle4_en));

////OR3V2                   inno_ac_clk_cell3  (.A1(cycle2),  .A2(cycle3_en),  .A3(cycle4_en),  .Z(ac_clk));
OR3_X1N_A9PP84TR_C16       inno_ac_clk_cell3  (.A(cycle2),   .B(cycle3_en),   .C(cycle4_en),   .Y(ac_clk));

////SDRNQV2                 inno_occ_inst      (.CK(scan_clk),  .D(occ_clk_en),  .RDN(scan_reset),   .SE(scan_se),  .SI(sel0), .Q(occ_clk_en));
SDFFRPQ_X2N_A9PP84TR_C16   inno_occ_inst      (.CK(scan_clk),  .D(occ_clk_en), .R(~scan_reset), .SE(scan_se),  .SI(sel0), .Q(occ_clk_en));

//Add lockup latch between last flop to scan_out
////LAHV2                   inno_lockup_latch   (.Q(lockup_latch_out),  .D(occ_clk_en),  .E(scan_clk));
//SC7P5T_LATQX2_SSC16R        inno_lockup_latch   (.Q(lockup_latch_out),  .D(occ_clk_en),  .CLK(scan_clk));  
//xieanran change    lockup should be low enable?
LATNQ_X2N_A9PP84TR_C16    inno_lockup_latch   (.Q(lockup_latch_out),  .D(occ_clk_en),  .GN(scan_clk));

////BUFV2                   inno_scan_out_buf   (.Z(scan_out),  .I(lockup_latch_out));
BUF_X1N_A9PP84TR_C16        inno_scan_out_buf   (.Y(scan_out),  .A(lockup_latch_out));

////AND3V2                  inno_clk_sel_cell1  (.A1(ac_scan_mode),  .A2(sw_en),  .A3(scan_mode),  .Z(scan_clk_sel));
AND3_X1N_A9PP84TR_C16      inno_clk_sel_cell1  (.A(ac_scan_mode),   .B(sw_en),   .C(scan_mode),   .Y(scan_clk_sel));

////AND2V2
AND2_X1N_A9PP84TR_C16      inno_clk_sel_cell2 (.A(ac_clk),  .B(occ_clk_en),   .Y(ac_clk_in_1));

////CLKLANQV2 xieanran
PREICG_X1N_A9PP84TR_C16  inno_clk_sel_icg    (.CK(func_clk),  .E(ac_clk_in_1),    .ECK(ac_clk_in),   .SE(1'b0));

////CLKMUX2V2               inno_clk_sel_cell5   (.I0(scan_clk_gated),  .I1(ac_clk_in),  .S(scan_clk_sel), .Z(scan_mode_clk));
MXT2_X1N_A9PP84TR_C16        inno_clk_sel_cell5   (.A(scan_clk_gated),  .B(ac_clk_in),  .S0(scan_clk_sel), .Y(scan_mode_clk));


//add clk_gating for scan_clock
////CLKLANQV2
//xieanran changed
//SC7P5T_CKGPRELATNX8_SSC16R   inno_scan_mode_clk_icg   (.CLK(scan_mode_clk),  .E(scan_clk_en),  .Z(scan_mode_gclk),  .TE(1'b0));
PREICG_X1N_A9PP84TR_C16  inno_scan_mode_clk_icg    (.CK(scan_mode_clk),  .E(1'b1),    .ECK(scan_mode_gclk),   .SE(1'b0));

////CLKMUX2V2                inno_clk_out_inst   (.I0(func_clk),  .I1(scan_mode_gclk),  .S(scan_mode), .Z(pre_clk_out));
MXT2_X1N_A9PP84TR_C16        inno_clk_out_inst   (.A(func_clk),  .B(scan_mode_gclk),  .S0(scan_mode), .Y(pre_clk_out));

////BUFV2                    inno_mbist_pad_clk_buf   (.Z(mbist_clk_pad_buf),  .I(mbist_clk_pad));
//BUFFD1BWP6T16P96CPD          inno_mbist_pad_clk_buf   (.Z(mbist_clk_pad_buf),  .I(mbist_clk_pad));

////CLKMUX2V2                inno_bist_clk_mux_inst    (.I0(pre_clk_out),  .I1(mbist_clk_pad_buf),  .S(mbist_mode), .Z(clk_out));
MXT2_X1N_A9PP84TR_C16        inno_bist_clk_mux_inst   (.A(pre_clk_out),  .B(func_clk),  .S0(mbist_mode), .Y(clk_out));
`endif
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


endmodule
