`timescale 1 ns / 1 ps
module reset_n_sync_dft #(
    parameter ADD_BEATS = 0,
    parameter WID       = 1
) (
    dft_test_mode   ,
    dft_test_rstn   ,
    rst_n           ,
    clk             ,
    rst_n_sync
);


input  wire   dft_test_mode    ;
input  wire   dft_test_rstn    ;
input  [WID-1:0]       rst_n            ;
input                  clk              ;
//asynch restz active, synch restz end
output [WID-1:0]       rst_n_sync       ;

wire [WID-1:0] rst_muxed_n  ;

//////////
wire [WID-1:0]         rst_n_sync       ;
reg  [WID-1:0]         latchff_clk      ;
reg  [ADD_BEATS+1:0]   syncrstz_clk [WID-1:0]    ;

genvar i;
generate
  for(i=0;i<WID;i=i+1)begin: gen_mult
    assign rst_muxed_n[i] = dft_test_mode ? dft_test_rstn : rst_n[i];

    always@(posedge clk or negedge rst_muxed_n[i])
       if (!rst_muxed_n[i])
          latchff_clk[i] <= 1'b0 ;
       else
          latchff_clk[i] <= 1'b1 ;
    
    always@(posedge clk or negedge rst_muxed_n[i]) //HH: to avoid short rst_n pulse glitch
       if (!rst_muxed_n[i])
          syncrstz_clk[i][0] <= 1'b0 ;
       else
          syncrstz_clk[i][0] <= latchff_clk[i] ;
    
    always@(posedge clk)
          syncrstz_clk[i][ADD_BEATS+1:1] <= syncrstz_clk[i][ADD_BEATS:0] ;
    
    assign rst_n_sync[i] = dft_test_mode ? dft_test_rstn : latchff_clk[i] && (&syncrstz_clk[i]) ;

  end
endgenerate


endmodule
