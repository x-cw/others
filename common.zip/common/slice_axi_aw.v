//******************************************************************************
//
//   Copyright (c) 2020 Innosilicon. All rights reserved.
//
//   THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF INNOSILICON
//   The copyright notice above does not evidence any actual or intended
//   publication of such source code.
//
//    Module name: slice_axi_aw.v
//    Create by: Huck He
//    Create time: 2020-12-04
//
//    Change List:
// 
//
//
//******************************************************************************

module slice_axi_aw  #
  (
    parameter  SLICE_RESET_SYNC = 0 ,
    parameter  SL_AW_LEN        = 4 ,
    parameter  SL_AW_ADDR       = 40,
    parameter  SL_AW_ID         = 9 ,
    parameter  SL_AW_USER       = 13 
  )
  (
    input                     clk              ,
    input                     rst_n            ,
    //input channel
    input                     src_awvalid      ,
    input  [SL_AW_ADDR-1:0]   src_awaddr       ,
    input  [SL_AW_ID-1:0]     src_awid         ,
    input  [SL_AW_LEN-1:0]    src_awlen        ,
    input  [2:0]              src_awsize       ,
    input  [1:0]              src_awburst      ,
    input                     src_awlock       ,
    input  [3:0]              src_awcache      ,
    input  [2:0]              src_awprot       ,
    input  [SL_AW_USER-1:0]   src_awuser       ,
    input  [3:0]              src_awqos        ,
    output                    src_awready      ,
    //output channel
    output                    dst_awvalid      ,
    output [SL_AW_ADDR-1:0]   dst_awaddr       ,
    output [SL_AW_ID-1:0]     dst_awid         ,
    output [SL_AW_LEN-1:0]    dst_awlen        ,
    output [2:0]              dst_awsize       ,
    output [1:0]              dst_awburst      ,
    output                    dst_awlock       ,
    output [3:0]              dst_awcache      ,
    output [2:0]              dst_awprot       ,
    output [SL_AW_USER-1:0]   dst_awuser       ,
    output [3:0]              dst_awqos        ,
    input                     dst_awready      
  );


localparam SL_TOTAL_WIDTH = SL_AW_ADDR + SL_AW_ID + SL_AW_USER + SL_AW_LEN + 17;

wire [SL_TOTAL_WIDTH-1:0]  payload_src;
wire [SL_TOTAL_WIDTH-1:0]  payload_dst;

assign payload_src = {
                      src_awaddr  ,//         input  [SL_AW_ADDR-1:0];
                      src_awid    ,//         input  [SL_AW_ID-1:0]  ;
                      src_awlen   ,//         input  [3:0]           ;
                      src_awsize  ,//         input  [2:0]           ;
                      src_awburst ,//         input  [1:0]           ;
                      src_awlock  ,//         input                  ;
                      src_awcache ,//         input  [3:0]           ;
                      src_awprot  ,//         input  [2:0]           ;
                      src_awuser  ,//         input  [SL_AW_USER-1:0];
                      src_awqos    //         input  [3:0]           ;
                     };

assign {dst_awaddr    ,            //         output [SL_AW_ADDR-1:0]
        dst_awid      ,            //         output [SL_AW_ID-1:0]  
        dst_awlen     ,            //         output [3:0]           
        dst_awsize    ,            //         output [2:0]           
        dst_awburst   ,            //         output [1:0]           
        dst_awlock    ,            //         output                 
        dst_awcache   ,            //         output [3:0]           
        dst_awprot    ,            //         output [2:0]           
        dst_awuser    ,            //         output [SL_AW_USER-1:0]
        dst_awqos                  //         output [3:0]           
       }         = payload_dst; 

full_regd_slice #(
    .SLICE_RESET_SYNC (SLICE_RESET_SYNC),
    .WIDTH            (SL_TOTAL_WIDTH)
  ) slice_aw (
    .rst_b       (rst_n             ), 
    .clk         (clk               ), 
                             
    .payload_src (payload_src       ), 
    .valid_src   (src_awvalid       ), 
    .ready_src   (src_awready       ),
    
    .payload_dst (payload_dst       ),
    .valid_dst   (dst_awvalid       ), 
    .ready_dst   (dst_awready       )  
);

endmodule
