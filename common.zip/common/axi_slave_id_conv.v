//******************************************************************************
//
//   Copyright (c) 2020 Innosilicon. All rights reserved.
//
//   THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF INNOSILICON
//   The copyright notice above does not evidence any actual or intended
//   publication of such source code.
//
//    Module name: axi_slave_id_conv
//    Create by: Huck He
//    Create time: 2020-05-22
//
//    Change List:
// 
//
//
//******************************************************************************
//
// This is the general module for converting *_user sidgeband signals into/from slave
// ID and generate output IDs to real slaves/AXI buses.
// This module should be connected to 
// 
// 1. For "real" slaves 
// 1.1.  For AW/W/AR channels, master selection ID bits are removed, and 7-bit *_user 
//       signals are added directly to the higher bits of slave side IDs. 
//           For cfg_bus, *_user are placed to *id[12:6], 
//           For dat_bus, *_user are placed to *id[14:8].
// 1.2. For R/B channels, slave replied ID's high bits are extracted to *_user 
//      and removed. And several bits of higher IDs are added to let AXI routing
//      logic could put them back to the correct master. This routing rule
//      should be configurable through parameters for different buses.
//     
//
// 2. For "bus" slaves 
// 2.1. For AW/W/AR channels, [x:8] ID bits are removed, and 7-bit *_user 
//      signals are passed through. 
// 2.2. For R/B channels, slave replied ID's high bits are extracted to *_user 
//      and removed. And several bits of higher IDs are added to let AXI routing
//      logic could put them back to the correct master. This routing rule
//      should be configurable through parameters for different buses.
//     
// 3. *_user definition：
//        [6:5]: Chip_id selection, 2'b00 means chip0 (main chip). 2'b01~2'b11
//               are chip1~chip3. 
//        [4]  : cfg_bus / data bus selection, 1'b0 means cfg_bus, 1'b1 means
//               data_bus
//        [3:2]: when cfg_bus, [3:2] are cfg bus master selection; 
//               when dat_bus, [3:2] are data bus matrix slection, 
//        [1:0]: when cfg_bus, these bits are reserved.
//               when dat_bus, [1:0] are data bus axi selection.
//

module axi_slave_id_conv 
#(
parameter REAL_SLAVE      = 1        , //if slave port is connected to a real slave, this bit should be set to 1; if slave port is another axi bus element (axi bus or x2x converter), set 0

parameter USER_BIT        = 7        , //Width of user signals (AXI sideband signals)
parameter MAS_ID          = 8        , //Main AXI bus master ID width , this AXI bus's slave port is connected with this module 
parameter SLV_ID          = 10       , //Main AXI bus slave ID width  , this AXI bus's slave port is connected with this module 
parameter SLV_ID_DOWN     = 15       , //should  = (REAL_SLAVE ? (MAS_ID+USER_BIT) : MAS_ID) ;

parameter MAS_USER_HI     = 3        , //AXI user high bit for master ID decoding
parameter MAS1_CODE       = 2'b00    , //MASTER 1 decoding rule
parameter MAS2_CODE       = 2'b01    , //MASTER 2 decoding rule
parameter MAS3_CODE       = 2'b10    , //MASTER 3 decoding rule
parameter MAS4_CODE       = 2'b11    , //MASTER 4 decoding rule8
parameter MAS5_USER       = 4        , //MASTER 5 decoding using which bit of user.
parameter MAS5_USER_INV   = 0          //MASTER 5 decoding using INTVERTED bit or not inverted bit
)
(

//bus side
mas_awid,
mas_wid, 
mas_arid,
mas_rid,
mas_bid,

mas_aw_user,
mas_w_user,
mas_ar_user,
mas_r_user,
mas_b_user,

//slave side
slv_awid,
slv_wid, 
slv_arid,
slv_rid,
slv_bid,

slv_aw_user,
slv_w_user,
slv_ar_user,
slv_r_user,
slv_b_user


);



parameter EXTRA_MAS_ID    = (SLV_ID - MAS_ID)   ;
//parameter SLV_ID_DOWN     = (REAL_SLAVE ? (MAS_ID+USER_BIT) : MAS_ID) ;




//bus side
input  [SLV_ID-1:0]   mas_awid;
input  [SLV_ID-1:0]   mas_wid; 
input  [SLV_ID-1:0]   mas_arid;
output [SLV_ID-1:0]   mas_rid;
output [SLV_ID-1:0]   mas_bid;

input  [USER_BIT-1:0] mas_aw_user;
input  [USER_BIT-1:0] mas_w_user;
input  [USER_BIT-1:0] mas_ar_user;
output [USER_BIT-1:0] mas_r_user;
output [USER_BIT-1:0] mas_b_user;

//slave side
output [SLV_ID_DOWN-1:0]   slv_awid;
output [SLV_ID_DOWN-1:0]   slv_wid; 
output [SLV_ID_DOWN-1:0]   slv_arid;
input  [SLV_ID_DOWN-1:0]   slv_rid;
input  [SLV_ID_DOWN-1:0]   slv_bid;

output  [USER_BIT-1:0] slv_aw_user;
output  [USER_BIT-1:0] slv_w_user;
output  [USER_BIT-1:0] slv_ar_user;
input   [USER_BIT-1:0] slv_r_user;
input   [USER_BIT-1:0] slv_b_user;


wire   [2:0]   r_mas_info;
wire   [2:0]   b_mas_info;

reg    [2:0]   mas_rid_hi;
reg    [2:0]   mas_bid_hi;



//channels AR, AW, W id output
assign slv_awid   = REAL_SLAVE ?   {mas_aw_user,  mas_awid[MAS_ID-1:0]} : mas_awid[MAS_ID-1:0] ;
assign slv_arid   = REAL_SLAVE ?   {mas_ar_user,  mas_arid[MAS_ID-1:0]} : mas_arid[MAS_ID-1:0] ;
assign slv_wid    = REAL_SLAVE ?   {mas_w_user ,   mas_wid[MAS_ID-1:0]} :  mas_wid[MAS_ID-1:0] ;

//channels R, B id output
//user signals re-generation
assign mas_r_user =   REAL_SLAVE ? slv_rid[MAS_ID+USER_BIT-1:MAS_ID] : slv_r_user ;
assign mas_b_user =   REAL_SLAVE ? slv_bid[MAS_ID+USER_BIT-1:MAS_ID] : slv_b_user ;


assign r_mas_info =  MAS5_USER_INV ? {~mas_r_user[MAS5_USER],mas_r_user[MAS_USER_HI:MAS_USER_HI-1] } : 
                                     { mas_r_user[MAS5_USER],mas_r_user[MAS_USER_HI:MAS_USER_HI-1] } ;
assign b_mas_info =  MAS5_USER_INV ? {~mas_b_user[MAS5_USER],mas_b_user[MAS_USER_HI:MAS_USER_HI-1] } :
                                     { mas_b_user[MAS5_USER],mas_b_user[MAS_USER_HI:MAS_USER_HI-1] } ;

//mas ID generation : r channel
always @ (*) begin
    casex ( r_mas_info )
        3'b1??           : mas_rid_hi = 3'b100;
        {1'b0, MAS1_CODE}: mas_rid_hi = 3'b000;
        {1'b0, MAS2_CODE}: mas_rid_hi = 3'b001;
        {1'b0, MAS3_CODE}: mas_rid_hi = 3'b010;
        {1'b0, MAS4_CODE}: mas_rid_hi = 3'b011;
        default          : mas_rid_hi = 3'b111; //should not happen !!
    endcase
end
assign mas_rid = (EXTRA_MAS_ID == 2'h2) ? {mas_rid_hi[1:0], slv_rid[MAS_ID-1:0]} : // 2~4 masters
                 (EXTRA_MAS_ID == 2'h3) ? {mas_rid_hi[2:0], slv_rid[MAS_ID-1:0]} : //  >4 masters
                                           slv_rid[MAS_ID-1:0] ;                   //   1 master

always @ (*) begin
    casex ( b_mas_info ) 
        3'b1??           : mas_bid_hi = 3'b100;
        {1'b0, MAS1_CODE}: mas_bid_hi = 3'b000;
        {1'b0, MAS2_CODE}: mas_bid_hi = 3'b001;
        {1'b0, MAS3_CODE}: mas_bid_hi = 3'b010;
        {1'b0, MAS4_CODE}: mas_bid_hi = 3'b011;
        default          : mas_bid_hi = 3'b111; //should not happen !!
    endcase
end
assign mas_bid = (EXTRA_MAS_ID == 2'h2) ? {mas_bid_hi[1:0], slv_bid[MAS_ID-1:0]} : // 2~4 masters
                 (EXTRA_MAS_ID == 2'h3) ? {mas_bid_hi[2:0], slv_bid[MAS_ID-1:0]} : //  >4 masters
                                           slv_bid[MAS_ID-1:0] ;                   //   1 master


assign slv_aw_user   =   slv_aw_user ; 
assign slv_w_user    =   slv_w_user  ; 
assign slv_ar_user   =   slv_ar_user ; 




endmodule
