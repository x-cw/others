//******************************************************************************
//
//   Copyright (c) 2020 Innosilicon. All rights reserved.
//
//   THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF INNOSILICON
//   The copyright notice above does not evidence any actual or intended
//   publication of such source code.
//
//    Module name: slice_acel_w.v
//    Create by: Huck He
//    Create time: 2020-08-10
//
//    Change List:
// 
//
//
//******************************************************************************

module slice_acel_w  #
  (
    parameter  SLICE_RESET_SYNC = 0,
    parameter  DATA_WIDTH       = 256,
    parameter  STROB_WIDTH      = 32
  )
  (
    input                     clk              ,
    input                     rst_n            ,
    // Write Data Channel, master side 
    input                     src_wvalid       ,
    input  [DATA_WIDTH-1:0]   src_wdata        ,
    input  [STROB_WIDTH-1:0]  src_wstrb        ,
    input                     src_wlast        ,
    output                    src_wready       ,
    
    // Write Data Channel, slave side 
    output                    dst_wvalid       ,
    output  [DATA_WIDTH-1:0]  dst_wdata        ,
    output  [STROB_WIDTH-1:0] dst_wstrb        ,
    output                    dst_wlast        ,
    input                     dst_wready       
  );


localparam SL_TOTAL_WIDTH =  DATA_WIDTH + STROB_WIDTH + 1;

wire [SL_TOTAL_WIDTH-1:0]  payload_src;
wire [SL_TOTAL_WIDTH-1:0]  payload_dst;

assign payload_src = {
                      src_wdata ,
                      src_wstrb ,
                      src_wlast 
                     };

assign {
        dst_wdata ,
        dst_wstrb ,
        dst_wlast 
       }          = payload_dst; 

full_regd_slice #(
    .SLICE_RESET_SYNC (SLICE_RESET_SYNC),
    .WIDTH            (SL_TOTAL_WIDTH)
  ) slice_w (
    .rst_b       (rst_n             ), 
    .clk         (clk               ), 
                             
    .payload_src (payload_src       ), 
    .valid_src   (src_wvalid        ), 
    .ready_src   (src_wready        ),
    
    .payload_dst (payload_dst       ),
    .valid_dst   (dst_wvalid        ), 
    .ready_dst   (dst_wready        )  
);

endmodule
