// +FHDR----------------------------------------------------------------------------
// Project Name  : virtural_prj
// Author        : xuxq
// Email         : xuxq@innosilicon.com.cn
// Create On     : 2024/03/12 19:27
// Last Modified : 2024/03/12 19:27
// File Name     : general_slice_dti.v
// Description   :
// 
// Copyright (c) 2024 Innosilicon.
// ALL RIGHTS RESERVED
// 
// ---------------------------------------------------------------------------------
// Modification History:
// Date         By              Version                 Change Description
// ---------------------------------------------------------------------------------
// 2024/03/12   xuxq            1.0                     Original
// 
// -FHDR----------------------------------------------------------------------------
`timescale 1ns/1ps

module general_slice_dti #(
     parameter DATA_WIDTH  = 160, 
     parameter SLICE_NUM_DTI = 4
)
(
   // Outputs
   tbu2slice_tready_dti, slice2tbu_tvalid_dti, slice2tbu_tlast_dti,
   slice2tbu_tkeep_dti, slice2tbu_tdata_dti, slice2adb_tvalid_dti,
   slice2adb_tlast_dti, slice2adb_tkeep_dti, slice2adb_tdata_dti,
   adb2slice_tready_dti,
   // Inputs
   tbu2slice_tvalid_dti, tbu2slice_tlast_dti, tbu2slice_tkeep_dti,
   tbu2slice_tdata_dti, slice2tbu_tready_dti, slice2adb_tready_dti,
   core_resetn, core_clk, adb2slice_tvalid_dti, adb2slice_tlast_dti,
   adb2slice_tkeep_dti, adb2slice_tdata_dti
   );
// Beginning of automatic inputs (from unused autoinst inputs)
input [DATA_WIDTH - 1:0]      adb2slice_tdata_dti;    // To u_bas_reg_slice_160_sw1_0 of mmu_700_bas_reg_slice.v
input [(DATA_WIDTH / 8) -1:0]     adb2slice_tkeep_dti;    // To u_bas_reg_slice_160_sw1_0 of mmu_700_bas_reg_slice.v
input                   adb2slice_tlast_dti;    // To u_bas_reg_slice_160_sw1_0 of mmu_700_bas_reg_slice.v
input                   adb2slice_tvalid_dti;   // To u_bas_reg_slice_160_sw1_0 of mmu_700_bas_reg_slice.v
input                   core_clk;               // To u_bas_reg_slice_160_sw1_0 of mmu_700_bas_reg_slice.v
input                   core_resetn;            // To u_bas_reg_slice_160_sw1_0 of mmu_700_bas_reg_slice.v
input                   slice2adb_tready_dti;   // To u_bas_reg_slice_160_sw1_0 of mmu_700_bas_reg_slice.v
input                   slice2tbu_tready_dti;   // To u_bas_reg_slice_160_sw1_0 of mmu_700_bas_reg_slice.v
input [DATA_WIDTH - 1:0]      tbu2slice_tdata_dti;    // To u_bas_reg_slice_160_sw1_0 of mmu_700_bas_reg_slice.v
input [(DATA_WIDTH / 8) -1:0]     tbu2slice_tkeep_dti;    // To u_bas_reg_slice_160_sw1_0 of mmu_700_bas_reg_slice.v
input                   tbu2slice_tlast_dti;    // To u_bas_reg_slice_160_sw1_0 of mmu_700_bas_reg_slice.v
input                   tbu2slice_tvalid_dti;   // To u_bas_reg_slice_160_sw1_0 of mmu_700_bas_reg_slice.v
// End of automatics
// Beginning of automatic outputs (from unused autoinst outputs)
output                  adb2slice_tready_dti;   // From u_bas_reg_slice_160_sw1_0 of mmu_700_bas_reg_slice.v
output [DATA_WIDTH - 1:0]     slice2adb_tdata_dti;    // From u_bas_reg_slice_160_sw1_0 of mmu_700_bas_reg_slice.v
output [(DATA_WIDTH / 8) -1:0]    slice2adb_tkeep_dti;    // From u_bas_reg_slice_160_sw1_0 of mmu_700_bas_reg_slice.v
output                  slice2adb_tlast_dti;    // From u_bas_reg_slice_160_sw1_0 of mmu_700_bas_reg_slice.v
output                  slice2adb_tvalid_dti;   // From u_bas_reg_slice_160_sw1_0 of mmu_700_bas_reg_slice.v
output [DATA_WIDTH - 1:0]     slice2tbu_tdata_dti;    // From u_bas_reg_slice_160_sw1_0 of mmu_700_bas_reg_slice.v
output [(DATA_WIDTH / 8) -1:0]    slice2tbu_tkeep_dti;    // From u_bas_reg_slice_160_sw1_0 of mmu_700_bas_reg_slice.v
output                  slice2tbu_tlast_dti;    // From u_bas_reg_slice_160_sw1_0 of mmu_700_bas_reg_slice.v
output                  slice2tbu_tvalid_dti;   // From u_bas_reg_slice_160_sw1_0 of mmu_700_bas_reg_slice.v
output                  tbu2slice_tready_dti;   // From u_bas_reg_slice_160_sw1_0 of mmu_700_bas_reg_slice.v
// End of automatics

///*mmu_700_bas_reg_slice auto_template "u_bas_reg_slice_160_sw1_0" (
//    .clk              (core_clk ),
//    .resetn           (core_resetn),
//
//    .twakeup.*dn_s.* (1'b0),
//    .twakeup.*up_m   (1'b0),
//    .twakeup.*up_s.* (),
//    .twakeup.*dn_m   (),
//    .qreqn_cg        (1'b1),
//    .q.*             (),
//
//    .tdest_dti_up_s(),
//    .tid_dti_dn_m (),
//    .tdest_dti_up_m({@"vl-width"{1'd0}}),
//    .tid_dti_dn_s({@"vl-width"{1'd0}}),
//
//    .\(.*\)_dn_s              (tbu2slice_\1[]),
//    .\(.*\)_dn_m              (tbu2slice_\1[]),  
//    .\(.*\)_up_s              (adb2slice_\1[]),
//    .\(.*\)_up_m              (adb2slice_\1[]),
//    
//    // other
//    .\(.*\)                          (\1[]),
//
//    )
//*/
genvar i;
generate if(SLICE_NUM_DTI ==0) begin:pass_through
    assign  slice2adb_tdata_dti  = tbu2slice_tdata_dti ;    
    assign  slice2adb_tkeep_dti = tbu2slice_tkeep_dti;    
    assign  slice2adb_tlast_dti = tbu2slice_tlast_dti;    
    assign  slice2adb_tvalid_dti = tbu2slice_tvalid_dti;   
    assign tbu2slice_tready_dti = slice2adb_tready_dti;   

    assign slice2tbu_tdata_dti = adb2slice_tdata_dti;    
    assign slice2tbu_tkeep_dti = adb2slice_tkeep_dti;    
    assign slice2tbu_tlast_dti = adb2slice_tlast_dti;    
    assign slice2tbu_tvalid_dti = adb2slice_tvalid_dti;   
    assign adb2slice_tready_dti  = slice2tbu_tready_dti ;   
  end
  else begin:gen_slice
   //wire
    wire [DATA_WIDTH - 1:0]      adb2slice_tdata_dti_i[SLICE_NUM_DTI:0];    
    wire [(DATA_WIDTH / 8) -1:0]     adb2slice_tkeep_dti_i[SLICE_NUM_DTI:0];    
    wire                   adb2slice_tlast_dti_i[SLICE_NUM_DTI:0];    
    wire                   adb2slice_tvalid_dti_i[SLICE_NUM_DTI:0]; 
    wire                  adb2slice_tready_dti_i[SLICE_NUM_DTI:0];   

    wire [DATA_WIDTH - 1:0]      tbu2slice_tdata_dti_i[SLICE_NUM_DTI:0];    
    wire [(DATA_WIDTH / 8) -1:0]     tbu2slice_tkeep_dti_i[SLICE_NUM_DTI:0];    
    wire                   tbu2slice_tlast_dti_i[SLICE_NUM_DTI:0];    
    wire                   tbu2slice_tvalid_dti_i[SLICE_NUM_DTI:0];   
    wire                  tbu2slice_tready_dti_i[SLICE_NUM_DTI:0];   
      
   //input
    assign adb2slice_tdata_dti_i[0] = adb2slice_tdata_dti ;    
    assign adb2slice_tkeep_dti_i[0] = adb2slice_tkeep_dti ;    
    assign adb2slice_tlast_dti_i[0] = adb2slice_tlast_dti ;    
    assign adb2slice_tvalid_dti_i[0] = adb2slice_tvalid_dti ;   
    assign adb2slice_tready_dti = adb2slice_tready_dti_i[0];   


    assign tbu2slice_tdata_dti_i[0] = tbu2slice_tdata_dti ;    
    assign tbu2slice_tkeep_dti_i[0] = tbu2slice_tkeep_dti ;    
    assign tbu2slice_tlast_dti_i[0] = tbu2slice_tlast_dti ;    
    assign tbu2slice_tvalid_dti_i[0] = tbu2slice_tvalid_dti ;   
    assign tbu2slice_tready_dti = tbu2slice_tready_dti_i[0];   

   //output
    assign  slice2tbu_tdata_dti = adb2slice_tdata_dti_i[SLICE_NUM_DTI];    
    assign  slice2tbu_tkeep_dti = adb2slice_tkeep_dti_i[SLICE_NUM_DTI];    
    assign  slice2tbu_tlast_dti = adb2slice_tlast_dti_i[SLICE_NUM_DTI];    
    assign  slice2tbu_tvalid_dti = adb2slice_tvalid_dti_i[SLICE_NUM_DTI];   
    assign  adb2slice_tready_dti_i[SLICE_NUM_DTI] = slice2tbu_tready_dti;   

    assign  slice2adb_tdata_dti = tbu2slice_tdata_dti_i[SLICE_NUM_DTI];    
    assign  slice2adb_tkeep_dti = tbu2slice_tkeep_dti_i[SLICE_NUM_DTI];    
    assign  slice2adb_tlast_dti = tbu2slice_tlast_dti_i[SLICE_NUM_DTI];    
    assign  slice2adb_tvalid_dti = tbu2slice_tvalid_dti_i[SLICE_NUM_DTI];   
    assign  tbu2slice_tready_dti_i[SLICE_NUM_DTI] = slice2adb_tready_dti;   

  for(i=0; i<SLICE_NUM_DTI; i=i+1 ) begin:dti_slice
     
     
     mmu_700_bas_reg_slice #(
         .DATA_WIDTH (DATA_WIDTH  ) , 
         .ID_WIDTH   ( 0  ) , 
         .MODE       ( 0   ) 
     )  
     mmu_700_bas_reg_slice
     (
      // Outputs
      .tready_dti_dn_s                       (tbu2slice_tready_dti_i[i]),  // Templated
      .tvalid_dti_up_s                       (adb2slice_tvalid_dti_i[i+1]),  // Templated
      .tdata_dti_up_s                        (adb2slice_tdata_dti_i[i+1]), // Templated
      .tkeep_dti_up_s                        (adb2slice_tkeep_dti_i[i+1]), // Templated
      .tlast_dti_up_s                        (adb2slice_tlast_dti_i[i+1]),   // Templated
      .tdest_dti_up_s                        (),                      // Templated
      .tvalid_dti_dn_m                       (tbu2slice_tvalid_dti_i[i+1]),  // Templated
      .tdata_dti_dn_m                        (tbu2slice_tdata_dti_i[i+1]), // Templated
      .tkeep_dti_dn_m                        (tbu2slice_tkeep_dti_i[i+1]), // Templated
      .tlast_dti_dn_m                        (tbu2slice_tlast_dti_i[i+1]),   // Templated
      .tid_dti_dn_m                          (),                      // Templated
      .tready_dti_up_m                       (adb2slice_tready_dti_i[i]),  // Templated
      .twakeup_dti_up_s                      (),                      // Templated
      .twakeup_dti_dn_m                      (),                      // Templated
      .qactive_cg                            (),                      // Templated
      .qacceptn_cg                           (),                      // Templated
      .qdeny_cg                              (),                      // Templated
      // Inputs
      .resetn                                (core_resetn),           // Templated
      .clk                                   (core_clk ),             // Templated
      .tvalid_dti_dn_s                       (tbu2slice_tvalid_dti_i[i]),  // Templated
      .tdata_dti_dn_s                        (tbu2slice_tdata_dti_i[i]), // Templated
      .tkeep_dti_dn_s                        (tbu2slice_tkeep_dti_i[i]), // Templated
      .tlast_dti_dn_s                        (tbu2slice_tlast_dti_i[i]),   // Templated
      .tid_dti_dn_s                          (1'b0),  // Templated
      .tready_dti_up_s                       (adb2slice_tready_dti_i[i+1]),  // Templated
      .tready_dti_dn_m                       (tbu2slice_tready_dti_i[i+1]),  // Templated
      .tvalid_dti_up_m                       (adb2slice_tvalid_dti_i[i]),  // Templated
      .tdata_dti_up_m                        (adb2slice_tdata_dti_i[i]), // Templated
      .tkeep_dti_up_m                        (adb2slice_tkeep_dti_i[i]), // Templated
      .tlast_dti_up_m                        (adb2slice_tlast_dti_i[i]),   // Templated
      .tdest_dti_up_m                        (1'b0),  // Templated
      .twakeup_dti_dn_s                      (1'b0),                  // Templated
      .twakeup_dti_up_m                      (1'b0),                  // Templated
      .qreqn_cg                              (1'b1));                         // Templated
    end
   end
endgenerate



endmodule
// Local Variables:
// verilog-library-directories:("./" "../../../../../smmu/rtl/mmu700_logical/mmu_700_bas_reg_slice/verilog/") 
// verilog-auto-inst-param-value:t
// End:
