module   freq_div_2n (
   clk,
   rst_n,
   enable  ,
   n2_exp ,
   fout		// Output.
);


input			clk;
input			rst_n;
input           enable ;
input  [2:0]    n2_exp ;

output			fout;


`ifdef  FPGA_SYN
 assign fout = clk;

`else

parameter DIVCNT_WIDTH = 9;

reg [DIVCNT_WIDTH-1:0]  DivCnt ;
reg fout_pre ;

 
  always @ (posedge clk or negedge rst_n)
    begin
      if(!rst_n)
        begin
          DivCnt <= {(DIVCNT_WIDTH){1'b0}};
        end
      else  if(enable)
        begin 
            DivCnt <= DivCnt + 1'b1 ;
        end 
     else
	   DivCnt <= {(DIVCNT_WIDTH){1'b0}} ;
    end

	
  always @ (posedge clk or negedge rst_n)
    begin
      if(!rst_n)
        begin
          fout_pre <= 1'b0;
        end
      else  if(enable) 
        begin
          case(n2_exp[2:0])
          3'd0 : fout_pre <= DivCnt[0] ;
          3'd1 : fout_pre <= DivCnt[1] ;
          3'd2 : fout_pre <= DivCnt[2] ;
          3'd3 : fout_pre <= DivCnt[3] ;
          3'd4 : fout_pre <= DivCnt[4] ;
          3'd5 : fout_pre <= DivCnt[5] ;
          3'd6 : fout_pre <= DivCnt[6] ;
          3'd7 : fout_pre <= DivCnt[7] ;
          default : fout_pre <= DivCnt[0] ;
          endcase
        end
      else
        begin
          fout_pre <= 1'b0;
        end
    end

cell_clk_buf clk_div_buf (.clki(fout_pre), .clko(fout));

`endif

endmodule
