`timescale 1 ns / 1 ps
module cell_inverter (
    input  A   ,
    output X   
);

`ifdef SIM
assign X = ~A;


`else
//From /Foundry/ARM/samsung_14lpp/Standard_Cell/arm/samsung/14lpp/sc9mcpp84_base_rvt_c16/r1p1/verilog/sc9mcpp84_14lpp_base_rvt_c16.v
//INV_X8N_A9PP84TR_C16 dont_touch_inv_u(.A(A), .Y(X));

`ifdef  FPGA_SYN
assign X = ~A;
`else
//From /Foundry/ARM/samsung_14lpu/Standard_Cell/samsung/ln14lpu_sc_s8p25t_flk_slvt_c84_V1.50_pkg/FE-Common/FE-Common_sec250430_0098/MODEL/ln14lpu_sc_s8p25t_flk_slvt_c84l16/ln14lpu_sc_s8p25t_flk_slvt_c84l16.v
CLKINV_D8_N_S8P25TSL_C84L16  dont_touch_inv_u(.A(A), .Y(X));

`endif


///Foundry/ARM/samsung_8lpp/Standard_Cell/SynopsysIP/samsung08nlvh/22hs/hsl/rvt/3.00a/verilog/3.0/sa08nlhslogl22hsl068f.v
///Foundry/ARM/samsung_8lpp/Standard_Cell/SynopsysIP/samsung08nlvh/22hs/hsl/rvt/3.00a/verilog/std_primitives.v
//
///Foundry/ARM/samsung_8lpp/Standard_Cell/SynopsysIP/samsung08nlvg/22hd/hdp/rvt/latest/verilog/3.0/sa08nlgslogl22hdp068f.v
///Foundry/ARM/samsung_8lpp/Standard_Cell/SynopsysIP/samsung08nlvg/22hd/hdp/rvt/latest/verilog/std_primitives.v
//`elsif USE_HSB_LIB
//HSBSVT22_INV_4 dont_touch_inv_u(.A(A), .X(X));
//
//`else
//HDBSVT22_INV_4 dont_touch_inv_u(.A(A), .X(X));


//`else
///Foundry/ARM/samsung_5lpeAT/Standard_Cell/samsung/ln05lpe_sc_m7p5t_flk_lvt_c60_a00_V3.01_pkg/FE-Common_sec240318_0094/MODEL/ln05lpe_sc_m7p5t_flk_lvt_c60l08/ln05lpe_sc_m7p5t_flk_lvt_c60l08.v
//CLKINV_D8_N_M7P5TL_C60L08 dont_touch_inv_u(.A(A), .X(X));



///Foundry/ARM/samsung_4lpp/Standard_Cell/samsung/ln04lpp_sc_s7p94t_flk_lvt_c60_V1.11_pkg/FE-Common/FE-Common_sec250710_0002/MODEL/flk/ln04lpp_sc_s7p94t_flk_lvt_c60l06.v
//CLKINV_D8_N_S7P94TL_C60L06 dont_touch_inv_u(.A(A), .Y(X));

`endif
endmodule
