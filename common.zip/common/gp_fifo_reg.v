
module gp_fifo_reg 
  #(parameter
    FIFO_WIDTH=0,
    FIFO_WORDS=0,
    
    L2_FIFO_WORDS=$clog2(FIFO_WORDS)
    ) (
       input wire                    clk,
       input wire                    reset_n,
       
       //read
       input wire                    rd_en,
       output wire [FIFO_WIDTH-1:0]   dout,
       
       //write
       input wire                    wr_en,
       input wire [FIFO_WIDTH-1:0]   din,
       
       //status
       output wire                   empty,
       output reg                    full
       );

  reg  [L2_FIFO_WORDS:0] wr_addr;    // write address for fifo RAM
  reg  [L2_FIFO_WORDS:0] rd_addr;    // read address for fifo RAM
    
  reg [FIFO_WIDTH-1:0]  fifo_mem     [FIFO_WORDS-1:0];

  genvar i;
  generate
    for(i=0;i<FIFO_WORDS;i=i+1) begin
      always @(posedge clk ) begin
        if(wr_en && (wr_addr[L2_FIFO_WORDS-1:0] == i)) begin
          fifo_mem[i] <= din;
        end
      end
    end
  endgenerate

  assign dout = fifo_mem[rd_addr[L2_FIFO_WORDS-1:0]];

  assign empty = (wr_addr == rd_addr);
  assign full  = (wr_addr[L2_FIFO_WORDS] != rd_addr[L2_FIFO_WORDS]) && (wr_addr[L2_FIFO_WORDS-1:0] == rd_addr[L2_FIFO_WORDS-1:0]);

  always @(posedge clk, negedge reset_n) begin
    if (!reset_n) begin
        wr_addr <= 0;
    end
    else if (wr_en) begin
        if(wr_addr == (FIFO_WORDS*2-1)) begin
            wr_addr <= 'b0;
        end
        else begin
            wr_addr <= wr_addr + 'b1;
        end
    end 
  end

  always @(posedge clk, negedge reset_n) begin
    if (!reset_n) begin
        rd_addr <= 0;
    end
    else if (rd_en) begin
        if(rd_addr == (FIFO_WORDS*2-1)) begin
            rd_addr <= 'b0;
        end
        else begin
            rd_addr <= rd_addr + 'b1;
        end
    end 
  end

endmodule
