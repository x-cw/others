//******************************************************************************
//
//   Copyright (c) 2020 Innosilicon. All rights reserved.
//
//   THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF INNOSILICON
//   The copyright notice above does not evidence any actual or intended
//   publication of such source code.
//
//    Module name: ar_r_limit_outstand.v
//    Create by: Huck He
//    Create time: 2021-01-29
//
//    Change List:
// 
//
//
//******************************************************************************


module ar_r_limit_outstand #
   (
    parameter  SLICE_RESET_SYNC = 0,
    parameter  SL_AR_ADDR = 40     ,
    parameter  SL_AR_ID   = 10     ,
    parameter  SL_AR_USER = 13 
   )
   (
   /*autoarg*/
   // Outputs
   m_arready, s_arvalid, s_araddr, s_arid, s_arlen, s_arsize,
   s_arburst, s_arlock, s_arcache, s_arprot, s_aruser, s_arqos,
   s_arsnoop, s_ardomain, s_arbar,
   // Inputs
   aclk, aresetn, ar_outstand_lim, ar_outstand_clr, ar_outstand_dis,
   m_rvalid, m_rready, m_rlast, m_arvalid, m_araddr, m_arid, m_arlen,
   m_arsize, m_arburst, m_arlock, m_arcache, m_arprot, m_aruser,
   m_arqos, m_arsnoop, m_ardomain, m_arbar, s_arready
   );

  input                     aclk;
  input                     aresetn;

  input  [5:0]              ar_outstand_lim;
  input                     ar_outstand_clr;
  input                     ar_outstand_dis;

// Read Data Channel from AXI Master
  input                     m_rvalid  ;
  input                     m_rready  ;
  input                     m_rlast   ;

  //read data channel connecting to AXI master (master direction)

  input                     m_arvalid      ;
  input  [SL_AR_ADDR-1:0]   m_araddr       ;
  input  [SL_AR_ID-1:0]     m_arid         ;
  input  [3:0]              m_arlen        ;
  input  [2:0]              m_arsize       ;
  input  [1:0]              m_arburst      ;
  input                     m_arlock       ;
  input  [3:0]              m_arcache      ;
  input  [2:0]              m_arprot       ;
  input  [SL_AR_USER-1:0]   m_aruser       ;
  input  [3:0]              m_arqos        ;
  input  [3:0]              m_arsnoop      ;
  input  [1:0]              m_ardomain     ;
  input  [1:0]              m_arbar        ;
  output                    m_arready      ;
 
  //read addr channel connecting to AXI bus matrix (slave direction) 
  output                    s_arvalid      ;
  output [SL_AR_ADDR-1:0]   s_araddr       ;
  output [SL_AR_ID-1:0]     s_arid         ;
  output [3:0]              s_arlen        ;
  output [2:0]              s_arsize       ;
  output [1:0]              s_arburst      ;
  output                    s_arlock       ;
  output [3:0]              s_arcache      ;
  output [2:0]              s_arprot       ;
  output [SL_AR_USER-1:0]   s_aruser       ;
  output [3:0]              s_arqos        ;
  output [3:0]              s_arsnoop      ;
  output [1:0]              s_ardomain     ;
  output [1:0]              s_arbar        ;
  input                     s_arready      ;


/*autowire*/

wire          ar_trans;
wire          r_trans;

wire          arvalid_slice;
wire          arready_slice; //consider reorder, re-generate s_rready for SLICE

reg  [7:0]    axi_ar_r_inc_cnt;

reg  [5:0]    cnt_limit_pre;
reg  [5:0]    cnt_limit;

reg           trig_clear_d0;
reg           trig_clear_d1;
reg           trig_clear_d2;

reg           ar_outstand_dis_d0;
reg           ar_outstand_dis_d1;


assign ar_trans =  m_arvalid & m_arready;
assign  r_trans =  m_rvalid  & m_rready & m_rlast;

//sync for cnt_limit, trig_clear
always@(posedge aclk or negedge aresetn)
  if(!aresetn) begin
    cnt_limit_pre <= 6'd32;
    cnt_limit     <= 6'd32;
    trig_clear_d2 <= 1'b0 ;
    trig_clear_d1 <= 1'b0 ;
    trig_clear_d0 <= 1'b0 ;
    ar_outstand_dis_d0 <= 1'b0;
    ar_outstand_dis_d1 <= 1'b0;
  end else begin
    cnt_limit_pre <= ar_outstand_lim ;
    cnt_limit     <= cnt_limit_pre    ;
    {trig_clear_d2,trig_clear_d1,trig_clear_d0} <= {trig_clear_d1,trig_clear_d0,ar_outstand_clr};
    {ar_outstand_dis_d1, ar_outstand_dis_d0} <= {ar_outstand_dis_d0, ar_outstand_dis};
  end

always@(posedge aclk or negedge aresetn) begin
  if(!aresetn) 
    axi_ar_r_inc_cnt <= 8'h0;
  else if ( trig_clear_d1 && (!trig_clear_d2) ) //posedge of trig_clear
    axi_ar_r_inc_cnt <= 8'h0;
  else if(ar_trans && r_trans)
    axi_ar_r_inc_cnt <= axi_ar_r_inc_cnt;
  else if(ar_trans)
    axi_ar_r_inc_cnt <= axi_ar_r_inc_cnt + 8'h1;
  else if(r_trans)
    axi_ar_r_inc_cnt <= axi_ar_r_inc_cnt - 8'h1;
end

assign s_arvalid     = arvalid_slice & (ar_outstand_dis_d1 ? 1'b1 : (axi_ar_r_inc_cnt <= cnt_limit));
assign arready_slice = s_arready     & (ar_outstand_dis_d1 ? 1'b1 : (axi_ar_r_inc_cnt <= cnt_limit));

/*slice_acel_ar auto_template (
              .clk            (aclk           ),
              .rst_n          (aresetn        ),

              .dst_arready    (arready_slice   ),
              .dst_arvalid    (arvalid_slice   ),
              .src_\(.*\)     (m_\1[]         ),
              .dst_\(.*\)     (s_\1[]         ),

);
*/
slice_acel_ar  #(.SLICE_RESET_SYNC (SLICE_RESET_SYNC), .SL_AR_ADDR(SL_AR_ADDR), .SL_AR_ID(SL_AR_ID), .SL_AR_USER(SL_AR_USER)) 
        slice_ar_limit_inst (/*autoinst*/
                             // Outputs
                             .src_arready       (m_arready         ), // Templated
                             .dst_arvalid       (arvalid_slice   ), // Templated
                             .dst_araddr        (s_araddr[SL_AR_ADDR-1:0]         ), // Templated
                             .dst_arid          (s_arid[SL_AR_ID-1:0]         ), // Templated
                             .dst_arlen         (s_arlen[3:0]         ), // Templated
                             .dst_arsize        (s_arsize[2:0]         ), // Templated
                             .dst_arburst       (s_arburst[1:0]         ), // Templated
                             .dst_arlock        (s_arlock         ), // Templated
                             .dst_arcache       (s_arcache[3:0]         ), // Templated
                             .dst_arprot        (s_arprot[2:0]         ), // Templated
                             .dst_aruser        (s_aruser[SL_AR_USER-1:0]         ), // Templated
                             .dst_arqos         (s_arqos[3:0]         ), // Templated
                             .dst_arsnoop       (s_arsnoop[3:0]         ), // Templated
                             .dst_ardomain      (s_ardomain[1:0]         ), // Templated
                             .dst_arbar         (s_arbar[1:0]         ), // Templated
                             // Inputs
                             .clk               (aclk           ), // Templated
                             .rst_n             (aresetn        ), // Templated
                             .src_arvalid       (m_arvalid         ), // Templated
                             .src_araddr        (m_araddr[SL_AR_ADDR-1:0]         ), // Templated
                             .src_arid          (m_arid[SL_AR_ID-1:0]         ), // Templated
                             .src_arlen         (m_arlen[3:0]         ), // Templated
                             .src_arsize        (m_arsize[2:0]         ), // Templated
                             .src_arburst       (m_arburst[1:0]         ), // Templated
                             .src_arlock        (m_arlock         ), // Templated
                             .src_arcache       (m_arcache[3:0]         ), // Templated
                             .src_arprot        (m_arprot[2:0]         ), // Templated
                             .src_aruser        (m_aruser[SL_AR_USER-1:0]         ), // Templated
                             .src_arqos         (m_arqos[3:0]         ), // Templated
                             .src_arsnoop       (m_arsnoop[3:0]         ), // Templated
                             .src_ardomain      (m_ardomain[1:0]         ), // Templated
                             .src_arbar         (m_arbar[1:0]         ), // Templated
                             .dst_arready       (arready_slice   )); // Templated


endmodule 
// Local Variables:
// verilog-library-directories:("./")  
// verilog-auto-inst-param-value:t
// End:
