// +FHDR----------------------------------------------------------------------------
// Project Name  : virtural_prj
// Author        : xuxq
// Email         : xuxq@innosilicon.com.cn
// Create On     : 2024/03/12 15:44
// Last Modified : 2024/03/12 15:44
// File Name     : ip_wrap/general_slice.v
// Description   :
// 
// Copyright (c) 2024 Innosilicon.
// ALL RIGHTS RESERVED
// 
// ---------------------------------------------------------------------------------
// Modification History:
// Date         By              Version                 Change Description
// ---------------------------------------------------------------------------------
// 2024/03/12   xuxq            1.0                     Original
// 
// -FHDR----------------------------------------------------------------------------
`timescale 1ns/1ps

module general_slice_axi3 #(
    parameter  SLICE_NUM_AXI =4,
    parameter  DATA_WIDTH  = 256,
    parameter  STROB_WIDTH = 32,
    parameter  LEN_WIDTH =  8,
    parameter  ADDR_WIDTH = 64,
    parameter  ID_WIDTH =14,
    parameter  USER_WIDTH =12,
    parameter  LOCK_WIDTH =2
)(
   // Outputs
   src_wready, src_rready, src_bready, src_awready, src_arready,
   dst_wvalid, dst_wstrb, dst_wlast, dst_wdata,dst_wid,dst_rvalid, dst_ruser,
   dst_rresp, dst_rlast, dst_rid, dst_rdata, dst_bvalid, dst_buser,
   dst_bresp, dst_bid, dst_awvalid, dst_awuser, dst_awsize, dst_awqos,
   dst_awprot, dst_awlock, dst_awlen, dst_awid, dst_awcache,
   dst_awburst, dst_awaddr, dst_arvalid, dst_aruser, dst_arsize,
   dst_arqos, dst_arprot, dst_arlock, dst_arlen, dst_arid,
   dst_arcache, dst_arburst, dst_araddr,
   // Inputs
   src_wvalid, src_wstrb, src_wlast, src_wdata,src_wid,src_rvalid, src_ruser,
   src_rresp, src_rlast, src_rid, src_rdata, src_bvalid, src_buser,
   src_bresp, src_bid, src_awvalid, src_awuser, src_awsize, src_awqos,
   src_awprot, src_awlock, src_awlen, src_awid, src_awcache,
   src_awburst, src_awaddr, src_arvalid, src_aruser, src_arsize,
   src_arqos, src_arprot, src_arlock, src_arlen, src_arid,
   src_arcache, src_arburst, src_araddr, rst_n, dst_wready,
   dst_rready, dst_bready, dst_awready, dst_arready, clk
   );
// Beginning of automatic inputs (from unused autoinst inputs)
input                   clk;                    // To slice_axi_aw_inst0 of slice_axi_aw.v, ...
input                   dst_arready;            // To slice_axi_ar_inst0 of slice_axi_aw.v
input                   dst_awready;            // To slice_axi_aw_inst0 of slice_axi_aw.v
input                   dst_bready;             // To slice_axi_b_inst0 of slice_axi_b.v
input                   dst_rready;             // To slice_axi_r_inst0 of slice_axi_r.v
input                   dst_wready;             // To slice_axi_w_inst0 of slice_acel_w.v
input                   rst_n;                  // To slice_axi_aw_inst0 of slice_axi_aw.v, ...
input [ADDR_WIDTH-1:0]  src_araddr;             // To slice_axi_ar_inst0 of slice_axi_aw.v
input [1:0]             src_arburst;            // To slice_axi_ar_inst0 of slice_axi_aw.v
input [3:0]             src_arcache;            // To slice_axi_ar_inst0 of slice_axi_aw.v
input [ID_WIDTH-1:0]    src_arid;               // To slice_axi_ar_inst0 of slice_axi_aw.v
input [LEN_WIDTH-1:0]   src_arlen;              // To slice_axi_ar_inst0 of slice_axi_aw.v
input [LOCK_WIDTH-1 :0] src_arlock;             // To slice_axi_ar_inst0 of slice_axi_aw.v
input [2:0]             src_arprot;             // To slice_axi_ar_inst0 of slice_axi_aw.v
input [3:0]             src_arqos;              // To slice_axi_ar_inst0 of slice_axi_aw.v
input [2:0]             src_arsize;             // To slice_axi_ar_inst0 of slice_axi_aw.v
input [USER_WIDTH-1:0]  src_aruser;             // To slice_axi_ar_inst0 of slice_axi_aw.v
input                   src_arvalid;            // To slice_axi_ar_inst0 of slice_axi_aw.v
input [ADDR_WIDTH-1:0]  src_awaddr;             // To slice_axi_aw_inst0 of slice_axi_aw.v
input [1:0]             src_awburst;            // To slice_axi_aw_inst0 of slice_axi_aw.v
input [3:0]             src_awcache;            // To slice_axi_aw_inst0 of slice_axi_aw.v
input [ID_WIDTH-1:0]    src_awid;               // To slice_axi_aw_inst0 of slice_axi_aw.v
input [LEN_WIDTH-1:0]   src_awlen;              // To slice_axi_aw_inst0 of slice_axi_aw.v
input [LOCK_WIDTH-1 :0] src_awlock;             // To slice_axi_aw_inst0 of slice_axi_aw.v
input [2:0]             src_awprot;             // To slice_axi_aw_inst0 of slice_axi_aw.v
input [3:0]             src_awqos;              // To slice_axi_aw_inst0 of slice_axi_aw.v
input [2:0]             src_awsize;             // To slice_axi_aw_inst0 of slice_axi_aw.v
input [USER_WIDTH-1:0]  src_awuser;             // To slice_axi_aw_inst0 of slice_axi_aw.v
input                   src_awvalid;            // To slice_axi_aw_inst0 of slice_axi_aw.v
input [ID_WIDTH-1:0]    src_bid;                // To slice_axi_b_inst0 of slice_axi_b.v
input [1:0]             src_bresp;              // To slice_axi_b_inst0 of slice_axi_b.v
input [USER_WIDTH-1:0]  src_buser;              // To slice_axi_b_inst0 of slice_axi_b.v
input                   src_bvalid;             // To slice_axi_b_inst0 of slice_axi_b.v
input [DATA_WIDTH-1:0]  src_rdata;              // To slice_axi_r_inst0 of slice_axi_r.v
input [ID_WIDTH-1:0]    src_rid;                // To slice_axi_r_inst0 of slice_axi_r.v
input                   src_rlast;              // To slice_axi_r_inst0 of slice_axi_r.v
input [1:0]             src_rresp;              // To slice_axi_r_inst0 of slice_axi_r.v
input [USER_WIDTH-1:0]  src_ruser;              // To slice_axi_r_inst0 of slice_axi_r.v
input                   src_rvalid;             // To slice_axi_r_inst0 of slice_axi_r.v
input [DATA_WIDTH-1:0]  src_wdata;              // To slice_axi_w_inst0 of slice_acel_w.v
input [ID_WIDTH-1:0]  src_wid;              // To slice_axi_w_inst0 of slice_acel_w.v
input                   src_wlast;              // To slice_axi_w_inst0 of slice_acel_w.v
input [STROB_WIDTH-1:0] src_wstrb;              // To slice_axi_w_inst0 of slice_acel_w.v
input                   src_wvalid;             // To slice_axi_w_inst0 of slice_acel_w.v
// End of automatics
// Beginning of automatic outputs (from unused autoinst outputs)
output [ADDR_WIDTH-1:0] dst_araddr;             // From slice_axi_ar_inst0 of slice_axi_aw.v
output [1:0]            dst_arburst;            // From slice_axi_ar_inst0 of slice_axi_aw.v
output [3:0]            dst_arcache;            // From slice_axi_ar_inst0 of slice_axi_aw.v
output [ID_WIDTH-1:0]   dst_arid;               // From slice_axi_ar_inst0 of slice_axi_aw.v
output [LEN_WIDTH-1:0]  dst_arlen;              // From slice_axi_ar_inst0 of slice_axi_aw.v
output  [LOCK_WIDTH-1 :0] dst_arlock;             // From slice_axi_ar_inst0 of slice_axi_aw.v
output [2:0]            dst_arprot;             // From slice_axi_ar_inst0 of slice_axi_aw.v
output [3:0]            dst_arqos;              // From slice_axi_ar_inst0 of slice_axi_aw.v
output [2:0]            dst_arsize;             // From slice_axi_ar_inst0 of slice_axi_aw.v
output [USER_WIDTH-1:0] dst_aruser;             // From slice_axi_ar_inst0 of slice_axi_aw.v
output                  dst_arvalid;            // From slice_axi_ar_inst0 of slice_axi_aw.v
output [ADDR_WIDTH-1:0] dst_awaddr;             // From slice_axi_aw_inst0 of slice_axi_aw.v
output [1:0]            dst_awburst;            // From slice_axi_aw_inst0 of slice_axi_aw.v
output [3:0]            dst_awcache;            // From slice_axi_aw_inst0 of slice_axi_aw.v
output [ID_WIDTH-1:0]   dst_awid;               // From slice_axi_aw_inst0 of slice_axi_aw.v
output [LEN_WIDTH-1:0]  dst_awlen;              // From slice_axi_aw_inst0 of slice_axi_aw.v
output [LOCK_WIDTH-1 :0]                dst_awlock;             // From slice_axi_aw_inst0 of slice_axi_aw.v
output [2:0]            dst_awprot;             // From slice_axi_aw_inst0 of slice_axi_aw.v
output [3:0]            dst_awqos;              // From slice_axi_aw_inst0 of slice_axi_aw.v
output [2:0]            dst_awsize;             // From slice_axi_aw_inst0 of slice_axi_aw.v
output [USER_WIDTH-1:0] dst_awuser;             // From slice_axi_aw_inst0 of slice_axi_aw.v
output                  dst_awvalid;            // From slice_axi_aw_inst0 of slice_axi_aw.v
output [ID_WIDTH-1:0]   dst_bid;                // From slice_axi_b_inst0 of slice_axi_b.v
output [1:0]            dst_bresp;              // From slice_axi_b_inst0 of slice_axi_b.v
output [USER_WIDTH-1:0] dst_buser;              // From slice_axi_b_inst0 of slice_axi_b.v
output                  dst_bvalid;             // From slice_axi_b_inst0 of slice_axi_b.v
output [DATA_WIDTH-1:0] dst_rdata;              // From slice_axi_r_inst0 of slice_axi_r.v
output [ID_WIDTH-1:0]   dst_rid;                // From slice_axi_r_inst0 of slice_axi_r.v
output                  dst_rlast;              // From slice_axi_r_inst0 of slice_axi_r.v
output [1:0]            dst_rresp;              // From slice_axi_r_inst0 of slice_axi_r.v
output [USER_WIDTH-1:0] dst_ruser;              // From slice_axi_r_inst0 of slice_axi_r.v
output                  dst_rvalid;             // From slice_axi_r_inst0 of slice_axi_r.v
output [DATA_WIDTH-1:0] dst_wdata;              // From slice_axi_w_inst0 of slice_acel_w.v
output [ID_WIDTH-1:0] dst_wid;              // From slice_axi_w_inst0 of slice_acel_w.v
output                  dst_wlast;              // From slice_axi_w_inst0 of slice_acel_w.v
output [STROB_WIDTH-1:0] dst_wstrb;             // From slice_axi_w_inst0 of slice_acel_w.v
output                  dst_wvalid;             // From slice_axi_w_inst0 of slice_acel_w.v
output                  src_arready;            // From slice_axi_ar_inst0 of slice_axi_aw.v
output                  src_awready;            // From slice_axi_aw_inst0 of slice_axi_aw.v
output                  src_bready;             // From slice_axi_b_inst0 of slice_axi_b.v
output                  src_rready;             // From slice_axi_r_inst0 of slice_axi_r.v
output                  src_wready;             // From slice_axi_w_inst0 of slice_acel_w.v
// End of automatics
//--------------------------aw channel--------------------------
genvar i;
generate if(SLICE_NUM_AXI ==0) begin:pass_through
      assign dst_araddr = src_araddr ;             
      assign dst_arburst = src_arburst ;            
      assign dst_arcache = src_arcache ;            
      assign dst_arid = src_arid ;               
      assign dst_arlen = src_arlen ;              
      assign dst_arlock = src_arlock ;             
      assign dst_arprot = src_arprot ;             
      assign dst_arqos = src_arqos ;              
      assign dst_arsize = src_arsize ;             
      assign dst_aruser = src_aruser ;             
      assign dst_arvalid = src_arvalid ;            
      assign dst_awaddr = src_awaddr ;             
      assign dst_awburst = src_awburst ;            
      assign dst_awcache = src_awcache ;            
      assign dst_awid = src_awid ;               
      assign dst_awlen = src_awlen ;              
      assign dst_awlock = src_awlock ;             
      assign dst_awprot = src_awprot ;             
      assign dst_awqos = src_awqos ;              
      assign dst_awsize = src_awsize ;             
      assign dst_awuser = src_awuser ;             
      assign dst_awvalid = src_awvalid ;            
      assign dst_bid = src_bid ;                
      assign dst_bresp = src_bresp ;              
      assign dst_buser = src_buser ;              
      assign dst_bvalid = src_bvalid ;             
      assign dst_rdata = src_rdata ;              
      assign dst_rid = src_rid ;                
      assign dst_rlast = src_rlast ;              
      assign dst_rresp = src_rresp ;              
      assign dst_ruser = src_ruser ;              
      assign dst_rvalid = src_rvalid ;             
      assign dst_wdata = src_wdata ;              
      assign dst_wid = src_wid ;              
      assign dst_wlast = src_wlast ;              
      assign dst_wstrb = src_wstrb ;              
      assign dst_wvalid = src_wvalid ;             
      assign src_arready = dst_arready ;            
      assign src_awready = dst_awready ;            
      assign src_bready = dst_bready ;             
      assign src_rready = dst_rready ;             
      assign src_wready = dst_wready ;    
end 
else begin:gen_slice
     //wire
      wire [ADDR_WIDTH-1:0]  src_araddr_i[SLICE_NUM_AXI:0];             
      wire [1:0]             src_arburst_i[SLICE_NUM_AXI:0];            
      wire [3:0]             src_arcache_i[SLICE_NUM_AXI:0];            
      wire [ID_WIDTH-1:0]    src_arid_i[SLICE_NUM_AXI:0];               
      wire [LEN_WIDTH-1:0]   src_arlen_i[SLICE_NUM_AXI:0];              
      wire  [LOCK_WIDTH-1 :0]                  src_arlock_i[SLICE_NUM_AXI:0];             
      wire [2:0]             src_arprot_i[SLICE_NUM_AXI:0];             
      wire [3:0]             src_arqos_i[SLICE_NUM_AXI:0];              
      wire [2:0]             src_arsize_i[SLICE_NUM_AXI:0];             
      wire [USER_WIDTH-1:0]  src_aruser_i[SLICE_NUM_AXI:0];             
      wire                   src_arvalid_i[SLICE_NUM_AXI:0];            
      wire [ADDR_WIDTH-1:0]  src_awaddr_i[SLICE_NUM_AXI:0];             
      wire [1:0]             src_awburst_i[SLICE_NUM_AXI:0];            
      wire [3:0]             src_awcache_i[SLICE_NUM_AXI:0];            
      wire [ID_WIDTH-1:0]    src_awid_i[SLICE_NUM_AXI:0];               
      wire [LEN_WIDTH-1:0]   src_awlen_i[SLICE_NUM_AXI:0];              
      wire   [LOCK_WIDTH-1 :0]                 src_awlock_i[SLICE_NUM_AXI:0];             
      wire [2:0]             src_awprot_i[SLICE_NUM_AXI:0];             
      wire [3:0]             src_awqos_i[SLICE_NUM_AXI:0];              
      wire [2:0]             src_awsize_i[SLICE_NUM_AXI:0];             
      wire [USER_WIDTH-1:0]  src_awuser_i[SLICE_NUM_AXI:0];             
      wire                   src_awvalid_i[SLICE_NUM_AXI:0];            
      wire [ID_WIDTH-1:0]    src_bid_i[SLICE_NUM_AXI:0];                
      wire [1:0]             src_bresp_i[SLICE_NUM_AXI:0];              
      wire [USER_WIDTH-1:0]  src_buser_i[SLICE_NUM_AXI:0];              
      wire                   src_bvalid_i[SLICE_NUM_AXI:0];             
      wire [DATA_WIDTH-1:0]  src_rdata_i[SLICE_NUM_AXI:0];              
      wire [ID_WIDTH-1:0]    src_rid_i[SLICE_NUM_AXI:0];                
      wire                   src_rlast_i[SLICE_NUM_AXI:0];              
      wire [1:0]             src_rresp_i[SLICE_NUM_AXI:0];              
      wire [USER_WIDTH-1:0]  src_ruser_i[SLICE_NUM_AXI:0];              
      wire                   src_rvalid_i[SLICE_NUM_AXI:0];             
      wire [DATA_WIDTH-1:0]  src_wdata_i[SLICE_NUM_AXI:0];              
      wire [ID_WIDTH-1:0]  src_wid_i[SLICE_NUM_AXI:0];              
      wire                   src_wlast_i[SLICE_NUM_AXI:0];              
      wire [STROB_WIDTH-1:0] src_wstrb_i[SLICE_NUM_AXI:0];              
      wire                   src_wvalid_i[SLICE_NUM_AXI:0];             
      
      wire                  src_arready_i[SLICE_NUM_AXI:0];            
      wire                  src_awready_i[SLICE_NUM_AXI:0];            
      wire                  src_bready_i[SLICE_NUM_AXI:0];             
      wire                  src_rready_i[SLICE_NUM_AXI:0];             
      wire                  src_wready_i[SLICE_NUM_AXI:0];             


     //input
      assign src_araddr_i[0] = src_araddr;             
      assign src_arburst_i[0] = src_arburst;            
      assign src_arcache_i[0] = src_arcache;            
      assign src_arid_i[0] = src_arid;               
      assign src_arlen_i[0] = src_arlen;              
      assign src_arlock_i[0] = src_arlock;             
      assign src_arprot_i[0] = src_arprot;             
      assign src_arqos_i[0] = src_arqos;              
      assign src_arsize_i[0] = src_arsize;             
      assign src_aruser_i[0] = src_aruser;             
      assign src_arvalid_i[0] = src_arvalid;            
      assign src_awaddr_i[0] = src_awaddr;             
      assign src_awburst_i[0] = src_awburst;            
      assign src_awcache_i[0] = src_awcache;            
      assign src_awid_i[0] = src_awid;               
      assign src_awlen_i[0] = src_awlen;              
      assign src_awlock_i[0] = src_awlock;             
      assign src_awprot_i[0] = src_awprot;             
      assign src_awqos_i[0] = src_awqos;              
      assign src_awsize_i[0] = src_awsize;             
      assign src_awuser_i[0] = src_awuser;             
      assign src_awvalid_i[0] = src_awvalid;            
      assign src_bid_i[0] = src_bid;                
      assign src_bresp_i[0] = src_bresp;              
      assign src_buser_i[0] = src_buser;              
      assign src_bvalid_i[0] = src_bvalid;             
      assign src_rdata_i[0] = src_rdata;              
      assign src_rid_i[0] = src_rid;                
      assign src_rlast_i[0] = src_rlast;              
      assign src_rresp_i[0] = src_rresp;              
      assign src_ruser_i[0] = src_ruser;              
      assign src_rvalid_i[0] = src_rvalid;             
      assign src_wdata_i[0] = src_wdata;              
      assign src_wid_i[0] = src_wid;              
      assign src_wlast_i[0] = src_wlast;              
      assign src_wstrb_i[0] = src_wstrb;              
      assign src_wvalid_i[0] = src_wvalid;             
      assign src_arready = src_arready_i[0];            
      assign src_awready = src_awready_i[0];            
      assign src_bready = src_bready_i[0];             
      assign src_rready = src_rready_i[0];             
      assign src_wready = src_wready_i[0];         
     //output
      assign dst_araddr = src_araddr_i[SLICE_NUM_AXI] ;             
      assign dst_arburst = src_arburst_i[SLICE_NUM_AXI] ;            
      assign dst_arcache = src_arcache_i[SLICE_NUM_AXI] ;            
      assign dst_arid = src_arid_i[SLICE_NUM_AXI] ;               
      assign dst_arlen = src_arlen_i[SLICE_NUM_AXI] ;              
      assign dst_arlock = src_arlock_i[SLICE_NUM_AXI] ;             
      assign dst_arprot = src_arprot_i[SLICE_NUM_AXI] ;             
      assign dst_arqos = src_arqos_i[SLICE_NUM_AXI] ;              
      assign dst_arsize = src_arsize_i[SLICE_NUM_AXI] ;             
      assign dst_aruser = src_aruser_i[SLICE_NUM_AXI] ;             
      assign dst_arvalid = src_arvalid_i[SLICE_NUM_AXI] ;            
      assign dst_awaddr = src_awaddr_i[SLICE_NUM_AXI] ;             
      assign dst_awburst = src_awburst_i[SLICE_NUM_AXI] ;            
      assign dst_awcache = src_awcache_i[SLICE_NUM_AXI] ;            
      assign dst_awid = src_awid_i[SLICE_NUM_AXI] ;               
      assign dst_awlen = src_awlen_i[SLICE_NUM_AXI] ;              
      assign dst_awlock = src_awlock_i[SLICE_NUM_AXI] ;             
      assign dst_awprot = src_awprot_i[SLICE_NUM_AXI] ;             
      assign dst_awqos = src_awqos_i[SLICE_NUM_AXI] ;              
      assign dst_awsize = src_awsize_i[SLICE_NUM_AXI] ;             
      assign dst_awuser = src_awuser_i[SLICE_NUM_AXI] ;             
      assign dst_awvalid = src_awvalid_i[SLICE_NUM_AXI] ;            
      assign dst_bid = src_bid_i[SLICE_NUM_AXI] ;                
      assign dst_bresp = src_bresp_i[SLICE_NUM_AXI] ;              
      assign dst_buser = src_buser_i[SLICE_NUM_AXI] ;              
      assign dst_bvalid = src_bvalid_i[SLICE_NUM_AXI] ;             
      assign dst_rdata = src_rdata_i[SLICE_NUM_AXI] ;              
      assign dst_rid = src_rid_i[SLICE_NUM_AXI] ;                
      assign dst_rlast = src_rlast_i[SLICE_NUM_AXI] ;              
      assign dst_rresp = src_rresp_i[SLICE_NUM_AXI] ;              
      assign dst_ruser = src_ruser_i[SLICE_NUM_AXI] ;              
      assign dst_rvalid = src_rvalid_i[SLICE_NUM_AXI] ;             
      assign dst_wdata = src_wdata_i[SLICE_NUM_AXI] ;              
      assign dst_wid = src_wid_i[SLICE_NUM_AXI] ;              
      assign dst_wlast = src_wlast_i[SLICE_NUM_AXI] ;              
      assign dst_wstrb = src_wstrb_i[SLICE_NUM_AXI] ;              
      assign dst_wvalid = src_wvalid_i[SLICE_NUM_AXI] ;             
      assign src_arready_i[SLICE_NUM_AXI] = dst_arready ;            
      assign src_awready_i[SLICE_NUM_AXI] = dst_awready ;            
      assign src_bready_i[SLICE_NUM_AXI] = dst_bready ;             
      assign src_rready_i[SLICE_NUM_AXI] = dst_rready ;             
      assign src_wready_i[SLICE_NUM_AXI] = dst_wready ;    

    for(i=0; i<SLICE_NUM_AXI; i=i+1 ) begin:axi_slice
      //assign
                        

       slice_axi3_aw  #
        (
          .SLICE_RESET_SYNC (0) ,
          .SL_AW_LEN        (LEN_WIDTH) ,
          .SL_AW_ADDR        (ADDR_WIDTH),
          .SL_AW_ID          (ID_WIDTH) ,
          .SL_AW_USER         (USER_WIDTH),
          .SL_AW_LOCK        (LOCK_WIDTH)
        )
       slice_axi3_aw (
                          // Outputs
                          .src_awready        (src_awready_i[i]),
                          .dst_awvalid        (src_awvalid_i[i+1]),
                          .dst_awaddr         (src_awaddr_i[i+1]),
                          .dst_awid           (src_awid_i[i+1]),
                          .dst_awlen          (src_awlen_i[i+1]),
                          .dst_awsize         (src_awsize_i[i+1]),
                          .dst_awburst        (src_awburst_i[i+1]),
                          .dst_awlock         (src_awlock_i[i+1]),
                          .dst_awcache        (src_awcache_i[i+1]),
                          .dst_awprot         (src_awprot_i[i+1]),
                          .dst_awuser         (src_awuser_i[i+1]),
                          .dst_awqos          (src_awqos_i[i+1]),
                          // Inputs
                          .clk                (clk),
                          .rst_n              (rst_n),
                          .src_awvalid        (src_awvalid_i[i]),
                          .src_awaddr         (src_awaddr_i[i]),
                          .src_awid           (src_awid_i[i]),
                          .src_awlen          (src_awlen_i[i]),
                          .src_awsize         (src_awsize_i[i]),
                          .src_awburst        (src_awburst_i[i]),
                          .src_awlock         (src_awlock_i[i]),
                          .src_awcache        (src_awcache_i[i]),
                          .src_awprot         (src_awprot_i[i]),
                          .src_awuser         (src_awuser_i[i]),
                          .src_awqos          (src_awqos_i[i]),
                          .dst_awready        (src_awready_i[i+1]));

//--------------------------w channel--------------------------
      slice_acel_w_axi3 #(
          .SLICE_RESET_SYNC (0),
          .DATA_WIDTH       (DATA_WIDTH),
          .STROB_WIDTH      (STROB_WIDTH),
          .ID_WIDTH      (ID_WIDTH)
       )
       slice_axi3_w 
       (
        // Outputs
        .src_wready                            (src_wready_i[i]),
        .dst_wvalid                            (src_wvalid_i[i+1]),
        .dst_wdata                             (src_wdata_i[i+1]),
        .dst_wid                             (src_wid_i[i+1]),
        .dst_wstrb                             (src_wstrb_i[i+1]),
        .dst_wlast                             (src_wlast_i[i+1]),
        // Inputs
        .clk                                   (clk),
        .rst_n                                 (rst_n),
        .src_wvalid                            (src_wvalid_i[i]),
        .src_wdata                             (src_wdata_i[i]),
        .src_wid                             (src_wid_i[i]),
        .src_wstrb                             (src_wstrb_i[i]),
        .src_wlast                             (src_wlast_i[i]),
        .dst_wready                            (src_wready_i[i+1]));
       
       //--------------------------b channel--------------------------
       slice_axi_b #(
           .SLICE_RESET_SYNC ( 0),
           .SL_ID            (ID_WIDTH ),
           .SL_USER          ( USER_WIDTH)
       )
       slice_axi_b(
                         // Outputs
                         .src_bready           (src_bready_i[i]),
                         .dst_bid              (src_bid_i[i+1]),
                         .dst_bresp            (src_bresp_i[i+1]),
                         .dst_bvalid           (src_bvalid_i[i+1]),
                         .dst_buser            (src_buser_i[i+1]),
                         // Inputs
                         .clk                  (clk),
                         .rst_n                (rst_n),
                         .src_bid              (src_bid_i[i]),
                         .src_bresp            (src_bresp_i[i]),
                         .src_bvalid           (src_bvalid_i[i]),
                         .src_buser            (src_buser_i[i]),
                         .dst_bready           (src_bready_i[i+1]));
       
       
       //--------------------------ar channel--------------------------
       
             
       slice_axi3_aw #(
           .SLICE_RESET_SYNC (0) ,
           .SL_AW_LEN        (LEN_WIDTH) ,
           .SL_AW_ADDR        (ADDR_WIDTH),
           .SL_AW_ID          (ID_WIDTH) ,
           .SL_AW_USER         (USER_WIDTH),
           .SL_AW_LOCK        (LOCK_WIDTH)
         )
        slice_axi3_ar (
                            // Outputs
                            .src_awready       (src_arready_i[i]),
                            .dst_awvalid       (src_arvalid_i[i+1]),
                            .dst_awaddr        (src_araddr_i[i+1]),
                            .dst_awid          (src_arid_i[i+1]),
                            .dst_awlen         (src_arlen_i[i+1]),
                            .dst_awsize        (src_arsize_i[i+1]),
                            .dst_awburst       (src_arburst_i[i+1]),
                            .dst_awlock        (src_arlock_i[i+1]),
                            .dst_awcache       (src_arcache_i[i+1]),
                            .dst_awprot        (src_arprot_i[i+1]),
                            .dst_awuser        (src_aruser_i[i+1]),
                            .dst_awqos         (src_arqos_i[i+1]),
                            // Inputs
                            .clk               (clk),
                            .rst_n             (rst_n),
                            .src_awvalid       (src_arvalid_i[i]),
                            .src_awaddr        (src_araddr_i[i]),
                            .src_awid          (src_arid_i[i]),
                            .src_awlen         (src_arlen_i[i]),
                            .src_awsize        (src_arsize_i[i]),
                            .src_awburst       (src_arburst_i[i]),
                            .src_awlock        (src_arlock_i[i]),
                            .src_awcache       (src_arcache_i[i]),
                            .src_awprot        (src_arprot_i[i]),
                            .src_awuser        (src_aruser_i[i]),
                            .src_awqos         (src_arqos_i[i]),
                            .dst_awready       (src_arready_i[i+1]));
       
       
       //--------------------------r channel--------------------------
       slice_axi_r  #(
           .SLICE_RESET_SYNC ( 0  ),
           .SL_ID            ( ID_WIDTH  ),
           .SL_USER          ( USER_WIDTH  ), 
           .DATA_WIDTH       ( DATA_WIDTH)
       )
       slice_axi_r(
                         // Outputs
                         .dst_rid              (src_rid_i[i+1]),
                         .dst_rvalid           (src_rvalid_i[i+1]),
                         .dst_rdata            (src_rdata_i[i+1]),
                         .dst_ruser            (src_ruser_i[i+1]),
                         .dst_rresp            (src_rresp_i[i+1]),
                         .dst_rlast            (src_rlast_i[i+1]),
                         .src_rready           (src_rready_i[i]),
                         // Inputs
                         .clk                  (clk),
                         .rst_n                (rst_n),
                         .dst_rready           (src_rready_i[i+1]),
                         .src_rvalid           (src_rvalid_i[i]),
                         .src_rid              (src_rid_i[i]),
                         .src_rdata            (src_rdata_i[i]),
                         .src_ruser            (src_ruser_i[i]),
                         .src_rresp            (src_rresp_i[i]),
                         .src_rlast            (src_rlast_i[i]));
     end
  end
endgenerate



endmodule
