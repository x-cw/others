
module async_fifo_noreg #(
  parameter ASIZE = 1  ,
  parameter DSIZE = 256,
  parameter AWFULL_THRESHOLD = 1
)  
 (
    input  wire               test_en     ,
    input  wire               wclk        ,
    input  wire               wrst_b      ,
    input  wire  [DSIZE-1:0]  wdin        ,
    input  wire               wren        ,
    output wire               wfull       ,
    output wire               awfull      ,
    

    input wire                rclk        ,
    input wire                rrst_b      ,
    input wire                rden        ,
    output wire  [DSIZE-1:0]  rdout       ,
    output wire               rempty     
    );


//wire            wempty ;
//wire            rfull  ;

reg  [ASIZE:0]  waddr;
reg  [ASIZE:0]  raddr;

reg  [ASIZE:0]  waddr_gray;
reg  [ASIZE:0]  raddr_gray;

wire [ASIZE:0] waddr_comb;
wire [ASIZE:0] waddr_gray_comb;

reg  [ASIZE:0] raddr_gray_wclk_d1;
reg  [ASIZE:0] raddr_gray_wclk_d2;
wire [ASIZE:0] raddr_wclk_d2;

wire [ASIZE:0] raddr_comb;
wire [ASIZE:0] raddr_gray_comb;

reg  [ASIZE:0] waddr_gray_rclk_d1;
reg  [ASIZE:0] waddr_gray_rclk_d2;

wire [ASIZE:0] waddr_rclk_d2;

reg            depth_cur_full;
wire [ASIZE-1:0]  depth_cur;
wire [ASIZE-1:0]  depth_limit;

genvar i;
//=====================================
//waddr gen
//=====================================






always @(posedge wclk or negedge wrst_b)
    if(!wrst_b)
        waddr <= {(ASIZE+1){1'b0}};
    else
        waddr <= waddr_comb;

assign waddr_comb = wren? waddr+ 1'b1 : waddr;

assign waddr_gray_comb = waddr_comb[ASIZE:0] ^ {1'b0,waddr_comb[ASIZE:1]};


always @(posedge wclk or negedge wrst_b)
    if(!wrst_b)
        waddr_gray <= {(ASIZE+1){1'b0}};
    else
        waddr_gray <= waddr_gray_comb;


//========================================
//w side full   empty generate
//========================================

always @(posedge wclk or negedge wrst_b)
    if(!wrst_b)
        raddr_gray_wclk_d1 <= {(ASIZE+1){1'b0}};
    else
        raddr_gray_wclk_d1 <= raddr_gray;


always @(posedge wclk or negedge wrst_b)
    if(!wrst_b)
        raddr_gray_wclk_d2 <= {(ASIZE+1){1'b0}};
    else
        raddr_gray_wclk_d2 <= raddr_gray_wclk_d1;



assign raddr_wclk_d2[ASIZE] = raddr_gray_wclk_d2[ASIZE];

generate
for (i = ASIZE-1; i>=0; i= i-1)
    begin : waddr_compare
       assign raddr_wclk_d2[i] = raddr_gray_wclk_d2[i] ^  raddr_wclk_d2[i+1];
    end
endgenerate


assign wfull  = ((~(waddr[ASIZE] == raddr_wclk_d2[ASIZE])) && (waddr[ASIZE-1:0] == raddr_wclk_d2[ASIZE-1:0])) ? 1'b1 : 1'b0;
//add almost full

assign  depth_cur[ASIZE-1:0] = (waddr[ASIZE-1:0] > raddr_wclk_d2[ASIZE-1:0])? (waddr[ASIZE-1:0] - raddr_wclk_d2[ASIZE-1:0]) : ({1'b1,waddr[ASIZE-1:0]} - {1'b0,raddr_wclk_d2[ASIZE-1:0]});
assign  depth_limit[ASIZE-1:0] = ({(ASIZE){32'hffff_ffff}} - AWFULL_THRESHOLD); //-1 
always @(posedge wclk or negedge wrst_b)
    if(!wrst_b)
          depth_cur_full <= 1'b0;
    else
          depth_cur_full <=  (depth_cur >= depth_limit)? 1'b1 : 1'b0 ;
assign awfull  = depth_cur_full;

//assign wempty = (  (waddr[ASIZE] == raddr_wclk_d2[ASIZE]) && (waddr[ASIZE-1:0] == raddr_wclk_d2[ASIZE-1:0])) ? 1'b1 : 1'b0;


//wire [ASIZE:0] sub;
//
//assign sub = waddr - raddr_wclk_d2;  


//=====================================
//raddr gen
//=====================================




always @(posedge rclk or negedge rrst_b)
    if(!rrst_b)
        raddr <= {(ASIZE+1){1'b0}};
    else
        raddr <= raddr_comb;

assign raddr_comb = rden? raddr+1'b1 : raddr;

assign raddr_gray_comb = raddr_comb[ASIZE:0] ^ {1'b0,raddr_comb[ASIZE:1]};


always @(posedge rclk or negedge rrst_b)
    if(!rrst_b)
        raddr_gray <= {(ASIZE+1){1'b0}};
    else
        raddr_gray <= raddr_gray_comb;


//========================================
//r side full   empty generate
//========================================

always @(posedge rclk or negedge rrst_b)
    if(!rrst_b)
        waddr_gray_rclk_d1 <= {(ASIZE+1){1'b0}};
    else
        waddr_gray_rclk_d1 <= waddr_gray;


always @(posedge rclk or negedge rrst_b)
    if(!rrst_b)
        waddr_gray_rclk_d2 <= {(ASIZE+1){1'b0}};
    else
        waddr_gray_rclk_d2 <= waddr_gray_rclk_d1;


assign waddr_rclk_d2[ASIZE] = waddr_gray_rclk_d2[ASIZE];

generate
for (i = ASIZE-1; i>=0; i= i-1)
    begin : raddr_compare
       assign waddr_rclk_d2[i] = waddr_gray_rclk_d2[i] ^  waddr_rclk_d2[i+1];
    end
endgenerate

//assign rfull  = ((~(raddr[ASIZE] == waddr_rclk_d2[ASIZE])) && (raddr[ASIZE-1:0] == waddr_rclk_d2[ASIZE-1:0])) ? 1'b1 : 1'b0;
assign rempty = (  (raddr[ASIZE] == waddr_rclk_d2[ASIZE]) && (raddr[ASIZE-1:0] == waddr_rclk_d2[ASIZE-1:0])) ? 1'b1 : 1'b0;


//===========================================




dpram_async_fifo_noreg  #(
  .ASIZE(ASIZE),
  .DSIZE(DSIZE)
) dpram_async_fifo_0 (
    .test_en (test_en      ),
    .wclk (wclk      ),
    .wdata(wdin      ),
    .waddr(waddr[ASIZE-1:0]),
    .wren (wren      ),
    
    //.rclk (rclk      ),
    .raddr(raddr[ASIZE-1:0]),
    //.rden (rden      ),
    .dout (rdout     )
);


endmodule


module dpram_async_fifo_noreg #(
  parameter ASIZE = 2  ,
  parameter DSIZE = 128
) (
    input  wire                 test_en,

    input  wire                 wclk,
    input  wire [DSIZE-1:0]     wdata,
    input  wire [ASIZE-1:0]     waddr,
    input  wire                 wren,
    
    //input  wire                 rclk,
    input  wire [ASIZE-1:0]     raddr,
    //input  wire                 rden ,
    output wire [DSIZE-1:0]     dout
);

reg [DSIZE-1:0] mem[2**ASIZE-1:0];

wire wclk_gating;
//wire rclk_gating;

//clk_gating clk_gating_wclk(.clk_in (wclk ),.clk_en (wren), .clk_out(wclk_gating));
cell_clk_gate clk_gate_wclk (.clk_in(wclk), .en(wren), .ten(test_en), .clk_out(wclk_gating));

//clk_gating clk_gating_rclk(.clk_in (rclk ),.clk_en (rden), .clk_out(rclk_gating));


always @(posedge wclk_gating)
    if(wren)
        mem[waddr]  <= wdata;

assign dout = mem[raddr];


endmodule
