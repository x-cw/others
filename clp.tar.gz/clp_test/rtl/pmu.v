// +FHDR----------------------------------------------------------------------------
// Project Name  : IC_Design
// Author        : xucw
// Email         : xucw@innosilicon.com.cn
// Create On     : 2025/02/28 15:15
// Last Modified : 2025/02/28 15:15
// File Name     : pmu.v
// Description   :
// 
// Copyright (c) 2025 Innosilicon.
// ALL RIGHTS RESERVED
// 
// ---------------------------------------------------------------------------------
// Modification History:
// Date         By              Version                 Change Description
// ---------------------------------------------------------------------------------
// 2025/02/28   xucw            1.0                     Original
// 
// -FHDR----------------------------------------------------------------------------

module pmu(
    input clk,
    input rstn,
    output reg ctrl_pm_sub_a_off,
    output reg ctrl_pm_sub_b_off,
    output reg ctrl_pm_sub_c_off,
    input ctrl_on 


);


always@(posedge clk or negedge rstn)
if(!rstn)
  ctrl_pm_sub_a_off <= 1'b0;
else
  ctrl_pm_sub_a_off <=  ctrl_on? 1'b1:1'b0;



always@(posedge clk or negedge rstn)
if(!rstn)
  ctrl_pm_sub_b_off <= 1'b0;
else
  ctrl_pm_sub_b_off <=  ctrl_on? 1'b1:1'b0;

always@(posedge clk or negedge rstn)
if(!rstn)
  ctrl_pm_sub_c_off <= 1'b0;
else
  ctrl_pm_sub_c_off <=  ctrl_on? 1'b1:1'b0;


//assign  ctrl_pm_sub_b_off = ctrl_on? 1'b1:1'b0;
//assign  ctrl_pm_sub_c_off = ctrl_on? 1'b1:1'b0;

endmodule
// Local Variables:
// verilog-library-directories:("./" ) 
// verilog-auto-inst-param-value:t
// End:

