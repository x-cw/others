// +FHDR----------------------------------------------------------------------------
// Project Name  : IC_Design
// Author        : xucw
// Email         : xucw@innosilicon.com.cn
// Create On     : 2025/02/25 19:58
// Last Modified : 2025/02/25 19:58
// File Name     : sub_a.v
// Description   :
// 
// Copyright (c) 2025 Innosilicon.
// ALL RIGHTS RESERVED
// 
// ---------------------------------------------------------------------------------
// Modification History:
// Date         By              Version                 Change Description
// ---------------------------------------------------------------------------------
// 2025/02/25   xucw            1.0                     Original
// 
// -FHDR----------------------------------------------------------------------------

module sub_c(
    input clk,
    input rstn,

    input ctrl_pm_sub_c_off,

    input bc_0,
    input bc_1,
    output reg cb_0,
    output reg cb_1,

    input ac_0,
    input ac_1,
    output reg ca_0,
    output reg ca_1,
    input   in_c,
    input   in_c_t,
    output reg  out_c

);




always@(posedge clk or negedge rstn)
if(!rstn)
  cb_0 <= 1'b0;
else
  cb_0 <=  in_c ;

always@(posedge clk or negedge rstn)
if(!rstn)
  cb_1 <= 1'b0;
else
  cb_1 <=  ~in_c & in_c_t ;

always@(posedge clk or negedge rstn)
if(!rstn)
  ca_0 <= 1'b0;
else
  ca_0 <=  in_c ;

always@(posedge clk or negedge rstn)
if(!rstn)
  ca_1 <= 1'b0;
else
  ca_1 <=  ~in_c  & in_c_t;

always@(posedge clk or negedge rstn)
if(!rstn)
  out_c <= 1'b0;
else
  out_c <=  (cb_0 & cb_1 & ca_0 & ca_1) | (bc_0 & bc_1 & ac_0 & ac_1);

endmodule
// Local Variables:
// verilog-library-directories:("./" ) 
// verilog-auto-inst-param-value:t
// End:


