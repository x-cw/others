// +FHDR----------------------------------------------------------------------------
// Project Name  : IC_Design
// Author        : xucw
// Email         : xucw@innosilicon.com.cn
// Create On     : 2025/02/25 19:58
// Last Modified : 2025/02/25 19:58
// File Name     : sub_a.v
// Description   :
// 
// Copyright (c) 2025 Innosilicon.
// ALL RIGHTS RESERVED
// 
// ---------------------------------------------------------------------------------
// Modification History:
// Date         By              Version                 Change Description
// ---------------------------------------------------------------------------------
// 2025/02/25   xucw            1.0                     Original
// 
// -FHDR----------------------------------------------------------------------------

module sub_b(
    input clk,
    input rstn,

    input ctrl_pm_sub_b_off,


    input ab_0,
    input ab_1,
    output reg ba_0,
    output reg ba_1,

    input cb_0,
    input cb_1,
    output reg bc_0,
    output reg bc_1,
    input   in_b,
    input   in_b_t,
    output reg out_b
);




always@(posedge clk or negedge rstn)
if(!rstn)
  ba_0 <= 1'b0;
else
  ba_0 <= in_b;

always@(posedge clk or negedge rstn)
if(!rstn)
  ba_1 <= 1'b0;
else
  ba_1 <=  ~in_b & in_b_t;

always@(posedge clk or negedge rstn)
if(!rstn)
  bc_0 <= 1'b0;
else
  bc_0 <=  in_b;

always@(posedge clk or negedge rstn)
if(!rstn)
  bc_1 <= 1'b0;
else
  bc_1 <=  ~in_b & in_b_t;

always@(posedge clk or negedge rstn)
if(!rstn)
  out_b <= 1'b0;
else
  out_b <=  (ba_0 & ba_1 & bc_0 & bc_1) | (ab_0 & ab_1 & cb_0 & cb_1);



endmodule
// Local Varibales:
// verilog-library-directories:("./" ) 
// verilog-auto-inst-param-value:t
// End:


