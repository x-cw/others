// +FHDR----------------------------------------------------------------------------
// Project Name  : IC_Design
// Author        : xucw
// Email         : xucw@innosilicon.com.cn
// Create On     : 2025/02/25 19:58
// Last Modified : 2025/02/25 19:58
// File Name     : sub_a.v
// Description   :
// 
// Copyright (c) 2025 Innosilicon.
// ALL RIGHTS RESERVED
// 
// ---------------------------------------------------------------------------------
// Modification History:
// Date         By              Version                 Change Description
// ---------------------------------------------------------------------------------
// 2025/02/25   xucw            1.0                     Original
// 
// -FHDR----------------------------------------------------------------------------

module sub_a(
    input clk,
    input rstn,
    input ctrl_on,
    output ctrl_pm_sub_b_off,
    output ctrl_pm_sub_c_off,

    input ba_0,
    input ba_1,
    output reg ab_0,
    output reg ab_1,

    input ca_0,
    input ca_1,
    output reg ac_0,
    output reg ac_1,

    input   in_a,
    input   in_a_t,
    output reg  out_a


);


wire ctrl_pm_sub_a_off;


always@(posedge clk or negedge rstn)
if(!rstn)
  ab_0 <= 1'b0;
else
  ab_0 <=  in_a ;

always@(posedge clk or negedge rstn)
if(!rstn)
  ab_1 <= 1'b0;
else
  ab_1 <=  ~in_a & in_a_t;

always@(posedge clk or negedge rstn)
if(!rstn)
  ac_0 <= 1'b0;
else
  ac_0 <=  in_a ;

always@(posedge clk or negedge rstn)
if(!rstn)
  ac_1 <= 1'b0;
else
  ac_1 <=  ~in_a & in_a_t;





always@(posedge clk or negedge rstn)
if(!rstn)
  out_a <= 1'b0;
else
  out_a <=  (ab_0 & ab_1 & ac_0 & ac_1) | (ba_1 & ba_0 & ca_1 & ca_0);




pmu
pmu_inst
(/*autoinst*/
 // Outputs
 .ctrl_pm_sub_a_off                     (ctrl_pm_sub_a_off),
 .ctrl_pm_sub_b_off                     (ctrl_pm_sub_b_off),
 .ctrl_pm_sub_c_off                     (ctrl_pm_sub_c_off),
 // Inputs
 .clk                                   (clk),
 .rstn                                  (rstn),
 .ctrl_on                               (ctrl_on));



endmodule
// Local Variables:
// verilog-library-directories:("./" ) 
// verilog-auto-inst-param-value:t
// End:


