// +FHDR----------------------------------------------------------------------------
// Project Name  : IC_Design
// Author        : xucw
// Email         : xucw@innosilicon.com.cn
// Create On     : 2025/02/25 20:09
// Last Modified : 2025/02/25 20:09
// File Name     : top.v
// Description   :
// 
// Copyright (c) 2025 Innosilicon.
// ALL RIGHTS RESERVED
// 
// ---------------------------------------------------------------------------------
// Modification History:
// Date         By              Version                 Change Description
// ---------------------------------------------------------------------------------
// 2025/02/25   xucw            1.0                     Original
// 
// -FHDR----------------------------------------------------------------------------

module top(
  /*autoarg*/
   // Outputs
   out_c, out_b, out_a,
   // Inputs
   rstn, out_c_t, out_b_t, in_c, in_b, in_a_t, in_a, ctrl_on, clk
   );

  /*autoinput*/
  // Beginning of automatic inputs (from unused autoinst inputs)
  input                 clk;                    // To sub_a_inst of sub_a.v, ...
  input                 ctrl_on;                // To sub_a_inst of sub_a.v
  input                 in_a;                   // To sub_a_inst of sub_a.v
  input                 in_a_t;                 // To sub_a_inst of sub_a.v
  input                 in_b;                   // To sub_b_inst of sub_b.v
  input                 in_c;                   // To sub_c_inst of sub_c.v
  input                 out_b_t;                // To sub_b_inst of sub_b.v
  input                 out_c_t;                // To sub_c_inst of sub_c.v
  input                 rstn;                   // To sub_a_inst of sub_a.v, ...
  // End of automatics
  /*autooutput*/
  // Beginning of automatic outputs (from unused autoinst outputs)
  output                out_a;                  // From sub_a_inst of sub_a.v
  output                out_b;                  // From sub_b_inst of sub_b.v
  output                out_c;                  // From sub_c_inst of sub_c.v
  // End of automatics
  /*autowire*/
  // Beginning of automatic wires (for undeclared instantiated-module outputs)
  wire                  ab_0;                   // From sub_a_inst of sub_a.v
  wire                  ab_1;                   // From sub_a_inst of sub_a.v
  wire                  ac_0;                   // From sub_a_inst of sub_a.v
  wire                  ac_1;                   // From sub_a_inst of sub_a.v
  wire                  ba_0;                   // From sub_b_inst of sub_b.v
  wire                  ba_1;                   // From sub_b_inst of sub_b.v
  wire                  bc_0;                   // From sub_b_inst of sub_b.v
  wire                  bc_1;                   // From sub_b_inst of sub_b.v
  wire                  ca_0;                   // From sub_c_inst of sub_c.v
  wire                  ca_1;                   // From sub_c_inst of sub_c.v
  wire                  cb_0;                   // From sub_c_inst of sub_c.v
  wire                  cb_1;                   // From sub_c_inst of sub_c.v
  wire                  ctrl_pm_sub_b_off;      // From sub_a_inst of sub_a.v
  wire                  ctrl_pm_sub_c_off;      // From sub_a_inst of sub_a.v
  // End of automatics





/*
sub_a auto_template
(

);

*/

sub_a sub_a_inst(

/*autoinst*/
                 // Outputs
                 .ctrl_pm_sub_b_off     (ctrl_pm_sub_b_off),
                 .ctrl_pm_sub_c_off     (ctrl_pm_sub_c_off),
                 .ab_0                  (ab_0),
                 .ab_1                  (ab_1),
                 .ac_0                  (ac_0),
                 .ac_1                  (ac_1),
                 .out_a                 (out_a),
                 // Inputs
                 .clk                   (clk),
                 .rstn                  (rstn),
                 .ctrl_on               (ctrl_on),
                 .ba_0                  (ba_0),
                 .ba_1                  (ba_1),
                 .ca_0                  (ca_0),
                 .ca_1                  (ca_1),
                 .in_a                  (in_a),
                 .in_a_t                (in_a_t));

/*
sub_b auto_template
(
                 .out_b                 (out_b),     
                 .in_b                 (in_b),     
  .\(.*\)in\(.*\) (\1out\2),
  .\(.*\)out\(.*\) (\1in\2),

);

*/
sub_b sub_b_inst(
/*autoinst*/
                 // Outputs
                 .ba_0                  (ba_0),
                 .ba_1                  (ba_1),
                 .bc_0                  (bc_0),
                 .bc_1                  (bc_1),
                 .out_b                 (out_b),                 // Templated
                 // Inputs
                 .clk                   (clk),
                 .rstn                  (rstn),
                 .ctrl_pm_sub_b_off     (ctrl_pm_sub_b_off),
                 .ab_0                  (ab_0),
                 .ab_1                  (ab_1),
                 .cb_0                  (cb_0),
                 .cb_1                  (cb_1),
                 .in_b                  (in_b),                  // Templated
                 .in_b_t                (out_b_t));              // Templated

/*
sub_c auto_template
(
                 .out_c                 (out_c),   
                 .in_c                 (in_c),   
  .\(.*\)in\(.*\) (\1out\2),
  .\(.*\)out\(.*\) (\1in\2),

);

*/
sub_c sub_c_inst(
/*autoinst*/
                 // Outputs
                 .cb_0                  (cb_0),
                 .cb_1                  (cb_1),
                 .ca_0                  (ca_0),
                 .ca_1                  (ca_1),
                 .out_c                 (out_c),                 // Templated
                 // Inputs
                 .clk                   (clk),
                 .rstn                  (rstn),
                 .ctrl_pm_sub_c_off     (ctrl_pm_sub_c_off),
                 .bc_0                  (bc_0),
                 .bc_1                  (bc_1),
                 .ac_0                  (ac_0),
                 .ac_1                  (ac_1),
                 .in_c                  (in_c),                  // Templated
                 .in_c_t                (out_c_t));              // Templated



endmodule
// Local Variables:
// verilog-library-directories:("./" ) 
// verilog-auto-inst-param-value:t
// End:

