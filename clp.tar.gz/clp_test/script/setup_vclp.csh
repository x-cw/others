#! /bin/csh



if (! -e logs) then
  mkdir ../logs
endif

if (! -e reports) then
  mkdir ../reports
endif


if (! -e result) then
  mkdir ../result
endif

if (! -e work) then
  mkdir ../work
endif
