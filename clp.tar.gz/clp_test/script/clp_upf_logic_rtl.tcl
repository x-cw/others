set UPF_TEST_RTL /home/Storage_Plugins/xucw/mytest/clp_test/rtl
set design_top top

set_lowpower_option -netlist_style logical
set_lowpower_option -native_1801
set_lowpower_option -witness_limit 0

#add_search_path -design  /home/Storage_Plugins/xucw/mytest/clp_test/rtl
add_search_path -library  \
              /Foundry/ARM/samsung_5lpeAT/Standard_Cell/samsung/ln05lpe_sc_m7p5t_flk_lvt_c60_a00_V3.01_pkg/FE-Common_sec240318_0094/LIBERTY/ln05lpe_sc_m7p5t_flk_lvt_c60l08 \
              /Foundry/ARM/samsung_5lpeAT/Standard_Cell/samsung/ln05lpe_sc_m7p5t_pmk_lvt_c60_a00_V4.21_pkg/FE-Common/FE-Common_sec250408_0044/LIBERTY/ln05lpe_sc_m7p5t_pmk_lvt_c60l08

read_library -liberty -lp \
ln05lpe_sc_m7p5t_flk_lvt_c60l08_sspg_nominal_max_0p7650v_m40c.lib_ccs_tn_lvf.gz \
ln05lpe_sc_m7p5t_flk_lvt_c60l08_sspg_nominal_max_0p6750v_m40c.lib_ccs_tn_lvf.gz \
ln05lpe_sc_m7p5t_pmk_lvt_c60l08_sspg_nominal_max_0p7650v_m40c.lib_ccs_tn_lvf.gz \
ln05lpe_sc_m7p5t_pmk_lvt_c60l08_sspg_nominal_max_0p6750v_m40c.lib_ccs_tn_lvf.gz \
ln05lpe_sc_m7p5t_pmk_lvt_c60l08_sspg_nominal_max_0p6750v_0p7650v_m40c.lib_ccs_tn_lvf.gz \
ln05lpe_sc_m7p5t_pmk_lvt_c60l08_sspg_nominal_max_0p7650v_0p6750v_m40c.lib_ccs_tn_lvf.gz



set_rtl_type -systemverilog .sv .v .vc .vh
read_design -MIXvlog -systemverilog -sva -root ${design_top} -file ../rtl/top.f 


analyze_library -lowpower -used -verbose


read_power_intent -upf ../upf/${design_top}.upf  -version 3.1 -replace 


report_rule_check -summary                >  ../reports/${design_top}_upf_logic_rtl_rule_check.sum.rpt
report_rule_check -rtl -library -verbose  >  ../reports/${design_top}_upf_logic_rtl_rule_check.lib.rpt
report_rule_check -rtl -design  -verbose  >  ../reports/${design_top}_upf_logic_rtl_rule_check.rtl.rpt
report_rule_check lib_rule      -verbose  >> ../reports/${design_top}_upf_logic_rtl_rule_check.lib.rpt
report_rule_check -lp           -verbose  >  ../reports/${design_top}_upf_logic_rtl_rule_check.lp.rpt

#set gui
