set UPF_TEST_RTL /home/Storage_Plugins/xucw/mytest/clp_test/rtl
set design_name "top"

#set_db lib_search_path         [ list \
#              /Foundry/ARM/samsung_5lpeAT/Standard_Cell/samsung/ln05lpe_sc_m7p5t_flk_lvt_c60_a00_V3.01_pkg/FE-Common_sec240318_0094/LIBERTY/ln05lpe_sc_m7p5t_flk_lvt_c60l08 \
#              /Foundry/ARM/samsung_5lpeAT/Standard_Cell/samsung/ln05lpe_sc_m7p5t_pmk_lvt_c60_a00_V4.21_pkg/FE-Common/FE-Common_sec250408_0044/LIBERTY/ln05lpe_sc_m7p5t_pmk_lvt_c60l08 \
#]
#create_library_domain {domain1 domain2 ...}
#set_db library lib1 domain1

set target_library [ list \
/Foundry/ARM/samsung_5lpeAT/Standard_Cell/samsung/ln05lpe_sc_m7p5t_flk_lvt_c60_a00_V3.01_pkg/FE-Common_sec240318_0094/LIBERTY/ln05lpe_sc_m7p5t_flk_lvt_c60l08/ln05lpe_sc_m7p5t_flk_lvt_c60l08_sspg_nominal_max_0p7650v_m40c.lib_ccs_tn_lvf.gz \
/Foundry/ARM/samsung_5lpeAT/Standard_Cell/samsung/ln05lpe_sc_m7p5t_flk_lvt_c60_a00_V3.01_pkg/FE-Common_sec240318_0094/LIBERTY/ln05lpe_sc_m7p5t_flk_lvt_c60l08/ln05lpe_sc_m7p5t_flk_lvt_c60l08_sspg_nominal_max_0p6750v_m40c.lib_ccs_tn_lvf.gz \
/Foundry/ARM/samsung_5lpeAT/Standard_Cell/samsung/ln05lpe_sc_m7p5t_pmk_lvt_c60_a00_V4.21_pkg/FE-Common/FE-Common_sec250408_0044/LIBERTY/ln05lpe_sc_m7p5t_pmk_lvt_c60l08/ln05lpe_sc_m7p5t_pmk_lvt_c60l08_sspg_nominal_max_0p6750v_0p7650v_m40c.lib_ccs_tn_lvf.gz \
/Foundry/ARM/samsung_5lpeAT/Standard_Cell/samsung/ln05lpe_sc_m7p5t_pmk_lvt_c60_a00_V4.21_pkg/FE-Common/FE-Common_sec250408_0044/LIBERTY/ln05lpe_sc_m7p5t_pmk_lvt_c60l08/ln05lpe_sc_m7p5t_pmk_lvt_c60l08_sspg_nominal_max_0p7650v_0p6750v_m40c.lib_ccs_tn_lvf.gz \
/Foundry/ARM/samsung_5lpeAT/Standard_Cell/samsung/ln05lpe_sc_m7p5t_pmk_lvt_c60_a00_V4.21_pkg/FE-Common/FE-Common_sec250408_0044/LIBERTY/ln05lpe_sc_m7p5t_pmk_lvt_c60l08/ln05lpe_sc_m7p5t_pmk_lvt_c60l08_sspg_nominal_max_0p6750v_m40c.lib_ccs_tn_lvf.gz \
/Foundry/ARM/samsung_5lpeAT/Standard_Cell/samsung/ln05lpe_sc_m7p5t_pmk_lvt_c60_a00_V4.21_pkg/FE-Common/FE-Common_sec250408_0044/LIBERTY/ln05lpe_sc_m7p5t_pmk_lvt_c60l08/ln05lpe_sc_m7p5t_pmk_lvt_c60l08_sspg_nominal_max_0p7650v_m40c.lib_ccs_tn_lvf.gz \
]

read_libs $target_library





#read_hdl -sv -f ../rtl/top.f
read_hdl -netlist ../result/${design_name}_genus_syn.v
#analyze -f sverilog -vcs "-f ${TOP_SV_FILELIST}"
elaborate $design_name
init_design


set_dont_use [get_lib_cells */* ] false
set_dont_touch [get_lib_cells */* ] false


read_power_intent -1801  -version 3.1 ../upf/top.upf -module  $design_name 


### operate conditions

#set_operating_conditions  sspg_0p6750v_m40c



apply_power_intent

commit_power_intent



#syn_generic
#syn_map
#syn_opt

#write_power_intent -1801 > ../result/${design_name}_genus_forBE.upf
write_power_intent -1801 -design  ${design_name} -overwrite -base_name ../result/${design_name}_genus_forBE

write_hdl -lec > ../result/${design_name}_genus_iso.v


check_power_intent     -detail > ../reports/${design_name}_genus.check_power_intent
check_power_structure  -detail > ../reports/${design_name}_genus.check_power_structure



report_power_intent -detail -level_shifter_rule_only > ../reports/${design_name}_genus.level_shifter_rule
report_power_intent -detail -isolation_rule_only     > ../reports/${design_name}_genus.isolation_rule

report_power_intent_instances -detail -level_shifter_only > ../reports/${design_name}_genus.level_shifter_cell
report_power_intent_instances -detail -isolation_only     > ../reports/${design_name}_genus.isolation_cell

