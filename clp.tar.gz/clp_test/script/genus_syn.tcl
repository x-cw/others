set UPF_TEST_RTL /home/Storage_Plugins/xucw/mytest/clp_test/rtl
set design_name "top"


#set_db lib_search_path         [ list \
#              /Foundry/ARM/samsung_5lpeAT/Standard_Cell/samsung/ln05lpe_sc_m7p5t_flk_lvt_c60_a00_V3.01_pkg/FE-Common_sec240318_0094/LIBERTY/ln05lpe_sc_m7p5t_flk_lvt_c60l08 \
#              /Foundry/ARM/samsung_5lpeAT/Standard_Cell/samsung/ln05lpe_sc_m7p5t_pmk_lvt_c60_a00_V4.21_pkg/FE-Common/FE-Common_sec250408_0044/LIBERTY/ln05lpe_sc_m7p5t_pmk_lvt_c60l08 \
#]
#create_library_domain {domain1 domain2 ...}
#set_db library lib1 domain1

set target_library [ list \
/Foundry/ARM/samsung_5lpeAT/Standard_Cell/samsung/ln05lpe_sc_m7p5t_flk_lvt_c60_a00_V3.01_pkg/FE-Common_sec240318_0094/LIBERTY/ln05lpe_sc_m7p5t_flk_lvt_c60l08/ln05lpe_sc_m7p5t_flk_lvt_c60l08_sspg_nominal_max_0p7650v_m40c.lib_ccs_tn_lvf.gz \
/Foundry/ARM/samsung_5lpeAT/Standard_Cell/samsung/ln05lpe_sc_m7p5t_flk_lvt_c60_a00_V3.01_pkg/FE-Common_sec240318_0094/LIBERTY/ln05lpe_sc_m7p5t_flk_lvt_c60l08/ln05lpe_sc_m7p5t_flk_lvt_c60l08_sspg_nominal_max_0p6750v_m40c.lib_ccs_tn_lvf.gz \
]

read_libs $target_library




read_hdl -sv -f ../rtl/top.f
#analyze -f sverilog -vcs "-f ${TOP_SV_FILELIST}"
elaborate $design_name
init_design






#source -e -v ../sdc/.sdc
create_clock -name "dbus_clk"             [get_ports "clk"]          -period 1

set_output_delay -clock "dbus_clk" 0.6 [get_ports "out_a out_b out_c"]
set_input_delay -clock "dbus_clk" 0.6 [get_ports "rstn ctrl_on in_a in_b in_c in_a_t in_b_t in_c_t"]


set_clock_uncertainty 0.200 [all_clocks]

#set_dont_touch [get_cells -hierarchical -filter "full_name =~ sub_*_inst"]
#3set_dont_touch [get_cells -hierarchical -filter "full_name =~ *ctrl_pm_sub_a_off*"]
set_dont_touch_network [get_pins -hierarchical -filter "full_name =~ *ctrl_pm_sub_a_off*"]
set_dont_touch_network [get_pins -hierarchical -filter "full_name =~ *ctrl_pm_sub_b_off*"]
set_dont_touch_network [get_pins -hierarchical -filter "full_name =~ *ctrl_pm_sub_c_off*"]

check_timing_intent -verbose >  ../reports/${design_name}_genus_syn.unmapping.chk_timing
check_design -unresolved  >  ../reports/${design_name}_genus_syn.unmapping.chk_design




syn_generic
syn_map
syn_opt




write_hdl -lec > ../result/${design_name}_genus_syn.v



check_design -unresolved  >  ../reports/${design_name}_genus_syn.chk_design
check_timing_intent -verbose >  ../reports/${design_name}_genus_syn.chk_timing

report area > ../reports/${design_name}_genus_syn.area.rpt
report_timing -encounter  -max_paths 1000 > ../reports/${design_name}_genus_syn.timing.rpt
