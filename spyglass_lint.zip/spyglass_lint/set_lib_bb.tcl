set_option ignorefile /Foundry/ARM/samsung_14lpu/Standard_IO/samsung/ln14lpu_gpio_lib_1p8v_a01_V1.21_pkg/FE-Common/FE-Common_sec260303_0070/MODEL/ln14lpu_gpio_lib_t18.v
set_option ignorefile /Foundry/ARM/samsung_14lpu/Standard_IO/samsung/ln14lpu_gpio_lib_3p3v_a01_V1.13_pkg/FE-Common/FE-Common_sec260317_0034/MODEL/ln14lpu_gpio_lib_t33.v

set_option ignorefile /home/Storage_Plugins/xucw/work/G2_PRJ/g2_code/soc/design/src/scp/rtl/scp_bus/scp_bus_commons.v

#set_option ignorefile $G2_RTL/scp/sim_model/INNO_FNPLL_TOP.v
#set_option ignorefile $G2_RTL/scp/sim_model/inno_por_ip.v 
#set_option ignorefile /softs/Synopsys_vT/syn/T-2022.03-SP2/dw/dw02/src_ver/DW_div.v
#set_option ignorefile $G2_RTL/scp/rtl/trust_engine/memory/sim_model/SE_ACA_S14_RAM_SP_512X128.v
#set_option ignorefile $G2_RTL/scp/rtl/trust_engine/memory/sim_model/SE_CXT_S14_RAM_SP_528X32.v
#set_option ignorefile $G2_RTL/risc_v/rtl/wrapper/memory/mem_lib/CPU_S14_ROM_SP_4096X32.v
#set_option ignorefile $G2_RTL/risc_v/rtl/wrapper/memory/mem_lib/CPU_S14_RAM_SP_4096X32.v
#set_option ignorefile $G2_RTL/lowspeed/sim_model/sf_efuse4kb_v101_ln14lpp_34000.v
#set_option ignorefile $G2_RTL/lowspeed/sim_model/EC_S14_RAM_SP_128X32.v
#set_option ignorefile $G2_RTL/lowspeed/sim_model/inno_puf_64b_ip.v
