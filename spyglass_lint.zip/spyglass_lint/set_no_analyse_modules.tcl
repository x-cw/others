

## stop check memory sim model
#set_option stop { \
#ln14lpu_a01_mc_ra1rws_hdrw_rvt_4096x32m8b2c1_CPU_S14_RAM_SP_4096X32 \
#ln14lpu_a01_mc_rf1rs_hdrw_rvt_128x32m2b1c0_EC_S14_RAM_SP_128X32 
#ln14lpu_a01_mc_rf1rws_hdrw_rvt_512x128m2b1c0_SE_ACA_S14_RAM_SP_512X128 \
#ln14lpu_a01_mc_rf1rws_hdrw_rvt_528x32m4b1c0_SE_CXT_S14_RAM_SP_528X32 \
#ln14lpu_a01_mc_vromp_hd_lvt_4096x32m16b2c1_CPU_S14_ROM_SP_4096X32 \
#sf_efuse4kb_a100_ln14lpu_34000 \
#}
#
## stop check ip model
#set_option stop { \
#INNO_FNPLL_TOP \
#inno_por_ip \
#inno_puf_64b_ip \
#}
#

#set_option stopfile $GP3_RTL/img_fbc/verif/common/lib/gen_mixed_language_packages_cxtp_a/sa_img_fbc_fbdc_v5_pack.sv
#set_option stopfile $GP3_RTL/img_fbc/verif/common/lib/gen_mixed_language_packages_cxtp_a/sa_img_fbc_fbdc_v5_lossy_pack.sv
#set_option stopfile $GP3_RTL/img_fbc/design/common/rtl/img_fbcdc/sa_img_fbc_fbdc_v5_ecc_pack.sv


#ip_block -name inno_tsensor_ip
