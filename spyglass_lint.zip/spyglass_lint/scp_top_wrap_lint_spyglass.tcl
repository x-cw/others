#set env
set G2_RTL $env(G2_RTL)

#new project
new_project -force sglint.prj



read_file -type sourcelist  ../../scp_top_wrap_for_dc.f
#read_file -type verilog ./top_ppu_vir.v




read_file -type awl ./scp_top_wrap_waive.awl
#read_file -type awl $G2_RTL/interleaver/spyglass/lint/intlv_lint.awl
read_file -type awl $G2_RTL/adb/spyglass/lint/adb_lint.awl
read_file -type awl ./scp_bus.awl
read_file -type awl  $G2_RTL/lowspeed/spyglass/lint/low_speed_lint.awl
read_file -type awl  ./trust_engine_wrapper_waivelist.awl
#read_file -type awl  /home/Storage_Plugins/xuxq/gp3/GPUHW/code/flow_run/design/lint/soc/scp/gp3_io_lint/gp3_io_waivelist.awl
read_file -type awl  $G2_RTL/lowspeed/spyglass/lint/qspi_wrapper_waivelist.awl
read_file -type awl  $G2_RTL/top/rtl/interleaver/spyglass/lint/interleave.awl

# set libs and ignore files to block box 
source set_lib_bb.tcl
# read memory and lib cell 
source set_gateslib.tcl
#set_option ignorefile $G2_RTL/lowspeed/rtl/low_speed_misc_wrap.v
#set_option stop low_speed_misc_wrap


#read_file -type sglib {./aggregate.sglib}

#set clock and reset
#read_file -type sgdc ./template.sgdc


#----------- Set Design Options
#set_option top gp3_io
set_option top scp_top_wrap
#infer module with blackbox:   Causes SpyGlass to infer blackbox module interface based on the blackbox instances in the synthesized netlist and write to file named sgBlackbox.v in the current output directory
set_option inferblackbox yes
#hdl mode
set_option disablev2k no 
set_option enableV05 yes
set_option enableSV yes
set_option enableSV09 yes
#IEEE Std 1800-2012 Section 6.25 Parameterized data types: parameter type xxx = logic
set_option enableSV12 yes
set_option language_mode mixed
set_option mthresh 100000
#This option takes the threshold limit in terms of size of data bus  given as a power of 2. For e.g. if it's value is specified as 12, then data bus of size 4096 (2^12) would be completely evaluated.
set_option define_cell_sim_depth 12
#SpyGlass include the SYNTHESIS macro by default, so set it to false
set_option macro_synthesis_off yes

# Specify modules not to analyse
#source set_no_analyse_modules.tcl


#add for lint_rtl_enhanced waive rule of low risk
#set_option ignorerules {SYNTH_1084}
waive -rule {  {SYNTH_1084}  }  -comment {parameter/localparam cannot be assigned a timeliteral value ( 1ps )} 


#----------- Read in the design; Equivalent to Design Read in Console
link_design



#----------- Compiling the design; Equivalent to Design Read with Synthesis. Will also enable flattening
compile_design
set_option designread_disable_flatten true

##################################################
#-----------        Goal Setup        -----------#
##################################################

#----------- Define the methodology to use
#current_methodology $SPYGLASS_HOME/GuideWare/latest/block/rtl_handoff

#----------- Define the goal to run
current_goal Group_Run -goal {lint/lint_rtl lint/lint_rtl_enhanced}
#current_goal Group_Run -goal {lint/lint_rtl lint/lint_turbo_rtl lint/lint_functional_rtl lint/lint_abstract adv_lint/adv_lint_struct adv_lint/adv_lint_verify}


set_goal_option ignorerules { BufClock FlopEConst }

set_goal_option rules { \
CombLoop DisallowXInCaseZ-ML HangingInstInput-ML HangingInst-ML HangingInstOutput-ML IfWithoutElse-ML InferLatch infiniteloop  \
LatchGatedClock mixedsenselist ModuleName-ML NoAssignX-ML NoBusPartClock-ML NoStrengthInput-ML NoTopLogic NullPort-ML PragmaComments-ML \
ReserveNameSystemVerilog-ML SensListRepeat-ML SetBeforeRead-ML sim_loop01 sim_race02 STARC05-1.1.1.1 STARC05-1.1.1.3 STARC05-1.3.1.7 STARC05-2.10.1.4a \
STARC05-2.10.3.1 STARC05-2.10.3.2a STARC05-2.10.3.2c STARC05-2.1.1.2 STARC05-2.1.2.4 STARC05-2.1.3.2 STARC05-2.1.4.5 STARC05-2.1.4.6a STARC05-2.2.2.2b \
STARC05-2.2.2.3a STARC05-2.2.3.1 STARC05-2.3.1.2c STARC05-2.3.2.2 STARC05-2.3.6.1 STARC05-2.4.1.2 STARC05-2.4.1.5 STARC05-2.5.1.1 STARC05-2.7.2.2 \
STARC05-2.8.1.3 STARC05-2.8.1.5 STARC05-2.8.3.3 STARC05-3.2.3.1 STARC05-3.2.3.2 STARC-1.4.3.4 STARC-2.11.1.4 STARC-2.3.6.1 STARC-2.3.6.2a STARC-3.2.3.2 \
SYNTH_5058 SYNTH_5143 SYNTH_5164 SYNTH_5192 SYNTH_5224 SYNTH_5230 SYNTH_5254 SYNTH_5255 SYNTH_5260 SYNTH_5273 SYNTH_5288 SYNTH_5294 \
SYNTH_102 SYNTH_103 SYNTH_104 SYNTH_78 SYNTH_126 SYNTH_12613 SYNTH_131 SYNTH_132 SYNTH_5035 SYNTH_5037 SYNTH_5054 SYNTH_77 SYNTH_92 \
TaskComment TriStateName UndrivenInTerm-ML UndrivenNet-ML UndrivenNUnloaded-ML UndrivenOutPort-ML UndrivenOutTermNLoaded-ML UnrecSynthDir-ML UnloadedInPort-ML \
W116 W120 W122 W129 W159 W163 W164a W164b W17 W18 W182g W182h W182k W188 W19 W213 W215 W224 W240 W241 W245 W250 W263 W287a W287b W210 \
W293 W317 W336 W337 W339a W342 W345 W346 W348 W362 W392 W398 W414 W415 W422 W423 W428 W429L W433 W438 W442a W442b W464 W468 W480 W486 W490 W502 W528 W541 W546 \
W71 WarnAnalyzeBBox WRN_1021 WRN_27 WRN_43 WRN_48 WRN_73 STX_VE_363 STX_VE_481 STX_VE_489 STX_VE_601 \
}


set_goal_option  addrules {W164a W164b W164c W287a W122}

set_goal_option  overloadrules {W164a+severity=Error}
set_goal_option  overloadrules {W164b+severity=Error}
set_goal_option  overloadrules {W164c+severity=Error}
set_goal_option  overloadrules {W287a+severity=Error} ;#undriven input
set_goal_option  overloadrules {W122+severity=Error}



#SGDC_waive24 (6628) : Design units specified with -du or -ip fields should exist in the design
set_goal_option  overloadrules {SGDC_waive24+severity=Info}
#SGDC_waive25 (57) : Specified regular expression does not match any design unit names
set_goal_option  overloadrules {SGDC_waive25+severity=Info}
#SGDC_waive26 (23) : Specified files should exist in the current setup
set_goal_option  overloadrules {SGDC_waive26+severity=Info}
#SGDC_waive27 (573) : Specified regular expression does not match any files in the current setup
set_goal_option  overloadrules {SGDC_waive27+severity=Info}
#SGDC_waive30 (20) : Severity of rule specified with -rule field is not matching severities specified with -severity field
set_goal_option  overloadrules {SGDC_waive30+severity=Info}

#Signal 'fifo_mem[rbinnext[(AWIDTH - 1):0] ]' size too big thus not processed, use 'set_parameter handle_large_bus yes' for enabling handling of these signals
set_parameter handle_large_bus yes
set_parameter nocheckoverflow yes

#----------- Run the goal
run_goal

save_project -force
gui_start
# exit -save
