// +FHDR----------------------------------------------------------------------------
// Project Name  : CodaCache
// Author        : chenm
// Email         : chenm@innosilicon.com.cn
// Create On     : 2024/07/16 10:58
// Last Modified : 2024/07/16 10:58
// File Name     : CC_prot_reg_set.v
// Description   :
// 
// Copyright (c) 2024 Innosilicon.
// ALL RIGHTS RESERVED
// 
// ---------------------------------------------------------------------------------
// Modification History:
// Date         By              Version                 Change Description
// ---------------------------------------------------------------------------------
// 2024/07/16   chenm           1.0                     Original
// 
// -FHDR----------------------------------------------------------------------------
module arb_core_round_robin #(parameter REQ_NUM = 2) (
	input [REQ_NUM-1:0]req,
	input [REQ_NUM-1:0]park_point,
	output [REQ_NUM-1:0]grant);

// round robin arb
// round robin prioroty from high to low
//
// (park_point - 1'd1) menas that mask the current and high position
// the merge becase of the conversion from lowest to highrst bit
// we shold to find the highest bit value is equal 1

wire  [REQ_NUM*2-1:0] req_mask = {req & (park_point - 1'd1) , req};


wire [REQ_NUM*2-1:0]grant_temp;
wire [REQ_NUM*2-1:0]grant_pre ;

// set grant_pre the hightest bit is zero
// all bits is 1 after highest bit 
assign grant_pre[REQ_NUM*2-1] = 1'd0;
assign grant_pre[REQ_NUM*2-2:0] = grant_pre[REQ_NUM*2-1:1] | req_mask[REQ_NUM*2-1:1];

// the low bit value is 1 will mask by  ~grant_pre
assign grant_temp = req_mask & ~grant_pre;

assign grant = grant_temp[REQ_NUM*2-1:REQ_NUM] | grant_temp[REQ_NUM-1:0];

endmodule
// Local Variables:
// verilog-library-directories:("./" ) 
// verilog-auto-inst-param-value:t
// End:
