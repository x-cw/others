
`timescale 1ns/1ps
module comb_process_dp2clk_D64W512_wrapper (
// Beginning of automatic inputs (from unused autoinst inputs)
input                   Clk,                    // To inst_u0 of pcie_atomic_dp2clk_D16W128_wrapper.v, ...
input [5:0]             RdAddr,                 // To inst_u0 of pcie_atomic_dp2clk_D16W128_wrapper.v, ...
input                   RdEn,                   // To inst_u0 of pcie_atomic_dp2clk_D16W128_wrapper.v, ...
input [5:0]             WrAddr,                 // To inst_u0 of pcie_atomic_dp2clk_D16W128_wrapper.v, ...
input [511: 0]          WrData,                 // To inst_u0 of pcie_atomic_dp2clk_D16W128_wrapper.v, ..., Couldn't Merge
input                   WrEn,                   // To inst_u0 of pcie_atomic_dp2clk_D16W128_wrapper.v, ...
// End of automatics
// Beginning of automatic outputs (from unused autoinst outputs)
output reg [511: 0]       RdData                  // From inst_u0 of pcie_atomic_dp2clk_D16W128_wrapper.v, ..., Couldn't Merge
// End of automatics
   );
// Beginning of automatic inputs (from unused autoinst inputs)
wire                   RdEn0;                  // To inst_u0 of comb_process_dp2clk_D32W512_wrapper.v
wire                   RdEn1;                  // To inst_u1 of comb_process_dp2clk_D32W512_wrapper.v
wire                   WrEn0;                  // To inst_u0 of comb_process_dp2clk_D32W512_wrapper.v
wire                   WrEn1;                  // To inst_u1 of comb_process_dp2clk_D32W512_wrapper.v
// End of automatics

/*autowire*/
// Beginning of automatic wires (for undeclared instantiated-module outputs)
wire [511:0]            RdData0;                // From inst_u0 of comb_process_dp2clk_D32W512_wrapper.v
wire [511:0]            RdData1;                // From inst_u1 of comb_process_dp2clk_D32W512_wrapper.v
// End of automatics


assign WrEn0 = WrEn & ~WrAddr[5];
assign WrEn1 = WrEn &  WrAddr[5];


assign RdEn0 = RdEn & ~RdAddr[5];
assign RdEn1 = RdEn &  RdAddr[5];

reg  read_addr_reg;
always@(posedge Clk)
    read_addr_reg <= RdAddr[5];


always@(*)begin
    RdData = {512{1'd0}};
    case(read_addr_reg)
        1'd0 : RdData = RdData0  ;
        1'd1 : RdData = RdData1  ;
        default: RdData = {512{1'd0}};
    endcase
end

/* comb_process_dp2clk_D32W512_wrapper auto_template "inst_u\(.*\)"(
.\(RdData\)          (\1@[]),
.\(.*En\)            (\1@),
);*/

comb_process_dp2clk_D32W512_wrapper inst_u0(/*autoinst*/
                                           // Outputs
                                           .RdData              (RdData0[511:0]), // Templated
                                           // Inputs
                                           .Clk                 (Clk),
                                           .RdAddr              (RdAddr[4:0]),
                                           .RdEn                (RdEn0),         // Templated
                                           .WrAddr              (WrAddr[4:0]),
                                           .WrData              (WrData[511:0]),
                                           .WrEn                (WrEn0));        // Templated

comb_process_dp2clk_D32W512_wrapper inst_u1(/*autoinst*/
                                           // Outputs
                                           .RdData              (RdData1[511:0]), // Templated
                                           // Inputs
                                           .Clk                 (Clk),
                                           .RdAddr              (RdAddr[4:0]),
                                           .RdEn                (RdEn1),         // Templated
                                           .WrAddr              (WrAddr[4:0]),
                                           .WrData              (WrData[511:0]),
                                           .WrEn                (WrEn1));        // Templated
 endmodule

// Local Variables:
// verilog-library-directories:("./") 
// verilog-auto-inst-param-value:t
// End:
