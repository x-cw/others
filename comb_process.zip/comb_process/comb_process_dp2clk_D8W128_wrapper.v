
`timescale 1ns/1ps
module comb_process_dp2clk_D8W128_wrapper (
/*autoinput*/
// Beginning of automatic inputs (from unused autoinst inputs)
input [2:0]             AA,                     // To u0 of ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128.v
input [2:0]             AB,                     // To u0 of ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128.v
input                   CLK,                    // To u0 of ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128.v, ...
input [127:0]           D,                      // To u0 of ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128.v
input                   REB,                    // To u0 of ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128.v
input                   WEA,                    // To u0 of ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128.v
// End of automatics
/*autooutput*/
// Beginning of automatic outputs (from unused autoinst outputs)
output [127:0]          Q                       // From u0 of ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128.v
// End of automatics
   );

   wire [127:0] BWEB;
   assign BWEB = {128{1'd1}};
`ifndef REG_MEM

/*autowire*/

/* ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 auto_template (
        //output
        .DOUT              (Q[]),              //data output
        .SO_D_L            (),
        .SO_D_R         (),
//        .VDDPE          (),
//        .VDDCE          (),
//        .VSSE           (),        
        //input
        .RCK           (CLK),                  //clock input
        .WCK           (CLK), 
        .WA             (AA[2:0]),             
        .RA             (AB[2:0]),           
        .DI             (D[]),              
        .REN           (~REB[]),
        .WEN           (~WEA[]),
        .BWEN           (~BWEB[]),
//        .MCS[RW][DR]        (2'b01),
        .MCS[RW][DR]        (2'b00),
        .ADME             (3'b100),              
   .KCS                                 (1'd0),
        ..*             (@"( if(equal vl-dir \\"input\\") (concat \\"{\\" vl-width \\"{1'd0}}\\")  \\" \\"  )"),             
);*/

ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 #(
.word_width(128),
.addr_width(3),
.mcsa_width(2),
.mcsb_width(2),
.adme_width(3),
.faddr1_width(5),
.faddr2_width(5)
)
u0( 
/*autoinst*/
   // Outputs
   .SO_D_L                              (),                      // Templated
   .SO_D_R                              (),                      // Templated
   .DOUT                                (Q[127:0]),              // Templated
   // Inouts
//   .VDDE                                ( ),                     // Templated
//   .VSSE                                ( ),                     // Templated
   // Inputs
   .RA                                  (AB[2:0]),               // Templated
   .WA                                  (AA[2:0]),               // Templated
   .DI                                  (D[127:0]),              // Templated
   .RCK                                 (CLK),                   // Templated
   .WCK                                 (CLK),                   // Templated
   .REN                                 (~REB),                  // Templated
   .WEN                                 (~WEA),                  // Templated
   .BWEN                                (~BWEB[127:0]),          // Templated
   .DFTRAM                              ({1{1'd0}}),             // Templated
   .SE                                  ({1{1'd0}}),             // Templated
   .SI_D_L                              ({1{1'd0}}),             // Templated
   .SI_D_R                              ({1{1'd0}}),             // Templated
   .MCSRD                               (2'b00),                 // Templated
   .KCS                                 (1'd0),                  // Templated
   .MCSWR                               (2'b00),                 // Templated
   .ADME                                (3'b100),                // Templated
   .CRE1                                ({1{1'd0}}),             // Templated
   .CRE2                                ({1{1'd0}}),             // Templated
   .FCA1                                ({5{1'd0}}),             // Templated
   .FCA2                                ({5{1'd0}}));            // Templated
`else


reg   [127:0] mem [7:0];
always @(posedge CLK) begin
  if(WEA) 
      mem[AA]  <=  D;
end

reg [127:0]          data;
always @(posedge CLK) begin
  if(REB) begin
    data[127:0]     <=  mem[AB];
  end
end
assign Q = data;

`endif



endmodule

// Local Variables:
// verilog-library-directories:("./") 
// verilog-auto-inst-param-value:t
// End:
