// +FHDR----------------------------------------------------------------------------
// Copyright (c) 2025, Innosilicon, Inc. Confidential Proprietary
// PROJECT NAME  : xxx
// DEPARTMENT    : Digtal Frontend SOC
// AUTHOR        : chenm
// EMAIL         : chenm@innosilicon.com.cn
// CREATE ON     : 2025/12/05 11:17
// FILE NAME     : comb_process_unit.v
// DESCRIPTION   :          
//         
// Copyright (c) 2025 Innosilicon.
// ALL RIGHTS RESERVED
// 
// ---------------------------------------------------------------------------------
// Modification History:
// Date         By              Version                 Change Description
// ---------------------------------------------------------------------------------
// 2025/12/05   chenm           1.0                     Original
// 
// -FHDR----------------------------------------------------------------------------

`timescale 1ns/1ps

module comb_process_unit #(
    parameter ADDRW = 49,
    parameter USERW = 14,
    parameter IDW   = 10,
    parameter OT    = 512,
    parameter ENTRY_DEPTH = 8,
    parameter BYPASS_DEPTH = 2,
    parameter BOUNDARY = 512
)(/*autoarg*/
   // Outputs
   awready_s, awvalid_m, awid_m, awaddr_m, awlen_m, awsize_m,
   awburst_m, awprot_m, awcache_m, awqos_m, awuser_m, awatop_m,
   awlock_m, wready_s, wvalid_m, wdata_m, wstrb_m, wlast_m, bvalid_s,
   bid_s, bresp_s, bready_m, arready_s, arvalid_m, arid_m, araddr_m,
   arlen_m, arsize_m, arburst_m, arprot_m, arcache_m, arqos_m,
   aruser_m, arlock_m, rvalid_s, rid_s, rdata_s, rresp_s, rlast_s,
   rready_m, reg_ar_trig_flush_comb_done_cnt,
   reg_ar_trig_flush_tmo_cnt, reg_ar_trig_flush_full_cnt,
   reg_ar_trig_send_req_total_cnt, reg_aw_trig_flush_comb_done_cnt,
   reg_aw_trig_flush_tmo_cnt, reg_aw_trig_flush_full_cnt,
   reg_aw_trig_send_req_total_cnt, req_ar_tmo_avg_payload_cnt,
   req_ar_tmo_avg_payload_len_cnt, req_ar_total_avg_payload_cnt,
   req_ar_total_avg_payload_len_cnt, req_aw_tmo_avg_payload_cnt,
   req_aw_tmo_avg_payload_len_cnt, req_aw_total_avg_payload_cnt,
   req_aw_total_avg_payload_len_cnt, reg_ar_normal_harzard_cnt,
   reg_aw_normal_harzard_cnt,
   // Inputs
   clk, rstn, reg_comb_tmo_cnt_num, reg_bypass_mode,
   reg_read_bypass_mode, reg_write_bypass_mode, awvalid_s, awid_s,
   awaddr_s, awlen_s, awsize_s, awburst_s, awprot_s, awcache_s,
   awqos_s, awuser_s, awatop_s, awlock_s, awready_m, wvalid_s,
   wdata_s, wstrb_s, wlast_s, wready_m, bready_s, bvalid_m, bid_m,
   bresp_m, arvalid_s, arid_s, araddr_s, arlen_s, arsize_s, arburst_s,
   arprot_s, arcache_s, arqos_s, aruser_s, arlock_s, arready_m,
   rready_s, rvalid_m, rid_m, rdata_m, rresp_m, rlast_m, reg_avg_mode,
   reg_cnt_clear_en, reg_avg_enable, reg_avg_time
   );
input                   clk;                    // To bypass_fifo of repack_sync_fifo.v, ...
input                   rstn;                   // To bypass_fifo of repack_sync_fifo.v, ...
input [6:0] reg_comb_tmo_cnt_num ;
input  reg_bypass_mode            ;
input  reg_read_bypass_mode       ;
input  reg_write_bypass_mode      ;
  //axi upstream awchannel interface
  input  wire             awvalid_s ;
  output wire             awready_s ;
  input  wire [IDW-1:0]   awid_s    ;
  input  wire [ADDRW-1:0] awaddr_s  ;
  input  wire [3:0]       awlen_s   ;
  input  wire [2:0]       awsize_s  ;
  input  wire [1:0]       awburst_s ;
  input  wire [2:0]       awprot_s  ;
  input  wire [3:0]       awcache_s ;
  input  wire [3:0]       awqos_s   ;
  input  wire [USERW-1:0] awuser_s  ;
  input  wire [5:0]       awatop_s  ;
  input  wire             awlock_s  ;
  
  //axi downstream awchannel interface
  output wire             awvalid_m ;
  input  wire             awready_m ;
  output wire [IDW-1:0]   awid_m    ;
  output wire [ADDRW-1:0] awaddr_m  ;
  output wire [3:0]       awlen_m   ;
  output wire [2:0]       awsize_m  ;
  output wire [1:0]       awburst_m ;
  output wire [2:0]       awprot_m  ;
  output wire [3:0]       awcache_m ;
  output wire [3:0]       awqos_m   ;
  output wire [USERW-1:0] awuser_m  ;
  output wire [5:0]       awatop_m  ;
  output wire             awlock_m  ;
  

//axi upstream wchannel interface
input  wire             wvalid_s  ;
output wire             wready_s  ;
input  wire [511:0]     wdata_s   ;
input  wire [ 63:0]     wstrb_s   ;
input  wire             wlast_s   ;

//axi downstream wchannel interface
output  wire            wvalid_m  ;
input   wire            wready_m  ;
output  wire [511:0]    wdata_m   ;
output  wire [ 63:0]    wstrb_m   ;
output  wire            wlast_m   ;

//axi upstream bchannel interface
output wire             bvalid_s  ;
output wire [IDW-1:0]   bid_s     ;
//output wire [USERW-1:0] buser_s   ;
output wire [1:0]       bresp_s   ;
input  wire             bready_s  ;

//axi downstream rchannel interface
input  wire             bvalid_m  ;
input  wire [IDW-1:0]   bid_m     ;
//input  wire [USERW-1:0] buser_m   ;
input  wire [1:0]       bresp_m   ;
output wire             bready_m  ;

//axi upstream archannel interface
input  wire             arvalid_s ;
output wire             arready_s ;
input  wire [IDW-1:0]   arid_s    ;
input  wire [ADDRW-1:0] araddr_s  ;
input  wire [3:0]       arlen_s   ;
input  wire [2:0]       arsize_s  ;
input  wire [1:0]       arburst_s ;
input  wire [2:0]       arprot_s  ;
input  wire [3:0]       arcache_s ;
input  wire [3:0]       arqos_s   ;
input  wire [USERW-1:0] aruser_s  ;
input  wire             arlock_s  ;

//axi downstream archannel interface
input  wire             arready_m ;
output wire             arvalid_m ;
output      [IDW-1:0]   arid_m    ;
output wire [ADDRW-1:0] araddr_m  ;
output wire [3:0]       arlen_m   ;
output wire [2:0]       arsize_m  ;
output wire [1:0]       arburst_m ;
output wire [2:0]       arprot_m  ;
output wire [3:0]       arcache_m ;
output wire [3:0]       arqos_m   ;
output wire [USERW-1:0] aruser_m  ;
output wire             arlock_m  ;

//axi upstream rchannel interface
output wire             rvalid_s  ;
output wire [IDW-1:0]   rid_s     ;
//output wire [USERW-1:0] ruser_s   ;
output wire [511:0]     rdata_s   ;
output wire [1:0]       rresp_s   ;
output wire             rlast_s   ;
input  wire             rready_s  ;

//axi downstream rchannel interface
input  wire             rvalid_m  ;
input  wire [IDW-1:0]   rid_m     ;
//input  wire [USERW-1:0] ruser_m   ;
input  wire [511:0]     rdata_m   ;
input  wire [1:0]       rresp_m   ;
input  wire             rlast_m   ;
output wire             rready_m  ;

output [31:0] reg_ar_trig_flush_comb_done_cnt ;
output [31:0] reg_ar_trig_flush_tmo_cnt       ;
output [31:0] reg_ar_trig_flush_full_cnt      ;
output [31:0] reg_ar_trig_send_req_total_cnt  ;
//output [ 3:0] reg_ar_send_avg_beat_total_cnt  ;
//output [ 3:0] reg_ar_send_avg_beat_tmo_cnt    ;
output [31:0] reg_aw_trig_flush_comb_done_cnt ;
output [31:0] reg_aw_trig_flush_tmo_cnt       ;
output [31:0] reg_aw_trig_flush_full_cnt      ;
output [31:0] reg_aw_trig_send_req_total_cnt  ;
//output [ 3:0] reg_aw_send_avg_beat_total_cnt  ;
//output [ 3:0] reg_aw_send_avg_beat_tmo_cnt    ;
output [31:0]             req_ar_tmo_avg_payload_cnt;// From write_unit of write_comb_unit.v, ...
output [31:0]             req_ar_tmo_avg_payload_len_cnt;// From write_unit of write_comb_unit.v, ...
output [31:0]             req_ar_total_avg_payload_cnt;// From write_unit of write_comb_unit.v, ...
output [31:0]             req_ar_total_avg_payload_len_cnt;// From write_unit of write_comb_unit.v, ...
output [31:0]             req_aw_tmo_avg_payload_cnt;// From write_unit of write_comb_unit.v, ...
output [31:0]             req_aw_tmo_avg_payload_len_cnt;// From write_unit of write_comb_unit.v, ...
output [31:0]             req_aw_total_avg_payload_cnt;// From write_unit of write_comb_unit.v, ...
output [31:0]             req_aw_total_avg_payload_len_cnt;// From write_unit of write_comb_unit.v, ...


output [15:0]             reg_ar_normal_harzard_cnt;// From read_unit of read_process_unit.v
output [15:0]             reg_aw_normal_harzard_cnt;// From write_unit of write_comb_unit.v
input         reg_avg_mode                    ;
input         reg_cnt_clear_en                  ;
input         reg_avg_enable                  ;
input [31:0]  reg_avg_time                    ;
wire  reg_cnt_clear_en_temp      ;
reg   reg_cnt_clear_en_reg;

reg [12:0] register_r0;
reg [12:0] register_r1;

wire           reg_sync_avg_mode          ;
wire           reg_sync_cnt_clear_en      ;
wire           reg_sync_avg_enable        ;
wire           reg_sync_bypass_mode       ;
wire           reg_sync_read_bypass_mode  ;
wire           reg_sync_write_bypass_mode ;
wire [6:0]     reg_sync_comb_tmo_cnt_num  ;

/*autowire*/
// Beginning of automatic wires (for undeclared instantiated-module outputs)
wire [ADDRW-1:0]        comb_araddr;            // From read_unit of read_process_unit.v
wire [1:0]              comb_arburst;           // From read_unit of read_process_unit.v
wire [3:0]              comb_arcache;           // From read_unit of read_process_unit.v
wire [IDW-1:0]          comb_arid;              // From read_unit of read_process_unit.v
wire [3:0]              comb_arlen;             // From read_unit of read_process_unit.v
wire                    comb_arlock;            // From read_unit of read_process_unit.v
wire [2:0]              comb_arprot;            // From read_unit of read_process_unit.v
wire [3:0]              comb_arqos;             // From read_unit of read_process_unit.v
wire [2:0]              comb_arsize;            // From read_unit of read_process_unit.v
wire [USERW-1:0]        comb_aruser;            // From read_unit of read_process_unit.v
wire [ADDRW-1:0]        comb_awaddr;            // From write_unit of write_comb_unit.v
wire [5:0]              comb_awatop;            // From write_unit of write_comb_unit.v
wire [1:0]              comb_awburst;           // From write_unit of write_comb_unit.v
wire [3:0]              comb_awcache;           // From write_unit of write_comb_unit.v
wire [IDW-1:0]          comb_awid;              // From write_unit of write_comb_unit.v
wire [3:0]              comb_awlen;             // From write_unit of write_comb_unit.v
wire                    comb_awlock;            // From write_unit of write_comb_unit.v
wire [2:0]              comb_awprot;            // From write_unit of write_comb_unit.v
wire [3:0]              comb_awqos;             // From write_unit of write_comb_unit.v
wire [2:0]              comb_awsize;            // From write_unit of write_comb_unit.v
wire [USERW-1:0]        comb_awuser;            // From write_unit of write_comb_unit.v
wire [IDW-1:0]          comb_bid;               // From write_unit of write_comb_unit.v
wire [1:0]              comb_bresp;             // From write_unit of write_comb_unit.v
wire [511:0]            comb_rdata;             // From read_unit of read_process_unit.v
wire [IDW-1:0]          comb_rid;               // From read_unit of read_process_unit.v
wire                    comb_rlast;             // From read_unit of read_process_unit.v
wire [1:0]              comb_rresp;             // From read_unit of read_process_unit.v
wire [511:0]            comb_wdata;             // From write_unit of write_comb_unit.v
wire                    comb_wlast;             // From write_unit of write_comb_unit.v
wire [63:0]             comb_wstrb;             // From write_unit of write_comb_unit.v
// End of automatics
wire                    downstream_arvalid;     // From read_unit of read_process_unit.v
wire                    downstream_awvalid;     // From write_unit of write_comb_unit.v
wire                    downstream_bready;      // From write_unit of write_comb_unit.v
wire                    downstream_rready;      // From read_unit of read_process_unit.v
wire                    downstream_wvalid;      // From write_unit of write_comb_unit.v
wire                    upstream_arready;       // From read_unit of read_process_unit.v
wire                    upstream_awready;       // From write_unit of write_comb_unit.v
wire                    upstream_bvalid;        // From write_unit of write_comb_unit.v
wire                    upstream_rvalid;        // From read_unit of read_process_unit.v
wire                    upstream_wready;        // From write_unit of write_comb_unit.v
wire                    upstream_arvalid;     // From read_unit of read_process_unit.v
wire                    upstream_awvalid;     // From write_unit of write_comb_unit.v
wire                    upstream_bready;      // From write_unit of write_comb_unit.v
wire                    upstream_rready;      // From read_unit of read_process_unit.v
wire                    upstream_wvalid;      // From write_unit of write_comb_unit.v
wire                    downstream_arready;       // From read_unit of read_process_unit.v
wire                    downstream_awready;       // From write_unit of write_comb_unit.v
wire                    downstream_bvalid;        // From write_unit of write_comb_unit.v
wire                    downstream_rvalid;        // From read_unit of read_process_unit.v
wire                    downstream_wready;        // From write_unit of write_comb_unit.v
wire read_bypass;
wire write_bypass;

always@(posedge clk or negedge rstn)
if(~rstn)begin
    register_r0           <= 13'd0;
    register_r1           <= 13'd0;
    reg_cnt_clear_en_reg  <= 1'd0;
end else begin
    register_r0 <= {reg_bypass_mode, reg_read_bypass_mode, reg_write_bypass_mode, reg_comb_tmo_cnt_num, reg_avg_mode, reg_cnt_clear_en, reg_avg_enable};
    register_r1 <=  register_r0;
    reg_cnt_clear_en_reg  <= reg_sync_cnt_clear_en ;
end

assign {reg_sync_bypass_mode, reg_sync_read_bypass_mode, reg_sync_write_bypass_mode, reg_sync_comb_tmo_cnt_num, reg_sync_avg_mode, reg_sync_cnt_clear_en, reg_sync_avg_enable} = register_r1;
assign reg_cnt_clear_en_temp = ~reg_cnt_clear_en_reg & reg_sync_cnt_clear_en;

assign read_bypass  = reg_sync_read_bypass_mode  | reg_sync_bypass_mode;
assign write_bypass = reg_sync_write_bypass_mode | reg_sync_bypass_mode;

assign arready_s = read_bypass  ? arready_m : upstream_arready;
assign awready_s = write_bypass ? awready_m : upstream_awready;
assign  wready_s = write_bypass ?  wready_m : upstream_wready ;

assign rvalid_s = read_bypass  ? rvalid_m : upstream_rvalid;
assign bvalid_s = write_bypass ? bvalid_m : upstream_bvalid;

assign upstream_arvalid = arvalid_s & ~read_bypass;
assign upstream_awvalid = awvalid_s & ~write_bypass;
assign upstream_wvalid  =  wvalid_s & ~write_bypass;

assign upstream_rready  = rready_s & ~read_bypass ;
assign upstream_bready  = bready_s & ~write_bypass;

assign arvalid_m = read_bypass  ? arvalid_s : downstream_arvalid; 
assign awvalid_m = write_bypass ? awvalid_s : downstream_awvalid; 
assign  wvalid_m = write_bypass ?  wvalid_s : downstream_wvalid; 

assign  rready_m = read_bypass  ? rready_s : downstream_rready;
assign  bready_m = write_bypass ? bready_s : downstream_bready;

assign downstream_arready = ~read_bypass  & arready_m;
assign downstream_awready = ~write_bypass & awready_m;
assign downstream_wready  = ~write_bypass &  wready_m;

assign downstream_rvalid  = ~read_bypass  & rvalid_m;
assign downstream_bvalid  = ~write_bypass & bvalid_m;

assign awid_m     =  write_bypass ?  awid_s      :  comb_awid    ;
assign awlen_m    =  write_bypass ?  awlen_s     :  comb_awlen   ;
assign awsize_m   =  write_bypass ?  awsize_s    :  comb_awsize  ;
assign awburst_m  =  write_bypass ?  awburst_s   :  comb_awburst ;
assign awprot_m   =  write_bypass ?  awprot_s    :  comb_awprot  ;
assign awcache_m  =  write_bypass ?  awcache_s   :  comb_awcache ;
assign awqos_m    =  write_bypass ?  awqos_s     :  comb_awqos   ;
assign awuser_m   =  write_bypass ?  awuser_s    :  comb_awuser  ;
assign awatop_m   =  write_bypass ?  awatop_s    :  comb_awatop  ;
assign awlock_m   =  write_bypass ?  awlock_s    :  comb_awlock  ;


assign  wdata_m  = write_bypass ? wdata_s  :  comb_wdata  ;
assign  wstrb_m  = write_bypass ? wstrb_s  :  comb_wstrb  ;
assign  wlast_m  = write_bypass ? wlast_s  :  comb_wlast  ;

assign bid_s    = write_bypass ?  bid_m    :  comb_bid    ;
assign bresp_s  = write_bypass ?  bresp_m  :  comb_bresp  ;


assign araddr_m   = read_bypass  ?  {1'd1, araddr_s[ADDRW-2:0]}  : {1'd1, comb_araddr[ADDRW-2:0]}  ;
assign awaddr_m   = write_bypass ?  {1'd1, awaddr_s[ADDRW-2:0]}  : {1'd1, comb_awaddr[ADDRW-2:0]}  ;

assign arid_m     = read_bypass ?  arid_s    : comb_arid    ;
assign arlen_m    = read_bypass ?  arlen_s   : comb_arlen   ;
assign arsize_m   = read_bypass ?  arsize_s  : comb_arsize  ;
assign arburst_m  = read_bypass ?  arburst_s : comb_arburst ;
assign arprot_m   = read_bypass ?  arprot_s  : comb_arprot  ;
assign arcache_m  = read_bypass ?  arcache_s : comb_arcache ;
assign arqos_m    = read_bypass ?  arqos_s   : comb_arqos   ;
assign aruser_m   = read_bypass ?  aruser_s  : comb_aruser  ;
assign arlock_m   = read_bypass ?  arlock_s  : comb_arlock  ;


assign rid_s    = read_bypass ?  rid_m    :   comb_rid     ;
assign rdata_s  = read_bypass ?  rdata_m  :   comb_rdata   ;
assign rresp_s  = read_bypass ?  rresp_m  :   comb_rresp   ;
assign rlast_s  = read_bypass ?  rlast_m  :   comb_rlast   ;


/*write_comb_unit auto_template "\(.*\)" (
.\(.*ready\|.*valid\)_s                     (upstream_\1),
.\(.*ready\|.*valid\)_m                     (downstream_\1),
.\(aw.*\)_m                                 (comb_\1[]),
.\(w.*\)_m                                  (comb_\1[]),
.\(b.*\)_s                                  (comb_\1[]),
.reg_avg_time                               (reg_avg_time[]),
.reg_cnt_clear_en                           (reg_cnt_clear_en_temp),
.reg_\(avg_.*\|comb_tmo_cnt_num\)           (reg_sync_\1[]),

);*/          
write_comb_unit #(
    .ADDRW       (ADDRW       ) ,
    .USERW       (USERW       ) ,
    .IDW         (IDW         ) ,
    .OT          (OT          ) ,
    .ENTRY_DEPTH (ENTRY_DEPTH ) ,
    .BYPASS_DEPTH (BYPASS_DEPTH ) ,
    .BOUNDARY    (BOUNDARY    ) )
 write_unit(/*autoinst*/
            // Outputs
            .awready_s                  (upstream_awready),      // Templated
            .awvalid_m                  (downstream_awvalid),    // Templated
            .awid_m                     (comb_awid[IDW-1:0]),    // Templated
            .awaddr_m                   (comb_awaddr[ADDRW-1:0]), // Templated
            .awlen_m                    (comb_awlen[3:0]),       // Templated
            .awsize_m                   (comb_awsize[2:0]),      // Templated
            .awburst_m                  (comb_awburst[1:0]),     // Templated
            .awprot_m                   (comb_awprot[2:0]),      // Templated
            .awcache_m                  (comb_awcache[3:0]),     // Templated
            .awqos_m                    (comb_awqos[3:0]),       // Templated
            .awuser_m                   (comb_awuser[USERW-1:0]), // Templated
            .awatop_m                   (comb_awatop[5:0]),      // Templated
            .awlock_m                   (comb_awlock),           // Templated
            .wready_s                   (upstream_wready),       // Templated
            .wvalid_m                   (downstream_wvalid),     // Templated
            .wdata_m                    (comb_wdata[511:0]),     // Templated
            .wstrb_m                    (comb_wstrb[63:0]),      // Templated
            .wlast_m                    (comb_wlast),            // Templated
            .bvalid_s                   (upstream_bvalid),       // Templated
            .bid_s                      (comb_bid[IDW-1:0]),     // Templated
            .bresp_s                    (comb_bresp[1:0]),       // Templated
            .bready_m                   (downstream_bready),     // Templated
            .reg_aw_trig_send_req_total_cnt(reg_aw_trig_send_req_total_cnt[31:0]),
            .reg_aw_trig_flush_comb_done_cnt(reg_aw_trig_flush_comb_done_cnt[31:0]),
            .req_aw_tmo_avg_payload_len_cnt(req_aw_tmo_avg_payload_len_cnt[31:0]),
            .req_aw_tmo_avg_payload_cnt (req_aw_tmo_avg_payload_cnt[31:0]),
            .req_aw_total_avg_payload_len_cnt(req_aw_total_avg_payload_len_cnt[31:0]),
            .req_aw_total_avg_payload_cnt(req_aw_total_avg_payload_cnt[31:0]),
            .reg_aw_trig_flush_full_cnt (reg_aw_trig_flush_full_cnt[31:0]),
            .reg_aw_trig_flush_tmo_cnt  (reg_aw_trig_flush_tmo_cnt[31:0]),
            .reg_aw_normal_harzard_cnt  (reg_aw_normal_harzard_cnt[15:0]),
            // Inputs
            .clk                        (clk),
            .rstn                       (rstn),
            .reg_comb_tmo_cnt_num       (reg_sync_comb_tmo_cnt_num[6:0]), // Templated
            .awvalid_s                  (upstream_awvalid),      // Templated
            .awid_s                     (awid_s[IDW-1:0]),
            .awaddr_s                   (awaddr_s[ADDRW-1:0]),
            .awlen_s                    (awlen_s[3:0]),
            .awsize_s                   (awsize_s[2:0]),
            .awburst_s                  (awburst_s[1:0]),
            .awprot_s                   (awprot_s[2:0]),
            .awcache_s                  (awcache_s[3:0]),
            .awqos_s                    (awqos_s[3:0]),
            .awuser_s                   (awuser_s[USERW-1:0]),
            .awatop_s                   (awatop_s[5:0]),
            .awlock_s                   (awlock_s),
            .awready_m                  (downstream_awready),    // Templated
            .wvalid_s                   (upstream_wvalid),       // Templated
            .wdata_s                    (wdata_s[511:0]),
            .wstrb_s                    (wstrb_s[63:0]),
            .wlast_s                    (wlast_s),
            .wready_m                   (downstream_wready),     // Templated
            .bready_s                   (upstream_bready),       // Templated
            .bvalid_m                   (downstream_bvalid),     // Templated
            .bid_m                      (bid_m[IDW-1:0]),
            .bresp_m                    (bresp_m[1:0]),
            .reg_avg_enable             (reg_sync_avg_enable),   // Templated
            .reg_avg_mode               (reg_sync_avg_mode),     // Templated
            .reg_avg_time               (reg_avg_time[31:0]),    // Templated
            .reg_cnt_clear_en           (reg_cnt_clear_en_temp)); // Templated


/*read_process_unit auto_template "\(.*\)" (
.\(.*ready\|.*valid\)_s (upstream_\1),
.\(.*ready\|.*valid\)_m (downstream_\1),
.\(ar.*\)_m             (comb_\1[]),
.\(r.*\)_s              (comb_\1[]),
.reg_avg_time                               (reg_avg_time[]),
.reg_cnt_clear_en                           (reg_cnt_clear_en_temp),
.reg_\(avg_.*\|comb_tmo_cnt_num\)           (reg_sync_\1[]),
);*/          
read_process_unit #(
    .ADDRW       (ADDRW       ) ,
    .USERW       (USERW       ) ,
    .IDW         (IDW         ) ,
    .OT          (OT          ) ,
    .ENTRY_DEPTH (ENTRY_DEPTH ) ,
    .BOUNDARY    (BOUNDARY    ) )
 read_unit(/*autoinst*/
           // Outputs
           .arready_s                   (upstream_arready),      // Templated
           .arvalid_m                   (downstream_arvalid),    // Templated
           .arid_m                      (comb_arid[IDW-1:0]),    // Templated
           .araddr_m                    (comb_araddr[ADDRW-1:0]), // Templated
           .arlen_m                     (comb_arlen[3:0]),       // Templated
           .arsize_m                    (comb_arsize[2:0]),      // Templated
           .arburst_m                   (comb_arburst[1:0]),     // Templated
           .arprot_m                    (comb_arprot[2:0]),      // Templated
           .arcache_m                   (comb_arcache[3:0]),     // Templated
           .arqos_m                     (comb_arqos[3:0]),       // Templated
           .aruser_m                    (comb_aruser[USERW-1:0]), // Templated
           .arlock_m                    (comb_arlock),           // Templated
           .rvalid_s                    (upstream_rvalid),       // Templated
           .rid_s                       (comb_rid[IDW-1:0]),     // Templated
           .rdata_s                     (comb_rdata[511:0]),     // Templated
           .rresp_s                     (comb_rresp[1:0]),       // Templated
           .rlast_s                     (comb_rlast),            // Templated
           .rready_m                    (downstream_rready),     // Templated
           .reg_ar_trig_flush_comb_done_cnt(reg_ar_trig_flush_comb_done_cnt[31:0]),
           .reg_ar_trig_flush_tmo_cnt   (reg_ar_trig_flush_tmo_cnt[31:0]),
           .reg_ar_trig_flush_full_cnt  (reg_ar_trig_flush_full_cnt[31:0]),
           .reg_ar_trig_send_req_total_cnt(reg_ar_trig_send_req_total_cnt[31:0]),
           .reg_ar_normal_harzard_cnt   (reg_ar_normal_harzard_cnt[15:0]),
           .req_ar_tmo_avg_payload_len_cnt(req_ar_tmo_avg_payload_len_cnt[31:0]),
           .req_ar_tmo_avg_payload_cnt  (req_ar_tmo_avg_payload_cnt[31:0]),
           .req_ar_total_avg_payload_len_cnt(req_ar_total_avg_payload_len_cnt[31:0]),
           .req_ar_total_avg_payload_cnt(req_ar_total_avg_payload_cnt[31:0]),
           // Inputs
           .clk                         (clk),
           .rstn                        (rstn),
           .reg_comb_tmo_cnt_num        (reg_sync_comb_tmo_cnt_num[6:0]), // Templated
           .arvalid_s                   (upstream_arvalid),      // Templated
           .arid_s                      (arid_s[IDW-1:0]),
           .araddr_s                    (araddr_s[ADDRW-1:0]),
           .arlen_s                     (arlen_s[3:0]),
           .arsize_s                    (arsize_s[2:0]),
           .arburst_s                   (arburst_s[1:0]),
           .arprot_s                    (arprot_s[2:0]),
           .arcache_s                   (arcache_s[3:0]),
           .arqos_s                     (arqos_s[3:0]),
           .aruser_s                    (aruser_s[USERW-1:0]),
           .arlock_s                    (arlock_s),
           .arready_m                   (downstream_arready),    // Templated
           .rready_s                    (upstream_rready),       // Templated
           .rvalid_m                    (downstream_rvalid),     // Templated
           .rid_m                       (rid_m[IDW-1:0]),
           .rdata_m                     (rdata_m[511:0]),
           .rresp_m                     (rresp_m[1:0]),
           .rlast_m                     (rlast_m),
           .reg_cnt_clear_en            (reg_cnt_clear_en_temp), // Templated
           .reg_avg_mode                (reg_sync_avg_mode),     // Templated
           .reg_avg_enable              (reg_sync_avg_enable),   // Templated
           .reg_avg_time                (reg_avg_time[31:0]));   // Templated

endmodule
// Local Variables:
// verilog-library-directories:("-y ./ -y ../")
// verilog-auto-output-ignore-regexp:"\\(upstream_\\|downstream_\\|temp\\|sync\\)"
// verilog-auto-input-ignore-regexp:"\\(upstream_\\|downstream_\\|temp\\|sync\\)"
// verilog-auto-inst-param-value:t
// End:
