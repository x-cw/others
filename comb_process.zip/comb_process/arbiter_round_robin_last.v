// +FHDR----------------------------------------------------------------------------
// Project Name  : CodaCache
// Author        : chenm
// Email         : chenm@innosilicon.com.cn
// Create On     : 2024/07/16 10:58
// Last Modified : 2024/07/16 10:58
// File Name     : CC_prot_reg_set.v
// Description   :
// 
// Copyright (c) 2024 Innosilicon.
// ALL RIGHTS RESERVED
// 
// ---------------------------------------------------------------------------------
// Modification History:
// Date         By              Version                 Change Description
// ---------------------------------------------------------------------------------
// 2024/07/16   chenm           1.0                     Original
// 
// -FHDR----------------------------------------------------------------------------
module arbiter_round_robin_last #(REQ_NUM = 2) (
	input  clk,
	input  reset_n,
	input  [REQ_NUM-1:0] sink_valid,
	input  [REQ_NUM-1:0] sink_last,
	output [REQ_NUM-1:0] grant_valid);


reg  [REQ_NUM-1:0] held_request;
reg  [REQ_NUM-1:0] req_mask;
reg  [REQ_NUM-1:0] en;
wire [REQ_NUM-1:0] req;
wire [REQ_NUM-1:0] grant;	 // 
wire [REQ_NUM-1:0] last;         // last signal after mask grant
wire [REQ_NUM-1:0] req_vector;   // after mask request vector
wire [REQ_NUM-1:0] otherblock;   // has some one sibk is processing
wire 	  	   arb_complete; // arb operation is over
wire 	  	   orig_done;    // is last beat data

// req_vector is equal sink req mask by req_mask, if has one request is
// processing, other sink request will be mask
assign req_vector = sink_valid & ~req_mask;

//req is equal | held_request(is processing request)
assign req = req_vector | held_request;

//last is equal currently granted & currently process req_vector and sink
assign last = sink_last & grant & req;

//when any sink last is high means this arb is complete
assign arb_complete = |last;

//output to  grant_valid is currently granted & currently process req_vector
assign grant_valid = req & grant;

// in reset state, the en value defaule is the highest request index
// else if update once data processing is complete
always@(posedge clk or negedge reset_n)
	if(!reset_n)
		en <= {1'd1,{REQ_NUM-1{1'd0}}};
	else if(arb_complete)
		en <= grant;
	
arb_core_round_robin #(. REQ_NUM( REQ_NUM)) u_arb_comb (
	.req		(req),
	.park_point	(en),
	.grant		(grant)	
);

// in the initial state, the held request is all 0, means not any request is  processing	
// if has request is execute, the held_request will equal otherblock
// else if the request will be done in next beat, the next beat held_request
// will turn to idle, or keep value
always@(posedge clk or negedge reset_n)
	if(!reset_n)
		held_request <= {REQ_NUM{1'd0}};
	else 
		held_request <= |otherblock ? otherblock : (orig_done ? {REQ_NUM{1'd0}} : held_request);

// in reset status, the arb is idle, the arbiter can accept all request from  any sink
// if arb is processing request and not last beat data, this sink req will be
// not mask, will refuse others sink request to  enter req vector 
//
// if next beat the arb is idle, and the beat is last one data, so the next
// beat the req_mask will be idle, or keep orig value
always@(posedge clk or negedge reset_n)
	if(!reset_n)
		req_mask <= {REQ_NUM{1'd0}};
	else 
		req_mask <= |otherblock ? ~otherblock : (orig_done ? {REQ_NUM{1'd0}} : req_mask);


//means the arb is processing other sink data know, and not the sink last one request data
assign otherblock 	= req &  grant & ~last;

//means the arb processig sink data is over, and accept by the downstream. so
//the next beat can process other request
assign orig_done 	= |{req & grant & last};

endmodule
// Local Variables:
// verilog-library-directories:("./" ) 
// verilog-auto-inst-param-value:t
// End:
