// +FHDR----------------------------------------------------------------------------
// Copyright (c) 2025, Innosilicon, Inc. Confidential Proprietary
// PROJECT NAME  : xxx
// DEPARTMENT    : Digtal Frontend SOC
// AUTHOR        : chenm
// EMAIL         : chenm@innosilicon.com.cn
// CREATE ON     : 2025/12/04 19:26
// FILE NAME     : read_process_unit.v
// DESCRIPTION   :          
//         
// Copyright (c) 2025 Innosilicon.
// ALL RIGHTS RESERVED
// 
// ---------------------------------------------------------------------------------
// Modification History:
// Date         By              Version                 Change Description
// ---------------------------------------------------------------------------------
// 2025/12/04   chenm           1.0                     Original
// 
// -FHDR----------------------------------------------------------------------------
module read_process_unit
#(
    parameter ADDRW       = 52  ,
    parameter USERW       = 14  ,
    parameter IDW         = 10  ,
    parameter OT          = 512 ,
    parameter ENTRY_DEPTH = 8   ,
    parameter BOUNDARY    = 512
)(/*autoarg*/
   // Outputs
   arready_s, arvalid_m, arid_m, araddr_m, arlen_m, arsize_m,
   arburst_m, arprot_m, arcache_m, arqos_m, aruser_m, arlock_m,
   rvalid_s, rid_s, rdata_s, rresp_s, rlast_s, rready_m,
   reg_ar_trig_flush_comb_done_cnt, reg_ar_trig_flush_tmo_cnt,
   reg_ar_trig_flush_full_cnt, reg_ar_trig_send_req_total_cnt,
   reg_ar_normal_harzard_cnt, req_ar_tmo_avg_payload_len_cnt,
   req_ar_tmo_avg_payload_cnt, req_ar_total_avg_payload_len_cnt,
   req_ar_total_avg_payload_cnt,
   // Inputs
   clk, rstn, reg_comb_tmo_cnt_num, arvalid_s, arid_s, araddr_s,
   arlen_s, arsize_s, arburst_s, arprot_s, arcache_s, arqos_s,
   aruser_s, arlock_s, arready_m, rready_s, rvalid_m, rid_m, rdata_m,
   rresp_m, rlast_m, reg_cnt_clear_en, reg_avg_mode, reg_avg_enable,
   reg_avg_time
   );
input  wire             clk       ;
input  wire             rstn      ;
input [6:0] reg_comb_tmo_cnt_num  ; 
//axi upstream archannel interface
input  wire             arvalid_s ;
output wire             arready_s ;
input  wire [IDW-1:0]   arid_s    ;
input  wire [ADDRW-1:0] araddr_s  ;
input  wire [3:0]       arlen_s   ;
input  wire [2:0]       arsize_s  ;
input  wire [1:0]       arburst_s ;
input  wire [2:0]       arprot_s  ;
input  wire [3:0]       arcache_s ;
input  wire [3:0]       arqos_s   ;
input  wire [USERW-1:0] aruser_s  ;
input  wire             arlock_s  ;

//axi downstream archannel interface
input  wire             arready_m ;
output wire             arvalid_m ;
output      [IDW-1:0]   arid_m    ;
output wire [ADDRW-1:0] araddr_m  ;
output wire [3:0]       arlen_m   ;
output wire [2:0]       arsize_m  ;
output wire [1:0]       arburst_m ;
output wire [2:0]       arprot_m  ;
output wire [3:0]       arcache_m ;
output wire [3:0]       arqos_m   ;
output wire [USERW-1:0] aruser_m  ;
output wire             arlock_m  ;

//axi upstream rchannel interface
output wire             rvalid_s  ;
output wire [IDW-1:0]   rid_s     ;
output wire [511:0]     rdata_s   ;
output wire [1:0]       rresp_s   ;
output wire             rlast_s   ;
input  wire             rready_s  ;

//axi downstream rchannel interface
input  wire             rvalid_m  ;
input  wire [IDW-1:0]   rid_m     ;
input  wire [511:0]     rdata_m   ;
input  wire [1:0]       rresp_m   ;
input  wire             rlast_m   ;
output wire             rready_m  ;

output reg [ 31:0 ] reg_ar_trig_flush_comb_done_cnt ;
output reg [ 31:0 ] reg_ar_trig_flush_tmo_cnt       ;
output reg [ 31:0 ] reg_ar_trig_flush_full_cnt      ;
output reg [ 31:0 ] reg_ar_trig_send_req_total_cnt  ;
output reg [ 15:0 ] reg_ar_normal_harzard_cnt       ;
//output     [ 3:0  ] reg_ar_send_avg_beat_total_cnt  ;
//output     [ 3:0  ] reg_ar_send_avg_beat_tmo_cnt    ;

output [31:0] req_ar_tmo_avg_payload_len_cnt  ;
output [31:0] req_ar_tmo_avg_payload_cnt      ;
output [31:0] req_ar_total_avg_payload_len_cnt  ;
output [31:0] req_ar_total_avg_payload_cnt      ;

input               reg_cnt_clear_en                ;
input               reg_avg_mode                    ;
input               reg_avg_enable                  ;
input      [ 31:0 ] reg_avg_time                    ;

localparam  REQ_WIDTH          = BOUNDARY / 64           ;
localparam  ENTRY_ADDRW        = $clog2(ENTRY_DEPTH)     ;
localparam  REQ_DEPTH          = $clog2(REQ_WIDTH)       ;
localparam  ENTRY_BOUNDARY     = $clog2(BOUNDARY)        ;
localparam  OT_WIDTH           = OT / 32                 ;

reg [ENTRY_DEPTH-1     : 0 ] entry_valid                       ;
reg [ENTRY_DEPTH-1     : 0 ] entry_record                      ;
reg [ENTRY_DEPTH-1     : 0 ] entry_narrow                      ;
reg [ENTRY_DEPTH-1     : 0 ] entry_comb_cache                  ;
reg [ADDRW-1           : 2 ] entry_base_addr [ENTRY_DEPTH-1:0] ;
reg [REQ_WIDTH-1       : 0 ] entry_comb_mask [ENTRY_DEPTH-1:0] ;
reg [USERW-1           : 0 ] entry_comb_user [ENTRY_DEPTH-1:0] ;
reg [IDW-1             : 0 ] entry_comb_id   [ENTRY_DEPTH-1:0] ;
reg [3                 : 0 ] entry_comb_qos  [ENTRY_DEPTH-1:0] ;
reg [6                 : 0 ] entry_comb_cnt  [ENTRY_DEPTH-1:0] ;
reg [(REQ_WIDTH*IDW)-1 : 0 ] entry_origin_id [ENTRY_DEPTH-1:0] ;
reg [OT-1              : 0 ] origin_valid                      ;
reg [OT-1              : 0 ] origin_len                        ;
reg [OT-1              : 0 ] origin_has_back_rdata             ;
reg [IDW-1             : 0 ] origin_id_map           [OT-1 :0] ;
reg [2                 : 0 ] origin_addr             [OT-1 :0] ;
reg [OT-1              : 0 ] comb_valid                        ;
reg [REQ_WIDTH-1       : 0 ] comb_req_mask           [OT-1 :0] ;
reg [2                 : 0 ] comb_curr_back_cnt      [OT-1 :0] ;

reg                 reg_rvalid  ;
reg [IDW-1   : 0]   reg_rid     ;
reg [511     : 0]   reg_rdata   ;
reg [1       : 0]   reg_rresp   ;

wire [REQ_WIDTH-1   : 0] current_cnt_onehot       ;
wire [REQ_WIDTH-1   : 0] current_resp_mask        ;
wire [REQ_WIDTH-1   : 0] current_req_mask         ;
wire [REQ_WIDTH-1   : 0] flush_req_mask           ;
wire [REQ_WIDTH-1   : 0] flush_req_mask_rev       ;
wire [REQ_WIDTH-1   : 0] flush_req_mask_start     ;
wire [REQ_WIDTH-1   : 0] flush_req_mask_end       ;
wire [REQ_WIDTH-1   : 0] flush_req_mask_end_rev   ;
reg  [REQ_DEPTH-1   : 0] flush_req_mask_start_bin ;
reg  [REQ_DEPTH-1   : 0] flush_req_mask_end_bin   ;
wire [ENTRY_DEPTH-1 : 0] valid_entry_post         ;
wire [ENTRY_DEPTH-1 : 0] new_alloc_entry          ;
wire [ENTRY_DEPTH-1 : 0] flush_entry              ;
wire [ENTRY_DEPTH-1 : 0] ar_entry_index           ;
//wire [ENTRY_DEPTH-1 : 0] same_addr_window_index   ;
wire [ENTRY_DEPTH-1 : 0] narrow_harzard_window    ;
wire [ENTRY_DEPTH-1 : 0] normal_harzard_window    ;
wire [ENTRY_DEPTH-1 : 0] status_change_window     ;
wire [ENTRY_DEPTH-1 : 0] harzard_window           ;
wire [ENTRY_DEPTH-1 : 0] narrow_entry             ;
reg  [ENTRY_ADDRW-1 : 0] ar_entry_index_bin       ;
reg  [ENTRY_ADDRW-1 : 0] harzard_window_bin       ;
reg  [ENTRY_ADDRW-1 : 0] status_change_window_bin ;
reg  [ENTRY_ADDRW-1 : 0] narrow_entry_bin         ;
reg  [ENTRY_ADDRW-1 : 0] new_alloc_entry_bin      ;
reg  [ENTRY_ADDRW-1 : 0] cnt_time_out             ;
reg  [ENTRY_ADDRW-1 : 0] comb_done_reg            ;
reg  [ENTRY_ADDRW-1 : 0] entry_full_has_new_req   ;

reg  [ENTRY_ADDRW-1:0] flush_order_push_data    ; // To   repack_sync_fifo.v
wire                   flush_order_push_valid   ; // To   repack_sync_fifo.v
wire                   flush_order_push_ready   ; // From repack_sync_fifo.v
wire [ENTRY_ADDRW-1:0] flush_order_pop_data     ; // From repack_sync_fifo.v
wire                   flush_order_pop_valid    ; // From repack_sync_fifo.v
wire                   flush_order_pop_ready    ; // To   repack_sync_fifo.v

wire [  2:0]    araddr_8_6_bit0           ;
wire [  7:0]    araddr_8_6_bit0_onehot    ;
reg  [  6:0]    max_value                 ;
reg             comb_done_reg_flag        ;
reg             time_out_flag             ;
//wire            time_out_flag        ;
wire             ar_has_entry             ;
wire            narrow_flag               ;
wire            receive_new_ar            ;
wire            send_ar_success           ;
wire            send_non_narrow           ;
wire            need_alloc_window         ;
wire            flush_enable              ;
wire            has_harzard               ;
//wire            block_from_harzard_narrow ;
wire            block_from_no_window      ;
wire            send_rlast_over           ;
wire            send_resp_success         ;
wire            receive_non_narrow        ;
wire            rresp_comb_valid          ;
wire            receive_rlast             ;
wire            receive_rresp             ;
wire            receive_comb_done         ;
wire            comb_done_flag            ;
wire            entry_full_need_evict     ;
reg  [$clog2(OT_WIDTH)-1 :0] group_index;
wire             flush_except_evict        ;
wire             has_entry_rid_origin      ;
reg  [IDW-2 : 0] origin_id                 ;
wire [OT-1  : 0] origin_id_entry           ;
reg  [4     : 0] inner_index               ;
reg  [21    : 0] avg_window_time           ;
reg  [21    : 0] tmo_window_time           ;
reg  [25    : 0] total_beat_cnt            ;
reg  [25    : 0] tmo_beat_cnt              ;
reg  [21    : 0] tmo_req_cnt               ;
reg  [21    : 0] total_req_cnt             ;
reg  [1     : 0] reg_avg_enable_reg        ;
wire [25    : 0] tmo_beat_cnt_next         ;
wire [21    : 0] tmo_req_cnt_next          ;
wire [21    : 0] total_req_cnt_next        ;
wire [25    : 0] total_beat_cnt_next       ;
reg              has_entry_rid_origin_reg  ;
reg              all_pkt_window_cnt_enable ;
reg              tmo_pkt_window_cnt_enable ;
wire             avg_enable_posedge        ;
wire             all_pkt_window_full       ;
wire             tmo_pkt_window_full       ;
//wire             has_narrow_block          ;
wire             tmo_cnt_enable            ;
wire             all_cnt_enable            ;
reg  [(REQ_WIDTH*IDW)-1:0] origin_id_mask  ;
wire [(REQ_WIDTH*IDW)-1:0] flush_origin_id ;
integer j,l,m,n;
//------------------------------------------------------------------------//
//                           WINDOW ALLOC CONTROL                         //
//------------------------------------------------------------------------//
assign receive_new_ar = arready_s & arvalid_s;

reg status_bit;
wire status_bit_next;
wire status_change;
always@(posedge clk or negedge rstn)
if(~rstn)
    status_bit <= 1'd0;
else if(receive_new_ar)
    status_bit <= status_bit_next;

assign status_bit_next = |aruser_s[13:10];

// the status valid only in has entry is valid
assign status_change = (status_bit_next ^ status_bit) & (|entry_valid) & arvalid_s;

assign status_change_window = entry_valid & (~entry_record);

// we need update the entry valid flag, in initial state the valid is all be keep zero
// when has receiving a new req, we need alloc a new entry and update the valid flag
// when the entry will be flush, the valid flag will turn back to zero
always@(posedge clk or negedge rstn)
    if(!rstn)
        entry_valid <= {ENTRY_DEPTH{1'd0}};
    else if(need_alloc_window)
        entry_valid <= flush_enable ? (valid_entry_post | new_alloc_entry ) : (entry_valid | new_alloc_entry);
    else if(flush_enable)
        entry_valid <= valid_entry_post;

// the flush enable can be assert after the last window flush done or flush_window flush from idle
assign flush_enable = send_ar_success ;
assign flush_entry  = {{ENTRY_DEPTH-1{1'd0}}, 1'd1} << flush_order_pop_data; 

// if has flush event, the valid_entry ture state will mask the flush entry
assign valid_entry_post = flush_enable ? entry_valid & (~flush_entry) : entry_valid;

// to find the lowest index high as new alloc entry
assign new_alloc_entry = (~valid_entry_post) & (~((~valid_entry_post) - 1'd1));

// when has received a new ar req, we should check its need create a new entry?
// if has not find entry, means that is a new entry, else will check has harzard? if has has_harzard we also need create a new entry 
// ----> has_harzard will block the new req receive, untill the harzard entry is record, so only consider the new req but not has entry
//assign need_alloc_window = receive_new_ar ? (ar_has_entry ? has_harzard : 1'd1 ) : 1'd0;  // equal need_alloc_new_window
assign need_alloc_window = receive_new_ar & (~ar_has_entry);  // equal need_alloc_new_window

genvar find_entry;
generate
    for(find_entry=0; find_entry<ENTRY_DEPTH; find_entry=find_entry+1)begin:find_ar_entry
        assign ar_entry_index[find_entry] = (araddr_s[ADDRW-1:ENTRY_BOUNDARY] == entry_base_addr[find_entry][ADDRW-1:ENTRY_BOUNDARY]) & entry_valid[find_entry] & (aruser_s[13:10] == entry_comb_user[find_entry][13:10]) & (~entry_record[find_entry]) & (entry_comb_cnt[find_entry] != reg_comb_tmo_cnt_num); // 
        assign narrow_harzard_window[find_entry] = (araddr_s[ADDRW-1:2] == entry_base_addr[find_entry][ADDRW-1:2]) & entry_valid[find_entry] & (~entry_record[find_entry]) & (aruser_s[13:10] == entry_comb_user[find_entry][13:10]) & entry_narrow[find_entry];
        assign normal_harzard_window[find_entry] = (|(current_req_mask & entry_comb_mask[find_entry])) & ar_entry_index[find_entry];
    end
endgenerate

// all narrow entry will alloc new entry
assign ar_has_entry = (|ar_entry_index) & arvalid_s & receive_non_narrow;

assign harzard_window = receive_non_narrow ? normal_harzard_window : narrow_harzard_window; 
//------------------------------------------------------------------------//
//                         NORMAL HARZARD CONTROL                         //
//------------------------------------------------------------------------//
assign araddr_8_6_bit0 = araddr_s[8:6];

wire [ 1:0] araddr_8_6_bit0_onehot_level0  = {araddr_8_6_bit0[0], ~araddr_8_6_bit0[0]};
wire [ 3:0] araddr_8_6_bit0_onehot_level1  = {araddr_8_6_bit0_onehot_level0 & { 2{araddr_8_6_bit0[1]}}, araddr_8_6_bit0_onehot_level0 & ~{ 2{araddr_8_6_bit0[1]}}};
wire [ 7:0] araddr_8_6_bit0_onehot_level2  = {araddr_8_6_bit0_onehot_level1 & { 4{araddr_8_6_bit0[2]}}, araddr_8_6_bit0_onehot_level1 & ~{ 4{araddr_8_6_bit0[2]}}};
assign      araddr_8_6_bit0_onehot         = araddr_8_6_bit0_onehot_level2;

assign current_req_mask = ~|arlen_s ? araddr_8_6_bit0_onehot[REQ_WIDTH-1:0] : (araddr_8_6_bit0_onehot[REQ_WIDTH-1:0] | (araddr_8_6_bit0_onehot[REQ_WIDTH-1:0] << 1));

// the addr harzard is when the len is zer0, the will check the addr[8:6] has valid addr? else will check the addr[8:6] and the next beat has valid addr?
assign has_harzard = (|harzard_window) & arvalid_s;

//------------AWREADY&WREADY BLOCK--------------------------//
//assign block_from_harzard_narrow   = has_harzard | has_narrow_block ;
assign block_from_no_window = arvalid_s & (~ar_has_entry) & (&valid_entry_post); 

assign arready_s = ~(has_harzard | block_from_no_window | status_change) ;

//------------------------------------------------------------------------//
//                      WINDOW INFO UPDATE CONTROL                        //
//------------------------------------------------------------------------//
//--------------BASE_ADDR & USER ID------------------------//
// the base_addr, comb_id and user only update in need_alloc_window is high
always@(posedge clk or negedge rstn)
if(~rstn)begin
    for(j=0; j<ENTRY_DEPTH; j=j+1)begin
        entry_base_addr [j              ] <= {ADDRW-2 {1'd0}};
        entry_comb_user [j              ] <= {USERW   {1'd0}};
//        entry_comb_id   [j              ] <= {IDW     {1'd0}};
    end
end else if(need_alloc_window)begin
    entry_base_addr [new_alloc_entry_bin] <= araddr_s[ADDRW-1 : 2];
    entry_comb_user [new_alloc_entry_bin] <= aruser_s[USERW-1 : 0];
//    entry_comb_id   [new_alloc_entry_bin] <= arid_s  [IDW-1   : 0];
end

// when alloc a new window, if it is a narrow trans, we will make it window assert, else will clear it
always@(posedge clk or negedge rstn)
if(~rstn)
    entry_narrow <= {ENTRY_DEPTH{1'd0}};
else if(need_alloc_window)
    entry_narrow <=  receive_non_narrow ? entry_narrow & (~new_alloc_entry) : entry_narrow | new_alloc_entry;

//-------------------QOS & CACHE------------------------//
// the all comb_sun_req qos max value will as the final comb_qos value
// and the cache value: once comb_sub_req has cache[1] is high, the comb_cache[1] is high
always@(posedge clk or negedge rstn)
if(~rstn)begin
    for(j=0; j<ENTRY_DEPTH; j=j+1)begin
        entry_comb_qos   [j] <= {4{1'd0}};
        entry_comb_cache [j] <= {1{1'd0}};
        entry_comb_id    [j] <= {IDW{1'd0}};
    end
end else if(need_alloc_window)begin
    entry_comb_qos   [ new_alloc_entry_bin ] <= arqos_s      ;
    entry_comb_cache [ new_alloc_entry_bin ] <= arcache_s[0] ;
    entry_comb_id    [ new_alloc_entry_bin ] <= arid_s       ;
end else if(receive_new_ar)begin
    entry_comb_cache [ ar_entry_index_bin  ] <= arcache_s[0] | entry_comb_cache[ar_entry_index_bin]                                           ;
    entry_comb_qos   [ ar_entry_index_bin  ] <= (arqos_s          > entry_comb_qos [ar_entry_index_bin]) ? arqos_s : entry_comb_qos[ar_entry_index_bin] ;
    entry_comb_id    [ ar_entry_index_bin  ] <= (current_req_mask > entry_comb_mask[ar_entry_index_bin]) ? arid_s  : entry_comb_id [ar_entry_index_bin] ;
end
// the current_req_mask every bit will repeat IDW time and meger again as origin_id update mask
//-------------------ORIGIN ID MAP------------------------//
genvar req_i;
generate 
    for(req_i=0; req_i<REQ_WIDTH; req_i=req_i+1)begin:gen_origin_req_mask
        assign origin_id_mask[IDW*req_i+:IDW] = {IDW{current_req_mask[req_i]}};
    end
endgenerate
// when is a new window alloc, will reset the id_info_array, the origin id and mask by origin_id_mask
// when has match a window, will update the info also mask by origin_id_mask
always@(posedge clk or negedge rstn)
    if(~rstn)begin
        for(j=0; j<ENTRY_DEPTH; j=j+1)
            entry_origin_id[j] <= {REQ_WIDTH*IDW{1'd0}}; 
    end else if(need_alloc_window)  
        entry_origin_id [ new_alloc_entry_bin ] <= origin_id_mask & {REQ_WIDTH{arid_s[IDW-1:0]}};
    else if(receive_new_ar)
        entry_origin_id [ ar_entry_index_bin  ] <= origin_id_mask & {REQ_WIDTH{arid_s[IDW-1:0]}} | entry_origin_id[ar_entry_index_bin];
//-------------------IDLE TIME CNT------------------------//
// the cnt, the cnt when receive a new req will become cnt from 1
// if the cnt is time out, we will keep the value to flush the netry
genvar tmo_iter;
generate
    for(tmo_iter=0; tmo_iter<ENTRY_DEPTH; tmo_iter=tmo_iter+1)begin:gen_tmo_cnt
        always@(posedge clk or negedge rstn)
        if(~rstn)
            entry_comb_cnt[tmo_iter] <= 7'd0;
        else if(need_alloc_window & (tmo_iter == new_alloc_entry_bin))
            entry_comb_cnt[tmo_iter] <= 7'd1;
        else if(receive_new_ar & ar_has_entry & (tmo_iter == ar_entry_index_bin))
            entry_comb_cnt[tmo_iter] <= 7'd1;
        else if(entry_comb_cnt[tmo_iter] == reg_comb_tmo_cnt_num)
            entry_comb_cnt[tmo_iter] <= entry_comb_cnt[tmo_iter];
        else if((|entry_comb_cnt[tmo_iter]) & entry_valid[tmo_iter] & (~entry_record[tmo_iter]) & (~entry_narrow[tmo_iter]))
            entry_comb_cnt[tmo_iter] <= entry_comb_cnt[tmo_iter] + 1'd1;
    end
endgenerate

//-------------------REQ MASK UPDATE------------------------//
// the comb mask is menas whick sub_req has receive
// when is first req we will assert as araddr[8:6]_one_hot or plus 1, else will merge the araddr[8:6]
always@(posedge clk or negedge rstn)
if(~rstn)begin
    for(j=0; j<ENTRY_DEPTH; j=j+1)begin
        entry_comb_mask[j] <= {REQ_WIDTH{1'd0}}; 
    end
end else begin  
    if(need_alloc_window)
        entry_comb_mask[new_alloc_entry_bin] <= current_req_mask;
    else if(receive_new_ar)
        entry_comb_mask[ar_entry_index_bin ] <= current_req_mask | entry_comb_mask[ar_entry_index_bin];
end
//------------------------------------------------------------------------//
//                          FLUSH LOGIC CONTROL                           //
//------------------------------------------------------------------------//
//-------------RECORD_FLAG----------------//
// when has alloc a new req will deassert its record 
// when the window was push into the order fifo, the reord will be assert
// at the same time the new_alloc_entry_bin and flush_order_push_data cannot equal
always@(posedge clk or negedge rstn)
    if(!rstn)
        entry_record <= {ENTRY_DEPTH{1'd0}};
    else begin
        if(need_alloc_window)
            entry_record[new_alloc_entry_bin  ] <= 1'd0;

        if(flush_order_push_ready & flush_order_push_valid)
            entry_record[flush_order_push_data] <= 1'd1;
    end 

//-----------------------TMO----------------------//
// if the entry is valid and the time cnt is upper max, the entry will be flush
always@(*)begin
    cnt_time_out            = {ENTRY_ADDRW{1'd0}};
    time_out_flag           = 1'd0;
    for(l=0; l<ENTRY_DEPTH; l=l+1)begin
        if((entry_comb_cnt[l] == reg_comb_tmo_cnt_num) & entry_valid[l] & ~entry_record[l])begin
            cnt_time_out                = l;
            time_out_flag               = 1'd1;
        end
    end
end
//wire tmo_deassert_flag;

// when receive a new req and happen tmo with same time, we will clear the tmo cnt
// ~has_harzard & ar_has_entry means that this req is non-narrow and can be receive successful
//assign tmo_deassert_flag = (ar_entry_index_bin == cnt_time_out) & ar_has_entry & (~has_harzard);

//assign time_out_flag_true = time_out_flag & (~tmo_deassert_flag);

//-----------------------COMB DONE-----------------//
// when receive a new ar, has hit window and not first, and req_mask will all high, means comb over
assign receive_comb_done = receive_new_ar & ar_has_entry & (&(current_req_mask | entry_comb_mask[ar_entry_index_bin]));
assign comb_done_flag = receive_comb_done | comb_done_reg_flag;
always@(*)begin
    comb_done_reg        = {ENTRY_ADDRW{1'd0}};
    comb_done_reg_flag   = 1'd0;
    for(m=0; m<ENTRY_DEPTH; m=m+1)begin
        if((&entry_comb_mask[m]) & entry_valid[m] & ~entry_record[m])begin
            comb_done_reg        = m;
            comb_done_reg_flag   = 1'd1;
        end
    end
end

//-----------------------NARROW----------------------//
//assign harzard_flag = has_harzard | harzard_keep_flag;
//assign has_narrow_block = arvalid_s & (~receive_non_narrow) & time_out_flag_true; 

assign  narrow_entry = entry_valid & entry_narrow & (~entry_record);
assign  narrow_flag = |narrow_entry;
//-----------------------EVICT_MUST_DILE_FIFO----------------------//
//when receive a new cmd but not hit any entry(so no harzard), no any window in comb_done or tmo state ,but all entry is valid
//and order fifo has not any window wait to flush 
//so we need to evict the must IDLE entry to accept new req
assign entry_full_need_evict = arvalid_s & (~ar_has_entry) & (&entry_valid) & (~flush_order_pop_valid) & (~flush_except_evict);

always@(*)begin
    entry_full_has_new_req  = {ENTRY_ADDRW{1'd0}};
    max_value               = entry_comb_cnt[0];
    if(entry_full_need_evict)begin
        for(n=1; n<ENTRY_DEPTH; n=n+1)begin
            if((entry_comb_cnt[n] > max_value) & entry_valid[n])begin
                max_value               = entry_comb_cnt[n];
                entry_full_has_new_req  = n;
            end
        end
    end
end
//-----------------------ORDER FIFO----------------------//
// when open harzard, or comb_done and tmo will push its window index to order_fifo
assign flush_except_evict     = has_harzard | comb_done_flag | time_out_flag | narrow_flag | (status_change & (|status_change_window));
assign flush_order_push_valid = flush_except_evict | entry_full_need_evict;

// flush_order pre-process, according to the priority.
// harzard and comb_done_flag cannot happen at same cycle
assign flush_order_pop_ready  = send_ar_success;

always@(*)begin
    flush_order_push_data = {ENTRY_ADDRW{1'd0}};
    if(status_change)
        flush_order_push_data = status_change_window_bin;
    else if(time_out_flag)
        flush_order_push_data = cnt_time_out;
    else if(has_harzard)
        flush_order_push_data = harzard_window_bin;
    else if(comb_done_flag)
        flush_order_push_data = comb_done_reg_flag ? comb_done_reg : ar_entry_index_bin;
    else if(narrow_flag)
        flush_order_push_data = narrow_entry_bin;
    else if(entry_full_need_evict)
        flush_order_push_data = entry_full_has_new_req;
end

integer bin_i;
always@(*)begin
    narrow_entry_bin         = {ENTRY_ADDRW{1'd0}};
    harzard_window_bin       = {ENTRY_ADDRW{1'd0}};
    ar_entry_index_bin       = {ENTRY_ADDRW{1'd0}};
    new_alloc_entry_bin      = {ENTRY_ADDRW{1'd0}};
    status_change_window_bin = {ENTRY_ADDRW{1'd0}};

    for(bin_i=ENTRY_DEPTH-1; bin_i>=0; bin_i=bin_i-1)begin
        if(status_change_window[bin_i])begin
            status_change_window_bin = bin_i;
        end
    end
    for(bin_i=0; bin_i<ENTRY_DEPTH; bin_i=bin_i+1)begin
        if(narrow_entry[bin_i])begin
            narrow_entry_bin = bin_i;
        end

        if(harzard_window[bin_i])begin
            harzard_window_bin = bin_i;
        end

        if(ar_entry_index[bin_i])begin
            ar_entry_index_bin = bin_i;
        end

        if(new_alloc_entry[bin_i])begin
            new_alloc_entry_bin = bin_i;
        end
    end
end
/*repack_sync_fifo auto_template "\(.*\)_fifo" (
.clk                        (clk),
.reset_n                    (rstn),
.second_data               (),
.almost_empty              (),
.\(.*\)                     (@_\1[]),
);*/

repack_sync_fifo #(
    .FIFO_WIDTH(ENTRY_ADDRW), 
    .FIFO_DEPTH(ENTRY_DEPTH), 
    .ADDR_WIDTH(ENTRY_ADDRW)
)flush_order_fifo(/*autoinst*/
                  // Outputs
                  .push_ready           (flush_order_push_ready), // Templated
                  .pop_data             (flush_order_pop_data[ENTRY_ADDRW-1:0]), // Templated
                  .second_data          (),                      // Templated
                  .almost_empty         (),                      // Templated
                  .pop_valid            (flush_order_pop_valid), // Templated
                  // Inputs
                  .clk                  (clk),                   // Templated
                  .reset_n              (rstn),                  // Templated
                  .push_data            (flush_order_push_data[ENTRY_ADDRW-1:0]), // Templated
                  .push_valid           (flush_order_push_valid), // Templated
                  .pop_ready            (flush_order_pop_ready)); // Templated

//assign flush_window_exit_idle = flush_order_push_valid & ~flush_order_pop_valid;
//------------------------------------------------------------------------//
//                           AR CHANNEL CONTROL                           //
//------------------------------------------------------------------------//
assign send_ar_success = arvalid_m & arready_m;

assign flush_req_mask         = entry_comb_mask[flush_order_pop_data]              ;
assign flush_req_mask_start   = flush_req_mask      & ~(flush_req_mask     - 1'd1) ;
assign flush_req_mask_end_rev = flush_req_mask_rev  & ~(flush_req_mask_rev - 1'd1) ;
assign flush_req_mask_rev     = {<<{flush_req_mask}}                               ;
assign flush_req_mask_end     = {<<{flush_req_mask_end_rev}}                       ;

integer mask_i;
always@(*)begin
    flush_req_mask_start_bin = {REQ_DEPTH{1'd0}};
    flush_req_mask_end_bin   = {REQ_DEPTH{1'd0}};
    for(mask_i=0; mask_i<REQ_WIDTH; mask_i=mask_i+1)begin
        if(flush_req_mask_start[mask_i])
            flush_req_mask_start_bin = mask_i;

        if(flush_req_mask_end[mask_i])
            flush_req_mask_end_bin = mask_i;
    end
end

//-----------tie value sideband signal-----------//
assign       arlock_m   = 1'd0;
assign       arprot_m   = 3'd0;
assign       arburst_m  = 2'd1;

assign       araddr_m   = entry_narrow[flush_order_pop_data] ? {entry_base_addr[flush_order_pop_data], 2'd0} : {entry_base_addr[flush_order_pop_data][ADDRW-1:ENTRY_BOUNDARY], flush_req_mask_start_bin ,6'd0};
assign       arlen_m    = entry_narrow[flush_order_pop_data] ? 4'd0                                          : {1'd0, flush_req_mask_end_bin - flush_req_mask_start_bin} ;
assign       arsize_m   = entry_narrow[flush_order_pop_data] ? 3'd2                                          : 3'd6                                                      ;

assign       arcache_m  = {3'd0, entry_comb_cache[flush_order_pop_data]} ;
assign       arid_m     = entry_comb_id   [ flush_order_pop_data ]             ;
assign       arqos_m    = entry_comb_qos  [ flush_order_pop_data ]             ;
assign       aruser_m   = entry_comb_user [ flush_order_pop_data ]             ;
assign       arvalid_m  = flush_order_pop_valid                                ;
//------------------------------------------------------------------------//
//                         ID MAP INFO                                    //
//------------------------------------------------------------------------//

assign receive_non_narrow = (arsize_s == 3'd6)          ;
assign send_rlast_over    = send_resp_success & rlast_s ;
assign send_resp_success  = rvalid_s & rready_s         ;

always@(posedge clk or negedge rstn)
if(~rstn)
    origin_valid <= {OT{1'd0}};
else begin
    if(send_ar_success)begin // if received a new aw req, will turn valid it
    //    origin_valid[arid_s[8:0]] <= 1'd1;
        if(flush_req_mask[7])
            origin_valid[flush_origin_id[IDW*7+:IDW-1]] <= 1'd1;
        if(flush_req_mask[6])
            origin_valid[flush_origin_id[IDW*6+:IDW-1]] <= 1'd1;
        if(flush_req_mask[5])
            origin_valid[flush_origin_id[IDW*5+:IDW-1]] <= 1'd1;
        if(flush_req_mask[4])
            origin_valid[flush_origin_id[IDW*4+:IDW-1]] <= 1'd1;
        if(flush_req_mask[3])
            origin_valid[flush_origin_id[IDW*3+:IDW-1]] <= 1'd1;
        if(flush_req_mask[2])
            origin_valid[flush_origin_id[IDW*2+:IDW-1]] <= 1'd1;
        if(flush_req_mask[1])
            origin_valid[flush_origin_id[IDW*1+:IDW-1]] <= 1'd1;
        if(flush_req_mask[0])
            origin_valid[flush_origin_id[IDW*0+:IDW-1]] <= 1'd1;        
    end
    if(send_rlast_over & ~rid_s[9]) // if has return rresp to upstream, will deassert it
        origin_valid[rid_s[8:0]] <= 1'd0;
end

// if has receive a first comb req, we will update the awid_s to the awreq
// if receive a new read req but not need alloc window, means has match window, we weed store comb_id to its id_info_array
assign flush_origin_id  = entry_origin_id [flush_order_pop_data] ;
always@(posedge clk or negedge rstn)
if(~rstn)begin
    origin_id_map <= '{OT{ {IDW{1'd0}} }};
end else if(send_ar_success)begin//todo
    if(flush_req_mask[7])
        origin_id_map[flush_origin_id[IDW*7+:IDW-1]] <= arid_m;
    if(flush_req_mask[6])
        origin_id_map[flush_origin_id[IDW*6+:IDW-1]] <= arid_m;
    if(flush_req_mask[5])
        origin_id_map[flush_origin_id[IDW*5+:IDW-1]] <= arid_m;
    if(flush_req_mask[4])
        origin_id_map[flush_origin_id[IDW*4+:IDW-1]] <= arid_m;
    if(flush_req_mask[3])
        origin_id_map[flush_origin_id[IDW*3+:IDW-1]] <= arid_m;
    if(flush_req_mask[2])
        origin_id_map[flush_origin_id[IDW*2+:IDW-1]] <= arid_m;
    if(flush_req_mask[1])
        origin_id_map[flush_origin_id[IDW*1+:IDW-1]] <= arid_m;
    if(flush_req_mask[0])
        origin_id_map[flush_origin_id[IDW*0+:IDW-1]] <= arid_m;
end
//end else if(receive_new_ar & receive_non_narrow)begin
//    if(need_alloc_window)
//        origin_id_map[arid_s[8:0]] <= arid_s                            ;
//    else
//        origin_id_map[arid_s[8:0]] <= entry_comb_id[ar_entry_index_bin] ;
//end

// when receive a new read req, we will store its addr[8:6] and len into origin_info_array
always@(posedge clk or negedge rstn)
if(~rstn)begin
    origin_addr <= '{OT{ {3{1'd0}} }}; 
    origin_len  <= '{OT{ {1{1'd0}} }}; 
end else if(receive_new_ar & receive_non_narrow) begin
    origin_addr[arid_s[8:0]] <= araddr_s[8:6] ;
    origin_len [arid_s[8:0]] <= |arlen_s      ;
end

always@(posedge clk or negedge rstn)
if(~rstn)
    has_entry_rid_origin_reg <= 1'd0;
else if(receive_rresp)
    has_entry_rid_origin_reg <= has_entry_rid_origin;

always@(posedge clk or negedge rstn)
if(~rstn)
    origin_has_back_rdata <= {OT{1'd0}};
else begin
    if(receive_new_ar & receive_non_narrow) // if received a new aw req, will ensure deassert it
        origin_has_back_rdata[arid_s[8:0]] <= 1'd0;

    if(has_entry_rid_origin_reg & send_resp_success) // if has return rresp to upstream, will deassert it
        origin_has_back_rdata[rid_s[8:0]] <= 1'd1;
end

assign receive_rlast = rlast_m  & receive_rresp ;
assign receive_rresp = rvalid_m & rready_m      ;

// when send a comb req to slave, we will assert it to valid
// else if return r non-atomic rlast, we will ensure it deassert
always@(posedge clk or negedge rstn)
if(~rstn)
    comb_valid <= {OT{1'd0}};
else begin
    if(send_ar_success & send_non_narrow)
        comb_valid[arid_m[8:0]] <= 1'd1;

    if(receive_rlast & ~rid_m[9])
        comb_valid[rid_m[8:0]] <= 1'd0;
end

assign send_non_narrow = (arsize_m == 3'd6);
// when send a new read req, we will store it req_mask
always@(posedge clk or negedge rstn)
    if(~rstn)
        comb_req_mask <= '{OT{ {REQ_WIDTH{1'd0}} }}; 
    else begin
        if(send_ar_success & send_non_narrow)
            comb_req_mask[arid_m[8:0]] <= entry_comb_mask[flush_order_pop_data] ;
    end

// when it send a new read req, we will make sure it back_cnt is zero
// when slave return non-atomic resp, we should plus it cnt    
always@(posedge clk or negedge rstn)
    if(~rstn)begin
        comb_curr_back_cnt <= '{OT{ {3{1'd0}} }}; 
    end
    else begin
        if(send_ar_success & send_non_narrow)
            comb_curr_back_cnt[arid_m[8:0]] <=   araddr_m[8:6];

        if(receive_rresp & ~rid_m[9])
            comb_curr_back_cnt[rid_m[8:0]] <= comb_curr_back_cnt[rid_m[8:0]] +  1'd1;
    end
//------------------------------------------------------------------------//
//                         RESP RETURN CONTROL                            //
//------------------------------------------------------------------------//
always@(posedge clk or negedge rstn)
if(~rstn)begin
    reg_rdata <= {  512{1'd0}} ;
    reg_rresp <= {    2{1'd0}} ;
end else if(receive_rresp)begin
    reg_rdata <= rdata_m       ;
    reg_rresp <= rresp_m       ;
end

//current rdata req_mask and back_cnt will obtain from rid_m
assign current_resp_mask  = comb_req_mask[rid_m[8:0]];
assign current_cnt_onehot = {{REQ_WIDTH-1{1'd0}}, 1'd1} << comb_curr_back_cnt[rid_m[8:0]];

//when return a non-atomic rresp, we first to check the resp is need?
assign rresp_comb_valid = ~rid_m[9] & comb_valid[rid_m[8:0]] & (|(current_cnt_onehot & current_resp_mask)) ;  

wire [OT-1:0] comb_id_match;
wire [OT-1:0] comb_addr_match;
genvar gen_i;
generate 
    for(gen_i=0; gen_i<OT; gen_i=gen_i+1)begin:gen_compare_comb_id
        assign comb_id_match  [gen_i] = ~|(rid_m ^ origin_id_map[gen_i]); 
        assign comb_addr_match[gen_i] = (comb_curr_back_cnt[rid_m[8:0]] == origin_addr[gen_i]) | ((comb_curr_back_cnt[rid_m[8:0]] == origin_addr[gen_i] + 1'd1) & origin_len[gen_i]);
        assign origin_id_entry[gen_i] = comb_id_match[gen_i] & comb_addr_match[gen_i] & origin_valid[gen_i]; 
    end
endgenerate

assign has_entry_rid_origin = (|origin_id_entry) & rresp_comb_valid;
integer ot_i, ot_j;
reg [31:0] group_onehot;
always@(*)begin
    origin_id   = {IDW-1            {1'd0}};
    group_index = {$clog2(OT_WIDTH) {1'd0}};
    inner_index = {5                {1'd0}};
    for(ot_i=0; ot_i<OT_WIDTH; ot_i=ot_i+1)begin
        group_onehot = origin_id_entry[ot_i*32+:32];
        if(|group_onehot)begin
            group_index = ot_i;
            for(ot_j=0; ot_j<32; ot_j=ot_j+1)begin
                if(group_onehot[ot_j])begin
                    inner_index = ot_j;
                    break;
                end
            end
            break;
        end
    end
    origin_id = {group_index, inner_index};
end


always@(posedge clk or negedge rstn)
if(~rstn)
    reg_rid <= {IDW{1'd0}} ;
else if(has_entry_rid_origin & receive_rresp)
    reg_rid <= {1'd0, origin_id} ;
else if(receive_rresp)
    reg_rid <= rid_m ;

always@(posedge clk or negedge rstn)
if(~rstn)
    reg_rvalid <= 1'd0;
else if(receive_rresp)
    reg_rvalid <= (~comb_valid[rid_m[8:0]]) | (comb_valid[rid_m[8:0]] & has_entry_rid_origin) | rid_m[9];  // if comb_valid is high but has not any entry, means its empty payload
else if(send_resp_success)
    reg_rvalid <= 1'd0;

assign rready_m = rready_s | ~rvalid_s; 

assign rvalid_s =  reg_rvalid      ;
assign rid_s    =  reg_rid         ;
assign rdata_s  =  reg_rdata       ;
assign rresp_s  =  reg_rresp       ;
// if it has match, and is first cycle to return this rdata, the rlast 
assign rlast_s  =  has_entry_rid_origin_reg ?  (~origin_len[rid_s[8:0]]) | (origin_len[rid_s[8:0]] & origin_has_back_rdata[rid_s[8:0]]) : 1'd1;

//------------------------------------------------------------------------//
//                                 PERFORMANCE                            //
//------------------------------------------------------------------------//
// send pack req cnt, trig due to tmo 
//------------------TMO---------------------//
wire trig_flush_tmo_cnt_full;
assign trig_flush_tmo_cnt_full = &reg_ar_trig_flush_tmo_cnt;

// if the status_change signal is high, at the time , the canot belong to tmo out, even its TMO status
wire tmo_reord_enable;
assign tmo_reord_enable = time_out_flag & (~status_change);

always@(posedge clk or negedge rstn)
if(~rstn)
    reg_ar_trig_flush_tmo_cnt[15:0] <= 16'd0;
else if(reg_cnt_clear_en)
    reg_ar_trig_flush_tmo_cnt[15:0] <= 16'd0;
else if(tmo_reord_enable & (~trig_flush_tmo_cnt_full))
    reg_ar_trig_flush_tmo_cnt[15:0] <= reg_ar_trig_flush_tmo_cnt[15:0] + 1'd1;

always@(posedge clk or negedge rstn)
if(~rstn)
    reg_ar_trig_flush_tmo_cnt[31:16] <= 16'd0;
else if(reg_cnt_clear_en)
    reg_ar_trig_flush_tmo_cnt[31:16] <= 16'd0;
else if((&reg_ar_trig_flush_tmo_cnt[15:0]) & (~trig_flush_tmo_cnt_full) & tmo_reord_enable)
    reg_ar_trig_flush_tmo_cnt[31:16] <= reg_ar_trig_flush_tmo_cnt[31:16] + 1'd1;

//------------------COMB_DONE---------------------//
// send pack req cnt, trig due to tmo 
wire trig_flush_comb_done_cnt_full;
assign trig_flush_comb_done_cnt_full = &reg_ar_trig_flush_comb_done_cnt;
// if the status_change signal or tmo and harzard is high, at the time , the canot belong to comb done, even its meet status
wire  comb_done_reord_enable;
assign comb_done_reord_enable = (~time_out_flag) & (~status_change) & (~has_harzard) & comb_done_flag;

always@(posedge clk or negedge rstn)
if(~rstn)
    reg_ar_trig_flush_comb_done_cnt[15:0] <= 16'd0;
else if(reg_cnt_clear_en)
    reg_ar_trig_flush_comb_done_cnt[15:0] <= 16'd0;
else if(comb_done_reord_enable & (~trig_flush_comb_done_cnt_full))
    reg_ar_trig_flush_comb_done_cnt[15:0] <= reg_ar_trig_flush_comb_done_cnt[15:0] + 1'd1;


always@(posedge clk or negedge rstn)
if(~rstn)
    reg_ar_trig_flush_comb_done_cnt[31:16] <= 16'd0;
else if(reg_cnt_clear_en)
    reg_ar_trig_flush_comb_done_cnt[31:16] <= 16'd0;
else if((&reg_ar_trig_flush_comb_done_cnt[15:0]) & (~trig_flush_comb_done_cnt_full) & comb_done_reord_enable)
    reg_ar_trig_flush_comb_done_cnt[31:16] <= reg_ar_trig_flush_comb_done_cnt[31:16] + 1'd1;

//------------------EVICT FULL---------------------//
// send pack req cnt, trig due to tmo 
wire trig_flush_full_cnt_full;
assign trig_flush_full_cnt_full = &reg_ar_trig_flush_full_cnt;

always@(posedge clk or negedge rstn)
if(~rstn)
    reg_ar_trig_flush_full_cnt[15:0] <= 16'd0;
else if(reg_cnt_clear_en)
    reg_ar_trig_flush_full_cnt[15:0] <= 16'd0;
else if(entry_full_need_evict & (~trig_flush_full_cnt_full))
    reg_ar_trig_flush_full_cnt[15:0] <= reg_ar_trig_flush_full_cnt[15:0] + 1'd1;


always@(posedge clk or negedge rstn)
if(~rstn)
    reg_ar_trig_flush_full_cnt[31:16] <= 16'd0;
else if(reg_cnt_clear_en)
    reg_ar_trig_flush_full_cnt[31:16] <= 16'd0;
else if((&reg_ar_trig_flush_full_cnt[15:0]) & (~trig_flush_full_cnt_full) & entry_full_need_evict)
    reg_ar_trig_flush_full_cnt[31:16] <= reg_ar_trig_flush_full_cnt[31:16] + 1'd1;


//------------------HARZARD---------------------//
// send pack req cnt, trig due to tmo 
wire flush_harzard_cnt_full;
assign flush_harzard_cnt_full = &reg_ar_normal_harzard_cnt;
// if the status_change signal or tmo and harzard is high, at the time , the canot belong to comb done, even its meet status
wire  harzard_reord_enable;
assign harzard_reord_enable = (~time_out_flag) & (~status_change) & has_harzard;

always@(posedge clk or negedge rstn)
if(~rstn)
    reg_ar_normal_harzard_cnt[15:0] <= 16'd0;
else if(reg_cnt_clear_en)
    reg_ar_normal_harzard_cnt[15:0] <= 16'd0;
else if(harzard_reord_enable & (~flush_harzard_cnt_full))
    reg_ar_normal_harzard_cnt[15:0] <= reg_ar_normal_harzard_cnt[15:0] + 1'd1;

//------------------TOTAL---------------------//
// send pack req cnt, trig due to tmo 
wire flush_total_cnt_full;
assign flush_total_cnt_full = &reg_ar_trig_send_req_total_cnt;

always@(posedge clk or negedge rstn)
if(~rstn)
    reg_ar_trig_send_req_total_cnt[15:0] <= 16'd0;
else if(reg_cnt_clear_en)
    reg_ar_trig_send_req_total_cnt[15:0] <= 16'd0;
else if(flush_order_push_valid & (~flush_total_cnt_full))
    reg_ar_trig_send_req_total_cnt[15:0] <= reg_ar_trig_send_req_total_cnt[15:0] + 1'd1;


always@(posedge clk or negedge rstn)
if(~rstn)
    reg_ar_trig_send_req_total_cnt[31:16] <= 16'd0;
else if(reg_cnt_clear_en)
    reg_ar_trig_send_req_total_cnt[31:16] <= 16'd0;
else if((&reg_ar_trig_send_req_total_cnt[15:0]) & (~flush_total_cnt_full) & flush_order_push_valid)
    reg_ar_trig_send_req_total_cnt[31:16] <= reg_ar_trig_send_req_total_cnt[31:16] + 1'd1;

//------------------AVG_LEN---------------------//
assign tmo_cnt_enable =  flush_order_pop_ready & (entry_comb_cnt[flush_order_pop_data] == reg_comb_tmo_cnt_num);
assign all_cnt_enable =  flush_order_pop_ready & ( ~entry_narrow[flush_order_pop_data]);
assign all_pkt_window_full = avg_window_time[21:10] == ({{10{1'd0}}, 1'd1} << reg_avg_time);
assign tmo_pkt_window_full = tmo_window_time[21:10] == ({{10{1'd0}}, 1'd1} << reg_avg_time);
// to grep the reg_avg_enable posedge
always@(posedge clk or negedge rstn)
if(!rstn)
    reg_avg_enable_reg <= 2'd0;
else 
    reg_avg_enable_reg <= {reg_avg_enable_reg[0], reg_avg_enable};

assign avg_enable_posedge = reg_avg_enable_reg[0] & (~reg_avg_enable_reg[1]);

//---------window cnt open enable flag register----------//
// if find the posedge will assert the all_pkt_window_cnt_enable
// once the avg_window_time has value we will deassert it
always@(posedge clk or negedge rstn)
if(!rstn)
    all_pkt_window_cnt_enable <= 1'd0;
else if(avg_enable_posedge)
    all_pkt_window_cnt_enable <= 1'd1;
else if(all_pkt_window_full)
    all_pkt_window_cnt_enable <= 1'd0;

always@(posedge clk or negedge rstn)
if(!rstn)
    tmo_pkt_window_cnt_enable <= 1'd0;
else if(avg_enable_posedge)
    tmo_pkt_window_cnt_enable <= 1'd1;
else if(tmo_pkt_window_full)
    tmo_pkt_window_cnt_enable <= 1'd0;

//---------window cnt register----------//
always@(posedge clk or negedge rstn)
if(!rstn)
    avg_window_time[21:0] <= 22'd0;
else if(avg_enable_posedge)
    avg_window_time[21:0] <= {21'd0, (~reg_avg_mode) | (reg_avg_mode & all_cnt_enable)} ;
else if(all_pkt_window_cnt_enable)begin
    if((~reg_avg_mode) | (reg_avg_mode & all_cnt_enable))
        avg_window_time[21:0] <= 1'd1 + avg_window_time[21:0];
end
//--------------tmo total window cnt----------------//
always@(posedge clk or negedge rstn)
if(!rstn)
    tmo_window_time[21:0] <= 22'd0;
else if(avg_enable_posedge)
    tmo_window_time[21:0] <= reg_avg_mode & tmo_cnt_enable ? 22'd1 : 22'd0;
else if(tmo_pkt_window_cnt_enable & reg_avg_mode & tmo_cnt_enable)
    tmo_window_time[21:0] <= 1'd1 + tmo_window_time[21:0];

//---------------total beat cnt---------//
always@(posedge clk or negedge rstn)
if(!rstn)begin
    total_beat_cnt <= 26'd0;
    total_req_cnt  <= 22'd0;
end
else if(avg_enable_posedge)begin
    total_beat_cnt <= all_cnt_enable  ? {22'd0 ,arlen_m + 1'd1} : 26'd0;
    total_req_cnt  <= {21'd0, all_cnt_enable};
end
else if(all_pkt_window_cnt_enable)begin
    total_beat_cnt <= total_beat_cnt_next;
    total_req_cnt  <= total_req_cnt_next;
end

assign total_beat_cnt_next = all_cnt_enable ? total_beat_cnt + {22'd0, arlen_m} + 1'd1 : total_beat_cnt; 
assign total_req_cnt_next  = all_cnt_enable ? total_req_cnt                     + 1'd1 : total_req_cnt ; 


assign req_ar_total_avg_payload_len_cnt = all_pkt_window_full ? { 6'd0, total_beat_cnt} : 32'd0 ;
assign req_ar_total_avg_payload_cnt     = all_pkt_window_full ? {10'd0, total_req_cnt } : 32'd0 ;
//---------------tmo beat cnt---------//
wire tmo_avg_beat_cnt_en = (tmo_pkt_window_cnt_enable & reg_avg_mode) |  ((~reg_avg_mode) & all_pkt_window_cnt_enable);
wire tmo_window_full     = (tmo_pkt_window_full       & reg_avg_mode) |  ((~reg_avg_mode) & all_pkt_window_full);

always@(posedge clk or negedge rstn)
if(!rstn)begin
    tmo_beat_cnt <= 26'd0;
    tmo_req_cnt  <= 22'd0;
end else if(avg_enable_posedge)begin
    tmo_beat_cnt <= tmo_cnt_enable ? {22'd0, arlen_m} + 1'd1 : 26'd0;
    tmo_req_cnt  <= {21'd0, tmo_cnt_enable};
end else if(tmo_avg_beat_cnt_en)begin
    tmo_beat_cnt <= tmo_beat_cnt_next;
    tmo_req_cnt  <= tmo_req_cnt_next;
end

assign tmo_beat_cnt_next = tmo_cnt_enable ? tmo_beat_cnt + {22'd0, arlen_m} + 1'd1 : tmo_beat_cnt; 
assign tmo_req_cnt_next  = tmo_cnt_enable ? tmo_req_cnt                     + 1'd1 : tmo_req_cnt ; 

assign req_ar_tmo_avg_payload_len_cnt = tmo_window_full ? { 6'd0, tmo_beat_cnt} : 32'd0 ;
assign req_ar_tmo_avg_payload_cnt     = tmo_window_full ? {10'd0, tmo_req_cnt } : 32'd0 ;

endmodule
// Local Variables:
// verilog-library-directories:("-y ./ -y ../")
// verilog-auto-inst-param-value:t
// End:
