// +FHDR----------------------------------------------------------------------------
// Copyright (c) 2025, Innosilicon, Inc. Confidential Proprietary
// PROJECT NAME  : xxx
// DEPARTMENT    : Digtal Frontend SOC
// AUTHOR        : chenm
// EMAIL         : chenm@innosilicon.com.cn
// CREATE ON     : 2025/12/04 14:15
// FILE NAME     : write_comb_unit.v
// DESCRIPTION   :          
//         
// Copyright (c) 2025 Innosilicon.
// ALL RIGHTS RESERVED
// 
// ---------------------------------------------------------------------------------
// Modification History:
// Date         By              Version                 Change Description
// ---------------------------------------------------------------------------------
// 2025/12/04   chenm           1.0                     Original
// 
// -FHDR----------------------------------------------------------------------------

`timescale 1ns/1ps

module write_comb_unit
#(
    parameter ADDRW = 49,
    parameter USERW = 14,
    parameter IDW   = 10,
    parameter OT    = 512,
    parameter ENTRY_DEPTH = 8,
    parameter BYPASS_DEPTH = 2,
    parameter BOUNDARY = 512
)
(/*autoarg*/
   // Outputs
   awready_s, awvalid_m, awid_m, awaddr_m, awlen_m, awsize_m,
   awburst_m, awprot_m, awcache_m, awqos_m, awuser_m, awatop_m,
   awlock_m, wready_s, wvalid_m, wdata_m, wstrb_m, wlast_m, bvalid_s,
   bid_s, bresp_s, bready_m, reg_aw_trig_send_req_total_cnt,
   reg_aw_trig_flush_comb_done_cnt, req_aw_tmo_avg_payload_len_cnt,
   req_aw_tmo_avg_payload_cnt, req_aw_total_avg_payload_len_cnt,
   req_aw_total_avg_payload_cnt, reg_aw_trig_flush_full_cnt,
   reg_aw_trig_flush_tmo_cnt, reg_aw_normal_harzard_cnt,
   // Inputs
   reg_cnt_clear_en, reg_avg_time, reg_avg_mode, reg_avg_enable, clk,
   rstn, reg_comb_tmo_cnt_num, awvalid_s, awid_s, awaddr_s, awlen_s,
   awsize_s, awburst_s, awprot_s, awcache_s, awqos_s, awuser_s,
   awatop_s, awlock_s, awready_m, wvalid_s, wdata_s, wstrb_s, wlast_s,
   wready_m, bready_s, bvalid_m, bid_m, bresp_m
   );
  input                   clk;                    // To bypass_fifo of repack_sync_fifo.v, ...
  input                   rstn;                   // To bypass_fifo of repack_sync_fifo.v, ...
  input [6:0] reg_comb_tmo_cnt_num  ; 
  //axi upstream awchannel interface
  input  wire             awvalid_s ;
  output wire             awready_s ;
  input  wire [IDW-1:0]   awid_s    ;
  input  wire [ADDRW-1:0] awaddr_s  ;
  input  wire [3:0]       awlen_s   ;
  input  wire [2:0]       awsize_s  ;
  input  wire [1:0]       awburst_s ;
  input  wire [2:0]       awprot_s  ;
  input  wire [3:0]       awcache_s ;
  input  wire [3:0]       awqos_s   ;
  input  wire [USERW-1:0] awuser_s  ;
  input  wire [5:0]       awatop_s  ;
  input  wire             awlock_s  ;
  
  //axi downstream awchannel interface
  output wire             awvalid_m ;
  input  wire             awready_m ;
  output wire [IDW-1:0]   awid_m    ;
  output wire [ADDRW-1:0] awaddr_m  ;
  output wire [3:0]       awlen_m   ;
  output wire [2:0]       awsize_m  ;
  output wire [1:0]       awburst_m ;
  output wire [2:0]       awprot_m  ;
  output wire [3:0]       awcache_m ;
  output wire [3:0]       awqos_m   ;
  output wire [USERW-1:0] awuser_m  ;
  output wire [5:0]       awatop_m  ;
  output wire             awlock_m  ;
  
  //axi upstream wchannel interface
  input  wire             wvalid_s  ;
  output wire             wready_s  ;
  input  wire [511:0]     wdata_s   ;
  input  wire [ 63:0]     wstrb_s   ;
  input  wire             wlast_s   ;
  
  //axi downstream wchannel interface
  output  wire            wvalid_m  ;
  input   wire            wready_m  ;
  output  wire [511:0]    wdata_m   ;
  output  wire [ 63:0]    wstrb_m   ;
  output  wire            wlast_m   ;
  
  //axi upstream bchannel interface
  output wire             bvalid_s  ;
  output wire [IDW-1:0]   bid_s     ;
  output wire [1:0]       bresp_s   ;
  input  wire             bready_s  ;
  
  //axi downstream rchannel interface
  input  wire             bvalid_m  ;
  input  wire [IDW-1:0]   bid_m     ;
  input  wire [1:0]       bresp_m   ;
  output wire             bready_m  ;

  localparam  REQ_WIDTH          = BOUNDARY / 64           ;  
  localparam  REQ_DEPTH          = $clog2(REQ_WIDTH)       ;
  localparam  ENTRY_BOUNDARY     = $clog2(BOUNDARY)        ;
  localparam  ENTRY_ADDRW        = $clog2(ENTRY_DEPTH)     ;
  localparam WDATA_WIDTH  = 512+64+1;
  localparam WDATA_DEPTH  = BYPASS_DEPTH*2;
  localparam BYPASS_ADDRW = $clog2(BYPASS_DEPTH);
// addr+qos+cache1+user+awatop+wdata+strb+id
  localparam BYPASS_WIDTH = IDW+ADDRW-6+1+1+4+USERW+6;
  localparam IDLE         = 2'b01;
  localparam HAS_AW_NO_W  = 2'b10;
  
  output [31:0]         reg_aw_trig_send_req_total_cnt;// From write_comb_unit of write_process_unit.v
  output [31:0]         reg_aw_trig_flush_comb_done_cnt;// From write_comb_unit of write_process_unit.v
  output [31:0] req_aw_tmo_avg_payload_len_cnt  ;
  output [31:0] req_aw_tmo_avg_payload_cnt      ;
  output [31:0] req_aw_total_avg_payload_len_cnt  ;
  output [31:0] req_aw_total_avg_payload_cnt      ;
  output [31:0]         reg_aw_trig_flush_full_cnt;// From write_comb_unit of write_process_unit.v
  output [31:0]         reg_aw_trig_flush_tmo_cnt;// From write_comb_unit of write_process_unit.v
  output [15:0]           reg_aw_normal_harzard_cnt;// From write_comb_unit of write_process_unit.v

  // End of automatics
  /*autoinput*/
  // Beginning of automatic inputs (from unused autoinst inputs)
  input                 reg_avg_enable;         // To write_comb_unit of write_process_unit.v
  input                 reg_avg_mode;           // To write_comb_unit of write_process_unit.v
  input [31:0]          reg_avg_time;           // To write_comb_unit of write_process_unit.v
  input                 reg_cnt_clear_en;       // To write_comb_unit of write_process_unit.v
  // End of automatics
  /*autowire*/
  // Beginning of automatic wires (for undeclared instantiated-module outputs)
  wire [BYPASS_WIDTH-1:0] bypass_second_data;   // From bypass_fifo of repack_sync_fifo.v
  wire [ADDRW-1:6]      comb_awaddr;            // From write_comb_unit of write_process_unit.v
  wire                  comb_awcache;           // From write_comb_unit of write_process_unit.v
  wire [IDW-1:0]        comb_awid;              // From write_comb_unit of write_process_unit.v
  wire [3:0]            comb_awlen;             // From write_comb_unit of write_process_unit.v
  wire [3:0]            comb_awqos;             // From write_comb_unit of write_process_unit.v
  wire [USERW-1:0]      comb_awuser;            // From write_comb_unit of write_process_unit.v
  wire                  comb_awvalid;           // From write_comb_unit of write_process_unit.v
  wire                  comb_flush_done;        // From write_comb_unit of write_process_unit.v
  wire                  comb_req;               // From write_comb_unit of write_process_unit.v
  wire                  comb_upstream_awready;  // From write_comb_unit of write_process_unit.v
  wire                  comb_upstream_wready;   // From write_comb_unit of write_process_unit.v
  wire [511:0]          comb_wdata;             // From write_comb_unit of write_process_unit.v
  wire                  comb_wlast;             // From write_comb_unit of write_process_unit.v
  wire [63:0]           comb_wstrb;             // From write_comb_unit of write_process_unit.v
  wire                  comb_wvalid;            // From write_comb_unit of write_process_unit.v
  wire [6:0]            entry_comb_cnt [ENTRY_DEPTH-1:0];// From write_comb_unit of write_process_unit.v
  // End of automatics
  wire [ADDRW-1      :9] entry_base_addr [ENTRY_DEPTH-1:0] ; // From write_comb_unit of write_process_unit.v
  wire [8-1          :0] entry_comb_mask [ENTRY_DEPTH-1:0] ; // From write_comb_unit of write_process_unit.v
  wire [USERW-1      :0] entry_comb_user [ENTRY_DEPTH-1:0] ; // From write_comb_unit of write_process_unit.v
  wire [ENTRY_DEPTH-1:0] entry_record           ; // From write_comb_unit of write_process_unit.v
  wire [ENTRY_DEPTH-1:0] entry_valid            ; // From write_comb_unit of write_process_unit.v
  wire [ENTRY_DEPTH-1:0] need_record_window     ;
  wire [ENTRY_DEPTH-1:0] now_pop_entry          ;
  wire [ENTRY_DEPTH-1:0] flush_entry            ;
  wire [ENTRY_DEPTH-1:0] addr_match_window ;
  wire [ENTRY_DEPTH-1:0] aw_entry_index ;
  wire [ENTRY_DEPTH-1:0] comb_harzard_window   ;
  wire [ENTRY_DEPTH-1:0] path_harzard_window   ;
  wire [ENTRY_DEPTH-1:0] comb_no_tmo_window   ;
  wire [ENTRY_DEPTH-1:0] mask_match_window   ;
  wire [ENTRY_ADDRW-1:0] need_record_window_bin     ;

  wire [2:0] awaddr_8_6_bit0;
  wire [REQ_WIDTH-1:0] current_req_mask;
  wire [REQ_WIDTH-1:0] bypass_mask;
  wire [REQ_WIDTH-1:0] bypass_mask_pre;
  wire [REQ_WIDTH-1:0] bypass_second_mask;
  wire [REQ_WIDTH-1:0] bypass_second_mask_pre;
  wire [REQ_WIDTH-1:0] awaddr_8_6_bit0_onehot;
  wire bypass_harzard;
  wire comb_has_harzard;
//  wire comb_harzard;
  wire bypass_req_harzard_with_comb;
  wire comb_req_harzard_with_bypass;
  wire is_bypass_normal_write;
  wire comb_need_record;
//  wire block_from_harzard;
  reg [1:0] current_state         ;
  reg [1:0] next_state            ;
//  reg bypass_send_cnt;
  wire receive_aw_success;
  wire receive_w_success;
  wire is_bypass_req;
  wire bypass_req;
  reg bypass_flag;
  wire [IDW-1:0]          bypass_awid    ;
  wire [ADDRW-1:6]        bypass_awaddr  ;
  wire                    bypass_awlen   ;
  wire                    bypass_awcache ;
  wire [3:0]              bypass_awqos   ;
  wire [USERW-1:0]        bypass_awuser  ;
  wire [5:0]              bypass_awatop  ;
  wire [IDW-1:0]          bypass_second_awid    ;
  wire [ADDRW-1:6]        bypass_second_awaddr  ;
  wire                    bypass_second_awlen   ;
  wire                    bypass_second_awcache ;
  wire [3:0]              bypass_second_awqos   ;
  wire [USERW-1:0]        bypass_second_awuser  ;
  wire [5:0]              bypass_second_awatop  ;
  wire [511:0]            bypass_wdata          ;
  wire [ 63:0]            bypass_wstrb          ;
  wire                    bypass_wlast          ; 
  wire                    comb_awready          ; // To write_comb_unit of write_process_unit.v
  wire                    comb_upstream_awvalid ; // To write_comb_unit of write_process_unit.v
  wire                    comb_upstream_wvalid  ; // To write_comb_unit of write_process_unit.v
  wire                    comb_wready           ; // To write_comb_unit of write_process_unit.v
  wire                    wready_fsm            ;
  wire                    awready_fsm           ;
//  wire                    arbiter_grant_ready   ;
  wire [1:0]              arbiter_sink_last     ; // To arbiter of arbiter_round_robin.v
  wire [1:0]              arbiter_sink_valid    ; // To arbiter of arbiter_round_robin.v
  wire [1:0]              arbiter_grant_valid   ; // From arbiter of arbiter_round_robin.v
  wire                    bypass_pop_ready      ; // To bypass_fifo of repack_sync_fifo.v
  wire [BYPASS_WIDTH-1:0] bypass_push_data      ; // To bypass_fifo of repack_sync_fifo.v
  wire                    bypass_push_valid     ; // To bypass_fifo of repack_sync_fifo.v
  wire [BYPASS_WIDTH-1:0] bypass_pop_data       ; // From bypass_fifo of repack_sync_fifo.v
  wire                    bypass_pop_valid      ; // From bypass_fifo of repack_sync_fifo.v
  wire                    bypass_push_ready     ; // From bypass_fifo of repack_sync_fifo.v
  wire                    wdata_pop_ready      ; // To bypass_fifo of repack_sync_fifo.v
  wire [WDATA_WIDTH-1:0]  wdata_push_data      ; // To bypass_fifo of repack_sync_fifo.v
  wire                    wdata_push_valid     ; // To bypass_fifo of repack_sync_fifo.v
  wire [WDATA_WIDTH-1:0]  wdata_pop_data       ; // From bypass_fifo of repack_sync_fifo.v
  wire                    wdata_pop_valid      ; // From bypass_fifo of repack_sync_fifo.v
  wire                    wdata_push_ready     ; // From bypass_fifo of repack_sync_fifo.v
  wire [BYPASS_WIDTH-1:0] aw_payload_out ; // From aw_slice of axi256_rs_DW_axi_rs_tpi.v
  wire                    aw_ready_out   ; // From aw_slice of axi256_rs_DW_axi_rs_tpi.v
  wire                    aw_valid_out   ; // From aw_slice of axi256_rs_DW_axi_rs_tpi.v
  wire [BYPASS_WIDTH-1:0] aw_payload_in  ; // To aw_slice of axi256_rs_DW_axi_rs_tpi.v
  wire                    aw_ready_in    ; // To aw_slice of axi256_rs_DW_axi_rs_tpi.v
  wire                    aw_valid_in    ; // To aw_slice of axi256_rs_DW_axi_rs_tpi.v
  wire [WDATA_WIDTH-1:0]  w_payload_in   ; // To w_slice of axi256_rs_DW_axi_rs_tpi.v
  wire                    w_ready_in     ; // To w_slice of axi256_rs_DW_axi_rs_tpi.v
  wire                    w_valid_in     ; // To w_slice of axi256_rs_DW_axi_rs_tpi.v
  wire [WDATA_WIDTH-1:0]  w_payload_out  ; // From w_slice of axi256_rs_DW_axi_rs_tpi.v
  wire                    w_ready_out    ; // From w_slice of axi256_rs_DW_axi_rs_tpi.v
  wire                    w_valid_out    ; // From w_slice of axi256_rs_DW_axi_rs_tpi.v

  wire [511:0]            slice_wdata   ;
  wire [ 63:0]            slice_wstrb   ;
  wire                    slice_wlast   ;
  wire [IDW-1:0]          slice_awid    ;
  wire [ADDRW-1:6]        slice_awaddr  ;
  wire                    slice_awlen   ;
  wire                    slice_awcache ;
  wire [3:0]              slice_awqos   ;
  wire [USERW-1:0]        slice_awuser  ;
  wire [5:0]              slice_awatop  ;  
  
  reg awvalid_send_done;
  reg  wvalid_send_done;
  wire awvalid_send_ok;
  wire  wvalid_send_ok;
  reg status_bit;
  wire status_bit_next;
  wire status_change;
  wire slice_send_aw;
  wire slice_send_w;
  wire wdata_bypass_ready;
  wire wdata_bypass_valid;
  reg slice_send_data_cnt;
  assign receive_aw_success = awvalid_s & awready_s;
  assign receive_w_success  = wvalid_s  & wready_s ;
  assign send_aw_success    = awvalid_m & awready_m;
  assign send_w_success     = wvalid_m  & wready_m ; 

  assign slice_send_aw = aw_valid_out & aw_ready_in;
  assign slice_send_w  =  w_valid_out &  w_ready_in;
//------------------------------------------------------------------------//
//                                    FSM                                 //
//------------------------------------------------------------------------//
  always@(posedge clk or negedge rstn)
  if(!rstn)
      current_state <= IDLE       ;
  else 
      current_state <= next_state ;

  // if has receive n new aw and wlast, will still keep idle state
  // else will turn in to HAS_AW_NO_W to wait wlast
  // once has receive wlast will turn back to IDLE state to receive the next aw
  always@(*)begin
      next_state = IDLE;
      case(current_state)
          IDLE:begin
              if(receive_aw_success)
                  next_state = wlast_s & receive_w_success ? IDLE : HAS_AW_NO_W;
              else 
                  next_state = IDLE;
          end

          HAS_AW_NO_W:begin
              if(wlast_s & receive_w_success)
                  next_state = IDLE;
              else 
                  next_state = HAS_AW_NO_W;
          end
          
          default:next_state = IDLE;
      endcase
  end
//------------------------------------------------------------------------//
//                                    AW&W SLICE                          //
//------------------------------------------------------------------------//
  assign aw_valid_in    = awvalid_s & awready_fsm ;
  assign  w_valid_in    =  wvalid_s &  wready_fsm ;

  assign aw_payload_in  =  {
                             awid_s,
                             awaddr_s[ADDRW-1:6],
                             awlen_s[0],
                             awcache_s[0],
                             awqos_s,
                             awuser_s,
                             awatop_s};

  assign { 
          slice_awid,
          slice_awaddr[ADDRW-1:6],
          slice_awlen,
          slice_awcache,
          slice_awqos,
          slice_awuser,
          slice_awatop} = aw_payload_out ; 

  assign  w_payload_in = {wdata_s, wstrb_s, wlast_s};

  assign {slice_wdata, slice_wstrb, slice_wlast} = w_payload_out; 

  // this is comb path or bypass path to upstream ready
  // if is bypass req, its ready decide by bypass fifo ready and canot harzard with comb, else it will decide by comb path
  assign aw_ready_in   =  (is_bypass_req ? bypass_push_ready  & (~bypass_req_harzard_with_comb) :  comb_upstream_awready & (~comb_has_harzard)) & (~status_change);
  assign  w_ready_in   =  (   bypass_req ? wdata_bypass_ready & (~bypass_req_harzard_with_comb) :  comb_upstream_wready  & (~comb_has_harzard)) & (~status_change);

  assign awready_s   =  aw_ready_out & awready_fsm ;
  assign  wready_s   =   w_ready_out &  wready_fsm ;

  // the awready_s assert only in IDLE state, if is bypass req we need the bypass fifo has entry can to store it, else will decide by comb block
  // the wready was limited by the fsm(cannot receive the wdata before receice aw channel), and decide its ready
  assign  wready_fsm =  (current_state == IDLE) & wvalid_s & awvalid_s | (current_state == HAS_AW_NO_W);
  assign awready_fsm =  (current_state == IDLE) & wvalid_s & awvalid_s;
  //assign awready_s   =  (bypass_req ? (current_state == IDLE)  & bypass_push_ready & (~bypass_req_harzard_with_comb) :  comb_upstream_awready & (~comb_req_harzard_with_bypass)) & (~status_change);
  //assign  wready_s   =  (bypass_req ? wready_fsm               & wdata_push_ready  & (~bypass_req_harzard_with_comb) :  comb_upstream_wready  & (~comb_req_harzard_with_bypass)) & (~status_change);

  always@(posedge clk or negedge rstn)
  if(!rstn)
      slice_send_data_cnt <= 1'd0       ;
  else if(slice_wlast & slice_send_w)
      slice_send_data_cnt <= 1'd0 ;
  else if(slice_send_w)
      slice_send_data_cnt <= 1'd1 ;

  assign wdata_bypass_ready = wdata_push_ready & (slice_send_data_cnt | bypass_push_ready);
  assign wdata_bypass_valid = slice_send_data_cnt | bypass_push_ready;

 /*comb_axi256_rs_axi_rs_tpi auto_template "\(.*\)_slice" (
  .test_mode            (1'd0),
  .aclk_i               (clk),
  .aresetn_i            (rstn),
  .\(.*\)_i             (@_\1_in[]),
  .\(.*\)_o             (@_\1_out[]),
);*/
  comb_axi256_rs_axi_rs_tpi #(
    .PLD_W  (BYPASS_WIDTH),
    .TMO    (1)  
  ) aw_slice
  (/*autoinst*/
   // Outputs
   .ready_o                             (aw_ready_out),          // Templated
   .valid_o                             (aw_valid_out),          // Templated
   .payload_o                           (aw_payload_out[BYPASS_WIDTH-1:0]), // Templated
   // Inputs
   .aclk_i                              (clk),                   // Templated
   .aresetn_i                           (rstn),                  // Templated
   .ready_i                             (aw_ready_in),           // Templated
   .valid_i                             (aw_valid_in),           // Templated
   .payload_i                           (aw_payload_in[BYPASS_WIDTH-1:0]), // Templated
   .test_mode                           (1'd0));                         // Templated

  comb_axi256_rs_axi_rs_tpi #(
    .PLD_W  (WDATA_WIDTH),
    .TMO    (1)   
  ) w_slice
  (/*autoinst*/
   // Outputs
   .ready_o                             (w_ready_out),           // Templated
   .valid_o                             (w_valid_out),           // Templated
   .payload_o                           (w_payload_out[WDATA_WIDTH-1:0]), // Templated
   // Inputs
   .aclk_i                              (clk),                   // Templated
   .aresetn_i                           (rstn),                  // Templated
   .ready_i                             (w_ready_in),            // Templated
   .valid_i                             (w_valid_in),            // Templated
   .payload_i                           (w_payload_in[WDATA_WIDTH-1:0]), // Templated
   .test_mode                           (1'd0));                         // Templated

//------------------------------------------------------------------------//
//                                PVF CHANGE                              //
//------------------------------------------------------------------------//  

always@(posedge clk or negedge rstn)
if(~rstn)
    status_bit <= 1'd0;
else if(slice_send_aw)
    status_bit <= status_bit_next;

assign status_bit_next = |slice_awuser[13:10];

// the status valid only in has entry is valid
assign status_change = (status_bit_next ^ status_bit) & ((|entry_valid) | bypass_pop_valid) & aw_valid_out;

//------------------------------------------------------------------------//
//                                MUX                                     //
//------------------------------------------------------------------------//

  assign wdata_pop_ready      = arbiter_grant_valid[0] & send_w_success          ; 
  assign bypass_pop_ready     = arbiter_grant_valid[0] & wvalid_send_ok & awvalid_send_ok ; 
  assign comb_awready         = arbiter_grant_valid[1] & awready_m;
  assign comb_wready          = arbiter_grant_valid[1] &  wready_m;

  // the bypass flag will update by receive a atomic req will non-all-bit-high-wstrb
  always@(posedge clk or negedge rstn)
  if(~rstn)
      bypass_flag <= 1'd0;
  else if(slice_send_aw)
      bypass_flag <= is_bypass_req;

  assign bypass_req = aw_valid_out ? is_bypass_req : bypass_flag;


  // when pop a bypass entry means has send success full a bypass req, we need clear the cnt
  // when pop a entry from wdata fifo, means has send a bypass wdata with non-last, we shold assert it
//  always@(posedge clk or negedge rstn)
//  if(~rstn)
//      bypass_send_cnt <= 1'd0;
////  else if(bypass_pop_ready)
////      bypass_send_cnt <= 1'd0;
//  else if(wdata_pop_ready & wlast_m)
//      bypass_send_cnt <= 1'd0;
//  else if(wdata_pop_ready & ~wlast_m)
//      bypass_send_cnt <= 1'd1;

  //--------------------------SLAVE INTERFACE-----------------------------//
  // MUX awready and awvalid assert
  // if is atomic_req or a non-strb_all_ff we will push it into the bypass fifo
  assign is_bypass_req         = aw_valid_out     & ((|slice_awatop) | ((~&wstrb_s) & slice_awlen) | (~&slice_wstrb)) ;  // the bypass req is decide by awatop and the all wstrb
  assign comb_upstream_awvalid = aw_valid_out     & (~is_bypass_req)           & (~comb_has_harzard)              & ~status_change;
  assign comb_upstream_wvalid  =  w_valid_out     & (~bypass_req   )           & (~comb_has_harzard)              & ~status_change;
  assign bypass_push_valid     = is_bypass_req                                 & (~bypass_req_harzard_with_comb)  & ~status_change;
  assign wdata_push_valid      = bypass_req & w_valid_out & wdata_bypass_valid & (~bypass_req_harzard_with_comb)  & ~status_change;

  //--------------------------MASTER INTERFACE-----------------------------//
  assign awvalid_send_ok = awvalid_send_done | ((~awvalid_send_done) & arbiter_grant_valid[0] & send_aw_success);
  assign  wvalid_send_ok =  wvalid_send_done | (( ~wvalid_send_done) & arbiter_grant_valid[0] & send_w_success & wlast_m);

  always@(posedge clk or negedge rstn)
  if(~rstn)
      awvalid_send_done <= 1'd0;
  else if(bypass_pop_ready)
      awvalid_send_done <= 1'd0;
  else if(arbiter_grant_valid[0] & send_aw_success)
      awvalid_send_done <= 1'd1;

  always@(posedge clk or negedge rstn)
  if(~rstn)
      wvalid_send_done <= 1'd0;
  else if(bypass_pop_ready)
      wvalid_send_done <= 1'd0;
  else if(arbiter_grant_valid[0] & send_w_success & wlast_m)
      wvalid_send_done <= 1'd1;

  // tie value sideband signal
  assign    awlock_m       = 1'd0 ;
  assign    awprot_m       = 3'd0 ;
  assign    awburst_m      = 2'd1 ;
  assign    awsize_m       = 3'd6 ;
  assign    awcache_m[3:1] = 3'd0 ;

  assign    awaddr_m     = arbiter_grant_valid[1] ? {comb_awaddr, 6'd0}     : {bypass_awaddr, 6'd0}                 ;
  assign    awid_m       = arbiter_grant_valid[1] ? comb_awid               : bypass_awid                           ;
  assign    awlen_m      = arbiter_grant_valid[1] ? comb_awlen              : {3'd0, bypass_awlen}                  ;
  assign    awcache_m[0] = arbiter_grant_valid[1] ? comb_awcache            : bypass_awcache                        ;
  assign    awqos_m      = arbiter_grant_valid[1] ? comb_awqos              : bypass_awqos                          ;
  assign    awuser_m     = arbiter_grant_valid[1] ? comb_awuser             : bypass_awuser                         ;
  assign    awatop_m     = arbiter_grant_valid[1] ? 6'd0                    : bypass_awatop                         ;
  assign    awvalid_m    = arbiter_grant_valid[1] ? comb_awvalid            : arbiter_grant_valid[0] & bypass_pop_valid & (~awvalid_send_done);

  assign     wvalid_m    = arbiter_grant_valid[1] ? comb_wvalid             : arbiter_grant_valid[0] & wdata_pop_valid & bypass_pop_valid  & (~wvalid_send_done)   ;
  assign     wdata_m     = arbiter_grant_valid[1] ? comb_wdata              : bypass_wdata                          ;
  assign     wstrb_m     = arbiter_grant_valid[1] ? comb_wstrb              : bypass_wstrb                          ;
  assign     wlast_m     = arbiter_grant_valid[1] ? comb_wlast              : bypass_wlast ;
//------------------------------------------------------------------------//
//                                HARZARD                                 //
//------------------------------------------------------------------------//
  // if it is non-atomic and wstrb has zero
assign is_bypass_normal_write    = aw_valid_out  &  (~|slice_awatop) & (slice_awlen ? ((~&wstrb_s) | (~&slice_wstrb)) : ~&slice_wstrb)  ;

assign awaddr_8_6_bit0 = slice_awaddr[8:6];

wire [ 1:0] awaddr_8_6_bit0_onehot_level0  = {awaddr_8_6_bit0[0], ~awaddr_8_6_bit0[0]};
wire [ 3:0] awaddr_8_6_bit0_onehot_level1  = {awaddr_8_6_bit0_onehot_level0 & { 2{awaddr_8_6_bit0[1]}}, awaddr_8_6_bit0_onehot_level0 & ~{ 2{awaddr_8_6_bit0[1]}}};
wire [ 7:0] awaddr_8_6_bit0_onehot_level2  = {awaddr_8_6_bit0_onehot_level1 & { 4{awaddr_8_6_bit0[2]}}, awaddr_8_6_bit0_onehot_level1 & ~{ 4{awaddr_8_6_bit0[2]}}};
assign      awaddr_8_6_bit0_onehot         = awaddr_8_6_bit0_onehot_level2;

// accord the awaddr[8:6] and awlen to decide the mask, once has mask bit is be assert, means has addr harzard
assign bypass_mask_pre        = {{{7'd0}}, 1'd1} << bypass_awaddr[8:6]                                                                ;
assign bypass_second_mask_pre = {{{7'd0}}, 1'd1} << bypass_second_awaddr[8:6]                                                         ;
assign bypass_mask            = bypass_awlen        ? bypass_mask_pre        | (bypass_mask_pre << 1)        : bypass_mask_pre        ;
assign bypass_second_mask     = bypass_second_awlen ? bypass_second_mask_pre | (bypass_second_mask_pre << 1) : bypass_second_mask_pre ;

assign current_req_mask = slice_awlen ?  (awaddr_8_6_bit0_onehot[7:0] | (awaddr_8_6_bit0_onehot[7:0] << 1)) : awaddr_8_6_bit0_onehot[7:0];

wire bypass_harzard_entry0;
wire bypass_harzard_entry1;

// the bypass fifo only depth2, if has entry, the pop_valid must is high, and the harzard must VF/PF identify same, and addr match, and the atomic req not consider harzard
// if the bypass fifof has 2 valid req, the push_ready will deassert, and we need consider the second entry req
// and if the bypass_req was grant, the harzard will be assert
assign bypass_harzard_entry0 = bypass_pop_valid & (~|bypass_awatop) & (slice_awaddr[ADDRW-1:9] == bypass_awaddr[ADDRW-1:9]) & (bypass_awuser[13:10] == slice_awuser[13:10]) & (|(bypass_mask & current_req_mask)) & ~arbiter_grant_valid[0];
assign bypass_harzard_entry1 = (~bypass_push_ready) & (~|bypass_second_awatop) & (slice_awaddr[ADDRW-1:9] == bypass_second_awaddr[ADDRW-1:9]) & (bypass_second_awuser[13:10] == slice_awuser[13:10]) & (|(bypass_second_mask & current_req_mask));

assign bypass_harzard = bypass_harzard_entry0 | bypass_harzard_entry1;

// if the neq awreq is not bypass req(comb_req) but the addr harzard with bypass channel's non-atomic req, we will assert the comb_req_harzard_with_bypass signal to block the new req accept, untill the harzard deassert
assign comb_req_harzard_with_bypass = bypass_harzard & (~is_bypass_req) & aw_valid_out;


// if the arbiter is grant to the comb req, the flush_entry is flush to slave interface, so we need should mask the entry's harzard info
assign now_pop_entry                = arbiter_grant_valid[1] ? flush_entry : {ENTRY_DEPTH{1'd0}};

// the harzard assert we need baseaddr and PF/VF identify equal, and the entry is valid, and not flush to slave interface now 
// and the mask has same bit all be assert at the same time
// if the entry is non-record state we should record now
genvar find_harzard;
generate
    for(find_harzard=0; find_harzard<ENTRY_DEPTH; find_harzard=find_harzard+1)begin:check_comb_harzard
        //assign addr_match_window[find_harzard] = (slice_awaddr[ADDRW-1:ENTRY_BOUNDARY] == entry_base_addr[find_harzard]) & entry_valid[find_harzard] & (slice_awuser[13:10] == entry_comb_user[find_harzard][13:10]) & (~now_pop_entry[find_harzard]);
        assign addr_match_window   [find_harzard] = (slice_awaddr[ADDRW-1:ENTRY_BOUNDARY] == entry_base_addr[find_harzard]) & entry_valid[find_harzard] & (slice_awuser[13:10] == entry_comb_user[find_harzard][13:10]);
        assign comb_no_tmo_window  [find_harzard] = (entry_comb_cnt[find_harzard] != reg_comb_tmo_cnt_num) & (~entry_record[find_harzard]);
        assign aw_entry_index      [find_harzard] = addr_match_window[find_harzard] & comb_no_tmo_window[find_harzard];
        assign mask_match_window   [find_harzard] = (|(current_req_mask & entry_comb_mask[find_harzard]));        
        assign comb_harzard_window [find_harzard] = aw_entry_index[find_harzard] & mask_match_window[find_harzard] ;
        assign path_harzard_window [find_harzard] = addr_match_window[find_harzard] & mask_match_window[find_harzard] & (~now_pop_entry[find_harzard]);
    end
endgenerate

assign bypass_req_harzard_with_comb = (|path_harzard_window) & is_bypass_normal_write;

// if is comb req and has harzard with comb_entry, it will assert harzard signal
// if its a normal bypass req and has path harzard, it will  assert harzard signal
assign comb_has_harzard = ((|comb_harzard_window) & (~is_bypass_req) & aw_valid_out) | (comb_req_harzard_with_bypass);   

assign comb_need_record = ((|comb_harzard_window) & (~is_bypass_req) & aw_valid_out) | ((|(path_harzard_window & (~entry_record))) & is_bypass_normal_write);
//when is a comb_req but has harzard, we need push harzard entry to ordfifo
//when is a normal bypass req, we need push harzard entry but not record entry to ordfifo
assign need_record_window =  ({8{~is_bypass_req}} & comb_harzard_window) | ({8{is_bypass_normal_write}} & path_harzard_window & (~entry_record));

assign need_record_window_bin[2] =  |need_record_window[7:4]; 
assign need_record_window_bin[1] = (|need_record_window[7:6]) | (|need_record_window[3:2]); 
assign need_record_window_bin[0] = need_record_window[7] | need_record_window[5] | need_record_window[3] | need_record_window[1]; 

//------------------------------------------------------------------------//
//                            BYPASS FIFO                                 //
//------------------------------------------------------------------------//

  // when receive a atomic req shoud push its signal when receive w data
  assign bypass_push_data  = {
          slice_awid,
          slice_awaddr[ADDRW-1:6],
          slice_awlen,
          slice_awcache,
          slice_awqos,
          slice_awuser,
          slice_awatop};

  assign { 
          bypass_awid,
          bypass_awaddr[ADDRW-1:6],
          bypass_awlen,
          bypass_awcache,
          bypass_awqos,
          bypass_awuser,
          bypass_awatop} = bypass_pop_data ;    

  assign { 
          bypass_second_awid,
          bypass_second_awaddr[ADDRW-1:6],
          bypass_second_awlen,
          bypass_second_awcache,
          bypass_second_awqos,
          bypass_second_awuser,
          bypass_second_awatop} = bypass_second_data ; 
//assign bypass_second_awaddr = bypass_second_data[BYPASS_WIDTH-1-IDW-:ADDRW-6];
//assign bypass_second_awatop = bypass_second_data[5 : 0];
//assign bypass_second_awuser = bypass_second_data[19:16];
//assign bypass_second_awlen  = bypass_second_data[6+USERW+4+1];

/*repack_sync_fifo auto_template "\(.*\)_fifo" (
.clk                        (clk),
.reset_n                    (rstn),
.almost_empty               (),
.\(.*\)                     (@_\1[]),
);*/
repack_sync_fifo #(
    .FIFO_WIDTH(BYPASS_WIDTH), 
    .FIFO_DEPTH(BYPASS_DEPTH), 
    .ADDR_WIDTH($clog2(BYPASS_DEPTH))
)bypass_fifo(/*autoinst*/
             // Outputs
             .push_ready                (bypass_push_ready),     // Templated
             .pop_data                  (bypass_pop_data[BYPASS_WIDTH-1:0]), // Templated
             .second_data               (bypass_second_data[BYPASS_WIDTH-1:0]), // Templated
             .almost_empty              (),                      // Templated
             .pop_valid                 (bypass_pop_valid),      // Templated
             // Inputs
             .clk                       (clk),                   // Templated
             .reset_n                   (rstn),                  // Templated
             .push_data                 (bypass_push_data[BYPASS_WIDTH-1:0]), // Templated
             .push_valid                (bypass_push_valid),     // Templated
             .pop_ready                 (bypass_pop_ready));     // Templated

assign wdata_push_data = {slice_wdata, slice_wstrb, slice_wlast};
assign {bypass_wdata, bypass_wstrb, bypass_wlast} = wdata_pop_data; 
/*repack_sync_fifo auto_template "\(.*\)_fifo" (
.clk                        (clk),
.reset_n                    (rstn),
.second_data                (),
.almost_empty               (),
.\(.*\)                     (@_\1[]),
);*/
repack_sync_fifo #(
    .FIFO_WIDTH(WDATA_WIDTH), 
    .FIFO_DEPTH(WDATA_DEPTH), 
    .ADDR_WIDTH(BYPASS_ADDRW+1)
)wdata_fifo(/*autoinst*/
            // Outputs
            .push_ready                 (wdata_push_ready),      // Templated
            .pop_data                   (wdata_pop_data[WDATA_WIDTH-1:0]), // Templated
            .second_data                (),                      // Templated
            .almost_empty               (),                      // Templated
            .pop_valid                  (wdata_pop_valid),       // Templated
            // Inputs
            .clk                        (clk),                   // Templated
            .reset_n                    (rstn),                  // Templated
            .push_data                  (wdata_push_data[WDATA_WIDTH-1:0]), // Templated
            .push_valid                 (wdata_push_valid),      // Templated
            .pop_ready                  (wdata_pop_ready));      // Templated
//------------------------------------------------------------------------//
//                                ARBITER                                 //
//------------------------------------------------------------------------//

// End of automatics
// the comb_req and pop_valid will aribter by round-robin
// the comb done decide by the process unit, the bypass req will decide by the bypass_pop_ready            
assign arbiter_sink_valid = {comb_req,        bypass_pop_valid & wdata_pop_valid};
assign arbiter_sink_last  = {comb_flush_done, awvalid_send_ok  & wvalid_send_ok};
//assign arbiter_grant_ready = wready_m;
//assign arbiter_grant_ready = arbiter_grant_valid[1] & comb_flush_done | arbiter_grant_valid[0] & awvalid_send_ok & wvalid_send_ok  ;

/*arbiter_round_robin auto_template "\(.*\)" (
.clk                        (clk),
.reset_n                    (rstn),
.\(.*\)                     (@_\1[]),
);*/
arbiter_round_robin #(
    .REQ_NUM(2) 
) arbiter(/*autoinst*/
          // Outputs
          .grant_valid                  (arbiter_grant_valid[1:0]), // Templated
          // Inputs
          .clk                          (clk),                   // Templated
          .reset_n                      (rstn),                  // Templated
          .sink_valid                   (arbiter_sink_valid[1:0]), // Templated
          .sink_last                    (arbiter_sink_last[1:0])); // Templated

//------------------------------------------------------------------------//
//                                COMB_UNIT                               //
//------------------------------------------------------------------------//
/*write_process_unit auto_template "write_\(.*\)_unit" (
.\([a]*wvalid\|[a]*wready\)_s               (@_upstream_\1[]),
.\(wvalid\|wready\)_s               (@_upstream_\1[]),
.\([a]*w.*\)_m                              (@_\1[]),
.\([a]*w.*\)_s                              (slice_\1[]),
);*/          
write_process_unit #(
    .ADDRW       (ADDRW       ) ,
    .USERW       (USERW       ) ,
    .IDW         (IDW         ) ,
    .OT          (OT          ) ,
    .ENTRY_DEPTH (ENTRY_DEPTH ) ,
    .ENTRY_ADDRW (ENTRY_ADDRW ) ,
    .REQ_WIDTH (REQ_WIDTH ) ,
    .REQ_DEPTH (REQ_DEPTH ) ,
    .ENTRY_BOUNDARY    (ENTRY_BOUNDARY    ) )
write_comb_unit(/*autoinst*/
                // Outputs
                .awready_s              (comb_upstream_awready), // Templated
                .awvalid_m              (comb_awvalid),          // Templated
                .awid_m                 (comb_awid[IDW-1:0]),    // Templated
                .awaddr_m               (comb_awaddr[ADDRW-1:6]), // Templated
                .awlen_m                (comb_awlen[3:0]),       // Templated
                .awcache_m              (comb_awcache),          // Templated
                .awqos_m                (comb_awqos[3:0]),       // Templated
                .awuser_m               (comb_awuser[USERW-1:0]), // Templated
                .wready_s               (comb_upstream_wready),  // Templated
                .wvalid_m               (comb_wvalid),           // Templated
                .wdata_m                (comb_wdata[511:0]),     // Templated
                .wstrb_m                (comb_wstrb[63:0]),      // Templated
                .wlast_m                (comb_wlast),            // Templated
                .bvalid_s               (bvalid_s),
                .bid_s                  (bid_s[IDW-1:0]),
                .bresp_s                (bresp_s[1:0]),
                .bready_m               (bready_m),
                .comb_req               (comb_req),
                .comb_flush_done        (comb_flush_done),
                .reg_aw_trig_flush_comb_done_cnt(reg_aw_trig_flush_comb_done_cnt[31:0]),
                .reg_aw_trig_flush_tmo_cnt(reg_aw_trig_flush_tmo_cnt[31:0]),
                .reg_aw_trig_flush_full_cnt(reg_aw_trig_flush_full_cnt[31:0]),
                .reg_aw_normal_harzard_cnt(reg_aw_normal_harzard_cnt[15:0]),
                .reg_aw_trig_send_req_total_cnt(reg_aw_trig_send_req_total_cnt[31:0]),
                .req_aw_tmo_avg_payload_len_cnt(req_aw_tmo_avg_payload_len_cnt[31:0]),
                .req_aw_tmo_avg_payload_cnt(req_aw_tmo_avg_payload_cnt[31:0]),
                .req_aw_total_avg_payload_len_cnt(req_aw_total_avg_payload_len_cnt[31:0]),
                .req_aw_total_avg_payload_cnt(req_aw_total_avg_payload_cnt[31:0]),
                .flush_entry            (flush_entry[ENTRY_DEPTH-1:0]),
                .entry_valid            (entry_valid[ENTRY_DEPTH-1:0]),
                .entry_record           (entry_record[ENTRY_DEPTH-1:0]),
                .entry_base_addr        (entry_base_addr/*[ADDRW-1:ENTRY_BOUNDARY].[ENTRY_DEPTH-1:0]*/),
                .entry_comb_mask        (entry_comb_mask/*[REQ_WIDTH-1:0].[ENTRY_DEPTH-1:0]*/),
                .entry_comb_user        (entry_comb_user/*[USERW-1:0].[ENTRY_DEPTH-1:0]*/),
                .entry_comb_cnt         (entry_comb_cnt/*[6:0].[ENTRY_DEPTH-1:0]*/),
                // Inputs
                .clk                    (clk),
                .rstn                   (rstn),
                .reg_comb_tmo_cnt_num   (reg_comb_tmo_cnt_num[6:0]),
                .awvalid_s              (comb_upstream_awvalid), // Templated
                .awid_s                 (slice_awid[IDW-1:0]),   // Templated
                .awaddr_s               (slice_awaddr[ADDRW-1:6]), // Templated
                .awlen_s                (slice_awlen),           // Templated
                .awcache_s              (slice_awcache),         // Templated
                .awqos_s                (slice_awqos[3:0]),      // Templated
                .awuser_s               (slice_awuser[USERW-1:0]), // Templated
                .awready_m              (comb_awready),          // Templated
                .wvalid_s               (comb_upstream_wvalid),  // Templated
                .wdata_s                (slice_wdata[511:0]),    // Templated
                .wstrb_s                (slice_wstrb[63:0]),     // Templated
                .wlast_s                (slice_wlast),           // Templated
                .wready_m               (comb_wready),           // Templated
                .bready_s               (bready_s),
                .bvalid_m               (bvalid_m),
                .bid_m                  (bid_m[IDW-1:0]),
                .bresp_m                (bresp_m[1:0]),
                .reg_avg_mode           (reg_avg_mode),
                .reg_cnt_clear_en       (reg_cnt_clear_en),
                .reg_avg_enable         (reg_avg_enable),
                .reg_avg_time           (reg_avg_time[31:0]),
                .comb_need_record       (comb_need_record),
                .aw_entry_index         (aw_entry_index[ENTRY_DEPTH-1:0]),
                .need_record_window_bin (need_record_window_bin[ENTRY_ADDRW-1:0]),
                .status_change          (status_change));

endmodule
// Local Variables:
// verilog-library-directories:("./" "../../../axi_slice/axi256_rs")
// verilog-auto-output-ignore-regexp:"\\(unuse\\|_temp\\|bypass_\\|pop_\\|push_\\|comb_\\|arbiter_\\|fsm\\|entry\\|status_change\\)"
// verilog-auto-input-ignore-regexp:"\\(unuse\\|_temp\\|bypass_\\|pop_\\|push_\\|comb_\\|arbiter_\\|fsm\\|entry\\|status_change\\)"
// verilog-auto-inst-param-value:t
// End:
