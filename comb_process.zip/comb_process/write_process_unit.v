// +FHDR----------------------------------------------------------------------------
// Copyright (c) 2025, Innosilicon, Inc. Confidential Proprietary
// PROJECT NAME  : xxx
// DEPARTMENT    : Digtal Frontend SOC
// AUTHOR        : chenm
// EMAIL         : chenm@innosilicon.com.cn
// CREATE ON     : 2025/11/24 10:29
// FILE NAME     : write_process_unit.v
// DESCRIPTION   :          
//         
// Copyright (c) 2025 Innosilicon.
// ALL RIGHTS RESERVED
// 
// ---------------------------------------------------------------------------------
// Modification History:
// Date         By              Version                 Change Description
// ---------------------------------------------------------------------------------
// 2025/11/24   chenm           1.0                     Original
// 
// -FHDR----------------------------------------------------------------------------

`timescale 1ns/1ps
module write_process_unit
#(
    parameter ADDRW          = 52,
    parameter USERW          = 14,
    parameter IDW            = 10,
    parameter OT             = 512,
    parameter ENTRY_DEPTH    = 8,
    parameter ENTRY_ADDRW    = 3,
    parameter REQ_WIDTH      = 8,
    parameter REQ_DEPTH      = 3,
    parameter ENTRY_BOUNDARY = 9
)
(/*autoarg*/
   // Outputs
   awready_s, awvalid_m, awid_m, awaddr_m, awlen_m, awcache_m,
   awqos_m, awuser_m, wready_s, wvalid_m, wdata_m, wstrb_m, wlast_m,
   bvalid_s, bid_s, bresp_s, bready_m, comb_req, comb_flush_done,
   reg_aw_trig_flush_comb_done_cnt, reg_aw_trig_flush_tmo_cnt,
   reg_aw_trig_flush_full_cnt, reg_aw_normal_harzard_cnt,
   reg_aw_trig_send_req_total_cnt, req_aw_tmo_avg_payload_len_cnt,
   req_aw_tmo_avg_payload_cnt, req_aw_total_avg_payload_len_cnt,
   req_aw_total_avg_payload_cnt, flush_entry, entry_valid,
   entry_record, entry_base_addr, entry_comb_mask, entry_comb_user,
   entry_comb_cnt,
   // Inputs
   clk, rstn, reg_comb_tmo_cnt_num, awvalid_s, awid_s, awaddr_s,
   awlen_s, awcache_s, awqos_s, awuser_s, awready_m, wvalid_s,
   wdata_s, wstrb_s, wlast_s, wready_m, bready_s, bvalid_m, bid_m,
   bresp_m, reg_avg_mode, reg_cnt_clear_en, reg_avg_enable,
   reg_avg_time, comb_need_record, aw_entry_index,
   need_record_window_bin, status_change
   );

input                   clk;                    // To bypass_fifo of repack_sync_fifo.v, ...
input                   rstn;                   // To bypass_fifo of repack_sync_fifo.v, ...
input [6:0] reg_comb_tmo_cnt_num  ; 
//axi upstream awchannel interface
input  wire             awvalid_s ;
output wire             awready_s ;
input  wire [IDW-1:0]   awid_s    ;
input  wire [ADDRW-1:6] awaddr_s  ;
input  wire             awlen_s   ;
input  wire             awcache_s ;
input  wire [3:0]       awqos_s   ;
input  wire [USERW-1:0] awuser_s  ;

//axi downstream awchannel interface
output wire             awvalid_m ;
input  wire             awready_m ;
output wire [IDW-1:0]   awid_m    ;
output wire [ADDRW-1:6] awaddr_m  ;
output wire [3:0]       awlen_m   ;
output wire             awcache_m ;
output wire [3:0]       awqos_m   ;
output wire [USERW-1:0] awuser_m  ;

//axi upstream wchannel interface
input  wire             wvalid_s  ;
output wire             wready_s  ;
input  wire [511:0]     wdata_s   ;
input  wire [ 63:0]     wstrb_s   ;
input  wire             wlast_s   ;

//axi downstream wchannel interface
output  wire            wvalid_m  ;
input   wire            wready_m  ;
output  wire [511:0]    wdata_m   ;
output  wire [ 63:0]    wstrb_m   ;
output  wire            wlast_m   ;

//axi upstream bchannel interface
output reg              bvalid_s  ;
output wire [IDW-1:0]   bid_s     ;
output wire [1:0]       bresp_s   ;
input  wire             bready_s  ;

//axi downstream rchannel interface
input  wire             bvalid_m  ;
input  wire [IDW-1:0]   bid_m     ;
input  wire [1:0]       bresp_m   ;
output wire             bready_m  ;

output                  comb_req        ;
output                  comb_flush_done ;

output reg [31:0] reg_aw_trig_flush_comb_done_cnt ;
output reg [31:0] reg_aw_trig_flush_tmo_cnt       ;
output reg [31:0] reg_aw_trig_flush_full_cnt      ;
output reg [15:0] reg_aw_normal_harzard_cnt       ;
output reg [31:0] reg_aw_trig_send_req_total_cnt       ;
//output reg [ 3:0] reg_aw_send_avg_beat_total_cnt  ;
//output reg [ 3:0] reg_aw_send_avg_beat_tmo_cnt    ;
output [31:0] req_aw_tmo_avg_payload_len_cnt  ;
output [31:0] req_aw_tmo_avg_payload_cnt      ;
output [31:0] req_aw_total_avg_payload_len_cnt  ;
output [31:0] req_aw_total_avg_payload_cnt      ;
input         reg_avg_mode                        ;
input         reg_cnt_clear_en                    ;
input         reg_avg_enable                      ;
input [31:0]  reg_avg_time                        ;
//input                    wready_fsm               ;
//input                    awready_fsm        ;
input                    comb_need_record   ;

output [ENTRY_DEPTH-1:0] flush_entry        ;
input  [ENTRY_DEPTH-1:0] aw_entry_index         ;
input  [ENTRY_ADDRW-1:0] need_record_window_bin ;
input  status_change; 

output reg [ENTRY_DEPTH-1     : 0              ] entry_valid                       ;
output reg [ENTRY_DEPTH-1     : 0              ] entry_record                      ;
output reg [ADDRW-1           : ENTRY_BOUNDARY ] entry_base_addr [ENTRY_DEPTH-1:0] ;
output reg [REQ_WIDTH-1       : 0              ] entry_comb_mask [ENTRY_DEPTH-1:0] ;
output reg [USERW-1           : 0              ] entry_comb_user [ENTRY_DEPTH-1:0] ; 
output reg [6                 : 0              ] entry_comb_cnt  [ENTRY_DEPTH-1:0] ; 

localparam  WDATA_DEPTH        = ENTRY_DEPTH             ;
//localparam  REQ_WIDTH          = BOUNDARY / 64           ;
//localparam  ENTRY_ADDRW        = $clog2(ENTRY_DEPTH)     ;
localparam  WDATA_ADDRW        = ENTRY_ADDRW             ;
//localparam  REQ_DEPTH          = $clog2(REQ_WIDTH)       ;
//localparam  ENTRY_BOUNDARY     = $clog2(BOUNDARY)        ;
localparam  WDATA_BUFFER_ADDRW = REQ_DEPTH + WDATA_ADDRW ;

localparam IDLE           = 4'b0001;
localparam SEND_SUB_CMD   = 4'b0010;
localparam ONLY_SEND_W    = 4'b0100;
localparam ONLY_SEND_AW   = 4'b1000;

  reg [3:0] current_state         ;
  reg [3:0] next_state            ;


reg [ENTRY_DEPTH-1     : 0              ] entry_comb_cache                  ;
reg [3                 : 0              ] entry_comb_qos  [ENTRY_DEPTH-1:0] ;
reg [(REQ_WIDTH*IDW)-1 : 0              ] entry_origin_id [ENTRY_DEPTH-1:0] ;

reg [OT-1   :0] comb_valid            ;
reg [IDW-1  :0] comb_id_map [OT-1 :0] ;

wire [ENTRY_DEPTH-1:0] new_alloc_entry        ;
wire [ENTRY_DEPTH-1:0] valid_entry_post       ;
//wire [ENTRY_DEPTH-1:0] same_addr_window_index ;
//wire [ENTRY_DEPTH-1:0] harzard_window_index   ;
wire [ENTRY_DEPTH-1:0] status_change_window   ;
reg  [ENTRY_ADDRW-1:0] cnt_time_out           ;
reg  [ENTRY_ADDRW-1:0] comb_done_reg          ;
reg  [ENTRY_ADDRW-1:0] entry_full_has_new_req ;
reg  [ENTRY_ADDRW-1:0] aw_entry_index_bin     ;
reg  [ENTRY_ADDRW-1:0] new_alloc_entry_bin    ;
//reg  [ENTRY_ADDRW-1:0] harzard_window_bin     ;
//reg  [ENTRY_ADDRW-1:0] need_record_window_bin ;
reg  [ENTRY_ADDRW-1:0] current_entry          ;
wire [ENTRY_ADDRW-1:0] current_window         ;
reg  [ENTRY_ADDRW-1:0] status_change_bin      ;


wire [REQ_WIDTH-1:0] current_req_mask       ;
reg  [REQ_WIDTH-1:0] first_wdata_mask       ;
wire [REQ_WIDTH-1:0] first_wdata_mask_post  ;
wire [REQ_WIDTH-1:0] flush_mask_prev        ;
wire [REQ_WIDTH-1:0] flush_mask_next        ;
wire [REQ_WIDTH-1:0] flush_mask_start       ;
wire [REQ_WIDTH-1:0] flush_mask_end         ;
wire [REQ_WIDTH-1:0] flush_mask_start_post  ;
wire [REQ_WIDTH-1:0] flush_mask_end_post    ;
reg  [REQ_WIDTH-1:0] flush_mask_update      ;
wire [REQ_WIDTH-1:0] flush_mask_update_next ;
wire [REQ_WIDTH-1:0] flush_mask_current     ;
wire [REQ_DEPTH-1:0] flush_mask_start_bin   ;
wire [REQ_DEPTH-1:0] flush_mask_end_bin     ;
wire [REQ_DEPTH-1:0] first_wdata_mask_bin   ;

reg  [ENTRY_BOUNDARY-6-1:0] addr_offset            ;
wire [ENTRY_BOUNDARY-6-1:0] current_addr_offset    ;
wire [WDATA_BUFFER_ADDRW-1:0] wdata_write_addr     ;
wire [WDATA_BUFFER_ADDRW-1:0] wdata_read_addr      ;
reg  [WDATA_BUFFER_ADDRW-1:0] wdata_read_addr_reg  ; //todo
reg  [WDATA_BUFFER_ADDRW-1:0] first_sub_wdata_addr ; //todo

reg  [WDATA_ADDRW-1:0] first_wdata_addr         ;
reg   [ENTRY_ADDRW-1:0] flush_order_push_data   ; // To   repack_sync_fifo.v
wire                   flush_order_push_valid   ; // To   repack_sync_fifo.v
wire                   flush_order_push_ready   ; // From repack_sync_fifo.v
wire                   flush_order_almost_empty ;
wire [ENTRY_ADDRW-1:0] flush_order_pop_data     ; // From repack_sync_fifo.v
wire [ENTRY_ADDRW-1:0] flush_order_second_data  ; // From repack_sync_fifo.v
wire                   flush_order_pop_valid    ; // From repack_sync_fifo.v
wire                   flush_order_pop_ready    ; // To   repack_sync_fifo.v

wire [ADDRW-1           : ENTRY_BOUNDARY ] flush_base_addr  ;
wire [REQ_WIDTH-1       : 0              ] flush_comb_mask  ;
wire [WDATA_ADDRW-1     : 0              ] flush_wdata_addr ;
wire [(REQ_WIDTH*IDW)-1 : 0              ] flush_origin_id  ;

wire [REQ_DEPTH-1    :0] offset_addr    ;
reg  [REQ_WIDTH*IDW-1:0] origin_id_mask ;

wire [OT-1    :0] comb_id_match    ;
wire comb_id_block;
//reg                reg_awvalid ;
reg  [IDW-1   : 0] reg_bid     ;
reg  [IDW-1   : 0] reg_bid_keep;
reg  [      1 : 0] reg_bresp   ;
wire [IDW-1   : 0] temp_awid   ;
wire [ADDRW-1 : 6] temp_awaddr ;
wire [3       : 0] temp_awlen  ;
reg  [IDW-2   : 0] origin_id   ;
reg  [IDW-2   : 0] origin_id_first   ;

wire [511:0] wdata_write_data       ;
wire [511:0] wdata_read_data        ;
wire [  2:0] awaddr_8_6_bit0        ;
wire [  7:0] awaddr_8_6_bit0_onehot ;
reg  [  2:0] sub_wdata_send_cnt     ;
reg  [  6:0] max_value              ;

wire          aw_has_entry             ;
reg          burst                     ;
reg          new_window_flush          ;
reg          time_out_flag             ;
reg          comb_done_reg_flag        ;
//reg          harzard_keep_flag         ;
reg          bresp_has_entry           ;
reg          has_entry_bids            ;
reg          has_comb_resp             ;
wire         sub_flush_done_flag       ;
wire         first_sub_cmd_enable      ;
reg          first_sub_cmd_keep      ;
wire         comb_done_flag            ;
wire         entry_full_need_evict     ;
wire         flush_window_exit_idle    ;
//wire         has_harzard              ;
wire         receive_comb_done         ;
wire         wdata_write_en            ;
wire         wdata_read_en             ;
wire         send_aw_success           ;
wire         send_w_success            ;
wire         send_b_success            ;
wire         receive_salve_resp        ;
//wire         block_from_harzard        ;
wire         block_from_no_window      ;
wire         burst_flag                ;
wire         receive_new_aw            ;
wire         flush_enable              ;
wire         first_comb_req            ;
wire         need_alloc_new_window     ;
wire         flush_except_evict        ;
reg  [ 21:0] avg_window_time           ;
reg  [ 21:0] tmo_window_time           ;
reg  [ 25:0] total_beat_cnt            ;
wire [ 25:0] total_beat_cnt_next       ;
reg  [ 25:0] tmo_beat_cnt              ;
wire [ 25:0] tmo_beat_cnt_next         ;
reg  [21    : 0] total_req_cnt             ;
wire [21    : 0] total_req_cnt_next        ;
reg  [21    : 0] tmo_req_cnt             ;
wire [21    : 0] tmo_req_cnt_next        ;
reg  [ 1 :0] reg_avg_enable_reg        ;
wire         avg_enable_posedge        ;
reg          all_pkt_window_cnt_enable ;
reg          tmo_pkt_window_cnt_enable ;
wire         all_pkt_window_full       ;
wire         tmo_pkt_window_full       ;
wire send_wlast_success;
wire has_window_need_flush;
integer j,l,m,n,o,p;
//------------------------------------------------------------------------//
//                           WINDOW ALLOC CONTROL                         //
//------------------------------------------------------------------------//
assign receive_new_aw = awready_s & awvalid_s;

// we need update the entry valid flag, in initial state the valid is all be keep zero
// when has receiving a new req, we need alloc a new entry and update the valid flag
// when the entry will be flush, the valid flag will turn back to zero
always@(posedge clk or negedge rstn)
    if(!rstn)
        entry_valid <= {ENTRY_DEPTH{1'd0}};
    else if(first_comb_req)
        entry_valid <= flush_enable ? (valid_entry_post | new_alloc_entry ) : (entry_valid | new_alloc_entry);
    else if(flush_enable)
        entry_valid <= valid_entry_post;

// the flush enable can be assert after the last window flush done or flush_window flush from idle
assign flush_enable = comb_flush_done;
assign flush_entry  = {{ENTRY_DEPTH-1{1'd0}}, 1'd1} << flush_order_pop_data; 

// when has received a new aw req, we should check its need create a new entry?
// if has not find entry, means that is a new entry, else will check has harzard? if has has_harzard we also need create a new entry
assign first_comb_req = receive_new_aw & (~aw_has_entry);  // equal need_alloc_new_window
assign need_alloc_new_window = first_comb_req;

// check has entry?
//genvar find_entry;
//generate
//    for(find_entry=0; find_entry<ENTRY_DEPTH; find_entry=find_entry+1)begin:find_aw_entry
//        assign aw_entry_index        [find_entry] = (awaddr_s[ADDRW-1:ENTRY_BOUNDARY] == entry_base_addr[find_entry]) & entry_valid[find_entry] & (awuser_s[13:10] == entry_comb_user[find_entry][13:10]) & (~entry_record[find_entry]) & (entry_comb_cnt[find_entry] != reg_comb_tmo_cnt_num);
//        assign harzard_window_index  [find_entry] = (|(current_req_mask & entry_comb_mask[find_entry])) & aw_entry_index[find_entry];        
//    end
//endgenerate

assign aw_has_entry = (|aw_entry_index) & awvalid_s;

// if has flush event, the valid_entry ture state will mask the flush entry
assign valid_entry_post = flush_enable ? entry_valid & (~flush_entry) : entry_valid;

// to find the lowest index high as new alloc entry
assign new_alloc_entry = (~valid_entry_post) & (~((~valid_entry_post) - 1'd1));
//------------------------------------------------------------------------//
//                         NORMAL HARZARD CONTROL                         //
//------------------------------------------------------------------------//
assign awaddr_8_6_bit0 = awaddr_s[8:6];

wire [ 1:0] awaddr_8_6_bit0_onehot_level0  = {awaddr_8_6_bit0[0], ~awaddr_8_6_bit0[0]};
wire [ 3:0] awaddr_8_6_bit0_onehot_level1  = {awaddr_8_6_bit0_onehot_level0 & { 2{awaddr_8_6_bit0[1]}}, awaddr_8_6_bit0_onehot_level0 & ~{ 2{awaddr_8_6_bit0[1]}}};
wire [ 7:0] awaddr_8_6_bit0_onehot_level2  = {awaddr_8_6_bit0_onehot_level1 & { 4{awaddr_8_6_bit0[2]}}, awaddr_8_6_bit0_onehot_level1 & ~{ 4{awaddr_8_6_bit0[2]}}};
assign      awaddr_8_6_bit0_onehot         = awaddr_8_6_bit0_onehot_level2;

assign current_req_mask = ~awlen_s ? awaddr_8_6_bit0_onehot[REQ_WIDTH-1:0] : (awaddr_8_6_bit0_onehot[REQ_WIDTH-1:0] | (awaddr_8_6_bit0_onehot[REQ_WIDTH-1:0] << 1));

// the addr harzard is when the len is zer0, the will check the addr[8:6] has valid addr? else will check the addr[8:6] and the next beat has valid addr?
//assign has_harzard = (|harzard_window_index) & awvalid_s ;

//------------AWREADY&WREADY BLOCK--------------------------//
//assign block_from_harzard   = has_harzard;
assign block_from_no_window = awvalid_s & (~aw_has_entry) & (&valid_entry_post); 

assign awready_s = ~block_from_no_window;
assign  wready_s = ~block_from_no_window;

//------------------------------------------------------------------------//
//                      WINDOW INFO UPDATE CONTROL                        //
//------------------------------------------------------------------------//
//--------------BASE_ADDR & USER------------------------//
// the base_addr, comb_id and user only update in first_comb_req is high
always@(posedge clk or negedge rstn)
if(~rstn)begin
    for(j=0; j<ENTRY_DEPTH; j=j+1)begin
        entry_base_addr[j] <= {ADDRW-ENTRY_BOUNDARY {1'd0}};
        entry_comb_user[j] <= {USERW                {1'd0}}; 
    end
end else if(first_comb_req)begin
    entry_base_addr[new_alloc_entry_bin] <= awaddr_s[ADDRW-1 : ENTRY_BOUNDARY];
    entry_comb_user[new_alloc_entry_bin] <= awuser_s[USERW-1 :              0]; 
end

//-------------------QOS & CACHE------------------------//
// the all comb_sun_req qos max value will as the final comb_qos value
// and the cache value: once comb_sub_req has cache[1] is high, the comb_cache[1] is high
always@(posedge clk or negedge rstn)
if(~rstn)begin
    for(j=0; j<ENTRY_DEPTH; j=j+1)begin
        entry_comb_qos[j]      <= {4{1'd0}}; 
        entry_comb_cache[j]    <= {1{1'd0}}; 
    end
end else if(first_comb_req)begin
    entry_comb_qos   [ new_alloc_entry_bin ] <= awqos_s      ;
    entry_comb_cache [ new_alloc_entry_bin ] <= awcache_s    ;
end else if(receive_new_aw)begin
    entry_comb_cache [ aw_entry_index_bin  ] <= awcache_s    | entry_comb_cache[aw_entry_index_bin] ;
    entry_comb_qos   [ aw_entry_index_bin  ] <= (awqos_s >  entry_comb_qos[aw_entry_index_bin]) ? awqos_s : entry_comb_qos[aw_entry_index_bin]     ;
end
//-------------------IDLE TIME CNT------------------------//
genvar tmo_iter;
generate
    for(tmo_iter=0; tmo_iter<ENTRY_DEPTH; tmo_iter=tmo_iter+1)begin:gen_tmo_cnt
        always@(posedge clk or negedge rstn)
        if(~rstn)
            entry_comb_cnt[tmo_iter] <= 7'd0;
        else if(wdata_write_en & (tmo_iter == current_window))
            entry_comb_cnt[tmo_iter] <= 7'd1;
        else if(entry_comb_cnt[tmo_iter] == reg_comb_tmo_cnt_num)
            entry_comb_cnt[tmo_iter] <= entry_comb_cnt[tmo_iter];
        else if(|entry_comb_cnt[tmo_iter] & entry_valid[tmo_iter] & (~entry_record[tmo_iter]))
            entry_comb_cnt[tmo_iter] <= entry_comb_cnt[tmo_iter] + 1'd1;
    end
endgenerate
//-------------------REQ MASK UPDATE------------------------//
// the comb mask is menas whick sub_req has receive
// when is first req we will assert as awaddr[8:6]_one_hot or plus 1, else will merge the awaddr[8:6]
always@(posedge clk or negedge rstn)
if(~rstn)begin
    for(j=0; j<ENTRY_DEPTH; j=j+1)begin
        entry_comb_mask[j] <= {REQ_WIDTH{1'd0}}; 
    end
end else begin  
    if(first_comb_req)
        entry_comb_mask[new_alloc_entry_bin] <= current_req_mask;
    else if(receive_new_aw)
        entry_comb_mask[aw_entry_index_bin ] <= current_req_mask | entry_comb_mask[aw_entry_index_bin];
end
//------------------------------------------------------------------------//
//                           WINDOW_ORIGIN_ID_ARRAY                       //
//------------------------------------------------------------------------//
// the current_req_mask every bit will repeat IDW time and meger again as origin_id update mask
genvar req_i;
generate 
    for(req_i=0; req_i<REQ_WIDTH; req_i=req_i+1)begin:gen_origin_req_mask
        assign origin_id_mask[IDW*req_i+:IDW] = {IDW{current_req_mask[req_i]}};
    end
endgenerate
// when is a new window alloc, will reset the id_info_array, the origin id and mask by origin_id_mask
// when has match a window, will update the info also mask by origin_id_mask
always@(posedge clk or negedge rstn)
    if(~rstn)begin
        for(j=0; j<ENTRY_DEPTH; j=j+1)
            entry_origin_id[j] <= {REQ_WIDTH*IDW{1'd0}}; 
    end else if(need_alloc_new_window)  
        entry_origin_id [ new_alloc_entry_bin ] <= origin_id_mask & {REQ_WIDTH{awid_s[IDW-1:0]}};
    else if(receive_new_aw)
        entry_origin_id [ aw_entry_index_bin  ] <= origin_id_mask & {REQ_WIDTH{awid_s[IDW-1:0]}} | entry_origin_id[aw_entry_index_bin];

//------------------------------------------------------------------------//
//                          FLUSH LOGIC CONTROL                           //
//------------------------------------------------------------------------//
//-------------RECORD_FLAG----------------//
// when has alloc a new req will deassert its entry_record 
// when the window was push into the order fifo, the reord will be assert
// at the same time the new_alloc_entry_bin and flush_order_push_data cannot equal
always@(posedge clk or negedge rstn)
    if(!rstn)
        entry_record <= {ENTRY_DEPTH{1'd0}};
    else begin
        if(first_comb_req)
            entry_record [ new_alloc_entry_bin   ] <= 1'd0;

        if(flush_order_push_ready & flush_order_push_valid)
            entry_record [ flush_order_push_data ] <= 1'd1;
    end 

//-----------------------TMO----------------------//
// if the entry is valid and the time cnt is upper max, the entry will be flush
always@(*)begin
    cnt_time_out            = {ENTRY_ADDRW{1'd0}};
    time_out_flag           = 1'd0;
    for(l=0; l<ENTRY_DEPTH; l=l+1)begin
        if((entry_comb_cnt[l] == reg_comb_tmo_cnt_num) & entry_valid[l] & ~entry_record[l])begin
            cnt_time_out                = l;
            time_out_flag               = 1'd1;
        end
    end
end
//wire tmo_deassert_flag;
//
//// when receive a new req and happen tmo with same time, we will clear the tmo cnt
//// ~has_harzard & aw_has_entry means that this req is non-narrow and can be receive successful
//assign tmo_deassert_flag = (aw_entry_index_bin == cnt_time_out) & aw_has_entry & (~has_harzard);
//
//assign time_out_flag = time_out_flag & (~tmo_deassert_flag);
//-----------------------COMB DONE-----------------//
// when receive a new aw, has hit window and not first, and req_mask will all high, means comb over
assign receive_comb_done = receive_new_aw & aw_has_entry & (&(current_req_mask | entry_comb_mask[aw_entry_index_bin]));
assign comb_done_flag = receive_comb_done | comb_done_reg_flag;
always@(*)begin
    comb_done_reg        = {ENTRY_ADDRW{1'd0}};
    comb_done_reg_flag   = 1'd0;
    for(m=0; m<ENTRY_DEPTH; m=m+1)begin
        if((&entry_comb_mask[m]) & entry_valid[m] & ~entry_record[m])begin
            comb_done_reg        = m;
            comb_done_reg_flag   = 1'd1;
        end
    end
end

//-----------------------EVICT_MUST_DILE_FIFO----------------------//
//when receive a new cmd but not hit any entry(so no harzard), no any window in comb_done or tmo state ,but all entry is valid
//and order fifo has not any window wait to flush 
//so we need to evict the must IDLE entry to accept new req
assign entry_full_need_evict = awvalid_s & (~aw_has_entry) & (&entry_valid) & (~flush_order_pop_valid) & (~flush_except_evict);

always@(*)begin
    entry_full_has_new_req  = {ENTRY_ADDRW{1'd0}};
    max_value               = entry_comb_cnt[0];
    if(awvalid_s & (&entry_valid))begin
        for(n=1; n<ENTRY_DEPTH; n=n+1)begin
            if((entry_comb_cnt[n] > max_value) & entry_valid[n])begin
                max_value               = entry_comb_cnt[n];
                entry_full_has_new_req  = n;
            end
        end
    end
end
//-----------------------ORDER FIFO----------------------//
// when open harzard, or comb_done and tmo will push its window index to order_fifo
//assign flush_except_evict = has_harzard | comb_done_flag | time_out_flag | comb_need_record | (status_change & (|status_change_window));
assign flush_except_evict =  comb_done_flag | time_out_flag ;
assign flush_order_push_valid = flush_except_evict | entry_full_need_evict | comb_need_record | (status_change & (|status_change_window)) ;

// flush_order pre-process, according to the priority.
// harzard and comb_done_flag cannot happen at same cycle
assign flush_order_pop_ready  = comb_flush_done;

always@(*)begin
    flush_order_push_data = entry_full_has_new_req;
    if(status_change)
        flush_order_push_data = status_change_bin;
    else if(time_out_flag)
        flush_order_push_data = cnt_time_out;
    else if(comb_need_record)
        flush_order_push_data = need_record_window_bin;
    else if(comb_done_flag)
        flush_order_push_data = comb_done_reg_flag ? comb_done_reg : aw_entry_index_bin;
    //else if(entry_full_need_evict)
    //    flush_order_push_data = entry_full_has_new_req;
end

assign status_change_window = entry_valid & (~entry_record); 


integer bin_i;
always@(*)begin
//    harzard_window_bin     = {ENTRY_ADDRW{1'd0}} ;
    aw_entry_index_bin     = {ENTRY_ADDRW{1'd0}} ;
    new_alloc_entry_bin    = {ENTRY_ADDRW{1'd0}} ;
    status_change_bin      = {ENTRY_ADDRW{1'd0}} ;
//    need_record_window_bin = {ENTRY_ADDRW{1'd0}} ;
    for(bin_i=ENTRY_DEPTH-1; bin_i>=0; bin_i=bin_i-1)begin
//        if(harzard_window_index[bin_i])begin
//            harzard_window_bin = bin_i;
//        end

        if(aw_entry_index[bin_i])begin
            aw_entry_index_bin = bin_i;
        end

        if(new_alloc_entry[bin_i])begin
            new_alloc_entry_bin = bin_i;
        end
  //      if(need_record_window[bin_i])begin
  //          need_record_window_bin = bin_i;
  //      end
        if(status_change_window[bin_i])begin
            status_change_bin = bin_i;
        end
    end
end

/*repack_sync_fifo auto_template "\(.*\)_fifo" (
.clk                        (clk),
.reset_n                    (rstn),
.\(.*\)                     (@_\1[]),
);*/

repack_sync_fifo #(
    .FIFO_WIDTH(ENTRY_ADDRW), 
    .FIFO_DEPTH(ENTRY_DEPTH), 
    .ADDR_WIDTH(ENTRY_ADDRW)
)flush_order_fifo(/*autoinst*/
                  // Outputs
                  .push_ready           (flush_order_push_ready), // Templated
                  .pop_data             (flush_order_pop_data[ENTRY_ADDRW-1:0]), // Templated
                  .second_data          (flush_order_second_data[ENTRY_ADDRW-1:0]), // Templated
                  .almost_empty         (flush_order_almost_empty), // Templated
                  .pop_valid            (flush_order_pop_valid), // Templated
                  // Inputs
                  .clk                  (clk),                   // Templated
                  .reset_n              (rstn),                  // Templated
                  .push_data            (flush_order_push_data[ENTRY_ADDRW-1:0]), // Templated
                  .push_valid           (flush_order_push_valid), // Templated
                  .pop_ready            (flush_order_pop_ready)); // Templated

//------------------------------------------------------------------------//
//                           AW CHANNEL CONTROL                           //
//------------------------------------------------------------------------//
assign send_aw_success    = awvalid_m & awready_m    ;
assign send_w_success     = wvalid_m  & wready_m     ;
assign send_wlast_success = send_w_success & wlast_m ;

// when current window has flush done or flush_windoe exit from idle will assert new_window to update all aw and w signal
always@(posedge clk or negedge rstn)
    if(~rstn)
        new_window_flush <= 1'd0;
    else
        new_window_flush <= comb_flush_done | flush_window_exit_idle;

// the sub_flush_done flag can assert for len is zero but len is 0, or has sending wlast now
// when has send wlast and req_mask_update_next is all zero means all wdata was send success, can pop new window    
//assign sub_flush_done_flag = send_w_success & wlast_m                         ;
//assign comb_flush_done     = sub_flush_done_flag & (~|flush_mask_update_next) ;

//genvar match_i;
//generate 
//    for(match_i=0; match_i<OT; match_i=match_i+1)begin:gen_match_comb_id
//        assign comb_id_match  [match_i] = (temp_awid == comb_id_map[match_i]) & comb_valid[match_i]; 
//    end
//endgenerate

//assign comb_id_block = |comb_id_match;
assign comb_id_block = (temp_awid == reg_bid_keep) & has_comb_resp;

assign comb_req            = flush_order_pop_valid                            ; 

assign flush_base_addr  = entry_base_addr [flush_order_pop_data] ;
assign flush_comb_mask  = entry_comb_mask [flush_order_pop_data] ;
assign flush_origin_id  = entry_origin_id [flush_order_pop_data] ; 
assign flush_wdata_addr =                  flush_order_pop_data  ;

// the req mask update in the first send or every sub_req_flush_done
// once new_window_flush success, the mask will mask the all low bit for update the new mask to calu the new start and end bit
always@(posedge clk or negedge rstn)
    if(~rstn)
        flush_mask_update <= {REQ_WIDTH{1'd0}};
    else if(sub_flush_done_flag)
        flush_mask_update <= flush_mask_update_next;
    else if(new_window_flush)
        flush_mask_update <= flush_comb_mask;

assign flush_mask_update_next = flush_comb_mask & (~((flush_mask_start_post << 1) - 1'd1)) ;
// if is new_window_flush, the flush_mask will equal the flush_comb_mask(origin), else will equal flush_mask_update
assign flush_mask_current = new_window_flush ? flush_comb_mask : flush_mask_update ;

assign flush_mask_prev = {1'b0, flush_mask_current[REQ_WIDTH-1:1]};
assign flush_mask_next = {flush_mask_current[REQ_WIDTH-2:0], 1'b0};

// to find every 'req mask window' start bit and end bit
assign flush_mask_start = flush_mask_current & ~flush_mask_prev;
assign flush_mask_end   = flush_mask_current & ~flush_mask_next;

// to find the lowest index is high
assign flush_mask_start_post = flush_mask_start & ~(flush_mask_start - 1'd1) ;
assign flush_mask_end_post   = flush_mask_end   & ~(flush_mask_end   - 1'd1) ;

// start bit and end bit turn to binaray, to calu the aw_len and awaddr[8:6]/[7:6], and to id origin select
//integer mask_i, mask_j;
//integer mask_i ;
//always@(*)begin
//    flush_mask_start_bin = {REQ_DEPTH{1'd0}};
//    flush_mask_end_bin   = {REQ_DEPTH{1'd0}};
//    first_wdata_mask_bin   = {REQ_DEPTH{1'd0}};
//    for(mask_i=0; mask_i<REQ_WIDTH; mask_i=mask_i+1)begin
//        if(flush_mask_start_post[mask_i])
//            flush_mask_start_bin = mask_i;
//
//        if(flush_mask_end_post[mask_i])
//            flush_mask_end_bin = mask_i;
//
//        if(first_wdata_mask_post[mask_i])
//            first_wdata_mask_bin = mask_i;
//
//    end
//end

generate 
    if(REQ_WIDTH == 8)begin:gen_onehot2bin_512B
        assign first_wdata_mask_bin[2] =  |first_wdata_mask_post[7:4]; 
        assign first_wdata_mask_bin[1] = (|first_wdata_mask_post[7:6]) | (|first_wdata_mask_post[3:2]); 
        assign first_wdata_mask_bin[0] =  first_wdata_mask_post[7] | first_wdata_mask_post[5] | first_wdata_mask_post[3] | first_wdata_mask_post[1]; 

        assign flush_mask_end_bin[2] =  |flush_mask_end_post[7:4]; 
        assign flush_mask_end_bin[1] = (|flush_mask_end_post[7:6]) | (|flush_mask_end_post[3:2]); 
        assign flush_mask_end_bin[0] =  flush_mask_end_post[7] | flush_mask_end_post[5] | flush_mask_end_post[3] | flush_mask_end_post[1]; 

        assign flush_mask_start_bin[2] =  |flush_mask_start_post[7:4]; 
        assign flush_mask_start_bin[1] = (|flush_mask_start_post[7:6]) | (|flush_mask_start_post[3:2]); 
        assign flush_mask_start_bin[0] =  flush_mask_start_post[7] | flush_mask_start_post[5] | flush_mask_start_post[3] | flush_mask_start_post[1]; 

    end else begin:gen_onehot2bin_256B
        assign first_wdata_mask_bin = {|first_wdata_mask_post[3:2], first_wdata_mask_post[3] | first_wdata_mask_post[1]};
        assign flush_mask_end_bin   = {|flush_mask_end_post  [3:2], flush_mask_end_post  [3] | flush_mask_end_post  [1]};
        assign flush_mask_start_bin = {|flush_mask_start_post[3:2], flush_mask_start_post[3] | flush_mask_start_post[1]};

    end
endgenerate

// the len addr and id will update with the 'req_mask window' move
assign temp_awlen  = {1'd0, flush_mask_start_bin - flush_mask_end_bin}; // todo 256B bit-width has not match
assign temp_awaddr = {flush_base_addr, flush_mask_end_bin};

generate 
    if(REQ_WIDTH == 8)begin:gen_id_mask_512B
        assign temp_awid = (flush_origin_id[IDW*8-1:IDW*7] & {IDW{flush_mask_start_post[7]}}) | (flush_origin_id[IDW*7-1:IDW*6] & {IDW{flush_mask_start_post[6]}}) | 
                           (flush_origin_id[IDW*6-1:IDW*5] & {IDW{flush_mask_start_post[5]}}) | (flush_origin_id[IDW*5-1:IDW*4] & {IDW{flush_mask_start_post[4]}}) | 
                           (flush_origin_id[IDW*4-1:IDW*3] & {IDW{flush_mask_start_post[3]}}) | (flush_origin_id[IDW*3-1:IDW*2] & {IDW{flush_mask_start_post[2]}}) | 
                           (flush_origin_id[IDW*2-1:IDW  ] & {IDW{flush_mask_start_post[1]}}) | (flush_origin_id[IDW-1  :    0] & {IDW{flush_mask_start_post[0]}}) ;

    end else begin:gen_id_mask_256B
        assign temp_awid = (flush_origin_id[IDW*4-1:IDW*3] & {IDW{flush_mask_start_post[3]}}) | (flush_origin_id[IDW*3-1:IDW*2] & {IDW{flush_mask_start_post[2]}}) | 
                           (flush_origin_id[IDW*2-1:IDW  ] & {IDW{flush_mask_start_post[1]}}) | (flush_origin_id[IDW-1  :    0] & {IDW{flush_mask_start_post[0]}}) ;
    end
endgenerate

//------------------------AW CHANNEL ASSERT--------------------------//
always@(posedge clk or negedge rstn)
if(!rstn)
    current_state <= IDLE       ;
else 
    current_state <= next_state ;

// if sub cmd send done and has not any sub_req need send, menas this window flush done
assign comb_flush_done = sub_flush_done_flag & (~|flush_mask_update_next) ;

// in the SEND_SUB_CMD, if send aw and wlast success menas sub cmd send done
// in the ONLY_SEND_W , if send wlast success menas sub cmd send done
// in the ONLY_SEND_AW, if send aw success menas sub cmd send done
assign sub_flush_done_flag = (current_state == SEND_SUB_CMD) & send_aw_success & send_wlast_success | (current_state == ONLY_SEND_W) & send_wlast_success | (current_state == ONLY_SEND_AW) & send_aw_success;

// if the orderfifo is not amlost_empty or is almost_empty but has window has trig flush now, neans the the has window wait to flush to slave
assign has_window_need_flush = (~flush_order_almost_empty);
always@(*)begin
    next_state = IDLE;
    case(current_state)
        IDLE:begin
            if(flush_order_pop_valid)
                next_state =  SEND_SUB_CMD;
            else 
                next_state = IDLE;
        end

        SEND_SUB_CMD:begin
            if(~send_aw_success & send_wlast_success) // if send wlast success but aw is fail, we will only send aw
                next_state = ONLY_SEND_AW;
            else if(send_aw_success & (~send_wlast_success))  // if send aw success but wlast is fail, we will only send w
                next_state = ONLY_SEND_W;
            // if send aw and send wlast succuss with this window is trig done(comb_flush_done),  and orderfifo is almost empty, and the has not any window trig flush --> not other window need flush
            else if(send_aw_success & send_wlast_success & (~|flush_mask_update_next)  & flush_order_almost_empty) 
                next_state = IDLE;
            else 
                next_state = SEND_SUB_CMD;
        end

        ONLY_SEND_W:begin
            // if send wlast success and has sub_cmd or other window need send will back to SEND_SUB_CMD state, else will back IDLE
            // if send wlast faill will keep send wdata state
            if(send_wlast_success)begin
                if((|flush_mask_update_next) | has_window_need_flush)
                    next_state = SEND_SUB_CMD;
                else
                    next_state = IDLE;
            end else
                next_state = ONLY_SEND_W;
        end

        ONLY_SEND_AW:begin
            // if send wlast success and has sub_cmd or other window need send will back to SEND_SUB_CMD state, else will back IDLE
            // if send wlast faill will keep send wdata state
            if(send_aw_success)begin
                if((|flush_mask_update_next) | has_window_need_flush)
                    next_state = SEND_SUB_CMD;
                else
                    next_state = IDLE;
            end else
                next_state = ONLY_SEND_AW;
        end
        default:next_state = IDLE;
    endcase
end

assign awvalid_m = ((current_state == ONLY_SEND_AW) | (current_state == SEND_SUB_CMD)) & ~(comb_id_block & first_sub_cmd_keep);

// in one window we will keep value
assign awcache_m  = entry_comb_cache [ flush_order_pop_data ] ;
assign awqos_m    = entry_comb_qos   [ flush_order_pop_data ] ;
assign awuser_m   = entry_comb_user  [ flush_order_pop_data ] ;

// we will update the value in every time sub req send
assign awid_m    = temp_awid    ;
assign awaddr_m  = temp_awaddr  ;
assign awlen_m   = temp_awlen   ;

//// when
//always@(posedge clk or negedge rstn)
//    if(~rstn)
//        reg_awvalid <= 1'd0;
//    else if(sub_flush_done_flag & (|flush_mask_update_next))
//        reg_awvalid <= 1'd1;
//    else if(new_window_flush & (~send_aw_success) & flush_order_pop_valid)
//        reg_awvalid <= 1'd1;
//    else if(send_aw_success)
//        reg_awvalid <= 1'd0;
//
//// when the new_window_flush is high, we need assert the awvalid_m    
//assign awvalid_m = new_window_flush & flush_order_pop_valid ? 1'd1 : reg_awvalid;
//------------------------------------------------------------------------//
//                           W CHANNEL CONTROL                            //
//------------------------------------------------------------------------//
// when the flush_mask_current has bit is high, the wvalid need assert
assign wvalid_m = ((current_state == ONLY_SEND_W) | (current_state == SEND_SUB_CMD)) & ~(comb_id_block & first_sub_cmd_keep);
//assign wvalid_m = (|flush_mask_current) & flush_order_pop_valid; 
assign wstrb_m  = 64'hffff_ffff_ffff_ffff;
assign wdata_m  = wdata_read_data;
assign wlast_m  = (sub_wdata_send_cnt == temp_awlen[2:0]);

// when has send w success the cnt will update
// if send aw at the same time, means that the w is first wdata, the next beat cnt will recovery to zero, else dircet to plus 1
//always@(posedge clk or negedge rstn)
//    if(~rstn)
//        sub_wdata_send_cnt <= 3'd0;
//    else if(send_w_success)begin
//        if(wlast_m)
//            sub_wdata_send_cnt <= 3'd0;
//        else if(send_aw_success)
//            sub_wdata_send_cnt <= 3'd1;
//        else
//            sub_wdata_send_cnt <= 3'd1 + sub_wdata_send_cnt;
//    end
always@(posedge clk or negedge rstn)
    if(~rstn)
        sub_wdata_send_cnt <= 3'd0;
    // when next state is SEND_SUB_CMD or IDLE, the wdata cnt must be clear to zero
    // but if current state is SEND_SUB_CMD but was send w success we need incr it, and if wlast is send we will back to zero
//    else if(((next_state == SEND_SUB_CMD) & send_wlast_success)  | (next_state == IDLE))
    else if(send_wlast_success)
        sub_wdata_send_cnt <= 3'd0;
    // else send w success will puls 1
    else if(send_w_success)
        sub_wdata_send_cnt <= 3'd1 + sub_wdata_send_cnt;
//------------------------------------------------------------------------//
//                           WDATA_LOAD_CONTROL                           //
//------------------------------------------------------------------------//
// should keep current entry signal
// when has need_alloc_new_window means should update to new_alloc_entry_bin
// when receive_new_aw but not need alloc window will update to aw_entry_index_bin 
always@(posedge clk or negedge rstn)
    if(~rstn)
        current_entry <= {ENTRY_ADDRW{1'd0}};
    else if(need_alloc_new_window)
        current_entry <= new_alloc_entry_bin;
    else if(receive_new_aw)
        current_entry <= aw_entry_index_bin;

assign current_window = need_alloc_new_window ? new_alloc_entry_bin : (receive_new_aw ? aw_entry_index_bin : current_entry);

// should keep addr_offset and len to calu the wdata write addr
always@(posedge clk or negedge rstn)
    if(~rstn)begin
        addr_offset <= {ENTRY_BOUNDARY-6{1'd0}}   ;
        burst       <= 1'd0                       ;
    end else if(receive_new_aw)begin
        addr_offset <= awaddr_s[ENTRY_BOUNDARY-1:6] ;
        burst       <= awlen_s                      ;
    end

assign current_addr_offset  = receive_new_aw ? awaddr_s[ENTRY_BOUNDARY-1:6] : addr_offset;
assign burst_flag           = receive_new_aw ? awlen_s                      :  burst;
assign offset_addr          = burst_flag     ? (wlast_s ? (current_addr_offset + 1'd1) : current_addr_offset) : current_addr_offset;

// when the w channel handshake success will write the wdata into the data_buffer
assign wdata_write_en   = wvalid_s & wready_s;
assign wdata_write_data = wdata_s;
assign wdata_write_addr = {current_window, offset_addr}; 

//------------------------------------------------------------------------//
//                       WDATA FIFO READ ADDR & EN                        //
//------------------------------------------------------------------------//
// flush_window_exit_idle: prefetch wdata if now has not any window wait to flush but has window is ready to flush
// flush_mask_current: means req_mask has bit is not-zero -> has wdata should send to slave, we need read wdata to send it
assign flush_window_exit_idle = (next_state == SEND_SUB_CMD) & (current_state == IDLE);
//assign wdata_read_en          = first_sub_cmd_enable | ((|flush_mask_current) & flush_order_pop_valid);
assign wdata_read_en          = (next_state == SEND_SUB_CMD) | (next_state == ONLY_SEND_W);

// the first wdata mask is the even sub_aw_req first addr alloc
// when the flush window will exit from idle: the req_mask and addr will obtain from order_push_data's window
// when the flush window will send over     : the req_mask and addr will obtain from order_second_data 's window or push data without almost_empty else will obtain req_mask from push_data when almost_empty and push_valid
// when the flush window sub req send over  : the req_mask and addr will obtain from the flush_mask_update_next
assign first_sub_cmd_enable = flush_window_exit_idle | comb_flush_done & has_window_need_flush | sub_flush_done_flag;

always@(posedge clk or negedge rstn)
    if(~rstn)
        first_sub_cmd_keep <= 1'd0;
    else if(first_sub_cmd_enable)
        first_sub_cmd_keep <= 1'd1;
    else if(~comb_id_block)
        first_sub_cmd_keep <= 1'd0;

always@(*)begin
    first_wdata_mask = flush_mask_update_next;
    first_wdata_addr = flush_wdata_addr;
    //first_wdata_mask = {  REQ_WIDTH{1'd0}};
    //first_wdata_addr = {WDATA_ADDRW{1'd0}};
    if(comb_flush_done & has_window_need_flush)begin
        first_wdata_mask = entry_comb_mask      [ flush_order_second_data   ] ;
        first_wdata_addr =                        flush_order_second_data     ;
    end
    else if(flush_window_exit_idle)begin
        first_wdata_mask = entry_comb_mask      [ flush_order_pop_data   ] ;
        first_wdata_addr =                        flush_order_pop_data     ;
    end
    //else if(sub_flush_done_flag)begin
    //    first_wdata_mask = flush_mask_update_next;
    //    first_wdata_addr = flush_wdata_addr;
    //end
end

// we need to find the lowest index is high bit
assign first_wdata_mask_post = first_wdata_mask & ~(first_wdata_mask - 1'd1);

//when need read first wdata, the wdata_read_addr should turn to the first_sub_wdata_addr
//else if send_w_success the addr need plus one else will keep it
assign first_sub_wdata_addr = {first_wdata_addr, first_wdata_mask_bin};
always@(posedge clk or negedge rstn)
    if(~rstn)
        wdata_read_addr_reg <= {WDATA_BUFFER_ADDRW{1'd0}};  //todo
    else
        wdata_read_addr_reg <= wdata_read_addr;

assign wdata_read_addr =  first_sub_cmd_enable ? first_sub_wdata_addr : (send_w_success ? (wdata_read_addr_reg + 1'd1) : wdata_read_addr_reg ) ;

  /*comb_process_dp2clk_D64W512_wrapper auto_template "\(.*\)" (
  .Clk           (clk),
  .RdEn          (wdata_read_en),
  .RdAddr        (wdata_read_addr),
  .RdData        (wdata_read_data[]),
  .WrEn          (wdata_write_en),
  .WrAddr        (wdata_write_addr),
  .WrData        (wdata_write_data[]),
);
*/
  comb_process_dp2clk_D64W512_wrapper comb_process_mem_wrapper
  (/*autoinst*/
   // Outputs
   .RdData                              (wdata_read_data[511:0]), // Templated
   // Inputs
   .Clk                                 (clk),                   // Templated
   .RdAddr                              (wdata_read_addr),       // Templated
   .RdEn                                (wdata_read_en),         // Templated
   .WrAddr                              (wdata_write_addr),      // Templated
   .WrData                              (wdata_write_data[511:0]), // Templated
   .WrEn                                (wdata_write_en));       // Templated


//------------------------------------------------------------------------//
//                         ID MAP INFO                                    //
//------------------------------------------------------------------------//
wire [IDW-1:0] current_wdata_origin_id;
wire [REQ_WIDTH-1:0] current_wdata_req_mask;

assign current_wdata_req_mask = {{REQ_WIDTH-1{1'd0}}, 1'd1} << wdata_read_addr_reg[REQ_DEPTH-1:0];
generate 
    if(REQ_WIDTH == 8)begin:find_origin_id_512B_in_send_wdata
        assign current_wdata_origin_id = (flush_origin_id[IDW*8-1:IDW*7] & {IDW{current_wdata_req_mask[7]}}) | (flush_origin_id[IDW*7-1:IDW*6] & {IDW{current_wdata_req_mask[6]}}) | 
                                         (flush_origin_id[IDW*6-1:IDW*5] & {IDW{current_wdata_req_mask[5]}}) | (flush_origin_id[IDW*5-1:IDW*4] & {IDW{current_wdata_req_mask[4]}}) | 
                                         (flush_origin_id[IDW*4-1:IDW*3] & {IDW{current_wdata_req_mask[3]}}) | (flush_origin_id[IDW*3-1:IDW*2] & {IDW{current_wdata_req_mask[2]}}) | 
                                         (flush_origin_id[IDW*2-1:IDW  ] & {IDW{current_wdata_req_mask[1]}}) | (flush_origin_id[IDW-1  :    0] & {IDW{current_wdata_req_mask[0]}}) ;

    end else begin:find_origin_id_256B_in_send_wdata
        assign current_wdata_origin_id = (flush_origin_id[IDW*4-1:IDW*3] & {IDW{current_wdata_req_mask[3]}}) | (flush_origin_id[IDW*3-1:IDW*2] & {IDW{current_wdata_req_mask[2]}}) | 
                                         (flush_origin_id[IDW*2-1:IDW  ] & {IDW{current_wdata_req_mask[1]}}) | (flush_origin_id[IDW-1  :    0] & {IDW{current_wdata_req_mask[0]}}) ;
    end
endgenerate


always@(posedge clk or negedge rstn)
if(~rstn)
    comb_valid <= {OT{1'd0}};
else begin
    if(send_w_success) // if received a new aw req, will turn valid it
        comb_valid[current_wdata_origin_id[8:0]] <= 1'd1;

    if(send_b_success & (~bid_s[9])) // if has returnbresp to upstream, will deassert it
        comb_valid[bid_s[8:0]] <= 1'd0;
end

// if has receive a first comb req, we will update the awid_s to the awreq
// else if has entry, will keep comb id to awreq
always@(posedge clk or negedge rstn)
if(~rstn)begin
    comb_id_map <= '{OT{ {IDW{1'd0}} }}; 
end else if(send_w_success)
    comb_id_map[current_wdata_origin_id[8:0]] <= awid_m;
//------------------------------------------------------------------------//
//                         RESP RETURN CONTROL                            //
//------------------------------------------------------------------------//
assign send_b_success       = bready_s & bvalid_s;
assign receive_salve_resp   = bvalid_m & bready_m;

always@(posedge clk or negedge rstn)
    if(~rstn)begin
        reg_bid      <= {IDW{1'd0}}   ;
        reg_bid_keep <= {IDW{1'd0}}   ;
        reg_bresp    <= 2'h0          ;
    end else if(receive_salve_resp)begin
        reg_bid      <= bresp_has_entry ? {1'd0, origin_id_first} : bid_m ;
        reg_bid_keep <= bid_m         ;
        reg_bresp    <= bresp_m       ;
    end else if(has_comb_resp & send_b_success)
        reg_bid      <= {1'd0, origin_id};

//if has receive resp from slave, will find origin id
always@(*)begin
    bresp_has_entry = 1'd0;
    origin_id_first = {IDW-1{1'd0}};
    if(receive_salve_resp & (~bid_m[9]))begin
        for(o=OT-1; o>=0; o=o-1)begin 
            if((comb_id_map[o] == bid_m) & comb_valid[o])begin
                bresp_has_entry = 1'd1;
                origin_id_first = o;
            end
        end
    end
end    
//if has receive resp from slave, will find origin id
always@(*)begin
    has_entry_bids  = 1'h0;
    origin_id       = {IDW-1{1'd0}};
    if(has_comb_resp)begin // once the bid_m has find valid entry, will assert has_comb_resp to find all comb_req origin awid t return
        for(p=OT-1; p>=0; p=p-1)begin 
            if((comb_id_map[p] == reg_bid_keep) & comb_valid[p])begin
                has_entry_bids  = 1'h1;
            end
            if((comb_id_map[p] == reg_bid_keep) & comb_valid[p] & (p != bid_s[8:0]))begin
                origin_id       = p;
            end
        end
    end
end

// when receive a new req and has find valid entry, will assert the has_comb_resp flag
// when the has_comb_resp flag is high, but not find any valid entry, means that the comb resp has turn done, will deassert it
always@(posedge clk or negedge rstn)
    if(~rstn)
        has_comb_resp <= 1'd0;
    else if(receive_salve_resp & bresp_has_entry & (~bid_m[9]))
        has_comb_resp <= 1'd1;
    else if(has_comb_resp & (~has_entry_bids))
        has_comb_resp <= 1'd0;

// if the b is returning comb resp, the bid will assert origin_id, other signal will assert the register b channel register else will assert master interface signale    
//assign bid_s   = bid_update ? {1'd0, origin_id} : reg_bid   ;
assign bid_s   =  reg_bid  ;
assign bresp_s = reg_bresp ;

// the bvliad_s is high due to the master interface has new bresp or is returning comb resp
reg reg_valid;
always@(posedge clk or negedge rstn)
if(~rstn)
    reg_valid <= 1'd0;
else if(receive_salve_resp) 
    reg_valid <= 1'd1;
else if(send_b_success)
    reg_valid <= 1'd0;

// if the resp has_comb flag is high, we assert the bvalid just consid the has_entry_bids
// else is origin resp, we just need direct send over
assign bvalid_s = has_comb_resp ? has_entry_bids : reg_valid;

// the bready_s is assert due to the slave interface was ready and has not any comb resp need reeturn
wire block_from_comb_resp;

assign block_from_comb_resp = has_comb_resp & has_entry_bids;
assign bready_m = (bready_s | ~bvalid_s) & ~block_from_comb_resp;

//------------------------------------------------------------------------//
//                                 PERFORMANCE                            //
//------------------------------------------------------------------------//
// send pack req cnt, trig due to tmo 
//------------------TMO---------------------//
wire trig_flush_tmo_cnt_full;
assign trig_flush_tmo_cnt_full = &reg_aw_trig_flush_tmo_cnt;

always@(posedge clk or negedge rstn)
if(~rstn)
    reg_aw_trig_flush_tmo_cnt[15:0] <= 16'd0;
else if(reg_cnt_clear_en)
    reg_aw_trig_flush_tmo_cnt[15:0] <= 16'd0;
else if(time_out_flag & (~trig_flush_tmo_cnt_full) & (~status_change))
    reg_aw_trig_flush_tmo_cnt[15:0] <= reg_aw_trig_flush_tmo_cnt[15:0] + 1'd1;


always@(posedge clk or negedge rstn)
if(~rstn)
    reg_aw_trig_flush_tmo_cnt[31:16] <= 16'd0;
else if(reg_cnt_clear_en)
    reg_aw_trig_flush_tmo_cnt[31:16] <= 16'd0;
else if((&reg_aw_trig_flush_tmo_cnt[15:0]) & (~trig_flush_tmo_cnt_full) & time_out_flag & (~status_change))
    reg_aw_trig_flush_tmo_cnt[31:16] <= reg_aw_trig_flush_tmo_cnt[31:16] + 1'd1;


//------------------COMB_DONE---------------------//
// send pack req cnt, trig due to tmo 
wire trig_flush_comb_done_cnt_full;
assign trig_flush_comb_done_cnt_full = &reg_aw_trig_flush_comb_done_cnt;
wire comb_done_push_enable;
assign comb_done_push_enable = (~time_out_flag) & comb_done_flag & (~status_change) & (~comb_need_record);

always@(posedge clk or negedge rstn)
if(~rstn)
    reg_aw_trig_flush_comb_done_cnt[15:0] <= 16'd0;
else if(reg_cnt_clear_en)
    reg_aw_trig_flush_comb_done_cnt[15:0] <= 16'd0;
else if(comb_done_push_enable & (~trig_flush_comb_done_cnt_full))
    reg_aw_trig_flush_comb_done_cnt[15:0] <= reg_aw_trig_flush_comb_done_cnt[15:0] + 1'd1;


always@(posedge clk or negedge rstn)
if(~rstn)
    reg_aw_trig_flush_comb_done_cnt[31:16] <= 16'd0;
else if(reg_cnt_clear_en)
    reg_aw_trig_flush_comb_done_cnt[31:16] <= 16'd0;
else if((&reg_aw_trig_flush_comb_done_cnt[15:0]) & (~trig_flush_comb_done_cnt_full) & comb_done_push_enable)
    reg_aw_trig_flush_comb_done_cnt[31:16] <= reg_aw_trig_flush_comb_done_cnt[31:16] + 1'd1;

//------------------EVICT FULL---------------------//
// send pack req cnt, trig due to tmo 
wire trig_flush_full_cnt_full;
assign trig_flush_full_cnt_full = &reg_aw_trig_flush_full_cnt;

always@(posedge clk or negedge rstn)
if(~rstn)
    reg_aw_trig_flush_full_cnt[15:0] <= 16'd0;
else if(reg_cnt_clear_en)
    reg_aw_trig_flush_full_cnt[15:0] <= 16'd0;
else if(entry_full_need_evict & (~trig_flush_full_cnt_full))
    reg_aw_trig_flush_full_cnt[15:0] <= reg_aw_trig_flush_full_cnt[15:0] + 1'd1;


always@(posedge clk or negedge rstn)
if(~rstn)
    reg_aw_trig_flush_full_cnt[31:16] <= 16'd0;
else if(reg_cnt_clear_en)
    reg_aw_trig_flush_full_cnt[31:16] <= 16'd0;
else if((&reg_aw_trig_flush_full_cnt[15:0]) & (~trig_flush_full_cnt_full) & entry_full_need_evict)
    reg_aw_trig_flush_full_cnt[31:16] <= reg_aw_trig_flush_full_cnt[31:16] + 1'd1;

//------------------HARZARD---------------------//
// send pack req cnt, trig due to tmo 
// the if has harzard, the status_change can not be assert
wire flush_harzard_cnt_full;
assign flush_harzard_cnt_full = &reg_aw_normal_harzard_cnt;

always@(posedge clk or negedge rstn)
if(~rstn)
    reg_aw_normal_harzard_cnt[15:0] <= 16'd0;
else if(reg_cnt_clear_en)
    reg_aw_normal_harzard_cnt[15:0] <= 16'd0;
else if((~time_out_flag) & comb_need_record & (~flush_harzard_cnt_full))
    reg_aw_normal_harzard_cnt[15:0] <= reg_aw_normal_harzard_cnt[15:0] + 1'd1;


//------------------TOTAL---------------------//
// send pack req cnt, trig due to tmo 
wire flush_total_cnt_full;
assign flush_total_cnt_full = &reg_aw_trig_send_req_total_cnt;

always@(posedge clk or negedge rstn)
if(~rstn)
    reg_aw_trig_send_req_total_cnt[15:0] <= 16'd0;
else if(reg_cnt_clear_en)
    reg_aw_trig_send_req_total_cnt[15:0] <= 16'd0;
else if(flush_order_push_valid & (~flush_total_cnt_full))
    reg_aw_trig_send_req_total_cnt[15:0] <= reg_aw_trig_send_req_total_cnt[15:0] + 1'd1;


always@(posedge clk or negedge rstn)
if(~rstn)
    reg_aw_trig_send_req_total_cnt[31:16] <= 16'd0;
else if(reg_cnt_clear_en)
    reg_aw_trig_send_req_total_cnt[31:16] <= 16'd0;
else if((&reg_aw_trig_send_req_total_cnt[15:0]) & (~flush_total_cnt_full) & flush_order_push_valid)
    reg_aw_trig_send_req_total_cnt[31:16] <= reg_aw_trig_send_req_total_cnt[31:16] + 1'd1;
//------------------AVG_LEN---------------------//
assign tmo_cnt_enable      = send_aw_success & (entry_comb_cnt[flush_order_pop_data] == reg_comb_tmo_cnt_num);
assign all_cnt_enable      = send_aw_success ;
assign all_pkt_window_full = avg_window_time[21:10] == ({{10{1'd0}}, 1'd1} << reg_avg_time);
assign tmo_pkt_window_full = tmo_window_time[21:10] == ({{10{1'd0}}, 1'd1} << reg_avg_time);
// to grep the reg_avg_enable posedge
always@(posedge clk or negedge rstn)
if(!rstn)
    reg_avg_enable_reg <= 2'd0;
else 
    reg_avg_enable_reg <= {reg_avg_enable_reg[0], reg_avg_enable};

assign avg_enable_posedge = reg_avg_enable_reg[0] & (~reg_avg_enable_reg[1]);

//---------window cnt open enable flag register----------//
// if find the posedge will assert the all_pkt_window_cnt_enable
// once the avg_window_time has value we will deassert it
always@(posedge clk or negedge rstn)
if(!rstn)
    all_pkt_window_cnt_enable <= 1'd0;
else if(avg_enable_posedge)
    all_pkt_window_cnt_enable <= 1'd1;
else if(all_pkt_window_full)
    all_pkt_window_cnt_enable <= 1'd0;

always@(posedge clk or negedge rstn)
if(!rstn)
    tmo_pkt_window_cnt_enable <= 1'd0;
else if(avg_enable_posedge)
    tmo_pkt_window_cnt_enable <= 1'd1;
else if(tmo_pkt_window_full)
    tmo_pkt_window_cnt_enable <= 1'd0;

//---------window cnt register----------//
always@(posedge clk or negedge rstn)
if(!rstn)
    avg_window_time[21:0] <= 22'd0;
else if(avg_enable_posedge)
    avg_window_time[21:0] <= {21'd0, (~reg_avg_mode) | (reg_avg_mode & all_cnt_enable)} ;
else if(all_pkt_window_cnt_enable)begin
    if((~reg_avg_mode) | (reg_avg_mode & all_cnt_enable))
        avg_window_time[21:0] <= 1'd1 + avg_window_time[21:0];
end

//--------------tmo total window cnt----------------//
always@(posedge clk or negedge rstn)
if(!rstn)
    tmo_window_time[21:0] <= 22'd0;
else if(avg_enable_posedge)
    tmo_window_time[21:0] <= reg_avg_mode & tmo_cnt_enable ? 22'd1 : 22'd0;
else if(tmo_pkt_window_cnt_enable & reg_avg_mode & tmo_cnt_enable)
    tmo_window_time[21:0] <= 1'd1 + tmo_window_time[21:0];

//---------------total beat cnt---------//
always@(posedge clk or negedge rstn)
if(!rstn)begin
    total_beat_cnt <= 26'd0;
    total_req_cnt  <= 22'd0;
end
else if(avg_enable_posedge)begin
    total_beat_cnt <= all_cnt_enable  ? {22'd0 ,awlen_m + 1'd1} : 26'd0;
    total_req_cnt  <= {21'd0, all_cnt_enable};
end
else if(all_pkt_window_cnt_enable)begin
    total_beat_cnt <= total_beat_cnt_next;
    total_req_cnt  <= total_req_cnt_next;
end

assign total_beat_cnt_next = all_cnt_enable ? total_beat_cnt + {22'd0, awlen_m} + 1'd1 : total_beat_cnt; 
assign total_req_cnt_next  = all_cnt_enable ? total_req_cnt                     + 1'd1 : total_req_cnt ; 


assign req_aw_total_avg_payload_len_cnt = all_pkt_window_full ? { 6'd0, total_beat_cnt} : 32'd0 ;
assign req_aw_total_avg_payload_cnt     = all_pkt_window_full ? {10'd0, total_req_cnt } : 32'd0 ;

//---------------tmo beat cnt---------//
wire tmo_avg_beat_cnt_en = (tmo_pkt_window_cnt_enable & reg_avg_mode) |  ((~reg_avg_mode) & all_pkt_window_cnt_enable);
wire tmo_window_full     = (tmo_pkt_window_full       & reg_avg_mode) |  ((~reg_avg_mode) & all_pkt_window_full);

always@(posedge clk or negedge rstn)
if(!rstn)begin
    tmo_beat_cnt <= 26'd0;
    tmo_req_cnt  <= 22'd0;
end else if(avg_enable_posedge)begin
    tmo_beat_cnt <= tmo_cnt_enable ? {22'd0, awlen_m} + 1'd1 : 26'd0;
    tmo_req_cnt  <= {21'd0, tmo_cnt_enable};
end else if(tmo_avg_beat_cnt_en)begin
    tmo_beat_cnt <= tmo_beat_cnt_next;
    tmo_req_cnt  <= tmo_req_cnt_next;
end

assign tmo_beat_cnt_next = tmo_cnt_enable ? tmo_beat_cnt + {22'd0, awlen_m} + 1'd1 : tmo_beat_cnt; 
assign tmo_req_cnt_next  = tmo_cnt_enable ? tmo_req_cnt                     + 1'd1 : tmo_req_cnt ; 

assign req_aw_tmo_avg_payload_len_cnt = tmo_window_full ? { 6'd0, tmo_beat_cnt} : 32'd0 ;
assign req_aw_tmo_avg_payload_cnt     = tmo_window_full ? {10'd0, tmo_req_cnt } : 32'd0 ;

endmodule
// Local Variables:
// verilog-library-directories:("-y ./ -y ../")
// verilog-auto-inst-param-value:t
// End:
