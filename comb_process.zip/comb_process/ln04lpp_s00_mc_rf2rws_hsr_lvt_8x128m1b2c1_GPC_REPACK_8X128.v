/*====================================================================================================*/
/*  MemoryCompiler Version : FB-V2.23                                                                 */
/*  Date of Generation     : Tue Dec  9 14:14:04 2025                                                 */
/*  User Name              : chenm                                                                    */
/*====================================================================================================*/
/*                                                                                     copyright 2024.*/
/*                                                                           SAMSUNG Electronics corp.*/
/*                                                                                all rights reserved.*/
/*  LIBRARY              : LN04LPP                                                                    */
/*  CONFIGURATION        : Depth=8, Bits=128, Ymux=1                                                  */
/*  INSTANCE NAME        : ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128                 */
/*  VIEW VERSION         : 1.0.0                                                                      */
/*====================================================================================================*/
/* The confidential and proprietary information contained in this file may only be used by a person   */
/* authorised under and to the extent permitted by a subsisting licensing agreement from Samsung      */
/* Electronics.                                                                                       */

/* This entire notice must be reproduced on all copies of this file and copies of this file may only  */
/* be made by a person if such person is permitted to do so under the terms of a subsisting license   */
/* agreement from Samsung Electronics.                                                                */

/* Modification of this file is not permitted for any one and any case. Samsung Electronics has no    */
/* responsibility for any problem caused by unpermitted modification of this file.                    */
/*====================================================================================================*/
`ifndef REG_MEM
`timescale 1ns / 1ps

`define SEC_LPV_STARTTIME 0.0
`define DELAY_FOR_STOP 0.0
`define D_MEM_DELAY 0.0
`define D_MEM_SETUP 0.0
`define D_MEM_HOLD 0.0
`define D_MEM_WIDTH_H 0.0
`define D_MEM_WIDTH_L 0.0
`define D_MEM_WIDTH_THD 0.0
`define D_MEM_PERIOD 0.0
`define D_MEM_RECOVERY 0.0
`define D_MEM_REMOVAL 0.0

module datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 (CK,DOUT_update,SEB,SIB,DI,DFTRAM,mem_path,XDOUT,DOUT,BWEN);
	input CK,DOUT_update,SEB,SIB,DI,DFTRAM,mem_path,XDOUT,BWEN;
	output DOUT;

	reg    DI_int;
	reg    DOUT;

//  Model PHI2 portion
	always @(CK or SEB or SIB or DI or BWEN) begin
		if (CK === 1'b0) begin
			if (SEB===1'b1)
				DI_int=SIB; // shift data
			else if (SEB===1'bx)
				DI_int=1'bx;
			else
				DI_int= DI | BWEN; // capture data
		end
	end
// model output side of RAM latch
	always @(posedge DOUT_update  or posedge XDOUT or mem_path) begin
		if (XDOUT===1'b0) begin
			if (DFTRAM===1'b1) begin
				DOUT<=DI_int; // scan mode
			end
			else
				DOUT<=mem_path;// mission mode
		end
		else
			DOUT<=1'bx;
	end

endmodule

`celldefine

`ifdef POWER_PINS
	module ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128  ( RA, WA, DI, RCK, WCK, REN, WEN, BWEN, SI_D_L, SI_D_R, SO_D_L, SO_D_R, SE, DFTRAM,  MCSRD, KCS, MCSWR, ADME, CRE1, CRE2, FCA1, FCA2, DOUT, VDDE, VSSE);
`else
	module ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128  ( RA, WA, DI, RCK, WCK, REN, WEN, BWEN, SI_D_L, SI_D_R, SO_D_L, SO_D_R, SE, DFTRAM,  MCSRD, KCS, MCSWR, ADME, CRE1, CRE2, FCA1, FCA2, DOUT);
`endif

// Parameter definition
		parameter word_depth  = 8;
		parameter WORDS  = 8;
		parameter word_width  = 128;
		parameter addr_width  = 3;
		parameter ADDR_WIDTH = 3;
		parameter faddr1_width = 5;
		parameter faddr2_width = 5;
		parameter faddr_width = 5;
		parameter mcsa_width = 2;
		parameter mcsb_width = 2;
		parameter adme_width = 3;
		parameter NB_left = 64;
		parameter NB_right = 64;
		parameter valid_fca_left = 32;
		parameter valid_fca_right = 32;
		parameter valid_fca_c0 = 64;
		parameter r_bit    = 2;//spare column
		parameter row_no   = 4;//spare rows
		parameter mux  = 1;
		parameter TRUE   = 1'b1;
		parameter FALSE  = 1'b0;
		parameter
		word1            = {word_width{1'b1}},
		word0            = {word_width{1'b0}},
		wordx            = {word_width{1'bx}},
		wordz            = {word_width{1'bz}},
		rowx             = {word_width*mux+r_bit*2{1'bx}},
		addrx            = {addr_width{1'bx}};

		parameter MEM_WIDTH = 132;
		parameter MEM_HEIGHT = 8;


// Primary port definition
		`ifdef POWER_PINS
			inout             VDDE;
			inout             VSSE;
			
		`endif

		input  [addr_width-1:0]   RA;
		input  [addr_width-1:0]   WA;
		input  [word_width-1:0]   DI;
		input                       RCK;
		input                       WCK;
		input                       REN;
		input                       WEN;
		input  [word_width-1:0]   BWEN;
		input                       DFTRAM;

		input                       SE;
		input                    SI_D_L;
		input                    SI_D_R;
		output                   SO_D_L;
		output                    SO_D_R;

		input  [mcsa_width-1:0]   MCSRD;
		input                       KCS;
		input  [mcsb_width-1:0]   MCSWR;
		input  [adme_width-1:0]   ADME;
		input                       CRE1;
		input                       CRE2;
		input  [faddr1_width-1:0]   FCA1;
		input  [faddr2_width-1:0]   FCA2;
		output  [word_width-1:0]     DOUT;

		integer i,j,h,k;

// Memory definition
		reg    [(word_width*mux)-1+r_bit*2:0] mem[0:(word_depth/mux)-1];
		reg    [(word_width*mux)-1+r_bit*2:0] mem1[0:3];
		reg    [(word_width*mux)-1+r_bit*2:0] mem2[0:3];
		reg    [(word_width*mux)-1+r_bit*2:0] col;
		reg    [(word_width*mux)-1+r_bit:0] col_c0;
		reg    [(word_width*mux)-1:0] col_norm;
		reg    [63+r_bit:0] colL;
		reg    [63:0] colLL;
		reg    [63:0] new_data_L;
		reg    [63:0] remained_data_L;
		reg    [127:0] new_data;
		reg    [127:0] remained_data;
		reg    [word_width-1:0] outreg_tmp,outreg,outreg_backdoor;
		reg    retention_mode;
		reg    Power_Gating_mode;
		reg    valid_op;
		reg    XDOUT,DOUT_update;
		reg    same_edge;
		reg    write_operation;
		reg    row_redu_valid;
		reg    [63+r_bit:0] colR;
		reg    [63:0] colRR;
		reg    [63:0] new_data_R;
		reg    [63:0] remained_data_R;
		wire [addr_width - 1:0] AA_ ;
		wire [addr_width - 1:0] AB_ ;
		wire [word_width - 1:0] DIB_ ;
		wire CKA_ ;
		wire CKB_ ;
		wire CSNA_ ;
		wire CSNB_ ;
		wire [word_width - 1:0] BWENB_ ;
		wire DFTRAMW_ ;
		wire DFTRAMRN_ ;
		wire [mcsa_width - 1:0] MCSA_ ;
		wire KCS_ ;
		wire [mcsb_width - 1:0] MCSB_ ;
		wire [adme_width - 1:0] ADME_ ;
		wire  SI_D_L_;
		wire  SI_D_R_;
		wire  SO_D_L_;
		wire  SO_D_R_;
		wire SEW_;
		wire SER_;
		wire CRE1_ ;
		wire CRE2_ ;
		wire [faddr1_width - 1:0] FCA1_ ;
		wire [faddr2_width - 1:0] FCA2_ ;
		wire RETN_temp ;
		wire [word_width - 1:0] DOUTA_ ;
		wire [word_width - 1:0] DOUTA_err_inj ;
		wire [word_width - 1:0] DOUTA_data_path ;
		wire [0:13]ctrl_scan;

// Internal register declaration
		reg               LAST_CKA;
		reg               last_WCKA0;
//For CLKB
		reg               LAST_CKB;
		reg               last_WCKB0;

		wire [1:0] AB_valid;
		wire [1:0] AA_valid;
		wire [1:0] AB_redu_valid;
		wire [1:0] AA_redu_valid;

		wire [word_width-1:0] D_int_bmux;
		wire [word_width-1:0] DOUT_int;
		reg  [word_width-1:0] BWEN_int;
		reg  [word_width-1:0] D_int;
		reg  [addr_width-1:0] AA_int,AA_B_int,AB_A_int;
		reg  [1 :0]           AA_redu_int;
		reg  [addr_width-1:0] AB_int;
		reg  [1 :0]           AB_redu_int;

		real             CKA_real;
		real             CKB_real;
		reg             CSNA_int;
		reg             CSNB_int;
		reg 		   DFTRAM_B_int,SE_int,SI_D_L_int,SI_D_R_int,SI_D_int;
		reg             DFTRAM_A_int;
		reg             RETN_int,PDE_int;
		wire             RETN_,PDE_;
		reg             VDDPE_int;
		reg             CRE1_int, CRE2_int,CRE_int,CRE_A_int,CRE_B_int,CRE1_A_int,CRE1_B_int,CRE2_A_int,CRE2_B_int;
		reg             RRE1A_int, RRE2A_int;
		reg             RRE1B_int, RRE2B_int;
		reg        [1:0] MCSRD_int,MCSRD_A_int,MCSRD_B_int;
		reg        [1:0] MCSWR_int,MCSWR_A_int,MCSWR_B_int;
		reg        [2:0] ADME_int,ADME_A_int,ADME_B_int;
		reg 		    KCS_int,KCS_A_int,KCS_B_int;

		reg  [faddr1_width-1:0] FCA1_int,FCA1A_int,FCA1A_prev,FCA1_A_int,FCA1_B_int;
		reg  [faddr2_width-1:0] FCA2_int,FCA2A_int,FCA2_A_int,FCA2_B_int;
		reg  [faddr_width-1:0] FCA_int,FCA_prev,FCA2A_prev,FCA_A_int,FCA_B_int;

		reg PDE_prev,RETN_prev,DFTRAM_prev;
		parameter TCSEP = 0.001;
//assign BWEN_int = word0;
		reg DFTRAM_oldB;
		reg DFTRAM_oldA;

// If INITIALIZE_MEMORY_0 is defined at Simulator Command Line, it Initializes the Memory with all ZEROS.
// If INITIALIZE_MEMORY_1 is defined at Simulator Command Line, it Initializes the Memory with all ONES.

//For Display Message

		`ifdef DISPLAY_CHECK_OFF
			parameter DISPLAY_CNTRL = 1;
		`else
			parameter DISPLAY_CNTRL = 0;
		`endif

		`ifdef BACKDOOR_DISPLAY_CHECK_OFF
			parameter BACKDOOR_DISPLAY_CNTRL = 1;
		`else
			parameter BACKDOOR_DISPLAY_CNTRL = 0;
		`endif

		`ifdef INITIALIZE_MEMORY_0
//integer i;
			initial
				for (i = 0; i < MEM_HEIGHT; i = i + 1)
					mem[i] = {MEM_WIDTH{1'b0}};
		`endif
		`ifdef INITIALIZE_MEMORY_1
//integer i;
			initial
				for (i = 0; i < MEM_HEIGHT; i = i + 1)
					mem[i] = {MEM_WIDTH{1'b1}};
		`endif

// If INITIALIZE_MEMORY_0 is defined at Simulator Command Line, it Initializes the Redundancy Memory with all ZEROS.
// If INITIALIZE_MEMORY_1 is defined at Simulator Command Line, it Initializes the Redundancy Memory with all ONES.

		`ifdef INITIALIZE_REDU1_MEMORY_0
//integer i;
			initial
				for (i = 0; i < 4; i = i + 1)
					mem1[i] = {MEM_WIDTH{1'b0}};
		`endif

		`ifdef INITIALIZE_REDU2_MEMORY_0
//integer i;
			initial
				for (i = 0; i < 4; i = i + 1)
					mem2[i] = {MEM_WIDTH{1'b0}};
		`endif
		`ifdef INITIALIZE_REDU1_MEMORY_1
//integer i;
			initial
				for (i = 0; i < 4; i = i + 1)
					mem1[i] = {MEM_WIDTH{1'b1}};
		`endif

		`ifdef INITIALIZE_REDU2_MEMORY_1
//integer i;
			initial
				for (i = 0; i < 4; i = i + 1)
					mem2[i] = {MEM_WIDTH{1'b1}};
		`endif

		initial begin
			same_edge = 1'b0;
			row_redu_valid = 1'b1;
		end
// ------------------------------------------------------
// MIPD definition
// ------------------------------------------------------

		wire              vddpe_int;
		wire              vddce_int;
		wire              vsse_int;

		`ifdef POWER_PINS
			assign vddce_int =  VDDE;
			assign vddpe_int =  VDDE;
			assign vsse_int =  VSSE;
		`else
			assign vddce_int =  1'b1;
			assign vddpe_int =  1'b1;
			assign vsse_int =  1'b0;
		`endif

		buf (AA_[0],RA[0]);
		buf (AA_[1],RA[1]);
		buf (AA_[2],RA[2]);
		buf (AB_[0],WA[0]);
		buf (AB_[1],WA[1]);
		buf (AB_[2],WA[2]);
		buf (DIB_[0],DI[0]);
		buf (DIB_[1],DI[1]);
		buf (DIB_[2],DI[2]);
		buf (DIB_[3],DI[3]);
		buf (DIB_[4],DI[4]);
		buf (DIB_[5],DI[5]);
		buf (DIB_[6],DI[6]);
		buf (DIB_[7],DI[7]);
		buf (DIB_[8],DI[8]);
		buf (DIB_[9],DI[9]);
		buf (DIB_[10],DI[10]);
		buf (DIB_[11],DI[11]);
		buf (DIB_[12],DI[12]);
		buf (DIB_[13],DI[13]);
		buf (DIB_[14],DI[14]);
		buf (DIB_[15],DI[15]);
		buf (DIB_[16],DI[16]);
		buf (DIB_[17],DI[17]);
		buf (DIB_[18],DI[18]);
		buf (DIB_[19],DI[19]);
		buf (DIB_[20],DI[20]);
		buf (DIB_[21],DI[21]);
		buf (DIB_[22],DI[22]);
		buf (DIB_[23],DI[23]);
		buf (DIB_[24],DI[24]);
		buf (DIB_[25],DI[25]);
		buf (DIB_[26],DI[26]);
		buf (DIB_[27],DI[27]);
		buf (DIB_[28],DI[28]);
		buf (DIB_[29],DI[29]);
		buf (DIB_[30],DI[30]);
		buf (DIB_[31],DI[31]);
		buf (DIB_[32],DI[32]);
		buf (DIB_[33],DI[33]);
		buf (DIB_[34],DI[34]);
		buf (DIB_[35],DI[35]);
		buf (DIB_[36],DI[36]);
		buf (DIB_[37],DI[37]);
		buf (DIB_[38],DI[38]);
		buf (DIB_[39],DI[39]);
		buf (DIB_[40],DI[40]);
		buf (DIB_[41],DI[41]);
		buf (DIB_[42],DI[42]);
		buf (DIB_[43],DI[43]);
		buf (DIB_[44],DI[44]);
		buf (DIB_[45],DI[45]);
		buf (DIB_[46],DI[46]);
		buf (DIB_[47],DI[47]);
		buf (DIB_[48],DI[48]);
		buf (DIB_[49],DI[49]);
		buf (DIB_[50],DI[50]);
		buf (DIB_[51],DI[51]);
		buf (DIB_[52],DI[52]);
		buf (DIB_[53],DI[53]);
		buf (DIB_[54],DI[54]);
		buf (DIB_[55],DI[55]);
		buf (DIB_[56],DI[56]);
		buf (DIB_[57],DI[57]);
		buf (DIB_[58],DI[58]);
		buf (DIB_[59],DI[59]);
		buf (DIB_[60],DI[60]);
		buf (DIB_[61],DI[61]);
		buf (DIB_[62],DI[62]);
		buf (DIB_[63],DI[63]);
		buf (DIB_[64],DI[64]);
		buf (DIB_[65],DI[65]);
		buf (DIB_[66],DI[66]);
		buf (DIB_[67],DI[67]);
		buf (DIB_[68],DI[68]);
		buf (DIB_[69],DI[69]);
		buf (DIB_[70],DI[70]);
		buf (DIB_[71],DI[71]);
		buf (DIB_[72],DI[72]);
		buf (DIB_[73],DI[73]);
		buf (DIB_[74],DI[74]);
		buf (DIB_[75],DI[75]);
		buf (DIB_[76],DI[76]);
		buf (DIB_[77],DI[77]);
		buf (DIB_[78],DI[78]);
		buf (DIB_[79],DI[79]);
		buf (DIB_[80],DI[80]);
		buf (DIB_[81],DI[81]);
		buf (DIB_[82],DI[82]);
		buf (DIB_[83],DI[83]);
		buf (DIB_[84],DI[84]);
		buf (DIB_[85],DI[85]);
		buf (DIB_[86],DI[86]);
		buf (DIB_[87],DI[87]);
		buf (DIB_[88],DI[88]);
		buf (DIB_[89],DI[89]);
		buf (DIB_[90],DI[90]);
		buf (DIB_[91],DI[91]);
		buf (DIB_[92],DI[92]);
		buf (DIB_[93],DI[93]);
		buf (DIB_[94],DI[94]);
		buf (DIB_[95],DI[95]);
		buf (DIB_[96],DI[96]);
		buf (DIB_[97],DI[97]);
		buf (DIB_[98],DI[98]);
		buf (DIB_[99],DI[99]);
		buf (DIB_[100],DI[100]);
		buf (DIB_[101],DI[101]);
		buf (DIB_[102],DI[102]);
		buf (DIB_[103],DI[103]);
		buf (DIB_[104],DI[104]);
		buf (DIB_[105],DI[105]);
		buf (DIB_[106],DI[106]);
		buf (DIB_[107],DI[107]);
		buf (DIB_[108],DI[108]);
		buf (DIB_[109],DI[109]);
		buf (DIB_[110],DI[110]);
		buf (DIB_[111],DI[111]);
		buf (DIB_[112],DI[112]);
		buf (DIB_[113],DI[113]);
		buf (DIB_[114],DI[114]);
		buf (DIB_[115],DI[115]);
		buf (DIB_[116],DI[116]);
		buf (DIB_[117],DI[117]);
		buf (DIB_[118],DI[118]);
		buf (DIB_[119],DI[119]);
		buf (DIB_[120],DI[120]);
		buf (DIB_[121],DI[121]);
		buf (DIB_[122],DI[122]);
		buf (DIB_[123],DI[123]);
		buf (DIB_[124],DI[124]);
		buf (DIB_[125],DI[125]);
		buf (DIB_[126],DI[126]);
		buf (DIB_[127],DI[127]);
		buf
		(CKA_,RCK);
		buf
		(CKB_,WCK);
		buf
		(CSNA_,REN);
		buf
		(CSNB_,WEN);
		buf (BWENB_[0],BWEN[0]);
		buf (BWENB_[1],BWEN[1]);
		buf (BWENB_[2],BWEN[2]);
		buf (BWENB_[3],BWEN[3]);
		buf (BWENB_[4],BWEN[4]);
		buf (BWENB_[5],BWEN[5]);
		buf (BWENB_[6],BWEN[6]);
		buf (BWENB_[7],BWEN[7]);
		buf (BWENB_[8],BWEN[8]);
		buf (BWENB_[9],BWEN[9]);
		buf (BWENB_[10],BWEN[10]);
		buf (BWENB_[11],BWEN[11]);
		buf (BWENB_[12],BWEN[12]);
		buf (BWENB_[13],BWEN[13]);
		buf (BWENB_[14],BWEN[14]);
		buf (BWENB_[15],BWEN[15]);
		buf (BWENB_[16],BWEN[16]);
		buf (BWENB_[17],BWEN[17]);
		buf (BWENB_[18],BWEN[18]);
		buf (BWENB_[19],BWEN[19]);
		buf (BWENB_[20],BWEN[20]);
		buf (BWENB_[21],BWEN[21]);
		buf (BWENB_[22],BWEN[22]);
		buf (BWENB_[23],BWEN[23]);
		buf (BWENB_[24],BWEN[24]);
		buf (BWENB_[25],BWEN[25]);
		buf (BWENB_[26],BWEN[26]);
		buf (BWENB_[27],BWEN[27]);
		buf (BWENB_[28],BWEN[28]);
		buf (BWENB_[29],BWEN[29]);
		buf (BWENB_[30],BWEN[30]);
		buf (BWENB_[31],BWEN[31]);
		buf (BWENB_[32],BWEN[32]);
		buf (BWENB_[33],BWEN[33]);
		buf (BWENB_[34],BWEN[34]);
		buf (BWENB_[35],BWEN[35]);
		buf (BWENB_[36],BWEN[36]);
		buf (BWENB_[37],BWEN[37]);
		buf (BWENB_[38],BWEN[38]);
		buf (BWENB_[39],BWEN[39]);
		buf (BWENB_[40],BWEN[40]);
		buf (BWENB_[41],BWEN[41]);
		buf (BWENB_[42],BWEN[42]);
		buf (BWENB_[43],BWEN[43]);
		buf (BWENB_[44],BWEN[44]);
		buf (BWENB_[45],BWEN[45]);
		buf (BWENB_[46],BWEN[46]);
		buf (BWENB_[47],BWEN[47]);
		buf (BWENB_[48],BWEN[48]);
		buf (BWENB_[49],BWEN[49]);
		buf (BWENB_[50],BWEN[50]);
		buf (BWENB_[51],BWEN[51]);
		buf (BWENB_[52],BWEN[52]);
		buf (BWENB_[53],BWEN[53]);
		buf (BWENB_[54],BWEN[54]);
		buf (BWENB_[55],BWEN[55]);
		buf (BWENB_[56],BWEN[56]);
		buf (BWENB_[57],BWEN[57]);
		buf (BWENB_[58],BWEN[58]);
		buf (BWENB_[59],BWEN[59]);
		buf (BWENB_[60],BWEN[60]);
		buf (BWENB_[61],BWEN[61]);
		buf (BWENB_[62],BWEN[62]);
		buf (BWENB_[63],BWEN[63]);
		buf (BWENB_[64],BWEN[64]);
		buf (BWENB_[65],BWEN[65]);
		buf (BWENB_[66],BWEN[66]);
		buf (BWENB_[67],BWEN[67]);
		buf (BWENB_[68],BWEN[68]);
		buf (BWENB_[69],BWEN[69]);
		buf (BWENB_[70],BWEN[70]);
		buf (BWENB_[71],BWEN[71]);
		buf (BWENB_[72],BWEN[72]);
		buf (BWENB_[73],BWEN[73]);
		buf (BWENB_[74],BWEN[74]);
		buf (BWENB_[75],BWEN[75]);
		buf (BWENB_[76],BWEN[76]);
		buf (BWENB_[77],BWEN[77]);
		buf (BWENB_[78],BWEN[78]);
		buf (BWENB_[79],BWEN[79]);
		buf (BWENB_[80],BWEN[80]);
		buf (BWENB_[81],BWEN[81]);
		buf (BWENB_[82],BWEN[82]);
		buf (BWENB_[83],BWEN[83]);
		buf (BWENB_[84],BWEN[84]);
		buf (BWENB_[85],BWEN[85]);
		buf (BWENB_[86],BWEN[86]);
		buf (BWENB_[87],BWEN[87]);
		buf (BWENB_[88],BWEN[88]);
		buf (BWENB_[89],BWEN[89]);
		buf (BWENB_[90],BWEN[90]);
		buf (BWENB_[91],BWEN[91]);
		buf (BWENB_[92],BWEN[92]);
		buf (BWENB_[93],BWEN[93]);
		buf (BWENB_[94],BWEN[94]);
		buf (BWENB_[95],BWEN[95]);
		buf (BWENB_[96],BWEN[96]);
		buf (BWENB_[97],BWEN[97]);
		buf (BWENB_[98],BWEN[98]);
		buf (BWENB_[99],BWEN[99]);
		buf (BWENB_[100],BWEN[100]);
		buf (BWENB_[101],BWEN[101]);
		buf (BWENB_[102],BWEN[102]);
		buf (BWENB_[103],BWEN[103]);
		buf (BWENB_[104],BWEN[104]);
		buf (BWENB_[105],BWEN[105]);
		buf (BWENB_[106],BWEN[106]);
		buf (BWENB_[107],BWEN[107]);
		buf (BWENB_[108],BWEN[108]);
		buf (BWENB_[109],BWEN[109]);
		buf (BWENB_[110],BWEN[110]);
		buf (BWENB_[111],BWEN[111]);
		buf (BWENB_[112],BWEN[112]);
		buf (BWENB_[113],BWEN[113]);
		buf (BWENB_[114],BWEN[114]);
		buf (BWENB_[115],BWEN[115]);
		buf (BWENB_[116],BWEN[116]);
		buf (BWENB_[117],BWEN[117]);
		buf (BWENB_[118],BWEN[118]);
		buf (BWENB_[119],BWEN[119]);
		buf (BWENB_[120],BWEN[120]);
		buf (BWENB_[121],BWEN[121]);
		buf (BWENB_[122],BWEN[122]);
		buf (BWENB_[123],BWEN[123]);
		buf (BWENB_[124],BWEN[124]);
		buf (BWENB_[125],BWEN[125]);
		buf (BWENB_[126],BWEN[126]);
		buf (BWENB_[127],BWEN[127]);
		buf (DFTRAMW_,DFTRAM);
		buf
		(MCSA_[0],MCSRD[0]),
		(MCSA_[1],MCSRD[1]);
		buf (SEW_,SE);

		buf (SI_D_R_,SI_D_R);
		buf (SI_D_L_,SI_D_L);
		buf (SO_D_L,SO_D_L_);
		buf (SO_D_R,SO_D_R_);
		buf
		(KCS_,KCS);
		buf
		(MCSB_[0],MCSWR[0]),
		(MCSB_[1],MCSWR[1]);
		buf (ADME_[0],ADME[0]);
		buf (ADME_[1],ADME[1]);
		buf (ADME_[2],ADME[2]);
		buf
		(CRE1_,CRE1);
		buf
		(CRE2_,CRE2);
		buf (FCA1_[0],FCA1[0]);
		buf (FCA1_[1],FCA1[1]);
		buf (FCA1_[2],FCA1[2]);
		buf (FCA1_[3],FCA1[3]);
		buf (FCA1_[4],FCA1[4]);
		buf (FCA2_[0],FCA2[0]);
		buf (FCA2_[1],FCA2[1]);
		buf (FCA2_[2],FCA2[2]);
		buf (FCA2_[3],FCA2[3]);
		buf (FCA2_[4],FCA2[4]);
		buf (DOUT[0],DOUTA_[0]);
		buf (DOUT[1],DOUTA_[1]);
		buf (DOUT[2],DOUTA_[2]);
		buf (DOUT[3],DOUTA_[3]);
		buf (DOUT[4],DOUTA_[4]);
		buf (DOUT[5],DOUTA_[5]);
		buf (DOUT[6],DOUTA_[6]);
		buf (DOUT[7],DOUTA_[7]);
		buf (DOUT[8],DOUTA_[8]);
		buf (DOUT[9],DOUTA_[9]);
		buf (DOUT[10],DOUTA_[10]);
		buf (DOUT[11],DOUTA_[11]);
		buf (DOUT[12],DOUTA_[12]);
		buf (DOUT[13],DOUTA_[13]);
		buf (DOUT[14],DOUTA_[14]);
		buf (DOUT[15],DOUTA_[15]);
		buf (DOUT[16],DOUTA_[16]);
		buf (DOUT[17],DOUTA_[17]);
		buf (DOUT[18],DOUTA_[18]);
		buf (DOUT[19],DOUTA_[19]);
		buf (DOUT[20],DOUTA_[20]);
		buf (DOUT[21],DOUTA_[21]);
		buf (DOUT[22],DOUTA_[22]);
		buf (DOUT[23],DOUTA_[23]);
		buf (DOUT[24],DOUTA_[24]);
		buf (DOUT[25],DOUTA_[25]);
		buf (DOUT[26],DOUTA_[26]);
		buf (DOUT[27],DOUTA_[27]);
		buf (DOUT[28],DOUTA_[28]);
		buf (DOUT[29],DOUTA_[29]);
		buf (DOUT[30],DOUTA_[30]);
		buf (DOUT[31],DOUTA_[31]);
		buf (DOUT[32],DOUTA_[32]);
		buf (DOUT[33],DOUTA_[33]);
		buf (DOUT[34],DOUTA_[34]);
		buf (DOUT[35],DOUTA_[35]);
		buf (DOUT[36],DOUTA_[36]);
		buf (DOUT[37],DOUTA_[37]);
		buf (DOUT[38],DOUTA_[38]);
		buf (DOUT[39],DOUTA_[39]);
		buf (DOUT[40],DOUTA_[40]);
		buf (DOUT[41],DOUTA_[41]);
		buf (DOUT[42],DOUTA_[42]);
		buf (DOUT[43],DOUTA_[43]);
		buf (DOUT[44],DOUTA_[44]);
		buf (DOUT[45],DOUTA_[45]);
		buf (DOUT[46],DOUTA_[46]);
		buf (DOUT[47],DOUTA_[47]);
		buf (DOUT[48],DOUTA_[48]);
		buf (DOUT[49],DOUTA_[49]);
		buf (DOUT[50],DOUTA_[50]);
		buf (DOUT[51],DOUTA_[51]);
		buf (DOUT[52],DOUTA_[52]);
		buf (DOUT[53],DOUTA_[53]);
		buf (DOUT[54],DOUTA_[54]);
		buf (DOUT[55],DOUTA_[55]);
		buf (DOUT[56],DOUTA_[56]);
		buf (DOUT[57],DOUTA_[57]);
		buf (DOUT[58],DOUTA_[58]);
		buf (DOUT[59],DOUTA_[59]);
		buf (DOUT[60],DOUTA_[60]);
		buf (DOUT[61],DOUTA_[61]);
		buf (DOUT[62],DOUTA_[62]);
		buf (DOUT[63],DOUTA_[63]);
		buf (DOUT[64],DOUTA_[64]);
		buf (DOUT[65],DOUTA_[65]);
		buf (DOUT[66],DOUTA_[66]);
		buf (DOUT[67],DOUTA_[67]);
		buf (DOUT[68],DOUTA_[68]);
		buf (DOUT[69],DOUTA_[69]);
		buf (DOUT[70],DOUTA_[70]);
		buf (DOUT[71],DOUTA_[71]);
		buf (DOUT[72],DOUTA_[72]);
		buf (DOUT[73],DOUTA_[73]);
		buf (DOUT[74],DOUTA_[74]);
		buf (DOUT[75],DOUTA_[75]);
		buf (DOUT[76],DOUTA_[76]);
		buf (DOUT[77],DOUTA_[77]);
		buf (DOUT[78],DOUTA_[78]);
		buf (DOUT[79],DOUTA_[79]);
		buf (DOUT[80],DOUTA_[80]);
		buf (DOUT[81],DOUTA_[81]);
		buf (DOUT[82],DOUTA_[82]);
		buf (DOUT[83],DOUTA_[83]);
		buf (DOUT[84],DOUTA_[84]);
		buf (DOUT[85],DOUTA_[85]);
		buf (DOUT[86],DOUTA_[86]);
		buf (DOUT[87],DOUTA_[87]);
		buf (DOUT[88],DOUTA_[88]);
		buf (DOUT[89],DOUTA_[89]);
		buf (DOUT[90],DOUTA_[90]);
		buf (DOUT[91],DOUTA_[91]);
		buf (DOUT[92],DOUTA_[92]);
		buf (DOUT[93],DOUTA_[93]);
		buf (DOUT[94],DOUTA_[94]);
		buf (DOUT[95],DOUTA_[95]);
		buf (DOUT[96],DOUTA_[96]);
		buf (DOUT[97],DOUTA_[97]);
		buf (DOUT[98],DOUTA_[98]);
		buf (DOUT[99],DOUTA_[99]);
		buf (DOUT[100],DOUTA_[100]);
		buf (DOUT[101],DOUTA_[101]);
		buf (DOUT[102],DOUTA_[102]);
		buf (DOUT[103],DOUTA_[103]);
		buf (DOUT[104],DOUTA_[104]);
		buf (DOUT[105],DOUTA_[105]);
		buf (DOUT[106],DOUTA_[106]);
		buf (DOUT[107],DOUTA_[107]);
		buf (DOUT[108],DOUTA_[108]);
		buf (DOUT[109],DOUTA_[109]);
		buf (DOUT[110],DOUTA_[110]);
		buf (DOUT[111],DOUTA_[111]);
		buf (DOUT[112],DOUTA_[112]);
		buf (DOUT[113],DOUTA_[113]);
		buf (DOUT[114],DOUTA_[114]);
		buf (DOUT[115],DOUTA_[115]);
		buf (DOUT[116],DOUTA_[116]);
		buf (DOUT[117],DOUTA_[117]);
		buf (DOUT[118],DOUTA_[118]);
		buf (DOUT[119],DOUTA_[119]);
		buf (DOUT[120],DOUTA_[120]);
		buf (DOUT[121],DOUTA_[121]);
		buf (DOUT[122],DOUTA_[122]);
		buf (DOUT[123],DOUTA_[123]);
		buf (DOUT[124],DOUTA_[124]);
		buf (DOUT[125],DOUTA_[125]);
		buf (DOUT[126],DOUTA_[126]);
		buf (DOUT[127],DOUTA_[127]);


		reg NOT_RCK_RA_0 ;
		reg NOT_RCK_RA_1 ;
		reg NOT_RCK_RA_2 ;
		reg NOT_WCK_WA_0 ;
		reg NOT_WCK_WA_1 ;
		reg NOT_WCK_WA_2 ;
		reg NOT_WCK_DI_0 ;
		reg NOT_WCK_DI_1 ;
		reg NOT_WCK_DI_2 ;
		reg NOT_WCK_DI_3 ;
		reg NOT_WCK_DI_4 ;
		reg NOT_WCK_DI_5 ;
		reg NOT_WCK_DI_6 ;
		reg NOT_WCK_DI_7 ;
		reg NOT_WCK_DI_8 ;
		reg NOT_WCK_DI_9 ;
		reg NOT_WCK_DI_10 ;
		reg NOT_WCK_DI_11 ;
		reg NOT_WCK_DI_12 ;
		reg NOT_WCK_DI_13 ;
		reg NOT_WCK_DI_14 ;
		reg NOT_WCK_DI_15 ;
		reg NOT_WCK_DI_16 ;
		reg NOT_WCK_DI_17 ;
		reg NOT_WCK_DI_18 ;
		reg NOT_WCK_DI_19 ;
		reg NOT_WCK_DI_20 ;
		reg NOT_WCK_DI_21 ;
		reg NOT_WCK_DI_22 ;
		reg NOT_WCK_DI_23 ;
		reg NOT_WCK_DI_24 ;
		reg NOT_WCK_DI_25 ;
		reg NOT_WCK_DI_26 ;
		reg NOT_WCK_DI_27 ;
		reg NOT_WCK_DI_28 ;
		reg NOT_WCK_DI_29 ;
		reg NOT_WCK_DI_30 ;
		reg NOT_WCK_DI_31 ;
		reg NOT_WCK_DI_32 ;
		reg NOT_WCK_DI_33 ;
		reg NOT_WCK_DI_34 ;
		reg NOT_WCK_DI_35 ;
		reg NOT_WCK_DI_36 ;
		reg NOT_WCK_DI_37 ;
		reg NOT_WCK_DI_38 ;
		reg NOT_WCK_DI_39 ;
		reg NOT_WCK_DI_40 ;
		reg NOT_WCK_DI_41 ;
		reg NOT_WCK_DI_42 ;
		reg NOT_WCK_DI_43 ;
		reg NOT_WCK_DI_44 ;
		reg NOT_WCK_DI_45 ;
		reg NOT_WCK_DI_46 ;
		reg NOT_WCK_DI_47 ;
		reg NOT_WCK_DI_48 ;
		reg NOT_WCK_DI_49 ;
		reg NOT_WCK_DI_50 ;
		reg NOT_WCK_DI_51 ;
		reg NOT_WCK_DI_52 ;
		reg NOT_WCK_DI_53 ;
		reg NOT_WCK_DI_54 ;
		reg NOT_WCK_DI_55 ;
		reg NOT_WCK_DI_56 ;
		reg NOT_WCK_DI_57 ;
		reg NOT_WCK_DI_58 ;
		reg NOT_WCK_DI_59 ;
		reg NOT_WCK_DI_60 ;
		reg NOT_WCK_DI_61 ;
		reg NOT_WCK_DI_62 ;
		reg NOT_WCK_DI_63 ;
		reg NOT_WCK_DI_64 ;
		reg NOT_WCK_DI_65 ;
		reg NOT_WCK_DI_66 ;
		reg NOT_WCK_DI_67 ;
		reg NOT_WCK_DI_68 ;
		reg NOT_WCK_DI_69 ;
		reg NOT_WCK_DI_70 ;
		reg NOT_WCK_DI_71 ;
		reg NOT_WCK_DI_72 ;
		reg NOT_WCK_DI_73 ;
		reg NOT_WCK_DI_74 ;
		reg NOT_WCK_DI_75 ;
		reg NOT_WCK_DI_76 ;
		reg NOT_WCK_DI_77 ;
		reg NOT_WCK_DI_78 ;
		reg NOT_WCK_DI_79 ;
		reg NOT_WCK_DI_80 ;
		reg NOT_WCK_DI_81 ;
		reg NOT_WCK_DI_82 ;
		reg NOT_WCK_DI_83 ;
		reg NOT_WCK_DI_84 ;
		reg NOT_WCK_DI_85 ;
		reg NOT_WCK_DI_86 ;
		reg NOT_WCK_DI_87 ;
		reg NOT_WCK_DI_88 ;
		reg NOT_WCK_DI_89 ;
		reg NOT_WCK_DI_90 ;
		reg NOT_WCK_DI_91 ;
		reg NOT_WCK_DI_92 ;
		reg NOT_WCK_DI_93 ;
		reg NOT_WCK_DI_94 ;
		reg NOT_WCK_DI_95 ;
		reg NOT_WCK_DI_96 ;
		reg NOT_WCK_DI_97 ;
		reg NOT_WCK_DI_98 ;
		reg NOT_WCK_DI_99 ;
		reg NOT_WCK_DI_100 ;
		reg NOT_WCK_DI_101 ;
		reg NOT_WCK_DI_102 ;
		reg NOT_WCK_DI_103 ;
		reg NOT_WCK_DI_104 ;
		reg NOT_WCK_DI_105 ;
		reg NOT_WCK_DI_106 ;
		reg NOT_WCK_DI_107 ;
		reg NOT_WCK_DI_108 ;
		reg NOT_WCK_DI_109 ;
		reg NOT_WCK_DI_110 ;
		reg NOT_WCK_DI_111 ;
		reg NOT_WCK_DI_112 ;
		reg NOT_WCK_DI_113 ;
		reg NOT_WCK_DI_114 ;
		reg NOT_WCK_DI_115 ;
		reg NOT_WCK_DI_116 ;
		reg NOT_WCK_DI_117 ;
		reg NOT_WCK_DI_118 ;
		reg NOT_WCK_DI_119 ;
		reg NOT_WCK_DI_120 ;
		reg NOT_WCK_DI_121 ;
		reg NOT_WCK_DI_122 ;
		reg NOT_WCK_DI_123 ;
		reg NOT_WCK_DI_124 ;
		reg NOT_WCK_DI_125 ;
		reg NOT_WCK_DI_126 ;
		reg NOT_WCK_DI_127 ;
		reg NOT_RCK_WCK ;
		reg NOT_RCK_MINL ;
		reg NOT_RCK_MINH ;
		reg NOT_RCK_PER ;
		reg NOT_WCK_RCK ;
		reg NOT_WCK_MINL ;
		reg NOT_WCK_MINH ;
		reg NOT_WCK_PER ;
		reg NOT_RCK_REN ;
		reg NOT_WCK_WEN ;
		reg NOT_WCK_BWEN_0 ;
		reg NOT_WCK_BWEN_1 ;
		reg NOT_WCK_BWEN_2 ;
		reg NOT_WCK_BWEN_3 ;
		reg NOT_WCK_BWEN_4 ;
		reg NOT_WCK_BWEN_5 ;
		reg NOT_WCK_BWEN_6 ;
		reg NOT_WCK_BWEN_7 ;
		reg NOT_WCK_BWEN_8 ;
		reg NOT_WCK_BWEN_9 ;
		reg NOT_WCK_BWEN_10 ;
		reg NOT_WCK_BWEN_11 ;
		reg NOT_WCK_BWEN_12 ;
		reg NOT_WCK_BWEN_13 ;
		reg NOT_WCK_BWEN_14 ;
		reg NOT_WCK_BWEN_15 ;
		reg NOT_WCK_BWEN_16 ;
		reg NOT_WCK_BWEN_17 ;
		reg NOT_WCK_BWEN_18 ;
		reg NOT_WCK_BWEN_19 ;
		reg NOT_WCK_BWEN_20 ;
		reg NOT_WCK_BWEN_21 ;
		reg NOT_WCK_BWEN_22 ;
		reg NOT_WCK_BWEN_23 ;
		reg NOT_WCK_BWEN_24 ;
		reg NOT_WCK_BWEN_25 ;
		reg NOT_WCK_BWEN_26 ;
		reg NOT_WCK_BWEN_27 ;
		reg NOT_WCK_BWEN_28 ;
		reg NOT_WCK_BWEN_29 ;
		reg NOT_WCK_BWEN_30 ;
		reg NOT_WCK_BWEN_31 ;
		reg NOT_WCK_BWEN_32 ;
		reg NOT_WCK_BWEN_33 ;
		reg NOT_WCK_BWEN_34 ;
		reg NOT_WCK_BWEN_35 ;
		reg NOT_WCK_BWEN_36 ;
		reg NOT_WCK_BWEN_37 ;
		reg NOT_WCK_BWEN_38 ;
		reg NOT_WCK_BWEN_39 ;
		reg NOT_WCK_BWEN_40 ;
		reg NOT_WCK_BWEN_41 ;
		reg NOT_WCK_BWEN_42 ;
		reg NOT_WCK_BWEN_43 ;
		reg NOT_WCK_BWEN_44 ;
		reg NOT_WCK_BWEN_45 ;
		reg NOT_WCK_BWEN_46 ;
		reg NOT_WCK_BWEN_47 ;
		reg NOT_WCK_BWEN_48 ;
		reg NOT_WCK_BWEN_49 ;
		reg NOT_WCK_BWEN_50 ;
		reg NOT_WCK_BWEN_51 ;
		reg NOT_WCK_BWEN_52 ;
		reg NOT_WCK_BWEN_53 ;
		reg NOT_WCK_BWEN_54 ;
		reg NOT_WCK_BWEN_55 ;
		reg NOT_WCK_BWEN_56 ;
		reg NOT_WCK_BWEN_57 ;
		reg NOT_WCK_BWEN_58 ;
		reg NOT_WCK_BWEN_59 ;
		reg NOT_WCK_BWEN_60 ;
		reg NOT_WCK_BWEN_61 ;
		reg NOT_WCK_BWEN_62 ;
		reg NOT_WCK_BWEN_63 ;
		reg NOT_WCK_BWEN_64 ;
		reg NOT_WCK_BWEN_65 ;
		reg NOT_WCK_BWEN_66 ;
		reg NOT_WCK_BWEN_67 ;
		reg NOT_WCK_BWEN_68 ;
		reg NOT_WCK_BWEN_69 ;
		reg NOT_WCK_BWEN_70 ;
		reg NOT_WCK_BWEN_71 ;
		reg NOT_WCK_BWEN_72 ;
		reg NOT_WCK_BWEN_73 ;
		reg NOT_WCK_BWEN_74 ;
		reg NOT_WCK_BWEN_75 ;
		reg NOT_WCK_BWEN_76 ;
		reg NOT_WCK_BWEN_77 ;
		reg NOT_WCK_BWEN_78 ;
		reg NOT_WCK_BWEN_79 ;
		reg NOT_WCK_BWEN_80 ;
		reg NOT_WCK_BWEN_81 ;
		reg NOT_WCK_BWEN_82 ;
		reg NOT_WCK_BWEN_83 ;
		reg NOT_WCK_BWEN_84 ;
		reg NOT_WCK_BWEN_85 ;
		reg NOT_WCK_BWEN_86 ;
		reg NOT_WCK_BWEN_87 ;
		reg NOT_WCK_BWEN_88 ;
		reg NOT_WCK_BWEN_89 ;
		reg NOT_WCK_BWEN_90 ;
		reg NOT_WCK_BWEN_91 ;
		reg NOT_WCK_BWEN_92 ;
		reg NOT_WCK_BWEN_93 ;
		reg NOT_WCK_BWEN_94 ;
		reg NOT_WCK_BWEN_95 ;
		reg NOT_WCK_BWEN_96 ;
		reg NOT_WCK_BWEN_97 ;
		reg NOT_WCK_BWEN_98 ;
		reg NOT_WCK_BWEN_99 ;
		reg NOT_WCK_BWEN_100 ;
		reg NOT_WCK_BWEN_101 ;
		reg NOT_WCK_BWEN_102 ;
		reg NOT_WCK_BWEN_103 ;
		reg NOT_WCK_BWEN_104 ;
		reg NOT_WCK_BWEN_105 ;
		reg NOT_WCK_BWEN_106 ;
		reg NOT_WCK_BWEN_107 ;
		reg NOT_WCK_BWEN_108 ;
		reg NOT_WCK_BWEN_109 ;
		reg NOT_WCK_BWEN_110 ;
		reg NOT_WCK_BWEN_111 ;
		reg NOT_WCK_BWEN_112 ;
		reg NOT_WCK_BWEN_113 ;
		reg NOT_WCK_BWEN_114 ;
		reg NOT_WCK_BWEN_115 ;
		reg NOT_WCK_BWEN_116 ;
		reg NOT_WCK_BWEN_117 ;
		reg NOT_WCK_BWEN_118 ;
		reg NOT_WCK_BWEN_119 ;
		reg NOT_WCK_BWEN_120 ;
		reg NOT_WCK_BWEN_121 ;
		reg NOT_WCK_BWEN_122 ;
		reg NOT_WCK_BWEN_123 ;
		reg NOT_WCK_BWEN_124 ;
		reg NOT_WCK_BWEN_125 ;
		reg NOT_WCK_BWEN_126 ;
		reg NOT_WCK_BWEN_127 ;
		reg NOT_RCK_DFTRAM ;
		reg NOT_WCK_DFTRAM ;
		reg NOT_RCK_DFTRAMRN ;
		reg NOT_WCK_DFTRAMRN ;
		reg NOT_RCK_SMX ;
		reg NOT_WCK_SMX ;
		reg NOT_RCK_MCSRD ;
		reg NOT_WCK_MCSA ;
		reg NOT_RCK_KCS ;
		reg NOT_WCK_KCS ;
		reg NOT_WCK_MCSWR ;
		reg NOT_WCK_ADME ;
		reg NOT_RCK_CRE ;
		reg NOT_WCK_CRE ;
		reg NOT_RCK_FCA ;
		reg NOT_WCK_FCA ;
		reg NOT_WCK_SE ;
		reg NOT_WCK_SI_D_L ;
		reg NOT_WCK_SI_D_R ;
		reg NOT_RCK_SERN;
		reg NOT_WCK_SI_D;
		reg NOT_WCK_SEWN;

		reg NOT_RCK_RRERD ;
		reg NOT_WCK_RREWR ;

		reg NOT_PDE_RET ;
		reg NOT_PDE_DFTRAM ;
		reg NOT_PDE_REN ;
		reg NOT_PDE_WEN ;
		reg NOT_RET_DFTRAM ;
		reg NOT_RET_REN ;
		reg NOT_RET_WEN ;

		initial begin
			NOT_RCK_RA_0 = 1'b0;
			NOT_WCK_WA_0 = 1'b0;
			NOT_RCK_RA_1 = 1'b0;
			NOT_WCK_WA_1 = 1'b0;
			NOT_RCK_RA_2 = 1'b0;
			NOT_WCK_WA_2 = 1'b0;
			NOT_WCK_DI_0 = 1'b0;
			NOT_WCK_DI_1 = 1'b0;
			NOT_WCK_DI_2 = 1'b0;
			NOT_WCK_DI_3 = 1'b0;
			NOT_WCK_DI_4 = 1'b0;
			NOT_WCK_DI_5 = 1'b0;
			NOT_WCK_DI_6 = 1'b0;
			NOT_WCK_DI_7 = 1'b0;
			NOT_WCK_DI_8 = 1'b0;
			NOT_WCK_DI_9 = 1'b0;
			NOT_WCK_DI_10 = 1'b0;
			NOT_WCK_DI_11 = 1'b0;
			NOT_WCK_DI_12 = 1'b0;
			NOT_WCK_DI_13 = 1'b0;
			NOT_WCK_DI_14 = 1'b0;
			NOT_WCK_DI_15 = 1'b0;
			NOT_WCK_DI_16 = 1'b0;
			NOT_WCK_DI_17 = 1'b0;
			NOT_WCK_DI_18 = 1'b0;
			NOT_WCK_DI_19 = 1'b0;
			NOT_WCK_DI_20 = 1'b0;
			NOT_WCK_DI_21 = 1'b0;
			NOT_WCK_DI_22 = 1'b0;
			NOT_WCK_DI_23 = 1'b0;
			NOT_WCK_DI_24 = 1'b0;
			NOT_WCK_DI_25 = 1'b0;
			NOT_WCK_DI_26 = 1'b0;
			NOT_WCK_DI_27 = 1'b0;
			NOT_WCK_DI_28 = 1'b0;
			NOT_WCK_DI_29 = 1'b0;
			NOT_WCK_DI_30 = 1'b0;
			NOT_WCK_DI_31 = 1'b0;
			NOT_WCK_DI_32 = 1'b0;
			NOT_WCK_DI_33 = 1'b0;
			NOT_WCK_DI_34 = 1'b0;
			NOT_WCK_DI_35 = 1'b0;
			NOT_WCK_DI_36 = 1'b0;
			NOT_WCK_DI_37 = 1'b0;
			NOT_WCK_DI_38 = 1'b0;
			NOT_WCK_DI_39 = 1'b0;
			NOT_WCK_DI_40 = 1'b0;
			NOT_WCK_DI_41 = 1'b0;
			NOT_WCK_DI_42 = 1'b0;
			NOT_WCK_DI_43 = 1'b0;
			NOT_WCK_DI_44 = 1'b0;
			NOT_WCK_DI_45 = 1'b0;
			NOT_WCK_DI_46 = 1'b0;
			NOT_WCK_DI_47 = 1'b0;
			NOT_WCK_DI_48 = 1'b0;
			NOT_WCK_DI_49 = 1'b0;
			NOT_WCK_DI_50 = 1'b0;
			NOT_WCK_DI_51 = 1'b0;
			NOT_WCK_DI_52 = 1'b0;
			NOT_WCK_DI_53 = 1'b0;
			NOT_WCK_DI_54 = 1'b0;
			NOT_WCK_DI_55 = 1'b0;
			NOT_WCK_DI_56 = 1'b0;
			NOT_WCK_DI_57 = 1'b0;
			NOT_WCK_DI_58 = 1'b0;
			NOT_WCK_DI_59 = 1'b0;
			NOT_WCK_DI_60 = 1'b0;
			NOT_WCK_DI_61 = 1'b0;
			NOT_WCK_DI_62 = 1'b0;
			NOT_WCK_DI_63 = 1'b0;
			NOT_WCK_DI_64 = 1'b0;
			NOT_WCK_DI_65 = 1'b0;
			NOT_WCK_DI_66 = 1'b0;
			NOT_WCK_DI_67 = 1'b0;
			NOT_WCK_DI_68 = 1'b0;
			NOT_WCK_DI_69 = 1'b0;
			NOT_WCK_DI_70 = 1'b0;
			NOT_WCK_DI_71 = 1'b0;
			NOT_WCK_DI_72 = 1'b0;
			NOT_WCK_DI_73 = 1'b0;
			NOT_WCK_DI_74 = 1'b0;
			NOT_WCK_DI_75 = 1'b0;
			NOT_WCK_DI_76 = 1'b0;
			NOT_WCK_DI_77 = 1'b0;
			NOT_WCK_DI_78 = 1'b0;
			NOT_WCK_DI_79 = 1'b0;
			NOT_WCK_DI_80 = 1'b0;
			NOT_WCK_DI_81 = 1'b0;
			NOT_WCK_DI_82 = 1'b0;
			NOT_WCK_DI_83 = 1'b0;
			NOT_WCK_DI_84 = 1'b0;
			NOT_WCK_DI_85 = 1'b0;
			NOT_WCK_DI_86 = 1'b0;
			NOT_WCK_DI_87 = 1'b0;
			NOT_WCK_DI_88 = 1'b0;
			NOT_WCK_DI_89 = 1'b0;
			NOT_WCK_DI_90 = 1'b0;
			NOT_WCK_DI_91 = 1'b0;
			NOT_WCK_DI_92 = 1'b0;
			NOT_WCK_DI_93 = 1'b0;
			NOT_WCK_DI_94 = 1'b0;
			NOT_WCK_DI_95 = 1'b0;
			NOT_WCK_DI_96 = 1'b0;
			NOT_WCK_DI_97 = 1'b0;
			NOT_WCK_DI_98 = 1'b0;
			NOT_WCK_DI_99 = 1'b0;
			NOT_WCK_DI_100 = 1'b0;
			NOT_WCK_DI_101 = 1'b0;
			NOT_WCK_DI_102 = 1'b0;
			NOT_WCK_DI_103 = 1'b0;
			NOT_WCK_DI_104 = 1'b0;
			NOT_WCK_DI_105 = 1'b0;
			NOT_WCK_DI_106 = 1'b0;
			NOT_WCK_DI_107 = 1'b0;
			NOT_WCK_DI_108 = 1'b0;
			NOT_WCK_DI_109 = 1'b0;
			NOT_WCK_DI_110 = 1'b0;
			NOT_WCK_DI_111 = 1'b0;
			NOT_WCK_DI_112 = 1'b0;
			NOT_WCK_DI_113 = 1'b0;
			NOT_WCK_DI_114 = 1'b0;
			NOT_WCK_DI_115 = 1'b0;
			NOT_WCK_DI_116 = 1'b0;
			NOT_WCK_DI_117 = 1'b0;
			NOT_WCK_DI_118 = 1'b0;
			NOT_WCK_DI_119 = 1'b0;
			NOT_WCK_DI_120 = 1'b0;
			NOT_WCK_DI_121 = 1'b0;
			NOT_WCK_DI_122 = 1'b0;
			NOT_WCK_DI_123 = 1'b0;
			NOT_WCK_DI_124 = 1'b0;
			NOT_WCK_DI_125 = 1'b0;
			NOT_WCK_DI_126 = 1'b0;
			NOT_WCK_DI_127 = 1'b0;
			NOT_RCK_WCK = 1'b0;
			NOT_RCK_MINL = 1'b0;
			NOT_RCK_MINH = 1'b0;
			NOT_RCK_PER = 1'b0;
			NOT_WCK_RCK = 1'b0;
			NOT_WCK_MINL = 1'b0;
			NOT_WCK_MINH = 1'b0;
			NOT_WCK_PER = 1'b0;
			NOT_RCK_REN = 1'b0;
			NOT_WCK_WEN = 1'b0;

			NOT_WCK_BWEN_0 = 1'b0;
			NOT_WCK_BWEN_1 = 1'b0;
			NOT_WCK_BWEN_2 = 1'b0;
			NOT_WCK_BWEN_3 = 1'b0;
			NOT_WCK_BWEN_4 = 1'b0;
			NOT_WCK_BWEN_5 = 1'b0;
			NOT_WCK_BWEN_6 = 1'b0;
			NOT_WCK_BWEN_7 = 1'b0;
			NOT_WCK_BWEN_8 = 1'b0;
			NOT_WCK_BWEN_9 = 1'b0;
			NOT_WCK_BWEN_10 = 1'b0;
			NOT_WCK_BWEN_11 = 1'b0;
			NOT_WCK_BWEN_12 = 1'b0;
			NOT_WCK_BWEN_13 = 1'b0;
			NOT_WCK_BWEN_14 = 1'b0;
			NOT_WCK_BWEN_15 = 1'b0;
			NOT_WCK_BWEN_16 = 1'b0;
			NOT_WCK_BWEN_17 = 1'b0;
			NOT_WCK_BWEN_18 = 1'b0;
			NOT_WCK_BWEN_19 = 1'b0;
			NOT_WCK_BWEN_20 = 1'b0;
			NOT_WCK_BWEN_21 = 1'b0;
			NOT_WCK_BWEN_22 = 1'b0;
			NOT_WCK_BWEN_23 = 1'b0;
			NOT_WCK_BWEN_24 = 1'b0;
			NOT_WCK_BWEN_25 = 1'b0;
			NOT_WCK_BWEN_26 = 1'b0;
			NOT_WCK_BWEN_27 = 1'b0;
			NOT_WCK_BWEN_28 = 1'b0;
			NOT_WCK_BWEN_29 = 1'b0;
			NOT_WCK_BWEN_30 = 1'b0;
			NOT_WCK_BWEN_31 = 1'b0;
			NOT_WCK_BWEN_32 = 1'b0;
			NOT_WCK_BWEN_33 = 1'b0;
			NOT_WCK_BWEN_34 = 1'b0;
			NOT_WCK_BWEN_35 = 1'b0;
			NOT_WCK_BWEN_36 = 1'b0;
			NOT_WCK_BWEN_37 = 1'b0;
			NOT_WCK_BWEN_38 = 1'b0;
			NOT_WCK_BWEN_39 = 1'b0;
			NOT_WCK_BWEN_40 = 1'b0;
			NOT_WCK_BWEN_41 = 1'b0;
			NOT_WCK_BWEN_42 = 1'b0;
			NOT_WCK_BWEN_43 = 1'b0;
			NOT_WCK_BWEN_44 = 1'b0;
			NOT_WCK_BWEN_45 = 1'b0;
			NOT_WCK_BWEN_46 = 1'b0;
			NOT_WCK_BWEN_47 = 1'b0;
			NOT_WCK_BWEN_48 = 1'b0;
			NOT_WCK_BWEN_49 = 1'b0;
			NOT_WCK_BWEN_50 = 1'b0;
			NOT_WCK_BWEN_51 = 1'b0;
			NOT_WCK_BWEN_52 = 1'b0;
			NOT_WCK_BWEN_53 = 1'b0;
			NOT_WCK_BWEN_54 = 1'b0;
			NOT_WCK_BWEN_55 = 1'b0;
			NOT_WCK_BWEN_56 = 1'b0;
			NOT_WCK_BWEN_57 = 1'b0;
			NOT_WCK_BWEN_58 = 1'b0;
			NOT_WCK_BWEN_59 = 1'b0;
			NOT_WCK_BWEN_60 = 1'b0;
			NOT_WCK_BWEN_61 = 1'b0;
			NOT_WCK_BWEN_62 = 1'b0;
			NOT_WCK_BWEN_63 = 1'b0;
			NOT_WCK_BWEN_64 = 1'b0;
			NOT_WCK_BWEN_65 = 1'b0;
			NOT_WCK_BWEN_66 = 1'b0;
			NOT_WCK_BWEN_67 = 1'b0;
			NOT_WCK_BWEN_68 = 1'b0;
			NOT_WCK_BWEN_69 = 1'b0;
			NOT_WCK_BWEN_70 = 1'b0;
			NOT_WCK_BWEN_71 = 1'b0;
			NOT_WCK_BWEN_72 = 1'b0;
			NOT_WCK_BWEN_73 = 1'b0;
			NOT_WCK_BWEN_74 = 1'b0;
			NOT_WCK_BWEN_75 = 1'b0;
			NOT_WCK_BWEN_76 = 1'b0;
			NOT_WCK_BWEN_77 = 1'b0;
			NOT_WCK_BWEN_78 = 1'b0;
			NOT_WCK_BWEN_79 = 1'b0;
			NOT_WCK_BWEN_80 = 1'b0;
			NOT_WCK_BWEN_81 = 1'b0;
			NOT_WCK_BWEN_82 = 1'b0;
			NOT_WCK_BWEN_83 = 1'b0;
			NOT_WCK_BWEN_84 = 1'b0;
			NOT_WCK_BWEN_85 = 1'b0;
			NOT_WCK_BWEN_86 = 1'b0;
			NOT_WCK_BWEN_87 = 1'b0;
			NOT_WCK_BWEN_88 = 1'b0;
			NOT_WCK_BWEN_89 = 1'b0;
			NOT_WCK_BWEN_90 = 1'b0;
			NOT_WCK_BWEN_91 = 1'b0;
			NOT_WCK_BWEN_92 = 1'b0;
			NOT_WCK_BWEN_93 = 1'b0;
			NOT_WCK_BWEN_94 = 1'b0;
			NOT_WCK_BWEN_95 = 1'b0;
			NOT_WCK_BWEN_96 = 1'b0;
			NOT_WCK_BWEN_97 = 1'b0;
			NOT_WCK_BWEN_98 = 1'b0;
			NOT_WCK_BWEN_99 = 1'b0;
			NOT_WCK_BWEN_100 = 1'b0;
			NOT_WCK_BWEN_101 = 1'b0;
			NOT_WCK_BWEN_102 = 1'b0;
			NOT_WCK_BWEN_103 = 1'b0;
			NOT_WCK_BWEN_104 = 1'b0;
			NOT_WCK_BWEN_105 = 1'b0;
			NOT_WCK_BWEN_106 = 1'b0;
			NOT_WCK_BWEN_107 = 1'b0;
			NOT_WCK_BWEN_108 = 1'b0;
			NOT_WCK_BWEN_109 = 1'b0;
			NOT_WCK_BWEN_110 = 1'b0;
			NOT_WCK_BWEN_111 = 1'b0;
			NOT_WCK_BWEN_112 = 1'b0;
			NOT_WCK_BWEN_113 = 1'b0;
			NOT_WCK_BWEN_114 = 1'b0;
			NOT_WCK_BWEN_115 = 1'b0;
			NOT_WCK_BWEN_116 = 1'b0;
			NOT_WCK_BWEN_117 = 1'b0;
			NOT_WCK_BWEN_118 = 1'b0;
			NOT_WCK_BWEN_119 = 1'b0;
			NOT_WCK_BWEN_120 = 1'b0;
			NOT_WCK_BWEN_121 = 1'b0;
			NOT_WCK_BWEN_122 = 1'b0;
			NOT_WCK_BWEN_123 = 1'b0;
			NOT_WCK_BWEN_124 = 1'b0;
			NOT_WCK_BWEN_125 = 1'b0;
			NOT_WCK_BWEN_126 = 1'b0;
			NOT_WCK_BWEN_127 = 1'b0;
			NOT_RCK_DFTRAM = 1'b0;
			NOT_WCK_DFTRAM = 1'b0;
			NOT_RCK_DFTRAMRN = 1'b0;
			NOT_WCK_DFTRAMRN = 1'b0;
			NOT_RCK_MCSRD = 1'b0;
			NOT_WCK_MCSA = 1'b0;
			NOT_RCK_KCS = 1'b0;
			NOT_WCK_KCS = 1'b0;
			NOT_WCK_MCSWR = 1'b0;
			NOT_WCK_ADME = 1'b0;
			
			NOT_RCK_CRE = 1'b0;
			NOT_WCK_CRE = 1'b0;
			NOT_RCK_FCA = 1'b0;
			NOT_WCK_FCA = 1'b0;
			NOT_WCK_SI_D_L= 1'b0;
			NOT_WCK_SI_D_R= 1'b0;
			NOT_WCK_SE= 1'b0;
			NOT_RCK_SERN= 1'b0;
			NOT_WCK_SI_D= 1'b0;
			NOT_WCK_SEWN= 1'b0;
			NOT_RCK_RRERD = 1'b0;
			NOT_WCK_RREWR = 1'b0;
			NOT_PDE_RET = 1'b0;
			NOT_PDE_DFTRAM = 1'b0;
			NOT_PDE_REN = 1'b0;
			NOT_PDE_WEN = 1'b0;
			NOT_RET_DFTRAM = 1'b0;
			NOT_RET_REN = 1'b0;
			NOT_RET_WEN = 1'b0;
		end

//======================================
//Retention and Power Gating
//=====================================

		buf ipgen(PDE_,       1'b0);
		buf iretn(RETN_,       1'b1);

		reg T_check_violation;

		function retentionFunction;
			input ret1;
			reg result;
			begin
				case ({ret1})
					1'b0: result = 1'b0; //normal
					1'b1: result = 1'b0; //normal
					default: result = 1'bx;
				endcase
				retentionFunction = result;
			end
		endfunction

		wire retention;
		assign retention = retentionFunction(RETN_);


//==========================================================
//     Power Aware
// =========================================================

		function poweraware;
			input vddce, vddpe, vsse;
			reg result_pwr_on;
			begin
				case ({vddce,vddpe,vsse})
					3'b110: result_pwr_on = 1'b1;
					default: begin
						result_pwr_on = 1'b0;
						XDOUT=1;
					end
				endcase
				poweraware = result_pwr_on;
			end
		endfunction

		wire poweron;
		`ifdef POWER_PINS
			assign poweron = poweraware(vddpe_int,vddpe_int,vsse_int);
		`else
			assign poweron = poweraware(1'b1,1'b1,1'b0);
		`endif
//==========================================================
//     Scan Enable
// =========================================================
		wire scan_enable;
		assign scan_enable= SEW_ && DFTRAMW_ ;
//==========================================================
//     Output Defination
// =========================================================
		`ifdef SAMSUNG_FAULT_MODELING
			ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128_error_injection u1
			(.CLKA(CKA_),
			.CLKB(CKB_),
			.Q_out(DOUTA_err_inj),
			.AA(AA_int),
			.AB(AB_int),
			.CENA(CSNA_int),
			.CENB(CSNB_int),
			.CRE1(CRE1_int),
			.FCA1(FCA1_int),
			.CRE2(CRE2_int),
			.FCA2(FCA2_int),
			
			.Q_in(outreg));
			assign DOUTA_data_path = DOUTA_err_inj;
			
		`else
			assign DOUTA_data_path = outreg;
		`endif

		`ifdef SEC_FUNCTIONAL_MODE
			assign  #`D_MEM_DELAY DOUTA_ = poweron === 1'b1 ? (retention === 1'bx ? {word_width{1'bx}} : (retention === 1'b1 ? {word_width{1'bx}} : DOUT_int)) : {word_width{1'bx}};
		`else
			assign  DOUTA_ = poweron === 1'b1 ? (retention === 1'bx ? {word_width{1'bx}} : (retention === 1'b1 ? {word_width{1'bx}} : DOUT_int)) : {word_width{1'bx}};
		`endif

		`ifdef SEC_FUNCTIONAL_MODE
// No scan or capture mode the read write data directly going to DOUT
			
			assign #`D_MEM_DELAY SO_D_L_ = poweron === 1'b1 ? (retention === 1'bx ? 1'bx : (retention === 1'b1 ? 1'bx : (T_check_violation === 1'b1 ? 1'bx : (scan_enable ===1'b1 ? DOUT_int[63]: 1'b0)))) : 1'bx;
			assign #`D_MEM_DELAY SO_D_R_ = poweron === 1'b1 ? (retention === 1'bx ? 1'bx : (retention === 1'b1 ? 1'bx : (T_check_violation === 1'b1 ? 1'bx : (scan_enable ===1'b1 ? DOUT_int[64] : 1'b0)))) : 1'bx;
		`else
// No scan or capture mode the read write data directly going to DOUT
			assign SO_D_L_ = poweron === 1'b1 ? (retention === 1'bx ? 1'bx : (retention === 1'b1 ? 1'bx : (T_check_violation === 1'b1 ? 1'bx : (scan_enable ===1'b1 ? DOUT_int[63]: 1'b0)))) : 1'bx;
			assign SO_D_R_ = poweron === 1'b1 ? (retention === 1'bx ? 1'bx : (retention === 1'b1 ? 1'bx : (T_check_violation === 1'b1 ? 1'bx : (scan_enable ===1'b1 ? DOUT_int[64] : 1'b0)))) : 1'bx;
		`endif
//Scan function
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ0 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(SI_D_L_), .DI(DIB_[0]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[0]), .XDOUT(XDOUT), .DOUT(DOUT_int[0]), .BWEN(BWENB_[0]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ1 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[0]), .DI(DIB_[1]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[1]), .XDOUT(XDOUT), .DOUT(DOUT_int[1]), .BWEN(BWENB_[1]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ2 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[1]), .DI(DIB_[2]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[2]), .XDOUT(XDOUT), .DOUT(DOUT_int[2]), .BWEN(BWENB_[2]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ3 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[2]), .DI(DIB_[3]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[3]), .XDOUT(XDOUT), .DOUT(DOUT_int[3]), .BWEN(BWENB_[3]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ4 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[3]), .DI(DIB_[4]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[4]), .XDOUT(XDOUT), .DOUT(DOUT_int[4]), .BWEN(BWENB_[4]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ5 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[4]), .DI(DIB_[5]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[5]), .XDOUT(XDOUT), .DOUT(DOUT_int[5]), .BWEN(BWENB_[5]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ6 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[5]), .DI(DIB_[6]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[6]), .XDOUT(XDOUT), .DOUT(DOUT_int[6]), .BWEN(BWENB_[6]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ7 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[6]), .DI(DIB_[7]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[7]), .XDOUT(XDOUT), .DOUT(DOUT_int[7]), .BWEN(BWENB_[7]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ8 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[7]), .DI(DIB_[8]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[8]), .XDOUT(XDOUT), .DOUT(DOUT_int[8]), .BWEN(BWENB_[8]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ9 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[8]), .DI(DIB_[9]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[9]), .XDOUT(XDOUT), .DOUT(DOUT_int[9]), .BWEN(BWENB_[9]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ10 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[9]), .DI(DIB_[10]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[10]), .XDOUT(XDOUT), .DOUT(DOUT_int[10]), .BWEN(BWENB_[10]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ11 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[10]), .DI(DIB_[11]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[11]), .XDOUT(XDOUT), .DOUT(DOUT_int[11]), .BWEN(BWENB_[11]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ12 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[11]), .DI(DIB_[12]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[12]), .XDOUT(XDOUT), .DOUT(DOUT_int[12]), .BWEN(BWENB_[12]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ13 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[12]), .DI(DIB_[13]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[13]), .XDOUT(XDOUT), .DOUT(DOUT_int[13]), .BWEN(BWENB_[13]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ14 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[13]), .DI(DIB_[14]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[14]), .XDOUT(XDOUT), .DOUT(DOUT_int[14]), .BWEN(BWENB_[14]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ15 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[14]), .DI(DIB_[15]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[15]), .XDOUT(XDOUT), .DOUT(DOUT_int[15]), .BWEN(BWENB_[15]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ16 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[15]), .DI(DIB_[16]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[16]), .XDOUT(XDOUT), .DOUT(DOUT_int[16]), .BWEN(BWENB_[16]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ17 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[16]), .DI(DIB_[17]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[17]), .XDOUT(XDOUT), .DOUT(DOUT_int[17]), .BWEN(BWENB_[17]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ18 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[17]), .DI(DIB_[18]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[18]), .XDOUT(XDOUT), .DOUT(DOUT_int[18]), .BWEN(BWENB_[18]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ19 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[18]), .DI(DIB_[19]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[19]), .XDOUT(XDOUT), .DOUT(DOUT_int[19]), .BWEN(BWENB_[19]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ20 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[19]), .DI(DIB_[20]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[20]), .XDOUT(XDOUT), .DOUT(DOUT_int[20]), .BWEN(BWENB_[20]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ21 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[20]), .DI(DIB_[21]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[21]), .XDOUT(XDOUT), .DOUT(DOUT_int[21]), .BWEN(BWENB_[21]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ22 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[21]), .DI(DIB_[22]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[22]), .XDOUT(XDOUT), .DOUT(DOUT_int[22]), .BWEN(BWENB_[22]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ23 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[22]), .DI(DIB_[23]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[23]), .XDOUT(XDOUT), .DOUT(DOUT_int[23]), .BWEN(BWENB_[23]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ24 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[23]), .DI(DIB_[24]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[24]), .XDOUT(XDOUT), .DOUT(DOUT_int[24]), .BWEN(BWENB_[24]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ25 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[24]), .DI(DIB_[25]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[25]), .XDOUT(XDOUT), .DOUT(DOUT_int[25]), .BWEN(BWENB_[25]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ26 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[25]), .DI(DIB_[26]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[26]), .XDOUT(XDOUT), .DOUT(DOUT_int[26]), .BWEN(BWENB_[26]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ27 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[26]), .DI(DIB_[27]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[27]), .XDOUT(XDOUT), .DOUT(DOUT_int[27]), .BWEN(BWENB_[27]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ28 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[27]), .DI(DIB_[28]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[28]), .XDOUT(XDOUT), .DOUT(DOUT_int[28]), .BWEN(BWENB_[28]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ29 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[28]), .DI(DIB_[29]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[29]), .XDOUT(XDOUT), .DOUT(DOUT_int[29]), .BWEN(BWENB_[29]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ30 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[29]), .DI(DIB_[30]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[30]), .XDOUT(XDOUT), .DOUT(DOUT_int[30]), .BWEN(BWENB_[30]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ31 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[30]), .DI(DIB_[31]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[31]), .XDOUT(XDOUT), .DOUT(DOUT_int[31]), .BWEN(BWENB_[31]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ32 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[31]), .DI(DIB_[32]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[32]), .XDOUT(XDOUT), .DOUT(DOUT_int[32]), .BWEN(BWENB_[32]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ33 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[32]), .DI(DIB_[33]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[33]), .XDOUT(XDOUT), .DOUT(DOUT_int[33]), .BWEN(BWENB_[33]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ34 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[33]), .DI(DIB_[34]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[34]), .XDOUT(XDOUT), .DOUT(DOUT_int[34]), .BWEN(BWENB_[34]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ35 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[34]), .DI(DIB_[35]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[35]), .XDOUT(XDOUT), .DOUT(DOUT_int[35]), .BWEN(BWENB_[35]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ36 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[35]), .DI(DIB_[36]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[36]), .XDOUT(XDOUT), .DOUT(DOUT_int[36]), .BWEN(BWENB_[36]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ37 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[36]), .DI(DIB_[37]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[37]), .XDOUT(XDOUT), .DOUT(DOUT_int[37]), .BWEN(BWENB_[37]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ38 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[37]), .DI(DIB_[38]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[38]), .XDOUT(XDOUT), .DOUT(DOUT_int[38]), .BWEN(BWENB_[38]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ39 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[38]), .DI(DIB_[39]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[39]), .XDOUT(XDOUT), .DOUT(DOUT_int[39]), .BWEN(BWENB_[39]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ40 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[39]), .DI(DIB_[40]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[40]), .XDOUT(XDOUT), .DOUT(DOUT_int[40]), .BWEN(BWENB_[40]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ41 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[40]), .DI(DIB_[41]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[41]), .XDOUT(XDOUT), .DOUT(DOUT_int[41]), .BWEN(BWENB_[41]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ42 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[41]), .DI(DIB_[42]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[42]), .XDOUT(XDOUT), .DOUT(DOUT_int[42]), .BWEN(BWENB_[42]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ43 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[42]), .DI(DIB_[43]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[43]), .XDOUT(XDOUT), .DOUT(DOUT_int[43]), .BWEN(BWENB_[43]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ44 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[43]), .DI(DIB_[44]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[44]), .XDOUT(XDOUT), .DOUT(DOUT_int[44]), .BWEN(BWENB_[44]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ45 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[44]), .DI(DIB_[45]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[45]), .XDOUT(XDOUT), .DOUT(DOUT_int[45]), .BWEN(BWENB_[45]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ46 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[45]), .DI(DIB_[46]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[46]), .XDOUT(XDOUT), .DOUT(DOUT_int[46]), .BWEN(BWENB_[46]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ47 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[46]), .DI(DIB_[47]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[47]), .XDOUT(XDOUT), .DOUT(DOUT_int[47]), .BWEN(BWENB_[47]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ48 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[47]), .DI(DIB_[48]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[48]), .XDOUT(XDOUT), .DOUT(DOUT_int[48]), .BWEN(BWENB_[48]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ49 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[48]), .DI(DIB_[49]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[49]), .XDOUT(XDOUT), .DOUT(DOUT_int[49]), .BWEN(BWENB_[49]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ50 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[49]), .DI(DIB_[50]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[50]), .XDOUT(XDOUT), .DOUT(DOUT_int[50]), .BWEN(BWENB_[50]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ51 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[50]), .DI(DIB_[51]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[51]), .XDOUT(XDOUT), .DOUT(DOUT_int[51]), .BWEN(BWENB_[51]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ52 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[51]), .DI(DIB_[52]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[52]), .XDOUT(XDOUT), .DOUT(DOUT_int[52]), .BWEN(BWENB_[52]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ53 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[52]), .DI(DIB_[53]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[53]), .XDOUT(XDOUT), .DOUT(DOUT_int[53]), .BWEN(BWENB_[53]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ54 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[53]), .DI(DIB_[54]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[54]), .XDOUT(XDOUT), .DOUT(DOUT_int[54]), .BWEN(BWENB_[54]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ55 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[54]), .DI(DIB_[55]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[55]), .XDOUT(XDOUT), .DOUT(DOUT_int[55]), .BWEN(BWENB_[55]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ56 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[55]), .DI(DIB_[56]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[56]), .XDOUT(XDOUT), .DOUT(DOUT_int[56]), .BWEN(BWENB_[56]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ57 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[56]), .DI(DIB_[57]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[57]), .XDOUT(XDOUT), .DOUT(DOUT_int[57]), .BWEN(BWENB_[57]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ58 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[57]), .DI(DIB_[58]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[58]), .XDOUT(XDOUT), .DOUT(DOUT_int[58]), .BWEN(BWENB_[58]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ59 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[58]), .DI(DIB_[59]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[59]), .XDOUT(XDOUT), .DOUT(DOUT_int[59]), .BWEN(BWENB_[59]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ60 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[59]), .DI(DIB_[60]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[60]), .XDOUT(XDOUT), .DOUT(DOUT_int[60]), .BWEN(BWENB_[60]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ61 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[60]), .DI(DIB_[61]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[61]), .XDOUT(XDOUT), .DOUT(DOUT_int[61]), .BWEN(BWENB_[61]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ62 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[61]), .DI(DIB_[62]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[62]), .XDOUT(XDOUT), .DOUT(DOUT_int[62]), .BWEN(BWENB_[62]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ63 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[62]), .DI(DIB_[63]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[63]), .XDOUT(XDOUT), .DOUT(DOUT_int[63]), .BWEN(BWENB_[63]));
		
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ127 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(SI_D_R_), .DI(DIB_[127]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[127]), .XDOUT(XDOUT), .DOUT(DOUT_int[127]), .BWEN(BWENB_[127]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ126 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[127]), .DI(DIB_[126]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[126]), .XDOUT(XDOUT), .DOUT(DOUT_int[126]), .BWEN(BWENB_[126]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ125 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[126]), .DI(DIB_[125]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[125]), .XDOUT(XDOUT), .DOUT(DOUT_int[125]), .BWEN(BWENB_[125]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ124 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[125]), .DI(DIB_[124]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[124]), .XDOUT(XDOUT), .DOUT(DOUT_int[124]), .BWEN(BWENB_[124]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ123 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[124]), .DI(DIB_[123]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[123]), .XDOUT(XDOUT), .DOUT(DOUT_int[123]), .BWEN(BWENB_[123]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ122 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[123]), .DI(DIB_[122]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[122]), .XDOUT(XDOUT), .DOUT(DOUT_int[122]), .BWEN(BWENB_[122]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ121 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[122]), .DI(DIB_[121]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[121]), .XDOUT(XDOUT), .DOUT(DOUT_int[121]), .BWEN(BWENB_[121]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ120 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[121]), .DI(DIB_[120]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[120]), .XDOUT(XDOUT), .DOUT(DOUT_int[120]), .BWEN(BWENB_[120]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ119 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[120]), .DI(DIB_[119]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[119]), .XDOUT(XDOUT), .DOUT(DOUT_int[119]), .BWEN(BWENB_[119]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ118 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[119]), .DI(DIB_[118]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[118]), .XDOUT(XDOUT), .DOUT(DOUT_int[118]), .BWEN(BWENB_[118]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ117 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[118]), .DI(DIB_[117]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[117]), .XDOUT(XDOUT), .DOUT(DOUT_int[117]), .BWEN(BWENB_[117]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ116 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[117]), .DI(DIB_[116]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[116]), .XDOUT(XDOUT), .DOUT(DOUT_int[116]), .BWEN(BWENB_[116]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ115 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[116]), .DI(DIB_[115]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[115]), .XDOUT(XDOUT), .DOUT(DOUT_int[115]), .BWEN(BWENB_[115]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ114 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[115]), .DI(DIB_[114]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[114]), .XDOUT(XDOUT), .DOUT(DOUT_int[114]), .BWEN(BWENB_[114]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ113 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[114]), .DI(DIB_[113]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[113]), .XDOUT(XDOUT), .DOUT(DOUT_int[113]), .BWEN(BWENB_[113]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ112 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[113]), .DI(DIB_[112]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[112]), .XDOUT(XDOUT), .DOUT(DOUT_int[112]), .BWEN(BWENB_[112]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ111 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[112]), .DI(DIB_[111]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[111]), .XDOUT(XDOUT), .DOUT(DOUT_int[111]), .BWEN(BWENB_[111]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ110 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[111]), .DI(DIB_[110]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[110]), .XDOUT(XDOUT), .DOUT(DOUT_int[110]), .BWEN(BWENB_[110]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ109 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[110]), .DI(DIB_[109]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[109]), .XDOUT(XDOUT), .DOUT(DOUT_int[109]), .BWEN(BWENB_[109]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ108 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[109]), .DI(DIB_[108]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[108]), .XDOUT(XDOUT), .DOUT(DOUT_int[108]), .BWEN(BWENB_[108]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ107 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[108]), .DI(DIB_[107]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[107]), .XDOUT(XDOUT), .DOUT(DOUT_int[107]), .BWEN(BWENB_[107]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ106 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[107]), .DI(DIB_[106]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[106]), .XDOUT(XDOUT), .DOUT(DOUT_int[106]), .BWEN(BWENB_[106]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ105 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[106]), .DI(DIB_[105]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[105]), .XDOUT(XDOUT), .DOUT(DOUT_int[105]), .BWEN(BWENB_[105]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ104 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[105]), .DI(DIB_[104]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[104]), .XDOUT(XDOUT), .DOUT(DOUT_int[104]), .BWEN(BWENB_[104]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ103 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[104]), .DI(DIB_[103]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[103]), .XDOUT(XDOUT), .DOUT(DOUT_int[103]), .BWEN(BWENB_[103]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ102 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[103]), .DI(DIB_[102]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[102]), .XDOUT(XDOUT), .DOUT(DOUT_int[102]), .BWEN(BWENB_[102]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ101 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[102]), .DI(DIB_[101]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[101]), .XDOUT(XDOUT), .DOUT(DOUT_int[101]), .BWEN(BWENB_[101]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ100 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[101]), .DI(DIB_[100]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[100]), .XDOUT(XDOUT), .DOUT(DOUT_int[100]), .BWEN(BWENB_[100]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ99 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[100]), .DI(DIB_[99]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[99]), .XDOUT(XDOUT), .DOUT(DOUT_int[99]), .BWEN(BWENB_[99]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ98 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[99]), .DI(DIB_[98]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[98]), .XDOUT(XDOUT), .DOUT(DOUT_int[98]), .BWEN(BWENB_[98]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ97 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[98]), .DI(DIB_[97]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[97]), .XDOUT(XDOUT), .DOUT(DOUT_int[97]), .BWEN(BWENB_[97]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ96 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[97]), .DI(DIB_[96]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[96]), .XDOUT(XDOUT), .DOUT(DOUT_int[96]), .BWEN(BWENB_[96]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ95 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[96]), .DI(DIB_[95]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[95]), .XDOUT(XDOUT), .DOUT(DOUT_int[95]), .BWEN(BWENB_[95]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ94 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[95]), .DI(DIB_[94]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[94]), .XDOUT(XDOUT), .DOUT(DOUT_int[94]), .BWEN(BWENB_[94]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ93 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[94]), .DI(DIB_[93]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[93]), .XDOUT(XDOUT), .DOUT(DOUT_int[93]), .BWEN(BWENB_[93]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ92 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[93]), .DI(DIB_[92]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[92]), .XDOUT(XDOUT), .DOUT(DOUT_int[92]), .BWEN(BWENB_[92]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ91 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[92]), .DI(DIB_[91]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[91]), .XDOUT(XDOUT), .DOUT(DOUT_int[91]), .BWEN(BWENB_[91]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ90 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[91]), .DI(DIB_[90]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[90]), .XDOUT(XDOUT), .DOUT(DOUT_int[90]), .BWEN(BWENB_[90]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ89 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[90]), .DI(DIB_[89]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[89]), .XDOUT(XDOUT), .DOUT(DOUT_int[89]), .BWEN(BWENB_[89]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ88 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[89]), .DI(DIB_[88]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[88]), .XDOUT(XDOUT), .DOUT(DOUT_int[88]), .BWEN(BWENB_[88]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ87 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[88]), .DI(DIB_[87]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[87]), .XDOUT(XDOUT), .DOUT(DOUT_int[87]), .BWEN(BWENB_[87]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ86 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[87]), .DI(DIB_[86]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[86]), .XDOUT(XDOUT), .DOUT(DOUT_int[86]), .BWEN(BWENB_[86]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ85 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[86]), .DI(DIB_[85]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[85]), .XDOUT(XDOUT), .DOUT(DOUT_int[85]), .BWEN(BWENB_[85]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ84 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[85]), .DI(DIB_[84]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[84]), .XDOUT(XDOUT), .DOUT(DOUT_int[84]), .BWEN(BWENB_[84]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ83 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[84]), .DI(DIB_[83]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[83]), .XDOUT(XDOUT), .DOUT(DOUT_int[83]), .BWEN(BWENB_[83]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ82 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[83]), .DI(DIB_[82]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[82]), .XDOUT(XDOUT), .DOUT(DOUT_int[82]), .BWEN(BWENB_[82]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ81 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[82]), .DI(DIB_[81]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[81]), .XDOUT(XDOUT), .DOUT(DOUT_int[81]), .BWEN(BWENB_[81]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ80 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[81]), .DI(DIB_[80]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[80]), .XDOUT(XDOUT), .DOUT(DOUT_int[80]), .BWEN(BWENB_[80]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ79 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[80]), .DI(DIB_[79]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[79]), .XDOUT(XDOUT), .DOUT(DOUT_int[79]), .BWEN(BWENB_[79]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ78 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[79]), .DI(DIB_[78]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[78]), .XDOUT(XDOUT), .DOUT(DOUT_int[78]), .BWEN(BWENB_[78]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ77 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[78]), .DI(DIB_[77]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[77]), .XDOUT(XDOUT), .DOUT(DOUT_int[77]), .BWEN(BWENB_[77]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ76 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[77]), .DI(DIB_[76]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[76]), .XDOUT(XDOUT), .DOUT(DOUT_int[76]), .BWEN(BWENB_[76]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ75 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[76]), .DI(DIB_[75]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[75]), .XDOUT(XDOUT), .DOUT(DOUT_int[75]), .BWEN(BWENB_[75]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ74 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[75]), .DI(DIB_[74]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[74]), .XDOUT(XDOUT), .DOUT(DOUT_int[74]), .BWEN(BWENB_[74]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ73 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[74]), .DI(DIB_[73]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[73]), .XDOUT(XDOUT), .DOUT(DOUT_int[73]), .BWEN(BWENB_[73]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ72 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[73]), .DI(DIB_[72]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[72]), .XDOUT(XDOUT), .DOUT(DOUT_int[72]), .BWEN(BWENB_[72]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ71 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[72]), .DI(DIB_[71]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[71]), .XDOUT(XDOUT), .DOUT(DOUT_int[71]), .BWEN(BWENB_[71]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ70 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[71]), .DI(DIB_[70]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[70]), .XDOUT(XDOUT), .DOUT(DOUT_int[70]), .BWEN(BWENB_[70]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ69 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[70]), .DI(DIB_[69]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[69]), .XDOUT(XDOUT), .DOUT(DOUT_int[69]), .BWEN(BWENB_[69]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ68 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[69]), .DI(DIB_[68]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[68]), .XDOUT(XDOUT), .DOUT(DOUT_int[68]), .BWEN(BWENB_[68]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ67 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[68]), .DI(DIB_[67]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[67]), .XDOUT(XDOUT), .DOUT(DOUT_int[67]), .BWEN(BWENB_[67]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ66 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[67]), .DI(DIB_[66]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[66]), .XDOUT(XDOUT), .DOUT(DOUT_int[66]), .BWEN(BWENB_[66]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ65 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[66]), .DI(DIB_[65]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[65]), .XDOUT(XDOUT), .DOUT(DOUT_int[65]), .BWEN(BWENB_[65]));
		datapath_latch_ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128 uDQ64 (.CK(CKB_), .DOUT_update(DOUT_update),.SEB(SEW_),.SIB(DOUT_int[65]), .DI(DIB_[64]), .DFTRAM(DFTRAMW_), .mem_path(DOUTA_data_path[64]), .XDOUT(XDOUT), .DOUT(DOUT_int[64]), .BWEN(BWENB_[64]));

//=====================================
//Power Suppy sequence (use for Power Verilog)
//=====================================
		`ifdef POWER_PINS
			always @ (vddpe_int or vsse_int) begin
				if (vddpe_int === 1'bx || vddpe_int === 1'bz)
				begin
					if (DISPLAY_CNTRL == 0) begin
						$display("Warning: Unknown value for VDDE %b in %m at %0t", vddpe_int, $time);
					end
				end
				if (vsse_int === 1'bx || vsse_int === 1'bz)
				begin
					if (DISPLAY_CNTRL == 0) begin
						$display("Warning: Unknown value for VSSE %b in %m at %0t", vsse_int, $time);
					end
				end
			end
			always @( vddpe_int or vsse_int ) begin
				if ($time > `SEC_LPV_STARTTIME) begin
					if ( vddpe_int !== 1'b1 ) begin
						failedWrite;
						OutputCorrupt;
					end
					PG_OFF_VSS: assert (vsse_int === 1'b0) else begin
						failedWrite;
						OutputCorrupt;
						if (DISPLAY_CNTRL == 0) begin
							$error("\n%m Error: VSSE = %b is forbidden - Read Fail and Data Fail (time %0t)",vsse_int,$time);
						end
					end
					if ( vddpe_int === 1'b1 && vsse_int === 1'b0 ) begin
						DOUT_update = 1'b0;
						if (DISPLAY_CNTRL == 0) begin
							$display("\n%m Power supplies are back to their normal states (time %0t)",$time);
						end
					end
				end
			end
		`endif

//========================================
//Retention and Power Gating Functionality
//========================================
//=================================================================================================
//				 Retention Block
//=================================================================================================
		always @ (RETN_) begin
			if (RETN_ === 1'bx) begin
				write_out_x;
				failedWrite;
			end else begin
				if(RETN_int === 1'b1 && RETN_ === 1'b0) begin
					PG_CSN_DFTRAM_0: assert(CSNA_ === 1'b1 && CSNB_ === 1'b1 && DFTRAMW_ === 1'b0) begin
					end else begin
						if ($time > `SEC_LPV_STARTTIME) begin
							if (DISPLAY_CNTRL == 0) begin
								$error("Error: Invalid mode for retention mode DFTRAM=%b REN=%b and WEN=%b in %m at %0t", DFTRAMW_,CSNA_,CSNB_, $time);
							end
							failedWrite;
							OutputCorrupt;
						end
					end
				end else if(RETN_int === 1'b0 && RETN_ === 1'b1) begin
					PG_CSN_DFTRAM_1: assert(CSNA_ === 1'b1 && CSNB_ === 1'b1 && DFTRAMW_ === 1'b0) begin
						OutputCorrupt;
					end else begin
						if ($time > `SEC_LPV_STARTTIME) begin
							if (DISPLAY_CNTRL == 0) begin
								$error("Error: Invalid mode for retention mode DFTRAM=%b REN=%b and WEN=%b in %m at %0t", DFTRAMW_,CSNA_,CSNB_, $time);
							end
							failedWrite;
							OutputCorrupt;
						end
					end
				end
				DOUT_update = 1'b0;
			end
			RETN_int = RETN_;
			T_check_violation = 0;
		end



//========================================
//DFTRAM Functionality
//========================================
		always @ (negedge CKB_ or DFTRAMW_)
		begin
			if (CKB_ === 1'b0)
				DFTRAM_oldB <= DFTRAMW_;
		end

		always @ (negedge CKA_ or DFTRAMW_)
		begin
			if (CKA_ === 1'b0)
				DFTRAM_oldA <= DFTRAMW_;
		end

//=============================================
// Memory Functionality CLKA
//=============================================
		assign AA_valid = (( ^RA === 1'bx ) ? 2'b01 : ( ( RA >= WORDS ) ? 2'b10 : 2'b00 ));
		assign AA_redu_valid = (( ^AA_redu_int === 1'bx ) ? 2'b01 : ( ( AA_redu_int >= WORDS ) ? 2'b10 : 2'b00 ));
		always @ (CKA_) begin
			`ifdef POWER_PINS
				CLOCK_TOGGLES_VDDE_R: assert(vddpe_int === 1'b1 || vddpe_int === 1'b0) else begin
					if (DISPLAY_CNTRL == 0) begin
						$error("Error: Unknown value for VDDE %b in %m at %0t", vddpe_int, $time);
					end
				end
				CLOCK_TOGGLES_VSSE_R: assert(vsse_int === 1'b1 || vsse_int === 1'b0) else begin
					if (DISPLAY_CNTRL == 0) begin
						$error("Error: Unknown value for VSSE %b in %m at %0t", vsse_int, $time);
					end
				end
			`endif
			if (vddpe_int === 1'b1 && vsse_int === 1'b0 ) begin // VDDP and VSSE shoud valid
//For Retention mode
				if (RETN_ === 1'b0) begin
				end
				else if (RETN_ === 1'bx || RETN_ === 1'bz ) begin
					failedWrite;
					write_out_low;
					XDOUT = 1'b1; #0 DOUT_update = 1'b1;
				end
				else begin
//For normal mode
					if (CKA_ === 1'bx || CKA_ === 1'bz ) begin
						OutputCorrupt;
						XDOUT=1'b1; #0 DOUT_update = 1'b0;
					end
					else if ((CKA_ === 1'b1 || CKA_ === 1'b0) && (LAST_CKA === 1'bx || LAST_CKA===1'bz)) begin
						XDOUT = 1'b0; #0 DOUT_update = 1'b0;
					end
					else if (CKA_ === 1'b1 && LAST_CKA === 1'b0) begin
						CKA_real = $realtime;
// Memory Normal operation in rising edge of clock
						FCA1A_prev = FCA1A_int;
						FCA2A_prev = FCA2A_int;
						FCA_prev = FCA_int;
						CRE1_int = CRE1_;
						CRE2_int = CRE2_;
						FCA1_int = FCA1_;
						FCA2_int = FCA2_;
						CRE1_A_int = CRE1_;
						CRE2_A_int = CRE2_;
						FCA1_A_int = FCA1_;
						FCA2_A_int = FCA2_;
						FCA1A_int = FCA1_;
						FCA2A_int = FCA2_;
						CRE_int = 1'b0;
						FCA_int = 0;
						RRE1A_int = 1'b0;
						RRE2A_int = 1'b0;
						CSNA_int = CSNA_;
						AA_int = AA_;
						AA_redu_int = AA_;
						DFTRAM_A_int = DFTRAMW_;
						MCSRD_A_int = MCSA_;
						MCSWR_A_int = MCSB_;
						KCS_A_int = KCS_;
						ADME_A_int = ADME_;
						AB_A_int = AB_;
						row_redu_valid = 1;

						if (DFTRAM_A_int === 1'b0 ) begin
							if (CKA_real - CKB_real < TCSEP)
							begin
								same_edge = ~same_edge;
							end
							READ_ROW;
							valid_op = 1;
//XDOUT = 1'b0; #0 DOUT_update = 1'b1;
						end
						if (DFTRAM_A_int === 1'b1 ) begin
//No read operation
							XDOUT = 1'b0;
						end
						if (DFTRAM_A_int === 1'bx || DFTRAM_A_int === 1'bz) begin
							failedWrite;
							OutputCorrupt;
						end
						if (DFTRAM_oldA !== DFTRAM_oldB) begin
							OutputCorrupt;
						end
						T_check_violation = 0;
					end
					else if (CKA_ === 1'b0 && LAST_CKA === 1'b1) begin
// No change in Memory in falling edge of clock
						XDOUT = 1'b0; #0 DOUT_update = 1'b0;
					end
				end
			end
			LAST_CKA = CKA_;
		end

//=============================================
// Memory Functionality CLKB
//=============================================
		assign AB_valid = (( ^WA === 1'bx ) ? 2'b01 : ( ( WA >= WORDS ) ? 2'b10 : 2'b00 ));
		assign AB_redu_valid = (( ^AB_redu_int === 1'bx ) ? 2'b01 : ( ( AB_redu_int >= WORDS ) ? 2'b10 : 2'b00 ));
		always @ (CKB_) begin
			`ifdef POWER_PINS
				CLOCK_TOGGLES_VDDE_W: assert(vddpe_int === 1'b1 || vddpe_int === 1'b0) else begin
					if (DISPLAY_CNTRL == 0) begin
						$error("Error: Unknown value for VDDE %b in %m at %0t", vddpe_int, $time);
					end
				end
				CLOCK_TOGGLES_VSSE_W: assert(vsse_int === 1'b1 || vsse_int === 1'b0) else begin
					if (DISPLAY_CNTRL == 0) begin
						$error("Error: Unknown value for VSSE %b in %m at %0t", vsse_int, $time);
					end
				end
			`endif
			if (vddpe_int === 1'b1 && vsse_int === 1'b0 ) begin // VDDP and VSSE shoud valid
//For Retention mode
				if (RETN_ === 1'b0) begin
				end

				else if (RETN_ === 1'bx || RETN_ === 1'bz ) begin
					failedWrite;
					write_out_low;
					XDOUT = 1'b1; #0 DOUT_update = 1'b1;
				end
				else begin
//For normal mode
					if (CKB_ === 1'bx || CKB_ === 1'bz ) begin
						failedWrite;
					end
					else if ((CKB_ === 1'b1 || CKB_ === 1'b0) && (LAST_CKB === 1'bx || LAST_CKB === 1'bz)) begin
//clk rising or falling to unknown output corrupted
						if (DFTRAM_B_int === 1) begin
							OutputCorrupt;
						end
					end
					else if (CKB_ === 1'b1 && LAST_CKB === 1'b0) begin
// Memory Normal operation in rising edge of clock
						CKB_real = $realtime;
						CRE1_int = CRE1_;
						CRE2_int = CRE2_;
						FCA1_int = FCA1_;
						FCA2_int = FCA2_;
						CRE1_B_int = CRE1_;
						FCA1_B_int = FCA1_;
						CRE2_B_int = CRE2_;
						FCA2_B_int = FCA2_;
						
						CRE_int = 1'b0;
						FCA_int = 0;
						RRE1B_int = 1'b0;
						RRE2B_int = 1'b0;
						BWEN_int = BWENB_;
						CSNB_int = CSNB_;
						D_int = DIB_;
						AB_int = AB_;
						AB_redu_int = AB_;
						DFTRAM_B_int = DFTRAMW_;
						SI_D_L_int = SI_D_L_;
						SI_D_R_int = SI_D_R_;
						SE_int = SEW_;
						MCSRD_B_int = MCSA_;
						MCSWR_B_int = MCSB_;
						KCS_B_int = KCS_;
						ADME_B_int = ADME_;
						AA_B_int = AA_;
						row_redu_valid = 1;

						if (DFTRAM_B_int === 1'b0 ) begin
							if (CKB_real - CKA_real < TCSEP) begin
								same_edge = ~same_edge;
							end
							WRITE_ROW;
							valid_op = 1;
						end
						else if (DFTRAM_B_int === 1'b1 ) begin
//DFTRAM MODE
							if (SE_int == 1'b0) begin
//scan
								XDOUT=1'b0; #0 DOUT_update = 1'b1;
							end
							else if (SE_int == 1'b1) begin
								XDOUT=1'b0; #0 DOUT_update = 1'b1;
//capture
							end
							else begin
								OutputCorrupt;
							end
						end
						else begin
							if (CSNB_int === 1'b0) begin
								failedWrite;
							end
							OutputCorrupt;
						end
						T_check_violation = 0;
					end
					else if (CKB_ === 1'b0 && LAST_CKB === 1'b1) begin
						XDOUT = 1'b0; #0 DOUT_update = 1'b0;
					end
				end
			end
			LAST_CKB = CKB_;
		end

//=============================================
// Memory Functionality SAME EDGE
//=============================================


		always @(  same_edge )
		begin
			if ( CSNB_int === 1'b0 && CSNA_int === 1'b0 && DFTRAM == 1'b0)
			begin
				if ((RRE1A_int==0 && RRE1B_int==0) && (RRE2A_int==0 && RRE2B_int==0)) begin
					if ((( AB_int === AA_int ) && (AB_valid == 2'b00)) && ( ^AB_int !== 1'bx ) && ( ^AA_int !== 1'bx )) begin
						write_operation = 1'b1;
						`ifdef PARTIAL_READ_ON_CONTENTION
							PartialOutputCorrupt;
						`else
							OutputCorrupt;
						`endif
						if (DISPLAY_CNTRL == 0) begin
							$display("WARNING :Contention in Normal Mode : Read Fail %b in %m at %0t", RA, $time);
						end
					end
				end
				else if ((RRE1A_int==1 && RRE1B_int==1) && (RRE2A_int==0 && RRE2B_int==0)) begin
					if (( AB_redu_int === AA_redu_int ) && ( ^AB_redu_int !== 1'bx ) && ( ^AA_redu_int !== 1'bx )) begin
						write_operation = 1'b1;
						`ifdef PARTIAL_READ_ON_CONTENTION
							PartialOutputCorrupt;
						`else
							OutputCorrupt;
						`endif
						if (DISPLAY_CNTRL == 0) begin
							$display("WARNING :Contention in Redundant Memory1 : Read Fail in %m at %0t", $time);
						end
					end
				end
				else if ((RRE1A_int==0 && RRE1B_int==0) && (RRE2A_int==1 && RRE2B_int==1)) begin
					if (( AB_redu_int === AA_redu_int ) && ( ^AB_redu_int !== 1'bx ) && ( ^AA_redu_int !== 1'bx )) begin
						write_operation = 1'b1;
						`ifdef PARTIAL_READ_ON_CONTENTION
							PartialOutputCorrupt;
						`else
							OutputCorrupt;
						`endif
						if (DISPLAY_CNTRL == 0) begin
							$display("WARNING :Contention in Redundant Memory2 : Read Fail in %m at %0t", $time);
						end
					end
				end
			end // end if simultaneous write and read
		end // end of block blk_same_edge


// ------------------------------------------------------
//            tasks and functions
// ------------------------------------------------------
		task READ_ROW;
			begin
//Row Redundancy
				if (CSNA_int === 1'b0) begin
					if( ((^MCSRD_A_int)===1'bx ) || ((^MCSRD_A_int)===1'bz )) begin
						OutputCorrupt;
						failedWrite;
					end
					else if( ((^MCSWR_A_int)===1'bx) || ((^MCSWR_A_int)===1'bz)) begin
						OutputCorrupt;
						failedWrite;
					end
					else if( isBitX(KCS_A_int)) begin
						OutputCorrupt;
						failedWrite;
					end

					else if (((^ADME_A_int)===1'bx) ||  ((^ADME_A_int)===1'bz)) begin
						OutputCorrupt;
						failedWrite;
					end
					else if( isBitX(CRE1_A_int) ) begin
						OutputCorrupt;
						failedWrite;
						x_war_message("CRE1");
					end
					else if( isBitX(CRE2_A_int) ) begin
						OutputCorrupt;
						failedWrite;
						x_war_message("CRE2");
					end
					
					else if( (((^FCA1_A_int)=== 1'bx) || ((^FCA1_A_int)=== 1'bz) )&& CRE1_A_int === 1'b1 ) begin
						OutputCorrupt;
						failedWrite;
					end
					else if( (((^FCA2_A_int)=== 1'bx) || ((^FCA2_A_int)=== 1'bz)) && CRE2_A_int === 1'b1 ) begin
						OutputCorrupt;
						failedWrite;
					end

					else if (((^AA_int) === 1'bx) || ((^AA_int) === 1'bz)) begin
						OutputCorrupt;
					end
					else begin
						if (RRE1A_int === 1'b0 && RRE2A_int === 1'b0 ) begin // Operation from Normal Memory
							if (row_redu_valid == 1) begin
								row_redu_valid = 1;
// When Normal Mode
								if (AA_int >= WORDS) begin
									OutputCorrupt;
								end
								else begin
									Read(AA_int,outreg);
									XDOUT=0; #0 DOUT_update=1;

								end
							end
							else begin
								if (RRE1B_int === 1'b1 && RRE2B_int === 1'b1 && CSNB_int === 1'b0) begin
									row_redu_valid = 0;
								end
								else begin
									row_redu_valid = 1;
								end
							end
						end


						else if (RRE1A_int === 1'b1 && RRE2A_int === 1'b0 ) begin //Operation from Redundant Memory1
							if (row_redu_valid == 1) begin

								row_redu_valid = 1;
								Read_redu1(AA_redu_int,outreg);
								XDOUT=0; #0 DOUT_update=1;
							end
							else begin
								if (RRE1B_int === 1'b1 && RRE2B_int === 1'b1 && CSNB_int === 1'b0) begin
									row_redu_valid = 0;
								end
								else begin
									row_redu_valid = 1;
								end
							end
						end // row1


						else if (RRE1A_int === 1'b0 && RRE2A_int === 1'b1 ) begin //Operation from Redundant Memory2
							if (row_redu_valid == 1) begin

								row_redu_valid = 1;
								Read_redu2(AA_redu_int,outreg);
								XDOUT=0; #0 DOUT_update=1;
							end
							else begin
								if (RRE1B_int === 1'b1 && RRE2B_int === 1'b1 && CSNB_int === 1'b0) begin
									row_redu_valid = 0;
								end
								else begin
									row_redu_valid = 1;
								end
							end
						end

						else if (RRE1A_int === 1'b1 && RRE2A_int === 1'b1) begin
							row_redu_valid = 0;
							SAME_VALUE1_RRERD: assert (0) else begin
								if (DISPLAY_CNTRL == 0) begin
									$error("Error: Illegal value for RRERD1=1'b%b and RRERD2=1'b%b in %m at %0t", RRE1A_int, RRE2A_int, $time);
								end
							end
							`ifdef REDU_CORRUPT_CONT
								failedWrite;
								OutputCorrupt;
							`else
								#1 $finish;
							`endif
						end
						else begin
							if (row_redu_valid == 1) begin

								row_redu_valid = 1;
								OutputCorrupt;
							end
							else begin
								if (RRE1B_int === 1'b1 && RRE2B_int === 1'b1 && CSNB_int === 1'b0) begin
									row_redu_valid = 0;
								end
								else begin
									row_redu_valid = 1;
								end
							end
						end
					end
				end
				else if (CSNA_int === 1'b1) begin
//no change in q
				end
				else begin
					OutputCorrupt;
					x_war_message("REN");
				end
			end
		endtask

		task WRITE_ROW;
			begin
//Row Redundancy
				if (CSNB_int === 1'b0) begin
					if( ((^MCSRD_B_int)===1'bx ) || ((^MCSRD_B_int)===1'bz )) begin
						OutputCorrupt;
						failedWrite;
					end
					else if( ((^MCSWR_B_int)===1'bx) || ((^MCSWR_B_int)===1'bz)) begin
						OutputCorrupt;
						failedWrite;
					end
					else if( isBitX(KCS_B_int)) begin
						OutputCorrupt;
						failedWrite;
					end

					else if (((^ADME_B_int)===1'bx) ||  ((^ADME_B_int)===1'bz)) begin
						OutputCorrupt;
						failedWrite;
					end
					
					else if( isBitX(CRE1_B_int) ) begin
						OutputCorrupt;
						failedWrite;
						x_war_message("CRE1");
					end
					else if( isBitX(CRE2_B_int) ) begin
						OutputCorrupt;
						failedWrite;
						x_war_message("CRE2");
					end
					else if( (((^FCA1_B_int)===1'bx) || ((^FCA1_B_int)===1'bz)) && CRE1_B_int === 1'b1 ) begin
						OutputCorrupt;
						failedWrite;
					end
					else if( (((^FCA2_B_int)===1'bx) || ((^FCA2_B_int)===1'bz)) && CRE2_B_int === 1'b1 ) begin
						OutputCorrupt;
						failedWrite;
					end

					else if (((^AB_int) === 1'bx) || ((^AB_int) === 1'bz)) begin
						failedWrite;
					end
					else begin
						if (RRE1B_int === 1'b0 && RRE2B_int === 1'b0) begin // Operation from Normal Memory
							if (row_redu_valid == 1) begin
								row_redu_valid = 1;
// When Normal Mode
								if (AB_int >= WORDS) begin
								end
								else begin
									Write(D_int,BWEN_int,AB_int);
								end
							end
							else begin
								if (RRE1A_int === 1'b1 && RRE2A_int === 1'b1 && CSNA_int === 1'b0) begin
									row_redu_valid = 0;
								end
								else begin
									row_redu_valid = 1;
								end
							end

						end


						else if (RRE1B_int === 1'b1 && RRE2B_int === 1'b0 ) begin //Operation from Redundant Memory1
							if (row_redu_valid == 1) begin
								row_redu_valid = 1;
								Write_redu1(D_int,BWEN_int,AB_redu_int);
							end
							else begin
								if (RRE1A_int === 1'b1 && RRE2A_int === 1'b1 && CSNA_int === 1'b0) begin
									row_redu_valid = 0;
								end
								else begin
									row_redu_valid = 1;
								end
							end
						end // row1


						else if (RRE1B_int === 1'b0 && RRE2B_int === 1'b1 ) begin //Operation from Redundant Memory2
							if (row_redu_valid == 1) begin

								row_redu_valid = 1;
								Write_redu2(D_int,BWEN_int,AB_redu_int);
							end
							else begin
								if (RRE1A_int === 1'b1 && RRE2A_int === 1'b1 && CSNA_int === 1'b0) begin
									row_redu_valid = 0;
								end
								else begin
									row_redu_valid = 1;
								end
							end

						end

						else if (RRE1B_int === 1'b1 && RRE2B_int === 1'b1 ) begin
							row_redu_valid = 0;
							SAME_VALUE1_RREWR: assert (0) else begin
								if (DISPLAY_CNTRL == 0) begin
									$error("Error: Illegal value for RREWR1=1'b%b and RREWR2=1'b%b in %m at %0t", RRE1B_int, RRE2B_int, $time);
								end
							end
							`ifdef REDU_CORRUPT_CONT
								failedWrite;
								OutputCorrupt;
							`else
								#1 $finish;
							`endif
						end
						else begin
							if (row_redu_valid == 1) begin
								failedWrite;
							end
							else begin
								if (RRE1A_int === 1'b1 && RRE2A_int === 1'b1 && CSNA_int === 1'b0) begin
									row_redu_valid = 0;
								end
								else begin
									row_redu_valid = 1;
								end
							end
						end
					end
				end//csn==1
				else if (CSNB_int === 1'b1) begin
//no change in q
				end
				else begin
					failedWrite;
					x_war_message("WEN");
				end
			end
		endtask

//Column Redundancy
		function void Read;
			input [addr_width-1:0] address;
			output [word_width-1:0] data_out;
			integer mux_address;
			integer row_address;
			begin
				mux_address = get_mux_address(address);
				row_address = get_row_address(address);
				col = mem[row_address];
				colR = col[(word_width*mux-1)+r_bit*2 : (64 + r_bit)];
				colL = col[(63 + r_bit):0];
				
//left
				if(CRE1_ === 1'b1 && FCA1_ < 32) begin
					k=0;
					for(i=0;i<64;i=i+1) begin
						j = i >> 1;
						h= 31 -j;
						
						if(h>FCA1_) begin
							colLL[i] = colL[k];
							k=k+1;
						end
						else if(h===FCA1_) begin
							colLL[i] = colL[k+r_bit];
							k=k+1;
						end
						else if(h<FCA1_) begin
							colLL[i] = colL[k+r_bit];
							k=k+1;
						end
					end
				end
				else if(CRE1_ === 1'b1 && FCA1_ >= 32) begin
					colLL[63:0] = colL[63:0];
					if (DISPLAY_CNTRL == 0) begin
						$display("Warning : Outof range FCA1 bit No left Shifting in %m at %0t", $time);
					end
				end
				else if(CRE1_ === 1'b0) begin
					colLL[63:0] = colL[63:0];
				end
				
//right
				if(CRE2_ === 1'b1 && FCA2_ < 32) begin
					k=0;
					for(i=0; i<64; i=i+1) begin
						j = i >> 1;
						if( j < FCA2_ ) begin
							colRR[i] = colR[k];
							k=k+1;
						end
						else if(j === FCA2_) begin
							colRR[i] = colR[k];
							k=k+1;
						end
						else if(j > FCA2_) begin
							colRR[i] = colR[k+r_bit];
							k=k+1;
						end
					end
				end
				else if(CRE2_ === 1'b1 && FCA2_ >= 32) begin
					colRR[63:0] = colR[63+r_bit:r_bit];
					if (DISPLAY_CNTRL == 0) begin
						$display("Warning : Outof range FCA2 bit No Right Shifting in %m at %0t", $time);
					end
				end
				
				else if(CRE2_ === 1'b0) begin
					colRR[63:0] = colR[63+r_bit:r_bit];
				end
				
				for(i=0; i<64; i=i+1) begin
					outreg_tmp[i] = colLL[(i*mux + mux_address)];
				end
				for(i=64; i<word_width; i=i+1) begin
					outreg_tmp[i] = colRR[(i-64)*mux + mux_address];
				end

				data_out = outreg_tmp;
			end
		endfunction

		function void Write;
			input [word_width-1:0] data;
			input [word_width-1:0] bwen;
			input [addr_width-1:0] address;
			integer mux_address;
			integer row_address;
			begin
				mux_address = get_mux_address(address);
				row_address = get_row_address(address);
				col = mem[row_address];
				colL = col[(63 + r_bit):0];
				colR = col[(word_width*mux-1)+r_bit*2 : (64 + r_bit)];
				
//left
				if(CRE1_ === 1'b1 && FCA1_ < 32) begin
					k=0;
					for(i=0; i<64; i=i+1) begin
						j = i >> 1;
						h= 31 -j;
						
						if(h>FCA1_) begin
							colLL[i] = colL[k];
							k=k+1;
						end
						else if(h===FCA1_) begin
							colLL[i] = colL[k+r_bit];
							k=k+1;
						end
						else if(h<FCA1_) begin
							colLL[i] = colL[k+r_bit];
							k=k+1;
						end
					end
				end
				else if(CRE1_ === 1'b1 && FCA1_ >= 32) begin
					colLL[63:0] = colL[63:0];
					if (DISPLAY_CNTRL == 0) begin
						$display("Warning : Outof range FCA1 bit No left Shifting in %m at %0t", $time);
					end
				end
				
				else if(CRE1_ === 1'b0) begin
					colLL[63:0] = colL[63:0];
				end
				
				for(i=0; i<64; i=i+1) begin
					remained_data_L[i] = colLL[i*mux + mux_address];
				end
				
				new_data_L = (((data[63:0] | bwen[63:0] ) & ~bwen[63:0]) | (remained_data_L & bwen[63:0]));
				
				for(i=0;i<64;i=i+1) begin
					colLL[i*mux + mux_address] = new_data_L[i];
				end
				
				if(CRE1_ === 1'b1 && FCA1_ < 32) begin
					k=0;
					for(i=0;i<64;i=i+1) begin
						j = i >> 1;
						h= 31 -j;
						
						if(h>FCA1_) begin
							colL[k] = colLL[i];
							k=k+1;
						end
						else if(h===FCA1_) begin
							colL[k+r_bit] = colLL[i];
							k=k+1;
						end
						else if(h<FCA1_) begin
							colL[k+r_bit] = colLL[i];
							k=k+1;
						end
					end
				end
				else if(CRE1_ === 1'b1 && FCA1_ >= 32) begin
					colL[63:0]=colLL[63:0];
					if (DISPLAY_CNTRL == 0) begin
						$display("Warning : Outof range FCA1 bit No left Shifting in %m at %0t", $time);
					end
				end
				
				else if(CRE1_ === 1'b0) begin
					colL[63:0]=colLL[63:0];
				end
//right
//right
				if(CRE2_ === 1'b1 && FCA2_ < 32) begin
					k=0;
					for(i=0;i<64;i=i+1) begin
						j = i >> 1;
						if( j < FCA2_ ) begin
							colRR[i] = colR[k];
							k=k+1;
						end
						else if(j === FCA2_) begin
							colRR[i] = colR[k];
							k=k+1;
						end
						else if(j > FCA2_) begin
							colRR[i] = colR[k+r_bit];
							k=k+1;
						end
					end
				end
				else if(CRE2_ === 1'b1 && FCA2_ >= 32) begin
					colRR[63:0] = colR[63+r_bit:r_bit];
					if (DISPLAY_CNTRL == 0) begin
						$display("Warning : Outof range FCA2 bit No Right Shifting in %m at %0t", $time);
					end
				end
				
				else if(CRE2_ === 1'b0) begin
					colRR[63:0] = colR[63+r_bit:r_bit];
				end
				
				for(i=64;i<word_width; i=i+1) begin
					remained_data_R[i-64] = colRR[(i-64)*mux + mux_address];
				end
				
				new_data_R = (((data[word_width-1:64] | bwen[word_width-1:64] ) & ~bwen[word_width-1:64]) | (remained_data_R & bwen[word_width-1:64]));
				
				
				for(i=64; i<word_width; i=i+1) begin
					colRR[(i-64)*mux + mux_address] =  new_data_R[i-64];
				end
				
				if(CRE2_ === 1'b1 && FCA2_ < 32) begin
					k=0;
					for(i=0;i<64;i=i+1) begin
						j = i >> 1;
						if( j < FCA2_ ) begin
							colR[k] = colRR[i];
							k=k+1;
						end
						else if(j === FCA2_) begin
							colR[k] = colRR[i];
							k=k+1;
						end
						else if(j > FCA2_) begin
							colR[k+r_bit] = colRR[i];
							k=k+1;
						end
					end
				end
				else if(CRE2_ === 1'b1 && FCA2_ >= 32) begin
					colR[63+r_bit:r_bit]=colRR[63:0];
					if (DISPLAY_CNTRL == 0) begin
						$display("Warning : Outof range FCA2 bit No Right Shifting in %m at %0t", $time);
					end
				end
				
				else if(CRE2_ === 1'b0) begin
					colR[63+r_bit:r_bit]=colRR[63:0];
				end
				col[63+r_bit:0] = colL[63+r_bit:0];
				col[(word_width*mux)-1+r_bit*2 : 64+r_bit] = colR[63+r_bit:0];
				mem[row_address] = col;
			end
		endfunction

//Redundancy memory1
		function void Read_redu1;
			input [addr_width-1:0] address;
			output [word_width-1:0] data_out;
			integer mux_address;
			integer row_address;
			begin
				mux_address = get_mux_address(address);
				row_address = get_row_address(address);
				col = mem1[row_address];
				colL = col[(63 + r_bit):0];
				colR = col[(word_width*mux-1)+r_bit*2 : (64 + r_bit)];
				
//left
				if(CRE1_ === 1'b1 && FCA1_ < 32) begin
					k=0;
					for(i=0;i<64;i=i+1) begin
						j = i >> 1;
						h= 31 -j;
						
						if(h>FCA1_) begin
							colLL[i] = colL[k];
							k=k+1;
						end
						else if(h===FCA1_) begin
							colLL[i] = colL[k+r_bit];
							k=k+1;
						end
						else if(h<FCA1_) begin
							colLL[i] = colL[k+r_bit];
							k=k+1;
						end
					end
				end
				else if(CRE1_ === 1'b1 && FCA1_ >= 32) begin
					colLL[63:0] = colL[63:0];
					if (DISPLAY_CNTRL == 0) begin
						$display("Warning : Outof range FCA1 bit No left Shifting in %m at %0t", $time);
					end
				end
				else if(CRE1_ === 1'b0) begin
					colLL[63:0] = colL[63:0];
				end
				
//right
				if(CRE2_ === 1'b1 && FCA2_ < 32) begin
					k=0;
					for(i=0; i<64; i=i+1) begin
						j = i >> 1;
						if( j < FCA2_ ) begin
							colRR[i] = colR[k];
							k=k+1;
						end
						else if(j === FCA2_) begin
							colRR[i] = colR[k];
							k=k+1;
						end
						else if(j > FCA2_) begin
							colRR[i] = colR[k+r_bit];
							k=k+1;
						end
					end
				end
				else if(CRE2_ === 1'b1 && FCA2_ >= 32) begin
					colRR[63:0] = colR[63+r_bit:r_bit];
					if (DISPLAY_CNTRL == 0) begin
						$display("Warning : Outof range FCA2 bit No Right Shifting in %m at %0t", $time);
					end
				end
				else if(CRE2_ === 1'b0) begin
					colRR[63:0] = colR[63+r_bit:r_bit];
				end
				
				for(i=0; i<64; i=i+1) begin
					outreg_tmp[i] = colLL[(i*mux + mux_address)];
				end
				for(i=64; i<word_width; i=i+1) begin
					outreg_tmp[i] = colRR[(i-64)*mux + mux_address];
				end
				data_out = outreg_tmp;
			end
		endfunction

		function void Write_redu1;
			input [word_width-1:0] data;
			input [word_width-1:0] bwen;
			input [addr_width-1:0] address;
			integer mux_address;
			integer row_address;
			begin
				mux_address = get_mux_address(address);
				row_address = get_row_address(address);
				col = mem1[row_address];
				colL = col[(63 + r_bit):0];
				colR = col[(word_width*mux-1)+r_bit*2 : (64 + r_bit)];
				
//left
				if(CRE1_ === 1'b1 && FCA1_ < 32) begin
					k=0;
					for(i=0; i<64; i=i+1) begin
						j = i >> 1;
						h= 31 -j;
						
						if(h>FCA1_) begin
							colLL[i] = colL[k];
							k=k+1;
						end
						else if(h===FCA1_) begin
							colLL[i] = colL[k+r_bit];
							k=k+1;
						end
						else if(h<FCA1_) begin
							colLL[i] = colL[k+r_bit];
							k=k+1;
						end
					end
				end
				else if(CRE1_ === 1'b1 && FCA1_ >= 32) begin
					colLL[63:0] = colL[63:0];
					if (DISPLAY_CNTRL == 0) begin
						$display("Warning : Outof range FCA1 bit No left Shifting in %m at %0t", $time);
					end
				end
				else if(CRE1_ === 1'b0) begin
					colLL[63:0] = colL[63:0];
				end
				for(i=0; i<64; i=i+1) begin
					remained_data_L[i] = colLL[i*mux + mux_address];
				end
				
				new_data_L = (((data[63:0] | bwen[63:0] ) & ~bwen[63:0]) | (remained_data_L & bwen[63:0]));
				
				for(i=0;i<64;i=i+1) begin
					colLL[i*mux + mux_address] = new_data_L[i];
				end
				
				if(CRE1_ === 1'b1 && FCA1_ < 32) begin
					k=0;
					for(i=0;i<64;i=i+1) begin
						j = i >> 1;
						h= 31 -j;
						
						if(h>FCA1_) begin
							colL[k] = colLL[i];
							k=k+1;
						end
						else if(h===FCA1_) begin
							colL[k+r_bit] = colLL[i];
							k=k+1;
						end
						else if(h<FCA1_) begin
							colL[k+r_bit] = colLL[i];
							k=k+1;
						end
					end
				end
				else if(CRE1_ === 1'b1 && FCA1_ >= 32) begin
					colL[63:0]=colLL[63:0];
					if (DISPLAY_CNTRL == 0) begin
						$display("Warning : Outof range FCA1 bit No left Shifting in %m at %0t", $time);
					end
				end
				else if(CRE1_ === 1'b0) begin
					colL[63:0]=colLL[63:0];
				end
//right
//right
				if(CRE2_ === 1'b1 && FCA2_ < 32) begin
					k=0;
					for(i=0;i<64;i=i+1) begin
						j = i >> 1;
						if( j < FCA2_ ) begin
							colRR[i] = colR[k];
							k=k+1;
						end
						else if(j === FCA2_) begin
							colRR[i] = colR[k];
							k=k+1;
						end
						else if(j > FCA2_) begin
							colRR[i] = colR[k+r_bit];
							k=k+1;
						end
					end
				end
				else if(CRE2_ === 1'b1 && FCA2_ >= 32) begin
					colRR[63:0] = colR[63+r_bit:r_bit];
					if (DISPLAY_CNTRL == 0) begin
						$display("Warning : Outof range FCA2 bit No Right Shifting in %m at %0t", $time);
					end
				end
				else if(CRE2_ === 1'b0) begin
					colRR[63:0] = colR[63+r_bit:r_bit];
				end
				
				for(i=64;i<word_width; i=i+1) begin
					remained_data_R[i-64] = colRR[(i-64)*mux + mux_address];
				end
				
				new_data_R = (((data[word_width-1:64] | bwen[word_width-1:64] ) & ~bwen[word_width-1:64]) | (remained_data_R & bwen[word_width-1:64]));
				
				
				for(i=64; i<word_width; i=i+1) begin
					colRR[(i-64)*mux + mux_address] =  new_data_R[i-64];
				end
				
				if(CRE2_ === 1'b1 && FCA2_ < 32) begin
					k=0;
					for(i=0;i<64;i=i+1) begin
						j = i >> 1;
						if( j < FCA2_ ) begin
							colR[k] = colRR[i];
							k=k+1;
						end
						else if(j === FCA2_) begin
							colR[k] = colRR[i];
							k=k+1;
						end
						else if(j > FCA2_) begin
							colR[k+r_bit] = colRR[i];
							k=k+1;
						end
					end
				end
				else if(CRE2_ === 1'b1 && FCA2_ >= 32) begin
					colR[63+r_bit:r_bit]=colRR[63:0];
					if (DISPLAY_CNTRL == 0) begin
						$display("Warning : Outof range FCA2 bit No Right Shifting in %m at %0t", $time);
					end
				end
				else if(CRE2_ === 1'b0) begin
					colR[63+r_bit:r_bit]=colRR[63:0];
				end
				
				
				col[63+r_bit:0] = colL[63+r_bit:0];
				col[(word_width*mux)-1+r_bit*2 : 64+r_bit] = colR[63+r_bit:0];
				mem1[row_address] = col;
			end
		endfunction

//Redundancy Memory2
		function void Read_redu2;
			input [addr_width-1:0] address;
			output [word_width-1:0] data_out;
			integer mux_address;
			integer row_address;
			begin
				mux_address = get_mux_address(address);
				row_address = get_row_address(address);
				col = mem2[row_address];
				colL = col[(63 + r_bit):0];
				colR = col[(word_width*mux-1)+r_bit*2 : (64 + r_bit)];
				
//left
				if(CRE1_ === 1'b1 && FCA1_ < 32) begin
					k=0;
					for(i=0;i<64;i=i+1) begin
						j = i >> 1;
						h= 31 -j;
						
						if(h>FCA1_) begin
							colLL[i] = colL[k];
							k=k+1;
						end
						else if(h===FCA1_) begin
							colLL[i] = colL[k+r_bit];
							k=k+1;
						end
						else if(h<FCA1_) begin
							colLL[i] = colL[k+r_bit];
							k=k+1;
						end
					end
				end
				else if(CRE1_ === 1'b1 && FCA1_ >= 32) begin
					colLL[63:0] = colL[63:0];
					if (DISPLAY_CNTRL == 0) begin
						$display("Warning : Outof range FCA1 bit No left Shifting in %m at %0t", $time);
					end
				end
				else if(CRE1_ === 1'b0) begin
					colLL[63:0] = colL[63:0];
				end
				
//right
				if(CRE2_ === 1'b1 && FCA2_ < 32) begin
					k=0;
					for(i=0; i<64; i=i+1) begin
						j = i >> 1;
						if( j < FCA2_ ) begin
							colRR[i] = colR[k];
							k=k+1;
						end
						else if(j === FCA2_) begin
							colRR[i] = colR[k];
							k=k+1;
						end
						else if(j > FCA2_) begin
							colRR[i] = colR[k+r_bit];
							k=k+1;
						end
					end
				end
				else if(CRE2_ === 1'b1 && FCA2_ >= 32) begin
					colRR[63:0] = colR[63+r_bit:r_bit];
					if (DISPLAY_CNTRL == 0) begin
						$display("Warning : Outof range FCA2 bit No Right Shifting in %m at %0t", $time);
					end
				end
				else if(CRE2_ === 1'b0) begin
					colRR[63:0] = colR[63+r_bit:r_bit];
				end
				
				for(i=0; i<64; i=i+1) begin
					outreg_tmp[i] = colLL[(i*mux + mux_address)];
				end
				for(i=64; i<word_width; i=i+1) begin
					outreg_tmp[i] = colRR[(i-64)*mux + mux_address];
				end
				data_out = outreg_tmp;
			end
		endfunction

		function void Write_redu2;
			input [word_width-1:0] data;
			input [word_width-1:0] bwen;
			input [addr_width-1:0] address;
			integer mux_address;
			integer row_address;
			begin
				mux_address = get_mux_address(address);
				row_address = get_row_address(address);
				col = mem2[row_address];
				colL = col[(63 + r_bit):0];
				colR = col[(word_width*mux-1)+r_bit*2 : (64 + r_bit)];
				
//left
				if(CRE1_ === 1'b1 && FCA1_ < 32) begin
					k=0;
					for(i=0; i<64; i=i+1) begin
						j = i >> 1;
						h= 31 -j;
						
						if(h>FCA1_) begin
							colLL[i] = colL[k];
							k=k+1;
						end
						else if(h===FCA1_) begin
							colLL[i] = colL[k+r_bit];
							k=k+1;
						end
						else if(h<FCA1_) begin
							colLL[i] = colL[k+r_bit];
							k=k+1;
						end
					end
				end
				else if(CRE1_ === 1'b1 && FCA1_ >= 32) begin
					colLL[63:0] = colL[63:0];
					if (DISPLAY_CNTRL == 0) begin
						$display("Warning : Outof range FCA1 bit No left Shifting in %m at %0t", $time);
					end
				end
				else if(CRE1_ === 1'b0) begin
					colLL[63:0] = colL[63:0];
				end
				
				for(i=0; i<64; i=i+1) begin
					remained_data_L[i] = colLL[i*mux + mux_address];
				end
				
				new_data_L = (((data[63:0] | bwen[63:0] ) & ~bwen[63:0]) | (remained_data_L & bwen[63:0]));
				
				for(i=0;i<64;i=i+1) begin
					colLL[i*mux + mux_address] = new_data_L[i];
				end
				
				if(CRE1_ === 1'b1 && FCA1_ < 32) begin
					k=0;
					for(i=0;i<64;i=i+1) begin
						j = i >> 1;
						h= 31 -j;
						
						if(h>FCA1_) begin
							colL[k] = colLL[i];
							k=k+1;
						end
						else if(h===FCA1_) begin
							colL[k+r_bit] = colLL[i];
							k=k+1;
						end
						else if(h<FCA1_) begin
							colL[k+r_bit] = colLL[i];
							k=k+1;
						end
					end
				end
				else if(CRE1_ === 1'b1 && FCA1_ >= 32) begin
					colL[63:0]=colLL[63:0];
					if (DISPLAY_CNTRL == 0) begin
						$display("Warning : Outof range FCA1 bit No left Shifting in %m at %0t", $time);
					end
				end
				else if(CRE1_ === 1'b0) begin
					colL[63:0]=colLL[63:0];
				end
//right
//right
				if(CRE2_ === 1'b1 && FCA2_ < 32) begin
					k=0;
					for(i=0;i<64;i=i+1) begin
						j = i >> 1;
						if( j < FCA2_ ) begin
							colRR[i] = colR[k];
							k=k+1;
						end
						else if(j === FCA2_) begin
							colRR[i] = colR[k];
							k=k+1;
						end
						else if(j > FCA2_) begin
							colRR[i] = colR[k+r_bit];
							k=k+1;
						end
					end
				end
				else if(CRE2_ === 1'b1 && FCA2_ >= 32) begin
					colRR[63:0] = colR[63+r_bit:r_bit];
					if (DISPLAY_CNTRL == 0) begin
						$display("Warning : Outof range FCA2 bit No Right Shifting in %m at %0t", $time);
					end
				end
				else if(CRE2_ === 1'b0) begin
					colRR[63:0] = colR[63+r_bit:r_bit];
				end
				
				for(i=64;i<word_width; i=i+1) begin
					remained_data_R[i-64] = colRR[(i-64)*mux + mux_address];
				end
				
				new_data_R = (((data[word_width-1:64] | bwen[word_width-1:64] ) & ~bwen[word_width-1:64]) | (remained_data_R & bwen[word_width-1:64]));
				
				
				for(i=64; i<word_width; i=i+1) begin
					colRR[(i-64)*mux + mux_address] =  new_data_R[i-64];
				end
				
				if(CRE2_ === 1'b1 && FCA2_ < 32) begin
					k=0;
					for(i=0;i<64;i=i+1) begin
						j = i >> 1;
						if( j < FCA2_ ) begin
							colR[k] = colRR[i];
							k=k+1;
						end
						else if(j === FCA2_) begin
							colR[k] = colRR[i];
							k=k+1;
						end
						else if(j > FCA2_) begin
							colR[k+r_bit] = colRR[i];
							k=k+1;
						end
					end
				end
				else if(CRE2_ === 1'b1 && FCA2_ >= 32) begin
					colR[63+r_bit:r_bit]=colRR[63:0];
					if (DISPLAY_CNTRL == 0) begin
						$display("Warning : Outof range FCA2 bit No Right Shifting in %m at %0t", $time);
					end
				end
				else if(CRE2_ === 1'b0) begin
					colR[63+r_bit:r_bit]=colRR[63:0];
				end
				
				
				col[63+r_bit:0] = colL[63+r_bit:0];
				col[(word_width*mux)-1+r_bit*2 : 64+r_bit] = colR[63+r_bit:0];
				mem2[row_address] = col;
//if centraldecode_enable
			end
		endfunction

		task write_out_low;
			begin
				outreg = word0;
			end
		endtask

		task write_out_high;
			begin
				outreg = word1;
			end
		endtask

		task failedWrite;
			begin
				for(i=0; i<word_depth/mux; i=i+1)
					mem[i] = rowx;
				for(i=0; i<4; i=i+1)
					mem1[i] = rowx;
				for(i=0; i<4; i=i+1)
					mem2[i] = rowx;

			end
		endtask

		task Corrupt_Redu_Mem1;
			begin
				for(i=0; i<4; i=i+1)
					mem1[i] = rowx;
			end
		endtask


		task Corrupt_Redu_Mem2;
			begin
				for(i=0; i<4; i=i+1)
					mem2[i] = rowx;
			end
		endtask


		task write_out_x;
			begin
				XDOUT=1'b1; #0 DOUT_update=1'b1;
			end
		endtask

		task write_out_x_L;
			begin
				uDQ0.DOUT<=1'bx;
				uDQ1.DOUT<=1'bx;
				uDQ2.DOUT<=1'bx;
				uDQ3.DOUT<=1'bx;
				uDQ4.DOUT<=1'bx;
				uDQ5.DOUT<=1'bx;
				uDQ6.DOUT<=1'bx;
				uDQ7.DOUT<=1'bx;
				uDQ8.DOUT<=1'bx;
				uDQ9.DOUT<=1'bx;
				uDQ10.DOUT<=1'bx;
				uDQ11.DOUT<=1'bx;
				uDQ12.DOUT<=1'bx;
				uDQ13.DOUT<=1'bx;
				uDQ14.DOUT<=1'bx;
				uDQ15.DOUT<=1'bx;
				uDQ16.DOUT<=1'bx;
				uDQ17.DOUT<=1'bx;
				uDQ18.DOUT<=1'bx;
				uDQ19.DOUT<=1'bx;
				uDQ20.DOUT<=1'bx;
				uDQ21.DOUT<=1'bx;
				uDQ22.DOUT<=1'bx;
				uDQ23.DOUT<=1'bx;
				uDQ24.DOUT<=1'bx;
				uDQ25.DOUT<=1'bx;
				uDQ26.DOUT<=1'bx;
				uDQ27.DOUT<=1'bx;
				uDQ28.DOUT<=1'bx;
				uDQ29.DOUT<=1'bx;
				uDQ30.DOUT<=1'bx;
				uDQ31.DOUT<=1'bx;
				uDQ32.DOUT<=1'bx;
				uDQ33.DOUT<=1'bx;
				uDQ34.DOUT<=1'bx;
				uDQ35.DOUT<=1'bx;
				uDQ36.DOUT<=1'bx;
				uDQ37.DOUT<=1'bx;
				uDQ38.DOUT<=1'bx;
				uDQ39.DOUT<=1'bx;
				uDQ40.DOUT<=1'bx;
				uDQ41.DOUT<=1'bx;
				uDQ42.DOUT<=1'bx;
				uDQ43.DOUT<=1'bx;
				uDQ44.DOUT<=1'bx;
				uDQ45.DOUT<=1'bx;
				uDQ46.DOUT<=1'bx;
				uDQ47.DOUT<=1'bx;
				uDQ48.DOUT<=1'bx;
				uDQ49.DOUT<=1'bx;
				uDQ50.DOUT<=1'bx;
				uDQ51.DOUT<=1'bx;
				uDQ52.DOUT<=1'bx;
				uDQ53.DOUT<=1'bx;
				uDQ54.DOUT<=1'bx;
				uDQ55.DOUT<=1'bx;
				uDQ56.DOUT<=1'bx;
				uDQ57.DOUT<=1'bx;
				uDQ58.DOUT<=1'bx;
				uDQ59.DOUT<=1'bx;
				uDQ60.DOUT<=1'bx;
				uDQ61.DOUT<=1'bx;
				uDQ62.DOUT<=1'bx;
				uDQ63.DOUT<=1'bx;
			end
		endtask

		task write_out_x_R;
			begin
				uDQ64.DOUT<=1'bx;
				uDQ65.DOUT<=1'bx;
				uDQ66.DOUT<=1'bx;
				uDQ67.DOUT<=1'bx;
				uDQ68.DOUT<=1'bx;
				uDQ69.DOUT<=1'bx;
				uDQ70.DOUT<=1'bx;
				uDQ71.DOUT<=1'bx;
				uDQ72.DOUT<=1'bx;
				uDQ73.DOUT<=1'bx;
				uDQ74.DOUT<=1'bx;
				uDQ75.DOUT<=1'bx;
				uDQ76.DOUT<=1'bx;
				uDQ77.DOUT<=1'bx;
				uDQ78.DOUT<=1'bx;
				uDQ79.DOUT<=1'bx;
				uDQ80.DOUT<=1'bx;
				uDQ81.DOUT<=1'bx;
				uDQ82.DOUT<=1'bx;
				uDQ83.DOUT<=1'bx;
				uDQ84.DOUT<=1'bx;
				uDQ85.DOUT<=1'bx;
				uDQ86.DOUT<=1'bx;
				uDQ87.DOUT<=1'bx;
				uDQ88.DOUT<=1'bx;
				uDQ89.DOUT<=1'bx;
				uDQ90.DOUT<=1'bx;
				uDQ91.DOUT<=1'bx;
				uDQ92.DOUT<=1'bx;
				uDQ93.DOUT<=1'bx;
				uDQ94.DOUT<=1'bx;
				uDQ95.DOUT<=1'bx;
				uDQ96.DOUT<=1'bx;
				uDQ97.DOUT<=1'bx;
				uDQ98.DOUT<=1'bx;
				uDQ99.DOUT<=1'bx;
				uDQ100.DOUT<=1'bx;
				uDQ101.DOUT<=1'bx;
				uDQ102.DOUT<=1'bx;
				uDQ103.DOUT<=1'bx;
				uDQ104.DOUT<=1'bx;
				uDQ105.DOUT<=1'bx;
				uDQ106.DOUT<=1'bx;
				uDQ107.DOUT<=1'bx;
				uDQ108.DOUT<=1'bx;
				uDQ109.DOUT<=1'bx;
				uDQ110.DOUT<=1'bx;
				uDQ111.DOUT<=1'bx;
				uDQ112.DOUT<=1'bx;
				uDQ113.DOUT<=1'bx;
				uDQ114.DOUT<=1'bx;
				uDQ115.DOUT<=1'bx;
				uDQ116.DOUT<=1'bx;
				uDQ117.DOUT<=1'bx;
				uDQ118.DOUT<=1'bx;
				uDQ119.DOUT<=1'bx;
				uDQ120.DOUT<=1'bx;
				uDQ121.DOUT<=1'bx;
				uDQ122.DOUT<=1'bx;
				uDQ123.DOUT<=1'bx;
				uDQ124.DOUT<=1'bx;
				uDQ125.DOUT<=1'bx;
				uDQ126.DOUT<=1'bx;
				uDQ127.DOUT<=1'bx;
			end
		endtask

		task PartialOutputCorrupt;
			integer i;
			begin
				for ( i=0; i< word_width; i++ ) begin
					if ( BWEN_int[i] === 1'b0 )
						outreg[i] = 1'bx;
				end
			end
		endtask

		task write_sout_x;
			begin
				T_check_violation = 1'b1;
			end
		endtask

		function void x_war_message;
			input [255:0] signal;
			begin
				IMPT_SIGNAL_X: assert (0) else begin
					if (DISPLAY_CNTRL == 0 && $time != 0) begin
						$error("%0t Error : Invalid value on  memory instance %m:: %0s", $time, signal);
					end
				end

			end
		endfunction

		function integer get_mux_address;
			input [addr_width-1:0] Address;
			begin
				return 0;
			end
		endfunction

		function integer get_row_address;
			input [addr_width-1:0] Address;
			begin
				return Address[addr_width-1:0];
			end
		endfunction

		function isBitX;
			input bitval;
			begin
				isBitX = ( bitval===1'bx || bitval===1'bz ) ? 1'b1 : 1'b0;
			end
		endfunction

		task OutputCorrupt;
			begin
				XDOUT=1'b1; #0 DOUT_update=1'b1;
			end
		endtask


		task write_A_x;
			begin
				if ( ^AB_int === 1'bx ) begin
					failedWrite;
				end
				else begin
					if (RRE1B_int === 1'b0 && RRE2B_int === 1'b0) begin // Operation from Normal Memory
						Write(wordx,BWEN_int,AB_int);
					end

					else if (RRE1B_int === 1'b1 && RRE2B_int === 1'b0 ) begin //Operation from Redundant Memory1
						Write_redu1(wordx,BWEN_int,AB_redu_int);
					end // row1


					else if (RRE1B_int === 1'b0 && RRE2B_int === 1'b1 ) begin //Operation from Redundant Memory2
						Write_redu2(wordx,BWEN_int,AB_redu_int);
					end
				end
			end
		endtask

		task write_BWEN_x;
			input integer fail_bit;
			begin
				if ( ^AB_int === 1'bx ) begin
					failedWrite;
				end
				else begin
					BWEN_int[fail_bit]=1'bx;
					if (RRE1B_int === 1'b0 && RRE2B_int === 1'b0) begin // Operation from Normal Memory
						Write(D_int,BWEN_int,AB_int);
					end

					else if (RRE1B_int === 1'b1 && RRE2B_int === 1'b0 ) begin //Operation from Redundant Memory1
						Write_redu1(D_int,BWEN_int,AB_redu_int);
					end // row1


					else if (RRE1B_int === 1'b0 && RRE2B_int === 1'b1 ) begin //Operation from Redundant Memory2
						Write_redu2(D_int,BWEN_int,AB_redu_int);
					end
				end
			end
		endtask

		function void load_mem;
			input [1000*8-1:0] filename;
			reg[word_width-1:0] mem_array [0:WORDS-1];
			reg[word_width-1:0] mem_word;
			integer adr_cnt;
			begin
				$readmemh(filename, mem_array);
				RRE1A_int = 1'b0;
				RRE1B_int = 1'b0;
				RRE2A_int =1'b0;
				RRE2B_int =1'b0;

				for( adr_cnt = 0; adr_cnt < WORDS ; adr_cnt = adr_cnt + 1)
				begin
					mem_word = mem_array[adr_cnt];
					if (BACKDOOR_DISPLAY_CNTRL == 0) begin
						$display("data_loading addr: %0x Data : %0x",adr_cnt,mem_word);
					end

					if (RRE1B_int === 1'b0 && RRE2B_int === 1'b0) begin // Operation from Normal Memory
						Write(mem_word,word0,adr_cnt);
					end

					else if (RRE1B_int === 1'b1 && RRE2B_int === 1'b0 ) begin //Operation from Redundant Memory1
						Write_redu1(mem_word,word0,adr_cnt);
					end // row1


					else if (RRE1B_int === 1'b0 && RRE2B_int === 1'b1 ) begin //Operation from Redundant Memory2
						Write_redu2(mem_word,word0,adr_cnt);
					end
					else begin
						$display("Invalid Operation");
					end

				end
			end
		endfunction


		function void write_mem;
			input [addr_width-1:0] addr_mem;
			input[word_width-1:0] mem_word;
			begin

				RRE1A_int = 1'b0;
				RRE1B_int = 1'b0;
				RRE2A_int =1'b0;
				RRE2B_int =1'b0;
				if (BACKDOOR_DISPLAY_CNTRL == 0) begin
					$display("data_loading addr: %0x Data : %0x",addr_mem,mem_word);
				end

				if (RRE1B_int === 1'b0 && RRE2B_int === 1'b0) begin // Operation from Normal Memory
					Write(mem_word,word0,addr_mem);
				end

				else if (RRE1B_int === 1'b1 && RRE2B_int === 1'b0 ) begin //Operation from Redundant Memory1
					Write_redu1(mem_word,word0,addr_mem);
				end // row1


				else if (RRE1B_int === 1'b0 && RRE2B_int === 1'b1 ) begin //Operation from Redundant Memory2
					Write_redu2(mem_word,word0,addr_mem);
				end
				else begin
					$display("Invalid Operation");
				end

			end
		endfunction

		function void read_mem;
			input [addr_width-1:0] addr_mem;
			output [word_width-1:0] data_out;
			begin
				RRE1A_int = 1'b0;
				RRE1B_int = 1'b0;
				RRE2A_int =1'b0;
				RRE2B_int =1'b0;

				if (RRE1B_int === 1'b0 && RRE2B_int === 1'b0) begin // Operation from Normal Memory
					Read(addr_mem,outreg_backdoor);
					data_out = outreg_backdoor;
				end


				else if (RRE1B_int === 1'b1 && RRE2B_int === 1'b0 ) begin //Operation from Redundant Memory1
					Read_redu1(addr_mem,outreg_backdoor);
					data_out = outreg_backdoor;
				end // row1


				else if (RRE1B_int === 1'b0 && RRE2B_int === 1'b1 ) begin //Operation from Redundant Memory2
					Read_redu2(addr_mem,outreg_backdoor);
					data_out = outreg_backdoor;
				end
				else begin
					$display("Invalid Operation");
				end
				if (BACKDOOR_DISPLAY_CNTRL == 0) begin
					$display("data_reading addr: %0x ",addr_mem);
				end
			end
		endfunction

		function void dump_mem;
			input [1000*8-1:0] filename_dump;
			integer adr_cnt, tmp_dump_file;
			begin
				tmp_dump_file = $fopen(filename_dump);
				for( adr_cnt = 0; adr_cnt < WORDS ; adr_cnt = adr_cnt + 1)
				begin

					if (RRE1A_int === 1'b0 && RRE2A_int === 1'b0) begin
						Read(adr_cnt,outreg_backdoor);
					end
					else if (RRE1A_int === 1'b1 && RRE2A_int === 1'b0 ) begin
						Read_redu1(adr_cnt,outreg_backdoor);
					end
					else if (RRE1A_int === 1'b0 && RRE2A_int === 1'b1 ) begin //Operation from Redundant Memory2
						Read_redu2(adr_cnt,outreg_backdoor);
					end
					else begin
						$display("Invalid Operation");
					end
					$fdisplay(tmp_dump_file, "%h", outreg_backdoor);
				end
				$fclose(tmp_dump_file);
			end
		endfunction
		function is_contention;
			input [ADDR_WIDTH-1:0] aa;
			input [ADDR_WIDTH-1:0] ab;
			input [1 :0] aa_redu;
			input [1 :0] ab_redu;
			input rre1a;
			input rre1b;
			input rre2a;
			input rre2b;
			reg result;
			begin
				if ((rre1a==0 && rre1b==0) && (rre2a==0 && rre2b==0)) begin
					if (aa == ab) begin
						result = 1'b1;
					end else begin
						result = 1'b0;
					end
				end
				else if ((rre1a==1 && rre1b==1) && (rre2a==0 && rre2b==0)) begin
					if (aa_redu == ab_redu) begin
						result = 1'b1;
					end else begin
						result = 1'b0;
					end
				end
				else if ((rre1a==0 && rre1b==0) && (rre2a==1 && rre2b==1)) begin
					if (aa_redu == ab_redu) begin
						result = 1'b1;
					end else begin
						result = 1'b0;
					end
				end
				else begin
					result = 1'b0;
				end
				is_contention = result;
			end
		endfunction

		wire contA_flag = (CSNA_int == 1'b0 && CSNB_int == 1'b0) && ((is_contention(AA_int,AB_int,AA_redu_int,AB_redu_int,RRE1A_int,RRE1B_int,RRE2A_int,RRE2B_int)));
		wire contB_flag = (CSNA_int == 1'b0 && CSNB_int == 1'b0) && ((is_contention(AA_int,AB_int,AA_redu_int,AB_redu_int,RRE1A_int,RRE1B_int,RRE2A_int,RRE2B_int)));



		`ifdef SEC_FUNCTIONAL_MODE
			
			initial $display("\n *** Attention! Functional Simulation, All Timing Disabled In Module %m -- SDF Will Not Be Annotated, Ignore any SDF Errors *** \n\n",$realtime);
		`else
//Notifier defination
			always @ (NOT_RCK_RA_0) begin
				failedWrite;
				write_out_x;
			end
			always @ (NOT_RCK_RA_1) begin
				failedWrite;
				write_out_x;
			end
			always @ (NOT_RCK_RA_2) begin
				failedWrite;
				write_out_x;
			end
			always @ (NOT_WCK_WA_0) begin
				failedWrite;
				write_out_x;
			end
			always @ (NOT_WCK_WA_1) begin
				failedWrite;
				write_out_x;
			end
			always @ (NOT_WCK_WA_2) begin
				failedWrite;
				write_out_x;
			end
			always @ (NOT_WCK_DI_0) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ0.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_1) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ1.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_2) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ2.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_3) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ3.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_4) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ4.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_5) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ5.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_6) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ6.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_7) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ7.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_8) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ8.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_9) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ9.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_10) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ10.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_11) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ11.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_12) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ12.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_13) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ13.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_14) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ14.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_15) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ15.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_16) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ16.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_17) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ17.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_18) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ18.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_19) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ19.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_20) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ20.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_21) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ21.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_22) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ22.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_23) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ23.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_24) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ24.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_25) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ25.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_26) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ26.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_27) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ27.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_28) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ28.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_29) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ29.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_30) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ30.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_31) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ31.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_32) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ32.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_33) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ33.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_34) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ34.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_35) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ35.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_36) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ36.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_37) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ37.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_38) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ38.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_39) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ39.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_40) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ40.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_41) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ41.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_42) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ42.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_43) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ43.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_44) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ44.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_45) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ45.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_46) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ46.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_47) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ47.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_48) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ48.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_49) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ49.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_50) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ50.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_51) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ51.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_52) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ52.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_53) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ53.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_54) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ54.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_55) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ55.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_56) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ56.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_57) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ57.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_58) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ58.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_59) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ59.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_60) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ60.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_61) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ61.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_62) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ62.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_63) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ63.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_64) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ64.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_65) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ65.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_66) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ66.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_67) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ67.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_68) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ68.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_69) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ69.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_70) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ70.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_71) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ71.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_72) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ72.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_73) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ73.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_74) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ74.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_75) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ75.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_76) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ76.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_77) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ77.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_78) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ78.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_79) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ79.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_80) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ80.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_81) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ81.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_82) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ82.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_83) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ83.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_84) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ84.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_85) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ85.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_86) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ86.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_87) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ87.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_88) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ88.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_89) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ89.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_90) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ90.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_91) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ91.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_92) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ92.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_93) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ93.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_94) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ94.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_95) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ95.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_96) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ96.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_97) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ97.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_98) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ98.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_99) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ99.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_100) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ100.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_101) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ101.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_102) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ102.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_103) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ103.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_104) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ104.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_105) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ105.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_106) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ106.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_107) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ107.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_108) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ108.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_109) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ109.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_110) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ110.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_111) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ111.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_112) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ112.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_113) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ113.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_114) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ114.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_115) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ115.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_116) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ116.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_117) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ117.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_118) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ118.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_119) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ119.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_120) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ120.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_121) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ121.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_122) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ122.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_123) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ123.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_124) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ124.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_125) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ125.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_126) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ126.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_WCK_DI_127) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ127.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_A_x;
					end
				end
			end
			always @ (NOT_RCK_WCK) begin
				`ifdef PARTIAL_READ_ON_CONTENTION
					PartialOutputCorrupt;
				`else
					OutputCorrupt;
				`endif
//contnue write operation
			end
			always @ (NOT_WCK_RCK) begin
				`ifdef PARTIAL_READ_ON_CONTENTION
					PartialOutputCorrupt;
				`else
					OutputCorrupt;
				`endif
//contnue write operation
			end
			
			
			always @ (NOT_RCK_MINL) begin
				failedWrite;
				write_out_x;
			end
			always @ (NOT_WCK_MINL) begin
				failedWrite;
				write_out_x;
			end
			always @ (NOT_RCK_MINH) begin
				failedWrite;
				write_out_x;
			end
			always @ (NOT_WCK_MINH) begin
				failedWrite;
				write_out_x;
			end
			always @ (NOT_RCK_PER) begin
				failedWrite;
				write_out_x;
			end
			always @ (NOT_WCK_PER) begin
				failedWrite;
				write_out_x;
			end
			always @ (NOT_RCK_REN) begin
				failedWrite;
				write_out_x;
			end
			
			
			
			always @ (NOT_WCK_WEN) begin
				failedWrite;
				write_out_x;
			end
			
			always @ (NOT_WCK_BWEN_0) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ0.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(0);
					end
				end
			end
			always @ (NOT_WCK_BWEN_1) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ1.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(1);
					end
				end
			end
			always @ (NOT_WCK_BWEN_2) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ2.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(2);
					end
				end
			end
			always @ (NOT_WCK_BWEN_3) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ3.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(3);
					end
				end
			end
			always @ (NOT_WCK_BWEN_4) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ4.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(4);
					end
				end
			end
			always @ (NOT_WCK_BWEN_5) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ5.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(5);
					end
				end
			end
			always @ (NOT_WCK_BWEN_6) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ6.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(6);
					end
				end
			end
			always @ (NOT_WCK_BWEN_7) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ7.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(7);
					end
				end
			end
			always @ (NOT_WCK_BWEN_8) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ8.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(8);
					end
				end
			end
			always @ (NOT_WCK_BWEN_9) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ9.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(9);
					end
				end
			end
			always @ (NOT_WCK_BWEN_10) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ10.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(10);
					end
				end
			end
			always @ (NOT_WCK_BWEN_11) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ11.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(11);
					end
				end
			end
			always @ (NOT_WCK_BWEN_12) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ12.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(12);
					end
				end
			end
			always @ (NOT_WCK_BWEN_13) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ13.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(13);
					end
				end
			end
			always @ (NOT_WCK_BWEN_14) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ14.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(14);
					end
				end
			end
			always @ (NOT_WCK_BWEN_15) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ15.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(15);
					end
				end
			end
			always @ (NOT_WCK_BWEN_16) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ16.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(16);
					end
				end
			end
			always @ (NOT_WCK_BWEN_17) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ17.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(17);
					end
				end
			end
			always @ (NOT_WCK_BWEN_18) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ18.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(18);
					end
				end
			end
			always @ (NOT_WCK_BWEN_19) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ19.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(19);
					end
				end
			end
			always @ (NOT_WCK_BWEN_20) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ20.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(20);
					end
				end
			end
			always @ (NOT_WCK_BWEN_21) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ21.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(21);
					end
				end
			end
			always @ (NOT_WCK_BWEN_22) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ22.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(22);
					end
				end
			end
			always @ (NOT_WCK_BWEN_23) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ23.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(23);
					end
				end
			end
			always @ (NOT_WCK_BWEN_24) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ24.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(24);
					end
				end
			end
			always @ (NOT_WCK_BWEN_25) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ25.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(25);
					end
				end
			end
			always @ (NOT_WCK_BWEN_26) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ26.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(26);
					end
				end
			end
			always @ (NOT_WCK_BWEN_27) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ27.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(27);
					end
				end
			end
			always @ (NOT_WCK_BWEN_28) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ28.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(28);
					end
				end
			end
			always @ (NOT_WCK_BWEN_29) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ29.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(29);
					end
				end
			end
			always @ (NOT_WCK_BWEN_30) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ30.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(30);
					end
				end
			end
			always @ (NOT_WCK_BWEN_31) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ31.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(31);
					end
				end
			end
			always @ (NOT_WCK_BWEN_32) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ32.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(32);
					end
				end
			end
			always @ (NOT_WCK_BWEN_33) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ33.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(33);
					end
				end
			end
			always @ (NOT_WCK_BWEN_34) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ34.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(34);
					end
				end
			end
			always @ (NOT_WCK_BWEN_35) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ35.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(35);
					end
				end
			end
			always @ (NOT_WCK_BWEN_36) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ36.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(36);
					end
				end
			end
			always @ (NOT_WCK_BWEN_37) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ37.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(37);
					end
				end
			end
			always @ (NOT_WCK_BWEN_38) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ38.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(38);
					end
				end
			end
			always @ (NOT_WCK_BWEN_39) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ39.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(39);
					end
				end
			end
			always @ (NOT_WCK_BWEN_40) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ40.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(40);
					end
				end
			end
			always @ (NOT_WCK_BWEN_41) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ41.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(41);
					end
				end
			end
			always @ (NOT_WCK_BWEN_42) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ42.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(42);
					end
				end
			end
			always @ (NOT_WCK_BWEN_43) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ43.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(43);
					end
				end
			end
			always @ (NOT_WCK_BWEN_44) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ44.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(44);
					end
				end
			end
			always @ (NOT_WCK_BWEN_45) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ45.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(45);
					end
				end
			end
			always @ (NOT_WCK_BWEN_46) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ46.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(46);
					end
				end
			end
			always @ (NOT_WCK_BWEN_47) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ47.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(47);
					end
				end
			end
			always @ (NOT_WCK_BWEN_48) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ48.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(48);
					end
				end
			end
			always @ (NOT_WCK_BWEN_49) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ49.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(49);
					end
				end
			end
			always @ (NOT_WCK_BWEN_50) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ50.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(50);
					end
				end
			end
			always @ (NOT_WCK_BWEN_51) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ51.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(51);
					end
				end
			end
			always @ (NOT_WCK_BWEN_52) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ52.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(52);
					end
				end
			end
			always @ (NOT_WCK_BWEN_53) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ53.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(53);
					end
				end
			end
			always @ (NOT_WCK_BWEN_54) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ54.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(54);
					end
				end
			end
			always @ (NOT_WCK_BWEN_55) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ55.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(55);
					end
				end
			end
			always @ (NOT_WCK_BWEN_56) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ56.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(56);
					end
				end
			end
			always @ (NOT_WCK_BWEN_57) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ57.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(57);
					end
				end
			end
			always @ (NOT_WCK_BWEN_58) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ58.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(58);
					end
				end
			end
			always @ (NOT_WCK_BWEN_59) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ59.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(59);
					end
				end
			end
			always @ (NOT_WCK_BWEN_60) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ60.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(60);
					end
				end
			end
			always @ (NOT_WCK_BWEN_61) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ61.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(61);
					end
				end
			end
			always @ (NOT_WCK_BWEN_62) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ62.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(62);
					end
				end
			end
			always @ (NOT_WCK_BWEN_63) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ63.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(63);
					end
				end
			end
			always @ (NOT_WCK_BWEN_64) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ64.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(64);
					end
				end
			end
			always @ (NOT_WCK_BWEN_65) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ65.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(65);
					end
				end
			end
			always @ (NOT_WCK_BWEN_66) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ66.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(66);
					end
				end
			end
			always @ (NOT_WCK_BWEN_67) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ67.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(67);
					end
				end
			end
			always @ (NOT_WCK_BWEN_68) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ68.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(68);
					end
				end
			end
			always @ (NOT_WCK_BWEN_69) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ69.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(69);
					end
				end
			end
			always @ (NOT_WCK_BWEN_70) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ70.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(70);
					end
				end
			end
			always @ (NOT_WCK_BWEN_71) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ71.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(71);
					end
				end
			end
			always @ (NOT_WCK_BWEN_72) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ72.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(72);
					end
				end
			end
			always @ (NOT_WCK_BWEN_73) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ73.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(73);
					end
				end
			end
			always @ (NOT_WCK_BWEN_74) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ74.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(74);
					end
				end
			end
			always @ (NOT_WCK_BWEN_75) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ75.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(75);
					end
				end
			end
			always @ (NOT_WCK_BWEN_76) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ76.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(76);
					end
				end
			end
			always @ (NOT_WCK_BWEN_77) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ77.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(77);
					end
				end
			end
			always @ (NOT_WCK_BWEN_78) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ78.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(78);
					end
				end
			end
			always @ (NOT_WCK_BWEN_79) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ79.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(79);
					end
				end
			end
			always @ (NOT_WCK_BWEN_80) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ80.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(80);
					end
				end
			end
			always @ (NOT_WCK_BWEN_81) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ81.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(81);
					end
				end
			end
			always @ (NOT_WCK_BWEN_82) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ82.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(82);
					end
				end
			end
			always @ (NOT_WCK_BWEN_83) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ83.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(83);
					end
				end
			end
			always @ (NOT_WCK_BWEN_84) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ84.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(84);
					end
				end
			end
			always @ (NOT_WCK_BWEN_85) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ85.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(85);
					end
				end
			end
			always @ (NOT_WCK_BWEN_86) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ86.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(86);
					end
				end
			end
			always @ (NOT_WCK_BWEN_87) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ87.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(87);
					end
				end
			end
			always @ (NOT_WCK_BWEN_88) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ88.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(88);
					end
				end
			end
			always @ (NOT_WCK_BWEN_89) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ89.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(89);
					end
				end
			end
			always @ (NOT_WCK_BWEN_90) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ90.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(90);
					end
				end
			end
			always @ (NOT_WCK_BWEN_91) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ91.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(91);
					end
				end
			end
			always @ (NOT_WCK_BWEN_92) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ92.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(92);
					end
				end
			end
			always @ (NOT_WCK_BWEN_93) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ93.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(93);
					end
				end
			end
			always @ (NOT_WCK_BWEN_94) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ94.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(94);
					end
				end
			end
			always @ (NOT_WCK_BWEN_95) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ95.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(95);
					end
				end
			end
			always @ (NOT_WCK_BWEN_96) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ96.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(96);
					end
				end
			end
			always @ (NOT_WCK_BWEN_97) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ97.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(97);
					end
				end
			end
			always @ (NOT_WCK_BWEN_98) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ98.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(98);
					end
				end
			end
			always @ (NOT_WCK_BWEN_99) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ99.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(99);
					end
				end
			end
			always @ (NOT_WCK_BWEN_100) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ100.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(100);
					end
				end
			end
			always @ (NOT_WCK_BWEN_101) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ101.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(101);
					end
				end
			end
			always @ (NOT_WCK_BWEN_102) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ102.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(102);
					end
				end
			end
			always @ (NOT_WCK_BWEN_103) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ103.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(103);
					end
				end
			end
			always @ (NOT_WCK_BWEN_104) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ104.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(104);
					end
				end
			end
			always @ (NOT_WCK_BWEN_105) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ105.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(105);
					end
				end
			end
			always @ (NOT_WCK_BWEN_106) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ106.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(106);
					end
				end
			end
			always @ (NOT_WCK_BWEN_107) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ107.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(107);
					end
				end
			end
			always @ (NOT_WCK_BWEN_108) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ108.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(108);
					end
				end
			end
			always @ (NOT_WCK_BWEN_109) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ109.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(109);
					end
				end
			end
			always @ (NOT_WCK_BWEN_110) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ110.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(110);
					end
				end
			end
			always @ (NOT_WCK_BWEN_111) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ111.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(111);
					end
				end
			end
			always @ (NOT_WCK_BWEN_112) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ112.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(112);
					end
				end
			end
			always @ (NOT_WCK_BWEN_113) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ113.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(113);
					end
				end
			end
			always @ (NOT_WCK_BWEN_114) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ114.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(114);
					end
				end
			end
			always @ (NOT_WCK_BWEN_115) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ115.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(115);
					end
				end
			end
			always @ (NOT_WCK_BWEN_116) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ116.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(116);
					end
				end
			end
			always @ (NOT_WCK_BWEN_117) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ117.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(117);
					end
				end
			end
			always @ (NOT_WCK_BWEN_118) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ118.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(118);
					end
				end
			end
			always @ (NOT_WCK_BWEN_119) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ119.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(119);
					end
				end
			end
			always @ (NOT_WCK_BWEN_120) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ120.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(120);
					end
				end
			end
			always @ (NOT_WCK_BWEN_121) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ121.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(121);
					end
				end
			end
			always @ (NOT_WCK_BWEN_122) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ122.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(122);
					end
				end
			end
			always @ (NOT_WCK_BWEN_123) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ123.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(123);
					end
				end
			end
			always @ (NOT_WCK_BWEN_124) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ124.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(124);
					end
				end
			end
			always @ (NOT_WCK_BWEN_125) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ125.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(125);
					end
				end
			end
			always @ (NOT_WCK_BWEN_126) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ126.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(126);
					end
				end
			end
			always @ (NOT_WCK_BWEN_127) begin
				if (DFTRAMW_ && !SEW_) begin
					uDQ127.DOUT<=1'bx;
				end else begin
					if(CSNB_int == 1'b0) begin
						write_BWEN_x(127);
					end
				end
			end
			
			always @ (NOT_RCK_MCSRD) begin
				if ( !DFTRAM ) begin
					failedWrite;
				end
				write_out_x;
			end
			always @ (NOT_WCK_MCSA) begin
				failedWrite;
				write_out_x;
			end
			
			always @ (NOT_RCK_KCS) begin
				failedWrite;
				write_out_x;
			end
			always @ (NOT_WCK_KCS) begin
				failedWrite;
				write_out_x;
			end
			always @ (NOT_WCK_MCSWR) begin
				if ( !DFTRAM ) begin
					failedWrite;
				end
				write_out_x;
			end
			
			always @ (NOT_WCK_DFTRAM) begin
				failedWrite;
				write_out_x;
			end
			
			always @ (NOT_RCK_DFTRAM) begin
				failedWrite;
				write_out_x;
			end
			
			always @ (NOT_WCK_DFTRAMRN) begin
				failedWrite;
				write_out_x;
			end
			
			always @ (NOT_RCK_DFTRAMRN) begin
				failedWrite;
				write_out_x;
			end
			
			
			always @ (NOT_WCK_ADME) begin
				failedWrite;
				write_out_x;
			end
			
			always @ (NOT_RCK_CRE) begin
				failedWrite;
				write_out_x;
			end
			always @ (NOT_WCK_CRE) begin
				failedWrite;
				write_out_x;
			end
			always @ (NOT_RCK_FCA) begin
				failedWrite;
				write_out_x;
			end
			always @ (NOT_WCK_FCA) begin
				failedWrite;
				write_out_x;
			end
			always @ (NOT_WCK_SE) begin
				write_out_x;
				write_sout_x;
			end
			always @ (NOT_WCK_SI_D_L) begin
				write_out_x_L;
			end
			always @ (NOT_WCK_SI_D_R) begin
				write_out_x_R;
			end
			always @ (NOT_RCK_RRERD) begin
				failedWrite;
				write_out_x;
			end
			always @ (NOT_WCK_RREWR) begin
				failedWrite;
				write_out_x;
			end
			
			
			always @ (NOT_WCK_SEWN) begin
				failedWrite;
				write_out_x;
			end
			always @ (NOT_WCK_SI_D) begin
				failedWrite;
				write_out_x;
			end
			always @ (NOT_RCK_SERN) begin
				failedWrite;
				write_out_x;
			end
			
			always @ (NOT_PDE_RET) begin
				failedWrite;
				if (PDE_ == 1) begin
					write_out_low;
				end
				else begin
					write_out_x;
				end
			end
			always @ (NOT_PDE_DFTRAM) begin
				failedWrite;
				if (PDE_ == 1) begin
					write_out_low;
				end
				else begin
					write_out_x;
				end
			end
			always @ (NOT_PDE_REN) begin
				failedWrite;
				if (PDE_ == 1) begin
					write_out_low;
				end
				else begin
					write_out_x;
				end
			end
			always @ (NOT_PDE_WEN) begin
				failedWrite;
				if (PDE_ == 1) begin
					write_out_low;
				end
				else begin
					write_out_x;
				end
			end
			always @ (NOT_RET_DFTRAM) begin
				failedWrite;
				if (PDE_ == 1) begin
					write_out_low;
				end
				else begin
					write_out_x;
				end
			end
			always @ (NOT_RET_REN) begin
				failedWrite;
				if (PDE_ == 1) begin
					write_out_low;
				end
				else begin
					write_out_x;
				end
			end
			always @ (NOT_RET_WEN) begin
				failedWrite;
				if (PDE_ == 1) begin
					write_out_low;
				end
				else begin
					write_out_x;
				end
			end
			
// C1SR_CW
//
// bussed mode
//
			
			wire CRE1eq1aRENeq0aDFTRAMeq0 ;
			wire CRE1eq1aWENeq0aDFTRAMeq0 ;
			wire CRE2eq1aRENeq0aDFTRAMeq0 ;
			wire CRE2eq1aWENeq0aDFTRAMeq0 ;
			wire DFTRAMeq0 ;
			wire DFTRAMeq0aRENeq0 ;
			wire DFTRAMeq0aRENeq0aWENeq0 ;
			wire DFTRAMeq0aWENeq0 ;
			wire DFTRAMeq1 ;
			wire DFTRAMeq1aSEeq1 ;
			wire KCSeq0aMCSRD1eq0aMCSRD0eq0aRENeq0aDFTRAMeq0 ;
			wire KCSeq0aMCSRD1eq0aMCSRD0eq1aRENeq0aDFTRAMeq0 ;
			wire KCSeq0aMCSRD1eq1aMCSRD0eq0aRENeq0aDFTRAMeq0 ;
			wire KCSeq0aMCSRD1eq1aMCSRD0eq1aRENeq0aDFTRAMeq0 ;
			wire KCSeq1aMCSRD1eq0aMCSRD0eq0aRENeq0aDFTRAMeq0 ;
			wire KCSeq1aMCSRD1eq0aMCSRD0eq1aRENeq0aDFTRAMeq0 ;
			wire KCSeq1aMCSRD1eq1aMCSRD0eq0aRENeq0aDFTRAMeq0 ;
			wire KCSeq1aMCSRD1eq1aMCSRD0eq1aRENeq0aDFTRAMeq0 ;
			wire MCSWR1eq0aMCSWR0eq0aopopWENeq0aDFTRAMeq0cpoDFTRAMeq1cpaADME2eq1aADME1eq0aADME0eq0 ;
			wire MCSWR1eq0aMCSWR0eq1aopopWENeq0aDFTRAMeq0cpoDFTRAMeq1cpaADME2eq1aADME1eq0aADME0eq0 ;
			wire MCSWR1eq1aMCSWR0eq0aopopWENeq0aDFTRAMeq0cpoDFTRAMeq1cpaADME2eq1aADME1eq0aADME0eq0 ;
			wire MCSWR1eq1aMCSWR0eq1aopopWENeq0aDFTRAMeq0cpoDFTRAMeq1cpaADME2eq1aADME1eq0aADME0eq0 ;
			wire RENeq0aDFTRAMeq0 ;
			wire RENeq0aWENeq0aDFTRAMeq0 ;
			wire WENeq0aDFTRAMeq0 ;
			wire opRENeq0aDFTRAMeq0cp ;
			wire opWENeq0oDFTRAMeq1cp ;
			wire opopWENeq0aDFTRAMeq0cpoDFTRAMeq1cpaopopADME2eq0aADME1eq0aADME0eq0cpoopADME2eq0aADME1eq0aADME0eq1cpoopADME2eq0aADME1eq1aADME0eq0cpoopADME2eq0aADME1eq1aADME0eq1cpoopADME2eq1aADME1eq0aADME0eq1cpoopADME2eq1aADME1eq1aADME0eq0cpoopADME2eq1aADME1eq1aADME0eq1cpcp ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN0eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN1eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN2eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN3eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN4eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN5eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN6eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN7eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN8eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN9eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN10eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN11eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN12eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN13eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN14eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN15eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN16eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN17eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN18eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN19eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN20eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN21eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN22eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN23eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN24eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN25eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN26eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN27eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN28eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN29eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN30eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN31eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN32eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN33eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN34eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN35eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN36eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN37eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN38eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN39eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN40eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN41eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN42eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN43eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN44eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN45eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN46eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN47eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN48eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN49eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN50eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN51eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN52eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN53eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN54eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN55eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN56eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN57eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN58eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN59eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN60eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN61eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN62eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN63eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN64eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN65eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN66eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN67eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN68eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN69eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN70eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN71eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN72eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN73eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN74eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN75eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN76eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN77eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN78eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN79eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN80eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN81eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN82eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN83eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN84eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN85eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN86eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN87eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN88eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN89eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN90eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN91eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN92eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN93eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN94eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN95eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN96eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN97eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN98eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN99eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN100eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN101eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN102eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN103eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN104eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN105eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN106eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN107eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN108eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN109eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN110eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN111eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN112eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN113eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN114eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN115eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN116eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN117eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN118eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN119eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN120eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN121eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN122eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN123eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN124eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN125eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN126eq0 ;
			wire opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN127eq0 ;
			
			assign CRE1eq1aRENeq0aDFTRAMeq0 = (CRE1&!REN&!DFTRAM) ? 1'b1:1'b0;
			assign CRE1eq1aWENeq0aDFTRAMeq0 = (CRE1&!WEN&!DFTRAM) ? 1'b1:1'b0;
			assign CRE2eq1aRENeq0aDFTRAMeq0 = (CRE2&!REN&!DFTRAM) ? 1'b1:1'b0;
			assign CRE2eq1aWENeq0aDFTRAMeq0 = (CRE2&!WEN&!DFTRAM) ? 1'b1:1'b0;
			assign DFTRAMeq0 = (!DFTRAM) ? 1'b1:1'b0;
			assign DFTRAMeq0aRENeq0 = (!DFTRAM&!REN) ? 1'b1:1'b0;
			assign DFTRAMeq0aRENeq0aWENeq0 = (!DFTRAM&!REN&!WEN) &contA_flag ?  1'b1:1'b0;
			assign DFTRAMeq0aWENeq0 = (!DFTRAM&!WEN) ? 1'b1:1'b0;
			assign DFTRAMeq1 = (DFTRAM) ? 1'b1:1'b0;
			assign DFTRAMeq1aSEeq1 = (DFTRAM&SE) ? 1'b1:1'b0;
			assign KCSeq0aMCSRD1eq0aMCSRD0eq0aRENeq0aDFTRAMeq0 = (!KCS&!MCSRD[1]&!MCSRD[0]&!REN&!DFTRAM) ? 1'b1:1'b0;
			assign KCSeq0aMCSRD1eq0aMCSRD0eq1aRENeq0aDFTRAMeq0 = (!KCS&!MCSRD[1]&MCSRD[0]&!REN&!DFTRAM) ? 1'b1:1'b0;
			assign KCSeq0aMCSRD1eq1aMCSRD0eq0aRENeq0aDFTRAMeq0 = (!KCS&MCSRD[1]&!MCSRD[0]&!REN&!DFTRAM) ? 1'b1:1'b0;
			assign KCSeq0aMCSRD1eq1aMCSRD0eq1aRENeq0aDFTRAMeq0 = (!KCS&MCSRD[1]&MCSRD[0]&!REN&!DFTRAM) ? 1'b1:1'b0;
			assign KCSeq1aMCSRD1eq0aMCSRD0eq0aRENeq0aDFTRAMeq0 = (KCS&!MCSRD[1]&!MCSRD[0]&!REN&!DFTRAM) ? 1'b1:1'b0;
			assign KCSeq1aMCSRD1eq0aMCSRD0eq1aRENeq0aDFTRAMeq0 = (KCS&!MCSRD[1]&MCSRD[0]&!REN&!DFTRAM) ? 1'b1:1'b0;
			assign KCSeq1aMCSRD1eq1aMCSRD0eq0aRENeq0aDFTRAMeq0 = (KCS&MCSRD[1]&!MCSRD[0]&!REN&!DFTRAM) ? 1'b1:1'b0;
			assign KCSeq1aMCSRD1eq1aMCSRD0eq1aRENeq0aDFTRAMeq0 = (KCS&MCSRD[1]&MCSRD[0]&!REN&!DFTRAM) ? 1'b1:1'b0;
			assign MCSWR1eq0aMCSWR0eq0aopopWENeq0aDFTRAMeq0cpoDFTRAMeq1cpaADME2eq1aADME1eq0aADME0eq0 = (!MCSWR[1]&!MCSWR[0]&((!WEN&!DFTRAM)|DFTRAM)&ADME[2]&!ADME[1]&!ADME[0]) ? 1'b1:1'b0;
			assign MCSWR1eq0aMCSWR0eq1aopopWENeq0aDFTRAMeq0cpoDFTRAMeq1cpaADME2eq1aADME1eq0aADME0eq0 = (!MCSWR[1]&MCSWR[0]&((!WEN&!DFTRAM)|DFTRAM)&ADME[2]&!ADME[1]&!ADME[0]) ? 1'b1:1'b0;
			assign MCSWR1eq1aMCSWR0eq0aopopWENeq0aDFTRAMeq0cpoDFTRAMeq1cpaADME2eq1aADME1eq0aADME0eq0 = (MCSWR[1]&!MCSWR[0]&((!WEN&!DFTRAM)|DFTRAM)&ADME[2]&!ADME[1]&!ADME[0]) ? 1'b1:1'b0;
			assign MCSWR1eq1aMCSWR0eq1aopopWENeq0aDFTRAMeq0cpoDFTRAMeq1cpaADME2eq1aADME1eq0aADME0eq0 = (MCSWR[1]&MCSWR[0]&((!WEN&!DFTRAM)|DFTRAM)&ADME[2]&!ADME[1]&!ADME[0]) ? 1'b1:1'b0;
			assign RENeq0aDFTRAMeq0 = (!REN&!DFTRAM) ? 1'b1:1'b0;
			assign RENeq0aWENeq0aDFTRAMeq0 = (!REN&!WEN&!DFTRAM) &contA_flag ?  1'b1:1'b0;
			assign WENeq0aDFTRAMeq0 = (!WEN&!DFTRAM) ? 1'b1:1'b0;
			assign opRENeq0aDFTRAMeq0cp = ((!REN&!DFTRAM)) ? 1'b1:1'b0;
			assign opWENeq0oDFTRAMeq1cp = ((!WEN|DFTRAM)) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoDFTRAMeq1cpaopopADME2eq0aADME1eq0aADME0eq0cpoopADME2eq0aADME1eq0aADME0eq1cpoopADME2eq0aADME1eq1aADME0eq0cpoopADME2eq0aADME1eq1aADME0eq1cpoopADME2eq1aADME1eq0aADME0eq1cpoopADME2eq1aADME1eq1aADME0eq0cpoopADME2eq1aADME1eq1aADME0eq1cpcp = (((!WEN&!DFTRAM)|DFTRAM)&((!ADME[2]&!ADME[1]&!ADME[0])|(!ADME[2]&!ADME[1]&ADME[0])|(!ADME[2]&ADME[1]&!ADME[0])|(!ADME[2]&ADME[1]&ADME[0])|(ADME[2]&!ADME[1]&ADME[0])|(ADME[2]&ADME[1]&!ADME[0])|(ADME[2]&ADME[1]&ADME[0]))) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp = (((!WEN&!DFTRAM)|(DFTRAM&!SE))) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN0eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[0]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN1eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[1]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN2eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[2]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN3eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[3]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN4eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[4]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN5eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[5]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN6eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[6]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN7eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[7]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN8eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[8]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN9eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[9]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN10eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[10]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN11eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[11]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN12eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[12]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN13eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[13]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN14eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[14]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN15eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[15]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN16eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[16]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN17eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[17]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN18eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[18]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN19eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[19]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN20eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[20]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN21eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[21]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN22eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[22]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN23eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[23]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN24eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[24]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN25eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[25]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN26eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[26]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN27eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[27]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN28eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[28]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN29eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[29]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN30eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[30]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN31eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[31]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN32eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[32]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN33eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[33]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN34eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[34]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN35eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[35]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN36eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[36]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN37eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[37]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN38eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[38]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN39eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[39]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN40eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[40]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN41eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[41]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN42eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[42]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN43eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[43]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN44eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[44]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN45eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[45]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN46eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[46]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN47eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[47]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN48eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[48]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN49eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[49]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN50eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[50]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN51eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[51]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN52eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[52]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN53eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[53]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN54eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[54]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN55eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[55]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN56eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[56]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN57eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[57]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN58eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[58]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN59eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[59]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN60eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[60]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN61eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[61]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN62eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[62]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN63eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[63]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN64eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[64]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN65eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[65]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN66eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[66]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN67eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[67]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN68eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[68]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN69eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[69]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN70eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[70]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN71eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[71]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN72eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[72]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN73eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[73]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN74eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[74]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN75eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[75]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN76eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[76]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN77eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[77]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN78eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[78]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN79eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[79]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN80eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[80]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN81eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[81]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN82eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[82]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN83eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[83]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN84eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[84]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN85eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[85]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN86eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[86]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN87eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[87]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN88eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[88]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN89eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[89]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN90eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[90]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN91eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[91]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN92eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[92]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN93eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[93]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN94eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[94]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN95eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[95]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN96eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[96]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN97eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[97]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN98eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[98]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN99eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[99]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN100eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[100]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN101eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[101]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN102eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[102]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN103eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[103]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN104eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[104]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN105eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[105]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN106eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[106]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN107eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[107]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN108eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[108]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN109eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[109]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN110eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[110]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN111eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[111]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN112eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[112]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN113eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[113]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN114eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[114]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN115eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[115]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN116eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[116]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN117eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[117]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN118eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[118]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN119eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[119]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN120eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[120]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN121eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[121]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN122eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[122]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN123eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[123]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN124eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[124]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN125eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[125]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN126eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[126]) ? 1'b1:1'b0;
			assign opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN127eq0 = (((!WEN&!DFTRAM)|(DFTRAM&!SE))&!BWEN[127]) ? 1'b1:1'b0;
			
			specify
				$width(negedge RCK &&& RENeq0aDFTRAMeq0, `D_MEM_WIDTH_L, `D_MEM_WIDTH_THD, NOT_RCK_MINL);
				$width(negedge WCK &&& opWENeq0oDFTRAMeq1cp, `D_MEM_WIDTH_L, `D_MEM_WIDTH_THD, NOT_WCK_MINL);
				$width(posedge RCK &&& RENeq0aDFTRAMeq0, `D_MEM_WIDTH_H, `D_MEM_WIDTH_THD, NOT_RCK_MINH);
				$width(posedge WCK &&& opWENeq0oDFTRAMeq1cp, `D_MEM_WIDTH_H, `D_MEM_WIDTH_THD, NOT_WCK_MINH);
				
				$period(negedge RCK &&& KCSeq0aMCSRD1eq0aMCSRD0eq0aRENeq0aDFTRAMeq0, `D_MEM_PERIOD, NOT_RCK_PER);
				$period(negedge RCK &&& KCSeq0aMCSRD1eq0aMCSRD0eq1aRENeq0aDFTRAMeq0, `D_MEM_PERIOD, NOT_RCK_PER);
				$period(negedge RCK &&& KCSeq0aMCSRD1eq1aMCSRD0eq0aRENeq0aDFTRAMeq0, `D_MEM_PERIOD, NOT_RCK_PER);
				$period(negedge RCK &&& KCSeq0aMCSRD1eq1aMCSRD0eq1aRENeq0aDFTRAMeq0, `D_MEM_PERIOD, NOT_RCK_PER);
				$period(negedge RCK &&& KCSeq1aMCSRD1eq0aMCSRD0eq0aRENeq0aDFTRAMeq0, `D_MEM_PERIOD, NOT_RCK_PER);
				$period(negedge RCK &&& KCSeq1aMCSRD1eq0aMCSRD0eq1aRENeq0aDFTRAMeq0, `D_MEM_PERIOD, NOT_RCK_PER);
				$period(negedge RCK &&& KCSeq1aMCSRD1eq1aMCSRD0eq0aRENeq0aDFTRAMeq0, `D_MEM_PERIOD, NOT_RCK_PER);
				$period(negedge RCK &&& KCSeq1aMCSRD1eq1aMCSRD0eq1aRENeq0aDFTRAMeq0, `D_MEM_PERIOD, NOT_RCK_PER);
				$period(negedge WCK &&& MCSWR1eq0aMCSWR0eq0aopopWENeq0aDFTRAMeq0cpoDFTRAMeq1cpaADME2eq1aADME1eq0aADME0eq0, `D_MEM_PERIOD, NOT_WCK_PER);
				$period(negedge WCK &&& MCSWR1eq0aMCSWR0eq1aopopWENeq0aDFTRAMeq0cpoDFTRAMeq1cpaADME2eq1aADME1eq0aADME0eq0, `D_MEM_PERIOD, NOT_WCK_PER);
				$period(negedge WCK &&& MCSWR1eq1aMCSWR0eq0aopopWENeq0aDFTRAMeq0cpoDFTRAMeq1cpaADME2eq1aADME1eq0aADME0eq0, `D_MEM_PERIOD, NOT_WCK_PER);
				$period(negedge WCK &&& MCSWR1eq1aMCSWR0eq1aopopWENeq0aDFTRAMeq0cpoDFTRAMeq1cpaADME2eq1aADME1eq0aADME0eq0, `D_MEM_PERIOD, NOT_WCK_PER);
				$period(negedge WCK &&& opopWENeq0aDFTRAMeq0cpoDFTRAMeq1cpaopopADME2eq0aADME1eq0aADME0eq0cpoopADME2eq0aADME1eq0aADME0eq1cpoopADME2eq0aADME1eq1aADME0eq0cpoopADME2eq0aADME1eq1aADME0eq1cpoopADME2eq1aADME1eq0aADME0eq1cpoopADME2eq1aADME1eq1aADME0eq0cpoopADME2eq1aADME1eq1aADME0eq1cpcp, `D_MEM_PERIOD, NOT_WCK_PER);
				$period(posedge RCK &&& KCSeq0aMCSRD1eq0aMCSRD0eq0aRENeq0aDFTRAMeq0, `D_MEM_PERIOD, NOT_RCK_PER);
				$period(posedge RCK &&& KCSeq0aMCSRD1eq0aMCSRD0eq1aRENeq0aDFTRAMeq0, `D_MEM_PERIOD, NOT_RCK_PER);
				$period(posedge RCK &&& KCSeq0aMCSRD1eq1aMCSRD0eq0aRENeq0aDFTRAMeq0, `D_MEM_PERIOD, NOT_RCK_PER);
				$period(posedge RCK &&& KCSeq0aMCSRD1eq1aMCSRD0eq1aRENeq0aDFTRAMeq0, `D_MEM_PERIOD, NOT_RCK_PER);
				$period(posedge RCK &&& KCSeq1aMCSRD1eq0aMCSRD0eq0aRENeq0aDFTRAMeq0, `D_MEM_PERIOD, NOT_RCK_PER);
				$period(posedge RCK &&& KCSeq1aMCSRD1eq0aMCSRD0eq1aRENeq0aDFTRAMeq0, `D_MEM_PERIOD, NOT_RCK_PER);
				$period(posedge RCK &&& KCSeq1aMCSRD1eq1aMCSRD0eq0aRENeq0aDFTRAMeq0, `D_MEM_PERIOD, NOT_RCK_PER);
				$period(posedge RCK &&& KCSeq1aMCSRD1eq1aMCSRD0eq1aRENeq0aDFTRAMeq0, `D_MEM_PERIOD, NOT_RCK_PER);
				$period(posedge WCK &&& MCSWR1eq0aMCSWR0eq0aopopWENeq0aDFTRAMeq0cpoDFTRAMeq1cpaADME2eq1aADME1eq0aADME0eq0, `D_MEM_PERIOD, NOT_WCK_PER);
				$period(posedge WCK &&& MCSWR1eq0aMCSWR0eq1aopopWENeq0aDFTRAMeq0cpoDFTRAMeq1cpaADME2eq1aADME1eq0aADME0eq0, `D_MEM_PERIOD, NOT_WCK_PER);
				$period(posedge WCK &&& MCSWR1eq1aMCSWR0eq0aopopWENeq0aDFTRAMeq0cpoDFTRAMeq1cpaADME2eq1aADME1eq0aADME0eq0, `D_MEM_PERIOD, NOT_WCK_PER);
				$period(posedge WCK &&& MCSWR1eq1aMCSWR0eq1aopopWENeq0aDFTRAMeq0cpoDFTRAMeq1cpaADME2eq1aADME1eq0aADME0eq0, `D_MEM_PERIOD, NOT_WCK_PER);
				$period(posedge WCK &&& opopWENeq0aDFTRAMeq0cpoDFTRAMeq1cpaopopADME2eq0aADME1eq0aADME0eq0cpoopADME2eq0aADME1eq0aADME0eq1cpoopADME2eq0aADME1eq1aADME0eq0cpoopADME2eq0aADME1eq1aADME0eq1cpoopADME2eq1aADME1eq0aADME0eq1cpoopADME2eq1aADME1eq1aADME0eq0cpoopADME2eq1aADME1eq1aADME0eq1cpcp, `D_MEM_PERIOD, NOT_WCK_PER);
				
				$setuphold(posedge WCK &&& (WENeq0aDFTRAMeq0), negedge ADME[0], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_ADME);
				$setuphold(posedge WCK &&& (WENeq0aDFTRAMeq0), negedge ADME[1], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_ADME);
				$setuphold(posedge WCK &&& (WENeq0aDFTRAMeq0), negedge ADME[2], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_ADME);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[0], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_0);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[1], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_1);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[2], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_2);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[3], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_3);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[4], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_4);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[5], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_5);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[6], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_6);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[7], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_7);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[8], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_8);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[9], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_9);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[10], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_10);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[11], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_11);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[12], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_12);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[13], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_13);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[14], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_14);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[15], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_15);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[16], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_16);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[17], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_17);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[18], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_18);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[19], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_19);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[20], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_20);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[21], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_21);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[22], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_22);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[23], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_23);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[24], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_24);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[25], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_25);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[26], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_26);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[27], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_27);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[28], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_28);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[29], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_29);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[30], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_30);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[31], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_31);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[32], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_32);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[33], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_33);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[34], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_34);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[35], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_35);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[36], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_36);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[37], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_37);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[38], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_38);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[39], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_39);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[40], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_40);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[41], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_41);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[42], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_42);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[43], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_43);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[44], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_44);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[45], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_45);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[46], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_46);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[47], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_47);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[48], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_48);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[49], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_49);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[50], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_50);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[51], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_51);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[52], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_52);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[53], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_53);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[54], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_54);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[55], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_55);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[56], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_56);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[57], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_57);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[58], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_58);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[59], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_59);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[60], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_60);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[61], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_61);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[62], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_62);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[63], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_63);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[64], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_64);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[65], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_65);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[66], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_66);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[67], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_67);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[68], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_68);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[69], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_69);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[70], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_70);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[71], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_71);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[72], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_72);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[73], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_73);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[74], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_74);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[75], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_75);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[76], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_76);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[77], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_77);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[78], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_78);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[79], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_79);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[80], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_80);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[81], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_81);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[82], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_82);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[83], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_83);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[84], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_84);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[85], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_85);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[86], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_86);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[87], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_87);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[88], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_88);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[89], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_89);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[90], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_90);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[91], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_91);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[92], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_92);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[93], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_93);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[94], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_94);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[95], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_95);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[96], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_96);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[97], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_97);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[98], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_98);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[99], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_99);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[100], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_100);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[101], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_101);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[102], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_102);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[103], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_103);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[104], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_104);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[105], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_105);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[106], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_106);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[107], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_107);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[108], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_108);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[109], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_109);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[110], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_110);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[111], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_111);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[112], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_112);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[113], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_113);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[114], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_114);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[115], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_115);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[116], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_116);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[117], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_117);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[118], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_118);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[119], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_119);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[120], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_120);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[121], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_121);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[122], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_122);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[123], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_123);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[124], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_124);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[125], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_125);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[126], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_126);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), negedge BWEN[127], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_127);
				$setuphold(posedge RCK &&& (RENeq0aDFTRAMeq0), negedge CRE1, `D_MEM_SETUP, `D_MEM_HOLD, NOT_RCK_CRE);
				$setuphold(posedge WCK &&& (WENeq0aDFTRAMeq0), negedge CRE1, `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_CRE);
				$setuphold(posedge RCK &&& (RENeq0aDFTRAMeq0), negedge CRE2, `D_MEM_SETUP, `D_MEM_HOLD, NOT_RCK_CRE);
				$setuphold(posedge WCK &&& (WENeq0aDFTRAMeq0), negedge CRE2, `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_CRE);
				$setuphold(posedge WCK, negedge DFTRAM, `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DFTRAM);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN0eq0), negedge DI[0], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_0);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN1eq0), negedge DI[1], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_1);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN2eq0), negedge DI[2], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_2);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN3eq0), negedge DI[3], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_3);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN4eq0), negedge DI[4], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_4);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN5eq0), negedge DI[5], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_5);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN6eq0), negedge DI[6], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_6);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN7eq0), negedge DI[7], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_7);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN8eq0), negedge DI[8], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_8);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN9eq0), negedge DI[9], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_9);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN10eq0), negedge DI[10], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_10);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN11eq0), negedge DI[11], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_11);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN12eq0), negedge DI[12], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_12);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN13eq0), negedge DI[13], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_13);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN14eq0), negedge DI[14], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_14);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN15eq0), negedge DI[15], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_15);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN16eq0), negedge DI[16], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_16);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN17eq0), negedge DI[17], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_17);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN18eq0), negedge DI[18], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_18);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN19eq0), negedge DI[19], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_19);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN20eq0), negedge DI[20], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_20);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN21eq0), negedge DI[21], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_21);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN22eq0), negedge DI[22], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_22);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN23eq0), negedge DI[23], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_23);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN24eq0), negedge DI[24], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_24);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN25eq0), negedge DI[25], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_25);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN26eq0), negedge DI[26], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_26);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN27eq0), negedge DI[27], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_27);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN28eq0), negedge DI[28], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_28);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN29eq0), negedge DI[29], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_29);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN30eq0), negedge DI[30], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_30);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN31eq0), negedge DI[31], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_31);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN32eq0), negedge DI[32], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_32);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN33eq0), negedge DI[33], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_33);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN34eq0), negedge DI[34], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_34);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN35eq0), negedge DI[35], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_35);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN36eq0), negedge DI[36], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_36);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN37eq0), negedge DI[37], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_37);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN38eq0), negedge DI[38], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_38);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN39eq0), negedge DI[39], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_39);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN40eq0), negedge DI[40], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_40);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN41eq0), negedge DI[41], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_41);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN42eq0), negedge DI[42], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_42);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN43eq0), negedge DI[43], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_43);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN44eq0), negedge DI[44], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_44);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN45eq0), negedge DI[45], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_45);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN46eq0), negedge DI[46], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_46);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN47eq0), negedge DI[47], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_47);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN48eq0), negedge DI[48], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_48);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN49eq0), negedge DI[49], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_49);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN50eq0), negedge DI[50], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_50);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN51eq0), negedge DI[51], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_51);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN52eq0), negedge DI[52], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_52);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN53eq0), negedge DI[53], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_53);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN54eq0), negedge DI[54], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_54);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN55eq0), negedge DI[55], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_55);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN56eq0), negedge DI[56], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_56);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN57eq0), negedge DI[57], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_57);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN58eq0), negedge DI[58], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_58);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN59eq0), negedge DI[59], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_59);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN60eq0), negedge DI[60], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_60);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN61eq0), negedge DI[61], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_61);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN62eq0), negedge DI[62], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_62);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN63eq0), negedge DI[63], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_63);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN64eq0), negedge DI[64], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_64);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN65eq0), negedge DI[65], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_65);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN66eq0), negedge DI[66], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_66);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN67eq0), negedge DI[67], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_67);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN68eq0), negedge DI[68], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_68);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN69eq0), negedge DI[69], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_69);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN70eq0), negedge DI[70], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_70);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN71eq0), negedge DI[71], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_71);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN72eq0), negedge DI[72], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_72);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN73eq0), negedge DI[73], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_73);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN74eq0), negedge DI[74], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_74);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN75eq0), negedge DI[75], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_75);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN76eq0), negedge DI[76], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_76);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN77eq0), negedge DI[77], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_77);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN78eq0), negedge DI[78], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_78);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN79eq0), negedge DI[79], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_79);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN80eq0), negedge DI[80], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_80);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN81eq0), negedge DI[81], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_81);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN82eq0), negedge DI[82], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_82);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN83eq0), negedge DI[83], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_83);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN84eq0), negedge DI[84], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_84);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN85eq0), negedge DI[85], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_85);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN86eq0), negedge DI[86], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_86);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN87eq0), negedge DI[87], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_87);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN88eq0), negedge DI[88], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_88);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN89eq0), negedge DI[89], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_89);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN90eq0), negedge DI[90], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_90);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN91eq0), negedge DI[91], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_91);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN92eq0), negedge DI[92], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_92);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN93eq0), negedge DI[93], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_93);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN94eq0), negedge DI[94], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_94);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN95eq0), negedge DI[95], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_95);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN96eq0), negedge DI[96], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_96);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN97eq0), negedge DI[97], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_97);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN98eq0), negedge DI[98], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_98);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN99eq0), negedge DI[99], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_99);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN100eq0), negedge DI[100], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_100);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN101eq0), negedge DI[101], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_101);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN102eq0), negedge DI[102], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_102);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN103eq0), negedge DI[103], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_103);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN104eq0), negedge DI[104], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_104);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN105eq0), negedge DI[105], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_105);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN106eq0), negedge DI[106], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_106);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN107eq0), negedge DI[107], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_107);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN108eq0), negedge DI[108], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_108);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN109eq0), negedge DI[109], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_109);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN110eq0), negedge DI[110], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_110);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN111eq0), negedge DI[111], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_111);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN112eq0), negedge DI[112], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_112);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN113eq0), negedge DI[113], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_113);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN114eq0), negedge DI[114], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_114);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN115eq0), negedge DI[115], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_115);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN116eq0), negedge DI[116], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_116);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN117eq0), negedge DI[117], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_117);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN118eq0), negedge DI[118], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_118);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN119eq0), negedge DI[119], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_119);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN120eq0), negedge DI[120], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_120);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN121eq0), negedge DI[121], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_121);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN122eq0), negedge DI[122], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_122);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN123eq0), negedge DI[123], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_123);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN124eq0), negedge DI[124], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_124);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN125eq0), negedge DI[125], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_125);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN126eq0), negedge DI[126], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_126);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN127eq0), negedge DI[127], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_127);
				$setuphold(posedge RCK &&& (CRE1eq1aRENeq0aDFTRAMeq0), negedge FCA1[0], `D_MEM_SETUP, `D_MEM_HOLD, NOT_RCK_FCA);
				$setuphold(posedge RCK &&& (CRE1eq1aRENeq0aDFTRAMeq0), negedge FCA1[1], `D_MEM_SETUP, `D_MEM_HOLD, NOT_RCK_FCA);
				$setuphold(posedge RCK &&& (CRE1eq1aRENeq0aDFTRAMeq0), negedge FCA1[2], `D_MEM_SETUP, `D_MEM_HOLD, NOT_RCK_FCA);
				$setuphold(posedge RCK &&& (CRE1eq1aRENeq0aDFTRAMeq0), negedge FCA1[3], `D_MEM_SETUP, `D_MEM_HOLD, NOT_RCK_FCA);
				$setuphold(posedge RCK &&& (CRE1eq1aRENeq0aDFTRAMeq0), negedge FCA1[4], `D_MEM_SETUP, `D_MEM_HOLD, NOT_RCK_FCA);
				$setuphold(posedge WCK &&& (CRE1eq1aWENeq0aDFTRAMeq0), negedge FCA1[0], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_FCA);
				$setuphold(posedge WCK &&& (CRE1eq1aWENeq0aDFTRAMeq0), negedge FCA1[1], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_FCA);
				$setuphold(posedge WCK &&& (CRE1eq1aWENeq0aDFTRAMeq0), negedge FCA1[2], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_FCA);
				$setuphold(posedge WCK &&& (CRE1eq1aWENeq0aDFTRAMeq0), negedge FCA1[3], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_FCA);
				$setuphold(posedge WCK &&& (CRE1eq1aWENeq0aDFTRAMeq0), negedge FCA1[4], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_FCA);
				$setuphold(posedge RCK &&& (CRE2eq1aRENeq0aDFTRAMeq0), negedge FCA2[0], `D_MEM_SETUP, `D_MEM_HOLD, NOT_RCK_FCA);
				$setuphold(posedge RCK &&& (CRE2eq1aRENeq0aDFTRAMeq0), negedge FCA2[1], `D_MEM_SETUP, `D_MEM_HOLD, NOT_RCK_FCA);
				$setuphold(posedge RCK &&& (CRE2eq1aRENeq0aDFTRAMeq0), negedge FCA2[2], `D_MEM_SETUP, `D_MEM_HOLD, NOT_RCK_FCA);
				$setuphold(posedge RCK &&& (CRE2eq1aRENeq0aDFTRAMeq0), negedge FCA2[3], `D_MEM_SETUP, `D_MEM_HOLD, NOT_RCK_FCA);
				$setuphold(posedge RCK &&& (CRE2eq1aRENeq0aDFTRAMeq0), negedge FCA2[4], `D_MEM_SETUP, `D_MEM_HOLD, NOT_RCK_FCA);
				$setuphold(posedge WCK &&& (CRE2eq1aWENeq0aDFTRAMeq0), negedge FCA2[0], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_FCA);
				$setuphold(posedge WCK &&& (CRE2eq1aWENeq0aDFTRAMeq0), negedge FCA2[1], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_FCA);
				$setuphold(posedge WCK &&& (CRE2eq1aWENeq0aDFTRAMeq0), negedge FCA2[2], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_FCA);
				$setuphold(posedge WCK &&& (CRE2eq1aWENeq0aDFTRAMeq0), negedge FCA2[3], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_FCA);
				$setuphold(posedge WCK &&& (CRE2eq1aWENeq0aDFTRAMeq0), negedge FCA2[4], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_FCA);
				$setuphold(posedge RCK &&& (RENeq0aDFTRAMeq0), negedge KCS, `D_MEM_SETUP, `D_MEM_HOLD, NOT_RCK_KCS);
				$setuphold(posedge RCK &&& (opRENeq0aDFTRAMeq0cp), negedge MCSRD[0], `D_MEM_SETUP, `D_MEM_HOLD, NOT_RCK_MCSRD);
				$setuphold(posedge RCK &&& (opRENeq0aDFTRAMeq0cp), negedge MCSRD[1], `D_MEM_SETUP, `D_MEM_HOLD, NOT_RCK_MCSRD);
				$setuphold(posedge WCK &&& (WENeq0aDFTRAMeq0), negedge MCSWR[0], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_MCSWR);
				$setuphold(posedge WCK &&& (WENeq0aDFTRAMeq0), negedge MCSWR[1], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_MCSWR);
				$setuphold(posedge RCK &&& (DFTRAMeq0aRENeq0), negedge RA[0], `D_MEM_SETUP, `D_MEM_HOLD, NOT_RCK_RA_0);
				$setuphold(posedge RCK &&& (DFTRAMeq0aRENeq0), negedge RA[1], `D_MEM_SETUP, `D_MEM_HOLD, NOT_RCK_RA_1);
				$setuphold(posedge RCK &&& (DFTRAMeq0aRENeq0), negedge RA[2], `D_MEM_SETUP, `D_MEM_HOLD, NOT_RCK_RA_2);
				$setuphold(posedge RCK &&& (DFTRAMeq0), negedge REN, `D_MEM_SETUP, `D_MEM_HOLD, NOT_RCK_REN);
				$setuphold(posedge WCK &&& (DFTRAMeq1), negedge SE, `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_SE);
				$setuphold(posedge WCK &&& (DFTRAMeq1aSEeq1), negedge SI_D_L, `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_SI_D_L);
				$setuphold(posedge WCK &&& (DFTRAMeq1aSEeq1), negedge SI_D_R, `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_SI_D_R);
				$setuphold(posedge WCK &&& (DFTRAMeq0aWENeq0), negedge WA[0], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_WA_0);
				$setuphold(posedge WCK &&& (DFTRAMeq0aWENeq0), negedge WA[1], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_WA_1);
				$setuphold(posedge WCK &&& (DFTRAMeq0aWENeq0), negedge WA[2], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_WA_2);
				$setuphold(posedge WCK &&& (DFTRAMeq0), negedge WEN, `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_WEN);
				$setuphold(posedge WCK &&& (WENeq0aDFTRAMeq0), posedge ADME[0], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_ADME);
				$setuphold(posedge WCK &&& (WENeq0aDFTRAMeq0), posedge ADME[1], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_ADME);
				$setuphold(posedge WCK &&& (WENeq0aDFTRAMeq0), posedge ADME[2], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_ADME);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[0], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_0);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[1], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_1);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[2], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_2);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[3], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_3);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[4], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_4);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[5], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_5);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[6], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_6);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[7], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_7);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[8], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_8);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[9], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_9);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[10], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_10);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[11], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_11);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[12], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_12);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[13], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_13);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[14], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_14);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[15], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_15);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[16], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_16);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[17], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_17);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[18], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_18);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[19], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_19);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[20], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_20);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[21], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_21);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[22], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_22);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[23], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_23);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[24], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_24);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[25], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_25);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[26], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_26);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[27], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_27);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[28], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_28);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[29], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_29);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[30], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_30);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[31], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_31);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[32], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_32);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[33], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_33);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[34], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_34);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[35], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_35);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[36], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_36);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[37], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_37);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[38], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_38);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[39], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_39);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[40], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_40);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[41], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_41);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[42], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_42);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[43], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_43);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[44], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_44);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[45], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_45);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[46], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_46);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[47], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_47);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[48], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_48);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[49], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_49);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[50], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_50);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[51], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_51);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[52], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_52);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[53], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_53);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[54], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_54);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[55], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_55);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[56], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_56);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[57], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_57);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[58], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_58);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[59], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_59);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[60], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_60);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[61], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_61);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[62], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_62);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[63], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_63);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[64], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_64);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[65], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_65);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[66], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_66);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[67], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_67);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[68], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_68);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[69], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_69);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[70], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_70);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[71], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_71);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[72], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_72);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[73], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_73);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[74], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_74);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[75], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_75);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[76], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_76);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[77], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_77);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[78], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_78);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[79], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_79);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[80], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_80);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[81], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_81);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[82], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_82);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[83], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_83);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[84], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_84);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[85], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_85);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[86], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_86);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[87], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_87);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[88], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_88);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[89], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_89);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[90], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_90);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[91], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_91);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[92], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_92);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[93], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_93);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[94], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_94);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[95], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_95);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[96], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_96);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[97], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_97);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[98], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_98);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[99], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_99);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[100], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_100);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[101], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_101);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[102], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_102);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[103], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_103);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[104], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_104);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[105], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_105);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[106], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_106);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[107], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_107);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[108], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_108);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[109], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_109);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[110], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_110);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[111], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_111);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[112], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_112);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[113], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_113);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[114], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_114);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[115], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_115);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[116], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_116);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[117], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_117);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[118], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_118);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[119], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_119);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[120], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_120);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[121], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_121);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[122], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_122);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[123], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_123);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[124], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_124);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[125], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_125);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[126], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_126);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcp), posedge BWEN[127], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_BWEN_127);
				$setuphold(posedge RCK &&& (RENeq0aDFTRAMeq0), posedge CRE1, `D_MEM_SETUP, `D_MEM_HOLD, NOT_RCK_CRE);
				$setuphold(posedge WCK &&& (WENeq0aDFTRAMeq0), posedge CRE1, `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_CRE);
				$setuphold(posedge RCK &&& (RENeq0aDFTRAMeq0), posedge CRE2, `D_MEM_SETUP, `D_MEM_HOLD, NOT_RCK_CRE);
				$setuphold(posedge WCK &&& (WENeq0aDFTRAMeq0), posedge CRE2, `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_CRE);
				$setuphold(posedge WCK, posedge DFTRAM, `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DFTRAM);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN0eq0), posedge DI[0], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_0);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN1eq0), posedge DI[1], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_1);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN2eq0), posedge DI[2], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_2);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN3eq0), posedge DI[3], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_3);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN4eq0), posedge DI[4], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_4);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN5eq0), posedge DI[5], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_5);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN6eq0), posedge DI[6], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_6);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN7eq0), posedge DI[7], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_7);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN8eq0), posedge DI[8], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_8);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN9eq0), posedge DI[9], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_9);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN10eq0), posedge DI[10], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_10);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN11eq0), posedge DI[11], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_11);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN12eq0), posedge DI[12], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_12);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN13eq0), posedge DI[13], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_13);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN14eq0), posedge DI[14], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_14);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN15eq0), posedge DI[15], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_15);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN16eq0), posedge DI[16], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_16);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN17eq0), posedge DI[17], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_17);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN18eq0), posedge DI[18], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_18);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN19eq0), posedge DI[19], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_19);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN20eq0), posedge DI[20], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_20);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN21eq0), posedge DI[21], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_21);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN22eq0), posedge DI[22], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_22);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN23eq0), posedge DI[23], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_23);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN24eq0), posedge DI[24], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_24);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN25eq0), posedge DI[25], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_25);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN26eq0), posedge DI[26], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_26);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN27eq0), posedge DI[27], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_27);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN28eq0), posedge DI[28], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_28);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN29eq0), posedge DI[29], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_29);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN30eq0), posedge DI[30], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_30);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN31eq0), posedge DI[31], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_31);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN32eq0), posedge DI[32], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_32);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN33eq0), posedge DI[33], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_33);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN34eq0), posedge DI[34], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_34);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN35eq0), posedge DI[35], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_35);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN36eq0), posedge DI[36], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_36);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN37eq0), posedge DI[37], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_37);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN38eq0), posedge DI[38], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_38);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN39eq0), posedge DI[39], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_39);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN40eq0), posedge DI[40], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_40);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN41eq0), posedge DI[41], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_41);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN42eq0), posedge DI[42], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_42);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN43eq0), posedge DI[43], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_43);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN44eq0), posedge DI[44], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_44);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN45eq0), posedge DI[45], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_45);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN46eq0), posedge DI[46], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_46);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN47eq0), posedge DI[47], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_47);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN48eq0), posedge DI[48], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_48);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN49eq0), posedge DI[49], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_49);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN50eq0), posedge DI[50], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_50);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN51eq0), posedge DI[51], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_51);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN52eq0), posedge DI[52], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_52);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN53eq0), posedge DI[53], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_53);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN54eq0), posedge DI[54], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_54);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN55eq0), posedge DI[55], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_55);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN56eq0), posedge DI[56], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_56);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN57eq0), posedge DI[57], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_57);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN58eq0), posedge DI[58], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_58);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN59eq0), posedge DI[59], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_59);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN60eq0), posedge DI[60], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_60);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN61eq0), posedge DI[61], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_61);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN62eq0), posedge DI[62], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_62);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN63eq0), posedge DI[63], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_63);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN64eq0), posedge DI[64], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_64);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN65eq0), posedge DI[65], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_65);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN66eq0), posedge DI[66], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_66);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN67eq0), posedge DI[67], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_67);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN68eq0), posedge DI[68], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_68);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN69eq0), posedge DI[69], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_69);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN70eq0), posedge DI[70], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_70);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN71eq0), posedge DI[71], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_71);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN72eq0), posedge DI[72], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_72);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN73eq0), posedge DI[73], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_73);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN74eq0), posedge DI[74], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_74);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN75eq0), posedge DI[75], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_75);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN76eq0), posedge DI[76], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_76);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN77eq0), posedge DI[77], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_77);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN78eq0), posedge DI[78], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_78);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN79eq0), posedge DI[79], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_79);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN80eq0), posedge DI[80], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_80);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN81eq0), posedge DI[81], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_81);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN82eq0), posedge DI[82], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_82);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN83eq0), posedge DI[83], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_83);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN84eq0), posedge DI[84], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_84);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN85eq0), posedge DI[85], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_85);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN86eq0), posedge DI[86], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_86);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN87eq0), posedge DI[87], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_87);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN88eq0), posedge DI[88], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_88);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN89eq0), posedge DI[89], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_89);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN90eq0), posedge DI[90], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_90);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN91eq0), posedge DI[91], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_91);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN92eq0), posedge DI[92], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_92);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN93eq0), posedge DI[93], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_93);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN94eq0), posedge DI[94], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_94);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN95eq0), posedge DI[95], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_95);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN96eq0), posedge DI[96], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_96);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN97eq0), posedge DI[97], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_97);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN98eq0), posedge DI[98], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_98);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN99eq0), posedge DI[99], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_99);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN100eq0), posedge DI[100], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_100);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN101eq0), posedge DI[101], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_101);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN102eq0), posedge DI[102], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_102);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN103eq0), posedge DI[103], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_103);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN104eq0), posedge DI[104], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_104);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN105eq0), posedge DI[105], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_105);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN106eq0), posedge DI[106], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_106);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN107eq0), posedge DI[107], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_107);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN108eq0), posedge DI[108], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_108);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN109eq0), posedge DI[109], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_109);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN110eq0), posedge DI[110], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_110);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN111eq0), posedge DI[111], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_111);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN112eq0), posedge DI[112], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_112);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN113eq0), posedge DI[113], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_113);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN114eq0), posedge DI[114], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_114);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN115eq0), posedge DI[115], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_115);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN116eq0), posedge DI[116], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_116);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN117eq0), posedge DI[117], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_117);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN118eq0), posedge DI[118], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_118);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN119eq0), posedge DI[119], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_119);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN120eq0), posedge DI[120], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_120);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN121eq0), posedge DI[121], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_121);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN122eq0), posedge DI[122], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_122);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN123eq0), posedge DI[123], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_123);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN124eq0), posedge DI[124], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_124);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN125eq0), posedge DI[125], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_125);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN126eq0), posedge DI[126], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_126);
				$setuphold(posedge WCK &&& (opopWENeq0aDFTRAMeq0cpoopDFTRAMeq1aSEeq0cpcpaBWEN127eq0), posedge DI[127], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_DI_127);
				$setuphold(posedge RCK &&& (CRE1eq1aRENeq0aDFTRAMeq0), posedge FCA1[0], `D_MEM_SETUP, `D_MEM_HOLD, NOT_RCK_FCA);
				$setuphold(posedge RCK &&& (CRE1eq1aRENeq0aDFTRAMeq0), posedge FCA1[1], `D_MEM_SETUP, `D_MEM_HOLD, NOT_RCK_FCA);
				$setuphold(posedge RCK &&& (CRE1eq1aRENeq0aDFTRAMeq0), posedge FCA1[2], `D_MEM_SETUP, `D_MEM_HOLD, NOT_RCK_FCA);
				$setuphold(posedge RCK &&& (CRE1eq1aRENeq0aDFTRAMeq0), posedge FCA1[3], `D_MEM_SETUP, `D_MEM_HOLD, NOT_RCK_FCA);
				$setuphold(posedge RCK &&& (CRE1eq1aRENeq0aDFTRAMeq0), posedge FCA1[4], `D_MEM_SETUP, `D_MEM_HOLD, NOT_RCK_FCA);
				$setuphold(posedge WCK &&& (CRE1eq1aWENeq0aDFTRAMeq0), posedge FCA1[0], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_FCA);
				$setuphold(posedge WCK &&& (CRE1eq1aWENeq0aDFTRAMeq0), posedge FCA1[1], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_FCA);
				$setuphold(posedge WCK &&& (CRE1eq1aWENeq0aDFTRAMeq0), posedge FCA1[2], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_FCA);
				$setuphold(posedge WCK &&& (CRE1eq1aWENeq0aDFTRAMeq0), posedge FCA1[3], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_FCA);
				$setuphold(posedge WCK &&& (CRE1eq1aWENeq0aDFTRAMeq0), posedge FCA1[4], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_FCA);
				$setuphold(posedge RCK &&& (CRE2eq1aRENeq0aDFTRAMeq0), posedge FCA2[0], `D_MEM_SETUP, `D_MEM_HOLD, NOT_RCK_FCA);
				$setuphold(posedge RCK &&& (CRE2eq1aRENeq0aDFTRAMeq0), posedge FCA2[1], `D_MEM_SETUP, `D_MEM_HOLD, NOT_RCK_FCA);
				$setuphold(posedge RCK &&& (CRE2eq1aRENeq0aDFTRAMeq0), posedge FCA2[2], `D_MEM_SETUP, `D_MEM_HOLD, NOT_RCK_FCA);
				$setuphold(posedge RCK &&& (CRE2eq1aRENeq0aDFTRAMeq0), posedge FCA2[3], `D_MEM_SETUP, `D_MEM_HOLD, NOT_RCK_FCA);
				$setuphold(posedge RCK &&& (CRE2eq1aRENeq0aDFTRAMeq0), posedge FCA2[4], `D_MEM_SETUP, `D_MEM_HOLD, NOT_RCK_FCA);
				$setuphold(posedge WCK &&& (CRE2eq1aWENeq0aDFTRAMeq0), posedge FCA2[0], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_FCA);
				$setuphold(posedge WCK &&& (CRE2eq1aWENeq0aDFTRAMeq0), posedge FCA2[1], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_FCA);
				$setuphold(posedge WCK &&& (CRE2eq1aWENeq0aDFTRAMeq0), posedge FCA2[2], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_FCA);
				$setuphold(posedge WCK &&& (CRE2eq1aWENeq0aDFTRAMeq0), posedge FCA2[3], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_FCA);
				$setuphold(posedge WCK &&& (CRE2eq1aWENeq0aDFTRAMeq0), posedge FCA2[4], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_FCA);
				$setuphold(posedge RCK &&& (RENeq0aDFTRAMeq0), posedge KCS, `D_MEM_SETUP, `D_MEM_HOLD, NOT_RCK_KCS);
				$setuphold(posedge RCK &&& (opRENeq0aDFTRAMeq0cp), posedge MCSRD[0], `D_MEM_SETUP, `D_MEM_HOLD, NOT_RCK_MCSRD);
				$setuphold(posedge RCK &&& (opRENeq0aDFTRAMeq0cp), posedge MCSRD[1], `D_MEM_SETUP, `D_MEM_HOLD, NOT_RCK_MCSRD);
				$setuphold(posedge WCK &&& (WENeq0aDFTRAMeq0), posedge MCSWR[0], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_MCSWR);
				$setuphold(posedge WCK &&& (WENeq0aDFTRAMeq0), posedge MCSWR[1], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_MCSWR);
				$setuphold(posedge RCK &&& (DFTRAMeq0aRENeq0), posedge RA[0], `D_MEM_SETUP, `D_MEM_HOLD, NOT_RCK_RA_0);
				$setuphold(posedge RCK &&& (DFTRAMeq0aRENeq0), posedge RA[1], `D_MEM_SETUP, `D_MEM_HOLD, NOT_RCK_RA_1);
				$setuphold(posedge RCK &&& (DFTRAMeq0aRENeq0), posedge RA[2], `D_MEM_SETUP, `D_MEM_HOLD, NOT_RCK_RA_2);
				$setuphold(posedge RCK &&& (DFTRAMeq0), posedge REN, `D_MEM_SETUP, `D_MEM_HOLD, NOT_RCK_REN);
				$setuphold(posedge WCK &&& (DFTRAMeq1), posedge SE, `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_SE);
				$setuphold(posedge WCK &&& (DFTRAMeq1aSEeq1), posedge SI_D_L, `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_SI_D_L);
				$setuphold(posedge WCK &&& (DFTRAMeq1aSEeq1), posedge SI_D_R, `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_SI_D_R);
				$setuphold(posedge WCK &&& (DFTRAMeq0aWENeq0), posedge WA[0], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_WA_0);
				$setuphold(posedge WCK &&& (DFTRAMeq0aWENeq0), posedge WA[1], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_WA_1);
				$setuphold(posedge WCK &&& (DFTRAMeq0aWENeq0), posedge WA[2], `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_WA_2);
				$setuphold(posedge WCK &&& (DFTRAMeq0), posedge WEN, `D_MEM_SETUP, `D_MEM_HOLD, NOT_WCK_WEN);
				
				$recrem(posedge RCK, posedge WCK &&& (DFTRAMeq0aRENeq0aWENeq0), `D_MEM_RECOVERY, `D_MEM_REMOVAL, NOT_RCK_WCK);
				$recrem(posedge WCK, posedge RCK &&& (RENeq0aWENeq0aDFTRAMeq0), `D_MEM_RECOVERY, `D_MEM_REMOVAL, NOT_WCK_RCK);
				
				(DFTRAM => SO_D_L) = (`D_MEM_DELAY, `D_MEM_DELAY);
				
				(DFTRAM => SO_D_R) = (`D_MEM_DELAY, `D_MEM_DELAY);
				
				(SE => SO_D_L) = (`D_MEM_DELAY, `D_MEM_DELAY);
				
				(SE => SO_D_R) = (`D_MEM_DELAY, `D_MEM_DELAY);
				
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[0]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[1]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[2]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[3]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[4]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[5]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[6]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[7]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[8]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[9]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[10]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[11]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[12]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[13]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[14]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[15]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[16]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[17]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[18]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[19]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[20]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[21]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[22]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[23]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[24]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[25]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[26]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[27]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[28]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[29]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[30]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[31]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[32]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[33]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[34]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[35]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[36]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[37]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[38]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[39]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[40]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[41]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[42]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[43]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[44]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[45]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[46]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[47]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[48]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[49]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[50]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[51]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[52]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[53]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[54]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[55]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[56]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[57]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[58]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[59]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[60]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[61]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[62]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[63]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[64]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[65]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[66]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[67]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[68]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[69]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[70]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[71]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[72]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[73]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[74]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[75]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[76]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[77]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[78]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[79]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[80]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[81]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[82]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[83]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[84]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[85]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[86]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[87]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[88]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[89]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[90]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[91]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[92]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[93]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[94]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[95]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[96]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[97]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[98]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[99]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[100]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[101]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[102]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[103]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[104]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[105]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[106]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[107]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[108]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[109]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[110]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[111]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[112]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[113]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[114]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[115]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[116]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[117]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[118]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[119]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[120]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[121]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[122]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[123]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[124]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[125]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[126]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[127]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[0]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[1]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[2]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[3]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[4]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[5]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[6]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[7]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[8]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[9]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[10]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[11]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[12]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[13]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[14]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[15]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[16]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[17]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[18]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[19]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[20]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[21]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[22]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[23]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[24]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[25]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[26]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[27]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[28]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[29]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[30]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[31]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[32]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[33]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[34]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[35]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[36]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[37]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[38]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[39]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[40]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[41]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[42]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[43]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[44]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[45]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[46]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[47]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[48]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[49]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[50]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[51]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[52]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[53]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[54]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[55]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[56]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[57]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[58]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[59]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[60]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[61]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[62]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[63]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[64]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[65]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[66]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[67]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[68]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[69]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[70]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[71]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[72]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[73]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[74]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[75]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[76]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[77]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[78]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[79]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[80]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[81]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[82]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[83]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[84]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[85]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[86]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[87]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[88]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[89]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[90]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[91]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[92]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[93]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[94]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[95]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[96]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[97]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[98]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[99]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[100]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[101]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[102]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[103]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[104]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[105]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[106]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[107]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[108]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[109]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[110]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[111]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[112]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[113]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[114]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[115]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[116]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[117]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[118]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[119]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[120]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[121]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[122]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[123]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[124]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[125]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[126]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[127]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[0]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[1]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[2]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[3]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[4]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[5]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[6]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[7]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[8]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[9]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[10]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[11]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[12]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[13]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[14]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[15]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[16]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[17]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[18]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[19]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[20]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[21]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[22]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[23]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[24]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[25]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[26]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[27]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[28]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[29]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[30]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[31]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[32]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[33]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[34]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[35]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[36]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[37]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[38]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[39]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[40]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[41]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[42]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[43]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[44]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[45]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[46]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[47]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[48]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[49]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[50]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[51]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[52]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[53]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[54]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[55]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[56]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[57]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[58]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[59]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[60]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[61]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[62]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[63]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[64]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[65]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[66]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[67]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[68]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[69]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[70]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[71]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[72]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[73]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[74]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[75]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[76]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[77]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[78]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[79]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[80]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[81]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[82]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[83]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[84]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[85]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[86]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[87]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[88]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[89]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[90]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[91]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[92]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[93]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[94]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[95]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[96]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[97]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[98]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[99]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[100]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[101]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[102]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[103]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[104]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[105]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[106]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[107]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[108]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[109]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[110]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[111]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[112]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[113]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[114]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[115]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[116]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[117]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[118]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[119]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[120]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[121]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[122]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[123]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[124]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[125]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[126]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[127]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[0]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[1]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[2]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[3]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[4]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[5]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[6]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[7]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[8]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[9]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[10]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[11]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[12]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[13]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[14]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[15]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[16]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[17]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[18]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[19]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[20]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[21]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[22]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[23]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[24]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[25]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[26]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[27]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[28]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[29]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[30]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[31]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[32]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[33]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[34]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[35]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[36]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[37]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[38]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[39]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[40]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[41]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[42]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[43]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[44]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[45]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[46]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[47]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[48]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[49]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[50]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[51]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[52]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[53]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[54]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[55]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[56]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[57]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[58]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[59]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[60]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[61]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[62]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[63]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[64]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[65]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[66]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[67]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[68]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[69]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[70]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[71]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[72]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[73]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[74]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[75]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[76]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[77]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[78]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[79]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[80]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[81]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[82]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[83]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[84]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[85]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[86]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[87]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[88]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[89]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[90]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[91]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[92]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[93]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[94]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[95]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[96]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[97]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[98]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[99]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[100]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[101]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[102]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[103]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[104]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[105]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[106]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[107]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[108]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[109]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[110]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[111]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[112]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[113]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[114]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[115]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[116]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[117]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[118]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[119]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[120]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[121]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[122]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[123]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[124]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[125]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[126]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B0 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[127]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[0]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[1]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[2]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[3]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[4]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[5]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[6]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[7]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[8]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[9]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[10]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[11]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[12]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[13]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[14]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[15]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[16]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[17]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[18]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[19]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[20]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[21]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[22]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[23]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[24]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[25]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[26]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[27]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[28]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[29]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[30]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[31]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[32]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[33]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[34]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[35]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[36]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[37]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[38]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[39]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[40]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[41]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[42]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[43]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[44]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[45]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[46]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[47]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[48]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[49]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[50]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[51]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[52]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[53]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[54]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[55]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[56]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[57]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[58]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[59]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[60]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[61]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[62]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[63]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[64]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[65]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[66]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[67]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[68]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[69]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[70]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[71]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[72]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[73]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[74]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[75]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[76]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[77]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[78]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[79]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[80]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[81]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[82]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[83]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[84]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[85]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[86]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[87]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[88]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[89]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[90]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[91]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[92]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[93]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[94]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[95]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[96]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[97]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[98]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[99]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[100]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[101]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[102]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[103]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[104]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[105]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[106]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[107]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[108]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[109]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[110]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[111]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[112]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[113]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[114]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[115]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[116]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[117]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[118]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[119]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[120]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[121]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[122]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[123]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[124]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[125]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[126]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[127]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[0]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[1]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[2]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[3]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[4]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[5]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[6]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[7]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[8]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[9]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[10]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[11]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[12]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[13]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[14]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[15]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[16]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[17]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[18]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[19]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[20]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[21]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[22]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[23]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[24]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[25]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[26]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[27]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[28]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[29]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[30]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[31]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[32]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[33]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[34]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[35]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[36]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[37]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[38]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[39]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[40]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[41]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[42]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[43]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[44]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[45]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[46]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[47]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[48]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[49]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[50]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[51]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[52]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[53]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[54]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[55]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[56]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[57]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[58]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[59]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[60]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[61]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[62]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[63]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[64]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[65]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[66]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[67]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[68]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[69]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[70]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[71]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[72]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[73]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[74]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[75]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[76]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[77]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[78]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[79]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[80]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[81]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[82]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[83]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[84]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[85]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[86]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[87]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[88]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[89]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[90]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[91]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[92]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[93]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[94]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[95]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[96]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[97]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[98]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[99]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[100]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[101]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[102]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[103]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[104]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[105]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[106]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[107]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[108]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[109]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[110]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[111]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[112]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[113]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[114]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[115]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[116]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[117]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[118]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[119]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[120]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[121]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[122]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[123]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[124]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[125]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[126]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B0 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[127]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[0]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[1]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[2]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[3]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[4]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[5]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[6]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[7]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[8]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[9]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[10]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[11]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[12]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[13]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[14]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[15]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[16]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[17]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[18]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[19]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[20]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[21]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[22]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[23]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[24]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[25]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[26]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[27]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[28]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[29]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[30]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[31]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[32]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[33]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[34]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[35]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[36]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[37]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[38]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[39]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[40]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[41]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[42]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[43]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[44]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[45]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[46]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[47]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[48]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[49]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[50]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[51]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[52]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[53]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[54]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[55]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[56]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[57]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[58]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[59]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[60]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[61]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[62]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[63]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[64]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[65]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[66]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[67]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[68]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[69]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[70]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[71]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[72]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[73]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[74]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[75]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[76]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[77]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[78]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[79]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[80]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[81]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[82]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[83]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[84]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[85]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[86]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[87]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[88]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[89]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[90]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[91]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[92]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[93]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[94]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[95]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[96]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[97]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[98]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[99]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[100]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[101]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[102]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[103]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[104]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[105]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[106]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[107]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[108]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[109]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[110]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[111]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[112]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[113]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[114]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[115]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[116]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[117]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[118]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[119]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[120]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[121]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[122]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[123]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[124]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[125]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[126]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B0 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[127]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[0]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[1]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[2]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[3]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[4]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[5]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[6]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[7]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[8]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[9]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[10]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[11]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[12]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[13]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[14]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[15]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[16]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[17]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[18]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[19]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[20]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[21]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[22]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[23]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[24]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[25]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[26]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[27]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[28]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[29]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[30]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[31]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[32]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[33]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[34]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[35]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[36]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[37]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[38]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[39]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[40]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[41]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[42]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[43]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[44]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[45]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[46]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[47]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[48]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[49]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[50]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[51]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[52]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[53]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[54]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[55]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[56]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[57]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[58]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[59]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[60]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[61]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[62]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[63]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[64]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[65]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[66]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[67]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[68]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[69]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[70]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[71]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[72]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[73]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[74]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[75]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[76]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[77]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[78]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[79]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[80]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[81]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[82]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[83]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[84]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[85]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[86]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[87]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[88]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[89]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[90]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[91]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[92]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[93]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[94]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[95]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[96]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[97]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[98]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[99]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[100]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[101]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[102]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[103]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[104]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[105]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[106]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[107]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[108]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[109]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[110]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[111]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[112]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[113]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[114]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[115]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[116]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[117]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[118]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[119]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[120]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[121]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[122]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[123]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[124]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[125]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[126]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( KCS==1'B1 && MCSRD[1]==1'B1 && MCSRD[0]==1'B1 && REN==1'B0 && DFTRAM==1'B0 && ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B0 )
					(posedge RCK => (DOUT[127]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[0]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[1]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[2]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[3]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[4]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[5]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[6]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[7]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[8]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[9]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[10]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[11]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[12]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[13]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[14]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[15]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[16]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[17]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[18]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[19]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[20]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[21]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[22]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[23]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[24]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[25]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[26]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[27]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[28]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[29]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[30]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[31]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[32]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[33]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[34]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[35]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[36]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[37]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[38]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[39]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[40]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[41]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[42]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[43]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[44]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[45]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[46]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[47]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[48]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[49]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[50]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[51]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[52]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[53]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[54]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[55]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[56]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[57]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[58]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[59]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[60]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[61]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[62]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[63]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[64]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[65]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[66]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[67]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[68]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[69]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[70]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[71]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[72]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[73]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[74]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[75]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[76]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[77]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[78]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[79]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[80]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[81]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[82]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[83]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[84]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[85]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[86]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[87]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[88]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[89]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[90]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[91]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[92]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[93]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[94]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[95]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[96]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[97]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[98]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[99]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[100]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[101]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[102]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[103]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[104]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[105]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[106]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[107]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[108]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[109]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[110]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[111]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[112]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[113]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[114]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[115]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[116]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[117]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[118]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[119]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[120]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[121]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[122]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[123]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[124]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[125]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[126]:1'b1)) = (`D_MEM_DELAY);
				if ( REN==1'B0 && DFTRAM==1'B0 && ( ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B0 && ADME[1]==1'B1 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B0 && ADME[0]==1'B1 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B0 ) || ( ADME[2]==1'B1 && ADME[1]==1'B1 && ADME[0]==1'B1 ) ) )
					(posedge RCK => (DOUT[127]:1'b1)) = (`D_MEM_DELAY);
				
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[0]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[1]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[2]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[3]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[4]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[5]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[6]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[7]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[8]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[9]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[10]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[11]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[12]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[13]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[14]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[15]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[16]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[17]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[18]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[19]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[20]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[21]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[22]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[23]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[24]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[25]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[26]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[27]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[28]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[29]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[30]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[31]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[32]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[33]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[34]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[35]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[36]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[37]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[38]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[39]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[40]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[41]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[42]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[43]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[44]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[45]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[46]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[47]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[48]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[49]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[50]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[51]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[52]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[53]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[54]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[55]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[56]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[57]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[58]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[59]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[60]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[61]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[62]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[63]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[64]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[65]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[66]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[67]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[68]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[69]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[70]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[71]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[72]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[73]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[74]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[75]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[76]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[77]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[78]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[79]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[80]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[81]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[82]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[83]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[84]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[85]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[86]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[87]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[88]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[89]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[90]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[91]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[92]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[93]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[94]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[95]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[96]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[97]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[98]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[99]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[100]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[101]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[102]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[103]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[104]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[105]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[106]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[107]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[108]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[109]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[110]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[111]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[112]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[113]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[114]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[115]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[116]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[117]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[118]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[119]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[120]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[121]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[122]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[123]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[124]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[125]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[126]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				if ( DFTRAM==1'B1 )
					(posedge WCK => (DOUT[127]:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				
				if ( DFTRAM==1'B1 && SE==1'B1 )
					(posedge WCK => (SO_D_L:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				
				if ( DFTRAM==1'B1 && SE==1'B1 )
					(posedge WCK => (SO_D_R:1'b1)) = (`D_MEM_DELAY, `D_MEM_DELAY);
				
			endspecify
			
			
			
		`endif
	endmodule

`endcelldefine


module ln04lpp_s00_mc_rf2rws_hsr_lvt_8x128m1b2c1_GPC_REPACK_8X128_error_injection
	(Q_out,
	Q_in,
	CLKA,
	CLKB,
	AA,
	AB,
	CENA,
	
	CRE1,
	CRE2,
	FCA1,
	FCA2,
	CENB
	);
// Parameter definition
	parameter word_depth  = 8;
	parameter WORDS  = 8;
	parameter word_width  = 128;
	parameter addr_width  = 3;
	parameter faddr1_width = 5;
	parameter faddr2_width = 5;
	parameter faddr_width = 5;
	parameter fault_table_width = 15;
	parameter fault_table_width_addr = 12;
	parameter bit_place_width = 7;
	parameter MEM_WIDTH = 132;
	parameter MEM_HEIGHT = 8;

	output [word_width-1:0] Q_out;
	input [word_width-1:0] Q_in;
	input CLKA;
	input CLKB;
	input [addr_width-1:0] AA;
	input [addr_width-1:0] AB;
	input CENA;
	input CENB;
	input CRE1;
	input [faddr1_width-1:0] FCA1;
	input CRE2;
	input [faddr2_width-1:0] FCA2;
	parameter LEFT_RED_COLUMN_FAULT = 2'd1;
	parameter RIGHT_RED_COLUMN_FAULT = 2'd2;
	parameter NO_RED_FAULT = 2'd0;
	reg [word_width-1:0] Q_out;
	reg entry_found;
	reg list_complete;
	reg [fault_table_width-1:0] fault_table [MEM_HEIGHT-1:0];
	reg [fault_table_width-1:0] fault_entry;

	initial
	begin
		`ifdef DUT
			`define pre_pend_path TB.DUT_inst.CHIP
		`else
			`define pre_pend_path TB.CHIP
		`endif
		`ifdef SAMSUNG_REPAIRABLE_FAULT
			`pre_pend_path.SMARCHCHKBVCD_LVISION_MBISTPG_ASSEMBLY_UNDER_TEST_INST.MEM0_MEM_INST.u_mem.u1.add_fault(3'd7,7'd2,2'd2,2'd0);
			`pre_pend_path.SMARCHCHKBVCD_LVISION_MBISTPG_ASSEMBLY_UNDER_TEST_INST.MEM0_MEM_INST.u_mem.u1.add_fault(3'd6,7'd125,2'd2,2'd0);
			
		`endif
		`ifdef SAMSUNG_NONREPAIRABLE_FAULT
			`pre_pend_path.SMARCHCHKBVCD_LVISION_MBISTPG_ASSEMBLY_UNDER_TEST_INST.MEM0_MEM_INST.u_mem.u1.add_fault(3'd7,7'd2,2'd2,2'd0);
			`pre_pend_path.SMARCHCHKBVCD_LVISION_MBISTPG_ASSEMBLY_UNDER_TEST_INST.MEM0_MEM_INST.u_mem.u1.add_fault(3'd6,7'd125,2'd2,2'd0);
			
			`pre_pend_path.SMARCHCHKBVCD_LVISION_MBISTPG_ASSEMBLY_UNDER_TEST_INST.MEM0_MEM_INST.u_mem.u1.add_fault(3'd4,7'd64,2'd2,2'd0);
			
		`endif

	end
	task add_fault;
//This task injects fault in memory
		input [addr_width-1:0] address;
		input [bit_place_width-1 :0] bitPlace;
		input [1:0] fault_type;
		input [1:0] red_fault;

		integer i;
		reg done;
		begin
			done = 1'b0;
			i = 0;
			while ((!done) && i < MEM_HEIGHT-1)
			begin
				fault_entry = fault_table[i];
				if (fault_entry[0] === 1'b0 || fault_entry[0] === 1'bx)
				begin
					fault_entry[0] = 1'b1;
					fault_entry[2:1] = red_fault;
					fault_entry[4:3] = fault_type;
					fault_entry[fault_table_width_addr-1:5] = bitPlace;
					fault_entry[fault_table_width-1:fault_table_width_addr] = address;
					fault_table[i] = fault_entry;
					done = 1'b1;
				end
				i = i+1;
			end
		end
	endtask
//This task removes all fault entries injected by user
	task remove_all_faults;
		integer i;
		begin
			for (i = 0; i < MEM_HEIGHT; i=i+1)
			begin
				fault_entry = fault_table[i];
				fault_entry[0] = 1'b0;
				fault_table[i] = fault_entry;
			end
		end
	endtask
	task bit_error;
// This task is used to inject error in memory and should be called
// only from current module.
//
// This task injects error depending upon fault type to particular bit
// of the output
		inout [word_width-1:0] q_int;
		input [1:0] fault_type;
		input [bit_place_width -1 :0] bitLoc;
		begin
			if (fault_type === 2'd0)
				q_int[bitLoc] = 1'b0;
			else if (fault_type === 2'd1)
				q_int[bitLoc] = 1'b1;
			else
				q_int[bitLoc] = ~q_int[bitLoc];
		end
	endtask
	task error_injection_on_output;
// This function goes through error injection table for every
// read cycle and corrupts Q output if fault for the particular
// address is present in fault table
//
// If fault is redundant column is detected, this task corrupts
// Q output in read cycle
//
// If fault is repaired using repair bus, this task does not
// courrpt Q output in read cycle
//
		output [word_width-1:0] Q_output;
		reg list_complete;
		integer i;
		reg [2:0] row_address;
		reg [bit_place_width -1 :0] bitPlace;
		reg [1:0] fault_type;
		reg [1:0] red_fault;
		reg valid;
		reg [bit_place_width :0] msb_bit_calc;
		begin
			entry_found = 1'b0;
			list_complete = 1'b0;
			i = 0;
			Q_output = Q_in;
			while(!list_complete)
			begin
				fault_entry = fault_table[i];
				{row_address, bitPlace, fault_type, red_fault, valid} = fault_entry;
				i = i + 1;
				if (valid == 1'b1)
				begin
					if (red_fault === LEFT_RED_COLUMN_FAULT && CRE1 === 1'b1)
						bit_error(Q_output, fault_type,7'd0);
					else if (red_fault === RIGHT_RED_COLUMN_FAULT && CRE2 === 1'b1)
						bit_error(Q_output, fault_type,7'd64);
					else if (red_fault === NO_RED_FAULT)
					begin
						if (row_address == AA[addr_width-1:0] )
						begin
//when no redundancy
									
//no col redundancy enable
								if (bitPlace <  64 && CRE1 === 1'b0)
									bit_error(Q_output,fault_type, bitPlace);
								else if (bitPlace >= 64 && CRE2 === 1'b0)
									bit_error(Q_output,fault_type, bitPlace);
//only for column redundancy
								else if (bitPlace < 64 && CRE1 === 1'b1)
								begin
									if ((bitPlace +(2*FCA1) != 63) && (bitPlace +(2*FCA1) != 62))
									begin
										bit_error(Q_output, fault_type,bitPlace);
									end
								end
								else if (bitPlace >= 64 && CRE2 === 1'b1)
								begin
									msb_bit_calc = bitPlace - 64;
									if ((msb_bit_calc != (2*FCA2)) && (msb_bit_calc != (2*FCA2+1)))
									begin
										bit_error(Q_output,fault_type, bitPlace);
									end
								end
							
						end
					end
				end
				else
					list_complete = 1'b1;
			end
		end
	endtask
	always @ (Q_in or CLKA or CLKB or AA or AB or CENA or CENB or CRE1 or FCA1 or CRE2 or FCA2)
	begin
		if (CENA === 1'b0)
			error_injection_on_output(Q_out);
	end
endmodule
	`else
`endif
	
		
