// +FHDR----------------------------------------------------------------------------
// Copyright   (c) 2025, Innosilicon, Inc. Confidential Proprietary
// PROJECT NAME  : xxx
// DEPARTMENT    : Digtal Frontend SOC
// AUTHOR        : chenm
// EMAIL         : chenm@innosilicon.com.cn
// CREATE ON     : 2025/11/14 11:24
// FILE NAME     : repack_sync_fifo.v
// DESCRIPTION   :          
//         
// Copyright   (c) 2025 Innosilicon.
// ALL RIGHTS RESERVED
// 
// ---------------------------------------------------------------------------------
// Modification History:
// Date         By              Version                 Change Description
// ---------------------------------------------------------------------------------
// 2025/11/14   chenm           1.0                     Original
// 
// -FHDR----------------------------------------------------------------------------

module repack_sync_fifo #(
    parameter FIFO_WIDTH = 32, 
    parameter FIFO_DEPTH = 4, 
    parameter ADDR_WIDTH = 2
   )(

	input                   clk        , //clock
	input                   reset_n    , //resetn
	input  [FIFO_WIDTH-1:0] push_data  , //input data
	input                   push_valid , //input data valid
	output                  push_ready , //input data ready

	output [FIFO_WIDTH-1:0] pop_data   , //output data
	output [FIFO_WIDTH-1:0] second_data, //output data
    output                  almost_empty,
	output                  pop_valid  , //output data valid
	input                   pop_ready    //output data read
);


reg  [ADDR_WIDTH :0] rd_addr     ; // according the input depth parameter declare read point
reg  [ADDR_WIDTH :0] wr_addr     ; // according the input depth parameter declare write point
wire [ADDR_WIDTH :0] rd_addr_nxt ; // according the input depth parameter declare read point
wire [ADDR_WIDTH :0] wr_addr_nxt ; // according the input depth parameter declare write point

wire   empty = (rd_addr == wr_addr);  //when write pointer is equal read pointer means this fifo is empty

assign   almost_empty = (wr_addr - rd_addr) == 1'd1;

assign rd_addr_nxt = rd_addr[ADDR_WIDTH-1:0] == (FIFO_DEPTH - 1) ? {~rd_addr[ADDR_WIDTH], {ADDR_WIDTH{1'd0}}} : rd_addr + 1'd1;
assign wr_addr_nxt = wr_addr[ADDR_WIDTH-1:0] == (FIFO_DEPTH - 1) ? {~wr_addr[ADDR_WIDTH], {ADDR_WIDTH{1'd0}}} : wr_addr + 1'd1;

//when the highest values of the read pointer and write pointer are not equal,
//the other bits are equal, indicating that the fifo is full
wire   full  = (wr_addr[ADDR_WIDTH] ^ rd_addr[ADDR_WIDTH]) & (wr_addr[ADDR_WIDTH-1:0] == rd_addr[ADDR_WIDTH-1:0]); 

//when the fifo is not empty, it can pop data to the downstream
//when the fifo is not full, it can accept data from the upstream
assign pop_valid  = ~empty;
assign push_ready = ~full;

//when handshake with downstream or upstream means read or write operation occurs
wire do_write = push_valid & push_ready;
wire do_read  = pop_valid  & pop_ready;

//update read pointer and write pointer after read and write operation 
always@(posedge clk or negedge reset_n)
	if(!reset_n)begin
		rd_addr <= {ADDR_WIDTH+1{1'd0}}; 
		wr_addr <= {ADDR_WIDTH+1{1'd0}}; 
	end else begin
		if(do_read)	    rd_addr <= rd_addr_nxt;
		if(do_write)	wr_addr <= wr_addr_nxt;
	end


reg [FIFO_WIDTH-1 :0] mem [FIFO_DEPTH-1 : 0];  // according the input depth and width parameter declare memreg 

integer i;
always@(posedge clk or negedge reset_n)
	if(!reset_n)begin  //when reset, clear all register
		for(i=0; i<FIFO_DEPTH; i=i+1)
			mem[i] <= {FIFO_WIDTH{1'd0}};
	end else if(do_write)  //when write operation occur, store the data in a register
		mem[wr_addr[ADDR_WIDTH-1:0]] <= push_data;  


assign pop_data     = mem[rd_addr[ADDR_WIDTH-1:0]];   //when read operation occur, pop the data from memory register
assign second_data  = mem[rd_addr_nxt[ADDR_WIDTH-1:0]];   //when read operation occur, pop the data from memory register

endmodule
// Local Variables:
// verilog-library-directories:("-y ./ -y ../")
// verilog-auto-inst-param-value:t
// End:
