
`timescale 1ns/1ps
module comb_process_dp2clk_D32W512_wrapper (
// Beginning of automatic inputs (from unused autoinst inputs)
input                   Clk,                    // To inst_u0 of pcie_atomic_dp2clk_D16W128_wrapper.v, ...
input [4:0]             RdAddr,                 // To inst_u0 of pcie_atomic_dp2clk_D16W128_wrapper.v, ...
input                   RdEn,                   // To inst_u0 of pcie_atomic_dp2clk_D16W128_wrapper.v, ...
input [4:0]             WrAddr,                 // To inst_u0 of pcie_atomic_dp2clk_D16W128_wrapper.v, ...
input [511: 0]        WrData,                 // To inst_u0 of pcie_atomic_dp2clk_D16W128_wrapper.v, ..., Couldn't Merge
input                   WrEn,                   // To inst_u0 of pcie_atomic_dp2clk_D16W128_wrapper.v, ...
// End of automatics
// Beginning of automatic outputs (from unused autoinst outputs)
output [511: 0]       RdData                  // From inst_u0 of pcie_atomic_dp2clk_D16W128_wrapper.v, ..., Couldn't Merge
// End of automatics
   );
/*autowire*/
/* comb_process_dp2clk_D32W128_wrapper auto_template "inst_u\(.*\)"(
.Q          (RdData[@"(+ (* 128 @) 127)": @"(* 128 @)"]),
    .AA         (WrAddr[]),
    .AB         (RdAddr[]),
    .BWEB       (WrBitEn[@"(+ (* 128 @) 127)": @"(* 128 @)"]),
    .CLK        (Clk),
    .D          (WrData[@"(+ (* 128 @) 127)": @"(* 128 @)"]),
    .REB        (RdEn),
    .WEA        (WrEn),
);*/

comb_process_dp2clk_D32W128_wrapper inst_u0(/*autoinst*/
                                            // Outputs
                                            .Q                  (RdData[127: 0]), // Templated
                                            // Inputs
                                            .AA                 (WrAddr[4:0]),   // Templated
                                            .AB                 (RdAddr[4:0]),   // Templated
                                            .CLK                (Clk),           // Templated
                                            .D                  (WrData[127: 0]), // Templated
                                            .REB                (RdEn),          // Templated
                                            .WEA                (WrEn));                 // Templated

comb_process_dp2clk_D32W128_wrapper inst_u1(/*autoinst*/
                                            // Outputs
                                            .Q                  (RdData[255: 128]), // Templated
                                            // Inputs
                                            .AA                 (WrAddr[4:0]),   // Templated
                                            .AB                 (RdAddr[4:0]),   // Templated
                                            .CLK                (Clk),           // Templated
                                            .D                  (WrData[255: 128]), // Templated
                                            .REB                (RdEn),          // Templated
                                            .WEA                (WrEn));                 // Templated
comb_process_dp2clk_D32W128_wrapper inst_u2(/*autoinst*/
                                            // Outputs
                                            .Q                  (RdData[383: 256]), // Templated
                                            // Inputs
                                            .AA                 (WrAddr[4:0]),   // Templated
                                            .AB                 (RdAddr[4:0]),   // Templated
                                            .CLK                (Clk),           // Templated
                                            .D                  (WrData[383: 256]), // Templated
                                            .REB                (RdEn),          // Templated
                                            .WEA                (WrEn));                 // Templated
comb_process_dp2clk_D32W128_wrapper inst_u3(/*autoinst*/
                                            // Outputs
                                            .Q                  (RdData[511: 384]), // Templated
                                            // Inputs
                                            .AA                 (WrAddr[4:0]),   // Templated
                                            .AB                 (RdAddr[4:0]),   // Templated
                                            .CLK                (Clk),           // Templated
                                            .D                  (WrData[511: 384]), // Templated
                                            .REB                (RdEn),          // Templated
                                            .WEA                (WrEn));                 // Templated

 endmodule

// Local Variables:
// verilog-library-directories:("./") 
// verilog-auto-inst-param-value:t
// End:
