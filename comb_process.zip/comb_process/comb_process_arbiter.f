//+define+REG_MEM
$GP3_RTL/top/rtl/gpu_comb/arb_core_round_robin.v
$GP3_RTL/top/rtl/gpu_comb/arbiter_round_robin_last.v
