  input bar;
  output foo;
