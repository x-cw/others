

reset -name  "${DESIGN_NAME}.resetn"       -value 0
reset -name  "${DESIGN_NAME}.presetn"      -value 0

quasi_static -name "${DESIGN_NAME}.u_aud_top_reg.reg04*"
quasi_static -name "${DESIGN_NAME}.u_aud_top_reg.reg10*"
quasi_static -name "${DESIGN_NAME}.u_aud_top_reg.reg14*"
