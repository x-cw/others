#set env
set G_RTL_ROOT  $env(G_RTL_ROOT)
set G_FLST_ROOT $env(G_FLST_ROOT)
set G2_RTL     $env(G2_RTL)
set DESIGN_NAME $env(DESIGN_NAME)

set search_path ". "

#####################################TODO read memory and lib cell 
set TECH_LIB        $env(TECH_LIB)
source ./tech_lib_setup/tech_lib_setup.tcl

## Enable ML RCA
#enable_rca_cluster -app cdc

# 0: Set parameter/options that can impact the design read.
set_app_var enable_cdc true  ;# Configures vc_static_shell to run CDC
set_app_var enable_dw true  ;# Handling Instantiated DesignWare
set_app_var enable_dc_naming_style true ;# DFF to *_reg
configure_cdc_tag -tag SETUP_CLOCK_* -severity error ;# Configures CDC tag


#####################################TODO  set libs and ignore files to ip 
#source set_lib_bb.tcl

#####################################TODO waive file manage
#read waive files
if {[file exists ./waive/vc_spyglass_cdc_waiver.tcl]} {
  manage_waiver_file -add         ./waive/vc_spyglass_cdc_waiver.tcl
  manage_waiver_file -add         ./waive/waive_ip.tcl
  set_app_var default_waiver_file ./waive/vc_spyglass_cdc_waiver.tcl
}

# 1: Specify where to find Source code, Analyze and Elaborate:
#####################################TODO read filellist
#analyze -verbose -format vhdl     -vcs "-f $G2_RTL/filelist_dut_vhdl.f"
analyze -verbose -format sverilog -vcs "-V +lint=all -f ../scp_top_wrap_for_dc.f -l analyze_vcs.log"


elaborate $DESIGN_NAME -verbose -vcs {-l elaborate_vcs.log}

# 2: Read SDCs - all clock and reset data
#####################################TODO read sdc
source -e -v scp_top_wrap.sdc
# reset constraint
source -e -v ./vc_spyglass_constraints.tcl


# 3: Specify synchronizer cells, configure CDC Configurations, etc
configure_cdc_nff_sync -depth 2 ;# Configuration for sync cells

configure_cdc_data_sync -skip_autoqual

configure_cdc_nff_sync -uds_modules "sig_sync sig_async_edge DW_apb_gpio_bcm21"
configure_cdc_asyncrst_nff_sync -uds_modules "reset_sync reset_sync_dft reset_n_sync reset_n_sync_dft"


#####################################TODO select different rules
# 4: Propagates clocks and resets; Report and fix setup issues
#check_cdc -type setup; report_cdc -stage setup -verbose -limit 0 -file setup.report ;# Run and report the setup checks

# 5: Checks synchronization schemes ; 
#check_cdc -type sync; report_cdc -stage sync -verbose -limit 0 -file sync.report ;# run and report the sync checks

# 6: Check convergence and glitch issue; 
check_cdc -type struct; 

## Performs RCA, used before report_cdc
#execute_rootcause_analysis -app cdc

#report_cdc -stage {conv glitch} -verbose -limit 0 -file struct.report ;# run and report other checks
report_cdc -verbose -limit 0 -file struct.report ;# run and report other checks

# 7: Save Session
checkpoint_session -session cdc_complete ;# save a CDC session

#save_session -session vc_cdc_session;

#Open GUI for analysis, schematics
view_activity ;# Open the GUI
#quit ;# quit VC static shell
