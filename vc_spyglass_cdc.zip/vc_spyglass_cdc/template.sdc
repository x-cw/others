
create_clock [get_ports "clk_a"] -name CLOCK_A    -period 0.5
create_clock [get_ports "clk_b"] -name CLOCK_B    -period 0.6


set_ideal_network [get_ports "clk_a"]
set_ideal_network [get_ports "clk_b"]


set_ideal_network [get_ports rst_n_a*] -no_propagate
set_ideal_network [get_ports rst_n_b*] -no_propagate

set_clock_groups  -asynchronous -name asynch  -group [get_clocks CLOCK_A] \
                                              -group [get_clocks CLOCK_B]


set_input_delay    0.3   -clock CLOCK_A  [get_ports "rst_n_a* din_a*"]
set_output_delay   0.3   -clock CLOCK_A  [get_ports "dout_a*"]
 
set_input_delay    0.3   -clock CLOCK_B  [get_ports "rst_n_b* din_b*"]
set_output_delay   0.3   -clock CLOCK_B  [get_ports "dout_b*"]
 
