
#current_design ${DESIGN_NAME}
#

#Reset definition

create_reset -async -sense high [get_ports "trig_pcie*_button*"] 
create_reset -async -sense low  [get_ports "pcie*_hot_resetn*"]
create_reset -async -sense low  [get_ports PADS_RESETN]
create_reset -async -sense low  [get_ports PADS_LSP_JTAG_RSTN]

create_reset -async -sense high [get_pins scp_top_inst/reset_ctrl_inst/wd_rst_*]
create_reset -async -sense low  [get_pins scp_top_inst/reset_ctrl_inst/noc_fr_ec_sys_rstn_reg]
create_reset -async -sense low  [get_pins scp_top_inst/reset_ctrl_inst/hw_rstn_from_pin]
create_reset -async -sense low  [get_pins scp_top_inst/reset_ctrl_inst/scp_por_inst/POR_U/POR_OUT]
create_reset -async -sense low  [get_pins scp_top_inst/scp_wdt_inst/wdt_sys_rst_n]
#create_reset -async -sense low  [get_pins scp_top_inst/reset_ctrl_inst/reset_ctrl_inst/rstn_mbist_pm_all]
create_reset -async -sense low  [get_pins -of [get_cells scp_top_inst/reset_ctrl_inst/rstn_mbist_pm_all_reg] -filter "full_name =~ *Q"]




#Add any missing SDC constraints - ignore paths, quasi-static signals, etc
#set_cdc_ignore_path -from_clock {clk1} -to_clock {clk2} # equivalent to cdc_false_path in SG
set_cdc_ignore_path -to  "reset_sync reset_sync_dft reset_n_sync reset_n_sync_dft" -type coherency_multi_sync

# reg
create_static -name [get_pins scp_top_inst/DW_apb_timers_inst/U_apbif/int_timer_intr_reg/Q[7:0]]
create_static -name [get_pins scp_top_inst/scp_reg_top_inst/scp_reg_inst/inter_*_reg/Q]
create_static -name [get_pins scp_top_inst/scp_reg_top_inst/scp_pf0_reg_inst/inter_*_reg/Q]
create_static -name [get_pins scp_top_inst/scp_reg_top_inst/scp_pf1_reg_inst/inter_*_reg/Q]
create_static -name [get_pins scp_top_inst/scp_reg_top_inst/scp_intlv_reg_inst/inter_*_reg/Q]
create_static -name [get_pins scp_top_inst/scp_wdt_inst/DW_apb_wdt_inst*/U_DW_apb_wdt_regfile/wdt_torr_ir_reg/Q]
create_static -name [get_pins scp_top_inst/scp_wdt_inst/DW_apb_wdt_inst*/U_DW_apb_wdt_regfile/wdt_torr_hold_reg/Q]
create_static -name [get_pins scp_top_inst/scp_wdt_inst/DW_apb_wdt_inst*/U_DW_apb_wdt_regfile/wdt_cr_ir_reg/Q]
create_static -name [get_pins scp_top_inst/DW_apb_timers_inst/U_apbif/u_t*cr/r_odata_reg/Q]
create_static -name [get_pins scp_top_inst/scp_reg_top_inst/scp_reg_inst/reg_pll_measure_cnt_err]
create_static -name [get_pins scp_top_inst/clk_gen_inst/pll_wrap_inst.pll_wrapper_*/reg_pll_pd_d_reg/Q]
create_static -name [get_pins scp_top_inst/clk_gen_inst/pll_wrap_inst.pll_wrapper_*/pd_ext_pre_reg/Q]
create_static -name [get_pins low_speed_misc_wrap_inst/pwm_wrap_u/apb_pwm_fan_u/pwm_fan_core_u/pwm_fan_apb_reg_u/pwm_start]
create_static -name [get_pins low_speed_misc_wrap_inst/pwm_wrap_u/apb_pwm_vid_u/pwm_vid_core_u/pwm_vid_apb_reg_u/pwm_start]
create_static -name [get_pins low_speed_misc_wrap_inst/pwm_wrap_u/apb_pwm_fan_u/pwm_fan_core_u/pwm_fan_apb_reg_u/pfwm*_th_low]
create_static -name [get_pins low_speed_misc_wrap_inst/pwm_wrap_u/apb_pwm_fan_u/pwm_fan_core_u/pwm_fan_apb_reg_u/pfwm*_th_high]
create_static -name [get_pins low_speed_misc_wrap_inst/pwm_wrap_u/apb_pwm_vid_u/pwm_vid_core_u/pwm_vid_apb_reg_u/pwm_period]
create_static -name [get_pins low_speed_misc_wrap_inst/pwm_wrap_u/apb_pwm_vid_u/pwm_vid_core_u/pwm_vid_apb_reg_u/pwm_end]
create_static -name [get_pins low_speed_misc_wrap_inst/pwm_wrap_u/apb_pwm_fan_u/pwm_fan_core_u/pwm_fan_apb_reg_u/pwm_period]
create_static -name [get_pins low_speed_misc_wrap_inst/pwm_wrap_u/apb_pwm_fan_u/pwm_fan_core_u/pwm_fan_apb_reg_u/pwm_end]
create_static -name [get_pins low_speed_misc_wrap_inst/pwm_wrap_u/apb_pwm_fan_u/pwm_fan_core_u/pwm_fan_apb_reg_u/pfwm0_cnt_high]
create_static -name [get_pins low_speed_misc_wrap_inst/pwm_wrap_u/apb_pwm_fan_u/pwm_fan_core_u/pwm_fan_apb_reg_u/pfwm1_cnt_high]
create_static -name [get_pins low_speed_misc_wrap_inst/pwm_wrap_u/apb_pwm_fan_u/pwm_fan_core_u/pwm_fan_apb_reg_u/pfwm0_cnt_low]
create_static -name [get_pins low_speed_misc_wrap_inst/pwm_wrap_u/apb_pwm_fan_u/pwm_fan_core_u/pwm_fan_apb_reg_u/pfwm1_cnt_low]
create_static -name [get_pins low_speed_misc_wrap_inst/pwm_wrap_u/apb_pwm_vid_u/pwm_vid_core_u/pwm_vid_apb_reg_u/pwm_enable]
create_static -name [get_pins low_speed_misc_wrap_inst/pwm_wrap_u/apb_pwm_vid_u/pwm_vid_core_u/pwm_vid_apb_reg_u/pwm_output_0]
create_static -name [get_pins low_speed_misc_wrap_inst/pwm_wrap_u/apb_pwm_vid_u/pwm_vid_core_u/pwm_vid_apb_reg_u/pwm_output_1]
create_static -name [get_pins low_speed_misc_wrap_inst/pwm_wrap_u/apb_pwm_fan_u/pwm_fan_core_u/pwm_fan_apb_reg_u/pwm_enable]
create_static -name [get_pins low_speed_misc_wrap_inst/pwm_wrap_u/apb_pwm_fan_u/pwm_fan_core_u/pwm_fan_apb_reg_u/pwm_output_0]
create_static -name [get_pins low_speed_misc_wrap_inst/pwm_wrap_u/apb_pwm_fan_u/pwm_fan_core_u/pwm_fan_apb_reg_u/pwm_output_1]
create_static -name [get_pins low_speed_misc_wrap_inst/pwm_wrap_u/apb_pwm_fan_u/pwm_fan_core_u/pwm_fan_apb_reg_u/pwm0_deb_en]
create_static -name [get_pins low_speed_misc_wrap_inst/pwm_wrap_u/apb_pwm_fan_u/pwm_fan_core_u/pwm_fan_apb_reg_u/pwm0_deb_delay_th]
create_static -name [get_pins low_speed_misc_wrap_inst/pwm_wrap_u/apb_pwm_fan_u/pwm_fan_core_u/pwm_fan_apb_reg_u/pwm1_deb_en]
create_static -name [get_pins low_speed_misc_wrap_inst/pwm_wrap_u/apb_pwm_fan_u/pwm_fan_core_u/pwm_fan_apb_reg_u/pwm1_deb_delay_th]
create_static -name [get_pins low_speed_misc_wrap_inst/jtag2axi_top_inst/u_lowspeed_jtag/o_cfg_cmd_reg/Q]
create_static -name [get_pins low_speed_misc_wrap_inst/jtag2axi_top_inst/u_lowspeed_jtag/o_cfg_wdata_reg/Q]
create_static -name [get_pins low_speed_misc_wrap_inst/jtag2axi_top_inst/u_lowspeed_jtag/o_cfg_addr_reg/Q]
create_static -name [get_pins low_speed_misc_wrap_inst/jtag2axi_top_inst/jtag_gen_axi_master_inst/i_cfg_rdata]


# intr
create_static -name [get_pins low_speed_misc_wrap_inst/gpio_top_wrap_u/DW_apb_gpio_u/U_apb_gpio_apbif/gpio_raw_intstatus]
create_static -name [get_pins low_speed_misc_wrap_inst/gpio_top_wrap_u/DW_apb_gpio_u/U_apb_gpio_apbif/gpio_int_polarity]
create_static -name [get_pins low_speed_misc_wrap_inst/gpio_top_wrap_u/DW_apb_gpio_u/U_apb_gpio_ctrl/gpio_intr_flag]
create_static -name [get_pins scp_top_inst/scp_wdt_inst/DW_apb_wdt_inst*/U_DW_apb_wdt_isrc/U_DW_apb_wdt_isrg/r_irq_tc_reg/Q]
create_static -name [get_pins low_speed_misc_wrap_inst/pwm_wrap_u/apb_pwm_fan_u/pwm_fan_core_u/pfwm0_intr_high_reg/Q]
create_static -name [get_pins low_speed_misc_wrap_inst/pwm_wrap_u/apb_pwm_fan_u/pwm_fan_core_u/pfwm0_intr_low_reg/Q]
create_static -name [get_pins low_speed_misc_wrap_inst/pwm_wrap_u/apb_pwm_fan_u/pwm_fan_core_u/pfwm1_intr_high_reg/Q]
create_static -name [get_pins low_speed_misc_wrap_inst/pwm_wrap_u/apb_pwm_fan_u/pwm_fan_core_u/pfwm1_intr_low_reg/Q]

# pad
create_static -name [get_ports PADS_GPIO*]
create_static -name [get_ports PADS_PWM_INPUT*]
