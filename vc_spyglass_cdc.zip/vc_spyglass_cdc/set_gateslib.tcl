#read memory db
read_file -type gateslibdb $G3_NEO_RTL/xxxxxxxx/syn_lib/db/*.db
read_file -type gateslibdb $G3_NEO_RTL/xxxxxxxx/syn_lib/db/*.lib

#read foundry cell db
read_file -type gateslibdb { \
    /Foundry/ARM/samsung_5lpeAT/Standard_Cell/samsung/ln05lpe_sc_m7p5t_flk_lvt_c60_a00_V3.01_pkg/FE-Common_sec240318_0094/LIBERTY/ln05lpe_sc_m7p5t_flk_lvt_c60l10/ln05lpe_sc_m7p5t_flk_lvt_c60l10_sspg_nominal_max_0p7650v_m40c.db_ccs_tn_lvf \
    /Foundry/ARM/samsung_5lpeAT/Standard_Cell/samsung/ln05lpe_sc_m7p5t_flk_lvt_c60_a00_V3.01_pkg/FE-Common_sec240318_0094/LIBERTY/ln05lpe_sc_m7p5t_flk_lvt_c60l08/ln05lpe_sc_m7p5t_flk_lvt_c60l08_sspg_nominal_max_0p7650v_m40c.db_ccs_tn_lvf \
    /Foundry/ARM/samsung_5lpeAT/Standard_Cell/samsung/ln05lpe_sc_m7p5t_flk_rvt_c60_a00_V3.01_pkg/FE-Common_sec240318_0093/LIBERTY/ln05lpe_sc_m7p5t_flk_rvt_c60l08/ln05lpe_sc_m7p5t_flk_rvt_c60l08_sspg_nominal_max_0p7650v_m40c.db_ccs_tn_lvf \
    /Foundry/ARM/samsung_5lpeAT/Standard_Cell/samsung/ln05lpe_sc_m7p5t_flk_rvt_c60_a00_V3.01_pkg/FE-Common_sec240318_0093/LIBERTY/ln05lpe_sc_m7p5t_flk_rvt_c60l10/ln05lpe_sc_m7p5t_flk_rvt_c60l10_sspg_nominal_max_0p7650v_m40c.db_ccs_tn_lvf \
}
