// +FHDR----------------------------------------------------------------------------
// Copyright (c) 2026, Innosilicon, Inc. Confidential Proprietary
// PROJECT NAME  : xxx
// DEPARTMENT    : Digtal Frontend SOC
// AUTHOR        : chenm
// EMAIL         : chenm@innosilicon.com.cn
// CREATE ON     : 2026/03/17 15:06
// FILE NAME     : intlv_addr_hash.v
// DESCRIPTION   :          
//         
// Copyright (c) 2026 Innosilicon.
// ALL RIGHTS RESERVED
// 
// ---------------------------------------------------------------------------------
// Modification History:
// Date         By              Version                 Change Description
// ---------------------------------------------------------------------------------
// 2026/03/17   chenm           1.0                     Original
// 
// -FHDR----------------------------------------------------------------------------

`timescale 1ns/1ps

module intlv_addr_hash#(
    parameter HASH_PLD_W = 40 ,
    parameter ID_W       = 13 ,
    parameter USER_W     = 16 ,
    parameter LEN_W      = 4  ,
    parameter ADDR_W     = 49
)(/*autoarg*/
   // Outputs
   req_ready, hash_paylod, hash_valid,
   // Inputs
   clk, rstn, test_mode, reg_sync_interleave_hash_enable,
   reg_sync_ddr_channel_size, req_id, req_addr, req_len, req_size,
   req_burst, req_lock, req_cache, req_prot, req_valid, req_user,
   req_qos, hash_ready
   );

    input           clk                             ;
    input           rstn                            ;
    input           test_mode                       ;
    // register signal
    input           reg_sync_interleave_hash_enable ;
    input [3:0]     reg_sync_ddr_channel_size       ;


    // from upstram aw/ar signal
    input  [     ID_W-1:0]               req_id     ;
    input  [   ADDR_W-1:0]               req_addr   ;
    input  [    LEN_W-1:0]               req_len    ;
    input  [          2:0]               req_size   ;
    input  [          1:0]               req_burst  ;
    input                                req_lock   ;
    input  [          3:0]               req_cache  ;
    input  [          2:0]               req_prot   ;
    input  [((USER_W>0)?(USER_W-1):0):0] req_user   ;
    input  [        4-1:0]               req_qos    ;
    input                                req_valid  ;
    output                               req_ready  ;

    // send hashshake and calu result to level_sel module
    output  [HASH_PLD_W-1:0]                 hash_paylod ;
    output                              hash_valid  ;
    input                               hash_ready  ;

    wire [HASH_PLD_W-1:0]        paylod_in     ;
    reg  [ 1:0]             hash_div3_h2b ;
    reg  [ 1:0]             hash_div3_2bit ;
    wire [17:0]             hash_out_div3 ;
    reg  [32:0]             addr_calc     ;
    wire                    is_ddr_req    ;
    wire [15:0]             hash_out      ;
    wire                    hash_div3_lo  ;
    wire                    hash_div3_hi  ;

    // ddr req addr range is 0x0010_0000_0000 ~ 0x0012_0000_0000
    // so the addr[36] need is high, and more high addr must be low
    // and the ddr max capacity is 8GB, so the addr[35:33] need keep zero
    assign is_ddr_req = ~|req_addr[ADDR_W-1:37] & req_addr[36] & (~|req_addr[35:33]);

    // accord by the ddr channel size, we need sel addr bit to calu the hash_div3
    always @(*) begin 
        case(reg_sync_ddr_channel_size) 
            4'd1    : hash_div3_h2b = req_addr[31:30];
            4'd3    : hash_div3_h2b = req_addr[32:31];
            default : hash_div3_h2b = 2'd0;
        endcase
    end
    
    // |                 |     2bits_x     |
    // | hash_lo16[15:8] |2'b00|2'b01|2'b10|
    // |-----------------------------------|
    // |       0-85      |2'b00|2'b01|2'b10|
    // |      85-170     |2'b10|2'b00|2'b01|
    // |     170-255     |2'b01|2'b10|2'b00|
    // next we need build a look-up table
    assign hash_out     =  hash_16b(req_addr[27:12]) ;
    assign hash_div3_lo = (hash_out[15:8] <= 8'd85 );
    assign hash_div3_hi = (hash_out[15:8] >= 8'd171);

    always @(*) begin 
        case(hash_div3_h2b)
            2'b00  : hash_div3_2bit = hash_div3_lo ? 2'b00 : hash_div3_hi ? 2'b01 : 2'b10;
            2'b01  : hash_div3_2bit = hash_div3_lo ? 2'b01 : hash_div3_hi ? 2'b10 : 2'b00;
            default: hash_div3_2bit = hash_div3_lo ? 2'b10 : hash_div3_hi ? 2'b00 : 2'b01; 
        endcase
    end

    // according the ddr channel size, we will using the corresponding interleave method to hash the address
    assign hash_out_div3  = {hash_div3_2bit, hash_out};
    wire [32:0] addr_512m = {2'd0, hash_out     , req_addr[30:28], req_addr[11:0]};
    wire [32:0] addr_768m = {1'd0, hash_out_div3, req_addr[29:28], req_addr[11:0]};
    wire [32:0] addr_1g   = {1'd0, hash_out     , req_addr[31:28], req_addr[11:0]};
    wire [32:0] addr_1p5g = {      hash_out_div3, req_addr[30:28], req_addr[11:0]};
    wire [32:0] addr_2g   = {      hash_out     , req_addr[32:28], req_addr[11:0]};

    // if in linear mode, we will direct output the origin addr
    always @(*) begin
        addr_calc = req_addr[32:0];
        if(reg_sync_interleave_hash_enable & is_ddr_req) begin
            case(reg_sync_ddr_channel_size)
                4'd0    : addr_calc[32:0] = addr_512m       ;
                4'd1    : addr_calc[32:0] = addr_768m       ;
                4'd2    : addr_calc[32:0] = addr_1g         ;
                4'd3    : addr_calc[32:0] = addr_1p5g       ;
                4'd4    : addr_calc[32:0] = addr_2g         ;
                default : addr_calc       = req_addr[32:0]  ;
            endcase
        end
    end 
    
    // the hash_16b function
    function automatic  [15:0] hash_16b;
        input [15:0] x;
        begin
            hash_16b[0 ] = x[15] ^ x[13] ^ x[ 4] ^ x[ 0] ;
            hash_16b[1 ] = x[15] ^ x[14] ^ x[13] ^ x[ 5] ^ x[ 4] ^ x[ 1] ^ x[0] ;
            hash_16b[2 ] = x[14] ^ x[13] ^ x[ 6] ^ x[ 5] ^ x[ 4] ^ x[ 2] ^ x[1] ^ x[0] ;
            hash_16b[3 ] = x[15] ^ x[14] ^ x[ 7] ^ x[ 6] ^ x[ 5] ^ x[ 3] ^ x[2] ^ x[1] ;
            hash_16b[4 ] = x[13] ^ x[ 8] ^ x[ 7] ^ x[ 6] ^ x[ 3] ^ x[ 2] ^ x[0] ;
            hash_16b[5 ] = x[14] ^ x[ 9] ^ x[ 8] ^ x[ 7] ^ x[ 4] ^ x[ 3] ^ x[1] ;
            hash_16b[6 ] = x[15] ^ x[10] ^ x[ 9] ^ x[ 8] ^ x[ 5] ^ x[ 4] ^ x[2] ;
            hash_16b[7 ] = x[15] ^ x[13] ^ x[11] ^ x[10] ^ x[ 9] ^ x[ 6] ^ x[5] ^ x[4] ^ x[3] ^ x[0] ;
            hash_16b[8 ] = x[15] ^ x[14] ^ x[13] ^ x[12] ^ x[11] ^ x[10] ^ x[7] ^ x[6] ^ x[5] ^ x[1] ^ x[0] ;
            hash_16b[9 ] = x[14] ^ x[12] ^ x[11] ^ x[ 8] ^ x[ 7] ^ x[ 6] ^ x[4] ^ x[2] ^ x[1] ^ x[0] ;
            hash_16b[10] = x[15] ^ x[13] ^ x[12] ^ x[ 9] ^ x[ 8] ^ x[ 7] ^ x[5] ^ x[3] ^ x[2] ^ x[1] ;
            hash_16b[11] = x[15] ^ x[14] ^ x[10] ^ x[ 9] ^ x[ 8] ^ x[ 6] ^ x[3] ^ x[2] ^ x[0] ;
            hash_16b[12] = x[13] ^ x[11] ^ x[10] ^ x[ 9] ^ x[ 7] ^ x[ 3] ^ x[1] ^ x[0] ;
            hash_16b[13] = x[14] ^ x[12] ^ x[11] ^ x[10] ^ x[ 8] ^ x[ 4] ^ x[2] ^ x[1] ;
            hash_16b[14] = x[15] ^ x[13] ^ x[12] ^ x[11] ^ x[ 9] ^ x[ 5] ^ x[3] ^ x[2] ;
            hash_16b[15] = x[15] ^ x[14] ^ x[12] ^ x[10] ^ x[ 6] ^ x[ 3] ^ x[0] ;
        end
    endfunction

    wire                    valid_out   ;
    wire                    ready_out   ;
    wire [HASH_PLD_W-1:0]   payload_out ;
    wire                    valid_in    ;
    wire                    ready_in    ;
    wire [HASH_PLD_W-1:0]   payload_in  ;

    assign hash_paylod = payload_out ;
    assign hash_valid  = valid_out   ;
    assign ready_in    = hash_ready  ;
    assign valid_in    = req_valid   ;
    assign req_ready   = ready_out   ;

    assign payload_in = {
        req_id               ,
        req_addr             ,
        req_len              ,
        req_size             ,
        req_burst            ,
        req_lock             ,
        req_cache            ,
        req_prot             ,
        req_user             ,
        req_qos              ,
        addr_calc            ,
        is_ddr_req           };

    intlv_axi256_rs_axi_rs_tpi#(.PLD_W(HASH_PLD_W))  slice(
          // Outputs
          .ready_o                          (ready_out),
          .valid_o                          (valid_out),
          .payload_o                        (payload_out[HASH_PLD_W-1:0]),
          // Inputs
          .aclk_i                           (clk),
          .aresetn_i                        (rstn),
          .ready_i                          (ready_in),
          .valid_i                          (valid_in),
          .payload_i                        (payload_in[HASH_PLD_W-1:0]),
          .test_mode                        (test_mode));


endmodule
// Local Variables:
// verilog-library-directories:("-y ./ -y ../")
// verilog-auto-inst-param-value:t
// End:
