// +FHDR----------------------------------------------------------------------------
// Copyright (c) 2026, Innosilicon, Inc. Confidential Proprietary
// PROJECT NAME  : xxx
// DEPARTMENT    : Digtal Frontend SOC
// AUTHOR        : chenm
// EMAIL         : chenm@innosilicon.com.cn
// CREATE ON     : 2026/03/17 19:32
// FILE NAME     : intlv_level_sel.v
// DESCRIPTION   :          
//         
// Copyright (c) 2026 Innosilicon.
// ALL RIGHTS RESERVED
// 
// ---------------------------------------------------------------------------------
// Modification History:
// Date         By              Version                 Change Description
// ---------------------------------------------------------------------------------
// 2026/03/17   chenm           1.0                     Original
// 
// -FHDR----------------------------------------------------------------------------

`timescale 1ns/1ps

module intlv_level_sel #(
    parameter HASH_PLD_W = 53 ,
    parameter ID_W       = 13 ,
    parameter USER_W     = 16 ,
    parameter LEN_W      = 4  ,
    parameter ADDR_W     = 49
)(/*autoarg*/
   // Outputs
   req_id, req_addr, req_len, req_size, req_burst, req_lock,
   req_cache, req_prot, req_valid, req_user, req_qos, hash_ready,
   // Inputs
   clk, rstn, test_mode, req_ready, reg_sync_interleave_hash_enable,
   reg_sync_ddr_channel_size, hash_paylod, hash_valid
   );

    input clk                                       ;
    input rstn                                      ;
    input test_mode                                 ;

    output  [     ID_W-1:0]               req_id    ;
    output  [   ADDR_W-1:0]               req_addr  ;
    output  [    LEN_W-1:0]               req_len   ;
    output  [          2:0]               req_size  ;
    output  [          1:0]               req_burst ;
    output                                req_lock  ;
    output  [          3:0]               req_cache ;
    output  [          2:0]               req_prot  ;
    output  [((USER_W>0)?(USER_W-1):0):0] req_user  ;
    output  [        4-1:0]               req_qos   ;
    output                                req_valid ;
    input                                 req_ready ;

    input           reg_sync_interleave_hash_enable ;
    input [3:0]     reg_sync_ddr_channel_size       ;

    input  [HASH_PLD_W-1:0]                 hash_paylod  ;
    input                              hash_valid   ;
    output                             hash_ready   ;

    parameter LEVEL_SEL_PLD_W = ID_W+LEN_W+3+2+1+4+3+USER_W+4+ADDR_W;

    wire  [     ID_W-1:0]               temp_id    ;
    wire  [   ADDR_W-1:0]               temp_addr  ;
    wire  [    LEN_W-1:0]               temp_len   ;
    wire  [          2:0]               temp_size  ;
    wire  [          1:0]               temp_burst ;
    wire                                temp_lock  ;
    wire  [          3:0]               temp_cache ;
    wire  [          2:0]               temp_prot  ;
    wire  [((USER_W>0)?(USER_W-1):0):0] temp_user  ;
    wire  [        4-1:0]               temp_qos   ;

    wire [32:0]             addr_calc_hash ;
    wire                    is_ddr_req    ;
    assign {
        temp_id               ,
        temp_addr             ,
        temp_len              ,
        temp_size             ,
        temp_burst            ,
        temp_lock             ,
        temp_cache            ,
        temp_prot             ,
        temp_user             ,
        temp_qos              ,
        addr_calc_hash        ,
        is_ddr_req            } = hash_paylod;


    wire [14:0] addr_15b;
    wire [4:0] hash_15b_temp0; 
    wire [4:0] hash_15b_temp1; 
    wire [4:0] hash_15b_temp2; 
    wire [4:0] hash_15b_map0; 
    wire [4:0] hash_15b_map1; 
    wire [4:0] hash_15b_map2; 
    wire [4:0] hash_15b_out0; 
    wire [4:0] hash_15b_out1; 
    wire [4:0] hash_15b_out2; 

    wire [1:0] addr_hash15to2;
    wire [1:0] channel_tag_id;
    wire [ADDR_W-1:0]               addr_calc_out  ;
    reg  [32:0]               addr_calc  ;

    // mask hash_addr 15bit, and we need user origin addr to do this
    assign addr_15b = temp_addr[25:11] ^ {7'd0, temp_addr[33:26]};

    // hash15to2 origin bit assign and use map5to5  to hash
    assign hash_15b_temp0 = {<<{addr_15b[14:10]}}; 
    assign hash_15b_temp1 = {<<{addr_15b[ 9: 5]}}; 
    assign hash_15b_temp2 = {<<{addr_15b[ 4: 0]}}; 

    assign hash_15b_map0 = map5to5_out(hash_15b_temp0);
    assign hash_15b_map1 = map5to5_out(hash_15b_temp1);
    assign hash_15b_map2 = map5to5_out(hash_15b_temp2);

    // the temp0 only just use map5to5, and the temp1 need rotate5by1, the temp2 need rotate5by2
    assign hash_15b_out0 = hash_15b_map0;
    assign hash_15b_out1 = {hash_15b_map1[  0], hash_15b_map1[4:1]};
    assign hash_15b_out2 = {hash_15b_map2[1:0], hash_15b_map2[4:2]};

    assign addr_hash15to2[0] = hash_15b_out0[0] ^ hash_15b_out0[1] ^ hash_15b_out0[4] ^ hash_15b_out1[2] ^ hash_15b_out1[4] ^ hash_15b_out2[1] ^ hash_15b_out2[2] ^ hash_15b_out2[3];
    assign addr_hash15to2[1] = hash_15b_out0[2] ^ hash_15b_out0[3] ^ hash_15b_out1[0] ^ hash_15b_out1[1] ^ hash_15b_out1[3] ^ hash_15b_out2[0] ^ hash_15b_out2[4] ;

    // final xor with addr[10:9] to calu the channel id
    assign channel_tag_id = addr_hash15to2 ^ temp_addr[10:9];

    // if its hash mode and is access ddr, 
    wire [32:0] addr_512m = {channel_tag_id, 2'd0, addr_calc_hash[30:11], temp_addr[8:0]};
    wire [32:0] addr_768m = {channel_tag_id, 1'd0, addr_calc_hash[31:11], temp_addr[8:0]};
    wire [32:0] addr_1g   = {channel_tag_id, 1'd0, addr_calc_hash[31:11], temp_addr[8:0]};
    wire [32:0] addr_1p5g = {channel_tag_id      , addr_calc_hash[32:11], temp_addr[8:0]};
    wire [32:0] addr_2g   = {channel_tag_id      , addr_calc_hash[32:11], temp_addr[8:0]};

    wire [3:0] which_channel = (reg_sync_ddr_channel_size == 4'd1) ? temp_addr[31:28]/4'd3 : temp_addr[32:29]/4'd3;
    wire [3:0] which_block   = (reg_sync_ddr_channel_size == 4'd1) ? temp_addr[31:28]%4'd3 : temp_addr[32:29]%4'd3;

    wire [32:0] addr_linear_512m = {    temp_addr[30:29], 2'd0,                   temp_addr[28:0]};
    wire [32:0] addr_linear_768m = {which_channel[ 1: 0], 1'd0, which_block[1:0], temp_addr[27:0]};
    wire [32:0] addr_linear_1g   = {    temp_addr[31:30], 1'd0,                   temp_addr[29:0]};
    wire [32:0] addr_linear_1p5g = {which_channel[ 1: 0],       which_block[1:0], temp_addr[28:0]};
    wire [32:0] addr_linear_2g   =      temp_addr[32: 0];    


    // accord the ddr channel size to sel correct address process and hash_enable?
    // if not is ddr addr, we will keep origin value
    always @(*) begin
        addr_calc = temp_addr[32:0];
        if(is_ddr_req) begin
            case(reg_sync_ddr_channel_size)
                4'd0    : addr_calc[32:0] = reg_sync_interleave_hash_enable ? addr_512m : addr_linear_512m ;
                4'd1    : addr_calc[32:0] = reg_sync_interleave_hash_enable ? addr_768m : addr_linear_768m ;
                4'd2    : addr_calc[32:0] = reg_sync_interleave_hash_enable ? addr_1g   : addr_linear_1g   ;
                4'd3    : addr_calc[32:0] = reg_sync_interleave_hash_enable ? addr_1p5g : addr_linear_1p5g ;
                4'd4    : addr_calc[32:0] = reg_sync_interleave_hash_enable ? addr_2g   : addr_linear_2g   ;
                default : addr_calc       = temp_addr[32:0] ;
            endcase
        end
    end

    assign addr_calc_out = is_ddr_req ? {{ADDR_W-37{1'd0}} ,4'd8, addr_calc[32:0]} : temp_addr ; 


    // the map5to5 function
    function automatic [4:0] map5to5_out;
        input [4:0] x;
        begin
            map5to5_out = 5'h0;
            case(x)
                5'h00   : map5to5_out = 5'h00 ;
                5'h01   : map5to5_out = 5'h03 ;
                5'h02   : map5to5_out = 5'h12 ;
                5'h03   : map5to5_out = 5'h18 ;
                5'h04   : map5to5_out = 5'h07 ;
                5'h05   : map5to5_out = 5'h06 ;
                5'h06   : map5to5_out = 5'h0e ;
                5'h07   : map5to5_out = 5'h01 ;
                5'h08   : map5to5_out = 5'h04 ;
                5'h09   : map5to5_out = 5'h1d ;
                5'h0a   : map5to5_out = 5'h14 ;
                5'h0b   : map5to5_out = 5'h0c ;
                5'h0c   : map5to5_out = 5'h1a ;
                5'h0d   : map5to5_out = 5'h0f ;
                5'h0e   : map5to5_out = 5'h08 ;
                5'h0f   : map5to5_out = 5'h0a ;
                5'h10   : map5to5_out = 5'h0b ;
                5'h11   : map5to5_out = 5'h19 ;
                5'h12   : map5to5_out = 5'h1e ;
                5'h13   : map5to5_out = 5'h17 ;
                5'h14   : map5to5_out = 5'h1f ;
                5'h15   : map5to5_out = 5'h10 ;
                5'h16   : map5to5_out = 5'h02 ;
                5'h17   : map5to5_out = 5'h11 ;
                5'h18   : map5to5_out = 5'h16 ;
                5'h19   : map5to5_out = 5'h0d ;
                5'h1a   : map5to5_out = 5'h1b ;
                5'h1b   : map5to5_out = 5'h15 ;
                5'h1c   : map5to5_out = 5'h13 ;
                5'h1d   : map5to5_out = 5'h09 ;
                5'h1e   : map5to5_out = 5'h1c ;
                default : map5to5_out = 5'h05 ;
            endcase
        end
    endfunction

    wire [LEVEL_SEL_PLD_W-1:0]    paylod_in  ;
    wire [LEVEL_SEL_PLD_W-1:0]    paylod_out ;
    wire                          valid_out  ;
    wire                          ready_out  ;
    wire                          valid_in   ;
    wire                          ready_in   ;

    assign valid_in   = hash_valid ;
    assign hash_ready = ready_out  ;
    assign ready_in   = req_ready  ;
    assign req_valid  = valid_out  ;

    assign paylod_in = {
        temp_id       ,
        addr_calc_out ,
        temp_len      ,
        temp_size     ,
        temp_burst    ,
        temp_lock     ,
        temp_cache    ,
        temp_prot     ,
        temp_user     ,
        temp_qos      };

    assign {
        req_id               ,
        req_addr             ,
        req_len              ,
        req_size             ,
        req_burst            ,
        req_lock             ,
        req_cache            ,
        req_prot             ,
        req_user             ,
        req_qos              } = paylod_out;
intlv_axi256_rs_axi_rs_tpi#(.PLD_W(LEVEL_SEL_PLD_W))  slice(
      // Outputs
      .ready_o                          (ready_out),
      .valid_o                          (valid_out),
      .payload_o                        (paylod_out[LEVEL_SEL_PLD_W-1:0]),
      // Inputs
      .aclk_i                           (clk),
      .aresetn_i                        (rstn),
      .ready_i                          (ready_in),
      .valid_i                          (valid_in),
      .payload_i                        (paylod_in[LEVEL_SEL_PLD_W-1:0]),
      .test_mode                        (test_mode));

endmodule
// Local Variables:
// verilog-library-directories:("-y ./ -y ../")
// verilog-auto-inst-param-value:t
// End:
